/*
 * Copyright © 2001-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <unistd.h>
#include <sx/acl_helper/sx_acl_helper.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_acl.h>
#include <sx/sdk/sx_strings.h>
#include <complib/sx_log.h>
#include <complib/cl_types.h>
#include <complib/cl_fleximap.h>
#include <complib/cl_thread.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_mem.h>
#include <complib/cl_math.h>
#include <complib/cl_dbg.h>

#undef  __MODULE__
#define __MODULE__ SX_ACL_HELPER

/************************************************
 *  Local Macros
 ***********************************************/
#define REGION_ID_GET(RULE_ID)   ((RULE_ID >> 32) & 0x00000000FFFFFFFF)
#define RULE_OFFSET_GET(RULE_ID) (RULE_ID & 0x00000000FFFFFFFF)

#define ACL_HELPER_CHECK_NULL_PTR(ptr, ptr_name)              \
    do {                                                      \
        if (ptr == NULL) {                                    \
            err = SX_ACL_HELPER_STATUS_PARAM_NULL;            \
            SX_LOG_ERR("Parameter %s is NULL.\n", #ptr_name); \
            goto out;                                         \
        }                                                     \
    } while (0)

#define ACL_HELPER_CHECK_INITIALIZED(init_done)                \
    do {                                                       \
        if (!init_done) {                                      \
            err = SX_ACL_HELPER_STATUS_NOT_INITIALIZED;        \
            SX_LOG_ERR("SX ACL Helper is not initialized.\n"); \
            goto out;                                          \
        }                                                      \
    } while (0)

#define ACL_HELPER_CHECK_FAIL(STATUS) (ACL_HELPER_STATUS_SUCCESS != (STATUS))

/************************************************
 *  Local Type definitions
 ***********************************************/
#define ACL_HELPER_ACL_NAME_LEN_MAX 128

#define ACL_HELPER_CACHE_CLEAN_INTERVAL 2
#define ACL_HELPER_RULE_NUMBER_MIN      64
#define ACL_HELPER_RULE_NUMBER_MAX      200 * 1024
#define ACL_HELPER_RULE_NUMBER_GROW     64

#define ACL_HELPER_KEY_LEN_MAX    512
#define ACL_HELPER_ACTION_LEN_MAX 128
#define ACL_HELPER_RULE_DESC_LEN  32

typedef struct acl_helper_rule_key {
    sx_acl_helper_acl_id_t  acl_id;
    sx_acl_helper_rule_id_t rule_id;
} acl_helper_rule_key_t;

typedef struct acl_helper_rule {
    cl_pool_item_t          pool_item;
    cl_fmap_item_t          map_item;
    acl_helper_rule_key_t   key;
    sx_acl_helper_acl_id_t  acl_id;
    sx_acl_helper_rule_id_t rule_id;
    char                   *rule_p;
    char                    acl_name[ACL_HELPER_ACL_NAME_LEN_MAX];
} acl_helper_rule_entry_t;

typedef struct acl_helper_db {
    cl_fmap_t  rule_lookup;   /* acl id+ rule id to rule record */
    cl_qpool_t rule_pool;
} acl_helper_db_t;

#define KEY_ID_2STR(key_id) sx_acl_key_str(key_id)

#define ACTION_ID_2STR(action_id) sx_flex_acl_flex_action_type_str(action_id)

char * mac_type_str_arr[] = {
    [SX_ACL_L2_DMAC_TYPE_MULTICAST] = "MULTICAST",
    [SX_ACL_L2_DMAC_TYPE_BROADCAST] = "BROADCAST",
    [SX_ACL_L2_DMAC_TYPE_UNICAST] = "UNICAST",
    [SX_ACL_L2_DMAC_TYPE_LAST] = "INVALID",
};
#define KEY_MAC_TYPE_2STR(key) ((key) < SX_ACL_L2_DMAC_TYPE_LAST) ? mac_type_str_arr[(key)] : "invalid"

char* l3_type_str_arr[] = {
    [SX_ACL_L3_TYPE_IPV4] = "IPV4",
    [SX_ACL_L3_TYPE_IPV6] = "IPV6",
    [SX_ACL_L3_TYPE_ARP] = "ARP",
    [SX_ACL_L3_TYPE_OTHER] = "OTHER",
    [SX_ACL_L3_TYPE_LAST] = "INVALID",
};
#define KEY_L3_TYPE_2STR(key) ((key) < SX_ACL_L3_TYPE_LAST) ? l3_type_str_arr[(key)] : "invalid"

char* l4_type_str_arr[] = {
    [SX_ACL_L4_TYPE_INVALID] = "INVALID",
    [SX_ACL_L4_TYPE_TCP] = "TCP",
    [SX_ACL_L4_TYPE_UDP] = "UDP",
    [SX_ACL_L4_TYPE_TCP_UDP] = "TCP_UDP",
    [SX_ACL_L4_TYPE_OTHER] = "OTHER",
    [SX_ACL_L4_TYPE_LAST] = "INVALID",
};
#define KEY_L4_TYPE_2STR(key) ((key) < SX_ACL_L4_TYPE_LAST) ? l4_type_str_arr[(key)] : "invalid"

char* l4_type_extended_str_arr[] = {
    [SX_ACL_L4_TYPE_EXTENDED_TCP] = "TCP",
    [SX_ACL_L4_TYPE_EXTENDED_UDP] = "UDP",
    [SX_ACL_L4_TYPE_EXTENDED_BTH] = "BTH",
    [SX_ACL_L4_TYPE_EXTENDED_BTHOUDP] = "BTHOUDP",
    [SX_ACL_L4_TYPE_EXTENDED_ICMP] = "ICMP",
    [SX_ACL_L4_TYPE_EXTENDED_IGMP] = "IGMP",
    [SX_ACL_L4_TYPE_EXTENDED_AH] = "AH",
    [SX_ACL_L4_TYPE_EXTENDED_ESP] = "ESP",
    [SX_ACL_L4_TYPE_EXTENDED_RAW] = "RAW",
    [SX_ACL_L4_TYPE_EXTENDED_OTHERS] = "OTHERS",
    [SX_ACL_L4_TYPE_EXTENDED_LAST] = "INVALID",
};
#define KEY_L4_TYPE_EXT_2STR(key) ((key) < SX_ACL_L4_TYPE_EXTENDED_LAST) ? l4_type_extended_str_arr[(key)] : "invalid"

char* discard_state_str_arr[] = {
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD] = "FORWARD",
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD] = "DISCARD",
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD] = "SOFT_DISCARD",
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT] = "PERMIT",
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_LAST] = "INVALID",
};
#define KEY_DISCARD_STATE_2STR(key) \
    ((key) <                        \
     SX_ACL_TRAP_FORWARD_ACTION_TYPE_LAST) ? discard_state_str_arr[(key)] : "invalid"

char* port_list_match_str_arr[] = {
    [SX_ACL_PORT_LIST_MATCH_NEGATIVE] = "PORT_LIST_MATCH_NEGATIVE",
    [SX_ACL_PORT_LIST_MATCH_POSITIVE] = "PORT_LIST_MATCH_POSITIVE",
    [SX_ACL_PORT_LIST_MATCH_LAST] = "INVALID",
};
#define KEY_PORT_LIST_MATCH_2STR(key) \
    ((key) <                          \
     SX_ACL_PORT_LIST_MATCH_LAST) ? port_list_match_str_arr[(key)] : "invalid"

char* color_str_arr[] = {
    [SX_ACL_FLEX_COLOR_GREEN] = "GREEN",
    [SX_ACL_FLEX_COLOR_YELLOW] = "YELLOW",
    [SX_ACL_FLEX_COLOR_RED] = "RED",
    [SX_ACL_FLEX_COLOR_LAST] = "INVALID",
};
#define KEY_COLOR_2STR(key) ((key) < SX_ACL_FLEX_COLOR_LAST) ? color_str_arr[(key)] : "invalid"

char* mc_type_str_arr[] = {
    [SX_ACL_MC_TYPE_FLOOD_FOR_UC] = "FLOOD_FOR_UC",
    [SX_ACL_MC_TYPE_BC] = "BC",
    [SX_ACL_MC_TYPE_FLOOD_MC_NON_IP] = "FLOOD_MC_NON_IP",
    [SX_ACL_MC_TYPE_FLOOD_MC_IPV4] = "FLOOD_MC_IPV4",
    [SX_ACL_MC_TYPE_FLOOD_MC_IPV4_LINK_LOCAL] = "FLOOD_MC_IPV4_LINK_LOCAL",
    [SX_ACL_MC_TYPE_FLOOD_MC_IPV6] = "FLOOD_MC_IPV6",
    [SX_ACL_MC_TYPE_FLOOD_MC_IPV6_NODES_LOCAL] = "FLOOD_MC_IPV6_NODES_LOCAL",
    [SX_ACL_MC_TYPE_FLOOD_MC_ROCE_V1] = "FLOOD_MC_ROCE_V1",
};

#define KEY_MC_TYPE_2STR(key) ((key) < SX_ACL_MC_TYPE_MAX) ? mc_type_str_arr[(key)] : "invalid"

char* ipv6_extension_header_str_arr[] = {
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_NONE] = "IPV6_EXTENSION_HEADER_NONE",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_ROUTING] = "IPV6_EXTENSION_HEADER_ROUTING",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_FRAGMENT] = "IPV6_EXTENSION_HEADER_FRAGMENT",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_DESTINATION_OPTIONS] = "IPV6_EXTENSION_HEADER_DESTINATION_OPTIONS",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_AUTHENTICATION] = "IPV6_EXTENSION_HEADER_AUTHENTICATION",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_ESP] = "IPV6_EXTENSION_HEADER_ESP",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_MOBILITY] = "IPV6_EXTENSION_HEADER_MOBILITY",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH] = "IPV6_EXTENSION_HEADER_HBH",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_SHIM6] = "IPV6_EXTENSION_HEADER_SHIM6",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HOST_IDENTIFY_PROTOCOL] = "IPV6_EXTENSION_HEADER_HOST_IDENTIFY_PROTOCOL",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_HBH_ROUTER_ALERT] = "IPV6_EXTENSION_HEADER_HBH_ROUTER_ALERT",
    [SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST] = "INVALID"
};
#define KEY_IPV6_EXTENSION_2STR(key)                                                  \
    ((key) <                                                                          \
     SX_FLEX_ACL_IPV6_EXTENSION_HEADER_LAST) ? ipv6_extension_header_str_arr[(key)] : \
    "invalid"

char* nd_sll_or_tll_valid_str_arr[] = {
    [SX_ACL_NO_ND_SLL_OR_TTL] = "NO_ND_SLL_OR_TLL",
    [SX_ACL_ND_SLL] = "ND_SLL",
    [SX_ACL_ND_TLL] = "ND_TTL",
    [SX_ACL_ND_LAST] = "INVALID"
};
#define KEY_ND_SLL_OR_TLL_VALID_2STR(key) ((key) < SX_ACL_ND_LAST) ? nd_sll_or_tll_valid_str_arr[(key)] : "invalid"

char * act_fwd_2str[SX_ACL_TRAP_FORWARD_ACTION_TYPE_LAST + 1] = {
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD] = "FORWARD",
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD] = "DISCARD",
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_SOFT_DISCARD] = "SOFT_DISCARD",
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT] = "PERMIT",
    [SX_ACL_TRAP_FORWARD_ACTION_TYPE_LAST] = "INVALID",
};
#define ACT_FWD_2STR(act) ((act) < SX_ACL_TRAP_FORWARD_ACTION_TYPE_LAST) ? act_fwd_2str[(act)] : "invalid"

char * act_trap_2str[SX_ACL_TRAP_ACTION_TYPE_LAST + 1] = {
    [SX_ACL_TRAP_ACTION_TYPE_TRAP] = "TRAP",
    [SX_ACL_TRAP_ACTION_TYPE_DISCARD] = "DISCARD",
    [SX_ACL_TRAP_ACTION_TYPE_SOFT_DISCARD] = "SOFT_DISCARD",
    [SX_ACL_TRAP_ACTION_TYPE_LAST] = "INVALID",
};
#define ACT_TRAP_2STR(act) ((act) < SX_ACL_TRAP_ACTION_TYPE_LAST) ? act_trap_2str[(act)] : "invalid"

char* vlan_cmd_dict[] = {"PUSH", "POP", "INVALID"};
#define ACT_VLAN_CMD_2STR(cmd) ((cmd) < SX_ACL_FLEX_SET_VLAN_CMD_TYPE_LAST) ? vlan_cmd_dict[(cmd)] : "invalid"

char* vlan_qos_dict[] = {"UNIFORM", "PIPE", "INVALID"};
#define ACT_VLAN_QOS_2STR(qos) ((qos) < SX_ACL_FLEX_QINQ_TUNNEL_QOS_LAST) ? vlan_qos_dict[(qos)] : "invalid"

char* act_color_2str[SX_ACL_FLEX_COLOR_LAST + 1] = {
    [SX_ACL_FLEX_COLOR_GREEN] = "GREEN",
    [SX_ACL_FLEX_COLOR_YELLOW] = "YELLOW",
    [SX_ACL_FLEX_COLOR_RED] = "RED",
    [SX_ACL_FLEX_COLOR_LAST] = "INVALID",
};
#define ACT_COLOR_2STR(act) ((act) < SX_ACL_FLEX_COLOR_LAST) ? act_color_2str[(act)] : "invalid"

char * act_rpf_action_2str[SX_ACL_RPF_ACTION_TYPE_LAST + 1] = {
    [SX_ACL_RPF_ACTION_TYPE_DISABLED] = "DISABLELD",
    [SX_ACL_RPF_ACTION_TYPE_DROP] = "DROP",
    [SX_ACL_RPF_ACTION_TYPE_TRAP] = "TRAP",
    [SX_ACL_RPF_ACTION_TYPE_LAST] = "INVALID",
};
#define ACT_RPF_ACTION_2STR(act) ((act) < SX_ACL_RPF_ACTION_TYPE_LAST) ? act_rpf_action_2str[(act)] : "invalid"

char * act_rpf_param_type_2str[SX_ACL_FLEX_RPF_PARAM_TYPE_LAST + 1] = {
    [SX_ACL_FLEX_RPF_PARAM_TYPE_IRIF] = "IRIF",
    [SX_ACL_FLEX_RPF_PARAM_TYPE_RPF_GROUP] = "RPF_GROUP",
    [SX_ACL_FLEX_RPF_PARAM_TYPE_LAST] = "INVALID",
};
#define ACT_RPF_PARAM_TYPE_2STR(act) \
    ((act) <                         \
     SX_ACL_FLEX_RPF_PARAM_TYPE_LAST) ? act_rpf_param_type_2str[(act)] : "invalid"

char * act_goto_cmd_2str[SX_ACL_ACTION_GOTO_LAST + 1] = {
    [SX_ACL_ACTION_GOTO_JUMP] = "JUMP",
    [SX_ACL_ACTION_GOTO_CALL] = "CALL",
    [SX_ACL_ACTION_GOTO_BREAK] = "BREAK",
    [SX_ACL_ACTION_GOTO_TERMINATE] = "TERMINATE",
    [SX_ACL_ACTION_GOTO_LAST] = "INVALID",
};
#define ACT_GOTO_CMD_2STR(act) ((act) < SX_ACL_ACTION_GOTO_LAST) ? act_goto_cmd_2str[(act)] : "invalid"

char * uc_route_type_2str[SX_UC_ROUTE_TYPE_MAX + 1] = {
    [SX_UC_ROUTE_TYPE_LOCAL] = "LOCAL",
    [SX_UC_ROUTE_TYPE_NEXT_HOP] = "REMOTE",
};
#define UC_ROUTE_TYPE_2STR(type) \
    ((type) <= SX_UC_ROUTE_TYPE_LOCAL) ? uc_route_type_2str[(type)] : "invalid"

char * rewrite_cmd_2str[SX_ACL_ACTION_REWRITE_LAST + 1] = {
    [SX_ACL_ACTION_REWRITE_ENABLE] = "REWRITE ENABLE",
    [SX_ACL_ACTION_REWRITE_DISABLE] = "REWRITE DISABLE",
    [SX_ACL_ACTION_REWRITE_LAST] = "INVALID",
};
#define REWRITE_CMD_2STR(type) \
    ((type) <= SX_ACL_ACTION_REWRITE_LAST) ? rewrite_cmd_2str[(type)] : "invalid"

char * act_hash_type_2str[SX_ACL_ACTION_HASH_TYPE_LAST + 1] = {
    [SX_ACL_ACTION_HASH_TYPE_LAG] = "LAG",
    [SX_ACL_ACTION_HASH_TYPE_ECMP] = "ECMP",
    [SX_ACL_ACTION_HASH_TYPE_LAST] = "INVALID",
};
#define ACT_HASH_TYPE_2STR(type) \
    ((type) < SX_ACL_ACTION_HASH_TYPE_LAST) ? act_hash_type_2str[(type)] : "invalid"

char * act_hash_cmd_2str[SX_ACL_ACTION_HASH_COMMAND_LAST + 1] = {
    [SX_ACL_ACTION_HASH_COMMAND_NONE] = "NONE",
    [SX_ACL_ACTION_HASH_COMMAND_SET] = "SET",
    [SX_ACL_ACTION_HASH_COMMAND_XOR] = "XOR",
    [SX_ACL_ACTION_HASH_COMMAND_RANDOM] = "RANDOM",
    [SX_ACL_ACTION_HASH_COMMAND_COPY] = "COPY",
    [SX_ACL_ACTION_HASH_COMMAND_SWAP] = "SWAP",
    [SX_ACL_ACTION_HASH_COMMAND_LAST] = "INVALID",
};
#define ACT_HASH_CMD_2STR(cmd) \
    ((cmd) < SX_ACL_ACTION_HASH_COMMAND_LAST) ? act_hash_cmd_2str[(cmd)] : "invalid"
/************************************************
 *  Global variables
 ***********************************************/
acl_helper_db_t acl_helper_db_g;
boolean_t       acl_helper_inited_g = FALSE;
sx_api_handle_t acl_helper_sx_api_handle_g;

/************************************************
 *  Local variables
 ***********************************************/
static cl_thread_t   acl_helper_thread_id_s;
static cl_spinlock_t acl_helper_spinlock_s;
static boolean_t     acl_helper_stop_thread_s = FALSE;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

#define FORMAT_BUFFER_SIZE 50

static inline const char* format_ip_addr(const sx_ip_addr_t *ip_addr, char *ip_addr_str)
{
    sx_ip_v4_addr_t ip4;
    sx_ip_v6_addr_t ip6;
    uint32_t        i = 0;

    if (!ip_addr) {
        return "NULL IP";
    }

    if (ip_addr->version == SX_IP_VERSION_IPV4) {
        ip4.s_addr = htonl(ip_addr->addr.ipv4.s_addr);
        return inet_ntop(AF_INET, &ip4, ip_addr_str, FORMAT_BUFFER_SIZE);
    } else if (ip_addr->version == SX_IP_VERSION_IPV6) {
        for (i = 0; i < 4; i++) {
            ip6.s6_addr32[i] = htonl(ip_addr->addr.ipv6.s6_addr32[i]);
        }
        return inet_ntop(AF_INET6, &ip6, ip_addr_str, FORMAT_BUFFER_SIZE);
    } else {
        return "Invalid IP version";
    }
}

static inline void __acl_helper_mac_to_str(sx_mac_addr_t mac, char* mac_str)
{
    sprintf(mac_str, "%02x:%02x:%02x:%02x:%02x:%02x",
            mac.ether_addr_octet[0], mac.ether_addr_octet[1], mac.ether_addr_octet[2],
            mac.ether_addr_octet[3], mac.ether_addr_octet[4], mac.ether_addr_octet[5]);
}

static int __acl_helper_rule_key_compare(const void *const key1_p, const void *const key2_p)
{
    acl_helper_rule_key_t *acl_rule_key1_p = (acl_helper_rule_key_t*)key1_p;
    acl_helper_rule_key_t *acl_rule_key2_p = (acl_helper_rule_key_t*)key2_p;

    if (acl_rule_key1_p->acl_id > acl_rule_key2_p->acl_id) {
        return 1;
    } else if (acl_rule_key1_p->acl_id < acl_rule_key2_p->acl_id) {
        return -1;
    }

    if (acl_rule_key1_p->rule_id > acl_rule_key2_p->rule_id) {
        return 1;
    } else if (acl_rule_key1_p->rule_id < acl_rule_key2_p->rule_id) {
        return -1;
    }

    return 0;
}

static void get_action_str(sx_flex_acl_flex_action_t *action_p, char* action_field)
{
#define GET_ACTION_FIELD_STR(ACTION_TYPE, ACTION_TITLE, ACTION_FIELD)                              \
case ACTION_TYPE:                                                                                  \
    sprintf(action_field, "%s = %" PRIu64, ACTION_TITLE, (uint64_t)action_p->fields.ACTION_FIELD); \
    goto out;                                                                                      \
    break;

    switch (action_p->type) {
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_COUNTER, "COUNTER_ID", action_counter.counter_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_MIRROR, "SESSION_ID", action_mirror.session_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_POLICER, "POLICER_ID", action_policer.policer_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_PRIO, "PRIO", action_set_prio.prio_val)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID, "VLAN_ID", action_set_inner_vlan_id.vlan_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID, "VLAN_ID", action_set_outer_vlan_id.vlan_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_DSCP, "DSCP", action_set_dscp.dscp_val)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_BRIDGE, "BRIDGE_ID", action_set_bridge.bridge_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_PBS, "PBS_ID", action_pbs.pbs_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_TC, "TC", action_set_tc.tc_val)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_TTL, "TTL", action_set_ttl.ttl_val)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_DEC_TTL, "TTL", action_dec_ttl.ttl_val)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_ECN, "ECN", action_set_ecn.ecn_val)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_MC_ROUTE, "MC_CONTAINER_ID", action_mc_route.egress_mc_container)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_TUNNEL_DECAP, "TUNNEL_ID", action_tunnel_decap.tunnel_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_ROUTER, "VR_ID", action_set_router.vrid)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_MC, "MC_CONTAINER_ID", action_mc.mc_container_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_EGRESS_MIRROR, "SESSION_ID", action_egress_mirror.session_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_PORT_FILTER, "MC_CONTAINER_ID", action_port_filter.mc_container_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_MPLS_TTL, "TTL", action_set_mpls_ttl.ttl_val)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_DEC_MPLS_TTL, "TTL", action_dec_mpls_ttl.ttl_val)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_EXP, "EXP", action_set_exp.exp_val)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_PBILM, "PBLIM_ID", action_pbilm.pbilm_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP,
                             "MC_CONTAINER_ID",
                             action_nve_mc_tunnel_encap.mc_container_id)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_L4_SRC_PORT, "L4_PORT", action_set_l4_src_port.l4_port)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_L4_DST_PORT, "L4_PORT", action_set_l4_dst_port.l4_port)
        GET_ACTION_FIELD_STR(SX_FLEX_ACL_ACTION_SET_VNI, "VNI", action_vni.vni_value)

    default:
        break;
    }

    switch (action_p->type) {
    case SX_FLEX_ACL_ACTION_FORWARD:
        sprintf(action_field, "FORWARD_ACTION = %s", ACT_FWD_2STR(action_p->fields.action_forward.action));
        break;

    case SX_FLEX_ACL_ACTION_TRAP:
        sprintf(action_field, "TRAP_ACTION = %s, TRAP_ID = %d",
                ACT_TRAP_2STR(action_p->fields.action_trap.action), action_p->fields.action_trap.trap_id);
        break;

    case SX_FLEX_ACL_ACTION_SET_VLAN:
        sprintf(action_field, "VLAN_ID = %d, CMD = %s, QOS = %s, PCP = %d, DEI = %d",
                action_p->fields.action_set_vlan.vlan_id,
                ACT_VLAN_CMD_2STR(action_p->fields.action_set_vlan.cmd),
                ACT_VLAN_QOS_2STR(action_p->fields.action_set_vlan.qinq_tunnel_qos),
                action_p->fields.action_set_vlan.qinq_tunnel_qos_fields.pipe.pcp,
                action_p->fields.action_set_vlan.qinq_tunnel_qos_fields.pipe.dei);
        break;

    case SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI:
        sprintf(action_field, "PCP = %d, DEI = %d",
                action_p->fields.action_set_inner_vlan_prio.pcp,
                action_p->fields.action_set_inner_vlan_prio.dei);
        break;

    case SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI:
        sprintf(action_field, "PCP = %d, DEI = %d",
                action_p->fields.action_set_outer_vlan_prio.pcp,
                action_p->fields.action_set_outer_vlan_prio.dei);
        break;

    case SX_FLEX_ACL_ACTION_SET_SRC_MAC:
        sprintf(action_field, "SRC_MAC = ");
        action_field += strlen(action_field);
        __acl_helper_mac_to_str(action_p->fields.action_set_src_mac.mac, action_field);
        break;

    case SX_FLEX_ACL_ACTION_SET_DST_MAC:
        sprintf(action_field, "DST_MAC = ");
        action_field += strlen(action_field);
        __acl_helper_mac_to_str(action_p->fields.action_set_src_mac.mac, action_field);
        break;

    case SX_FLEX_ACL_ACTION_SET_COLOR:
        sprintf(action_field, "COLOR = %s", ACT_COLOR_2STR(action_p->fields.action_set_color.color_val));
        break;

    case SX_FLEX_ACL_ACTION_SET_USER_TOKEN:
        sprintf(action_field, "USER_TOKEN = 0x%x, MASK = 0x%x",
                action_p->fields.action_set_user_token.user_token,
                action_p->fields.action_set_user_token.mask);
        break;

    case SX_FLEX_ACL_ACTION_DONT_LEARN:
        break;

    case SX_FLEX_ACL_ACTION_RPF:
        sprintf(action_field, "RPF_ACTION = %s",
                ACT_RPF_ACTION_2STR(action_p->fields.action_rpf.rpf_action));
        action_field += strlen(action_field);
        if (action_p->fields.action_rpf.rpf_action != SX_ACL_RPF_ACTION_TYPE_DISABLED) {
            sprintf(action_field, " RPF_ACTION_PRARM = %s, RPF_ACTION_VALUE = %d",
                    ACT_RPF_PARAM_TYPE_2STR(action_p->fields.action_rpf.rpf_param.rpf_param_type),
                    action_p->fields.action_rpf.rpf_param.rpf_param_value.rpf_group);
            action_field += strlen(action_field);
            if (action_p->fields.action_rpf.rpf_param.rpf_param_type ==
                SX_ACL_FLEX_RPF_PARAM_TYPE_IRIF) {
                sprintf(action_field, " RPF_RIF = %d",
                        action_p->fields.action_rpf.rpf_param.rpf_param_value.rpf_rif);
            } else if (action_p->fields.action_rpf.rpf_param.rpf_param_type ==
                       SX_ACL_FLEX_RPF_PARAM_TYPE_RPF_GROUP) {
                sprintf(action_field, " RPF_GROUP = %d",
                        action_p->fields.action_rpf.rpf_param.rpf_param_value.rpf_group);
            }
        }

        break;

    case SX_FLEX_ACL_ACTION_GOTO:
        sprintf(action_field, "GOTO_ACTION = %s",
                ACT_GOTO_CMD_2STR(action_p->fields.action_goto.goto_action_cmd));
        action_field += strlen(action_field);
        if ((action_p->fields.action_goto.goto_action_cmd ==
             SX_ACL_ACTION_GOTO_JUMP) ||
            (action_p->fields.action_goto.goto_action_cmd ==
             SX_ACL_ACTION_GOTO_CALL)) {
            sprintf(action_field, " ACL_GROUP_ID = %d", action_p->fields.action_goto.acl_group_id);
        }

        break;

    case SX_FLEX_ACL_ACTION_UC_ROUTE:
        sprintf(action_field, "UC_ROUTE_TYPE = %s",
                UC_ROUTE_TYPE_2STR(action_p->fields.action_uc_route.uc_route_type));

        action_field += strlen(action_field);
        switch (action_p->fields.action_uc_route.uc_route_type) {
        case SX_UC_ROUTE_TYPE_LOCAL:
            sprintf(action_field, " LOCAL_EGRESS_RIF = %d",
                    action_p->fields.action_uc_route.uc_route_param.local_egress_rif);
            break;

        case SX_UC_ROUTE_TYPE_NEXT_HOP:
            sprintf(action_field, " ECMP_ID = %d",
                    action_p->fields.action_uc_route.uc_route_param.ecmp_id);
            break;

        default:
            break;
        }
        break;

    case SX_FLEX_ACL_ACTION_SET_DSCP_REWRITE:
        sprintf(action_field, "REWRITE_CMD = %s",
                REWRITE_CMD_2STR(action_p->fields.action_set_dscp_rewrite.set_rewrite_cmd));
        break;

    case SX_FLEX_ACL_ACTION_SET_PCP_REWRITE:
        sprintf(action_field, "REWRITE_CMD = %s",
                REWRITE_CMD_2STR(action_p->fields.action_set_pcp_rewrite.set_rewrite_cmd));
        break;

    case SX_FLEX_ACL_ACTION_IGNORE_EGRESS_VLAN_FILTER:
        break;

    case SX_FLEX_ACL_ACTION_IGNORE_EGRESS_STP_FILTER:
        break;

    case SX_FLEX_ACL_ACTION_DISABLE_OVERLAY_LEARNING:
        break;

    case SX_FLEX_ACL_ACTION_SET_EXP_REWRITE:
        sprintf(action_field, "REWRITE_CMD = %s",
                REWRITE_CMD_2STR(action_p->fields.action_set_exp_rewrite.set_rewrite_cmd));
        break;

    case SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP:
        sprintf(action_field, "TUNNEL_ID = %d, UNDERLAY_DIP = ",
                action_p->fields.action_nve_tunnel_encap.tunnel_id);
        action_field += strlen(action_field);
        format_ip_addr(&action_p->fields.action_nve_tunnel_encap.underlay_dip, action_field);
        break;

    case SX_FLEX_ACL_ACTION_TRAP_W_USER_ID:
        sprintf(action_field, "TRAP_ACTION = %s, TRAP_ID = 0x%x, USER_ID = 0x%x",
                ACT_TRAP_2STR(action_p->fields.action_trap_w_user_id.action),
                action_p->fields.action_trap_w_user_id.trap_id,
                action_p->fields.action_trap_w_user_id.user_id);
        break;

    case SX_FLEX_ACL_ACTION_SET_SIP_ADDR:
        format_ip_addr(&action_p->fields.action_set_sip.ip_addr, action_field);
        break;

    case SX_FLEX_ACL_ACTION_SET_DIP_ADDR:
        format_ip_addr(&action_p->fields.action_set_dip.ip_addr, action_field);
        break;

    case SX_FLEX_ACL_ACTION_SET_SIPV6_ADDR:
        format_ip_addr(&action_p->fields.action_set_sipv6.ip_addr, action_field);
        break;

    case SX_FLEX_ACL_ACTION_SET_DIPV6_ADDR:
        format_ip_addr(&action_p->fields.action_set_dipv6.ip_addr, action_field);
        break;

    case SX_FLEX_ACL_ACTION_HASH:
        sprintf(action_field, "HASH_TYPE = %s, HASH_CMD = %s, HASH_VALUE = 0x%x",
                ACT_HASH_TYPE_2STR(action_p->fields.action_hash.type),
                ACT_HASH_CMD_2STR(action_p->fields.action_hash.command),
                action_p->fields.action_hash.hash_value);
        break;

    case SX_FLEX_ACL_ACTION_SWAP_INNER_OUTER_VLAN:
        break;

    case SX_FLEX_ACL_ACTION_SET_VNI:
        break;

    case SX_FLEX_ACL_ACTION_TRUNCATION:
        sprintf(action_field, "TRUNC_EN = %s, TRUNC_ID = %d",
                (action_p->fields.action_truncation.trunc_en ? "TRUE" : "FALSE"),
                action_p->fields.action_truncation.trunc_profile_id.trunc_profile_id.acl_trunc_id);
        break;

    default:
        break;
    }

out:
    return;
}

static void get_key_val_mask_str(sx_flex_acl_key_desc_t *key_desc_p, char* key_value, char* key_mask)
{
    uint32_t i = 0;

#define GET_KEY_VALUE_MASK_STR_BOOL_MASK(KEY_ID, KEY_FIELD)  \
case KEY_ID:                                                 \
    if (key_desc_p->mask.KEY_FIELD) {                        \
        sprintf(key_value, "%d", key_desc_p->key.KEY_FIELD); \
    }                                                        \
    goto out;                                                \
    break;

    switch (key_desc_p->key_id) {
        GET_KEY_VALUE_MASK_STR_BOOL_MASK(FLEX_ACL_KEY_FID, fid);
        GET_KEY_VALUE_MASK_STR_BOOL_MASK(FLEX_ACL_KEY_INNER_TTL, inner_ttl)
        GET_KEY_VALUE_MASK_STR_BOOL_MASK(FLEX_ACL_KEY_BOS, bos)
        GET_KEY_VALUE_MASK_STR_BOOL_MASK(FLEX_ACL_KEY_INNER_BOS, inner_bos)
        GET_KEY_VALUE_MASK_STR_BOOL_MASK(FLEX_ACL_KEY_DST_PORT, dst_port)
        GET_KEY_VALUE_MASK_STR_BOOL_MASK(FLEX_ACL_KEY_SRC_PORT, src_port)
        GET_KEY_VALUE_MASK_STR_BOOL_MASK(FLEX_ACL_KEY_SWITCH_PRIO, switch_prio)
        GET_KEY_VALUE_MASK_STR_BOOL_MASK(FLEX_ACL_KEY_IRIF, irif)
        GET_KEY_VALUE_MASK_STR_BOOL_MASK(FLEX_ACL_KEY_ERIF, erif)
        GET_KEY_VALUE_MASK_STR_BOOL_MASK(FLEX_ACL_KEY_VIRTUAL_ROUTER, virtual_router)

    default:
        break;
    }

#define GET_KEY_VALUE_MASK_STR_BOOL_VALUE(KEY_ID, KEY_FIELD)                    \
case KEY_ID:                                                                    \
    if (key_desc_p->mask.KEY_FIELD) {                                           \
        sprintf(key_value, "%s", key_desc_p->key.KEY_FIELD ? "TRUE" : "FALSE"); \
    }                                                                           \
    goto out;                                                                   \
    break;

    switch (key_desc_p->key_id) {
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_L2_VALID, l2_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_TTL_OK, inner_ttl_ok)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_VLAN_VALID, inner_vlan_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_RW_PCP, rw_pcp)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_DMAC_IS_UC, dmac_is_uc)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_VLAN_TAGGED, vlan_tagged)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_VLAN_VALID, vlan_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_RW_DSCP, rw_dscp)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IP_FRAGMENTED, ip_fragmented)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IP_DONT_FRAGMENT, ip_dont_fragment)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IPV6_EXTENSION_HEADER_EXISTS, ipv6_extension_header_exists)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST, ip_fragment_not_first)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IP_OK, ip_ok)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IS_ARP, is_arp)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_URPF_FAIL, urpf_fail)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IP_OPT, ip_opt)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IS_IP_V4, is_ip_v4)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_TTL_OK, ttl_ok)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_L4_OK, l4_ok)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IS_TRAPPED, is_trapped)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_IP_OK, inner_ip_ok)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_L4_OK, inner_l4_ok)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_GRE_KEY_EXISTS, gre_key_exists)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IS_MPLS, is_mpls)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_RW_EXP, rw_exp)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IS_ROUTED, is_routed)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_MPLS_CONTROL_WORD_VALID, mpls_control_word_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS_EXISTS,
                                          inner_ipv6_extension_headers_exists);
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_IS_MPLS, inner_is_mpls)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_IS_IP_V4, inner_is_ip_v4)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD_VALID, inner_mpls_control_word_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_IP_OPT, inner_ip_opt)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IP_MORE_FRAGMENTS, ip_more_fragments)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_IP_DONT_FRAGMENT, inner_ip_dont_fragment)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_IP_MORE_FRAGMENTS, inner_ip_more_fragments)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_IP_FRAGMENTED, inner_ip_fragmented)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_IP_FRAGMENT_NOT_FIRST, inner_ip_fragment_not_first)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_IS_TCP_OPTION, inner_is_tcp_option)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_IS_TCP_OPTION, is_tcp_option)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_FDB_MISS, fdb_miss)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_LLC_VALID, llc_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_DMAC_VALID, inner_dmac_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_VLAN_TAG_VALID, vlan_tag_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_INNER_VLAN_TAG_VALID, inner_vlan_tag_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_TUNNEL_VLAN_TAG_VALID, tunnel_vlan_tag_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_TUNNEL_INNER_VLAN_TAG_VALID, tunnel_inner_vlan_tag_valid)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_BUFF, buff)
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_DWORD_0_VALID, dword_valid);
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_DWORD_1_VALID, dword_valid);
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_DWORD_2_VALID, dword_valid);
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_DWORD_3_VALID, dword_valid);
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_DWORD_4_VALID, dword_valid);
        GET_KEY_VALUE_MASK_STR_BOOL_VALUE(FLEX_ACL_KEY_DWORD_5_VALID, dword_valid);

    default:
        break;
    }

#define GET_KEY_VALUE_MASK_HEX_STR(KEY_ID, KEY_FIELD)          \
case KEY_ID:                                                   \
    if (key_desc_p->mask.KEY_FIELD) {                          \
        sprintf(key_value, "0x%x", key_desc_p->key.KEY_FIELD); \
        sprintf(key_mask, "0x%x", key_desc_p->mask.KEY_FIELD); \
    }                                                          \
    goto out;                                                  \
    break;

    switch (key_desc_p->key_id) {
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ETHERTYPE, ethertype)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_ETHERTYPE, inner_ethertype)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_IP_PROTO, ip_proto)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_IP_PROTO, inner_ip_proto)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MC_TYPE, mc_type_vector)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_FREE_RUNNING_CLOCK_MSB, free_running_clock_msb)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MPLS_LABELS_VALID, mpls_labels_valid)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_MPLS_LABELS_VALID, inner_mpls_labels_valid)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_DEI, dei)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_PCP, pcp)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_VLAN_ID, vlan_id)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_DEI, inner_dei)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_PCP, inner_pcp)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_DSCP, inner_dscp)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_ECN, inner_ecn)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_IP_PACKET_LENGTH, ip_packet_length)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_DSCP, dscp)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ECN, ecn)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_TTL, ttl)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_L4_SOURCE_PORT, l4_source_port)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_L4_DESTINATION_PORT, l4_destination_port)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT, inner_l4_destination_port)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_L4_SOURCE_PORT, inner_l4_source_port)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_TCP_CONTROL, tcp_control)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_TCP_ECN, tcp_ecn)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_GRE_KEY, gre_key)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_VNI_KEY, vni_key)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_GRE_PROTOCOL, gre_protocol)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_TUNNEL_VLAN_ID, tunnel_vlan_id)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_TUNNEL_INNER_VLAN_ID, tunnel_inner_vlan_id)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MPLS_LABEL_ID_1, mpls_label_id_1)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MPLS_LABEL_ID_2, mpls_label_id_2)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MPLS_LABEL_ID_3, mpls_label_id_3)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MPLS_LABEL_ID_4, mpls_label_id_4)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MPLS_LABEL_ID_5, mpls_label_id_5)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MPLS_LABEL_ID_6, mpls_label_id_6)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_EXP, exp)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MPLS_TTL, mpls_ttl)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MPLS_CONTROL_WORD, mpls_control_word)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_MPLS_TTL, inner_mpls_ttl)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_1, inner_mpls_label_id_1)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_2, inner_mpls_label_id_2)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_MPLS_LABEL_ID_3, inner_mpls_label_id_3)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_MPLS_CONTROL_WORD, mpls_control_word)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_EXP, inner_exp)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_MPLS_ECN, mpls_ecn)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_MPLS_ECN, inner_mpls_ecn)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_USER_TOKEN, user_token)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_TRAP_ID, trap_id)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ROCE_DEST_QP, dest_qp)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ROCE_PKEY, pkey)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ROCE_BTH_OPCODE, bth_opcode)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_IP_PACKET_LENGTH, inner_ip_packet_length)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_TCP_CONTROL, inner_tcp_control)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_INNER_TCP_ECN, inner_tcp_ecn)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_0, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_1, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_2, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_3, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_4, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_5, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_6, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_7, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_8, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_9, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_10, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_11, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_12, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_13, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_14, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_15, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_16, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_17, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_18, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_CUSTOM_BYTE_19, custom_byte)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_0, ethernet_payload_dword)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_1, ethernet_payload_dword)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_2, ethernet_payload_dword)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_3, ethernet_payload_dword)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_4, ethernet_payload_dword)
        GET_KEY_VALUE_MASK_HEX_STR(FLEX_ACL_KEY_ETHERNET_PAYLOAD_DWORD_5, ethernet_payload_dword)

    default:
        break;
    }

    switch (key_desc_p->key_id) {
    case FLEX_ACL_KEY_INVALID:
        strcpy(key_value, "INVALID");
        strcpy(key_mask, "INVALID");
        break;

    case FLEX_ACL_KEY_COLOR:
        if (key_desc_p->mask.color) {
            strcpy(key_value, KEY_COLOR_2STR(key_desc_p->key.color));
        }
        break;

    case FLEX_ACL_KEY_RX_LIST:
        if (key_desc_p->mask.rx_list) {
            sprintf(key_value, "MC Container ID: %d", key_desc_p->key.rx_list);
        }
        break;

    case FLEX_ACL_KEY_DMAC:
        __acl_helper_mac_to_str(key_desc_p->key.dmac, key_value);
        __acl_helper_mac_to_str(key_desc_p->mask.dmac, key_mask);
        break;

    case FLEX_ACL_KEY_SMAC:
        __acl_helper_mac_to_str(key_desc_p->key.smac, key_value);
        __acl_helper_mac_to_str(key_desc_p->mask.smac, key_mask);
        break;

    case FLEX_ACL_KEY_INNER_DMAC:
        __acl_helper_mac_to_str(key_desc_p->key.inner_dmac, key_value);
        __acl_helper_mac_to_str(key_desc_p->mask.inner_dmac, key_mask);
        break;

    case FLEX_ACL_KEY_INNER_SMAC:
        __acl_helper_mac_to_str(key_desc_p->key.inner_smac, key_value);
        __acl_helper_mac_to_str(key_desc_p->mask.inner_smac, key_mask);
        break;

    case FLEX_ACL_KEY_DIP:
        format_ip_addr(&key_desc_p->key.dip, key_value);
        format_ip_addr(&key_desc_p->mask.dip, key_mask);
        break;

    case FLEX_ACL_KEY_SIP:
        format_ip_addr(&key_desc_p->key.sip, key_value);
        format_ip_addr(&key_desc_p->mask.sip, key_mask);
        break;

    case FLEX_ACL_KEY_DIPV6:
        format_ip_addr(&key_desc_p->key.dipv6, key_value);
        format_ip_addr(&key_desc_p->mask.dipv6, key_mask);
        break;

    case FLEX_ACL_KEY_SIPV6:
        format_ip_addr(&key_desc_p->key.sipv6, key_value);
        format_ip_addr(&key_desc_p->mask.sipv6, key_mask);
        break;

    case FLEX_ACL_KEY_INNER_SIP:
        format_ip_addr(&key_desc_p->key.inner_sip, key_value);
        format_ip_addr(&key_desc_p->mask.inner_sip, key_mask);
        break;

    case FLEX_ACL_KEY_INNER_DIP:
        format_ip_addr(&key_desc_p->key.inner_dip, key_value);
        format_ip_addr(&key_desc_p->mask.inner_dip, key_mask);
        break;

    case FLEX_ACL_KEY_INNER_SIPV6:
        format_ip_addr(&key_desc_p->key.inner_sipv6, key_value);
        format_ip_addr(&key_desc_p->mask.inner_sipv6, key_mask);
        break;

    case FLEX_ACL_KEY_INNER_DIPV6:
        format_ip_addr(&key_desc_p->key.inner_dipv6, key_value);
        format_ip_addr(&key_desc_p->mask.inner_dipv6, key_mask);
        break;

    case FLEX_ACL_KEY_L2_DMAC_TYPE:
        if (key_desc_p->mask.l2_dmac_type) {
            strcpy(key_value, KEY_MAC_TYPE_2STR(key_desc_p->key.l2_dmac_type));
        }
        break;

    case FLEX_ACL_KEY_L3_TYPE:
        if (key_desc_p->mask.l3_type) {
            strcpy(key_value, KEY_L3_TYPE_2STR(key_desc_p->key.l3_type));
        }
        break;

    case FLEX_ACL_KEY_L4_TYPE:
        if (key_desc_p->mask.l4_type) {
            strcpy(key_value, KEY_L4_TYPE_2STR(key_desc_p->key.l4_type));
        }
        break;

    case FLEX_ACL_KEY_L4_PORT_RANGE:
        if (key_desc_p->mask.l4_port_range) {
            for (i = 0; i < key_desc_p->key.l4_port_range.port_range_cnt; i++) {
                sprintf(key_value, "%d", key_desc_p->key.l4_port_range.port_range_list[i]);
                key_value += strlen(key_value);
                if (i < (key_desc_p->key.l4_port_range.port_range_cnt - 1)) {
                    sprintf(key_value, ", ");
                    key_value += strlen(key_value);
                }
            }
        }
        break;

    case FLEX_ACL_KEY_DISCARD_STATE:
        if (key_desc_p->mask.discard_state) {
            strcpy(key_value, KEY_DISCARD_STATE_2STR(key_desc_p->key.discard_state));
        }
        break;

    case FLEX_ACL_KEY_IPV6_EXTENSION_HEADERS:
        if (key_desc_p->mask.ipv6_extension_headers) {
            for (i = 0; i < key_desc_p->key.ipv6_extension_headers.extension_headers_cnt; i++) {
                sprintf(key_value, "%s",
                        KEY_IPV6_EXTENSION_2STR(key_desc_p->key.ipv6_extension_headers.extension_headers_list[i]));
                key_value += strlen(key_value);
                if (i < (key_desc_p->key.ipv6_extension_headers.extension_headers_cnt - 1)) {
                    sprintf(key_value, ", ");
                    key_value += strlen(key_value);
                }
            }
        }
        break;

    case FLEX_ACL_KEY_INNER_IPV6_EXTENSION_HEADERS:
        if (key_desc_p->mask.inner_ipv6_extension_headers) {
            for (i = 0; i < key_desc_p->key.inner_ipv6_extension_headers.extension_headers_cnt; i++) {
                sprintf(key_value, "%s",
                        KEY_IPV6_EXTENSION_2STR(key_desc_p->key.inner_ipv6_extension_headers.extension_headers_list[i]));
                key_value += strlen(key_value);
                if (i < (key_desc_p->key.inner_ipv6_extension_headers.extension_headers_cnt - 1)) {
                    sprintf(key_value, ", ");
                    key_value += strlen(key_value);
                }
            }
        }
        break;

    case FLEX_ACL_KEY_INNER_L3_TYPE:
        if (key_desc_p->mask.inner_l3_type) {
            strcpy(key_value, KEY_L3_TYPE_2STR(key_desc_p->key.inner_l3_type));
        }
        break;

    case FLEX_ACL_KEY_TUNNEL_TYPE:
        if (key_desc_p->mask.tunnel_type) {
            strcpy(key_value, SX_TUNNEL_TYPE_STR(key_desc_p->key.tunnel_type));
        }
        break;

    case FLEX_ACL_KEY_TUNNEL_NVE_TYPE:
        if (key_desc_p->mask.tunnel_nve_type) {
            strcpy(key_value, SX_TUNNEL_TYPE_STR(key_desc_p->key.tunnel_nve_type));
        }
        break;

    case FLEX_ACL_KEY_L4_TYPE_EXTENDED:
        if (key_desc_p->mask.l4_type) {
            strcpy(key_value, KEY_L4_TYPE_EXT_2STR(key_desc_p->key.l4_type_extended));
        }
        break;

    case FLEX_ACL_KEY_INNER_L4_TYPE_EXTENDED:
        if (key_desc_p->mask.inner_l4_type_extended) {
            strcpy(key_value, KEY_L4_TYPE_EXT_2STR(key_desc_p->key.inner_l4_type_extended));
        }
        break;

    case FLEX_ACL_KEY_RX_PORT_LIST:
        if (key_desc_p->mask.rx_port_list) {
            sprintf(key_value, "Match Type: %s, MC Container ID: %d",
                    KEY_PORT_LIST_MATCH_2STR(key_desc_p->key.rx_port_list.match_type),
                    key_desc_p->key.rx_port_list.mc_container_id);
        }
        break;

    case FLEX_ACL_KEY_TX_PORT_LIST:
        if (key_desc_p->mask.tx_port_list) {
            sprintf(key_value, "Match Type: %s, MC Container ID: %d",
                    KEY_PORT_LIST_MATCH_2STR(key_desc_p->key.tx_port_list.match_type),
                    key_desc_p->key.tx_port_list.mc_container_id);
        }
        break;

    case FLEX_ACL_KEY_ND_SLL_OR_TLL_VALID:
        if (key_desc_p->mask.nd_sll_or_tll_valid) {
            strcpy(key_value, KEY_ND_SLL_OR_TLL_VALID_2STR(key_desc_p->key.nd_sll_or_tll_valid));
        }
        break;

    default:
        strcpy(key_value, "Translation unsupported");
        strcpy(key_mask, "Translation unsupported");
        break;
    }

out:
    return;
}

static sx_acl_helper_status_t __acl_helper_translate(sx_flex_acl_flex_rule_t *acl_rule_p,
                                                     acl_helper_rule_entry_t *acl_rule_entry_p)
{
    sx_acl_helper_status_t err = SX_ACL_HELPER_STATUS_SUCCESS;
    uint32_t               i = 0;
    char                   key_value[ACL_HELPER_KEY_LEN_MAX];
    char                   key_mask[ACL_HELPER_KEY_LEN_MAX];
    char                  *key_list_p = NULL;
    char                  *key_list_tmp_p = NULL;
    char                   action_field[ACL_HELPER_ACTION_LEN_MAX];
    char                  *action_list_p = NULL;
    char                  *action_list_tmp_p = NULL;
    uint32_t               rule_len = 0;

    memset(key_value, 0, ACL_HELPER_KEY_LEN_MAX);
    memset(key_mask, 0, ACL_HELPER_KEY_LEN_MAX);
    memset(action_field, 0, ACL_HELPER_ACTION_LEN_MAX);

    key_list_p = cl_calloc((acl_rule_p->key_desc_count) * ACL_HELPER_KEY_LEN_MAX + 1, 1);
    if (key_list_p == NULL) {
        err = SX_ACL_HELPER_STATUS_NO_MEMORY;
        goto out;
    }

    action_list_p = cl_calloc((acl_rule_p->action_count) * ACL_HELPER_ACTION_LEN_MAX + 1, 1);
    if (action_list_p == NULL) {
        err = SX_ACL_HELPER_STATUS_NO_MEMORY;
        goto out;
    }

    key_list_tmp_p = key_list_p;
    action_list_tmp_p = action_list_p;

    for (i = 0; i < acl_rule_p->key_desc_count; i++) {
        memset(key_value, 0, ACL_HELPER_KEY_LEN_MAX);
        memset(key_mask, 0, ACL_HELPER_KEY_LEN_MAX);
        get_key_val_mask_str(&acl_rule_p->key_desc_list_p[i], key_value, key_mask);
        if (key_value[0] == 0) {
            continue;
        }
        if (key_mask[0] == 0) {
            snprintf(key_list_tmp_p, ACL_HELPER_KEY_LEN_MAX, "KEY[%s: %s];",
                     KEY_ID_2STR(acl_rule_p->key_desc_list_p[i].key_id), key_value);
        } else {
            snprintf(key_list_tmp_p, ACL_HELPER_KEY_LEN_MAX, "KEY[%s: %s/%s];",
                     KEY_ID_2STR(acl_rule_p->key_desc_list_p[i].key_id), key_value, key_mask);
        }

        key_list_tmp_p += strlen(key_list_tmp_p);
    }

    for (i = 0; i < acl_rule_p->action_count; i++) {
        memset(action_field, 0, ACL_HELPER_ACTION_LEN_MAX);
        get_action_str(&acl_rule_p->action_list_p[i], action_field);
        snprintf(action_list_tmp_p, ACL_HELPER_ACTION_LEN_MAX, "ACTION[%s: %s];",
                 ACTION_ID_2STR(acl_rule_p->action_list_p[i].type),
                 action_field);
        action_list_tmp_p += strlen(action_list_tmp_p);
    }

    rule_len = ACL_HELPER_RULE_DESC_LEN + strlen(key_list_p) + strlen(action_list_p);
    acl_rule_entry_p->rule_p = cl_malloc(rule_len);
    memset(acl_rule_entry_p->rule_p, 0, rule_len);

    snprintf(acl_rule_entry_p->rule_p, rule_len, "Priority[%d];%s%s",
             acl_rule_p->priority, key_list_p, action_list_p);

out:
    if (key_list_p) {
        CL_FREE_N_NULL(key_list_p);
    }
    if (action_list_p) {
        CL_FREE_N_NULL(action_list_p);
    }

    return err;
}

static void __acl_helper_clean_cache(void)
{
    cl_fmap_item_t          *map_item_p = NULL;
    acl_helper_rule_entry_t *acl_rule_entry_p = NULL;

    map_item_p = cl_fmap_head(&acl_helper_db_g.rule_lookup);

    while (map_item_p != cl_fmap_end(&acl_helper_db_g.rule_lookup)) {
        acl_rule_entry_p = PARENT_STRUCT(map_item_p, acl_helper_rule_entry_t, map_item);
        CL_FREE_N_NULL(acl_rule_entry_p->rule_p);
        map_item_p = cl_fmap_next(map_item_p);
        cl_fmap_remove_item(&acl_helper_db_g.rule_lookup, &acl_rule_entry_p->map_item);
        cl_qpool_put(&acl_helper_db_g.rule_pool, &acl_rule_entry_p->pool_item);
    }

    SX_LOG_DBG("cleaned cache\n");
}

static void __acl_helper_thread_func(void *args)
{
    uint32_t count = 0;
    uint32_t sleep_ms = 100;

    UNUSED_PARAM(args);

    while (!acl_helper_stop_thread_s) {
        if (count < (ACL_HELPER_CACHE_CLEAN_INTERVAL * 1000 / sleep_ms)) {
            usleep(sleep_ms * 1000);
            count++;
            continue;
        }

        /* Clean the cache */
        cl_spinlock_acquire(&acl_helper_spinlock_s);
        __acl_helper_clean_cache();
        cl_spinlock_release(&acl_helper_spinlock_s);
        count = 0;
    }

    pthread_exit((void*)NULL);
}

sx_acl_helper_status_t sx_acl_helper_init(void)
{
    sx_acl_helper_status_t err = SX_ACL_HELPER_STATUS_SUCCESS;
    sx_status_t            sdk_rc = SX_STATUS_SUCCESS;
    cl_status_t            cl_rc = CL_SUCCESS;
    sx_status_t            sdk_rb_rc = SX_STATUS_SUCCESS;
    boolean_t              log_inited = FALSE;
    boolean_t              api_opened = FALSE;
    boolean_t              qpool_inited = FALSE;
    boolean_t              spinlock_inited = FALSE;

    if (sx_log_init(TRUE, NULL, NULL) != 0) {
        err = SX_ACL_HELPER_STATUS_ERROR;
        fprintf(stderr, "Log initialization failed.\n");
        goto out;
    }
    log_inited = TRUE;

    if (acl_helper_inited_g) {
        err = SX_ACL_HELPER_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("WJH acl is already initialized.\n");
        goto out;
    }

    sdk_rc = sx_api_open(NULL, &acl_helper_sx_api_handle_g);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("Failed to open SX-API, error: %s\n", sx_status_str(sdk_rc));
        err = SX_ACL_HELPER_STATUS_ERROR;
        goto out;
    }
    api_opened = TRUE;

    cl_rc = CL_QPOOL_INIT(&acl_helper_db_g.rule_pool,
                          ACL_HELPER_RULE_NUMBER_MIN, ACL_HELPER_RULE_NUMBER_MAX, ACL_HELPER_RULE_NUMBER_GROW,
                          sizeof(acl_helper_rule_entry_t), NULL, NULL, NULL);
    if (cl_rc != CL_SUCCESS) {
        SX_LOG_ERR("Failed to initialize the pool.\n");
        err = SX_ACL_HELPER_STATUS_NO_RESOURCES;
        goto out;
    }
    qpool_inited = TRUE;

    cl_fmap_init(&acl_helper_db_g.rule_lookup, __acl_helper_rule_key_compare);

    cl_rc = cl_spinlock_init(&acl_helper_spinlock_s);
    if (cl_rc != CL_SUCCESS) {
        SX_LOG_ERR("Failed to initialize the spinlock object.\n");
        err = SX_ACL_HELPER_STATUS_NO_RESOURCES;
        goto out;
    }
    spinlock_inited = TRUE;

    acl_helper_stop_thread_s = FALSE;
    cl_rc = cl_thread_init(&acl_helper_thread_id_s, __acl_helper_thread_func, NULL, "aclHelper", 0);
    if (cl_rc != CL_SUCCESS) {
        SX_LOG_ERR("Could not create __wjh_thread_func thread.\n");
        err = SX_ACL_HELPER_STATUS_NO_RESOURCES;
        goto out;
    }

    acl_helper_inited_g = TRUE;

out:
    if (err != SX_ACL_HELPER_STATUS_SUCCESS) {
        if (spinlock_inited) {
            cl_spinlock_destroy(&acl_helper_spinlock_s);
        }

        if (qpool_inited) {
            CL_QPOOL_DESTROY(&acl_helper_db_g.rule_pool);
        }

        if (api_opened) {
            sdk_rb_rc = sx_api_close(&acl_helper_sx_api_handle_g);
            if (SX_CHECK_FAIL(sdk_rb_rc)) {
                SX_LOG_ERR("Failed to close SDK API, err: %s\n", sx_status_str(sdk_rb_rc));
            }
        }

        if (log_inited) {
            sx_log_close();
        }
    }

    return err;
}

sx_acl_helper_status_t sx_acl_helper_deinit(void)
{
    sx_acl_helper_status_t err = SX_ACL_HELPER_STATUS_SUCCESS;
    sx_status_t            sdk_rc = SX_STATUS_SUCCESS;

    ACL_HELPER_CHECK_INITIALIZED(acl_helper_inited_g);

    acl_helper_stop_thread_s = TRUE;

    cl_thread_destroy(&acl_helper_thread_id_s);

    cl_spinlock_destroy(&acl_helper_spinlock_s);

    sdk_rc = sx_api_close(&acl_helper_sx_api_handle_g);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("Failed to close SX-API, error: %s\n", sx_status_str(sdk_rc));
        err = SX_ACL_HELPER_STATUS_ERROR;
        goto out;
    }

    __acl_helper_clean_cache();
    CL_QPOOL_DESTROY(&acl_helper_db_g.rule_pool);

    acl_helper_inited_g = FALSE;

out:
    return err;
}

sx_acl_helper_status_t sx_acl_helper_acl_description_get(sx_acl_helper_acl_id_t  acl_id,
                                                         sx_acl_helper_rule_id_t rule_id,
                                                         char                   *acl_name_p,
                                                         uint32_t               *acl_name_len_p,
                                                         char                   *rule_p,
                                                         uint32_t               *rule_len_p)
{
    sx_acl_helper_status_t    err = SX_ACL_HELPER_STATUS_SUCCESS;
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    acl_helper_rule_key_t     acl_rule_key;
    acl_helper_rule_entry_t  *acl_rule_entry_p = NULL;
    cl_fmap_item_t           *map_item_p = NULL;
    cl_pool_item_t           *pool_item_p = NULL;
    sx_flex_acl_flex_rule_t   acl_rule;
    sx_flex_acl_rule_offset_t rule_offset = RULE_OFFSET_GET(rule_id);
    sx_acl_region_id_t        region_id = REGION_ID_GET(rule_id);
    uint32_t                  rule_count = 1;
    sx_acl_attributes_t       acl_attributes;

    memset(&acl_rule, 0, sizeof(sx_flex_acl_flex_rule_t));

    ACL_HELPER_CHECK_INITIALIZED(acl_helper_inited_g);

    ACL_HELPER_CHECK_NULL_PTR(acl_name_len_p, acl_name_len_p);
    if (*acl_name_len_p != 0) {
        ACL_HELPER_CHECK_NULL_PTR(acl_name_p, acl_name_p);
    }
    ACL_HELPER_CHECK_NULL_PTR(rule_len_p, rule_len_p);
    if (*rule_len_p != 0) {
        ACL_HELPER_CHECK_NULL_PTR(rule_p, rule_p);
    }

    acl_rule_key.acl_id = acl_id;
    acl_rule_key.rule_id = rule_id;

    cl_spinlock_acquire(&acl_helper_spinlock_s);

    map_item_p = cl_fmap_get(&acl_helper_db_g.rule_lookup, &acl_rule_key);
    if (map_item_p == cl_fmap_end(&acl_helper_db_g.rule_lookup)) {
        /* Get rule from SDK */
        SX_LOG_DBG("Region id = 0x%x, offset = 0x%x\n", region_id, rule_offset);

        sx_status = sx_api_acl_flex_rules_get(acl_helper_sx_api_handle_g,
                                              region_id,
                                              &rule_offset,
                                              &acl_rule,
                                              &rule_count);
        if (sx_status != SX_STATUS_SUCCESS) {
            if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
                err = SX_ACL_HELPER_STATUS_ENTRY_NOT_FOUND;
                goto out;
            }
            SX_LOG_ERR("Failed to get rules: %s\n", sx_status_str(sx_status));
            err = SX_ACL_HELPER_STATUS_ERROR;
            goto out;
        }

        if ((rule_count == 0) || (rule_offset != RULE_OFFSET_GET(rule_id))) {
            err = SX_ACL_HELPER_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        SX_LOG_DBG("key count = %d, action count = %d\n",
                   acl_rule.key_desc_count, acl_rule.action_count);
        acl_rule.key_desc_list_p = cl_malloc(sizeof(sx_flex_acl_key_desc_t) * acl_rule.key_desc_count);
        if (acl_rule.key_desc_list_p == NULL) {
            err = SX_ACL_HELPER_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for key desc list.\n");
            goto out;
        }
        acl_rule.action_list_p = cl_malloc(sizeof(sx_flex_acl_flex_action_t) * acl_rule.action_count);
        if (acl_rule.action_list_p == NULL) {
            err = SX_ACL_HELPER_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for action list.\n");
            goto out;
        }

        sx_status = sx_api_acl_flex_rules_get(acl_helper_sx_api_handle_g,
                                              region_id,
                                              &rule_offset,
                                              &acl_rule,
                                              &rule_count);

        if (sx_status != SX_STATUS_SUCCESS) {
            if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
                err = SX_ACL_HELPER_STATUS_ENTRY_NOT_FOUND;
            } else {
                err = SX_ACL_HELPER_STATUS_ERROR;
                SX_LOG_ERR("Failed to get rules.\n");
            }
            goto out;
        }

        pool_item_p = cl_qpool_get(&acl_helper_db_g.rule_pool);
        if (pool_item_p == NULL) {
            err = SX_ACL_HELPER_STATUS_NO_RESOURCES;
            goto out;
        }
        acl_rule_entry_p = PARENT_STRUCT(pool_item_p, acl_helper_rule_entry_t, pool_item);

        memset(&acl_attributes, 0, sizeof(sx_acl_attributes_t));
        sx_status = sx_api_acl_attributes_get(acl_helper_sx_api_handle_g, acl_id, &acl_attributes);
        if (sx_status != SX_STATUS_SUCCESS) {
            err = SX_ACL_HELPER_STATUS_ERROR;
            SX_LOG_ERR("Failed to get acl attributes.\n");
            goto out;
        }

        memset(acl_rule_entry_p->acl_name, 0, ACL_HELPER_ACL_NAME_LEN_MAX);
        if (acl_attributes.acl_desc.acl_name_str_len > 0) {
            strncpy(acl_rule_entry_p->acl_name,
                    acl_attributes.acl_desc.acl_name_str,
                    acl_attributes.acl_desc.acl_name_str_len);
        }

        acl_rule_entry_p->rule_p = NULL;
        err = __acl_helper_translate(&acl_rule, acl_rule_entry_p);
        if (err != SX_ACL_HELPER_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to save acl rule.\n");
            goto out;
        }

        SX_LOG_DBG("insert 0x%" PRIx64 "\n", rule_id);
        acl_rule_entry_p->key = acl_rule_key;
        cl_fmap_insert(&acl_helper_db_g.rule_lookup, &acl_rule_entry_p->key, &acl_rule_entry_p->map_item);
    } else {
        acl_rule_entry_p = PARENT_STRUCT(map_item_p, acl_helper_rule_entry_t, map_item);
    }

    if (*acl_name_len_p != 0) {
        strncpy(acl_name_p, acl_rule_entry_p->acl_name, *acl_name_len_p);
    }
    *acl_name_len_p = strlen(acl_rule_entry_p->acl_name);

    if (*rule_len_p != 0) {
        strncpy(rule_p, acl_rule_entry_p->rule_p, *rule_len_p);
    }
    *rule_len_p = strlen(acl_rule_entry_p->rule_p);


out:
    cl_spinlock_release(&acl_helper_spinlock_s);
    if (acl_rule.key_desc_list_p) {
        CL_FREE_N_NULL(acl_rule.key_desc_list_p);
    }
    if (acl_rule.action_list_p) {
        CL_FREE_N_NULL(acl_rule.action_list_p);
    }
    return err;
}
