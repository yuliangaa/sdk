/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef SX_PCC_H
#define SX_PCC_H

#include "sx_pcc_types.h"
/**
 *  This API initializes the PCC LIB DB.
 *
 *  Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * @return PCC_STATUS_SUCCESS, API finished successfully.
 * @return PCC_STATUS_ALREADY_INITIALIZED, Lib is already initialized.
 * @return PCC_STATUS_ERROR, General ERROR.
 */
pcc_status_t pcc_api_init_set();

/**
 *  This API de-initializes the PCC LIB, it will remove all
 *  configuration that was configured by the LIB.
 *
 *  Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * @return PCC_STATUS_SUCCESS, API finished successfully.
 * @return PCC_STATUS_ERROR, General ERROR.
 */
pcc_status_t pcc_api_deinit_set();

/**
 *  This API sets an application of the given type, and sets its resources.
 *  Currently supported type is PCC_APP_NVXCC. This Application configures the
 *  NVxCC(Nvidia Congestion Control) protocol on top of the SDK. Allowing
 *  detection and update of the relevant control packets of the protocol.
 *
 *  Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * @param[in]     cmd                - ADD/DELETE
 * @param[in]     app_init_params_p  - The type and initial parameters of the APP.
 *                                     Relevant for ADD command only.
 * @param[in/out] app_id_p           - For ADD the parameter is used to return
 *                                     the allocated APP ID. For DELETE the
 *                                     provides the APP ID to be deleted.
 *
 * @return PCC_STATUS_SUCCESS, API finished successfully.
 * @return PCC_STATUS_ERROR, General ERROR.
 * @return PCC_STATUS_NOT_INITIALIZED, LIB is not initialized.
 * @return PCC_STATUS_ENTRY_NOT_FOUND, APP identifier is not configured in LIB.
 */
pcc_status_t pcc_api_app_set(const pcc_access_cmd_e       cmd,
                             const pcc_app_init_params_t *app_init_params_p,
                             pcc_app_id_t                *app_id_p);

/**
 *  State set API to enable/disable the PCC APP.
 *
 *  Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * @param[in] app_id - Application Identifier to set state for.
 * @param[in] state  - Enable/Disable State for the given application ID.
 *
 * @return PCC_STATUS_SUCCESS, API finished successfully.
 * @return PCC_STATUS_ERROR, General ERROR.
 * @return PCC_STATUS_NOT_INITIALIZED, LIB is not initialized.
 * @return PCC_STATUS_ENTRY_NOT_FOUND, APP identifier is not configured in LIB.
 *
 */
pcc_status_t pcc_api_app_state_set(const pcc_app_id_t    app_id,
                                   const pcc_app_state_e state);

/**
 *  This API sets a logical port on which the application runs. Ports can be
 *  added as long as there is empty application resources available. As for the
 *  NVxCC application, control packets that will egress through the given port
 *  will be detected and processed. In addition, Note that ports from the same
 *  port group can not share one resource i.e., bind EMT that will be paired with
 *  the given port.
 *
 *  Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * @param[in] cmd         - ADD/DELETE.
 * @param[in] app_id      - Application Identifier to set the port for.
 * @param[in] port_id     - Logical port ID to set for the given application ID.
 * @param[in] port_data_p - Given port attributes: Port speed and control
 *                          packets port counter.
 *
 * @return PCC_STATUS_SUCCESS, API finished successfully.
 * @return PCC_STATUS_ERROR, General ERROR.
 * @return PCC_STATUS_NOT_INITIALIZED, LIB is not initialized.
 * @return PCC_STATUS_ENTRY_NOT_FOUND, APP identifier is not configured in LIB.
 * @return PCC_STATUS_NO_RESOURCES, No more resources available.
 */
pcc_status_t pcc_api_app_port_set(const pcc_access_cmd_e     cmd,
                                  const pcc_app_id_t         app_id,
                                  const pcc_port_log_id_t    port_id,
                                  const pcc_app_port_data_t *port_data_p);

/**
 *  This API retrieve the port data for a given port in an APP.
 *
 *  Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * @param[in]  app_id          - Application Identifier which port is associated with.
 * @param[in]  port_id         - The port of Interest.
 * @param[out] app_port_data_p - Pointer to Configured port data.
 *
 * @return PCC_STATUS_SUCCESS, API finished successfully.
 * @return PCC_STATUS_ERROR, General ERROR.
 * @return PCC_STATUS_NOT_INITIALIZED, LIB is not initialized.
 * @return PCC_STATUS_ENTRY_NOT_FOUND, port identifier is not configured in LIB.
 */
pcc_status_t pcc_api_app_port_get(const pcc_app_id_t      app_id,
                                  const pcc_port_log_id_t port_id,
                                  pcc_app_port_data_t    *app_port_data_p);

/**
 *  This API iterate over the ports associated with a given APP.
 *  cmd - Get_First will return the first port associated with the given APP,
 *        Port count will be 1, or 0 when no ports are associated with the APP.
 *
 *        Get_Next will return list of port, the size of port count,
 *        from the port in the first slot in port list (the first slot will be
 *         overwritten).
 *        Port count will return the correct number of returned ports.
 *
 *  Port count = 0 or Port List = NULL will return the number of ports
 *  associated with the APP given.
 *
 *  Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * @param[in] cmd - Get_First/Get_Next
 * @param[in] app_id - Associated Application Identifier.
 * @param[in/out] port_id_list_p - [In] - Get next cmd, start port,
 *                                 [Out] - Ports list associated to APP
 * @param[in/out] port_id_list_cnt_p - Number of associated ports with APP
 *
 *
 * @return PCC_STATUS_SUCCESS
 * @return PCC_STATUS_ERROR
 * @return PCC_STATUS_NOT_INITIALIZED - When LIB is not initialized.
 * @return PCC_STATUS_ENTRY_NOT_FOUND - When given port is not found.
 */
pcc_status_t pcc_api_app_port_iter_get(const pcc_access_cmd_e cmd,
                                       const pcc_app_id_t     app_id,
                                       pcc_port_log_id_t     *port_id_list_p,
                                       uint32_t              *port_id_list_cnt_p);

#endif /* SX_PCC_H */
