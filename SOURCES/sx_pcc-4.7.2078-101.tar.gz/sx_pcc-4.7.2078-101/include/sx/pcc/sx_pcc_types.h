/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef SX_PCC_TYPES_H
#define SX_PCC_TYPES_H

#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "complib/cl_types_osd.h"

/* Enum specific MACRO */
#define SX_GENERATE_ENUM(ENUM, STR)   ENUM,
#define SX_GENERATE_STRING(ENUM, STR) STR,

typedef enum pcc_status {
    PCC_STATUS_SUCCESS,
    PCC_STATUS_ERROR,
    PCC_STATUS_ENTRY_NOT_FOUND,
    PCC_STATUS_ENTRY_ALREADY_EXIST,
    PCC_STATUS_NOT_INITIALIZED,
    PCC_STATUS_ALREADY_INITIALIZED,
    PCC_STATUS_NO_RESOURCES,
} pcc_status_t;

static const char * const pcc_status_str_s[] = {
    [PCC_STATUS_SUCCESS] = "Success",                         \
    [PCC_STATUS_ERROR] = "Internal Error",                    \
    [PCC_STATUS_ENTRY_NOT_FOUND] = "Entry Not Found",         \
    [PCC_STATUS_ENTRY_ALREADY_EXIST] = "Entry Already Exist", \
    [PCC_STATUS_NOT_INITIALIZED] = "LIB is uninitialized",    \
    [PCC_STATUS_ALREADY_INITIALIZED] = "Already initialized", \
    [PCC_STATUS_NO_RESOURCES] = "No More Resources",
};

#define PCC_STATUS_STR_LEN \
    (sizeof(pcc_status_str_s) / sizeof(pcc_status_str_s[0]))

static inline const char * pcc_status_str(pcc_status_t idx)
{
    if ((idx <= (PCC_STATUS_STR_LEN - 1)) && pcc_status_str_s[idx]) {
        return pcc_status_str_s[idx];
    }
    return "Unknown";
}

/**
 *  * PCC_COS_TRAFFIC_CLASS_MIN defines minimum traffic class value
 *   */
#define PCC_COS_TRAFFIC_CLASS_MIN 0
/**
 *  * PCC_COS_TRAFFIC_CLASS_MAX defines maximum traffic class value
 *   */
#define PCC_COS_TRAFFIC_CLASS_MAX 7

typedef uint8_t pcc_cos_traffic_class_t;

typedef uint32_t pcc_acl_group_priority_t;

/**
 * General purpose registers ID.
 */
#define FOREACH_PCC_GP_REGISTER(F) \
    F(PCC_GP_REGISTER_0_E,    "")  \
    F(PCC_GP_REGISTER_1_E,    "")  \
    F(PCC_GP_REGISTER_2_E,    "")  \
    F(PCC_GP_REGISTER_3_E,    "")  \
    F(PCC_GP_REGISTER_4_E,    "")  \
    F(PCC_GP_REGISTER_5_E,    "")  \
    F(PCC_GP_REGISTER_6_E,    "")  \
    F(PCC_GP_REGISTER_7_E,    "")  \
    F(PCC_GP_REGISTER_8_E,    "")  \
    F(PCC_GP_REGISTER_9_E,    "")  \
    F(PCC_GP_REGISTER_10_E,   "")  \
    F(PCC_GP_REGISTER_11_E,   "")  \
    F(PCC_GP_REGISTER_LAST_E, "")

typedef enum pcc_gp_register {
    FOREACH_PCC_GP_REGISTER(SX_GENERATE_ENUM) \
} pcc_gp_register_e;

#define FOREACH_PCC_FLEX_MODIFIER_EMT_ID(F) \
    F(PCC_FLEX_MODIFIER_EMT0_E,     "EMT0") \
    F(PCC_FLEX_MODIFIER_EMT1_E,     "EMT1") \
    F(PCC_FLEX_MODIFIER_EMT2_E,     "EMT2") \
    F(PCC_FLEX_MODIFIER_EMT3_E,     "EMT3") \
    F(PCC_FLEX_MODIFIER_EMT4_E,     "EMT4") \
    F(PCC_FLEX_MODIFIER_EMT5_E,     "EMT5") \
    F(PCC_FLEX_MODIFIER_EMT6_E,     "EMT6") \
    F(PCC_FLEX_MODIFIER_EMT7_E,     "EMT7") \
    F(PCC_FLEX_MODIFIER_EMT_LAST_E, "")

typedef enum pcc_flex_modifier_emt_id {
    FOREACH_PCC_FLEX_MODIFIER_EMT_ID(SX_GENERATE_ENUM) \
} pcc_flex_modifier_emt_id_e;

typedef enum pcc_access_cmd {
    PCC_ACCESS_CMD_ADD_E,
    PCC_ACCESS_CMD_DELETE_E,
    PCC_ACCESS_CMD_CREATE_E,
    PCC_ACCESS_CMD_SET_E,
    PCC_ACCESS_CMD_GET_FIRST_E,
    PCC_ACCESS_CMD_GET_NEXT_E,
} pcc_access_cmd_e;

typedef uint8_t pcc_app_id_t;

typedef struct pcc_app_nvxcc_params_app { /**< General App Params **/
    uint32_t  switchid;
    boolean_t debug_enable; /**< Enable debug format of the metadata **/
} pcc_app_nvxcc_params_app_t;

typedef struct pcc_app_hpcc_params_app { /**< General App Params **/
    uint32_t  device_id;
    boolean_t debug_enable; /**< Enable debug format of the metadata **/
} pcc_app_hpcc_params_app_t;

typedef struct pcc_app_nvxcc_params_vip {
    boolean_t               set_tc; /**< If false - packet will continue with default TC = 6 **/
    pcc_cos_traffic_class_t vip_tc;
} pcc_app_nvxcc_params_vip_t;

typedef struct pcc_app_nvxcc_params_tc {
    boolean_t               set_app_tc; /**< If false - packet will read default TC = 3 **/
    pcc_cos_traffic_class_t app_tc;
} pcc_app_nvxcc_params_tc_t;

typedef struct pcc_emts {
    uint8_t                    emt_num;
    pcc_flex_modifier_emt_id_e emts[PCC_FLEX_MODIFIER_EMT_LAST_E];
} pcc_emts_t;

typedef struct gp_registers {
    uint8_t           reg_num;
    pcc_gp_register_e registers[PCC_GP_REGISTER_LAST_E];
} pcc_gp_registers_t;

typedef struct pcc_app_nvxcc_params_resources {
    pcc_emts_t         emts_data;
    pcc_gp_registers_t gp_registers_data;
} pcc_app_nvxcc_params_resources_t;

typedef pcc_app_nvxcc_params_resources_t pcc_app_hpcc_params_resources_t;
typedef struct pcc_app_nvxcc_params {
    pcc_app_nvxcc_params_app_t       app_params;
    pcc_app_nvxcc_params_resources_t app_resources;
    pcc_app_nvxcc_params_vip_t       vip_params; /**< Sets priority TC from which the probe packet will bypass. */
    pcc_app_nvxcc_params_tc_t        app_tc; /**< The TC that the application will examine traffic info of. */
    pcc_acl_group_priority_t         acl_bind_group_prio;
} pcc_app_nvxcc_params_t;

typedef struct pcc_app_hpcc_params {
    pcc_app_hpcc_params_app_t       app_params;
    pcc_app_hpcc_params_resources_t app_resources;
    pcc_acl_group_priority_t        acl_bind_group_prio;
} pcc_app_hpcc_params_t;

typedef enum pcc_application {
    PCC_APP_NVXCC,
    PCC_APP_HPCC
} pcc_app_type_e;

typedef union {
    pcc_app_nvxcc_params_t nvxcc_params;
    pcc_app_hpcc_params_t  hpcc_params;
} pcc_app_params_t;

typedef struct pcc_app_init_param {
    pcc_app_type_e   pcc_app_type;
    pcc_app_params_t pcc_app_params;
} pcc_app_init_params_t;

typedef enum pcc_app_state {
    PCC_APP_STATE_DISABLE,
    PCC_APP_STATE_ENABLE
} pcc_app_state_e;

typedef uint32_t pcc_port_log_id_t;

#define FOREACH_PCC_PORT_SPEED(F)        \
    F(PCC_PORT_SPEED_25GB = 0,  "25Gb")  \
    F(PCC_PORT_SPEED_40GB = 1,  "40Gb")  \
    F(PCC_PORT_SPEED_50GB = 2,  "50Gb")  \
    F(PCC_PORT_SPEED_100GB = 3, "100Gb") \
    F(PCC_PORT_SPEED_200GB = 4, "200Gb") \
    F(PCC_PORT_SPEED_400GB = 5, "400Gb") \
    F(PCC_PORT_SPEED_800GB = 6, "800Gb")

typedef enum pcc_port_speed {
    FOREACH_PCC_PORT_SPEED(SX_GENERATE_ENUM) \
} pcc_port_speed_e;

typedef uint32_t pcc_port_cntr_id_t;

typedef struct pcc_app_port_data {
    pcc_port_speed_e   port_speed;
    pcc_port_cntr_id_t cntr_id;
} pcc_app_port_data_t;


#endif /* SX_PCC_TYPES_H */
