/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include <unistd.h>
#include <sx/pcc/sx_pcc.h>
#include <sx/pcc/sx_pcc_types.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_modifier.h>
#include <sx/sdk/sx_api_flex_parser.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_flex_pm.h>
#include <sx/sdk/sx_api_register.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_port_id.h>
#include <sx/sdk/sx_api_flow_counter.h>
#include "pcc_db.h"

#undef  __MODULE__
#define __MODULE__ SX_PCC


#define PCC_NVXCC_EMTS_TYPES_NUM          3
#define PCC_NVXCC_ACL_REGIONS_NUM         3
#define APP_MIN_EMTS                      3
#define NVXCC_APP_MIN_REGS                (NVXCC_PROBE_REGS_NUM - 2)
#define HPCC_APP_MIN_REGS                 (HPCC_PROBE_REGS_NUM - 2)
#define NVXCC_EMT_ONLY_PROGRAM_CMD_NUM    9
#define HPCC_EMT_ONLY_PROGRAM_CMD_NUM     9
#define NVXCC_META_DATA_WORDS_NUM         14
#define HPCC_META_DATA_WORDS_NUM          16
#define PCC_META_DATA_WORDS_NUM_MAX       16
#define PCC_HEADER_WORDS_LENGTH_MAX       20
#define PCC_META_DATA_DEBUG_WORDS_NUM_MAX 2
#define PCC_DEFAULT_APP_TC                3
#define PCC_DEFAULT_VIP_TC                6
#define PORT_PARSING_DEPTH                256
#define BTH_OVER_UDP_PORT                 4791
/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_api_handle_t        pcc_sx_api_handle_g = 0;
static boolean_t              pcc_initialized_g = FALSE;
static sx_parser_attributes_t port_parsing_depth_g;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

static pcc_status_t __pcc_sdk_port_group_get(pcc_port_log_id_t port, uint32_t *port_group_p);

static pcc_status_t __pcc_sdk_app_state_set(const pcc_app_id_t app_id, const pcc_app_state_e state);

static pcc_status_t __pcc_flex_modifier_configure_edit(sx_flex_modifier_emt_id_e edit_emt);

static pcc_status_t __pcc_flex_modifier_configure_push(pcc_app_type_e             app_type,
                                                       sx_flex_modifier_emt_id_e *bind_emts_arr,
                                                       uint8_t                    bind_emts_num,
                                                       sx_flex_modifier_emt_id_e *spare_emts_arr,
                                                       uint8_t                    spare_emts_num,
                                                       boolean_t                  is_debug,
                                                       uint32_t                   dev_id);

static pcc_status_t __pcc_flex_pm_configure(pcc_app_type_e             app_type,
                                            pcc_app_id_t              *app_id_p,
                                            sx_flex_modifier_emt_id_e *spare_emts_arr,
                                            uint8_t                    spare_emts_num,
                                            pcc_app_nvxcc_params_tc_t *tc_p);

static pcc_status_t __pcc_nvxcc_acls_configure(pcc_app_nvxcc_params_vip_t *vip_params_p,
                                               probe_words_arr             probe_regs_arr,
                                               acl_regions_params_arr      acl_regions_params);

static pcc_status_t __pcc_nvxcc_app_set(const pcc_access_cmd_e       cmd,
                                        const pcc_app_init_params_t *app_init_params_p,
                                        pcc_app_id_t                *app_id_p);

static pcc_status_t __pcc_app_resources_check_update_valid(pcc_app_type_e      app_type,
                                                           pcc_emts_t         *emts_data,
                                                           pcc_gp_registers_t *gp_registers_data);

static pcc_status_t __pcc_app_resources_emt_set_types(pcc_emts_t                 *emts_data,
                                                      sx_flex_modifier_emt_id_e  *bind_emts_arr,
                                                      uint8_t                    *bind_emts_num,
                                                      sx_flex_modifier_emt_id_e * spare_emts_arr,
                                                      uint8_t                    *spare_emts_num,
                                                      sx_flex_modifier_emt_id_e * edit_emt);


static pcc_status_t __pcc_extraction_points_set(probe_words_arr probe_words_regs_arr,
                                                uint8_t        *regs_offset_arr,
                                                uint8_t         reg_cnt,
                                                uint8_t         reg0_offest,
                                                uint8_t         reg1_offset);

static pcc_status_t __pcc_app_resources_reg_set_types(pcc_gp_registers_t* registers_data_p,
                                                      probe_words_arr     probe_words_regs_arr,
                                                      uint8_t             regs_num);

static sx_acl_key_t __from_reg_id_to_acl_key(pcc_gp_register_e reg_id);

static pcc_status_t __port_speed_value_get(pcc_app_type_e   app_type,
                                           pcc_port_speed_e port_speed,
                                           uint16_t        *port_speed_value);

static pcc_status_t __pcc_port_acl_configuration_set(pcc_app_id_t               app_id,
                                                     pcc_app_type_e             app_type,
                                                     pcc_port_log_id_t          port_id,
                                                     pcc_flex_modifier_emt_id_e bind_emt,
                                                     pcc_flex_modifier_emt_id_e edit_emt,
                                                     acl_regions_params_arr     acl_regions_params_arr,
                                                     const pcc_app_port_data_t *port_data_p);

static pcc_status_t __port_flex_pm_context_set(pcc_access_cmd_e           cmd,
                                               pcc_app_id_t               app_id,
                                               pcc_port_log_id_t          port_id,
                                               pcc_flex_modifier_emt_id_e bind_emt);

static pcc_status_t __pcc_app_resources_emts_deconfigure(pcc_flex_modifier_emt_id_e *configured_emts_arr,
                                                         uint8_t                     configured_emts_num);

static pcc_status_t __pcc_flex_pm_deconfigure(pcc_app_id_t app_id);

static pcc_status_t __pcc_acls_deconfigure(acl_regions_params_arr acl_regions_params_arr);

static pcc_status_t __pcc_extraction_points_unset(probe_words_arr probe_words_regs_arr, uint8_t regs_num);

static pcc_status_t __pcc_app_port_set(const pcc_access_cmd_e     cmd,
                                       const pcc_app_id_t         app_id,
                                       const pcc_port_log_id_t    port_id,
                                       const pcc_app_port_data_t *port_data_p);

static pcc_status_t __pcc_port_acl_configuration_unset(pcc_port_log_id_t      port_id,
                                                       acl_regions_params_arr acl_regions_params_arr);

static pcc_status_t __port_flex_modifier_attributes_set(pcc_access_cmd_e  cmd,
                                                        pcc_port_log_id_t port_id);

static pcc_status_t __pcc_hpcc_app_set(const pcc_access_cmd_e       cmd,
                                       const pcc_app_init_params_t *app_init_params_p,
                                       pcc_app_id_t                *app_id_p);


static uint8_t nvxcc_emts_resources_num[PCC_FLEX_MODIFIER_EMT_LAST_E + 1][PCC_NVXCC_EMTS_TYPES_NUM] = {
    {0, 0, 0},/* 0 EMTs provided*/
    {0, 0, 0},/* 1 */
    {0, 0, 0},/* 2 */
    {1, 1, 1},/* 3 */
    {1, 1, 2},/* 4 */
    {1, 2, 2},/* 5 */
    {1, 2, 3},/* 6 */
    {1, 3, 3},/* 7 */
    {1, 3, 4} /* 8 */
};

static uint32_t nvxcc_emt_only_program_operands[NVXCC_EMT_ONLY_PROGRAM_CMD_NUM][3] = {
    {SX_FLEX_PM_REG_LOCAL_0_E, SX_FLEX_PM_REG_PORT_ID_E, 1},
    {SX_FLEX_PM_REG_LOCAL_0_E, SX_FLEX_PM_REG_LOCAL_0_E, 8},
    {SX_FLEX_PM_REG_LOCAL_0_E, 0x3, 6},
    {SX_FLEX_PM_REG_LOCAL_0_E, SX_FLEX_PM_REG_PORT_ID_E, 0},
    {SX_FLEX_PM_REG_LOCAL_0_E, SX_FLEX_PM_REG_LOCAL_0_E, 6},
    {SX_FLEX_PM_REG_LOCAL_0_E, 0x3, 8},
    {SX_FLEX_PM_REG_LOCAL_0_E, 0, 0},
    {SX_FLEX_PM_REG_LOCAL_0_E, 0x1, 11},
    {SX_FLEX_PM_REG_LOCAL_0_E, 0x2, 10},
};

static sx_flex_pm_app_cmd_op_type_e nvxcc_emt_only_program_operands_type[NVXCC_EMT_ONLY_PROGRAM_CMD_NUM][3] = {
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
};
static sx_flex_pm_app_cmd_op_code_e nvxcc_emt_only_program_opcodes[NVXCC_EMT_ONLY_PROGRAM_CMD_NUM] = {
    SX_FLEX_PM_APP_CMD_LOAD_TX_BYTE_E,
    SX_FLEX_PM_APP_CMD_SHIFT_RIGHT_E,
    SX_FLEX_PM_APP_CMD_STORE_REG_TO_EMT_E,
    SX_FLEX_PM_APP_CMD_LOAD_TC_CURR_OCCUPANCY_E,
    SX_FLEX_PM_APP_CMD_SHIFT_RIGHT_E,
    SX_FLEX_PM_APP_CMD_STORE_REG_TO_EMT_E,
    SX_FLEX_PM_APP_CMD_LOAD_UTC_E,
    SX_FLEX_PM_APP_CMD_STORE_REG_TO_EMT_E,
    SX_FLEX_PM_APP_CMD_STORE_REG_TO_EMT_E,
};

static sx_flex_pm_app_cmd_op_code_e hpcc_emt_only_program_opcodes[HPCC_EMT_ONLY_PROGRAM_CMD_NUM] = {
    SX_FLEX_PM_APP_CMD_LOAD_TX_BYTE_E,
    SX_FLEX_PM_APP_CMD_STORE_REG_TO_EMT_E,
    SX_FLEX_PM_APP_CMD_STORE_REG_TO_EMT_E,
    SX_FLEX_PM_APP_CMD_SHIFT_RIGHT_E,
    SX_FLEX_PM_APP_CMD_AND_IMM_E,
    SX_FLEX_PM_APP_CMD_STORE_REG_TO_EMT_E,
    SX_FLEX_PM_APP_CMD_LOAD_UTC_E,
    SX_FLEX_PM_APP_CMD_STORE_REG_TO_EMT_E,
    SX_FLEX_PM_APP_CMD_STORE_REG_TO_EMT_E,
};

static uint32_t hpcc_emt_only_program_operands[HPCC_EMT_ONLY_PROGRAM_CMD_NUM][3] = {
    {SX_FLEX_PM_REG_LOCAL_0_E, SX_FLEX_PM_REG_PORT_ID_E, 1},
    {SX_FLEX_PM_REG_LOCAL_0_E, 0x1, 15},
    {SX_FLEX_PM_REG_LOCAL_0_E, 0x2, 14},
    {SX_FLEX_PM_REG_LOCAL_0_E, SX_FLEX_PM_REG_LOCAL_0_E, 32},
    {SX_FLEX_PM_REG_LOCAL_1_E, SX_FLEX_PM_REG_LOCAL_0_E, 0x00ff}, /* Bits 32 - 39 on */
    {SX_FLEX_PM_REG_LOCAL_1_E, 0x1, 2},
    {SX_FLEX_PM_REG_LOCAL_0_E, 0, 0},
    {SX_FLEX_PM_REG_LOCAL_0_E, 0x2, 9},
    {SX_FLEX_PM_REG_LOCAL_0_E, 0x1, 10},
};

static sx_flex_pm_app_cmd_op_type_e hpcc_emt_only_program_operands_type[HPCC_EMT_ONLY_PROGRAM_CMD_NUM][3] = {
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
    {SX_FLEX_PM_APP_CMD_OP_TYPE_REG_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E, SX_FLEX_PM_APP_CMD_OP_TYPE_IMM_E},
};

static uint8_t probe_regs_nvxcc_offsets[NVXCC_PROBE_REGS_NUM] = {0, 2, 4, 6};
static uint8_t probe_regs_hpcc_offsets[HPCC_PROBE_REGS_NUM] = {0, 2, 4, 6, 8};
/************************************************
*  Function implementations
************************************************/
static pcc_status_t __pcc_sx_lib_adviser_init()
{
    pcc_status_t                 err = PCC_STATUS_SUCCESS;
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_lib_adviser_init_params_t sx_adviser_init_params;

    memset(&sx_adviser_init_params, 0, sizeof(sx_adviser_init_params));

    sx_adviser_init_params.logging_cb = NULL;
    sx_adviser_init_params.verbosity_level = SX_VERBOSITY_LEVEL_NOTICE;
    sx_adviser_init_params.trap_group_allocate_mode = SX_LIB_ADVISER_TRAP_GROUP_ALLOCATE_MODE_DYNAMIC;
    sx_status = sx_lib_adviser_init(sx_adviser_init_params);
    if (SX_CHECK_FAIL(sx_status)) {
        err = PCC_STATUS_ERROR;
        SX_LOG_ERR("Failed to initialize SX lib adviser for PCC LIB, err: %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

out:
    return err;
}

static pcc_status_t __pcc_sx_lib_adviser_deinit()
{
    pcc_status_t err = PCC_STATUS_SUCCESS;
    sx_status_t  sx_status = SX_STATUS_SUCCESS;

    sx_status = sx_lib_adviser_deinit();
    if (SX_CHECK_FAIL(sx_status)) {
        err = PCC_STATUS_ERROR;
        SX_LOG_ERR("Failed to deinitialize SX lib adviser in PCC LIB, err: %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

out:
    return err;
}

static sx_status_t __sx_adviser_port_added_deleted_cb(const sx_lib_adviser_event_info_t event_info,
                                                      const void                       *context)
{
    sx_status_t  sx_status = SX_STATUS_SUCCESS;
    pcc_status_t rc = PCC_STATUS_SUCCESS;

    UNUSED_PARAM(context);


    if ((event_info.type != SX_LIB_ADVISER_PORT_ADDED_E) && (event_info.type != SX_LIB_ADVISER_PORT_DELETED_E)) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Wrong adviser type %s, err: %s\n",
                   sx_lib_adviser_event_type_str(event_info.type), sx_status_str(sx_status));
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(event_info.info.port_added_deleted.log_port) != SX_PORT_TYPE_NETWORK) {
        goto out;
    }
    if (event_info.type == SX_LIB_ADVISER_PORT_ADDED_E) {
        rc = __port_flex_modifier_attributes_set(PCC_ACCESS_CMD_ADD_E, event_info.info.port_added_deleted.log_port);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed setting port 0x%08X flex modifier attributes with cmd = %d, error: %s\n",
                       event_info.info.port_added_deleted.log_port,
                       PCC_ACCESS_CMD_ADD_E,
                       pcc_status_str(rc));
            goto out;
        }
    } else {
        rc = __port_flex_modifier_attributes_set(PCC_ACCESS_CMD_DELETE_E, event_info.info.port_added_deleted.log_port);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed setting port 0x%08X flex modifier attributes with cmd = %d, error: %s\n",
                       event_info.info.port_added_deleted.log_port,
                       PCC_ACCESS_CMD_ADD_E,
                       pcc_status_str(rc));
            goto out;
        }
    }

out:
    return sx_status;
}

static pcc_status_t __pcc_port_add_sx_adviser_register()
{
    sx_lib_adviser_event_registration_params_t event_registration_params;
    pcc_status_t                               err = PCC_STATUS_SUCCESS;
    sx_status_t                                sx_status = SX_STATUS_SUCCESS;

    err = __pcc_sx_lib_adviser_init();
    if (err != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("lib adviser init failed, err=%u\n", err);
        goto out;
    }

    event_registration_params.event_type = SX_LIB_ADVISER_PORT_ADDED_E;
    event_registration_params.excluded_ports_cnt = 0;
    event_registration_params.excluded_ports_p = NULL;
    event_registration_params.callback = __sx_adviser_port_added_deleted_cb;
    event_registration_params.context = NULL;


    sx_status = sx_lib_adviser_event_register(event_registration_params);
    if (SX_CHECK_FAIL(sx_status)) {
        err = PCC_STATUS_ERROR;
        SX_LOG_ERR("Failed to register to SX lib adviser port added event, err: %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    event_registration_params.event_type = SX_LIB_ADVISER_PORT_DELETED_E;
    event_registration_params.excluded_ports_cnt = 0;
    event_registration_params.excluded_ports_p = NULL;
    event_registration_params.callback = __sx_adviser_port_added_deleted_cb;
    event_registration_params.context = NULL;


    sx_status = sx_lib_adviser_event_register(event_registration_params);
    if (SX_CHECK_FAIL(sx_status)) {
        err = PCC_STATUS_ERROR;
        SX_LOG_ERR("Failed to register to SX lib adviser port added event, err: %s\n",
                   sx_status_str(sx_status));
        goto out;
    }


out:
    /* A rollback is not needed as failures are not a valid flow */
    return err;
}

static pcc_status_t __pcc_port_add_sx_adviser_deregister()
{
    sx_lib_adviser_event_registration_params_t event_registration_params;
    pcc_status_t                               err = PCC_STATUS_SUCCESS;
    sx_status_t                                sx_status = SX_STATUS_SUCCESS;

    event_registration_params.excluded_ports_cnt = 0;
    event_registration_params.excluded_ports_p = NULL;
    event_registration_params.context = NULL;
    event_registration_params.callback = __sx_adviser_port_added_deleted_cb;
    event_registration_params.event_type = SX_LIB_ADVISER_PORT_ADDED_E;
    sx_status = sx_lib_adviser_event_deregister(event_registration_params);
    if (SX_CHECK_FAIL(sx_status)) {
        err = PCC_STATUS_ERROR;
        SX_LOG_ERR("Failed to deregister event type %u for PCC LIB , err: %s\n",
                   SX_LIB_ADVISER_PORT_ADDED_E, sx_status_str(sx_status));
        goto out;
    }

    event_registration_params.excluded_ports_cnt = 0;
    event_registration_params.excluded_ports_p = NULL;
    event_registration_params.context = NULL;
    event_registration_params.callback = __sx_adviser_port_added_deleted_cb;
    event_registration_params.event_type = SX_LIB_ADVISER_PORT_DELETED_E;
    sx_status = sx_lib_adviser_event_deregister(event_registration_params);
    if (SX_CHECK_FAIL(sx_status)) {
        err = PCC_STATUS_ERROR;
        SX_LOG_ERR("Failed to deregister event type %u for PCC LIB , err: %s\n",
                   SX_LIB_ADVISER_PORT_ADDED_E, sx_status_str(sx_status));
        goto out;
    }
    err = __pcc_sx_lib_adviser_deinit();
    if (err != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("lib adviser deinit failed, err=%u\n", err);
        goto out;
    }

out:
    return err;
}

pcc_status_t pcc_api_init_set()
{
    pcc_status_t           rc = PCC_STATUS_SUCCESS;
    sx_status_t            sdk_rc = SX_STATUS_SUCCESS;
    sx_flex_parser_param_t flex_parser_params = {0};
    sx_port_attributes_t  *port_attributes_list_p = NULL;
    sx_parser_attributes_t port_parser_attr;
    uint32_t               port_cnt = 0;
    uint32_t               i = 0;

    memset(&port_parser_attr, 0, sizeof(port_parser_attr));
    memset(&port_parsing_depth_g, 0, sizeof(port_parsing_depth_g));


    if (pcc_initialized_g) {
        rc = PCC_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("PCC LIB is already initialized, error: %s\n", pcc_status_str(rc));
        goto out;
    }

    sdk_rc = sx_api_open(NULL, &pcc_sx_api_handle_g);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("Failed to open SX-API for PCC LIB, error: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }

    flex_parser_params.default_flex_parser_graph = FALSE;
    sdk_rc = sx_api_flex_parser_init_set(pcc_sx_api_handle_g, &flex_parser_params);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("Failed to initiate flex parser for PCC LIB, error: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }

    sdk_rc = sx_api_port_parser_attr_get(pcc_sx_api_handle_g, &port_parsing_depth_g);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("sx_api_port_parser_attr_get failed, error: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }
    port_parser_attr.parsing_depth_valid = TRUE;
    port_parser_attr.parsing_depth = PORT_PARSING_DEPTH;
    sdk_rc = sx_api_port_parser_attr_set(pcc_sx_api_handle_g, &port_parser_attr);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("sx_api_port_parser_attr_set failed, error: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }

    /* Set flex modifier port attributes on all ports */
    sdk_rc = sx_api_port_device_get(pcc_sx_api_handle_g, 1, 0, NULL, &port_cnt);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("SX_PCC: sx_api_port_device_get failed, err: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }

    if (port_cnt != 0) {
        port_attributes_list_p = (sx_port_attributes_t*)cl_malloc(sizeof(sx_port_attributes_t) * port_cnt);
        if (port_attributes_list_p == NULL) {
            SX_LOG_ERR("SX_PCC: Failed to allocate memory for port list.\n");
            rc = PCC_STATUS_NO_RESOURCES;
            goto out;
        }
    }

    sdk_rc = sx_api_port_device_get(pcc_sx_api_handle_g, 1, 0, port_attributes_list_p, &port_cnt);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("SX_PCC: sx_api_port_device_get failed, err: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }
    for (i = 0; i < port_cnt; i++) {
        if (SX_PORT_TYPE_ID_GET(port_attributes_list_p[i].log_port) != SX_PORT_TYPE_NETWORK) {
            continue;
        }
        rc = __port_flex_modifier_attributes_set(PCC_ACCESS_CMD_ADD_E, port_attributes_list_p[i].log_port);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed setting port 0x%0X flex modifier attributes with cmd = %d, error: %s\n",
                       port_attributes_list_p[i].log_port,
                       PCC_ACCESS_CMD_ADD_E,
                       pcc_status_str(rc));
            goto out;
        }
    }


    /* Set lib adviser to configure ports attributes of added ports*/
    rc = __pcc_port_add_sx_adviser_register();
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register for sx_adviser in PCC LIB, error: %s\n",
                   pcc_status_str(rc));
        goto out;
    }

    pcc_db_init();
out:
    if (port_attributes_list_p) {
        cl_free(port_attributes_list_p);
    }
    return rc;
}

pcc_status_t pcc_api_deinit_set()
{
    pcc_status_t                  rc = PCC_STATUS_SUCCESS;
    sx_status_t                   sdk_rc = SX_STATUS_SUCCESS;
    pcc_app_id_t                 *app_id_list_p = NULL;
    uint32_t                      apps_count = 0, i = 0;
    sx_port_attributes_t         *port_attributes_list_p = NULL;
    uint32_t                      port_cnt = 0;
    sx_flex_modifier_attributes_t attr_cfg = {0};
    uint32_t                      attr_cnt = 1;

    rc = pcc_db_apps_get(NULL, &apps_count);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APPs count from DB, error: %s\n", pcc_status_str(rc));
        goto out;
    }

    if (apps_count != 0) {
        app_id_list_p = (pcc_app_id_t *)cl_malloc(sizeof(pcc_app_id_t) * (apps_count));
        if (app_id_list_p == NULL) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("Memory allocation for APPs list in PCC LIB failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_apps_get(app_id_list_p, &apps_count);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get APPs from DB, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        for (i = 0; i < apps_count; i++) {
            rc = pcc_api_app_set(PCC_ACCESS_CMD_DELETE_E,
                                 NULL,
                                 &app_id_list_p[i]);
            if (rc != PCC_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to delete APP (%d) from PCC LIB, error: %s\n", app_id_list_p[i],
                           pcc_status_str(rc));
                goto out;
            }
        }
    }
    /* Set flex modifier port attributes on all ports */
    sdk_rc = sx_api_port_device_get(pcc_sx_api_handle_g, 1, 0, NULL, &port_cnt);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("SX_PCC: sx_api_port_device_get failed, err: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }

    if (port_cnt != 0) {
        port_attributes_list_p = (sx_port_attributes_t*)cl_malloc(sizeof(sx_port_attributes_t) * port_cnt);
        if (port_attributes_list_p == NULL) {
            SX_LOG_ERR("SX_PCC: Failed to allocate memory for port list.\n");
            rc = PCC_STATUS_NO_RESOURCES;
            goto out;
        }
    }

    sdk_rc = sx_api_port_device_get(pcc_sx_api_handle_g, 1, 0, port_attributes_list_p, &port_cnt);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("SX_PCC: sx_api_port_device_get failed, err: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }
    for (i = 0; i < port_cnt; i++) {
        if (SX_PORT_TYPE_ID_GET(port_attributes_list_p[i].log_port) != SX_PORT_TYPE_NETWORK) {
            continue;
        }
        attr_cfg.attr_type = SX_FLEX_MODIFIER_ATTR_TYPE_PORT_E;
        attr_cfg.sx_flex_modifier_attr.port_attributes.log_port = port_attributes_list_p[i].log_port;
        attr_cfg.sx_flex_modifier_attr.port_attributes.payload_offset_shift = 0;
        attr_cnt = 1;
        sdk_rc = sx_api_flex_modifier_attr_get(pcc_sx_api_handle_g,
                                               SX_ACCESS_CMD_GET,
                                               &attr_cfg,
                                               &attr_cnt);
        if (sdk_rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SDK API sx_api_flex_modifier_attr_set failed: [%s] \n", sx_status_str(sdk_rc));
            rc = PCC_STATUS_ERROR;
            goto out;
        }

        if (attr_cfg.sx_flex_modifier_attr.port_attributes.payload_offset_shift == 0) {
            continue;
        }

        rc = __port_flex_modifier_attributes_set(PCC_ACCESS_CMD_DELETE_E, port_attributes_list_p[i].log_port);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed setting port 0x%0X flex modifier attributes with cmd = %d, error: %s\n",
                       port_attributes_list_p[i].log_port,
                       PCC_ACCESS_CMD_ADD_E,
                       pcc_status_str(rc));
            goto out;
        }
    }

    sdk_rc = sx_api_port_parser_attr_set(pcc_sx_api_handle_g, &port_parsing_depth_g);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("sx_api_port_parser_attr_set failed, error: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }


    sdk_rc = sx_api_flex_parser_deinit_set(pcc_sx_api_handle_g);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("Failed to deinit flex parser for PCC LIB, error: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }

    sdk_rc = sx_api_close(&pcc_sx_api_handle_g);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("Failed to close SX-API, error: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }
    rc = __pcc_port_add_sx_adviser_deregister();
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deregister for sx_adviser in  PCC LIB, error: %s\n",
                   pcc_status_str(rc));
        goto out;
    }
    pcc_db_deinit();

out:
    if (app_id_list_p) {
        cl_free(app_id_list_p);
    }
    if (port_attributes_list_p) {
        cl_free(port_attributes_list_p);
    }
    return rc;
}

pcc_status_t pcc_api_app_set(const pcc_access_cmd_e       cmd,
                             const pcc_app_init_params_t *app_init_params_p,
                             pcc_app_id_t                *app_id_p)
{
    pcc_status_t   rc = PCC_STATUS_SUCCESS;
    pcc_app_type_e app_type = 0;

    if ((app_init_params_p == NULL) && (cmd != PCC_ACCESS_CMD_DELETE_E)) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("app_init_params_p is NULL. error: %s\n", pcc_status_str(rc));
        goto out;
    }

    if (app_id_p == NULL) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("app_id_p is NULL. error: %s\n", pcc_status_str(rc));
        goto out;
    }
    if (cmd == PCC_ACCESS_CMD_DELETE_E) {
        rc = pcc_db_app_type_get(*app_id_p, &app_type);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get app type, error: %s\n", pcc_status_str(rc));
            goto out;
        }
    } else {
        app_type = app_init_params_p->pcc_app_type;
    }

    switch (app_type) {
    case PCC_APP_NVXCC:
        /* coverity[var_deref_model] */
        rc = __pcc_nvxcc_app_set(cmd, app_init_params_p, app_id_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set NVxCC APP, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        break;

    case PCC_APP_HPCC:
        rc = __pcc_hpcc_app_set(cmd, app_init_params_p, app_id_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set HPCC APP, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("APP type not supported, type = (%d). error: %s\n",
                   app_init_params_p->pcc_app_type, pcc_status_str(rc));
        break;
    }

out:
    return rc;
}

pcc_status_t pcc_api_app_state_set(const pcc_app_id_t app_id, const pcc_app_state_e state)
{
    pcc_status_t rc = PCC_STATUS_SUCCESS;

    if ((state != PCC_APP_STATE_ENABLE) && (state != PCC_APP_STATE_DISABLE)) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("State: %u is out of range, error: %s\n", state, pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_sdk_app_state_set(app_id, state);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed setting state: %u for APP %u, error: %s\n", state, app_id, pcc_status_str(rc));
        goto out;
    }

    rc = pcc_db_app_state_set(app_id, state);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed adding state to DB, state: %u for APP %u, error: %s\n", state, app_id, pcc_status_str(rc));
        goto out;
    }

out:
    return rc;
}

pcc_status_t pcc_api_app_port_set(const pcc_access_cmd_e     cmd,
                                  const pcc_app_id_t         app_id,
                                  const pcc_port_log_id_t    port_id,
                                  const pcc_app_port_data_t *port_data_p)
{
    pcc_status_t   rc = PCC_STATUS_SUCCESS;
    pcc_app_type_e app_type = 0;

    if ((port_data_p == NULL) && (cmd != PCC_ACCESS_CMD_DELETE_E)) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("port_data_p is NULL. error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = pcc_db_app_type_get(app_id, &app_type);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed getting APP (%d) type from DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    switch (app_type) {
    case PCC_APP_NVXCC:
    case PCC_APP_HPCC:
        rc = __pcc_app_port_set(cmd, app_id, port_id, port_data_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set NVxCC APP, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("APP type not supported, type = (%d). error: %s\n",
                   app_type, pcc_status_str(rc));
        break;
    }
out:
    return rc;
}

pcc_status_t pcc_api_app_port_get(const pcc_app_id_t      app_id,
                                  const pcc_port_log_id_t port_id,
                                  pcc_app_port_data_t    *app_port_data_p)
{
    pcc_status_t rc = PCC_STATUS_SUCCESS;

    if (app_port_data_p == NULL) {
        SX_LOG_ERR("App Port Data is NULL\n");
        rc = PCC_STATUS_ERROR;
        goto out;
    }

    rc = pcc_db_app_port_get(app_id, port_id, app_port_data_p);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get port 0x%08X from PCC DB, error: %s\n", port_id, pcc_status_str(rc));
        goto out;
    }

out:
    return rc;
}

pcc_status_t pcc_api_app_port_iter_get(const pcc_access_cmd_e cmd,
                                       const pcc_app_id_t     app_id,
                                       pcc_port_log_id_t     *port_id_list_p,
                                       uint32_t              *port_id_list_cnt_p)
{
    pcc_status_t rc = PCC_STATUS_SUCCESS;

    if (port_id_list_cnt_p == NULL) {
        SX_LOG_ERR(" Port List Count is NULL\n");
        rc = PCC_STATUS_ERROR;
        goto out;
    }

    if ((port_id_list_cnt_p == 0) || (port_id_list_p == NULL)) {
        rc = pcc_db_app_ports_count_get(app_id, port_id_list_cnt_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in pcc_db_app_ports_count_get, error %s \n", pcc_status_str(rc));
            goto out;
        }

        goto out;
    }

    switch (cmd) {
    case PCC_ACCESS_CMD_GET_FIRST_E:
        rc = pcc_db_app_ports_get_first(app_id, port_id_list_p, port_id_list_cnt_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in pcc_db_app_ports_get_first, error %s \n", pcc_status_str(rc));
            goto out;
        }

        break;

    case PCC_ACCESS_CMD_GET_NEXT_E:
        rc = pcc_db_app_ports_get_next(app_id, port_id_list_p, port_id_list_cnt_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in pcc_db_app_ports_get_first, error %s \n", pcc_status_str(rc));
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Command %u is not supported\n", cmd);
        rc = PCC_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}

static pcc_status_t __port_flex_modifier_attributes_set(pcc_access_cmd_e cmd, pcc_port_log_id_t port_id)
{
    sx_status_t                   sdk_rc = SX_STATUS_SUCCESS;
    pcc_status_t                  rc = PCC_STATUS_SUCCESS;
    sx_flex_modifier_attributes_t attr_cfg;
    sx_access_cmd_t               sx_cmd = SX_ACCESS_CMD_ADD;

    if (cmd == PCC_ACCESS_CMD_DELETE_E) {
        sx_cmd = SX_ACCESS_CMD_DELETE;
    }

    attr_cfg.attr_type = SX_FLEX_MODIFIER_ATTR_TYPE_PORT_E;
    attr_cfg.sx_flex_modifier_attr.port_attributes.log_port = port_id;

    attr_cfg.sx_flex_modifier_attr.port_attributes.payload_offset_shift = 2 * (PCC_META_DATA_WORDS_NUM_MAX +
                                                                               PCC_HEADER_WORDS_LENGTH_MAX +
                                                                               PCC_META_DATA_DEBUG_WORDS_NUM_MAX);

    sdk_rc = sx_api_flex_modifier_attr_set(pcc_sx_api_handle_g,
                                           sx_cmd,
                                           &attr_cfg,
                                           1);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SDK API sx_api_flex_modifier_attr_set failed: [%s] \n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }
out:
    return rc;
}
static pcc_status_t __port_flex_pm_context_set(pcc_access_cmd_e           cmd,
                                               pcc_app_id_t               app_id,
                                               pcc_port_log_id_t          port_id,
                                               pcc_flex_modifier_emt_id_e bind_emt)
{
    sx_status_t                             sdk_rc = SX_STATUS_SUCCESS;
    pcc_status_t                            rc = PCC_STATUS_SUCCESS;
    sx_flex_pm_app_program_context_key_t    context_key;
    sx_flex_pm_app_program_context_config_t config;

    context_key.app_key.app_id = (sx_flex_pm_app_id_t)app_id;
    context_key.log_port = port_id;
    switch (cmd) {
    case PCC_ACCESS_CMD_ADD_E:
        config.data.emt_data.emt_data.emt_key.emt_id = (sx_flex_modifier_emt_id_e)bind_emt;
        config.data.emt_data.emt_data.reg_persistent_0 = PCC_GP_REGISTER_0_E;
        config.type = SX_FLEX_PM_APP_PROG_CONTEXT_EMT_E;
        sdk_rc = sx_api_flex_pm_app_program_context_set(pcc_sx_api_handle_g,
                                                        SX_ACCESS_CMD_ADD,
                                                        &context_key,
                                                        &config,
                                                        1);
        if (SX_CHECK_FAIL(sdk_rc)) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("sx_api_flex_pm_app_program_context_set, cmd %s, error: %s\n",
                       sx_access_cmd_str(SX_ACCESS_CMD_ADD), sx_status_str(sdk_rc));
            goto out;
        }
        break;

    case PCC_ACCESS_CMD_DELETE_E:
        sdk_rc = sx_api_flex_pm_app_program_context_set(pcc_sx_api_handle_g,
                                                        SX_ACCESS_CMD_DELETE,
                                                        &context_key,
                                                        NULL,
                                                        1);
        if (SX_CHECK_FAIL(sdk_rc)) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("sx_api_flex_pm_app_program_context_set, cmd %s, error: %s\n",
                       sx_access_cmd_str(SX_ACCESS_CMD_DELETE), sx_status_str(sdk_rc));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Command %u is not supported\n", cmd);
        rc = PCC_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}

static pcc_status_t __pcc_port_speed_range_check(pcc_app_type_e app_type, pcc_port_speed_e port_speed)
{
    pcc_status_t rc = PCC_STATUS_SUCCESS;

    switch (app_type) {
    case PCC_APP_NVXCC:
        switch (port_speed) {
        case PCC_PORT_SPEED_25GB:
        case PCC_PORT_SPEED_40GB:
        case PCC_PORT_SPEED_50GB:
        case PCC_PORT_SPEED_100GB:
        case PCC_PORT_SPEED_200GB:
        case PCC_PORT_SPEED_400GB:
        case PCC_PORT_SPEED_800GB:
            break;

        default:
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("Port speed %d is not supported for NVxCC APP, error: %s\n", port_speed, pcc_status_str(rc));
            goto out;
        }
        break;

    case PCC_APP_HPCC:
        switch (port_speed) {
        case PCC_PORT_SPEED_40GB:
        case PCC_PORT_SPEED_100GB:
            break;

        default:
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("Port speed %d is not supported for HPCC APP, error: %s\n", port_speed, pcc_status_str(rc));
            goto out;
        }
        break;
    }

out:
    return rc;
}

static pcc_status_t __pcc_port_acl_configuration_set(pcc_app_id_t               app_id,
                                                     pcc_app_type_e             app_type,
                                                     pcc_port_log_id_t          port_id,
                                                     pcc_flex_modifier_emt_id_e bind_emt,
                                                     pcc_flex_modifier_emt_id_e edit_emt,
                                                     acl_regions_params_arr     acl_regions_params_arr,
                                                     const pcc_app_port_data_t *port_data_p)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    sx_status_t             sdk_rc = SX_STATUS_SUCCESS;
    uint32_t                max_num_of_rules = 1;
    uint16_t                port_speed_value = 0, action_idx = 0;
    sx_flex_acl_flex_rule_t rules[max_num_of_rules];
    sx_acl_rule_offset_t    offset = 0;
    uint32_t                device_id = 0;

    memset(&rules, 0, sizeof(sx_flex_acl_flex_rule_t) * max_num_of_rules);

    sdk_rc = sx_api_acl_port_bind_set(pcc_sx_api_handle_g,
                                      SX_ACCESS_CMD_BIND,
                                      port_id,
                                      acl_regions_params_arr[0].acl_group_id);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SDK API sx_api_acl_port_bind_set failed: [%s] \n", sx_status_str(sdk_rc));
        goto out;
    }

    sdk_rc = sx_lib_flex_acl_rule_init(acl_regions_params_arr[2].key_handle, 5, &rules[0]);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SDK API sx_lib_flex_acl_rule_init failed: [%s] \n", sx_status_str(sdk_rc));
        goto out;
    }

    rules[0].valid = 1;
    rules[0].key_desc_count = 1;
    rules[0].key_desc_list_p[0].key_id = FLEX_ACL_KEY_DST_PORT;
    rules[0].key_desc_list_p[0].key.dst_port = port_id;
    rules[0].key_desc_list_p[0].mask.dst_port = TRUE;
    rules[0].action_list_p[action_idx].type = SX_FLEX_ACL_ACTION_SET_EMT;
    rules[0].action_list_p[action_idx].fields.action_set_emt.emt_bind_action[0].emt_bind_index =
        SX_FLEX_MODIFIER_EMT_BIND_INDEX_0_E;
    rules[0].action_list_p[action_idx].fields.action_set_emt.emt_bind_action[0].emt_bind_type =
        SX_FLEX_MODIFIER_BIND_TYPE_EDIT_E;
    rules[0].action_list_p[action_idx].fields.action_set_emt.emt_bind_action[0].emt_bind_type_attr.emt_id.emt_id =
        (sx_flex_modifier_emt_id_e)edit_emt;
    rules[0].action_list_p[action_idx++].fields.action_set_emt.emt_bind_action[0].emt_bind_type_attr.emt_offset =
        SX_FLEX_MODIFIER_GP_REGISTER_0_OFFSET_E;

    rules[0].action_list_p[action_idx].type = SX_FLEX_ACL_ACTION_SET_EMT;
    rules[0].action_list_p[action_idx].fields.action_set_emt.emt_bind_action[0].emt_bind_index =
        SX_FLEX_MODIFIER_EMT_BIND_INDEX_1_E;
    rules[0].action_list_p[action_idx].fields.action_set_emt.emt_bind_action[0].emt_bind_type =
        SX_FLEX_MODIFIER_BIND_TYPE_PUSH_E;
    rules[0].action_list_p[action_idx].fields.action_set_emt.emt_bind_action[0].emt_bind_type_attr.emt_id.emt_id =
        (sx_flex_modifier_emt_id_e)bind_emt;
    rules[0].action_list_p[action_idx++].fields.action_set_emt.emt_bind_action[0].emt_bind_type_attr.emt_offset =
        SX_FLEX_MODIFIER_GP_REGISTER_1_OFFSET_E;

    rc = __port_speed_value_get(app_type, port_data_p->port_speed, &port_speed_value);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed getting port speed value, error: %s\n", pcc_status_str(rc));
        goto rule0_rollback;
    }

    if (app_type == PCC_APP_HPCC) {
        rules[0].action_list_p[action_idx].type = SX_FLEX_ACL_ACTION_ALU_IMM;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.command = SX_ACL_ACTION_ALU_IMM_COMMAND_SET;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.dst_offset = 2;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.dst_register = SX_GP_REGISTER_1_E;

        rc = pcc_db_app_hpcc_device_id_get(app_id, &device_id);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed getting device ID from DB, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        rules[0].action_list_p[action_idx].fields.action_alu_imm.imm_data = device_id;
        rules[0].action_list_p[action_idx++].fields.action_alu_imm.size = 14;

        rules[0].action_list_p[action_idx].type = SX_FLEX_ACL_ACTION_ALU_IMM;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.command = SX_ACL_ACTION_ALU_IMM_COMMAND_SET;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.dst_offset = 0;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.dst_register = SX_GP_REGISTER_1_E;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.imm_data = port_speed_value;
        rules[0].action_list_p[action_idx++].fields.action_alu_imm.size = 2;
    } else {
        rules[0].action_list_p[action_idx].type = SX_FLEX_ACL_ACTION_ALU_IMM;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.command = SX_ACL_ACTION_ALU_IMM_COMMAND_SET;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.dst_offset = 12;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.dst_register = SX_GP_REGISTER_1_E;
        rules[0].action_list_p[action_idx].fields.action_alu_imm.imm_data = port_speed_value;
        rules[0].action_list_p[action_idx++].fields.action_alu_imm.size = 4;
    }

    if (port_data_p->cntr_id) {
        rules[0].action_list_p[action_idx].type = SX_FLEX_ACL_ACTION_COUNTER;
        rules[0].action_list_p[action_idx++].fields.action_counter.counter_id = port_data_p->cntr_id;
    }

    rules[0].action_count = action_idx;
    offset = SX_PORT_LCL_ID_GET(port_id); /*Rule ID */
    sdk_rc = sx_api_acl_flex_rules_set(pcc_sx_api_handle_g,
                                       SX_ACCESS_CMD_SET,
                                       acl_regions_params_arr[2].region_id,
                                       &offset,
                                       rules,
                                       1);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SDK API sx_api_acl_flex_rules_set for region3 with rule offset = %d, failed [%s]\n",
                   offset,
                   sx_status_str(sdk_rc));
        goto rule0_rollback;
    }

rule0_rollback:
    sdk_rc = sx_lib_flex_acl_rule_deinit(&rules[0]);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SDK API sx_lib_flex_acl_rule_deinit failed: [%s] \n", sx_status_str(sdk_rc));
        goto out;
    }


out:
    return rc;
}

static pcc_status_t __pcc_sdk_port_group_get(pcc_port_log_id_t port, uint32_t *port_group_p)
{
    pcc_status_t         rc = PCC_STATUS_SUCCESS;
    sx_status_t          sdk_rc = SX_STATUS_SUCCESS;
    sx_port_group_cfg_t  port_group_cfg;
    sx_port_group_attr_t group_attr;
    uint32_t             port_cnt = 1;


    port_group_cfg.log_port = port;
    port_group_cfg.egress_params.egress_group_id = 0;

    sdk_rc = sx_api_port_group_get(pcc_sx_api_handle_g, SX_ACCESS_CMD_GET, &port_group_cfg, &port_cnt, &group_attr);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("Failed to get port group from sx_api_port_group_get, error: %s\n", sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }

    *port_group_p = port_group_cfg.egress_params.egress_group_id;

out:
    return rc;
}


static pcc_status_t __pcc_sdk_app_state_set(const pcc_app_id_t app_id, const pcc_app_state_e state)
{
    pcc_status_t                rc = PCC_STATUS_SUCCESS;
    sx_status_t                 sdk_rc = SX_STATUS_SUCCESS;
    sx_flex_pm_app_key_t        key = {0};
    sx_flex_pm_app_state_attr_t attr = {0};


    key.app_id = app_id;
    if (state == PCC_APP_STATE_DISABLE) {
        attr.app_state = SX_FLEX_PM_APP_STATE_STOP_E;
    } else {
        attr.app_state = SX_FLEX_PM_APP_STATE_RUN_E;
    }
    sdk_rc = sx_api_flex_pm_app_state_set(pcc_sx_api_handle_g, SX_ACCESS_CMD_SET, &key, &attr);
    if (SX_CHECK_FAIL(sdk_rc)) {
        SX_LOG_ERR("Failed to set APP(%u) state(%u) using sx_api_flex_pm_app_state_set, error: %s\n",
                   app_id,
                   state,
                   sx_status_str(sdk_rc));
        rc = PCC_STATUS_ERROR;
        goto out;
    }
out:
    return rc;
}


static pcc_status_t __pcc_app_resources_check_update_valid(pcc_app_type_e      app_type,
                                                           pcc_emts_t         *emts_data,
                                                           pcc_gp_registers_t *gp_registers_data)
{
    pcc_status_t               rc = PCC_STATUS_SUCCESS;
    uint8_t                    emts_num = 0;
    uint8_t                    regs_num = 0;
    pcc_flex_modifier_emt_id_e valid_emts[PCC_FLEX_MODIFIER_EMT_LAST_E];
    pcc_gp_register_e          valid_regs[PCC_GP_REGISTER_LAST_E];
    uint8_t                    i = 0, regs_min_cnt = 0;
    boolean_t                  is_valid = FALSE;
    boolean_t                  reg_0_valid = FALSE;
    boolean_t                  reg_1_valid = FALSE;

    if ((emts_data == NULL) || (gp_registers_data == NULL)) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("NULL pointer is passed as input for check resources. error: %s\n", pcc_status_str(rc));
        goto out;
    }
    emts_num = emts_data->emt_num;
    regs_num = gp_registers_data->reg_num;
    regs_min_cnt = (app_type == PCC_APP_NVXCC) ? NVXCC_APP_MIN_REGS : HPCC_APP_MIN_REGS;

    /* EMTs check */
    /* The library is responsible to manage the resources_p. Resources are set in
     *  accordance to the globally available EMTs out of which the user provide as
     *  allowed to use */
    for (i = 0; i < emts_num; i++) {
        rc = pcc_db_app_emt_valid_get(emts_data->emts[i], &is_valid);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in pcc_db_app_emt_valid_get, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        if (is_valid) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("given EMT (%d) is already used.error: %s\n", emts_data->emts[i],
                       pcc_status_str(rc));
            goto out;
        } else {
            valid_emts[i] = emts_data->emts[i];
        }
    }

    if (emts_num < APP_MIN_EMTS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("Not enough resources_p, minimum EMTs required (%d)"
                   " < valid EMTs for use (%d). error: %s\n",
                   APP_MIN_EMTS, emts_num, pcc_status_str(rc));
        goto out;
    }

    memcpy(emts_data->emts, valid_emts, sizeof(pcc_flex_modifier_emt_id_e) * emts_num);
    emts_data->emt_num = emts_num;

    /* Registers check */
    for (i = 0; i < regs_num; i++) {
        rc = pcc_db_app_reg_valid_get(gp_registers_data->registers[i], &is_valid);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in pcc_db_app_reg_valid_get, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        if (is_valid) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("given REG (%d) is already used.error: %s\n",
                       gp_registers_data->registers[i],
                       pcc_status_str(rc));
            goto out;
        } else {
            valid_regs[i] = gp_registers_data->registers[i];
        }
    }

    if (regs_num < regs_min_cnt) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("Not enough resources, minimum REGs required (%d)"
                   " < valid REGs for use (%d). error: %s\n",
                   regs_min_cnt, regs_num, pcc_status_str(rc));
        goto out;
    }

    for (i = 0; i < regs_num; i++) {
        if (valid_regs[i] == PCC_GP_REGISTER_0_E) {
            reg_0_valid = TRUE;
        }
        if (valid_regs[i] == PCC_GP_REGISTER_1_E) {
            reg_1_valid = TRUE;
        }
    }

    if ((reg_0_valid == FALSE) || (reg_1_valid == FALSE)) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("Global register 0 and 1 should be valid to use (%s) (%s). error: %s\n",
                   reg_0_valid ? "" : "REG 0 is not valid", reg_1_valid ? "" : "REG 1 is not valid",
                   pcc_status_str(rc));
        goto out;
    }

    memcpy(gp_registers_data->registers, valid_regs, sizeof(pcc_gp_register_e) * regs_num);
    gp_registers_data->reg_num = regs_num;

out:
    return rc;
}

static pcc_status_t __pcc_app_resources_emt_set_types(pcc_emts_t                 *emts_data,
                                                      sx_flex_modifier_emt_id_e  *bind_emts_arr,
                                                      uint8_t                    *bind_emts_num,
                                                      sx_flex_modifier_emt_id_e * spare_emts_arr,
                                                      uint8_t                    *spare_emts_num,
                                                      sx_flex_modifier_emt_id_e * edit_emt)
{
    uint8_t      i = 0, j = 0;
    uint8_t      edit_emts_num = 0;
    pcc_status_t rc = PCC_STATUS_SUCCESS;

    *bind_emts_num = nvxcc_emts_resources_num[emts_data->emt_num][2];
    *spare_emts_num = nvxcc_emts_resources_num[emts_data->emt_num][1];
    edit_emts_num = nvxcc_emts_resources_num[emts_data->emt_num][0]; /* always will be 1 for now */

    for (i = 0; i < emts_data->emt_num;) {
        for (j = 0; j < *bind_emts_num; j++) {
            bind_emts_arr[j] = (sx_flex_modifier_emt_id_e)emts_data->emts[i];
            i++;
        }
        for (j = 0; j < *spare_emts_num; j++) {
            spare_emts_arr[j] = (sx_flex_modifier_emt_id_e)emts_data->emts[i];
            i++;
        }
        for (j = 0; j < edit_emts_num; j++) {
            edit_emt[j] = (sx_flex_modifier_emt_id_e)emts_data->emts[i];
            i++;
        }
    }

    return rc;
}


static pcc_status_t __pcc_flex_modifier_configure_edit(sx_flex_modifier_emt_id_e edit_emt)
{
    pcc_status_t               rc = PCC_STATUS_SUCCESS;
    sx_status_t                sdk_rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_emt_cfg_t emt_cfg;
    sx_flex_modifier_emt_key_t key;

    memset(&emt_cfg, 0, sizeof(sx_flex_modifier_emt_cfg_t));
    memset(&key, 0, sizeof(sx_flex_modifier_emt_key_t));

    key.emt_id = edit_emt;
    sdk_rc = sx_api_flex_modifier_set(pcc_sx_api_handle_g,
                                      SX_ACCESS_CMD_CREATE,
                                      key,
                                      &emt_cfg);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_modifier_set failed to create edit EMT (%d), error: %s\n", edit_emt,
                   sx_status_str(sdk_rc));
        goto out;
    }

    emt_cfg.emt_data_cnt = 1;
    emt_cfg.emt_data_list[0].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_0_E;
    sdk_rc = sx_api_flex_modifier_set(pcc_sx_api_handle_g,
                                      SX_ACCESS_CMD_SET,
                                      key,
                                      &emt_cfg);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_modifier_set failed to set edit EMT (%d), error: %s\n", edit_emt,
                   sx_status_str(sdk_rc));
        goto out;
    }

out:
    return rc;
}

static pcc_status_t __pcc_flex_modifier_configure_push(pcc_app_type_e             app_type,
                                                       sx_flex_modifier_emt_id_e *bind_emts_arr,
                                                       uint8_t                    bind_emts_num,
                                                       sx_flex_modifier_emt_id_e *spare_emts_arr,
                                                       uint8_t                    spare_emts_num,
                                                       boolean_t                  is_debug,
                                                       uint32_t                   dev_id)
{
    pcc_status_t               rc = PCC_STATUS_SUCCESS;
    sx_status_t                sdk_rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_emt_cfg_t emt_cfg;
    sx_flex_modifier_emt_key_t key;
    sx_flex_modifier_emt_id_e  emts_arr[bind_emts_num + spare_emts_num];
    uint16_t                   i = 0;

    memset(&emt_cfg, 0, sizeof(sx_flex_modifier_emt_cfg_t));
    memset(&key, 0, sizeof(sx_flex_modifier_emt_key_t));
    memset(&emts_arr, 0, sizeof(sx_flex_modifier_emt_id_e) * (bind_emts_num + spare_emts_num));

    for (i = 0; i < bind_emts_num; i++) {
        emts_arr[i] = bind_emts_arr[i];
    }
    for (i = bind_emts_num; i < spare_emts_num + bind_emts_num; i++) {
        emts_arr[i] = spare_emts_arr[i - bind_emts_num];
    }

    memset(&emt_cfg, 0, sizeof(sx_flex_modifier_emt_cfg_t));
    for (i = 0; i < bind_emts_num + spare_emts_num; i++) {
        key.emt_id = emts_arr[i];
        sdk_rc = sx_api_flex_modifier_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_CREATE,
                                          key,
                                          &emt_cfg);
        if (sdk_rc != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("sx_api_flex_modifier_set failed to create EMT (%d), error: %s\n", bind_emts_arr[i],
                       sx_status_str(sdk_rc));
            goto out;
        }
    }
    switch (app_type) {
    case PCC_APP_NVXCC:
        emt_cfg.emt_data_cnt = NVXCC_META_DATA_WORDS_NUM;
        emt_cfg.emt_data_list[0].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[0].immediate_value = 0x1000;
        emt_cfg.emt_data_list[0].skip = FALSE;
        emt_cfg.emt_data_list[1].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[1].immediate_value = 0x0006;
        emt_cfg.emt_data_list[1].skip = FALSE;

        emt_cfg.emt_data_list[2].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[2].immediate_value = (uint16_t)((uint32_t)dev_id >> 16);

        emt_cfg.emt_data_list[2].skip = FALSE;
        emt_cfg.emt_data_list[3].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[3].immediate_value = (uint16_t)(dev_id);
        emt_cfg.emt_data_list[3].skip = FALSE;

        emt_cfg.emt_data_list[4].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_SPAN_MIRROR_EGRESS_PORT_LABEL_E;
        emt_cfg.emt_data_list[4].skip = FALSE;
        emt_cfg.emt_data_list[5].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_1_E;
        emt_cfg.emt_data_list[5].skip = FALSE;

        emt_cfg.emt_data_list[6].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[6].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[6].skip = FALSE;
        emt_cfg.emt_data_list[7].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[7].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[7].skip = FALSE;

        emt_cfg.emt_data_list[8].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[8].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[8].skip = FALSE;
        emt_cfg.emt_data_list[9].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[9].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[9].skip = FALSE;

        emt_cfg.emt_data_list[10].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[10].immediate_value = 0x0;
        emt_cfg.emt_data_list[10].skip = FALSE;

        emt_cfg.emt_data_list[11].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[11].immediate_value = 0x0;
        emt_cfg.emt_data_list[11].skip = FALSE;

        emt_cfg.emt_data_list[12].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[12].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[12].skip = FALSE;

        emt_cfg.emt_data_list[13].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[13].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[13].skip = FALSE;

        if (is_debug) {
            emt_cfg.emt_data_cnt += 2;
            emt_cfg.emt_data_list[14].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_NSEC_MSB_E;
            emt_cfg.emt_data_list[14].immediate_value = 0xFFFF;
            emt_cfg.emt_data_list[14].skip = FALSE;
            emt_cfg.emt_data_list[15].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_NSEC_LSB_E;
            emt_cfg.emt_data_list[15].immediate_value = 0xFFFF;
            emt_cfg.emt_data_list[15].skip = FALSE;
        }

        break;

    case PCC_APP_HPCC:
        emt_cfg.emt_data_cnt = HPCC_META_DATA_WORDS_NUM;
        emt_cfg.emt_data_list[0].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[0].immediate_value = (uint16_t)((uint32_t)dev_id >> 14);
        emt_cfg.emt_data_list[0].skip = FALSE;

        emt_cfg.emt_data_list[1].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_1_E;
        emt_cfg.emt_data_list[1].skip = FALSE;

        emt_cfg.emt_data_list[2].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[2].immediate_value = 0x0;
        emt_cfg.emt_data_list[2].skip = FALSE;

        emt_cfg.emt_data_list[3].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_TCLASS_E;
        emt_cfg.emt_data_list[3].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[3].skip = FALSE;

        emt_cfg.emt_data_list[4].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[4].immediate_value = 0x8000;
        emt_cfg.emt_data_list[4].skip = FALSE;

        emt_cfg.emt_data_list[5].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_BUFFER_FILL_LEVEL_MSB_E;
        emt_cfg.emt_data_list[5].skip = FALSE;

        emt_cfg.emt_data_list[6].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_INGRESS_TIMESTAMP_SEC_LSB_E;
        emt_cfg.emt_data_list[6].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[6].skip = FALSE;

        emt_cfg.emt_data_list[7].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_INGRESS_TIMESTAMP_NSEC_MSB_E;
        emt_cfg.emt_data_list[7].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[7].skip = FALSE;

        emt_cfg.emt_data_list[8].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_INGRESS_TIMESTAMP_NSEC_LSB_E;
        emt_cfg.emt_data_list[8].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[8].skip = FALSE;

        emt_cfg.emt_data_list[9].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[9].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[9].skip = FALSE;

        emt_cfg.emt_data_list[10].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[10].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[10].skip = FALSE;

        emt_cfg.emt_data_list[11].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_BUFFER_FILL_LEVEL_LSB_E;
        emt_cfg.emt_data_list[11].skip = FALSE;

        emt_cfg.emt_data_list[12].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_SPAN_MIRROR_INGRESS_PORT_LABEL_E;
        emt_cfg.emt_data_list[12].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[12].skip = FALSE;

        emt_cfg.emt_data_list[13].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_SPAN_MIRROR_EGRESS_PORT_LABEL_E;
        emt_cfg.emt_data_list[13].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[13].skip = FALSE;

        emt_cfg.emt_data_list[14].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[14].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[14].skip = FALSE;

        emt_cfg.emt_data_list[15].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E;
        emt_cfg.emt_data_list[15].immediate_value = 0xFFFF;
        emt_cfg.emt_data_list[15].skip = FALSE;
        if (is_debug) {
            emt_cfg.emt_data_cnt += 2;
            emt_cfg.emt_data_list[16].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_NSEC_MSB_E;
            emt_cfg.emt_data_list[16].immediate_value = 0xFFFF;
            emt_cfg.emt_data_list[16].skip = FALSE;
            emt_cfg.emt_data_list[17].cmd_id = SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_NSEC_LSB_E;
            emt_cfg.emt_data_list[17].immediate_value = 0xFFFF;
            emt_cfg.emt_data_list[17].skip = FALSE;
        }

        break;
    }
    for (i = 0; i < bind_emts_num + spare_emts_num; i++) {
        key.emt_id = emts_arr[i];
        sdk_rc = sx_api_flex_modifier_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_SET,
                                          key,
                                          &emt_cfg);
        if (sdk_rc != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("sx_api_flex_modifier_set failed to set EMT (%d), error: %s\n", bind_emts_arr[i],
                       sx_status_str(sdk_rc));
            goto out;
        }
    }

out:
    return rc;
}

static pcc_status_t __pcc_flex_pm_configure(pcc_app_type_e             app_type,
                                            pcc_app_id_t              *app_id_p,
                                            sx_flex_modifier_emt_id_e *spare_emts_arr,
                                            uint8_t                    spare_emts_num,
                                            pcc_app_nvxcc_params_tc_t *tc_p)
{
    pcc_status_t                  rc = PCC_STATUS_SUCCESS;
    sx_flex_pm_app_key_t          key;
    sx_flex_pm_app_attr_t         app_attr;
    sx_flex_pm_app_resource_t    *resource_list = NULL;
    sx_status_t                   sdk_rc = SX_STATUS_SUCCESS;
    sx_flex_pm_app_program_attr_t program_attr;
    uint8_t                       i = 0, prog_idx = 0;
    pcc_cos_traffic_class_t       app_tc = PCC_DEFAULT_APP_TC;

    resource_list = (sx_flex_pm_app_resource_t*)cl_malloc(sizeof(sx_flex_pm_app_resource_t) * (spare_emts_num + 1));
    if (resource_list == NULL) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("Memory allocation for Flex PM resources in PCC LIB failed, error: %s\n", pcc_status_str(rc));
        goto out;
    }

    for (i = 0; i < spare_emts_num; i++) {
        resource_list[i].data.emt_key.emt_id = spare_emts_arr[i];
        resource_list[i].type = SX_FLEX_PM_APP_PROG_EMT_SPARE_E;
    }

    resource_list[i].data.non_atomic = FALSE;
    resource_list[i].type = SX_FLEX_PM_APP_PROG_EMT_NON_ATOMIC_E;
    app_attr.app_resources.resources_list = resource_list;
    app_attr.app_resources.resources_list_cnt = spare_emts_num + 1;

    sdk_rc = sx_api_flex_pm_app_set(pcc_sx_api_handle_g, SX_ACCESS_CMD_CREATE, &key, &app_attr);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_pm_app_set failed, error: %s\n", sx_status_str(sdk_rc));
        goto out;
    }
    *app_id_p = key.app_id;

    switch (app_type) {
    case PCC_APP_NVXCC:
        if (tc_p == NULL) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("input parameter tc_p is NULL, error: %s\n", sx_status_str(sdk_rc));
            goto out;
        }
        if (tc_p->set_app_tc) {
            app_tc = tc_p->app_tc;

            if (app_tc > SX_COS_TRAFFIC_CLASS_MAX) {
                rc = PCC_STATUS_ERROR;
                SX_LOG_ERR("input parameter app_tc is invalid, error: %s\n", sx_status_str(sdk_rc));
                goto out;
            }
        }

        program_attr.program_cnt = NVXCC_EMT_ONLY_PROGRAM_CMD_NUM;
        for (i = 0; i < NVXCC_EMT_ONLY_PROGRAM_CMD_NUM; i++) {
            program_attr.program[i].opcode = nvxcc_emt_only_program_opcodes[i];
            program_attr.program[i].operand1.type = nvxcc_emt_only_program_operands_type[i][0];
            program_attr.program[i].operand1.data =
                (sx_flex_pm_app_cmd_op_data_t)nvxcc_emt_only_program_operands[i][0];
            program_attr.program[i].operand2.type = nvxcc_emt_only_program_operands_type[i][1];
            program_attr.program[i].operand2.data =
                (sx_flex_pm_app_cmd_op_data_t)nvxcc_emt_only_program_operands[i][1];
            program_attr.program[i].operand3.type = nvxcc_emt_only_program_operands_type[i][2];
            program_attr.program[i].operand3.data =
                (sx_flex_pm_app_cmd_op_data_t)nvxcc_emt_only_program_operands[i][2];
            if (i == 3) {
                program_attr.program[i].operand3.data =
                    (sx_flex_pm_app_cmd_op_data_t)(uint32_t)app_tc;
            }
        }
        break;

    case PCC_APP_HPCC:
        program_attr.program_cnt = HPCC_EMT_ONLY_PROGRAM_CMD_NUM;
        for (prog_idx = 0; prog_idx < HPCC_EMT_ONLY_PROGRAM_CMD_NUM; prog_idx++) {
            program_attr.program[prog_idx].opcode = hpcc_emt_only_program_opcodes[prog_idx];
            program_attr.program[prog_idx].operand1.type = hpcc_emt_only_program_operands_type[prog_idx][0];
            program_attr.program[prog_idx].operand1.data =
                (sx_flex_pm_app_cmd_op_data_t)hpcc_emt_only_program_operands[prog_idx][0];
            program_attr.program[prog_idx].operand2.type = hpcc_emt_only_program_operands_type[prog_idx][1];
            program_attr.program[prog_idx].operand2.data =
                (sx_flex_pm_app_cmd_op_data_t)hpcc_emt_only_program_operands[prog_idx][1];
            program_attr.program[prog_idx].operand3.type = hpcc_emt_only_program_operands_type[prog_idx][2];
            program_attr.program[prog_idx].operand3.data =
                (sx_flex_pm_app_cmd_op_data_t)hpcc_emt_only_program_operands[prog_idx][2];
        }
        break;
    }
    sdk_rc = sx_api_flex_pm_app_program_set(pcc_sx_api_handle_g, SX_ACCESS_CMD_ADD, key,
                                            &program_attr);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_pm_app_program_set failed, error: %s\n", sx_status_str(sdk_rc));
        goto out;
    }

out:
    if (resource_list) {
        cl_free(resource_list);
    }

    return rc;
}

static sx_acl_key_t __from_reg_id_to_acl_key(pcc_gp_register_e reg_id)
{
    switch (reg_id) {
    case PCC_GP_REGISTER_0_E:
        return FLEX_ACL_KEY_GP_REGISTER_0;

    case PCC_GP_REGISTER_1_E:
        return FLEX_ACL_KEY_GP_REGISTER_1;

    case PCC_GP_REGISTER_2_E:
        return FLEX_ACL_KEY_GP_REGISTER_2;

    case PCC_GP_REGISTER_3_E:
        return FLEX_ACL_KEY_GP_REGISTER_3;

    case PCC_GP_REGISTER_4_E:
        return FLEX_ACL_KEY_GP_REGISTER_4;

    case PCC_GP_REGISTER_5_E:
        return FLEX_ACL_KEY_GP_REGISTER_5;

    case PCC_GP_REGISTER_6_E:
        return FLEX_ACL_KEY_GP_REGISTER_6;

    case PCC_GP_REGISTER_7_E:
        return FLEX_ACL_KEY_GP_REGISTER_7;

    case PCC_GP_REGISTER_8_E:
        return FLEX_ACL_KEY_GP_REGISTER_8;

    case PCC_GP_REGISTER_9_E:
        return FLEX_ACL_KEY_GP_REGISTER_9;

    case PCC_GP_REGISTER_10_E:
        return FLEX_ACL_KEY_GP_REGISTER_10;

    case PCC_GP_REGISTER_11_E:
        return FLEX_ACL_KEY_GP_REGISTER_11;

    default:
        return FLEX_ACL_KEY_LAST;
    }
}

static pcc_status_t __port_speed_value_get(pcc_app_type_e   app_type,
                                           pcc_port_speed_e port_speed,
                                           uint16_t        *port_speed_value)
{
    if (app_type == PCC_APP_NVXCC) {
        switch (port_speed) {
        case PCC_PORT_SPEED_25GB:
            *port_speed_value = 0;
            break;

        case PCC_PORT_SPEED_40GB:
            *port_speed_value = 1;
            break;

        case PCC_PORT_SPEED_50GB:
            *port_speed_value = 2;
            break;

        case PCC_PORT_SPEED_100GB:
            *port_speed_value = 3;
            break;

        case PCC_PORT_SPEED_200GB:
            *port_speed_value = 4;
            break;

        case PCC_PORT_SPEED_400GB:
            *port_speed_value = 5;
            break;

        case PCC_PORT_SPEED_800GB:
            *port_speed_value = 6;
            break;

        default:
            SX_LOG_ERR("Port speed not supported, speed = (%d)", port_speed);
            return PCC_STATUS_ERROR;
        }
    } else if (app_type == PCC_APP_HPCC) {
        switch (port_speed) {
        case PCC_PORT_SPEED_40GB:
            *port_speed_value = 0;
            break;

        case PCC_PORT_SPEED_100GB:
            *port_speed_value = 1;
            break;

        default:
            SX_LOG_ERR("Port speed not supported, speed = (%d)", port_speed);
            return PCC_STATUS_ERROR;
        }
    }

    return PCC_STATUS_SUCCESS;
}
static pcc_status_t __pcc_nvxcc_acls_configure(pcc_app_nvxcc_params_vip_t *vip_params_p,
                                               probe_words_arr             probe_regs_arr,
                                               acl_regions_params_arr      acl_regions_params)
{
    uint16_t                max_num_of_rules = 400, cnfg_rules_num = 3;
    uint8_t                 max_num_of_actions = 5;
    uint8_t                 list_idx = 0;
    int                     i = 0;
    sx_acl_region_group_t   acl_region_group;
    sx_acl_direction_t      acl_direction = SX_ACL_DIRECTION_EGRESS;
    sx_acl_id_t             acl_id_list[1];
    sx_flex_acl_flex_rule_t rules[cnfg_rules_num];
    sx_status_t             sx_status = SX_STATUS_SUCCESS, rollback_sx_status = SX_STATUS_SUCCESS;
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    sx_acl_rule_offset_t    offset[3] = {0, 1, 2};
    uint8_t                 vip_tc = PCC_DEFAULT_VIP_TC;
    sx_acl_key_t            key_id_region1[] = {
        FLEX_ACL_KEY_L4_OK,
        FLEX_ACL_KEY_L4_TYPE_EXTENDED,
        FLEX_ACL_KEY_INNER_L4_OK,
        FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT,
        FLEX_ACL_KEY_TUNNEL_TYPE,
    };
    sx_acl_key_t            key_id_region2[] = {
        __from_reg_id_to_acl_key(probe_regs_arr[2]),
        __from_reg_id_to_acl_key(probe_regs_arr[3]),
        __from_reg_id_to_acl_key(probe_regs_arr[0]),
        __from_reg_id_to_acl_key(probe_regs_arr[1]),
        FLEX_ACL_KEY_GP_REGISTER_0,
    };
    sx_acl_key_t            key_id_region3[] = {
        __from_reg_id_to_acl_key(probe_regs_arr[0]),
        FLEX_ACL_KEY_DST_PORT,
    };

    /* Create key handle - For 3 ACLs*/
    acl_regions_params[0].key_id_size = sizeof(key_id_region1) / sizeof(key_id_region1[0]);
    memcpy(acl_regions_params[0].key_id, key_id_region1, sizeof(key_id_region1));

    acl_regions_params[1].key_id_size = sizeof(key_id_region2) / sizeof(key_id_region2[0]);
    memcpy(acl_regions_params[1].key_id, key_id_region2, sizeof(key_id_region2));

    acl_regions_params[2].key_id_size = sizeof(key_id_region3) / sizeof(key_id_region3[0]);
    memcpy(acl_regions_params[2].key_id, key_id_region3, sizeof(key_id_region3));

    sx_status = sx_api_acl_flex_key_set(pcc_sx_api_handle_g,
                                        SX_ACCESS_CMD_CREATE,
                                        acl_regions_params[0].key_id,
                                        acl_regions_params[0].key_id_size,
                                        &(acl_regions_params[0].key_handle));
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_key_set failed for Region 1: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_acl_flex_key_set(pcc_sx_api_handle_g,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_region2,
                                        sizeof(key_id_region2) / sizeof(key_id_region2[0]),
                                        &(acl_regions_params[1].key_handle));
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_key_set failed for Region 2: [%s] \n", sx_status_str(sx_status));
        goto out;
    }


    sx_status = sx_api_acl_flex_key_set(pcc_sx_api_handle_g,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_region3,
                                        sizeof(key_id_region3) / sizeof(key_id_region3[0]),
                                        &(acl_regions_params[2].key_handle));
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_key_set failed for Region 3: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create regions */
    for (i = 0; i < PCC_ACLS_MAX_NUM; i++) {
        acl_regions_params[i].region_size = max_num_of_rules;
        sx_status = sx_api_acl_region_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_CREATE,
                                          acl_regions_params[i].key_handle,
                                          SX_ACL_ACTION_TYPE_EXTENDED,
                                          max_num_of_rules,
                                          &(acl_regions_params[i].region_id));
        if (sx_status != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_region_set failed: for region (%d) [%s] \n", i + 1,
                       sx_status_str(sx_status));
            goto out;
        }

        /* Create ACL */
        acl_region_group.regions.acl_packet_agnostic.region = acl_regions_params[i].region_id;
        sx_status = sx_api_acl_set(pcc_sx_api_handle_g,
                                   SX_ACCESS_CMD_CREATE,
                                   SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                   acl_direction,
                                   &acl_region_group,
                                   &(acl_regions_params[i].acl_id));
        if (sx_status != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        /* Create ACL group */

        sx_status = sx_api_acl_group_set(pcc_sx_api_handle_g,
                                         SX_ACCESS_CMD_CREATE,
                                         acl_direction,
                                         acl_id_list,
                                         0,
                                         &(acl_regions_params[i].acl_group_id));
        if (sx_status != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }
        acl_id_list[0] = acl_regions_params[i].acl_id;
        sx_status = sx_api_acl_group_set(pcc_sx_api_handle_g,
                                         SX_ACCESS_CMD_SET,
                                         acl_direction,
                                         acl_id_list,
                                         1,
                                         &(acl_regions_params[i].acl_group_id));
        if (sx_status != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }
    }

    /* Initiate and allocate rules */
    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[0].key_handle, 1, &rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_init failed for rule 0 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }
    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[0].key_handle, 1, &rules[1]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_init failed for rule 1 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto rules0_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[0].key_handle, 1, &rules[2]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_init failed for rule 2 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto rules1_rollback;
    }
    /* Region 1 rules */
    rules[0].valid = 1;
    rules[0].key_desc_count = 2;
    rules[0].key_desc_list_p[0].key_id = FLEX_ACL_KEY_L4_OK;
    rules[0].key_desc_list_p[0].key.l4_ok = TRUE;
    rules[0].key_desc_list_p[0].mask.l4_ok = 1;
    rules[0].key_desc_list_p[1].key_id = FLEX_ACL_KEY_L4_TYPE_EXTENDED;
    rules[0].key_desc_list_p[1].key.l4_type_extended = SX_ACL_L4_TYPE_EXTENDED_BTHOUDP;
    rules[0].key_desc_list_p[1].mask.l4_type_extended = 1;
    rules[0].action_count = 1;

    rules[0].action_list_p[0].type = SX_FLEX_ACL_ACTION_GOTO;
    rules[0].action_list_p[0].fields.action_goto.acl_group_id = acl_regions_params[1].acl_group_id;
    rules[0].action_list_p[0].fields.action_goto.goto_action_cmd = SX_ACL_ACTION_GOTO_JUMP;

    /* Due to HW limitation we need to check the inner BTH over UDP using the L4 port and not the L4 type key */
    rules[1].valid = 1;
    rules[1].key_desc_count = 3;
    rules[1].key_desc_list_p[0].key_id = FLEX_ACL_KEY_INNER_L4_OK;
    rules[1].key_desc_list_p[0].key.inner_l4_ok = TRUE;
    rules[1].key_desc_list_p[0].mask.inner_l4_ok = 1;
    rules[1].key_desc_list_p[1].key_id = FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT;
    rules[1].key_desc_list_p[1].key.inner_l4_destination_port = BTH_OVER_UDP_PORT;
    rules[1].key_desc_list_p[1].mask.inner_l4_destination_port = 0xffff;
    rules[1].key_desc_list_p[2].key_id = FLEX_ACL_KEY_TUNNEL_TYPE;
    rules[1].key_desc_list_p[2].key.tunnel_type = SX_TUNNEL_TYPE_NVE_VXLAN;
    rules[1].key_desc_list_p[2].mask.tunnel_type = 1;
    rules[1].action_count = 1;

    rules[1].action_list_p[0].type = SX_FLEX_ACL_ACTION_GOTO;
    rules[1].action_list_p[0].fields.action_goto.acl_group_id = acl_regions_params[1].acl_group_id;
    rules[1].action_list_p[0].fields.action_goto.goto_action_cmd = SX_ACL_ACTION_GOTO_JUMP;


    rules[2].valid = 1;
    rules[2].key_desc_count = 0;
    rules[2].action_count = 1;

    rules[2].action_list_p[0].type = SX_FLEX_ACL_ACTION_FORWARD;
    rules[2].action_list_p[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD;

    sx_status = sx_api_acl_flex_rules_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_SET,
                                          acl_regions_params[0].region_id,
                                          offset,
                                          rules,
                                          3);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_rules_set failed for region 1 [%s]\n", sx_status_str(sx_status));
        goto rules1_rollback;
    }
    sx_status = sx_lib_flex_acl_rule_deinit(&rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed for rule 0 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto rules1_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules[1]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed for rule 1 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto rules0_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules[2]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed for rule 2 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }
    /* Region 2 rules */
    if (vip_params_p->set_tc) {
        vip_tc = vip_params_p->vip_tc;
    }
    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[1].key_handle, max_num_of_actions, &rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_init failed for rule 0 region 2: [%s] \n",
                   sx_status_str(sx_status));
        goto rules0_rollback;
    }
    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[1].key_handle, 1, &rules[1]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_init failed for rule 1 region 2: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }
    rules[0].valid = 1;
    rules[0].key_desc_count = 5;
    rules[0].key_desc_list_p[0].key_id = __from_reg_id_to_acl_key(probe_regs_arr[0]);
    rules[0].key_desc_list_p[0].key.gp_register = 0xFFFF;
    rules[0].key_desc_list_p[0].mask.gp_register = 0xFFFF;
    rules[0].key_desc_list_p[1].key_id = __from_reg_id_to_acl_key(probe_regs_arr[1]);
    rules[0].key_desc_list_p[1].key.gp_register = 0xFFFF;
    rules[0].key_desc_list_p[1].mask.gp_register = 0xFFFF;
    rules[0].key_desc_list_p[2].key_id = __from_reg_id_to_acl_key(probe_regs_arr[2]);
    rules[0].key_desc_list_p[2].key.gp_register = 0xCAFE;
    rules[0].key_desc_list_p[2].mask.gp_register = 0xFFFF;
    rules[0].key_desc_list_p[3].key_id = __from_reg_id_to_acl_key(probe_regs_arr[3]);
    rules[0].key_desc_list_p[3].key.gp_register = 0xCAFE;
    rules[0].key_desc_list_p[3].mask.gp_register = 0xFFFF;
    rules[0].key_desc_list_p[4].key_id = FLEX_ACL_KEY_GP_REGISTER_0;
    rules[0].key_desc_list_p[4].key.gp_register = 0;
    rules[0].key_desc_list_p[4].mask.gp_register = 0xf800;
    rules[0].action_count = max_num_of_actions;

    list_idx = 0;
    rules[0].action_list_p[list_idx].type = SX_FLEX_ACL_ACTION_SET_TC;
    rules[0].action_list_p[list_idx++].fields.action_set_tc.tc_val = vip_tc;
    rules[0].action_list_p[list_idx].type = SX_FLEX_ACL_ACTION_ALU_REG;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.command = SX_ACL_ACTION_ALU_REG_COMMAND_SET;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.dst_register = (sx_gp_register_e)probe_regs_arr[0];
    rules[0].action_list_p[list_idx].fields.action_alu_reg.dst_offset = 0;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.size = 8;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.src_register = SX_GP_REGISTER_0_E;
    rules[0].action_list_p[list_idx++].fields.action_alu_reg.src_offset = 8;
    rules[0].action_list_p[list_idx].type = SX_FLEX_ACL_ACTION_ALU_REG;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.command = SX_ACL_ACTION_ALU_REG_COMMAND_SUB;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.dst_register = (sx_gp_register_e)probe_regs_arr[0];
    rules[0].action_list_p[list_idx].fields.action_alu_reg.dst_offset = 0;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.src_register = SX_GP_REGISTER_0_E;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.size = 4;
    rules[0].action_list_p[list_idx++].fields.action_alu_reg.src_offset = 12;
    rules[0].action_list_p[list_idx].type = SX_FLEX_ACL_ACTION_ALU_IMM;
    rules[0].action_list_p[list_idx].fields.action_alu_imm.command = SX_ACL_ACTION_ALU_IMM_COMMAND_ADD;
    rules[0].action_list_p[list_idx].fields.action_alu_imm.imm_data = 1;
    rules[0].action_list_p[list_idx].fields.action_alu_imm.size = 4;
    rules[0].action_list_p[list_idx].fields.action_alu_imm.dst_register = SX_GP_REGISTER_0_E;
    rules[0].action_list_p[list_idx++].fields.action_alu_imm.dst_offset = 0;

    rules[0].action_list_p[list_idx].type = SX_FLEX_ACL_ACTION_GOTO;
    rules[0].action_list_p[list_idx].fields.action_goto.acl_group_id = acl_regions_params[2].acl_group_id;
    rules[0].action_list_p[list_idx++].fields.action_goto.goto_action_cmd = SX_ACL_ACTION_GOTO_JUMP;


    rules[1].valid = 1;
    rules[1].key_desc_count = 0;
    rules[1].action_count = 1;

    rules[1].action_list_p[0].type = SX_FLEX_ACL_ACTION_FORWARD;
    rules[1].action_list_p[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD;

    sx_status = sx_api_acl_flex_rules_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_SET,
                                          acl_regions_params[1].region_id,
                                          offset,
                                          rules,
                                          2);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_rules_set failed for region 2[%s]\n", sx_status_str(sx_status));
        goto rules0_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed for rule 0 region 2: [%s] \n",
                   sx_status_str(sx_status));
        goto rules0_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules[1]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed for rule 1 region 2: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[2].key_handle, 1, &rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SDK API sx_lib_flex_acl_rule_init failed: [%s] \n", sx_status_str(sx_status));
        goto rules0_rollback;
    }

    rules[0].valid = 1;
    rules[0].key_desc_count = 1;
    rules[0].action_count = 1;

    /* If max hop counter - hop counter = 0, discard packet */
    rules[0].key_desc_list_p[0].key_id = __from_reg_id_to_acl_key(probe_regs_arr[0]);
    rules[0].key_desc_list_p[0].key.gp_register = 0;
    rules[0].key_desc_list_p[0].mask.gp_register = 0xffff;
    rules[0].action_list_p[0].type = SX_FLEX_ACL_ACTION_FORWARD;
    rules[0].action_list_p[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD;

    sx_status = sx_api_acl_flex_rules_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_SET,
                                          acl_regions_params[2].region_id,
                                          offset,
                                          rules,
                                          1);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_rules_set failed for region 3[%s]\n", sx_status_str(sx_status));
        goto rules0_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed rule 0 for region 3: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }

    goto out;

rules1_rollback:
    rollback_sx_status = sx_lib_flex_acl_rule_deinit(&rules[1]);
    if (rollback_sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed rule 1: [%s] \n",
                   sx_status_str(rollback_sx_status));
        goto out;
    }

rules0_rollback:
    rollback_sx_status = sx_lib_flex_acl_rule_deinit(&rules[0]);
    if (rollback_sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed rule 0: [%s] \n",
                   sx_status_str(rollback_sx_status));
        goto out;
    }

out:
    return rc;
}

static pcc_status_t __pcc_hpcc_acls_configure(probe_words_arr        probe_regs_arr,
                                              acl_regions_params_arr acl_regions_params)
{
    uint16_t                max_num_of_rules = 400, cnfg_rules_num = 3;
    uint8_t                 max_num_of_actions = 5;
    uint8_t                 list_idx = 0;
    int                     i = 0;
    sx_acl_region_group_t   acl_region_group;
    sx_acl_direction_t      acl_direction = SX_ACL_DIRECTION_EGRESS;
    sx_acl_id_t             acl_id_list[1];
    sx_flex_acl_flex_rule_t rules[cnfg_rules_num];
    sx_status_t             sx_status = SX_STATUS_SUCCESS, rollback_sx_status = SX_STATUS_SUCCESS;
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    sx_acl_rule_offset_t    offset[3] = {0, 1, 2};
    sx_acl_key_t            key_id_region1[] = {
        FLEX_ACL_KEY_L4_OK,
        FLEX_ACL_KEY_L4_TYPE_EXTENDED,
        FLEX_ACL_KEY_INNER_L4_OK,
        FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT,
        FLEX_ACL_KEY_TUNNEL_TYPE,
    };
    sx_acl_key_t            key_id_region2[] = {
        __from_reg_id_to_acl_key(probe_regs_arr[0]),
        __from_reg_id_to_acl_key(probe_regs_arr[1]),
        __from_reg_id_to_acl_key(probe_regs_arr[2]),
        __from_reg_id_to_acl_key(probe_regs_arr[3]),
        __from_reg_id_to_acl_key(probe_regs_arr[4]),
    };
    sx_acl_key_t            key_id_region3[] = {
        __from_reg_id_to_acl_key(probe_regs_arr[0]),
        FLEX_ACL_KEY_DST_PORT,
    };

    /* Create key handle - For 3 ACLs*/
    acl_regions_params[0].key_id_size = sizeof(key_id_region1) / sizeof(key_id_region1[0]);
    memcpy(acl_regions_params[0].key_id, key_id_region1, sizeof(key_id_region1));

    acl_regions_params[1].key_id_size = sizeof(key_id_region2) / sizeof(key_id_region2[0]);
    memcpy(acl_regions_params[1].key_id, key_id_region2, sizeof(key_id_region2));

    acl_regions_params[2].key_id_size = sizeof(key_id_region3) / sizeof(key_id_region3[0]);
    memcpy(acl_regions_params[2].key_id, key_id_region3, sizeof(key_id_region3));

    sx_status = sx_api_acl_flex_key_set(pcc_sx_api_handle_g,
                                        SX_ACCESS_CMD_CREATE,
                                        acl_regions_params[0].key_id,
                                        acl_regions_params[0].key_id_size,
                                        &(acl_regions_params[0].key_handle));
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_key_set failed for Region 1: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_acl_flex_key_set(pcc_sx_api_handle_g,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_region2,
                                        sizeof(key_id_region2) / sizeof(key_id_region2[0]),
                                        &(acl_regions_params[1].key_handle));
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_key_set failed for Region 2: [%s] \n", sx_status_str(sx_status));
        goto out;
    }


    sx_status = sx_api_acl_flex_key_set(pcc_sx_api_handle_g,
                                        SX_ACCESS_CMD_CREATE,
                                        key_id_region3,
                                        sizeof(key_id_region3) / sizeof(key_id_region3[0]),
                                        &(acl_regions_params[2].key_handle));
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_key_set failed for Region 3: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    /* Create regions */
    for (i = 0; i < PCC_ACLS_MAX_NUM; i++) {
        acl_regions_params[i].region_size = max_num_of_rules;
        sx_status = sx_api_acl_region_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_CREATE,
                                          acl_regions_params[i].key_handle,
                                          SX_ACL_ACTION_TYPE_EXTENDED,
                                          max_num_of_rules,
                                          &(acl_regions_params[i].region_id));
        if (sx_status != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_region_set failed: for region (%d) [%s] \n", i + 1,
                       sx_status_str(sx_status));
            goto out;
        }

        /* Create ACL */
        acl_region_group.regions.acl_packet_agnostic.region = acl_regions_params[i].region_id;
        sx_status = sx_api_acl_set(pcc_sx_api_handle_g,
                                   SX_ACCESS_CMD_CREATE,
                                   SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                   acl_direction,
                                   &acl_region_group,
                                   &(acl_regions_params[i].acl_id));
        if (sx_status != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        /* Create ACL group */

        sx_status = sx_api_acl_group_set(pcc_sx_api_handle_g,
                                         SX_ACCESS_CMD_CREATE,
                                         acl_direction,
                                         acl_id_list,
                                         0,
                                         &(acl_regions_params[i].acl_group_id));
        if (sx_status != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }
        acl_id_list[0] = acl_regions_params[i].acl_id;
        sx_status = sx_api_acl_group_set(pcc_sx_api_handle_g,
                                         SX_ACCESS_CMD_SET,
                                         acl_direction,
                                         acl_id_list,
                                         1,
                                         &(acl_regions_params[i].acl_group_id));
        if (sx_status != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }
    }

    /* Initiate and allocate rules */
    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[0].key_handle, 1, &rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_init failed for rule 0 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }
    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[0].key_handle, 1, &rules[1]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_init failed for rule 1 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto rules0_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[0].key_handle, 1, &rules[2]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_init failed for rule 2 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto rules1_rollback;
    }
    /* Region 1 rules */
    rules[0].valid = 1;
    rules[0].key_desc_count = 2;
    rules[0].key_desc_list_p[0].key_id = FLEX_ACL_KEY_L4_OK;
    rules[0].key_desc_list_p[0].key.l4_ok = TRUE;
    rules[0].key_desc_list_p[0].mask.l4_ok = 1;
    rules[0].key_desc_list_p[1].key_id = FLEX_ACL_KEY_L4_TYPE_EXTENDED;
    rules[0].key_desc_list_p[1].key.l4_type_extended = SX_ACL_L4_TYPE_EXTENDED_BTHOUDP;
    rules[0].key_desc_list_p[1].mask.l4_type_extended = 1;
    rules[0].action_count = 1;

    rules[0].action_list_p[0].type = SX_FLEX_ACL_ACTION_GOTO;
    rules[0].action_list_p[0].fields.action_goto.acl_group_id = acl_regions_params[1].acl_group_id;
    rules[0].action_list_p[0].fields.action_goto.goto_action_cmd = SX_ACL_ACTION_GOTO_JUMP;


    rules[1].valid = 1;
    rules[1].key_desc_count = 3;
    rules[1].key_desc_list_p[0].key_id = FLEX_ACL_KEY_INNER_L4_OK;
    rules[1].key_desc_list_p[0].key.inner_l4_ok = TRUE;
    rules[1].key_desc_list_p[0].mask.inner_l4_ok = 1;
    rules[1].key_desc_list_p[1].key_id = FLEX_ACL_KEY_INNER_L4_DESTINATION_PORT;
    rules[1].key_desc_list_p[1].key.inner_l4_destination_port = BTH_OVER_UDP_PORT;
    rules[1].key_desc_list_p[1].mask.inner_l4_destination_port = 0xffff;
    rules[1].key_desc_list_p[2].key_id = FLEX_ACL_KEY_TUNNEL_TYPE;
    rules[1].key_desc_list_p[2].key.tunnel_type = SX_TUNNEL_TYPE_NVE_VXLAN;
    rules[1].key_desc_list_p[2].mask.tunnel_type = 1;
    rules[1].action_count = 1;

    rules[1].action_list_p[0].type = SX_FLEX_ACL_ACTION_GOTO;
    rules[1].action_list_p[0].fields.action_goto.acl_group_id = acl_regions_params[1].acl_group_id;
    rules[1].action_list_p[0].fields.action_goto.goto_action_cmd = SX_ACL_ACTION_GOTO_JUMP;


    rules[2].valid = 1;
    rules[2].key_desc_count = 0;
    rules[2].action_count = 1;

    rules[2].action_list_p[0].type = SX_FLEX_ACL_ACTION_FORWARD;
    rules[2].action_list_p[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD;

    sx_status = sx_api_acl_flex_rules_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_SET,
                                          acl_regions_params[0].region_id,
                                          offset,
                                          rules,
                                          3);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_rules_set failed for region 1 [%s]\n", sx_status_str(sx_status));
        goto rules1_rollback;
    }
    sx_status = sx_lib_flex_acl_rule_deinit(&rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed for rule 0 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto rules1_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules[1]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed for rule 1 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto rules0_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules[2]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed for rule 2 region 1: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }
    /* Region 2 rules */

    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[1].key_handle, max_num_of_actions, &rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_init failed for rule 0 region 2: [%s] \n",
                   sx_status_str(sx_status));
        goto rules0_rollback;
    }
    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[1].key_handle, 1, &rules[1]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_init failed for rule 1 region 2: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }
    rules[0].valid = 1;
    rules[0].key_desc_count = 5;
    rules[0].key_desc_list_p[0].key_id = __from_reg_id_to_acl_key(probe_regs_arr[0]);
    rules[0].key_desc_list_p[0].key.gp_register = 0xAAAA; /* Probe marker */
    rules[0].key_desc_list_p[0].mask.gp_register = 0xFFFF;
    rules[0].key_desc_list_p[1].key_id = __from_reg_id_to_acl_key(probe_regs_arr[1]);
    rules[0].key_desc_list_p[1].key.gp_register = 0xAAAA;
    rules[0].key_desc_list_p[1].mask.gp_register = 0xFFFF;
    rules[0].key_desc_list_p[2].key_id = __from_reg_id_to_acl_key(probe_regs_arr[2]);
    rules[0].key_desc_list_p[2].key.gp_register = 0xBBBB;
    rules[0].key_desc_list_p[2].mask.gp_register = 0xFFFF;
    rules[0].key_desc_list_p[3].key_id = __from_reg_id_to_acl_key(probe_regs_arr[3]);
    rules[0].key_desc_list_p[3].key.gp_register = 0xBBBB;
    rules[0].key_desc_list_p[3].mask.gp_register = 0xFFFF;
    rules[0].key_desc_list_p[4].key_id = __from_reg_id_to_acl_key(probe_regs_arr[4]);
    rules[0].key_desc_list_p[4].key.gp_register = 0x0101; /* version + message type */
    rules[0].key_desc_list_p[4].mask.gp_register = 0xFFFF;


    list_idx = 0;
    rules[0].action_list_p[list_idx].type = SX_FLEX_ACL_ACTION_ALU_REG;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.command = SX_ACL_ACTION_ALU_REG_COMMAND_SET;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.dst_register = (sx_gp_register_e)probe_regs_arr[0];
    rules[0].action_list_p[list_idx].fields.action_alu_reg.dst_offset = 0;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.size = 8;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.src_register = SX_GP_REGISTER_0_E;
    rules[0].action_list_p[list_idx++].fields.action_alu_reg.src_offset = 8;


    rules[0].action_list_p[list_idx].type = SX_FLEX_ACL_ACTION_ALU_REG;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.command = SX_ACL_ACTION_ALU_REG_COMMAND_SUB; /* probe_regs_arr[0] = hop limit - hop count */
    rules[0].action_list_p[list_idx].fields.action_alu_reg.dst_register = (sx_gp_register_e)probe_regs_arr[0];
    rules[0].action_list_p[list_idx].fields.action_alu_reg.dst_offset = 0;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.src_register = SX_GP_REGISTER_0_E;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.size = 4;
    rules[0].action_list_p[list_idx++].fields.action_alu_reg.src_offset = 12;

    rules[0].action_list_p[list_idx].type = SX_FLEX_ACL_ACTION_ALU_IMM;
    rules[0].action_list_p[list_idx].fields.action_alu_imm.command = SX_ACL_ACTION_ALU_IMM_COMMAND_ADD; /* reg0 = hop count + 1 */
    rules[0].action_list_p[list_idx].fields.action_alu_imm.imm_data = 1;
    rules[0].action_list_p[list_idx].fields.action_alu_imm.size = 4;
    rules[0].action_list_p[list_idx].fields.action_alu_imm.dst_register = SX_GP_REGISTER_0_E;
    rules[0].action_list_p[list_idx++].fields.action_alu_imm.dst_offset = 0;

    rules[0].action_list_p[list_idx].type = SX_FLEX_ACL_ACTION_ALU_REG;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.command = SX_ACL_ACTION_ALU_REG_COMMAND_SET; /* probe_regs_arr[1] = hop count * 32 */
    rules[0].action_list_p[list_idx].fields.action_alu_reg.size = 11;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.dst_register = (sx_gp_register_e)probe_regs_arr[1];
    rules[0].action_list_p[list_idx].fields.action_alu_reg.dst_offset = 5;
    rules[0].action_list_p[list_idx].fields.action_alu_reg.src_register = SX_GP_REGISTER_0_E;
    rules[0].action_list_p[list_idx++].fields.action_alu_reg.src_offset = 0;

    rules[0].action_list_p[list_idx].type = SX_FLEX_ACL_ACTION_GOTO;
    rules[0].action_list_p[list_idx].fields.action_goto.acl_group_id = acl_regions_params[2].acl_group_id;
    rules[0].action_list_p[list_idx].fields.action_goto.goto_action_cmd = SX_ACL_ACTION_GOTO_JUMP;
    rules[0].action_count = list_idx + 1;

    rules[1].valid = 1;
    rules[1].key_desc_count = 0;
    rules[1].action_count = 1;

    rules[1].action_list_p[0].type = SX_FLEX_ACL_ACTION_FORWARD;
    rules[1].action_list_p[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD;

    sx_status = sx_api_acl_flex_rules_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_SET,
                                          acl_regions_params[1].region_id,
                                          offset,
                                          rules,
                                          2);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_rules_set failed for region 2[%s]\n", sx_status_str(sx_status));
        goto rules0_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed for rule 0 region 2: [%s] \n",
                   sx_status_str(sx_status));
        goto rules0_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules[1]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed for rule 1 region 2: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_lib_flex_acl_rule_init(acl_regions_params[2].key_handle, 1, &rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SDK API sx_lib_flex_acl_rule_init failed: [%s] \n", sx_status_str(sx_status));
        goto rules0_rollback;
    }

    rules[0].valid = 1;
    rules[0].key_desc_count = 1;
    rules[0].action_count = 1;

    /* If max hop counter - hop counter = 0, discard packet */
    rules[0].key_desc_list_p[0].key_id = __from_reg_id_to_acl_key(probe_regs_arr[0]);
    rules[0].key_desc_list_p[0].key.gp_register = 0;
    rules[0].key_desc_list_p[0].mask.gp_register = 0xffff;
    rules[0].action_list_p[0].type = SX_FLEX_ACL_ACTION_FORWARD;
    rules[0].action_list_p[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD;


    sx_status = sx_api_acl_flex_rules_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_SET,
                                          acl_regions_params[2].region_id,
                                          offset,
                                          rules,
                                          1);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_rules_set failed for region 3[%s]\n", sx_status_str(sx_status));
        goto rules0_rollback;
    }

    sx_status = sx_lib_flex_acl_rule_deinit(&rules[0]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed rule 0 for region 3: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }
    sx_status = sx_lib_flex_acl_rule_deinit(&rules[1]);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed rule 1 for region 3: [%s] \n",
                   sx_status_str(sx_status));
        goto out;
    }

    goto out;

rules1_rollback:
    rollback_sx_status = sx_lib_flex_acl_rule_deinit(&rules[1]);
    if (rollback_sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed rule 1: [%s] \n",
                   sx_status_str(rollback_sx_status));
        goto out;
    }

rules0_rollback:
    rollback_sx_status = sx_lib_flex_acl_rule_deinit(&rules[0]);
    if (rollback_sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_lib_flex_acl_rule_deinit failed rule 0: [%s] \n",
                   sx_status_str(rollback_sx_status));
        goto out;
    }

out:
    return rc;
}
static pcc_status_t __pcc_extraction_points_set(probe_words_arr probe_words_regs_arr,
                                                uint8_t        *regs_offset_arr,
                                                uint8_t         reg_cnt,
                                                uint8_t         reg0_offest,
                                                uint8_t         reg1_offset)
{
    pcc_status_t          rc = PCC_STATUS_SUCCESS;
    sx_status_t           sdk_rc = SX_STATUS_SUCCESS;
    sx_register_key_t     reg_key;
    uint32_t              ext_point_cnt = 2;
    sx_extraction_point_t ext_point_list_p[ext_point_cnt];
    uint8_t               i = 0;
    uint32_t              reg_key_cnt = reg_cnt + 2;
    sx_register_key_t     reg_key_list[reg_key_cnt];

    /* Set Registers */
    for (i = 0; i < reg_cnt; i++) {
        reg_key_list[i].type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
        reg_key_list[i].key.gp_reg.reg_id = (sx_gp_register_e)probe_words_regs_arr[i];
    }
    reg_key_list[i].type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E; /* i = reg_cnt + 1 */
    reg_key_list[i++].key.gp_reg.reg_id = SX_GP_REGISTER_0_E;
    reg_key_list[i].type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E; /* i = reg_cnt + 2 */
    reg_key_list[i].key.gp_reg.reg_id = SX_GP_REGISTER_1_E;
    sdk_rc = sx_api_register_set(pcc_sx_api_handle_g,
                                 SX_ACCESS_CMD_CREATE,
                                 reg_key_list,
                                 &reg_key_cnt);

    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_register_set failed, error: %s\n", sx_status_str(sdk_rc));
        goto out;
    }

    /* Set Extraction Points */
    reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
    ext_point_list_p[0].type = SX_EXTRACTION_POINT_TYPE_UDP_PAYLOAD_E;
    ext_point_list_p[1].type = SX_EXTRACTION_POINT_TYPE_INNER_UDP_PAYLOAD_E;
    for (i = 0; i < reg_cnt; i++) {
        reg_key.key.gp_reg.reg_id = (sx_gp_register_e)probe_words_regs_arr[i];
        ext_point_list_p[0].offset = regs_offset_arr[i];
        ext_point_list_p[1].offset = regs_offset_arr[i];
        sdk_rc = sx_api_flex_parser_reg_ext_point_set(pcc_sx_api_handle_g,
                                                      SX_ACCESS_CMD_SET,
                                                      reg_key,
                                                      ext_point_list_p,
                                                      &ext_point_cnt);
        if (sdk_rc != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("sx_api_flex_parser_reg_ext_point_set failed for REG (%d), offset (%d), error: %s\n",
                       probe_words_regs_arr[i], regs_offset_arr[i],
                       sx_status_str(sdk_rc));
            goto out;
        }
    }

    reg_key.key.gp_reg.reg_id = SX_GP_REGISTER_0_E;
    ext_point_list_p[0].type = SX_EXTRACTION_POINT_TYPE_UDP_PAYLOAD_E;
    ext_point_list_p[1].type = SX_EXTRACTION_POINT_TYPE_INNER_UDP_PAYLOAD_E;
    ext_point_list_p[0].offset = reg0_offest;
    ext_point_list_p[1].offset = reg0_offest;
    sdk_rc = sx_api_flex_parser_reg_ext_point_set(pcc_sx_api_handle_g,
                                                  SX_ACCESS_CMD_SET,
                                                  reg_key,
                                                  ext_point_list_p,
                                                  &ext_point_cnt);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_parser_reg_ext_point_set failed for REG (%d), offset (%d), error: %s\n",
                   SX_GP_REGISTER_0_E, ext_point_list_p[0].offset, sx_status_str(sdk_rc));
        goto out;
    }

    reg_key.key.gp_reg.reg_id = SX_GP_REGISTER_1_E;
    ext_point_list_p[0].offset = reg1_offset;
    ext_point_list_p[1].offset = reg1_offset;
    sdk_rc = sx_api_flex_parser_reg_ext_point_set(pcc_sx_api_handle_g,
                                                  SX_ACCESS_CMD_SET,
                                                  reg_key,
                                                  ext_point_list_p,
                                                  &ext_point_cnt);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_parser_reg_ext_point_set failed for REG (%d), offset (%d), error: %s\n",
                   SX_GP_REGISTER_1_E, ext_point_list_p[0].offset, sx_status_str(sdk_rc));
        goto out;
    }

out:
    return rc;
}

static pcc_status_t __pcc_app_resources_reg_set_types(pcc_gp_registers_t* registers_data_p,
                                                      probe_words_arr     probe_words_regs_arr,
                                                      uint8_t             regs_num)
{
    pcc_status_t rc = PCC_STATUS_SUCCESS;
    uint8_t      i = 0, j = 0;

    if (registers_data_p == NULL) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("registers_data_p is NULL. error: %s\n", pcc_status_str(rc));
        goto out;
    }

    for (i = 0, j = 0; i < registers_data_p->reg_num && j < regs_num; i++) {
        if ((registers_data_p->registers[i] == PCC_GP_REGISTER_0_E) ||
            (registers_data_p->registers[i] == PCC_GP_REGISTER_1_E)) {
            continue;
        }
        probe_words_regs_arr[j] = registers_data_p->registers[i];
        j++;
    }

out:
    return rc;
}

static pcc_status_t __pcc_app_resources_emts_deconfigure(pcc_flex_modifier_emt_id_e *configured_emts_arr,
                                                         uint8_t                     configured_emts_num)
{
    pcc_status_t               rc = PCC_STATUS_SUCCESS;
    sx_status_t                sdk_rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_emt_cfg_t emt_cfg;
    sx_flex_modifier_emt_key_t key;
    uint8_t                    i = 0;

    memset(&emt_cfg, 0, sizeof(sx_flex_modifier_emt_cfg_t));
    memset(&key, 0, sizeof(sx_flex_modifier_emt_key_t));

    for (i = 0; i < configured_emts_num; i++) {
        key.emt_id = (sx_flex_modifier_emt_id_e)configured_emts_arr[i];
        sdk_rc = sx_api_flex_modifier_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_DESTROY,
                                          key,
                                          &emt_cfg);
        if (sdk_rc != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("sx_api_flex_modifier_set failed to destroy EMT (%d), error: %s\n", configured_emts_arr[i],
                       sx_status_str(sdk_rc));
            goto out;
        }
    }
out:
    return rc;
}

static pcc_status_t __pcc_port_acl_configuration_unset(pcc_port_log_id_t      port_id,
                                                       acl_regions_params_arr acl_regions_params_arr)
{
    pcc_status_t         rc = PCC_STATUS_SUCCESS;
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_acl_rule_offset_t offset = 0;

    sx_status = sx_api_acl_port_bind_set(pcc_sx_api_handle_g,
                                         SX_ACCESS_CMD_UNBIND,
                                         port_id,
                                         acl_regions_params_arr[0].acl_group_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SDK API sx_api_acl_port_bind_set failed: [%s] \n", sx_status_str(sx_status));
        goto out;
    }

    offset = SX_PORT_LCL_ID_GET(port_id);
    sx_status = sx_api_acl_flex_rules_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_DELETE,
                                          acl_regions_params_arr[2].region_id,
                                          &offset,
                                          NULL,
                                          1);
    if (sx_status != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC LIB: SDK API sx_api_acl_flex_rules_set failed with CMD = SX_ACCESS_CMD_DELETE [%s]\n",
                   sx_status_str(sx_status));
        goto out;
    }

out:
    return rc;
}

static pcc_status_t __pcc_acls_deconfigure(acl_regions_params_arr acl_regions_params_arr)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    pcc_status_t          rc = PCC_STATUS_SUCCESS;
    uint8_t               i = 0;
    sx_acl_id_t           acl_id_list[1];
    sx_acl_region_group_t acl_region_group;

    for (i = 0; i < PCC_ACLS_MAX_NUM; i++) {
        /* Delete ACL group */
        sx_status = sx_api_acl_group_set(pcc_sx_api_handle_g,
                                         SX_ACCESS_CMD_DESTROY,
                                         SX_ACL_DIRECTION_EGRESS,
                                         acl_id_list,
                                         0,
                                         &acl_regions_params_arr[i].acl_group_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SDK API sx_api_acl_group_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        /* Delete ACL */
        acl_region_group.regions.acl_packet_agnostic.region = acl_regions_params_arr[i].region_id;
        sx_status = sx_api_acl_set(pcc_sx_api_handle_g,
                                   SX_ACCESS_CMD_DESTROY,
                                   SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                   SX_ACL_DIRECTION_EGRESS,
                                   &acl_region_group,
                                   &acl_regions_params_arr[i].acl_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SDK API sx_api_acl_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        /* Delete region */
        sx_status = sx_api_acl_region_set(pcc_sx_api_handle_g,
                                          SX_ACCESS_CMD_DESTROY,
                                          acl_regions_params_arr[i].key_handle,
                                          SX_ACL_ACTION_TYPE_EXTENDED,
                                          acl_regions_params_arr[i].region_size,
                                          &acl_regions_params_arr[i].region_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SDK API sx_api_acl_region_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }

        /* Delete key handle */
        sx_status = sx_api_acl_flex_key_set(pcc_sx_api_handle_g,
                                            SX_ACCESS_CMD_DELETE,
                                            acl_regions_params_arr[i].key_id,
                                            acl_regions_params_arr[i].key_id_size,
                                            &acl_regions_params_arr[i].key_handle);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SDK API sx_api_acl_flex_key_set failed: [%s] \n", sx_status_str(sx_status));
            goto out;
        }
    }

out:
    return rc;
}

static pcc_status_t __pcc_flex_pm_deconfigure(pcc_app_id_t app_id)
{
    pcc_status_t                  rc = PCC_STATUS_SUCCESS;
    sx_status_t                   sdk_rc = SX_STATUS_SUCCESS;
    sx_flex_pm_app_key_t          key;
    sx_flex_pm_app_attr_t         app_attr;
    sx_flex_pm_app_program_attr_t program_attr;

    memset(&app_attr, 0, sizeof(sx_flex_pm_app_attr_t));
    memset(&program_attr, 0, sizeof(sx_flex_pm_app_program_attr_t));

    key.app_id = app_id;

    sdk_rc = sx_api_flex_pm_app_program_set(pcc_sx_api_handle_g, SX_ACCESS_CMD_DELETE, key,
                                            &program_attr);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_pm_app_program_set failed, error: %s\n", sx_status_str(sdk_rc));
        goto out;
    }

    sdk_rc = sx_api_flex_pm_app_program_context_set(pcc_sx_api_handle_g, SX_ACCESS_CMD_DELETE_ALL, NULL, NULL, 0);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_pm_app_program_context_set failed, error: %s\n", sx_status_str(sdk_rc));
        goto out;
    }

    sdk_rc = sx_api_flex_pm_app_set(pcc_sx_api_handle_g, SX_ACCESS_CMD_DESTROY, &key, &app_attr);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_pm_app_set failed, error: %s\n", sx_status_str(sdk_rc));
        goto out;
    }
out:
    return rc;
}

static pcc_status_t __pcc_extraction_points_unset(probe_words_arr probe_words_regs_arr, uint8_t regs_num)
{
    pcc_status_t      rc = PCC_STATUS_SUCCESS;
    sx_status_t       sdk_rc = SX_STATUS_SUCCESS;
    sx_register_key_t reg_key = {0};
    uint32_t          ext_point_cnt = 0;
    uint8_t           i = 0, j = 0;
    uint32_t          reg_key_cnt = regs_num + 2;
    sx_register_key_t reg_key_list[reg_key_cnt];

    reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
    reg_key.key.gp_reg.reg_id = SX_GP_REGISTER_0_E;
    sdk_rc = sx_api_flex_parser_reg_ext_point_set(pcc_sx_api_handle_g,
                                                  SX_ACCESS_CMD_UNSET,
                                                  reg_key,
                                                  NULL,
                                                  &ext_point_cnt);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_parser_reg_ext_point_set failed for REG (%d), error: %s\n",
                   SX_GP_REGISTER_0_E, sx_status_str(sdk_rc));
        goto out;
    }

    reg_key.key.gp_reg.reg_id = SX_GP_REGISTER_1_E;
    sdk_rc = sx_api_flex_parser_reg_ext_point_set(pcc_sx_api_handle_g,
                                                  SX_ACCESS_CMD_UNSET,
                                                  reg_key,
                                                  NULL,
                                                  &ext_point_cnt);
    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_flex_parser_reg_ext_point_set failed for REG (%d), error: %s\n",
                   SX_GP_REGISTER_1_E, sx_status_str(sdk_rc));
        goto out;
    }

    /* Un-Set Extraction Points */
    reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
    for (i = 0; i < regs_num; i++) {
        reg_key.key.gp_reg.reg_id = (sx_gp_register_e)probe_words_regs_arr[i];
        sdk_rc = sx_api_flex_parser_reg_ext_point_set(pcc_sx_api_handle_g,
                                                      SX_ACCESS_CMD_UNSET,
                                                      reg_key,
                                                      NULL,
                                                      &ext_point_cnt);
        if (sdk_rc != SX_STATUS_SUCCESS) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("sx_api_flex_parser_reg_ext_point_set failed for REG (%d), error: %s\n",
                       probe_words_regs_arr[i],
                       sx_status_str(sdk_rc));
            goto out;
        }
    }

    /* Un-Set Registers */
    reg_key_list[0].type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
    reg_key_list[0].key.gp_reg.reg_id = SX_GP_REGISTER_0_E;
    reg_key_list[1].type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
    reg_key_list[1].key.gp_reg.reg_id = SX_GP_REGISTER_1_E;
    for (i = 2, j = 0; i < reg_key_cnt; i++, j++) {
        reg_key_list[i].type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
        reg_key_list[i].key.gp_reg.reg_id = (sx_gp_register_e)probe_words_regs_arr[j];
    }
    sdk_rc = sx_api_register_set(pcc_sx_api_handle_g,
                                 SX_ACCESS_CMD_DESTROY,
                                 reg_key_list,
                                 &reg_key_cnt);

    if (sdk_rc != SX_STATUS_SUCCESS) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("sx_api_register_set failed, error: %s\n", sx_status_str(sdk_rc));
        goto out;
    }

out:
    return rc;
}
static pcc_status_t __pcc_nvxcc_app_set(const pcc_access_cmd_e       cmd,
                                        const pcc_app_init_params_t *app_init_params_p,
                                        pcc_app_id_t                *app_id_p)
{
    pcc_status_t               rc = PCC_STATUS_SUCCESS;
    pcc_app_init_params_t      app_init_params;
    uint8_t                    bind_emts_num = 0;
    sx_flex_modifier_emt_id_e  bind_emts_arr[PCC_FLEX_MODIFIER_EMT_LAST_E];
    uint8_t                    spare_emts_num = 0;
    sx_flex_modifier_emt_id_e  spare_emts_arr[PCC_FLEX_MODIFIER_EMT_LAST_E];
    sx_flex_modifier_emt_id_e  edit_emt = 0;
    probe_words_arr            probe_words_regs_arr = {0};
    acl_regions_params_arr     acl_regions_params_arr;
    pcc_app_state_e            app_state = PCC_APP_STATE_DISABLE;
    uint8_t                    configured_emts_num = 0;
    pcc_flex_modifier_emt_id_e configured_emts_arr[PCC_FLEX_MODIFIER_EMT_LAST_E];
    pcc_port_log_id_t         *port_id_list_p = NULL;
    uint32_t                   port_id_list_cnt = 0, i = 0;
    uint8_t                    reg0_offset = 8, reg1_offset = 20;

    memcpy(&app_init_params, app_init_params_p, sizeof(pcc_app_init_params_t));

    switch (cmd) {
    case PCC_ACCESS_CMD_ADD_E:

        rc = __pcc_app_resources_check_update_valid(PCC_APP_NVXCC,
                                                    &app_init_params.pcc_app_params.nvxcc_params.app_resources.emts_data,
                                                    &app_init_params.pcc_app_params.nvxcc_params.app_resources.gp_registers_data);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP resources check failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_app_resources_emt_set_types(&app_init_params.pcc_app_params.nvxcc_params.app_resources.emts_data,
                                               bind_emts_arr,
                                               &bind_emts_num,
                                               spare_emts_arr,
                                               &spare_emts_num,
                                               &edit_emt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP EMT resources types set failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_app_resources_reg_set_types(
            &app_init_params.pcc_app_params.nvxcc_params.app_resources.gp_registers_data,
            probe_words_regs_arr, NVXCC_PROBE_REGS_NUM);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP REG resources types set failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_extraction_points_set(probe_words_regs_arr,
                                         probe_regs_nvxcc_offsets,
                                         NVXCC_PROBE_REGS_NUM,
                                         reg0_offset,
                                         reg1_offset);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP extraction points set failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_flex_modifier_configure_edit(edit_emt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP flex modifier configuration for edit EMT (%d) failed, error: %s\n",
                       edit_emt,
                       pcc_status_str(rc));
            goto out;
        }
        rc = __pcc_flex_modifier_configure_push(PCC_APP_NVXCC,
                                                bind_emts_arr,
                                                bind_emts_num,
                                                spare_emts_arr,
                                                spare_emts_num,
                                                app_init_params.pcc_app_params.nvxcc_params.app_params.debug_enable,
                                                app_init_params.pcc_app_params.nvxcc_params.app_params.switchid);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP flex modifier configuration for push EMTs failed, error: %s\n",
                       pcc_status_str(rc));
            goto out;
        }
        rc = __pcc_flex_pm_configure(PCC_APP_NVXCC,
                                     app_id_p,
                                     spare_emts_arr,
                                     spare_emts_num,
                                     &app_init_params.pcc_app_params.nvxcc_params.app_tc);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP flex PM configuration failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_nvxcc_acls_configure(&app_init_params.pcc_app_params.nvxcc_params.vip_params,
                                        probe_words_regs_arr,
                                        acl_regions_params_arr);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP ACLs configuration failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_nvxcc_app_create(*app_id_p,
                                     &app_init_params.pcc_app_params.nvxcc_params,
                                     acl_regions_params_arr,
                                     &app_init_params.pcc_app_params.nvxcc_params.app_resources.gp_registers_data,
                                     bind_emts_arr,
                                     bind_emts_num,
                                     spare_emts_arr,
                                     spare_emts_num,
                                     edit_emt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP DB create, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        break;

    case PCC_ACCESS_CMD_DELETE_E:
        rc = pcc_db_app_state_get(*app_id_p, &app_state);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("APP (%d) state get from DB failed, error: %s\n", *app_id_p, pcc_status_str(rc));
            goto out;
        }
        if (PCC_APP_STATE_ENABLE == app_state) {
            rc = pcc_api_app_state_set(*app_id_p, PCC_APP_STATE_DISABLE);
            if (rc != PCC_STATUS_SUCCESS) {
                SX_LOG_ERR("APP (%d) state set failed, error: %s\n", *app_id_p, pcc_status_str(rc));
                goto out;
            }
        }

        rc = __pcc_flex_pm_deconfigure(*app_id_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to de-configure Flex PM for APP (%d), error: %s\n", *app_id_p, pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_configured_emts_get(*app_id_p,
                                            configured_emts_arr,
                                            &configured_emts_num);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get configured EMTs on APP (%d) from DB, error: %s\n", *app_id_p,
                       pcc_status_str(rc));
            goto out;
        }


        rc = pcc_db_app_acl_params_get(*app_id_p, acl_regions_params_arr);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get ACL parameters for APP (%d) from DB, error: %s\n", *app_id_p,
                       pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_ports_count_get(*app_id_p, &port_id_list_cnt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in pcc_db_app_ports_count_get, error %s \n", pcc_status_str(rc));
            goto out;
        }

        port_id_list_p = (pcc_port_log_id_t *)cl_malloc(sizeof(pcc_port_log_id_t) * (port_id_list_cnt));
        if (port_id_list_p == NULL) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("Memory allocation for ports list in PCC LIB failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_ports_get_first(*app_id_p, port_id_list_p, &port_id_list_cnt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in pcc_db_app_ports_get_first, error %s \n", pcc_status_str(rc));
            goto out;
        }

        for (i = 0; i < port_id_list_cnt; i++) {
            rc = __pcc_app_port_set(PCC_ACCESS_CMD_DELETE_E, *app_id_p, port_id_list_p[i], NULL);
            if (rc != PCC_STATUS_SUCCESS) {
                SX_LOG_ERR("NVxCC APP port 0x%x delete failed, error: %s\n", port_id_list_p[i], pcc_status_str(rc));
                goto out;
            }
        }

        rc = __pcc_acls_deconfigure(acl_regions_params_arr);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP ACLs configuration failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_probe_words_regs_get(*app_id_p, probe_words_regs_arr);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed getting probe REGs for APP (%d) from DB, error: %s\n", *app_id_p, pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_extraction_points_unset(probe_words_regs_arr, NVXCC_PROBE_REGS_NUM);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP extraction points un-set failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        rc = __pcc_app_resources_emts_deconfigure(configured_emts_arr, configured_emts_num);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to de-configure EMTs on APP (%d) from DB, error: %s\n", *app_id_p, pcc_status_str(rc));
            goto out;
        }
        rc = pcc_db_app_delete(*app_id_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP DB create, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        break;

    default:
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("APP set command (%d) not supported. error: %s\n", cmd, pcc_status_str(rc));
        break;
    }
out:
    if (port_id_list_p) {
        cl_free(port_id_list_p);
    }
    return rc;
}

static pcc_status_t __pcc_hpcc_app_set(const pcc_access_cmd_e       cmd,
                                       const pcc_app_init_params_t *app_init_params_p,
                                       pcc_app_id_t                *app_id_p)
{
    pcc_status_t               rc = PCC_STATUS_SUCCESS;
    pcc_app_init_params_t      app_init_params;
    uint8_t                    bind_emts_num = 0;
    sx_flex_modifier_emt_id_e  bind_emts_arr[PCC_FLEX_MODIFIER_EMT_LAST_E];
    uint8_t                    spare_emts_num = 0;
    sx_flex_modifier_emt_id_e  spare_emts_arr[PCC_FLEX_MODIFIER_EMT_LAST_E];
    sx_flex_modifier_emt_id_e  edit_emt = 0;
    probe_words_arr            probe_words_regs_arr = {0};
    uint8_t                    reg0_offset = 16, reg1_offset = 28;
    acl_regions_params_arr     acl_regions_params_arr;
    pcc_app_state_e            app_state = PCC_APP_STATE_DISABLE;
    uint8_t                    configured_emts_num = 0;
    pcc_flex_modifier_emt_id_e configured_emts_arr[PCC_FLEX_MODIFIER_EMT_LAST_E];
    pcc_port_log_id_t         *port_id_list_p = NULL;
    uint32_t                   port_id_list_cnt = 0, i = 0;

    UNUSED_PARAM(app_id_p);

    memcpy(&app_init_params, app_init_params_p, sizeof(pcc_app_init_params_t));

    switch (cmd) {
    case PCC_ACCESS_CMD_ADD_E:

        rc = __pcc_app_resources_check_update_valid(PCC_APP_HPCC,
                                                    &app_init_params.pcc_app_params.hpcc_params.app_resources.emts_data,
                                                    &app_init_params.pcc_app_params.hpcc_params.app_resources.gp_registers_data);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP resources check failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_app_resources_emt_set_types(&app_init_params.pcc_app_params.hpcc_params.app_resources.emts_data,
                                               bind_emts_arr,
                                               &bind_emts_num,
                                               spare_emts_arr,
                                               &spare_emts_num,
                                               &edit_emt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP EMT resources types set failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_app_resources_reg_set_types(
            &app_init_params.pcc_app_params.hpcc_params.app_resources.gp_registers_data,
            probe_words_regs_arr, HPCC_PROBE_REGS_NUM);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP REG resources types set failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_extraction_points_set(probe_words_regs_arr,
                                         probe_regs_hpcc_offsets,
                                         HPCC_PROBE_REGS_NUM,
                                         reg0_offset,
                                         reg1_offset);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP extraction points set failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_flex_modifier_configure_edit(edit_emt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP flex modifier configuration for edit EMT (%d) failed, error: %s\n",
                       edit_emt,
                       pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_flex_modifier_configure_push(PCC_APP_HPCC,
                                                bind_emts_arr,
                                                bind_emts_num,
                                                spare_emts_arr,
                                                spare_emts_num,
                                                app_init_params.pcc_app_params.hpcc_params.app_params.debug_enable,
                                                app_init_params.pcc_app_params.hpcc_params.app_params.device_id);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP flex modifier configuration for push EMTs failed, error: %s\n",
                       pcc_status_str(rc));
            goto out;
        }
        rc = __pcc_flex_pm_configure(PCC_APP_HPCC,
                                     app_id_p,
                                     spare_emts_arr,
                                     spare_emts_num,
                                     NULL);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("NVxCC APP flex PM configuration failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_hpcc_acls_configure(probe_words_regs_arr,
                                       acl_regions_params_arr);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP ACLs configuration failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_hpcc_app_create(*app_id_p,
                                    &app_init_params.pcc_app_params.hpcc_params,
                                    acl_regions_params_arr,
                                    &app_init_params.pcc_app_params.hpcc_params.app_resources.gp_registers_data,
                                    bind_emts_arr,
                                    bind_emts_num,
                                    spare_emts_arr,
                                    spare_emts_num,
                                    edit_emt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP DB create, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        break;

    case PCC_ACCESS_CMD_DELETE_E:
        rc = pcc_db_app_state_get(*app_id_p, &app_state);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("APP (%d) state get from DB failed, error: %s\n", *app_id_p, pcc_status_str(rc));
            goto out;
        }
        if (PCC_APP_STATE_ENABLE == app_state) {
            rc = pcc_api_app_state_set(*app_id_p, PCC_APP_STATE_DISABLE);
            if (rc != PCC_STATUS_SUCCESS) {
                SX_LOG_ERR("APP (%d) state set failed, error: %s\n", *app_id_p, pcc_status_str(rc));
                goto out;
            }
        }

        rc = __pcc_flex_pm_deconfigure(*app_id_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to de-configure Flex PM for APP (%d), error: %s\n", *app_id_p, pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_configured_emts_get(*app_id_p,
                                            configured_emts_arr,
                                            &configured_emts_num);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get configured EMTs on APP (%d) from DB, error: %s\n", *app_id_p,
                       pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_acl_params_get(*app_id_p, acl_regions_params_arr);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get ACL parameters for APP (%d) from DB, error: %s\n", *app_id_p,
                       pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_ports_count_get(*app_id_p, &port_id_list_cnt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in pcc_db_app_ports_count_get, error %s \n", pcc_status_str(rc));
            goto out;
        }

        port_id_list_p = (pcc_port_log_id_t *)cl_malloc(sizeof(pcc_port_log_id_t) * (port_id_list_cnt));
        if (port_id_list_p == NULL) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("Memory allocation for ports list in PCC LIB failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_ports_get_first(*app_id_p, port_id_list_p, &port_id_list_cnt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in pcc_db_app_ports_get_first, error %s \n", pcc_status_str(rc));
            goto out;
        }

        for (i = 0; i < port_id_list_cnt; i++) {
            rc = __pcc_app_port_set(PCC_ACCESS_CMD_DELETE_E, *app_id_p, port_id_list_p[i], NULL);
            if (rc != PCC_STATUS_SUCCESS) {
                SX_LOG_ERR("HPCC APP port 0x%x delete failed, error: %s\n", port_id_list_p[i], pcc_status_str(rc));
                goto out;
            }
        }

        rc = __pcc_acls_deconfigure(acl_regions_params_arr);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP ACLs configuration failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_probe_words_regs_get(*app_id_p, probe_words_regs_arr);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed getting probe REGs for APP (%d) from DB, error: %s\n", *app_id_p, pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_extraction_points_unset(probe_words_regs_arr, HPCC_PROBE_REGS_NUM);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP extraction points un-set failed, error: %s\n", pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_app_resources_emts_deconfigure(configured_emts_arr, configured_emts_num);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to de-configure EMTs on APP (%d) from DB, error: %s\n", *app_id_p, pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_delete(*app_id_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("HPCC APP DB create, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("HPCC APP set command (%d) not supported. error: %s\n", cmd, pcc_status_str(rc));
        break;
    }
out:
    return rc;
}

static pcc_status_t __pcc_app_port_set(const pcc_access_cmd_e     cmd,
                                       const pcc_app_id_t         app_id,
                                       const pcc_port_log_id_t    port_id,
                                       const pcc_app_port_data_t *port_data_p)
{
    pcc_status_t               rc = PCC_STATUS_SUCCESS;
    uint32_t                   port_group = 0;
    pcc_flex_modifier_emt_id_e bind_emt = 0, edit_emt = 0;
    acl_regions_params_arr     acl_regions_params_arr;
    pcc_app_port_data_t        port_data;
    pcc_app_type_e             app_type = 0;

    memset(&port_data, 0, sizeof(pcc_app_port_data_t));

    rc = pcc_db_app_acl_params_get(app_id, acl_regions_params_arr);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed getting ACL parameters for APP (%d) from DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    rc = pcc_db_app_type_get(app_id, &app_type);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP type from DB, error: %s\n", pcc_status_str(rc));
        goto out;
    }


    switch (cmd) {
    case PCC_ACCESS_CMD_ADD_E:
        rc = __pcc_port_speed_range_check(app_type, port_data_p->port_speed);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed checking port speed range for APP (%d), error: %s\n", app_id, pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_sdk_port_group_get(port_id, &port_group);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed getting port group for port 0x%08X, error: %s\n", port_id, pcc_status_str(rc));
            goto out;
        }
        rc = pcc_db_app_bind_emt_get(app_id, port_group, &bind_emt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed getting bind EMT for port 0x%08X from DB, error: %s\n", port_id, pcc_status_str(rc));
            goto out;
        }
        rc = pcc_db_app_edit_emt_get(app_id, &edit_emt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed getting edit EMT for port 0x%08X from DB, error: %s\n", port_id, pcc_status_str(rc));
            goto out;
        }

        rc = __port_flex_pm_context_set(cmd, app_id, port_id, bind_emt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed setting Flex PM context for APP (%d) and port (0x%08X), error: %s\n",
                       app_id,
                       port_id,
                       pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_port_acl_configuration_set(app_id,
                                              app_type,
                                              port_id,
                                              bind_emt,
                                              edit_emt,
                                              acl_regions_params_arr,
                                              port_data_p);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed setting port 0x%08X ACL configuration, error: %s\n", port_id, pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_port_set(app_id, port_id, port_group, bind_emt, port_data_p->port_speed, port_data_p->cntr_id);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed setting port 0x%08X to APP in DB, error: %s\n", port_id, pcc_status_str(rc));
            goto out;
        }

        break;

    case PCC_ACCESS_CMD_DELETE_E:

        rc = __port_flex_pm_context_set(cmd, app_id, port_id, bind_emt);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed un-setting Flex PM context for APP (%d) and port (0x%08X), error: %s\n",
                       app_id,
                       port_id,
                       pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_port_get(app_id, port_id, &port_data);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed getting port data for APP (%d) and port (0x%08X) from DB, error: %s\n",
                       app_id,
                       port_id,
                       pcc_status_str(rc));
            goto out;
        }

        rc = __pcc_port_acl_configuration_unset(port_id,
                                                acl_regions_params_arr);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed un-setting port 0x%08X ACL configuration, error: %s\n", port_id, pcc_status_str(rc));
            goto out;
        }

        rc = pcc_db_app_port_delete(app_id, port_id);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed deleting port 0x%08X to APP from DB, error: %s\n", port_id, pcc_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("APP set command (%d) not supported. error: %s\n", cmd, pcc_status_str(rc));
        break;
    }

out:
    return rc;
}
