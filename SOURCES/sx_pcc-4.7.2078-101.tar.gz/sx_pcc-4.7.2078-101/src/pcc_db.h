/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef SX_PCC_SRC_PCC_DB_H_
#define SX_PCC_SRC_PCC_DB_H_

#include <sx/pcc/sx_pcc_types.h>
#include <sx/pcc/sx_pcc.h>
#include <stdint.h>
#include <stdio.h>
#include "complib/cl_types_osd.h"
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_flex_modifier.h>

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/
#define PCC_ACLS_MAX_NUM     3
#define PROBE_REGS_NUM_MAX   HPCC_PROBE_REGS_NUM
#define HPCC_PROBE_REGS_NUM  5
#define NVXCC_PROBE_REGS_NUM 4
#define MAX_ACL_KEYS         8

typedef enum pcc_db_app_emt_type {
    PCC_DB_APP_EMT_TYPE_INVALID,
    PCC_DB_APP_EMT_TYPE_EDIT,
    PCC_DB_APP_EMT_TYPE_BIND,
    PCC_DB_APP_EMT_TYPE_SPARE
} pcc_db_app_emt_type_e;

typedef struct pcc_db_acl_regions_params {
    sx_acl_key_type_t  key_handle;
    sx_acl_region_id_t region_id;
    uint16_t           region_size;
    sx_acl_id_t        acl_id;
    sx_acl_id_t        acl_group_id;
    sx_acl_key_t       key_id[MAX_ACL_KEYS];
    uint8_t            key_id_size;
} pcc_db_acl_regions_params_t;

typedef pcc_db_acl_regions_params_t acl_regions_params_arr[PCC_ACLS_MAX_NUM];
typedef pcc_gp_register_e probe_words_arr[PROBE_REGS_NUM_MAX];

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

pcc_status_t pcc_db_init();

pcc_status_t pcc_db_nvxcc_app_create(pcc_app_id_t               app_id,
                                     pcc_app_nvxcc_params_t    *app_params,
                                     acl_regions_params_arr     acl_regions_params_arr,
                                     pcc_gp_registers_t        *gp_registers_data,
                                     sx_flex_modifier_emt_id_e *bind_emts_arr,
                                     uint8_t                    bind_emts_num,
                                     sx_flex_modifier_emt_id_e *spare_emts_arr,
                                     uint8_t                    spare_emts_num,
                                     sx_flex_modifier_emt_id_e  edit_emt);
pcc_status_t pcc_db_hpcc_app_create(pcc_app_id_t               app_id,
                                    pcc_app_hpcc_params_t     *app_params,
                                    acl_regions_params_arr     acl_regions_params_arr,
                                    pcc_gp_registers_t        *gp_registers_data,
                                    sx_flex_modifier_emt_id_e *bind_emts_arr,
                                    uint8_t                    bind_emts_num,
                                    sx_flex_modifier_emt_id_e *spare_emts_arr,
                                    uint8_t                    spare_emts_num,
                                    sx_flex_modifier_emt_id_e  edit_emt);

pcc_status_t pcc_db_app_delete(pcc_app_id_t app_id);

pcc_status_t pcc_db_apps_get(pcc_app_id_t *app_id_list_p, uint32_t *apps_count);

pcc_status_t pcc_db_app_type_get(pcc_app_id_t app_id, pcc_app_type_e *app_type);

pcc_status_t pcc_db_app_state_set(pcc_app_id_t app_id, pcc_app_state_e app_state);

pcc_status_t pcc_db_app_state_get(pcc_app_id_t app_id, pcc_app_state_e *app_state);

pcc_status_t pcc_db_app_debug_enabled_get(pcc_app_id_t app_id, boolean_t *debug_enabled);

pcc_status_t pcc_db_app_hpcc_device_id_get(pcc_app_id_t app_id, uint32_t *device_id);

pcc_status_t pcc_db_app_acl_params_set(pcc_app_id_t app_id, acl_regions_params_arr acl_regions_params_arr);

pcc_status_t pcc_db_app_acl_params_get(pcc_app_id_t app_id, acl_regions_params_arr acl_regions_params_arr);

pcc_status_t pcc_db_app_port_set(pcc_app_id_t               app_id,
                                 pcc_port_log_id_t          port_id,
                                 uint32_t                   port_group,
                                 pcc_flex_modifier_emt_id_e emt_id,
                                 pcc_port_speed_e           port_speed,
                                 pcc_port_cntr_id_t         cntr_id);

pcc_status_t pcc_db_app_port_get(pcc_app_id_t app_id, pcc_port_log_id_t port_id, pcc_app_port_data_t *port_data);

pcc_status_t pcc_db_app_port_delete(pcc_app_id_t app_id, pcc_port_log_id_t port_id);

pcc_status_t pcc_db_app_ports_get_first(pcc_app_id_t app_id, pcc_port_log_id_t *port_list, uint32_t *ports_count);

pcc_status_t pcc_db_app_ports_get_next(pcc_app_id_t app_id, pcc_port_log_id_t *port_list, uint32_t *ports_count);

pcc_status_t pcc_db_app_ports_count_get(pcc_app_id_t app_id, uint32_t *ports_count);

pcc_status_t pcc_db_app_bind_emt_get(pcc_app_id_t app_id, uint32_t port_group,
                                     pcc_flex_modifier_emt_id_e *emt_id);

pcc_status_t pcc_db_app_edit_emt_get(pcc_app_id_t app_id, pcc_flex_modifier_emt_id_e *emt_id);

pcc_status_t pcc_db_app_configured_emts_get(pcc_app_id_t                app_id,
                                            pcc_flex_modifier_emt_id_e *configured_emts_arr,
                                            uint8_t                    *configured_emts_num);

pcc_status_t pcc_db_app_emt_valid_get(pcc_flex_modifier_emt_id_e emt_id, boolean_t *is_valid);

pcc_status_t pcc_db_app_probe_words_regs_get(pcc_app_id_t app_id, probe_words_arr probe_regs_arr);

pcc_status_t pcc_db_app_reg_valid_get(pcc_gp_register_e reg_id, boolean_t *is_valid);

pcc_status_t pcc_db_deinit();


#endif /* SX_PCC_SRC_PCC_DB_H_ */
