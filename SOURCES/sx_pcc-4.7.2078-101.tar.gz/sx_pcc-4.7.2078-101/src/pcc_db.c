/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#undef  __MODULE__
#define __MODULE__ PCC_DB

#include "pcc_db.h"
#include <complib/cl_mem.h>
#include "complib/cl_types.h"
#include <complib/sx_log.h>
#include <unistd.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_flex_acl.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_flex_pm.h>


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/

typedef boolean_t valid_emts_arr[PCC_FLEX_MODIFIER_EMT_LAST_E];
typedef boolean_t valid_regs_arr[PCC_GP_REGISTER_LAST_E];

typedef struct pcc_db_port_group_map_entry {
    uint16_t      port_group;
    uint8_t       bound_emts_bitmask;
    cl_map_item_t map_item;
} pcc_db_port_group_map_entry_t;

typedef struct pcc_db_port_list_entry {
    pcc_port_log_id_t          port_id;
    pcc_flex_modifier_emt_id_e emt_id;
    pcc_port_speed_e           port_speed;
    pcc_port_cntr_id_t         cntr_id;
    uint16_t                   port_group;
    cl_list_item_t             list_item;
    uint32_t                   port_rule_offset;
} pcc_db_port_list_entry_t;

typedef struct pcc_db_app_emt_resource {
    pcc_db_app_emt_type_e emt_type;
} pcc_db_app_emt_resource_t;

typedef pcc_db_app_emt_resource_t app_emts_arr[PCC_FLEX_MODIFIER_EMT_LAST_E];

typedef struct pcc_db_app_reg_resource {
    boolean_t reg_valid;
} pcc_db_app_reg_resource_t;

typedef pcc_db_app_reg_resource_t app_regs_arr[PCC_GP_REGISTER_LAST_E];

typedef struct pcc_db_nvxcc_app_data_entry {
    pcc_app_nvxcc_params_app_t app_params;
    app_emts_arr               emts_arr;
    app_regs_arr               regs_arr;
    pcc_app_nvxcc_params_vip_t tc_attr;
    pcc_acl_group_priority_t   prio;
    acl_regions_params_arr     acl_params;
} pcc_db_nvxcc_app_data_entry_t;

typedef struct pcc_db_hpcc_app_data_entry {
    pcc_app_hpcc_params_app_t app_params;
    app_emts_arr              emts_arr;
    app_regs_arr              regs_arr;
    pcc_acl_group_priority_t  prio;
    acl_regions_params_arr    acl_params;
} pcc_db_hpcc_app_data_entry_t;

typedef union pcc_db_app_data_entry {
    pcc_db_nvxcc_app_data_entry_t nvxcc_app_data;
    pcc_db_hpcc_app_data_entry_t  hpcc_app_data;
} pcc_db_app_data_entry_t;

typedef struct pcc_db_app_map_entry {
    cl_map_item_t           map_item;
    pcc_app_id_t            app_id;
    pcc_app_type_e          app_type;
    pcc_db_app_data_entry_t app_data;
    pcc_app_state_e         app_state;
    cl_qlist_t              ports_list;
} pcc_db_app_map_entry_t;

static cl_qmap_t      g_db_pcc_apps_map;
static boolean_t      g_pcc_db_initialized = FALSE;
static cl_qmap_t      g_pcc_db_port_group_emts_map;
static valid_emts_arr g_valid_emts_arr;  /* Global array of used EMTs by all applications*/
static valid_regs_arr g_valid_regs_arr;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
static boolean_t __emt_id_is_in_range(pcc_flex_modifier_emt_id_e emt_id);

static boolean_t __reg_id_is_in_range(pcc_gp_register_e reg_id);

/************************************************
*  Function implementations
************************************************/
static boolean_t __emt_id_is_in_range(pcc_flex_modifier_emt_id_e emt_id)
{
    return emt_id < PCC_FLEX_MODIFIER_EMT_LAST_E;
}

static boolean_t __reg_id_is_in_range(pcc_gp_register_e reg_id)
{
    return reg_id < PCC_GP_REGISTER_LAST_E;
}

static pcc_status_t __pcc_db_app_entry_get(pcc_app_id_t app_id, pcc_db_app_map_entry_t** entry_p)
{
    pcc_status_t    rc = PCC_STATUS_SUCCESS;
    cl_map_item_t * map_item = NULL;

    map_item = cl_qmap_get(&g_db_pcc_apps_map, app_id);
    if (map_item == NULL) {
        SX_LOG_ERR("Failed to get APP (%d) entry from DB", app_id);
        rc = PCC_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    *entry_p = PARENT_STRUCT(map_item, pcc_db_app_map_entry_t, map_item);
out:
    return rc;
}

static pcc_status_t __pcc_db_app_entry_create(pcc_app_id_t app_id)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *map_entry = NULL;
    cl_map_item_t          *map_item = NULL;
    const cl_map_item_t    *map_end = NULL;

    map_end = cl_qmap_end(&g_db_pcc_apps_map);
    map_item = cl_qmap_get(&g_db_pcc_apps_map, app_id);
    if (map_item != map_end) {
        rc = PCC_STATUS_ENTRY_ALREADY_EXIST;
        SX_LOG_ERR("Failed to create APP (%d) entry, entry already exists. error: (%s).\n", app_id,
                   pcc_status_str(rc));
        goto out;
    }
    /* Allocate map entry */
    map_entry = (pcc_db_app_map_entry_t*)cl_malloc(sizeof(pcc_db_app_map_entry_t));
    if (NULL == map_entry) {
        rc = PCC_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate memory for PCC APP map entry in DB. error: (%s).\n", pcc_status_str(rc));
        goto out;
    }

    /* Initiate map entry */
    memset(map_entry, 0, sizeof(pcc_db_app_map_entry_t));
    cl_qlist_init(&map_entry->ports_list);

    cl_qmap_insert(&g_db_pcc_apps_map, app_id, &(map_entry->map_item));

out:
    return rc;
}

static void __pcc_db_app_map_destroy_all()
{
    pcc_db_app_map_entry_t   *map_entry = NULL;
    cl_map_item_t            *map_item_p = NULL;
    const cl_map_item_t      *map_end_p = NULL;
    pcc_db_port_list_entry_t *list_entry = NULL;
    cl_list_item_t           *list_item_p = NULL;
    const cl_list_item_t     *list_end_p = NULL;

    map_item_p = cl_qmap_head(&g_db_pcc_apps_map);
    map_end_p = cl_qmap_end(&g_db_pcc_apps_map);
    while (map_item_p != map_end_p) {
        cl_qmap_remove_item(&g_db_pcc_apps_map, map_item_p);
        map_entry = PARENT_STRUCT(map_item_p, pcc_db_app_map_entry_t, map_item);
        list_item_p = cl_qlist_head(&map_entry->ports_list);
        list_end_p = cl_qlist_end(&map_entry->ports_list);
        while (list_item_p != list_end_p) {
            cl_qlist_remove_item(&(map_entry->ports_list), list_item_p);
            list_entry = PARENT_STRUCT(list_item_p, pcc_db_port_list_entry_t, list_item);
            cl_free(list_entry);
        }
        cl_free(map_entry);
        map_item_p = cl_qmap_head(&g_db_pcc_apps_map);
    }

    return;
}

static void __pcc_db_port_group_map_destroy_all()
{
    pcc_db_port_group_map_entry_t *map_entry = NULL;
    cl_map_item_t                 *map_item_p = NULL;
    const cl_map_item_t           *map_end_p = NULL;

    map_item_p = cl_qmap_head(&g_pcc_db_port_group_emts_map);
    map_end_p = cl_qmap_end(&g_pcc_db_port_group_emts_map);
    while (map_item_p != map_end_p) {
        cl_qmap_remove_item(&g_pcc_db_port_group_emts_map, map_item_p);
        map_entry = PARENT_STRUCT(map_item_p, pcc_db_port_group_map_entry_t, map_item);
        cl_free(map_entry);
        map_item_p = cl_qmap_head(&g_pcc_db_port_group_emts_map);
    }

    return;
}
static pcc_status_t __pcc_db_app_entry_set(pcc_app_id_t             app_id,
                                           pcc_app_type_e           app_type,
                                           pcc_db_app_data_entry_t *app_data,
                                           pcc_app_state_e          app_state)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    app_entry->app_type = app_type;
    memcpy(&app_entry->app_data, app_data, sizeof(pcc_db_app_data_entry_t));
    app_entry->app_state = app_state;

out:
    return rc;
}

static pcc_db_port_group_map_entry_t* __pcc_db_port_group_entry_get(uint16_t port_group)
{
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;

    map_end = cl_qmap_end(&g_pcc_db_port_group_emts_map);
    map_item = cl_qmap_get(&g_pcc_db_port_group_emts_map, port_group);
    if (map_item == map_end) {
        return NULL;
    }
    return PARENT_STRUCT(map_item, pcc_db_port_group_map_entry_t, map_item);
}

static void __pcc_db_global_resources_set(pcc_db_app_data_entry_t *app_data)
{
    uint8_t i = 0;

    for (i = 0; i < PCC_FLEX_MODIFIER_EMT_LAST_E; i++) {
        if (app_data->nvxcc_app_data.emts_arr[i].emt_type != PCC_DB_APP_EMT_TYPE_INVALID) {
            g_valid_emts_arr[i] = TRUE;
        }
    }
    for (i = 0; i < PCC_GP_REGISTER_LAST_E; i++) {
        if (app_data->nvxcc_app_data.regs_arr[i].reg_valid) {
            g_valid_regs_arr[i] = TRUE;
        }
    }
}

static void __pcc_db_port_group_emt_is_free(uint32_t                   port_group,
                                            pcc_flex_modifier_emt_id_e emt_id,
                                            boolean_t                 *is_free)
{
    pcc_db_port_group_map_entry_t *entry_p = NULL;

    entry_p = __pcc_db_port_group_entry_get(port_group);
    if (entry_p == NULL) {
        *is_free = TRUE; /* New port group all EMTs are free */
        return;
    }
    *is_free = !(entry_p->bound_emts_bitmask & (0x01 << emt_id));
    return;
}

static pcc_status_t __pcc_db_port_group_emt_bind_set(uint32_t                   port_group,
                                                     pcc_flex_modifier_emt_id_e emt_id,
                                                     boolean_t                  set)
{
    pcc_status_t                   rc = PCC_STATUS_SUCCESS;
    cl_map_item_t                 *map_item = NULL;
    const cl_map_item_t           *map_end = NULL;
    pcc_db_port_group_map_entry_t *entry_p = NULL;

    map_end = cl_qmap_end(&g_pcc_db_port_group_emts_map);
    map_item = cl_qmap_get(&g_pcc_db_port_group_emts_map, port_group);
    if (map_item == map_end) {
        SX_LOG_ERR("Failed to get port group (%d) entry from DB", port_group);
        rc = PCC_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    entry_p = PARENT_STRUCT(map_item, pcc_db_port_group_map_entry_t, map_item);
    if (set) {
        entry_p->bound_emts_bitmask = (entry_p->bound_emts_bitmask | (0x01 << emt_id));
    } else { /* un-set */
        entry_p->bound_emts_bitmask = (entry_p->bound_emts_bitmask & (~(0x01 << emt_id)));
    }

out:
    return rc;
}

static pcc_status_t __pcc_db_port_group_entry_create(uint16_t port_group)
{
    pcc_status_t                   rc = PCC_STATUS_SUCCESS;
    pcc_db_port_group_map_entry_t *port_group_map_entry = NULL;

    port_group_map_entry = (pcc_db_port_group_map_entry_t*)cl_malloc(sizeof(pcc_db_port_group_map_entry_t));
    if (NULL == port_group_map_entry) {
        rc = PCC_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate memory for PCC APP port entry in DB. error: (%s).\n", pcc_status_str(rc));
        goto out;
    }
    memset(port_group_map_entry, 0, sizeof(pcc_db_port_group_map_entry_t));
    cl_qmap_insert(&g_pcc_db_port_group_emts_map, port_group, &(port_group_map_entry->map_item));

out:
    return rc;
}

static void __pcc_db_port_group_entry_destroy(uint16_t port_group)
{
    cl_map_item_t *map_item_p = NULL;

    map_item_p = cl_qmap_get(&g_pcc_db_port_group_emts_map, port_group);
    cl_qmap_remove_item(&g_pcc_db_port_group_emts_map, map_item_p);
}

static pcc_db_port_list_entry_t* __pcc_db_app_entry_port_get(cl_qlist_t *ports_list, pcc_port_log_id_t port_id)
{
    pcc_db_port_list_entry_t* port_list_entry = NULL;
    const cl_list_item_t    * p_end = NULL;
    cl_list_item_t          * p_item = NULL;

    p_end = cl_qlist_end(ports_list);
    p_item = cl_qlist_head(ports_list);
    while (p_item != p_end) {
        port_list_entry = PARENT_STRUCT(p_item, pcc_db_port_list_entry_t,
                                        list_item);
        if (port_id == port_list_entry->port_id) {
            return port_list_entry;
        }
        p_item = cl_qlist_next(p_item);
    }
    return NULL;
}

pcc_status_t pcc_db_init()
{
    pcc_status_t rc = PCC_STATUS_SUCCESS;

    cl_qmap_init(&g_db_pcc_apps_map);
    cl_qmap_init(&g_pcc_db_port_group_emts_map);
    memset(g_valid_emts_arr, 0, sizeof(boolean_t) * PCC_FLEX_MODIFIER_EMT_LAST_E);
    memset(g_valid_regs_arr, 0, sizeof(boolean_t) * PCC_GP_REGISTER_LAST_E);

    g_pcc_db_initialized = TRUE;

    return rc;
}

pcc_status_t pcc_db_nvxcc_app_create(pcc_app_id_t               app_id,
                                     pcc_app_nvxcc_params_t    *app_params,
                                     acl_regions_params_arr     acl_regions_params_arr,
                                     pcc_gp_registers_t        *gp_registers_data,
                                     sx_flex_modifier_emt_id_e *bind_emts_arr,
                                     uint8_t                    bind_emts_num,
                                     sx_flex_modifier_emt_id_e *spare_emts_arr,
                                     uint8_t                    spare_emts_num,
                                     sx_flex_modifier_emt_id_e  edit_emt)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_data_entry_t app_data;
    uint8_t                 i = 0;

    memset(&app_data, 0, sizeof(pcc_db_app_data_entry_t));

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_create(app_id);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create APP (%d) entry in PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    for (i = 0; i < PCC_ACLS_MAX_NUM; i++) {
        app_data.nvxcc_app_data.acl_params[i] = acl_regions_params_arr[i];
    }
    memcpy(&app_data.nvxcc_app_data.app_params, &app_params->app_params, sizeof(pcc_app_nvxcc_params_app_t));
    app_data.nvxcc_app_data.prio = app_params->acl_bind_group_prio;
    app_data.nvxcc_app_data.tc_attr = app_params->vip_params;

    for (i = 0; i < bind_emts_num; i++) {
        app_data.nvxcc_app_data.emts_arr[bind_emts_arr[i]].emt_type = PCC_DB_APP_EMT_TYPE_BIND;  /* Free to be bound later */
    }
    for (i = 0; i < spare_emts_num; i++) {
        app_data.nvxcc_app_data.emts_arr[spare_emts_arr[i]].emt_type = PCC_DB_APP_EMT_TYPE_SPARE;
    }

    app_data.nvxcc_app_data.emts_arr[edit_emt].emt_type = PCC_DB_APP_EMT_TYPE_EDIT;

    for (i = 0; i < gp_registers_data->reg_num; i++) {
        app_data.nvxcc_app_data.regs_arr[gp_registers_data->registers[i]].reg_valid = TRUE;
    }

    rc = __pcc_db_app_entry_set(app_id,
                                PCC_APP_NVXCC,
                                &app_data,
                                PCC_APP_STATE_DISABLE);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set APP (%d) entry in PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    __pcc_db_global_resources_set(&app_data);

out:
    return rc;
}

pcc_status_t pcc_db_hpcc_app_create(pcc_app_id_t               app_id,
                                    pcc_app_hpcc_params_t     *app_params,
                                    acl_regions_params_arr     acl_regions_params_arr,
                                    pcc_gp_registers_t        *gp_registers_data,
                                    sx_flex_modifier_emt_id_e *bind_emts_arr,
                                    uint8_t                    bind_emts_num,
                                    sx_flex_modifier_emt_id_e *spare_emts_arr,
                                    uint8_t                    spare_emts_num,
                                    sx_flex_modifier_emt_id_e  edit_emt)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_data_entry_t app_data;
    uint8_t                 i = 0;

    memset(&app_data, 0, sizeof(pcc_db_app_data_entry_t));

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_create(app_id);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create APP (%d) entry in PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    for (i = 0; i < PCC_ACLS_MAX_NUM; i++) {
        memcpy(&app_data.hpcc_app_data.acl_params[i], &acl_regions_params_arr[i], sizeof(pcc_db_acl_regions_params_t));
    }
    memcpy(&app_data.hpcc_app_data.app_params, &app_params->app_params, sizeof(pcc_app_hpcc_params_app_t));
    app_data.hpcc_app_data.prio = app_params->acl_bind_group_prio;

    for (i = 0; i < bind_emts_num; i++) {
        app_data.hpcc_app_data.emts_arr[bind_emts_arr[i]].emt_type = PCC_DB_APP_EMT_TYPE_BIND;  /* Free to be bound later */
    }
    for (i = 0; i < spare_emts_num; i++) {
        app_data.hpcc_app_data.emts_arr[spare_emts_arr[i]].emt_type = PCC_DB_APP_EMT_TYPE_SPARE;
    }

    app_data.hpcc_app_data.emts_arr[edit_emt].emt_type = PCC_DB_APP_EMT_TYPE_EDIT;

    for (i = 0; i < gp_registers_data->reg_num; i++) {
        app_data.hpcc_app_data.regs_arr[gp_registers_data->registers[i]].reg_valid = TRUE;
    }

    rc = __pcc_db_app_entry_set(app_id,
                                PCC_APP_HPCC,
                                &app_data,
                                PCC_APP_STATE_DISABLE);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set APP (%d) entry in PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    __pcc_db_global_resources_set(&app_data);

out:
    return rc;
}

pcc_status_t pcc_db_app_delete(pcc_app_id_t app_id)
{
    pcc_status_t              rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t   *app_entry = NULL;
    cl_list_item_t           *list_item_p = NULL;
    const cl_list_item_t     *list_end_p = NULL;
    pcc_db_port_list_entry_t *list_entry = NULL;
    uint8_t                   i = 0;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }
    switch (app_entry->app_type) {
    case PCC_APP_NVXCC:
        for (i = 0; i < PCC_FLEX_MODIFIER_EMT_LAST_E; i++) {
            if (app_entry->app_data.nvxcc_app_data.emts_arr[i].emt_type != PCC_DB_APP_EMT_TYPE_INVALID) {
                g_valid_emts_arr[i] = FALSE;
            }
        }
        for (i = 0; i < PCC_GP_REGISTER_LAST_E; i++) {
            if (app_entry->app_data.nvxcc_app_data.regs_arr[i].reg_valid == TRUE) {
                g_valid_regs_arr[i] = FALSE;
            }
        }
        break;

    case PCC_APP_HPCC:
        for (i = 0; i < PCC_FLEX_MODIFIER_EMT_LAST_E; i++) {
            if (app_entry->app_data.hpcc_app_data.emts_arr[i].emt_type != PCC_DB_APP_EMT_TYPE_INVALID) {
                g_valid_emts_arr[i] = FALSE;
            }
        }
        for (i = 0; i < PCC_GP_REGISTER_LAST_E; i++) {
            if (app_entry->app_data.hpcc_app_data.regs_arr[i].reg_valid == TRUE) {
                g_valid_regs_arr[i] = FALSE;
            }
        }
        break;
    }

    cl_qmap_remove_item(&g_db_pcc_apps_map, &app_entry->map_item);
    list_item_p = cl_qlist_head(&app_entry->ports_list);
    list_end_p = cl_qlist_end(&app_entry->ports_list);
    while (list_item_p != list_end_p) {
        cl_qlist_remove_item(&(app_entry->ports_list), list_item_p);
        list_entry = PARENT_STRUCT(list_item_p, pcc_db_port_list_entry_t, list_item);
        rc = __pcc_db_port_group_emt_bind_set(list_entry->port_group, list_entry->emt_id, FALSE);
        if (rc != PCC_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set port group bind EMT in PCC DB, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        cl_free(list_entry);
    }
    cl_free(app_entry);

out:
    return rc;
}

pcc_status_t pcc_db_apps_get(pcc_app_id_t *app_id_list_p, uint32_t *apps_count)
{
    pcc_db_app_map_entry_t *map_entry = NULL;
    cl_map_item_t          *map_item_p = NULL;
    const cl_map_item_t    *map_end_p = NULL;
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    uint32_t                i = 0;

    if ((*apps_count == 0) || (app_id_list_p == NULL)) {
        *apps_count = cl_qmap_count(&g_db_pcc_apps_map);
        goto out;
    }

    map_item_p = cl_qmap_head(&g_db_pcc_apps_map);
    map_end_p = cl_qmap_end(&g_db_pcc_apps_map);
    while (map_item_p != map_end_p && i < *apps_count) {
        map_entry = PARENT_STRUCT(map_item_p, pcc_db_app_map_entry_t, map_item);
        app_id_list_p[i] = map_entry->app_id;
        i++;
        map_item_p = cl_qmap_next(map_item_p);
    }

out:
    return rc;
}

pcc_status_t pcc_db_app_state_set(pcc_app_id_t app_id, pcc_app_state_e app_state)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    app_entry->app_state = app_state;

out:
    return rc;
}

pcc_status_t pcc_db_app_state_get(pcc_app_id_t app_id, pcc_app_state_e *app_state)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    *app_state = app_entry->app_state;

out:
    return rc;
}

pcc_status_t pcc_db_app_debug_enabled_get(pcc_app_id_t app_id, boolean_t *debug_enabled)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    switch (app_entry->app_type) {
    case PCC_APP_NVXCC:
        *debug_enabled = app_entry->app_data.nvxcc_app_data.app_params.debug_enable;
        break;

    case PCC_APP_HPCC:
        *debug_enabled = app_entry->app_data.hpcc_app_data.app_params.debug_enable;
        break;
    }


out:
    return rc;
}

pcc_status_t pcc_db_app_hpcc_device_id_get(pcc_app_id_t app_id, uint32_t *device_id)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    *device_id = app_entry->app_data.hpcc_app_data.app_params.device_id;

out:
    return rc;
}

pcc_status_t pcc_db_app_type_get(pcc_app_id_t app_id, pcc_app_type_e *app_type)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    *app_type = app_entry->app_type;

out:
    return rc;
}

pcc_status_t pcc_db_app_acl_params_set(pcc_app_id_t app_id, acl_regions_params_arr acl_regions_params_arr)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    switch (app_entry->app_type) {
    case PCC_APP_NVXCC:
        memcpy(app_entry->app_data.nvxcc_app_data.acl_params, acl_regions_params_arr,
               sizeof(pcc_db_acl_regions_params_t) * PCC_ACLS_MAX_NUM);
        break;

    case PCC_APP_HPCC:
        memcpy(app_entry->app_data.hpcc_app_data.acl_params, acl_regions_params_arr,
               sizeof(pcc_db_acl_regions_params_t) * PCC_ACLS_MAX_NUM);
        break;
    }


out:
    return rc;
}

pcc_status_t pcc_db_app_acl_params_get(pcc_app_id_t app_id, acl_regions_params_arr acl_regions_params_arr)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    switch (app_entry->app_type) {
    case PCC_APP_NVXCC:
        memcpy(acl_regions_params_arr, app_entry->app_data.nvxcc_app_data.acl_params,
               sizeof(pcc_db_acl_regions_params_t) * PCC_ACLS_MAX_NUM);
        break;

    case PCC_APP_HPCC:
        memcpy(acl_regions_params_arr, app_entry->app_data.hpcc_app_data.acl_params,
               sizeof(pcc_db_acl_regions_params_t) * PCC_ACLS_MAX_NUM);
        break;
    }

out:
    return rc;
}

pcc_status_t pcc_db_app_port_set(pcc_app_id_t               app_id,
                                 pcc_port_log_id_t          port_id,
                                 uint32_t                   port_group,
                                 pcc_flex_modifier_emt_id_e emt_id,
                                 pcc_port_speed_e           port_speed,
                                 pcc_port_cntr_id_t         cntr_id)
{
    pcc_status_t                   rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t        *app_entry = NULL;
    pcc_db_port_list_entry_t      *port_list_entry;
    pcc_db_port_group_map_entry_t *port_group_map_entry = NULL;
    boolean_t                      port_group_entry_created = FALSE;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }
    port_list_entry = __pcc_db_app_entry_port_get(&app_entry->ports_list, port_id);
    if (port_list_entry != NULL) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("Port (0x%x) is already set to APP (%d). error: (%s).\n", port_id, app_id, pcc_status_str(rc));
        goto out;
    }
    port_list_entry = (pcc_db_port_list_entry_t*)cl_malloc(sizeof(pcc_db_port_list_entry_t));
    if (NULL == port_list_entry) {
        rc = PCC_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate memory for PCC APP port entry in DB. error: (%s).\n", pcc_status_str(rc));
        goto out;
    }
    memset(port_list_entry, 0, sizeof(pcc_db_port_list_entry_t));

    port_list_entry->port_id = port_id;
    port_list_entry->emt_id = emt_id;
    port_list_entry->cntr_id = cntr_id;
    port_list_entry->port_speed = port_speed;
    cl_qlist_insert_head(&app_entry->ports_list, &port_list_entry->list_item);

    port_group_map_entry = __pcc_db_port_group_entry_get(port_group);
    if (NULL == port_group_map_entry) {
        __pcc_db_port_group_entry_create(port_group);
        port_group_entry_created = TRUE;
    }
    port_list_entry->port_group = port_group;

    rc = __pcc_db_port_group_emt_bind_set(port_group, emt_id, TRUE);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set bind EMT for port group (%d), error: %s\n", port_group, pcc_status_str(rc));
        goto out;
    }

out:
    if (rc != PCC_STATUS_SUCCESS) {
        if (TRUE == port_group_entry_created) {
            __pcc_db_port_group_entry_destroy(port_group);
        }
        cl_qlist_remove_head(&app_entry->ports_list);
        if (port_group_map_entry != NULL) {
            cl_free(port_list_entry);
        }
    }
    return rc;
}

pcc_status_t pcc_db_app_port_get(pcc_app_id_t app_id, pcc_port_log_id_t port_id, pcc_app_port_data_t *port_data)
{
    pcc_status_t              rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t   *app_entry = NULL;
    pcc_db_port_list_entry_t *port_list_entry;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    port_list_entry = __pcc_db_app_entry_port_get(&app_entry->ports_list, port_id);
    if (port_list_entry == NULL) {
        rc = PCC_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Port (0x%x) is not set to APP (%d) in PCC DB. error: (%s).\n", port_id, app_id,
                   pcc_status_str(rc));
        goto out;
    }

    port_data->cntr_id = port_list_entry->cntr_id;
    port_data->port_speed = port_list_entry->port_speed;
out:
    return rc;
}

pcc_status_t pcc_db_app_port_delete(pcc_app_id_t app_id, pcc_port_log_id_t port_id)
{
    pcc_status_t              rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t   *app_entry = NULL;
    pcc_db_port_list_entry_t *port_list_entry;
    const cl_list_item_t     *p_end = NULL, *p_item = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    p_end = cl_qlist_end(&app_entry->ports_list);
    p_item = cl_qlist_head(&app_entry->ports_list);
    while (p_item != p_end) {
        port_list_entry = PARENT_STRUCT(p_item, pcc_db_port_list_entry_t,
                                        list_item);
        if (port_id == port_list_entry->port_id) {
            cl_qlist_remove_item(&(app_entry->ports_list), &port_list_entry->list_item);
            rc = __pcc_db_port_group_emt_bind_set(port_list_entry->port_group, port_list_entry->emt_id, FALSE);
            if (rc != PCC_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set port group bind EMT in PCC DB, error: %s\n", pcc_status_str(rc));
                goto out;
            }
            cl_free(port_list_entry);
            break;
        }
        p_item = cl_qlist_next(p_item);
    }
out:
    return rc;
}


pcc_status_t pcc_db_app_ports_count_get(pcc_app_id_t app_id, uint32_t *ports_count)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    *ports_count = cl_qlist_count(&app_entry->ports_list);

out:
    return rc;
}

pcc_status_t pcc_db_app_ports_get_next(pcc_app_id_t app_id, pcc_port_log_id_t *port_list, uint32_t *ports_count)
{
    pcc_status_t              rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t   *app_entry = NULL;
    pcc_db_port_list_entry_t *port_list_entry;
    uint16_t                  i = 0;
    const cl_list_item_t     *p_end = NULL, *p_item = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    p_end = cl_qlist_end(&app_entry->ports_list);
    p_item = cl_qlist_head(&app_entry->ports_list);
    while (p_item != p_end) {
        port_list_entry = PARENT_STRUCT(p_item, pcc_db_port_list_entry_t,
                                        list_item);

        if (port_list_entry->port_id == port_list[0]) {
            p_item = cl_qlist_next(p_item);
            break;
        }

        p_item = cl_qlist_next(p_item);
    }

    while (p_item != p_end && i < *ports_count) {
        port_list_entry = PARENT_STRUCT(p_item, pcc_db_port_list_entry_t,
                                        list_item);
        port_list[i] = port_list_entry->port_id;
        p_item = cl_qlist_next(p_item);
        i++;
    }

    *ports_count = i;
out:
    return rc;
}

pcc_status_t pcc_db_app_ports_get_first(pcc_app_id_t app_id, pcc_port_log_id_t *port_list, uint32_t *ports_count)
{
    pcc_status_t              rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t   *app_entry = NULL;
    pcc_db_port_list_entry_t *port_list_entry;
    uint16_t                  i = 0;
    const cl_list_item_t     *p_end = NULL, *p_item = NULL;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    p_end = cl_qlist_end(&app_entry->ports_list);
    p_item = cl_qlist_head(&app_entry->ports_list);
    while (p_item != p_end && i < *ports_count) {
        port_list_entry = PARENT_STRUCT(p_item, pcc_db_port_list_entry_t,
                                        list_item);
        port_list[i] = port_list_entry->port_id;
        p_item = cl_qlist_next(p_item);
        i++;
    }

    *ports_count = i;
out:
    return rc;
}

pcc_status_t pcc_db_app_bind_emt_get(pcc_app_id_t app_id, uint32_t port_group, pcc_flex_modifier_emt_id_e *emt_id)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;
    uint8_t                 i = 0;
    boolean_t               is_free = FALSE;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    *emt_id = PCC_FLEX_MODIFIER_EMT_LAST_E;
    switch (app_entry->app_type) {
    case PCC_APP_NVXCC:
        for (i = 0; i < PCC_FLEX_MODIFIER_EMT_LAST_E; i++) {
            if (app_entry->app_data.nvxcc_app_data.emts_arr[i].emt_type == PCC_DB_APP_EMT_TYPE_BIND) {
                *emt_id = (pcc_flex_modifier_emt_id_e)i;
                __pcc_db_port_group_emt_is_free(port_group, *emt_id, &is_free);
                if (is_free) {
                    break;
                }
            }
        }
        break;

    case PCC_APP_HPCC:
        for (i = 0; i < PCC_FLEX_MODIFIER_EMT_LAST_E; i++) {
            if (app_entry->app_data.hpcc_app_data.emts_arr[i].emt_type == PCC_DB_APP_EMT_TYPE_BIND) {
                *emt_id = (pcc_flex_modifier_emt_id_e)i;
                __pcc_db_port_group_emt_is_free(port_group, *emt_id, &is_free);
                if (is_free) {
                    break;
                }
            }
        }
        break;

    default:
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("APP type (%d) is not supported. error: %s\n", app_entry->app_type, pcc_status_str(rc));
        goto out;
    }

    if (*emt_id == PCC_FLEX_MODIFIER_EMT_LAST_E) {
        rc = PCC_STATUS_NO_RESOURCES;
        SX_LOG_ERR("No Free EMTs found to bind in PCC DB error: %s\n", pcc_status_str(rc));
        goto out;
    }

out:
    return rc;
}

pcc_status_t pcc_db_app_edit_emt_get(pcc_app_id_t app_id, pcc_flex_modifier_emt_id_e *emt_id)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;
    uint8_t                 i = 0;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    *emt_id = PCC_FLEX_MODIFIER_EMT_LAST_E;
    switch (app_entry->app_type) {
    case PCC_APP_NVXCC:
        for (i = 0; i < PCC_FLEX_MODIFIER_EMT_LAST_E; i++) {
            if (app_entry->app_data.nvxcc_app_data.emts_arr[i].emt_type == PCC_DB_APP_EMT_TYPE_EDIT) {
                *emt_id = (pcc_flex_modifier_emt_id_e)i;
            }
        }
        break;

    case PCC_APP_HPCC:
        for (i = 0; i < PCC_FLEX_MODIFIER_EMT_LAST_E; i++) {
            if (app_entry->app_data.hpcc_app_data.emts_arr[i].emt_type == PCC_DB_APP_EMT_TYPE_EDIT) {
                *emt_id = (pcc_flex_modifier_emt_id_e)i;
            }
        }
        break;

    default:
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("APP type (%d) is not supported. error: %s\n", app_entry->app_type, pcc_status_str(rc));
        goto out;
    }

    if (*emt_id == PCC_FLEX_MODIFIER_EMT_LAST_E) {
        rc = PCC_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Edit EMT is not found in PCC DB error: %s\n", pcc_status_str(rc));
        goto out;
    }

out:
    return rc;
}

pcc_status_t pcc_db_app_probe_words_regs_get(pcc_app_id_t app_id, probe_words_arr probe_regs_arr)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;
    uint8_t                 i = 0, j = 0;


    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }

    switch (app_entry->app_type) {
    case PCC_APP_NVXCC:
        for (i = 2, j = 0; i < PCC_GP_REGISTER_LAST_E && j < NVXCC_PROBE_REGS_NUM; i++) {
            if (app_entry->app_data.nvxcc_app_data.regs_arr[i].reg_valid == TRUE) {
                probe_regs_arr[j] = (pcc_gp_register_e)i;
                j++;
            }
        }
        if (j != NVXCC_PROBE_REGS_NUM) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("Probe words REGs not found in DB, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        break;

    case PCC_APP_HPCC:
        for (i = 2, j = 0; i < PCC_GP_REGISTER_LAST_E && j < HPCC_PROBE_REGS_NUM; i++) {
            if (app_entry->app_data.hpcc_app_data.regs_arr[i].reg_valid == TRUE) {
                probe_regs_arr[j] = (pcc_gp_register_e)i;
                j++;
            }
        }
        if (j != HPCC_PROBE_REGS_NUM) {
            rc = PCC_STATUS_ERROR;
            SX_LOG_ERR("Probe words REGs not found in DB, error: %s\n", pcc_status_str(rc));
            goto out;
        }
        break;

    default:
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("PCC APP type (%d) is not supported, error: %s\n", app_entry->app_type, pcc_status_str(rc));
        goto out;
    }


out:
    return rc;
}

pcc_status_t pcc_db_app_emt_valid_get(pcc_flex_modifier_emt_id_e emt_id, boolean_t *is_valid)
{
    pcc_status_t rc = PCC_STATUS_SUCCESS;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }
    if (!__emt_id_is_in_range(emt_id)) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("EMT ID (%d) is out of range error: %s\n", emt_id, pcc_status_str(rc));
        goto out;
    }

    *is_valid = g_valid_emts_arr[emt_id];


out:
    return rc;
}

pcc_status_t pcc_db_app_reg_valid_get(pcc_gp_register_e reg_id, boolean_t *is_valid)
{
    pcc_status_t rc = PCC_STATUS_SUCCESS;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }
    if (!__reg_id_is_in_range(reg_id)) {
        rc = PCC_STATUS_ERROR;
        SX_LOG_ERR("REG ID (%d) is out of range error: %s\n", reg_id, pcc_status_str(rc));
        goto out;
    }

    *is_valid = g_valid_regs_arr[reg_id];

out:
    return rc;
}

pcc_status_t pcc_db_app_configured_emts_get(pcc_app_id_t                app_id,
                                            pcc_flex_modifier_emt_id_e *configured_emts_arr,
                                            uint8_t                    *configured_emts_num)
{
    pcc_status_t            rc = PCC_STATUS_SUCCESS;
    pcc_db_app_map_entry_t *app_entry = NULL;
    uint8_t                 i = 0, num_config = 0;

    if (!g_pcc_db_initialized) {
        rc = PCC_STATUS_NOT_INITIALIZED;
        SX_LOG_ERR("PCC DB not initialised error: %s\n", pcc_status_str(rc));
        goto out;
    }

    rc = __pcc_db_app_entry_get(app_id, &app_entry);
    if (rc != PCC_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get APP entry (%d) from PCC DB, error: %s\n", app_id, pcc_status_str(rc));
        goto out;
    }
    switch (app_entry->app_type) {
    case PCC_APP_NVXCC:
        for (i = 0; i < PCC_FLEX_MODIFIER_EMT_LAST_E; i++) {
            if ((app_entry->app_data.nvxcc_app_data.emts_arr[i].emt_type == PCC_DB_APP_EMT_TYPE_EDIT) ||
                (app_entry->app_data.nvxcc_app_data.emts_arr[i].emt_type == PCC_DB_APP_EMT_TYPE_SPARE) ||
                (app_entry->app_data.nvxcc_app_data.emts_arr[i].emt_type == PCC_DB_APP_EMT_TYPE_BIND)) {
                configured_emts_arr[num_config] = (pcc_flex_modifier_emt_id_e)i;
                num_config++;
            }
        }
        break;

    case PCC_APP_HPCC:
        for (i = 0; i < PCC_FLEX_MODIFIER_EMT_LAST_E; i++) {
            if ((app_entry->app_data.hpcc_app_data.emts_arr[i].emt_type == PCC_DB_APP_EMT_TYPE_EDIT) ||
                (app_entry->app_data.hpcc_app_data.emts_arr[i].emt_type == PCC_DB_APP_EMT_TYPE_SPARE) ||
                (app_entry->app_data.hpcc_app_data.emts_arr[i].emt_type == PCC_DB_APP_EMT_TYPE_BIND)) {
                configured_emts_arr[num_config] = (pcc_flex_modifier_emt_id_e)i;
                num_config++;
            }
        }
        break;
    }


    *configured_emts_num = num_config;
out:
    return rc;
}

pcc_status_t pcc_db_deinit()
{
    pcc_status_t rc = PCC_STATUS_SUCCESS;

    __pcc_db_app_map_destroy_all();
    __pcc_db_port_group_map_destroy_all();
    g_pcc_db_initialized = FALSE;

    return rc;
}
