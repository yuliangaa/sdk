/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sx_api/sx_api_internal.h"
#include "utils/sx_internal.h"
#include "timer/timer.h"
#include "utils/sx_adviser.h"
#include "utils/port_type_validate.h"
#include <resource_manager/resource_manager.h>
#include <complib/cl_mem.h>
#include <complib/cl_dbg.h>
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include <complib/cl_mem.h>
#include "sx_reg_bulk/sx_reg_bulk.h"
#include <sx/utils/gbin_allocator.h>
#include <sx/utils/linear_manager.h>
#include "sx/sdk/sx_status_convertor.h"
#include "sx_core/sx_core_async.h"

#undef  __MODULE__
#define __MODULE__ LINEAR_MANAGER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

typedef struct {
    /* queue and completion queue of sx core async infra */
    sx_work_queue_pair_info_t logic_queue_pair;
    sx_work_queue_pair_info_t reg_bulk_queue_pair;
} async_linear_manager_async_data_t;

typedef struct {
    cl_pool_item_t  pool_item;
    ba_handle_t     ba_handle;
    ba_logical_id_t lid;
    uint32_t        cntx;
    ba_index_t      old_id;
    ba_index_t      new_id;
    void          * relocate_cntx;
} async_linear_manager_async_job_data_t;

/* async sx core global context */
static async_linear_manager_async_data_t async_g_ctx;

#define   LINEAR_MANAGER_MODULE_QUEUE_SIZE 1000

static uint32_t   linear_manager_async_g_ctx;
static cl_qpool_t job_data_pool;
/************************************************
 *  Local function declarations
 ***********************************************/
static sx_work_queuep_status_t linear_manager_async_job_handler_cb(sx_work_queuep_job_cb_info_t *job_cb_info_p);
static sx_work_queuep_status_t __linear_manager_async_reg_bulk_post_completion_cb(
    const sx_work_queuep_completion_cb_params_t *params,
    void                                        *context);
static async_linear_manager_async_job_data_t * __linear_manager_async_db_obtain_job_data_item(void);
static sx_status_t __linear_manager_async_db_delete_job_data_item(async_linear_manager_async_job_data_t *item_p);
static sx_utils_status_t __linear_manager_async_transaction_id_get(sx_tid_manager_transaction_id_t *tid_p);
static sx_utils_status_t linear_manager_async_relocate(ba_handle_t     ba_handle,
                                                       ba_logical_id_t lid,
                                                       uint32_t        cntx,
                                                       ba_index_t      old_id,
                                                       ba_index_t      new_id,
                                                       void          * relocate_cntx);
/************************************************
 *  Function implementations
 ***********************************************/
static sx_status_t __linear_manager_async_register(void);
static sx_status_t __linear_manager_async_unregister_default_module(void);
static boolean_t        async_init = FALSE;
static ba_cb_relocate_t linear_manager_relocate_cb = NULL;

sx_status_t sdk_linear_manager_async_init(void)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_utils_status_t             utils_err = SX_UTILS_STATUS_SUCCESS;
    linear_manager_async_params_t params;
    cl_status_t                   cl_status;

    SX_LOG_ENTER();

    /* Init linear manager async*/

    /* Keep the relocate CB */
    params.relocate_async_cb = linear_manager_async_relocate;
    params.async_get_tid_cb = __linear_manager_async_transaction_id_get;
    params.async_init_cb = NULL;
    params.async_deinit_cb = NULL;

    utils_err = linear_manager_async_init(&params, (void*)&linear_manager_relocate_cb);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to initialize linear manager async, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

    /* Register to sx core async layer */
    err = __linear_manager_async_register();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register linear manager to async module logic layer.\n");
        goto out;
    }
    async_init = TRUE;

    cl_status = CL_QPOOL_INIT(&job_data_pool,
                              LINEAR_MANAGER_MODULE_QUEUE_SIZE,
                              LINEAR_MANAGER_MODULE_QUEUE_SIZE,
                              0,
                              sizeof(async_linear_manager_async_job_data_t),
                              NULL,
                              NULL,
                              NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate queue id to work queue pool.\n");
        goto out;
    }


out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t linear_manager_async_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}


sx_status_t linear_manager_async_deinit(void)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    /* Unregister linear manager processing from reg_bulk layer. */
    sx_status = sx_reg_bulk_unregister_module(SX_WORK_QUEUEP_MODULE_LINEAR_MANAGER_E);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "Failed to unregister fdb processing reg bulk layer sx_status [%s].\n",
            SX_STATUS_MSG(sx_status));
        goto out;
    }

    sx_status = __linear_manager_async_unregister_default_module();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinit linear manager module logic layer.\n");
        goto out;
    }


    if (cl_is_state_valid(job_data_pool.qcpool.state)) {
        CL_QPOOL_DESTROY(&job_data_pool);
    }

out:
    return sx_status;
}


static sx_status_t __linear_manager_async_register()
{
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t        work_queuep_rc = SX_WORK_QUEUEP_STATUS_SUCCESS;
    uint32_t                       queue_size = LINEAR_MANAGER_MODULE_QUEUE_SIZE;
    sx_work_queue_pair_info_t      logic_queue_pair;
    sx_work_queuep_module_params_t module_params;
    sx_work_queue_pair_info_t      wq_pair_info;
    sx_work_queuep_module_id_t     module_id = SX_WORK_QUEUEP_MODULE_LINEAR_MANAGER_E;
    const char                    *module_name = "linearManager";

    SX_MEM_CLR(async_g_ctx);
    SX_MEM_CLR(module_params);

    module_params.pre_completion_cb = NULL;
    module_params.post_completion_cb = NULL;
    module_params.post_completion_cb_context = NULL;

    /*snprintf(module_name, sizeof(module_name), "linear_manager_[%s]", client_name);*/

    work_queuep_rc = sx_work_queuep_module_init(module_id,
                                                module_name,
                                                &module_params);
    sx_status = wqp_status_to_sx_status(work_queuep_rc);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialized linear manager async layer module.\n");
        goto out;
    }

    /* Create the module and the thread at sx work queue p */
    work_queuep_rc = sx_work_queuep_module_register(module_id,
                                                    SX_WORK_QUEUE_TYPE_PRIVATE_WITH_THREAD_E,
                                                    queue_size,
                                                    &logic_queue_pair);
    sx_status = wqp_status_to_sx_status(work_queuep_rc);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register linear manager logic layer.\n");
        goto out;
    }

    async_g_ctx.logic_queue_pair = logic_queue_pair;

    /* Register to sx reg bulk layer */
    sx_status = sx_reg_bulk_module_register(SX_ACCESS_CMD_SET,
                                            SX_WORK_QUEUEP_MODULE_LINEAR_MANAGER_E,
                                            module_name,
                                            (sx_reg_bulk_queue_type_e)SX_WORK_QUEUE_TYPE_ORDERED_E,
                                            queue_size,
                                            NULL,
                                            NULL,
                                            __linear_manager_async_reg_bulk_post_completion_cb,
                                            &linear_manager_async_g_ctx,
                                            &wq_pair_info);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "linear manager async - __linear_manager_async_register fail to create reg bulk ordered queue sx_status = %d\n",
            sx_status);
        goto out;
    }

    async_g_ctx.reg_bulk_queue_pair = wq_pair_info;

out:
    return sx_status;
}


sx_utils_status_t linear_manager_reg_bulk_queue_id_get(sx_work_queue_pair_info_t *wq_pair_info_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();


    *wq_pair_info_p = async_g_ctx.reg_bulk_queue_pair;

    SX_LOG_EXIT();
    return err;
}


/* qpool of async job data */
/* BA -> LINEAR MANAGER ASYNC RELOCATE -> SEND MSG TO THREAD -> CALL RELOCATE CB */
static sx_utils_status_t linear_manager_async_relocate(ba_handle_t     ba_handle,
                                                       ba_logical_id_t lid,
                                                       uint32_t        cntx,
                                                       ba_index_t      old_id,
                                                       ba_index_t      new_id,
                                                       void          * relocate_cntx)
{
    sx_utils_status_t                      err = SX_UTILS_STATUS_SUCCESS;
    sx_work_queuep_status_t                wq_err = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_work_queuep_job_info_t              job_info;
    async_linear_manager_async_job_data_t *job_data_p = NULL;
    sx_work_queue_id_t                     queue_id = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(job_info);

    job_data_p = __linear_manager_async_db_obtain_job_data_item();
    if (job_data_p == NULL) {
        err = SX_UTILS_STATUS_NO_MEMORY;
        SX_LOG_ERR("Error allocating linear manager async job data memory\n");
        goto out;
    }
    job_data_p->ba_handle = ba_handle;
    job_data_p->lid = lid;
    job_data_p->cntx = cntx;
    job_data_p->old_id = old_id;
    job_data_p->new_id = new_id;
    job_data_p->relocate_cntx = relocate_cntx;

    job_info.module_id = SX_WORK_QUEUEP_MODULE_LINEAR_MANAGER_E; /* module_id;*/
    job_info.job_data = (void*)job_data_p;
    job_info.job_handler_cb = linear_manager_async_job_handler_cb;
    job_info.job_handler_cb_context = NULL;

    /* Push job to linear manager async */
    queue_id = async_g_ctx.logic_queue_pair.queue_id;

    wq_err = sx_work_queue_push_job(queue_id, &job_info);
    if (wq_err != SX_WORK_QUEUEP_STATUS_SUCCESS) {
        SX_LOG_ERR("Linear manager async - sx_work_queue_push_job failed, rc = %d\n", wq_err);
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_work_queuep_status_t __linear_manager_async_reg_bulk_post_completion_cb(
    const sx_work_queuep_completion_cb_params_t *params,
    void                                        *context)
{
    sx_work_queuep_status_t status = SX_WORK_QUEUEP_STATUS_SUCCESS;

    UNUSED_PARAM(params);
    UNUSED_PARAM(context);

    return status;
}


static sx_work_queuep_status_t linear_manager_async_job_handler_cb(sx_work_queuep_job_cb_info_t *job_cb_info_p)
{
    sx_work_queuep_status_t                sx_work_queuep_status = SX_WORK_QUEUEP_STATUS_SUCCESS;
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    async_linear_manager_async_job_data_t *logic_job_data_p = NULL;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;

    if (job_cb_info_p == NULL) {
        goto out;
    }
    if (job_cb_info_p->job_data == NULL) {
        goto out;
    }

    logic_job_data_p = (async_linear_manager_async_job_data_t*)job_cb_info_p->job_data;
    /* Call linear manager relocate function */
    /* get ba_handle and call the relocate */
    if (linear_manager_relocate_cb != NULL) {
        utils_err = linear_manager_relocate_cb(logic_job_data_p->ba_handle,
                                               logic_job_data_p->lid,
                                               logic_job_data_p->cntx,
                                               logic_job_data_p->old_id,
                                               logic_job_data_p->new_id,
                                               logic_job_data_p->relocate_cntx);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            SX_LOG_ERR("Failed to call linear manager relocate cb err = [%s]\n",
                       SX_UTILS_STATUS_MSG(utils_err));
        }
    }

    /* put the queue back to the job data pool */
    sx_status = __linear_manager_async_db_delete_job_data_item(logic_job_data_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR,
               "Error deleting linear manager async job data\n");
        goto out;
    }

out:
    return sx_work_queuep_status;
}

sx_status_t linear_manager_async_transaction_id_get(sx_tid_manager_transaction_id_t *tid_p)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    utils_err = __linear_manager_async_transaction_id_get(tid_p);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        sx_status = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to get linear manager async tid, err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

    SX_LOG_EXIT();
out:
    return sx_status;
}

static sx_utils_status_t __linear_manager_async_transaction_id_get(sx_tid_manager_transaction_id_t *tid_p)
{
    sx_utils_status_t                      err = SX_UTILS_STATUS_SUCCESS;
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    sx_tid_manager_transaction_id_t        tid;
    sx_tid_manager_transaction_id_params_t tid_params;

    SX_LOG_ENTER();

    *tid_p = 0;
    /* assign tid */
    SX_MEM_CLR(tid_params);
    tid_params.context = NULL;
    tid_params.owner = SX_WORK_QUEUEP_MODULE_LINEAR_MANAGER_E;
    tid_params.source = TID_SOURCE_INTERNAL;

    sx_status = sx_tid_manager_transaction_id_get(&tid_params, &tid);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__linear_manager_async_transaction_id_get Failed to get tid .\n");
        err = sx_status_to_sx_utils_status(sx_status);

        goto out;
    }

    *tid_p = SX_TID_MANAGER_TID_GET(tid);

    SX_LOG_EXIT();
out:
    return err;
}

static sx_status_t __linear_manager_async_unregister_default_module(void)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    sx_work_queuep_status_t work_queuep_rc = SX_WORK_QUEUEP_STATUS_SUCCESS;

    /* Unregister from module from sx work queuep  */
    work_queuep_rc = sx_work_queuep_unregister_module(SX_WORK_QUEUEP_MODULE_LINEAR_MANAGER_E);
    sx_status = wqp_status_to_sx_status(work_queuep_rc);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to unregister linear manager from async layer.\n");
        goto out;
    }

out:
    return sx_status;
}


static async_linear_manager_async_job_data_t * __linear_manager_async_db_obtain_job_data_item(void)
{
    cl_pool_item_t                        *pool_item_p = NULL;
    async_linear_manager_async_job_data_t *item_p = NULL;


    pool_item_p = cl_qpool_get(&job_data_pool);

    if (!pool_item_p) {
        SX_LOG_ERR("pool returned nothing\n");
        goto out;
    }

    item_p = PARENT_STRUCT(pool_item_p, async_linear_manager_async_job_data_t, pool_item);


out:
    return item_p;
}


/* Delete queue item and return it to the pool */
static sx_status_t __linear_manager_async_db_delete_job_data_item(async_linear_manager_async_job_data_t *item_p)
{
    cl_qpool_put(&job_data_pool,
                 &item_p->pool_item);


    return SX_STATUS_SUCCESS;
}
