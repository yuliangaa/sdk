/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __LINEAR_MANAGER_ASYNC_H_INCL__
#define __LINEAR_MANAGER_ASYNC_H_INCL__

#include <complib/sx_log.h>

#include <complib/cl_types.h>
#include <complib/cl_qlist.h>
#include <complib/cl_qmap.h>

#include <sx/sdk/sx_types.h>

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * pSort handle.
 */
typedef uint64_t linear_manager_async_handle_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t linear_manager_async_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

/**
 *  This function initializes the bin alloc module in applibs layer.
 *
 *
 *
 * @return SX_STATUS_SUCCESS success , otherwise error
 *
 */
sx_status_t sdk_linear_manager_async_init(void);

/**
 *  This function deinit bin allocator module in applibs layer.
 *
 * @return SX_STATUS_SUCCESS
 */
sx_status_t linear_manager_async_deinit(void);

/**
 *  This function return queue id of linear manager reg bulk queue for default clients.
 *
 * @return SX_STATUS_SUCCESS
 */
sx_utils_status_t linear_manager_reg_bulk_queue_id_get(sx_work_queue_pair_info_t *wq_pair_info_p);

/**
 *  This function return tid from linear manager.
 *
 * @return SX_STATUS_SUCCESS
 */
sx_status_t linear_manager_async_transaction_id_get(sx_tid_manager_transaction_id_t *tid_p);

sx_work_queuep_status_t linear_manager_async_async_relocate(void);

#endif /* __LINEAR_MANAGER_ASYNC_H_INCL__ */
