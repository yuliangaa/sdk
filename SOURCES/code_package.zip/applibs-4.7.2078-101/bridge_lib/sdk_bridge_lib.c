/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include "bridge/sdk_bridge.h"
#include "sdk_bridge_lib.h"
#include "sx_core/sx_core_cmd_db.h"
#include "sx_api/sx_api_internal.h"
#include <include/resource_manager/resource_manager.h>
#include <sx/sxd/sxd_access_register.h>
#include "ethl2/port.h"


#undef  __MODULE__
#define __MODULE__ BRIDGE_LIB

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/*************************************************
 *  Local Functions
 ************************************************/
static sx_status_t __bridge_verbosity(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                      uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __bridge_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __bridge_iter_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                     uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __bridge_vport_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                      uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __bridge_vport_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                      uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __bridge_vport_multi_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                            uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __bridge_counter_bind_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                             uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __bridge_counter_bind_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                             uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __bridge_tunnel_counter_bind_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                                    uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __bridge_tunnel_counter_bind_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                                    uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __bridge_lib_init_core_cmds(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type);
static sx_status_t __bridge_lib_init_internal_apis();
/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
/* SPC1, SPC_A1, SPC2, SPC3, SPC4 */
#define SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP (ALL_ACTIVE_ETH_ASIC_BITMAP)
static sx_api_command_t sx_core_api_sx_bridge_cmd_table[] = {
    {SX_API_INT_CMD_BRIDGE_VERBOSITY_E,         "SX_API_INT_CMD_BRIDGE_VERBOSITY_E",        __bridge_verbosity,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_BRIDGE_SET_E,         "SX_API_INT_CMD_BRIDGE_SET_E",        __bridge_set,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_BRIDGE_ITER_GET_E,         "SX_API_INT_CMD_BRIDGE_ITER_GET_E",        __bridge_iter_get,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_BRIDGE_VPORT_SET_E,         "SX_API_INT_CMD_BRIDGE_VPORT_SET_E",        __bridge_vport_set,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_BRIDGE_VPORT_GET_E,         "SX_API_INT_CMD_BRIDGE_VPORT_GET_E",        __bridge_vport_get,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_BRIDGE_VPORT_MULTI_SET_E,         "SX_API_INT_CMD_BRIDGE_VPORT_MULTI_SET_E",
     __bridge_vport_multi_set,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_BRIDGE_COUNTER_BIND_SET_E,         "SX_API_INT_CMD_BRIDGE_COUNTER_BIND_SET_E",
     __bridge_counter_bind_set,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_BRIDGE_COUNTER_BIND_GET_E,         "SX_API_INT_CMD_BRIDGE_COUNTER_BIND_GET_E",
     __bridge_counter_bind_get,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_BRIDGE_TUNNEL_COUNTER_BIND_SET_E,  "SX_API_INT_CMD_BRIDGE_TUNNEL_COUNTER_BIND_SET_E",
     __bridge_tunnel_counter_bind_set,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_BRIDGE_TUNNEL_COUNTER_BIND_GET_E,  "SX_API_INT_CMD_BRIDGE_TUNNEL_COUNTER_BIND_GET_E",
     __bridge_tunnel_counter_bind_get,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_NUM_E, "", NULL, SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E,
     SDK_BRIDGE_LIB_ALLOWED_ASIC_BITMAP}                                                                                       /* NULL Entry. Keep at end!! */
};

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

/* This function adds the specific bridge commands to the core api command structure */
int sdk_bridge_lib_init(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type)
{
    sx_status_t status;

    status = __bridge_lib_init_core_cmds(default_verbosity, asic_type);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("__bridge_lib_init_core_cmds failed, err (%s)\n", sx_status_str(status));
        goto out;
    }

    status = __bridge_lib_init_internal_apis();
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to initialize bridge module internal APIs, err (%s)\n", sx_status_str(status));
        goto out;
    }

    SX_LOG(SX_LOG_NOTICE, "SDK BRIDGE LIB is loaded\n");
out:
    return (int)status;
}

static sx_status_t __bridge_lib_init_core_cmds(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type)
{
    int               cmd_index = 0;
    sx_api_command_t* cmd = &sx_core_api_sx_bridge_cmd_table[cmd_index++];
    sx_status_t       err = SX_STATUS_SUCCESS;

    SX_LOG(SX_LOG_DEBUG, "system ASIC bit="BYTE_TO_BINARY_PATTERN,  BYTE_TO_BINARY((uint32_t)(1UL << asic_type)));

    do {
        if ((cmd->supported_asic_types) & (1UL << asic_type)) {
            SX_LOG(SX_LOG_DEBUG, "i=%d Add cmd %s to Bridge Lib CMD table.\n", cmd_index, cmd->name);
            err = sx_core_set_api_command(cmd);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("sdk bridge api cmd initialization failed \n");
                goto out;
            }
        } else {
            SX_LOG(SX_LOG_DEBUG, "SUPP ASIC bitmap="BYTE_TO_BINARY_PATTERN,
                   BYTE_TO_BINARY((uint32_t)(cmd->supported_asic_types)));
            SX_LOG(SX_LOG_DEBUG, "Skip adding unsupported cmd %s to SDK Bridge table.\n", cmd->name);
        }
        cmd = &sx_core_api_sx_bridge_cmd_table[cmd_index++];
    } while (cmd->cmd_id != SX_API_INT_CMD_NUM_E);

    LOG_VAR_NAME(__MODULE__) = default_verbosity;
    err = sdk_bridge_log_verbosity_level_set(default_verbosity);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set log level, SDK BRIDGE module, return message: [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    return err;
}

static sx_status_t __bridge_lib_init_internal_apis()
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    bridge_specific_cb_t* bridge_cb_api_p = NULL;

    status = bridge_common_cb_table_get(&bridge_cb_api_p);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to get bridge module internal APIs, err (%s)\n", sx_status_str(status));
        goto out;
    }

    /* Now we can fill the API pointers */
    bridge_cb_api_p->bridge_log_verbosity_level_set = sdk_bridge_log_verbosity_level_set;
    bridge_cb_api_p->bridge_init = sdk_bridge_init;
    bridge_cb_api_p->bridge_deinit = sdk_bridge_deinit;
    bridge_cb_api_p->bridge_ref_cnt_increase = sdk_bridge_ref_cnt_increase;
    bridge_cb_api_p->bridge_ref_cnt_decrease = sdk_bridge_ref_cnt_decrease;
    bridge_cb_api_p->bridge_vport_get = sdk_bridge_vport_get;
    bridge_cb_api_p->bridge_vport_fid_get = sdk_bridge_vport_fid_get;
    bridge_cb_api_p->bridge_is_log_port_in_bridge = sdk_bridge_is_vport_in_bridge;
    bridge_cb_api_p->bridge_is_sync_fence_needed = sdk_bridge_is_sync_fence_needed;
    bridge_cb_api_p->bridge_port_vport_get = sdk_bridge_port_vport_get;
    bridge_cb_api_p->bridge_mode_get = sdk_bridge_mode_get;
    bridge_cb_api_p->bridge_redirect_lag_validate = sdk_bridge_redirect_lag_validate;
    bridge_cb_api_p->bridge_redirect_lag_set = sdk_bridge_redirect_lag_set;
    bridge_cb_api_p->bridge_clear_port = sdk_bridge_clear_port;
    bridge_cb_api_p->bridge_dbg_generate_dump = sdk_bridge_dbg_generate_dump;
    bridge_cb_api_p->bridge_remove_vport_from_gc_queue = sdk_bridge_remove_vport_from_gc_queue;
    bridge_cb_api_p->bridge_is_homogeneous = sdk_bridge_is_homogeneous;
out:
    return status;
}


static sx_status_t __bridge_verbosity(sx_core_td_event_src_t *event, uint8_t * cmd_body, uint32_t cmd_body_size)
{
    sx_api_command_log_verbosity_t *params = NULL;
    sx_status_t                     err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_command_log_verbosity_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_command_log_verbosity_t*)cmd_body;

    switch (params->cmd) {
    case SX_ACCESS_CMD_SET:
        err = sdk_bridge_log_verbosity_level_set(params->verbosity_level);
        break;

    case SX_ACCESS_CMD_GET:
        err = sdk_bridge_log_verbosity_level_get(&(params->verbosity_level));
        break;

    default:
        break;
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    params->cmd == SX_ACCESS_CMD_GET ?
                                    sizeof(sx_api_command_log_verbosity_t) : 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __bridge_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_bridge_set_params_t *cmd_body_p = NULL;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(cmd_body_p);
    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_bridge_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }
    cmd_body_p = (sx_api_bridge_set_params_t*)cmd_body;

    err = sdk_bridge_set(cmd_body_p->cmd, &(cmd_body_p->bridge_id));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __bridge_iter_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_bridge_iter_get_params_t *params = NULL;
    uint32_t                         size = 0, bridge_id_cnt = 0;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_bridge_iter_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_bridge_iter_get_params_t*)cmd_body;
    bridge_id_cnt = params->bridge_id_cnt;

    err = sdk_bridge_iter_get(params->cmd,
                              params->bridge_id,
                              &(params->filter),
                              params->bridge_id_list,
                              &(params->bridge_id_cnt));

    if (err != SX_STATUS_SUCCESS) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
        goto out;
    }

    if (bridge_id_cnt > 0) {
        size = sizeof(sx_api_bridge_iter_get_params_t) +
               (params->bridge_id_cnt * sizeof(sx_bridge_id_t));
    } else {
        size = sizeof(sx_api_bridge_iter_get_params_t);
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_SUCCESS,
                                    (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __bridge_vport_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_bridge_vport_set_params_t *cmd_body_p = NULL;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_bridge_vport_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }
    cmd_body_p = (sx_api_bridge_vport_set_params_t*)cmd_body;

    err = sdk_bridge_vport_set(cmd_body_p->cmd, cmd_body_p->bridge_id, cmd_body_p->log_port, FALSE);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __bridge_vport_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_bridge_vport_get_params_t *params = NULL;
    sx_status_t                       err = SX_STATUS_SUCCESS;
    uint32_t                          reply_body_size;
    uint32_t                          bridge_vport_cnt;

    SX_LOG_ENTER();

    if (cmd_body_size < sizeof(sx_api_bridge_vport_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_bridge_vport_get_params_t*)cmd_body;
    bridge_vport_cnt = params->bridge_vport_cnt;

    err = sdk_bridge_vport_get(params->bridge_id,
                               params->bridge_vport_list,
                               &bridge_vport_cnt);

    if (params->bridge_vport_cnt > 0) {
        reply_body_size = sizeof(sx_api_bridge_vport_get_params_t) +
                          (bridge_vport_cnt * sizeof(sx_port_log_id_t));
    } else {
        reply_body_size = sizeof(sx_api_bridge_vport_get_params_t);
    }

    params->bridge_vport_cnt = bridge_vport_cnt;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, reply_body_size);
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __bridge_vport_multi_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_bridge_vport_multi_set_params_t *cmd_body_p = NULL;
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_status_t                             mode_err;
    uint32_t                                i;
    boolean_t                               need_restore_mode = FALSE;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_bridge_vport_multi_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }
    cmd_body_p = (sx_api_bridge_vport_multi_set_params_t*)cmd_body;

    err = fdb_transaction_mode_set(SX_ACCESS_CMD_ENABLE, rm_resource_global.swid_id_max);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("FDB transaction mode ENABLE failed - %s\n", sx_status_str(err));
        goto out;
    }

    need_restore_mode = TRUE;
    for (i = 0; i < cmd_body_p->list_cnt - 1; i++) {
        err = sdk_bridge_vport_set(cmd_body_p->cmd, cmd_body_p->bridge_id_list[i],
                                   cmd_body_p->log_port_list[i], TRUE);
        if ((cmd_body_p->cmd == SX_ACCESS_CMD_ADD) && (err == SX_STATUS_ENTRY_ALREADY_EXISTS)) {
            err = SX_STATUS_SUCCESS;
        } else if ((cmd_body_p->cmd == SX_ACCESS_CMD_DELETE) && (err == SX_STATUS_ENTRY_NOT_FOUND)) {
            err = SX_STATUS_SUCCESS;
        }
        if (err) {
            err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);
            goto out;
        }
    }

    err = fdb_transaction_mode_set(SX_ACCESS_CMD_DISABLE, rm_resource_global.swid_id_max);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("FDB transaction mode DISABLE failed - %s\n", sx_status_str(err));
        goto out;
    }
    need_restore_mode = FALSE;

    err = sdk_bridge_vport_set(cmd_body_p->cmd, cmd_body_p->bridge_id_list[i],
                               cmd_body_p->log_port_list[i], TRUE);

    sdk_bridge_vport_pending_push_set();

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    if (need_restore_mode) {
        mode_err = fdb_transaction_mode_set(SX_ACCESS_CMD_DISABLE, rm_resource_global.swid_id_max);
        if (mode_err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("FDB transaction mode DISABLE failed (restore) - %s\n", sx_status_str(mode_err));
        }
    }

    SX_LOG_EXIT();
    return err;
}


static sx_status_t __bridge_counter_bind_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_bridge_counter_bind_set_params_t *cmd_body_p = NULL;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_bridge_counter_bind_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }
    cmd_body_p = (sx_api_bridge_counter_bind_set_params_t*)cmd_body;

    err = sdk_bridge_counter_bind_set(cmd_body_p->cmd, cmd_body_p->bridge_id, cmd_body_p->flow_counter_id);

    if (err != SX_STATUS_SUCCESS) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
        goto out;
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);


out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __bridge_counter_bind_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_bridge_counter_bind_get_params_t *params = NULL;
    sx_status_t                              err = SX_STATUS_SUCCESS;
    uint32_t                                 reply_body_size;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_bridge_counter_bind_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_bridge_counter_bind_get_params_t*)cmd_body;

    err = sdk_bridge_counter_bind_get(params->bridge_id, &params->flow_counter_id);
    if (err != SX_STATUS_SUCCESS) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
        goto out;
    }

    reply_body_size = sizeof(sx_api_bridge_counter_bind_get_params_t);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, reply_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __bridge_tunnel_counter_bind_set(sx_core_td_event_src_t *event,
                                                    uint8_t                *cmd_body,
                                                    uint32_t                cmd_body_size)
{
    sx_api_bridge_tunnel_counter_bind_set_params_t *cmd_body_p = NULL;
    sx_status_t                                     err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_bridge_tunnel_counter_bind_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_bridge_tunnel_counter_bind_set_params_t*)cmd_body;

    err = sdk_bridge_tunnel_counter_bind_set(cmd_body_p->cmd, cmd_body_p->bridge_id,
                                             &cmd_body_p->counter_attr, cmd_body_p->counter_id);
    if (err != SX_STATUS_SUCCESS) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
        goto out;
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);


out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __bridge_tunnel_counter_bind_get(sx_core_td_event_src_t *event,
                                                    uint8_t                *cmd_body,
                                                    uint32_t                cmd_body_size)
{
    sx_api_bridge_tunnel_counter_bind_get_params_t *cmd_body_p = NULL;
    sx_status_t                                     err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size != sizeof(sx_api_bridge_tunnel_counter_bind_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    cmd_body_p = (sx_api_bridge_tunnel_counter_bind_get_params_t*)cmd_body;

    err = sdk_bridge_tunnel_counter_bind_get(cmd_body_p->bridge_id,
                                             &cmd_body_p->counter_attr,
                                             &cmd_body_p->counter_id);
    if (err != SX_STATUS_SUCCESS) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);
        goto out;
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)cmd_body_p,
                                    sizeof(sx_api_bridge_tunnel_counter_bind_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}
