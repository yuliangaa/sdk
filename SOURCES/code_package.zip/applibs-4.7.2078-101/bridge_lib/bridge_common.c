/*
 * SPDX-FileCopyrightText: Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <errno.h>
#include <dlfcn.h>

#include "bridge_lib/bridge_common.h"
#include "complib/sx_log.h"
#include "sdk_bridge_lib.h"
#include "sx_core/sx_core_cmd_db.h"
#include "sx_api/sx_api_internal.h"
#include "include/resource_manager/resource_manager.h"
#include "dbg_dump_modules/dbg_dump_modules.h"

#undef  __MODULE__
#define __MODULE__ BRIDGE_COM

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
/************************************************
 *  Local Defines
 ***********************************************/
#define SDK_BRIDGE_LIB_PATH "libsdkbridgelib.so"
#define SDK_BRIDGE_LIB_INIT "sdk_bridge_lib_init"

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/
/************************************************
 *  Global variables
 ***********************************************/
/************************************************
 *  Local variables
 ***********************************************/
static boolean_t            bridge_load_library_done = FALSE;
static bridge_specific_cb_t bridge_cb_api = {
    NULL,       /* bridge_log_verbosity_level_set */
    NULL,       /* bridge_init */
    NULL,       /* bridge_deinit */
    NULL,       /* bridge_set */
    NULL,       /* bridge_port_set */
    NULL,       /* bridge_port_get */
    NULL,       /* bridge_vport_get */
    NULL,       /* bridge_vport_fid_get */
    NULL,       /* bridge_is_vport_in_bridge */
    NULL,       /* bridge_port_vport_get */
    NULL,       /* bridge_int_vlan_bridge_id_get */
    NULL,       /* bridge_add_to_router */
    NULL,       /* bridge_remove_from_router */
    NULL,       /* bridge_mode_get */
    NULL,       /* bridge_redirect_lag_validate */
    NULL,       /* bridge_redirect_lag_set */
    NULL,       /* bridge_clear_port */
    NULL,       /* bridge_clear_undo */
    NULL,       /* bridge_int_vlan_group_set */
    NULL,       /* bridge_int_vlan_group_get */
    NULL,       /* bridge_port_acl_binding_get */
    NULL,       /* bridge_dbg_generate_dump */
    NULL,       /* bridge_remove_vport_from_gc_queue */
    NULL,       /* bridge_is_sync_fence_needed */
    NULL,       /* bridge_is_homogeneous */
};

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __dump_module_bridge_wrapper(dbg_dump_params_t *dbg_dump_params_p);

/************************************************
 *  Function implementations
 ***********************************************/

/* sdk bridge loader */
sx_status_t sdk_bridge_load_library(void              ** bridge_lib_handle,
                                    sx_verbosity_level_t default_verbosity,
                                    sxd_chip_types_t     asic_type)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    void       *lib_handle = NULL;

    sx_status_t (*lib_init_fn)(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type);
    char       *dlerr = NULL;

    if (bridge_load_library_done) {
        SX_LOG(SX_LOG_ERROR, "bridge_load_library already done\n");
        err = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    lib_handle = dlopen(SDK_BRIDGE_LIB_PATH, RTLD_NOW | RTLD_GLOBAL);
    if (!lib_handle) {
        SX_LOG(SX_LOG_ERROR, "dlopen (%s) failed: (%s)\n", SDK_BRIDGE_LIB_PATH, dlerror());
        err = SX_STATUS_ERROR;
        goto out;
    }

    *bridge_lib_handle = lib_handle;

    SX_LOG(SX_LOG_INFO, "%s is loaded\n", SDK_BRIDGE_LIB_PATH);

    lib_init_fn = dlsym(lib_handle, SDK_BRIDGE_LIB_INIT);
    dlerr = dlerror();
    if (dlerr != NULL) {
        dlclose(lib_handle);
        SX_LOG(SX_LOG_ERROR, "dlsym (%s) failed: (%s)\n", SDK_BRIDGE_LIB_INIT, dlerr);
        err = SX_STATUS_ERROR;
        goto out;
    }

    err = (*lib_init_fn)(default_verbosity, asic_type);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "bridge_init failed\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    bridge_load_library_done = TRUE;

out:
    return err;
}

sx_status_t bridge_common_cb_table_get(bridge_specific_cb_t** bridge_cb_api_p)
{
    if (NULL == bridge_cb_api_p) {
        SX_LOG(SX_LOG_ERROR, "bridge_cb_api_p is NULL\n");
        return SX_STATUS_ERROR;
    }

    *bridge_cb_api_p = &bridge_cb_api;

    return SX_STATUS_SUCCESS;
}
sx_status_t bridge_common_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    return err;
}

sx_status_t bridge_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = bridge_common_log_verbosity_level_set(verbosity_level);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }
    if (NULL == bridge_cb_api.bridge_log_verbosity_level_set) {
        SX_LOG(SX_LOG_NOTICE, "bridge_log_verbosity_level_set callback not initialized\n");
        goto out;
    }
    err = bridge_cb_api.bridge_log_verbosity_level_set(verbosity_level);
out:
    return err;
}

sx_status_t bridge_init(sx_bridge_params_t *bridge_init_param)
{
    sx_status_t err = SX_STATUS_ERROR;

    if (NULL == bridge_cb_api.bridge_init) {
        SX_LOG(SX_LOG_ERROR, "bridge_init callback not initialized\n");
        return SX_STATUS_ERROR;
    }

    DBG_DUMP_MODULES_REGISTER(err, BRIDGE, BRIDGE, bridge, FALSE, FALSE, FALSE);

    err = bridge_cb_api.bridge_init(bridge_init_param);

out:
    return err;
}

sx_status_t bridge_deinit()
{
    if (NULL == bridge_cb_api.bridge_deinit) {
        SX_LOG(SX_LOG_ERROR, "bridge_deinit callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_deinit();
}

sx_status_t bridge_set(sx_access_cmd_t cmd, sx_bridge_id_t     *bridge_id, bridge_entry_type_e entry_type)
{
    if (NULL == bridge_cb_api.bridge_set) {
        SX_LOG(SX_LOG_ERROR, "bridge_set callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_set(cmd, bridge_id, entry_type);
}

sx_status_t bridge_vport_get(sx_bridge_id_t    bridge_id,
                             sx_port_log_id_t *bridge_vport_list,
                             uint32_t         *bridge_vport_cnt)
{
    if (NULL == bridge_cb_api.bridge_vport_get) {
        SX_LOG(SX_LOG_ERROR, "bridge_vport_get callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_vport_get(bridge_id, bridge_vport_list, bridge_vport_cnt);
}


sx_status_t bridge_vport_fid_get(sx_port_log_id_t log_port, sx_fid_t *fid)
{
    if (NULL == bridge_cb_api.bridge_vport_fid_get) {
        SX_LOG(SX_LOG_ERROR, "bridge_vport_fid_get callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_vport_fid_get(log_port, fid);
}

sx_status_t bridge_is_log_port_in_bridge(sx_bridge_id_t *bridge_id, sx_port_log_id_t log_port)
{
    if (NULL == bridge_cb_api.bridge_is_log_port_in_bridge) {
        SX_LOG(SX_LOG_ERROR, "bridge_is_log_port_in_bridge callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_is_log_port_in_bridge(bridge_id, log_port);
}

sx_status_t bridge_is_sync_fence_needed(sx_bridge_id_t  *bridge_id,
                                        sx_port_log_id_t log_port,
                                        boolean_t       *is_sync_fence_needed)
{
    if (NULL == bridge_cb_api.bridge_is_sync_fence_needed) {
        SX_LOG(SX_LOG_ERROR, "bridge_is_sync_fence_needed callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_is_sync_fence_needed(bridge_id, log_port, is_sync_fence_needed);
}

sx_status_t bridge_remove_vport_from_gc_queue(sx_port_log_id_t log_port)
{
    if (NULL == bridge_cb_api.bridge_remove_vport_from_gc_queue) {
        SX_LOG(SX_LOG_ERROR, "bridge_remove_vport_from_gc_queue callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_remove_vport_from_gc_queue(log_port);
}

sx_status_t bridge_port_vport_get(sx_bridge_id_t bridge_id, sx_port_log_id_t port, sx_port_log_id_t *vport)
{
    if (NULL == bridge_cb_api.bridge_port_vport_get) {
        SX_LOG(SX_LOG_ERROR, "bridge_port_vport_get callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_port_vport_get(bridge_id, port, vport);
}

sx_status_t bridge_ref_cnt_increase(sx_bridge_id_t bridge_id)
{
    if (NULL == bridge_cb_api.bridge_ref_cnt_increase) {
        SX_LOG(SX_LOG_ERROR, "bridge_ref_cnt_increase callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_ref_cnt_increase(bridge_id);
}

sx_status_t bridge_ref_cnt_decrease(sx_bridge_id_t bridge_id)
{
    if (NULL == bridge_cb_api.bridge_ref_cnt_decrease) {
        SX_LOG(SX_LOG_ERROR, "bridge_ref_cnt_decrease callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_ref_cnt_decrease(bridge_id);
}

sx_status_t bridge_mode_get(sx_bridge_mode_t *bridge_mode)
{
    if (NULL == bridge_cb_api.bridge_mode_get) {
        /* Make sure to return a fixed value */
        *bridge_mode = SX_MODE_HYBRID;
        return SX_STATUS_SUCCESS;
    }
    return bridge_cb_api.bridge_mode_get(bridge_mode);
}

sx_status_t bridge_redirect_lag_validate(sx_port_log_id_t lag_port_log_id, sx_port_log_id_t redirect_lag_port_log_id)
{
    if (NULL == bridge_cb_api.bridge_redirect_lag_validate) {
        SX_LOG(SX_LOG_ERROR, "bridge_redirect_lag_validate callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_redirect_lag_validate(lag_port_log_id, redirect_lag_port_log_id);
}

sx_status_t bridge_redirect_lag_set(sx_access_cmd_t access_cmd, sx_port_log_id_t lag_port)
{
    if (NULL == bridge_cb_api.bridge_redirect_lag_set) {
        SX_LOG(SX_LOG_ERROR, "bridge_redirect_lag_set callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_redirect_lag_set(access_cmd, lag_port);
}

sx_status_t bridge_clear_port(sx_port_id_t port_id, boolean_t remove_port_from_db)
{
    if (NULL == bridge_cb_api.bridge_clear_port) {
        return SX_STATUS_SUCCESS;
    }
    return bridge_cb_api.bridge_clear_port(port_id, remove_port_from_db);
}

sx_status_t bridge_clear_undo(sx_port_id_t port_id, sx_swid_id_t swid)
{
    if (NULL == bridge_cb_api.bridge_clear_undo) {
        return SX_STATUS_SUCCESS;
    }
    return bridge_cb_api.bridge_clear_undo(port_id, swid);
}

sx_status_t bridge_int_vlan_group_set(sx_access_cmd_t      cmd,
                                      sx_bridge_id_t       bridge_id,
                                      sx_acl_direction_t   acl_direction,
                                      sx_acl_vlan_group_t *vlan_group)
{
    if (NULL == bridge_cb_api.bridge_int_vlan_group_set) {
        SX_LOG(SX_LOG_ERROR, "bridge_int_vlan_group_set callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_int_vlan_group_set(cmd, bridge_id, acl_direction, vlan_group);
}

sx_status_t bridge_int_vlan_group_get(sx_bridge_id_t bridge_id, sx_acl_vlan_group_t *vlan_group)
{
    if (NULL == bridge_cb_api.bridge_int_vlan_group_get) {
        SX_LOG(SX_LOG_ERROR, "bridge_int_vlan_group_get callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_int_vlan_group_get(bridge_id, vlan_group);
}

sx_status_t bridge_port_acl_binding_get(sx_port_id_t port_id,
                                        sx_acl_id_t *ingress_acl_id_p,
                                        sx_acl_id_t *egress_acl_id_p)
{
    if (NULL == bridge_cb_api.bridge_port_acl_binding_get) {
        SX_LOG(SX_LOG_DEBUG, "bridge_port_acl_binding_get callback not initialized\n");
        return SX_STATUS_UNSUPPORTED;
    }
    return bridge_cb_api.bridge_port_acl_binding_get(port_id, ingress_acl_id_p, egress_acl_id_p);
}

static sx_status_t __dump_module_bridge_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = bridge_dbg_generate_dump(dbg_dump_params_p);
    if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_MODULE_UNINITIALIZED)) {
        SX_LOG_ERR("dbg_dump failed to generate bridge module dump.\n");
    }

    return err;
}

sx_status_t bridge_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        return SX_STATUS_PARAM_NULL;
    }

    if (NULL == bridge_cb_api.bridge_dbg_generate_dump) {
        SX_LOG(SX_LOG_INFO, "bridge_dbg_generate_dump callback not initialized\n");
        return SX_STATUS_SUCCESS;
    }
    return bridge_cb_api.bridge_dbg_generate_dump(dbg_dump_params_p);
}

sx_status_t bridge_is_homogeneous(sx_bridge_id_t bridge_id, boolean_t *is_homogeneous)
{
    if (NULL == bridge_cb_api.bridge_is_homogeneous) {
        SX_LOG_ERR("bridge_is_homogeneous callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return bridge_cb_api.bridge_is_homogeneous(bridge_id, is_homogeneous);
}
