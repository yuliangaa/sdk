/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __SWITCH_QUANTUM3_H__
#define __SWITCH_QUANTUM3_H__
/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/


#define QUANTUM3_ACL_INGRESS_GROUPS_MAX                       0
#define QUANTUM3_ACL_ENGRESS_GROUPS_MAX                       0
#define QUANTUM3_ACL_GROUPS_SIZE_MAX                          0
#define QUANTUM3_ACL_GROUPS_NUM_MIN                           0
#define QUANTUM3_ACL_GROUPS_NUM_MAX                           0
#define QUANTUM3_ACL_RULES_BLOCK_MAX                          0
#define QUANTUM3_ACL_RULES_NUM_MIN                            0
#define QUANTUM3_ACL_RULES_NUM_MAX                            0
#define QUANTUM3_ACL_PBS_ENTRIES_MAX                          0
#define QUANTUM3_ACL_PORT_RANGES_MAX                          0
#define QUANTUM3_ACL_REGIONS_MAX                              0
#define QUANTUM3_ACL_INGRESS_TABLES_MAX                       0
#define QUANTUM3_ACL_EGRESS_TABLES_MAX                        0
#define QUANTUM3_ACL_TABLES_MAX                               0
#define QUANTUM3_ACL_VLAN_GROUPS_MAX                          0
#define QUANTUM3_ACL_TRAP_GROUPS_MAX                          0
#define QUANTUM3_ACL_MAX_ACTIONS_PER_RULE                     0
#define QUANTUM3_ACL_MAX_ACTIONS_PER_BASIC_SET                0
#define QUANTUM3_ACL_MAX_ACTIONS_PER_EXTENDED_SET             0
#define QUANTUM3_ACL_EXTENDED_ACTIONS_NUM_MIN                 0
#define QUANTUM3_ACL_EXTENDED_ACTIONS_NUM_MAX                 0
#define QUANTUM3_ACL_PARSING_DEPTH                            0
#define QUANTUM3_ACL_CUSTOM_BYTES_SET_MAX                     0
#define QUANTUM3_ACL_CUSTOM_BYTES_SET_SIZE_MAX                0
#define QUANTUM3_ACL_CUSTOM_BYTES_EXTRACTION_POINT_OFFSET_MAX 0
#define QUANTUM3_ACL_PBILM_ENTRIES_MAX                        0
#define QUANTUM3_ACL_KEY_BLOCKS_MAX                           0
#define QUANTUM3_ACL_ACLS_IN_GROUPS                           0
#define QUANTUM3_ACL_REGION_SIZE_MAX                          0

#define QUANTUM3_ROUTER_RIFS_MAX                      0
#define QUANTUM3_ROUTER_RIFS_DONTCARE                 0
#define QUANTUM3_ROUTER_SUB_PORT_FID_START_INDEX      0
#define QUANTUM3_ROUTER_IPV4_UC_MAX                   0
#define QUANTUM3_ROUTER_IPV4_MC_MAX                   0
#define QUANTUM3_ROUTER_IPV6_UC_MAX                   0
#define QUANTUM3_ROUTER_IPV6_SHORT_UC_MAX             0
#define QUANTUM3_ROUTER_IPV6_LONG_UC_MAX              0
#define QUANTUM3_ROUTER_IPV6_MC_MAX                   0
#define QUANTUM3_ROUTER_ECMP_MAX                      0
#define QUANTUM3_ROUTER_ECMP_HASH_MAX                 0
#define QUANTUM3_ROUTER_NEIGHS_MAX                    0
#define QUANTUM3_ROUTER_ADJ_MAX                       0
#define QUANTUM3_ROUTER_VRID_MAX                      0
#define QUANTUM3_ROUTER_COUNTERS_ID_MAX               0
#define QUANTUM3_ROUTER_NEXT_HOP_MAX                  0
#define QUANTUM3_ROUTER_ECMP_CONTAINER_TOT_WEIGHT_MAX 0
#define QUANTUM3_ROUTER_MAC_PROFILES_MAX              0
#define QUANTUM3_ROUTER_MAC_PREFIX_SIZE               0
#define QUANTUM3_SHSPM_TREE_MAX                       0
#define QUANTUM3_SHSPM_ENTRY_MAX                      0
#define QUANTUM3_MC_RPF_GROUP_MAX                     0
#define QUANTUM3_MC_RPF_GROUP_SIZE                    0
#define QUANTUM3_MC_CONTAINERS_MAX                    0
#define QUANTUM3_ROUTER_CAP_MAX_ARFT_ENTRIES_IN_ROW   0

#define QUANTUM3_IB_ROUTER_LIDS_MAX        49152
#define QUANTUM3_IB_ROUTER_MC_LIDS_NUM_MAX 0x4000   /*16k*/
#define QUANTUM3_IB_ROUTER_UC_LID_NUM_MAX  0xc000   /*48k*/
#define QUANTUM3_IB_PKEYS_TABLE_SIZE       32

#define QUANTUM3_FCF_PORT_DENSITY_MAX 0
#define QUANTUM3_FCF_ZONES_PAIRS_MAX  0
#define QUANTUM3_FCF_ZONES_GROUPS_MAX 0
#define QUANTUM3_FCF_GATEWAY_MAX      0
#define QUANTUM3_FCF_RULES_MAX        0

#define QUANTUM3_PORT_LCL_NUM_MAX             152
#define QUANTUM3_PORT_EXT_NUM_MAX             148    /* Please note the current value must not be greater than the 'MAX_PHYPORT_NUM' and 'MAX_SWITCHX_PORTS' defines */
#define QUANTUM3_PORT_LOG_NUM_MAX             4096
#define QUANTUM3_PORT_MTU_MAX                 KU_CAP_MAX_MTU_SWITCH_IB
#define QUANTUM3_PORT_MTU_MIN                 68
#define QUANTUM3_PORT_STORM_CONTROL_ID_MAX    4
#define QUANTUM3_PORT_VEPA_CHANNELS_NUM_MAX   0
#define QUANTUM3_PORT_SYSTEM_PORTS_MAX        148
#define QUANTUM3_PORT_SYSTEM_PORT_MODULES_MAX 148
#define QUANTUM3_PORT_MAP_WIDTH_MAX           8
#define QUANTUM3_IB_PORTS_MAX                 148 /* in case of 1x we may have 148 ports, for 2x - only 74 */
#define QUANTUM3_PORT_PARSING_DEPTH_MAX       0
#define QUANTUM3_PORT_PARSING_DEPTH_MIN       0
#define QUANTUM3_PORT_TX_FIR_TAPS_MAX         0


#define QUANTUM3_LAG_NUM_MAX          0
#define QUANTUM3_LAG_PORT_MEMBERS_MAX 0
#define QUANTUM3_LAG_VECTORS_NUM_MAX  0

#define QUANTUM3_SPAN_SESSION_ID_MAX            6
#define QUANTUM3_SPAN_TRUNCATE_SIZE_MIN         48
#define QUANTUM3_SPAN_TRUNCATE_SIZE_MAX         4088
#define QUANTUM3_SPAN_TRUNCATE_SIZE_GRANULARITY 4

#define QUANTUM3_FDB_MID_MAX         0
#define QUANTUM3_FDB_MID_START_INDEX 0
#define QUANTUM3_FDB_PGT_MAX         0
#define QUANTUM3_FDB_UC_ADDRESS_MAX  0
#define QUANTUM3_FDB_MC_ADDRESS_MAX  0

#define QUANTUM3_FLOODING_TABLE_MAX         2
#define QUANTUM3_FLOODING_TABLE_PER_VID_MAX 1

#define QUANTUM3_SWID_ID_MAX 7

#define QUANTUM3_POLICER_POOL_SIZE               0
#define QUANTUM3_POLICER_HOST_IFC_POOL_SIZE      56
#define QUANTUM3_POLICER_STORM_CONTROL_POOL_SIZE 0
#define QUANTUM3_POLICER_SPAN_POOL_SIZE          0
#define QUANTUM3_POLICER_BS_MIN_VALUE_PACKETS    0
#define QUANTUM3_POLICER_BS_MIN_VALUE_BYTES      0
#define QUANTUM3_POLICER_BS_MAX_VALUE            0

#define QUANTUM3_COS_TRAFFIC_CLASS_MAX                0
#define QUANTUM3_COS_PORT_ETS_SUB_GROUP_MAX           0
#define QUANTUM3_COS_PORT_ETS_GROUP_MAX               0
#define QUANTUM3_COS_PORT_PRIO_MAX                    0
#define QUANTUM3_COS_PORT_COLOR_MAX                   0
#define QUANTUM3_COS_PORT_ETS_ELEMENTS_NUM            0
#define QUANTUM3_COS_BUFFER_64K_SIZE_MAX              0
#define QUANTUM3_COS_BUFFER_128K_SIZE_MAX             0
#define QUANTUM3_COS_REDECN_DEFAULT_AQS_WEIGHT        0
#define QUANTUM3_COS_REDECN_RED_DROP_ENABLED          FALSE
#define QUANTUM3_COS_REDECN_SCD                       FALSE
#define QUANTUM3_COS_REDECN_PROFILES_MAX              0
#define QUANTUM3_COS_REDECN_CELL_MULTIPLIER           0
#define QUANTUM3_COS_REDECN_DEFAULT_TC_RED_ENABLED    FALSE
#define QUANTUM3_COS_REDECN_DEFAULT_TC_ECN_ENABLED    FALSE
#define QUANTUM3_COS_REDECN_DEFAULT_TC_ECE_ENABLED    FALSE
#define QUANTUM3_COS_REDECN_DEFAULT_ECE_INNER_ENABLED FALSE
#define QUANTUM3_BRIDGE_NUM_MAX                       0

#define QUANTUM3_TOTAL_TCAM                  0
#define QUANTUM3_TOTAL_L3_REPLICATION_MATRIX 0

/*SW TABLE -> HW TABLE MAPPING */

#define QUANTUM3_FDB_UC_MAC_HW_TABLE_TYPE /*sfd*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM3_FDB_MC_MAC_HW_TABLE_TYPE /*sfd*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM3_ROUTER_IPV4_UC_HW_TABLE_TYPE      /*ruft*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM3_ROUTER_IPV6_UC_HW_TABLE_TYPE      /*ruft*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM3_ROUTER_IPV6_SHORT_UC_HW_TABLE_TYPE/*ruft*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM3_ROUTER_IPV6_LONG_UC_HW_TABLE_TYPE /*ruft*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM3_ROUTER_IPV4_MC_HW_TABLE_TYPE      /*rmft*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM3_ROUTER_IPV6_MC_HW_TABLE_TYPE      /*rmft*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM3_ROUTER_ARP_IPV4_HW_TABLE_TYPE/*ruht*/ RM_HW_TABLE_TYPE_TCAM_E
#define QUANTUM3_ROUTER_ARP_IPV6_HW_TABLE_TYPE/*ruht*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM3_ROUTER_MC_REPLICATIONS_HW_TABLE_TYPE/*rigr*/ RM_HW_TABLE_TYPE_REPLICATION_MATRIX_E

#define QUANTUM3_ROUTER_ADJACENCY_HW_TABLE_TYPE/*ratr*/ RM_HW_TABLE_TYPE_ADJACENCY_E

#define QUANTUM3_L2_MC_MIDS_HW_TABLE_TYPE/*smid*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM3_LAG_VECTORS_HW_TABLE_TYPE/*sldr*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM3_L2_MC_FLOODING_HW_TABLE_TYPE/*sftr*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM3_FCF_FORWORDING_HW_TABLE_TYPE/*fftr*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM3_ACL_RULES_HW_TABLE_TYPE /*ptce*/ RM_HW_TABLE_TYPE_TCAM_E

#define QUANTUM3_ACL_GROUPS_HW_TABLE_TYPE RM_HW_TABLE_TYPE_ACL_GROUP_TABLE_E

#define QUANTUM3_ACL_EXTENDED_ACTIONS_HW_TABLE_TYPE RM_HW_TABLE_TYPE_INVALID


/*phy_entry_cost per table */

#define QUANTUM3_FDB_UC_MAC_HW_ENTRY_COST 1
#define QUANTUM3_FDB_MC_MAC_HW_ENTRY_COST 1

#define QUANTUM3_ROUTER_IPV4_UC_HW_ENTRY_COST      /*ruft*/ 1
#define QUANTUM3_ROUTER_IPV6_UC_HW_ENTRY_COST      /*ruft*/ 1
#define QUANTUM3_ROUTER_IPV6_SHORT_UC_HW_ENTRY_COST/*ruft*/ 1
#define QUANTUM3_ROUTER_IPV6_LONG_UC_HW_ENTRY_COST /*ruft*/ 1
#define QUANTUM3_ROUTER_IPV4_MC_HW_ENTRY_COST      /*rmft*/ 1
#define QUANTUM3_ROUTER_IPV6_MC_HW_ENTRY_COST      /*rmft*/ 1

#define QUANTUM3_ROUTER_ARP_IPV4_HW_ENTRY_COST/*ruft*/ 1
#define QUANTUM3_ROUTER_ARP_IPV6_HW_ENTRY_COST/*ruft*/ 1

#define QUANTUM3_ROUTER_MC_REPLICATIONS_HW_ENTRY_COST/*rigr*/ 1

#define QUANTUM3_ROUTER_ADJACENCY_HW_ENTRY_COST/*ratr*/ 1

#define QUANTUM3_L2_MC_MIDS_HW_ENTRY_COST/*smid*/ 1

#define QUANTUM3_LAG_VECTORS_ENTRY_COST 1

#define QUANTUM3_L2_MC_FLOODING_HW_ENTRY_COST/*sftr*/ 1

#define QUANTUM3_FCF_FORWORDING_HW_ENTRY_COST/*fftr*/ 1

#define QUANTUM3_ACL_RULES_HW_ENTRY_COST /*ptce*/ 1

#define QUANTUM3_ACL_GROUPS_HW_ENTRY_COST           1
#define QUANTUM3_ACL_EXTENDED_ACTIONS_HW_ENTRY_COST 0

#define QUANTUM3_BUFFERS_TOTAL_MEMORY            0
#define QUANTUM3_DESCRIPTOR_BUFFERS_TOTAL_MEMORY 0
#define QUANTUM3_MAX_TOTAL_HEADROOM_SIZE         0
#define QUANTUM3_HEADROOM_NUM_BUFF_PER_PORT      9
/* Shared buffers - QUANTUM3 */
#define QUANTUM3_SHARED_BUFF_NUM_ING_POOL_PER_PORT 0
#define QUANTUM3_SHARED_BUFF_NUM_EGR_POOL_PER_PORT 0
#define QUANTUM3_SHARED_BUFF_NUM_MC_POOL_PER_PORT  0
#define QUANTUM3_SHARED_BUFF_NUM_ING_DESC_PER_PORT 0
#define QUANTUM3_SHARED_BUFF_NUM_EGR_DESC_PER_PORT 0
#define QUANTUM3_SHARED_BUFF_NUM_MANAGMENT_POOL    0
#define QUANTUM3_SHARED_BUFF_TOTAL_NUM_POOL        0
#define QUANTUM3_SHARED_HEADROOM_NUM_POOL          0
#define QUANTUM3_SHARED_BUFF_NUM_EGR_BUFF_PER_PORT 0
#define QUANTUM3_SHARED_BUFF_NUM_ING_BUFF_PER_PORT 0
#define QUANTUM3_SHARED_BUFF_MAX_POOL_SIZE         0

#define QUANTUM3_SHARED_BUFF_DEF_ING_DATA_POOL_SIZE QUANTUM3_SHARED_BUFF_MAX_POOL_SIZE
#define QUANTUM3_SHARED_BUFF_DEF_EGR_DATA_POOL_SIZE QUANTUM3_SHARED_BUFF_MAX_POOL_SIZE
#define QUANTUM3_SHARED_BUFF_DEF_ING_MGMT_POOL_SIZE (0)
#define QUANTUM3_SHARED_BUFF_DEF_EGR_MGMT_POOL_SIZE (0)
#define QUANTUM3_SHARED_BUFF_DEF_ING_DESC_POOL_SIZE (0)           /* 32 banks, 4280 descriptors per bank */
#define QUANTUM3_SHARED_BUFF_DEF_EGR_DESC_POOL_SIZE (0)           /* 32 banks, 4280 descriptors per bank */

#define QUANTUM3_SHARED_BUFF_PORT_NUM_MAX           0
#define QUANTUM3_SHARED_BUFF_TCLASS_NUM_MAX         0
#define QUANTUM3_SHARED_BUFF_RET_STATISTICS_NUM_MAX 0
#define QUANTUM3_BUFF_UNIT_SIZE                     96
#define QUANTUM3_SHARED_BUFF_MC_MAX_NUM_PRIO        0
#define QUANTUM3_MAX_SHARED_HEADROOM_POOL_SIZE      0

/* COS SB port buffers profile defines */
#define QUANTUM3_SHARED_BUFF_MAX_ALPHA_0_E        0x00
#define QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E      0x06
#define QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E        0x0B
#define QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E 0xFF
#define QUANTUM3_SHARED_BUFF_FULL_POOL            100

#define QUANTUM3_KVD_SIZE           0
#define QUANTUM3_KVD_MAX_BLOCK_SIZE 0

#define QUANTUM3_NUM_HW_CPU_INGRESS_TCLASS_MAX             32
#define QUANTUM3_NUM_HW_DR_PATHS_MAX                       0
#define QUANTUM3_NUM_HW_TRAP_GROUPS_MAX                    5
#define QUANTUM3_NUM_HW_TOTAL_TRAP_GROUPS_MAX              5
#define QUANTUM3_TRAP_GROUP_PRIORITY_MIN                   0
#define QUANTUM3_TRAP_GROUP_PRIORITY_MAX                   4
#define QUANTUM3_NUM_RDQS_MAX                              32
#define QUANTUM3_NUM_CPU_TCLASS                            4
#define QUANTUM3_KVD_HASH_SINGLE_MIN_SIZE                  0
#define QUANTUM3_KVD_HASH_DOUBLE_MIN_SIZE                  0
#define QUANTUM3_KVD_GUARANTEED_CAPACITY                   0
#define QUANTUM3_KVD_LINEAR_VIRTUAL_TABLE_SIZE             0
#define QUANTUM3_KVD_HASH_HIGH_THRESHOLD                   0
#define QUANTUM3_KVD_HASH_LOW_THRESHOLD                    0
#define QUANTUM3_KVD_HASH_GC_TRIGGER_THRESHOLD             0
#define QUANTUM3_KVD_HASH_PENDING_ENTRIES_TRIGGER_THRESOLD 0


#define QUANTUM3_RESERVED_EMPTY_MID      0
#define QUANTUM3_PGT_SIZE                0
#define QUANTUM3_PGT_MAX_BLOCK_SIZE      0
#define QUANTUM3_PGT_MAX_BLOCK_ALLOC_NUM 0
#define QUANTUM3_RMPE_SIZE               0
#define QUANTUM_FIDS_MAX                 0
#define QUANTUM3_ARFT_NUM_REC_MAX        0

/* SW Counter Allocation - Only used on some chips */
#define QUANTUM3_CNTR_BANK_PAIRS              0
#define QUANTUM3_CNTR_LINES_PER_BANK          0
#define QUANTUM3_CNTR_LINES_RESERVED_PER_BANK 0
#define QUANTUM3_CNTR_LINES_FLOW_PKT          0
#define QUANTUM3_CNTR_TYPE_FLOW_PKT           0
#define QUANTUM3_CNTR_LINES_FLOW_BYTE         0
#define QUANTUM3_CNTR_TYPE_FLOW_BYTE          0
#define QUANTUM3_CNTR_LINES_FLOW_BOTH         0
#define QUANTUM3_CNTR_TYPE_FLOW_BOTH          0
#define QUANTUM3_CNTR_LINES_RIF_BASIC         0
#define QUANTUM3_CNTR_TYPE_RIF_BASIC          0
#define QUANTUM3_CNTR_LINES_RIF_MIXED_1       0
#define QUANTUM3_CNTR_TYPE_RIF_MIXED_1        0
#define QUANTUM3_CNTR_LINES_RIF_MIXED_2       0
#define QUANTUM3_CNTR_TYPE_RIF_MIXED_2        0
#define QUANTUM3_CNTR_LINES_RIF_ENHANCED      0
#define QUANTUM3_CNTR_TYPE_RIF_ENHANCED       0

#define QUANTUM3_ACCUFLOW_CNTR_BANKS                   0   /* Not supported */
#define QUANTUM3_ACCUFLOW_CNTR_LINES_RESERVED_PER_BANK 0   /* Not supported */
#define QUANTUM3_ACCUFLOW_CNTR_LINES_PER_HW_BANK       0   /* Not supported */
#define QUANTUM3_ACCUFLOW_CNTR_LINES_PER_BANK          0   /* Not supported */
#define QUANTUM3_ACCUFLOW_CNTR_LINES_FLOW_BOTH         0   /* Not supported */
#define QUANTUM3_ACCUFLOW_CNTR_TYPE_FLOW_BOTH          0   /* Not supported */
#define QUANTUM3_ACCUFLOW_CNTR_START_IDX_OFFSET        0   /* Not supported */

/* Tunnel */
#define QUANTUM3_NUM_MAX_TUNNEL_IPINIP         0   /* Not supported */
#define QUANTUM3_NUM_MAX_TUNNEL_NVE            0   /* Not supported */
#define QUANTUM3_NUM_MAX_TUNNEL_L2_FLEX        0   /* Not supported */
#define QUANTUM3_TUNNEL_NVE_GS_FLOOD_MAX       0   /* Not supported */
#define QUANTUM3_TUNNEL_NVE_GS_MC_MAX          0 /* Not supported */
#define QUANTUM3_TUNNEL_TNUMT_IPV6_RECORDS_MAX 0   /* Not supported */

/* IGMP V3 */
#define QUANTUM3_IGMP_V3_NUM_MAX_ENTRIES 0        /* Not supported */

/* Telemetry */
#define QUANTUM3_TELE_HISTOGRAM_NUM_MAX                                      0
#define QUANTUM3_TELE_HISTOGRAM_QUEUE_DEPTH_BINS                             0
#define QUANTUM3_TELE_HISTOGRAM_SAMPLE_TIME_RESOLUTION_MAX                   0
#define QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LINEAR_MIN               0
#define QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_EXPONENT_MIN             0
#define QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_QUEUE_DEPTH_LINEAR_MAX   0
#define QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_QUEUE_DEPTH_EXPONENT_MAX 0
#define QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LATENCY_LINEAR_MAX       0
#define QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LATENCY_EXPONENT_MAX     0
#define QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_MAX                      0
#define QUANTUM3_TELE_HISTOGRAM_DATA_BIN_BITS_MAX                            23
#define QUANTUM3_TELE_HISTOGRAM_MIN_BOUNDARY_MIN                             1
#define QUANTUM3_TELE_THRESHOLD_NUM_MAX \
    (QUANTUM3_LAG_NUM_MAX +             \
     QUANTUM3_PORT_EXT_NUM_MAX) *       \
    QUANTUM3_COS_TRAFFIC_CLASS_MAX
#define QUANTUM3_TELE_THRESHOLD_THR_MAX            0xFFFFFF
#define QUANTUM3_TELE_THRESHOLD_LATENCY_THR_MAX    0
#define QUANTUM3_TELE_THRESHOLD_LATENCY_TABLE_SIZE 0

/* BFD */
#define QUANTUM3_BFD_SESSION_NUM_MAX 0

/* Register module */
#define QUANTUM3_GP_REGISTER_NUM_MAX      0
#define QUANTUM3_GP_REGISTER_HASH_NUM_MAX 0

/* General Purpose RAM */
#define QUANTUM3_GP_RAM_SIZE 0

/* STP */
#define QUANTUM3_STP_FAST_RECORDS_NUM_MAX 0

#define QUANTUM3_INVALID_SW_TABLE_TYPE RM_SDK_TABLE_TYPE_INVALID_E

#define QUANTUM3_INFRA_PROFILE_BASE_LOCAL_PORT_INVALID 0
/* Port group */
#define QUANTUM3_EGRESS_GROUP_TOTAL_PORTS 0

/*stateful DB*/
#define QUANTUM3_STATEFUL_DB_PARTITION_MAX_EXCEED_KVD 0
/* Config profile*/
#define QUANTUM3_CONFIG_PROFILE_FLOOD_MODE     4        /* Controlled mode*/
#define QUANTUM3_CONFIG_PROFILE_LAG_TABLE_MNGR RM_SDK_LAG_TABLE_FW_MNGR
#define QUANTUM3_CONFIG_PROFILE_DDD_LAG_TABLE  RM_SDK_LAG_TABLE_ENTRY_DUPLICATION_ENABLED

/* Truncation Profile - Unsupported */
#define QUANTUM3_TRUNCATION_PROFILE_SPAN_TOTAL_NUM                        0
#define QUANTUM3_TRUNCATION_PROFILE_ACL_TOTAL_NUM                         0
#define QUANTUM3_TRUNCATION_PROFILE_STATIC_TRUNC_SIZE_MIN                 0
#define QUANTUM3_TRUNCATION_PROFILE_STATIC_TRUNC_SIZE_WHEN_MASKING_MAX    0
#define QUANTUM3_TRUNCATION_PROFILE_STATIC_TRUNC_GRANULARITY              0
#define QUANTUM3_TRUNCATION_PROFILE_MASKING_ADDITIONAL_OFFSET_MAX         0
#define QUANTUM3_TRUNCATION_PROFILE_MASKING_ADDITIONAL_OFFSET_GRANULARITY 0

/* Adaptive Routing - Unsupported */
#define QUANTUM3_ADAPTIVE_ROUTING_TCLASS_NUM 0

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

static const rm_resources_t rm_resource_quantum3 = {
    /*23*/
    QUANTUM3_ACL_INGRESS_GROUPS_MAX,
    QUANTUM3_ACL_ENGRESS_GROUPS_MAX,
    QUANTUM3_ACL_GROUPS_SIZE_MAX,
    QUANTUM3_ACL_GROUPS_NUM_MAX,
    QUANTUM3_ACL_RULES_BLOCK_MAX,
    QUANTUM3_ACL_PBS_ENTRIES_MAX,
    QUANTUM3_ACL_PORT_RANGES_MAX,
    QUANTUM3_ACL_REGIONS_MAX,
    QUANTUM3_ACL_INGRESS_TABLES_MAX,
    QUANTUM3_ACL_EGRESS_TABLES_MAX,
    QUANTUM3_ACL_TABLES_MAX,
    QUANTUM3_ACL_VLAN_GROUPS_MAX,
    QUANTUM3_ACL_TRAP_GROUPS_MAX,
    QUANTUM3_ACL_MAX_ACTIONS_PER_RULE,
    QUANTUM3_ACL_MAX_ACTIONS_PER_BASIC_SET,
    QUANTUM3_ACL_MAX_ACTIONS_PER_EXTENDED_SET,
    QUANTUM3_ACL_PARSING_DEPTH,
    QUANTUM3_ACL_CUSTOM_BYTES_SET_MAX,
    QUANTUM3_ACL_CUSTOM_BYTES_SET_SIZE_MAX,
    QUANTUM3_ACL_CUSTOM_BYTES_EXTRACTION_POINT_OFFSET_MAX,
    QUANTUM3_ACL_PBILM_ENTRIES_MAX,
    QUANTUM3_ACL_KEY_BLOCKS_MAX,
    QUANTUM3_ACL_ACLS_IN_GROUPS,
    QUANTUM3_ACL_REGION_SIZE_MAX,

    /*26*/
    QUANTUM3_ROUTER_RIFS_MAX,
    QUANTUM3_ROUTER_RIFS_DONTCARE,
    QUANTUM3_ROUTER_SUB_PORT_FID_START_INDEX,
    QUANTUM3_ROUTER_IPV4_UC_MAX,
    QUANTUM3_ROUTER_IPV4_MC_MAX,
    QUANTUM3_ROUTER_IPV6_UC_MAX,
    QUANTUM3_ROUTER_IPV6_MC_MAX,
    QUANTUM3_ROUTER_ECMP_MAX,
    QUANTUM3_ROUTER_ECMP_HASH_MAX,
    QUANTUM3_ROUTER_ADJ_MAX,
    QUANTUM3_ROUTER_NEIGHS_MAX,
    QUANTUM3_ROUTER_VRID_MAX,
    QUANTUM3_ROUTER_COUNTERS_ID_MAX,
    QUANTUM3_ROUTER_NEXT_HOP_MAX,
    QUANTUM3_ROUTER_ECMP_CONTAINER_TOT_WEIGHT_MAX,
    QUANTUM3_ROUTER_MAC_PROFILES_MAX,
    QUANTUM3_ROUTER_MAC_PREFIX_SIZE,
    QUANTUM3_SHSPM_TREE_MAX,
    QUANTUM3_SHSPM_ENTRY_MAX,
    QUANTUM3_MC_RPF_GROUP_MAX,
    QUANTUM3_MC_RPF_GROUP_MAX,
    QUANTUM3_MC_RPF_GROUP_SIZE,
    QUANTUM3_MC_CONTAINERS_MAX,
    {
        .rash_ecmp_valid_size_arr = {0},
    },
    QUANTUM3_ROUTER_CAP_MAX_ARFT_ENTRIES_IN_ROW,

    /*5*/
    QUANTUM3_FCF_PORT_DENSITY_MAX,
    QUANTUM3_FCF_ZONES_PAIRS_MAX,
    QUANTUM3_FCF_ZONES_GROUPS_MAX,
    QUANTUM3_FCF_GATEWAY_MAX,
    QUANTUM3_FCF_RULES_MAX,

    /*10*/
    QUANTUM3_PORT_LCL_NUM_MAX,
    QUANTUM3_PORT_EXT_NUM_MAX,
    QUANTUM3_PORT_LOG_NUM_MAX,
    QUANTUM3_PORT_MTU_MAX,
    QUANTUM3_PORT_MTU_MIN,
    QUANTUM3_PORT_STORM_CONTROL_ID_MAX,
    QUANTUM3_PORT_VEPA_CHANNELS_NUM_MAX,
    QUANTUM3_PORT_SYSTEM_PORTS_MAX,
    QUANTUM3_PORT_SYSTEM_PORT_MODULES_MAX,
    QUANTUM3_PORT_MAP_WIDTH_MAX,
    QUANTUM3_PORT_PARSING_DEPTH_MAX,
    QUANTUM3_PORT_PARSING_DEPTH_MIN,
    QUANTUM3_PORT_TX_FIR_TAPS_MAX,

    /*6*/
    QUANTUM3_LAG_NUM_MAX,
    QUANTUM3_LAG_PORT_MEMBERS_MAX,

    QUANTUM3_SPAN_SESSION_ID_MAX,
    QUANTUM3_SPAN_SESSION_ID_MAX,
    QUANTUM3_SPAN_TRUNCATE_SIZE_MIN,
    QUANTUM3_SPAN_TRUNCATE_SIZE_MAX,
    QUANTUM3_SPAN_TRUNCATE_SIZE_GRANULARITY,

    QUANTUM3_FDB_MID_MAX,
    QUANTUM3_FDB_MID_START_INDEX,
    QUANTUM3_FDB_PGT_MAX,
    QUANTUM3_FDB_UC_ADDRESS_MAX,
    QUANTUM3_FDB_MC_ADDRESS_MAX,

    QUANTUM3_FLOODING_TABLE_MAX,
    QUANTUM3_FLOODING_TABLE_PER_VID_MAX,

    QUANTUM3_COS_TRAFFIC_CLASS_MAX,
    QUANTUM3_COS_PORT_ETS_SUB_GROUP_MAX,
    QUANTUM3_COS_PORT_ETS_GROUP_MAX,
    QUANTUM3_COS_PORT_PRIO_MAX,
    QUANTUM3_COS_PORT_COLOR_MAX,
    QUANTUM3_COS_PORT_ETS_ELEMENTS_NUM,

    QUANTUM3_COS_BUFFER_64K_SIZE_MAX,
    QUANTUM3_COS_BUFFER_128K_SIZE_MAX,

    QUANTUM3_COS_REDECN_DEFAULT_AQS_WEIGHT,
    QUANTUM3_COS_REDECN_RED_DROP_ENABLED,
    QUANTUM3_COS_REDECN_SCD,
    QUANTUM3_COS_REDECN_PROFILES_MAX,
    QUANTUM3_COS_REDECN_CELL_MULTIPLIER,
    QUANTUM3_COS_REDECN_DEFAULT_TC_RED_ENABLED,
    QUANTUM3_COS_REDECN_DEFAULT_TC_ECN_ENABLED,
    QUANTUM3_COS_REDECN_DEFAULT_TC_ECE_ENABLED,
    QUANTUM_COS_REDECN_DEFAULT_ECE_INNER_ENABLED,

    QUANTUM3_SWID_ID_MAX,

    QUANTUM3_POLICER_POOL_SIZE,
    QUANTUM3_POLICER_HOST_IFC_POOL_SIZE,
    QUANTUM3_POLICER_STORM_CONTROL_POOL_SIZE,
    QUANTUM3_POLICER_SPAN_POOL_SIZE,
    QUANTUM3_POLICER_BS_MIN_VALUE_PACKETS,
    QUANTUM3_POLICER_BS_MIN_VALUE_BYTES,
    QUANTUM3_POLICER_BS_MAX_VALUE,
    QUANTUM3_POLICER_BS_MAX_VALUE,
    QUANTUM3_POLICER_BS_MAX_VALUE,

    QUANTUM3_KVD_SIZE,
    QUANTUM3_KVD_MAX_BLOCK_SIZE,
    QUANTUM3_KVD_HASH_SINGLE_MIN_SIZE,
    QUANTUM3_KVD_HASH_DOUBLE_MIN_SIZE,
    QUANTUM3_KVD_GUARANTEED_CAPACITY,
    QUANTUM3_KVD_LINEAR_VIRTUAL_TABLE_SIZE,
    QUANTUM3_KVD_HASH_HIGH_THRESHOLD,
    QUANTUM3_KVD_HASH_LOW_THRESHOLD,
    QUANTUM3_KVD_HASH_GC_TRIGGER_THRESHOLD,
    QUANTUM3_KVD_HASH_PENDING_ENTRIES_TRIGGER_THRESOLD,

    QUANTUM3_RESERVED_EMPTY_MID,
    QUANTUM3_PGT_SIZE,
    QUANTUM3_PGT_MAX_BLOCK_SIZE,
    QUANTUM3_PGT_MAX_BLOCK_ALLOC_NUM,
    QUANTUM3_RMPE_SIZE,
    QUANTUM_FIDS_MAX,
    QUANTUM3_ARFT_NUM_REC_MAX,

    QUANTUM3_BRIDGE_NUM_MAX,

    /* Shared buffer */
    QUANTUM3_BUFFERS_TOTAL_MEMORY,
    QUANTUM3_DESCRIPTOR_BUFFERS_TOTAL_MEMORY,
    QUANTUM3_MAX_TOTAL_HEADROOM_SIZE,
    QUANTUM3_HEADROOM_NUM_BUFF_PER_PORT,

    /* Shared buffers - Condor */
    QUANTUM3_SHARED_BUFF_NUM_ING_POOL_PER_PORT,
    QUANTUM3_SHARED_BUFF_NUM_EGR_POOL_PER_PORT,
    QUANTUM3_SHARED_BUFF_NUM_MC_POOL_PER_PORT,
    QUANTUM3_SHARED_BUFF_NUM_ING_DESC_PER_PORT,
    QUANTUM3_SHARED_BUFF_NUM_EGR_DESC_PER_PORT,
    QUANTUM3_SHARED_BUFF_NUM_MANAGMENT_POOL,
    QUANTUM3_SHARED_BUFF_TOTAL_NUM_POOL,
    QUANTUM3_SHARED_HEADROOM_NUM_POOL,
    QUANTUM3_SHARED_BUFF_NUM_EGR_BUFF_PER_PORT,
    QUANTUM3_SHARED_BUFF_NUM_ING_BUFF_PER_PORT,
    QUANTUM3_SHARED_BUFF_MAX_POOL_SIZE,
    QUANTUM3_SHARED_BUFF_DEF_ING_DATA_POOL_SIZE,
    QUANTUM3_SHARED_BUFF_DEF_EGR_DATA_POOL_SIZE,
    QUANTUM3_SHARED_BUFF_DEF_ING_MGMT_POOL_SIZE,
    QUANTUM3_SHARED_BUFF_DEF_EGR_MGMT_POOL_SIZE,
    QUANTUM3_SHARED_BUFF_DEF_ING_DESC_POOL_SIZE,
    QUANTUM3_SHARED_BUFF_DEF_EGR_DESC_POOL_SIZE,

    /*** COS SB profile ***/
    {
        /** ingress data pool **/

        /* iPort.pool MIN Configuration */
        (10 * 1024),

        /* iPort.pool MAX Configuration */
        QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,

        /* iPort.PGs MIN Configuration */
        {
            /* { size, is_lossy, xon, xoff, override_headroom, headroom (in jumbo frames) } */
            { 0, TRUE, 0, 0, FALSE, 0 },                 /* PG 0*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 1*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 2*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 3*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 4*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 5*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 6*/
            { 0, TRUE, 0, 0, TRUE, 0 },                  /* PG 7*/
            { 0, 0, 0, 0, 0, 0 },                        /* reserved */
            { (10 * 1024), TRUE, 0, 0, TRUE, 1 },        /* PG 9 - Control */
        },

        /* iPort.PGs MAX Configuration */
        {
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* PG 0*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 1*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 2*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 3*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 4*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 5*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 6*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_0_E,       /* PG 7*/
            0,                                         /* reserved*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E        /* PG 9 - Control*/
        },

        /** egress data pool **/

        /* ePort.pool MIN Configuration */
        (10 * 1024),

        /* ePort.pool MAX Configuration */
        QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,

        /* ePort.TCs MIN Configuration */
        {
            (1 * 1024),       /* TC 0 */
            (1 * 1024),       /* TC 1 */
            (1 * 1024),       /* TC 2 */
            (1 * 1024),       /* TC 3 */
            (1 * 1024),       /* TC 4 */
            (1 * 1024),       /* TC 5 */
            (1 * 1024),       /* TC 6 */
            (1 * 1024),       /* TC 7 */
            (1 * 1024),       /* TC 8 */
            (1 * 1024),       /* TC 9 */
            (1 * 1024),       /* TC 10 */
            (1 * 1024),       /* TC 11 */
            (1 * 1024),       /* TC 12 */
            (1 * 1024),       /* TC 13 */
            (1 * 1024),       /* TC 14 */
            (1 * 1024),       /* TC 15 */
            (1 * 1024)        /* TC 16 - Control */
        },

        /* ePort.TCs MAX Configuration */
        {
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 0 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 1 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 2 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 3 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 4 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 5 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 6 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 7 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 8 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 9 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 10 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 11 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 12 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 13 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 14 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,       /* TC 15 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E        /* TC 16 - control*/
        },

        /* MC.SPs MIN Configuration */
        {
            0,       /* SP 0 */
            0,       /* SP 1 */
            0,       /* SP 2 */
            0,       /* SP 3 */
            0,       /* SP 4 */
            0,       /* SP 5 */
            0,       /* SP 6 */
            0,       /* SP 7 */
            0,       /* SP 8 */
            0,       /* SP 9 */
            0,       /* SP 10 */
            0,       /* SP 11 */
            0,       /* SP 12 */
            0,       /* SP 13 */
            0        /* SP 14 */
        },

        /* MC.SPs MAX Configuration */
        {
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 0 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 1 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 2 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 3 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 4 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 5 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 6 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 7 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 8 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 9 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 10 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 11 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 12 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E,       /* SP 13 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_1_4_E        /* SP 14 */
        },

        /** ingress management pool **/

        /* iPort_mgmt.pool MIN Configuration */
        0,

        /* iPort_mgmt.pool MAX Configuration */
        QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,

        /** egress management pool **/

        /* ePort_mgmt.pool MIN Configuration */
        0,

        /* ePort_mgmt.pool MAX Configuration */
        QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,

        /* CPU_port.TCs (0-6) MIN Configuration */
        (1 * 1024),

        /* CPU_port.TCs (0-6) MAX Configuration */
        QUANTUM3_SHARED_BUFF_MAX_ALPHA_8_E,

        /** multicast pool **/

        /* ePort.MC_pool MIN Configuration */
        (10 * 1024),

        /* ePort.MC_pool MAX Configuration */
        (90 * 1024),

        /* ePort.MC_pool MIN Configuration (MC aware == TRUE) */
        {
            0,       /* TC 8 */
            0,       /* TC 9 */
            0,       /* TC 10 */
            0,       /* TC 11 */
            0,       /* TC 12 */
            0,       /* TC 13 */
            0,       /* TC 14 */
            0        /* TC 15 */
        },

        /* ePort.MC_pool MAX Configuration (MC aware == TRUE): size is taken from pool properties (100%) */
        {
            QUANTUM3_SHARED_BUFF_FULL_POOL,       /* TC 8 */
            QUANTUM3_SHARED_BUFF_FULL_POOL,       /* TC 9 */
            QUANTUM3_SHARED_BUFF_FULL_POOL,       /* TC 10 */
            QUANTUM3_SHARED_BUFF_FULL_POOL,       /* TC 11 */
            QUANTUM3_SHARED_BUFF_FULL_POOL,       /* TC 12 */
            QUANTUM3_SHARED_BUFF_FULL_POOL,       /* TC 13 */
            QUANTUM3_SHARED_BUFF_FULL_POOL,       /* TC 14 */
            QUANTUM3_SHARED_BUFF_FULL_POOL        /* TC 15 */
        },

        /** ingress descriptor pool (1 lane) **/

        /* iPort_desc.pool MIN Configuration */
        5,

        /* iPort_desc.pool MAX Configuration */
        QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,

        /* iPort_desc.PGs MIN Configuration */
        {
            1,       /* PG 0*/
            1,       /* PG 1*/
            1,       /* PG 2*/
            1,       /* PG 3*/
            1,       /* PG 4*/
            1,       /* PG 5*/
            1,       /* PG 6*/
            1,       /* PG 7*/
            0,       /* reserved*/
            1        /* PG 9 - Control*/
        },

        /* iPort_desc.PGs MAX Configuration */
        {
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 0*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 1*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 2*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 3*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 4*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 5*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 6*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 7*/
            0,                                                /* reserved*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E        /* PG 9 - Control*/
        },

        /** egress descriptor pool (1 lane) **/

        /* ePort_desc.pool MIN Configuration */
        48,

        /* ePort_desc.pool MAX Configuration */
        QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,

        /* ePort_desc.TCs MIN Configuration */
        {
            5,       /* TC 0 */
            5,       /* TC 1 */
            5,       /* TC 2 */
            5,       /* TC 3 */
            5,       /* TC 4 */
            5,       /* TC 5 */
            5,       /* TC 6 */
            5,       /* TC 7 */
            5,       /* TC 8 */
            5,       /* TC 9 */
            5,       /* TC 10 */
            5,       /* TC 11 */
            5,       /* TC 12 */
            5,       /* TC 13 */
            5,       /* TC 14 */
            5,       /* TC 15 */
            5        /* TC 16 - control*/
        },

        /* ePort_desc.TCs MAX Configuration */
        {
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 0 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 1 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 2 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 3 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 4 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 5 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 6 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 7 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 8 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 9 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 10 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 11 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 12 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 13 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 14 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 15 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E        /* TC 16 - control*/
        },

        /** ingress descriptor pool (4 lanes) **/

        /* iPort_desc.pool MIN Configuration */
        5,

        /* iPort_desc.pool MAX Configuration */
        QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,

        /* iPort_desc.PGs MIN Configuration */
        {
            1,       /* PG 0*/
            1,       /* PG 1*/
            1,       /* PG 2*/
            1,       /* PG 3*/
            1,       /* PG 4*/
            1,       /* PG 5*/
            1,       /* PG 6*/
            1,       /* PG 7*/
            0,       /* reserved*/
            1        /* PG 9 - Control*/
        },

        /* iPort_desc.PGs MAX Configuration */
        {
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 0*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 1*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 2*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 3*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 4*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 5*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 6*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* PG 7*/
            0,                                                /* reserved*/
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E        /* PG 9 - Control*/
        },

        /** egress descriptor pool (4 lanes) **/

        /* ePort_desc.pool MIN Configuration */
        96,

        /* ePort_desc.pool MAX Configuration */
        QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,

        /* ePort_desc.TCs MIN Configuration */
        {
            5,       /* TC 0 */
            5,       /* TC 1 */
            5,       /* TC 2 */
            5,       /* TC 3 */
            5,       /* TC 4 */
            5,       /* TC 5 */
            5,       /* TC 6 */
            5,       /* TC 7 */
            5,       /* TC 8 */
            5,       /* TC 9 */
            5,       /* TC 10 */
            5,       /* TC 11 */
            5,       /* TC 12 */
            5,       /* TC 13 */
            5,       /* TC 14 */
            5,       /* TC 15 */
            5        /* TC 16 - control*/
        },

        /* ePort_desc.TCs MAX Configuration */
        {
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 0 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 1 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 2 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 3 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 4 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 5 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 6 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 7 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 8 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 9 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 10 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 11 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 12 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 13 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 14 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E,       /* TC 15 */
            QUANTUM3_SHARED_BUFF_MAX_ALPHA_INFINITY_E        /* TC 16 - control*/
        }
    },

    QUANTUM3_SHARED_BUFF_PORT_NUM_MAX,
    QUANTUM3_SHARED_BUFF_TCLASS_NUM_MAX,
    QUANTUM3_SHARED_BUFF_RET_STATISTICS_NUM_MAX,
    QUANTUM3_BUFF_UNIT_SIZE,
    QUANTUM3_SHARED_BUFF_MC_MAX_NUM_PRIO,
    QUANTUM3_MAX_SHARED_HEADROOM_POOL_SIZE,

    {
        /* RM_SDK_TABLE_TYPE_UC_MAC_E */
        {QUANTUM3_FDB_UC_ADDRESS_MAX,
         QUANTUM3_FDB_UC_ADDRESS_MAX,
         QUANTUM3_FDB_UC_MAC_HW_ENTRY_COST,
         QUANTUM3_FDB_UC_MAC_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_MC_MAC_E */
        {QUANTUM3_FDB_MC_ADDRESS_MAX,
         QUANTUM3_FDB_MC_ADDRESS_MAX,
         QUANTUM3_FDB_MC_MAC_HW_ENTRY_COST,
         QUANTUM3_FDB_MC_MAC_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV4_UC_E */
        {QUANTUM3_ROUTER_IPV4_UC_MAX,
         QUANTUM3_ROUTER_IPV4_UC_MAX,
         QUANTUM3_ROUTER_IPV4_UC_HW_ENTRY_COST,
         QUANTUM3_ROUTER_IPV4_UC_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV6_UC_E */
        {QUANTUM3_ROUTER_IPV6_UC_MAX,
         QUANTUM3_ROUTER_IPV6_UC_MAX,
         QUANTUM3_ROUTER_IPV6_UC_HW_ENTRY_COST,
         QUANTUM3_ROUTER_IPV6_UC_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV6_SHORT_UC_E */
        {QUANTUM3_ROUTER_IPV6_SHORT_UC_MAX,
         QUANTUM3_ROUTER_IPV6_SHORT_UC_MAX,
         QUANTUM3_ROUTER_IPV6_SHORT_UC_HW_ENTRY_COST,
         QUANTUM3_ROUTER_IPV6_SHORT_UC_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV6_LONG_UC_E */
        {QUANTUM3_ROUTER_IPV6_LONG_UC_MAX,
         QUANTUM3_ROUTER_IPV6_LONG_UC_MAX,
         QUANTUM3_ROUTER_IPV6_LONG_UC_HW_ENTRY_COST,
         QUANTUM3_ROUTER_IPV6_LONG_UC_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV4_MC_E */
        {QUANTUM3_ROUTER_IPV4_MC_MAX,
         QUANTUM3_ROUTER_IPV4_MC_MAX,
         QUANTUM3_ROUTER_IPV4_MC_HW_ENTRY_COST,
         QUANTUM3_ROUTER_IPV4_MC_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV6_MC_E */
        {QUANTUM3_ROUTER_IPV6_MC_MAX,
         QUANTUM3_ROUTER_IPV6_MC_MAX,
         QUANTUM3_ROUTER_IPV6_MC_HW_ENTRY_COST,
         QUANTUM3_ROUTER_IPV6_MC_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ARP_IPV4_E */
        {QUANTUM3_ROUTER_NEIGHS_MAX,
         QUANTUM3_ROUTER_NEIGHS_MAX,
         QUANTUM3_ROUTER_ARP_IPV4_HW_ENTRY_COST,
         QUANTUM3_ROUTER_ARP_IPV4_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ARP_IPV6_E */
        {QUANTUM3_ROUTER_NEIGHS_MAX,
         QUANTUM3_ROUTER_NEIGHS_MAX,
         QUANTUM3_ROUTER_ARP_IPV6_HW_ENTRY_COST,
         QUANTUM3_ROUTER_ARP_IPV6_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_L3_MC_REPLICATIONS_E */
        {QUANTUM3_TOTAL_L3_REPLICATION_MATRIX,
         QUANTUM3_TOTAL_L3_REPLICATION_MATRIX,
         QUANTUM3_ROUTER_MC_REPLICATIONS_HW_ENTRY_COST,
         QUANTUM3_ROUTER_MC_REPLICATIONS_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ADJACENCY_E */
        {QUANTUM3_ROUTER_ADJ_MAX,
         QUANTUM3_ROUTER_ADJ_MAX,
         QUANTUM3_ROUTER_ADJACENCY_HW_ENTRY_COST,
         QUANTUM3_ROUTER_ADJACENCY_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_L2_MC_VECTORS_E */
        {QUANTUM3_FDB_MID_MAX,
         QUANTUM3_FDB_MID_MAX,
         QUANTUM3_L2_MC_MIDS_HW_ENTRY_COST,
         QUANTUM3_L2_MC_MIDS_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_LAG_VECTORS_E */
        {QUANTUM3_LAG_VECTORS_NUM_MAX,
         QUANTUM3_LAG_VECTORS_NUM_MAX,
         QUANTUM3_LAG_VECTORS_ENTRY_COST,
         QUANTUM3_LAG_VECTORS_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FLOOD_VECTORS_E */
        {QUANTUM3_FLOODING_TABLE_MAX,
         QUANTUM3_FLOODING_TABLE_MAX,
         QUANTUM3_L2_MC_FLOODING_HW_ENTRY_COST,
         QUANTUM3_L2_MC_FLOODING_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},


        /* RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E */
        {QUANTUM3_ACL_EXTENDED_ACTIONS_NUM_MIN,
         QUANTUM3_ACL_EXTENDED_ACTIONS_NUM_MAX,
         QUANTUM3_ACL_EXTENDED_ACTIONS_HW_ENTRY_COST,
         QUANTUM3_ACL_EXTENDED_ACTIONS_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_PBS_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ERIF_LIST_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_TUNNEL_RTDP_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},


        /* RM_SDK_TABLE_TYPE_ILM_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_RPF_GROUP_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_VLAN_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_VPORTS_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FID_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_VNI_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_TUNNEL_IPV6_FDB_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_MPLS_NHLFE_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_NVE_IPV6_LIST_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_RIPS_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_IGMP_V3_IPv4_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_IGMP_V3_IPv6_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_DECAP_RULES_IPv4_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_DECAP_RULES_IPv6_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_RIF_COUNTER_BASIC_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_RIF_COUNTER_MIXED_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_RIF_COUNTER_ENHANCED_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FLOW_COUNTER_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_GROUPS_E */
        {QUANTUM3_ACL_GROUPS_NUM_MIN,
         QUANTUM3_ACL_GROUPS_NUM_MAX,
         QUANTUM3_ACL_GROUPS_HW_ENTRY_COST,
         QUANTUM3_ACL_GROUPS_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FLEX_PARSER_TRANSITION_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FLEX_PARSER_PROGRAM_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FLEX_MODIFIER_EMT_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_SPAN_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_GP_REGISTER_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_AR_LOCAL_PORT_GRP_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_AR_FLOWS_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_NAT_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_STATEFUL_DB_PARTITION_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_COMPRESSED_FID_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_COMPRESSED_RFID_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_LAG_TABLE_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FINE_GRAIN_LAG_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ARN_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_INTERNAL_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACL_RULES_E */
        {QUANTUM3_ACL_RULES_NUM_MIN,
         QUANTUM3_ACL_RULES_NUM_MAX,
         QUANTUM3_ACL_RULES_HW_ENTRY_COST,
         QUANTUM3_ACL_RULES_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_DECAP_RULES_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_IGMP_V3_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_A_TCAM_ONE_KEY_BLOCK_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_A_TCAM_TWO_KEYS_BLOCK_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_A_TCAM_FOUR_KEYS_BLOCK_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_A_TCAM_SIX_KEYS_BLOCK_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FCF_FORWORDING_E */
        {QUANTUM3_FCF_RULES_MAX,
         QUANTUM3_FCF_RULES_MAX,
         QUANTUM3_FCF_FORWORDING_HW_ENTRY_COST,
         QUANTUM3_FCF_FORWORDING_HW_TABLE_TYPE,
         QUANTUM3_INVALID_SW_TABLE_TYPE,
         FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_RMID_MANAGER_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_NVE_MC_LIST_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_SMID_MANAGER_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV4_MC_SYSTEM_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_FIB_IPV6_MC_SYSTEM_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_RIF_COUNTER_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_IGMP_V3_PRUNE_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_C_TCAM_TWO_KEYS_BLOCK_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /*  RM_SDK_TABLE_TYPE_A_TCAM_FOUR_KEYS_BLOCK_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_C_TCAM_SIX_KEYS_BLOCK_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_IGMP_V3_PRUNE_IPV6_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_RULES_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_COUNTER_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_PORT_MACSEC_SADB_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_RULE_KEY_WIDTH_9B_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_RULE_KEY_WIDTH_18B_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_RULE_KEY_WIDTH_36B_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},

        /* RM_SDK_TABLE_TYPE_PORT_MACSEC_ACL_RULE_KEY_WIDTH_54B_E */
        {0, 0, 0, 0, QUANTUM3_INVALID_SW_TABLE_TYPE, FALSE, FALSE},
    },

    {
        {TRUE, QUANTUM3_TOTAL_TCAM},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {TRUE, QUANTUM3_ROUTER_ADJ_MAX},
        {TRUE, QUANTUM3_TOTAL_L3_REPLICATION_MATRIX},
        {TRUE, QUANTUM3_ACL_GROUPS_NUM_MAX},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},
        {FALSE, 0},

        /* RM_HW_TABLE_TYPE_ACCUFLOW_COUNTER_E */
        { FALSE, 0 },
        /* RM_HW_TABLE_TYPE_MACSEC_UTCAM_E */
        { FALSE, 0 },
        /* RM_HW_TABLE_TYPE_MACSEC_UTCAM_COUNTER_E */
        { FALSE, 0 },
        /* RM_HW_TABLE_TYPE_MACSEC_USADB_E */
        { FALSE, 0 },
    },

    /*16*/
    QUANTUM3_CNTR_BANK_PAIRS,
    QUANTUM3_CNTR_LINES_PER_BANK,
    QUANTUM3_CNTR_LINES_PER_BANK,
    QUANTUM3_CNTR_LINES_RESERVED_PER_BANK,
    QUANTUM3_CNTR_LINES_FLOW_PKT,
    QUANTUM3_CNTR_TYPE_FLOW_PKT,
    QUANTUM3_CNTR_LINES_FLOW_BYTE,
    QUANTUM3_CNTR_TYPE_FLOW_BYTE,
    QUANTUM3_CNTR_LINES_FLOW_BOTH,
    QUANTUM3_CNTR_TYPE_FLOW_BOTH,
    0, 0, 0, 0, 0,  /* flow estimator is not supported */
    QUANTUM3_CNTR_LINES_RIF_BASIC,
    QUANTUM3_CNTR_TYPE_RIF_BASIC,
    QUANTUM3_CNTR_LINES_RIF_MIXED_1,
    QUANTUM3_CNTR_TYPE_RIF_MIXED_1,
    QUANTUM3_CNTR_LINES_RIF_MIXED_2,
    QUANTUM3_CNTR_TYPE_RIF_MIXED_2,
    QUANTUM3_CNTR_LINES_RIF_ENHANCED,
    QUANTUM3_CNTR_TYPE_RIF_ENHANCED,
    0, 0, 0, 0, 0, 0, 0, 0, /* reduced counter type is not supported */
    QUANTUM3_ACCUFLOW_CNTR_BANKS,
    QUANTUM3_ACCUFLOW_CNTR_LINES_PER_BANK,
    QUANTUM3_ACCUFLOW_CNTR_LINES_PER_HW_BANK,
    QUANTUM3_ACCUFLOW_CNTR_LINES_RESERVED_PER_BANK,
    QUANTUM3_ACCUFLOW_CNTR_LINES_FLOW_BOTH,
    QUANTUM3_ACCUFLOW_CNTR_TYPE_FLOW_BOTH,
    QUANTUM3_ACCUFLOW_CNTR_START_IDX_OFFSET,

    /*10*/
    QUANTUM3_IB_PKEYS_TABLE_SIZE,


    QUANTUM3_IB_ROUTER_LIDS_MAX,
    QUANTUM3_IB_ROUTER_MC_LIDS_NUM_MAX,
    QUANTUM3_IB_ROUTER_UC_LID_NUM_MAX,

    /*1*/
    QUANTUM3_IB_PORTS_MAX,

    /*5*/
    QUANTUM3_NUM_HW_CPU_INGRESS_TCLASS_MAX,
    QUANTUM3_NUM_HW_DR_PATHS_MAX,
    QUANTUM3_NUM_HW_TRAP_GROUPS_MAX,
    QUANTUM3_NUM_HW_TOTAL_TRAP_GROUPS_MAX,
    QUANTUM3_TRAP_GROUP_PRIORITY_MIN,
    QUANTUM3_TRAP_GROUP_PRIORITY_MAX,
    QUANTUM3_NUM_RDQS_MAX,
    QUANTUM3_NUM_CPU_TCLASS,

    /* Tunnel */
    QUANTUM3_NUM_MAX_TUNNEL_IPINIP,
    QUANTUM3_NUM_MAX_TUNNEL_NVE,
    QUANTUM3_NUM_MAX_TUNNEL_L2_FLEX,
    QUANTUM3_TUNNEL_NVE_GS_FLOOD_MAX,
    QUANTUM3_TUNNEL_NVE_GS_MC_MAX,
    QUANTUM3_TUNNEL_TNUMT_IPV6_RECORDS_MAX,

    /* IGMP V3 */
    QUANTUM3_IGMP_V3_NUM_MAX_ENTRIES,

    /* Telemetry */
    QUANTUM3_TELE_HISTOGRAM_NUM_MAX,
    QUANTUM3_TELE_HISTOGRAM_QUEUE_DEPTH_BINS,
    QUANTUM3_TELE_HISTOGRAM_SAMPLE_TIME_RESOLUTION_MAX,
    QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LINEAR_MIN,
    QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_EXPONENT_MIN,
    QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_QUEUE_DEPTH_LINEAR_MAX,
    QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_QUEUE_DEPTH_EXPONENT_MAX,
    QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LATENCY_LINEAR_MAX,
    QUANTUM3_TELE_HISTOGRAM_BIN_SIZE_RESOLUTION_LATENCY_EXPONENT_MAX,
    QUANTUM3_TELE_HISTOGRAM_DATA_BIN_BITS_MAX,
    QUANTUM3_TELE_HISTOGRAM_MIN_BOUNDARY_MIN,
    QUANTUM3_TELE_THRESHOLD_THR_MAX,
    QUANTUM3_TELE_THRESHOLD_LATENCY_THR_MAX,
    QUANTUM3_TELE_THRESHOLD_LATENCY_TABLE_SIZE,

    /* BFD */
    QUANTUM3_BFD_SESSION_NUM_MAX,

    /* Register module */
    QUANTUM3_GP_REGISTER_NUM_MAX,
    QUANTUM3_GP_REGISTER_HASH_NUM_MAX,

    /* Port profile */
    QUANTUM3_INFRA_PROFILE_BASE_LOCAL_PORT_INVALID,
    /* STP */
    QUANTUM3_STP_FAST_RECORDS_NUM_MAX,
    /* Port group */
    QUANTUM3_EGRESS_GROUP_TOTAL_PORTS,

    /* Stateful DB */
    QUANTUM3_STATEFUL_DB_PARTITION_MAX_EXCEED_KVD,

    /* General Purpose RAM */
    QUANTUM3_GP_RAM_SIZE,
    /* Flood mode */
    QUANTUM3_CONFIG_PROFILE_FLOOD_MODE,
    /* lag_table_mngr */
    QUANTUM3_CONFIG_PROFILE_LAG_TABLE_MNGR,
    /* ddd_lag_table */
    QUANTUM3_CONFIG_PROFILE_DDD_LAG_TABLE,

    /* Truncation-Profile*/
    QUANTUM3_TRUNCATION_PROFILE_SPAN_TOTAL_NUM,
    QUANTUM3_TRUNCATION_PROFILE_ACL_TOTAL_NUM,
    QUANTUM3_TRUNCATION_PROFILE_STATIC_TRUNC_SIZE_MIN,
    QUANTUM3_TRUNCATION_PROFILE_STATIC_TRUNC_SIZE_WHEN_MASKING_MAX,
    QUANTUM3_TRUNCATION_PROFILE_STATIC_TRUNC_GRANULARITY,
    QUANTUM3_TRUNCATION_PROFILE_MASKING_ADDITIONAL_OFFSET_MAX,
    QUANTUM3_TRUNCATION_PROFILE_MASKING_ADDITIONAL_OFFSET_GRANULARITY,

    /* Adaptive Routing */
    QUANTUM3_ADAPTIVE_ROUTING_TCLASS_NUM,
};
/************************************************
 *  Function declarations
 ***********************************************/


#endif /*__SWITCH_QUANTUM3_H__*/
