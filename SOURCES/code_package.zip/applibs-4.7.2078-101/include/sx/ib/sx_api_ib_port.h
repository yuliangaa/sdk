/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */

#ifndef SX_API_IB_PORT_H_
#define SX_API_IB_PORT_H_

#include <sx/sdk/sx_api.h>
#include <sx/ib/sx_ib_port.h>
#include <sx/sdk/sx_strings.h>

/**
 *      This API Initializes the IB Port in the SDK.
 ******************************************************************************
 * Supported devices: SwitchX, SwitchX2, SwitchIB.
 * @param[in] handle - SX-API handle.
 * @param[in] log_port - Logical Port ID.
 * @param[in] ib_port - Ib Port ID.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_MESSAGE_SIZE_ZERO: Message size error.
 * @return SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT: Message size error.
 * @return SX_STATUS_COMM_ERROR: Communication error - send fail.
 * @return SX_STATUS_INVALID_HANDLE: Invalid Handle.
 */
sx_status_t sx_api_ib_port_init(const sx_api_handle_t  handle,
                                const sx_port_log_id_t log_port,
                                const sx_ib_port_id_t  ib_port);

#endif /* SX_API_IB_PORT_H_ */
