/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */

#ifndef SX_IB_ROUTER_H_
#define SX_IB_ROUTER_H_

#include <sx/sdk/sx_access_cmd.h>
#include <sx/sdk/sx_router.h>
/**
 * SX_LMC_MAX notes MAX valid value of lmc.
 */

/**
 * SX_LID_MAX notes MAX valid value of lid.
 */
#define SX_IB_ADDR_LEN_BYTES 16

/**
 * minimum/maximum UC lid values.
 */

/**
 * minimum/maximum MC lid values.
 */

#define SX_UC_LID_MIN    0x0001
#define SX_UC_MY_LID_MAX 0x7f
#define SX_UC_MYLID_CHECK_RANGE(LID) SX_CHECK_MAX(LID, SX_UC_MY_LID_MAX)
/**
 * minimum/maximum Pkey values.
 */

/**
 * minimum/maximum Qpn values.
 */

typedef uint16_t sx_pkey_t;
typedef uint32_t sx_qkey_t;
typedef uint32_t sx_qpn_t;

typedef uint16_t sx_lid_t;
typedef uint8_t sx_sl_t;

typedef uint8_t sx_lmc_t;

struct ib_addr {
    uint8_t addr_octet[SX_IB_ADDR_LEN_BYTES];
} __attribute__ ((__packed__));

typedef struct ib_addr sx_gid_t;

/**
 * ib_l2_router_interface_t structure is used to note Layer 2 IB
 * interface attributes.
 */
typedef struct sx_ib_l2_router_interface {
    sx_swid_t swid;         /**< Switch ID */
    sx_pkey_t pkey;         /**< P_Key value */
    sx_qkey_t qkey;         /**< Q_Key value */
    sx_qpn_t  qpn;          /**< local QPn */
    uint16_t  mtu;          /**< MTU */
    uint8_t   multicast_ttl_threshold; /**<TTL threshold */
    uint8_t   scope;        /**<Multicast GID scope */
} sx_ib_l2_router_interface_t;

/**
 * sx_ib_adjacency is used to store ib neighbor information.
 */
typedef struct sx_ib_adjacency {
    sx_lid_t dlid;          /**< Dest LID - path to neighbor*/
    sx_sl_t  sl;            /**< SL - path to neighbor*/
    sx_qpn_t dqpn;          /**< Neighbor QPn */
    sx_lid_t my_lid;        /**< alters local LID per neighbor*/
    uint8_t  is_grh;        /**< Specify whether this entry is a GRH neighbor */
    sx_gid_t dgid;          /**< Neighbor GID, relevant only for GRH neighbors */
} sx_ib_adjacency_t;

/**
 * sx_ib_router_attr_t structure is used to store the router attributes.
 */
typedef struct sx_ib_router_attr {
    sx_lmc_t lmc;           /**< lmc  - Lid Mask Count*/
    uint8_t  lmc_valid;     /**< lmc_valid - On EDIT event, identifies if this field needs to be updated.*/
    sx_lid_t lid;           /**< lid  - Base LID for the port*/
    uint8_t  lid_valid;     /**< lid_valid - On EDIT event, identifies if this field needs to be updated.*/
    sx_gid_t gid;           /**< gid  - Global ID*/
} sx_ib_router_attr_t;

/**
 * sx_api_ib_router_set_attr structure is used to store SX-API
 * IB Router Attributes set function parameters.
 */
typedef struct sx_api_ib_router_set_attr {
    sx_access_cmd_t     cmd;                /**< SX ACCESS COMMAND    */
    sx_swid_t           swid;               /**< Switch partition ID  */
    sx_ib_router_attr_t sx_ib_router_attr;  /**< Router attributes structure:  lid, lid_valid, lmc, lmc_valid and gid.*/
} sx_api_ib_router_set_attr_t;

typedef sx_api_ib_router_set_attr_t sx_api_ib_router_get_attr_t;

/**
 * sx_router_resources_param_t is used to store the routers resources
 * allocation parameters.
 */
typedef struct sx_vpi_router_resources_param {
    uint32_t max_virtual_routers_num;
    uint32_t max_vlan_router_interfaces;
    uint32_t max_port_router_interfaces;
    uint32_t max_pkey_router_interfaces;
    uint32_t max_router_interfaces;
    uint32_t min_ipv4_eth_neighbor_entries;
    uint32_t min_ipv6_eth_neighbor_entries;
    uint32_t min_ipv4_ib_neighbor_entries;
    uint32_t min_ipv6_ib_neighbor_entries;
    uint32_t min_ipv4_uc_route_entries;
    uint32_t min_ipv6_uc_route_entries;
    uint32_t min_ipv4_mc_route_entries;
    uint32_t min_ipv6_mc_route_entries;
    uint32_t max_ipv4_eth_neighbor_entries;
    uint32_t max_ipv6_eth_neighbor_entries;
    uint32_t max_ipv4_ib_neighbor_entries;
    uint32_t max_ipv6_ib_neighbor_entries;
    uint32_t max_ipv4_uc_route_entries;
    uint32_t max_ipv6_uc_route_entries;
    uint32_t max_ipv4_mc_route_entries;
    uint32_t max_ipv6_mc_route_entries;
} sx_vpi_router_resources_param_t;

/**
 * sx_router_general_param is used to store the routers general
 * configuration parameters.
 */
typedef struct sx_vpi_router_general_param {
    boolean_t ipv4_enable;
    boolean_t ipv6_enable;
    boolean_t ipv4_mc_enable;
    boolean_t ipv6_mc_enable;
    boolean_t rpf_enable;
    boolean_t ipoib_broadcast_enable;
    boolean_t ipoib_allrouters_enable;
    boolean_t mc_single_egress_rif_enable; /**< If set, this flag limits MC routes to one egress router interface. Setting this flag allows raising the total MC routes */
    uint8_t   grh_hop_limit; /**< Default value of hop limit field. setting this field to zero means using SDK default */
} sx_vpi_router_general_param_t;

/**
 * sx_mc_ipoib_adj_t is used to store an IPoIB MC adjacency
 * entry.
 */
typedef struct {
    sx_router_interface_t rif;  /* pkey rif */
    sx_lid_t              mlid; /* Destination Local ID   */
    sx_sl_t               sl; /* Service Level */
    uint8_t               hoplimit; /* Hop Limit - Deprecated */
    uint8_t               tclass; /* Traffic Class  */
} sx_mc_ipoib_adj_t;

/**
 * sx_api_ib_router_set_attr structure is used to store SX-API
 * IB Router Attributes set function parameters.
 */
typedef struct sx_api_ib_router_mc_egress_rif_set_params {
    sx_access_cmd_t       cmd;
    sx_router_id_t        vrid;
    sx_ip_prefix_t        source_addr;
    sx_ip_prefix_t        mc_group_addr;
    sx_router_interface_t ingress_rif;
    uint32_t              adj_num;
    sx_mc_ipoib_adj_t     mc_ipoib_adj_arr[0];
} sx_api_ib_router_mc_egress_rif_set_params_t;

typedef sx_api_ib_router_mc_egress_rif_set_params_t sx_api_ib_router_mc_egress_rif_get_params_t;
#endif /* SX_IB_ROUTER_H_ */
