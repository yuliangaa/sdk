/*
 * Copyright (C) 2014-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */
#ifndef __SX_TUNNEL_ID_H__
#define __SX_TUNNEL_ID_H__

#include "sx/sdk/auto_headers/sx_tunnel_id_auto.h"


/************************************************
 *  Type definitions
 ***********************************************/

#define SX_GENERATE_ENUM(ENUM, STR) ENUM,

#define SX_TUNNEL_NUM_MAX                                                               \
    (rm_resource_global.tunnel_ipinip_num_max + rm_resource_global.tunnel_nve_num_max + \
     rm_resource_global.tunnel_l2_flex_num_max)

/**
 * General Helpers for tunnels
 */
#define SX_TUNNEL_IDENTIFIER_CLR(id) \
    ((id) &= ~SX_TUNNEL_IDENTIFIER_MASK)
#define SX_TUNNEL_TYPE_ID_CLR(id) \
    ((id) &= ~SX_TUNNEL_TYPE_ID_MASK)
#define SX_TUNNEL_DIRECTION_CLR(id) \
    ((id) &= ~SX_TUNNEL_DIRECTION_MASK)
#define SX_TUNNEL_IDENTIFIER_SET(id, identifier) \
    ((id & ~SX_TUNNEL_IDENTIFIER_MASK) | (identifier))
#define SX_TUNNEL_TYPE_ID_SET(id, type) \
    ((id & ~SX_TUNNEL_TYPE_ID_MASK) | ((type) << SX_TUNNEL_TYPE_ID_OFFSET))
#define SX_TUNNEL_DIRECTION_SET(id, type) \
    ((id & ~SX_TUNNEL_DIRECTION_MASK) | ((type) << SX_TUNNEL_DIRECTION_OFFSET))
#define SX_TUNNEL_IDENTIFIER_GET(tunnel_id) \
    ((tunnel_id) & SX_TUNNEL_IDENTIFIER_MASK)
#define SX_TUNNEL_TYPE_ID_GET(tunnel_id) \
    (((tunnel_id) & SX_TUNNEL_TYPE_ID_MASK) >> SX_TUNNEL_TYPE_ID_OFFSET)
#define SX_TUNNEL_DIRECTION_GET(tunnel_id) \
    (((tunnel_id) & SX_TUNNEL_DIRECTION_MASK) >> SX_TUNNEL_DIRECTION_OFFSET)
#define SX_TUNNEL_TYPE_CHECK_RANGE(tunnel_type) \
    SX_CHECK_MAX(tunnel_type, SX_TUNNEL_TYPE_MAX)
#define SX_TUNNEL_DIRECTION_CHECK_RANGE(tunnel_direction) \
    SX_CHECK_RANGE(SX_TUNNEL_DIRECTION_MIN, tunnel_direction, SX_TUNNEL_DIRECTION_MAX)
#define SX_TUNNEL_TYPE_ID_CHECK(tunnel_id, tunnel_type) \
    (SX_TUNNEL_TYPE_ID_GET(tunnel_id) == tunnel_type)
#define SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id) \
    (SX_TUNNEL_DIRECTION_GET(tunnel_id) & SX_TUNNEL_DIRECTION_ENCAP)
#define SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id) \
    (SX_TUNNEL_DIRECTION_GET(tunnel_id) & SX_TUNNEL_DIRECTION_DECAP)
#define SX_TUNNEL_TYPE_ID_PROTO_CHECK(tunnel_id, range_min, range_max) \
    SX_CHECK_RANGE((range_min), SX_TUNNEL_TYPE_ID_GET(tunnel_id), (range_max))
#define SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)                                  \
    (SX_CHECK_MAX(SX_TUNNEL_IDENTIFIER_GET(tunnel_id), SX_TUNNEL_NUM_MAX) && \
     SX_TUNNEL_TYPE_CHECK_RANGE(SX_TUNNEL_TYPE_ID_GET(tunnel_id)) &&         \
     SX_CHECK_MIN(SX_TUNNEL_DIRECTION_MIN, SX_TUNNEL_DIRECTION_GET(tunnel_id)))
#define SX_TUNNEL_VNI_RANGE_CHECK(vni) \
    (SX_CHECK_MAX((vni), SX_TUNNEL_VNI_VALUE_MAX))
#define SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(check) \
    SX_CHECK_MAX(check, SX_TUNNEL_NVE_RESERVED_BITS_MODE_MAX_E)

/**
 * Type specific helpers.
 */
#define SX_TUNNEL_TYPE_IPINIP_CHECK(tunnel_id) \
    SX_CHECK_MAX(SX_TUNNEL_TYPE_ID_GET(tunnel_id), SX_TUNNEL_TYPE_IPINIP_MAX)
#define SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id)               \
    SX_TUNNEL_TYPE_ID_PROTO_CHECK(tunnel_id,              \
                                  SX_TUNNEL_TYPE_NVE_MIN, \
                                  SX_TUNNEL_TYPE_NVE_MAX)
#define SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)               \
    SX_TUNNEL_TYPE_ID_PROTO_CHECK(tunnel_id,                  \
                                  SX_TUNNEL_TYPE_L2_FLEX_MIN, \
                                  SX_TUNNEL_TYPE_L2_FLEX_MAX)
#define SX_TUNNEL_ID_IP_CONSISTENCY_CHECK(tunnel_id, ip_version) \
    SX_TUNNEL_TYPE_IP_CONSISTENCY_CHECK(SX_TUNNEL_TYPE_ID_GET((tunnel_id)), (ip_version))
#define SX_TUNNEL_TYPE_IP_CONSISTENCY_CHECK(tunnel_type, ip_version) \
    ((((ip_version) == SX_IP_VERSION_IPV6)                           \
      && (((tunnel_type) == SX_TUNNEL_TYPE_NVE_VXLAN_IPV6) ||        \
          ((tunnel_type) == SX_TUNNEL_TYPE_NVE_NVGRE_IPV6) ||        \
          ((tunnel_type) == SX_TUNNEL_TYPE_L2_FLEX_IPV6))) ||        \
     (((ip_version) == SX_IP_VERSION_IPV4)                           \
      && ((SX_CHECK_MAX((tunnel_type), SX_TUNNEL_TYPE_NVE_NVGRE)) || \
          ((tunnel_type) == SX_TUNNEL_TYPE_L2_FLEX))))

#endif /* __SX_TUNNEL_ID_H__ */
