/*
 * SPDX-FileCopyrightText: Copyright (c) 2014-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __SX_BULK_COUNTER_H__
#define __SX_BULK_COUNTER_H__

#include <sx/sxd/kernel_user.h>
#include <sx/sdk/sx_port_id.h>
#include <resource_manager/resource_manager.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_acl.h>
#include <sx/sdk/sx_stateful_db.h>
#include <sx/sdk/auto_headers/sx_bulk_counter_auto.h>


#define SX_BULK_CNTR_PG_NUM   SXD_BULK_CNTR_PG_NUM
#define SX_BULK_CNTR_TC_NUM   SXD_BULK_CNTR_TC_NUM
#define SX_BULK_CNTR_POOL_NUM SXD_BULK_CNTR_POOL_NUM
#define SX_BULK_CNTR_SP_NUM   SXD_BULK_CNTR_SP_NUM

#define SX_BULK_CNTR_TOTAL_POOL_MAX_NUM SXD_BULK_CNTR_TOTAL_POOL_MAX_NUM

#define SX_BULK_CNTR_HFT_SIZE_32  SXD_BULK_CNTR_HFT_SIZE_32
#define SX_BULK_CNTR_HFT_SIZE_64  SXD_BULK_CNTR_HFT_SIZE_64
#define SX_BULK_CNTR_HFT_SIZE_128 SXD_BULK_CNTR_HFT_SIZE_128

typedef sxd_bulk_cntr_buffer_layout_common_t sx_bulk_cntr_buffer_layout_common_t;
typedef sxd_bulk_cntr_buffer_layout_flow_t sx_bulk_cntr_buffer_layout_flow_t;
typedef sxd_bulk_cntr_buffer_layout_flow_estimator_t sx_bulk_cntr_buffer_layout_flow_estimator_t;

typedef struct sx_bulk_cntr_read_key_port {
    sx_bulk_cntr_port_grp_e grp; /**< Counter-set of port counters */
    sx_port_log_id_t        log_port; /**< Port ID */
    union {
        sx_cos_ieee_prio_t      prio_id; /**< Priority ID (in use only when grp is SX_BULK_PORT_CNTR_GRP_PRIO_E) */
        sx_port_tc_id_t         tc_id; /**< TC ID (in use only when grp is SX_BULK_PORT_CNTR_GRP_TC_E) */
        sx_cos_priority_group_t prio_group; /**< Priority group (in use only when grp is SX_BULK_PORT_CNTR_GRP_BUFF_E) */
    } grp_ex_param;
} sx_bulk_cntr_read_key_port_t;

typedef struct sx_bulk_cntr_read_key_flow {
    sx_flow_counter_id_t cntr_id; /**< Flow counter ID */
} sx_bulk_cntr_read_key_flow_t;

typedef struct sx_bulk_cntr_read_key_shared_buffer {
    sx_bulk_cntr_shared_buffer_attr_type_e type;        /**< Shared buffer counter attribute type */
    union {
        sx_port_log_id_t log_port;                      /**< Port ID, physical port supported only.
                                                         * (in use when attr is SX_BULK_CNTR_SHARED_BUFFER_PORT_ATTR_E
                                                         * or SX_BULK_CNTR_SHARED_BUFFER_MULTICAST_PORT_ATTR_E) */
    } attr;
} sx_bulk_cntr_read_key_shared_buffer_t;

typedef struct sx_bulk_cntr_read_key_headroom {
    sx_port_log_id_t log_port;                        /**< Port ID, physical port supported only */
} sx_bulk_cntr_read_key_headroom_t;

typedef struct sx_bulk_cntr_read_key_macsec_port {
    sx_bulk_cntr_macsec_port_grp_e type;                       /**< select a counter type */
    sx_port_log_id_t               log_port;                   /**< Port ID, physical port supported only */
} sx_bulk_cntr_read_key_macsec_port_t;

typedef struct sx_bulk_cntr_read_key_macsec_acl_flow {
    sx_macsec_acl_counter_id_t counter_id;          /**< MACSec ACL Counter ID */
} sx_bulk_cntr_read_key_macsec_acl_flow_t;

typedef struct sx_bulk_cntr_read_key_macsec_sa {
    sx_macsec_sa_obj_id_t sa_id;                    /**< MACSec ACL SA ID */
} sx_bulk_cntr_read_key_macsec_sa_t;

/**
 * High Frequency Telemetry bulk counter read key types
 */
typedef enum sx_bulk_cntr_hft_read_key_type {
    SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_METADATA_E       = 1,        /**< key type for retrieving metadata of a particular sample. */
    SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_PORT_E           = 2,        /**< key type for retrieving a given counter belonging to a given port in a particular sample. */
    SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_GLOBAL_COUNTER_E = 3,        /**< key type for retrieving global counters in a particular sample. */
    SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_MIN              = SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_METADATA_E,
    SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_MAX              = SX_BULK_CNTR_HFT_READ_KEY_SAMPLE_GLOBAL_COUNTER_E,
} sx_bulk_cntr_hft_read_key_type_e;


/**
 * High Frequency Telemetry bulk counter key for a particular sample.
 */
typedef struct sx_bulk_cntr_hft_read_key_sample {
    uint32_t sample_iteration;             /* Sample number to select the sample from a collection of samples retrieved by high frequency telemetry */
} sx_bulk_cntr_hft_read_key_sample_t;

/**
 * High Frequency Telemetry bulk counter key for metadata in a particular sample.
 */
typedef struct sx_bulk_cntr_hft_read_key_sample_metadata {
    sx_bulk_cntr_hft_read_key_sample_t sample_key;  /* Sample number to be used as source for high frequency telemetry metadata information */
} sx_bulk_cntr_hft_read_key_sample_metadata_t;

/**
 * High Frequency Telemetry bulk counter key for port counters in a particular sample.
 */
typedef struct sx_bulk_cntr_hft_read_key_sample_port_counter {
    sx_bulk_cntr_hft_read_key_sample_t sample_key;  /* Sample number to be used as source for high frequency telemetry metadata information. */
    sx_port_log_id_t                   port;        /* Port within the sample to fetch counter information. */
} sx_bulk_cntr_hft_read_key_sample_port_counter_t;

/**
 * High Frequency Telemetry bulk counter key for global counters in a particular sample.
 */
typedef struct sx_bulk_cntr_hft_read_key_global_counter {
    sx_bulk_cntr_hft_read_key_sample_t       sample_key;
    sx_bulk_cntr_hft_sample_global_counter_e global_counter_type;
    union {
        sx_bulk_cntr_read_key_flow_t flow_key;                   /**< Flow counter key */
    } global_counter_data;
} sx_bulk_cntr_hft_read_key_sample_global_counter_t;

/**
 * High Frequency Telemetry bulk counter key.
 */
typedef struct sx_bulk_cntr_read_key_hft {
    sx_bulk_cntr_hft_read_key_type_e key_type;
    union {
        sx_bulk_cntr_hft_read_key_sample_metadata_t       metadata_key;
        sx_bulk_cntr_hft_read_key_sample_port_counter_t   port_counter_key;
        sx_bulk_cntr_hft_read_key_sample_global_counter_t global_counter_key;
    } hft_key_data;
} sx_bulk_cntr_read_key_hft_t;

typedef enum sx_bulk_cntr_arn_flow_status_read_key_type {
    SX_BULK_CNTR_ARN_FLOW_STATUS_READ_KEY_SAMPLE_METADATA_E = 1,              /**< Key type for retrieving metadata of a particular sample. */
    SX_BULK_CNTR_ARN_FLOW_STATUS_READ_KEY_SAMPLE_ARN_FLOW_E = 2,              /**< Key type for retrieving a given ECMP id in a particular sample. */
} sx_bulk_cntr_arn_flow_status_read_key_type_e;


typedef struct sx_bulk_cntr_arn_flow_status_read_key_sample {
    uint32_t sample_iteration;                                                /**< Sample number to select the sample from a collection of samples  */
} sx_bulk_cntr_arn_flow_status_read_key_sample_t;


typedef struct sx_bulk_cntrarn_flow_read_key_sample_metadata {
    sx_bulk_cntr_arn_flow_status_read_key_sample_t sample_key;                /**< Sample key to be used as source for ARN flow status metadata information */
} sx_bulk_cntr_arn_flow_status_read_key_sample_metadata_t;


typedef struct sx_bulk_cntr_arn_flow_status_read_key_sample_ecmp {
    sx_bulk_cntr_arn_flow_status_read_key_sample_t sample_key;              /**< key to access the arn flow table of all tables and iteration */
    sx_ecmp_id_t                                   ecmp_id;
    sx_ar_profile_handle_e                         profile_id;
} sx_bulk_cntr_arn_flow_status_read_key_sample_ecmp_t;


typedef struct sx_bulk_cntr_read_key_arn_flow_status {
    sx_bulk_cntr_arn_flow_status_read_key_type_e key_type;
    union {
        sx_bulk_cntr_arn_flow_status_read_key_sample_metadata_t metadata_key;
        sx_bulk_cntr_arn_flow_status_read_key_sample_ecmp_t     ecmp_key;
    } arn_flow_status_key_data;
} sx_bulk_cntr_read_key_arn_flow_status_t;


typedef struct sx_bulk_cntr_read_key {
    sx_bulk_cntr_key_type_e type; /**< Type of counter to get */
    union {
        sx_bulk_cntr_read_key_port_t            port_key;        /**< Port counter key */
        sx_bulk_cntr_read_key_flow_t            flow_key;        /**< Flow counter key */
        sx_bulk_cntr_read_key_shared_buffer_t   shared_buffer_key; /**< Shared buffer counters key */
        sx_bulk_cntr_read_key_headroom_t        headroom_key;    /**< Headroom counters key */
        sx_bulk_cntr_read_key_elephant_t        elephant_key;    /**< Detected elephant flow key */
        sx_bulk_cntr_read_key_stateful_db_t     stateful_db_key; /**< Stateful DB dump key */
        sx_bulk_cntr_read_key_flow_t            flow_estimator_key;     /**< Flow estimator counter key */
        sx_bulk_cntr_read_key_macsec_port_t     macsec_port_key;        /**< MACSec Port counter key */
        sx_bulk_cntr_read_key_macsec_acl_flow_t macsec_acl_flow_key;   /**< MACSec ACL counter key */
        sx_bulk_cntr_read_key_macsec_sa_t       macsec_sa_key;        /**< MACSec SA key */
        sx_bulk_cntr_read_key_hft_t             hft_key;              /**< High frequency telemetry key */
        sx_bulk_cntr_read_key_arn_flow_status_t arn_flow_status_key;   /**< ARN flow status telemetry key */
    } key;
} sx_bulk_cntr_read_key_t;

typedef struct sx_bulk_cntr_shared_buffer_pool_statistic {
    sx_cos_pool_id_t        pool_id;
    uint32_t                reserved;
    sx_cos_buff_statistic_t statistics;
    uint32_t                ext_occupancy;
} sx_bulk_cntr_shared_buffer_pool_statistic_t;

typedef struct sx_bulk_cntr_shared_buffer_port {
    sx_cos_buff_statistic_t                     port_pg[SX_BULK_CNTR_PG_NUM];             /**< Use PG as index, PG8 is reserved */
    sx_cos_buff_statistic_t                     port_tc[SX_BULK_CNTR_TC_NUM];             /**< Use TC as index */
    sx_bulk_cntr_shared_buffer_pool_statistic_t ingress_port[SX_BULK_CNTR_POOL_NUM];      /**< Pool ID is stated within the data.
                                                                                           * Pool ID SX_COS_POOL_ID_INVALID is used to
                                                                                           * mark end of list */
    sx_bulk_cntr_shared_buffer_pool_statistic_t egress_port[SX_BULK_CNTR_POOL_NUM];       /**< Pool ID is stated within the data.
                                                                                           * Pool ID SX_COS_POOL_ID_INVALID is used to
                                                                                           * mark end of list */
    sx_cos_buff_statistic_t                     port_pg_desc[SX_BULK_CNTR_PG_NUM];        /**< Use PG as index, PG8 is reserved */
    sx_cos_buff_statistic_t                     port_tc_desc[SX_BULK_CNTR_TC_NUM];        /**< Use TC as index */
    sx_bulk_cntr_shared_buffer_pool_statistic_t ingress_port_desc[SX_BULK_CNTR_POOL_NUM]; /**< Pool ID is stated within the data.
                                                                                           * Pool ID SX_COS_POOL_ID_INVALID is used to
                                                                                           * mark end of list */
    sx_bulk_cntr_shared_buffer_pool_statistic_t egress_port_desc[SX_BULK_CNTR_POOL_NUM];  /**< Pool ID is stated within the data.
                                                                                           * Pool ID SX_COS_POOL_ID_INVALID is used to
                                                                                           * mark end of list */
} sx_bulk_cntr_shared_buffer_port_t;

typedef struct sx_bulk_cntr_shared_buffer_mc_switch_prio {
    sx_cos_buff_statistic_t statistics[SX_BULK_CNTR_SP_NUM];    /**< Use switch priority as index */
} sx_bulk_cntr_shared_buffer_mc_switch_prio_t;

typedef struct sx_bulk_cntr_shared_buffer_mc_port {
    sx_cos_buff_statistic_t statistics;
} sx_bulk_cntr_shared_buffer_mc_port_t;

typedef struct sx_bulk_cntr_shared_buffer_pool {
    sx_bulk_cntr_shared_buffer_pool_statistic_t statistics[SX_BULK_CNTR_TOTAL_POOL_MAX_NUM];  /**< Pool ID is stated within the data.
                                                                                               * Pool ID SX_COS_POOL_ID_INVALID is used to
                                                                                               * mark end of list */
} sx_bulk_cntr_shared_buffer_pool_t;

typedef struct sx_bulk_cntr_occupancy_statistics_list {
    uint64_t                cnt;                                    /**< Indicates how many instances of statistics were returned */
    sx_cos_buff_statistic_t statistics[SX_COS_PORT_BUFF_NUM_MAX_E]; /**< Used for 8x lanes interface, since there we have two buffers,
                                                                     * supported on Spectrum2 and Spectrum3 */
} sx_bulk_cntr_occupancy_statistics_list_t;

typedef struct sx_bulk_cntr_headroom_statistic {
    sx_cos_buff_statistic_t                  statistics;
    sx_bulk_cntr_occupancy_statistics_list_t occupancy_statistics_lst;
} sx_bulk_cntr_headroom_statistic_t;

typedef struct sx_bulk_cntr_headroom_t {
    sx_bulk_cntr_headroom_statistic_t port_pg[SX_BULK_CNTR_PG_NUM];  /**< Use priority group as index, PG8 is reserved */
    sx_bulk_cntr_headroom_statistic_t port_shared_buffer;
    sx_cos_buff_statistic_t           port_shared_headroom_pool_usage;     /**< Usage of the shared headroom pool.
                                                                            * Not supported on Spectrum2, Spectrum3
                                                                            * Note: watermark is not supported. */
} sx_bulk_cntr_headroom_t;

typedef struct sx_hft_ts_32 {
    uint32_t ts_val;                                                      /**< Time stamp, 32 bits. */
} sx_hft_ts_32_t;


typedef struct sx_hft_port_ctr_64 {
    uint64_t counter_value;
} sx_hft_port_ctr_64_t;

typedef struct sx_hft_port_ctr_32 {
    uint32_t counter_value;                                               /**< counter value, 32 bits. */
} sx_hft_port_ctr_32_t;

typedef sx_hft_port_ctr_64_t sx_hft_buffer_unit_64_t;
typedef sx_hft_port_ctr_32_t sx_hft_buffer_unit_32_t;

typedef struct sx_hft_metadata {
    const sx_hft_ts_32_t *start_ts_secs_p;                                      /**< hardware timestamp, UTC in seconds 32 bits */
    const sx_hft_ts_32_t *start_ts_nsecs_p;                                     /**< hardware timestamp, UTC in nano seconds 32 bits */
} sx_bulk_cntr_hft_metadata_t;


typedef struct sx_hft_port_cntr {
    const sx_hft_port_ctr_64_t    *if_out_octets_p;                                  /**< port counter RFC 2863 group, interface out octets 64bits */
    const sx_hft_port_ctr_64_t    *if_in_octets_p;                                   /**< port counter RFC 2863 group, interface in octets 64bits */
    const sx_hft_port_ctr_64_t    *a_frames_received_ok_p;                           /**< port counter RFC 802.3 group, frames transmitted successfully but not including pause frames, 64 bits */
    const sx_hft_port_ctr_64_t    *a_frames_transmitted_ok_p;                        /**< port counter RFC 802.3 group, frames received successfully 64 bits */
    const sx_hft_port_ctr_64_t    *if_in_discards_p;                                 /**< port counter RFC 2863 group, ingress discard 64 bits */
    const sx_hft_port_ctr_64_t    *a_pause_mac_ctrl_frames_transmitted_p;            /**< port counter group RFC 2863, pause frame transmitted, 64 bits */
    const sx_hft_port_ctr_64_t    *a_pause_mac_ctrl_frames_received_p;               /**< port counter group RFC 2863, pause frame received, 64 bits */
    const sx_hft_port_ctr_64_t    *tx_pause_per_prio_list_p;                         /**< port PRIO counter list, egress pause frames, 64 bits */
    const sx_hft_port_ctr_64_t    *rx_pause_per_prio_list_p;                         /**< port PRIO counter list, ingress pause frames, 64 bits */
    const sx_hft_port_ctr_64_t    *rx_octets_list_p;                                 /**< port PRIO counter list, ingress bytes, 64 bits */
    const sx_hft_port_ctr_64_t    *tx_octets_list_p;                                 /**< port TC egress bytes counter list, 64 bits */
    const sx_hft_port_ctr_64_t    *ecn_marked_tc_list_p;                             /**< port TC ecn marked packets counter list, 64 bits */
    const sx_hft_buffer_unit_32_t *headroom_watermark_list_p;                        /**< port PG headroom max occupancy list, units in cells, 32 bits */
    const sx_hft_buffer_unit_32_t *headroom_curr_occupancy_list_p;                   /**< port PG headroom current occupancy list, units in cells, 32 bits */
    const sx_hft_buffer_unit_64_t *tc_watermark_list_p;                              /**< port per TC shared buffer max occupancy list, units in cells, 64 bits. This will have outdated values when buffer snapshot is enabled. */
    const sx_hft_buffer_unit_32_t *tc_curr_occupancy_list_p;                         /**< port per TC shared buffer occupancy list, units in cells, 32 bits. This will have outdated values when buffer snapshot is enabled. */
    const sx_hft_buffer_unit_64_t *pg_watermark_list_p;                              /**< port per PG shared buffer max occupancy list, units in cells, 64 bits. This will have outdated values when buffer snapshot is enabled. */
    const sx_hft_buffer_unit_32_t *pg_curr_occupancy_list_p;                         /**< port per PG shared buffer occupancy list, units in cells, 32 bits. This will have outdated values when buffer snapshot is enabled. */
    const sx_hft_port_ctr_32_t    *ar_grades_low_p;                                  /**< AR grades for TC0..TC7 4 bits */
    const sx_hft_port_ctr_32_t    *ar_grades_high_p;                                 /**< AR grades for TC8..TC15 4 bits */
    const uint32_t                *prio_list_cnt_p;                                  /**< port PRIO list count applicable to tx_pause_per_prio_list_p, rx_pause_per_prio_list_p, rx_octets_list_p */
    const uint32_t                *tc_list_cnt_p;                                    /**< port TC list count applicable to tx_octets_list_p, ecn_marked_tc_list_p, tc_watermark_list_p,
                                                                                      *  tc_curr_occupancy_list_p  */
    const uint32_t *pg_list_cnt_p;                                                   /**< port PG list count applicable to headroom_watermark_list_p, headroom_curr_occupancy_list_p,
                                                                                      *  pg_watermark_list_p, pg_curr_occupancy_list_p*/
} sx_bulk_cntr_hft_port_cntr_t;


typedef struct sx_hft_global_data {
    const sx_flow_counter_set_t *flow_cntr_p;  /**< Flow counter */
} sx_bulk_cntr_hft_global_data_t;


typedef struct sx_arn_flow_status_metadata {
    const sx_hft_ts_32_t *ts_secs_p;                                      /**< Hardware timestamp, UTC in seconds 32 bits */
    const sx_hft_ts_32_t *ts_nsecs_p;                                     /**< Hardware timestamp, UTC in nano seconds 32 bits */
} sx_bulk_cntr_arn_flow_status_metadata_t;

typedef struct sx_bulk_cntr_arn_flow_status_ecmp {
    const sx_arn_flow_entry_status_t *flow_status_list_p;
    const uint32_t                   *flow_status_cnt_p;
} sx_bulk_cntr_arn_flow_status_t;

typedef struct sx_bulk_cntr_data {
    union {
        union {
            const sx_port_cntr_ieee_802_dot_3_t       *port_cntr_ieee_802_p;    /**< IEEE 802.3 counters entry */
            const sx_port_cntr_rfc_2863_t             *port_cntr_rfc_2863_p;    /**< RFC 2863 counters entry */
            const sx_port_cntr_rfc_2819_t             *port_cntr_rfc_2819_p;    /**< RFC 2819 counters entry */
            const sx_port_cntr_rfc_3635_t             *port_cntr_rfc_3635_p;    /**< RFC 3635 counters entry */
            const sx_port_cntr_prio_t                 *port_cntr_prio_p;    /**< Priority counters entry */
            const sx_port_traffic_cntr_t              *port_cntr_tc_p;    /**< Per TC counters */
            const sx_port_cntr_buff_t                 *port_cntr_buff_p;    /**< Buffer counters entry */
            const sx_port_cntr_perf_t                 *port_cntr_perf_p;    /**< Performance counters entry */
            const sx_port_cntr_discard_t              *port_cntr_discard_p;    /**< Discard counters entry */
            const sx_port_cntr_phy_layer_t            *port_cntr_phy_p;    /**< Phy layer counters entry */
            const sx_port_cntr_phy_layer_statistics_t *port_cntr_phy_stats_p;    /**< Phy layer stats counters entry */
            const sx_port_cntr_ib_packets_counters_t  *port_cntr_ib_packets_counters_p;    /**< InfiniBand packets counters entry */
            const sx_port_cntr_plr_t                  *port_cntr_plr_p;    /**< PLR counters entry */
            const sx_port_cntr_rs_fec_t               *port_cntr_rs_fec_p;    /**< RS FEC counters entry */
            const sx_port_cntr_ib_ext_t               *port_cntr_ib_ext_p;    /**< IB Extended counters entry */
            const sx_port_cntr_ib_general_t           *port_cntr_ib_general_p;   /**< IB General counters entry */
        } port_counters;
        union {
            const sx_flow_counter_set_t *flow_cntr_p; /**< Flow counter */
        } flow_counters;
        union {
            const sx_bulk_cntr_shared_buffer_port_t           *port_p;
            const sx_bulk_cntr_shared_buffer_mc_port_t        *mc_port_p;
            const sx_bulk_cntr_shared_buffer_mc_switch_prio_t *mc_switch_prio_p;
            const sx_bulk_cntr_shared_buffer_pool_t           *pool_p;
        } shared_buffer_counters;
        union {
            const sx_bulk_cntr_headroom_t *headroom_p;
        } headroom_counters;
        union {
            const sx_cos_elephant_flow_ids_list_t *flow_id_list_p; /**< List of detected elephant flows per port */
            const sx_cos_elephant_flow_data_t     *elephant_flow_data_p; /**< Detected elephant flow data per port and flow ID */
        } elephant_flow_data;
        union {
            const sx_stateful_db_entries_num_t *stateful_db_entries_num_p; /**< Number of entries in Stateful DB partition ID */
            const sx_stateful_db_entry_t       *stateful_db_entry_p;     /**< Stateful DB entry */
        } stateful_db_entry_data;
        union {
            const sx_flow_estimator_counter_set_t *flow_counter_estimator_p; /**< Flow estimator data */
        } flow_estimator_data;
        union {
            const sx_macsec_cntr_port_group0_stats_t *port_stats_grp0_p;  /**< port Group0 Counter Stats */
            const sx_macsec_cntr_port_group1_stats_t *port_stats_grp1_p;  /**< port Group1 Counter Stats */
        } macsec_port_counters;
        union {
            const sx_macsec_acl_counter_set_t *acl_counter_data_p;       /**< MACSec ACL counter data */
        } macsec_acl_flow_counters;
        union {
            const sx_macsec_cntr_sa_stats_t *sa_stats_data_p;           /**< MACSec SA counter data */
        } macsec_sa_counters;
        union {
            sx_bulk_cntr_hft_metadata_t    meta_data_info;                      /**< High frequency telemetry Metadata information. */
            sx_bulk_cntr_hft_port_cntr_t   port_cntr_info;                      /**< High frequency telemetry port counter information. */
            sx_bulk_cntr_hft_global_data_t global_data_info;                    /**< High frequency telemetry global data information. */
        } hft_data;
        union {
            sx_bulk_cntr_arn_flow_status_metadata_t metadata_info;                          /**< ARN flow status metadata information. */
            sx_bulk_cntr_arn_flow_status_t          arn_flow_table_data_info;               /**< ARN flow table status information. */
        } arn_flow_status_data;
    } data;
} sx_bulk_cntr_data_t;

#endif /* ifndef __SX_BULK_COUNTER_H__ */
