/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */
#ifndef __SX_MPLS_ILM_H__
#define __SX_MPLS_ILM_H__


#include "sx/sdk/auto_headers/sx_mpls_ilm_auto.h"


#define SX_MPLS_IN_SEGMENT_LABEL_COUNT_RANGE(label_count) \
    SX_CHECK_MAX(label_count, SX_MPLS_MAX_SUPPORTED_LABELS_TO_MATCH)

#define SX_MPLS_ILM_FORWARD_ACTION_CHECK_RANGE(ACTION) \
    SX_CHECK_MAX(ACTION, SX_MPLS_ILM_MAX)


/**
 * The following callback is used to display ILM action forward
 * information is correct format for different chip types. For
 * example for Spectrum2 will be displayed in the following
 * format:
 * [iRIF/use_eRIF/eRIF/qos_from_inner_dscp/qos_from_inner_exp]
 */
typedef void (*hwd_ilm_fwd_action_dump_cb)(const sx_mpls_in_segment_params_t *in_segment_params, char *fwd_params,
                                           int fwd_params_len);


#endif /* __SX_MPLS_ILM__H__ */
