/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef __SX_IB_LIB_IF_H__
#define __SX_IB_LIB_IF_H__

#define SX_IB_LIB_INIT  "sx_ib_lib_init"
#define SX_IB_L3_INIT   "sx_ib_l3_init"
#define SX_IB_L3_DEINIT "sx_ib_l3_deinit"
#define SX_IB_LIB_NAME  "libsxib.so"


typedef struct sx_ib_lib_init_params {
    unsigned int version;
} sx_ib_lib_init_params_t;

#define IB_LIB_VERSION 0xbfffffff;

#endif /* __SX_IB_LIB_IF_H__ */
