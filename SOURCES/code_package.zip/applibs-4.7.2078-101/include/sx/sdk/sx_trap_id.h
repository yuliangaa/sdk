/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#ifndef SX_TRAP_ID_H_
#define SX_TRAP_ID_H_


#include "sx/sdk/auto_headers/sx_trap_id_auto.h"


#define SX_TRAP_ID_MIRROR_AGENT(span_session_id)      (span_session_id | (SX_TRAP_TYPE_SPAN << SX_TRAP_TYPE_SPAN_OFFS))
#define SX_TRAP_SPAN_SESSION_ID(mirror_agent_trap_id) (mirror_agent_trap_id & SX_TRAP_SAPN_SESSION_ID_MASK)

/**
 * SX_TRAP_ID_CHECK_RANGE defines Trap ID check range macro
 */
#define SX_TRAP_ID_CHECK_RANGE(TRAP_ID) \
    SX_CHECK_RANGE(SX_TRAP_ID_MIN, TRAP_ID, SX_TRAP_ID_MAX)

/**
 * SX_TRAP_ACL_CHECK_RANGE defines acl trap id check range macro
 */
#define SX_TRAP_ID_ACL_CHECK_RANGE(TRAP_ID) \
    SX_CHECK_RANGE(SX_TRAP_ID_ACL_MIN, TRAP_ID, SX_TRAP_ID_ACL_MAX)

/**
 * SX_TRAP_IPTRAP_CHECK_RANGE defines iptrap trap id check range macro
 */
#define SX_TRAP_ID_IPTRAP_CHECK_RANGE(TRAP_ID) \
    SX_CHECK_RANGE(SX_TRAP_ID_IPTRAP_MIN, TRAP_ID, SX_TRAP_ID_IPTRAP_MAX)

#define SX_TRAP_ID_MIRROR_AGENT_CHECK_RANGE(TRAP_ID) \
    SX_CHECK_RANGE(SX_TRAP_ID_MIRROR_AGENT_MIN, TRAP_ID, SX_TRAP_ID_MIRROR_AGENT_MAX)

/**
 * SX_TRAP_ID_SW_CHECK_RANGE returns true if trap ID is SW event.
 * macro
 */
#define SX_TRAP_ID_SW_CHECK_RANGE(TRAP_ID)                 \
    (TRAP_ID == SX_TRAP_ID_NEW_DEVICE_ADD ||               \
     TRAP_ID == SX_TRAP_ID_NEED_TO_RESOLVE_ARP ||          \
     TRAP_ID == SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP ||       \
     TRAP_ID == SX_TRAP_ID_FDB_EVENT ||                    \
     TRAP_ID == SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT || \
     TRAP_ID == SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT ||  \
     TRAP_ID == SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY ||        \
     TRAP_ID == SX_TRAP_ID_ASYNC_API_COMPLETE_EVENT ||     \
     TRAP_ID == SX_TRAP_ID_ROUTER_MC_ACTIVITY ||           \
     TRAP_ID == SX_TRAP_ID_FDB_IP_ADDR_ACTIVITY ||         \
     TRAP_ID == SX_TRAP_ID_PORT_ADDED ||                   \
     TRAP_ID == SX_TRAP_ID_PORT_DELETED ||                 \
     TRAP_ID == SX_TRAP_ID_PORT_ADDED_TO_LAG ||            \
     TRAP_ID == SX_TRAP_ID_PORT_REMOVED_FROM_LAG ||        \
     TRAP_ID == SX_TRAP_ID_SIGNAL ||                       \
     TRAP_ID == SX_TRAP_ID_SDK_HEALTH_EVENT ||             \
     TRAP_ID == SX_TRAP_ID_BULK_COUNTER_DONE_EVENT ||      \
     TRAP_ID == SX_TRAP_ID_API_LOGGER_EVENT ||             \
     TRAP_ID == SX_TRAP_ID_ACL_ACTIVITY ||                 \
     TRAP_ID == SX_TRAP_ID_OBJECT_DELETED_EVENT ||         \
     TRAP_ID == SX_TRAP_ID_PORT_PROFILE_APPLY_DONE         \
    )

/**
 * SX_TRAP_SW_CHECK_RANGE defines iptrap trap id check range
 * macro
 */
#define SX_TRAP_ID_USER_L4_PORT_CHECK_RANGE(TRAP_ID) \
    SX_CHECK_RANGE(SX_TRAP_ID_USER_BASE, TRAP_ID, SX_TRAP_ID_USER_MAX)

#define SX_TRAP_ID_DISCARD_CHECK_RANGE(TRAP_ID) \
    SX_CHECK_RANGE(SX_TRAP_ID_DISCARD_BASE, TRAP_ID, SX_TRAP_ID_DISCARD_MAX)

#define SX_TRAP_ID_EXTENDED_DISCARD_CHECK_RANGE(TRAP_ID) \
    SX_CHECK_RANGE(SX_TRAP_ID_EXTENDED_DISCARD_BASE, TRAP_ID, SX_TRAP_ID_EXTENDED_DISCARD_MAX)

#define SX_TRAP_ID_IPV6_UNSPECIFIED_CHECK_RANGE(TRAP_ID) \
    (TRAP_ID == SX_TRAP_ID_IPV6_UNSPECIFIED_SIP ||       \
     TRAP_ID == SX_TRAP_ID_IPV6_UNSPECIFIED_DIP          \
    )

static const uint32_t user_attr_traps_list[] = {
    SX_TRAP_ID_USER_ICMPV6_CONF_TYPE0,
    SX_TRAP_ID_USER_ICMPV6_CONF_TYPE1,
    SX_TRAP_ID_USER_OVERLAY_ICMPV6_CONF_TYPE,
    SX_TRAP_ID_USER_NVE_DECAP_ETH,
    SX_TRAP_ID_USER_ETH_CONF_TYPE0,
    SX_TRAP_ID_USER_ETH_CONF_TYPE1
};

#define SX_USER_ATTR_TRAPS_NUM (sizeof(user_attr_traps_list) / sizeof(user_attr_traps_list[0]))
#define SX_USER_DEFINED_TRAPS_NUM                                  \
    (SX_USER_DEFINED_L4_PORTS_TRAPS_NUM + SX_USER_ATTR_TRAPS_NUM + \
     SX_USER_ATTR_EXT_TRAPS_NUM)

#define SX_TRAP_ID_USER_ATTR_CHECK_RANGE(TRAP_ID)           \
    (TRAP_ID == SX_TRAP_ID_USER_ICMPV6_CONF_TYPE0 ||        \
     TRAP_ID == SX_TRAP_ID_USER_ICMPV6_CONF_TYPE1 ||        \
     TRAP_ID == SX_TRAP_ID_USER_OVERLAY_ICMPV6_CONF_TYPE || \
     TRAP_ID == SX_TRAP_ID_USER_NVE_DECAP_ETH ||            \
     TRAP_ID == SX_TRAP_ID_USER_ETH_CONF_TYPE0 ||           \
     TRAP_ID == SX_TRAP_ID_USER_ETH_CONF_TYPE1              \
    )

#define SX_TRAP_ID_MACSEC_TRAP_CHECK_RANGE(TRAP_ID) \
    (TRAP_ID == SX_TRAP_ID_UTFD)

static const uint32_t user_attr_ext_traps_list[] = {
    SX_TRAP_ID_USER_CONF_SWITCH0,
    SX_TRAP_ID_USER_CONF_SWITCH1,
    SX_TRAP_ID_USER_CONF_SWITCH2,
    SX_TRAP_ID_USER_CONF_SWITCH3,

    SX_TRAP_ID_USER_CONF_ROUTER0,
    SX_TRAP_ID_USER_CONF_ROUTER1,
    SX_TRAP_ID_USER_CONF_ROUTER2,
    SX_TRAP_ID_USER_CONF_ROUTER3,

    SX_TRAP_ID_USER_CONF_SWITCH_ENC0,
    SX_TRAP_ID_USER_CONF_SWITCH_ENC1,
    SX_TRAP_ID_USER_CONF_SWITCH_ENC2,
    SX_TRAP_ID_USER_CONF_SWITCH_ENC3,

    SX_TRAP_ID_USER_CONF_SWITCH_DEC0,
    SX_TRAP_ID_USER_CONF_SWITCH_DEC1,
    SX_TRAP_ID_USER_CONF_SWITCH_DEC2,
    SX_TRAP_ID_USER_CONF_SWITCH_DEC3,
};

#define SX_USER_ATTR_EXT_TRAPS_NUM (sizeof(user_attr_ext_traps_list) / sizeof(user_attr_ext_traps_list[0]))

#define SX_TRAP_ID_USER_ATTR_EXT_CHECK_RANGE(TRAP_ID) \
    (TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH0 ||       \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH1 ||       \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH2 ||       \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH3 ||       \
     TRAP_ID == SX_TRAP_ID_USER_CONF_ROUTER0 ||       \
     TRAP_ID == SX_TRAP_ID_USER_CONF_ROUTER1 ||       \
     TRAP_ID == SX_TRAP_ID_USER_CONF_ROUTER2 ||       \
     TRAP_ID == SX_TRAP_ID_USER_CONF_ROUTER3 ||       \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH_ENC0 ||   \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH_ENC1 ||   \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH_ENC2 ||   \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH_ENC3 ||   \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH_DEC0 ||   \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH_DEC1 ||   \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH_DEC2 ||   \
     TRAP_ID == SX_TRAP_ID_USER_CONF_SWITCH_DEC3      \
    )


#define SX_TRAP_ID_USER_CHECK_RANGE(TRAP_ID)         \
    (SX_TRAP_ID_USER_L4_PORT_CHECK_RANGE(TRAP_ID) || \
     SX_TRAP_ID_USER_ATTR_CHECK_RANGE(TRAP_ID) ||    \
     SX_TRAP_ID_USER_ATTR_EXT_CHECK_RANGE(TRAP_ID))

#define SX_TRAP_ID_MGMT_TRAP_CHECK_RANGE(TRAP_ID) \
    (TRAP_ID == SX_TRAP_ID_TSDE ||                \
     TRAP_ID == SX_TRAP_ID_DSDSC ||               \
     TRAP_ID == SX_TRAP_ID_BCTOE ||               \
     TRAP_ID == SX_TRAP_ID_PMLPE)

/**
 * SX_TRAP_ACTION_CHECK_RANGE defines trap action check range macro
 */
#define SX_TRAP_ACTION_CHECK_RANGE(TRAP_ACTION) \
    SX_CHECK_RANGE(SX_TRAP_ACTION_MIN, TRAP_ACTION, SX_TRAP_ACTION_MAX)

static __attribute__((__used__)) const char* sx_trap_priority_str[] = {
    "B/E",
    "LOW",
    "MED",
    "HIGH",
    "CRIT",
};

#define SX_TRAP_PRIORITY_STR_LEN (sizeof(sx_trap_priority_str) / sizeof(char*))

#define SX_TRAP_PRIORITY_STR(index)                      \
    (SX_CHECK_MAX(index, SX_TRAP_PRIORITY_STR_LEN - 1) ? \
     sx_trap_priority_str[index] : "UNKNOWN")

/**
 * SX_TRAP_PRIORITY_CHECK_RANGE defines trap priority check range macro,
 * for SwitchX and SwitchX-2 devices.
 */
#define SX_TRAP_PRIORITY_CHECK_RANGE(TRAP_PRIORITY) \
    SX_CHECK_MAX(TRAP_PRIORITY, SX_TRAP_PRIORITY_MAX)

/**
 * SX_TRAP_SPECTRUM_PRIORITY_CHECK_RANGE defines trap priority check range
 * macro, for SPECTRUM devices.
 */
#define SX_TRAP_SPECTRUM_PRIORITY_CHECK_RANGE(TRAP_PRIORITY) \
    SX_CHECK_MAX(TRAP_PRIORITY, SX_TRAP_SPECTRUM_PRIORITY_MAX)

/************************************************
 *  DEFINITIONS
 ***********************************************/

/**
 * SX_PACKET_TYPE_CHECK_RANGE defines a packet type value check range macro
 */
#define SX_PACKET_TYPE_CHECK_RANGE(PACKET_TYPE) SX_CHECK_RANGE(SX_PKT_TYPE_MIN, (int)PACKET_TYPE, SX_PKT_TYPE_MAX)

/**
 * sx_packet_type_str is used to store packet types names
 */
static const char *sx_packet_type_str[] = {
    /*SX_PKT_TYPE_ETH_CTL_UC */
    "ETH packet (control - UC)",
    /*SX_PKT_TYPE_ETH_CTL_MC */
    "ETH packet (control - MC)",
    /*SX_PKT_TYPE_ETH_DATA */
    "ETH packet (data)",
    /*SX_PKT_TYPE_DROUTE_EMAD_CTL */
    "EMAD - direct route",
    /*SX_PKT_TYPE_EMAD_CTL */
    "EMAD - non direct route",
    /*SX_PKT_TYPE_FC_CTL_UC */
    "FC (control - UC)",
    /*SX_PKT_TYPE_FC_CTL_MC */
    "FC (control - MC)",
    /*SX_PKT_TYPE_FCOE_CTL_UC */
    "FCOE (control - UC)",
    /*SX_PKT_TYPE_FCOE_CTL_MC */
    "FCOE (control - MC)",
    /*SX_PKT_TYPE_IB_RAW_CTL */
    "IB (control - RAW)",
    /*SX_PKT_TYPE_IB_TRANSPORT_CTL */
    "IB (control - transport)",
    /*SX_PKT_TYPE_IB_RAW_DATA */
    "IB (data - RAW)",
    /*SX_PKT_TYPE_IB_TRANSPORT_DATA */
    "IB (data - transport)",
    /*SX_PKT_TYPE_EOIB_CTL */
    "ETH OVER IB (control)",
    /*SX_PKT_TYPE_FCOIB_CTL */
    "FC OVER IB (control)",
    /* SX_PKT_TYPE_LOOPBACK_CTL */
    "SX_PKT_TYPE_LOOPBACK_CTL",
    /* SX_PKT_TYPE_IB_CTL_2 */
    "SX_PKT_TYPE_IB_CTL_2",
    /* SX_PKT_TYPE_IB_NVLINK */
    "SX_PKT_TYPE_IB_NVLINK"
};

/**
 * sx_packet_type_str_len is used to store packet types names array length
 */
static const int sx_packet_type_str_len = sizeof(sx_packet_type_str) / sizeof(char*);

/**
 * SX_PACKET_TYPE_STR defines a packet type value to string macro
 */
#define SX_PACKET_TYPE_STR(PACKET_TYPE)                                          \
    (SX_PACKET_TYPE_CHECK_RANGE(PACKET_TYPE) ? sx_packet_type_str[PACKET_TYPE] : \
     "UNKNOWN")


/************************************************
 *  MACROS
 ***********************************************/

/**
 * SX_API_GET_RELEVANT_PACKET_TYPE defines a trap id / event id to syndrome id macro
 */
#define SX_API_GET_RELEVANT_PACKET_TYPE(EVENT_ID, TYPE)                                                  \
    {                                                                                                    \
        if (EVENT_ID == SX_TRAP_ID_FCOE_FIP) {                                                           \
            TYPE = SX_KU_L2_TYPE_FC;                                                                     \
        }                                                                                                \
        else if (EVENT_ID == SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED) {                                       \
            TYPE = SX_KU_L2_TYPE_DONT_CARE;                                                              \
        }                                                                                                \
        else if (EVENT_ID == SX_TRAP_ID_ETH_L2_PACKET_SAMPLING) {                                        \
            TYPE = SX_KU_L2_TYPE_DONT_CARE;                                                              \
        }                                                                                                \
        else if (EVENT_ID == SX_TRAP_ID_PPIR || EVENT_ID == SX_TRAP_ID_IBISSU) {                         \
            TYPE = SX_KU_L2_TYPE_DONT_CARE;                                                              \
        }                                                                                                \
        else if (SX_CHECK_RANGE(SX_TRAP_ID_ETH_L2_STP, EVENT_ID, SX_TRAP_ID_ETH_L2_RARP_OPCODES)) {      \
            TYPE = SX_KU_L2_TYPE_ETH;                                                                    \
        }                                                                                                \
        else if (SX_CHECK_RANGE(SX_TRAP_ID_INFINIBAND_QP0, EVENT_ID, SX_TRAP_ID_INFINIBAND_OTHER_QPS)) { \
            TYPE = SX_KU_L2_TYPE_IB;                                                                     \
        }                                                                                                \
        else if (EVENT_ID == SX_TRAP_ID_ARP_REQUEST) {                                                   \
            TYPE = SX_KU_L2_TYPE_ETH;                                                                    \
        }                                                                                                \
        else if (EVENT_ID == SX_TRAP_ID_ARP_RESPONSE) {                                                  \
            TYPE = SX_KU_L2_TYPE_ETH;                                                                    \
        }                                                                                                \
        else if (SX_CHECK_RANGE(SX_TRAP_ID_ACL_MIN, EVENT_ID, SX_TRAP_ID_ACL_MAX)) {                     \
            TYPE = SX_KU_L2_TYPE_ETH;                                                                    \
        }                                                                                                \
        else {                                                                                           \
            TYPE = SX_KU_L2_TYPE_DONT_CARE;                                                              \
        }                                                                                                \
    }

/**
 * SX_API_GET_DROP_ENABLED defines whether a trap id / event id can drops
 * events in driver
 */
#define SX_API_GET_DROP_ENABLED(EVENT_ID, DROP_E)                  \
    {                                                              \
        if (EVENT_ID == SX_TRAP_ID_BER_MONITOR) {                  \
            DROP_E = 1;                                            \
        }                                                          \
        else if (EVENT_ID == SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED) { \
            DROP_E = 1;                                            \
        }                                                          \
        else {                                                     \
            DROP_E = 0;                                            \
        }                                                          \
    }

#endif /* SX_TRAP_ID_H_ */
