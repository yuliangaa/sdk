/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <complib/cl_list.h>
#include <complib/cl_types.h>
#include <complib/cl_qpool.h>
#include <complib/cl_dbg.h>
#include <complib/cl_qmap.h>

#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <sx/utils/debug_cmd.h>

#include <sx/sxd/sxd_access_register.h>
#include <resource_manager/resource_manager_sdk_table.h>

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "ethl2/port.h"
#include "utils/sx_adviser.h"
#include "ethl2/topo.h"
#include "flow_counter/flow_counter.h"

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ FLOW_COUNTER

/************************************************
 *  Local defines
 ***********************************************/

#define FLOW_ESTIMATOR_PROFILE_HASH_IS_FIELD_ENABLE_OUTER(field)   \
    ((SX_FLOW_EST_PROF_HASH_FIELD_ENABLE_OUTER_IPV6_E >= field) && \
     (SX_FLOW_EST_PROF_HASH_OUTER_ENABLES_OFFSET <= field))

#define FLOW_ESTIMATOR_PROFILE_HASH_IS_FIELD_ENABLE_INNER(field)   \
    ((SX_FLOW_EST_PROF_HASH_FIELD_ENABLE_INNER_IPV6_E >= field) && \
     (SX_FLOW_EST_PROF_HASH_INNER_ENABLES_OFFSET <= field))

#define FLOW_ESTIMATOR_PROFILE_HASH_IS_FIELD_OUTER(field) \
    ((SX_FLOW_EST_PROF_HASH_OUTER_LAST >= field) &&       \
     (SX_FLOW_EST_PROF_HASH_OUTER_FIELDS_OFFSET <= field))

#define FLOW_ESTIMATOR_PROFILE_HASH_IS_FIELD_INNER(field) \
    ((SX_FLOW_EST_PROF_HASH_INNER_LAST >= field) &&       \
     (SX_FLOW_EST_PROF_HASH_INNER_FIELDS_OFFSET <= field))

#define IS_VALID_PROFILE_ID(id)                  \
    ((id >= SX_FLOW_ESTIMATOR_PROFILE_ID_MIN) && \
     (id <= SX_FLOW_ESTIMATOR_PROFILE_ID_MAX))
#define IS_PROFILE_ALLOCATED(profile_id) (!!(s_flow_estimator_profiles_db.profiles[profile_id].allocated))
#define IS_PROFILE_IN_USE(profile_id)    (s_flow_estimator_profiles_db.profiles[profile_id].ref_cnt > 0)
#define SIZE_OF_PROFILE(profile_id)      (s_flow_estimator_profiles_db.profiles[profile_id].bin_group_size)

static __attribute__((__used__)) const char* s_est_prof_hash_enables_str[] = {
    FOREACH_FLOW_ESTIMATOR_PROFILE_HASH_FIELD_ENABLE(SX_GENERATE_STRING)
};

#define ECMP_HASH_PP_ENABLES_STR_LEN (sizeof(s_est_prof_hash_enables_str) / sizeof(char*))

static __attribute__((__used__)) const char* s_est_prof_hash_fields_str[] = {
    /* Outer header fields enables */
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV4_DIP_BYTE_0",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV4_DIP_BYTE_1",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV4_DIP_BYTE_2",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV4_DIP_BYTE_3",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV4_SIP_BYTE_0",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV4_SIP_BYTE_1",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV4_SIP_BYTE_2",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV4_SIP_BYTE_3",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV4_MASK_FRAGMENT",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV4_PROTOCOL",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_DIP_BYTES_0_TO_7",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_DIP_BYTES_8",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_DIP_BYTES_9",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_DIP_BYTES_10",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_DIP_BYTES_11",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_DIP_BYTES_12",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_DIP_BYTES_13",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_DIP_BYTES_14",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_DIP_BYTES_15",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_SIP_BYTES_0_TO_7",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_SIP_BYTES_8",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_SIP_BYTES_9",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_SIP_BYTES_10",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_SIP_BYTES_11",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_SIP_BYTES_12",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_SIP_BYTES_13",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_SIP_BYTES_14",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_SIP_BYTES_15",
    "UNKNOWN",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_IPV6_NEXT_HEADER",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_L4_DPORT",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_L4_SPORT",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_L4_NO_TCP_UDP_PORTS",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_EXP",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_LABEL_0",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_LABEL_1",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_LABEL_2",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_LABEL_3",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_LABEL_4",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_LABEL_5",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_MASK_LABEL_AFTER_EXTENSION",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_MASK_LABELS_HEADS_AFTER_ENTROPY",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_MASK_ALL_HEADERS_AFTER_MPLS_HEADER",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MPLS_MASK_RESERVED_LABELS",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_ARP_DIP",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_ARP_SIP",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_BTH_DEST_QP",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_MASK_ALL_HEADERS_AFTER_FLEX",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_GRH_DIP",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_GRH_NEXT_PROTOCOL",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_GRH_SIP",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_VXLAN_GENEVE_GPE_MASK_ALL_NEXT_HEADERS_AFTER_UDP",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_VXLAN_GENEVE_GPE_MASK_ALL_HEADER_AFTER_VXLAN_GENEVE_GPE",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_INGRESS_PORT",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_OUTER_NVGRE_MASK_ALL_NEXT_HEADERS_AFTER_NVGRE",

    /* Inner header fields */
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV4_DIP_BYTE_0",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV4_DIP_BYTE_1",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV4_DIP_BYTE_2",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV4_DIP_BYTE_3",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV4_SIP_BYTE_0",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV4_SIP_BYTE_1",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV4_SIP_BYTE_2",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV4_SIP_BYTE_3",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV4_MASK_FRAGMENT",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV4_PROTOCOL",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_DIP_BYTES_0_TO_7",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_DIP_BYTES_8",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_DIP_BYTES_9",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_DIP_BYTES_10",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_DIP_BYTES_11",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_DIP_BYTES_12",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_DIP_BYTES_13",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_DIP_BYTES_14",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_DIP_BYTES_15",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_SIP_BYTES_0_TO_7",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_SIP_BYTES_8",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_SIP_BYTES_9",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_SIP_BYTES_10",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_SIP_BYTES_11",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_SIP_BYTES_12",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_SIP_BYTES_13",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_SIP_BYTES_14",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_SIP_BYTES_15",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_FLOW_LABEL",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_IPV6_NEXT_HEADER",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_L4_DPORT",
    "SX_FLOW_ESTIMATOR_PROFILE_HASH_INNER_L4_SPORT",
};

#define EST_PROF_HASH_FIELDS_STR_LEN (sizeof(s_est_prof_hash_fields_str) / sizeof(char*))

#define IS_FLOW_ESTIMATOR_COUNTING_ENABLED()                      \
    ((rm_resource_global.cntr_lines_flow_estimator > 0) &&        \
     (rm_resource_global.cntr_type_flow_estimator > 0) &&         \
     (rm_resource_global.flow_estimator_cntr_max_profile > 0) &&  \
     (rm_resource_global.flow_estimator_cntr_max_bins_log > 0) && \
     (rm_resource_global.flow_estimator_cntr_bins_per_estimator > 0))

/* Default hash params are with 5 tuple (SIP, DIP, SPort, DPort, Protocol) fields being enabled */
sx_flow_estimator_profile_hash_field_enable_t s_default_est_prof_hash_enable_arr[] = {
    SX_FLOW_EST_PROF_HASH_FIELD_ENABLE_OUTER_IPV4_TCP_UDP_E,
    SX_FLOW_EST_PROF_HASH_FIELD_ENABLE_OUTER_IPV6_TCP_UDP_E,
    SX_FLOW_EST_PROF_HASH_FIELD_ENABLE_OUTER_IPV4_E,
    SX_FLOW_EST_PROF_HASH_FIELD_ENABLE_OUTER_IPV6_E
};
#define DFAULT_EST_PROF_HASH_ENABLES_NUM          \
    (sizeof(s_default_est_prof_hash_enable_arr) / \
     sizeof(s_default_est_prof_hash_enable_arr[0]))

sx_flow_estimator_profile_hash_field_t s_default_est_prof_hash_field_arr[] = {
    SX_FLOW_EST_PROF_HASH_OUTER_IPV4_DIP_BYTE_0_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV4_DIP_BYTE_1_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV4_DIP_BYTE_2_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV4_DIP_BYTE_3_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV4_SIP_BYTE_0_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV4_SIP_BYTE_1_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV4_SIP_BYTE_2_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV4_SIP_BYTE_3_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV4_PROTOCOL_E,

    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_DIP_BYTES_0_TO_7_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_DIP_BYTES_8_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_DIP_BYTES_9_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_DIP_BYTES_10_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_DIP_BYTES_11_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_DIP_BYTES_12_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_DIP_BYTES_13_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_DIP_BYTES_14_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_DIP_BYTES_15_E,

    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_SIP_BYTES_0_TO_7_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_SIP_BYTES_8_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_SIP_BYTES_9_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_SIP_BYTES_10_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_SIP_BYTES_11_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_SIP_BYTES_12_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_SIP_BYTES_13_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_SIP_BYTES_14_E,
    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_SIP_BYTES_15_E,

    SX_FLOW_EST_PROF_HASH_OUTER_IPV6_NEXT_HEADER_E,
    SX_FLOW_EST_PROF_HASH_OUTER_L4_DPORT_E,
    SX_FLOW_EST_PROF_HASH_OUTER_L4_SPORT_E
};
#define DEFAULT_EST_PROF_HASH_FIELDS_NUM         \
    (sizeof(s_default_est_prof_hash_field_arr) / \
     sizeof(s_default_est_prof_hash_field_arr[0]))

#define DEFAULT_EST_PROF_HASH_SEED_VAL 0
#define MOCBS_READ_CLEAR               1
typedef struct cm_item {
    cl_pool_item_t       pool_item;                     /* MGMT */
    cl_map_item_t        map_item;                      /* MGMT */
    sx_flow_counter_id_t cntr_id;                       /* KEY */
} cm_item_t;

typedef enum sx_flow_counter_type {
    FLOW_COUNTER_E = 0,
    FLOW_ESTIMATOR_COUNTER_E,
} sx_flow_counter_type_e;

typedef struct sx_flow_estimator_profile_db_entry {
    boolean_t                                     allocated;    /* whether it is created via SX API */
    uint32_t                                      ref_cnt;      /* number referenced by ACL actions */
    uint32_t                                      bin_group_size;
    boolean_t                                     seed_en_by_sw;
    sx_flow_estimator_profile_hash_seed_t         seed_by_sw;
    uint32_t                                      fields_enable_list_cnt;
    uint32_t                                      fields_cnt;
    sx_flow_estimator_profile_hash_field_enable_t fields_enable_list_p[FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_ENABLES_NUM];
    sx_flow_estimator_profile_hash_field_t        fields_p[FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_NUM];
} sx_flow_estimator_profile_db_entry_t;

typedef struct sx_flow_estimator_profile_db {
    sx_flow_estimator_profile_db_entry_t profiles[SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM];
} sx_flow_estimator_profile_db_t;

typedef struct cm_by_ref_item {
    cl_map_item_t        map_item;                      /* MGMT */
    cm_type_e            cm_type;
    cm_hw_type_t         cm_hw_type;
    cm_index_t           cm_index;
    uint32_t             hw_len;
    sx_flow_counter_id_t base_counter_id;               /* KEY */
} cm_by_ref_item_t;

static flow_counter_cb_t spectrum_flow_counters;
static boolean_t         counter_by_ref_enabled = FALSE;

static inline cl_pool_item_t* __cm_parent_struct_pool_item(const void *item_p)
{
    return &((cm_item_t*)item_p)->pool_item;
}

/************************************************
 *  Global variables
 ***********************************************/
extern sx_brg_context_t brg_context;

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cntr_client_handle_t     cm_handle = NULL;
cl_qmap_t                       cm_qmap;
cl_qmap_t                       cm_by_ref_qmap;
static cl_qpool_t               cm_qpool;
static cl_qpool_t               accuflow_counters_qpool;
static sx_flow_counter_params_t g_flow_counter_init_params;
static boolean_t                g_accuflow_counters_inited = FALSE;
static boolean_t                s_flow_estimator_counting_is_enabled = FALSE;
static uint32_t                 s_flow_estimator_cntr_allowed_bulk_sizes[] = {4, 8, 16, 32, 64, 128};
static uint32_t                 s_flow_estimator_profile_allowed_bin_group_sizes[] = {16, 32, 64, 128, 256, 512};
sx_flow_estimator_profile_db_t  s_flow_estimator_profiles_db;

static sx_flow_estimator_profile_hash_t s_default_est_prof_hash_params = {
    TRUE,
    DEFAULT_EST_PROF_HASH_SEED_VAL,
    DFAULT_EST_PROF_HASH_ENABLES_NUM,
    s_default_est_prof_hash_enable_arr,
    DEFAULT_EST_PROF_HASH_FIELDS_NUM,
    s_default_est_prof_hash_field_arr,
};


/************************************************
 *  Function implementations
 ***********************************************/
static sx_status_t __flow_counters_debug_commands_register();
static sx_status_t __flow_counters_debug_commands_unregister();
static void __flow_counters_prm_idx_get_debug_cmd(FILE *stream, int argc, const char *argv[], void *handler_context);
static void __flow_counters_relocate_force(FILE *stream, int argc, const char *argv[], void *handler_context);
static void __flow_counters_relocate_undo(FILE *stream, int argc, const char *argv[], void *handler_context);

static sx_status_t __accuflow_counters_init(const sx_flow_counter_params_t *init_params_p);
static void __accuflow_counters_deinit();

static sx_status_t __flow_counter_get_all_devs_list(sx_dev_id_t *devs_list, uint16_t *devs_count)
{
    sx_status_t   err = SX_STATUS_SUCCESS;
    sx_dev_info_t leaf_filter = {
        .dev_id = 0,
        .node_type = SX_DEV_NODE_TYPE_LEAF,
    };
    length_t      dev_info_arr_size = SX_DEV_ID_MAX;
    sx_dev_info_t dev_info_arr[SX_DEV_NUM_MAX];
    length_t      dev_idx = 0;

    *devs_count = 0;

    err = topo_device_tbl_bulk_get(SX_ACCESS_CMD_GET, &leaf_filter, dev_info_arr, &dev_info_arr_size);
    for (dev_idx = 0; dev_idx < dev_info_arr_size; dev_idx++) {
        devs_list[*devs_count] = dev_info_arr[dev_idx].dev_id;
        *devs_count += 1;
    }
    return err;
}

static sx_status_t validate_flow_counter_cm_type(cm_type_e type)
{
    if ((type != CM_TYPE_PACKET_COUNTER_E) &&
        (type != CM_TYPE_BYTE_COUNTER_E) &&
        (type != CM_TYPE_PACKET_AND_BYTE_E) &&
        (type != CM_TYPE_ACCUFLOW_PACKET_AND_BYTE_E) &&
        (type != CM_TYPE_ESTIMATOR_E)) {
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t spectrum_convert_flow_counter_type(const sx_flow_counter_type_t cntr_type, cm_type_e *cm_type)
{
    switch (cntr_type) {
    case SX_FLOW_COUNTER_TYPE_BYTES:
        *cm_type = CM_TYPE_BYTE_COUNTER_E;
        break;

    case SX_FLOW_COUNTER_TYPE_PACKETS:
        *cm_type = CM_TYPE_PACKET_COUNTER_E;
        break;

    case SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES:
        *cm_type = CM_TYPE_PACKET_AND_BYTE_E;
        break;

    case SX_FLOW_COUNTER_TYPE_ACCUMULATED:
        *cm_type = CM_TYPE_ACCUFLOW_PACKET_AND_BYTE_E;
        break;

    case SX_FLOW_COUNTER_TYPE_ESTIMATOR:
        *cm_type = CM_TYPE_ESTIMATOR_E;
        break;

    default:
        SX_LOG_ERR("%s: Unknown flow-counter type - %d\n", __func__, cntr_type);
        return SX_STATUS_PARAM_ERROR; /* Invalid type, which will fail the allocation */
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t spectrum_flow_counter_set(const sx_access_cmd_t        cmd,
                                             const sx_flow_counter_type_t cntr_type,
                                             sx_flow_counter_id_t        *cntr_id_p)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    cl_pool_item_t      *pool_item = NULL;
    cl_map_item_t       *map_item = NULL;
    cm_item_t           *cm_item = NULL;
    const cl_map_item_t *map_end = NULL;
    cm_type_e            cm_counter_type = CM_TYPE_BYTE_COUNTER_E;
    boolean_t            rbs_required_on_error = FALSE;
    boolean_t            rm_rollback = FALSE;
    boolean_t            accu_rm_rollback = FALSE;
    sx_status_t          rb_err = SX_STATUS_SUCCESS;
    cm_logical_id_t      cm_lid = 0;
    rm_sdk_table_type_e  resource = RM_SDK_TABLE_TYPE_FLOW_COUNTER_E;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(cntr_id_p, "cntr_id_p"))) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        sx_status = spectrum_convert_flow_counter_type(cntr_type, &cm_counter_type);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("spectrum_convert_flow_counter_type failed status = %d \n", sx_status);
            goto out;
        }

        switch (cntr_type) {
        case SX_FLOW_COUNTER_TYPE_ACCUMULATED:
            if (g_accuflow_counters_inited != TRUE) {
                SX_LOG_ERR("Accumulated counters are not supported. \n");
                sx_status = SX_STATUS_UNSUPPORTED;
                goto out;
            }

            sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E, SX_ACCESS_CMD_ADD, 1, NULL);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: rm_entries_set failed \n", __func__);
                goto out;
            }
            accu_rm_rollback = TRUE;

            sx_status = cm_block_add(cm_counter_type, &cm_lid);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: cm_block_add failed \n", __func__);
                goto out;
            }
            rbs_required_on_error = TRUE;

            *cntr_id_p = LID_OFFSET_TO_FLOW_CNTR_ID(cm_lid, 0);
            break;

        case SX_FLOW_COUNTER_TYPE_BYTES:
        case SX_FLOW_COUNTER_TYPE_PACKETS:
        case SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES:
            sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_FLOW_COUNTER_E, SX_ACCESS_CMD_ADD, 1, NULL);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: rm_entries_set failed \n", __func__);
                goto out;
            }
            rm_rollback = TRUE;

            sx_status = cm_block_add(cm_counter_type, &cm_lid);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: cm_block_add failed \n", __func__);
                goto out;
            }
            rbs_required_on_error = TRUE;

            *cntr_id_p = LID_OFFSET_TO_FLOW_CNTR_ID(cm_lid, 0);

            /* And clear the value */
            sx_status = flow_counter_clear(*cntr_id_p);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR("%s: flow_counter_clear failed \n", __func__);
                goto out;
            }
            break;

        default:
            SX_LOG_ERR("Unknown flow-counter type - %d\n", cntr_type);
            sx_status = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        map_item = cl_qmap_get(&(cm_qmap), *cntr_id_p);
        map_end = cl_qmap_end(&(cm_qmap));
        if (map_item == map_end) {
            if (cntr_type == SX_FLOW_COUNTER_TYPE_ACCUMULATED) {
                pool_item = cl_qpool_get(&(accuflow_counters_qpool));
            } else {
                pool_item = cl_qpool_get(&(cm_qpool));
            }
            if (pool_item == NULL) {
                SX_LOG_WRN("Could not find free cm_item.\n");
                sx_status = SX_STATUS_NO_RESOURCES;
                goto out;
            }
            cm_item = PARENT_STRUCT(pool_item, cm_item_t, pool_item);
            cm_item->cntr_id = *cntr_id_p;

            cl_qmap_insert(&(cm_qmap), *cntr_id_p, &(cm_item->map_item));
        } else {
            SX_LOG_NTC("Flow counter [0x%x] exist in DB.\n", *cntr_id_p);
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        map_item = cl_qmap_get(&(cm_qmap), *cntr_id_p);
        map_end = cl_qmap_end(&(cm_qmap));
        if (map_item == map_end) {
            SX_LOG_ERR("Could not find the flow counter[0x%x].\n",
                       *cntr_id_p);
            sx_status = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        sx_status = cm_block_delete(FLOW_CNTR_ID_LID_GET(*cntr_id_p));
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("%s: cm_block_delete failed \n", __func__);
            /* align return code of spectrum with previous version */
            if (sx_status == SX_STATUS_DB_NOT_EMPTY) {
                sx_status = SX_STATUS_RESOURCE_IN_USE;
            }

            goto out;
        }

        cm_item = PARENT_STRUCT(map_item, cm_item_t, map_item);
        cl_qmap_remove(&(cm_qmap), *cntr_id_p);
        if (cm_counter_bank_type_get(FLOW_CNTR_ID_LID_GET(*cntr_id_p)) == CM_ACCUFLOW_COUNTERS_BANKS_E) {
            cl_qpool_put(&(accuflow_counters_qpool), &(cm_item->pool_item));
            resource = RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E;
        } else {
            cl_qpool_put(&(cm_qpool), &(cm_item->pool_item));
            resource = RM_SDK_TABLE_TYPE_FLOW_COUNTER_E;
        }
        sx_status = rm_entries_set(resource, SX_ACCESS_CMD_DELETE, 1, NULL);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: rm_entries_set failed \n", __func__);
            goto out;
        }
        break;

    default:
        /* cmd not supported */
        return SX_STATUS_CMD_UNSUPPORTED;
    }

out:
    if (sx_status) {
        if (rbs_required_on_error) {
            rb_err = cm_block_delete(FLOW_CNTR_ID_LID_GET(*cntr_id_p));
            /* coverity[example_checked] */
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("Failed to delete cm block"
                           "err = [%s] (%d)\n", sx_status_str(rb_err), rb_err);
            }
        }
        if (rm_rollback) {
            rb_err = rm_entries_set(RM_SDK_TABLE_TYPE_FLOW_COUNTER_E, SX_ACCESS_CMD_DELETE, 1, NULL);
            if (SX_STATUS_SUCCESS != rb_err) {
                SX_LOG_ERR("%s: rm_entries_set failed, error: [%s] (%d) \n",
                           __func__, sx_status_str(rb_err), rb_err);
            }
        }
        if (accu_rm_rollback) {
            rb_err = rm_entries_set(RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E, SX_ACCESS_CMD_DELETE, 1, NULL);
            if (SX_STATUS_SUCCESS != rb_err) {
                SX_LOG_ERR("%s: rm_entries_set failed, error: [%s] (%d) \n",
                           __func__, sx_status_str(rb_err), rb_err);
            }
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_flow_counter_get_impl(cm_index_t             cntr_offset,
                                      cm_type_e              type,
                                      cm_hw_type_t           hw_type,
                                      sx_flow_counter_set_t *counter_set_p)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status;
    sx_dev_id_t        devs_list[SX_DEV_NUM_MAX];
    uint16_t           devs_count = 0;
    uint32_t           dev_idx;
    struct ku_mgpc_reg mgpc;
    sxd_reg_meta_t     meta;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(mgpc);
    SX_MEM_CLR_P(counter_set_p);

    meta.access_cmd = SXD_ACCESS_CMD_GET;
    mgpc.counter_set.index = cntr_offset;
    mgpc.counter_set.type = hw_type;
    mgpc.counter_opcode = SXD_COUNTER_OPCODE_NOP;

    __flow_counter_get_all_devs_list(devs_list, &devs_count);
    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        meta.dev_id = devs_list[dev_idx];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MGPC_E, &mgpc, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("%s: Failed to read MGPC [index=%u,err=%u]\n",
                       __func__, cntr_offset, sxd_status);
            sx_status = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
        switch (type) {
        case CM_TYPE_PACKET_COUNTER_E:
            counter_set_p->flow_counter_packets += mgpc.packet_counter;
            break;

        case CM_TYPE_BYTE_COUNTER_E:
            counter_set_p->flow_counter_bytes += mgpc.byte_counter;
            break;

        case CM_TYPE_PACKET_AND_BYTE_E:
            counter_set_p->flow_counter_bytes += mgpc.byte_counter;
            counter_set_p->flow_counter_packets += mgpc.packet_counter;
            break;

        case CM_TYPE_ESTIMATOR_E:
            SX_LOG_ERR("%s: Not support get operations for type %d\n",
                       __func__, type);
            break;

        default:
            break;
        }
    }

out:
    return sx_status;
}

sx_status_t sdk_flow_estimator_counter_get_impl(boolean_t                        clear,
                                                cm_index_t                       cntr_idx,
                                                sx_flow_estimator_counter_set_t *counter_set_p)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_dev_id_t         devs_list[SX_DEV_NUM_MAX];
    uint16_t            devs_count = 0;
    uint32_t            dev_idx = 0;
    struct ku_mofrb_reg mofrb;
    sxd_reg_meta_t      meta;
    uint32_t            i = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(meta);
    SX_MEM_CLR(mofrb);
    SX_MEM_CLR_P(counter_set_p);
    SX_MEM_CLR_P(devs_list);

    meta.access_cmd = SXD_ACCESS_CMD_GET;
    mofrb.clear = clear;
    mofrb.counter_index_base = cntr_idx;
    mofrb.num_rec = FLOW_ESTIMATOR_BINS_PER_FLOW_COUNTER; /* 4 flow bins per counter */

    __flow_counter_get_all_devs_list(devs_list, &devs_count);
    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        meta.dev_id = devs_list[dev_idx];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOFRB_E, &mofrb, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to read MGPC [index=%u,err=%u]\n",
                       cntr_idx, sxd_status);
            sx_status = sxd_status_to_sx_status(sxd_status);
            goto out;
        }

        for (i = 0; i < FLOW_ESTIMATOR_BINS_PER_FLOW_COUNTER; i++) {
            counter_set_p->flow_estimator_bins[i] += mofrb.flow_estimator_bin[i];
        }
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __flow_counter_operation(cm_hw_type_t hw_type, cm_index_t cntr_offset, uint8_t opcode)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status;
    sx_dev_id_t        devs_list[SX_DEV_NUM_MAX];
    uint16_t           devs_count = 0;
    uint32_t           dev_idx;
    struct ku_mgpc_reg mgpc;
    sxd_reg_meta_t     meta;

    CL_ASSERT(opcode != SXD_COUNTER_OPCODE_ADD_COUNTERS);

    SX_MEM_CLR(meta);
    SX_MEM_CLR(mgpc);

    meta.access_cmd = SXD_ACCESS_CMD_SET;
    mgpc.counter_set.index = cntr_offset;
    mgpc.counter_set.type = hw_type;
    mgpc.counter_opcode = opcode;

    __flow_counter_get_all_devs_list(devs_list, &devs_count);
    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        meta.dev_id = devs_list[dev_idx];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MGPC_E, &mgpc, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("%s: Failed to access MGPC [opcode=%u, index=%u,err=%u]\n",
                       __func__, opcode, cntr_offset, sxd_status);
            sx_status = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }

out:
    return sx_status;
}

static sx_status_t sdk_flow_counter_clear_impl(cm_logical_id_t lid,
                                               cm_type_e       type,
                                               cm_hw_type_t    hw_type,
                                               cm_index_t      cntr_offset)
{
    sx_status_t sx_status;

    SX_LOG_ENTER();

    UNUSED_PARAM(lid);

    sx_status = validate_flow_counter_cm_type(type);
    if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_DBG("%s: Not a flow counter type - %d\n", __func__, type);
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: Invalid counter type - %d\n", __func__, type);
        goto out;
    }

    sx_status = __flow_counter_operation(hw_type, cntr_offset, SXD_COUNTER_OPCODE_CLEAR_COUNTERS);

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t sdk_flow_counter_add_impl(cm_logical_id_t lid,
                                             cm_type_e       type,
                                             cm_hw_type_t    hw_type,
                                             cm_index_t      src_cntr,
                                             cm_index_t      dst_cntr)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status;
    sx_dev_id_t        devs_list[SX_DEV_NUM_MAX];
    uint16_t           devs_count = 0;
    uint32_t           dev_idx;
    struct ku_mgpc_reg mgpc;
    sxd_reg_meta_t     meta;

    SX_LOG_ENTER();

    UNUSED_PARAM(lid);
    SX_MEM_CLR(meta);
    SX_MEM_CLR(mgpc);

    sx_status = validate_flow_counter_cm_type(type);
    if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_DBG("%s: Not a flow counter type - %d\n", __func__, type);
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: Invalid counter type - %d\n", __func__, type);
        goto out;
    }

    /* Flush and read previous value */
    sx_status = __flow_counter_operation(hw_type, src_cntr, SXD_COUNTER_OPCODE_FLUSH_COUNTERS);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: SXD_COUNTER_OPCODE_FLUSH_COUNTERS failed\n", __func__);
        goto out;
    }

    mgpc.counter_set.type = hw_type;
    __flow_counter_get_all_devs_list(devs_list, &devs_count);
    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        /* Read the previous MGPC value */
        meta.dev_id = devs_list[dev_idx];
        meta.access_cmd = SXD_ACCESS_CMD_GET;
        mgpc.counter_set.index = src_cntr;
        mgpc.counter_opcode = SXD_COUNTER_OPCODE_NOP;
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MGPC_E, &mgpc, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("%s: Failed to get MGPC [index=%u,err=%u]\n",
                       __func__, src_cntr, sxd_status);
            sx_status = sxd_status_to_sx_status(sxd_status);
            goto out;
        }

        /* And add it to the new counter */
        meta.access_cmd = SXD_ACCESS_CMD_SET;
        mgpc.counter_set.index = dst_cntr;
        mgpc.counter_opcode = SXD_COUNTER_OPCODE_ADD_COUNTERS;
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MGPC_E, &mgpc, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("%s: Failed to add MGPC [index=%u,err=%u]\n",
                       __func__, dst_cntr, sxd_status);
            sx_status = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }

out:
    return sx_status;
}

static sx_status_t spectrum_flow_counter_lock(sx_flow_counter_id_t cntr_id,
                                              cm_type_e           *type_p,
                                              cm_hw_type_t        *hw_type_p,
                                              cm_index_t          *index_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    cm_index_t  cm_index = 0;
    cm_type_e   cm_type = 0;
    cm_attr_t   cm_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(cm_attr);

    sx_status = cm_lock(FLOW_CNTR_ID_LID_GET(cntr_id), &cm_type, hw_type_p, &cm_index);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: cm_lock failed [lid=%u, flow_counter_id=%u]\n",
                   __func__, FLOW_CNTR_ID_LID_GET(cntr_id), cntr_id);
        if (sx_status == SX_STATUS_ERROR) {
            sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        }
        goto out;
    }

    sx_status = cm_lid_attr_get(FLOW_CNTR_ID_LID_GET(cntr_id), &cm_attr);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: cm_return_len failed\n", __func__);
        goto out;
    }

    if (type_p != NULL) {
        *type_p = cm_type;
    }

    if (index_p != NULL) {
        *index_p = cm_index + cm_attr.hw_len * FLOW_CNTR_ID_OFFSET_GET(cntr_id);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t spectrum_flow_counter_unlock(sx_flow_counter_id_t cntr_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    sx_status = cm_unlock(FLOW_CNTR_ID_LID_GET(cntr_id));
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: cm_unlock failed [lid=%u flow_counter_id=%u]\n",
                   __func__, FLOW_CNTR_ID_LID_GET(cntr_id), cntr_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t spectrum_flow_counter_lock_spc4(sx_flow_counter_id_t cntr_id,
                                                   cm_type_e           *type_p,
                                                   cm_hw_type_t        *hw_type_p,
                                                   cm_index_t          *index_p)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    cm_by_ref_item_t    *cm_by_ref_item = NULL;
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;
    sx_flow_counter_id_t base_cntr_id;

    SX_LOG_ENTER();

    base_cntr_id = LID_OFFSET_TO_FLOW_CNTR_ID(FLOW_CNTR_ID_LID_GET(cntr_id), 0);
    map_item = cl_qmap_get(&(cm_by_ref_qmap), base_cntr_id);
    map_end = cl_qmap_end(&(cm_by_ref_qmap));
    if (map_item != map_end) {
        /*counter by ref block is always locked, can't lock again*/
        cm_by_ref_item = PARENT_STRUCT(map_item, cm_by_ref_item_t, map_item);
        if (type_p) {
            *type_p = cm_by_ref_item->cm_type;
        }
        if (hw_type_p) {
            *hw_type_p = cm_by_ref_item->cm_hw_type;
        }
        if (index_p) {
            *index_p = cm_by_ref_item->cm_index + cm_by_ref_item->hw_len * FLOW_CNTR_ID_OFFSET_GET(cntr_id);
        }
        return sx_status;
    }

    return spectrum_flow_counter_lock(cntr_id, type_p, hw_type_p, index_p);
}

static sx_status_t spectrum_flow_counter_unlock_spc4(sx_flow_counter_id_t cntr_id)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;
    sx_flow_counter_id_t base_cntr_id;

    SX_LOG_ENTER();

    base_cntr_id = LID_OFFSET_TO_FLOW_CNTR_ID(FLOW_CNTR_ID_LID_GET(cntr_id), 0);
    map_item = cl_qmap_get(&(cm_by_ref_qmap), base_cntr_id);
    map_end = cl_qmap_end(&(cm_by_ref_qmap));
    if (map_item != map_end) {
        return sx_status;
    }

    return spectrum_flow_counter_unlock(cntr_id);
}

static sx_status_t spectrum_flow_counter_ref_inc(sx_flow_counter_id_t cntr_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = cm_ref_inc(FLOW_CNTR_ID_LID_GET(cntr_id));
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: cm_ref_inc failed [lid=%u flow_counter_id=%u]\n",
                   __func__, FLOW_CNTR_ID_LID_GET(cntr_id), cntr_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t spectrum_flow_counter_ref_dec(sx_flow_counter_id_t cntr_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = cm_ref_dec(FLOW_CNTR_ID_LID_GET(cntr_id));
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: cm_ref_dec failed [lid=%u flow_counter_id=%u]\n",
                   __func__, FLOW_CNTR_ID_LID_GET(cntr_id), cntr_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t spectrum_flow_counter_ref_modify(sx_flow_counter_id_t cntr_id, int32_t val)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = cm_ref_modify(FLOW_CNTR_ID_LID_GET(cntr_id), val);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: cm_ref_modify failed [lid=%u flow_counter_id=%u]\n",
                   __func__, FLOW_CNTR_ID_LID_GET(cntr_id), cntr_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t spectrum_flow_counter_get(sx_flow_counter_id_t cntr_id, sx_flow_counter_set_t *counter_set)
{
    sx_status_t  sx_status = SX_STATUS_SUCCESS;
    cm_hw_type_t cm_hw_type = 0;
    cm_type_e    cm_type = 0;
    cm_index_t   cm_index = 0;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(counter_set, "counter_set"))) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    switch (cm_counter_bank_type_get(FLOW_CNTR_ID_LID_GET(cntr_id))) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        if (g_accuflow_counters_inited != TRUE) {
            SX_LOG_ERR("Accumulated counters are not supported. \n");
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        sx_status = cm_block_get(FLOW_CNTR_ID_LID_GET(cntr_id), FLOW_CNTR_ID_OFFSET_GET(cntr_id), counter_set);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("%s: cm_block_get failed [lid=%u]\n", __func__, cntr_id);
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
        sx_status = spectrum_flow_counters.lock(cntr_id, &cm_type, &cm_hw_type, &cm_index);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("%s: spectrum_flow_counter_lock failed [cntr_id=%u]\n",
                       __func__, cntr_id);
            if (sx_status == SX_STATUS_ERROR) {
                sx_status = SX_STATUS_ENTRY_NOT_FOUND;
            }

            goto out;
        }

        sx_status = validate_flow_counter_cm_type(cm_type);
        if (SX_STATUS_SUCCESS != sx_status) {
            /* coverity[check_return] */
            spectrum_flow_counters.unlock(cntr_id);
            SX_LOG_ERR("%s: Invalid counter type - %d\n", __func__, cm_type);
            goto out;
        }

        if (cm_type == CM_TYPE_ESTIMATOR_E) {
            spectrum_flow_counters.unlock(cntr_id);
            SX_LOG_ERR("Counter ID %u is flow estimator type and not supported via this API.\n", cntr_id);
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        sx_status = sdk_flow_counter_get_impl(cm_index, cm_type, cm_hw_type, counter_set);
        if (SX_STATUS_SUCCESS != sx_status) {
            /* coverity[check_return] */
            spectrum_flow_counters.unlock(cntr_id);
            SX_LOG_ERR("%s: __get_counter_from_hw failed [cntr_id=%u]\n", __func__, cntr_id);
            goto out;
        }

        sx_status = spectrum_flow_counters.unlock(cntr_id);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("%s: cm_unlock failed [cntr_id=%u]\n", __func__, cntr_id);
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Unsupported flow counter ID: [0x%x]. \n", cntr_id);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t spectrum_flow_counter_clear(sx_flow_counter_id_t cntr_id)
{
    sx_status_t  sx_status = SX_STATUS_SUCCESS;
    cm_type_e    cm_type = 0;
    cm_hw_type_t cm_hw_type = 0;
    cm_index_t   cm_index = 0;

    SX_LOG_ENTER();

    switch (cm_counter_bank_type_get(FLOW_CNTR_ID_LID_GET(cntr_id))) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        if (g_accuflow_counters_inited != TRUE) {
            SX_LOG_ERR("Accumulated counters are not supported. \n");
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        sx_status = cm_block_clear(FLOW_CNTR_ID_LID_GET(cntr_id), FLOW_CNTR_ID_OFFSET_GET(cntr_id));
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("cm_block_clear failed [lid=%u]\n", cntr_id);
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
        sx_status = spectrum_flow_counters.lock(cntr_id, &cm_type, &cm_hw_type, &cm_index);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("spectrum_flow_counter : spectrum_flow_counter_lock failed \n");
            /* align return code of spectrum with previous version */
            if (sx_status == SX_STATUS_ERROR) {
                sx_status = SX_STATUS_ENTRY_NOT_FOUND;
            }
            goto out;
        }

        if (cm_type == CM_TYPE_ESTIMATOR_E) {
            spectrum_flow_counters.unlock(cntr_id);
            SX_LOG_ERR("Estimator counters are not supported. \n");
            sx_status = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        sx_status = sdk_flow_counter_clear_impl(cntr_id, cm_type, cm_hw_type, cm_index);
        if (SX_STATUS_SUCCESS != sx_status) {
            /* coverity[check_return] */
            spectrum_flow_counters.unlock(cntr_id);
            SX_LOG_ERR("spectrum_flow_counter : sdk_flow_counter_clear_impl failed \n");
            goto out;
        }

        sx_status = spectrum_flow_counters.unlock(cntr_id);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("spectrum_flow_counter : spectrum_flow_counter_unlock failed \n");
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Unsupported flow counter ID: [0x%x]. \n", cntr_id);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t spectrum_flow_counter_is_exists(sx_flow_counter_id_t cntr_id)
{
    cm_attr_t attr;

    SX_MEM_CLR(attr);

    if (cm_lid_attr_get(FLOW_CNTR_ID_LID_GET(cntr_id), &attr) != SX_STATUS_SUCCESS) {
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    if (FLOW_CNTR_ID_OFFSET_GET(cntr_id) >= attr.size) {
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    SX_LOG_DBG("Counter[%u] has type[%u] & hw type[%u] size[%u].\n ",
               cntr_id, attr.type, attr.hw_type, attr.size);

    return validate_flow_counter_cm_type(attr.type);
}

static sx_status_t spectrum_flow_counter_accumulated_num_get(uint32_t *accumulated_type_max_number_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(err = utils_check_pointer(accumulated_type_max_number_p, "accumulated_type_max_number"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (g_accuflow_counters_inited != TRUE) {
        *accumulated_type_max_number_p = 0;
    } else {
        *accumulated_type_max_number_p = \
            g_flow_counter_init_params.flow_counter_accumulated_type_max_number * 1024 *
            rm_resource_global.accuflow_cntr_lines_flow_both;
    }

out:
    return err;
}

static boolean_t spectrum_flow_counter_is_accuflow(sx_flow_counter_id_t cntr_id)
{
    if (cm_counter_bank_type_get(FLOW_CNTR_ID_LID_GET(cntr_id)) == CM_ACCUFLOW_COUNTERS_BANKS_E) {
        return TRUE;
    } else {
        return FALSE;
    }
}

static boolean_t __flow_counter_is_estimator_type(sx_flow_counter_id_t cntr_base_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    cm_attr_t   cm_attr;
    boolean_t   is_estimator = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(cm_attr);

    sx_status = cm_lid_attr_get(FLOW_CNTR_ID_LID_GET(cntr_base_id), &cm_attr);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: cm_lid_attr_get failed\n", __func__);
        goto out;
    }
    if (cm_attr.type == CM_TYPE_ESTIMATOR_E) {
        is_estimator = TRUE;
    }

out:
    SX_LOG_EXIT();
    return is_estimator;
}

static boolean_t spectrum_flow_estimator_counting_is_enabled()
{
    return s_flow_estimator_counting_is_enabled;
}

static sx_status_t __flow_estimator_operation_precheck(boolean_t check_size, uint32_t size)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    arr_len = 0;
    uint32_t    i;

    if (!s_flow_estimator_counting_is_enabled) {
        SX_LOG_ERR("Estimator counting are not supported. \n");
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if (check_size) {
        arr_len = sizeof(s_flow_estimator_cntr_allowed_bulk_sizes) /
                  sizeof(s_flow_estimator_cntr_allowed_bulk_sizes[0]);
        for (i = 0; i < arr_len; i++) {
            if (size == s_flow_estimator_cntr_allowed_bulk_sizes[i]) {
                break;
            }
        }
        if (i == arr_len) {
            sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Estimator counter size is out of range of valid values: [ 4, 8, 16, 32, 64, 128 ].\n");
            goto out;
        }
    }
out:
    return sx_status;
}

static sx_status_t spectrum_flow_estimator_counter_get(const sx_access_cmd_t            cmd,
                                                       sx_flow_counter_id_t             cntr_id,
                                                       sx_flow_estimator_counter_set_t *counter_set)
{
    sx_status_t  sx_status = SX_STATUS_SUCCESS;
    cm_hw_type_t cm_hw_type = 0;
    cm_type_e    cm_type = 0;
    cm_index_t   cm_index = 0;
    boolean_t    clear = FALSE;

    SX_LOG_ENTER();

    if (!s_flow_estimator_counting_is_enabled) {
        SX_LOG_ERR("Estimator counting are not supported. \n");
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
        break;

    case SX_ACCESS_CMD_READ_CLEAR:
        clear = TRUE;
        break;

    default:
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access command: [%s].\n", sx_access_cmd_str(cmd));
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(counter_set, "counter_set"))) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!__flow_counter_is_estimator_type(cntr_id)) {
        SX_LOG_ERR("Counter ID [0x%x] is not estimator type. \n", cntr_id);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sx_status = spectrum_flow_counters.lock(cntr_id, &cm_type, &cm_hw_type, &cm_index);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: spectrum_flow_counter_lock failed [cntr_id=%u]\n",
                   __func__, cntr_id);
        if (sx_status == SX_STATUS_ERROR) {
            sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        }

        goto out;
    }

    sx_status = sdk_flow_estimator_counter_get_impl(clear, cm_index, counter_set);
    if (SX_STATUS_SUCCESS != sx_status) {
        /* coverity[check_return] */
        spectrum_flow_counters.unlock(cntr_id);
        SX_LOG_ERR("%s: __get_counter_from_hw failed [cntr_id=%u]\n", __func__, cntr_id);
        goto out;
    }

    sx_status = spectrum_flow_counters.unlock(cntr_id);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: cm_unlock failed [cntr_id=%u]\n", __func__, cntr_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

/* If the filter is not given, none of counters is skipped,
 *  and the function will return TRUE.
 *  If the filter is given and the given counter doesn't match
 *  the filter, the function will return FALSE. */
static boolean_t spectrum_flow_counter_is_filtered(const sx_flow_counter_filter_t *cntr_filter_p,
                                                   sx_flow_counter_id_t            cntr_id)
{
    boolean_t filtered = TRUE;

    if (cntr_filter_p != NULL) {
        filtered = FALSE;

        switch (cntr_filter_p->filter_by_type) {
        case SX_FLOW_COUNTER_FILTER_FIELD_VALID_E:

            switch (cntr_filter_p->type) {
            case SX_FLOW_COUNTER_TYPE_BYTES:
            case SX_FLOW_COUNTER_TYPE_PACKETS:
            case SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES:
                filtered = !spectrum_flow_counter_is_accuflow(cntr_id);
                break;

            case SX_FLOW_COUNTER_TYPE_ACCUMULATED:
                filtered = spectrum_flow_counter_is_accuflow(cntr_id);
                break;

            case SX_FLOW_COUNTER_TYPE_ESTIMATOR:
                filtered = __flow_counter_is_estimator_type(cntr_id);
                break;

            default:
                goto out;
            }

            break;

        case SX_FLOW_COUNTER_FILTER_FIELD_NOT_VALID_E:
            filtered = TRUE;
            break;

        default:
            goto out;
        }
    }

out:
    return filtered;
}

sx_status_t spectrum_flow_counter_iter_get(const sx_access_cmd_t           access_cmd,
                                           const sx_flow_counter_id_t      cntr_id,
                                           const sx_flow_counter_filter_t *cntr_filter_p,
                                           sx_flow_counter_id_t           *cntr_id_list_p,
                                           uint32_t                       *cntr_id_cnt_p)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t       *start_map_item = NULL;
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;
    cm_item_t           *cm_item = NULL;
    uint32_t             ii = 0;
    uint32_t             data_count = 0;

    /* Check count != NULL */
    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(cntr_id_cnt_p, "cntr_id_cnt_p"))) {
        goto out;
    }

    if (*cntr_id_cnt_p != 0) {
        if (SX_CHECK_FAIL(sx_status = utils_check_pointer(cntr_id_list_p,
                                                          "cntr_id_list_p"))) {
            goto out;
        }
    }

    data_count = *cntr_id_cnt_p;

    switch (access_cmd) {
    case SX_ACCESS_CMD_GETNEXT:
        /* Can be the tail if it doesn't exist */
        start_map_item = cl_qmap_get_next(&(cm_qmap), cntr_id);
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        start_map_item = cl_qmap_head(&(cm_qmap));
        break;

    case SX_ACCESS_CMD_GET:
        if (*cntr_id_cnt_p == 0) {
            *cntr_id_cnt_p = cl_qmap_count(&(cm_qmap));
        } else {
            if (cl_qmap_contains(&(cm_qmap), cntr_id)) {
                cntr_id_list_p[0] = cntr_id;
                *cntr_id_cnt_p = 1;
            } else {
                *cntr_id_cnt_p = 0;
            }
        }
        goto out;

    default:
        SX_LOG_ERR("Command is not supported for iterator\n");
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (data_count && start_map_item) {
        ii = 0;
        map_item = start_map_item;
        map_end = cl_qmap_end(&(cm_qmap));
        while (map_item != map_end) {
            cm_item = PARENT_STRUCT(map_item, cm_item_t, map_item);
            if (spectrum_flow_counter_is_filtered(cntr_filter_p, cm_item->cntr_id)) {
                cntr_id_list_p[ii++] = cm_item->cntr_id;
                if (ii >= data_count) {
                    break;
                }
            }
            map_item = cl_qmap_next(map_item);
        }
        *cntr_id_cnt_p = ii;
    } else {
        *cntr_id_cnt_p = 0;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __flow_counter_type_set(cm_index_t             cntr_base_idx,
                                           uint32_t               flow_cntr_num,
                                           sx_flow_counter_type_e type)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status;
    sx_dev_id_t        devs_list[SX_DEV_NUM_MAX];
    uint16_t           devs_count = 0;
    uint32_t           dev_idx;
    cm_type_e          cm_type = 0;
    cm_hw_type_t       cm_hw_type = 0;
    cm_index_t         cm_index = 0;
    boolean_t          need_unlock = FALSE;
    sx_status_t        rb_err = SX_STATUS_SUCCESS;
    struct ku_moca_reg moca;
    sxd_reg_meta_t     meta;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(moca);

    sx_status = spectrum_flow_counters.lock(cntr_base_idx, &cm_type, &cm_hw_type, &cm_index);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("spectrum_flow_counter : spectrum_flow_counter_lock failed \n");
        if (sx_status == SX_STATUS_ERROR) {
            sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        }
        goto out;
    }
    need_unlock = TRUE;

    meta.access_cmd = SXD_ACCESS_CMD_SET;
    moca.counter_index = cm_index;
    moca.size = flow_cntr_num * 2; /* each flow counter consumes to 2 HW counters */
    moca.counter_type = type;

    __flow_counter_get_all_devs_list(devs_list, &devs_count);
    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        meta.dev_id = devs_list[dev_idx];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOCA_E, &moca, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("%s: Failed to access MOCA [index=%u, size=%u, type=%u, err=%u]\n",
                       __func__, cntr_base_idx, flow_cntr_num * 2, type, sxd_status);
            sx_status = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }
out:
    if (need_unlock) {
        rb_err = spectrum_flow_counters.unlock(cntr_base_idx);
        if (SX_STATUS_SUCCESS != rb_err) {
            SX_LOG_ERR("spectrum_flow_counter : spectrum_flow_counter_unlock failed \n");
        }
    }
    return sx_status;
}

sx_status_t spec4_reg_write_mocbr(boolean_t enable, boolean_t use_long_index)
{
    sx_status_t         rc = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    struct ku_mocbr_reg mocbr_reg_data = {.e = 1};
    sxd_reg_meta_t      mocbr_reg_meta = {.access_cmd = 0};
    sx_dev_id_t         devs_list[SX_DEV_NUM_MAX];
    uint16_t            devs_count = 0;
    uint32_t            dev_idx;

    SX_MEM_CLR(mocbr_reg_meta);
    SX_MEM_CLR(mocbr_reg_data);

    mocbr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    mocbr_reg_data.e = enable;
    mocbr_reg_data.l = use_long_index;

    __flow_counter_get_all_devs_list(devs_list, &devs_count);
    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        mocbr_reg_meta.dev_id = devs_list[dev_idx];
        sxd_status =
            sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOCBR_E, &mocbr_reg_data, &mocbr_reg_meta, 1, NULL, NULL);
        if (SXD_STATUS_SUCCESS != sxd_status) {
            SX_LOG_ERR("ACL : Failed to configure MOCBR rc [%u]\n", sxd_status);
            rc = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t spectrum_flow_counter_bulk_set(const sx_access_cmd_t             cmd,
                                           const sx_flow_counter_bulk_attr_t bulk_attr,
                                           sx_flow_counter_bulk_data_t      *bulk_data_p)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    cl_pool_item_t      *pool_item = NULL;
    cl_map_item_t       *map_item = NULL;
    cm_item_t           *cm_item = NULL;
    const cl_map_item_t *map_end = NULL;
    cm_type_e            cm_counter_type = CM_TYPE_BYTE_COUNTER_E;
    boolean_t            rbs_required_on_error = FALSE;
    boolean_t            rm_rollback = FALSE;
    boolean_t            afrm_rollback = FALSE;
    boolean_t            flow_type_rollback = FALSE;
    sx_status_t          rb_err = SX_STATUS_SUCCESS;
    cm_logical_id_t      cm_lid = 0;
    sx_flow_counter_id_t cntr_id = 0;
    uint32_t             i = 0, offset = 0;
    cm_attr_t            cm_attr;
    cm_by_ref_item_t    *cm_by_ref_item = NULL;
    cm_hw_type_t         cm_hw_type = 0;
    cm_type_e            cm_type = 0;
    cm_index_t           cm_index = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(cm_attr);

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        sx_status = spectrum_convert_flow_counter_type(bulk_attr.counter_type, &cm_counter_type);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("spectrum_convert_flow_counter_type failed status = %d \n", sx_status);
            goto out;
        }

        if (bulk_attr.inc_by_ref_en) {
            if (brg_context.spec_cb_g.dev_type < SX_CHIP_TYPE_SPECTRUM4) {
                sx_status = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("inc_by_ref_en only supported on spectrum4 and above\n");
                goto out;
            }

            if ((bulk_attr.counter_type == SX_FLOW_COUNTER_TYPE_ACCUMULATED) ||
                (bulk_attr.counter_type == SX_FLOW_COUNTER_TYPE_ESTIMATOR)) {
                sx_status = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("inc_by_ref_en is not supported for accumulated or estimator flow counter\n");
                goto out;
            }
        }

        if (bulk_attr.counter_type == SX_FLOW_COUNTER_TYPE_ESTIMATOR) {
            sx_status = __flow_estimator_operation_precheck(TRUE, bulk_attr.counter_num);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR("flow estimator operation is not allowed, failed status = %d \n", sx_status);
                goto out;
            }
        }

        switch (bulk_attr.counter_type) {
        case SX_FLOW_COUNTER_TYPE_ACCUMULATED:
            if (g_accuflow_counters_inited != TRUE) {
                SX_LOG_ERR("Accumulated counters are not supported. \n");
                sx_status = SX_STATUS_UNSUPPORTED;
                goto out;
            }

            sx_status =
                rm_entries_set(RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E, SX_ACCESS_CMD_ADD, bulk_attr.counter_num, NULL);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: rm_entries_set failed \n", __func__);
                goto out;
            }
            afrm_rollback = TRUE;

            sx_status = cm_bulk_block_add(cm_counter_type, bulk_attr.counter_num, &cm_lid);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: cm_block_add failed \n", __func__);
                goto out;
            }
            rbs_required_on_error = TRUE;

            break;

        case SX_FLOW_COUNTER_TYPE_BYTES:
        case SX_FLOW_COUNTER_TYPE_PACKETS:
        case SX_FLOW_COUNTER_TYPE_PACKETS_AND_BYTES:
        case SX_FLOW_COUNTER_TYPE_ESTIMATOR:
            sx_status =
                rm_entries_set(RM_SDK_TABLE_TYPE_FLOW_COUNTER_E, SX_ACCESS_CMD_ADD, bulk_attr.counter_num, NULL);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: rm_entries_set failed \n", __func__);
                goto out;
            }
            rm_rollback = TRUE;

            sx_status = cm_bulk_block_add(cm_counter_type, bulk_attr.counter_num, &cm_lid);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: cm_bulk_block_add failed to"
                                         "allocated bulk size %d\n", __func__, bulk_attr.counter_num);
                goto out;
            }
            break;

        default:
            SX_LOG_ERR("Unknown flow-counter type - %d\n", cm_counter_type);
            sx_status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        rbs_required_on_error = TRUE;
        bulk_data_p->base_counter_id = LID_OFFSET_TO_FLOW_CNTR_ID(cm_lid, 0);

        if (bulk_attr.counter_type == SX_FLOW_COUNTER_TYPE_ESTIMATOR) {
            /* change flow counter to flow estimator counter type */
            sx_status = __flow_counter_type_set(bulk_data_p->base_counter_id,
                                                bulk_attr.counter_num,
                                                FLOW_ESTIMATOR_COUNTER_E);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR(
                    "%s: __flow_counter_type_set failed to set flow counter type (%d), counter id %u, size %d\n",
                    __func__,
                    FLOW_ESTIMATOR_COUNTER_E,
                    bulk_data_p->base_counter_id,
                    bulk_attr.counter_num);
                goto out;
            }
            flow_type_rollback = TRUE;
            SX_LOG_DBG("change flow counter [%u, %u] to flow estimator counter type.\n",
                       bulk_data_p->base_counter_id,
                       bulk_attr.counter_num);
        }

        if (bulk_attr.inc_by_ref_en) {
            cm_by_ref_item = (cm_by_ref_item_t*)cl_malloc(sizeof(cm_by_ref_item_t));
            if (cm_by_ref_item == NULL) {
                SX_LOG_ERR("Failed to allocate memory for cm_by_ref_item\n");
                sx_status = SX_STATUS_NO_MEMORY;
                goto out;
            }

            sx_status = cm_lock(FLOW_CNTR_ID_LID_GET(bulk_data_p->base_counter_id), &cm_type, &cm_hw_type, &cm_index);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR("%s: spectrum_flow_counter_lock failed [cntr_id=%u]\n",
                           __func__, bulk_data_p->base_counter_id);
                if (sx_status == SX_STATUS_ERROR) {
                    sx_status = SX_STATUS_ENTRY_NOT_FOUND;
                }

                goto out;
            }
            sx_status = cm_lid_attr_get(FLOW_CNTR_ID_LID_GET(bulk_data_p->base_counter_id), &cm_attr);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR("%s: cm_return_len failed\n", __func__);
                goto out;
            }

            if (cl_qmap_head(&(cm_by_ref_qmap)) == cl_qmap_end(&(cm_by_ref_qmap))) {
                sx_status = spec4_reg_write_mocbr(TRUE, FALSE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("spec4_reg_write_mocbr failed, rc:[%s]\n", sx_status_str(sx_status));
                    goto out;
                }
                counter_by_ref_enabled = TRUE;
            }

            cm_by_ref_item->cm_type = cm_type;
            cm_by_ref_item->cm_hw_type = cm_hw_type;
            cm_by_ref_item->hw_len = cm_attr.hw_len;
            cm_by_ref_item->cm_index = cm_index + cm_attr.hw_len *
                                       FLOW_CNTR_ID_OFFSET_GET(bulk_data_p->base_counter_id);
            cm_by_ref_item->base_counter_id = bulk_data_p->base_counter_id;
            cl_qmap_insert(&(cm_by_ref_qmap), bulk_data_p->base_counter_id, &(cm_by_ref_item->map_item));
        }


        for (i = 0; i < bulk_attr.counter_num; i++) {
            cntr_id = LID_OFFSET_TO_FLOW_CNTR_ID(cm_lid, i);
            /* And clear the value, no need for flow estimator counter */
            if (bulk_attr.counter_type != SX_FLOW_COUNTER_TYPE_ESTIMATOR) {
                sx_status = flow_counter_clear(cntr_id);
                if (SX_STATUS_SUCCESS != sx_status) {
                    SX_LOG_ERR("%s: flow_counter_clear failed \n", __func__);
                    goto out;
                }
            }

            map_item = cl_qmap_get(&(cm_qmap), cntr_id);
            map_end = cl_qmap_end(&(cm_qmap));
            if (map_item == map_end) {
                if (bulk_attr.counter_type == SX_FLOW_COUNTER_TYPE_ACCUMULATED) {
                    pool_item = cl_qpool_get(&(accuflow_counters_qpool));
                } else {
                    pool_item = cl_qpool_get(&(cm_qpool));
                }
                if (pool_item == NULL) {
                    SX_LOG_WRN("Could not find free cm_item.\n");
                    sx_status = SX_STATUS_NO_RESOURCES;
                    goto out;
                }
                cm_item = PARENT_STRUCT(pool_item, cm_item_t, pool_item);
                cm_item->cntr_id = cntr_id;

                cl_qmap_insert(&(cm_qmap), cntr_id, &(cm_item->map_item));
            } else {
                SX_LOG_NTC("Flow counter [0x%x] exist in DB.\n", cntr_id);
            }
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        if (bulk_attr.counter_type == SX_FLOW_COUNTER_TYPE_ESTIMATOR) {
            if (!s_flow_estimator_counting_is_enabled) {
                SX_LOG_ERR("Estimator counting are not supported. \n");
                sx_status = SX_STATUS_UNSUPPORTED;
                goto out;
            }
        }

        map_item = cl_qmap_get(&(cm_by_ref_qmap), bulk_data_p->base_counter_id);
        map_end = cl_qmap_end(&(cm_by_ref_qmap));
        if (map_item != map_end) {
            cm_by_ref_item = PARENT_STRUCT(map_item, cm_by_ref_item_t, map_item);
            cl_qmap_remove(&(cm_by_ref_qmap), bulk_data_p->base_counter_id);
            sx_status = cm_unlock(FLOW_CNTR_ID_LID_GET(bulk_data_p->base_counter_id));
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("failed to unlock the base counter\n");
                goto out;
            }
            cl_free(cm_by_ref_item);
            if (cl_qmap_head(&(cm_by_ref_qmap)) == cl_qmap_end(&(cm_by_ref_qmap))) {
                sx_status = spec4_reg_write_mocbr(FALSE, FALSE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("spec4_reg_write_mocbr failed, rc:[%s]\n", sx_status_str(sx_status));
                    goto out;
                }
                counter_by_ref_enabled = FALSE;
            }
        }

        map_item = cl_qmap_get(&(cm_qmap), bulk_data_p->base_counter_id);
        map_end = cl_qmap_end(&(cm_qmap));
        if (map_item == map_end) {
            SX_LOG_ERR("Failed to destroy bulk: could not find the base flow counter [0x%x].\n",
                       bulk_data_p->base_counter_id);
            sx_status = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        cm_lid = FLOW_CNTR_ID_LID_GET(bulk_data_p->base_counter_id);
        sx_status = cm_lid_attr_get(cm_lid, &cm_attr);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to destroy bulk: could not find the flow counter [0x%x] "
                       "attributes.\n",
                       bulk_data_p->base_counter_id);
            sx_status = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        offset = FLOW_CNTR_ID_OFFSET_GET(bulk_data_p->base_counter_id);
        if (offset != 0) {
            SX_LOG_ERR("Counter bulk destroy must receive the bulk base counter ID. "
                       "Received base flow counter: [0x%x].\n",
                       bulk_data_p->base_counter_id);
            sx_status = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        if (bulk_attr.counter_type == SX_FLOW_COUNTER_TYPE_ESTIMATOR) {
            /* change flow estimator counters back to normal flow counter type */
            sx_status = __flow_counter_type_set(bulk_data_p->base_counter_id, bulk_attr.counter_num, FLOW_COUNTER_E);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR(
                    "__flow_counter_type_set failed to set flow counter type (%d), counter id %u, size %d\n",
                    FLOW_COUNTER_E,
                    bulk_data_p->base_counter_id,
                    bulk_attr.counter_num);
                goto out;
            }
        }

        sx_status = cm_block_delete(cm_lid);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("%s: cm_block_delete failed \n", __func__);
            /* align return code of spectrum with previous version */
            if (sx_status == SX_STATUS_DB_NOT_EMPTY) {
                sx_status = SX_STATUS_RESOURCE_IN_USE;
            }

            goto out;
        }
        for (i = 0; i < cm_attr.size; i++) {
            cntr_id = LID_OFFSET_TO_FLOW_CNTR_ID(cm_lid, i);
            map_item = cl_qmap_get(&(cm_qmap), cntr_id);
            map_end = cl_qmap_end(&(cm_qmap));
            if (map_item == map_end) {
                SX_LOG_ERR("Could not find the flow counter [0x%x].\n",
                           cntr_id);
                sx_status = SX_STATUS_ENTRY_NOT_FOUND;
                goto out;
            }

            cm_item = PARENT_STRUCT(map_item, cm_item_t, map_item);
            cl_qmap_remove(&(cm_qmap), cntr_id);
            if (bulk_attr.counter_type == SX_FLOW_COUNTER_TYPE_ACCUMULATED) {
                cl_qpool_put(&(accuflow_counters_qpool), &(cm_item->pool_item));
            } else {
                cl_qpool_put(&(cm_qpool), &(cm_item->pool_item));
            }
        }

        if (bulk_attr.counter_type == SX_FLOW_COUNTER_TYPE_ACCUMULATED) {
            sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E, SX_ACCESS_CMD_DELETE, cm_attr.size, NULL);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: rm_entries_set failed \n", __func__);
                goto out;
            }
        } else {
            sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_FLOW_COUNTER_E, SX_ACCESS_CMD_DELETE, cm_attr.size, NULL);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR_RESOURCE_COND(sx_status, "%s: rm_entries_set failed \n", __func__);
                goto out;
            }
        }

        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("%s: Command %s is not supported.\n", __func__, sx_access_cmd_str(cmd));
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    if (sx_status) {
        if (flow_type_rollback) {
            rb_err = __flow_counter_type_set(bulk_data_p->base_counter_id, bulk_attr.counter_num, FLOW_COUNTER_E);
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("%s: Failed to rollback flow counter type, counter id %u, size %d, error: [%s] (%d)\n",
                           __func__, bulk_data_p->base_counter_id, bulk_attr.counter_num,
                           sx_status_str(rb_err), rb_err);
            }
        }
        if (rbs_required_on_error) {
            rb_err = cm_block_delete(cm_lid);
            /* coverity[example_checked] */
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("Failed to delete cm block"
                           "err = [%s] (%d)\n", sx_status_str(rb_err), rb_err);
            }
        }
        if (rm_rollback) {
            rb_err =
                rm_entries_set(RM_SDK_TABLE_TYPE_FLOW_COUNTER_E, SX_ACCESS_CMD_DELETE, bulk_attr.counter_num, NULL);
            if (SX_STATUS_SUCCESS != rb_err) {
                SX_LOG_ERR("%s: rm_entries_set failed, error: [%s] (%d) \n",
                           __func__, sx_status_str(rb_err), rb_err);
            }
        }
        if (afrm_rollback) {
            rb_err =
                rm_entries_set(RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E, SX_ACCESS_CMD_DELETE, bulk_attr.counter_num,
                               NULL);
            if (SX_STATUS_SUCCESS != rb_err) {
                SX_LOG_ERR("%s: rm_entries_set failed, error: [%s] (%d) \n",
                           __func__, sx_status_str(rb_err), rb_err);
            }
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __flow_estimator_profile_operation_precheck(const sx_flow_estimator_profile_key_t *profile_key_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (!s_flow_estimator_counting_is_enabled) {
        SX_LOG_ERR("Flow estimator profiles are not supported. \n");
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if (!IS_VALID_PROFILE_ID(profile_key_p->profile_id)) {
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, "Flow estimator profile id [%d] exceeds range.\n", profile_key_p->profile_id);
        goto out;
    }

out:
    return sx_status;
}

static inline uint8_t __log2_num(uint32_t value)
{
    uint8_t log_num = 0;

    while (value >>= 1) {
        log_num++;
    }
    return log_num;
}

static boolean_t __allow_to_set_flow_estimator_profile_size(const sx_flow_estimator_profile_key_t *profile_key_p,
                                                            uint32_t                               bin_group_size)
{
    return (!IS_PROFILE_IN_USE(profile_key_p->profile_id) ||
            SIZE_OF_PROFILE(profile_key_p->profile_id) == bin_group_size);
}

static boolean_t __is_valid_flow_estimator_profile_size(uint32_t bin_group_size)
{
    uint32_t arr_len = 0;
    uint32_t i;

    arr_len = sizeof(s_flow_estimator_profile_allowed_bin_group_sizes) /
              sizeof(s_flow_estimator_profile_allowed_bin_group_sizes[0]);
    for (i = 0; i < arr_len; i++) {
        if (bin_group_size == s_flow_estimator_profile_allowed_bin_group_sizes[i]) {
            break;
        }
    }

    if (i == arr_len) {
        return FALSE;
    }

    return TRUE;
}

static sx_status_t __flow_estimator_profile_set_size(const sx_flow_estimator_profile_key_t *profile_key_p,
                                                     uint32_t                               bin_group_size)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status;
    sx_dev_id_t         devs_list[SX_DEV_NUM_MAX];
    uint16_t            devs_count = 0;
    uint32_t            dev_idx;
    struct ku_mofpc_reg mofpc;
    sxd_reg_meta_t      meta;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(mofpc);

    if (!__is_valid_flow_estimator_profile_size(bin_group_size)) {
        SX_LOG_ERR("%s: profile %d is set with size %d out of range of valid values: [ 16, 32, 64, 128, 256, 512 ]\n",
                   __func__, profile_key_p->profile_id, bin_group_size);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (!__allow_to_set_flow_estimator_profile_size(profile_key_p, bin_group_size)) {
        SX_LOG_ERR("%s: A different profile size %d is not allowed to set because profile %d (size %d) is in use\n",
                   __func__, bin_group_size, profile_key_p->profile_id, SIZE_OF_PROFILE(profile_key_p->profile_id));
        sx_status = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    meta.access_cmd = SXD_ACCESS_CMD_SET;
    mofpc.profile = profile_key_p->profile_id;
    mofpc.log_num_of_bins = __log2_num(bin_group_size);

    __flow_counter_get_all_devs_list(devs_list, &devs_count);
    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        meta.dev_id = devs_list[dev_idx];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOFPC_E, &mofpc, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("%s: Failed to access MOFPC [profile=%u, log_num_of_bins=%u, err=%u]\n",
                       __func__, mofpc.profile, mofpc.log_num_of_bins, sxd_status);
            sx_status = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }
out:
    return sx_status;
}

static sx_status_t __flow_estimator_profile_set_hash_params(const sx_flow_estimator_profile_key_t  *profile_key_p,
                                                            const sx_flow_estimator_profile_hash_t *hash_params_p)
{
    sx_status_t                                          sx_status = SX_STATUS_SUCCESS;
    sxd_status_t                                         sxd_status;
    sx_dev_id_t                                          devs_list[SX_DEV_NUM_MAX];
    uint16_t                                             devs_count = 0;
    uint32_t                                             dev_idx;
    struct ku_mofph_reg                                  mofph;
    sxd_reg_meta_t                                       meta;
    uint32_t                                             idx;
    uint32_t                                             offset;
    uint32_t                                             profile_idx = profile_key_p->profile_id;
    const sx_flow_estimator_profile_hash_field_enable_t *fields_enable_list_p = hash_params_p->fields_enable_list_p;
    const sx_flow_estimator_profile_hash_field_t        *fields_p = hash_params_p->fields_list_p;
    sxd_mofph_seed_en_t                                  seed_en = SXD_MOFPH_SEED_EN_SEED_BY_HW_E;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(mofph);

    meta.access_cmd = SXD_ACCESS_CMD_SET;
    mofph.profile = profile_idx;
    mofph.type = SXD_MOFPH_TYPE_CRC_E;

    if (hash_params_p->seed_en_by_sw) {
        seed_en = SXD_MOFPH_SEED_EN_SEED_BY_SW_E;
    }
    mofph.seed_en = seed_en;
    if (seed_en == SXD_MOFPH_SEED_EN_SEED_BY_SW_E) {
        mofph.seed_by_sw = hash_params_p->seed_by_sw;
    }

    for (idx = 0; idx < hash_params_p->fields_enable_list_cnt; idx++) {
        if (FLOW_ESTIMATOR_PROFILE_HASH_IS_FIELD_ENABLE_OUTER(fields_enable_list_p[idx])) {
            offset = fields_enable_list_p[idx] - SX_FLOW_EST_PROF_HASH_OUTER_ENABLES_OFFSET;
            mofph.outer_header_enables |= (1 << offset);
        } else if (FLOW_ESTIMATOR_PROFILE_HASH_IS_FIELD_ENABLE_INNER(fields_enable_list_p[idx])) {
            offset = fields_enable_list_p[idx] - SX_FLOW_EST_PROF_HASH_INNER_ENABLES_OFFSET;
            mofph.inner_header_enables |= (1 << offset);
        } else {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "__flow_estimator_profile_set_hash_params Failed."
                   "hash field enable [%u] is not in range.\n", fields_enable_list_p[idx]);
            goto out;
        }
    }

    for (idx = 0; idx < hash_params_p->fields_list_cnt; idx++) {
        if (FLOW_ESTIMATOR_PROFILE_HASH_IS_FIELD_OUTER(fields_p[idx])) {
            offset = fields_p[idx] - SX_FLOW_EST_PROF_HASH_OUTER_FIELDS_OFFSET;
            mofph.outer_header_hash |= (UINT64_C(1) << offset);
        } else if (FLOW_ESTIMATOR_PROFILE_HASH_IS_FIELD_INNER(fields_p[idx])) {
            offset = fields_p[idx] - SX_FLOW_EST_PROF_HASH_INNER_FIELDS_OFFSET;
            mofph.inner_header_hash |= (1 << offset);
        } else {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "__flow_estimator_profile_set_hash_params Failed."
                   "hash field [%u] is not in range.\n", fields_p[idx]);
            goto out;
        }
    }

    __flow_counter_get_all_devs_list(devs_list, &devs_count);
    for (dev_idx = 0; dev_idx < devs_count; dev_idx++) {
        meta.dev_id = devs_list[dev_idx];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOFPH_E, &mofph, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("%s: Failed to access MOFPH [profile=%u, err=%u]\n",
                       __func__, mofph.profile, sxd_status);
            sx_status = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }

out:
    return sx_status;
}

static sx_status_t __update_flow_estimator_profile_db(const sx_access_cmd_t                  cmd,
                                                      const sx_flow_estimator_profile_key_t *profile_key_p,
                                                      const sx_flow_estimator_profile_cfg_t *profile_cfg_p)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    uint32_t                          profile_idx = profile_key_p->profile_id;
    sx_flow_estimator_profile_hash_t *hash_params_p = NULL;

    if (cmd == SX_ACCESS_CMD_DESTROY) {
        if (IS_PROFILE_IN_USE(profile_idx)) {
            err = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("Failed to destroy profile %d because it is still in-use.\n", profile_idx);
            goto out;
        }

        SX_MEM_CLR_BUF(&(s_flow_estimator_profiles_db.profiles[profile_idx]),
                       sizeof(s_flow_estimator_profiles_db.profiles[profile_idx]));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_CREATE) {
        s_flow_estimator_profiles_db.profiles[profile_idx].allocated = TRUE;
    }

    hash_params_p = profile_cfg_p->hash_params_p;
    s_flow_estimator_profiles_db.profiles[profile_idx].bin_group_size = profile_cfg_p->bin_group_size;
    s_flow_estimator_profiles_db.profiles[profile_idx].seed_en_by_sw = hash_params_p->seed_en_by_sw;
    s_flow_estimator_profiles_db.profiles[profile_idx].seed_by_sw = hash_params_p->seed_by_sw;
    s_flow_estimator_profiles_db.profiles[profile_idx].fields_enable_list_cnt = hash_params_p->fields_enable_list_cnt;
    s_flow_estimator_profiles_db.profiles[profile_idx].fields_cnt = hash_params_p->fields_list_cnt;

    /* flow estimator profile hash params are always overwritten */
    SX_MEM_CLR_ARRAY(s_flow_estimator_profiles_db.profiles[profile_idx].fields_enable_list_p,
                     FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_ENABLES_NUM,
                     sx_flow_estimator_profile_hash_field_enable_t);
    SX_MEM_CLR_ARRAY(s_flow_estimator_profiles_db.profiles[profile_idx].fields_p,
                     FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_NUM,
                     sx_flow_estimator_profile_hash_field_t);

    SX_MEM_CPY_ARRAY(s_flow_estimator_profiles_db.profiles[profile_idx].fields_enable_list_p,
                     hash_params_p->fields_enable_list_p,
                     hash_params_p->fields_enable_list_cnt,
                     sx_flow_estimator_profile_hash_field_enable_t);
    SX_MEM_CPY_ARRAY(s_flow_estimator_profiles_db.profiles[profile_idx].fields_p,
                     hash_params_p->fields_list_p,
                     hash_params_p->fields_list_cnt,
                     sx_flow_estimator_profile_hash_field_t);
out:
    return err;
}

static sx_status_t spectrum_flow_estimator_profile_set(const sx_access_cmd_t                  cmd,
                                                       const sx_flow_estimator_profile_key_t *profile_key_p,
                                                       const sx_flow_estimator_profile_cfg_t *profile_cfg_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_flow_estimator_profile_cfg_t profile_cfg;

    SX_LOG_ENTER();
    VALIDATE_POINTER_NOT_NULL(profile_key_p);

    err = __flow_estimator_profile_operation_precheck(profile_key_p);
    if (err) {
        SX_LOG_ERR("flow estimator profile operation is not allowed, failed status = %d \n", err);
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        VALIDATE_POINTER_NOT_NULL(profile_cfg_p);
        if (IS_PROFILE_ALLOCATED(profile_key_p->profile_id)) {
            err = SX_STATUS_ENTRY_ALREADY_EXISTS;
            SX_LOG_ERR("Failed to create profile %d because it has been created.\n", profile_key_p->profile_id);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_SET:
        VALIDATE_POINTER_NOT_NULL(profile_cfg_p);
        if (!IS_PROFILE_ALLOCATED(profile_key_p->profile_id)) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to set profile %d because it does not exist.\n", profile_key_p->profile_id);
            goto out;
        }

        break;

    case SX_ACCESS_CMD_DESTROY:
        if (!IS_PROFILE_ALLOCATED(profile_key_p->profile_id)) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to destory profile %d because it does not exist.\n", profile_key_p->profile_id);
            goto out;
        }
        if (IS_PROFILE_IN_USE(profile_key_p->profile_id)) {
            err = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("Failed to destory profile %d because it is still used in some ACL flow estimator actions, "
                       "change the related ACL action(s) before re-trying to destory it.\n",
                       profile_key_p->profile_id);
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG(SX_LOG_ERROR, "sx_api_flow_estimator_profile_set failed: "
               "CMD %s is not supported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    SX_MEM_CLR_TYPE(&profile_cfg, sx_flow_estimator_profile_cfg_t);

    if (cmd != SX_ACCESS_CMD_DESTROY) {
        err = __flow_estimator_profile_set_size(profile_key_p, profile_cfg_p->bin_group_size);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR, "__flow_estimator_profile_set_size: %s.\n", sx_status_str(err));
            goto out;
        }

        SX_MEM_CPY_TYPE(&profile_cfg, profile_cfg_p, sx_flow_estimator_profile_cfg_t);
        if (profile_cfg_p->hash_params_p == NULL) {
            profile_cfg.hash_params_p = &s_default_est_prof_hash_params;
        }
        err = __flow_estimator_profile_set_hash_params(profile_key_p, profile_cfg.hash_params_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR, "__flow_estimator_profile_set_hash_params: %s.\n", sx_status_str(err));
            goto out;
        }
    }

    /* update local DB */
    err = __update_flow_estimator_profile_db(cmd,
                                             profile_key_p,
                                             &profile_cfg);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "__update_flow_estimator_profile_db: %s.\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t spectrum_flow_estimator_profile_get(const sx_flow_estimator_profile_key_t *profile_key_p,
                                                sx_flow_estimator_profile_attr_t      *profile_attr_p)
{
    sx_status_t                                    err = SX_STATUS_SUCCESS;
    uint32_t                                       profile_idx;
    sx_flow_estimator_profile_hash_field_enable_t *fields_enable_list_p;
    sx_flow_estimator_profile_hash_field_t        *fields_p;
    sx_flow_estimator_profile_hash_t              *hash_params_p;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(profile_key_p);
    VALIDATE_POINTER_NOT_NULL(profile_attr_p);

    err = __flow_estimator_profile_operation_precheck(profile_key_p);
    if (err) {
        SX_LOG_ERR("flow estimator profile operation is not allowed, failed status = %d \n", err);
        goto out;
    }
    profile_idx = profile_key_p->profile_id;

    if (!IS_PROFILE_ALLOCATED(profile_idx)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to get profile %d because it is not created.\n", profile_idx);
        goto out;
    }

    hash_params_p = profile_attr_p->config.hash_params_p;
    fields_enable_list_p = hash_params_p->fields_enable_list_p;
    fields_p = hash_params_p->fields_list_p;

    if (hash_params_p->fields_enable_list_cnt > 0) {
        VALIDATE_POINTER_NOT_NULL(fields_enable_list_p);
    }
    if (hash_params_p->fields_list_cnt > 0) {
        VALIDATE_POINTER_NOT_NULL(fields_p);
    }

    if (hash_params_p->fields_list_cnt > FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "sx_api_flow_estimator_profile_get: "
               "fields_cnt_p [%u] exceeds max number of fields [%u].\n",
               hash_params_p->fields_list_cnt, FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_NUM);
        goto out;
    }

    if (hash_params_p->fields_enable_list_cnt > FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "sx_api_flow_estimator_profile_get: "
               "fields_enable_list_cnt_p [%u] exceeds max number of fields [%u].\n",
               hash_params_p->fields_enable_list_cnt, FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_ENABLES_NUM);
        goto out;
    }

    /* fetch from local DB */
    profile_attr_p->in_use = IS_PROFILE_IN_USE(profile_idx);
    profile_attr_p->config.bin_group_size = s_flow_estimator_profiles_db.profiles[profile_idx].bin_group_size;
    hash_params_p->seed_en_by_sw = s_flow_estimator_profiles_db.profiles[profile_idx].seed_en_by_sw;
    hash_params_p->seed_by_sw = s_flow_estimator_profiles_db.profiles[profile_idx].seed_by_sw;


    if (0 == hash_params_p->fields_enable_list_cnt) {
        SX_LOG_DBG("Get Flow Estimator Profile Hash Params of Profile %d from DB, Get only fields enables count.\n",
                   profile_idx);
        hash_params_p->fields_enable_list_cnt =
            s_flow_estimator_profiles_db.profiles[profile_idx].fields_enable_list_cnt;
    } else {
        hash_params_p->fields_enable_list_cnt = MIN(
            s_flow_estimator_profiles_db.profiles[profile_idx].fields_enable_list_cnt,
            hash_params_p->fields_enable_list_cnt);
        SX_MEM_CPY_ARRAY(fields_enable_list_p,
                         s_flow_estimator_profiles_db.profiles[profile_idx].fields_enable_list_p,
                         hash_params_p->fields_enable_list_cnt,
                         sx_flow_estimator_profile_hash_field_enable_t);
    }

    if (0 == hash_params_p->fields_list_cnt) {
        SX_LOG_DBG("Get Flow Estimator Profile Hash Params of Profile %d from DB, Get only fields count.\n",
                   profile_idx);
        hash_params_p->fields_list_cnt = s_flow_estimator_profiles_db.profiles[profile_idx].fields_cnt;
    } else {
        hash_params_p->fields_list_cnt = MIN(s_flow_estimator_profiles_db.profiles[profile_idx].fields_cnt,
                                             hash_params_p->fields_list_cnt);
        SX_MEM_CPY_ARRAY(fields_p,
                         s_flow_estimator_profiles_db.profiles[profile_idx].fields_p,
                         hash_params_p->fields_list_cnt,
                         sx_flow_estimator_profile_hash_field_t);
    }

out:
    SX_LOG_EXIT();
    return err;
}

static uint32_t __flow_estimator_profile_get_allocated_num(void)
{
    uint32_t idx;
    uint32_t count = 0;

    for (idx = SX_FLOW_ESTIMATOR_PROFILE_ID_MIN; idx <= SX_FLOW_ESTIMATOR_PROFILE_ID_MAX; idx++) {
        if (IS_PROFILE_ALLOCATED(idx)) {
            count++;
        }
    }
    return count;
}

sx_status_t spectrum_flow_estimator_profile_iter_get(const sx_access_cmd_t                     cmd,
                                                     const sx_flow_estimator_profile_key_t    *profile_key_p,
                                                     const sx_flow_estimator_profile_filter_t *profile_key_filter_p,
                                                     sx_flow_estimator_profile_key_t          *profile_key_list_p,
                                                     uint32_t                                 *profile_key_cnt_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    uint32_t    j = 0;
    uint32_t    data_count = 0;
    uint32_t    profile_idx = profile_key_p->profile_id;
    uint32_t    start_idx = 0;

    UNUSED_PARAM(profile_key_filter_p);

    sx_status = __flow_estimator_profile_operation_precheck(profile_key_p);
    if (sx_status) {
        SX_LOG_ERR("flow estimator profile operation is not allowed, failed status = %d \n", sx_status);
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(profile_key_cnt_p, "profile_key_cnt_p"))) {
        goto out;
    }

    if (*profile_key_cnt_p != 0) {
        if (SX_CHECK_FAIL(sx_status = utils_check_pointer(profile_key_list_p,
                                                          "profile_key_list_p"))) {
            goto out;
        }
    }

    data_count = *profile_key_cnt_p;

    switch (cmd) {
    case SX_ACCESS_CMD_GETNEXT:
        start_idx = profile_idx + 1;
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        start_idx = SX_FLOW_ESTIMATOR_PROFILE_ID_MIN;
        break;

    case SX_ACCESS_CMD_GET:
        if (*profile_key_cnt_p == 0) {
            *profile_key_cnt_p = __flow_estimator_profile_get_allocated_num();
        } else {
            if (IS_PROFILE_ALLOCATED(profile_idx)) {
                profile_key_list_p[0].profile_id = profile_idx;
                *profile_key_cnt_p = 1;
            } else {
                *profile_key_cnt_p = 0;
            }
        }
        goto out;

    default:
        SX_LOG_ERR("Command is not supported for iterator\n");
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (data_count && (start_idx <= SX_FLOW_ESTIMATOR_PROFILE_ID_MAX)) {
        j = 0;
        for (i = start_idx; i <= SX_FLOW_ESTIMATOR_PROFILE_ID_MAX; i++) {
            if (IS_PROFILE_ALLOCATED(i)) {
                profile_key_list_p[j++].profile_id = i;
                if (j >= data_count) {
                    break;
                }
            }
        }
        *profile_key_cnt_p = j;
    } else {
        *profile_key_cnt_p = 0;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t spectrum_flow_estimator_profile_is_exists(const sx_flow_estimator_profile_key_t *profile_key_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    VALIDATE_POINTER_NOT_NULL(profile_key_p);
    err = __flow_estimator_profile_operation_precheck(profile_key_p);
    if (err) {
        SX_LOG_ERR("flow estimator profile operation is not allowed, failed status = %d \n", err);
        goto out;
    }

    if (!IS_PROFILE_ALLOCATED(profile_key_p->profile_id)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
    }

out:
    return err;
}

sx_status_t spectrum_flow_estimator_profile_ref_inc(const sx_flow_estimator_profile_key_t *profile_key_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = spectrum_flow_estimator_profile_is_exists(profile_key_p);
    if (err) {
        SX_LOG_ERR("spectrum_flow_estimator_profile_ref_inc failed to check params, status = %d \n", err);
        goto out;
    }

    s_flow_estimator_profiles_db.profiles[profile_key_p->profile_id].ref_cnt++;

out:
    return err;
}


sx_status_t spectrum_flow_estimator_profile_ref_dec(const sx_flow_estimator_profile_key_t *profile_key_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = spectrum_flow_estimator_profile_is_exists(profile_key_p);
    if (err) {
        SX_LOG_ERR("spectrum_flow_estimator_profile_ref_dec failed to check params, status = %d \n", err);
        goto out;
    }

    s_flow_estimator_profiles_db.profiles[profile_key_p->profile_id].ref_cnt--;

out:
    return err;
}

/* get flow estimator counter number created via one sx_api_flow_counter_bulk_set() */
static sx_status_t __fetch_bulk_size_from_flow_esimator_base_counter(sx_flow_counter_id_t base_counter_id,
                                                                     uint32_t            *size_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    cm_attr_t   cm_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(cm_attr);

    sx_status = cm_lid_attr_get(FLOW_CNTR_ID_LID_GET(base_counter_id), &cm_attr);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("%s: cm_lid_attr_get failed\n", __func__);
        goto out;
    }

    if (cm_attr.type != CM_TYPE_ESTIMATOR_E) {
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("%s: only estimator counter supports to get size\n", __func__);
        goto out;
    }

    if (size_p != NULL) {
        *size_p = cm_attr.size;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t spectrum_flow_estimator_counter_is_matching_profile(const sx_flow_counter_id_t             base_counter_id,
                                                                const sx_flow_estimator_profile_key_t *profile_key_p,
                                                                boolean_t                             *match)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    size = 0;

    err = spectrum_flow_counter_is_exists(base_counter_id);
    if (err) {
        SX_LOG_ERR(
            "spectrum_flow_estimator_is_profile_matching_counter failed to check counter params, status = %d \n",
            err);
        goto out;
    }

    err = __fetch_bulk_size_from_flow_esimator_base_counter(base_counter_id, &size);
    if (err) {
        SX_LOG_ERR(
            "spectrum_flow_estimator_is_profile_matching_counter failed to check estimator counter params, status = %d \n",
            err);
        goto out;
    }

    err = spectrum_flow_estimator_profile_is_exists(profile_key_p);
    if (err) {
        SX_LOG_ERR(
            "spectrum_flow_estimator_is_profile_matching_counter failed to check profile params, status = %d \n",
            err);
        goto out;
    }

    if (SIZE_OF_PROFILE(profile_key_p->profile_id) == size * FLOW_ESTIMATOR_BINS_PER_FLOW_COUNTER) {
        *match = TRUE;
        goto out;
    }
    *match = FALSE;
out:
    return err;
}

const char* spectrum_flow_estimator_profile_hash_enable_to_str(sx_flow_estimator_profile_hash_field_enable_t enable)
{
    uint32_t str_idx;

    if (enable > SX_FLOW_EST_PROF_HASH_INNER_ENABLES_OFFSET) {
        str_idx = enable - SX_FLOW_EST_PROF_HASH_INNER_ENABLES_OFFSET +
                  FLOW_ESTIMATOR_PROFILE_HASH_OUTER_FIELDS_ENABLE_NUM;
    } else {
        str_idx = enable - SX_FLOW_EST_PROF_HASH_OUTER_ENABLES_OFFSET;
    }
    return (SX_CHECK_MAX(str_idx,
                         FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_ENABLES_NUM -
                         1) ? s_est_prof_hash_enables_str[str_idx] : "UNKNOWN");
}

const char* spectrum_flow_estimator_profile_hash_field_to_str(sx_flow_estimator_profile_hash_field_t field)
{
    uint32_t str_idx;

    if (field >= SX_FLOW_EST_PROF_HASH_INNER_FIELDS_OFFSET) {
        str_idx = field - SX_FLOW_EST_PROF_HASH_INNER_FIELDS_OFFSET + FLOW_ESTIMATOR_PROFILE_HASH_OUTER_FIELDS_NUM;
    } else {
        str_idx = field - SX_FLOW_EST_PROF_HASH_OUTER_FIELDS_OFFSET;
    }
    return (SX_CHECK_MAX(str_idx, EST_PROF_HASH_FIELDS_STR_LEN - 1) ? s_est_prof_hash_fields_str[str_idx] : "UNKNOWN");
}

boolean_t spectrum_flow_counter_is_counter_by_ref_type_base(sx_flow_counter_id_t cntr_id)
{
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;

    map_item = cl_qmap_get(&(cm_by_ref_qmap), cntr_id);
    map_end = cl_qmap_end(&(cm_by_ref_qmap));
    if (map_item == map_end) {
        return FALSE;
    }

    return TRUE;
}

static void flex_counter_by_ref_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    FILE *stream = NULL;

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        return;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Counter by reference status:");
    dbg_utils_pprinter_field_print(stream, "Enabled:",
                                   (void *)&counter_by_ref_enabled, PARAM_BOOL_E);
    return;
}

static void spectrum_flow_estimator_profile_dbg_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    uint32_t                             profile_cnt = 0;
    uint32_t                             i, j;
    FILE                                *stream = NULL;
    sx_flow_estimator_profile_db_entry_t profile;

    SX_LOG_ENTER();

    if (!s_flow_estimator_counting_is_enabled) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_user_defined_header_print(stream,
                                                 DBG_UTILS_LEVEL_USER_DEFINED_1_E,
                                                 "Flow Estimator Profile Params");

    profile_cnt = __flow_estimator_profile_get_allocated_num();
    dbg_utils_pprinter_field_print(stream, "Allocated Number", &profile_cnt, PARAM_UINT32_E);

    if (profile_cnt > 0) {
        for (i = SX_FLOW_ESTIMATOR_PROFILE_ID_MIN; i <= SX_FLOW_ESTIMATOR_PROFILE_ID_MAX; i++) {
            if (IS_PROFILE_ALLOCATED(i)) {
                SX_MEM_CLR(profile);
                SX_MEM_CPY_TYPE(&profile,
                                &(s_flow_estimator_profiles_db.profiles[i]),
                                sx_flow_estimator_profile_db_entry_t);

                dbg_utils_pprinter_user_defined_header_print(stream, DBG_UTILS_LEVEL_USER_DEFINED_2_E, "profile %u",
                                                             i);
                dbg_utils_pprinter_field_print(stream, "ref cnt", &profile.ref_cnt, PARAM_UINT32_E);
                dbg_utils_pprinter_field_print(stream, "bin group size", &profile.bin_group_size, PARAM_UINT32_E);
                dbg_utils_pprinter_field_print(stream,
                                               "hash enable count",
                                               &(profile.fields_enable_list_cnt),
                                               PARAM_UINT32_E);
                dbg_utils_pprinter_field_print(stream, "hash fields count", &(profile.fields_cnt), PARAM_UINT32_E);

                dbg_utils_pprinter_secondary_header_print(stream, "hash enables:");
                for (j = 0; j < profile.fields_enable_list_cnt; j++) {
                    dbg_utils_pprinter_field_print(stream,
                                                   spectrum_flow_estimator_profile_hash_enable_to_str(profile.
                                                                                                      fields_enable_list_p
                                                                                                      [j]),
                                                   "", PARAM_STRING_E);
                }

                dbg_utils_pprinter_secondary_header_print(stream, "hash fields:");
                for (j = 0; j < profile.fields_cnt; j++) {
                    dbg_utils_pprinter_field_print(stream,
                                                   spectrum_flow_estimator_profile_hash_field_to_str(
                                                       profile.fields_p[j]),
                                                   "",
                                                   PARAM_STRING_E);
                }
            }
        }
    }
out:
    SX_LOG_EXIT();
    return;
}

static sx_status_t spectrum_flow_counter_dbg_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    sx_flow_counter_id_t      cntr_id = 0;
    cm_index_t                cm_index = 0;
    cm_logical_id_t           block_id = 0;
    uint32_t                  fc_offest = 0;
    uint32_t                  cntr_cnt = 1;
    cm_attr_t                 cm_attr;
    FILE                     *stream_p = NULL;
    uint8_t                   column_type_idx = 4;
    char                      uknown_type_str[] = "Unknown";
    dbg_utils_table_columns_t flow_counter_dump_clmns[] = {
        { "Flow counter ID", 15, PARAM_UINT32_E, &cntr_id},
        { "Block ID",         8, PARAM_UINT32_E, &block_id},
        { "FC offset",       13, PARAM_UINT32_E, &fc_offest},
        { "PRM ID",           6, PARAM_UINT32_E, &cm_index},
        { "Type",            25, PARAM_STRING_E, uknown_type_str},
        { "HW type",          7, PARAM_UINT8_E,  &cm_attr.hw_type},
        { "HW_LEN",           6, PARAM_UINT32_E, &cm_attr.hw_len},
        { "Size",             4, PARAM_UINT32_E, &cm_attr.size},
        { "Ref",              4, PARAM_UINT32_E, &cm_attr.ref},
        {NULL, 0, 0, NULL}
    };

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }
    stream_p = dbg_dump_params_p->stream;

    SX_MEM_CLR(cm_attr);

    dbg_utils_pprinter_module_header_print(stream_p, "Flow counters");
    dbg_utils_pprinter_field_print(stream_p, "Accumulated initialized                          : ",
                                   &g_accuflow_counters_inited,
                                   PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream_p, "Flow estimator counters enabled                  : ",
                                   &s_flow_estimator_counting_is_enabled,
                                   PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream_p, "Maximum Accumulated counters (in K (1024) units) : ",
                                   &g_flow_counter_init_params.flow_counter_accumulated_type_max_number,
                                   PARAM_UINT16_E);
    dbg_utils_pprinter_field_print(stream_p, "Minimum Flow byte counters                    : ",
                                   &g_flow_counter_init_params.flow_counter_byte_type_min_number,
                                   PARAM_UINT16_E);
    dbg_utils_pprinter_field_print(stream_p, "Maximum Flow byte counters                    : ",
                                   &g_flow_counter_init_params.flow_counter_byte_type_max_number,
                                   PARAM_UINT16_E);
    dbg_utils_pprinter_field_print(stream_p, "Minimum Flow packet counters                  : ",
                                   &g_flow_counter_init_params.flow_counter_packet_type_min_number,
                                   PARAM_UINT16_E);
    dbg_utils_pprinter_field_print(stream_p, "Maximum Flow packet counters                  : ",
                                   &g_flow_counter_init_params.flow_counter_packet_type_max_number,
                                   PARAM_UINT16_E);
    dbg_utils_pprinter_field_print(stream_p, "Number of allocated counters                  : ",
                                   &cm_qmap.count,
                                   PARAM_UINT32_E);

    dbg_utils_pprinter_table_headline_print(stream_p, flow_counter_dump_clmns);

    sx_status = spectrum_flow_counter_iter_get(SX_ACCESS_CMD_GET_FIRST, 0, NULL, &cntr_id, &cntr_cnt);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to get accumulated counter ID (err=%s)\n", sx_status_str(sx_status));
        goto out;
    }

    while (cntr_cnt) {
        block_id = FLOW_CNTR_ID_LID_GET(cntr_id);
        fc_offest = FLOW_CNTR_ID_OFFSET_GET(cntr_id);

        sx_status = cm_lid_attr_get(FLOW_CNTR_ID_LID_GET(cntr_id), &cm_attr);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("%s: cm_return_len failed\n", __func__);
            goto out;
        }

        flow_counter_dump_clmns[column_type_idx].data = cm_type_str(cm_attr.type);

        sx_status = spectrum_flow_counters.lock(cntr_id, NULL, NULL, &cm_index);
        if (SX_STATUS_SUCCESS == sx_status) {
            sx_status = spectrum_flow_counters.unlock(cntr_id);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR("%s: spectrum_flow_counter_unlock failed [lid=%u flow_counter_id=%u]\n",
                           __func__, FLOW_CNTR_ID_LID_GET(cntr_id), cntr_id);
            }
        } else {
            SX_LOG_ERR("%s: spectrum_flow_counter_lock failed [lid=%u, flow_counter_id=%u]\n",
                       __func__, FLOW_CNTR_ID_LID_GET(cntr_id), cntr_id);
            cm_index = 0;
        }

        dbg_utils_pprinter_table_data_line_print(stream_p, flow_counter_dump_clmns);

        sx_status = spectrum_flow_counter_iter_get(SX_ACCESS_CMD_GETNEXT, cntr_id, NULL, &cntr_id, &cntr_cnt);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("Failed to get accumulated counter ID (err=%s)\n", sx_status_str(sx_status));
            goto out;
        }
    }

    if (s_flow_estimator_counting_is_enabled) {
        spectrum_flow_estimator_profile_dbg_dump(dbg_dump_params_p);
    }

    if (brg_context.spec_cb_g.dev_type >= SX_CHIP_TYPE_SPECTRUM4) {
        flex_counter_by_ref_debug_dump(dbg_dump_params_p);
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}


static flow_counter_cb_t spectrum_flow_counters = {
    .set = spectrum_flow_counter_set,
    .get = spectrum_flow_counter_get,
    .clear = spectrum_flow_counter_clear,
    .is_exists = spectrum_flow_counter_is_exists,
    .iter_get = spectrum_flow_counter_iter_get,
    .bulk_set = spectrum_flow_counter_bulk_set,
    .ref_inc = spectrum_flow_counter_ref_inc,
    .ref_dec = spectrum_flow_counter_ref_dec,
    .ref_modify = spectrum_flow_counter_ref_modify,
    .is_accuflow = spectrum_flow_counter_is_accuflow,
    .accumulated_num_get = spectrum_flow_counter_accumulated_num_get,
    .estimator_counting_is_enabled = spectrum_flow_estimator_counting_is_enabled,
    .estimator_get = spectrum_flow_estimator_counter_get,
    .estimator_profile_set = spectrum_flow_estimator_profile_set,
    .estimator_profile_get = spectrum_flow_estimator_profile_get,
    .estimator_profile_iter_get = spectrum_flow_estimator_profile_iter_get,
    .estimator_profile_is_exists = spectrum_flow_estimator_profile_is_exists,
    .estimator_profile_ref_inc = spectrum_flow_estimator_profile_ref_inc,
    .estimator_profile_ref_dec = spectrum_flow_estimator_profile_ref_dec,
    .estimator_counter_is_matching_profile = spectrum_flow_estimator_counter_is_matching_profile,
    .dgb_dump = spectrum_flow_counter_dbg_dump,
    .is_counter_by_ref_type_base = spectrum_flow_counter_is_counter_by_ref_type_base,
};

sx_status_t sdk_flow_counter_init(sx_flow_counter_params_t *init_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_status_t rb_err = SX_STATUS_SUCCESS;
    cl_status_t cl_rc = CL_SUCCESS;
    uint32_t    cm_max = 0, cm_min = 0, cm_grow = 0;
    uint8_t     min_flow_counter_lines = 1;
    boolean_t   accuflow_counters_init_done = FALSE;
    boolean_t   rm_init_done = FALSE;
    boolean_t   debug_cmd_inited = FALSE;

    SX_LOG_ENTER();

    if (init_params_p == NULL) {
        SX_LOG_ERR("Failure - %s\n", sx_status_str(SX_STATUS_PARAM_ERROR));
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    g_flow_counter_init_params = *init_params_p;
    s_flow_estimator_counting_is_enabled = IS_FLOW_ESTIMATOR_COUNTING_ENABLED();

    err = __flow_counters_debug_commands_register();
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Registering debug commands failed \n");
        goto out;
    }
    debug_cmd_inited = TRUE;

    if (init_params_p->flow_counter_accumulated_type_max_number > 0) {
        err = __accuflow_counters_init(init_params_p);
        if (err != SX_STATUS_SUCCESS) {
            goto out;
        }
        accuflow_counters_init_done = TRUE;
    }

    cm_max = init_params_p->flow_counter_packet_type_max_number + init_params_p->flow_counter_byte_type_max_number;
    if (cm_max != 0) {
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FLOW_COUNTER_E].table_size_max = cm_max;
    }

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FLOW_COUNTER_E].is_initialized = TRUE;
    err = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_FLOW_COUNTER_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialize flow counters resource in resource-manager: %s\n",
                   sx_status_str(err));
        goto out;
    }
    rm_init_done = TRUE;

    if (cm_max == 0) {
        min_flow_counter_lines = MIN(rm_resource_global.cntr_lines_flow_pkt,
                                     MIN(rm_resource_global.cntr_lines_flow_byte,
                                         rm_resource_global.cntr_lines_flow_both));
        cm_max = rm_resource_global.cntr_bank_pairs * rm_resource_global.cntr_lines_per_bank * 2;
        if (min_flow_counter_lines != 0) {
            cm_max /= min_flow_counter_lines;
        }
    }
    cm_min = cm_max / 10;
    cm_grow = cm_min;

    if (brg_context.spec_cb_g.dev_type >= SX_CHIP_TYPE_SPECTRUM4) {
        spectrum_flow_counters.lock = spectrum_flow_counter_lock_spc4;
        spectrum_flow_counters.unlock = spectrum_flow_counter_unlock_spc4;
    } else {
        spectrum_flow_counters.lock = spectrum_flow_counter_lock;
        spectrum_flow_counters.unlock = spectrum_flow_counter_unlock;
    }

    flow_counter_set_cb(&spectrum_flow_counters);

    err = cm_user_init(NULL, sdk_flow_counter_clear_impl, sdk_flow_counter_add_impl,
                       &cm_handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to register to Counter Manager, err= %s.\n", sx_status_str(err));
    }

    cl_rc = CL_QPOOL_INIT(&cm_qpool,
                          cm_min, cm_max, cm_grow,
                          sizeof(cm_item_t),
                          NULL,
                          NULL,
                          NULL);
    if (cl_rc != CL_SUCCESS) {
        SX_LOG_ERR("CM Pool Init Failure - %s.\n", CL_STATUS_MSG(cl_rc));
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cl_qmap_init(&cm_qmap);
    cl_qmap_init(&cm_by_ref_qmap);

out:
    if (err != SX_STATUS_SUCCESS) {
        if (rm_init_done == TRUE) {
            rb_err = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_FLOW_COUNTER_E, FALSE);
            if (rb_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to deinitialize flow counters resource inside rollback: %s\n",
                           sx_status_str(rb_err));
            } else {
                rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FLOW_COUNTER_E].is_initialized = FALSE;
            }
        }

        if (accuflow_counters_init_done == TRUE) {
            __accuflow_counters_deinit(TRUE);
        }

        if (debug_cmd_inited == TRUE) {
            rb_err = __flow_counters_debug_commands_unregister();
            if (SX_STATUS_SUCCESS != rb_err) {
                SX_LOG_ERR("Rollback: Unregistering debug commands failed \n");
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

void sdk_flow_counter_deinit(const boolean_t is_forced)
{
    SX_LOG_ENTER();
    sx_status_t       err = SX_STATUS_SUCCESS;
    cm_item_t        *item_p = NULL;
    cl_map_item_t    *map_item_p = NULL;
    cm_by_ref_item_t *cm_by_ref_item = NULL;
    cm_attr_t         cm_attr = {0};
    int32_t           ref;


    err = __flow_counters_debug_commands_unregister();
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Unregistering debug commands failed \n");
    }

    while (SX_CL_QMAP_HEAD(map_item_p, &cm_qmap)) {
        cl_qmap_remove_item(&cm_qmap, map_item_p);
        item_p = (void*)PARENT_STRUCT(map_item_p, cm_item_t, map_item);
        if (FLOW_CNTR_ID_OFFSET_GET(item_p->cntr_id) == 0) {
            if (is_forced == TRUE) {
                SX_MEM_CLR(cm_attr);
                if (cm_lid_attr_get(FLOW_CNTR_ID_LID_GET(item_p->cntr_id), &cm_attr) == SX_STATUS_SUCCESS) {
                    if (cm_attr.ref > 1) {
                        ref = (-1 * (cm_attr.ref - 1));
                        err = cm_ref_modify(FLOW_CNTR_ID_LID_GET(item_p->cntr_id), ref);
                        if (SX_CHECK_FAIL(err)) {
                            SX_LOG_WRN("Failed to modify ref counter %u, error: %s\n",
                                       item_p->cntr_id, sx_status_str(err));
                        }
                    }
                }
            }

            err = cm_block_delete(FLOW_CNTR_ID_LID_GET(item_p->cntr_id));
            if (SX_CHECK_FAIL(err)) {
                if (is_forced == TRUE) {
                    SX_LOG_WRN("Failed to delete counter %u, error: %s\n",
                               item_p->cntr_id, sx_status_str(err));
                } else {
                    SX_LOG_ERR("Failed to delete counter %u, error: %s\n",
                               item_p->cntr_id, sx_status_str(err));
                }
            }
        }
        if (cm_counter_bank_type_get(FLOW_CNTR_ID_LID_GET(item_p->cntr_id)) == CM_ACCUFLOW_COUNTERS_BANKS_E) {
            cl_qpool_put(&accuflow_counters_qpool, __cm_parent_struct_pool_item(item_p));
        } else {
            cl_qpool_put(&cm_qpool, __cm_parent_struct_pool_item(item_p));
        }
    }

    CL_QPOOL_DESTROY(&cm_qpool);

    err = cm_user_deinit(cm_handle);
    if (SX_CHECK_FAIL(err)) {
        if (is_forced == TRUE) {
            SX_LOG_WRN("Failed to deinitialize counter manager handle, error: %s\n",
                       sx_status_str(err));
        } else {
            SX_LOG_ERR("Failed to deinitialize counter manager handle, error: %s\n",
                       sx_status_str(err));
        }
    }

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_FLOW_COUNTER_E].is_initialized = FALSE;
    err = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_FLOW_COUNTER_E, is_forced);
    if (SX_CHECK_FAIL(err)) {
        if (is_forced == TRUE) {
            SX_LOG_WRN("Failed to deinitialize resource manager flow counter table, error: %s\n",
                       sx_status_str(err));
        } else {
            SX_LOG_ERR("Failed to deinitialize resource manager flow counter table, error: %s\n",
                       sx_status_str(err));
        }
    }

    __accuflow_counters_deinit(is_forced);
    s_flow_estimator_counting_is_enabled = FALSE;
    while (SX_CL_QMAP_HEAD(map_item_p, &cm_by_ref_qmap)) {
        cm_by_ref_item = (void*)PARENT_STRUCT(map_item_p, cm_by_ref_item_t, map_item);
        cl_qmap_remove(&(cm_by_ref_qmap), cm_by_ref_item->base_counter_id);
        if (SX_CHECK_FAIL(cm_unlock(cm_by_ref_item->base_counter_id))) {
            SX_LOG_ERR("failed to unlock the base counter\n");
        }
        cl_free(cm_by_ref_item);
    }

    SX_LOG_EXIT();
}

static sx_status_t __accuflow_counters_init(const sx_flow_counter_params_t *init_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_status_t rb_err = SX_STATUS_SUCCESS;
    cl_status_t cl_rc = CL_SUCCESS;
    uint32_t    afcm_max = 0, afcm_min = 0, afcm_grow = 0;
    boolean_t   rm_init_done = FALSE;

    SX_LOG_ENTER();

    afcm_max = 1024 * init_params_p->flow_counter_accumulated_type_max_number;
    afcm_min = afcm_max / 10;
    afcm_grow = afcm_min;

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E].is_initialized = TRUE;
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E].table_size_max = afcm_max;
    err = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialize flow counters resource in resource-manager: %s\n",
                   sx_status_str(err));
        goto out;
    }
    rm_init_done = TRUE;

    cl_rc = CL_QPOOL_INIT(&accuflow_counters_qpool,
                          afcm_min, afcm_max, afcm_grow,
                          sizeof(cm_item_t),
                          NULL,
                          NULL,
                          NULL);
    if (cl_rc != CL_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }
    g_accuflow_counters_inited = TRUE;

out:
    if (err != SX_STATUS_SUCCESS) {
        if (rm_init_done == TRUE) {
            rb_err = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E, FALSE);
            if (rb_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to deinitialize flow counters resource inside rollback: %s\n",
                           sx_status_str(rb_err));
            } else {
                rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E].is_initialized = FALSE;
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

static void __accuflow_counters_deinit(const boolean_t is_forced)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (g_accuflow_counters_inited == TRUE) {
        rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E].is_initialized = FALSE;
        err = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACCUFLOW_COUNTER_E, is_forced);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to deinitialize resource manager flow counter table, error: %s\n",
                       sx_status_str(err));
        }

        CL_QPOOL_DESTROY(&accuflow_counters_qpool);
        g_accuflow_counters_inited = FALSE;
    }
}

static void __flow_counters_prm_idx_get_debug_cmd(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_flow_counter_id_t flow_counter_id = 0;
    cm_type_e            type = 0;
    cm_hw_type_t         hw_type = 0;
    cm_index_t           index = 0;

    UNUSED_PARAM(handler_context);

    if ((argc == 1) && (sscanf(argv[0], "%u", (uint32_t*)&flow_counter_id) == 1)) {
        err = flow_counter_lock(flow_counter_id, &type, &hw_type, &index);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Debug CLI. Failed to lock the counter %u, error: %s\n",
                       flow_counter_id, sx_status_str(err));
            return;
        }

        err = flow_counter_unlock(flow_counter_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Debug CLI. Failed to unlock the counter %u, error: %s\n",
                       flow_counter_id, sx_status_str(err));
            /* return is omitted on purpose */
        }

        dbg_utils_print(stream, "Debug CLI. Flow counter %u: type %u, hw_type %u, index %u \n",
                        flow_counter_id, type, hw_type, index);
    } else {
        SX_LOG_ERR("Error: need only 1 Flow counter ID parameter\n");
    }
}

static void __flow_counters_relocate_force(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_flow_counter_id_t flow_counter_id = 0;

    UNUSED_PARAM(handler_context);

    if ((argc == 1) && (sscanf(argv[0], "%u", (uint32_t*)&flow_counter_id) == 1)) {
        err = cm_counter_relocate_force(FLOW_CNTR_ID_LID_GET(flow_counter_id));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Debug CLI. Failed to force relocation of the counter %u, error: %s\n",
                       flow_counter_id, sx_status_str(err));
            return;
        }

        dbg_utils_print(stream, "Debug CLI. Flow counter %u was relocated. \n",
                        flow_counter_id);
    } else {
        SX_LOG_ERR("Error: need only 1 Flow counter ID parameter\n");
    }
}

static void __flow_counters_relocate_undo(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_flow_counter_id_t flow_counter_id = 0;

    UNUSED_PARAM(handler_context);

    if ((argc == 1) && (sscanf(argv[0], "%u", (uint32_t*)&flow_counter_id) == 1)) {
        err = cm_counter_relocate_undo(FLOW_CNTR_ID_LID_GET(flow_counter_id));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Debug CLI. Failed to undo the relocation of the counter %u, error: %s\n",
                       flow_counter_id, sx_status_str(err));
            return;
        }

        dbg_utils_print(stream, "Debug CLI. Flow counter %u was moved back. \n",
                        flow_counter_id);
    } else {
        SX_LOG_ERR("Error: need only 1 Flow counter ID parameter\n");
    }
}

static sx_status_t __flow_counters_debug_commands_register()
{
    sx_utils_status_t rc = SX_UTILS_STATUS_SUCCESS;

    rc = sx_utils_debug_cmd_register_path("flow counters prm_idx get <Flow-ID>",
                                          __flow_counters_prm_idx_get_debug_cmd,
                                          (void*)FALSE);
    if (rc) {
        SX_LOG_NTC("Failed to register Flow counters debug CLI\n");
    }

    sx_utils_debug_cmd_register_path("flow counters relocate <Flow-ID> force",
                                     __flow_counters_relocate_force,
                                     NULL);
    sx_utils_debug_cmd_register_path("flow counters relocate <Flow-ID> undo",
                                     __flow_counters_relocate_undo,
                                     NULL);

    return SX_STATUS_SUCCESS;
}

static sx_status_t __flow_counters_debug_commands_unregister()
{
    sx_utils_status_t rc = SX_UTILS_STATUS_SUCCESS;

    rc = sx_utils_debug_cmd_unregister_path("flow counters prm_idx get <Flow-ID>");
    if (rc) {
        SX_LOG_NTC("Failed to unregister Flow counters debug CLI\n");
    }
    sx_utils_debug_cmd_unregister_path("flow counters relocate <Flow-ID> force");
    sx_utils_debug_cmd_unregister_path("flow counters relocate <Flow-ID> undo");

    return SX_STATUS_SUCCESS;
}
