/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/cl_types.h>
#include <complib/cl_commchnl.h>

#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/sxd_access_register.h>

#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_cos.h>
#include <sx/sdk/sx_api_fdb.h>
#include <sx/sdk/sx_api_flow_counter.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_lag.h>
#include <sx/sdk/sx_api_mstp.h>
#include <sx/sdk/sx_api_policer.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sdk/sx_api_span.h>
#include <sx/sdk/sx_api_topo.h>
#include <sx/sdk/sx_api_vlan.h>
#include <sx/sdk/sx_api_bridge.h>
#include <sx/sdk/sx_api_tunnel.h>
#include <sx/sdk/sx_api_mc_container.h>
#include <sx/sdk/sx_api_mpls.h>
#include <sx/sdk/sx_api_issu.h>
#include <sx/sdk/sx_api_bfd.h>
#include <sx/sdk/sx_api_register.h>
#include <sx/sdk/sx_api_adaptive_routing.h>
#include <sx/sdk/sx_api_bulk_counter.h>
#include <sx/sdk/sx_api_dbg.h>
#include <sx/sdk/sx_api_flex_modifier.h>
#include <sx/sdk/sx_api_flex_parser.h>
#include <sx/sdk/sx_api_flex_pm.h>
#include <sx/sdk/sx_api_macsec.h>
#include <sx/sdk/sx_api_mgmt.h>
#include <sx/sdk/sx_api_ptp.h>
#include <sx/sdk/sx_api_stateful_db.h>
#include <sx/sdk/sx_api_tele.h>
#include <sx/sdk/sx_api_truncation_profile.h>
#include "sx_api_internal.h"
#include <sx/sdk/sx_init.h>

#undef __MODULE__
#define __MODULE__ SX_API_INIT

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;


/************************************************
 *  Global variables
 ***********************************************/
extern boolean_t g_sx_log_api_func_enabled;

/************************************************
 *  Functions Declaration
 ***********************************************/

/************************************************
 *  Functions Implementation
 ***********************************************/

sx_status_t sx_api_system_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  const sx_verbosity_level_t      module_verbosity_level,
                                                  const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;

        /* set all modules verbosity level */

        err = sx_api_internal_log_verbosity_level_set(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, SX API INTERNAL API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_flow_counter_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, FLOW COUNTER API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_policer_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, POLICER API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_host_ifc_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, HOST IFC API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_port_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, PORT API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_topo_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, TOPO API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_lag_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, LAG API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_vlan_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, VLAN API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_fdb_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, FDB API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_cos_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, COS API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_mstp_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, MSTP API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_router_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, ROUTER API, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_acl_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, ACL module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_span_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, SPAN module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_bridge_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, BRIDGE module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_mc_container_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, MC_CONTAINER  module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_tunnel_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, TUNNEL module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_mpls_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, MPLS module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_issu_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, ISSU module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_bfd_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, BFD module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_register_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, REGISTER module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_ar_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, AR module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_bulk_counter_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, BULK_COUNTER module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_cos_redecn_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, COS_REDECN module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_dbg_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, DBG module, return message: [%s]\n", sx_status_str(err));
        }
        err =
            sx_api_flex_modifier_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, FLEX_MODIFIER module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_flex_parser_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, FLEX_PARSER module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_flex_pm_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, FLEX_PM module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_macsec_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, MACSEC module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_mgmt_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, MGMT module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_ptp_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, PTP module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_stateful_db_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, STATEFUL_DB module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_tele_log_verbosity_level_set(handle, SX_LOG_VERBOSITY_TARGET_API, 0, api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, TELE module, return message: [%s]\n", sx_status_str(err));
        }
        err = sx_api_truncation_profile_log_verbosity_level_set(handle,
                                                                SX_LOG_VERBOSITY_TARGET_API,
                                                                0,
                                                                api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, TRUNCATION_PROFILE module, return message: [%s]\n",
                       sx_status_str(err));
        }
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_ALL_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_system_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  sx_verbosity_level_t           *module_verbosity_level_p,
                                                  sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_ALL_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_system_log_enter_func_severity_set(const sx_api_handle_t                 handle,
                                                      const sx_log_verbosity_target_attr_t *attr_p)
{
    sx_status_t                                        err = SX_STATUS_SUCCESS;
    sx_api_system_log_enter_func_severity_set_params_t cmd_body;
    uint32_t                                           cmd_size =
        sizeof(sx_api_system_log_enter_func_severity_set_params_t);

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (NULL == attr_p) {
        SX_LOG_ERR("attr_p is null pointer.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.attr = *attr_p;

    if ((attr_p->verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (attr_p->verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        g_sx_log_api_func_enabled = attr_p->enable;
    }

    if ((attr_p->verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (attr_p->verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = sx_api_send_command_wrapper(handle,
                                          SX_API_SYSTEM_LOG_ENTER_FUNC_SEVERITY_SET_E,
                                          (uint8_t*)&cmd_body, cmd_size);
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_system_log_enter_func_severity_get(const sx_api_handle_t           handle,
                                                      sx_log_verbosity_target_attr_t *attr_p)
{
    sx_api_command_head_t                              cmd_head;
    sx_api_system_log_enter_func_severity_set_params_t cmd_body;
    sx_api_reply_head_t                                reply_head;
    sx_status_t                                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);


    if (NULL == attr_p) {
        SX_LOG_ERR("attr_p is null pointer.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (attr_p->verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if (attr_p->verbosity_target == SX_LOG_VERBOSITY_BOTH) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target BOTH is not allowed for get command.\n");
        goto out;
    }

    if (attr_p->verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) {
        cmd_head.opcode = SX_API_SYSTEM_LOG_ENTER_FUNC_SEVERITY_GET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.attr.verbosity_target = attr_p->verbosity_target;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        attr_p->enable = cmd_body.attr.enable;
    } else {
        attr_p->enable = g_sx_log_api_func_enabled;
    }


out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_open(sx_log_cb_t logging_cb, sx_api_handle_t *handle)
{
    sx_api_user_ctxt_t      *ctxt = NULL;
    sx_api_sx_sdk_versions_t versions;
    uint32_t                 len = sizeof(versions);
    int                      log_err = 0;
    cl_status_t              cl_err = CL_SUCCESS;
    sx_status_t              err = SX_STATUS_SUCCESS;
    int                      sxd_err = 0;
    sxd_ctrl_pack_t          ctrl_pack;
    int                      fd = 0;
    sx_api_open_params_t     cmd_body;
    char                    *sx_api_commchnl_addr = NULL;

    log_err = sx_log_init(TRUE, NULL, logging_cb);
    if (log_err != 0) {
        fprintf(stderr, "ERROR: Initializing log utility failed.\n");
        return SX_STATUS_PARAM_ERROR;
    }

    SX_API_LOG_ENTER();

    SX_MEM_CLR(ctrl_pack);
    SX_MEM_CLR(cmd_body);

    if (handle == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL handle\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out_log;
    }

    *handle = SX_API_INVALID_HANDLE;

    err = utils_clr_memory_get((void**)&ctxt, 1,
                               sizeof(sx_api_user_ctxt_t),
                               UTILS_MEM_TYPE_ID_API_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Memory allocation failed.\n");
        goto out_log;
    }

    sx_api_commchnl_addr = getenv("SX_API_SOCKET_FILE");
    if (sx_api_commchnl_addr == NULL) {
        sx_api_commchnl_addr = SX_API_COMMCHNL_ADDRESS;
    }

    /* Complib init is not needed as long as atomic operation and timers are not used */
    cl_err = cl_commchnl_init(&(ctxt->commchnl), sx_api_commchnl_addr,
                              CL_COMMCHNL_SIDE_CLIENT);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not open SX-API client communication channel.\n");
        err = SX_STATUS_COMM_ERROR;
        goto out_ctxt;
    }

    cl_err = cl_spinlock_init(&(ctxt->mutex));
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not open SX-API client mutex\n");
        err = SX_STATUS_ERROR;
        goto out_commchnl;
    }

    cl_err = cl_commchnl_recv_fd(&(ctxt->commchnl), TRUE, (uint8_t*)&versions,
                                 &len, &fd);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_WARNING, "Failed opening new connection: Out Of Resources.\n");
        err = SX_STATUS_COMM_ERROR;
        goto out_spinlock;
    }

    sxd_err = sxd_get_new_handle(fd, &ctxt->dev);
    if (sxd_err != 0) {
        SX_LOG_ERR("Failed to get new handle from SXD, errno = [%s], sxd_err = [%d]\n",
                   strerror(errno), sxd_err);
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out_spinlock;
    }

    /* set receive multiple packets = false */
    ctrl_pack.cmd_body = (void*)FALSE;
    ctrl_pack.ctrl_cmd = CTRL_CMD_MULTI_PACKET_ENABLE;
    sxd_err = sxd_ioctl(ctxt->dev, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("IOCTL failed (set MULTI_PACKET_ENABLE = FALSE), errno = [%s]\n",
                   strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out_sxd_handle;
    }

    /* set blocking on read */
    ctrl_pack.cmd_body = (void*)TRUE;
    ctrl_pack.ctrl_cmd = CTRL_CMD_BLOCKING_ENABLE;
    sxd_err = sxd_ioctl(ctxt->dev, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("ioctl FAILED (set BLOCKING_ENABLE = TRUE), errno = [%s]\n",
                   strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out_sxd_handle;
    }

    /* get ownership on the FD (so fd will be displayed in fd_dump with the current process and not under SDK process) */
    ctrl_pack.cmd_body = NULL;
    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_OWNER;
    sxd_err = sxd_ioctl(ctxt->dev, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("sxd_ioctl (set CTRL_CMD_SET_OWNER) error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    ctxt->valid = TRUE;
    err = host_ifc_user_channel_init();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to initiate user channel. err = [%s]\n", sx_status_str(err));
        goto out_sxd_handle;
    }

    *handle = (uint64_t)(uintptr_t)ctxt;

    /* Retrieve from the SDK process if the user asked to hide the deprecation errors.
     * If he did, set the value in this process copy of sx_log library */
    err = sx_api_send_command_wrapper(*handle,
                                      SX_API_INT_CMD_SDK_OPEN_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(cmd_body));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve SDK deprecation error mode, err %s\n",
                   sx_status_str(err));
        goto out_sxd_handle;
    }

    if (cmd_body.hide_deprecation_err == TRUE) {
        sx_log_hide_deprecation_err_set();
    }

    SX_LOG(SX_LOG_INFO, "SX-API handle opened successfully , handle: [%" PRIu64 "]\n", handle[0]);
    goto out;

out_sxd_handle:
    sxd_put_handle(ctxt->dev);

out_spinlock:
    cl_spinlock_destroy(&(ctxt->mutex));

out_commchnl:
    cl_commchnl_destroy(&(ctxt->commchnl));

out_ctxt:
    (void)utils_memory_put((void*)ctxt, UTILS_MEM_TYPE_ID_API_E);

out_log:
    sx_log_close();

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_transaction_mode_set(const sx_api_handle_t handle, const sx_access_cmd_t cmd)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    cmd_size;

    SX_API_LOG_ENTER();

    sx_api_transaction_mode_set_params_t cmd_body = {
        .cmd = cmd,
    };

    cmd_size = sizeof(sx_api_transaction_mode_set_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TRANSACTION_MODE_SET_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_close(sx_api_handle_t *handle)
{
    sx_api_user_ctxt_t *ctxt = NULL;
    sx_status_t         err = SX_STATUS_SUCCESS;
    int                 sxd_err = 0;

    SX_API_LOG_ENTER();

    if (handle == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL handle\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    if (*handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Invalid handle\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_INVALID_HANDLE;
    }

    ctxt = (sx_api_user_ctxt_t*)(uintptr_t)*handle;

    host_ifc_user_channel_deinit();

    sxd_err = sxd_close_device(ctxt->dev);
    if (sxd_err != 0) {
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        SX_LOG_ERR("Failed to close device %u, errno = [%s]\n",
                   ctxt->dev, strerror(errno));
    }

    cl_spinlock_destroy(&(ctxt->mutex));
    cl_commchnl_destroy(&(ctxt->commchnl));
    (void)utils_memory_put((void*)ctxt, UTILS_MEM_TYPE_ID_API_E);

    *handle = SX_API_INVALID_HANDLE;

    SX_API_LOG_EXIT();
    sx_log_close();
    return err;
}

sx_status_t sx_api_device_hw_info_get(const sx_api_handle_t handle, sx_device_hw_info_t *dev_hw_info_p)
{
    const sx_api_user_ctxt_t * user_ctx = (sx_api_user_ctxt_t*)(uintptr_t)handle;
    sxd_status_t               sxd_err = SXD_STATUS_SUCCESS;
    sx_status_t                status = SX_STATUS_SUCCESS;
    struct ku_dev_info         dev_info;

    SX_API_LOG_ENTER();

    if (!user_ctx || !dev_hw_info_p) {
        status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!user_ctx->valid) {
        status = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    /* we use sxd_get_device_info_with_handle() and not sxd_get_device_info() because this API
     * is running on the client side and might be called in a very early stage, before
     * sxd_access_reg_init() call that initializes hw_p. Moreover, sxd_access_reg_init()
     * might not be called at all on the client side.
     */
    memset(&dev_info, 0, sizeof(dev_info));
    dev_info.dev_id = 1;
    sxd_err = sxd_get_device_info_with_handle(user_ctx->dev, &dev_info);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        status = sxd_status_to_sx_status(sxd_err);
        SX_LOG_ERR("Failed to get secure FW boot status, error: %s\n", sx_status_str(status));
        goto out;
    }

    dev_hw_info_p->chip_type = (sx_chip_types_t)dev_info.dev_info.dev_info_ro.chip_type;

    switch (dev_info.dev_info.dev_info_ro.fw_boot_status) {
    case SXD_FW_BOOT_STATUS_OK_E:
        break;

    case SXD_FW_BOOT_STATUS_IN_FLASH_RECOVERY_E:
        SX_LOG_ERR("FW image is faulty, boot status is 'Flash Recovery' (chip-type: %s)\n",
                   sx_chip_type_str(dev_hw_info_p->chip_type));
        status = SX_STATUS_FW_INIT_FAILURE;
        break;

    case SXD_FW_BOOT_STATUS_RMA_E:
        SX_LOG_ERR("FW image is faulty, boot status is 'RMA' (chip-type: %s)\n",
                   sx_chip_type_str(dev_hw_info_p->chip_type));
        status = SX_STATUS_DEVICE_UNRECOVERABLE;
        break;

    default:
        /* we should not get here */
        SX_LOG_ERR("FW image is faulty, boot status is unknown\n");
        status = SX_STATUS_ERROR;
        break;
    }

out:
    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_sdk_init_set(const sx_api_handle_t handle, const sx_api_sx_sdk_init_t *sdk_init_params_p)
{
    sx_api_command_head_t     cmd_head;
    sx_api_command_sdk_init_t cmd_body;
    sx_api_reply_head_t       reply_head;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (sdk_init_params_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL param.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((sdk_init_params_p->profile.swid0_config_type.type == SX_SWID_TYPE_DISABLED) &&
        (sdk_init_params_p->profile.swid1_config_type.type == SX_SWID_TYPE_DISABLED) &&
        (sdk_init_params_p->profile.swid2_config_type.type == SX_SWID_TYPE_DISABLED) &&
        (sdk_init_params_p->profile.swid3_config_type.type == SX_SWID_TYPE_DISABLED) &&
        (sdk_init_params_p->profile.swid4_config_type.type == SX_SWID_TYPE_DISABLED) &&
        (sdk_init_params_p->profile.swid5_config_type.type == SX_SWID_TYPE_DISABLED) &&
        (sdk_init_params_p->profile.swid6_config_type.type == SX_SWID_TYPE_DISABLED) &&
        (sdk_init_params_p->profile.swid7_config_type.type == SX_SWID_TYPE_DISABLED)) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_SDK_INIT_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_command_sdk_init_t);

    cmd_body.sdk_init_params = *sdk_init_params_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_sdk_init_params_get(const sx_api_handle_t handle, sx_api_sx_sdk_init_t *sdk_init_params_p)
{
    sx_api_command_head_t cmd_head;
    sx_api_reply_head_t   reply_head;
    sx_api_sx_sdk_init_t  cmd_body;
    sx_api_sx_sdk_init_t  reply_body;
    sx_status_t           err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    SX_API_LOG_ENTER();

    if (sdk_init_params_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "NULL param.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_SDK_INIT_PARAMS_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_sx_sdk_init_t);

    err =
        sx_api_send_command_decoupled(handle,
                                      &cmd_head,
                                      (uint8_t*)&cmd_body,
                                      &reply_head,
                                      (uint8_t*)&reply_body,
                                      sizeof(sx_api_sx_sdk_init_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    memcpy(sdk_init_params_p, &reply_body, sizeof(sx_api_sx_sdk_init_t));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_sx_sdk_version_get(const sx_api_handle_t handle, sx_api_sx_sdk_versions_t *versions_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_api_command_head_t     cmd_head;
    sx_api_sdk_versions_get_t cmd_body;
    sx_api_reply_head_t       reply_head;
    sx_api_sdk_versions_get_t reply_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    if (!versions_p) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_VERSIONS_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_sdk_versions_get_t);

    cmd_body.type = SX_API_SX_SDK_VERSIONS_GET_CMDS_E;
    if (strcmp(versions_p->sx_api, "com") == 0) {
        cmd_body.data.print_commands = 1;
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)&reply_body, sizeof(sx_api_sdk_versions_get_t));

    /* Copy received versions to the user's buffer */
    memcpy(versions_p, &reply_body.data.versions, sizeof(sx_api_sx_sdk_versions_t));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_object_refcount_get(const sx_api_handle_t handle,
                                       const sx_object_id_t *object_id_p,
                                       uint32_t             *refcount_p)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_api_command_head_t               cmd_head;
    sx_api_object_refcount_get_params_t cmd_body;
    sx_api_reply_head_t                 reply_head;
    sx_api_object_refcount_get_params_t reply_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    if (!object_id_p) {
        SX_LOG_ERR("object_id_p parameter is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!refcount_p) {
        SX_LOG_ERR("refcount_p parameter is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!SX_OBJECT_TYPE_CHECK_RANGE(object_id_p->object_type)) {
        SX_LOG_ERR("Invalid object type %u given\n", object_id_p->object_type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_REFCOUNT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_object_refcount_get_params_t);

    cmd_body.object_id = *object_id_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body,
                                        sizeof(reply_body));
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *refcount_p = reply_body.refcount;

out:
    SX_API_LOG_EXIT();
    return err;
}
