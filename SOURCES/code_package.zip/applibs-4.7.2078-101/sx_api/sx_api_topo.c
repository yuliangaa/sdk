/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_types.h>

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_topo.h>
#include "sx_api_internal.h"

#undef __MODULE__
#define __MODULE__ SX_API_TOPO

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

sx_status_t __sx_topo_tree_copy(sx_topo_lib_tree_t * tree, sx_api_topo_tree_set_params_t * rpc_tree);
/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sx_api_topo_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                const sx_verbosity_level_t      module_verbosity_level,
                                                const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_TOPO_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_topo_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                sx_verbosity_level_t           *module_verbosity_level_p,
                                                sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_TOPO_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_topo_device_dump(sx_api_handle_t handle, sx_access_cmd_t cmd, sx_topo_lib_dump_db_info_t* dump_info)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_status_t                 api_rc = SX_STATUS_SUCCESS;
    sx_api_topo_dump_db_info_t* cmd_body_p;
    uint32_t                    cmd_size = sizeof(sx_api_topo_dump_db_info_t);

    SX_API_LOG_ENTER();

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (NULL == dump_info) {
        SX_LOG_ERR("topo dev info is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /*allocate and copy */
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_TOPO_E, "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    cmd_body_p->cmd = cmd;

    /*copy dev_info data */
    SX_MEM_CPY_BUF(&(cmd_body_p->dump_info), dump_info, sizeof(sx_topo_lib_dump_db_info_t));

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TOPO_DEVICE_DUMP_E, (uint8_t*)cmd_body_p, cmd_size);

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_TOPO_E, "Error on cmd_body_p memory free", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_topo_tree_dump(sx_api_handle_t handle, sx_access_cmd_t cmd, sx_topo_lib_dump_db_info_t* dump_info)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_status_t                 api_rc = SX_STATUS_SUCCESS;
    sx_api_topo_dump_db_info_t* cmd_body_p;
    uint32_t                    cmd_size = sizeof(sx_api_topo_dump_db_info_t);

    SX_API_LOG_ENTER();

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (NULL == dump_info) {
        SX_LOG_ERR("topo tree info is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /*allocate and copy */
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_TOPO_E, "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    cmd_body_p->cmd = cmd;

    /*copy dev_info data */
    SX_MEM_CPY_BUF(&(cmd_body_p->dump_info), dump_info, sizeof(sx_topo_lib_dump_db_info_t));

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TOPO_TREE_DUMP_E, (uint8_t*)cmd_body_p, cmd_size);

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_TOPO_E, "Error on cmd_body_p memory free", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

/**
 *  This function sets the device s. Each device that is
 *  introduced to the system must be configured to the topology
 *  library. This API maintains a database that is used by other
 *  libraries to receive a device relevant for configuration
 *
 * @param[in] handle -   SX-API handle
 * @param[in] cmd -
 * ADD a new device to topo lib the
 * DELETE delete device from topo lib  note that the device
 * should be removed from all forwarding tree prior to that
 * operation change  unicast/multicast/flood_tree_hndl_arr;
 * READY device is ready we can route traffic from/to /via this
 * device please note that trees(unicast/multicast/flood_ must
 * be configured with the new device
 * EDIT in order to add tree to device
 * GET
 * GET_COUNT
 * @param[in] dev_info  - parameters to set
 *
 * @return sx_status_t
 */
sx_status_t sx_api_topo_device_set(IN sx_api_handle_t         handle,
                                   IN sx_access_cmd_t         cmd,
                                   IN sx_topolib_dev_info_t * dev_info)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       api_rc = SX_STATUS_SUCCESS;
    sx_api_topo_device_set_params_t * cmd_body_p;
    uint32_t                          cmd_size = sizeof(sx_api_topo_device_set_params_t);

    SX_API_LOG_ENTER();

    if (NULL == dev_info) {
        SX_LOG_ERR("topo dev info is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /* Calculate dev_info size */
    if ((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_GET) || (cmd == SX_ACCESS_CMD_EDIT)) {
        /* There is a valid tree list array, so we have to copy it as well */
        cmd_size += (dev_info->unicast_arr_len) * sizeof(sx_tree_hndl_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* Allocate the buffer and copy parameters */
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_TOPO_E, "cmd_body", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    cmd_body_p->cmd = cmd;

    /* Copy dev_info data */
    SX_MEM_CPY_BUF(&cmd_body_p->dev_info, dev_info, sizeof(sx_topolib_dev_info_t));
    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TOPO_DEVICE_SET_E, (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_PASS(api_rc)) {
        SX_MEM_CPY(dev_info, cmd_body_p->dev_info);
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_TOPO_E, "Error on cmd_body_p memory free", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

/**
 *  This function sets forwarding tree .
 *
 * @param[in] handle -   SX-API handle
 * @param[in] cmd -
 * ADD  add new tree
 * EDIT -add leaf to existing tree
 * DELETE-remove tree
 *
 * @param[in] sx_topo_lib_tree_t -
 * @param[in,out] len_p - In: Pointer to the input array's length
 *                       Out: Pointer to the # of updated entries
 *
 * @return sx_status_t
 */
sx_status_t sx_api_topo_tree_set(IN sx_api_handle_t handle, IN sx_access_cmd_t cmd, INOUT sx_topo_lib_tree_t  * tree)
{
    sx_status_t                   api_rc = SX_STATUS_SUCCESS;
    sx_api_topo_tree_set_params_t cmd_body;
    uint32_t                      cmd_size = sizeof(sx_api_topo_tree_set_params_t);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    /*copy user input to fix structure size */
    api_rc = __sx_topo_tree_copy(tree, &cmd_body);
    if (api_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("fail in copying memory \n");
        SX_API_LOG_EXIT();
        return SX_STATUS_MEMORY_ERROR;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
    case SX_ACCESS_CMD_EDIT:
        cmd_body.cmd = cmd;
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TOPO_TREE_SET_E, (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        if (SX_ACCESS_CMD_ADD == cmd_body.cmd) {
            SX_MEM_CPY_TYPE(&(tree->tree_hndl), &(cmd_body.tree_info.tree_hndl), sx_tree_hndl_t);
        }
    }


    SX_API_LOG_EXIT();
    return api_rc;
}

/**
 *  This function reload balance Unicast traffic
 *
 * @param[in] handle - SX-API handle
 *  [in] tree- all ports that forward traffic via "tree" should
 *  rebalance (choose another tree) possible value specific tree
 *  handle/ALL_TREE
 *  [in] log_port- rebalance this port possible value port/ALL_PORT
 *
 * @param[in,out] mc_id_p - Pointer to a Multicast ID
 *
 * @return sx_status_t
 */

sx_status_t sx_api_topo_unicast_reload_balance(IN sx_api_handle_t  handle,
                                               IN sx_tree_hndl_t   tree,
                                               IN sx_port_log_id_t log_port)
{
    UNUSED_PARAM(handle);
    UNUSED_PARAM(tree);
    UNUSED_PARAM(log_port);
    SX_API_LOG_ENTER();
    SX_API_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}


/**
 *  This function sets multicast tree group
 * tree group is a group  of devices that tag ingress packet
 * with the  same MID (multicast ID)
 * @param[in] handle -   SX-API handle
 * @param[in] cmd -
 * CREATE-create a new multicast tree group
 * DELETE-delete  multicast tree group please note that the
 * should be empty
 * GET-get multicast tree group parameters
 * @param[in] sx_topo_lib_tree_t -
 * @param[in,out] len_p - In: Pointer to the input array's length
 *                       Out: Pointer to the # of updated entries
 *
 * @return sx_status_t
 */

sx_status_t sx_api_topo_mc_tree_group_set(IN sx_api_handle_t            handle,
                                          IN sx_access_cmd_t            cmd,
                                          INOUT sx_mc_tree_group_id_t * mc_tree_group_id)
{
    UNUSED_PARAM(handle);
    UNUSED_PARAM(cmd);
    UNUSED_PARAM(mc_tree_group_id);
    SX_API_LOG_ENTER();
    SX_API_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}


/**
 *  This function  add/remove devices form  tree group
 *  tree group is a group of devices that tag ingress packet
 * with the same MID (multicast ID)
 * @param[in] handle -   SX-API handle
 * @param[in] cmd -
 * ADD/REMOVE
 * MOVE-migrate device form one  multicast tree group to another
 * @param[in] old_tree_group -valid only for cmd  MOVE the tree
 *       group to migrate from
 * @param[in] new_tree_group -
 * @param[in] dev_id
 *
 * @return sx_status_t
 */
sx_status_t sx_api_topo_mc_tree_group_dev_set(IN sx_api_handle_t         handle,
                                              IN sx_access_cmd_t         cmd,
                                              IN sx_mc_tree_group_hndl_t old_tree_group,
                                              IN sx_mc_tree_group_hndl_t new_tree_group,
                                              IN sx_dev_id_t             dev_id)
{
    UNUSED_PARAM(handle);
    UNUSED_PARAM(cmd);
    UNUSED_PARAM(old_tree_group);
    UNUSED_PARAM(new_tree_group);
    UNUSED_PARAM(dev_id);
    SX_API_LOG_ENTER();
    SX_API_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}


/**
 * This function add/remove forwarding tree form mc tree group
 *
 * @param[in] handle -   SX-API handle
 * @param[in] cmd -ADD/REMOVE
 *
 * @param[in]  tree_group - multicast tree group
 * @param[in]  tree forwarding tree
 *
 * @return sx_status_t
 */
sx_status_t sx_api_topo_mc_tree_group_tree_set(IN sx_api_handle_t         handle,
                                               IN sx_access_cmd_t         cmd,
                                               IN sx_mc_tree_group_hndl_t tree_group,
                                               IN sx_tree_hndl_t          tree)
{
    UNUSED_PARAM(handle);
    UNUSED_PARAM(cmd);
    UNUSED_PARAM(tree_group);
    UNUSED_PARAM(tree);
    SX_API_LOG_ENTER();
    SX_API_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}


/**
 *  This function reload balance multicast  traffic
 *
 * @param[in] handle - SX-API handle
 *  [in] tree- reload balance all multicast that  forwards traffic
 *  via mc_tree_group_id value "specific tree group
 *  handle"/ALL_TREE_GROUP
 * @return sx_status_t
 */

sx_status_t sx_api_topo_mc_reload_balance(IN sx_api_handle_t handle, IN sx_mc_tree_group_hndl_t mc_tree_group_id)
{
    UNUSED_PARAM(handle);
    UNUSED_PARAM(mc_tree_group_id);

    SX_API_LOG_ENTER();
    SX_API_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}


sx_status_t __sx_topo_tree_copy(sx_topo_lib_tree_t * tree, sx_api_topo_tree_set_params_t * rpc_tree)
{
    int dev_index, neigh_index;

    SX_API_LOG_ENTER();

    rpc_tree->tree_info.mc_root_device = tree->mc_root_device;
    rpc_tree->tree_info.tree_hndl = tree->tree_hndl;
    rpc_tree->tree_info.tree_qos = tree->tree_qos;
    rpc_tree->tree_info.tree_len = tree->tree_len;
    for (dev_index = 0; dev_index < tree->tree_len; dev_index++) {
        rpc_tree->tree_info.tree_dev[dev_index].dev_id = tree->tree_dev[dev_index].dev_id;
        rpc_tree->tree_info.tree_dev[dev_index].dirty = tree->tree_dev[dev_index].dirty;
        rpc_tree->tree_info.tree_dev[dev_index].len = tree->tree_dev[dev_index].len;
        for (neigh_index = 0; neigh_index < tree->tree_dev[dev_index].len; neigh_index++) {
            rpc_tree->tree_info.tree_dev[dev_index].neigh[neigh_index].len =
                tree->tree_dev[dev_index].neigh[neigh_index].len;
            rpc_tree->tree_info.tree_dev[dev_index].neigh[neigh_index].peer_dev_id =
                tree->tree_dev[dev_index].neigh[neigh_index].peer_dev_id;
            memcpy(rpc_tree->tree_info.tree_dev[dev_index].neigh[neigh_index].local_port,
                   tree->tree_dev[dev_index].neigh[neigh_index].local_port, sizeof(sx_port_phy_id_t) *
                   tree->tree_dev[dev_index].neigh[neigh_index].len);
            memcpy(rpc_tree->tree_info.tree_dev[dev_index].neigh[neigh_index].peer_local_port,
                   tree->tree_dev[dev_index].neigh[neigh_index].peer_local_port,
                   sizeof(sx_port_phy_id_t) * tree->tree_dev[dev_index].neigh[neigh_index].len);
        }
    }

    SX_API_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}
