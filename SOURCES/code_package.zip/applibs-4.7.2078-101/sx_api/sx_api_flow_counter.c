/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_flow_counter.h>
#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_FLOW_COUNTER

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;


/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_flow_counter_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                        const sx_log_verbosity_target_t verbosity_target,
                                                        const sx_verbosity_level_t      module_verbosity_level,
                                                        const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_FLOW_COUNTER_LOG_VERBOSITY_LEVEL_SET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flow_counter_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                        const sx_log_verbosity_target_t verbosity_target,
                                                        sx_verbosity_level_t           *module_verbosity_level_p,
                                                        sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_FLOW_COUNTER_LOG_VERBOSITY_LEVEL_GET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flow_counter_set(const sx_api_handle_t        handle,
                                    const sx_access_cmd_t        cmd,
                                    const sx_flow_counter_type_t counter_type,
                                    sx_flow_counter_id_t        *counter_id_p)
{
    sx_api_flow_counter_set_params_t cmd_body;
    sx_api_int_cmd_e                 int_cmd = SX_API_INT_CMD_FLOW_COUNTER_SET_E;
    uint32_t                         cmd_size = sizeof(sx_api_flow_counter_set_params_t);
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        break;

    case SX_ACCESS_CMD_DESTROY:
        if (counter_id_p == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("NULL parameter - counter_id.\n");
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access command: [%s].\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.counter_type = counter_type;
    if (cmd == SX_ACCESS_CMD_DESTROY) {
        cmd_body.counter_id = *counter_id_p;
    }

    err = sx_api_send_command_wrapper(handle, int_cmd, (uint8_t*)&cmd_body, cmd_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (counter_id_p != NULL) {
        *counter_id_p = cmd_body.counter_id;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flow_counter_bulk_set(const sx_api_handle_t             handle,
                                         const sx_access_cmd_t             cmd,
                                         const sx_flow_counter_bulk_attr_t bulk_attr,
                                         sx_flow_counter_bulk_data_t      *bulk_data_p)
{
    sx_api_flow_counter_bulk_set_params_t cmd_body;
    uint32_t                              cmd_size = sizeof(cmd_body);
    sx_status_t                           err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (bulk_data_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("NULL parameter - bulk_data_p.\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.bulk_attr, bulk_attr);
    if (cmd == SX_ACCESS_CMD_DESTROY) {
        cmd_body.bulk_data.base_counter_id = bulk_data_p->base_counter_id;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLOW_COUNTER_BULK_SET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    bulk_data_p->base_counter_id = cmd_body.bulk_data.base_counter_id;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flow_counter_get(const sx_api_handle_t      handle,
                                    const sx_access_cmd_t      cmd,
                                    const sx_flow_counter_id_t counter_id,
                                    sx_flow_counter_set_t     *counter_set_p)
{
    sx_api_flow_counter_get_params_t cmd_body;
    sx_api_int_cmd_e                 int_cmd = SX_API_INT_CMD_FLOW_COUNTER_GET_E;
    uint32_t                         cmd_size = sizeof(sx_api_flow_counter_get_params_t);
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (counter_set_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("NULL parameter - counter_val.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access command: [%s].\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.counter_id = counter_id;

    err = sx_api_send_command_wrapper(handle, int_cmd, (uint8_t*)&cmd_body, cmd_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *counter_set_p = cmd_body.counter_set;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flow_counter_iter_get(const sx_api_handle_t      handle,
                                         const sx_access_cmd_t      cmd,
                                         const sx_flow_counter_id_t counter_id_key,
                                         sx_flow_counter_filter_t  *counter_filter_p,
                                         sx_flow_counter_id_t      *counter_id_list_p,
                                         uint32_t                  *counter_id_cnt_p)
{
    sx_api_command_head_t                  cmd_head;
    sx_api_flow_counter_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                    reply_head;
    sx_api_flow_counter_iter_get_params_t* reply_body = NULL;
    uint32_t                               reply_body_size;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (counter_id_cnt_p == NULL) {
        SX_LOG_ERR("counter_id_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (*counter_id_cnt_p > SX_FLOW_COUNTER_ITER_GET_MAX) {
        SX_LOG_ERR("The requested number of counters %u is bigger than allowed %u\n",
                   *counter_id_cnt_p, SX_FLOW_COUNTER_ITER_GET_MAX);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*counter_id_cnt_p == 0) {
            SX_LOG_ERR("counter_id_cnt_p is 0\n");
            counter_id_list_p = NULL;
            goto out;
        }
        if (counter_id_list_p == NULL) {
            SX_LOG_ERR("counter_id_list_p is NULL\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*counter_id_cnt_p == 0) {
            counter_id_list_p = NULL;
        } else if (counter_id_list_p == NULL) {
            SX_LOG_ERR("counter_id_list_p is NULL\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }


    reply_body_size = sizeof(sx_api_flow_counter_iter_get_params_t) +
                      (*counter_id_cnt_p * sizeof(sx_flow_counter_id_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_WRN("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_FLOW_COUNTER_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_flow_counter_iter_get_params_t);
    cmd_head.list_size = *counter_id_cnt_p * sizeof(sx_flow_counter_id_t);

    cmd_body.counter_id_key = counter_id_key;
    cmd_body.cmd = cmd;
    cmd_body.counter_id_cnt = *counter_id_cnt_p;
    if (counter_filter_p != NULL) {
        cmd_body.counter_id_filter = *counter_filter_p;
    }

    *counter_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


    if (reply_body->counter_id_cnt) {
        *counter_id_cnt_p = reply_body->counter_id_cnt;
        if (counter_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(counter_id_list_p, reply_body->counter_id_list,
                             reply_body->counter_id_cnt, sx_flow_counter_id_t);
        }
    }


out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_flow_counter_clear_set(const sx_api_handle_t handle, const sx_flow_counter_id_t counter_id)
{
    sx_api_flow_counter_clear_params_t cmd_body;
    sx_api_int_cmd_e                   int_cmd = SX_API_INT_CMD_FLOW_COUNTER_CLEAR_E;
    uint32_t                           cmd_size = sizeof(sx_api_flow_counter_clear_params_t);
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.counter_id = counter_id;

    err = sx_api_send_command_wrapper(handle, int_cmd, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flow_counter_estimator_get(const sx_api_handle_t            handle,
                                              const sx_access_cmd_t            cmd,
                                              const sx_flow_counter_id_t       counter_id,
                                              sx_flow_estimator_counter_set_t *counter_set_p)
{
    sx_api_flow_estimator_counter_get_params_t cmd_body;
    sx_api_int_cmd_e                           int_cmd = SX_API_INT_CMD_FLOW_ESTIMATOR_COUNTER_GET_E;
    uint32_t                                   cmd_size = sizeof(sx_api_flow_estimator_counter_get_params_t);
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (counter_set_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("NULL parameter - counter_val.\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access command: [%s].\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.counter_id = counter_id;

    err = sx_api_send_command_wrapper(handle, int_cmd, (uint8_t*)&cmd_body, cmd_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *counter_set_p = cmd_body.counter_set;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flow_estimator_profile_set(const sx_api_handle_t                  handle,
                                              const sx_access_cmd_t                  cmd,
                                              const sx_flow_estimator_profile_key_t  profile_key,
                                              const sx_flow_estimator_profile_cfg_t *profile_cfg_p)
{
    sx_status_t                                 rc = SX_STATUS_SUCCESS;
    sx_api_flow_estimator_profile_set_params_t *cmd_body = NULL;
    sx_api_command_head_t                       cmd_head;
    sx_api_reply_head_t                         reply_head;
    uint32_t                                    cmd_body_size = 0;
    boolean_t                                   use_default_hash = FALSE;
    sx_flow_estimator_profile_hash_t            hash_params;
    sx_status_t                                 out_err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(hash_params);

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
    case SX_ACCESS_CMD_SET:
        if (profile_cfg_p == NULL) {
            SX_LOG_ERR("profile_cfg_p is NULL.\n");
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }
        if (profile_cfg_p->hash_params_p == NULL) {
            /* use default hash params */
            use_default_hash = TRUE;
        }
        if (!use_default_hash) {
            if ((profile_cfg_p->hash_params_p->fields_list_cnt > 0) &&
                (NULL == profile_cfg_p->hash_params_p->fields_list_p)) {
                rc = SX_STATUS_PARAM_NULL;
                SX_LOG_ERR("hash fields_list_p param is NULL.\n");
                goto out;
            }

            if ((profile_cfg_p->hash_params_p->fields_enable_list_cnt > 0) &&
                (NULL == profile_cfg_p->hash_params_p->fields_enable_list_p)) {
                rc = SX_STATUS_PARAM_NULL;
                SX_LOG_ERR("hash fields_enable_list_p param is NULL.\n");
                goto out;
            }
            if (profile_cfg_p->hash_params_p->fields_enable_list_cnt >
                FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_ENABLES_NUM) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("hash_field_enable_list_cnt exceeds range.\n");
                goto out;
            }
            if (profile_cfg_p->hash_params_p->fields_list_cnt > FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_NUM) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("hash_field_list_cnt exceeds range.\n");
                goto out;
            }
            SX_MEM_CPY_P(&hash_params, profile_cfg_p->hash_params_p);
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access command: [%s].\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body_size = sizeof(*cmd_body) + hash_params.fields_list_cnt * sizeof(sx_flow_estimator_profile_hash_field_t);
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body,
                        1,
                        cmd_body_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for flow estimator profile params.\n",
                        rc);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->profile_key.profile_id = profile_key.profile_id;
    if (profile_cfg_p) {
        cmd_body->bin_group_size = profile_cfg_p->bin_group_size;
    }

    cmd_body->use_default_hash = use_default_hash;
    cmd_head.opcode = SX_API_INT_CMD_FLOW_ESTIMATOR_PROFILE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    if (!use_default_hash) {
        cmd_body->hash_params.seed_en_by_sw = hash_params.seed_en_by_sw;
        cmd_body->hash_params.seed_by_sw = hash_params.seed_by_sw;

        cmd_body->hash_params.fields_enable_list_cnt = hash_params.fields_enable_list_cnt;
        if (hash_params.fields_enable_list_cnt > 0) {
            SX_MEM_CPY_ARRAY(cmd_body->hash_params.fields_enable_list_p,
                             hash_params.fields_enable_list_p,
                             hash_params.fields_enable_list_cnt,
                             sx_flow_estimator_profile_hash_field_enable_t);
        }

        cmd_body->hash_params.fields_cnt = hash_params.fields_list_cnt;
        if (hash_params.fields_list_cnt > 0) {
            SX_MEM_CPY_ARRAY(cmd_body->hash_params.fields_p,
                             hash_params.fields_list_p,
                             hash_params.fields_list_cnt,
                             sx_flow_estimator_profile_hash_field_t);
        }
    }

    rc = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                       &reply_head, NULL, 0);

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free flow estimator profile API params.\n",
                        out_err);
        if ((!SX_CHECK_FAIL(rc)) && SX_CHECK_FAIL(out_err)) {
            rc = out_err;
        }
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_flow_estimator_profile_get(const sx_api_handle_t                 handle,
                                              const sx_flow_estimator_profile_key_t profile_key,
                                              sx_flow_estimator_profile_attr_t     *profile_attr_p)
{
    sx_api_command_head_t                       cmd_head;
    sx_api_flow_estimator_profile_get_params_t  cmd_body;
    sx_api_flow_estimator_profile_get_params_t *reply_body = NULL;
    sx_api_reply_head_t                         reply_head;
    uint32_t                                    reply_body_size = 0;
    sx_status_t                                 out_err = SX_STATUS_SUCCESS;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((profile_attr_p->config.hash_params_p->fields_list_cnt > 0) &&
        (NULL == profile_attr_p->config.hash_params_p->fields_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("profile hash fields_list_p param is NULL.\n");
        goto out;
    }

    if ((profile_attr_p->config.hash_params_p->fields_enable_list_cnt > 0) &&
        (NULL == profile_attr_p->config.hash_params_p->fields_enable_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("profile hash fields_enable_list_p param is NULL.\n");
        goto out;
    }

    if (profile_attr_p->config.hash_params_p->fields_list_cnt > FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("profile hash fields_list_cnt exceeds range.\n");
        goto out;
    }

    if (profile_attr_p->config.hash_params_p->fields_enable_list_cnt >
        FLOW_ESTIMATOR_PROFILE_HASH_FIELDS_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("profile hash fields_enable_list_cnt exceeds range.\n");
        goto out;
    }

    reply_body_size = sizeof(sx_api_flow_estimator_profile_get_params_t) +
                      ((profile_attr_p->config.hash_params_p->fields_list_cnt) *
                       sizeof(sx_flow_estimator_profile_hash_field_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Allocate the field list and field list arrays in the command body */
    M_UTILS_CLR_MEM_GET(&reply_body,
                        1,
                        reply_body_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for flow estimator profile params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    cmd_body.profile_key.profile_id = profile_key.profile_id;
    cmd_body.hash_params.fields_enable_list_cnt = profile_attr_p->config.hash_params_p->fields_enable_list_cnt;
    cmd_body.hash_params.fields_cnt = profile_attr_p->config.hash_params_p->fields_list_cnt;

    cmd_head.opcode = SX_API_INT_CMD_FLOW_ESTIMATOR_PROFILE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_flow_estimator_profile_get_params_t);
    cmd_head.list_size = (profile_attr_p->config.hash_params_p->fields_list_cnt) *
                         sizeof(sx_flow_estimator_profile_hash_field_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body, reply_body_size);

    profile_attr_p->config.hash_params_p->fields_list_cnt = reply_body->hash_params.fields_cnt;
    if ((profile_attr_p->config.hash_params_p->fields_list_cnt > 0) &&
        (profile_attr_p->config.hash_params_p->fields_list_p != NULL)) {
        SX_MEM_CPY_ARRAY(profile_attr_p->config.hash_params_p->fields_list_p,
                         reply_body->hash_params.fields_p,
                         profile_attr_p->config.hash_params_p->fields_list_cnt,
                         sx_flow_estimator_profile_hash_field_t);
    }
    profile_attr_p->config.hash_params_p->fields_enable_list_cnt = reply_body->hash_params.fields_enable_list_cnt;
    if ((profile_attr_p->config.hash_params_p->fields_enable_list_cnt > 0) &&
        (profile_attr_p->config.hash_params_p->fields_enable_list_p != NULL)) {
        SX_MEM_CPY_ARRAY(profile_attr_p->config.hash_params_p->fields_enable_list_p,
                         reply_body->hash_params.fields_enable_list_p,
                         profile_attr_p->config.hash_params_p->fields_enable_list_cnt,
                         sx_flow_estimator_profile_hash_field_enable_t);
    }
    profile_attr_p->config.hash_params_p->seed_en_by_sw = reply_body->hash_params.seed_en_by_sw;
    profile_attr_p->config.hash_params_p->seed_by_sw = reply_body->hash_params.seed_by_sw;
    profile_attr_p->config.bin_group_size = reply_body->bin_group_size;
    profile_attr_p->in_use = reply_body->in_use;

out:
    if (NULL != reply_body) {
        M_UTILS_MEM_PUT(reply_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free ECMP port hash API params.\n",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_flow_estimator_profile_iter_get(const sx_api_handle_t                 handle,
                                                   const sx_access_cmd_t                 cmd,
                                                   const sx_flow_estimator_profile_key_t profile_key_key,
                                                   sx_flow_estimator_profile_filter_t   *profile_filter_p,
                                                   sx_flow_estimator_profile_key_t      *profile_key_list_p,
                                                   uint32_t                             *profile_key_cnt_p)
{
    sx_api_command_head_t                            cmd_head;
    sx_api_flow_estimator_profile_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                              reply_head;
    sx_api_flow_estimator_profile_iter_get_params_t* reply_body = NULL;
    uint32_t                                         reply_body_size;
    sx_status_t                                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (profile_key_cnt_p == NULL) {
        SX_LOG_ERR("profile_key_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (*profile_key_cnt_p > SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM) {
        SX_LOG_ERR("The requested number of counters %u is bigger than allowed %u\n",
                   *profile_key_cnt_p, SX_FLOW_ESTIMATOR_PROFILE_MAX_NUM);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*profile_key_cnt_p == 0) {
            SX_LOG_ERR("profile_key_cnt_p is 0\n");
            profile_key_list_p = NULL;
            goto out;
        }
        if (profile_key_list_p == NULL) {
            SX_LOG_ERR("profile_key_list_p is NULL\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*profile_key_cnt_p == 0) {
            profile_key_list_p = NULL;
        } else if (profile_key_list_p == NULL) {
            SX_LOG_ERR("profile_key_list_p is NULL\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_flow_estimator_profile_iter_get_params_t) +
                      (*profile_key_cnt_p * sizeof(sx_flow_estimator_profile_key_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_WRN("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_FLOW_ESTIMATOR_PROFILE_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_flow_estimator_profile_iter_get_params_t);
    cmd_head.list_size = *profile_key_cnt_p * sizeof(sx_flow_estimator_profile_key_t);

    cmd_body.profile_key.profile_id = profile_key_key.profile_id;
    cmd_body.cmd = cmd;
    cmd_body.profile_key_cnt = *profile_key_cnt_p;
    if (profile_filter_p != NULL) {
        cmd_body.profile_key_filter = *profile_filter_p;
    }

    *profile_key_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->profile_key_cnt) {
        *profile_key_cnt_p = reply_body->profile_key_cnt;
        if (profile_key_list_p != NULL) {
            SX_MEM_CPY_ARRAY(profile_key_list_p, reply_body->profile_key_list,
                             reply_body->profile_key_cnt, sx_flow_estimator_profile_key_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}
