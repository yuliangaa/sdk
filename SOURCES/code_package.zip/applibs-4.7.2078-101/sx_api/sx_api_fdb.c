/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_fdb.h>
#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_FDB

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;


/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_fdb_log_verbosity_level_set(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               const sx_verbosity_level_t      module_verbosity_level,
                                               const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_FDB_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_log_verbosity_level_get(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               sx_verbosity_level_t           *module_verbosity_level_p,
                                               sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_FDB_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_age_time_set(const sx_api_handle_t   handle,
                                    const sx_swid_t         swid,
                                    const sx_fdb_age_time_t age_time)
{
    sx_api_command_head_t            cmd_head;
    sx_api_fdb_age_time_set_params_t cmd_body;
    sx_api_reply_head_t              reply_head;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_AGE_TIME_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_age_time_set_params_t);

    cmd_body.age_time = age_time;
    cmd_body.swid = swid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_age_time_get(const sx_api_handle_t handle, const sx_swid_t swid, sx_fdb_age_time_t *age_time_p)
{
    sx_api_fdb_age_time_get_params_t cmd_body;
    uint32_t                         cmd_size = sizeof(sx_api_fdb_age_time_get_params_t);
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (SX_CHECK_FAIL(err = utils_check_pointer(age_time_p, "Age time"))) {
        SX_API_LOG_EXIT();
        return err;
    }

    cmd_body.swid = swid;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FDB_AGE_TIME_GET_E, (uint8_t*)&cmd_body, cmd_size);
    *age_time_p = cmd_body.age_time;

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_poll_set(const sx_api_handle_t handle, const sx_swid_t swid)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_api_command_head_t        cmd_head;
    sx_api_fdb_poll_set_params_t cmd_body;
    sx_api_reply_head_t          reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_POLL_SET_DEBUG_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_poll_set_params_t);

    cmd_body.swid = swid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_polling_interval_set(const sx_api_handle_t           handle,
                                            const sx_swid_t                 swid,
                                            const sx_fdb_polling_interval_t interval)
{
    sx_api_command_head_t                    cmd_head;
    sx_api_fdb_polling_interval_set_params_t cmd_body;
    sx_api_reply_head_t                      reply_head;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_POLLING_INTERVAL_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_polling_interval_set_params_t);

    cmd_body.interval = interval;
    cmd_body.swid = swid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_polling_interval_get(const sx_api_handle_t      handle,
                                            const sx_swid_t            swid,
                                            sx_fdb_polling_interval_t* interval)
{
    sx_api_fdb_polling_interval_get_params_t cmd_body;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (interval == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("interval is NULL.\n");
        goto out;
    }

    cmd_body.swid = swid;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_FDB_POLLING_INTERVAL_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_fdb_polling_interval_get_params_t));

    if (err == SX_STATUS_SUCCESS) {
        *interval = cmd_body.interval;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_uc_mac_addr_set(const sx_api_handle_t        handle,
                                       const sx_access_cmd_t        cmd,
                                       const sx_swid_t              swid,
                                       sx_fdb_uc_mac_addr_params_t *mac_list_p,
                                       uint32_t                    *data_cnt_p)
{
    sx_api_fdb_uc_mac_addr_set_params_t *cmd_body_p = NULL;
    uint32_t                             mac_list_size = 0;
    uint32_t                             cmd_body_size = 0;
    sx_status_t                          err = SX_STATUS_SUCCESS;
    uint32_t                             i = 0;

    SX_API_LOG_ENTER();

    /* Validity check - verify not null */
    if (NULL == mac_list_p) {
        SX_LOG_ERR("FDB: mac_list_p is null\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (NULL == data_cnt_p) {
        SX_LOG_ERR("FDB: data_cnt_p is null\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    mac_list_size = (*data_cnt_p) * sizeof(sx_fdb_uc_mac_addr_params_t);

    if (SX_ACCESS_CMD_CHECK_RANGE(cmd) == FALSE) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("FDB: cmd out of range\n");
        goto out;
    }

    if ((SX_ACCESS_CMD_ADD != cmd) &&
        (SX_ACCESS_CMD_DELETE != cmd)) {
        SX_LOG_ERR("access command unsupported\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    /* Validity check - verify data_cnt > 0 */
    if (0 == *data_cnt_p) {
        SX_LOG_ERR("FDB: data_cnt_p is zero\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Validity check - verify the MAC is UC*/
    for (i = 0; i < *data_cnt_p; i++) {
        if (mac_list_p[i].mac_addr.ether_addr_octet[0] & SX_FDB_GROUP_ADDRESS_MASK) {
            SX_LOG_ERR("FDB: At least one MAC address is not a UC address\n");
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (cmd != SX_ACCESS_CMD_DELETE) {
            if (SX_FDB_UC_MAC_ENTRY_CHECK_RANGE(mac_list_p[i].entry_type) == FALSE) {
                SX_LOG_ERR("FDB: MAC entry type exceeds range (%u-%u).\n",
                           SX_FDB_UC_ENTRY_TYPE_MIN, SX_FDB_UC_ENTRY_TYPE_MAX);
                SX_API_LOG_EXIT();
                return SX_STATUS_PARAM_EXCEEDS_RANGE;
            }
            if (SX_FDB_ACTION_CHECK_RANGE(mac_list_p[i].action) == FALSE) {
                SX_LOG_ERR("FDB: MAC entry action exceeds range (%u-%u).\n",
                           SX_FDB_ACTION_MIN, SX_FDB_ACTION_MAX);
                SX_API_LOG_EXIT();
                return SX_STATUS_PARAM_EXCEEDS_RANGE;
            }

            if (IS_MAC_ENTRY_DYNAMIC(mac_list_p[i].entry_type)) {
                if (SX_FDB_ACTION_FORWARD != mac_list_p[i].action) {
                    SX_LOG_ERR("Dynamic MAC entries are limited to FORWARD"
                               " action only: SX_STATUS_PARAM_ERROR\n");
                    err = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
            }
        }
    }

    cmd_body_size = sizeof(sx_api_fdb_uc_mac_addr_set_params_t) +
                    (*data_cnt_p * sizeof(sx_fdb_uc_mac_addr_params_t));

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    /* allocate memory for the list */
    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (SX_CHECK_FAIL(err)) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("FDB: Failed to allocate cmd_body memory (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    cmd_body_p->access_cmd = cmd;
    cmd_body_p->swid = swid;
    cmd_body_p->data_cnt = *data_cnt_p;

    /* copy mac entry list */
    memcpy(cmd_body_p->mac_list, mac_list_p, mac_list_size);

    err =
        sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FDB_UC_MAC_ADDR_SET_E, (uint8_t*)cmd_body_p, cmd_body_size);

    *data_cnt_p = cmd_body_p->data_cnt;
    if (*data_cnt_p > 0) {
        memcpy(mac_list_p, cmd_body_p->mac_list, cmd_body_p->data_cnt * sizeof(sx_fdb_uc_mac_addr_params_t));
    }

out:
    if (NULL != cmd_body_p) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_uc_mac_addr_get(const sx_api_handle_t              handle,
                                       const sx_swid_t                    swid,
                                       const sx_access_cmd_t              cmd,
                                       const sx_fdb_uc_mac_entry_type_t   mac_type,
                                       const sx_fdb_uc_mac_addr_params_t *key_p,
                                       const sx_fdb_uc_key_filter_t      *key_filter_p,
                                       sx_fdb_uc_mac_addr_params_t       *mac_list_p,
                                       uint32_t                          *data_cnt_p)
{
    sx_api_command_head_t        cmd_head;
    sx_api_fdb_uc_get_params_t   cmd_body;
    sx_api_reply_head_t          reply_head;
    sx_api_fdb_uc_reply_params_t reply_body;
    sx_status_t                  err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((mac_list_p == NULL) || (data_cnt_p == NULL) ||
        (key_p == NULL) || (key_filter_p == NULL)) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_MAC_ADDR_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    cmd_body.swid = swid;
    cmd_body.command = cmd;
    cmd_body.mac_type = mac_type;
    cmd_body.data_cnt = *data_cnt_p;
    SX_MEM_CPY(cmd_body.key, *key_p);
    SX_MEM_CPY(cmd_body.key_filter, *key_filter_p);

    *data_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)&reply_body, sizeof(reply_body));

    if ((err == SX_STATUS_SUCCESS) && (reply_body.data_cnt)) {
        *data_cnt_p = reply_body.data_cnt;
        SX_MEM_CPY_ARRAY(mac_list_p, reply_body.mac_list_p, reply_body.data_cnt, sx_fdb_uc_mac_addr_params_t);
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_uc_count_get(const sx_api_handle_t handle, const sx_swid_t swid, uint32_t *data_cnt_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_command_head_t            cmd_head;
    sx_api_fdb_uc_count_get_params_t cmd_body;
    sx_api_reply_head_t              reply_head;
    sx_api_fdb_uc_count_get_params_t reply_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    if (data_cnt_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_COUNT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    cmd_body.swid = swid;
    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)&reply_body, sizeof(reply_body));

    *data_cnt_p = reply_body.data_cnt;

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_uc_port_count_get(const sx_api_handle_t  handle,
                                         const sx_port_log_id_t log_port,
                                         uint32_t              *data_cnt_p)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                 cmd_head;
    sx_api_fdb_uc_port_count_get_params_t cmd_body;
    sx_api_reply_head_t                   reply_head;
    sx_api_fdb_uc_port_count_get_params_t reply_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    if (data_cnt_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_PORT_COUNT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    cmd_body.log_port = log_port;
    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)&reply_body, sizeof(reply_body));

    *data_cnt_p = reply_body.data_cnt;

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_uc_fid_count_get(const sx_api_handle_t handle,
                                        const sx_swid_t       swid,
                                        const sx_fid_t        fid,
                                        uint32_t             *data_cnt_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_command_head_t            cmd_head;
    sx_api_fdb_uc_fid_count_params_t cmd_body;
    sx_api_reply_head_t              reply_head;
    sx_api_fdb_uc_fid_count_params_t reply_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    if (data_cnt_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_FID_COUNT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    cmd_body.swid = swid;
    cmd_body.fid = fid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)&reply_body, sizeof(reply_body));

    *data_cnt_p = reply_body.data_cnt;

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_uc_limit_port_set(const sx_api_handle_t  handle,
                                         const sx_access_cmd_t  cmd,
                                         const sx_port_log_id_t log_port,
                                         const uint32_t         limit)
{
    sx_api_command_head_t             cmd_head;
    sx_api_fdb_uc_port_limit_params_t cmd_body;
    sx_api_reply_head_t               reply_head;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_LIMIT_PORT_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    cmd_body.limit = limit;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_uc_limit_port_get(const sx_api_handle_t  handle,
                                         const sx_port_log_id_t log_port,
                                         uint32_t              *limit_p)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                 cmd_head;
    sx_api_fdb_uc_limit_port_get_params_t cmd_body;
    sx_api_reply_head_t                   reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (NULL == limit_p) {
        SX_LOG_ERR("NULL param\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_LIMIT_PORT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    cmd_body.log_port = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)limit_p, sizeof(*limit_p));

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_uc_limit_fid_set(const sx_api_handle_t handle,
                                        const sx_access_cmd_t cmd,
                                        const sx_swid_t       swid,
                                        const sx_fid_t        fid,
                                        const uint32_t        limit)
{
    sx_api_command_head_t            cmd_head;
    sx_api_fdb_uc_fid_limit_params_t cmd_body;
    sx_api_reply_head_t              reply_head;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_LIMIT_FID_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.fid = fid;
    cmd_body.limit = limit;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_fdb_uc_limit_fid_get(const sx_api_handle_t handle,
                                        const sx_swid_t       swid,
                                        const sx_fid_t        fid,
                                        uint32_t             *limit_p)
{
    sx_api_command_head_t            cmd_head;
    sx_api_fdb_uc_fid_limit_params_t cmd_body;
    sx_api_reply_head_t              reply_head;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (NULL == limit_p) {
        SX_LOG_ERR("NULL param\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_LIMIT_FID_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    cmd_body.swid = swid;
    cmd_body.fid = fid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)limit_p, sizeof(*limit_p));

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_mc_mac_addr_set(const sx_api_handle_t   handle,
                                       const sx_access_cmd_t   cmd,
                                       const sx_swid_t         swid,
                                       const sx_vid_t          vid,
                                       const sx_mac_addr_t     group_addr,
                                       const sx_port_log_id_t* log_port_list_p,
                                       const uint32_t          port_cnt)
{
    sx_status_t                          api_status = SX_STATUS_SUCCESS;
    sx_status_t                          utils_status = SX_STATUS_SUCCESS;
    sx_api_command_head_t                cmd_head;
    sx_api_fdb_mc_mac_addr_set_params_t *cmd_body_p = NULL;
    uint32_t                             cmd_body_size = sizeof(sx_api_fdb_mc_mac_addr_set_params_t);
    sx_api_reply_head_t                  reply_head;
    uint32_t                             port_num = port_cnt;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    /* Validity check - verify the MAC is MC and not broadcast */
    if (!is_multicast_ether_addr(group_addr.ether_addr_octet) ||
        is_broadcast_ether_addr(group_addr.ether_addr_octet)) {
        SX_LOG_ERR("Given MAC address is not a MC address\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (log_port_list_p == NULL) {
        port_num = 0;
    }
    if (port_num > 0) {
        cmd_body_size += (port_num * sizeof(sx_port_log_id_t));
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_MC_MAC_ADDR_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    if (SX_CHECK_FAIL(utils_status = utils_check_msg_size(cmd_head.msg_size, SX_API_MESSAGE_SIZE_LIMIT))) {
        SX_API_LOG_EXIT();
        return utils_status;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for cmd_body_p\n", utils_status);
    if (SX_CHECK_FAIL(utils_status)) {
        SX_API_LOG_EXIT();
        return utils_status;
    }

    cmd_body_p->swid = swid;
    cmd_body_p->access_cmd = cmd;
    SX_MEM_CPY(cmd_body_p->group_addr, group_addr);
    cmd_body_p->vid = vid;
    cmd_body_p->port_num = port_num;

    if (log_port_list_p) {
        SX_MEM_CPY_BUF(cmd_body_p->log_port_list, log_port_list_p, port_num * sizeof(sx_port_log_id_t));
    }

    api_status = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body_p, &reply_head, NULL, 0);

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Failed to free cmd_body_p memory \n", utils_status);
    if (SX_CHECK_FAIL(utils_status)) {
        SX_API_LOG_EXIT();
        return utils_status;
    }

    SX_API_LOG_EXIT();

    return api_status;
}

sx_status_t sx_api_fdb_mc_mac_addr_get(const sx_api_handle_t handle,
                                       const sx_swid_t       swid,
                                       const sx_vid_t        vid,
                                       const sx_mac_addr_t   group_addr,
                                       sx_port_log_id_t     *log_port_list_p,
                                       uint32_t             *port_cnt_p)
{
    sx_api_command_head_t                cmd_head;
    sx_api_fdb_mc_mac_addr_get_params_t  cmd_body;
    sx_api_reply_head_t                  reply_head;
    sx_api_fdb_mc_mac_addr_get_params_t* reply_body = NULL;
    uint32_t                             reply_body_size;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    /* Validity check - verify the MAC is MC and not broadcast */
    if (!is_multicast_ether_addr(group_addr.ether_addr_octet) ||
        is_broadcast_ether_addr(group_addr.ether_addr_octet)) {
        SX_LOG_ERR("Given MAC address is not a MC address\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (port_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (log_port_list_p == NULL) {
        *port_cnt_p = 0;
    }
    if (*port_cnt_p == 0) {
        log_port_list_p = NULL;
    }

    if (is_mac_reserved_mc(group_addr)) {
        SX_LOG_DBG("Given MAC address is a MC Reserved address. Do nothing. Return OK.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_SUCCESS;
    }

    reply_body_size = sizeof(sx_api_fdb_mc_mac_addr_get_params_t) +
                      ((*port_cnt_p) * sizeof(sx_port_log_id_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_MC_MAC_ADDR_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_mc_mac_addr_get_params_t);
    cmd_head.list_size = (*port_cnt_p) * sizeof(sx_port_log_id_t);

    cmd_body.swid = swid;
    SX_MEM_CPY(cmd_body.group_addr, group_addr);
    cmd_body.vid = vid;
    cmd_body.port_num = *port_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    port_cnt_p[0] = reply_body->port_num;
    if (log_port_list_p != NULL) {
        SX_MEM_CPY_ARRAY(log_port_list_p, reply_body->log_port_list,
                         *port_cnt_p, sx_port_log_id_t);
    }

out:
    utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_mc_mac_addr_iter_get(const sx_api_handle_t         handle,
                                            const sx_access_cmd_t         cmd,
                                            const sx_swid_t               swid,
                                            const sx_fdb_mc_mac_key_t    *key_p,
                                            const sx_fdb_mc_mac_filter_t *filter_p,
                                            sx_fdb_mc_mac_key_t          *key_list_p,
                                            uint32_t                     *key_cnt_p)
{
    sx_api_command_head_t                     cmd_head;
    sx_api_fdb_mc_mac_addr_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                       reply_head;
    sx_api_fdb_mc_mac_addr_iter_get_params_t *reply_body = NULL;
    uint32_t                                  reply_body_size;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (key_cnt_p == NULL) {
        SX_LOG_ERR("key_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*key_cnt_p > 0) && (key_list_p == NULL)) {
        SX_LOG_ERR("*key_cnt_p is not 0 but key_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (((cmd == SX_ACCESS_CMD_GET) || (cmd == SX_ACCESS_CMD_GETNEXT)) &&
        (*key_cnt_p > 0) &&
        (key_p == NULL)) {
        SX_LOG_ERR("key_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*key_cnt_p == 0) {
            key_list_p = NULL;
        } else {
            *key_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*key_cnt_p == 0) {
            SX_LOG_DBG("MC MAC key count is 0\n");
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_fdb_mc_mac_addr_iter_get_params_t) +
                      (*key_cnt_p * sizeof(sx_fdb_mc_mac_key_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_MC_MAC_ADDR_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_mc_mac_addr_iter_get_params_t);
    cmd_head.list_size = *key_cnt_p * sizeof(sx_fdb_mc_mac_key_t);

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.key_cnt = *key_cnt_p;
    if (key_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.key), key_p, sx_fdb_mc_mac_key_t);
    }

    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), filter_p, sx_fdb_mc_mac_filter_t);
    } else {
        cmd_body.filter.filter_by_vid = SX_FDB_KEY_FILTER_FIELD_NOT_VALID;
        cmd_body.filter.filter_by_mac_addr = SX_FDB_KEY_FILTER_FIELD_NOT_VALID;
    }

    *key_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->key_cnt != 0) {
        *key_cnt_p = reply_body->key_cnt;
        if (key_list_p != NULL) {
            SX_MEM_CPY_ARRAY(key_list_p, reply_body->key_list,
                             reply_body->key_cnt, sx_fdb_mc_mac_key_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_mc_mac_addr_group_set(const sx_api_handle_t     handle,
                                             const sx_access_cmd_t     cmd,
                                             const sx_fdb_mac_key_t  * group_key_p,
                                             const sx_fdb_mac_data_t * data_p)
{
    sx_status_t                                api_status = SX_STATUS_SUCCESS;
    sx_status_t                                utils_status = SX_STATUS_SUCCESS;
    sx_api_command_head_t                      cmd_head;
    sx_api_fdb_mc_mac_addr_group_set_params_t *cmd_body_p = NULL;
    uint32_t                                   cmd_body_size = sizeof(sx_api_fdb_mc_mac_addr_group_set_params_t);
    sx_api_reply_head_t                        reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (group_key_p == NULL) {
        SX_LOG_ERR("Given group key is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (data_p == NULL) {
        SX_LOG_ERR("Given data is NULL\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /* Validity check - verify the MAC is MC and not broadcast */
    if (!is_multicast_ether_addr(group_key_p->addr.ether_addr_octet)) {
        SX_LOG_ERR("Given MAC address is not a MC address\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_MC_MAC_ADDR_GROUP_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    if (SX_CHECK_FAIL(utils_status = utils_check_msg_size(cmd_head.msg_size, SX_API_MESSAGE_SIZE_LIMIT))) {
        SX_API_LOG_EXIT();
        return utils_status;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for cmd_body_p\n", utils_status);
    if (SX_CHECK_FAIL(utils_status)) {
        SX_API_LOG_EXIT();
        return utils_status;
    }

    cmd_body_p->access_cmd = cmd;
    SX_MEM_CPY_P(&cmd_body_p->key, group_key_p);
    SX_MEM_CPY_P(&cmd_body_p->data, data_p);

    api_status = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body_p, &reply_head, NULL, 0);

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Failed to free cmd_body_p memory \n", utils_status);
    if (SX_CHECK_FAIL(utils_status)) {
        SX_API_LOG_EXIT();
        return utils_status;
    }

    SX_API_LOG_EXIT();

    return api_status;
}

sx_status_t sx_api_fdb_mc_mac_addr_group_get(const sx_api_handle_t    handle,
                                             const sx_fdb_mac_key_t * group_key_p,
                                             sx_fdb_mac_data_t      * data_p)
{
    sx_api_command_head_t                      cmd_head;
    sx_api_fdb_mc_mac_addr_group_get_params_t  cmd_body;
    sx_api_reply_head_t                        reply_head;
    sx_api_fdb_mc_mac_addr_group_get_params_t* reply_body = NULL;
    uint32_t                                   reply_body_size;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (group_key_p == NULL) {
        SX_LOG_ERR("Given group key is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (data_p == NULL) {
        SX_LOG_ERR("Given data is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Validity check - verify the MAC is MC and not broadcast */
    if (!is_multicast_ether_addr(group_key_p->addr.ether_addr_octet) ||
        is_broadcast_ether_addr(group_key_p->addr.ether_addr_octet)) {
        SX_LOG_ERR("Given MAC address is not a MC address\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    reply_body_size = sizeof(sx_api_fdb_mc_mac_addr_group_get_params_t);

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_MC_MAC_ADDR_GROUP_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_mc_mac_addr_group_get_params_t);

    SX_MEM_CPY_P(&cmd_body.key, group_key_p);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_MEM_CPY_P(data_p, &reply_body->data);

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_mc_mac_addr_group_iter_get(const sx_api_handle_t         handle,
                                                  const sx_access_cmd_t         cmd,
                                                  const sx_fdb_mac_key_t       *key_p,
                                                  const sx_fdb_mc_key_filter_t *filter_p,
                                                  sx_fdb_mac_key_t             *key_list_p,
                                                  uint32_t                     *key_cnt_p)
{
    sx_api_command_head_t                           cmd_head;
    sx_api_fdb_mc_mac_addr_group_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                             reply_head;
    sx_api_fdb_mc_mac_addr_group_iter_get_params_t *reply_body = NULL;
    uint32_t                                        reply_body_size;
    sx_status_t                                     err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (key_cnt_p == NULL) {
        SX_LOG_ERR("key_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*key_cnt_p > 0) && (key_list_p == NULL)) {
        SX_LOG_ERR("*key_cnt_p is not 0 but key_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (((cmd == SX_ACCESS_CMD_GET) || (cmd == SX_ACCESS_CMD_GETNEXT)) &&
        (*key_cnt_p > 0) &&
        (key_p == NULL)) {
        SX_LOG_ERR("key_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*key_cnt_p == 0) {
            key_list_p = NULL;
        } else {
            *key_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*key_cnt_p == 0) {
            SX_LOG_NTC("MC MAC GROUP key count is 0\n");
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_fdb_mc_mac_addr_group_iter_get_params_t) +
                      (*key_cnt_p * sizeof(sx_fdb_mac_key_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_MC_MAC_ADDR_GROUP_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_mc_mac_addr_group_iter_get_params_t);
    cmd_head.list_size = *key_cnt_p * sizeof(sx_fdb_mac_key_t);

    cmd_body.cmd = cmd;
    cmd_body.key_cnt = *key_cnt_p;
    if (key_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.key), key_p, sx_fdb_mac_key_t);
    }

    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), filter_p, sx_fdb_mc_key_filter_t);
    } else {
        cmd_body.filter.filter_by_fid = SX_FDB_KEY_FILTER_FIELD_NOT_VALID;
        cmd_body.filter.filter_by_mac_addr = SX_FDB_KEY_FILTER_FIELD_NOT_VALID;
    }

    *key_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->key_cnt != 0) {
        *key_cnt_p = reply_body->key_cnt;
        if (key_list_p != NULL) {
            SX_MEM_CPY_ARRAY(key_list_p, reply_body->key_list,
                             reply_body->key_cnt, sx_fdb_mac_key_t);
        }
    }

out:
    SX_API_LOG_EXIT();
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    return err;
}

sx_status_t sx_api_fdb_uc_flush_all_set(const sx_api_handle_t handle, const sx_swid_t swid)
{
    sx_api_command_head_t             cmd_head;
    sx_api_fdb_flush_all_set_params_t cmd_body;
    sx_api_reply_head_t               reply_head;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_FLUSH_ALL_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_flush_all_set_params_t);
    cmd_body.swid = swid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_uc_flush_port_set(const sx_api_handle_t handle, const sx_port_log_id_t log_port)
{
    sx_api_command_head_t              cmd_head;
    sx_api_fdb_flush_port_set_params_t cmd_body;
    sx_api_reply_head_t                reply_head;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_FLUSH_PORT_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_flush_port_set_params_t);

    cmd_body.log_port = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_uc_flush_fid_set(const sx_api_handle_t handle, const sx_swid_t swid, const sx_fid_t fid)
{
    sx_api_command_head_t             cmd_head;
    sx_api_fdb_flush_fid_set_params_t cmd_body;
    sx_api_reply_head_t               reply_head;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_FLUSH_FID_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_flush_fid_set_params_t);

    cmd_body.swid = swid;
    cmd_body.fid = fid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_uc_flush_port_fid_set(const sx_api_handle_t  handle,
                                             const sx_port_log_id_t log_port,
                                             const sx_fid_t         fid)
{
    sx_api_command_head_t                  cmd_head;
    sx_api_fdb_flush_port_fid_set_params_t cmd_body;
    sx_api_reply_head_t                    reply_head;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_FLUSH_PORT_FID_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_flush_port_fid_set_params_t);

    cmd_body.log_port = log_port;
    cmd_body.fid = fid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_flush_by_type_set(const sx_api_handle_t handle, const sx_flush_data_t *flush_data_p)
{
    sx_api_command_head_t                 cmd_head;
    sx_api_fdb_flush_by_type_set_params_t cmd_body;
    sx_api_reply_head_t                   reply_head;
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER()

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(flush_data_p, "flush_data_p"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_FLUSH_BY_TYPE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_flush_by_type_set_params_t);

    SX_MEM_CPY_TYPE(&cmd_body.flush_data, flush_data_p, sx_flush_data_t);

    sx_status = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return sx_status;
}


sx_status_t sx_api_fdb_mc_flush_all_set(const sx_api_handle_t handle, const sx_swid_t swid)
{
    sx_api_command_head_t             cmd_head;
    sx_api_fdb_flush_all_set_params_t cmd_body;
    sx_api_reply_head_t               reply_head;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_MC_FLUSH_ALL_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_flush_all_set_params_t);
    cmd_body.swid = swid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_mc_flush_fid_set(const sx_api_handle_t handle, const sx_swid_t swid, const sx_fid_t fid)
{
    sx_api_command_head_t             cmd_head;
    sx_api_fdb_flush_fid_set_params_t cmd_body;
    sx_api_reply_head_t               reply_head;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_MC_FLUSH_FID_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_flush_fid_set_params_t);
    cmd_body.swid = swid;
    cmd_body.fid = fid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_fid_vlan_member_set(const sx_api_handle_t handle,
                                           const sx_access_cmd_t cmd,
                                           const sx_swid_t       swid,
                                           const sx_fid_t        fid,
                                           const sx_vid_t        vid)
{
    sx_api_command_head_t                   cmd_head;
    sx_api_fdb_fid_vlan_member_set_params_t cmd_body;
    sx_api_reply_head_t                     reply_head;
    sx_status_t                             err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_FID_VLAN_MEMBER_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_fid_vlan_member_set_params_t);

    cmd_body.swid = swid;
    cmd_body.fid = fid;
    cmd_body.access_cmd = cmd;
    cmd_body.vid = vid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_global_params_set(const sx_api_handle_t     handle,
                                         const sx_swid_t           swid,
                                         const sx_fdb_learn_ctrl_t learn_ctrl)
{
    sx_api_fdb_swid_global_learning_mode_set_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_SET,
        .swid = swid
    };
    uint32_t                                          cmd_size =
        sizeof(sx_api_fdb_swid_global_learning_mode_get_params_t);
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (!((learn_ctrl.svl_mode == SX_FDB_SHARED_VLAN_LEARNING) ||
          (learn_ctrl.svl_mode == SX_FDB_INDEPENDENT_VLAN_LEARNING))) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    if (!((learn_ctrl.roam_mode == SX_FDB_LEARN_ROAM_MODE_DONT_LEARN) ||
          (learn_ctrl.roam_mode == SX_FDB_LEARN_ROAM_MODE_LEARN))) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body.svl_mode = learn_ctrl.svl_mode;
    cmd_body.roaming_enable = learn_ctrl.roam_mode;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FDB_GLOBAL_PARAMS_SET_E, (uint8_t*)&cmd_body, cmd_size);

out:

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_global_params_get(const sx_api_handle_t handle,
                                         const sx_swid_t       swid,
                                         sx_fdb_learn_ctrl_t  *learn_ctrl_p)
{
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_api_fdb_swid_global_learning_mode_get_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_GET,
        .swid = swid
    };
    uint32_t                                          cmd_size =
        sizeof(sx_api_fdb_swid_global_learning_mode_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(learn_ctrl_p, "Learning Control"))) {
        SX_API_LOG_EXIT();
        return err;
    }
    /* O/W: */
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FDB_GLOBAL_PARAMS_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);

    learn_ctrl_p->svl_mode = cmd_body.svl_mode;
    learn_ctrl_p->roam_mode = cmd_body.roaming_enable;

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_learn_mode_set(const sx_api_handle_t     handle,
                                      const sx_swid_t           swid,
                                      const sx_fdb_learn_mode_t learn_mode)
{
    sx_api_command_head_t              cmd_head;
    sx_api_fdb_learn_mode_set_params_t cmd_body;
    sx_api_reply_head_t                reply_head;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    /* Check params range */

    if (!SX_FDB_LEARN_MODE_CHECK_RANGE(learn_mode)) {
        SX_LOG_ERR("learn_mode (%u) range error\n", learn_mode);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_FDB_LEARN_MODE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_learn_mode_set_params_t);

    cmd_body.swid = swid;
    cmd_body.learn_mode = learn_mode;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_learn_mode_get(const sx_api_handle_t handle,
                                      const sx_swid_t       swid,
                                      sx_fdb_learn_mode_t  *learn_mode_p)
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_learn_mode_get_params_t cmd_body = {
        .swid = swid,
    };
    uint32_t                           cmd_size = sizeof(sx_api_fdb_learn_mode_get_params_t);

    SX_API_LOG_ENTER();


    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(learn_mode_p, "learn mode"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    sx_status =
        sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FDB_LEARN_MODE_GET_E, (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(sx_status)) {
        *learn_mode_p = cmd_body.learn_mode;
    }

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_fid_learn_mode_set(const sx_api_handle_t     handle,
                                          const sx_swid_t           swid,
                                          const sx_fid_t            fid,
                                          const sx_fdb_learn_mode_t learn_mode)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_fid_learn_mode_set_params_t cmd_body = {
        .swid = swid,
        .fid = fid,
        .learn_mode = learn_mode
    };

    SX_API_LOG_ENTER();

    if (!SX_FDB_LEARN_MODE_CHECK_RANGE(learn_mode)) {
        SX_LOG_ERR("FDB: learn_mode (%u) range error\n", learn_mode);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    uint32_t cmd_size = sizeof(sx_api_fdb_fid_learn_mode_set_params_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_FID_LEARN_MODE_SET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_fid_learn_mode_get(const sx_api_handle_t handle,
                                          const sx_swid_t       swid,
                                          const sx_fid_t        fid,
                                          sx_fdb_learn_mode_t  *learn_mode_p)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_fid_learn_mode_get_params_t cmd_body = {
        .swid = swid,
        .fid = fid
    };
    uint32_t                               cmd_size = sizeof(sx_api_fdb_fid_learn_mode_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(learn_mode_p, "fid learn mode"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_FID_LEARN_MODE_GET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    if (SX_CHECK_PASS(sx_status)) {
        *learn_mode_p = cmd_body.learn_mode;
    }

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_port_learn_mode_set(const sx_api_handle_t     handle,
                                           const sx_port_log_id_t    log_port,
                                           const sx_fdb_learn_mode_t learn_mode)
{
    sx_status_t                             sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_port_learn_mode_set_params_t cmd_body = {
        .log_port = log_port,
        .learn_mode = learn_mode
    };

    SX_API_LOG_ENTER();

    if (!SX_FDB_LEARN_MODE_CHECK_RANGE(learn_mode)) {
        SX_LOG_ERR("FDB: learn_mode (%u) range error\n", learn_mode);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    uint32_t cmd_size = sizeof(sx_api_fdb_port_learn_mode_set_params_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_PORT_LEARN_MODE_SET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_port_learn_mode_get(const sx_api_handle_t  handle,
                                           const sx_port_log_id_t log_port,
                                           sx_fdb_learn_mode_t   *learn_mode_p)
{
    sx_status_t                             sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_port_learn_mode_get_params_t cmd_body = { .log_port = log_port };
    uint32_t                                cmd_size = sizeof(sx_api_fdb_port_learn_mode_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(learn_mode_p, "PORT learn mode"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_PORT_LEARN_MODE_GET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    if (SX_CHECK_PASS(sx_status)) {
        *learn_mode_p = cmd_body.learn_mode;
    }

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_notify_params_set(const sx_api_handle_t         handle,
                                         const sx_swid_t               swid,
                                         const sx_fdb_notify_params_t *notify_params_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_fdb_notify_set_params_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (NULL == notify_params_p) {
        SX_LOG_ERR("FDB: NULL param (notify_params_p)\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (notify_params_p->size_threshold < SX_FDB_NOTIFY_SIZE_MIN) {
        SX_LOG_ERR("FDB: size_threshold (%u) range error, valid range: (%u - %u)\n",
                   notify_params_p->size_threshold, SX_FDB_NOTIFY_SIZE_MIN, SX_FDB_NOTIFY_SIZE_MAX);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    if (0 == notify_params_p->interval_units) {
        SX_LOG_ERR("FDB: interval_units (%u) should not be zero\n", notify_params_p->interval_units);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_NOTIFY_PARAMS_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    cmd_body.swid = swid;
    SX_MEM_CPY_TYPE(&cmd_body.notify_params, notify_params_p, sx_fdb_notify_params_t);

    /* Best effort */
    cmd_body.notify_params.size_threshold = MIN(notify_params_p->size_threshold,
                                                SX_FDB_NOTIFY_SIZE_MAX);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head,
                                        NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_notify_params_get(const sx_api_handle_t   handle,
                                         const sx_swid_t         swid,
                                         sx_fdb_notify_params_t *notify_params_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_fdb_notify_get_params_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (NULL == notify_params_p) {
        SX_LOG_ERR("FDB: NULL param (notify_params_p)\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_NOTIFY_PARAMS_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);

    cmd_body.swid = swid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)&cmd_body, sizeof(cmd_body));

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY_TYPE(notify_params_p, &cmd_body.notify_params, sx_fdb_notify_params_t);
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_flood_control_set(const sx_api_handle_t          handle,
                                         const sx_access_cmd_t          cmd,
                                         const sx_swid_t                swid,
                                         const sx_fid_t                 fid,
                                         sx_flood_control_type_t        type,
                                         const uint16_t                 ports_count,
                                         const sx_port_log_id_t * const ports_list)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_status_t                         free_err = SX_STATUS_SUCCESS;
    sx_api_fdb_flood_control_params_t * cmd_body_p = NULL;
    uint32_t                            cmd_size = sizeof(sx_api_fdb_flood_control_params_t);

    SX_API_LOG_ENTER();
    if (cmd != SX_ACCESS_CMD_DELETE_ALL_PORTS) {
        if (ports_list == NULL) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
    } else {
        if ((ports_list != NULL) || (ports_count != 0)) {
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    /* add the number of ports to the cmd_size*/
    cmd_size += ports_count * sizeof(sx_port_log_id_t);

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->fid = fid;
    cmd_body_p->type = type;
    cmd_body_p->swid = swid;
    cmd_body_p->ports_count = ports_count;
    SX_MEM_CPY_ARRAY(cmd_body_p->log_port_list, ports_list, ports_count, sx_port_log_id_t);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_FDB_FLOOD_CONTROL_SET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_size);

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free\n", free_err);
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_flood_control_get(const sx_api_handle_t    handle,
                                         const sx_swid_t          swid,
                                         const sx_fid_t           fid,
                                         sx_flood_control_type_t  type,
                                         uint16_t * const         ports_count,
                                         sx_port_log_id_t * const ports_list)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_status_t                         free_err = SX_STATUS_SUCCESS;
    sx_api_fdb_flood_control_params_t * cmd_body_p = NULL;
    uint32_t                            cmd_size = sizeof(sx_api_fdb_flood_control_params_t);

    SX_API_LOG_ENTER();

    if (ports_count == NULL) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((ports_list == NULL) && (*ports_count != 0)) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    /* add the number of ports to the cmd_size*/
    cmd_size += (*ports_count) * sizeof(sx_port_log_id_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", err);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    cmd_body_p->ports_count = *ports_count;
    cmd_body_p->swid = swid;
    cmd_body_p->fid = fid;
    cmd_body_p->type = type;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_FDB_FLOOD_CONTROL_GET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *ports_count = cmd_body_p->ports_count;
    if (NULL != ports_list) {
        SX_MEM_CPY_ARRAY(ports_list, cmd_body_p->log_port_list, *ports_count, sx_port_log_id_t);
    }
out:
    if (NULL != cmd_body_p) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free\n", free_err);
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_flood_set(const sx_api_handle_t      handle,
                                 const sx_access_cmd_t      cmd,
                                 const sx_swid_t            swid,
                                 const sx_fid_t             fid,
                                 const sx_mc_container_id_t flood_vector)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_flood_set_params_t cmd_body = {
        .cmd = cmd,
        .swid = swid,
        .fid = fid,
        .flood_vector = flood_vector
    };

    SX_API_LOG_ENTER();

    uint32_t cmd_size = sizeof(sx_api_fdb_flood_set_params_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_FLOOD_SET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_flood_get(const sx_api_handle_t handle,
                                 const sx_swid_t       swid,
                                 const sx_fid_t        fid,
                                 sx_mc_container_id_t *flood_vector)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_flood_get_params_t cmd_body = {
        .swid = swid,
        .fid = fid,
        .flood_vector = 0
    };
    uint32_t                      cmd_size = sizeof(sx_api_fdb_flood_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(flood_vector, "FDB flood vector"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_FLOOD_GET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    if (SX_CHECK_PASS(sx_status)) {
        *flood_vector = cmd_body.flood_vector;
    }

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_src_miss_protect_set(const sx_api_handle_t  handle,
                                            const sx_port_log_id_t log_port,
                                            const boolean_t        enable)
{
    sx_status_t                          sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_miss_protect_set_params_t cmd_body = {
        .log_port = log_port,
        .enable = enable
    };

    SX_API_LOG_ENTER();

    uint32_t cmd_size = sizeof(sx_api_fdb_miss_protect_set_params_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_SRC_MISS_PROTECT_SET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_src_miss_protect_get(const sx_api_handle_t  handle,
                                            const sx_port_log_id_t log_port,
                                            boolean_t             *enable_p)
{
    sx_status_t                          sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_miss_protect_get_params_t cmd_body = {
        .log_port = log_port
    };
    uint32_t                             cmd_size = sizeof(sx_api_fdb_miss_protect_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(enable_p, "PORT FDB miss protect"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_SRC_MISS_PROTECT_GET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    if (SX_CHECK_PASS(sx_status)) {
        *enable_p = cmd_body.enable;
    }

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_src_miss_protect_drop_cntr_set(const sx_api_handle_t handle, const sx_access_cmd_t cmd)
{
    sx_status_t                                   sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_miss_protect_drop_cnt_set_params_t cmd_body = {
        .access_cmd = cmd
    };

    SX_API_LOG_ENTER();

    uint32_t cmd_size = sizeof(sx_api_fdb_miss_protect_drop_cnt_set_params_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_SRC_MISS_PROTECT_DROP_CNTR_SET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    SX_API_LOG_EXIT();

    return sx_status;
}


sx_status_t sx_api_fdb_src_miss_protect_drop_cntr_get(const sx_api_handle_t handle,
                                                      const sx_access_cmd_t cmd,
                                                      uint64_t             *dropped_pkts_cntr)
{
    sx_status_t                                   sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_miss_protect_drop_cnt_get_params_t cmd_body = {
        .access_cmd = cmd,
        .dropped_pkts_cntr = 0
    };

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(dropped_pkts_cntr, "PORT FDB miss protect"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    uint32_t cmd_size = sizeof(sx_api_fdb_miss_protect_drop_cnt_get_params_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_SRC_MISS_PROTECT_DROP_CNTR_GET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);
    if (SX_CHECK_PASS(sx_status)) {
        *dropped_pkts_cntr = cmd_body.dropped_pkts_cntr;
    }

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_igmpv3_state_set(const sx_api_handle_t       handle,
                                        const sx_access_cmd_t       cmd,
                                        const sx_fid_t              fid,
                                        const sx_fdb_igmpv3_state_t fdb_igmpv3_snooping_state)
{
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_igmp_v3_state_set_params_t cmd_body = {
        .cmd = cmd,
        .fid = fid,
        .state = fdb_igmpv3_snooping_state
    };

    SX_API_LOG_ENTER();

    uint32_t cmd_size = sizeof(sx_api_fdb_igmp_v3_state_set_params_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_IGMPV3_STATE_SET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_igmpv3_state_get(const sx_api_handle_t  handle,
                                        const sx_access_cmd_t  cmd,
                                        const sx_fid_t         fid,
                                        sx_fdb_igmpv3_state_t* fdb_igmpv3_snooping_state)
{
    sx_status_t                           sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_igmp_v3_state_get_params_t cmd_body = {
        .cmd = cmd,
        .fid = fid
    };

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(fdb_igmpv3_snooping_state, "IGMPV3 Enable State"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    uint32_t cmd_size = sizeof(sx_api_fdb_igmp_v3_state_get_params_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_IGMPV3_STATE_GET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);
    if (SX_CHECK_PASS(sx_status)) {
        *fdb_igmpv3_snooping_state = cmd_body.state;
    }

    SX_API_LOG_EXIT();

    return sx_status;
}


sx_status_t sx_api_fdb_mc_ip_addr_group_set(const sx_api_handle_t        handle,
                                            const sx_access_cmd_t        cmd,
                                            const sx_fdb_mc_ip_key_t   * mc_fdb_mc_ip_key,
                                            const sx_fdb_mc_ip_action_t* fdb_mc_ip_action)
{
    sx_status_t                              sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_igmp_v3_ip_group_set_params_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (mc_fdb_mc_ip_key == NULL) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("mc_fdb_mc_ip_key is NULL.\n");
        goto out;
    }
    if (fdb_mc_ip_action == NULL) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("fdb_mc_ip_action is NULL.\n");
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.mc_fdb_mc_ip_key, *mc_fdb_mc_ip_key);
    SX_MEM_CPY(cmd_body.fdb_mc_ip_action, *fdb_mc_ip_action);


    uint32_t cmd_size = sizeof(sx_api_fdb_igmp_v3_ip_group_set_params_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_MC_IP_ADDR_GROUP_SET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    SX_API_LOG_EXIT();

out:

    SX_API_LOG_EXIT();
    return sx_status;
}


sx_status_t sx_api_fdb_mc_ip_addr_group_get(const sx_api_handle_t     handle,
                                            const sx_fdb_mc_ip_key_t* mc_fdb_mc_ip_key,
                                            sx_fdb_mc_ip_action_t   * fdb_mc_ip_action_p)
{
    sx_status_t                              sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_igmp_v3_ip_group_get_params_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(fdb_mc_ip_action_p, "IGMPV3 action"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }
    SX_MEM_CPY(cmd_body.mc_fdb_mc_ip_key, *mc_fdb_mc_ip_key);


    uint32_t cmd_size = sizeof(sx_api_fdb_igmp_v3_ip_group_get_params_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_MC_IP_ADDR_GROUP_GET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);

    if (SX_CHECK_PASS(sx_status)) {
        SX_MEM_CPY(*fdb_mc_ip_action_p, cmd_body.fdb_mc_ip_action);
    }

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_mc_ip_addr_group_counter_bind_set(const sx_api_handle_t      handle,
                                                         const sx_access_cmd_t      cmd,
                                                         const sx_fdb_mc_ip_key_t  *key_p,
                                                         const sx_flow_counter_id_t counter_id)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_api_command_mc_group_counter_bind_set_t cmd_body;
    uint32_t                                   cmd_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (SX_CHECK_FAIL(err = utils_check_pointer(key_p, "key_p"))) {
        SX_API_LOG_EXIT();
        return err;
    }

    cmd_body.cmd = cmd;
    cmd_body.counter_id = counter_id;
    SX_MEM_CPY(cmd_body.mc_fdb_mc_ip_key, *key_p);

    cmd_size = sizeof(sx_api_command_mc_group_counter_bind_set_t);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MC_IP_ADDR_GROUP_COUNTER_BIND_SET_E,
                                      (uint8_t*)&cmd_body,
                                      cmd_size);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_fdb_mc_ip_addr_group_counter_bind_get(const sx_api_handle_t     handle,
                                                         const sx_fdb_mc_ip_key_t *key_p,
                                                         sx_flow_counter_id_t     *counter_id_p)
{
    sx_status_t                                sx_status = SX_STATUS_SUCCESS;
    sx_api_command_mc_group_counter_bind_get_t cmd_body;
    uint32_t                                   cmd_size = 0;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(key_p, "key_p"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(counter_id_p, "counter_id_p"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    SX_MEM_CPY(cmd_body.mc_fdb_mc_ip_key, *key_p);
    cmd_size = sizeof(sx_api_command_mc_group_counter_bind_get_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_MC_IP_ADDR_GROUP_COUNTER_BIND_GET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);
    if (SX_CHECK_PASS(sx_status)) {
        *counter_id_p = cmd_body.counter_id;
    }

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_unreg_mc_flood_mode_set(const sx_api_handle_t           handle,
                                               const sx_swid_t                 swid,
                                               const sx_vid_t                  vid,
                                               const sx_fdb_unreg_flood_mode_t urmc_flood_mode)
{
    sx_status_t                             sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_unreg_mc_flood_mode_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_SET,
        .swid = swid,
        .vid = vid
    };
    uint32_t                                cmd_size = sizeof(sx_api_fdb_unreg_mc_flood_mode_params_t);

    SX_API_LOG_ENTER();

    cmd_body.urmc_flood_mode = urmc_flood_mode;

    sx_status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FDB_UNREG_MC_FLOOD_MODE_SET_E,
                                            (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_unreg_mc_flood_mode_get(const sx_api_handle_t      handle,
                                               const sx_swid_t            swid,
                                               const sx_vid_t             vid,
                                               sx_fdb_unreg_flood_mode_t *urmc_flood_mode_p)
{
    sx_status_t                             rc = SX_STATUS_SUCCESS;
    sx_status_t                             api_rc = SX_STATUS_SUCCESS;
    sx_api_fdb_unreg_mc_flood_mode_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_GET,
        .swid = swid,
        .vid = vid
    };
    uint32_t                                cmd_size = sizeof(sx_api_fdb_unreg_mc_flood_mode_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(urmc_flood_mode_p, "URMC mode"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    api_rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FDB_UNREG_MC_FLOOD_MODE_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *urmc_flood_mode_p = cmd_body.urmc_flood_mode;
    }

    SX_API_LOG_EXIT();

    return api_rc;
}

sx_status_t sx_api_fdb_unreg_mc_flood_ports_set(const sx_api_handle_t   handle,
                                                const sx_swid_t         swid,
                                                const sx_vid_t          vid,
                                                const sx_port_log_id_t *log_port_list_p,
                                                const uint32_t          port_cnt)
{
    sx_status_t                               api_status = SX_STATUS_SUCCESS;
    sx_status_t                               utils_status = SX_STATUS_SUCCESS;
    sx_api_command_head_t                     cmd_head;
    sx_api_fdb_unreg_mc_flood_ports_params_t *cmd_body_p = NULL;
    uint32_t                                  cmd_body_size = sizeof(*cmd_body_p);
    sx_api_reply_head_t                       reply_head;

    SX_API_LOG_ENTER();


    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);
    if ((log_port_list_p == NULL) && (port_cnt != 0)) {
        utils_status = SX_STATUS_PARAM_NULL;
        SX_API_LOG_EXIT();
        return utils_status;
    }
    if (port_cnt > 0) {
        cmd_body_size += (port_cnt * sizeof(sx_port_log_id_t));
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_UNREG_MC_FLOOD_PORTS_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    if (SX_CHECK_FAIL(utils_status = utils_check_msg_size(cmd_head.msg_size, SX_API_MESSAGE_SIZE_LIMIT))) {
        SX_API_LOG_EXIT();
        return utils_status;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for cmd_body_p\n", utils_status);
    if (SX_CHECK_FAIL(utils_status)) {
        SX_API_LOG_EXIT();
        return utils_status;
    }

    cmd_body_p->swid = swid;
    cmd_body_p->vid = vid;
    cmd_body_p->port_num = port_cnt;

    if (log_port_list_p && (port_cnt != 0)) {
        SX_MEM_CPY_BUF(cmd_body_p->log_port_list, log_port_list_p, port_cnt * sizeof(sx_port_log_id_t));
    }

    api_status = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body_p, &reply_head, NULL, 0);

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Failed to free cmd_body_p memory \n", utils_status);
    if (SX_CHECK_FAIL(utils_status)) {
        SX_API_LOG_EXIT();
        return utils_status;
    }

    SX_API_LOG_EXIT();

    return api_status;
}

sx_status_t sx_api_fdb_unreg_mc_flood_ports_get(const sx_api_handle_t handle,
                                                const sx_swid_t       swid,
                                                const sx_vid_t        vid,
                                                sx_port_log_id_t     *log_port_list_p,
                                                uint32_t             *port_cnt_p)
{
    sx_api_command_head_t                     cmd_head;
    sx_api_fdb_unreg_mc_flood_ports_params_t  cmd_body;
    sx_api_reply_head_t                       reply_head;
    sx_api_fdb_unreg_mc_flood_ports_params_t* reply_body = NULL;
    uint32_t                                  reply_body_size;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    if (port_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("port_cnt_p is NULL.\n");
        goto out;
    }
    if (log_port_list_p == NULL) {
        *port_cnt_p = 0;
    }
    if (*port_cnt_p == 0) {
        log_port_list_p = NULL;
    }

    reply_body_size = sizeof(sx_api_fdb_unreg_mc_flood_ports_params_t) +
                      ((*port_cnt_p) * sizeof(sx_port_id_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_UNREG_MC_FLOOD_PORTS_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_unreg_mc_flood_ports_params_t);
    cmd_head.list_size = (*port_cnt_p) * sizeof(sx_port_id_t);

    cmd_body.swid = swid;
    cmd_body.vid = vid;
    cmd_body.port_num = *port_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    port_cnt_p[0] = reply_body->port_num;
    if (log_port_list_p != NULL) {
        SX_MEM_CPY_ARRAY(log_port_list_p, reply_body->log_port_list,
                         *port_cnt_p, sx_port_id_t);
    }

out:
    utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_unreg_mc_flood_mode_ext_set(const sx_api_handle_t               handle,
                                                   const sx_access_cmd_t               access_cmd,
                                                   const sx_fdb_unreg_mc_flood_key_t * flood_key_p,
                                                   const sx_fdb_unreg_mc_flood_attr_t* flood_attr_p)
{
    sx_status_t                                 sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_unreg_mc_flood_mode_ext_params_t cmd_body = {
        .cmd = access_cmd,
    };
    uint32_t                                    cmd_size = sizeof(sx_api_fdb_unreg_mc_flood_mode_ext_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(flood_key_p, "flood_key_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(flood_attr_p, "flood_attr_p"))) {
        goto out;
    }

    cmd_body.flood_key = *flood_key_p;
    cmd_body.flood_attr = *flood_attr_p;

    sx_status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FDB_UNREG_MC_FLOOD_MODE_EXT_SET_E,
                                            (uint8_t*)&cmd_body, cmd_size);


out:
    return M_UTILS_SX_LOG_EXIT(sx_status);
}

sx_status_t sx_api_fdb_unreg_mc_flood_mode_ext_get(const sx_api_handle_t               handle,
                                                   const sx_fdb_unreg_mc_flood_key_t * flood_key_p,
                                                   sx_fdb_unreg_mc_flood_attr_t* const flood_attr_p)
{
    sx_status_t                                 sx_status = SX_STATUS_SUCCESS;
    sx_api_fdb_unreg_mc_flood_mode_ext_params_t cmd_body = {
        .cmd = SX_ACCESS_CMD_GET,
    };
    uint32_t                                    cmd_size = sizeof(sx_api_fdb_unreg_mc_flood_mode_ext_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(flood_key_p, "flood_key_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(flood_attr_p, "flood_attr_p"))) {
        goto out;
    }

    cmd_body.flood_key = *flood_key_p;
    sx_status = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FDB_UNREG_MC_FLOOD_MODE_EXT_GET_E,
                                            (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(sx_status)) {
        memcpy(flood_attr_p, &cmd_body.flood_attr, sizeof(*flood_attr_p));
    }

out:
    return M_UTILS_SX_LOG_EXIT(sx_status);
}


sx_status_t sx_api_fdb_mc_ip_addr_group_activity_get(const sx_api_handle_t     handle,
                                                     const sx_access_cmd_t     cmd,
                                                     const sx_fdb_mc_ip_key_t *key_p,
                                                     boolean_t                *activity_p)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    sx_api_command_mc_group_activity_get_t cmd_body;
    uint32_t                               cmd_size = 0;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(key_p, "key_p"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(activity_p, "activity_p"))) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.mc_fdb_mc_ip_key, *key_p);
    cmd_size = sizeof(sx_api_command_mc_group_activity_get_t);

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_FDB_MC_IP_ADDR_GROUP_ACTIVITY_GET_E,
                                            (uint8_t*)&cmd_body,
                                            cmd_size);
    if (SX_CHECK_PASS(sx_status)) {
        *activity_p = cmd_body.activity;
    }

    SX_API_LOG_EXIT();

    return sx_status;
}

sx_status_t sx_api_fdb_mc_ip_addr_group_activity_notify(const sx_api_handle_t        handle,
                                                        const sx_access_cmd_t        cmd,
                                                        const sx_fdb_mc_ip_filter_t *filter_p)
{
    sx_api_fdb_mc_ip_addr_activity_notify_params_t cmd_body;
    sx_status_t                                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (filter_p != NULL) {
        cmd_body.filter.filter_by_vid = filter_p->filter_by_vid;
        cmd_body.filter.vid = filter_p->vid;
        cmd_body.filter.filter_by_group = filter_p->filter_by_group;
        cmd_body.filter.group = filter_p->group;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("Unsupported command %s given\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FDB_MC_IP_ADDR_GROUP_ACTIVITY_NOTIFY_E,
                                      (uint8_t*)(&cmd_body), sizeof(cmd_body));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fdb_uc_local_protect_set(const sx_api_handle_t                  handle,
                                            const sx_api_fdb_uc_protection_key_t  *protection_key_p,
                                            const sx_api_fdb_uc_protection_data_t *protection_data_p)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_fdb_uc_local_protect_set_params_t cmd_body;
    sx_api_command_head_t                    cmd_head;
    sx_api_reply_head_t                      reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(protection_key_p, "protection_key_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(err = utils_check_pointer(protection_data_p, "protection_data_p"))) {
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_FDB_UC_LOCAL_PROTECT_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_fdb_uc_local_protect_set_params_t);

    SX_MEM_CPY(cmd_body.protection_key, *protection_key_p);
    SX_MEM_CPY(cmd_body.protection_data, *protection_data_p);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}
