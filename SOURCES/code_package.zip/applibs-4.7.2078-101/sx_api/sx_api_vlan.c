/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_vlan.h>
#include "sx_api_internal.h"

#undef __MODULE__
#define __MODULE__ SX_API_VLAN

#define SDK_COMPILE_TIME_ASSERT(EXPRESSION) \
    switch (0) {                            \
    case 0:                                 \
    case (EXPRESSION):                      \
        ; }

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

sx_status_t sx_api_vlan_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                const sx_verbosity_level_t      module_verbosity_level,
                                                const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_VLAN_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                sx_verbosity_level_t           *module_verbosity_level_p,
                                                sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_VLAN_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_ports_set(const sx_api_handle_t  handle,
                                  const sx_access_cmd_t  cmd,
                                  const sx_swid_t        swid,
                                  const sx_vid_t         vid,
                                  const sx_vlan_ports_t *vlan_port_list_p,
                                  const uint32_t         port_cnt)
{
    sx_api_command_head_t        cmd_head;
    sx_api_command_vlan_ports_t *cmd_body_p = NULL;
    sx_api_reply_head_t          reply_head;
    uint32_t                     buff_size, i;
    uint8_t                      result = 0;
    sx_status_t                  err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);


    if (SX_ACCESS_CMD_DELETE_ALL == cmd) {
        buff_size = sizeof(sx_api_command_vlan_ports_t);
    } else if (!vlan_port_list_p) {
        SX_LOG_ERR("vlan_port_list_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    } else {
        for (i = 0; i < port_cnt; i++) {
            if ((vlan_port_list_p[i].is_untagged != SX_TAGGED_MEMBER) &&
                (vlan_port_list_p[i].is_untagged != SX_UNTAGGED_MEMBER)) {
                SX_LOG_ERR("Invalid input tag param for port: %u\n", vlan_port_list_p[i].log_port);
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
            if (SX_VLAN_PASS_STATE_CHECK_RANGE(vlan_port_list_p[i].pass_state) == FALSE) {
                SX_LOG_ERR("Invalid input pass state param for port: %u\n", vlan_port_list_p[i].log_port);
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
        }
/*Assign the buffer size for access commands else than delete all*/
        buff_size = sizeof(sx_api_command_vlan_ports_t) +
                    sizeof(sx_vlan_ports_t) * port_cnt;
    }

    cmd_head.opcode = SX_API_INT_CMD_VLAN_PORTS_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + buff_size;

    if (buff_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, buff_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", result);
    if (SX_CHECK_FAIL(result)) {
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_body_p->access_cmd = cmd;
    cmd_body_p->swid = swid;
    cmd_body_p->vid = vid;

    if (SX_ACCESS_CMD_DELETE_ALL != cmd) {
        memcpy(&(cmd_body_p->vlan_port_list_p),
               vlan_port_list_p,
               sizeof(sx_vlan_ports_t) * port_cnt);
        cmd_body_p->port_num = port_cnt;
    } else {
        cmd_body_p->port_num = 0;     /*Delete all*/
    }
    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body_p,
                                        &reply_head, NULL, 0);

out:
    if (cmd_body_p) {
        /* free allocated memory */
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Failed to free cmd_body_p memory\n", result);
        if (SX_CHECK_FAIL(result)) {
            err = SX_STATUS_NO_MEMORY;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_vlan_ports_get(const sx_api_handle_t handle,
                                  const sx_swid_t       swid,
                                  const sx_vid_t        vid,
                                  sx_vlan_ports_t      *vlan_port_list_p,
                                  uint32_t             *port_cnt_p)
{
    sx_api_command_head_t           cmd_head;
    sx_api_command_vlan_ports_get_t cmd_body;
    sx_api_reply_head_t             reply_head;
    sx_status_t                     err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (!port_cnt_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("port_cnt_p is NULL.\n");
        goto out;
    }

    if (!vlan_port_list_p) {
        *port_cnt_p = 0;
    }
    if (*port_cnt_p == 0) { /* only the port count is needed */
        vlan_port_list_p = NULL;
    }
    cmd_head.opcode = SX_API_INT_CMD_VLAN_PORTS_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_command_vlan_ports_get_t);

    cmd_body.swid = swid;
    cmd_body.vid = vid;
    cmd_body.port_num = *port_cnt_p;
    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)vlan_port_list_p,
                                        (*port_cnt_p) * sizeof(sx_vlan_ports_t));

    if (SX_STATUS_SUCCESS == err) {
        *port_cnt_p = reply_head.list_size;
    }

out:

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_port_multi_vlan_set(const sx_api_handle_t  handle,
                                            const sx_access_cmd_t  cmd,
                                            const sx_port_log_id_t log_port,
                                            const sx_port_vlans_t *vlan_list_p,
                                            const uint32_t         vlan_cnt)
{
    sx_api_command_head_t              cmd_head;
    sx_api_command_port_multi_vlans_t *cmd_body_p = NULL;
    sx_api_reply_head_t                reply_head;
    uint32_t                           buff_size;
    uint8_t                            result = 0;
    sx_status_t                        status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if ((SX_ACCESS_CMD_ADD != cmd) && (SX_ACCESS_CMD_DELETE != cmd)) {
        status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        goto out;
    }

    if (NULL == vlan_list_p) {
        status = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("vlan_list_p is NULL (%s)\n", sx_status_str(status));
        goto out;
    }

    if (0 == vlan_cnt) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("vlan_cnt must be greater than zero (%s)\n", sx_status_str(status));
        goto out;
    }

    buff_size = sizeof(sx_api_command_port_multi_vlans_t) +
                sizeof(sx_port_vlans_t) * vlan_cnt;
    cmd_head.opcode = SX_API_INT_CMD_MULTI_VLAN_PORTS_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + buff_size;

    if (buff_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, buff_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", result);
    if (SX_CHECK_FAIL(result)) {
        status = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_body_p->access_cmd = cmd;
    cmd_body_p->log_port = log_port;
    cmd_body_p->vlan_num = vlan_cnt;

    memcpy(&(cmd_body_p->vlan_list_p), vlan_list_p, sizeof(sx_port_vlans_t) * vlan_cnt);

    status = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body_p,
                                           &reply_head, NULL, 0);

out:
    if (cmd_body_p) {
        /* free allocated memory */
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Failed to free cmd_body_p memory\n", result);
        if (SX_CHECK_FAIL(result)) {
            status = SX_STATUS_NO_MEMORY;
        }
    }

    SX_API_LOG_EXIT();

    return status;
}

sx_status_t sx_api_vlan_port_prio_tagged_set(const sx_api_handle_t          handle,
                                             const sx_port_log_id_t         log_port,
                                             const sx_untagged_prio_state_t untagged_prio_state)
{
    sx_api_command_head_t                      cmd_head;
    sx_api_command_vlan_port_prio_tagged_set_t cmd_body;
    sx_api_reply_head_t                        reply_head;
    uint32_t                                   buff_size;
    sx_status_t                                status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (SX_MAX_UNTAGGED_PRIO_STATE <= untagged_prio_state) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("untagged_prio_state (%u) exceeds limit (%u).\n", untagged_prio_state, SX_MAX_UNTAGGED_PRIO_STATE);
        goto out;
    }


    buff_size = sizeof(sx_api_command_vlan_port_prio_tagged_set_t);
    cmd_head.opcode = SX_API_INT_CMD_VLAN_PORT_PRIO_TAGGED_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + buff_size;

    cmd_body.log_port = log_port;
    cmd_body.untagged_prio_state = untagged_prio_state;

    status = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                           &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_vlan_port_prio_tagged_get(const sx_api_handle_t     handle,
                                             const sx_port_log_id_t    log_port,
                                             sx_untagged_prio_state_t *untagged_prio_state_p)
{
    sx_api_command_vlan_port_prio_tagged_get_t cmd_body;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (untagged_prio_state_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("untagged_prio_state_p is NULL.\n");
        goto out;
    }

    cmd_body.log_port = log_port;


    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_VLAN_PORT_PRIO_TAGGED_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_command_vlan_port_prio_tagged_get_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *untagged_prio_state_p = cmd_body.untagged_prio_state;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_port_ingr_filter_set(const sx_api_handle_t       handle,
                                             const sx_port_log_id_t      log_port,
                                             const sx_ingr_filter_mode_t ingress_filter_state)
{
    sx_api_command_head_t                   cmd_head;
    sx_api_command_vlan_ingr_filter_ports_t cmd_body;
    sx_api_reply_head_t                     reply_head;
    sx_status_t                             err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_VLAN_PORT_INGR_FILTER_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_command_vlan_ingr_filter_ports_t);
    cmd_body.log_port = log_port;

    switch (ingress_filter_state) {
    case SX_INGR_FILTER_ENABLE:
        cmd_body.access_cmd = SX_ACCESS_CMD_ENABLE;
        break;

    case SX_INGR_FILTER_DISABLE:
        cmd_body.access_cmd = SX_ACCESS_CMD_DISABLE;
        break;
    }
    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);


    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_port_ingr_filter_get(const sx_api_handle_t  handle,
                                             const sx_port_log_id_t log_port,
                                             sx_ingr_filter_mode_t *ingress_filter_state_p)
{
    sx_api_command_vlan_ingr_filter_ports_t cmd_body;
    sx_status_t                             err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (ingress_filter_state_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("ingress_filter_state_p is NULL.\n");
        goto out;
    }

    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_VLAN_PORT_INGR_FILTER_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_command_vlan_ingr_filter_ports_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *ingress_filter_state_p = cmd_body.ingress_filter_state;

out:

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_port_pvid_set(const sx_api_handle_t  handle,
                                      const sx_access_cmd_t  cmd,
                                      const sx_port_log_id_t log_port,
                                      const sx_vid_t         pvid)
{
    sx_api_command_head_t           cmd_head;
    sx_api_command_vlan_port_pvid_t cmd_body;
    sx_api_reply_head_t             reply_head;
    sx_status_t                     err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_VLAN_PORT_PVID_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_command_vlan_port_pvid_t);

    cmd_body.access_cmd = cmd;
    cmd_body.log_port = log_port;
    cmd_body.pvid = pvid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);


    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_port_pvid_get(const sx_api_handle_t  handle,
                                      const sx_port_log_id_t log_port,
                                      sx_vid_t              *pvid_p)
{
    sx_api_command_vlan_port_pvid_t cmd_body;
    sx_status_t                     err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();
    if (pvid_p == NULL) {
        SX_LOG_ERR("pvid parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.access_cmd = SX_ACCESS_CMD_GET;
    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_VLAN_PORT_PVID_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_command_vlan_port_pvid_t));

    if (err == SX_STATUS_SUCCESS) {
        *pvid_p = cmd_body.pvid;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_port_accptd_frm_types_set(const sx_api_handle_t        handle,
                                                  const sx_port_log_id_t       log_port,
                                                  const sx_vlan_frame_types_t *accptd_frm_types_p)
{
    sx_api_command_head_t                       cmd_head;
    sx_api_command_vlan_port_accptd_frm_types_t cmd_body;
    sx_api_reply_head_t                         reply_head;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (accptd_frm_types_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("accptd_frm_types is NULL.\n");
        goto out;
    }
    if (!SX_CHECK_BOOLEAN(accptd_frm_types_p->allow_priotagged) |
        !SX_CHECK_BOOLEAN(accptd_frm_types_p->allow_tagged) |
        !SX_CHECK_BOOLEAN(accptd_frm_types_p->allow_untagged)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("one or more of the accptd_frm_types values exceeds range.\n");
        goto out;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_VLAN_ACCPTD_FRM_TYPES_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_command_vlan_port_accptd_frm_types_t);

    cmd_body.log_port = log_port;
    cmd_body.accptd_frm_types = *accptd_frm_types_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);
out:

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_port_accptd_frm_types_get(const sx_api_handle_t  handle,
                                                  const sx_port_log_id_t log_port,
                                                  sx_vlan_frame_types_t *accptd_frm_types_p)
{
    sx_api_command_vlan_port_accptd_frm_types_t cmd_body;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (accptd_frm_types_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("accptd_frm_types_p is NULL.\n");
        goto out;
    }

    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_VLAN_ACCPTD_FRM_TYPES_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_command_vlan_port_accptd_frm_types_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *accptd_frm_types_p = cmd_body.accptd_frm_types;

out:

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_default_vid_set(const sx_api_handle_t handle, const sx_swid_t swid, const sx_vid_t vid)
{
    sx_api_command_head_t             cmd_head;
    sx_api_command_vlan_default_vid_t cmd_body;
    sx_api_reply_head_t               reply_head;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_VLAN_DEFAULT_VID_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_command_vlan_default_vid_t);

    cmd_body.swid = swid;
    cmd_body.vid = vid;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_vlan_default_vid_get(const sx_api_handle_t handle, const sx_swid_t swid, sx_vid_t          *vid)
{
    sx_api_command_vlan_default_vid_get_t cmd_body;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (vid == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("vid is NULL.\n");
        goto out;
    }

    cmd_body.swid = swid;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_VLAN_DEFAULT_VID_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_command_vlan_default_vid_get_t));

    if (err == SX_STATUS_SUCCESS) {
        *vid = cmd_body.vid;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_port_qinq_mode_set(const sx_api_handle_t  handle,
                                           const sx_port_log_id_t log_port,
                                           const sx_qinq_mode_t   qinq_mode)
{
    sx_api_command_head_t               cmd_head;
    sx_api_command_vlan_qinq_mode_set_t cmd_body;
    sx_api_reply_head_t                 reply_head;
    uint32_t                            buff_size;
    sx_status_t                         status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    /* check qinq range */
    if (SX_QINQ_MODE_CHECK_RANGE(qinq_mode) == FALSE) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("qinq_mode out of range (%s)\n", sx_status_str(status));
        SX_API_LOG_EXIT();
        return status;
    }

    buff_size = sizeof(sx_api_command_vlan_qinq_mode_set_t);
    cmd_head.opcode = SX_API_INT_CMD_VLAN_QINQ_MODE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + buff_size;

    cmd_body.log_port = log_port;
    cmd_body.qinq_mode = qinq_mode;
    cmd_body.egress_et_set = FALSE;

    status = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                           &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_vlan_port_qinq_mode_get(const sx_api_handle_t  handle,
                                           const sx_port_log_id_t log_port,
                                           sx_qinq_mode_t        *qinq_mode_p)
{
    sx_api_command_vlan_qinq_mode_get_t cmd_body;
    sx_status_t                         err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (NULL == qinq_mode_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("qinq_mode_p is NULL.\n");
        goto out;
    }

    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_VLAN_QINQ_MODE_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_command_vlan_qinq_mode_get_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *qinq_mode_p = cmd_body.qinq_mode;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_port_tag_mode_set(const sx_api_handle_t            handle,
                                          const sx_port_log_id_t           log_port,
                                          const sx_vlan_tag_mode_params_t *params_p)
{
    sx_api_command_head_t               cmd_head;
    sx_api_command_vlan_qinq_mode_set_t cmd_body;
    sx_api_reply_head_t                 reply_head;
    uint32_t                            buff_size;
    sx_status_t                         status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SDK_COMPILE_TIME_ASSERT((int)SX_VLAN_TAG_MODE_802_1Q_E == (int)SX_QINQ_MODE_802_1Q);
    SDK_COMPILE_TIME_ASSERT((int)SX_VLAN_TAG_MODE_QINQ_E == (int)SX_QINQ_MODE_QINQ);
    SDK_COMPILE_TIME_ASSERT((int)SX_VLAN_TAG_MODE_802_1AD_E == (int)SX_QINQ_MODE_802_1AD);

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (SX_VLAN_TAG_MODE_CHECK_RANGE(params_p->tag_mode) == FALSE) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("The VLAN tag mode is out of range (%s)\n", sx_status_str(status));
        SX_API_LOG_EXIT();
        return status;
    }

    buff_size = sizeof(sx_api_command_vlan_qinq_mode_set_t);
    cmd_head.opcode = SX_API_INT_CMD_VLAN_QINQ_MODE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + buff_size;

    cmd_body.log_port = log_port;
    cmd_body.qinq_mode = (sx_qinq_mode_t)params_p->tag_mode;
    cmd_body.egress_et_set = !!params_p->egress_et_set;

    status = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                           &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_vlan_port_tag_mode_get(const sx_api_handle_t      handle,
                                          const sx_port_log_id_t     log_port,
                                          sx_vlan_tag_mode_params_t *params_p)
{
    sx_api_command_vlan_qinq_mode_get_t cmd_body;
    sx_status_t                         err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (NULL == params_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("params_p is NULL.\n");
        goto out;
    }

    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_VLAN_QINQ_MODE_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_command_vlan_qinq_mode_get_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    params_p->tag_mode = (sx_vlan_tag_mode_t)cmd_body.qinq_mode;
    params_p->egress_et_set = cmd_body.egress_et_set;


out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_port_qinq_outer_prio_mode_set(const sx_api_handle_t           handle,
                                                      const sx_port_log_id_t          log_port,
                                                      const sx_qinq_outer_prio_mode_t prio_mode)
{
    sx_api_command_head_t                          cmd_head;
    sx_api_command_vlan_qinq_outer_prio_mode_set_t cmd_body;
    sx_api_reply_head_t                            reply_head;
    uint32_t                                       buff_size;
    sx_status_t                                    status = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    /* check prio mode range */
    if (SX_QINQ_OUTER_PRIO_MODE_CHECK_RANGE(prio_mode) == FALSE) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("prio_mode out of range (%s)\n", sx_status_str(status));
        SX_API_LOG_EXIT();
        return status;
    }

    buff_size = sizeof(sx_api_command_vlan_qinq_outer_prio_mode_set_t);
    cmd_head.opcode = SX_API_INT_CMD_VLAN_QINQ_OUTER_PRIO_MODE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + buff_size;

    cmd_body.log_port = log_port;
    cmd_body.prio_mode = prio_mode;

    status = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                           &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return status;
}

sx_status_t sx_api_vlan_port_qinq_outer_prio_mode_get(const sx_api_handle_t      handle,
                                                      const sx_port_log_id_t     log_port,
                                                      sx_qinq_outer_prio_mode_t *prio_mode_p)
{
    sx_api_command_vlan_qinq_outer_prio_mode_get_t cmd_body;
    sx_status_t                                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (NULL == prio_mode_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("prio_mode_p is NULL.\n");
        goto out;
    }

    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_VLAN_QINQ_OUTER_PRIO_MODE_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_command_vlan_qinq_outer_prio_mode_get_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *prio_mode_p = cmd_body.prio_mode;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_set(const sx_api_handle_t handle,
                            const sx_access_cmd_t cmd,
                            const sx_swid_t       swid,
                            sx_vlan_id_t         *vlan_list_p,
                            uint32_t             *vlan_cnt_p)
{
    sx_api_command_vlan_set_t *cmd_body_p = NULL;
    uint32_t                   vlan_list_size = 0;
    uint32_t                   cmd_body_size = 0;
    sx_api_reply_head_t        reply_head;
    sx_status_t                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(reply_head);

    if ((SX_ACCESS_CMD_ADD != cmd) && (SX_ACCESS_CMD_DELETE != cmd)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        goto out;
    }

    if (NULL == vlan_list_p) {
        SX_LOG_ERR("vlan_list_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (NULL == vlan_cnt_p) {
        SX_LOG_ERR("vlan_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (*vlan_cnt_p == 0) {
        SX_LOG_ERR("vlan_cnt_p is zero\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    vlan_list_size = (*vlan_cnt_p) * sizeof(sx_vlan_id_t);

    cmd_body_size = sizeof(sx_api_command_vlan_set_t) +
                    (*vlan_cnt_p * sizeof(sx_vlan_id_t));
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* allocate memory for the list */
    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (SX_CHECK_FAIL(err)) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate cmd_body memory (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    cmd_body_p->access_cmd = cmd;
    cmd_body_p->swid = swid;
    cmd_body_p->vlan_num = *vlan_cnt_p;

    /* copy mac entry list */
    memcpy(cmd_body_p->vlan_list_p, vlan_list_p, vlan_list_size);

    err =
        sx_api_send_command_wrapper(handle, SX_API_INT_CMD_VLAN_SET_E, (uint8_t*)cmd_body_p, cmd_body_size);

    if (err == SX_STATUS_NO_RESOURCES) {
        *vlan_cnt_p = cmd_body_p->vlan_num;
        memcpy(vlan_list_p, cmd_body_p->vlan_list_p, cmd_body_p->vlan_num * sizeof(sx_vlan_id_t));
    }

out:
    if (NULL != cmd_body_p) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_get(const sx_api_handle_t handle,
                            const sx_swid_t       swid,
                            sx_vlan_id_t         *vlan_list_p,
                            uint32_t             *vlan_cnt_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_api_command_vlan_get_t *cmd_body_p = NULL;
    uint32_t                   cmd_body_size = 0;
    sx_access_cmd_t            api_access_cmd = SX_ACCESS_CMD_COUNT;

    SX_API_LOG_ENTER();

    if (!vlan_cnt_p) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("vlan_cnt_p is NULL.\n");
        goto out;
    }

    /* Define API access command according to the parameters */
    if ((!vlan_list_p) || (*vlan_cnt_p == 0)) {
        /* User did not allocated array for VLANs or do not know the
         * number of VLANs needed */
        api_access_cmd = SX_ACCESS_CMD_COUNT;
        *vlan_cnt_p = 0;
        vlan_list_p = NULL;
    } else {
        /* User specified number of required VLANs and provided array
         * for them */
        api_access_cmd = SX_ACCESS_CMD_GET;
    }

    /* Calculate needed buffer size */
    cmd_body_size = offsetof(sx_api_command_vlan_get_t, vlan_list_p) +
                    (*vlan_cnt_p * sizeof(sx_vlan_id_t));
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Allocate memory for the list */
    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (SX_CHECK_FAIL(err)) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate cmd_body memory (%s)\n",
                   sx_status_str(err));
        goto out;
    }

    /* Initialize command body */
    cmd_body_p->access_cmd = api_access_cmd;
    cmd_body_p->swid = swid;
    cmd_body_p->vlan_num = *vlan_cnt_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_VLAN_GET_E, (uint8_t*)cmd_body_p, cmd_body_size);
    if (SX_STATUS_SUCCESS == err) {
        /* Return number of VLANs */
        *vlan_cnt_p = cmd_body_p->vlan_num;

        if (vlan_list_p) {
            /* Copy VLANs array */
            memcpy(vlan_list_p, cmd_body_p->vlan_list_p, cmd_body_p->vlan_num * sizeof(sx_vlan_id_t));
        }
    }

out:
    if (NULL != cmd_body_p) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_vlan_attrib_set(const sx_api_handle_t   handle,
                                   sx_vlan_id_t            vid,
                                   const sx_vlan_attrib_t *vlan_attrib_p)
{
    sx_api_command_head_t                   cmd_head;
    sx_api_command_vlan_attrib_set_params_t cmd_body;
    sx_api_reply_head_t                     reply_head;
    sx_status_t                             err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (vlan_attrib_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("vlan_attrib_p is NULL.\n");
        goto out;
    }

    if (!SX_CHECK_BOOLEAN(vlan_attrib_p->flood_to_router)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("one or more of the vlan_attrib_p values exceeds range.\n");
        goto out;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_VLAN_ATTRIB_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_command_vlan_attrib_set_params_t);

    cmd_body.vid = vid;
    memcpy(&cmd_body.vlan_attrib, vlan_attrib_p, sizeof(sx_vlan_attrib_t));

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);
out:

    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_vlan_attrib_get(const sx_api_handle_t handle, sx_vlan_id_t vid,
                                   sx_vlan_attrib_t      *vlan_attrib_p)
{
    sx_api_command_vlan_attrib_get_params_t cmd_body;
    sx_status_t                             err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (vlan_attrib_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("vlan_attrib_p is NULL.\n");
        goto out;
    }

    cmd_body.vid = vid;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_VLAN_ATTRIB_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_command_vlan_attrib_get_params_t));

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *vlan_attrib_p = cmd_body.vlan_attrib;

out:

    SX_API_LOG_EXIT();
    return err;
}
