/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_bfd.h>
#include "sx_api_internal.h"
#include <complib/cl_mem.h>

#undef  __MODULE__
#define __MODULE__ SX_API_BFD

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

#define MAX_CMD_SIZE (SX_API_MESSAGE_SIZE_LIMIT - sizeof(sx_api_command_head_t))

/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_bfd_log_verbosity_level_set(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               const sx_verbosity_level_t      module_verbosity_level,
                                               const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_BFD_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bfd_log_verbosity_level_get(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               sx_verbosity_level_t           *module_verbosity_level_p,
                                               sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_BFD_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bfd_init_set(const sx_api_handle_t handle, sx_bfd_init_params_t *params_p)
{
    sx_api_bfd_init_params_t cmd_body;
    sx_status_t              err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(params_p, "params_p")) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("params_p is NULL.\n");
        goto out;
    }

    /*coverity[unsigned_compare]*/
    SX_MEM_CPY_P(&cmd_body.init_params, params_p);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_BFD_INIT_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_bfd_init_params_t));
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bfd_deinit_set(const sx_api_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_BFD_DEINIT_E,
                                      NULL,
                                      0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bfd_offload_get_stats(const sx_api_handle_t       handle,
                                         const sx_access_cmd_t       cmd,
                                         const sx_bfd_session_type_t session_type,
                                         sx_bfd_session_id_t        *session_id,
                                         sx_bfd_offload_stats_t     *session_stats)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    uint32_t                cmd_body_size = 0;
    sx_api_reply_head_t     reply_head;
    sx_bfd_offload_stats_t *reply_body = NULL;
    uint32_t                reply_body_size;
    sx_api_command_head_t   cmd_head;
    sx_bfd_offload_stats_t *cmd_body = NULL;

    SX_API_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        err = SX_STATUS_CMD_ERROR;
        SX_LOG_ERR("Failed: cmd is not SX_ACCESS_CMD_READ or SX_ACCESS_CMD_READ_CLEAR \n");
        goto out;
    }

    cmd_body_size = sizeof(sx_bfd_offload_stats_t);
    reply_body_size = sizeof(sx_bfd_offload_stats_t);
    if ((cmd_body_size > MAX_CMD_SIZE) || (reply_body_size > MAX_CMD_SIZE)) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    /* allocate cmd_body buffer */
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size, UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->session_id = *session_id;
    cmd_body->session_type = session_type;

    cmd_head.opcode = SX_API_INT_CMD_BFD_OFFLOAD_GET_STATS_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_bfd_offload_stats_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    memcpy(session_stats, reply_body, sizeof(sx_bfd_offload_stats_t));

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bfd_offload_set(const sx_api_handle_t          handle,
                                   const sx_access_cmd_t          cmd,
                                   const sx_bfd_session_params_t *session_params,
                                   sx_bfd_session_id_t           *session_id)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_bfd_offload_set_params_t *cmd_body = NULL;
    uint32_t                         cmd_body_size = 0;

    SX_API_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_EDIT) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        SX_LOG_ERR("Failed: Unsupported command.\n");
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_DESTROY) && (session_params->packet.packet_buffer == NULL)) {
        SX_LOG_ERR("<bfd_packet> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_bfd_offload_set_params_t);
    if (cmd != SX_ACCESS_CMD_DESTROY) {
        cmd_body_size += session_params->packet.buffer_length;
    }

    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->session_id = *session_id;
    SX_MEM_CPY_BUF(&cmd_body->session_data, &session_params->session_data, sizeof(sx_bfd_session_t));
    if (cmd != SX_ACCESS_CMD_DESTROY) {
        SX_MEM_CPY_BUF(&cmd_body->peer, &session_params->peer, sizeof(sx_bfd_peer_t));
        cmd_body->packet_size = session_params->packet.buffer_length;
        SX_MEM_CPY_BUF(cmd_body->bfd_packet, session_params->packet.packet_buffer,
                       session_params->packet.buffer_length);
        cmd_body->bfd_pid = session_params->bfd_pid;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_BFD_OFFLOAD_SET_E, (uint8_t*)cmd_body, cmd_body_size);

    if ((err == SX_STATUS_SUCCESS) && (cmd == SX_ACCESS_CMD_CREATE)) {
        *session_id = cmd_body->session_id;
    }

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bfd_session_iter_get(const sx_api_handle_t       handle,
                                        const sx_access_cmd_t       cmd,
                                        const sx_bfd_session_id_t   session_id_key,
                                        sx_bfd_session_id_filter_t *session_id_filter_p,
                                        sx_bfd_session_id_t        *session_id_list_p,
                                        uint32_t                   *session_id_cnt_p)
{
    sx_api_command_head_t                    cmd_head;
    sx_api_bfd_session_id_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                      reply_head;
    sx_api_bfd_session_id_iter_get_params_t *reply_body = NULL;
    uint32_t                                 reply_body_size;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (session_id_cnt_p == NULL) {
        SX_LOG_ERR("session_id_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*session_id_cnt_p == 0) {
            SX_LOG_ERR("session_id_cnt_p is 0\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (session_id_cnt_p == NULL) {
            SX_LOG_ERR("policer_id_list_p is NULL\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*session_id_cnt_p == 0) {
            session_id_list_p = NULL;
        } else if (session_id_list_p == NULL) {
            SX_LOG_ERR("session_id_list_p is NULL\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is unsupported, err: %s.\n",
                   cmd, SX_ACCESS_CMD_STR(cmd), SX_STATUS_MSG(err));
        goto out;
    }


    reply_body_size = sizeof(sx_api_bfd_session_id_iter_get_params_t) +
                      (*session_id_cnt_p * sizeof(sx_bfd_session_id_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_BFD_SESSION_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_bfd_session_id_iter_get_params_t);
    cmd_head.list_size = *session_id_cnt_p * sizeof(sx_bfd_session_id_t);


    cmd_body.session_id_key = session_id_key;
    cmd_body.cmd = cmd;
    cmd_body.session_id_cnt = *session_id_cnt_p;
    if (session_id_filter_p != NULL) {
        cmd_body.session_id_filter = *session_id_filter_p;
    }

    *session_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


    if (reply_body->session_id_cnt) {
        *session_id_cnt_p = reply_body->session_id_cnt;
        if (session_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(session_id_list_p, reply_body->session_id_list,
                             reply_body->session_id_cnt, sx_bfd_session_id_t);
        }
    }


out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}
