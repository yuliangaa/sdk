/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_tunnel.h>
#include <sx/sdk/sx_api_tele.h>
#include "sx_api_internal.h"

#undef __MODULE__
#define __MODULE__ SX_API_TELE

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_tele_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                const sx_verbosity_level_t      module_verbosity_level,
                                                const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_TELE_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tele_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                sx_verbosity_level_t           *module_verbosity_level_p,
                                                sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_TELE_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tele_init_set(const sx_api_handle_t handle, sx_tele_init_params_t *params_p)
{
    sx_api_tele_init_params_t cmd_body;
    sx_status_t               err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    /*coverity[bad_memset]*/
    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(params_p, "params_p")) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("params_p is NULL.\n");
        goto out;
    }

    /*coverity[unsigned_compare]*/
    SX_MEM_CPY_P(&cmd_body.init_params, params_p);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_INIT_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tele_init_params_t));
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tele_deinit_set(const sx_api_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_DEINIT_E,
                                      NULL,
                                      0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tele_histogram_set(const sx_api_handle_t                     handle,
                                      const sx_access_cmd_t                     cmd,
                                      const sx_tele_histogram_key_t             key,
                                      const sx_tele_histogram_attributes_data_t data)
{
    sx_api_tele_histogram_set_params_t cmd_body;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_EDIT) &&
        (cmd != SX_ACCESS_CMD_DESTROY)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.key, key);
    SX_MEM_CPY(cmd_body.data, data);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_HISTOGRAM_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tele_histogram_set_params_t));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tele_histogram_get(const sx_api_handle_t                handle,
                                      const sx_access_cmd_t                cmd,
                                      const sx_tele_histogram_key_t        key,
                                      sx_tele_histogram_attributes_data_t *data_p)
{
    sx_api_tele_histogram_get_params_t cmd_body;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(data_p, "data_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.key, key);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_HISTOGRAM_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tele_histogram_get_params_t));

    SX_MEM_CPY(*data_p, cmd_body.data);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tele_histogram_iter_get(const sx_api_handle_t            handle,
                                           const sx_access_cmd_t            cmd,
                                           const sx_tele_histogram_key_t   *hist_key_p,
                                           const sx_tele_histogram_filter_t filter,
                                           sx_tele_histogram_key_t         *hist_list_p,
                                           uint32_t                        *hist_cnt_p)
{
    sx_api_tele_histogram_iter_get_params_t *cmd_body_p = NULL;
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_status_t                              free_err = SX_STATUS_SUCCESS;
    uint32_t                                 cmd_size = 0;
    boolean_t                                copy_list = FALSE;

    SX_API_LOG_ENTER();

    if (utils_check_pointer(hist_cnt_p, "hist_cnt_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (*hist_cnt_p > 0) {
        copy_list = TRUE;

        if (((cmd == SX_ACCESS_CMD_GET) || (cmd == SX_ACCESS_CMD_GETNEXT))
            && (hist_key_p == NULL)) {
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_GET_FIRST) &&
        (cmd != SX_ACCESS_CMD_GETNEXT)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_size = sizeof(sx_api_tele_histogram_iter_get_params_t);
    cmd_size += (sizeof(sx_tele_histogram_key_t) * (*hist_cnt_p));
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (SX_STATUS_SUCCESS != err) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    if (hist_key_p != NULL) {
        SX_MEM_CPY(cmd_body_p->hist_key, *hist_key_p);
    }

    SX_MEM_CPY(cmd_body_p->cmd, cmd);
    SX_MEM_CPY(cmd_body_p->hist_filter, filter);
    SX_MEM_CPY(cmd_body_p->hist_cnt, *hist_cnt_p);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_HISTOGRAM_ITER_GET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_size);

    if (copy_list) {
        SX_MEM_CPY_ARRAY(hist_list_p, &cmd_body_p->hist_list, cmd_body_p->hist_cnt, sx_tele_histogram_key_t);
    }

    SX_MEM_CPY(*hist_cnt_p, cmd_body_p->hist_cnt);

out:
    if (NULL != cmd_body_p) {
        free_err = utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != free_err) {
            SX_LOG_ERR("Failed to free reply_body memory.\n");
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tele_histogram_data_get(const sx_api_handle_t         handle,
                                           const sx_access_cmd_t         cmd,
                                           const sx_tele_histogram_key_t key,
                                           sx_tele_histogram_data_t     *histogram_p)
{
    sx_api_tele_histogram_data_get_params_t cmd_body;
    sx_status_t                             err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(histogram_p, "histogram_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.hist_key = key;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_HISTOGRAM_DATA_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tele_histogram_data_get_params_t));

    SX_MEM_CPY(*histogram_p, cmd_body.hist_data);

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_tele_threshold_set(const sx_api_handle_t          handle,
                                      const sx_access_cmd_t          cmd,
                                      const sx_tele_threshold_key_t  key,
                                      const sx_tele_threshold_data_t data)
{
    sx_api_tele_threshold_set_params_t cmd_body;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_EDIT) &&
        (cmd != SX_ACCESS_CMD_DESTROY)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.key = key;
    cmd_body.data = data;


    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_THRESHOLD_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tele_threshold_set_params_t));
out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_tele_threshold_get(const sx_api_handle_t         handle,
                                      const sx_access_cmd_t         cmd,
                                      const sx_tele_threshold_key_t key,
                                      sx_tele_threshold_data_t     *data_p)
{
    sx_api_tele_threshold_get_params_t cmd_body;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(data_p, "data_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.key = key;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_THRESHOLD_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tele_threshold_get_params_t));
    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*data_p, cmd_body.data);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tele_threshold_crossed_data_get(const sx_api_handle_t             handle,
                                                   const sx_access_cmd_t             cmd,
                                                   const sx_tele_threshold_key_t    *key_p,
                                                   sx_tele_threshold_crossed_data_t *crossed_data_p,
                                                   uint32_t                          key_cnt)
{
    sx_api_tele_threshold_crossed_data_get_params_t *cmd_body_p = NULL;
    sx_status_t                                      err = SX_STATUS_SUCCESS;
    sx_status_t                                      free_err = SX_STATUS_SUCCESS;
    uint32_t                                         cmd_size = 0;
    uint32_t                                         i = 0;

    SX_API_LOG_ENTER();

    if (utils_check_pointer(crossed_data_p, "crossed_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_size = sizeof(sx_api_tele_threshold_crossed_data_get_params_t);
    cmd_size += (sizeof(sx_tele_threshold_crossed_data_keys_t) * (key_cnt));
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (SX_STATUS_SUCCESS != err) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    SX_MEM_CPY(cmd_body_p->cmd, cmd);
    SX_MEM_CPY(cmd_body_p->list_cnt, key_cnt);
    for (i = 0; i < key_cnt; i++) {
        SX_MEM_CPY(cmd_body_p->data[i].key, key_p[i]);
        SX_MEM_CPY(cmd_body_p->data[i].key_index, i);
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_THRESHOLD_CROSSED_DATA_GET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_size);
    if (SX_CHECK_PASS(err)) {
        for (i = 0; i < key_cnt; i++) {
            SX_MEM_CPY(crossed_data_p[i], cmd_body_p->data[i].crossed_data);
        }
    }

out:
    if (NULL != cmd_body_p) {
        free_err = utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
        if (SX_STATUS_SUCCESS != free_err) {
            SX_LOG_ERR("Failed to free reply_body memory.\n");
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tele_attributes_set(const sx_api_handle_t handle, const sx_tele_attrib_t attributes)
{
    sx_tele_attrib_t cmd_body;
    sx_status_t      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    SX_MEM_CPY(cmd_body, attributes);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_ATTRIBUTES_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_tele_attrib_t));

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_tele_attributes_get(const sx_api_handle_t handle, sx_tele_attrib_t         *attributes_p)
{
    sx_tele_attrib_t cmd_body;
    sx_status_t      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(attributes_p, "attributes_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_ATTRIBUTES_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_tele_attrib_t));

    SX_MEM_CPY(*attributes_p, cmd_body);

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_tele_hash_sig_default_prof_set(const sx_api_handle_t                  handle,
                                                  const sx_access_cmd_t                  cmd,
                                                  const sx_tele_hash_sig_params_t       *hash_params_p,
                                                  const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                                  const uint32_t                         hash_field_enable_list_cnt,
                                                  const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                                  const uint32_t                         hash_field_list_cnt)
{
    sx_api_tele_hash_sig_default_set_params_t *cmd_body = NULL;
    sx_api_command_head_t                      cmd_head;
    uint32_t                                   cmd_body_size = 0;
    uint32_t                                   dynamic_size = 0;
    sx_api_reply_head_t                        reply_head;
    sx_status_t                                out_err = SX_STATUS_SUCCESS;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if ((hash_field_list_cnt > 0) && (NULL == hash_field_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_list_p param is NULL while hash_field_list_cnt (=%d) > 0\n",
                   hash_field_list_cnt);
        goto out;
    }

    if ((hash_field_enable_list_cnt > 0) && (NULL == hash_field_enable_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_enable_list_p param is NULL while hash_field_enable_list_cnt (=%d) > 0\n",
                   hash_field_enable_list_cnt);
        goto out;
    }
    if (hash_field_enable_list_cnt > SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("HASH_SIG hash_field_enable_list_cnt (=%d) exceeds range (=%d)\n",
                   hash_field_enable_list_cnt,
                   SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM);
        goto out;
    }
    if (hash_field_list_cnt > SX_TELE_HASH_SIG_FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("HASH_SIG hash_field_list_cnt (=%d) exceeds range (=%d)\n",
                   hash_field_list_cnt,
                   SX_TELE_HASH_SIG_FIELDS_NUM);
        goto out;
    }

    dynamic_size = hash_field_list_cnt * sizeof(sx_tele_hash_sig_field_t);
    if (dynamic_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body,
                        1,
                        sizeof(sx_api_tele_hash_sig_default_set_params_t) + dynamic_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for HASH_SIG hash params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    /* Allocate the field list and field list arrays in the command body */
    if (hash_field_list_cnt > 0) {
        SX_MEM_CPY_ARRAY(cmd_body->hash_field_list_p,
                         hash_field_list_p,
                         hash_field_list_cnt,
                         sx_tele_hash_sig_field_t);
    }

    if (hash_field_enable_list_cnt > 0) {
        SX_MEM_CPY_ARRAY(cmd_body->hash_field_enable_list_p,
                         hash_field_enable_list_p,
                         hash_field_enable_list_cnt,
                         sx_tele_hash_sig_field_enable_t);
    }

    cmd_body->cmd = cmd;
    if (hash_params_p != NULL) {
        cmd_body->hash_params = *hash_params_p;
    }
    cmd_body->hash_field_enable_list_cnt = hash_field_enable_list_cnt;
    cmd_body->hash_field_list_cnt = hash_field_list_cnt;
    cmd_body_size = sizeof(*cmd_body) + dynamic_size;

    cmd_head.opcode = SX_API_INT_CMD_TELE_HASH_SIG_DEFAULT_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, NULL, 0);

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free HASH_SIG port hash API params",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_tele_hash_sig_default_prof_get(const sx_api_handle_t            handle,
                                                  sx_tele_hash_sig_params_t       *hash_params_p,
                                                  sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                                  uint32_t                        *hash_field_enable_list_cnt_p,
                                                  sx_tele_hash_sig_field_t        *hash_field_list_p,
                                                  uint32_t                        *hash_field_list_cnt_p)
{
    sx_api_command_head_t                      cmd_head;
    sx_api_tele_hash_sig_default_get_params_t  cmd_body;
    sx_api_tele_hash_sig_default_get_params_t *reply_body = NULL;
    sx_api_reply_head_t                        reply_head;
    uint32_t                                   reply_body_size = 0;
    sx_status_t                                out_err = SX_STATUS_SUCCESS;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (NULL == hash_field_list_cnt_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_list_cnt param is NULL\n");
        goto out;
    }

    if ((*hash_field_list_cnt_p > 0) && (NULL == hash_field_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_list_p param is NULL\n");
        goto out;
    }

    if (NULL == hash_field_enable_list_cnt_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_enable_list_cnt param is NULL\n");
        goto out;
    }

    if ((*hash_field_enable_list_cnt_p > 0) && (NULL == hash_field_enable_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_enable_list_p param is NULL\n");
        goto out;
    }

    if (*hash_field_enable_list_cnt_p > SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("HASH_SIG hash_field_enable_list_cnt_p (=%d) exceeds range(=%d)\n",
                   *hash_field_enable_list_cnt_p,
                   SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM);
        goto out;
    }

    if (*hash_field_list_cnt_p > SX_TELE_HASH_SIG_FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("HASH_SIG hash_field_list_cnt_p (=%d) exceeds range(=%d)\n",
                   *hash_field_list_cnt_p, SX_TELE_HASH_SIG_FIELDS_NUM);
        goto out;
    }

    reply_body_size = sizeof(sx_api_tele_hash_sig_default_get_params_t) +
                      ((*hash_field_list_cnt_p) * sizeof(sx_tele_hash_sig_field_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Allocate the field list and field list arrays in the command body */
    M_UTILS_CLR_MEM_GET(&reply_body,
                        1,
                        reply_body_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for HASH_SIG hash params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    cmd_body.hash_field_enable_list_cnt = *hash_field_enable_list_cnt_p;
    cmd_body.hash_field_list_cnt = *hash_field_list_cnt_p;

    cmd_head.opcode = SX_API_INT_CMD_TELE_HASH_SIG_DEFAULT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_tele_hash_sig_default_get_params_t);
    cmd_head.list_size = (*hash_field_list_cnt_p) * sizeof(sx_tele_hash_sig_field_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body, reply_body_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *hash_params_p = reply_body->hash_params;
    *hash_field_list_cnt_p = reply_body->hash_field_list_cnt;
    if (*hash_field_list_cnt_p > 0) {
        if (hash_field_list_p != NULL) {
            SX_MEM_CPY_ARRAY(hash_field_list_p,
                             reply_body->hash_field_list_p,
                             *hash_field_list_cnt_p,
                             sx_tele_hash_sig_field_t);
        }
    }
    *hash_field_enable_list_cnt_p = reply_body->hash_field_enable_list_cnt;
    if (*hash_field_enable_list_cnt_p > 0) {
        if (hash_field_enable_list_p != NULL) {
            SX_MEM_CPY_ARRAY(hash_field_enable_list_p,
                             reply_body->hash_field_enable_list_p,
                             *hash_field_enable_list_cnt_p,
                             sx_tele_hash_sig_field_enable_t);
        }
    }

out:
    if (NULL != reply_body) {
        M_UTILS_MEM_PUT(reply_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free HASH SIG hash API params",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_tele_hash_sig_prof_set(const sx_api_handle_t                     handle,
                                          const sx_access_cmd_t                     cmd,
                                          const sx_tele_hash_sig_prof_t            *hash_sig_prof_idx_p,
                                          const sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_class_p,
                                          const sx_tele_hash_sig_params_t          *hash_params_p,
                                          const sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                          const uint32_t                            hash_field_enable_list_cnt,
                                          const sx_tele_hash_sig_field_t           *hash_field_list_p,
                                          const uint32_t                            hash_field_list_cnt)
{
    sx_api_tele_hash_sig_prof_set_params_t *cmd_body = NULL;
    sx_api_command_head_t                   cmd_head;
    uint32_t                                cmd_body_size = 0;
    uint32_t                                dynamic_size = 0;
    sx_api_reply_head_t                     reply_head;
    sx_status_t                             out_err = SX_STATUS_SUCCESS;
    sx_status_t                             err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (NULL == hash_sig_prof_idx_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_sig_prof_idx_p param is NULL\n");
        goto out;
    }

    if ((hash_field_list_cnt > 0) && (NULL == hash_field_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_list_p param is NULL while hash_field_list_cnt (=%d) > 0\n",
                   hash_field_list_cnt);
        goto out;
    }

    if ((hash_field_enable_list_cnt > 0) && (NULL == hash_field_enable_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_enable_list_p param is NULL while hash_field_enable_list_cnt (=%d) > 0\n",
                   hash_field_enable_list_cnt);
        goto out;
    }
    if (hash_field_enable_list_cnt > SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("HASH_SIG hash_field_enable_list_cnt (=%d) exceeds range (=%d)\n",
                   hash_field_enable_list_cnt,
                   SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM);
        goto out;
    }
    if (hash_field_list_cnt > SX_TELE_HASH_SIG_FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("HASH_SIG hash_field_list_cnt (=%d) exceeds range (=%d)\n",
                   hash_field_list_cnt,
                   SX_TELE_HASH_SIG_FIELDS_NUM);
        goto out;
    }

    dynamic_size = hash_field_list_cnt * sizeof(sx_tele_hash_sig_field_t);
    if (dynamic_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body,
                        1,
                        sizeof(sx_api_tele_hash_sig_prof_set_params_t) + dynamic_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for HASH_SIG hash params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    /* Allocate the field list and field list arrays in the command body */
    if (hash_field_list_cnt > 0) {
        SX_MEM_CPY_ARRAY(cmd_body->hash_field_list_p,
                         hash_field_list_p,
                         hash_field_list_cnt,
                         sx_tele_hash_sig_field_t);
    }

    if (hash_field_enable_list_cnt > 0) {
        SX_MEM_CPY_ARRAY(cmd_body->hash_field_enable_list_p,
                         hash_field_enable_list_p,
                         hash_field_enable_list_cnt,
                         sx_tele_hash_sig_field_enable_t);
    }

    cmd_body->cmd = cmd;
    cmd_body->hash_sig_prof_idx = *hash_sig_prof_idx_p;

    if (hash_sig_prof_class_p != NULL) {
        cmd_body->hash_sig_prof_class = *hash_sig_prof_class_p;
    }

    if (hash_params_p != NULL) {
        cmd_body->hash_params = *hash_params_p;
    }

    cmd_body->hash_field_enable_list_cnt = hash_field_enable_list_cnt;
    cmd_body->hash_field_list_cnt = hash_field_list_cnt;
    cmd_body_size = sizeof(*cmd_body) + dynamic_size;

    cmd_head.opcode = SX_API_INT_CMD_TELE_HASH_SIG_PROF_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, NULL, 0);

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free HASH_SIG port hash API params",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_tele_hash_sig_prof_get(const sx_api_handle_t               handle,
                                          const sx_tele_hash_sig_prof_t      *hash_sig_prof_idx_p,
                                          sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_class_p,
                                          sx_tele_hash_sig_params_t          *hash_params_p,
                                          sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                          uint32_t                           *hash_field_enable_list_cnt_p,
                                          sx_tele_hash_sig_field_t           *hash_field_list_p,
                                          uint32_t                           *hash_field_list_cnt_p)
{
    sx_api_command_head_t                   cmd_head;
    sx_api_tele_hash_sig_prof_get_params_t  cmd_body;
    sx_api_tele_hash_sig_prof_get_params_t *reply_body = NULL;
    sx_api_reply_head_t                     reply_head;
    uint32_t                                reply_body_size = 0;
    sx_status_t                             out_err = SX_STATUS_SUCCESS;
    sx_status_t                             err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (NULL == hash_field_list_cnt_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_list_cnt param is NULL\n");
        goto out;
    }

    if (NULL == hash_sig_prof_idx_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_sig_prof_idx_p param is NULL\n");
        goto out;
    }

    if (NULL == hash_sig_prof_class_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_sig_prof_class_p param is NULL\n");
        goto out;
    }

    if ((*hash_field_list_cnt_p > 0) && (NULL == hash_field_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_list_p param is NULL\n");
        goto out;
    }

    if (NULL == hash_field_enable_list_cnt_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_enable_list_cnt param is NULL\n");
        goto out;
    }

    if ((*hash_field_enable_list_cnt_p > 0) && (NULL == hash_field_enable_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("HASH_SIG hash_field_enable_list_p param is NULL\n");
        goto out;
    }

    if (*hash_field_enable_list_cnt_p > SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("HASH_SIG hash_field_enable_list_cnt_p (=%d) exceeds range(=%d)\n",
                   *hash_field_enable_list_cnt_p,
                   SX_TELE_HASH_SIG_FIELDS_ENABLES_NUM);
        goto out;
    }

    if (*hash_field_list_cnt_p > SX_TELE_HASH_SIG_FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("HASH_SIG hash_field_list_cnt_p (=%d) exceeds range(=%d)\n",
                   *hash_field_list_cnt_p, SX_TELE_HASH_SIG_FIELDS_NUM);
        goto out;
    }

    reply_body_size = sizeof(sx_api_tele_hash_sig_prof_get_params_t) +
                      ((*hash_field_list_cnt_p) * sizeof(sx_tele_hash_sig_field_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Allocate the field list and field list arrays in the command body */
    M_UTILS_CLR_MEM_GET(&reply_body,
                        1,
                        reply_body_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for HASH_SIG hash params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body.hash_sig_prof_idx = *hash_sig_prof_idx_p;
    cmd_body.hash_field_enable_list_cnt = *hash_field_enable_list_cnt_p;
    cmd_body.hash_field_list_cnt = *hash_field_list_cnt_p;

    cmd_head.opcode = SX_API_INT_CMD_TELE_HASH_SIG_PROF_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_tele_hash_sig_prof_get_params_t);
    cmd_head.list_size = (*hash_field_list_cnt_p) * sizeof(sx_tele_hash_sig_field_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body, reply_body_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *hash_params_p = reply_body->hash_params;
    *hash_sig_prof_class_p = reply_body->hash_sig_prof_class;
    *hash_field_list_cnt_p = reply_body->hash_field_list_cnt;
    if (*hash_field_list_cnt_p > 0) {
        if (hash_field_list_p != NULL) {
            SX_MEM_CPY_ARRAY(hash_field_list_p,
                             reply_body->hash_field_list_p,
                             *hash_field_list_cnt_p,
                             sx_tele_hash_sig_field_t);
        }
    }
    *hash_field_enable_list_cnt_p = reply_body->hash_field_enable_list_cnt;
    if (*hash_field_enable_list_cnt_p > 0) {
        if (hash_field_enable_list_p != NULL) {
            SX_MEM_CPY_ARRAY(hash_field_enable_list_p,
                             reply_body->hash_field_enable_list_p,
                             *hash_field_enable_list_cnt_p,
                             sx_tele_hash_sig_field_enable_t);
        }
    }

out:
    if (NULL != reply_body) {
        M_UTILS_MEM_PUT(reply_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free HASH SIG hash API params",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}


sx_status_t sx_api_tele_tac_set(const sx_api_handle_t handle,
                                const sx_access_cmd_t cmd,
                                const sx_trap_group_t trap_group,
                                sx_tele_tac_cfg_t    *tac_cfg_p)
{
    sx_api_tele_tac_set_params_t *cmd_body = NULL;
    sx_api_command_head_t         cmd_head;
    uint32_t                      cmd_body_size = 0;
    sx_api_reply_head_t           reply_head;
    sx_status_t                   out_err = SX_STATUS_SUCCESS;
    sx_status_t                   err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (tac_cfg_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("tac_cfg_p param is NULL.\n");
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, sizeof(*cmd_body), UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for TAC set params.\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->trap_group = trap_group;
    cmd_body->tac_cfg = *tac_cfg_p;
    cmd_body_size = sizeof(*cmd_body);

    cmd_head.opcode = SX_API_INT_CMD_TELE_AGG_CACHE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, NULL, 0);

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free TAC set API params", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_tele_tac_get(const sx_api_handle_t handle,
                                const sx_access_cmd_t cmd,
                                const sx_trap_group_t trap_group,
                                sx_tele_tac_cfg_t    *tac_cfg_p)
{
    sx_api_tele_tac_get_params_t *cmd_body = NULL;
    sx_api_command_head_t         cmd_head;
    uint32_t                      cmd_body_size = 0;
    sx_api_reply_head_t           reply_head;
    sx_status_t                   out_err = SX_STATUS_SUCCESS;
    sx_status_t                   err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (tac_cfg_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("tac_cfg_p param is NULL.\n");
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, sizeof(*cmd_body), UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for TAC get params.\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->trap_group = trap_group;
    cmd_body_size = sizeof(*cmd_body);

    cmd_head.opcode = SX_API_INT_CMD_TELE_AGG_CACHE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)cmd_body, sizeof(*cmd_body));

    if (err == SX_STATUS_SUCCESS) {
        *tac_cfg_p = cmd_body->tac_cfg;
    }

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free TAC get API params", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_tele_tac_action_set(const sx_api_handle_t        handle,
                                       const sx_access_cmd_t        cmd,
                                       sx_tele_tac_action_filter_t *tac_action_filter_p,
                                       sx_tele_tac_action_info_t   *tac_action_info_p)
{
    sx_api_tele_tac_action_set_params_t *cmd_body = NULL;
    sx_api_command_head_t                cmd_head;
    uint32_t                             cmd_body_size = 0;
    sx_api_reply_head_t                  reply_head;
    sx_status_t                          out_err = SX_STATUS_SUCCESS;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (tac_action_filter_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("tac_action_filter_p param is NULL.\n");
        goto out;
    }

    if (tac_action_info_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("tac_action_info_p param is NULL.\n");
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, sizeof(*cmd_body), UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for TAC action set params.\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->tac_action_filter = *tac_action_filter_p;
    cmd_body->tac_action_info = *tac_action_info_p;
    cmd_body_size = sizeof(*cmd_body);

    cmd_head.opcode = SX_API_INT_CMD_TELE_AGG_CACHE_ACTION_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, NULL, 0);

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free TAC action set API params", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_tele_tac_action_status_get(const sx_api_handle_t        handle,
                                              const sx_access_cmd_t        cmd,
                                              sx_tele_tac_action_status_t *tac_action_status_p)
{
    sx_api_tele_tac_action_status_get_params_t *cmd_body = NULL;
    sx_api_command_head_t                       cmd_head;
    uint32_t                                    cmd_body_size = 0;
    sx_api_reply_head_t                         reply_head;
    sx_status_t                                 out_err = SX_STATUS_SUCCESS;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (tac_action_status_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("tac_action_status_p param is NULL.\n");
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, sizeof(*cmd_body), UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for TAC action status get params.\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body_size = sizeof(*cmd_body);

    cmd_head.opcode = SX_API_INT_CMD_TELE_AGG_CACHE_ACTION_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)cmd_body, (uint32_t)sizeof(*cmd_body));

    if (err == SX_STATUS_SUCCESS) {
        tac_action_status_p->tac_action_status = cmd_body->tac_action_status;
    }

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free TAC action status get API params", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_tele_tac_statistics_get(const sx_api_handle_t     handle,
                                           const sx_access_cmd_t     cmd,
                                           sx_tele_tac_statistics_t *tac_stat_p)
{
    sx_api_tele_tac_statistics_get_params_t *cmd_body = NULL;
    sx_api_command_head_t                    cmd_head;
    uint32_t                                 cmd_body_size = 0;
    sx_api_reply_head_t                      reply_head;
    sx_status_t                              out_err = SX_STATUS_SUCCESS;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (tac_stat_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("tac_stat_p param is NULL.\n");
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, sizeof(*cmd_body), UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for TAC statistics get params.\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->tac_stat = *tac_stat_p;
    cmd_body_size = sizeof(*cmd_body);

    cmd_head.opcode = SX_API_INT_CMD_TELE_AGG_CACHE_STAT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)cmd_body, (uint32_t)sizeof(*cmd_body));

    if (err == SX_STATUS_SUCCESS) {
        *tac_stat_p = cmd_body->tac_stat;
    }

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free TAC statistics get API params", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_tele_tac_oob_msg_send(const sx_api_handle_t       handle,
                                         const sx_access_cmd_t       cmd,
                                         sx_tele_tac_oob_send_cfg_t* oob_cfg_p)
{
    sx_api_tele_tac_oob_msg_send_params_t *cmd_body = NULL;
    sx_api_command_head_t                  cmd_head;
    uint32_t                               cmd_body_size = 0;
    sx_api_reply_head_t                    reply_head;
    sx_status_t                            out_err = SX_STATUS_SUCCESS;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (oob_cfg_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("oob_cfg_p param is NULL.\n");
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, sizeof(*cmd_body), UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for TAC oob_msg send params.\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->oob_cfg = *oob_cfg_p;
    cmd_body_size = sizeof(*cmd_body);

    cmd_head.opcode = SX_API_INT_CMD_TELE_AGG_CACHE_OOB_MSG_SEND_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, (uint8_t*)cmd_body, (uint32_t)sizeof(*cmd_body));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Send of oob TAC message failed with err: %s \n",
                   sx_status_str(err));
    }

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free TAC statistics get API params", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_tele_port_bw_gauge_set(const sx_api_handle_t   handle,
                                          const sx_access_cmd_t   cmd,
                                          sx_tele_gauge_config_t *gauge_config_p)
{
    sx_api_tele_port_bw_gauge_set_params_t cmd_body;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(gauge_config_p, "gauge_config_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_EDIT) &&
        (cmd != SX_ACCESS_CMD_DESTROY)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.gauge_config, *gauge_config_p);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_PORT_BW_GAUGE_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tele_port_bw_gauge_set_params_t));

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_tele_port_bw_gauge_get(const sx_api_handle_t   handle,
                                          const sx_access_cmd_t   cmd,
                                          sx_tele_gauge_config_t *gauge_config_p)
{
    sx_api_tele_port_bw_gauge_get_params_t cmd_body;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(gauge_config_p, "gauge_config_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.gauge_config, *gauge_config_p);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_PORT_BW_GAUGE_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tele_port_bw_gauge_get_params_t));

    SX_MEM_CPY(*gauge_config_p, cmd_body.gauge_config);

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_tele_port_bw_gauge_data_get(const sx_api_handle_t handle,
                                               const sx_access_cmd_t cmd,
                                               sx_tele_gauge_key_t  *gauge_key_p,
                                               sx_tele_gauge_data_t *gauge_data_p)
{
    sx_api_tele_port_bw_gauge_data_get_params_t cmd_body;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(gauge_data_p, "gauge_data_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(gauge_key_p, "gauge_key_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.gauge_key, *gauge_key_p);
    SX_MEM_CPY(cmd_body.gauge_data, *gauge_data_p);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_TELE_PORT_BW_GAUGE_DATA_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_tele_port_bw_gauge_data_get_params_t));

    SX_MEM_CPY(*gauge_data_p, cmd_body.gauge_data);

out:
    SX_API_LOG_EXIT();
    return err;
}
