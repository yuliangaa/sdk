/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_register.h>
#include "sx_api_internal.h"

#undef __MODULE__
#define __MODULE__ SX_API_REGISTER
/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sx_api_register_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                    const sx_log_verbosity_target_t verbosity_target,
                                                    const sx_verbosity_level_t      module_verbosity_level,
                                                    const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_REGISTER_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head,
                                            (uint8_t*)&cmd_body, &reply_head,
                                            NULL, 0);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_register_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                    const sx_log_verbosity_target_t verbosity_target,
                                                    sx_verbosity_level_t           *module_verbosity_level_p,
                                                    sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p,
                                  "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_REGISTER_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(
            handle, cmd_head.opcode, (uint8_t*)&cmd_body,
            sizeof(sx_api_command_log_verbosity_t));

        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            goto out;
        }

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_register_set(const sx_api_handle_t    handle,
                                const sx_access_cmd_t    cmd,
                                const sx_register_key_t *reg_key_list_p,
                                const uint32_t          *reg_key_cnt_p)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    sx_status_t                   utils_rc = SX_STATUS_SUCCESS;
    sx_api_register_set_params_t *cmd_body_p = NULL;
    uint32_t                      cmd_size = sizeof(sx_api_register_set_params_t);

    SX_API_LOG_ENTER();

    /* parameter validation */
    if (reg_key_cnt_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer reg_key_cnt_p\n");
        goto out;
    }

    if (*reg_key_cnt_p == 0) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid value reg_key_cnt_p: %d\n", *reg_key_cnt_p);
        goto out;
    }

    if (reg_key_list_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer reg_key_list_p\n");
        goto out;
    }

    cmd_size += (*reg_key_cnt_p) * sizeof(sx_register_key_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", utils_rc);
    if (SX_CHECK_FAIL(utils_rc)) {
        rc = utils_rc;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->reg_key_cnt = *reg_key_cnt_p;
    SX_MEM_CPY_ARRAY(cmd_body_p->reg_key_list_p, reg_key_list_p, *reg_key_cnt_p, sx_register_key_t);

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_REGISTER_SET_E,
                                     (uint8_t*)cmd_body_p,
                                     cmd_size);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed register set - [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", utils_rc);
        if (SX_CHECK_FAIL(utils_rc)) {
            rc = utils_rc;
            goto out;
        }
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_register_iter_get(const sx_api_handle_t       handle,
                                     const sx_access_cmd_t       cmd,
                                     const sx_register_key_t     reg_key,
                                     const sx_register_filter_t *filter_p,
                                     sx_register_key_t          *reg_key_list_p,
                                     uint32_t                   *reg_key_cnt_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_status_t                        utils_rc = SX_STATUS_SUCCESS;
    sx_api_register_iter_get_params_t *cmd_body_p = NULL;
    uint32_t                           cmd_size = sizeof(sx_api_register_iter_get_params_t);

    SX_API_LOG_ENTER();

    /* parameter validation */
    if (reg_key_cnt_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer reg_key_cnt_p\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*reg_key_cnt_p == 0) {
            goto out;
        } else if (reg_key_list_p == NULL) {
            SX_LOG_ERR("reg_key_list_p must be valid for cmd (%s)\n", sx_access_cmd_str(cmd));
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*reg_key_cnt_p > 0) {
            if (reg_key_list_p == NULL) {
                SX_LOG_ERR("reg_key_list_p must be valid for cmd (%s) and reg_key_cnt_p > 0\n",
                           sx_access_cmd_str(cmd));
                rc = SX_STATUS_PARAM_NULL;
                goto out;
            }
            *reg_key_cnt_p = 1;
        }
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is unsupported, error: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(rc));
        goto out;
    }

    cmd_size += (*reg_key_cnt_p) * sizeof(sx_register_key_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", utils_rc);
    if (SX_CHECK_FAIL(utils_rc)) {
        rc = utils_rc;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->reg_key = reg_key;
    if (filter_p != NULL) {
        memcpy(&cmd_body_p->filter, filter_p, sizeof(sx_register_filter_t));
    }
    cmd_body_p->reg_key_cnt = *reg_key_cnt_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_REGISTER_ITER_GET_E,
                                     (uint8_t*)cmd_body_p,
                                     cmd_size);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed register iter get - [%s]\n", sx_status_str(rc));
        goto out;
    }

    *reg_key_cnt_p = cmd_body_p->reg_key_cnt;

    if ((reg_key_list_p != NULL) && (*reg_key_cnt_p > 0)) {
        SX_MEM_CPY_ARRAY(reg_key_list_p, cmd_body_p->reg_key_list_p, *reg_key_cnt_p, sx_register_key_t);
    }

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", utils_rc);
        if (SX_CHECK_FAIL(utils_rc)) {
            rc = utils_rc;
            goto out;
        }
    }

    SX_API_LOG_EXIT();
    return rc;
}
