/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>

#include <sx/sdk/sx_api_mc_container.h>

#include <sx/sdk/sx_swid.h>
#include <sx/sdk/sx_vlan.h>
#include <sx/sdk/sx_mc_container.h>

#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_MC_CONTAINER

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sx_api_mc_container_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                        const sx_log_verbosity_target_t verbosity_target,
                                                        const sx_verbosity_level_t      module_verbosity_level,
                                                        const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_MC_CONTAINER_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_mc_container_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                        const sx_log_verbosity_target_t verbosity_target,
                                                        sx_verbosity_level_t           *module_verbosity_level_p,
                                                        sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_MC_CONTAINER_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_mc_container_set(const sx_api_handle_t               handle,
                                    const sx_access_cmd_t               cmd,
                                    sx_mc_container_id_t               *container_id_p,
                                    const sx_mc_next_hop_t             *next_hop_list_p,
                                    const uint32_t                      next_hop_cnt,
                                    const sx_mc_container_attributes_t* container_attr_p)
{
    sx_api_command_head_t                  cmd_head;
    sx_api_mc_container_mode_set_params_t *cmd_body_p = NULL;
    uint32_t                               cmd_body_size = 0;
    sx_api_reply_head_t                    reply_head;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_CREATE) &&
        (cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE) &&
        (cmd != SX_ACCESS_CMD_DESTROY) && (cmd != SX_ACCESS_CMD_DELETE_ALL)) {
        SX_LOG_ERR("Unsupported command %s given\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (NULL == container_id_p) {
        SX_LOG_ERR("<container_id_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((NULL != next_hop_list_p) && (next_hop_cnt > 4000)) {
        SX_LOG_ERR("<next_hop_cnt> param is out of range.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_ACCESS_CMD_CREATE == cmd) {
        if (NULL == container_attr_p) {
            SX_LOG_ERR("container_attr is NULL.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    cmd_body_size = sizeof(sx_api_mc_container_mode_set_params_t) +
                    (next_hop_cnt * sizeof(sx_mc_next_hop_t));
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_MC_CONTAINER_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        cmd_body_size;

    cmd_body_p->cmd = cmd;

    if (cmd == SX_ACCESS_CMD_CREATE) {
        cmd_body_p->container_attr = *container_attr_p;
    }
    cmd_body_p->container_id = *container_id_p;
    cmd_body_p->next_hop_cnt = next_hop_cnt;
    SX_MEM_CPY_ARRAY(cmd_body_p->next_hop, next_hop_list_p,
                     cmd_body_p->next_hop_cnt, sx_mc_next_hop_t);


    /* O/W: */
    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body_p,
                                        &reply_head, (uint8_t*)cmd_body_p, cmd_body_size);

    if ((err == SX_STATUS_SUCCESS) && (cmd == SX_ACCESS_CMD_CREATE)) {
        *container_id_p = cmd_body_p->container_id;
    }

out:
    if (cmd_body_p) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_mc_container_get(const sx_api_handle_t         handle,
                                    const sx_access_cmd_t         cmd,
                                    sx_mc_container_id_t          container_id,
                                    sx_mc_next_hop_t             *next_hop_list_p,
                                    uint32_t                     *next_hop_cnt_p,
                                    sx_mc_container_attributes_t *container_attr_p)
{
    sx_api_command_head_t                  cmd_head;
    sx_api_mc_container_mode_get_params_t  cmd_body;
    uint32_t                               reply_body_size = 0;
    sx_api_reply_head_t                    reply_head;
    sx_api_mc_container_mode_get_params_t *reply_body = NULL;
    sx_status_t                            err = SX_STATUS_SUCCESS;


    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((cmd != SX_ACCESS_CMD_GET) && (cmd != SX_ACCESS_CMD_GET_FIRST) &&
        (cmd != SX_ACCESS_CMD_GETNEXT) && (cmd != SX_ACCESS_CMD_COUNT)) {
        SX_LOG_ERR("Unsupported command %s given\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (next_hop_cnt_p == NULL) {
        SX_LOG_ERR("<next_hop_cnt> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (next_hop_list_p == NULL) {
        *next_hop_cnt_p = 0;
    }
    if (*next_hop_cnt_p == 0) {
        next_hop_list_p = NULL;
    }

    reply_body_size = sizeof(sx_api_mc_container_mode_get_params_t) +
                      ((*next_hop_cnt_p) * sizeof(sx_mc_next_hop_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_MC_CONTAINER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_mc_container_mode_get_params_t);
    cmd_head.list_size = (*next_hop_cnt_p) * sizeof(sx_mc_next_hop_t);

    cmd_body.cmd = cmd;
    cmd_body.container_id = container_id;
    cmd_body.next_hop_cnt = *next_hop_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *container_attr_p = reply_body->container_attr;

    if (*next_hop_cnt_p == 0) {
        *next_hop_cnt_p = reply_body->next_hop_cnt;
    } else if (*next_hop_cnt_p >= reply_body->next_hop_cnt) {
        SX_MEM_CPY_ARRAY(next_hop_list_p, reply_body->next_hop,
                         reply_body->next_hop_cnt, sx_mc_next_hop_t);
        *next_hop_cnt_p = reply_body->next_hop_cnt;
    } else {
        SX_LOG_ERR("Number of hops returned %u is larger than output buffer size %u\n",
                   reply_body->next_hop_cnt, *next_hop_cnt_p);
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_mc_container_iter_get(const sx_api_handle_t        handle,
                                         const sx_access_cmd_t        cmd,
                                         const sx_mc_container_id_t   container_id_key,
                                         sx_mc_container_id_filter_t *container_id_filter_p,
                                         sx_mc_container_id_t        *container_id_list_p,
                                         uint32_t                    *container_id_cnt_p)
{
    sx_api_command_head_t                  cmd_head;
    sx_api_mc_container_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                    reply_head;
    sx_api_mc_container_iter_get_params_t *reply_body = NULL;
    uint32_t                               reply_body_size;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (container_id_cnt_p == NULL) {
        SX_LOG_ERR("container_id_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*container_id_cnt_p == 0) {
            SX_LOG_ERR("container_id_cnt_p is 0\n");
            container_id_list_p = NULL;
            goto out;
        }
        if (container_id_list_p == NULL) {
            SX_LOG_ERR("container_id_list_p is NULL\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET:
        if (*container_id_cnt_p == 0) {
            container_id_list_p = NULL;
        } else if (container_id_list_p == NULL) {
            SX_LOG_ERR("container_id_list_p is NULL\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is unsupported, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }


    reply_body_size = sizeof(reply_body[0]) +
                      (*container_id_cnt_p * sizeof(container_id_list_p[0]));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_MC_CONTAINER_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(cmd_head) + sizeof(cmd_body);
    cmd_head.list_size = *container_id_cnt_p * sizeof(container_id_list_p[0]);

    cmd_body.container_id_key = container_id_key;
    cmd_body.cmd = cmd;
    cmd_body.container_id_cnt = *container_id_cnt_p;
    if (container_id_filter_p != NULL) {
        cmd_body.container_id_filter = *container_id_filter_p;
    }

    *container_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


    if (reply_body->container_id_cnt) {
        *container_id_cnt_p = reply_body->container_id_cnt;
        if (container_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(container_id_list_p, reply_body->container_id_list,
                             reply_body->container_id_cnt, container_id_list_p[0]);
        }
    }


out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}
