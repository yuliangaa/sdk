/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_flex_parser.h>
#include "sx_api_internal.h"

#undef __MODULE__
#define __MODULE__ SX_API_FLEX_PARSER
/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sx_api_flex_parser_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                       const sx_log_verbosity_target_t verbosity_target,
                                                       const sx_verbosity_level_t      module_verbosity_level,
                                                       const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_FLEX_PARSER_LOG_VERBOSITY_LEVEL_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head,
                                            (uint8_t*)&cmd_body, &reply_head,
                                            NULL, 0);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_parser_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                       const sx_log_verbosity_target_t verbosity_target,
                                                       sx_verbosity_level_t           *module_verbosity_level_p,
                                                       sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p,
                                  "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_FLEX_PARSER_LOG_VERBOSITY_LEVEL_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(
            handle, cmd_head.opcode, (uint8_t*)&cmd_body,
            sizeof(sx_api_command_log_verbosity_t));

        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            goto out;
        }

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_parser_init_set(const sx_api_handle_t handle, const sx_flex_parser_param_t *params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    UNUSED_PARAM(params_p);

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_FLEX_PARSER_INIT_E,
                                      NULL,
                                      0);

    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed flex parser init - [%s]\n", sx_status_str(err));
    }

    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_flex_parser_deinit_set(const sx_api_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_FLEX_PARSER_DEINIT_E,
                                      NULL, 0);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed flex parser deinit - [%s]\n", sx_status_str(err));
    }

    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_flex_parser_transition_set(const sx_api_handle_t             handle,
                                              const sx_access_cmd_t             cmd,
                                              const sx_flex_parser_header_t     from,
                                              const sx_flex_parser_transition_t to)
{
    sx_status_t                                err = SX_STATUS_SUCCESS;
    sx_api_flex_parser_transition_set_params_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_UNSET)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Invalid command error:[%s]\n", sx_status_str(err));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.from = from;
    cmd_body.to = to;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_TRANSITION_SET_E, (uint8_t*)&cmd_body,
                                      sizeof(sx_api_flex_parser_transition_set_params_t));

    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed flex parser transition set - [%s]\n", sx_status_str(err));
        goto out;
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_parser_transition_get(const sx_api_handle_t         handle,
                                              const sx_flex_parser_header_t curr_ph,
                                              sx_flex_parser_transition_t  *next_trans_ph_p,
                                              uint32_t                     *next_trans_ph_cnt_p)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                    cmd_head;
    sx_api_flex_parser_trans_ph_get_params_t cmd_body;
    sx_api_reply_head_t                      reply_head;
    sx_flex_parser_transition_t             *trans_ph_p = NULL;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (!next_trans_ph_cnt_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("next_trans_cnt_p is NULL.\n");
        goto out;
    }

    if (!next_trans_ph_p) {
        *next_trans_ph_cnt_p = 0;
    }

    if (*next_trans_ph_cnt_p == 0) {
        trans_ph_p = NULL;
    } else {
        trans_ph_p = next_trans_ph_p;
    }

    cmd_head.opcode = SX_API_INT_CMD_FLEX_PARSER_TRANSITION_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_flex_parser_trans_ph_get_params_t);

    cmd_body.next_trans_ph_cnt = *next_trans_ph_cnt_p;
    SX_MEM_CPY(cmd_body.curr_ph, curr_ph);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)trans_ph_p,
                                        (*next_trans_ph_cnt_p) * sizeof(sx_flex_parser_transition_t));

    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed flex parser transition get - [%s]\n", sx_status_str(err));
        goto out;
    }

    *next_trans_ph_cnt_p = reply_head.list_size;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_parser_flex_graph_set(const sx_api_handle_t                handle,
                                              const sx_access_cmd_t                cmd,
                                              const sx_flex_parser_graph_action_t *actions_list_p,
                                              const uint32_t                       actions_list_cnt)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_graph_set_params_t *cmd_body_p = NULL;
    uint32_t                               cmd_size = 0;

    SX_API_LOG_ENTER();

    /* Allocate command body */
    cmd_size = sizeof(sx_api_flex_parser_graph_set_params_t);

    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        if (actions_list_p == NULL) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Invalid NULL pointer actions_list_p\n");
            goto out;
        }

        cmd_size += (sizeof(sx_flex_parser_graph_action_t) * actions_list_cnt);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for flex parser flex graph set exceeds range.\n", cmd_size);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_p = (sx_api_flex_parser_graph_set_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for flex parser flex graph set command body\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }


    cmd_body_p->cmd = cmd;
    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        cmd_body_p->actions_cnt = actions_list_cnt;
        SX_MEM_CPY_ARRAY(&cmd_body_p->actions_list[0], actions_list_p, actions_list_cnt,
                         sx_flex_parser_graph_action_t);
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_FLEX_GRAPH_SET_E,
                                     (uint8_t*)cmd_body_p,
                                     cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set flex parser flex graph - [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_flex_parser_hard_graph_set(const sx_api_handle_t                handle,
                                              const sx_access_cmd_t                cmd,
                                              const sx_flex_parser_graph_action_t *actions_list_p,
                                              const uint32_t                       actions_list_cnt)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_graph_set_params_t *cmd_body_p = NULL;
    uint32_t                               cmd_size = 0;

    SX_API_LOG_ENTER();

    /* Allocate command body */
    cmd_size = sizeof(sx_api_flex_parser_graph_set_params_t);

    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        if (actions_list_p == NULL) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Invalid NULL pointer actions_list_p\n");
            goto out;
        }

        cmd_size += (sizeof(sx_flex_parser_graph_action_t) * actions_list_cnt);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for flex parser hard graph set exceeds range.\n", cmd_size);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_p = (sx_api_flex_parser_graph_set_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for flex parser hard graph set command body\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }


    cmd_body_p->cmd = cmd;
    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        cmd_body_p->actions_cnt = actions_list_cnt;
        SX_MEM_CPY_ARRAY(&cmd_body_p->actions_list[0], actions_list_p, actions_list_cnt,
                         sx_flex_parser_graph_action_t);
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_HARD_GRAPH_SET_E,
                                     (uint8_t*)cmd_body_p,
                                     cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set flex parser hard graph - [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_flex_parser_flex_transition_set(const sx_api_handle_t               handle,
                                                   const sx_access_cmd_t               cmd,
                                                   sx_flex_parser_transition_index_t  *transition_index_p,
                                                   sx_flex_parser_transition_action_t *transition_cfg_p)
{
    sx_status_t                                     err = SX_STATUS_SUCCESS;
    sx_api_flex_parser_flex_transition_set_params_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (transition_index_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer transition_index_p\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        if (transition_cfg_p == NULL) {
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Invalid NULL pointer transition_cfg_p\n");
            goto out;
        }
        SX_MEM_CPY_TYPE(&(cmd_body.transition_cfg), transition_cfg_p, sx_flex_parser_transition_action_t);
        break;

    case SX_ACCESS_CMD_UNSET:
    case SX_ACCESS_CMD_CREATE:
    case SX_ACCESS_CMD_DESTROY:
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_body.cmd = cmd;
    cmd_body.transition_index = *transition_index_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_FLEX_TRANSITION_SET_E, (uint8_t*)&cmd_body,
                                      sizeof(sx_api_flex_parser_flex_transition_set_params_t));

    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed flex parser flex transition set - [%s]\n", sx_status_str(err));
        goto out;
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_parser_flex_transition_get(const sx_api_handle_t                   handle,
                                                   const sx_flex_parser_transition_index_t transition_index,
                                                   sx_flex_parser_transition_action_t     *transition_cfg_p)
{
    sx_status_t                                     err = SX_STATUS_SUCCESS;
    sx_api_flex_parser_flex_transition_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (!transition_cfg_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("transition_cfg_p is NULL.\n");
        goto out;
    }

    cmd_body.transition_index = transition_index;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_FLEX_TRANSITION_GET_E, (uint8_t*)&cmd_body,
                                      sizeof(sx_api_flex_parser_flex_transition_get_params_t));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get transition_cfg - [%s]\n", sx_status_str(err));
        goto out;
    }

    *transition_cfg_p = cmd_body.transition_cfg;

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_flex_parser_fpp_set(const sx_api_handle_t       handle,
                                       const sx_access_cmd_t       cmd,
                                       sx_flex_parser_fpp_id_t    *fpp_id_p,
                                       const sx_flex_parser_fpp_t *fpp_cfg_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_fpp_set_params_t cmd_body;
    uint32_t                            cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    if (fpp_id_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer fpp_id\n");
        goto out;
    }

    if (fpp_cfg_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer fpp_cfg\n");
        goto out;
    }

    memset(&cmd_body, 0, cmd_size);
    cmd_body.cmd = cmd;
    cmd_body.fpp_id = *fpp_id_p;
    cmd_body.fpp_cfg = *fpp_cfg_p;

    /* We currently do not support setting of the FPP id by the SDK itself so for now this is a simple command */
    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_FPP_SET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set FPP - [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_flex_parser_fpp_get(const sx_api_handle_t         handle,
                                       const sx_access_cmd_t         cmd,
                                       const sx_flex_parser_fpp_id_t fpp_id,
                                       sx_flex_parser_fpp_t         *fpp_cfg_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_fpp_set_params_t cmd_body;
    uint32_t                            cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, cmd_size);
    cmd_body.cmd = cmd;
    cmd_body.fpp_id = fpp_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_FPP_GET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get FPP - [%s]\n", sx_status_str(rc));
        goto out;
    }

    if (fpp_cfg_p != NULL) {
        *fpp_cfg_p = cmd_body.fpp_cfg;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_flex_parser_root_set(const sx_api_handle_t                handle,
                                        const sx_access_cmd_t                cmd,
                                        const sx_flex_parser_root_sop_cfg_t *root_cfg_list_p,
                                        const uint32_t                       root_cfg_cnt)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_root_set_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = 0;

    SX_API_LOG_ENTER();

    if (root_cfg_list_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer root_cfg_list_p\n");
        goto out;
    }

    /* Allocate command body */
    cmd_size = sizeof(sx_api_flex_parser_root_set_params_t);
    cmd_size += (sizeof(sx_flex_parser_root_sop_cfg_t) * root_cfg_cnt);

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for flex parser root set exceeds range.\n", cmd_size);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    cmd_body_p = (sx_api_flex_parser_root_set_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for flex parser root set command body\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->root_cfg_cnt = root_cfg_cnt;
    SX_MEM_CPY_ARRAY(&cmd_body_p->root_cfg_list[0], root_cfg_list_p, root_cfg_cnt, sx_flex_parser_root_sop_cfg_t);

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_ROOT_SET_E,
                                     (uint8_t*)cmd_body_p,
                                     cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set flex parser root - [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_flex_parser_root_get(const sx_api_handle_t          handle,
                                        const sx_access_cmd_t          cmd,
                                        const sx_port_log_id_t         log_port,
                                        sx_flex_parser_root_sop_cfg_t *root_cfg_list_p,
                                        uint32_t                      *root_cfg_cnt_p)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_root_get_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = 0;
    uint32_t                              cfg_cnt = 0;

    SX_API_LOG_ENTER();

    if (root_cfg_cnt_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer root_cfg_cnt_p\n");
        goto out;
    }

    cfg_cnt = *root_cfg_cnt_p;
    if (root_cfg_list_p == NULL) {
        cfg_cnt = 0;
    }

    /* Allocate command body */
    cmd_size = sizeof(sx_api_flex_parser_root_get_params_t);
    cmd_size += (sizeof(sx_flex_parser_root_sop_cfg_t) * cfg_cnt);

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size [%u] for flex parser root get exceeds range.\n", cmd_size);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    cmd_body_p = (sx_api_flex_parser_root_get_params_t*)cl_calloc(1, cmd_size);
    if (!cmd_body_p) {
        SX_LOG_ERR("Failed to allocate memory for flex parser root get command body\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->log_port = log_port;
    cmd_body_p->root_cfg_cnt = cfg_cnt;
    if (cfg_cnt > 0) {
        SX_MEM_CPY_ARRAY(&cmd_body_p->root_cfg_list[0], root_cfg_list_p, cfg_cnt, sx_flex_parser_root_sop_cfg_t);
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_ROOT_GET_E,
                                     (uint8_t*)cmd_body_p,
                                     cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get flex parser root - [%s]\n", sx_status_str(rc));
        goto out;
    }

    if (cfg_cnt == 0) {
        /* We return the number of entries we have for root configurations */
        cfg_cnt = cmd_body_p->root_cfg_cnt;
    } else {
        cfg_cnt = (cfg_cnt > cmd_body_p->root_cfg_cnt) ? cmd_body_p->root_cfg_cnt : cfg_cnt;
        if (cfg_cnt > 0) {
            SX_MEM_CPY_ARRAY(root_cfg_list_p, &cmd_body_p->root_cfg_list[0], cfg_cnt, sx_flex_parser_root_sop_cfg_t);
        }
    }
    *root_cfg_cnt_p = cfg_cnt;

out:
    if (cmd_body_p != NULL) {
        CL_FREE_N_NULL(cmd_body_p);
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_flex_parser_hph_set(const sx_api_handle_t         handle,
                                       const sx_access_cmd_t         cmd,
                                       const sx_flex_parser_hph_id_t hph_id,
                                       const sx_flex_parser_hph_t   *hph_cfg_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_hph_set_params_t cmd_body;
    uint32_t                            cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, cmd_size);
    cmd_body.cmd = cmd;
    cmd_body.hph_id = hph_id;

    if (cmd != SX_ACCESS_CMD_UNSET) {
        if (hph_cfg_p == NULL) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Invalid NULL pointer hph_cfg_p\n");
            goto out;
        }
        cmd_body.hph_cfg = *hph_cfg_p;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_HPH_SET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set HPH - [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_flex_parser_hph_get(const sx_api_handle_t         handle,
                                       const sx_access_cmd_t         cmd,
                                       const sx_flex_parser_hph_id_t hph_id,
                                       sx_flex_parser_hph_t         *hph_cfg_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_hph_get_params_t cmd_body;
    uint32_t                            cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, cmd_size);
    cmd_body.cmd = cmd;
    cmd_body.hph_id = hph_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_HPH_GET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get HPH - [%s]\n", sx_status_str(rc));
        goto out;
    }

    if (hph_cfg_p != NULL) {
        *hph_cfg_p = cmd_body.hph_cfg;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_flex_parser_fexp_set(const sx_api_handle_t     handle,
                                        const sx_access_cmd_t     cmd,
                                        sx_flex_parser_fexp_id_t *fexp_id_p)
{
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_fexp_set_params_t cmd_body;
    uint32_t                             cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, cmd_size);
    cmd_body.cmd = cmd;
    cmd_body.fexp_id = *fexp_id_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_FEXP_SET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set FEXP - [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_flex_parser_resources_get(const sx_api_handle_t       handle,
                                             const sx_access_cmd_t       cmd,
                                             sx_flex_parser_resources_t *flex_parser_resources_p)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_resources_get_params_t cmd_body;
    uint32_t                                  cmd_size = sizeof(cmd_body);

    if (flex_parser_resources_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer flex_parser_resources\n");
        goto out;
    }

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, cmd_size);
    cmd_body.cmd = cmd;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_RESOURCES_GET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get flex parser resources - [%s]\n", sx_status_str(rc));
        goto out;
    }

    *flex_parser_resources_p = cmd_body.flex_parser_resources;

out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_flex_parser_reg_ext_point_set(const sx_api_handle_t        handle,
                                                 const sx_access_cmd_t        cmd,
                                                 const sx_register_key_t      reg_key,
                                                 const sx_extraction_point_t *ext_point_list_p,
                                                 const uint32_t              *ext_point_cnt_p)
{
    sx_status_t                                   rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_reg_ext_point_set_params_t cmd_body;
    uint32_t                                      cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, cmd_size);

    cmd_body.cmd = cmd;
    cmd_body.reg_key = reg_key;

    if (cmd == SX_ACCESS_CMD_SET) {
        if (ext_point_cnt_p == NULL) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Invalid NULL pointer ext_point_cnt_p\n");
            goto out;
        }

        if ((*ext_point_cnt_p == 0) || (*ext_point_cnt_p > RM_API_FLEX_PARSER_EXT_POINT_MAX_NUM)) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid value ext_point_cnt_p: %d, valid range: [%d,%d]\n",
                       *ext_point_cnt_p, 1, RM_API_FLEX_PARSER_EXT_POINT_MAX_NUM);
            goto out;
        }

        if (ext_point_list_p == NULL) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Invalid NULL pointer ext_point_list_p\n");
            goto out;
        }
        cmd_body.ext_point_cnt = *ext_point_cnt_p;
        SX_MEM_CPY_ARRAY(cmd_body.ext_point_list, ext_point_list_p, cmd_body.ext_point_cnt, sx_extraction_point_t);
    } else {
        cmd_body.ext_point_cnt = 0;
        memset(&cmd_body.ext_point_list, 0, sizeof(cmd_body.ext_point_list));
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_REG_EXT_POINT_SET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set extraction point - [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_flex_parser_reg_ext_point_get(const sx_api_handle_t   handle,
                                                 const sx_register_key_t reg_key,
                                                 sx_extraction_point_t  *ext_point_list_p,
                                                 uint32_t               *ext_point_cnt_p)
{
    sx_status_t                                   rc = SX_STATUS_SUCCESS;
    sx_api_flex_parser_reg_ext_point_get_params_t cmd_body;
    uint32_t                                      cmd_size = sizeof(cmd_body);

    SX_API_LOG_ENTER();

    memset(&cmd_body, 0, cmd_size);

    if (ext_point_list_p != NULL) {
        cmd_body.cmd = SX_ACCESS_CMD_GET;
    } else {
        cmd_body.cmd = SX_ACCESS_CMD_COUNT;
    }

    if (ext_point_cnt_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Invalid NULL pointer ext_point_cnt_p\n");
        goto out;
    }

    cmd_body.reg_key = reg_key;
    cmd_body.ext_point_cnt = *ext_point_cnt_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FLEX_PARSER_REG_EXT_POINT_GET_E,
                                     (uint8_t*)&cmd_body,
                                     cmd_size);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get extraction point - [%s]\n", sx_status_str(rc));
        goto out;
    }

    *ext_point_cnt_p = cmd_body.ext_point_cnt;

    if (ext_point_list_p != NULL) {
        SX_MEM_CPY_ARRAY(ext_point_list_p, cmd_body.ext_point_list, cmd_body.ext_point_cnt, sx_extraction_point_t);
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}
