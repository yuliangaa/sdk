/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_span.h>
#include <sx/sdk/sx_swid.h>
#include <sx/sdk/sx_strings.h>
#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_SPAN

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;


/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sx_api_span_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                const sx_verbosity_level_t      module_verbosity_level,
                                                const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_SPAN_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_span_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                sx_verbosity_level_t           *module_verbosity_level_p,
                                                sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_SPAN_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

/*
 * This function checks that the SPAN format type is in range such that it may
 * be supported for some device.  Device-specific checking is performed in the
 * SPAN module.
 */
static sx_status_t __validate_span_type_format(const sx_span_session_params_t *span_session_params)
{
    if ((span_session_params->span_type < SX_SPAN_TYPE_MIN) ||
        (span_session_params->span_type > SX_SPAN_TYPE_MAX)) {
        return SX_STATUS_PARAM_ERROR;
    } else {
        return SX_STATUS_SUCCESS;
    }
}


static sx_status_t __validate_span_header_padding(const sx_span_session_params_t *span_session_params)
{
    if ((span_session_params->padding < SX_SPAN_HEADER_PADDING_MIN_E) ||
        (span_session_params->padding > SX_SPAN_HEADER_PADDING_MAX_E)) {
        SX_LOG_ERR("SPAN Session padding Mirror Header param [%d] is out of range\n", span_session_params->padding);
        return SX_STATUS_PARAM_ERROR;
    } else {
        return SX_STATUS_SUCCESS;
    }
}

sx_status_t sx_api_span_session_set(const sx_api_handle_t           handle,
                                    const sx_access_cmd_t           cmd,
                                    const sx_span_session_params_t *span_session_params_p,
                                    sx_span_session_id_t           *span_session_id_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_api_span_session_set_params_t cmd_body;
    uint32_t                         cmd_size = sizeof(sx_api_span_session_set_params_t);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((span_session_id_p == NULL) || (span_session_params_p == NULL)) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if ((cmd == SX_ACCESS_CMD_CREATE) || (cmd == SX_ACCESS_CMD_EDIT)) {
        if (SX_SPAN_TYPE_CHECK_RANGE(span_session_params_p->span_type) == FALSE) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }

        if (__validate_span_type_format(span_session_params_p) != SX_STATUS_SUCCESS) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }

        if (__validate_span_header_padding(span_session_params_p) != SX_STATUS_SUCCESS) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
    }

    cmd_body.cmd = cmd;
    cmd_body.span_session_params = *span_session_params_p;
    cmd_body.span_session_id = *span_session_id_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_SESSION_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *span_session_id_p = cmd_body.span_session_id;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_session_get(const sx_api_handle_t      handle,
                                    const sx_span_session_id_t span_session_id,
                                    sx_span_session_params_t  *span_session_params_p)
{
    sx_api_span_session_get_params_t cmd_body;
    uint32_t                         cmd_size = sizeof(sx_api_span_session_get_params_t);
    sx_status_t                      rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (span_session_params_p == NULL) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.span_session_id = span_session_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_SESSION_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *span_session_params_p = cmd_body.span_session_params;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_session_iter_get(const sx_api_handle_t       handle,
                                         const sx_access_cmd_t       cmd,
                                         const sx_span_session_id_t *span_session_key_p,
                                         const sx_span_filter_t     *filter_p,
                                         sx_span_session_id_t       *span_session_list_p,
                                         uint32_t                   *span_session_cnt_p)
{
    sx_api_span_session_iter_get_params_t *cmd_body = NULL;
    sx_status_t                            err = SX_STATUS_SUCCESS;
    uint32_t                               reply_body_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (span_session_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Span Session Counter pointer is NULL. Cannot proceed\n");
        goto out;
    }
    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*span_session_cnt_p > 1) {
            *span_session_cnt_p = 1;
            SX_LOG(SX_LOG_NOTICE, "Force count to be 1 for %s \n",
                   sx_access_cmd_str(cmd));
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        break;

    case SX_ACCESS_CMD_GETNEXT:
        if ((*span_session_cnt_p > 0) && (span_session_key_p == NULL)) {
            /* get next requires non null key */
            err = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Invalid! Span session key is NULL for Cmd = %s\n",
                       sx_access_cmd_str(cmd));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
        break;
    }

    /* malloc the cmd body. We will use the same body for the reply also*/
    reply_body_size = sizeof(sx_api_span_session_iter_get_params_t) +
                      ((*span_session_cnt_p) * sizeof(sx_span_session_id_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, reply_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for Span Session List reply msg.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->span_session_list_cnt = *span_session_cnt_p;


    if (span_session_key_p == NULL) {
        cmd_body->span_session_key = 0;
        SX_LOG(SX_LOG_DEBUG, "[%s]span_session_key_p is Null. Set cmd key = %d\n", __func__,
               cmd_body->span_session_key);
    } else {
        cmd_body->span_session_key = *span_session_key_p;
    }

    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body->filter), filter_p, sx_span_filter_t);
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_SPAN_SESSION_ITER_GET_E,
                                      (uint8_t*)cmd_body,
                                      reply_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "[%s]SDK Core RPC failed with rc = %s \n", __func__,
               sx_status_str(err));
        goto out;
    }

    *span_session_cnt_p = cmd_body->span_session_list_cnt;

    if (*span_session_cnt_p != 0) {
        if (span_session_list_p != NULL) {
            SX_MEM_CPY_ARRAY(span_session_list_p, cmd_body->span_session_list,
                             cmd_body->span_session_list_cnt, sx_router_interface_t);
        }
    }

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_span_session_trap_id_get(const sx_api_handle_t      handle,
                                            const sx_span_session_id_t span_session_id,
                                            sx_trap_id_t              *trap_id_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    UNUSED_PARAM(handle);

    if (trap_id_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Trap ID pointer is NULL\n");
        goto out;
    }

    *trap_id_p = SX_TRAP_ID_MIRROR_AGENT(span_session_id);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_span_session_state_set(const sx_api_handle_t      handle,
                                          const sx_span_session_id_t span_session_id,
                                          const boolean_t            admin_state)
{
    sx_api_command_head_t                  cmd_head;
    sx_api_span_session_state_set_params_t cmd_body;
    sx_api_reply_head_t                    reply_head;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (SX_CHECK_BOOLEAN(admin_state) == FALSE) {
        SX_LOG_ERR("SPAN Session admin_state (%d) exceed range.\n", admin_state);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_SPAN_SESSION_STATE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_span_session_state_set_params_t);

    cmd_body.span_session_id = span_session_id;
    cmd_body.admin_state = admin_state;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_span_session_state_get(const sx_api_handle_t      handle,
                                          const sx_span_session_id_t span_session_id,
                                          boolean_t                 *admin_state_p)
{
    sx_api_span_session_state_get_params_t cmd_body;
    uint32_t                               cmd_size = sizeof(sx_api_span_session_state_get_params_t);
    sx_status_t                            rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (admin_state_p == NULL) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.span_session_id = span_session_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_SESSION_STATE_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *admin_state_p = cmd_body.admin_state;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_session_state_ext_get(const sx_api_handle_t        handle,
                                              const sx_span_session_id_t   span_session_id,
                                              sx_span_session_state_ext_t *span_session_state_p)
{
    sx_api_span_session_state_ext_get_params_t cmd_body;
    uint32_t                                   cmd_size = sizeof(sx_api_span_session_state_ext_get_params_t);
    sx_status_t                                rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (span_session_state_p == NULL) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.span_session_id = span_session_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_SESSION_STATE_EXT_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *span_session_state_p = cmd_body.span_session_state_ext;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_session_analyzer_get(const sx_api_handle_t      handle,
                                             const sx_span_session_id_t span_session_id,
                                             sx_port_log_id_t          *analyzer_port_p)
{
    sx_api_span_session_analyzer_get_params_t cmd_body;
    uint32_t                                  cmd_size = sizeof(sx_api_span_session_analyzer_get_params_t);
    sx_status_t                               rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (analyzer_port_p == NULL) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.span_session_id = span_session_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_SESSION_ANALYZER_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *analyzer_port_p = cmd_body.analyzer_port;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_session_mirror_get(const sx_api_handle_t      handle,
                                           const sx_span_session_id_t span_session_id,
                                           sx_span_mirror_t          *mirror_ports_list_p,
                                           uint32_t                  *mirror_ports_cnt_p)
{
    sx_api_span_session_mirror_get_params_t *cmd_body = NULL;
    uint32_t                                 cmd_size = sizeof(sx_api_span_session_mirror_get_params_t);
    uint32_t                                 i = 0;
    sx_status_t                              mem_rc = SX_STATUS_SUCCESS;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (mirror_ports_cnt_p == NULL) {
        SX_LOG_ERR("mirror_ports_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*mirror_ports_cnt_p > 0) && (mirror_ports_list_p == NULL)) {
        SX_LOG_ERR("mirror_ports_cnt_p > 0 but mirror_ports_list_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_size += (*mirror_ports_cnt_p) * sizeof(sx_span_mirror_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->span_session_id = span_session_id;
    cmd_body->mirrors_num = *mirror_ports_cnt_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_SESSION_MIRROR_GET_E,
                                      (uint8_t*)cmd_body, cmd_size);

    if (SX_CHECK_PASS(err)) {
        for (i = 0; i < cmd_body->mirrors_num && *mirror_ports_cnt_p > 0; ++i) {
            mirror_ports_list_p[i] = cmd_body->mirrors_arr[i];
        }

        *mirror_ports_cnt_p = cmd_body->mirrors_num;
    }

    M_UTILS_MEM_PUT(cmd_body, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        err = mem_rc;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_span_mirror_set(const sx_api_handle_t       handle,
                                   const sx_access_cmd_t       cmd,
                                   const sx_port_log_id_t      mirror_port,
                                   const sx_mirror_direction_t mirror_direction,
                                   const sx_span_session_id_t  span_session_id)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    sx_api_span_mirror_set_params_t cmd_body;
    uint32_t                        cmd_size = sizeof(sx_api_span_mirror_set_params_t);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_body.cmd = cmd;
    cmd_body.mirror.log_port = mirror_port;
    cmd_body.mirror.mirror_direction = mirror_direction;
    cmd_body.span_session_id = span_session_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_get(const sx_api_handle_t       handle,
                                   const sx_port_log_id_t      mirror_port,
                                   const sx_mirror_direction_t mirror_direction,
                                   sx_span_session_id_t       *span_session_id_p)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    sx_api_span_mirror_get_params_t cmd_body;
    uint32_t                        cmd_size = sizeof(sx_api_span_mirror_get_params_t);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (span_session_id_p == NULL) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.mirror.log_port = mirror_port;
    cmd_body.mirror.mirror_direction = mirror_direction;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *span_session_id_p = cmd_body.span_session_id;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_state_set(const sx_api_handle_t       handle,
                                         const sx_port_log_id_t      mirror_port,
                                         const sx_mirror_direction_t mirror_direction,
                                         const boolean_t             admin_state)
{
    sx_api_span_mirror_state_set_params_t cmd_body;
    uint32_t                              cmd_size = sizeof(sx_api_span_mirror_state_set_params_t);
    sx_status_t                           rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (SX_CHECK_BOOLEAN(admin_state) == FALSE) {
        SX_LOG_ERR("SPAN Mirror Admin State (%d) exceed range.\n", admin_state);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body.mirror.log_port = mirror_port;
    cmd_body.mirror.mirror_direction = mirror_direction;
    cmd_body.admin_state = admin_state;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_STATE_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_state_get(const sx_api_handle_t       handle,
                                         const sx_port_log_id_t      mirror_port,
                                         const sx_mirror_direction_t mirror_direction,
                                         boolean_t                  *admin_state_p)
{
    sx_api_span_mirror_state_get_params_t cmd_body;
    uint32_t                              cmd_size = sizeof(sx_api_span_mirror_state_get_params_t);
    sx_status_t                           rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (admin_state_p == NULL) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.mirror.log_port = mirror_port;
    cmd_body.mirror.mirror_direction = mirror_direction;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_STATE_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *admin_state_p = cmd_body.admin_state;
    }

    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_span_analyzer_set(const sx_api_handle_t                 handle,
                                     const sx_access_cmd_t                 cmd,
                                     const sx_port_log_id_t                log_port,
                                     const sx_span_analyzer_port_params_t *port_params_p,
                                     const sx_span_session_id_t            span_session_id)
{
    sx_api_span_analyzer_set_params_t cmd_body;
    uint32_t                          cmd_size = sizeof(sx_api_span_analyzer_set_params_t);
    sx_status_t                       rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (port_params_p == NULL) {
        SX_LOG_ERR("port_params_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    cmd_body.port_params = *port_params_p;
    cmd_body.span_session_id = span_session_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_ANALYZER_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_analyzer_get(const sx_api_handle_t           handle,
                                     const sx_port_log_id_t          log_port,
                                     sx_span_analyzer_port_params_t *port_params_p,
                                     sx_span_session_id_t           *span_session_id_list_p,
                                     uint32_t                       *span_sessions_cnt_p)
{
    sx_api_span_analyzer_get_params_t *cmd_body = NULL;
    uint32_t                           cmd_size = sizeof(sx_api_span_analyzer_get_params_t);
    uint32_t                           i = 0;
    sx_status_t                        mem_rc = SX_STATUS_SUCCESS;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (span_sessions_cnt_p == NULL) {
        SX_LOG_ERR("span_sessions_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*span_sessions_cnt_p > 0) && (span_session_id_list_p == NULL)) {
        SX_LOG_ERR("span_sessions_cnt_p > 0 but span_session_id_list_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_size += (*span_sessions_cnt_p) * sizeof(sx_span_session_id_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->log_port = log_port;
    cmd_body->span_sessions_num = *span_sessions_cnt_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_ANALYZER_GET_E,
                                      (uint8_t*)cmd_body, cmd_size);

    if (SX_CHECK_PASS(err)) {
        for (i = 0; i < cmd_body->span_sessions_num && *span_sessions_cnt_p > 0; ++i) {
            span_session_id_list_p[i] = cmd_body->span_session_id_arr[i];
        }

        *span_sessions_cnt_p = cmd_body->span_sessions_num;
        if (port_params_p != NULL) {
            *port_params_p = cmd_body->port_params;
        }
    }

    M_UTILS_MEM_PUT(cmd_body, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        err = mem_rc;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_span_init_set(sx_api_handle_t handle, sx_span_init_params_t   *init_params_p)
{
    sx_api_span_init_params_t cmd_body;
    uint32_t                  cmd_size = sizeof(sx_api_span_init_params_t);
    sx_status_t               rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (init_params_p == NULL) {
        SX_LOG_ERR("init_params_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.init_params = *init_params_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_INIT_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_deinit_set(sx_api_handle_t handle)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_DEINIT_SET_E,
                                     NULL, 0);

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_session_counter_get(const sx_api_handle_t      handle,
                                            const sx_access_cmd_t      cmd,
                                            const sx_span_session_id_t span_session_id,
                                            sx_span_counter_set_t     *counter_set_p)
{
    sx_api_span_session_counter_get_params_t cmd_body;
    uint32_t                                 cmd_size = sizeof(sx_api_span_session_counter_get_params_t);
    sx_status_t                              rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (counter_set_p == NULL) {
        SX_LOG_ERR("counter_set_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.cmd = cmd;
    cmd_body.span_session_id = span_session_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_SESSION_COUNTER_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *counter_set_p = cmd_body.counter_set;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_tables_set(const sx_api_handle_t      handle,
                                          const sx_access_cmd_t      cmd,
                                          const sx_span_session_id_t span_session_id)
{
    sx_api_span_mirror_tables_set_params_t cmd_body;
    uint32_t                               cmd_size = sizeof(sx_api_span_mirror_tables_set_params_t);
    sx_status_t                            rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_body.cmd = cmd;
    cmd_body.span_session_id = span_session_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_TABLES_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_tables_get(const sx_api_handle_t handle, sx_span_session_id_t   *span_session_id_p)
{
    sx_api_span_mirror_tables_get_params_t cmd_body;
    uint32_t                               cmd_size = sizeof(sx_api_span_mirror_tables_get_params_t);
    sx_status_t                            rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (span_session_id_p == NULL) {
        SX_LOG_ERR("span_session_id_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_TABLES_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *span_session_id_p = cmd_body.span_session_id;
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_drop_mirror_set(const sx_api_handle_t                handle,
                                        const sx_access_cmd_t                cmd,
                                        const sx_span_session_id_t           span_session_id,
                                        const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                        const sx_span_drop_reason_t         *drop_reason_list_p,
                                        const uint32_t                       drop_reason_cnt)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_api_span_drop_mirror_set_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = 0;
    uint32_t                              list_count = 0;

    SX_API_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        list_count = drop_reason_cnt;
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        list_count = 0;
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_size = sizeof(*cmd_body_p);
    cmd_size += sizeof(sx_span_drop_reason_t) * list_count;
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = (sx_api_span_drop_mirror_set_params_t*)cl_malloc(cmd_size);
    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_span_drop_mirror_set_params_t);

    cmd_body_p->cmd = cmd;
    cmd_body_p->span_session_id = span_session_id;
    if (drop_mirroring_attr_p != NULL) {
        cmd_body_p->drop_mirror_attributes = *drop_mirroring_attr_p;
    }
    if (list_count > 0) {
        SX_MEM_CPY_ARRAY(cmd_body_p->drop_reason_list, drop_reason_list_p,
                         list_count, sx_span_drop_reason_t);
    }
    cmd_body_p->drop_reason_count = list_count;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_DROP_MIRROR_SET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    CL_FREE_N_NULL(cmd_body_p);
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_drop_mirror_get(const sx_api_handle_t          handle,
                                        const sx_span_session_id_t     span_session_id,
                                        sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                        sx_span_drop_reason_t         *drop_reason_list_p,
                                        uint32_t                      *drop_reason_cnt_p)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_api_span_drop_mirror_get_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = 0;
    uint32_t                              max_count = 0;

    SX_API_LOG_ENTER();

    if (drop_reason_cnt_p == NULL) {
        SX_LOG_ERR("drop_reason_cnt_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if ((*drop_reason_cnt_p > 0) && (drop_reason_list_p == NULL)) {
        SX_LOG_ERR("drop_reason count > 0 but drop_reason_list_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }
    max_count = MIN(*drop_reason_cnt_p, SX_SPAN_DROP_REASON_COUNT);

    cmd_size = sizeof(*cmd_body_p) + (max_count * sizeof(*drop_reason_list_p));
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = (sx_api_span_drop_mirror_get_params_t*)cl_malloc(cmd_size);
    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_span_drop_mirror_get_params_t);

    cmd_body_p->span_session_id = span_session_id;
    cmd_body_p->drop_reason_count = max_count;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_DROP_MIRROR_GET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "[%s]SDK Core RPC failed with rc = %s\n", __func__, sx_status_str(rc));
        goto out;
    }

    *drop_reason_cnt_p = cmd_body_p->drop_reason_count;
    if (drop_mirroring_attr_p != NULL) {
        *drop_mirroring_attr_p = cmd_body_p->drop_mirror_attributes;
    }
    if ((drop_reason_list_p != NULL) && (cmd_body_p->drop_reason_count > 0)) {
        SX_MEM_CPY_ARRAY(drop_reason_list_p, cmd_body_p->drop_reason_list,
                         cmd_body_p->drop_reason_count, sx_span_drop_reason_t);
    }

out:
    CL_FREE_N_NULL(cmd_body_p);
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_bind_set(const sx_api_handle_t             handle,
                                        const sx_access_cmd_t             cmd,
                                        const sx_span_mirror_bind_key_t  *key_p,
                                        const sx_span_mirror_bind_attr_t *attr_p)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_api_span_mirror_bind_set_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = 0;

    SX_API_LOG_ENTER();

    if (key_p == NULL) {
        SX_LOG_ERR("key_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
    case SX_ACCESS_CMD_UNBIND:
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_size = sizeof(*cmd_body_p);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = (sx_api_span_mirror_bind_set_params_t*)cl_malloc(cmd_size);
    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_span_mirror_bind_set_params_t);

    cmd_body_p->cmd = cmd;
    cmd_body_p->key = *key_p;
    cmd_body_p->attr = *attr_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_BIND_SET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    CL_FREE_N_NULL(cmd_body_p);
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_bind_get(const sx_api_handle_t            handle,
                                        const sx_span_mirror_bind_key_t *key_p,
                                        sx_span_mirror_bind_attr_t      *attr_p)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_api_span_mirror_bind_get_params_t *cmd_body_p = NULL;
    uint32_t                              cmd_size = 0;

    SX_API_LOG_ENTER();

    if (key_p == NULL) {
        SX_LOG_ERR("key_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_size = sizeof(*cmd_body_p);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_p = (sx_api_span_mirror_bind_get_params_t*)cl_malloc(cmd_size);
    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_span_mirror_bind_get_params_t);

    cmd_body_p->key = *key_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_BIND_GET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "[%s]SDK Core RPC failed with rc = %s\n", __func__, sx_status_str(rc));
        goto out;
    }

    *attr_p = cmd_body_p->attr;

out:
    CL_FREE_N_NULL(cmd_body_p);
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_session_mirror_bound_get(const sx_api_handle_t      handle,
                                                 const sx_span_session_id_t span_session_id,
                                                 sx_span_mirror_bind_key_t *mirror_bind_key_list_p,
                                                 uint32_t                  *mirror_bind_key_cnt_p)
{
    sx_api_span_session_mirror_bound_get_params_t *cmd_body = NULL;
    uint32_t                                       cmd_size = sizeof(sx_api_span_session_mirror_bound_get_params_t);
    uint32_t                                       i = 0;
    sx_status_t                                    mem_rc = SX_STATUS_SUCCESS;
    sx_status_t                                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (mirror_bind_key_cnt_p == NULL) {
        SX_LOG_ERR("mirror_bind_key_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*mirror_bind_key_cnt_p > 0) && (mirror_bind_key_list_p == NULL)) {
        SX_LOG_ERR("mirror_bind_key_cnt_p > 0 but mirror_bind_key_list_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_size += (*mirror_bind_key_cnt_p) * sizeof(sx_span_mirror_bind_key_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->span_session_id = span_session_id;
    cmd_body->mirror_bind_key_cnt = *mirror_bind_key_cnt_p;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_SESSION_MIRROR_BOUND_GET_E,
                                      (uint8_t*)cmd_body, cmd_size);

    if (SX_CHECK_PASS(err)) {
        for (i = 0; i < cmd_body->mirror_bind_key_cnt && *mirror_bind_key_cnt_p > 0; ++i) {
            mirror_bind_key_list_p[i] = cmd_body->mirror_bind_key_list[i];
        }

        *mirror_bind_key_cnt_p = cmd_body->mirror_bind_key_cnt;
    }

    M_UTILS_MEM_PUT(cmd_body, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        err = mem_rc;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_span_mirror_enable_set(const sx_api_handle_t                 handle,
                                          const sx_access_cmd_t                 cmd,
                                          const sx_span_mirror_enable_object_t *object_p,
                                          const sx_span_mirror_enable_attr_t   *attr_p)
{
    sx_status_t                             rc = SX_STATUS_SUCCESS;
    sx_api_span_mirror_enable_set_params_t *cmd_body_p = NULL;
    uint32_t                                cmd_size = 0;

    SX_API_LOG_ENTER();

    if (object_p == NULL) {
        SX_LOG_ERR("object_p is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");

        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
    case SX_ACCESS_CMD_DELETE:
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_size = sizeof(*cmd_body_p);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = (sx_api_span_mirror_enable_set_params_t*)cl_malloc(cmd_size);
    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_span_mirror_enable_set_params_t);

    cmd_body_p->cmd = cmd;
    cmd_body_p->object = *object_p;
    cmd_body_p->attr = *attr_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_ENABLE_SET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    CL_FREE_N_NULL(cmd_body_p);
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_enable_get(const sx_api_handle_t                 handle,
                                          const sx_span_mirror_enable_object_t *object_p,
                                          sx_span_mirror_enable_attr_t         *attr_p)
{
    sx_status_t                             rc = SX_STATUS_SUCCESS;
    sx_api_span_mirror_enable_get_params_t *cmd_body_p = NULL;
    uint32_t                                cmd_size = 0;

    SX_API_LOG_ENTER();

    if (object_p == NULL) {
        SX_LOG_ERR("object_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_size = sizeof(*cmd_body_p);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_p = (sx_api_span_mirror_enable_get_params_t*)cl_malloc(cmd_size);
    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_span_mirror_enable_get_params_t);

    cmd_body_p->object = *object_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_ENABLE_GET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "[%s]SDK Core RPC failed with rc = %s\n", __func__, sx_status_str(rc));
        goto out;
    }

    *attr_p = cmd_body_p->attr;

out:
    CL_FREE_N_NULL(cmd_body_p);
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_enable_iter_get(const sx_api_handle_t                handle,
                                               const sx_access_cmd_t                cmd,
                                               sx_span_mirror_enable_object_t      *object_key_p,
                                               sx_span_mirror_enable_iter_filter_t *filter_p,
                                               sx_span_mirror_enable_object_t      *object_list_p,
                                               uint32_t                            *object_cnt_p)
{
    sx_api_span_mirror_enable_iter_get_params_t *cmd_body = NULL;
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    uint32_t                                     reply_body_size = 0;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (object_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Span mirror enable Counter pointer is NULL. Cannot proceed\n");
        goto out;
    }
    if (object_key_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Span mirror enable object key pointer is NULL. Cannot proceed\n");
        goto out;
    }
    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*object_cnt_p > 1) {
            *object_cnt_p = 1;
            SX_LOG(SX_LOG_NOTICE, "Force count to be 1 for %s \n",
                   sx_access_cmd_str(cmd));
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
        break;
    }

    /* malloc the cmd body. We will use the same body for the reply also*/
    reply_body_size = sizeof(sx_api_span_mirror_enable_iter_get_params_t) +
                      ((*object_cnt_p) * sizeof(sx_span_mirror_enable_object_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, reply_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for Span mirror enable object List reply msg.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->object_cnt = *object_cnt_p;
    cmd_body->object_key = *object_key_p;

    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body->filter), filter_p, sx_span_mirror_enable_iter_filter_t);
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_SPAN_MIRROR_ENABLE_ITER_GET_E,
                                      (uint8_t*)cmd_body,
                                      reply_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "[%s]SDK Core RPC failed with rc = %s \n", __func__,
               sx_status_str(err));
        goto out;
    }

    *object_cnt_p = cmd_body->object_cnt;

    if (*object_cnt_p != 0) {
        if (object_list_p != NULL) {
            SX_MEM_CPY_ARRAY(object_list_p, cmd_body->object_list,
                             cmd_body->object_cnt, sx_span_mirror_enable_object_t);
        }
    }

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_span_header_time_stamp_set(const sx_api_handle_t   handle,
                                              const sx_access_cmd_t   cmd,
                                              sx_span_hdr_ts_config_t span_hdr_ts)
{
    sx_api_span_header_time_stamp_set_params_t cmd_body;
    uint32_t                                   cmd_size = sizeof(sx_api_span_header_time_stamp_set_params_t);
    sx_status_t                                rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (cmd != SX_ACCESS_CMD_SET) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(rc));
        goto out;
    }

    cmd_body.span_hdr_ts_config = span_hdr_ts;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_HEADER_TIME_STAMP_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_session_policer_bind_set(const sx_api_handle_t      handle,
                                                 const sx_access_cmd_t      cmd,
                                                 const sx_span_session_id_t span_session_id,
                                                 const sx_policer_id_t      policer_id)
{
    sx_api_span_policer_bind_set_params_t cmd_body;
    uint32_t                              cmd_size = sizeof(sx_api_span_policer_bind_set_params_t);
    sx_status_t                           rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_BIND) && (cmd != SX_ACCESS_CMD_UNBIND)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(rc));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.span_session_id = span_session_id;
    cmd_body.policer_id = policer_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_SESSION_POLICER_BIND_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_session_policer_bind_get(const sx_api_handle_t      handle,
                                                 const sx_span_session_id_t span_session_id,
                                                 sx_policer_id_t           *policer_id_p)
{
    sx_api_span_policer_bind_get_params_t cmd_body;
    uint32_t                              cmd_size = sizeof(sx_api_span_policer_bind_get_params_t);
    sx_status_t                           rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (policer_id_p == NULL) {
        SX_LOG_ERR("policer_id_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.span_session_id = span_session_id;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_SESSION_POLICER_BIND_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *policer_id_p = cmd_body.policer_id;
    } else {
        *policer_id_p = SX_POLICER_ID_INVALID;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_attributes_set(const sx_api_handle_t handle, sx_span_attrs_t *span_attrs_p)
{
    sx_api_span_attributes_set_params_t cmd_body;
    uint32_t                            cmd_size = sizeof(sx_api_span_attributes_set_params_t);
    sx_status_t                         rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (span_attrs_p == NULL) {
        SX_LOG_ERR("span_attrs_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.attr.device_uid = span_attrs_p->device_uid;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_ATTRIBUTES_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_attributes_get(const sx_api_handle_t handle, sx_span_attrs_t        *span_attrs_p)
{
    sx_api_span_attributes_get_params_t cmd_body;
    uint32_t                            cmd_size = sizeof(sx_api_span_attributes_get_params_t);
    sx_status_t                         rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (span_attrs_p == NULL) {
        SX_LOG_ERR("span_attrs_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_ATTRIBUTES_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *span_attrs_p = cmd_body.attr;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_span_port_attr_set(const sx_api_handle_t  handle,
                                      const sx_port_log_id_t log_port,
                                      sx_span_port_attr_t   *span_port_attr_list_p,
                                      uint32_t               span_port_attr_list_size)
{
    sx_api_span_port_attr_set_params_t *cmd_body_p = NULL;
    uint32_t                            cmd_size = sizeof(sx_api_span_port_attr_set_params_t);
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    unsigned int                        i;

    SX_API_LOG_ENTER();

    if (span_port_attr_list_p == NULL) {
        SX_LOG_ERR("span_port_attr_list_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (span_port_attr_list_size > SPAN_PORT_ATTR_MAX_NUM) {
        SX_LOG_ERR("num of attr %d exceeds max %d \n",
                   span_port_attr_list_size, SPAN_PORT_ATTR_MAX_NUM);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (span_port_attr_list_size == 0) {
        SX_LOG_ERR("wrong num of attr %d , should be > 0 \n",
                   span_port_attr_list_size);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_size += (span_port_attr_list_size) * sizeof(sx_span_port_attr_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    cmd_body_p->log_port = log_port;
    cmd_body_p->span_port_attr_list_size = span_port_attr_list_size;
    for (i = 0; i < span_port_attr_list_size; i++) {
        cmd_body_p->span_port_attr_list_p[i] = span_port_attr_list_p[i];
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_PORT_ATTR_SET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to Free cmd_body_p memory\n", rc);
    }
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_span_port_attr_get(const sx_api_handle_t    handle,
                                      const sx_port_log_id_t   log_port,
                                      sx_span_port_attr_type_e attr_type,
                                      sx_span_port_attr_t     *span_port_attr_p)
{
    sx_api_span_port_attr_get_params_t cmd_body;
    uint32_t                           cmd_size = sizeof(sx_api_span_port_attr_get_params_t);
    sx_status_t                        rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (span_port_attr_p == NULL) {
        SX_LOG_ERR("span_port_attr_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.log_port = log_port;
    cmd_body.attr_type = attr_type;

    if (attr_type == SX_SPAN_PORT_ATTR_PROBABILITY_RATE_E) {
        cmd_body.span_port_attr.attr.probability_rate.key.mirror_direction =
            span_port_attr_p->attr.probability_rate.key.mirror_direction;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_PORT_ATTR_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);
    if (rc) {
        SX_LOG_ERR("SX_API_INT_CMD_SPAN_PORT_ATTR_GET_E failed with err:%s \n",
                   sx_status_str(rc));
        goto out;
    }

    *span_port_attr_p = cmd_body.span_port_attr;

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_enable_port_set(const sx_api_handle_t             handle,
                                               const sx_access_cmd_t             cmd,
                                               sx_span_mirror_enable_port_set_t *mirror_enable_cfg_list_p,
                                               const uint32_t                    mirror_enable_cnt)
{
    sx_status_t                                  rc = SX_STATUS_SUCCESS;
    sx_api_span_mirror_enable_port_set_params_t *cmd_body_p = NULL;
    uint32_t                                     cmd_size = 0;
    uint32_t                                     list_count = 0;

    SX_API_LOG_ENTER();
    list_count = mirror_enable_cnt;

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
    case SX_ACCESS_CMD_UNSET:
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));

        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_size = sizeof(*cmd_body_p);
    cmd_size += sizeof(sx_span_mirror_enable_port_set_t) * list_count;
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    cmd_body_p = (sx_api_span_mirror_enable_port_set_params_t*)cl_malloc(cmd_size);
    SX_MEM_CLR_TYPE(cmd_body_p, sx_api_span_mirror_enable_port_set_params_t);

    cmd_body_p->cmd = cmd;
    if (list_count > 0) {
        SX_MEM_CPY_ARRAY(cmd_body_p->mirror_enable_cfg_list, mirror_enable_cfg_list_p,
                         list_count, sx_span_mirror_enable_port_set_t);
    }
    cmd_body_p->mirror_enable_cnt = list_count;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_SPAN_MIRROR_ENABLE_PORT_SET_E,
                                     (uint8_t*)cmd_body_p, cmd_size);

    CL_FREE_N_NULL(cmd_body_p);
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_api_span_mirror_enable_port_iter_get(const sx_api_handle_t                           handle,
                                                    const sx_access_cmd_t                           cmd,
                                                    const sx_port_log_id_t                          log_port,
                                                    const sx_span_mirror_enable_port_iter_filter_t *filter_p,
                                                    sx_span_mirror_enable_port_set_t               *mirror_enable_cfg_list_p,
                                                    uint32_t                                       *mirror_enable_cnt_p)
{
    sx_api_span_mirror_enable_port_iter_get_params_t *cmd_body = NULL;
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    uint32_t                                          reply_body_size = 0;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (mirror_enable_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Span mirror enable Counter pointer is NULL. Cannot proceed\n");
        goto out;
    }
    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*mirror_enable_cnt_p > 1) {
            *mirror_enable_cnt_p = 1;
            SX_LOG(SX_LOG_NOTICE, "Force count to be 1 for %s \n",
                   sx_access_cmd_str(cmd));
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
        break;
    }

    /* malloc the cmd body. We will use the same body for the reply also*/
    reply_body_size = sizeof(sx_api_span_mirror_enable_port_iter_get_params_t) +
                      ((*mirror_enable_cnt_p) * sizeof(sx_span_mirror_enable_port_set_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body, 1, reply_body_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for Span mirror enable object List reply msg.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body->cmd = cmd;
    cmd_body->log_port = log_port;

    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body->filter), filter_p, sx_span_mirror_enable_port_iter_filter_t);
    }

    cmd_body->mirror_enable_cnt = *mirror_enable_cnt_p;
    if (*mirror_enable_cnt_p > 0) {
        SX_MEM_CPY_ARRAY(cmd_body->mirror_enable_cfg_list_p, mirror_enable_cfg_list_p,
                         *mirror_enable_cnt_p, sx_span_mirror_enable_port_set_t);
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_SPAN_MIRROR_ENABLE_PORT_ITER_GET_E,
                                      (uint8_t*)cmd_body,
                                      reply_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "[%s]SDK Core RPC failed with rc = %s \n", __func__,
               sx_status_str(err));
        goto out;
    }

    *mirror_enable_cnt_p = cmd_body->mirror_enable_cnt;

    if (*mirror_enable_cnt_p != 0) {
        if (mirror_enable_cfg_list_p != NULL) {
            SX_MEM_CPY_ARRAY(mirror_enable_cfg_list_p, cmd_body->mirror_enable_cfg_list_p,
                             cmd_body->mirror_enable_cnt, sx_span_mirror_enable_port_set_t);
        }
    }

out:
    if (cmd_body) {
        utils_memory_put(cmd_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}
