/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_bridge.h>
#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_BRIDGE

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  DEFINES
 ***********************************************/

#define __SX_API_LOG_EXIT(SX_STATUS) __log_exit(SX_STATUS, __func__)

/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_bridge_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  const sx_verbosity_level_t      module_verbosity_level,
                                                  const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_BRIDGE_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bridge_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  sx_verbosity_level_t           *module_verbosity_level_p,
                                                  sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_BRIDGE_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

/**
 *  This function is used to create/destroy a bridge.
 *  This function is supported in 802.1D mode only.
 *
 * @param[in] handle - SX-API handle
 * @param[in] cmd - CREATE/DESTROY
 * @param[in,out] bridge_id_p - a bridge_id.
 */
sx_status_t sx_api_bridge_set(const sx_api_handle_t handle, const sx_access_cmd_t cmd, sx_bridge_id_t *bridge_id_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    uint32_t                   cmd_size;
    sx_api_bridge_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (NULL == bridge_id_p) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.cmd = cmd;
    cmd_body.bridge_id = *bridge_id_p;

    cmd_size = sizeof(sx_api_bridge_set_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_BRIDGE_SET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        *bridge_id_p = cmd_body.bridge_id;
    }

    SX_API_LOG_EXIT();
    return err;
}


/**
 *  Supported devices: Spectrum
 *  This function is used to add a virtual port to a bridge.
 *
 * @param[in] handle - SX-API handle
 * @param[in] cmd - ADD/DELETE/DELETE_ALL
 * @param[in] bridge_id - bridge_id.
 * @param[in] log_port - logical virtual port ID.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND if bridge not found in DB
 * @return SX_STATUS_ERROR if unexpected behaviour occurs
 */
sx_status_t sx_api_bridge_vport_set(const sx_api_handle_t  handle,
                                    const sx_access_cmd_t  cmd,
                                    const sx_bridge_id_t   bridge_id,
                                    const sx_port_log_id_t log_port)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         cmd_size;
    sx_api_bridge_vport_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.cmd = cmd;
    cmd_body.bridge_id = bridge_id;
    cmd_body.log_port = log_port;

    cmd_size = sizeof(sx_api_bridge_vport_set_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_BRIDGE_VPORT_SET_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return err;
}

/**
 *  Supported devices: Spectrum
 *  This function is used to get a list of all virtual ports associated with a bridge.
 *  When using bridge_vport_cnt_p == 0, the number of existing entries will be returned.
 *
 * @param[in] handle - SX-API handle
 * @param[in] bridge_id - bridge_id.
 * @param[out] bridge_vport_list_p - a pointer to a sx_port_log_id_t list.
 * @param[in/out] bridge_vport_cnt_p - size of the bridge_vport_list.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND if bridge not found in DB
 * @return SX_STATUS_ERROR if unexpected behaviour occurs
 */
sx_status_t sx_api_bridge_vport_get(const sx_api_handle_t handle,
                                    const sx_bridge_id_t  bridge_id,
                                    sx_port_log_id_t     *bridge_vport_list_p,
                                    uint32_t             *bridge_vport_cnt_p)
{
    sx_api_command_head_t             cmd_head;
    sx_api_bridge_vport_get_params_t  cmd_body;
    uint32_t                          reply_body_size = 0;
    sx_api_reply_head_t               reply_head;
    sx_api_bridge_vport_get_params_t *reply_body = NULL;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (bridge_vport_cnt_p == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (bridge_vport_list_p == NULL) {
        *bridge_vport_cnt_p = 0;
    }
    if (*bridge_vport_cnt_p == 0) {
        bridge_vport_list_p = NULL;
    }

    reply_body_size = sizeof(sx_api_bridge_vport_get_params_t) +
                      ((*bridge_vport_cnt_p) * sizeof(sx_port_log_id_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);
    if (err != SX_STATUS_SUCCESS) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for command params.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_BRIDGE_VPORT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_bridge_vport_get_params_t);
    cmd_head.list_size = (*bridge_vport_cnt_p) * sizeof(sx_port_log_id_t);

    cmd_body.bridge_id = bridge_id;
    cmd_body.bridge_vport_cnt = *bridge_vport_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (*bridge_vport_cnt_p == 0) {
        *bridge_vport_cnt_p = reply_body->bridge_vport_cnt;
    } else {
        SX_MEM_CPY_ARRAY(bridge_vport_list_p, reply_body->bridge_vport_list,
                         reply_body->bridge_vport_cnt, sx_port_log_id_t);
        *bridge_vport_cnt_p = reply_body->bridge_vport_cnt;
    }

out:
    if (reply_body) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

/**
 *  Supported devices: Spectrum
 *  This function is used to add a virtual port from list to a corresponding
 *  bridge from list.
 *
 * @param[in] handle - SX-API handle
 * @param[in] cmd - ADD/DELETE/DELETE_ALL
 * @param[in] bridge_id_list - bridge_id.
 * @param[in] log_port_list - logical virtual port ID.
 * @param[in] list_cnt - list count
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND if bridge not found in DB
 * @return SX_STATUS_ERROR if unexpected behaviour occurs
 */
sx_status_t sx_api_bridge_vport_multi_set(const sx_api_handle_t   handle,
                                          const sx_access_cmd_t   cmd,
                                          const sx_bridge_id_t   *bridge_id_list,
                                          const sx_port_log_id_t *log_port_list,
                                          uint32_t                list_cnt)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    uint32_t                               cmd_size;
    sx_api_bridge_vport_multi_set_params_t cmd_body;
    uint32_t                               i;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (list_cnt > MAX_VPORT_MULTI_LIST_SIZE) {
        SX_LOG_ERR("List count > that max supported %d \n",
                   MAX_VPORT_MULTI_LIST_SIZE);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    if (list_cnt == 0) {
        SX_API_LOG_EXIT();
        return SX_STATUS_SUCCESS;
    }

    cmd_body.cmd = cmd;
    cmd_body.list_cnt = list_cnt;
    for (i = 0; i < list_cnt; i++) {
        cmd_body.bridge_id_list[i] = bridge_id_list[i];
        cmd_body.log_port_list[i] = log_port_list[i];
    }

    cmd_size = sizeof(sx_api_bridge_vport_multi_set_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_BRIDGE_VPORT_MULTI_SET_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

    return err;
}

/**
 *  Supported devices: Spectrum
 *  This function is used to bind/unbind a flow counter to a bridge.
 *
 * @param[in] handle - SX-API handle
 * @param[in] cmd - BIND/UNBIND
 * @param[in] bridge_id - bridge_id.
 * @param[in] flow_counter_id - flow counter id to bind
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND if bridge is not found in DB
 * @return SX_STATUS_ERROR if unexpected behavior occurs
 */
sx_status_t sx_api_bridge_counter_bind_set(const sx_api_handle_t      handle,
                                           const sx_access_cmd_t      cmd,
                                           const sx_bridge_id_t       bridge_id,
                                           const sx_flow_counter_id_t flow_counter_id)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    uint32_t                                cmd_size;
    sx_api_bridge_counter_bind_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.cmd = cmd;
    cmd_body.bridge_id = bridge_id;
    cmd_body.flow_counter_id = flow_counter_id;

    cmd_size = sizeof(sx_api_bridge_counter_bind_set_params_t);


    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_BRIDGE_COUNTER_BIND_SET_E, (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return err;
}

/**
 *  Supported devices: Spectrum
 *  This function is used to get the flow counter bound to the bridge.
 *  When no counter is bound to the bridge,
 *  flow_counter_id_p will be set to SX_FLOW_COUNTER_ID_INVALID.
 *
 * @param[in] handle - SX-API handle
 * @param[in] bridge_id - bridge_id.
 * @param[out] flow_counter_id_p - bound counter id
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND if bridge is not found in DB
 * @return SX_STATUS_ERROR if unexpected behavior occurs
 */
sx_status_t sx_api_bridge_counter_bind_get(const sx_api_handle_t handle,
                                           const sx_bridge_id_t  bridge_id,
                                           sx_flow_counter_id_t* flow_counter_id_p)
{
    sx_api_bridge_counter_bind_get_params_t cmd_body;
    sx_status_t                             err = SX_STATUS_SUCCESS;
    uint32_t                                cmd_size;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (flow_counter_id_p == NULL) {
        SX_LOG_ERR("NULL params\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body.bridge_id = bridge_id;

    cmd_size = sizeof(sx_api_bridge_counter_bind_get_params_t);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_BRIDGE_COUNTER_BIND_GET_E, (uint8_t*)&cmd_body, cmd_size);

    if (err == SX_STATUS_SUCCESS) {
        *flow_counter_id_p = cmd_body.flow_counter_id;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bridge_tunnel_counter_bind_set(const sx_api_handle_t                  handle,
                                                  const sx_access_cmd_t                  cmd,
                                                  const sx_bridge_id_t                   bridge_id,
                                                  const sx_bridge_tunnel_counter_attr_t *counter_attr_p,
                                                  const sx_flow_counter_id_t             counter_id)
{
    sx_api_bridge_tunnel_counter_bind_set_params_t cmd_body;
    sx_status_t                                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(counter_attr_p, "counter_attr_p")) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_BIND) &&
        (cmd != SX_ACCESS_CMD_UNBIND)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported command %s, bridge_id = %u, counter_id = %u, err = %s\n",
                   sx_access_cmd_str(cmd), bridge_id, counter_id, sx_status_str(err));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.bridge_id = bridge_id;
    cmd_body.counter_id = counter_id;
    SX_MEM_CPY_P(&cmd_body.counter_attr, counter_attr_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_BRIDGE_TUNNEL_COUNTER_BIND_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bridge_tunnel_counter_bind_get(const sx_api_handle_t                  handle,
                                                  const sx_bridge_id_t                   bridge_id,
                                                  const sx_bridge_tunnel_counter_attr_t *counter_attr_p,
                                                  sx_flow_counter_id_t                  *counter_id_p)
{
    sx_api_bridge_tunnel_counter_bind_get_params_t cmd_body;
    sx_status_t                                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((utils_check_pointer(counter_id_p, "counter_id_p")) ||
        (utils_check_pointer(counter_attr_p, "counter_attr_p"))) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_body.bridge_id = bridge_id;
    SX_MEM_CPY_P(&cmd_body.counter_attr, counter_attr_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_BRIDGE_TUNNEL_COUNTER_BIND_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    if (SX_CHECK_PASS(err)) {
        *counter_id_p = cmd_body.counter_id;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_bridge_iter_get(const sx_api_handle_t     handle,
                                   const sx_access_cmd_t     cmd,
                                   const sx_bridge_id_t      bridge_id,
                                   const sx_bridge_filter_t *filter_p,
                                   sx_bridge_id_t           *bridge_id_list_p,
                                   uint32_t                 *bridge_id_cnt_p)
{
    sx_api_command_head_t            cmd_head;
    sx_api_bridge_iter_get_params_t  cmd_body;
    sx_api_reply_head_t              reply_head;
    sx_api_bridge_iter_get_params_t *reply_body = NULL;
    uint32_t                         reply_body_size;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (bridge_id_cnt_p == NULL) {
        SX_LOG_ERR("bridge_id_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*bridge_id_cnt_p > 0) && (bridge_id_list_p == NULL)) {
        SX_LOG_ERR("*bridge_id_cnt_p is not 0 but bridge_id_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*bridge_id_cnt_p == 0) {
            bridge_id_list_p = NULL;
        } else {
            *bridge_id_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*bridge_id_cnt_p == 0) {
            SX_LOG_NTC("Bridge Iter Get + cmd [%s] + count [0] = empty list. \n", sx_access_cmd_str(cmd));
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_bridge_iter_get_params_t) +
                      (*bridge_id_cnt_p * sizeof(sx_bridge_id_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_BRIDGE_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_bridge_iter_get_params_t);
    cmd_head.list_size = *bridge_id_cnt_p * sizeof(sx_bridge_id_t);

    cmd_body.cmd = cmd;
    cmd_body.bridge_id = bridge_id;
    cmd_body.bridge_id_cnt = *bridge_id_cnt_p;
    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), filter_p, sx_bridge_filter_t);
    }

    *bridge_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->bridge_id_cnt != 0) {
        *bridge_id_cnt_p = reply_body->bridge_id_cnt;
        if (bridge_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(bridge_id_list_p, reply_body->bridge_id_list,
                             reply_body->bridge_id_cnt, sx_bridge_id_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}
