/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <sys/stat.h>
#include <errno.h>
#include <sx/sdk/sx_api_dbg.h>
#include <sx/sxd/sxd_fw_dbg.h>
#include <sx/sxd/sxd_fw_trace.h>
#include <sx/sxd/cr_access.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_access_register_init.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/sxd_access_register.h>
#include <complib/cl_fcntl.h>
#include <linux/elf.h>
#include <sys/wait.h>
#include "sx_api_internal.h"
#include "config.h"

#undef  __MODULE__
#define __MODULE__ SX_API_DBG

/************************************************
 *  Global MACROS
 ***********************************************/
#define ELF_PRARGSZ (80)    /* Number of chars for args */
#define PRARGSZ     ELF_PRARGSZ

#define EM_IRISC                 8657 /* Mellanox IRISC */
#define SEG_MEM_ADDR             0x10600000UL
#define SEG_MEM_IRISC_SIZE       0x2000UL
#define L1_CACHE_WRITE_BACK_SIZE 0x2000UL

#define __ARBEL_BP   0x00000010     /* IRISC has Arbel-type HW breakpoints */
#define __DEBUG_MODE 0x00000001         /* In debug mode */
/* */
/* Debug Hooks Registers and Bits */
/* status and control bits in 0x1e0 */
#define __REMOTE   (1 << 0)
#define __DBG_EN   (1 << 4)
#define __DBG_CRDY (1 << 5)
#define __DBG_RET  (1 << 6)
#define __INT_D    (1 << 8)
#define __RINT     (1 << 9)
#define __CODE_BP  (0xF << 20)
#define __READ_BP  (0xF << 28)
#define __WRITE_BP (0xF << 24)
#define __RTRAP    (1 << 10)
#define __MISACC   (1 << 11)
#define __OORCODE  (1 << 7)
#define __OORDATA  (1 << 12)

/*Opcodes */
#define NOP_OPCODE   0x00000000
#define RIRET_OPCODE 0xFC00082E
#define RET_OPCODE   0xFC00002D
#define BRI_OPCODE(disp)   (0x95000000 | ((((signed long)(disp)) >> 2) & 0x0FFFFFF))
#define LDCR_OPCODE(r, cr) (0x48000000 | (((r) & 0x01F) << 16) | ((cr) & 0xFFFF))
#define STCR_OPCODE(r, cr) (0x4C000000 | (((r) & 0x01F) << 21) | ((cr) & 0xFFFF))
#define LD4_OPCODE(dest, addr1, addr2) \
    (0xFC000219 | ((dest) << 16) | ((addr1) << 21) | ((addr2) << 11))
#define ST4_OPCODE(src, raddr) \
    (0x6C000002 | ((src) << 11) | ((raddr) << 21))


/* CR Registers and bits */
#define NUMBER_OF_REGS       (32 + 13)
#define HALT_DEVICE_LOCATION 0x100028;
#define IRISCBOOT            0x000
#define IRISC_ID             0x004
#define EXINSTP              0x070 /* exinstptr */
#define NXTINSTP             0x074 /* nxtinstptr */
#define GPREG                0x078
#define CC_REG               0x07C
#define INTBASE              0x080
#define RINT_BASE            0x088
#define INTCAUSE             0x0A0 /* intcause_r_w_ */
#define INTCAUSE_CLR         0x0A4
#define INTENABLE            0x0AC
#define INTRA                0x0B0
#define GCTRL                0x0B4
#define RINTRA               0x0B8
#define CALLRA               0x0BC

#define BP_HI_OFFSET 0x000          /*breakpoint configuration */
#define BP_LO_OFFSET 0x004          /*breakpoint address */
#define BP0_OFFSET   0x0C0
#define BP0_MASK     BP0_OFFSET + BP_HI_OFFSET
#define BP0_ADDR     BP0_OFFSET + BP_LO_OFFSET
#define NUM_OF_BPS   4

/* */
/* Cache Registers and bits */
/* */
#define CODECACHE_REG 0x00C
#define __CACHE_WAYS(X)    ((X) & 0x0000000F)
#define __CACHE_LSIZE(X)   (((X) >> 8) & 0x0F)
#define __CACHE_LPERWAY(X) (((X) >> 16) & 0xFFFF)
#define TARGET_WORD_BYTES       4
#define TARGET_CACHE_LINE_BYTES 64

/* */
/* Cache GW */
/* */
#define CACHE_GW_CONTROL 0x020
#define __CACHE_GW_LOCK  (1 << 31)
#define __CACHE_GW_BUSY  (1 << 30)
#define CACHE_GW_DATA    0x024
#define __CACHE_GW_CODE_WRITE(lock, busy, way, addr32)                                        \
    ((__IS_ARBEL_TPT)                                                                         \
     ? (((lock) << 31) | ((busy) << 30) | (0x04 << 24) | ((way) << 20) | ((addr32) & 0x3FFC)) \
     : (((lock) << 31) | ((busy) << 30) | (0x04 << 24) | ((way) << 20) | ((addr32) & 0x0FFC)))
#define __CACHE_GW_CODE_READ(lock, busy, way, addr32)                                         \
    ((__IS_ARBEL_TPT)                                                                         \
     ? (((lock) << 31) | ((busy) << 30) | (0x03 << 24) | ((way) << 20) | ((addr32) & 0x3FFC)) \
     : (((lock) << 31) | ((busy) << 30) | (0x03 << 24) | ((way) << 20) | ((addr32) & 0x0FFC)))
#define __CACHE_GW_CODE_TAG_READ(lock, busy, way, index) \
    (((lock) << 31) | ((busy) << 30) | (0x01 << 24) | ((way) << 20) | (index << 6))
#define CODE_CACHE_MISS 1
#define DATA_CACHE_MISS 2

/* Cache internal fields */
#define TPT_IRISC                   0
#define __IS_ARBEL_TPT              ((gdbs_set.flags & __ARBEL_BP) && (gdbs_set.irisc_n == TPT_IRISC))
#define MAX_WAYS                    4
#define MAX_LINES_PER_WAY_TAVOR     64
#define MAX_LINES_PER_WAY_ARBEL_TPT 256

#define __CACHE_TAG_VALID 0x00000001
#define __CACHE_TAG(value)  (__IS_ARBEL_TPT ? (((value) >> 14) & 0x3FFFF) : (((value) >> 12) & 0xFFFFF))
#define __CACHE_INDEX(addr) (__IS_ARBEL_TPT ? (((addr) >> 6) & 0xFF) : (((addr) >> 6) & 0x3F))
#define __CACHE_WAY(cmd)    (((cmd) >> 20) & 0xF)

#define IRISC_CACHE_ADDRESS_MASK  0x0000FFC0
#define L2_DATA_WAY               0x00300000
#define IRISC_CACHE_CODE_READ_CMD 0xC2000000


#define MAX_FILE_PATH_LEN 1024
#define CR_BYTE_LEN       4
#define CR_READ(offset, data)                    __debug_ir_read(dev_id, offset, data)
#define CR_READ_IRISC(offset, data, irisc_num)   __debug_ir_read_irisc(dev_id, offset, data, irisc_num)
#define CR_WRITE(offset, data)                   __debug_ir_write(dev_id, offset, data)
#define CR_WRITE_IRISC(offset, data, irisc_num)  __debug_ir_write_irisc(dev_id, offset, data, irisc_num)
#define EXEC_OPCODE(opcode, mnemonics)           __dbg_ir_target_exec_opcode(dev_id, opcode)
#define CR_WRITE_GLOBAL(offset, data)            sx_cr_access_write(dev_id, offset, (uint8_t*)&data, CR_BYTE_LEN)
#define CR_READ_GLOBAL(offset, data)             sx_cr_access_read(dev_id, offset, (uint8_t*)data, CR_BYTE_LEN)
#define CR_READ_GLOBAL_BLOCK(offset, data, size) sx_cr_access_read(dev_id, offset, (uint8_t*)data, size)

/* Default configuration */

/* each call to sx_api_dbg_generate_dump_extra() will generate 3 CR-Space dumps */
#define SX_NUM_OF_CR_SPACE_DUMPS 3

#define DEFAULT_DEVICE_NAME ""
#define DEFAULT_IRISC_N     0
#define DEFAULT_CORE_PATH   ""

#define MAX_CACHE_RETRIES 3000

#define SX_TMP_FILE_NAME_LEN (10)
#define SX_DMP_EXT_VER       ("1")

#define IGNORE_CRDUMP_DURING_IRDUMP_ENV "IGNORE_CRS_DUMP_DURING_IRCORE_DUMP"

#define IS_DUMP_SUPPORTED_WITH_ISSU(chip_type)  \
    ((chip_type == SXD_CHIP_TYPE_SPECTRUM ||    \
      chip_type == SXD_CHIP_TYPE_SPECTRUM_A1 || \
      chip_type == SXD_CHIP_TYPE_SPECTRUM2 ||   \
      chip_type == SXD_CHIP_TYPE_SPECTRUM3))

/************************************************
 *  Type definitions
 ***********************************************/
struct sx_elf_siginfo {
    int si_signo;           /* signal number */
    int si_code;            /* extra code */
    int si_errno;           /* errno */
};

typedef uint32_t sx_elf_gregset_t[NUMBER_OF_REGS];    /* gdb known registers */
struct  sx_elf_prstatus {
    struct sx_elf_siginfo pr_info; /* Info associated with signal */
    short                 pr_cursig; /* Current signal */
    unsigned long         pr_sigpend; /* Set of pending signals */
    unsigned long         pr_sighold; /* Set of held signals */
    pid_t                 pr_pid;
    pid_t                 pr_ppid;
    pid_t                 pr_pgrp;
    pid_t                 pr_sid;
    struct timeval        pr_utime; /* User time */
    struct timeval        pr_stime; /* System time */
    struct timeval        pr_cutime; /* Cumulative user time */
    struct timeval        pr_cstime; /* Cumulative system time */
    sx_elf_gregset_t      pr_reg; /* GP registers */
    int                   pr_fpvalid; /* True if math co-processor being used.  */
};
struct sx_elf_prpsinfo {
    char           pr_state; /* numeric process state */
    char           pr_sname; /* char for pr_state */
    char           pr_zomb; /* zombie */
    char           pr_nice; /* nice val */
    unsigned long  pr_flag; /* flags */
    __kernel_uid_t pr_uid;
    __kernel_gid_t pr_gid;
    pid_t          pr_pid, pr_ppid, pr_pgrp, pr_sid;
    /* Lots missing */
    char pr_fname[16];      /* filename of executable */
    char pr_psargs[ELF_PRARGSZ];    /* initial part of arg list */
};
typedef struct sx_elf_prstatus sx_prstatus_t;
typedef struct sx_elf_prpsinfo sx_prpsinfo_t;

struct core_dump_prstatus_note_s {
    Elf32_Nhdr             nhdr;
    struct sx_elf_prstatus prstatus;
} __attribute__ ((packed));
struct core_dump_sections_s {
    Elf32_Ehdr                       *ehdr;
    Elf32_Phdr                       *phdr;
    int                               irisc_count; /*including special iriscs */
    struct core_dump_prstatus_note_s *prstatus_notes;
    uint32_t                          seg_mem_size;
    char                             *seg_mem;
};

enum {
    PH_INDEX_NOTE,
    PH_INDEX_SEG_MEM,
    PH_INDEX_NUM
};

typedef struct {
    char     name[20];      /* Name of IRISC */
    char     unit_name[29]; /* Name of unit */
    uint32_t cr_base_addr;        /* Base address on CR space */
} irisc_table_t;

typedef struct {
    char          device_name[100]; /* Name of device file */
    int           irisc_n;                          /* Irisc number (index  in irisc_table) to work with */
    boolean_t     special_irisc_flag;        /*In case of stuck iRISC debug, halt only current iRISC */
    unsigned long flags;
    char          core_file_path[MAX_FILE_PATH_LEN];
    boolean_t     force;         /*force mode - when can't enter debug mode */
} gdbs_set_t;

typedef enum {
    r0,
    r1,
    sp,
    r3,
    r4,
    r5,
    r6,
    r7,
    r8,
    r9,
    r10,
    r11,
    r12,
    r13,
    r14,
    r15,
    r16,
    r17,
    r18,
    r19,
    r20,
    r21,
    r22,
    r23,
    r24,
    r25,
    r26,
    r27,
    r28,
    r29,
    r30,
    r31,
    /* Control registers */
    cc,
    gctrl,
    intra,
    callra,
    ip,                 /* nxtinstptr */
    irisc_id,
    intcause,           /* intcause read/write */
    intbase,
    nip,                /* */
    incause_clr,        /* intcause clear */
    intenable,
    iriscboot,
    gpreg
} ir_regs_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

static uint32_t      seg_mem_addr_g = SEG_MEM_ADDR;
static uint32_t      bp_size = 0;
static uint32_t      num_of_iriscs = 0;
static uint32_t      special_irisc_mask = 0;   /*iriscs with special jobs - do NOT stop with BP */
static uint32_t      dbg_reg_offset = 0x1e0;
static uint32_t      dbg_set_offset = 0x1e4;
static uint32_t      dbg_clr_offset = 0x1e8;
static uint32_t      dbg_code_offset = 0x1ec;
static uint32_t      f_ip_offset = 0x1f0;
static uint32_t      last_e_ip_offset = 0x1f8;
static uint32_t      ir_cache_l2_gw_base_addr = 0;
static uint32_t      ir_cache_l2_gw_copy_offest = 4;
static uint32_t      ir_cache_l2_gw_data_offest = 0x40;
static uint32_t      ir_cache_l2_gw_busy_mask = 0x40000000;
static uint32_t      halt_code_ip = 0;
static unsigned long gdbs_stat;
static irisc_table_t irisc_table[] = {
    {
        name : "irisc0",
        unit_name : "IRISC0",
        cr_base_addr : 0xA0000
    },

    {
        name : "irisc1",
        unit_name : "IRISC1",
        cr_base_addr : 0xA0200
    },

    {
        name : "irisc2",
        unit_name : "IRISC2",
        cr_base_addr : 0xA0400
    },

    {
        name : "irisc3",
        unit_name : "IRISC3",
        cr_base_addr : 0xA0600
    },

    {
        name : "irisc4",
        unit_name : "IRISC4",
        cr_base_addr : 0xA0800
    },

    {
        name : "irisc5",
        unit_name : "IRISC5",
        cr_base_addr : 0xA0A00
    },

    {
        name : "irisc6",
        unit_name : "IRISC6",
        cr_base_addr : 0xA0C00
    },

    {
        name : "irisc7",
        unit_name : "IRISC7",
        cr_base_addr : 0xA0E00
    },

    {
        name : "irisc8",
        unit_name : "IRISC8",
        cr_base_addr : 0xA1000
    },

    {
        name : "irisc9",
        unit_name : "IRISC9",
        cr_base_addr : 0xA1200
    },

    {
        name : "irisc10",
        unit_name : "IRISC10",
        cr_base_addr : 0xA1400
    }
};
static gdbs_set_t    gdbs_set = {
    DEFAULT_DEVICE_NAME,
    DEFAULT_IRISC_N,
    0,
    0,
    DEFAULT_CORE_PATH,
    0
};

static struct target_stat_t {
    uint32_t dbg_reg;             /* DBG_REG at last halt */
    uint32_t regs[NUMBER_OF_REGS];        /* gdb known registers */
} target_stat;

static boolean_t g_crdump_env_checked = FALSE;
static boolean_t g_ignore_crdump_during_irdump = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __dbg_ircore_dump_scan_memory(sx_dev_id_t dev_id, struct core_dump_sections_s *core_dump_sections);
static sx_status_t __dbg_ircore_dump_scan_registers(sx_dev_id_t                  dev_id,
                                                    struct core_dump_sections_s *core_dump_sections,
                                                    int                          irisc_n,
                                                    boolean_t                    read_regs,
                                                    int                          prstatus_notes_index);
static sx_status_t __dbg_ircore_init_ehdr(Elf32_Ehdr *ehdr);
static sx_status_t __dbg_ircore_init_sections(struct core_dump_sections_s *core_dump_sections);
static sx_status_t __dbg_ircore_init_phdr(Elf32_Phdr *phdr_seg);
static sx_status_t __dbg_ircore_deinit_sections(struct core_dump_sections_s *core_dump_sections);
static sx_status_t __dbg_ir_target_read_memory(sx_dev_id_t dev_id, char* buf, uint32_t addr);
static sx_status_t __debug_ir_read(sx_dev_id_t dev_id, uint32_t ir_cr_addr, uint32_t* val);
static sx_status_t __debug_ir_read_irisc(sx_dev_id_t dev_id, uint32_t ir_cr_addr, uint32_t* val, uint32_t irisc);
static sx_status_t __debug_ir_write(sx_dev_id_t dev_id, uint32_t ir_cr_addr, uint32_t val);
static sx_status_t __debug_ir_write_irisc(sx_dev_id_t dev_id, uint32_t ir_cr_addr, uint32_t val, uint32_t irisc);
static sx_status_t __dbg_ir_target_halt(sx_dev_id_t dev_id);
static sx_status_t __dbg_ir_target_continue(sx_dev_id_t dev_id);
static sx_status_t __dbg_ir_target_exec_opcode(sx_dev_id_t dev_id, uint32_t opcode);
static sx_status_t __dbg_ir_target_read_reg(sx_dev_id_t dev_id, ir_regs_t reg, uint32_t* val);
static sx_status_t __dbg_ir_target_read_all_regs(sx_dev_id_t dev_id);
static sx_status_t __dbg_ir_target_read_l2_cache_line(sx_dev_id_t dev_id, char* buf, uint32_t addr);
static sx_status_t __dbg_ir_target_clr_hwbp_all(sx_dev_id_t dev_id);
static sx_status_t __dbg_ir_handle_hwbp_on_memaccess(sx_dev_id_t dev_id, uint32_t addr,  int reenable);
static sx_status_t __dbg_ircore_init(sx_dev_id_t dev_id, sxd_chip_types_t chip_type);
static sx_status_t __dbg_ir_target_ram_read4(sx_dev_id_t dev_id, char* buf, uint32_t addr);
static sx_status_t __fw_dbg_device_tiles_info_init(sx_dev_id_t dev_id);

/************************************************
 *  Function implementations
 ***********************************************/

static void __default_log_cb(sx_log_severity_t severity, const char *module_name, char *msg)
{
    FILE *f_out = (severity == SX_LOG_ERROR) ? stderr : stdout;

    fprintf(f_out, "[%s] %s", module_name, msg);
}

sx_status_t sx_api_dbg_generate_dump(const sx_api_handle_t handle, const char *dump_file_path)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    uint32_t                          cmd_size;
    sx_api_dbg_generate_dump_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (dump_file_path != NULL) {
        if (strlen(dump_file_path) > SX_API_DUMP_PATH_LEN_LIMIT) {
            SX_LOG_ERR("dump file path length exceeds range - max string length is %u .\n",
                       SX_API_DUMP_PATH_LEN_LIMIT);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        strcpy(cmd_body.path, dump_file_path);
    } else {
        cmd_body.path[0] = '\0';
    }

    cmd_size = sizeof(sx_api_dbg_generate_dump_params_t);
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_DBG_GENERATE_DUMP_E, (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_dbg_atcam(const sx_api_handle_t handle, sx_dbg_atcam_cmd_info_t* cmd_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_dbg_atcam_cmd_info_t cmd_body;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (!cmd_p) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body = *cmd_p;
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_DBG_ATCAM_CONFIG_TEST_E, (uint8_t*)&cmd_body,
                                      sizeof(cmd_body));
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    switch (cmd_p->type) {
    case SX_DBG_ATCAM_CMD_REGION_ERPS_GET_E:
        memcpy(cmd_p->data.region_erps_get.erps_ids,
               cmd_body.data.region_erps_get.erps_ids,
               sizeof(cmd_body.data.region_erps_get.erps_ids));
        break;

    case SX_DBG_ATCAM_CMD_REORDER_REGION_ERPS_E:
        memcpy(cmd_p->data.reorder_region_erps.erps_ids,
               cmd_body.data.reorder_region_erps.erps_ids,
               sizeof(cmd_body.data.reorder_region_erps.erps_ids));
        cmd_p->data.reorder_region_erps.region_id = cmd_body.data.reorder_region_erps.region_id;
        cmd_p->data.reorder_region_erps.completed = cmd_body.data.reorder_region_erps.completed;
        break;

    case SX_DBG_ATCAM_CMD_REGION_COUNTERS_READ_E:
        SX_MEM_CPY(cmd_p->data.region_counters_read, cmd_body.data.region_counters_read);
        break;

    case SX_DBG_ATCAM_CMD_ERP_COUNTERS_READ_E:
        SX_MEM_CPY(cmd_p->data.erp_counters_read, cmd_body.data.erp_counters_read);
        break;

    case SX_DBG_ATCAM_CMD_ERPS_SAMPLING_SET_E:
    case SX_DBG_ATCAM_CMD_ERPS_COUNTERS_SAMPLE_E:
    default:
        ;      /* Do nothing */
    }


out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t generate_dump_file(const char       *path,
                               const sx_dev_id_t dev_id,
                               const char       *dump_prefix,
                               const char       *dump_suffix,
                               FILE            **f_ret)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    struct timeval tv;
    struct tm     *nowtm = NULL;
    char           time_str[30] = { 0 };
    int            path_len;
    int            tv_usec;
    char           dump_name[SX_API_DUMP_PATH_LEN_LIMIT] = { 0 };

    if (dump_prefix == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("dump file prefix is NULL\n");
        goto out;
    }

    if (f_ret == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("dump file pointer is NULL\n");
        goto out;
    }

    gettimeofday(&tv, NULL);
    nowtm = localtime(&tv.tv_sec);

    if (NULL == nowtm) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to create dump file (prefix: %s, suffix: %s) - could not get time of day\n",
                   dump_prefix,
                   ((dump_suffix != NULL) ? dump_suffix : "N/A"));
        goto out;
    }

    strftime(time_str, 30, "%d%b%Y_%H:%M:%S", nowtm);
    tv_usec = (int)tv.tv_usec;

    path_len = snprintf(dump_name, sizeof(dump_name) - 1, "%s/sdk_dump_ext_%s.%06d_dev%d_%s%s%s",
                        path,
                        time_str,
                        tv_usec,
                        dev_id,
                        dump_prefix,
                        (dump_suffix ? "." : ""),
                        (dump_suffix ? dump_suffix : ""));

    if (path_len >= ((int)sizeof(dump_name)) - 1) {
        SX_LOG_ERR("Failed to create dump file (prefix: %s, suffix: %s) - full path is too long\n",
                   dump_prefix,
                   ((dump_suffix != NULL) ? dump_suffix : "N/A"));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    *f_ret = fopen(dump_name, "w");
    if (*f_ret == NULL) {
        SX_LOG_ERR("Failed to create dump file - could not open file (path=%s, errno=%d)\n",
                   dump_name,
                   errno);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    SX_LOG_NTC("Created dump file: %s\n", dump_name);

out:
    return rc;
}

static sx_status_t __debug_ir_read(sx_dev_id_t dev_id, uint32_t ir_cr_addr, uint32_t* val)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    swapped_val = 0;

    *val = 0;
    uint32_t cr_addr = irisc_table[gdbs_set.irisc_n].cr_base_addr + ir_cr_addr;

    err = sxd_status_to_sx_status(sx_cr_access_read(dev_id, cr_addr, (uint8_t*)&swapped_val, 4));
    *val = be32toh(swapped_val);
    return err;
}
static sx_status_t __debug_ir_read_irisc(sx_dev_id_t dev_id, uint32_t ir_cr_addr, uint32_t* val, uint32_t irisc)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    swapped_val = 0;

    *val = 0;
    uint32_t cr_addr = irisc_table[irisc].cr_base_addr + ir_cr_addr;

    err = sxd_status_to_sx_status(sx_cr_access_read(dev_id, cr_addr, (uint8_t*)&swapped_val, 4));
    *val = be32toh(swapped_val);
    return err;
}

static sx_status_t __debug_ir_write(sx_dev_id_t dev_id, uint32_t ir_cr_addr, uint32_t val)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    uint32_t     swapped_val;
    unsigned int i = 0;

    swapped_val = htobe32(val);
    for (i = 0; i < num_of_iriscs; i++) {
        uint32_t cr_addr = irisc_table[i].cr_base_addr + ir_cr_addr;
        if (1 << i & special_irisc_mask) {  /*don't write to special irisc */
            continue;
        }
        /* Write register */
        err = sxd_status_to_sx_status(sx_cr_access_write(dev_id, cr_addr, (uint8_t*)&swapped_val, 4));
    }
    return err;
}
static sx_status_t __debug_ir_write_irisc(sx_dev_id_t dev_id, uint32_t ir_cr_addr, uint32_t val, uint32_t irisc)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    swapped_val;

    swapped_val = htobe32(val);
    uint32_t cr_addr = irisc_table[irisc].cr_base_addr + ir_cr_addr;

    err = sxd_status_to_sx_status(sx_cr_access_write(dev_id, cr_addr, (uint8_t*)&swapped_val, 4));
    return err;
}


static sx_status_t __dbg_ircore_init(sx_dev_id_t dev_id, sxd_chip_types_t chip_type)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    swapped_halt_code_ip;
    int         iron_irisc = 0; /*Debug on iron is currently not supported. */
    uint32_t    halt_device_addr_location = HALT_DEVICE_LOCATION; /*0x100028; */

    strcpy(gdbs_set.device_name, DEFAULT_DEVICE_NAME);
    gdbs_set.irisc_n = DEFAULT_IRISC_N;
    gdbs_set.flags |= __ARBEL_BP;

    /*get device halt function address */
    rc =
        sxd_status_to_sx_status(sx_cr_access_read(dev_id, halt_device_addr_location, (uint8_t*)&swapped_halt_code_ip,
                                                  4));
    halt_code_ip = be32toh(swapped_halt_code_ip);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "Fail to read halt_device function address. Cores cannot be stopped.dev_id [%d] addr [0x%x] rc [%d %s].\n",
            dev_id,
            halt_device_addr_location,
            rc,
            SX_STATUS_MSG(rc));
        return rc;
    }


    switch (chip_type) {
    case SX_CHIP_TYPE_SPECTRUM: /*condor */
    case SX_CHIP_TYPE_SPECTRUM_A1:
        strcpy(gdbs_set.device_name, "SPECTRUM");
        bp_size = 0x8;
        num_of_iriscs = 8;
        special_irisc_mask = iron_irisc ? 0xFD : 0x3;     /*if iron - work only on irisc1, else don't work on 0 (scheduler) & 1 (pci) */
        if (gdbs_set.irisc_n == DEFAULT_IRISC_N) {
            /* coverity[dead_error_line] */
            gdbs_set.irisc_n = iron_irisc ? 1 : 2;
        }
        ir_cache_l2_gw_base_addr = 0xa1500;

        break;

    case SX_CHIP_TYPE_QUANTUM:  /*raven */
        bp_size = 0x10;
        num_of_iriscs = 8;
        special_irisc_mask = iron_irisc ? 0xFD : 0x2;     /*if iron - work only on irisc1, else don't work on 1 (pci) */
        if (gdbs_set.irisc_n == DEFAULT_IRISC_N) {
            /* coverity[dead_error_line] */
            gdbs_set.irisc_n = iron_irisc ? 1 : 0;
        }
        ir_cache_l2_gw_base_addr = 0xa3400;
        strcpy(gdbs_set.device_name, "QUANTUM");
        break;

    case SX_CHIP_TYPE_QUANTUM2:  /*blackbird */
    case SX_CHIP_TYPE_QUANTUM3:  /*sunbird */
    case SX_CHIP_TYPE_QUANTUM4:  /*starling */
        bp_size = 0x10;
        num_of_iriscs = 10;
        special_irisc_mask = iron_irisc ? 0x3FD : 0x2;     /*if iron - work only on irisc1, else don't work on 1 (pci) */
        if (gdbs_set.irisc_n == DEFAULT_IRISC_N) {
            /* coverity[dead_error_line] */
            gdbs_set.irisc_n = iron_irisc ? 1 : 0;
        }
        dbg_reg_offset = 0x1c0;
        dbg_set_offset = 0x1c4;
        dbg_clr_offset = 0x1c8;
        dbg_code_offset = 0x1cc;
        f_ip_offset = 0x1d0;
        last_e_ip_offset = 0x1d8;
        ir_cache_l2_gw_base_addr = 0xa2400;
        seg_mem_addr_g = 0x10640000UL;
        strcpy(gdbs_set.device_name, "QUANTUM2");
        break;

    case SX_CHIP_TYPE_SPECTRUM2: /*phoenix */
        bp_size = 0x10;
        num_of_iriscs = 8;
        special_irisc_mask = iron_irisc ? 0xFD : 0x2;     /*if iron - work only on irisc1, else don't work on 1 (pci) */
        if (gdbs_set.irisc_n == DEFAULT_IRISC_N) {
            /* coverity[dead_error_line] */
            gdbs_set.irisc_n = iron_irisc ? 1 : 0;
        }
        ir_cache_l2_gw_base_addr = 0xa3400;
        strcpy(gdbs_set.device_name, "SPECTRUM2");
        break;

    case SX_CHIP_TYPE_SPECTRUM3: /*firebird - only main */
        special_irisc_mask = iron_irisc ? 0x3FD : 0x2;      /*if iron - work only on irisc1, else don't work on 1 (pci) */
        if (gdbs_set.irisc_n == DEFAULT_IRISC_N) {
            /* coverity[dead_error_line] */
            gdbs_set.irisc_n = iron_irisc ? 1 : 0;
        }
        num_of_iriscs = 10;
        bp_size = 0x10;
        dbg_reg_offset = 0x1c0;
        dbg_set_offset = 0x1c4;
        dbg_clr_offset = 0x1c8;
        dbg_code_offset = 0x1cc;
        f_ip_offset = 0x1d0;
        last_e_ip_offset = 0x1d8;
        ir_cache_l2_gw_base_addr = 0xa3400;
        strcpy(gdbs_set.device_name, "SPECTRUM3-MAIN");
        break;

    case SX_CHIP_TYPE_UNKNOWN:
    case SX_CHIP_TYPE_SWITCHX_A2:
    case SX_CHIP_TYPE_SWITCHX_A1:
    case SX_CHIP_TYPE_SWITCHX_A0:
    case SX_CHIP_TYPE_SPECTRUM4:
    case SX_CHIP_TYPE_SPECTRUM5:
    case SXD_CHIP_TYPE_SWITCH_IB:
    case SXD_CHIP_TYPE_SWITCH_IB2:
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("__dbg_ircore_init failed, unsupported ASIC type:[%d,%s]\n",
                   chip_type, sx_chip_type_str((sx_chip_types_t)chip_type));
        break;
        /* No default: we want any new ASIC to break this so it will appear in bringup! */
    }

    return rc;
}

static sx_status_t __dbg_ircore_dump_scan_memory(sx_dev_id_t dev_id, struct core_dump_sections_s *core_dump_sections)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    Elf32_Phdr  *current_phdr = 0;
    uint32_t     address = seg_mem_addr_g;
    uint32_t     size = 0;
    char         temp_word[TARGET_WORD_BYTES] = {0};
    unsigned int cache_addr = seg_mem_addr_g;
    uint32_t     mem_offset = 0;


    SX_LOG_INF("reading stack memory\n");

    size = core_dump_sections->seg_mem_size;

    /* Read 1 word from each cache line to cause L1 cache write back to L2 */
    /* cache. */

    for (cache_addr = seg_mem_addr_g;
         cache_addr < seg_mem_addr_g + L1_CACHE_WRITE_BACK_SIZE;
         cache_addr += TARGET_CACHE_LINE_BYTES) {
        __dbg_ir_target_read_memory(dev_id, temp_word, cache_addr); /*, &temp_size); */
    }

    /* Read the target stack memory from L2 cache. */

    for (mem_offset = 0; mem_offset < core_dump_sections->seg_mem_size;
         mem_offset += TARGET_CACHE_LINE_BYTES) {
        __dbg_ir_target_read_l2_cache_line(dev_id, &core_dump_sections->seg_mem[mem_offset],
                                           address + mem_offset);
    }

    /* Set the memory segment header. */

    current_phdr = &core_dump_sections->phdr[PH_INDEX_SEG_MEM];
    current_phdr->p_memsz = current_phdr->p_filesz = htobe32(size);
    current_phdr->p_paddr = current_phdr->p_vaddr = htobe32(address);

    return rc;
}


static sx_status_t __dbg_ircore_dump_scan_registers(sx_dev_id_t                  dev_id,
                                                    struct core_dump_sections_s *core_dump_sections,
                                                    int                          irisc_n,
                                                    boolean_t                    read_regs,
                                                    int                          prstatus_notes_index)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    int                               reg_index = 0;
    struct core_dump_prstatus_note_s *prstatus_note = 0;


    /* Set the note section data, including the registers. */
    prstatus_note = &core_dump_sections->prstatus_notes[prstatus_notes_index];
    prstatus_note->nhdr.n_descsz = htobe32(sizeof(prstatus_note->prstatus));
    prstatus_note->nhdr.n_type = htobe32(NT_PRSTATUS);
    /* The pr_pid field will be presented in the GDB client as the thread id. irisc id */
    prstatus_note->prstatus.pr_pid = htobe32(irisc_n);

    /*The register content should not be read for special iRISCs. */
    if (read_regs) {
        /* Set the iRISC id for all CR-Space reads. */
        gdbs_set.irisc_n = irisc_n;
        /* Read the target registers. */
        SX_LOG_INF("reading registers of irisc%d\n", irisc_n);
        rc = __dbg_ir_target_read_all_regs(dev_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("read_all_regs returned error\n");
            goto out;
        }
        /* Copy the target registers to pr_reg. */
        for (reg_index = 0; reg_index < NUMBER_OF_REGS; reg_index++) {
            prstatus_note->prstatus.pr_reg[reg_index] = htobe32(target_stat.regs[reg_index]);
        }
    }
out:
    return rc;
}


static sx_status_t __dbg_ircore_deinit_sections(struct core_dump_sections_s *core_dump_sections)
{
    cl_free(core_dump_sections->seg_mem);
    cl_free(core_dump_sections->prstatus_notes);
    cl_free(core_dump_sections->phdr);
    cl_free(core_dump_sections->ehdr);
    return SX_STATUS_SUCCESS;
}

static sx_status_t __dbg_ircore_init_ehdr(Elf32_Ehdr *ehdr)
{
    ehdr->e_ident[EI_MAG0] = ELFMAG0;
    ehdr->e_ident[EI_MAG1] = ELFMAG1;
    ehdr->e_ident[EI_MAG2] = ELFMAG2;
    ehdr->e_ident[EI_MAG3] = ELFMAG3;
    ehdr->e_ident[EI_CLASS] = ELFCLASS32;
    ehdr->e_ident[EI_DATA] = ELFDATA2MSB;
    ehdr->e_ident[EI_VERSION] = EV_CURRENT;
    ehdr->e_ident[EI_OSABI] = ELFOSABI_LINUX;
    ehdr->e_type = htobe16(ET_CORE);
    ehdr->e_machine = htobe16(EM_IRISC);
    ehdr->e_version = htobe32(EV_CURRENT);
    ehdr->e_phoff = htobe32(sizeof(Elf32_Ehdr));
    ehdr->e_ehsize = htobe16(sizeof(Elf32_Ehdr));
    ehdr->e_phentsize = htobe16(sizeof(Elf32_Phdr));
    ehdr->e_shentsize = htobe16(sizeof(Elf32_Shdr));
    ehdr->e_phnum = htobe16(PH_INDEX_NUM);
    return SX_STATUS_SUCCESS;
}

static sx_status_t __dbg_ircore_init_phdr(Elf32_Phdr *phdr_seg)
{
    phdr_seg->p_type = htobe32(PT_NOTE);
    return SX_STATUS_SUCCESS;
}

static sx_status_t __core_dump_init_phdr_seg(Elf32_Phdr *phdr_seg)
{
    phdr_seg->p_type = htobe32(PT_LOAD);
    phdr_seg->p_flags = htobe32(PF_R | PF_W | PF_X);
    return SX_STATUS_SUCCESS;
}

/*
 *
 * core_dump_init_sections
 * Init the core dump sections - elf data structure to be written to file
 */

static sx_status_t __dbg_ircore_init_sections(struct core_dump_sections_s *core_dump_sections)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    Elf32_Ehdr                       *ehdr_p = NULL;
    Elf32_Phdr                       *phdr_p = NULL;
    struct core_dump_prstatus_note_s *prstatus_notes_p = NULL;
    char                             *seg_mem_p = NULL;


    /*dump all iriscs */
    core_dump_sections->irisc_count = num_of_iriscs;

    /* Allocate memory for the core dump sections. */
    ehdr_p = (Elf32_Ehdr*)cl_malloc(sizeof(Elf32_Ehdr));
    if (ehdr_p == NULL) {
        SX_LOG_ERR("failed to malloc ehdr");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    memset(ehdr_p, 0, sizeof(Elf32_Ehdr));
    core_dump_sections->ehdr = ehdr_p;


    phdr_p = (Elf32_Phdr*)cl_malloc(PH_INDEX_NUM * sizeof(Elf32_Phdr));
    if (phdr_p == NULL) {
        SX_LOG_ERR("failed to malloc phdr");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    memset(phdr_p, 0, sizeof(Elf32_Phdr));
    core_dump_sections->phdr = phdr_p;


    prstatus_notes_p =
        (struct core_dump_prstatus_note_s *)cl_malloc(
            sizeof(struct core_dump_prstatus_note_s) * core_dump_sections->irisc_count);
    if (prstatus_notes_p == NULL) {
        SX_LOG_ERR("failed to malloc prstatus_notes_p");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    memset(prstatus_notes_p, 0, sizeof(struct core_dump_prstatus_note_s) * core_dump_sections->irisc_count);
    core_dump_sections->prstatus_notes = prstatus_notes_p;


    core_dump_sections->seg_mem_size = SEG_MEM_IRISC_SIZE * core_dump_sections->irisc_count;
    seg_mem_p = (char*)cl_malloc(sizeof(char) * core_dump_sections->seg_mem_size);
    if (seg_mem_p == NULL) {
        SX_LOG_ERR("failed to malloc prstatus_notes_p");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    memset(seg_mem_p, 0, sizeof(char) * core_dump_sections->seg_mem_size);
    core_dump_sections->seg_mem = seg_mem_p;


    /* Init the headers. */
    rc = __dbg_ircore_init_ehdr(core_dump_sections->ehdr);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed init ehdr");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = __dbg_ircore_init_phdr(&core_dump_sections->phdr[PH_INDEX_NOTE]);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed init phdr note");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = __core_dump_init_phdr_seg(&core_dump_sections->phdr[PH_INDEX_SEG_MEM]);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed init phdr seg");
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    return rc;
}


static sx_status_t __dbg_ircore_write_core_info(FILE *core_file, struct core_dump_sections_s *core_dump_sections)
{
    sx_status_t rc = SX_STATUS_SUCCESS, rc_out = SX_STATUS_SUCCESS;
    size_t      size_t_rc = 0;

    /* Write the file and section headers. */

    size_t_rc = fwrite(core_dump_sections->ehdr,
                       sizeof(*core_dump_sections->ehdr), 1, core_file);
    if (size_t_rc != 1) {
        SX_LOG_ERR("fwrite(ehdr) returned error\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }
    size_t_rc = fwrite(core_dump_sections->phdr,
                       sizeof(*core_dump_sections->phdr), PH_INDEX_NUM, core_file);
    if (size_t_rc != PH_INDEX_NUM) {
        SX_LOG_ERR("fwrite(phdr) returned error\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* Write the sections data. */

    size_t_rc = fwrite(core_dump_sections->prstatus_notes,
                       be32toh(core_dump_sections->phdr[PH_INDEX_NOTE].p_memsz),
                       1,
                       core_file);
    if (size_t_rc != 1) {
        SX_LOG_ERR("fwrite(prstatus_notes) returned error\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }
    size_t_rc = fwrite(core_dump_sections->seg_mem,
                       be32toh(core_dump_sections->phdr[PH_INDEX_SEG_MEM].p_memsz),
                       1,
                       core_file);
    if (size_t_rc != 1) {
        SX_LOG_ERR("fwrite(seg_mem) returned error\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    rc_out = fclose(core_file);
    if (rc_out) {
        SX_LOG_ERR("fclose(core_file) returned error\n");
        rc = SX_STATUS_ERROR;
    }

    return rc;
}

static sx_status_t __dbg_ircore_dump_scan(sx_dev_id_t dev_id, struct core_dump_sections_s *core_dump_sections)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    u_int32_t   irisc_n = 0;
    u_int32_t   offset = 0;
    int         ph_index = 0;
    Elf32_Phdr *current_phdr = 0;
    boolean_t   special_irisc = FALSE;

    rc = __dbg_ir_target_halt(dev_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Iriscs cannot halt\n");
        goto out;
    }

    /* Set the note header. */
    current_phdr = &core_dump_sections->phdr[PH_INDEX_NOTE];

    current_phdr->p_memsz = current_phdr->p_filesz =
        htobe32(sizeof(*core_dump_sections->prstatus_notes) * core_dump_sections->irisc_count);

    /* Scan the registers of all iRISCs. */
    for (irisc_n = 0; irisc_n < num_of_iriscs; irisc_n++) {
        special_irisc = (1 << irisc_n & special_irisc_mask);
        SX_LOG_DBG("%d", special_irisc);
        rc = __dbg_ircore_dump_scan_registers(dev_id, core_dump_sections, irisc_n,
                                              !special_irisc, irisc_n);
        if (rc) {
            SX_LOG_ERR("core_dump_scan_registers returned error\n");
            goto out;
        }
    }
    /* Scan the stack memory. */
    rc = __dbg_ircore_dump_scan_memory(dev_id, core_dump_sections);  /*, specific_irisc_flag,specific_irisc_n); */


    /* Set the offsets of all the segments. */

    offset = sizeof(*core_dump_sections->ehdr) +
             sizeof(*core_dump_sections->phdr) * PH_INDEX_NUM;
    for (ph_index = 0; ph_index < PH_INDEX_NUM; ph_index++) {
        current_phdr = &core_dump_sections->phdr[ph_index];
        current_phdr->p_offset = htobe32(offset);
        offset += be32toh(current_phdr->p_filesz);
    }

    rc = __dbg_ir_target_continue(dev_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("target_continue returned error\n");
    }
out:
    return rc;
}


static sx_status_t __dbg_ir_extract_core_dump(sx_dev_id_t dev_id, sxd_chip_types_t chip_type, FILE *fp)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    struct core_dump_sections_s core_dump_sections = {0};
    int                         err = 0;
    boolean_t                   cr_access_inited = FALSE;

    err = sx_cr_access_init();
    if (err != 0) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("sx_cr_access_init failed, err = %d\n", err);
        goto out;
    }
    cr_access_inited = TRUE;

    rc = __dbg_ircore_init(dev_id, chip_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed on initialization of IRISCs \n");
        goto out;
    }
    /* Init the core dump sections. */
    rc = __dbg_ircore_init_sections(&core_dump_sections);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed on section initialization\n");
        goto out;
    }
    /* Read the registers and stack memory of the requested iRISCs. */
    rc = __dbg_ircore_dump_scan(dev_id, &core_dump_sections);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("core dump scan failed\n");
        goto out;
    }
    /* Write out the core file. */
    rc = __dbg_ircore_write_core_info(fp, &core_dump_sections);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("write core failed\n");
        goto out;
    }
    /*Deinit the core dump sections. */
    rc = __dbg_ircore_deinit_sections(&core_dump_sections);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("was not able to free memory sections\n");
        goto out;
    }
out:
    if (cr_access_inited) {
        err = sx_cr_access_deinit();
        if (err != 0) {
            SX_LOG_ERR("sx_cr_access_deinit failed, err = %d\n", err);
        }
    }

    return rc;
}

static sx_status_t __dbg_thread_bt_core_dump(FILE *threads_bt_f, const char* path)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    sx_status_t  rc_unlink = SX_STATUS_SUCCESS;
    char         buff[1024];
    FILE       * fsrc;
    char         rnad_file_name[256] = { 0 };
    int          bytes_read;
    char         cmd[1024] = {0};
    int          f_rc = 0;
    int          system_rc = 0;
    boolean_t    restore_tread_monitor = FALSE;
    sxd_status_t sxd_rc = SXD_STATUS_SUCCESS;
    size_t       size_t_rc = 0;

    /* Before running thread BT we will disable the health check thread monitor to
     * prevent false alarm in case user wants thread back trace during sdk dump */
    sxd_rc = sxd_access_sdk_update_thread_monitor(0, 0, THREAD_MONITOR_DISCONNECT_E);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        rc = sxd_status_to_sx_status(sxd_rc);
        SX_LOG_ERR(
            "Failed to disable main thread monitoring because of debug dump ext, error (%s)\n",
            sx_status_str(rc));
        goto out;
    }
    restore_tread_monitor = TRUE;

    snprintf(rnad_file_name, sizeof(rnad_file_name) - 1, "%s/thread_bt.tmp", path);

    snprintf(cmd,
             sizeof(cmd),
             "pidof sx_sdk >/dev/null");

    system_rc = system(cmd);
    if (system_rc != 0) {
        SX_LOG_NTC("SDK Process is not running so threads BT dump will not generate go out gracefully \n");
        rc = SX_STATUS_SUCCESS;
        goto out;
    }
    /* Check if GDB is installed otherwise SDK BT cannot be generated */
    snprintf(cmd,
             sizeof(cmd),
             "which gdb >/dev/null");

    system_rc = system(cmd);
    if (system_rc != 0) {
        SX_LOG_NTC("GDB is not installed in the system so threads BT dump can not be generate. \n");
        rc = SX_STATUS_SUCCESS;
        strncpy(buff,
                "Empty dump file because GDB is not installed in the system so threads BT dump cannot be generated\n",
                sizeof(buff) - 1);
        buff[sizeof(buff) - 1] = '\0'; /* Ensure null-termination */
        size_t_rc = fwrite(buff, strlen(buff), 1, threads_bt_f);
        if (size_t_rc != 1) {
            SX_LOG_ERR("fwrite returned error while trying to write empty dump message (GDB not installed) \n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        fflush(threads_bt_f);
        goto out;
    }

    snprintf(cmd,
             sizeof(cmd),
             "gdb -p `pidof sx_sdk` --batch -ex 'thread apply all bt' -ex 'quit' > %s 2>/dev/null",
             rnad_file_name);

    system_rc = system(cmd);
    if (system_rc != 0) {
        SX_LOG_ERR("failed to add threads bt to file %s \n", rnad_file_name);
        rc = SX_STATUS_ERROR;
        goto unlink_tmp_file;
    }
    fsrc = fopen(rnad_file_name, "r");
    if (!fsrc) {
        SX_LOG_ERR("failed to open file %s on read mode \n", rnad_file_name);
        rc = SX_STATUS_ERROR;
        goto unlink_tmp_file;
    }
    while (!feof(fsrc)) {
        bytes_read = fread(buff, 1, sizeof(buff), fsrc);
        if (bytes_read > 0) {
            fwrite(buff, 1, bytes_read, threads_bt_f);
        }
    }

    f_rc = fclose(fsrc);
    if (0 != f_rc) {
        SX_LOG_ERR("failed to close threads_bt_f file, err [%d]: %s\n", errno, strerror(errno));
        rc = SX_STATUS_ERROR;
        goto unlink_tmp_file;
    }

unlink_tmp_file:
    rc_unlink = unlink(rnad_file_name);
    if (rc_unlink != 0) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("unlink failed (%s) - file (%s).\n",
                   strerror(errno), rnad_file_name);
    }

out:
    if (restore_tread_monitor) {
        sxd_rc = sxd_access_sdk_update_thread_monitor(0, 0, THREAD_MONITOR_RECONNECT_E);
        if (sxd_rc != SXD_STATUS_SUCCESS) {
            rc = sxd_status_to_sx_status(sxd_rc);
            SX_LOG_ERR(
                "Failed to reactivate main thread monitoring after finish debug dump ext, error (%s)\n",
                sx_status_str(rc));
        }
    }
    return rc;
}

static sx_status_t __dbg_secure_ir_extract_core_dump(sx_dev_id_t dev_id, sxd_chip_types_t chip_type, FILE *core_file)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = sxd_status_to_sx_status(sxd_secure_fw_op_transaction_dump(chip_type,
                                                                   dev_id,
                                                                   SX_CR_DUMP_OP_START_GDB,
                                                                   core_file,
                                                                   NULL,
                                                                   NULL));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed on fw core dump.\n");
        goto out;
    }

out:
    if (0 != fsync(fileno(core_file))) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("FW dump generation failed to sync core dump file.\n");
    }

    fclose(core_file);
    return rc;
}

static sx_status_t __dbg_ir_target_halt(sx_dev_id_t dev_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    dbg_reg_val = 0, rintra_reg_val = 0;
    uint32_t    interrupt_ip = halt_code_ip; /* holds HALT_DEVICE address from fw dump */
    int         i;
    int         self_code_bp = 0;


    /* Check target state */
    CR_READ(dbg_reg_offset, &dbg_reg_val);
    if (dbg_reg_val & __MISACC) {
        SX_LOG_ERR(" misaccess in irisc  !! \n");
        return SX_STATUS_ERROR;
    }

    if (dbg_reg_val & __DBG_EN) {
        /* Target already in debug mode */
        SX_LOG_INF("target already halted - jumping to target_halted\n");
        goto target_halted;
    }
    CR_WRITE(RINT_BASE, halt_code_ip);
    CR_WRITE(dbg_set_offset, __REMOTE);

    CR_WRITE(BP0_MASK, 0x90080002); /*stop all iRISCs on any code fetches except from addr 0 */
    CR_WRITE(BP0_ADDR, 0);

    self_code_bp = 1;

    /* Poll for target stop */
    for (i = 0; i < 10; i++) {
        CR_READ(dbg_reg_offset, &dbg_reg_val);
        if (dbg_reg_val & __DBG_EN) {  /*check if current iRISC stopped */
            goto target_halted;                     /* Target already in debug mode */
        }
    }

    /* Could not stop target */
    SX_LOG_ERR("can't halt irisc %d  halt_addr =0x%x dbg_reg_val =0x%x dbg_reg_offset = 0x%x\n",
               gdbs_set.irisc_n,
               interrupt_ip,
               dbg_reg_val,
               dbg_reg_offset);
    return SX_STATUS_ERROR;

target_halted:
    SX_LOG_INF("target_halted 0x%x\n", dbg_reg_val);
    CR_READ(RINTRA, &rintra_reg_val);

    if (!rintra_reg_val) {
        CR_READ(f_ip_offset, &rintra_reg_val);     /*fetch IP (next command irisc fetch) */
        CR_WRITE(RINTRA, rintra_reg_val);
    }


    target_stat.dbg_reg = dbg_reg_val;        /* store halt condition */
    __dbg_ir_target_clr_hwbp_all(dev_id);    /* disable all code/data breakpoints to enable debugging */
    if (self_code_bp) {
        target_stat.dbg_reg &= ~__CODE_BP;         /* remove __CODE_BP */
    }

    /* Debug mode init . Clear all causes */
    CR_WRITE(dbg_clr_offset,
             __DBG_CRDY | __DBG_RET | __RINT | __CODE_BP | __READ_BP | __WRITE_BP
             | __RTRAP | __MISACC | __OORCODE | __OORDATA);
    CR_WRITE(dbg_set_offset, __INT_D);


    /* Exit from rint handler */
    /* 4 nop to clear pipe */

    EXEC_OPCODE(NOP_OPCODE, "nop");     /* nop */
    EXEC_OPCODE(NOP_OPCODE, "nop");     /* nop */
    EXEC_OPCODE(NOP_OPCODE, "nop");     /* nop */
    EXEC_OPCODE(RIRET_OPCODE, "riret");
    EXEC_OPCODE(NOP_OPCODE, "nop");     /* Taken br need nop */

    gdbs_stat |= __DEBUG_MODE;


    return rc;
}


static sx_status_t __dbg_ir_target_continue(sx_dev_id_t dev_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    char        mnemonics[30];

/* In target_halt we advance 1 command past the point where we stopped. */
/* Here we rewind that command because of core dump. */

    sprintf(mnemonics, "bri .-%d", 4);
    EXEC_OPCODE(BRI_OPCODE(-4), mnemonics); /* Take back bri .-4 */
    EXEC_OPCODE(NOP_OPCODE, "nop");   /* Taken br need nop */


    if (!(gdbs_stat & __DEBUG_MODE)) {
        return SX_STATUS_ERROR;
    }
/* Force exit from debug mode on next fetch from debug_code */
    CR_WRITE(RINTRA, 0); /*part of bug workaround (FM20548): RINTRA=0 on leaving debug mode */
    CR_WRITE(dbg_set_offset, __DBG_RET | __REMOTE);

/* Set dbg_crdy */
    CR_WRITE(dbg_set_offset, __DBG_CRDY);
    gdbs_stat &= ~__DEBUG_MODE;

/* Enable interrupts */
    CR_WRITE(dbg_clr_offset, __INT_D);


    return rc;
}

static sx_status_t __dbg_ir_target_read_reg(sx_dev_id_t dev_id, ir_regs_t reg, uint32_t* val)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    char        mnemonics[30];


    switch (reg) {
    case cc:
        rc = CR_READ(CC_REG, val);
        break;

    case gctrl:
        rc = CR_READ(GCTRL, val);
        break;

    case intra:
        rc = CR_READ(INTRA, val);
        break;

    case callra:
        rc = CR_READ(CALLRA, val);
        break;

    case ip:
        rc = CR_READ(f_ip_offset, val);
        break;

    case irisc_id:
        rc = CR_READ(IRISC_ID, val);
        break;

    case intcause:
        rc = CR_READ(INTCAUSE, val);
        break;

    case gpreg:
        rc = CR_READ(GPREG, val);
        break;

    case nip:
        rc = CR_READ(NXTINSTP, val);    /*next instruction pointer */
        break;

    case incause_clr:
        rc = CR_READ(INTCAUSE_CLR, val);
        break;

    case intbase:
        rc = CR_READ(INTBASE, val);
        break;

    case intenable:
        rc = CR_READ(INTENABLE, val);
        break;

    case iriscboot:
        rc = CR_READ(IRISCBOOT, val);
        break;

    default:
        /*read r0-r31 */
        if (reg > r31) {
            SX_LOG_ERR(" Don't know how to read r%d\n",  reg);
            return SX_STATUS_ERROR;
        }

        /* Execute stcr reg,GPREG */
        sprintf(mnemonics, "stcr r%d, GPREG", reg);
        rc = EXEC_OPCODE(STCR_OPCODE(reg, GPREG), mnemonics);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Was not able to store r%d in GPREG\n", reg);
            return rc;
        }
        /* Read register value from gpreg */
        CR_READ(GPREG, val);

        /* Go back one instruction */
        rc = EXEC_OPCODE(BRI_OPCODE(-4), "br .-4   ; restore ip,fip");
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Was not able to go back one instruction\n");
            return rc;
        }
        EXEC_OPCODE(NOP_OPCODE, "nop");
        /* Taken br need nop */
    }


    return rc;
}

static sx_status_t __dbg_ir_target_read_all_regs(sx_dev_id_t dev_id)
{
    int         i;
    sx_status_t rc = SX_STATUS_SUCCESS;


    for (i = 0; i < NUMBER_OF_REGS; i++) {
        rc = __dbg_ir_target_read_reg(dev_id, (ir_regs_t)i, &target_stat.regs[i]);
        if (rc) {
            return rc;
        }
    }


    return rc;
}


static sx_status_t __dbg_ir_target_exec_opcode(sx_dev_id_t dev_id, uint32_t opcode) /*char *mnemonics) { */
{
    int      retry;
    uint32_t reg_val = 0;

    /* Write opcode to dbg_code */
    CR_WRITE(dbg_code_offset, opcode);

    /* Set dbg_crdy */
    CR_WRITE(dbg_set_offset, __DBG_CRDY);

    /* Wait dbg_crdy cleared by HW */
    for (retry = 0; retry < 30; retry++) {
        CR_READ(dbg_reg_offset, &reg_val);
        if ((reg_val & __DBG_CRDY) == 0) {
            return SX_STATUS_SUCCESS;
        }
    }

    /* Instruction was not fetched */
    SX_LOG_ERR("Can't execute instruction through debug hooks  %x opcode = %x \n", dbg_reg_offset, opcode);
    return SX_STATUS_ERROR;
}


static sx_status_t __dbg_ir_target_ram_read4(sx_dev_id_t dev_id, char* buf, uint32_t addr)
{
    int      rc = SX_STATUS_SUCCESS;
    uint32_t curr_addr = addr;
    char     mnemonics[30];
    int      back_cntr = 0;
    uint32_t tmp_r31[num_of_iriscs];
    uint32_t tmp_r30[num_of_iriscs];
    int      regs_stored = 0;
    uint32_t i = 0;

    SX_MEM_CLR_ARRAY(tmp_r30, num_of_iriscs, uint32_t);
    SX_MEM_CLR_ARRAY(tmp_r31, num_of_iriscs, uint32_t);

    /* Store registers r31, r30 */
    if (!regs_stored) {
        regs_stored = 1;
        EXEC_OPCODE(STCR_OPCODE(31, GPREG), "stcr r31,GPREG");
        back_cntr++;
        for (i = 0; i < num_of_iriscs; i++) {
            if (1 << i & special_irisc_mask) {   /*skip special iriscs */
                continue;
            }
            CR_READ_IRISC(GPREG, tmp_r31 + i, i);
        }
        EXEC_OPCODE(STCR_OPCODE(30, GPREG), "stcr r30,GPREG");
        back_cntr++;
        for (i = 0; i < num_of_iriscs; i++) {
            if (1 << i & special_irisc_mask) {  /*skip special iriscs */
                continue;
            }
            CR_READ_IRISC(GPREG, tmp_r30 + i, i);
        }
    }
    /* Load guaranteed word-aligned address to r31 */
    CR_WRITE(GPREG, curr_addr);
    EXEC_OPCODE(LDCR_OPCODE(31, GPREG), "ldcr r31, GPREG");
    back_cntr++;
    EXEC_OPCODE(LD4_OPCODE(30, 31, 0), "ld4 (r31,r0),r30");
    back_cntr++;
    /*ld4 is 2 cycles - need 2 nop */
    EXEC_OPCODE(NOP_OPCODE, "nop ; compensate");
    back_cntr++;
    EXEC_OPCODE(NOP_OPCODE, "nop ; compensate");
    back_cntr++;

    EXEC_OPCODE(STCR_OPCODE(30, GPREG), "stcr r30,GPREG");
    back_cntr++;
    CR_READ(GPREG, (uint32_t*)buf);


    /* Restore registers r31, r30 and jmp back */
    if (regs_stored) {
        /* Restore r31 */
        for (i = 0; i < num_of_iriscs; i++) {
            if (1 << i & special_irisc_mask) {  /*skip special iriscs */
                continue;
            }
            CR_WRITE_IRISC(GPREG, tmp_r31[i], i);
        }
        EXEC_OPCODE(LDCR_OPCODE(31, GPREG), "ldcr r31, GPREG");
        back_cntr++;

        /* Restore r30 */
        for (i = 0; i < num_of_iriscs; i++) {
            if (1 << i & special_irisc_mask) { /*skip special iriscs */
                continue;
            }
            CR_WRITE_IRISC(GPREG, tmp_r30[i], i);
        }
        EXEC_OPCODE(LDCR_OPCODE(30, GPREG), "ldcr r30, GPREG");
        back_cntr++;

        /* Restore f_ip */
        sprintf(mnemonics, "bri .-%d", back_cntr * 4);
        EXEC_OPCODE(BRI_OPCODE(-back_cntr * 4), mnemonics); /* Take back bri .-num_of_executed */
        EXEC_OPCODE(NOP_OPCODE, "nop");   /* Taken br need nop */
    }


    return rc;
}


static sx_status_t __dbg_ir_target_read_memory(sx_dev_id_t dev_id, char* buf, uint32_t addr)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    /* if reading HW data breakpoint address disable data breakpoint */
    __dbg_ir_handle_hwbp_on_memaccess(dev_id, addr, 0);

    /*accessing only addresses in cache addr <0x80000000 */
    rc = __dbg_ir_target_ram_read4(dev_id, buf, addr);
    return rc;
}

static sx_status_t __dbg_ir_target_read_l2_cache_line(sx_dev_id_t dev_id, char* buf, uint32_t addr)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    l2_gw_copy = 0;
    uint32_t    l2_gw_copy_swapped = 0;
    uint32_t    l2_gw_base = (IRISC_CACHE_ADDRESS_MASK & addr) | L2_DATA_WAY |
                             IRISC_CACHE_CODE_READ_CMD;
    uint32_t l2_gw_base_swapped = htobe32(l2_gw_base);
    char     buf_swapped[TARGET_CACHE_LINE_BYTES];
    int      i = 0;

    /* Write the address to the L2 GW. */
    CR_WRITE_GLOBAL(ir_cache_l2_gw_base_addr, l2_gw_base_swapped);
    /* Wait until the busy bit is cleared. */
    do {
        CR_READ_GLOBAL(ir_cache_l2_gw_base_addr + ir_cache_l2_gw_copy_offest,
                       &l2_gw_copy);
        l2_gw_copy_swapped = be32toh(l2_gw_copy);
    } while (l2_gw_copy_swapped & ir_cache_l2_gw_busy_mask);
    /* Read the data. */
    CR_READ_GLOBAL_BLOCK(ir_cache_l2_gw_base_addr + ir_cache_l2_gw_data_offest,
                         buf_swapped, TARGET_CACHE_LINE_BYTES);
    /*data needs to be  swapped */
    for (i = 0; i < (TARGET_CACHE_LINE_BYTES); i += 4) {
        buf[i + 3] = buf_swapped[i];
        buf[i + 2] = buf_swapped[i + 1];
        buf[i + 1] = buf_swapped[i + 2];
        buf[i] = buf_swapped[i + 3];
    }
    return rc;
}

static sx_status_t __dbg_ir_handle_hwbp_on_memaccess(sx_dev_id_t dev_id, uint32_t addr,  int reenable)
{
    int             rc = SX_STATUS_SUCCESS;
    static uint32_t store_mask[NUM_OF_BPS] = { 0 };
    static uint32_t store_hwbp[NUM_OF_BPS];
    static uint32_t store_hwbp_min[NUM_OF_BPS];

    if (gdbs_set.flags & __ARBEL_BP) {
        /* if HW data breakpoint address is affected, disable data breakpoint */
        uint32_t bp_addr, base_bp_addr;
        int      regdef, bpno;
        base_bp_addr = BP0_OFFSET;

        if (reenable) {
            for (bpno = 0, bp_addr = base_bp_addr; bpno < NUM_OF_BPS; bp_addr += bp_size, bpno++) {
                regdef = (store_mask[bpno] >> 16) & 0xF;
                if ((regdef == 8) || (regdef == 9)) { /*if HWBP */
                    if (store_hwbp_min[bpno] >= addr) {
                        CR_WRITE(bp_addr + BP_LO_OFFSET, store_hwbp[bpno]);
                        CR_WRITE(bp_addr + BP_HI_OFFSET, store_mask[bpno]);
                    }
                }
            }
        } else {
            for (bpno = 0, bp_addr = base_bp_addr; bpno < NUM_OF_BPS; bp_addr += bp_size, bpno++) {
                CR_READ(bp_addr, &store_mask[bpno]);
                regdef = (store_mask[bpno] >> 16) & 0xF;
                if ((regdef == 8) || (regdef == 9)) { /*if HWBP */
                    CR_READ(bp_addr + BP_LO_OFFSET, &store_hwbp[bpno]);
                    store_hwbp_min[bpno] = store_hwbp[bpno] & ((0xffffffff) << (store_mask[bpno] & 0x3F));
                    if (store_hwbp_min[0] >= addr) {
                        CR_WRITE(bp_addr + BP_HI_OFFSET, 0x00020000); /*disables HWBP */
                    }
                }
            }
        }
    } else {
        SX_LOG_ERR("flags are not set\n");
        rc = SX_STATUS_ERROR;
    }
    return rc;
}

static sx_status_t __dbg_ir_target_clr_hwbp_all(sx_dev_id_t dev_id)
{
    uint32_t old_bp_reg, bp_addr;

    old_bp_reg = 0;

    for (bp_addr = BP0_OFFSET; bp_addr < BP0_OFFSET + NUM_OF_BPS * bp_size; bp_addr += bp_size) {
        CR_READ(bp_addr, &old_bp_reg);
        CR_WRITE(bp_addr + BP_HI_OFFSET, 0x00020000); /*disables HWBP */
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __fw_dbg_device_tiles_info_init(sx_dev_id_t dev_id)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    struct ku_dev_info dev_info;
    sxd_status_t       sxd_st = SXD_STATUS_SUCCESS;

    if (sxd_fw_dbg_tiles_info_is_inited()) {
        goto out;
    }

    memset(&dev_info, 0, sizeof(dev_info));
    dev_info.dev_id = dev_id;

    sxd_st = sxd_get_device_info(&dev_info);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get device information (err=%d)\n", sxd_st);
        err = sxd_status_to_sx_status(sxd_st);
        goto out;
    }

    sxd_fw_dbg_tiles_info_set(dev_info.dev_info.dev_info_ro.mgir.fw_info.disabled_tiles_bitmap);

out:
    return err;
}

static sx_status_t __dbg_generate_ir_core_dump(const char               *path,
                                               const sx_dev_id_t         dev_id,
                                               const struct ku_dev_info *dev_info_p,
                                               sxd_chip_types_t          chip_type)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    FILE       *fp = NULL;

    SX_LOG_NTC("Starting IR-Core dump\n");

    /* generate irisc core file name */
    /* create the file name and the full path */
    rc = generate_dump_file(path, dev_id,  "ir_core", "core", &fp);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to generate ir core dump file name");
        goto out;
    }

    if ((chip_type == SXD_CHIP_TYPE_SPECTRUM4) || (chip_type == SXD_CHIP_TYPE_SPECTRUM5) ||
        (chip_type == SXD_CHIP_TYPE_QUANTUM2)) {
        if (dev_info_p->dev_info.dev_info_ro.q_fw.cap_dump_host_size_gdb == 0) {
            SX_LOG_NTC("FW does not support GDB core dump\n");
            fprintf(fp, "FW does not support GDB core dump\n");
            fclose(fp);
            rc = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        rc = __dbg_secure_ir_extract_core_dump(dev_id, chip_type, fp);
    } else {
        rc = __dbg_ir_extract_core_dump(dev_id, chip_type, fp);
    }
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write iriscs core dump");
    } else {
        SX_LOG_NTC("SDK extra dump file iriscs core saved\n");
    }

out:
    SX_LOG_NTC("Finished IR-Core dump\n");
    return rc;
}

static void __notify_dump_completion(sx_dev_id_t dev_id, boolean_t dump_success, sxd_handle dev_handle)
{
    sxd_event_health_notification_t sdk_health;
    struct ku_write                 ku_write;
    struct ku_iovec                 iov;
    int                             ret = 0;

    memset(&sdk_health, 0, sizeof(sdk_health));
    memset(&ku_write, 0, sizeof(ku_write));
    memset(&iov, 0, sizeof(iov));

    sdk_health.device_id = dev_id;
    sdk_health.irisc_id = DBG_ALL_IRISCS;
    sdk_health.was_debug_started = FALSE;
    sdk_health.severity = SXD_HEALTH_SEVERITY_NOTICE;
    if (dump_success == TRUE) {
        sdk_health.cause = SXD_HEALTH_CAUSE_DUMP_COMPLETED;
    } else {
        sdk_health.cause = SXD_HEALTH_CAUSE_DUMP_FAILED;
    }

    ku_write.meta.swid = 0;
    ku_write.meta.system_port_mid = 0;
    ku_write.meta.to_cpu = 0;
    ku_write.meta.type = SX_PKT_TYPE_LOOPBACK_CTL;
    ku_write.meta.rdq = 0;
    ku_write.meta.lp = 0;
    ku_write.meta.dev_id = dev_id;
    ku_write.meta.etclass = 6;
    ku_write.meta.loopback_data.trap_id = SX_TRAP_ID_SDK_HEALTH_EVENT;
    ku_write.meta.loopback_data.is_lag = 0;
    ku_write.meta.loopback_data.lag_subport = 0;
    ku_write.vec_entries = 1;
    ku_write.iov = &iov;
    ku_write.meta.dev_id = dev_id;
    ku_write.iov->iov_base = &sdk_health;
    ku_write.iov->iov_len = sizeof(sdk_health);

    /* SDK health event --> NOS */
    ret = sxd_send(dev_handle, &ku_write, sizeof(struct ku_write));
    if (ret != sizeof(ku_write)) {
        SX_LOG_ERR("Could not send SDK health event, err: %s.\n", strerror(errno));
    }
}


static sx_status_t __dbg_generate_fw_trace_dump(const char *path, const sx_dev_id_t dev_id, sxd_chip_types_t chip_type)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    FILE       *fw_trace_file = NULL;
    boolean_t   is_emad_used = FALSE;

    SX_LOG_NTC("Starting FW-Trace dump\n");

    /* make sure that registers are accessed through EMAD */
    rc = sxd_status_to_sx_status(sxd_dpt_is_emad_used(dev_id, &is_emad_used));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("FW TRACE: Failed to check if device is using EMAD\n");
        goto out;
    }

    if (!is_emad_used) {
        /* On IB systems using EMADs is not mandatory */
        switch (chip_type) {
        case SX_CHIP_TYPE_QUANTUM:
        case SX_CHIP_TYPE_QUANTUM2:
        case SX_CHIP_TYPE_QUANTUM3:
        case SX_CHIP_TYPE_QUANTUM4:
            break;

        default:
            SX_LOG_NTC("FW TRACE: Device is not using EMAD, dump will not be taken\n");
            goto out;
        }
    }

    /* generate FW trace file name */
    /* create the file name and the full path */
    rc = generate_dump_file(path, dev_id, "fw_trace", "txt", &fw_trace_file);
    if (rc != SX_STATUS_SUCCESS) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("FW trace file name generation fail for device id:[%u] path =%s\n",
                   dev_id, path);
        goto out;
    }

    rc = sxd_status_to_sx_status(sxd_fw_trace_extract(dev_id, fw_trace_file));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_WRN("Failed on FW trace extract.\n");
        /* Fail quietly*/
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

out:
    if (fw_trace_file) {
        if (0 != fsync(fileno(fw_trace_file))) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("FW trace generation failed to close FW trace dump file.\n");
        }
        fclose(fw_trace_file);
    }

    SX_LOG_NTC("Finished FW-Trace dump\n");
    return rc;
}

static sx_status_t __dbg_generate_thread_bt_dump(const char *path, const sx_dev_id_t dev_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    FILE       *threads_bt_file = NULL;

    SX_LOG_NTC("Starting SDK threads backtrace dump\n");


    /* generate FW trace file name */
    /* create the file name and the full path */
    rc = generate_dump_file(path, dev_id, "sdk_threads_backtrace", "txt", &threads_bt_file);
    if (rc != SX_STATUS_SUCCESS) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Threads backtrace file name generation fail for device id:[%u] path =%s\n",
                   dev_id, path);
        goto out;
    }
    rc = __dbg_thread_bt_core_dump(threads_bt_file, path);


out:
    if (threads_bt_file) {
        if (0 != fsync(fileno(threads_bt_file))) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("Thread stack generation failed to close threads backtrace dump file.\n");
        }
        fclose(threads_bt_file);
    }

    SX_LOG_NTC("Finished Threads backtrace dump\n");
    return rc;
}

static sx_status_t __dbg_generate_single_crspace_dump(const sx_dbg_extra_info_t *dbg_params,
                                                      boolean_t                  reduced_dump,
                                                      sxd_chip_types_t           chip_type,
                                                      int                        dump_no,
                                                      uint32_t                  *address_count_p,
                                                      uint32_t                  *layer1_count_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    FILE       *stream_cr = NULL;
    uint8_t     dump_op = SX_CR_DUMP_OP_INVALID;
    char        dump_file_prefix[32];

    snprintf(dump_file_prefix, sizeof(dump_file_prefix) - 1, "cr_space_%d", dump_no);

    rc = generate_dump_file(dbg_params->path, dbg_params->dev_id, dump_file_prefix, "udmp", &stream_cr);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to generate ir core dump file name");
        goto out;
    }

    if ((chip_type == SXD_CHIP_TYPE_SPECTRUM4) || (chip_type == SXD_CHIP_TYPE_SPECTRUM5) ||
        (chip_type == SXD_CHIP_TYPE_QUANTUM2) ||
        (chip_type == SXD_CHIP_TYPE_QUANTUM3) ||
        (chip_type == SXD_CHIP_TYPE_QUANTUM4)) {
        dump_op = (reduced_dump) ? SX_CR_DUMP_OP_START_REDUCED_FLAT : SX_CR_DUMP_OP_START_FLAT;
        rc = sxd_status_to_sx_status(sxd_secure_fw_op_transaction_dump(chip_type,
                                                                       dbg_params->dev_id,
                                                                       dump_op,
                                                                       stream_cr,
                                                                       address_count_p,
                                                                       layer1_count_p));
        if (rc != SX_STATUS_SUCCESS) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR(
                "dbg_generate_dump_ext failed retrieving FW instructions for device id:[%u] ASIC type:[%d,%s]\n",
                dbg_params->dev_id,
                chip_type,
                sx_chip_type_str((sx_chip_types_t)chip_type));
            goto out;
        }
    } else {
        /*
         * at this point the API will execute the "logic" in the "debug DB" that we read from the FW
         * this logic is saved in the structure:
         * the ASIC type can be gotten per device id from the DPT ??
         * sx_chip_types_t    dev_type;
         */
        rc = sxd_status_to_sx_status(sxd_fw_dbg_extract(chip_type, dbg_params->dev_id, stream_cr, address_count_p));
        if (rc != SX_STATUS_SUCCESS) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR(
                "dbg_generate_dump_ext failed retrieving FW instructions for device id:[%u] ASIC type:[%d,%s]\n",
                dbg_params->dev_id,
                chip_type,
                sx_chip_type_str((sx_chip_types_t)chip_type));
            goto out;
        }
    }

out:
    if (stream_cr != NULL) {
        if (0 != fsync(fileno(stream_cr))) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("FW dump generation failed to dump CR file.\n");
        }
        if (CL_SUCCESS != cl_fclose(stream_cr)) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("FW dump generation failed to close CR file.\n");
        }
    }

    return rc;
}

static sx_status_t __dbg_generate_gw_dump(const sx_dbg_extra_info_t *dbg_params, sxd_chip_types_t chip_type)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    FILE       *stream_gw = NULL;

    SX_LOG_ENTER();

    SX_LOG_NTC("Starting FW-GW dump\n");

    rc = generate_dump_file(dbg_params->path, dbg_params->dev_id, "gw", "udmp", &stream_gw);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to generate gw dump file name");
        goto out;
    }

    rc = sxd_status_to_sx_status(sxd_secure_fw_op_transaction_dump(chip_type,
                                                                   dbg_params->dev_id,
                                                                   SX_CR_DUMP_OP_START_GW,
                                                                   stream_gw,
                                                                   NULL,
                                                                   NULL));
    if (rc != SX_STATUS_SUCCESS) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR(
            "__dbg_generate_gw_dump failed retrieving FW GW dump for device id:[%u] ASIC type:[%d,%s]\n",
            dbg_params->dev_id,
            chip_type,
            sx_chip_type_str((sx_chip_types_t)chip_type));
        goto out;
    }

out:

    if (stream_gw != NULL) {
        if ((0 != fsync(fileno(stream_gw))) || (CL_SUCCESS != cl_fclose(stream_gw))) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("FW GW dump generation failed to close GW file.\n");
        }
    }

    SX_LOG_NTC("Finished FW-GW dump\n");

    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __dbg_generate_driver_dump(const char *path, const sx_dev_id_t dev_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    FILE       *stream = NULL;

    SX_LOG_NTC("Starting driver dump\n");

    rc = generate_dump_file(path, dev_id, "driver", "txt", &stream);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Driver dump file name generation fail for device id:[%u] path =%s\n",
                   dev_id, path);
        goto out;
    }

    fprintf(stream, "\n"
            "***********************************************"
            "\n"
            " Driver "
            "\n"
            "***********************************************"
            "\n"
            );

    rc = sxd_status_to_sx_status(sxd_dbg_generate_driver_dump(stream));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to dump driver files (err=%d)\n", rc);
        goto out;
    }

out:
    if (stream) {
        if (0 != fsync(fileno(stream))) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("Driver Dump failed to close file.\n");
        }
        fclose(stream);
    }

    SX_LOG_NTC("Finished driver dump\n");

    return rc;
}

static sx_status_t __dbg_generate_dpt_dump(const char *path, sx_dev_id_t dev_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    FILE       *stream = NULL;

    SX_LOG_NTC("Starting DPT dump\n");

    rc = generate_dump_file(path, dev_id,  "dpt", "txt", &stream);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to generate DPT dump file name\n");
        goto out;
    }

    sxd_dpt_dump(stream, dev_id);

out:
    if (stream) {
        fclose(stream);
    }

    SX_LOG_NTC("Finished DPT dump\n");

    return rc;
}

static void __get_timestamp(struct timeval *tv)
{
    gettimeofday(tv, NULL);
}

static uint32_t __get_diff_msec(const struct timeval *tv_from)
{
    struct timeval now;

    gettimeofday(&now, NULL);

    if ((now.tv_sec < tv_from->tv_sec) || /* negative diff (in seconds) */
        ((now.tv_sec == tv_from->tv_sec) && (now.tv_usec < tv_from->tv_usec)) /* negative diff (in usecs) */) {
        return (uint32_t)-1;
    }

    return (uint32_t)((now.tv_sec * 1000 + now.tv_usec / 1000) -
                      (tv_from->tv_sec * 1000 + tv_from->tv_usec / 1000));
}

void __log_dump_duration(FILE                 *fp,
                         const char           *dump_name,
                         sx_status_t           dump_rc,
                         const struct timeval *tv_from,
                         uint32_t              raw_duration_msec /* used only if 'tv_from' is NULL */)
{
    uint32_t duration_msec;

    if (!fp) {
        return;
    }

    if (tv_from) {
        duration_msec = __get_diff_msec(tv_from);

        if (duration_msec == (uint32_t)-1) {
            fprintf(fp, "%-40s %-20s [Invalid duration]\n",
                    dump_name,
                    sx_status_str(dump_rc));
            return;
        }
    } else {
        duration_msec = raw_duration_msec;
    }

    fprintf(fp, "%-40s %u.%03u [%s]\n",
            dump_name,
            duration_msec / 1000,
            duration_msec % 1000,
            sx_status_str(dump_rc));
}

static sx_status_t __generate_crspace_dumps(const sx_dbg_extra_info_t *dbg_params_p,
                                            FILE                      *sum_fp,
                                            const struct ku_dev_info  *dev_info_p,
                                            sxd_chip_types_t           chip_type)
{
    sx_status_t                st = SX_STATUS_SUCCESS, rc = SX_STATUS_SUCCESS;
    char                       dump_name[40];
    struct timeval             tv_from_single;
    boolean_t                  reduced_dump;
    uint32_t                   single_diff, total_diff = 0;
    int                        dump_no;
    fw_dump_completion_state_t fw_dump_completion_state = FW_DUMP_COMPLETION_STATE_IDLE;
    uint32_t                   address_count;
    uint32_t                   layer1_count;

    SX_LOG_NTC("Generating %d CR-Space dumps\n", SX_NUM_OF_CR_SPACE_DUMPS);

    switch (chip_type) {
    case SX_CHIP_TYPE_SPECTRUM:
    case SX_CHIP_TYPE_SWITCH_IB:
    case SX_CHIP_TYPE_SWITCH_IB2:
    case SX_CHIP_TYPE_SPECTRUM_A1:
    case SX_CHIP_TYPE_SPECTRUM2:
    case SX_CHIP_TYPE_QUANTUM:
    case SX_CHIP_TYPE_QUANTUM2:
    case SX_CHIP_TYPE_QUANTUM3:
    case SX_CHIP_TYPE_QUANTUM4:
    case SX_CHIP_TYPE_SPECTRUM4:
    case SX_CHIP_TYPE_SPECTRUM5:
        /* its OK .. */
        break;

    case SX_CHIP_TYPE_SPECTRUM3:
        st = __fw_dbg_device_tiles_info_init(dbg_params_p->dev_id);
        if (st != SX_STATUS_SUCCESS) {
            st = SX_STATUS_ERROR;
            SX_LOG_ERR("Failed to retrieve tiles information during FW dump generation\n");
            goto out;
        }
        break;

    case SX_CHIP_TYPE_UNKNOWN:
    case SX_CHIP_TYPE_SWITCHX_A2:
    case SX_CHIP_TYPE_SWITCHX_A1:
    case SX_CHIP_TYPE_SWITCHX_A0:
        st = SX_STATUS_ERROR;
        SX_LOG_ERR("FW dump generation failed, unsupported ASIC type:[%d,%s]\n",
                   chip_type, sx_chip_type_str((sx_chip_types_t)chip_type));
        goto out;
        break;
        /* No default: we want any new ASIC to break this so it will appear in bringup! */
    }

    /* Before we take the CRSpace dump, we need to check if FW has requested to be notified when a dump is taken. */
    st = sxd_status_to_sx_status(sxd_fw_dbg_dump_completion_state(dbg_params_p->dev_id,
                                                                  TRUE /* query value */,
                                                                  &fw_dump_completion_state));
    if (st != SX_STATUS_SUCCESS) {
        st = SX_STATUS_ERROR;
        SX_LOG_ERR("dbg_generate_dump_ext failed querying fw dump completion state for device id:[%u]\n",
                   dbg_params_p->dev_id);
        goto out;
    }

    for (dump_no = 1; dump_no <= SX_NUM_OF_CR_SPACE_DUMPS; dump_no++) {
        /* the first iteration is a full dump, the rest are 'reduced' to minimize dump time.
         * we'll use the 'reduced' dumps only if FW supports it (cap_dump_host_size_reduced_flat > 0)
         */
        reduced_dump = (dump_no > 1 && dev_info_p->dev_info.dev_info_ro.q_fw.cap_dump_host_size_reduced_flat > 0);
        snprintf(dump_name, sizeof(dump_name) - 1, "CR-Space %d/%d (%s)",
                 dump_no,
                 SX_NUM_OF_CR_SPACE_DUMPS,
                 (reduced_dump ? "Reduced" : "Full"));
        layer1_count = 0;
        address_count = 0;

        SX_LOG_NTC("Starting CR-Space dump (iteration %d/%d)\n", dump_no, SX_NUM_OF_CR_SPACE_DUMPS);

        __get_timestamp(&tv_from_single);
        st = __dbg_generate_single_crspace_dump(dbg_params_p,
                                                reduced_dump,
                                                chip_type,
                                                dump_no,
                                                &address_count,
                                                &layer1_count);
        if (st != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("CR-Space dump failed (iteration %d/%d, err=%s)\n",
                       dump_no,
                       SX_NUM_OF_CR_SPACE_DUMPS,
                       sx_status_str(st));

            break;
        }

        single_diff = __get_diff_msec(&tv_from_single);
        __log_dump_duration(sum_fp, dump_name, st, NULL, single_diff);
        total_diff += single_diff;

        if ((chip_type == SXD_CHIP_TYPE_SPECTRUM4) || (chip_type == SXD_CHIP_TYPE_SPECTRUM5) ||
            (chip_type == SXD_CHIP_TYPE_QUANTUM2) ||
            (chip_type == SXD_CHIP_TYPE_QUANTUM3) ||
            (chip_type == SXD_CHIP_TYPE_QUANTUM4)) {
            fprintf(sum_fp, "%-40s %d\n", "    Layer 1 timeout count", layer1_count);
        }

        fprintf(sum_fp, "%-40s %d\n",  "    Addresses count", address_count);

        SX_LOG_NTC("Finished CR-Space dump (iteration %d/%d)\n", dump_no, SX_NUM_OF_CR_SPACE_DUMPS);
    }

    __log_dump_duration(sum_fp, "CR-Space (Total)", st, NULL, total_diff);

    if (fw_dump_completion_state == FW_DUMP_COMPLETION_STATE_REQUEST_SENT) {
        fw_dump_completion_state = FW_DUMP_COMPLETION_STATE_DONE;
        SX_LOG_NTC("Notifying FW of dump generation completion.\n");
        rc = sxd_status_to_sx_status(sxd_fw_dbg_dump_completion_state(dbg_params_p->dev_id,
                                                                      FALSE /* write value */,
                                                                      &fw_dump_completion_state));
        if (rc != SX_STATUS_SUCCESS) {
            if (st == SX_STATUS_SUCCESS) {
                st = rc;
            }

            SX_LOG_ERR("dbg_generate_dump_ext failed notifying dump execution completed for device id:[%u]\n",
                       dbg_params_p->dev_id);
            goto out;
        }
    }

out:
    return st;
}

static sx_status_t __dbg_generate_all(sx_dbg_extra_info_t      *dbg_params,
                                      const struct ku_dev_info *dev_info_p,
                                      boolean_t                 bootstrap_dump)
{
    const char      *fw_branch_tag = "N/A";
    sx_status_t      rc = SX_STATUS_SUCCESS, st = SX_STATUS_SUCCESS;
    const char      *ignore_crdump_in_irdump_val = NULL;
    sxd_chip_types_t chip_type = SXD_CHIP_TYPE_UNKNOWN;
    struct timeval   tv_from, tv_total;
    uint32_t         amber_fw_time_msec = 0;
    FILE            *sum_fp = NULL;

    __get_timestamp(&tv_total);

    if (bootstrap_dump) {
        chip_type = dev_info_p->dev_info.dev_info_ro.chip_type;
    } else {
        /* actually, 'dev_info_p->dev_info.dev_info_ro.chip_type' will hold the chip type
         * for every chip type that is using PCI. However, we still have the OOB chassis
         * and the chip type cannot be retrieved from it.
         */
        sxd_dpt_get_device_type(dbg_params->dev_id, &chip_type);
    }

    rc = generate_dump_file(dbg_params->path, dbg_params->dev_id, "summary", "txt", &sum_fp);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to generate dump-summary file (err=%s)\n", sx_status_str(rc));
        /* dump-summary is not mandatory so we continue the dump process */
    } else {
        fprintf(sum_fp, "Dump Summary\n");
        fprintf(sum_fp, "============\n\n");
        fprintf(sum_fp, "Device ID ............ %u\n", dbg_params->dev_id);
        fprintf(sum_fp, "Chip type ............ %s\n", sx_chip_type_str((sx_chip_types_t)chip_type));
        fprintf(sum_fp, "SDK version .......... %s\n", PACKAGE_VERSION);

        if (((char)dev_info_p->dev_info.dev_info_ro.mgir.dev_info.dev_branch_tag[0]) != '\0') {
            fw_branch_tag = (const char*)dev_info_p->dev_info.dev_info_ro.mgir.dev_info.dev_branch_tag;
        }

        fprintf(sum_fp, "FW version ........... %d.%d.%04d [dev_branch_tag: %s]\n",
                (int)(dev_info_p->dev_info.dev_info_ro.mgir.fw_info.extended_major),
                (int)(dev_info_p->dev_info.dev_info_ro.mgir.fw_info.extended_minor),
                (int)(dev_info_p->dev_info.dev_info_ro.mgir.fw_info.extended_sub_minor),
                fw_branch_tag);
        fprintf(sum_fp, "FW boot status ....... %d\n", dev_info_p->dev_info.dev_info_ro.fw_boot_status);
        fprintf(sum_fp, "PSID ................. %s\n", dev_info_p->dev_info.dev_info_ro.mgir.fw_info.psid);
        fprintf(sum_fp, "Bootstrap dump ....... %s\n", ((bootstrap_dump) ? "Yes" : "No"));
        fprintf(sum_fp, "Async dump ........... %s\n", ((dbg_params->is_async) ? "Yes" : "No"));
        fprintf(sum_fp, "\n");
    }

    if (!g_crdump_env_checked) {
        ignore_crdump_in_irdump_val = getenv(IGNORE_CRDUMP_DURING_IRDUMP_ENV);
        if (ignore_crdump_in_irdump_val) {
            g_ignore_crdump_during_irdump = !!atoi(ignore_crdump_in_irdump_val);
            if (g_ignore_crdump_during_irdump) {
                SX_LOG_NTC("ENV '%s' = '%s', crs-dump will be ignored during ir-dump\n",
                           IGNORE_CRDUMP_DURING_IRDUMP_ENV,
                           ignore_crdump_in_irdump_val);
            }
        }
        g_crdump_env_checked = TRUE;
    }

    if (!g_ignore_crdump_during_irdump || !(dbg_params->ir_dump_enable)) {
        st = __generate_crspace_dumps(dbg_params, sum_fp, dev_info_p, chip_type);
        if ((st != SX_STATUS_SUCCESS) && (rc == SX_STATUS_SUCCESS)) {
            rc = st;
        }
        /* Even if CR-Space dump fails, we continue the debug-dump-extra flow */

        if ((SXD_CHIP_TYPE_QUANTUM2 == chip_type) || (SXD_CHIP_TYPE_QUANTUM3 == chip_type)) {
            SX_LOG_NTC("Generating FW GW dump\n");

            __get_timestamp(&tv_from);
            st = __dbg_generate_gw_dump(dbg_params, chip_type);
            if (st != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("GW dump generation failed, err=%s\n",
                           sx_status_str(st));
                if (rc == SX_STATUS_SUCCESS) {
                    rc = st;
                    /* Even if FW GW dump fails, we continue the debug-dump-extra flow */
                }
            }
            __log_dump_duration(sum_fp, "GW", st, &tv_from, 0);
        }
    }

    if (bootstrap_dump) {
        /* we are done here, we will not take any other dumps in this case! bye! */
        goto out;
    }

    __get_timestamp(&tv_from);
    st = __dbg_generate_driver_dump(dbg_params->path, dbg_params->dev_id);
    if (st != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Driver dump failed (err=%s)\n", sx_status_str(st));
        if (rc == SX_STATUS_SUCCESS) {
            rc = st;
            /* Even if driver dump fails, we continue the debug-dump-extra flow */
        }
    }
    __log_dump_duration(sum_fp, "Driver", st, &tv_from, 0);

    __get_timestamp(&tv_from);
    st = __dbg_generate_dpt_dump(dbg_params->path, dbg_params->dev_id);
    if (st != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("DPT dump failed (err=%s)\n", sx_status_str(st));
        if (rc == SX_STATUS_SUCCESS) {
            rc = st;
            /* Even if DPT dump fails, we continue the debug-dump-extra flow */
        }
    }
    __log_dump_duration(sum_fp, "DPT", st, &tv_from, 0);

    if (dbg_params->amber_dump_enable) {
        __get_timestamp(&tv_from);
        st = dbg_generate_amber_dump(dbg_params->path, dbg_params->dev_id, dev_info_p, &amber_fw_time_msec);
        if (st != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("AMBER dump failed (err=%s)\n", sx_status_str(st));
            if (rc == SX_STATUS_SUCCESS) {
                rc = st;
            }

            /* Even if AMBER dump fails, we continue the debug-dump-extra flow */
        }
        __log_dump_duration(sum_fp, "AMBER (FW time)", st, NULL, amber_fw_time_msec);
        __log_dump_duration(sum_fp, "AMBER (Total)", st, &tv_from, 0);
    }

    if (dbg_params->ir_dump_enable) {
        __get_timestamp(&tv_from);
        st = __dbg_generate_ir_core_dump(dbg_params->path, dbg_params->dev_id, dev_info_p, chip_type);
        if ((st != SX_STATUS_SUCCESS) && (st != SX_STATUS_UNSUPPORTED)) {
            SX_LOG_ERR("IR-Core dump failed (err=%s)\n", sx_status_str(st));

            if (rc == SX_STATUS_SUCCESS) {
                rc = st;
            }

            /* Even if IR-Core dump fails, we continue the debug-dump-extra flow */
        }
        __log_dump_duration(sum_fp, "IR-Core", st, &tv_from, 0);
    }

    if (dbg_params->fw_trace_dump_enable) {
        __get_timestamp(&tv_from);
        st = __dbg_generate_fw_trace_dump(dbg_params->path, dbg_params->dev_id, chip_type);
        if (st != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("fw trace dump failed (err=%s)\n", sx_status_str(st));
            if (rc == SX_STATUS_SUCCESS) {
                rc = st;
            }
        }
        __log_dump_duration(sum_fp, "FW-Trace", st, &tv_from, 0);
    }

    if (dbg_params->sdk_threads_backtrace_enable) {
        __get_timestamp(&tv_from);
        st = __dbg_generate_thread_bt_dump(dbg_params->path, dbg_params->dev_id);
        if (st != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Threads BT Dump failed (err=%s)\n", sx_status_str(st));

            if (rc == SX_STATUS_SUCCESS) {
                rc = st;
            }

            /* Even if SDK thread stack dump fails, we continue the debug-dump-extra flow */
        }
        __log_dump_duration(sum_fp, "SDK-Threads-Backtrace", st, &tv_from, 0);
    }

out:
    if (sum_fp) {
        fprintf(sum_fp, "---------------------------------------------------------\n");
        __log_dump_duration(sum_fp, "Total", rc, &tv_total, 0);
        fclose(sum_fp);
    }

    return rc;
}

static void __dbg_background_call(sx_dbg_extra_info_t      *dbg_params,
                                  const struct ku_dev_info *dev_info,
                                  sxd_handle                dev_handle,
                                  boolean_t                 fw_dump_in_progress_set,
                                  boolean_t                 bootstrap_dump)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   dump_success = TRUE;
    boolean_t   fw_dump_in_progress_already_set = FALSE;
    int         err = 0;

    rc = __dbg_generate_all(dbg_params, dev_info, bootstrap_dump);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("dump generation failed\n");
        dump_success = FALSE;
    }

    if (fw_dump_in_progress_set) {
        err = sxd_dpt_fw_dump_in_progress_set(FALSE, &fw_dump_in_progress_already_set);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set FW dump in-progress flag to TRUE in DPT\n");
        }
    }

    __notify_dump_completion(dbg_params->dev_id, dump_success, dev_handle);
    exit(0);
}

static sx_status_t __set_dump_path(sx_dbg_extra_info_t *dbg_params, const struct ku_dev_info *dev_info_p)
{
    struct stat st;

    if (dbg_params->path[0]) { /* path parameter is set explicitly by the user, no need to do anything */
        return SX_STATUS_SUCCESS;
    }

    /* if we get here, user did not set an explicit path, let's try to get the SDK folder path */
    if (dev_info_p->dev_info.dev_info_set.sdk_folder_path[0]) {
        SX_LOG_NTC("No explicit path parameter, using SDK path setting\n");
        strncpy(dbg_params->path,
                (char*)dev_info_p->dev_info.dev_info_set.sdk_folder_path,
                sizeof(dbg_params->path) - 1);

        return SX_STATUS_SUCCESS;
    }

    /* if we get here, neither having an explicit path nor SDK folder path. need to use the default path */
    SX_LOG_NTC("No explicit path parameter and SDK path setting is empty, using default path\n");
    strncpy(dbg_params->path, SDK_SYS_INFO_PATH_DEFAULT, sizeof(dbg_params->path) - 1);

    /* coverity[fs_check_call]*/
    if (stat(SDK_SYS_INFO_PATH_DEFAULT, &st) != 0) {
        SX_LOG_NTC("Path [%s] does not exist, creating it\n", SDK_SYS_INFO_PATH_DEFAULT);
        if (errno == ENOENT) {
            if (mkdir(SDK_SYS_INFO_PATH_DEFAULT, 0644)) {
                SX_LOG_ERR("Failed to create path [%s] (errno=%d)\n", SDK_SYS_INFO_PATH_DEFAULT, errno);
                return SX_STATUS_ERROR;
            }
        } else {
            SX_LOG_ERR("Cannot use path [%s] (errno=%d)\n", SDK_SYS_INFO_PATH_DEFAULT, errno);
            return SX_STATUS_ERROR;
        }
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t dbg_generate_dump_ext(sx_dbg_extra_info_t *dbg_params)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    char               dev_name[MAX_NAME_LEN];
    char              *dev_name_p = dev_name;
    uint32_t           dev_num = 1;
    sxd_handle         dev_handle = -1;
    int                err = 0;
    pid_t              child_pid = -1;
    sxd_status_t       sxd_rc = SXD_STATUS_SUCCESS;
    boolean_t          fw_dump_in_progress_already_set = FALSE;
    boolean_t          fw_dump_in_progress_set = FALSE;
    boolean_t          clear_fw_dump_in_progress = TRUE;
    boolean_t          issu_in_progress = FALSE;
    boolean_t          need_access_reg_deinit = FALSE;
    boolean_t          bootstrap_dump = FALSE;
    struct ku_dev_info dev_info;
    sxd_chip_types_t   chip_type = SXD_CHIP_TYPE_UNKNOWN;

    /*check that params are not empty.Must have dev_id*/
    if (NULL == dbg_params) {
        SX_LOG_ERR("parameters not initialized\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* we don't know if sxd_access_reg_init() was already called by the current process.
     * so we call it on our own. if it was already called, we will get the ALREADY_INITIALIZED error.
     * The call may also fail because this function was called before the SDK had the opportunity to
     * create the DPT shared memory. this is why relying on shared memory is best-effort here (e.g.
     * checking if in ISSU mode or if there is already other dump in progress).
     */
    sxd_rc = sxd_access_reg_init_strict(getpid(), __default_log_cb, SX_VERBOSITY_LEVEL_INFO);
    if (sxd_rc == SXD_STATUS_SUCCESS) {
        need_access_reg_deinit = TRUE;
    }

    err = sxd_get_dev_list(&dev_name_p, &dev_num);
    if (err != 0) {
        SX_LOG_ERR("Could not get device list: %s\n", strerror(errno));
        rc = sxd_status_to_sx_status(SXD_STATUS_DEVICE_GET_ERROR);
        goto out;
    }

    err = sxd_open_device(dev_name, &dev_handle);
    if ((err != 0) || (dev_handle < 0)) {
        SX_LOG_ERR("Could not open device: %s\n", strerror(errno));
        rc = sxd_status_to_sx_status(SXD_STATUS_DEVICE_OPEN_ERROR);
        goto out;
    }

    memset(&dev_info, 0, sizeof(dev_info));
    dev_info.dev_id = dbg_params->dev_id;
    sxd_rc = sxd_get_device_info_with_handle(dev_handle, &dev_info);
    if (SXD_CHECK_FAIL(sxd_rc)) {
        rc = sxd_status_to_sx_status(sxd_rc);
        SX_LOG_ERR("Failed to get device information\n");
        goto out;
    }

    rc = __set_dump_path(dbg_params, &dev_info);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Cannot use dump folder\n");
        goto out;
    }

    SX_LOG_NTC("Path used for dumps: %s\n", dbg_params->path);

    /* bootstrap dump is TRUE when the device is in FATAL state during the very early boot process.
     * in this phase, DPT shared memory may be uninitialized so relying on it is nice-to-have.
     * in this mode we need to do the minimum steps required: CR-Space dump. All other dumps, even if
     * requested in dbg_params, will not be processed.
     */
    bootstrap_dump = (dev_info.dev_info.dev_info_ro.flags & SX_DEV_INFO_F_PCI_PROBE_FAILURE) ? TRUE : FALSE;
    if (bootstrap_dump) {
        SX_LOG_NTC("This is a bootstrap dump, skipping validations\n");
        chip_type = dev_info.dev_info.dev_info_ro.chip_type;
        goto post_validation;
    }
    sxd_dpt_get_device_type(dbg_params->dev_id, &chip_type);

    sxd_rc = sxd_dpt_issu_in_progress_get(&issu_in_progress);
    if (SXD_CHECK_FAIL(sxd_rc)) {
        rc = sxd_status_to_sx_status(sxd_rc);
        SX_LOG_ERR("Failed to get ISSU in-progress flag from DPT\n");
        goto out;
    }

    if (issu_in_progress && !(IS_DUMP_SUPPORTED_WITH_ISSU(chip_type))) {
        SX_LOG_ERR("FW dump is not permitted since ISSU is now in progress\n");
        rc = SX_STATUS_ISSU_IN_PROGRESS;
        goto out;
    }

    sxd_rc = sxd_dpt_fw_dump_in_progress_set(TRUE, &fw_dump_in_progress_already_set);
    if (SXD_CHECK_FAIL(sxd_rc)) {
        rc = sxd_status_to_sx_status(sxd_rc);
        SX_LOG_ERR("Failed to set FW dump in-progress flag to TRUE in DPT\n");
        goto out;
    }

    if (fw_dump_in_progress_already_set) {
        SX_LOG_NTC("FW dump in progress, cannot start a new dump\n");
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }
    fw_dump_in_progress_set = TRUE;

post_validation:

    if (dbg_params->is_async) {
        child_pid = fork();
        if (child_pid == -1) {
            SX_LOG_ERR("Failed to fork child process, err: %s\n", strerror(errno));
            rc = SX_STATUS_NO_RESOURCES;
            goto out;
        } else if (child_pid == 0) {
            err = daemon(0, 0);
            if (err == -1) {
                SX_LOG_ERR("Failed to run the child process in background, err: %s\n", strerror(errno));

                if (fw_dump_in_progress_set) {
                    sxd_rc = sxd_dpt_fw_dump_in_progress_set(FALSE, &fw_dump_in_progress_already_set);
                    if (SXD_CHECK_FAIL(sxd_rc)) {
                        SX_LOG_ERR("Failed to set FW dump in-progress flag to TRUE in DPT\n");
                    }
                }

                __notify_dump_completion(dbg_params->dev_id, FALSE, dev_handle);
                exit(0);
            }

            sxd_access_reg_init_after_fork(getpid(), NULL, SX_VERBOSITY_LEVEL_INFO);
            __dbg_background_call(dbg_params, &dev_info, dev_handle, fw_dump_in_progress_set, bootstrap_dump);
        } else {
            /* In the above call to daemon, the child process will do fork again and then exit, the real work will be done in the grandchild in background.
             * Here it just waits for the child process, otherwise it will become zombie process.
             */
            waitpid(child_pid, NULL, 0);
            clear_fw_dump_in_progress = FALSE;
        }
    } else {
        /* this call is to make sure the current process has initialized sxd_libs properly.
         * if the process has already called sxd_access_reg_init() before, the call here will be a NOP
         */
        sxd_rc = sxd_access_reg_init_strict(getpid(), __default_log_cb, SX_VERBOSITY_LEVEL_INFO);
        if ((SXD_STATUS_SUCCESS != sxd_rc) && (SXD_STATUS_ALREADY_INITIALIZED != sxd_rc)) {
            printf("ERROR: SXD API sxd_access_reg_init failed: [%s]\n", SXD_STATUS_MSG(sxd_rc));
            rc = sxd_status_to_sx_status(sxd_rc);
            goto out;
        }

        rc = __dbg_generate_all(dbg_params, &dev_info, bootstrap_dump);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("FW dump failed, err: %s\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    if (dev_handle != -1) {
        err = sxd_close_device(dev_handle);
        if (err != 0) {
            SX_LOG_ERR("Failed to close the SXD device handle, err: %s\n", strerror(errno));
        }
    }

    if (fw_dump_in_progress_set && clear_fw_dump_in_progress) {
        sxd_rc = sxd_dpt_fw_dump_in_progress_set(FALSE, &fw_dump_in_progress_already_set);
        if (SXD_CHECK_FAIL(sxd_rc)) {
            SX_LOG_ERR("Failed to set FW dump in-progress flag to FALSE in DPT\n");
        }
    }

    if (need_access_reg_deinit) {
        sxd_access_reg_deinit();
    }

    return rc;
}

sx_status_t sx_api_dbg_generate_dump_extra(const sx_api_handle_t handle, const sx_dbg_extra_info_t *dbg_params_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sx_dbg_extra_info_t cmd_body;

    UNUSED_PARAM(handle);

    SX_API_LOG_ENTER();

    if (!dbg_params_p) {
        SX_LOG_ERR("NULL params\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (strlen(dbg_params_p->path) >= SX_API_DUMP_EXT_PATH_LEN_LIMIT) {
        SX_LOG_ERR("extended dump file path length exceeds range - max string length is %u .\n",
                   SX_API_DUMP_EXT_PATH_LEN_LIMIT - 1);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    memcpy(&cmd_body, dbg_params_p, sizeof(cmd_body));
    err = dbg_generate_dump_ext(&cmd_body);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_dbg_dump(const sx_api_handle_t handle, const sx_dbg_dump_info_t *dump_info_p)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    sx_dbg_dump_info_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (!dump_info_p) {
        SX_LOG_ERR("dump_info_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!SX_DBG_DUMP_DEST_CHECK_RANGE(dump_info_p->dump_dest)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Dump destination (%u) is out of range\n", dump_info_p->dump_dest);
        goto out;
    }

    /* Only dump to SDK file system is supported for now */
    if (dump_info_p->dump_dest != SX_DBG_DUMP_DEST_SDK_FILE_SYS_E) {
        err = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Only dump destination (%u) is supported for now\n", SX_DBG_DUMP_DEST_SDK_FILE_SYS_E);
        goto out;
    }

    if (!SX_DBG_DUMP_FORMAT_CHECK_RANGE(dump_info_p->dump_format)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Dump format (%u) is out of range\n", dump_info_p->dump_format);
        goto out;
    }

    if (!SX_DBG_HW_DUMP_METHOD_CHECK_RANGE(dump_info_p->hw_dump_method)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("HW dump method (%u) is out of range\n", dump_info_p->hw_dump_method);
        goto out;
    }

    cmd_body = *dump_info_p;
    /* Make sure the path arrays are NULL-terminated */
    cmd_body.text_info.path[sizeof(cmd_body.text_info.path) - 1] = 0;
    cmd_body.json_info.path[sizeof(cmd_body.json_info.path) - 1] = 0;
    err =
        sx_api_send_command_wrapper(handle, SX_API_INT_CMD_DBG_DUMP_E, (uint8_t*)&cmd_body,
                                    sizeof(cmd_body));
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fw_dbg_test(const sx_api_handle_t handle, const sx_dbg_test_params_t *params)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_dbg_test_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (!params) {
        SX_LOG_ERR("NULL params\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    if ((params->test_type < SX_DBG_TEST_FW_MIN_E) || (params->test_type > SX_DBG_TEST_FW_MAX_E)) {
        SX_LOG_ERR("test type parameter is out of range \n");
        return SX_STATUS_PARAM_ERROR;
    }

    cmd_body.dev_id = params->dev_id;
    cmd_body.test_type = params->test_type;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_DBG_CONTROL_TEST_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_api_fw_dbg_control_set(const sx_api_handle_t          handle,
                                      const sx_access_cmd_t          cmd,
                                      const sx_dbg_control_params_t *params)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_dbg_control_params_t cmd_body;

    SX_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (!params) {
        SX_LOG_ERR("NULL params\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_SET) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Illegal command\n");
        goto out;
    }

    if (params->fw_fatal_event_config.auto_extraction_policy > SX_DBG_POLICY_MAX_E) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Debug control policy parameter value is out of range \n");
        goto out;
    }

    cmd_body.dev_id = params->dev_id;
    cmd_body.fw_fatal_event_config.auto_extraction_policy = params->fw_fatal_event_config.auto_extraction_policy;
    cmd_body.fw_fatal_event_config.fw_fatal_event_enable = params->fw_fatal_event_config.fw_fatal_event_enable;
    cmd_body.fw_fatal_event_config.ir_dump_enable = params->fw_fatal_event_config.ir_dump_enable;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_DBG_CONTROL_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));


out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sx_api_fw_dbg_control_get(const sx_api_handle_t handle, sx_dbg_control_params_t *params)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_dbg_control_params_t cmd_body;

    SX_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (!params) {
        SX_LOG_ERR("NULL params\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.dev_id = params->dev_id;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_DBG_CONTROL_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("sx_api_send_command_wrapper failed \n");
        goto out;
    }

    params->fw_fatal_event_config.auto_extraction_policy = cmd_body.fw_fatal_event_config.auto_extraction_policy;
    params->fw_fatal_event_config.fw_fatal_event_enable = cmd_body.fw_fatal_event_config.fw_fatal_event_enable;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_api_dbg_fatal_failure_detection_get(const sx_api_handle_t          handle,
                                                   boolean_t                     *is_enable_p,
                                                   sx_dbg_health_sample_params_t *health_sample_params_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sx_api_dbg_health_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);


    if (NULL == health_sample_params_p) {
        SX_LOG_ERR("health_sample_params_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == is_enable_p) {
        SX_LOG_ERR("is_enable_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FATAL_FAILURE_DETECTION_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    if (err == SX_STATUS_SUCCESS) {
        if (SX_ACCESS_CMD_ENABLE == cmd_body.cmd) {
            *is_enable_p = TRUE;
            health_sample_params_p->failures_num = cmd_body.params.failures_num;
            health_sample_params_p->periodic_time = cmd_body.params.periodic_time;
            health_sample_params_p->min_severity = cmd_body.params.min_severity;
        } else {
            *is_enable_p = FALSE;
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_dbg_fatal_failure_detection_set(const sx_api_handle_t                handle,
                                                   const sx_access_cmd_t                cmd,
                                                   const sx_dbg_health_sample_params_t *health_sample_params_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sx_api_dbg_health_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_ENABLE) && (cmd != SX_ACCESS_CMD_DISABLE)) {
        SX_LOG_ERR("Unsupported command - %s \n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (health_sample_params_p == NULL) { /*Default values*/
        cmd_body.params.failures_num = SX_DBG_HEALTH_NUM_OF_FAILURES_DEFAULT;
        cmd_body.params.periodic_time = SX_DBG_HEALTH_PERIODIC_TIME_DEFAULT;
        cmd_body.params.min_severity = SX_HEALTH_SEVERITY_NOTICE_E;
    } else {
        if (!SX_DBG_HEALTH_FAILURES_NUM_CHECK_RANGE(health_sample_params_p->failures_num)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Failures number (%u) is out of range\n", health_sample_params_p->failures_num);
            goto out;
        }
        if (!SX_DBG_HEALTH_PERIODIC_TIME_CHECK_RANGE(health_sample_params_p->periodic_time)) {
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Period in millisecond (%u) is out of range\n", health_sample_params_p->periodic_time);
            goto out;
        }
        if ((health_sample_params_p->issu_off) || (health_sample_params_p->issu_on)) {
            /* issu_on, issu_off are true only by SDK internal command*/
            SX_LOG_ERR("issu_on and issu_off flags are for SDK internal use only\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_body.params.failures_num = health_sample_params_p->failures_num;
        cmd_body.params.periodic_time = health_sample_params_p->periodic_time;

        if (health_sample_params_p->min_severity == 0) { /* legacy */
            cmd_body.params.min_severity = SX_HEALTH_SEVERITY_NOTICE_E; /* default value */
        } else {
            if ((health_sample_params_p->min_severity != SX_HEALTH_SEVERITY_FATAL_E) &&
                (health_sample_params_p->min_severity != SX_HEALTH_SEVERITY_WARN_E) &&
                (health_sample_params_p->min_severity != SX_HEALTH_SEVERITY_NOTICE_E)) {
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            cmd_body.params.min_severity = health_sample_params_p->min_severity;
        }
    }

    cmd_body.cmd = cmd;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_FATAL_FAILURE_DETECTION_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_dbg_api_logger_set(const sx_api_handle_t             handle,
                                      const sx_access_cmd_t             cmd,
                                      const sx_dbg_api_logger_params_t *params_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_api_dbg_api_logger_set_params_t cmd_body;

    SX_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (params_p == NULL) {
        SX_LOG_ERR("params_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_ENABLE) {
        if (memchr(params_p->log_file_path, '\0', sizeof(params_p->log_file_path)) == NULL) {
            SX_LOG_ERR("log_file_path is not NULL terminated\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    if (params_p->filter_mode != SX_DBG_API_LOGGER_FILTER_NONE_MODE) {
        if (memchr(params_p->filter_file_path, '\0', sizeof(params_p->filter_file_path)) == NULL) {
            SX_LOG_ERR("filter_file_path is not NULL terminated\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }


    if ((cmd != SX_ACCESS_CMD_ENABLE) && (cmd != SX_ACCESS_CMD_DISABLE)) {
        SX_LOG_ERR("Unsupported command - %s \n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.params, *params_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_DBG_API_LOGGER_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_api_dbg_api_logger_get(const sx_api_handle_t handle, sx_dbg_api_logger_params_t *params_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_api_dbg_api_logger_get_params_t cmd_body;

    SX_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (params_p == NULL) {
        SX_LOG_ERR("params_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_DBG_API_LOGGER_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_MEM_CPY(*params_p, cmd_body.params);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_dbg_log_verbosity_level_set(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               const sx_verbosity_level_t      module_verbosity_level,
                                               const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_DBG_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_dbg_log_verbosity_level_get(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               sx_verbosity_level_t           *module_verbosity_level_p,
                                               sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_DBG_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t dbg_api_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return status;
}

sx_status_t dbg_api_log_verbosity_level_get(sx_verbosity_level_t * verbosity_level_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    if (utils_check_pointer(verbosity_level_p, "verbosity_level_p")) {
        status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);
out:
    return status;
}
