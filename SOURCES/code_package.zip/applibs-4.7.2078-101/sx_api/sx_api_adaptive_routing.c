/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <sx/sdk/sx_api_adaptive_routing.h>
#include <include/resource_manager/resource_manager.h>
#include "utils/sx_router_utils_validate.h"
#include "sx_api_internal.h"
#include "utils/sx_ip_utils.h"

#undef __MODULE__
#define __MODULE__ SX_API_ROUTER

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

#ifndef MIN
#define MIN(x, y) ((x) < (y) ? (x) : (y))
#endif

sx_status_t sx_api_ar_log_verbosity_level_set(const sx_api_handle_t           handle,
                                              const sx_log_verbosity_target_t verbosity_target,
                                              const sx_verbosity_level_t      module_verbosity_level,
                                              const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_AR_VERBOSITY_SET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head,
                                            (uint8_t*)&cmd_body, &reply_head,
                                            NULL, 0);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_ar_log_verbosity_level_get(const sx_api_handle_t           handle,
                                              const sx_log_verbosity_target_t verbosity_target,
                                              sx_verbosity_level_t           *module_verbosity_level_p,
                                              sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p,
                                  "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_AR_VERBOSITY_GET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(
            handle, cmd_head.opcode, (uint8_t*)&cmd_body,
            sizeof(sx_api_command_log_verbosity_t));

        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            goto out;
        }

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_ar_init_set(const sx_api_handle_t handle, const sx_ar_init_params_t   *init_params_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_api_command_head_t cmd_head;
    sx_ar_init_params_t   cmd_body;
    uint32_t              cmd_body_size = 0;
    sx_api_reply_head_t   reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (init_params_p == NULL) {
        SX_LOG_ERR("init_params_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_ar_init_params_t);

    SX_MEM_CPY(cmd_body, *init_params_p);

    cmd_head.opcode = SX_API_INT_CMD_AR_INIT_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_deinit_set(const sx_api_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_AR_DEINIT_SET_E,
                                      NULL,
                                      0);

    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_ar_profile_get(const sx_api_handle_t      handle,
                                  const sx_ar_profile_key_t *profile_key_p,
                                  sx_ar_profile_attr_t      *profile_attr_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_api_command_head_t      cmd_head;
    sx_api_ar_profile_params_t cmd_body;
    uint32_t                   cmd_body_size = 0;
    sx_api_ar_profile_params_t reply_body;
    uint32_t                   reply_body_size = sizeof(sx_api_ar_profile_params_t);
    sx_api_reply_head_t        reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (profile_key_p == NULL) {
        SX_LOG_ERR("profile_key_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (profile_attr_p == NULL) {
        SX_LOG_ERR("profile_attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_ar_profile_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_PROFILE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    SX_MEM_CPY(cmd_body.profile_key_p, *profile_key_p);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body, reply_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*profile_attr_p, reply_body.profile_attr_p);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_profile_set(const sx_api_handle_t       handle,
                                  const sx_access_cmd_t       cmd,
                                  const sx_ar_profile_key_t  *profile_key_p,
                                  const sx_ar_profile_attr_t *profile_attr_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_api_command_head_t      cmd_head;
    sx_api_ar_profile_params_t cmd_body;
    uint32_t                   cmd_body_size = 0;
    sx_api_reply_head_t        reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (profile_key_p == NULL) {
        SX_LOG_ERR("profile_key_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (profile_attr_p == NULL) {
        SX_LOG_ERR("profile_attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_ar_profile_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_PROFILE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.profile_key_p, *profile_key_p);
    SX_MEM_CPY(cmd_body.profile_attr_p, *profile_attr_p);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_default_classification_get(const sx_api_handle_t handle, sx_ar_classifier_action_t   *action_p)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                     cmd_head;
    sx_api_ar_default_classification_params_t cmd_body;
    uint32_t                                  cmd_body_size = 0;
    sx_api_ar_default_classification_params_t reply_body;
    sx_api_reply_head_t                       reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (action_p == NULL) {
        SX_LOG_ERR("action_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_ar_default_classification_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_DEFAULT_CLASSIFICATION_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = SX_ACCESS_CMD_GET;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body,
                                        cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*action_p, reply_body.classifier_action);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_ar_default_classification_set(const sx_api_handle_t            handle,
                                                 const sx_access_cmd_t            cmd,
                                                 const sx_ar_classifier_action_t *action_p)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                     cmd_head;
    sx_api_ar_default_classification_params_t cmd_body;
    uint32_t                                  cmd_body_size = 0;
    sx_api_reply_head_t                       reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (action_p == NULL) {
        SX_LOG_ERR("action_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body_size = sizeof(sx_api_ar_default_classification_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_DEFAULT_CLASSIFICATION_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    SX_MEM_CPY(cmd_body.classifier_action, *action_p);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_classifier_set(const sx_api_handle_t            handle,
                                     const sx_access_cmd_t            cmd,
                                     const sx_ar_classifier_id_e      classifier_id,
                                     const sx_ar_classifier_attr_t   *attr_p,
                                     const sx_ar_classifier_action_t *action_p)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sx_api_command_head_t             cmd_head;
    sx_api_ar_classification_params_t cmd_body;
    uint32_t                          cmd_body_size = 0;
    sx_api_reply_head_t               reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (action_p == NULL) {
        SX_LOG_ERR("action_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.classifier_id = classifier_id;
    cmd_body_size = sizeof(sx_api_ar_classification_params_t);
    SX_MEM_CPY(cmd_body.action_p, *action_p);
    SX_MEM_CPY(cmd_body.attr_p, *attr_p);

    cmd_head.opcode = SX_API_INT_CMD_AR_CLASSIFIER_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_classifier_get(const sx_api_handle_t       handle,
                                     const sx_ar_classifier_id_e classifier_id,
                                     sx_ar_classifier_attr_t    *attr_p,
                                     sx_ar_classifier_action_t  *action_p)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sx_api_command_head_t             cmd_head;
    sx_api_ar_classification_params_t cmd_body;
    sx_api_ar_classification_params_t reply_body;
    uint32_t                          cmd_body_size = 0;
    sx_api_reply_head_t               reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (action_p == NULL) {
        SX_LOG_ERR("action_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_ar_classification_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_CLASSIFIER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.classifier_id = classifier_id;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body,
                                        cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*action_p, reply_body.action_p);
        SX_MEM_CPY(*attr_p, reply_body.attr_p);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_congestion_threshold_set(const sx_api_handle_t                    handle,
                                               const sx_access_cmd_t                    cmd,
                                               const sx_ar_congestion_threshold_attr_t *threshold_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                   cmd_head;
    sx_api_ar_congestion_threshold_params_t cmd_body;
    uint32_t                                cmd_body_size = 0;
    sx_api_reply_head_t                     reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (threshold_p == NULL) {
        SX_LOG_ERR("threshold_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_ar_congestion_threshold_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_CONGESTION_THRESHOLD_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = cmd;
    SX_MEM_CPY(cmd_body.congestion_thresh, *threshold_p);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_congestion_threshold_get(const sx_api_handle_t              handle,
                                               sx_ar_congestion_threshold_attr_t *threshold_p)
{
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                   cmd_head;
    sx_api_ar_congestion_threshold_params_t cmd_body;
    uint32_t                                cmd_body_size = 0;
    sx_api_reply_head_t                     reply_head;
    sx_api_ar_congestion_threshold_params_t reply_body;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    SX_API_LOG_ENTER();

    if (threshold_p == NULL) {
        SX_LOG_ERR("threshold_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_ar_congestion_threshold_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_CONGESTION_THRESHOLD_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    SX_MEM_CPY(cmd_body.congestion_thresh, *threshold_p);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*threshold_p, reply_body.congestion_thresh);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_link_utilization_threshold_set(const sx_api_handle_t                handle,
                                                     const sx_access_cmd_t                cmd,
                                                     const sx_port_log_id_t               log_port,
                                                     const sx_ar_link_utilization_attr_t *link_util_attr_p)
{
    sx_status_t                                   err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                         cmd_head;
    sx_api_ar_link_utilization_threshold_params_t cmd_body;
    uint32_t                                      cmd_body_size = 0;
    sx_api_reply_head_t                           reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (link_util_attr_p == NULL) {
        SX_LOG_ERR("link_util_attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_ar_link_utilization_threshold_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_LINK_UTILIZATION_THRESHOLD_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;
    SX_MEM_CPY(cmd_body.link_util_attr, *link_util_attr_p);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_link_utilization_threshold_get(const sx_api_handle_t          handle,
                                                     const sx_port_log_id_t         log_port,
                                                     sx_ar_link_utilization_attr_t *link_util_attr_p)
{
    sx_status_t                                   err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                         cmd_head;
    sx_api_ar_link_utilization_threshold_params_t cmd_body;
    uint32_t                                      cmd_body_size = 0;
    sx_api_reply_head_t                           reply_head;
    sx_api_ar_link_utilization_threshold_params_t reply_body;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    SX_API_LOG_ENTER();

    if (link_util_attr_p == NULL) {
        SX_LOG_ERR("link_util_attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_ar_link_utilization_threshold_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_LINK_UTILIZATION_THRESHOLD_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.log_port = log_port;
    SX_MEM_CPY(cmd_body.link_util_attr, *link_util_attr_p);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*link_util_attr_p, reply_body.link_util_attr);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_shaper_rate_set(const sx_api_handle_t      handle,
                                      const sx_access_cmd_t      cmd,
                                      const sx_ar_shaper_attr_t *shaper_attr_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_api_command_head_t          cmd_head;
    sx_api_ar_shaper_rate_params_t cmd_body;
    uint32_t                       cmd_body_size = 0;
    sx_api_reply_head_t            reply_head;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (shaper_attr_p == NULL) {
        SX_LOG_ERR("shaper_attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body_size = sizeof(sx_api_ar_shaper_rate_params_t);
    SX_MEM_CPY(cmd_body.shaper_attr_p, *shaper_attr_p);

    cmd_head.opcode = SX_API_INT_CMD_AR_SHAPER_RATE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_shaper_rate_get(const sx_api_handle_t handle, sx_ar_shaper_attr_t      *shaper_attr_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_api_command_head_t          cmd_head;
    sx_api_ar_shaper_rate_params_t cmd_body;
    uint32_t                       cmd_body_size = 0;
    sx_api_reply_head_t            reply_head;
    sx_api_ar_shaper_rate_params_t reply_body;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    SX_API_LOG_ENTER();

    if (shaper_attr_p == NULL) {
        SX_LOG_ERR("shaper_attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_ar_shaper_rate_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_SHAPER_RATE_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = SX_ACCESS_CMD_GET;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*shaper_attr_p, reply_body.shaper_attr_p);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_counters_get(const sx_api_handle_t    handle,
                                   const sx_access_cmd_t    cmd,
                                   sx_ar_global_counters_t *ar_counters_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_api_command_head_t          cmd_head;
    sx_api_ar_counter_get_params_t cmd_body;
    uint32_t                       cmd_body_size = 0;
    sx_api_reply_head_t            reply_head;
    sx_api_ar_counter_get_params_t reply_body;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    SX_API_LOG_ENTER();

    if (ar_counters_p == NULL) {
        SX_LOG_ERR("ar_counters_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_ar_counter_get_params_t);

    cmd_head.opcode = SX_API_INT_CMD_AR_COUNTERS_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = cmd;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*ar_counters_p, reply_body.ar_counters);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_arn_set(const sx_api_handle_t          handle,
                              const sx_access_cmd_t          cmd,
                              const sx_arn_general_params_t *general_params_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_api_arn_set_params_t cmd_body;
    uint32_t                cmd_body_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (general_params_p == NULL) {
        SX_LOG_ERR("general_params_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body_size = sizeof(sx_api_arn_set_params_t);
    SX_MEM_CPY(cmd_body.general_params_p, *general_params_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ARN_SET_E,
                                      (uint8_t*)&cmd_body,
                                      cmd_body_size);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_arn_get(const sx_api_handle_t handle, sx_arn_general_params_t *general_params_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_api_arn_set_params_t cmd_body;
    uint32_t                cmd_body_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (general_params_p == NULL) {
        SX_LOG_ERR("general_params_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body_size = sizeof(sx_api_arn_set_params_t);
    SX_MEM_CPY(cmd_body.general_params_p, *general_params_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ARN_GET_E,
                                      (uint8_t*)&cmd_body,
                                      cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*general_params_p, cmd_body.general_params_p);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_arn_profile_set(const sx_api_handle_t        handle,
                                      const sx_access_cmd_t        cmd,
                                      const sx_ar_profile_key_t   *profile_key_p,
                                      const sx_arn_profile_attr_t *profile_attr_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_api_arn_profile_params_t cmd_body;
    uint32_t                    cmd_body_size = 0;


    SX_MEM_CLR(cmd_body);


    SX_API_LOG_ENTER();

    if (profile_key_p == NULL) {
        SX_LOG_ERR("profile_key_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (profile_attr_p == NULL) {
        SX_LOG_ERR("profile_attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body_size = sizeof(sx_api_arn_profile_params_t);
    SX_MEM_CPY(cmd_body.profile_attr_p, *profile_attr_p);
    SX_MEM_CPY(cmd_body.profile_key_p, *profile_key_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ARN_PROFILE_SET_E,
                                      (uint8_t*)&cmd_body,
                                      cmd_body_size);


out:
    return err;
}

sx_status_t sx_api_ar_arn_profile_get(const sx_api_handle_t      handle,
                                      const sx_ar_profile_key_t *profile_key_p,
                                      sx_arn_profile_attr_t     *profile_attr_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_api_arn_profile_params_t cmd_body;
    uint32_t                    cmd_body_size = 0;

    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if (profile_key_p == NULL) {
        SX_LOG_ERR("profile_key_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (profile_attr_p == NULL) {
        SX_LOG_ERR("profile_attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }


    cmd_body_size = sizeof(sx_api_arn_profile_params_t);
    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.profile_key_p.profile = profile_key_p->profile;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ARN_PROFILE_GET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*profile_attr_p, cmd_body.profile_attr_p);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_arn_defaults_set(const sx_api_handle_t          handle,
                                       const sx_access_cmd_t          cmd,
                                       const sx_arn_default_params_t *default_params_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_arn_defaults_set_params_t cmd_body;
    uint32_t                         cmd_body_size = 0;

    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if (default_params_p == NULL) {
        SX_LOG_ERR("default_params_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body_size = sizeof(sx_api_arn_defaults_set_params_t);
    SX_MEM_CPY(cmd_body.default_params_p, *default_params_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ARN_DEFAULTS_SET_E,
                                      (uint8_t*)&cmd_body,
                                      cmd_body_size);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_arn_defaults_get(const sx_api_handle_t handle, sx_arn_default_params_t *default_params_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_arn_defaults_set_params_t cmd_body;
    uint32_t                         cmd_body_size = 0;

    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if (default_params_p == NULL) {
        SX_LOG_ERR("default_params_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_arn_defaults_set_params_t);
    cmd_body.cmd = SX_ACCESS_CMD_GET;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ARN_DEFAULTS_GET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*default_params_p, cmd_body.default_params_p);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_arn_router_gen_set(const sx_api_handle_t             handle,
                                         const sx_access_cmd_t             cmd,
                                         const sx_arn_router_key_t        *router_key_p,
                                         const sx_arn_router_attributes_t *router_attr_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_api_arn_router_gen_set_params_t cmd_body;
    uint32_t                           cmd_body_size = 0;

    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if (router_key_p == NULL) {
        SX_LOG_ERR("router_key_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_SET) && (router_attr_p == NULL)) {
        SX_LOG_ERR("router_attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body_size = sizeof(sx_api_arn_router_gen_set_params_t);
    SX_MEM_CPY(cmd_body.router_key_p, *router_key_p);
    SX_MEM_CPY(cmd_body.router_attr_p, *router_attr_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ARN_ROUTER_GEN_SET_E,
                                      (uint8_t*)&cmd_body,
                                      cmd_body_size);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_arn_router_gen_get(const sx_api_handle_t       handle,
                                         const sx_arn_router_key_t  *router_key_p,
                                         sx_arn_router_attributes_t *router_attr_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_api_arn_router_gen_set_params_t cmd_body;
    uint32_t                           cmd_body_size = 0;

    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if (router_key_p == NULL) {
        SX_LOG_ERR("router_key_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (router_attr_p == NULL) {
        SX_LOG_ERR("router_attr_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_arn_router_gen_set_params_t);
    cmd_body.cmd = SX_ACCESS_CMD_GET;
    SX_MEM_CPY(cmd_body.router_key_p, *router_key_p);

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ARN_ROUTER_GEN_GET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*router_attr_p, cmd_body.router_attr_p);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_arn_counters_get(const sx_api_handle_t handle,
                                       const sx_access_cmd_t cmd,
                                       sx_arn_counters_t    *arn_counters_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_api_command_head_t        cmd_head;
    sx_api_arn_counters_params_t cmd_body;
    uint32_t                     cmd_body_size = 0;
    sx_api_reply_head_t          reply_head;
    sx_api_arn_counters_params_t reply_body;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    SX_API_LOG_ENTER();

    if (arn_counters_p == NULL) {
        SX_LOG_ERR("arn_counters_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body_size = sizeof(sx_api_arn_counters_params_t);

    cmd_head.opcode = SX_API_INT_CMD_ARN_COUNTERS_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    cmd_body.cmd = cmd;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)&reply_body, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*arn_counters_p, reply_body.arn_counters_p);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_arn_port_counters_get(const sx_api_handle_t   handle,
                                            const sx_access_cmd_t   cmd,
                                            const sx_port_log_id_t  log_port,
                                            sx_arn_port_counters_t *port_counters_p)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sx_api_arn_port_counters_params_t cmd_body;
    uint32_t                          cmd_body_size = 0;

    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if (port_counters_p == NULL) {
        SX_LOG_ERR("port_counters_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }


    cmd_body_size = sizeof(sx_api_arn_port_counters_params_t);
    cmd_body.cmd = cmd;
    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ARN_PORT_COUNTERS_GET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*port_counters_p, cmd_body.port_counters_p);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_ar_arn_flow_status_get(const sx_api_handle_t      handle,
                                          const sx_access_cmd_t      cmd,
                                          sx_arn_flow_status_key_t  *flow_status_key_p,
                                          sx_arn_flow_status_data_t *flow_status_data_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_api_ar_arn_flow_status_params_t cmd_body;
    uint32_t                           cmd_body_size = 0;

    SX_MEM_CLR(cmd_body);

    SX_API_LOG_ENTER();

    if (flow_status_key_p == NULL) {
        SX_LOG_ERR("flow_status_key_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (flow_status_data_p == NULL) {
        SX_LOG_ERR("flow_status_data_p parameter is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }


    cmd_body_size = sizeof(sx_api_ar_arn_flow_status_params_t);
    cmd_body.cmd = cmd;

    SX_MEM_CPY(cmd_body.flow_status_key_p, *flow_status_key_p);
    cmd_body.flow_status_data_p.flow_status_cnt = flow_status_data_p->flow_status_cnt;
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ARN_FLOW_STATUS_GET_E,
                                      (uint8_t*)&cmd_body, cmd_body_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY(*flow_status_data_p, cmd_body.flow_status_data_p);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}
