/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include "sx_api_internal.h"
#include "sx/sdk/auto_headers/sx_truncation_profile_auto.h"

#undef  __MODULE__
#define __MODULE__ SX_API_TRUNCATION_PROFILE


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/


sx_status_t sx_api_truncation_profile_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                              const sx_log_verbosity_target_t verbosity_target,
                                                              const sx_verbosity_level_t      module_verbosity_level,
                                                              const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_TRUNCATION_PROFILE_VERBOSITY_SET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head,
                                            (uint8_t*)&cmd_body, &reply_head,
                                            NULL, 0);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level set - [%s]\n", sx_status_str(err));
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_truncation_profile_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                              const sx_log_verbosity_target_t verbosity_target,
                                                              sx_verbosity_level_t           *module_verbosity_level_p,
                                                              sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p,
                                  "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_TRUNCATION_PROFILE_VERBOSITY_GET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(
            handle, cmd_head.opcode, (uint8_t*)&cmd_body,
            sizeof(sx_api_command_log_verbosity_t));

        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed verbosity level get - [%s]\n", sx_status_str(err));
            goto out;
        }

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_truncation_profile_set(const sx_api_handle_t              handle,
                                          const sx_access_cmd_t              cmd,
                                          const sx_truncation_profile_key_t *trunc_profile_key_p,
                                          sx_truncation_profile_cfg_t       *trunc_profile_cfg_p)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_truncation_profile_set_params_t cmd_body;
    uint32_t                               cmd_size = sizeof(sx_api_truncation_profile_set_params_t);

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (NULL == trunc_profile_key_p) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("The given trunc_profile_key_p is NULL\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        if (NULL == trunc_profile_cfg_p) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("The given trunc_profile_cfg_p is NULL\n");
            goto out;
        }

        SX_MEM_CPY_P(&cmd_body.truncation_profile_cfg, trunc_profile_cfg_p);
        break;

    case SX_ACCESS_CMD_DESTROY:
        break;

    default:
        SX_LOG_ERR("Unsupported command: [%s]\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    SX_MEM_CPY_P(&cmd_body.truncation_profile_key, trunc_profile_key_p);

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TRUNCATION_PROFILE_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_truncation_profile_get(const sx_api_handle_t              handle,
                                          const sx_truncation_profile_key_t *trunc_profile_key_p,
                                          sx_truncation_profile_cfg_t       *trunc_profile_cfg_p)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_truncation_profile_get_params_t cmd_body;
    uint32_t                               cmd_size = sizeof(sx_api_truncation_profile_get_params_t);

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if ((NULL == trunc_profile_key_p) || (NULL == trunc_profile_cfg_p)) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("The given arg is NULL\n");
        goto out;
    }

    SX_MEM_CPY_P(&cmd_body.truncation_profile_key, trunc_profile_key_p);

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_TRUNCATION_PROFILE_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        SX_MEM_CPY_P(trunc_profile_cfg_p, &cmd_body.truncation_profile_cfg);
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}
