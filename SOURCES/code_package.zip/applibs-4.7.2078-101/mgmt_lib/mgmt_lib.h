/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __MGMT_LIB_H__
#define __MGMT_LIB_H__

#include <sx/sxd/sxd_access_register.h>
#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_api.h>
#include "ethl2/topo_db.h"
#include "utils/sx_internal.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/
/*
 * Temperature reading from the sensor. Reading is in 0.125 Celsius degrees units.
 * For negative values 2's complement is used (for example: -3.25
 * Celsius will read as 0xFFE6)
 */
#define MTMP_CONV_TO_CELSIUS(val) \
    ((val & 0x8000) ? ((0xFFFF - val + 1) / 8) : val / 8)

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/
/* Define all necessary local variables */
#define SX_MGMT_LIB_FOR_EACH_LEAF_DEV_VARS          \
    int dev_info_arr_size = SX_DEV_ID_MAX;          \
    topo_device_item_t dev_info_arr[SX_DEV_ID_MAX]; \
    int                dev_idx = 0

/* Get list of LEAF devices */
#define SX_MGMT_LIB_GET_LIST_OF_LEAF_DEV \
    topo_db_device_list_get(             \
        SX_ACCESS_CMD_GET,               \
        &dev_info_arr_size,              \
        dev_info_arr)

/* Start processing of LEAF devices */
#define SX_MGMT_LIB_FOR_EACH_LEAF_DEV_BEGIN                                   \
    for (dev_idx = 0; dev_idx < dev_info_arr_size; dev_idx++) {               \
        if (dev_info_arr[dev_idx].node_type != SX_DEV_NODE_TYPE_LEAF_LOCAL) { \
            continue;                                                         \
        }                                                                     \

/* Stop processing of LEAF devices */
#define SX_MGMT_LIB_FOR_EACH_LEAF_DEV_END }

#define SX_MGMT_LIB_LIST_OF_LEAF_DEV_IS_EMPTY (dev_info_arr_size == 0)

/************************************************
 *  Type definitions
 ***********************************************/
typedef sxd_mgpir_hw_info_t mgmt_lib_hw_info_t;

typedef struct mgmt_lib_system_info {
    boolean_t          is_valid;
    mgmt_lib_hw_info_t hw_info;
} mgmt_lib_system_info_t;

typedef struct mgmt_lib_ctxt {
    mgmt_lib_system_info_t sys_info;
} mgmt_lib_ctxt_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t mgmt_lib_init(void);

sx_status_t mgmt_lib_deinit(void);

sx_status_t mgmt_lib_handle_set(void* lib_handle);

sx_status_t mgmt_lib_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t mgmt_lib_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

sx_status_t mgmt_lib_set_internal_job_func(sx_add_intern_job_cb cb);

sx_status_t mgmt_lib_system_info_get(sx_mgmt_slot_system_info_t *system_info_p);

sx_status_t mgmt_lib_slot_control_set(sx_slot_id_t slot_id, sx_mgmt_slot_control_info_t *slot_control_info_p);

sx_status_t mgmt_lib_slot_info_get(sx_slot_id_t        *slot_id_list_p,
                                   sx_mgmt_slot_info_t *slot_info_list_p,
                                   uint32_t             slot_list_size,
                                   uint32_t            *system_slot_count);

sx_status_t mgmt_lib_ini_data_set(sx_slot_id_t                        slot_id,
                                  sx_mgmt_slot_ini_data_t            *data_p,
                                  sx_mgmt_slot_ini_transfer_result_t *ini_transfer_result_p);

sx_status_t mgmt_lib_ini_operation_set(sx_slot_id_t                         slot_id,
                                       sx_mgmt_slot_ini_operation_e         oper,
                                       sx_mgmt_slot_ini_operation_result_t *ini_operation_result_p);

sx_status_t mgmt_lib_slot_state_info_get(sx_slot_id_t              *slot_id_list_p,
                                         sx_mgmt_slot_state_info_t *slot_state_info_list_p,
                                         uint32_t                   slot_list_size,
                                         uint32_t                  *system_slot_count);

sx_status_t mgmt_lib_phy_module_split_info_get(sx_mgmt_module_id_info_t          *module_id_info_p,
                                               sx_mgmt_phy_module_split_params_t *module_split_params_p,
                                               sx_mgmt_phy_module_split_info_t   *module_split_info_p);

sx_status_t mgmt_lib_phy_module_info_get(const sx_mgmt_module_id_info_t *module_id_info_list_p,
                                         sx_mgmt_phy_module_info_t      *module_info_list_p,
                                         uint32_t                        list_size);

sx_status_t mgmt_lib_log_port_info_get(sx_port_log_id_t    *log_port_list_p,
                                       sx_mgmt_port_info_t *log_port_info_list_p,
                                       uint32_t             list_size);

sx_status_t mgmt_lib_temp_sensor_set(sx_access_cmd_t                  cmd,
                                     sx_slot_id_t                     slot_id,
                                     uint32_t                         list_size,
                                     sx_sensor_id_t                  *sensor_id_list_p,
                                     sx_mgmt_temp_sensor_ctrl_info_t *temp_sensor_ctrl_info_list_p);

sx_status_t mgmt_lib_temp_sensor_get(sx_access_cmd_t             cmd,
                                     sx_slot_id_t                slot_id,
                                     uint32_t                    list_size,
                                     sx_sensor_id_t             *sensor_id_list_p,
                                     sx_mgmt_temp_sensor_info_t *temp_sensor_info_list_p);

/**
 *  Configures the Port's physical media type value.
 *
 * @param[in] slot_id - slot ID
 * @param[in] module_id - module ID
 * @param[in] types_p   - new types enabled
 *
 * @return sx_status_t - SX_STATUS_SUCCESS if function completed OK.
 * O/W, the appropriate error code it returned.
 */
sx_status_t mgmt_lib_phy_module_admin_type_set(const sx_slot_id_t                 slot_id,
                                               const sx_port_mod_id_t             module_id,
                                               sx_port_phy_module_type_bitmask_t *types_p);

/**
 *  Retrieves the Port's operation physical media type value.
 *
 * @param[in] slot_id - slot ID
 * @param[in] module_id - module ID
 * @param[out] types_p  - operational phy module type
 *
 * @return sx_status_t - SX_STATUS_SUCCESS if function completed OK.
 * O/W, the appropriate error code it returned.
 */
sx_status_t mgmt_lib_phy_module_oper_get(const sx_slot_id_t         slot_id,
                                         const sx_port_mod_id_t     module_id,
                                         sx_port_phy_module_type_e *oper_type_p);

/**
 *  Retrieves the Port's capable physical media type values.
 *
 * @param[in] slot_id - slot ID
 * @param[in] module_id - module ID
 * @param[out] capab_port_rate_p - supported by module rate values
 * @param[out] admin_types_p   - configured by user port types to enable
 * @param[out] capab_types_p   - supported by module electrical interfaces
 *
 * @return sx_status_t - SX_STATUS_SUCCESS if function completed OK.
 * O/W, the appropriate error code it returned.
 */
sx_status_t mgmt_lib_phy_module_capab_get(const sx_slot_id_t                 slot_id,
                                          const sx_port_mod_id_t             module_id,
                                          sx_port_rate_bitmask_t            *capab_port_rate_p,
                                          sx_port_phy_module_type_bitmask_t *admin_types_p,
                                          sx_port_phy_module_type_bitmask_t *capab_types_p);


sx_status_t mgmt_lib_is_module_id_info_valid(const sx_mgmt_module_id_info_t *module_id_info_p, boolean_t *is_valid_p);


sx_status_t mgmt_lib_is_slot_valid(sx_slot_id_t slot_id, boolean_t *is_valid_p);


sx_status_t mgmt_lib_phy_module_pwr_attr_set(const sx_access_cmd_t             cmd,
                                             const sx_mgmt_module_id_info_t   *module_id_info_p,
                                             const sx_mgmt_phy_mod_pwr_attr_t *pwr_attr_p);

sx_status_t mgmt_lib_phy_module_pwr_attr_get(const sx_access_cmd_t           cmd,
                                             const sx_mgmt_module_id_info_t *module_id_info_p,
                                             sx_mgmt_phy_mod_pwr_attr_t     *pwr_attr_p);

sx_status_t mgmt_lib_phy_module_reset(const sx_mgmt_module_id_info_t *module_id_info_p);

sx_status_t mgmt_lib_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);

/**
 *  This API Sets the Port Module Status Change Event Generation mode.
 * @param[in] cmd - SET
 * @param[in] dev_id - Device ID
 * @param[in] port_id - Port ID (whose status to set)
 * @param[in] slot_id - slot ID
 * @param[in] module_id - module ID
 * @param[in] oper_state_change_event_gen_mode - Event generation mode.
 * @param[in] last_oper_state - Last known operational status of the module.
 *
 * @return sx_status_t - SX_STATUS_SUCCESS if function completed OK.
 * O/W, the appropriate error code it returned.
 */
sx_status_t mgmt_lib_module_state_event_set(const sx_access_cmd_t          cmd,
                                            const sx_dev_id_t              dev_id,
                                            const sx_slot_id_t             slot_id,
                                            const sx_port_mod_id_t         module_id,
                                            const sx_event_generate_mode_t oper_state_change_event_gen_mode,
                                            sx_port_module_state_t         last_oper_state);

sx_status_t mgmt_lib_phy_module_state_sync(sx_device_id_t dev_id, sx_slot_id_t slot_id, sx_port_mod_id_t module_id);
sx_status_t mgmt_lib_phy_module_admin_set(sx_device_id_t                   dev_id,
                                          sx_mgmt_module_id_info_t        *module_info_p,
                                          sx_mgmt_phy_module_admin_info_t *admin_info_p);

/* This function is called when a module event is received by the host interface to
 * rearm the module event.
 */
sx_status_t mgmt_lib_module_event_rearm_after_timeout(sx_slot_id_t           slot_id,
                                                      uint32_t               module_id,
                                                      sx_port_module_state_t oper_state,
                                                      sx_dev_id_t            dev_id);
/* This function checks if an event was received for a specific module. If any event is received for a module,
 * then, this function sends an internal event to rearm module event. Rearming the module event involves PMAOS
 * register access, so it needs to be done in SDK main thread context, as async infra cannot handle register
 * access from different threads.
 */
sx_status_t mgmt_lib_module_event_status_poll(int32_t *active_events_cnt_p);

/* These functions are called during ISSU to disable, enable module events */
sx_status_t mgmt_lib_set_module_event_config(sx_slot_id_t slot_id, uint32_t module_id, boolean_t event_disabled);

sx_status_t mgmt_lib_is_module_event_disabled(sx_slot_id_t slot_id, uint32_t module_id, boolean_t *event_disabled_p);

/* Module specific database managed by host interface. */
sx_status_t mgmt_lib_module_event_map_init();
void mgmt_lib_module_event_map_deinit();

#endif /*__MGMT_LIB_H__*/
