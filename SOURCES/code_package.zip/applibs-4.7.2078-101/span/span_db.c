/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "span.h"
#include "span_db.h"
#include "ethl2/brg.h"
#include "ethl2/port_uc_route.h"
#include "ethl2/fdb_common.h"
#include "ethl2/fdb_flood.h"
#include "ethl2/la_db.h"
#include "ethl2/port_db.h"
#include "ethl2/cos_db_sb.h"
#include "host_ifc/host_ifc.h"
#include <sx/sdk/sx_mac.h>
#include <include/resource_manager/resource_manager.h>
#include <complib/cl_mem.h>
#include <complib/cl_dbg.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "sx/utils/gc.h"
#include "sx/sdk/sx_status_convertor.h"

#include "policer/policer_manager.h"

#include "sx_reg_bulk/sx_reg_bulk.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"

#undef __MODULE__
#define __MODULE__ SPAN_DB

/************************************************
 *  Global variables
 ***********************************************/

/* #define SPAN_DEBUG */
#define __SX_LOG_EXIT(SX_STATUS) __sx_log_exit(SX_STATUS, __func__)

extern sx_brg_context_t brg_context;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

#define MIRROR_ENABLE_OBJECT_KEY(log_port, tc_pg) ((uint64_t)log_port << 32 | tc_pg)
#define SPAN_STRING_BUF_SIZE                       (40)
#define SPAN_SMALL_STRING_BUF_SIZE                 (20)
#define SPAN_DB_ANALYZER_MULTI_PORT_NUM_UNSUPORTED (3)

/*************************************************
 *  Local variables
 ***********************************************/
span_db_t                              span_db;
sx_span_session_id_int_t               g_mirror_tables_session = SPAN_NO_SESSION;
sx_span_probability_rate_t             g_mirror_tables_probability_rate = SPAN_DEFAULT_PROBABILITY_RATE;
static sx_span_mirror_header_version_t g_mirror_header_version = SX_SPAN_MIRROR_HEADER_VERSION_0;
static sx_trap_group_t                *g_mirror_drops_hw_trap_groups = NULL;
static uint32_t                        g_mirror_drops_hw_trap_groups_count = 0;

typedef struct {
    boolean_t    in_use;
    uint32_t     trap_id_count;
    sx_trap_id_t trap_id_list[SX_TRAP_ID_MAX + 1];
} span_drop_reason_to_trap_ids_map_t;

typedef sx_status_t (*span_db_pfn_int_session_apply_t) (IN const sx_span_session_id_int_t span_session_id_int,
                                                        IN void                          *context_p);

static span_drop_reason_to_trap_ids_map_t sx_span_drop_reason_to_trap_map[] = {
    [SX_SPAN_DROP_REASON_ALL_ROUTER_DROPS_E] = { FALSE, 9, { SX_TRAP_ID_DISCARD_ING_ROUTER,
                                                             SX_TRAP_ID_DISCARD_ROUTER,
                                                             SX_TRAP_ID_DISCARD_ROUTER2,
                                                             SX_TRAP_ID_DISCARD_ROUTER3,
                                                             SX_TRAP_ID_DISCARD_LSR,
                                                             SX_TRAP_ID_DISCARD_LSR2,
                                                             SX_TRAP_ID_DISCARD_LSR3,
                                                             SX_TRAP_ID_DISCARD_NON_ROUTED,
                                                             SX_TRAP_ID_DISCARD_MC_SCOPE }
    },
    [SX_SPAN_DROP_REASON_DISCARD_ING_PACKET_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_ING_PACKET }
    },
    [SX_SPAN_DROP_REASON_DISCARD_ING_SWITCH_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_ING_SWITCH }
    },
    [SX_SPAN_DROP_REASON_DISCARD_LOOKUP_SWITCH_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_LOOKUP_SWITCH }
    },
    [SX_SPAN_DROP_REASON_DISCARD_ING_ROUTER_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_ING_ROUTER }
    },
    [SX_SPAN_DROP_REASON_DISCARD_ING_LSR_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_ING_LSR }
    },
    [SX_SPAN_DROP_REASON_DISCARD_ROUTER_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_ROUTER }
    },
    [SX_SPAN_DROP_REASON_DISCARD_ROUTER2_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_ROUTER2 }
    },
    [SX_SPAN_DROP_REASON_DISCARD_ROUTER3_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_ROUTER3 }
    },
    [SX_SPAN_DROP_REASON_DISCARD_LSR_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_LSR }
    },
    [SX_SPAN_DROP_REASON_DISCARD_LSR2_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_LSR2 }
    },
    [SX_SPAN_DROP_REASON_DISCARD_LSR3_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_LSR3 }
    },
    [SX_SPAN_DROP_REASON_DISCARD_DEC_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_DEC }
    },
    [SX_SPAN_DROP_REASON_DISCARD_OVERLAY_SWITCH_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_OVERLAY_SWITCH }
    },
    [SX_SPAN_DROP_REASON_DISCARD_ISOLATION_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_ISOLATION }
    },
    [SX_SPAN_DROP_REASON_DISCARD_NON_ROUTED_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_NON_ROUTED }
    },
    [SX_SPAN_DROP_REASON_DISCARD_EGR_LSR_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_EGR_LSR }
    },
    [SX_SPAN_DROP_REASON_DISCARD_MC_SCOPE_E] = { FALSE, 1, { SX_TRAP_ID_DISCARD_MC_SCOPE }
    },
};


/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __span_db_fw_span_session_set(sx_span_session_id_int_t span_session_id,
                                                 span_session_info_t    * span_session_info);
static sx_status_t __span_db_do_sync_fence_and_remove_from_gc_queue();
static sx_status_t __span_db_dump_mirror_enable_port_map(dbg_dump_params_t *dbg_dump_params_p);
static sx_status_t __span_db_analyzer_port_add(sx_port_log_id_t                       port_log_id,
                                               const span_analyzer_port_set_params_t *port_params_p,
                                               sx_span_session_id_int_t               span_session_id);
static sx_status_t __span_db_analyzer_port_delete(IN sx_port_log_id_t         port_log_id,
                                                  IN sx_span_session_id_int_t span_session_id);
static sx_status_t span_mirror_header_padding_cb_wrapper(const sx_span_mirror_header_version_t header_version,
                                                         const sx_span_session_params_t       *sx_span_session_params_p,
                                                         uint8_t                              *padding_p);
static sx_status_t __span_db_analyzer_active_sessions_apply(const sx_port_id_t              analyzer_port_log_id,
                                                            span_db_pfn_int_session_apply_t pfn_func,
                                                            void                          * context_p);
static sx_status_t __span_db_analyzer_lag_port_update_mult_apply(const sx_span_session_id_int_t span_session_id_int,
                                                                 void                          *context_p);
static sx_port_cntr_t __span_db_build_64bit_counter(uint32_t counter_high, uint32_t counter_low);
static sx_status_t __span_db_analyzer_port_set(sx_port_log_id_t                       port_log_id,
                                               const span_analyzer_port_set_params_t *port_params_p,
                                               span_session_info_t                   *span_session_info_p,
                                               sx_span_session_id_int_t               span_session_id);
static sx_status_t __span_db_analyzer_multiport_select(sx_port_log_id_t  port_log_id,
                                                       sx_port_log_id_t *analyzer_multiport_p,
                                                       uint8_t          *multiport_num_p,
                                                       sx_port_log_id_t  port_to_exclude);
static sx_status_t __span_db_analyzer_multiport_num_to_nmp(uint8_t num, span_multiport_number_e *nmp);
static sx_status_t __span_db_multiport_switch_prio_set(span_session_info_t *span_session_info);
static sx_status_t __span_db_analyzer_lag_port_set(sx_port_log_id_t                       port_log_id,
                                                   const span_analyzer_port_set_params_t *port_params_p,
                                                   span_session_info_t                   *span_session_info_p,
                                                   sx_span_session_id_int_t               span_session_id);
static sx_status_t __span_db_mirror_port_probabilty_rate_get(const span_mirror_map_item_t* span_mirror_port_item_p,
                                                             sx_span_probability_rate_t   *rate_p);
/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t span_db_log_verbosity_level(IN sx_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SX_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

/**
 *  This function initializes the SPAN module DB.
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_NO_MEMORY - memory can not be allocated for DB.
 *
 */
sx_status_t span_db_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    cl_status_t cl_status = CL_SUCCESS;
    uint32_t    i;

    SX_LOG_ENTER();

    /*********** allocate span_db************/
    span_db.sx_span_sessions =
        (span_session_t*)cl_malloc(sizeof(span_session_t) *
                                   (rm_resource_global.span_session_id_max_internal + 1));
    if (!span_db.sx_span_sessions) {
        return SX_STATUS_NO_MEMORY;
    }
    memset(span_db.sx_span_sessions, 0, sizeof(span_session_t) *
           (rm_resource_global.span_session_id_max_internal + 1));

    span_db.mirror_bind_entries =
        (span_mirror_bind_entry_t*)cl_malloc(sizeof(span_mirror_bind_entry_t) *
                                             SPAN_DB_MIRROR_BIND_TYPE_NUM);
    memset(span_db.mirror_bind_entries, 0, sizeof(span_mirror_bind_entry_t) *
           SPAN_DB_MIRROR_BIND_TYPE_NUM);

    span_db.mirror_enable_entries =
        (span_mirror_enable_entry_t*)cl_malloc(sizeof(span_mirror_enable_entry_t) *
                                               SPAN_DB_MIRROR_ENABLE_TYPE_NUM);
    memset(span_db.mirror_enable_entries, 0, sizeof(span_mirror_enable_entry_t) *
           SPAN_DB_MIRROR_ENABLE_TYPE_NUM);

    /*********** allocate mapping from external to internal session IDs ************/
    span_db.ext_to_int_id =
        (sx_span_session_id_int_t*)cl_malloc(sizeof(sx_span_session_id_int_t) *
                                             (rm_resource_global.span_session_id_max_external + 1));
    if (!span_db.ext_to_int_id) {
        return SX_STATUS_NO_MEMORY;
    }
    memset(span_db.ext_to_int_id, SPAN_NO_SESSION, sizeof(sx_span_session_id_int_t) *
           (rm_resource_global.span_session_id_max_external + 1));

    /*********** allocate mapping from internal to external session IDs ************/
    span_db.int_to_ext_id =
        (sx_span_session_id_t*)cl_malloc(sizeof(sx_span_session_id_t) *
                                         (rm_resource_global.span_session_id_max_internal + 1));
    if (!span_db.int_to_ext_id) {
        return SX_STATUS_NO_MEMORY;
    }
    memset(span_db.int_to_ext_id, SPAN_NO_SESSION, sizeof(sx_span_session_id_t) *
           (rm_resource_global.span_session_id_max_internal + 1));

    /*********** allocate locks for external session IDs ************/
    span_db.locked =
        (boolean_t*)cl_malloc(sizeof(boolean_t) *
                              (rm_resource_global.span_session_id_max_external + 1));
    if (!span_db.locked) {
        return SX_STATUS_NO_MEMORY;
    }
    memset(span_db.locked, 0, sizeof(boolean_t) *
           (rm_resource_global.span_session_id_max_external + 1));

    /*********** allocate list of available Trap Groups for Drop Mirroring ************/
    g_mirror_drops_hw_trap_groups =
        (sx_trap_group_t*)cl_malloc(sizeof(sx_trap_group_t) *
                                    (rm_resource_global.span_session_id_max_internal + 1));
    if (g_mirror_drops_hw_trap_groups == NULL) {
        return SX_STATUS_NO_MEMORY;
    }
    for (i = 0; i < rm_resource_global.span_session_id_max_internal + 1; i++) {
        g_mirror_drops_hw_trap_groups[i] = SX_TRAP_GROUP_INVALID;
    }

    /*********** SPAN pools INIT ************/
    cl_status = CL_QPOOL_INIT(&(span_db.mirror_ports_pool),
                              SPAN_DB_MIRROR_POOL_MIN_SIZE, SPAN_DB_MIRROR_POOL_MAX_SIZE,
                              SPAN_DB_MIRROR_POOL_GROW_SIZE, sizeof(span_mirror_map_item_t),
                              NULL, NULL, NULL);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("SPAN MIRROR pool initialization failed , cl error: %s\n", CL_STATUS_MSG(cl_status));
        err = SX_STATUS_NO_MEMORY;
        goto err_out;
    }

    cl_status = CL_QPOOL_INIT(&(span_db.mirror_enable_pool),
                              SPAN_DB_MIRROR_ENABLE_POOL_MIN_SIZE, SPAN_DB_MIRROR_ENABLE_POOL_MAX_SIZE,
                              SPAN_DB_MIRROR_ENABLE_POOL_GROW_SIZE, sizeof(span_mirror_enable_item_t),
                              NULL, NULL, NULL);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("SPAN MIRROR enable pool initialization failed , cl error: %s\n", CL_STATUS_MSG(cl_status));
        err = SX_STATUS_NO_MEMORY;
        goto err_out;
    }

    cl_status = CL_QPOOL_INIT(&(span_db.mirror_enable_object_pool),
                              SPAN_DB_MIRROR_ENABLE_OBJECT_POOL_MIN_SIZE, SPAN_DB_MIRROR_ENABLE_OBJECT_POOL_MAX_SIZE,
                              SPAN_DB_MIRROR_ENABLE_OBJECT_POOL_GROW_SIZE, sizeof(span_mirror_enable_object_item_t),
                              NULL, NULL, NULL);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("SPAN MIRROR enable object pool initialization failed , cl error: %s\n", CL_STATUS_MSG(cl_status));
        err = SX_STATUS_NO_MEMORY;
        goto err_out;
    }

    cl_status = CL_QPOOL_INIT(&(span_db.mirror_enable_port_pool),
                              SPAN_DB_MIRROR_ENABLE_POOL_MIN_SIZE, SPAN_DB_MIRROR_ENABLE_POOL_MAX_SIZE,
                              SPAN_DB_MIRROR_ENABLE_POOL_GROW_SIZE, sizeof(span_mirror_enable_port_item_t),
                              NULL, NULL, NULL);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("SPAN MIRROR enable port pool initialization failed , cl error: %s\n", CL_STATUS_MSG(cl_status));
        err = SX_STATUS_NO_MEMORY;
        goto err_out;
    }

    /*********** SPAN maps INIT ************/

    for (i = 0; i <= rm_resource_global.span_session_id_max_internal; i++) {
        cl_qmap_init(&(span_db.sx_span_sessions[i].mirror_ports_db));
    }

    for (i = 0; i < SPAN_DB_MIRROR_ENABLE_TYPE_NUM; i++) {
        cl_qmap_init(&(span_db.mirror_enable_entries[i].mirror_enable_map));
        cl_qmap_init(&(span_db.mirror_enable_entries[i].mirror_enable_object_lookup));
    }
    cl_qmap_init(&(span_db.mirror_disallow_map));

    /*********** SPAN users INIT ************/
    memset(span_db.user, 0, sizeof(span_db.user));

    /*********** SPAN attributes INIT ************/
    span_db.span_attrs.buffer_occupancy_units = SPAN_DB_DEFAULT_BUFFER_OCCUPANCY_UNITS;
    span_db.span_attrs.latency_units = SPAN_DB_DEFAULT_LATENCY_UNITS;

    SX_LOG_EXIT();
    return err;

err_out:
    if (span_db.sx_span_sessions) {
        CL_FREE_N_NULL(span_db.sx_span_sessions);
    }
    SX_LOG_EXIT();
    return err;
}

/**
 *  This function deletes the SPAN module DB.
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_MEMORY_ERROR - memory can not be freed.
 */
sx_status_t span_db_deinit(void)
{
    cl_map_item_t                    *map_item_p = NULL;
    sx_status_t                       err = SX_STATUS_SUCCESS;
    span_mirror_map_item_t           *mirror_map_item_p = NULL;
    span_mirror_enable_item_t        *mirror_enable_item_p = NULL;
    span_mirror_enable_object_item_t *mirror_enable_object_item_p = NULL;
    span_mirror_db_record_t           span_mirror_record;
    sx_span_session_id_int_t          span_session_id;
    span_mirror_enable_port_item_t   *mirror_enable_port_item_p = NULL;
    uint32_t                          i = 0;

    SX_LOG_ENTER();

    for (span_session_id = 0;
         span_session_id <= rm_resource_global.span_session_id_max_internal;
         span_session_id++) {
        if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
            continue;
        }

        /* free Mirror pool */
        map_item_p = cl_qmap_head(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db));
        while (map_item_p != NULL &&
               map_item_p != cl_qmap_end(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db))) {
            mirror_map_item_p = PARENT_STRUCT(map_item_p, span_mirror_map_item_t, map_item);
            span_mirror_record = mirror_map_item_p->span_mirror_record;
            map_item_p = cl_qmap_next(map_item_p);
            SX_CL_QPOOL_PUT(&(mirror_map_item_p->pool_item), &(span_db.mirror_ports_pool));
            SX_LOG_DBG("Put back Mirror to Mirror pool [ pa_id:%u, log_port:%d ]\n",
                       span_mirror_record.pa_id, span_mirror_record.log_port);
        }
    }

    CL_QPOOL_DESTROY(&(span_db.mirror_ports_pool));

    for (i = 0; i < SPAN_DB_MIRROR_ENABLE_TYPE_NUM; i++) {
        /* free Mirror enable pool */
        map_item_p = cl_qmap_head(&(span_db.mirror_enable_entries[i].mirror_enable_map));
        while (map_item_p != NULL &&
               map_item_p != cl_qmap_end(&(span_db.mirror_enable_entries[i].mirror_enable_map))) {
            mirror_enable_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_item_t, map_item);
            map_item_p = cl_qmap_next(map_item_p);
            SX_CL_QPOOL_PUT(&(mirror_enable_item_p->pool_item), &(span_db.mirror_enable_pool));
        }
    }
    CL_QPOOL_DESTROY(&(span_db.mirror_enable_pool));

    for (i = 0; i < SPAN_DB_MIRROR_ENABLE_TYPE_NUM; i++) {
        /* free Mirror enable pool */
        map_item_p = cl_qmap_head(&(span_db.mirror_enable_entries[i].mirror_enable_object_lookup));
        while (map_item_p != NULL &&
               map_item_p != cl_qmap_end(&(span_db.mirror_enable_entries[i].mirror_enable_object_lookup))) {
            mirror_enable_object_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_object_item_t, map_item);
            map_item_p = cl_qmap_next(map_item_p);
            SX_CL_QPOOL_PUT(&(mirror_enable_object_item_p->pool_item), &(span_db.mirror_enable_object_pool));
        }
    }
    CL_QPOOL_DESTROY(&(span_db.mirror_enable_object_pool));

    map_item_p = cl_qmap_head(&(span_db.mirror_disallow_map));
    while (map_item_p != NULL &&
           map_item_p != cl_qmap_end(&(span_db.mirror_disallow_map))) {
        mirror_enable_port_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_port_item_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);
        SX_CL_QPOOL_PUT(&(mirror_enable_port_item_p->pool_item), &(span_db.mirror_enable_port_pool));
    }
    CL_QPOOL_DESTROY(&(span_db.mirror_enable_port_pool));

    if (span_db.locked) {
        CL_FREE_N_NULL(span_db.locked);
    }
    if (span_db.int_to_ext_id) {
        CL_FREE_N_NULL(span_db.int_to_ext_id);
    }
    if (span_db.ext_to_int_id) {
        CL_FREE_N_NULL(span_db.ext_to_int_id);
    }
    if (span_db.sx_span_sessions) {
        CL_FREE_N_NULL(span_db.sx_span_sessions);
    }
    if (g_mirror_drops_hw_trap_groups != NULL) {
        CL_FREE_N_NULL(g_mirror_drops_hw_trap_groups);
    }
    g_mirror_drops_hw_trap_groups_count = 0;
    SX_LOG_EXIT();
    return err;
}

boolean_t span_db_any_sessions_used(void)
{
    boolean_t any_used = FALSE;
    uint32_t  idx = 0;

    SX_LOG_ENTER();

    /* Check if any session used */
    for (idx = 0; idx <= rm_resource_global.span_session_id_max_internal; idx++) {
        if ((span_db.sx_span_sessions[idx].used == TRUE) &&
            (span_db.sx_span_sessions[idx].span_session_info.gc_handle == NULL)) {
            any_used = TRUE;
            break;
        }
    }

    SX_LOG_EXIT();
    return any_used;
}

sx_status_t span_db_total_session_get(OUT uint32_t *count_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx = 0;
    uint32_t    db_count = 0;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(count_p, "count_p"))) {
        goto out;
    }

    /* count active session used */
    for (idx = 0; idx <= rm_resource_global.span_session_id_max_external; idx++) {
        if ((span_db.sx_span_sessions[idx].used == TRUE) &&
            (span_db.sx_span_sessions[idx].span_session_info.gc_handle == NULL)) {
            db_count++;
        }
    }

    *count_p = db_count;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_int_to_ext(sx_span_session_id_int_t span_session_id_int,
                                       sx_span_session_id_t    *span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Initialize to invalid result */
    *span_session_id = SPAN_NO_SESSION;

    /* Verify input in range */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("invalid internal session id %u\n", span_session_id_int);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Lookup external session ID corresponding to this internal session */
    *span_session_id = span_db.int_to_ext_id[span_session_id_int];

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_ext_to_int(sx_span_session_id_t      span_session_id,
                                       sx_span_session_id_int_t *span_session_id_int)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Initialize to invalid result */
    *span_session_id_int = SPAN_NO_SESSION;

    /* Verify input in range */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id)) {
        SX_LOG_ERR("invalid external session id %u\n", span_session_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Lookup internal session ID corresponding to this external session */
    *span_session_id_int = span_db.ext_to_int_id[span_session_id];

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_cnv_span_to_sxd_header_version(const sx_span_mirror_header_version_t span_ver,
                                                   sxd_mpat_version_t                   *sxd_ver_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!sxd_ver_p) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (span_ver) {
    case SX_SPAN_MIRROR_HEADER_VERSION_0:
        *sxd_ver_p = SXD_MPAT_VERSION_V0_E;
        break;

    case SX_SPAN_MIRROR_HEADER_VERSION_1:
        *sxd_ver_p = SXD_MPAT_VERSION_V1_E;
        break;

    case SX_SPAN_MIRROR_HEADER_VERSION_2:
        *sxd_ver_p = SXD_MPAT_VERSION_V2_E;
        break;

    case SX_SPAN_MIRROR_HEADER_NONE:
        *sxd_ver_p = SXD_MPAT_VERSION_NO_HEADER_E;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_cnv_span_to_sxd_mirror_direction(const span_mirror_direction_t     span_dir,
                                                     sxd_span_mirror_port_direction_t *sxd_dir_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!sxd_dir_p) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (span_dir) {
    case SPAN_MIRROR_DIRECTION_EGRESS:
        *sxd_dir_p = SXD_MPAR_MIRROR_DIRECTION_EGRESS;
        break;

    case SPAN_MIRROR_DIRECTION_INGRESS:
        *sxd_dir_p = SXD_MPAR_MIRROR_DIRECTION_INGRESS;
        break;

    case SPAN_MIRROR_DIRECTION_INGRESS_WRED:
        *sxd_dir_p = SXD_MPAR_MIRROR_DIRECTION_INGRESS_WRED;
        break;

    case SPAN_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER:
        *sxd_dir_p = SXD_MPAR_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER;
        break;

    case SPAN_MIRROR_DIRECTION_INGRESS_PG_CONGESTION:
        *sxd_dir_p = SXD_MPAR_MIRROR_DIRECTION_INGRESS_ING_CONGESTION;
        break;

    case SPAN_MIRROR_DIRECTION_INGRESS_TC_CONGESTION:
        *sxd_dir_p = SXD_MPAR_MIRROR_DIRECTION_INGRESS_EGR_CONGESTION;
        break;

    case SPAN_MIRROR_DIRECTION_EGRESS_ECN:
        *sxd_dir_p = SXD_MPAR_MIRROR_DIRECTION_EGRESS_ECN;
        break;

    case SPAN_MIRROR_DIRECTION_EGRESS_TC_LATENCY:
        *sxd_dir_p = SXD_MPAR_MIRROR_DIRECTION_EGRESS_TC_LATENCY;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_cnv_sxd_to_span_mirror_direction(const sxd_span_mirror_port_direction_t sxd_dir,
                                                     span_mirror_direction_t               *span_dir_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!span_dir_p) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (sxd_dir) {
    case SXD_MPAR_MIRROR_DIRECTION_EGRESS:
        *span_dir_p = SPAN_MIRROR_DIRECTION_EGRESS;
        break;

    case SXD_MPAR_MIRROR_DIRECTION_INGRESS:
        *span_dir_p = SPAN_MIRROR_DIRECTION_INGRESS;
        break;

    case SXD_MPAR_MIRROR_DIRECTION_INGRESS_WRED:
        *span_dir_p = SPAN_MIRROR_DIRECTION_INGRESS_WRED;
        break;

    case SXD_MPAR_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER:
        *span_dir_p = SPAN_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER;
        break;

    case SXD_MPAR_MIRROR_DIRECTION_INGRESS_ING_CONGESTION:
        *span_dir_p = SPAN_MIRROR_DIRECTION_INGRESS_PG_CONGESTION;
        break;

    case SXD_MPAR_MIRROR_DIRECTION_INGRESS_EGR_CONGESTION:
        *span_dir_p = SPAN_MIRROR_DIRECTION_INGRESS_TC_CONGESTION;
        break;

    case SXD_MPAR_MIRROR_DIRECTION_EGRESS_ECN:
        *span_dir_p = SPAN_MIRROR_DIRECTION_EGRESS_ECN;
        break;

    case SXD_MPAR_MIRROR_DIRECTION_EGRESS_TC_LATENCY:
        *span_dir_p = SPAN_MIRROR_DIRECTION_EGRESS_TC_LATENCY;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_id_int_alloc(sx_span_session_id_int_t* span_session_id_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx = 0;
    boolean_t   is_sync_fence_needed = FALSE;


    SX_LOG_ENTER();

    /* Allocate an internal SPAN session ID*/
    for (idx = 0; idx <= rm_resource_global.span_session_id_max_internal; idx++) {
        if (span_db.sx_span_sessions[idx].used == FALSE) {
            *span_session_id_p = idx;
            is_sync_fence_needed = FALSE;
            break;
        } else if ((span_db.ext_to_int_id[idx] != SPAN_NO_SESSION) &&
                   (span_db.sx_span_sessions[span_db.ext_to_int_id[idx]].span_session_info.gc_handle != NULL)) {
            is_sync_fence_needed = TRUE;
        }
    }

    /* No resources case */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(idx)) {
        /*this if will be true only on spectrum */
        if (is_sync_fence_needed == TRUE) {
            /* In this case we will do sync fence, empty the gc queue and delete the span items from the queue */
            err = __span_db_do_sync_fence_and_remove_from_gc_queue();
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed in  __span_db_do_sync_fence_and_remove_from_gc_queue, utils_err = [%s]\n",
                           sx_status_str(err));
                goto out;
            }
            for (idx = 0; idx <= rm_resource_global.span_session_id_max_internal; idx++) {
                if (span_db.sx_span_sessions[idx].used == FALSE) {
                    *span_session_id_p = idx;
                    break;
                }
            }
        } else {
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }
    }

    /* Initialize session */
    span_db.sx_span_sessions[idx].used = TRUE;
    SX_MEM_CLR(span_db.sx_span_sessions[idx].span_session_info);
    span_db.sx_span_sessions[idx].span_session_info.system_port = SPAN_INVALID_SYSTEM_PORT;
    span_db.sx_span_sessions[idx].analyzer_port = SX_SPAN_INVALID_LOG_PORT;

    cl_qmap_init(&(span_db.sx_span_sessions[idx].mirror_ports_db));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_id_alloc(sx_span_session_id_t* span_session_id_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint32_t                 idx = 0;
    sx_span_session_id_int_t span_session_id_int = SPAN_NO_SESSION;
    boolean_t                is_sync_fence_needed = FALSE;

    SX_LOG_ENTER();


    /* Try to assign an free external session number */
    for (idx = 0; idx <= rm_resource_global.span_session_id_max_external; idx++) {
        if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_db.ext_to_int_id[idx])) {
            *span_session_id_p = idx;
            is_sync_fence_needed = FALSE;

            break;
        } else if (span_db.sx_span_sessions[span_db.ext_to_int_id[idx]].span_session_info.gc_handle != NULL) {
            is_sync_fence_needed = TRUE;
        }
    }

    /* No free external session */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(idx)) {
        if (is_sync_fence_needed == TRUE) {
            /* In this case we will do sync fence, empty the gc queue and delete the span items from the queue */
            err = __span_db_do_sync_fence_and_remove_from_gc_queue();
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed in  __span_db_do_sync_fence_and_remove_from_gc_queue, utils_err = [%s]\n",
                           sx_status_str(err));
                goto out;
            }
            /* Try to assign an free external session number */
            for (idx = 0; idx <= rm_resource_global.span_session_id_max_external; idx++) {
                if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_db.ext_to_int_id[idx])) {
                    *span_session_id_p = idx;
                    break;
                }
            }
        } else {
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }
    }

    /* Allocate an internal SPAN session ID*/
    err = span_db_session_id_int_alloc(&span_session_id_int);
    if (err) {
        goto out;
    }

    /* Map between internal and external sessions */
    span_db.ext_to_int_id[*span_session_id_p] = span_session_id_int;
    span_db.int_to_ext_id[span_session_id_int] = *span_session_id_p;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_do_sync_fence_and_remove_from_gc_queue()
{
    sx_status_t              status = SX_STATUS_SUCCESS;
    sx_utils_status_t        utils_status = SX_UTILS_STATUS_SUCCESS;
    sx_span_session_id_int_t int_id;
    uint32_t                 idx = 0;


    SX_LOG_ENTER();

    utils_status = gc_object_fence(GC_FENCE_TYPE_SLOW);
    status = sx_utils_status_to_sx_status(utils_status);
    if (SX_UTILS_CHECK_FAIL(utils_status)) {
        SX_LOG_ERR("Failed to perform fence operation , utils_err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_status));
        goto out;
    }

    for (idx = 0; idx <= rm_resource_global.span_session_id_max_external; idx++) {
        int_id = span_db.ext_to_int_id[idx];
        if (span_db.sx_span_sessions[int_id].span_session_info.gc_handle != NULL) {
            utils_status = gc_object_remove(span_db.sx_span_sessions[int_id].span_session_info.gc_handle);
            status = sx_utils_status_to_sx_status(utils_status);
            if (SX_UTILS_CHECK_FAIL(utils_status)) {
                SX_LOG_ERR("Failed to remove %d from gc queue , utils_err = [%s]\n",
                           idx, SX_UTILS_STATUS_MSG(utils_status));
                goto out;
            }

            status = span_free_session_id_free_spectrum(idx);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to delete %d , utils_err = [%s]\n",
                           int_id, sx_status_str(status));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t span_db_session_id_int_free(sx_span_session_id_int_t span_session_id)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_err = SXD_STATUS_SUCCESS;
    span_session_info_t span_session_info;

    SX_LOG_ENTER();

    /* Look up internal session */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id)) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Check double free */
    if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
        SX_LOG_ERR("Try to free non existent SPAN session id %d !!!\n",
                   span_session_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* disable SPAN session in FW */
    SX_MEM_CLR(span_session_info);
    span_session_info.pa_id = span_session_id;
    span_session_info.span_type = SX_SPAN_TYPE_MIN;
    span_session_info.admin_state = FALSE;
    span_session_info.system_port = SPAN_INVALID_SYSTEM_PORT;

    err = __span_db_fw_span_session_set(span_session_id,
                                        &span_session_info);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__span_db_fw_span_session_set(SPAN %d, ... ) failed, rc: %s\n",
                   span_session_id, sx_status_str(err));
        /* Continue, make the best of a bad situation, e.g. if this free was */
        /* called because FW failed on allocation and fails again for free   */
        /* with the same parameters, we want to free local resources         */
    }

    span_db.sx_span_sessions[span_session_id].used = FALSE;
    SX_MEM_CLR(span_db.sx_span_sessions[span_session_id].span_session_info);

    sxd_err = sxd_dpt_span_session_map_set(SXD_ACCESS_CMD_DELETE,
                                           span_session_info.session_id,
                                           span_session_id);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        err = sxd_status_to_sx_status(sxd_err);
        SX_LOG_ERR("sxd_dpt_span_session_map_set DEL ext span_id:%d, hw span_id:%d failed. err: %s \n",
                   span_session_info.session_id, span_session_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_id_free(sx_span_session_id_t span_session_id)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    /* Look up internal session */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id)) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    ATOMIC_LOAD_VAL(span_session_id_int, span_db.ext_to_int_id[span_session_id]);

    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Free internal session */
    err = span_db_session_id_int_free(span_session_id_int);
    if (err) {
        SX_LOG_ERR("span_db_session_id_int_free %d failed. rc: %s\n",
                   span_session_id_int, sx_status_str(err));
        /* Continue, make the best of a bad situation */
    }

    span_db.sx_span_sessions[span_session_id_int].span_session_info.gc_handle = NULL;
    span_db.sx_span_sessions[span_session_id_int].span_session_info.span_gc_context_item.
    span_session_id = SPAN_NO_SESSION;

    /* Break external <-> internal mapping */
    span_db.ext_to_int_id[span_session_id] = SPAN_NO_SESSION;
    span_db.int_to_ext_id[span_session_id_int] = SPAN_NO_SESSION;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_id_remap(sx_span_session_id_t     span_session_id,
                                     sx_span_session_id_int_t span_session_id_int)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_span_session_id_t old_span_session_id;
    sx_span_session_id_t old_span_session_id_int;

    SX_LOG_ENTER();

    /* Validate inputs */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id)) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    ATOMIC_LOAD_VAL(old_span_session_id, span_db.int_to_ext_id[span_session_id_int]);
    ATOMIC_LOAD_VAL(old_span_session_id_int, span_db.ext_to_int_id[span_session_id]);

    /* Break any previous mappings if they exist */
    if (RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(old_span_session_id)) {
        span_db.ext_to_int_id[old_span_session_id] = SPAN_NO_SESSION;
    }
    if (RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(old_span_session_id_int)) {
        span_db.int_to_ext_id[old_span_session_id_int] = SPAN_NO_SESSION;
    }

    /* Map internal and external sessions to each other */
    span_db.ext_to_int_id[span_session_id] = span_session_id_int;
    /* coverity[sensitive_memory_access] */
    span_db.int_to_ext_id[span_session_id_int] = span_session_id;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_gc_context_set(span_session_info_t *span_session_info_p)
{
    sx_status_t              status = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    /* Look up internal session */
    status =
        span_db_session_ext_to_int(span_session_info_p->span_gc_context_item.span_session_id, &span_session_id_int);
    if ((status != SX_STATUS_SUCCESS) || (span_session_id_int == SPAN_NO_SESSION)) {
        goto out;
    }

    span_db.sx_span_sessions[span_session_id_int].span_session_info.gc_handle = span_session_info_p->gc_handle;
    span_db.sx_span_sessions[span_session_id_int].span_session_info.span_gc_context_item =
        span_session_info_p->span_gc_context_item;


out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t span_db_session_set(sx_span_session_id_int_t span_session_id, span_session_info_t*    span_session_info)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
        SX_LOG_ERR("SPAN session %d is not allocated. \n",
                   span_session_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* don't config SPAN till it has Analyzer port */
    if (span_session_info->admin_state == TRUE) {
        if (span_session_info->is_multiport == TRUE) {
            if (span_session_info->multiport[0] == SPAN_INVALID_SYSTEM_PORT) {
                /* Multiport SPAN has no active ports */
                goto save_to_db;
            }
        } else if (span_session_info->system_port == SPAN_INVALID_SYSTEM_PORT) {
            /* SPAN has no analyzer port */
            goto save_to_db;
        }
    }

    err = __span_db_fw_span_session_set(span_session_id,
                                        span_session_info);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__span_db_fw_span_session_set(SPAN %d, ... ) failed, rc: %s\n",
                   span_session_id, sx_status_str(err));
        goto out;
    }

save_to_db:
    span_db.sx_span_sessions[span_session_id].span_session_info =
        *span_session_info;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_find(sx_span_session_id_int_t span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_get(sx_span_session_id_int_t span_session_id,
                                span_session_info_t     *span_session_info,
                                sx_port_log_id_t        *analyzer_port,
                                uint32_t                *mirrors_num,
                                span_mirror_t           *mirrors_arr,
                                uint32_t                *ref_cnt,
                                boolean_t               *table_mirror)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    cl_map_item_t          *map_item_p = NULL;
    span_mirror_map_item_t *mirror_map_item_p = NULL;
    span_mirror_db_record_t span_mirror_record;

    SX_LOG_ENTER();

    if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (span_session_info != NULL) {
        *span_session_info = span_db.sx_span_sessions[span_session_id].span_session_info;
    }

    if (analyzer_port != NULL) {
        *analyzer_port = span_db.sx_span_sessions[span_session_id].analyzer_port;
    }

    if ((mirrors_num != NULL) && (*mirrors_num != 0) &&
        (mirrors_arr != NULL)) {
        /* get mirror ports count and the port list */
        uint32_t curr_mirror_ports_num = cl_qmap_count(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db));
        uint32_t i = 0;

        *mirrors_num = MIN(*mirrors_num, curr_mirror_ports_num);
        curr_mirror_ports_num = *mirrors_num;

        map_item_p = cl_qmap_head(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db));
        while (map_item_p != NULL &&
               map_item_p != cl_qmap_end(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db)) &&
               i < curr_mirror_ports_num) {
            mirror_map_item_p = PARENT_STRUCT(map_item_p, span_mirror_map_item_t, map_item);
            span_mirror_record = mirror_map_item_p->span_mirror_record;
            mirrors_arr[i].log_port = span_mirror_record.log_port;
            mirrors_arr[i].mirror_direction = span_mirror_record.mirror_direction;
            map_item_p = cl_qmap_next(map_item_p);
            SX_LOG_DBG("Found Mirror port [ pa_id:%u, log_port: %d  ]\n",
                       span_mirror_record.pa_id, span_mirror_record.log_port);
            i++;
        }
    } else if ((mirrors_num != NULL) && (*mirrors_num == 0)) {
        /* get mirror ports count only */
        *mirrors_num = cl_qmap_count(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db));
    }

    if (ref_cnt != NULL) {
        *ref_cnt = span_db.sx_span_sessions[span_session_id].span_session_info.ref_cnt;
    }

    if (table_mirror != NULL) {
        if ((g_mirror_tables_session == span_session_id) ||
            span_db.sx_span_sessions[span_session_id].span_session_info.drop_mirror.trap_group_valid) {
            *table_mirror = TRUE;
        } else {
            *table_mirror = FALSE;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_analyzer_multiport_get(sx_span_session_id_int_t span_session_id_int,
                                           sx_port_log_id_t        *analyzer_multiport_p,
                                           uint8_t                 *multiport_num_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(multiport_num_p);

    if (span_db.sx_span_sessions[span_session_id_int].used == FALSE) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(span_db.sx_span_sessions[span_session_id_int].analyzer_port) != SX_PORT_TYPE_LAG) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (analyzer_multiport_p != NULL) {
        if (*multiport_num_p != SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX) {
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

    *multiport_num_p = span_db.sx_span_sessions[span_session_id_int].multiport_num;
    if (analyzer_multiport_p != NULL) {
        SX_MEM_CPY_ARRAY(analyzer_multiport_p,
                         span_db.sx_span_sessions[span_session_id_int].analyzer_multiport,
                         span_db.sx_span_sessions[span_session_id_int].multiport_num,
                         sx_port_log_id_t);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_drop_reason_in_list(const sx_span_drop_reason_t  drop_reason,
                                        const sx_span_drop_reason_t *drop_reason_list_p,
                                        const uint32_t               drop_reason_count,
                                        boolean_t                   *has_drop_reason)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    drop_reason_idx = 0;
    boolean_t   found_drop_reason = FALSE;

    SX_LOG_ENTER();

    for (drop_reason_idx = 0; drop_reason_idx < drop_reason_count; drop_reason_idx++) {
        if (drop_reason_list_p[drop_reason_idx] == drop_reason) {
            found_drop_reason = TRUE;
            break;
        }
    }
    *has_drop_reason = found_drop_reason;

    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_iter_get(IN const sx_access_cmd_t       cmd,
                                     IN const sx_span_session_id_t *span_session_key_p,
                                     IN const sx_span_filter_t     *filter_p,
                                     OUT sx_span_session_id_t      *span_session_list_p,
                                     INOUT uint32_t                *span_session_cnt_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_t     span_session_id_ext = 0;
    sx_span_session_id_int_t span_session_id_int = 0;
    span_session_info_t      span_session_info;
    uint32_t                 db_total_count = 0;
    uint32_t                 db_found_count = 0;
    boolean_t                has_drop_reason = FALSE;

    UNUSED_PARAM(filter_p);

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*span_session_cnt_p == 0) {
            /* count of 0 with GET implies return the total count of sessions
             *  return the db count. we are done */
            err = span_db_total_session_get(&db_total_count);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get number of sessions from SPAN db, err = [%s]\n",
                           sx_status_str(err));
                goto out;
            }
            *span_session_cnt_p = db_total_count;
            goto out;
        } else {
            /* find the session but first get the corresponding internal session id */
            span_session_id_ext = *span_session_key_p;
            err = span_db_session_ext_to_int(span_session_id_ext, &span_session_id_int);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_DEBUG, "[%s] Could not find int session for ext session id [%d]. rc= [%s]\n",
                       __func__, span_session_id_ext, sx_access_cmd_str(cmd));
                *span_session_cnt_p = 0;
                goto out;
            } else if (span_session_id_int == SPAN_NO_SESSION) {
                *span_session_cnt_p = 0;
                goto out;
            }

            err = span_db_session_get(span_session_id_int, &span_session_info, NULL, NULL, NULL, NULL, NULL);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_INFO, "SPAN session id %d isn't found.\n", span_session_id_int);
                err = SX_STATUS_SUCCESS;

                /* Return Empty List */
                *span_session_cnt_p = 0;
            } else {
                /* Found the session.*/

                if (filter_p->filter_by_drop_reason) {
                    err = span_db_drop_reason_in_list(filter_p->drop_reason,
                                                      span_session_info.drop_mirror.drop_reasons,
                                                      span_session_info.drop_mirror.drop_reasons_count,
                                                      &has_drop_reason);
                    if (SX_CHECK_FAIL(err)) {
                        SX_LOG_ERR("Error searching for Drop Reason. rc= [%s]\n", sx_access_cmd_str(cmd));
                        goto out;
                    }
                    if (!has_drop_reason) {
                        *span_session_cnt_p = 0;
                        goto out;
                    }
                }

                /* Session that were deleted and are currently pending fence should not be returned */
                if (span_session_info.gc_handle != NULL) {
                    *span_session_cnt_p = 0;
                    goto out;
                }

                *span_session_cnt_p = 1;
                *span_session_list_p = span_session_id_ext;
            }
        }
        goto out;
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        span_session_id_ext = 0;
        break;

    case SX_ACCESS_CMD_GETNEXT:
        span_session_id_ext = (*span_session_key_p) + 1;
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
        break;
    }

    if (*span_session_cnt_p == 0) {
        /* return empty list. */
        SX_LOG(SX_LOG_DEBUG, "[%s] Cmd = %s; but count is 0 return Empty List\n",
               __func__, sx_access_cmd_str(cmd));
        goto out;
    }

    while (span_session_id_ext <= rm_resource_global.span_session_id_max_external &&
           db_found_count < *span_session_cnt_p) {
        err = span_db_session_ext_to_int(span_session_id_ext, &span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_DEBUG, "[%s] Could not find int session for ext session id [%d]. rc= [%s]\n",
                   __func__, span_session_id_ext, sx_access_cmd_str(cmd));
            goto out;
        } else if (span_session_id_int == SPAN_NO_SESSION) {
            span_session_id_ext++;
            continue;
        }

        err = span_db_session_get(span_session_id_int, &span_session_info, NULL, NULL, NULL, NULL, NULL);
        if (SX_CHECK_FAIL(err)) {
            err = SX_STATUS_SUCCESS;
            span_session_id_ext++;
            continue;
        }

        /* Session that were deleted and are currently pending fence should not be returned */
        if (span_session_info.gc_handle != NULL) {
            span_session_id_ext++;
            continue;
        }

        if (filter_p->filter_by_drop_reason) {
            err = span_db_drop_reason_in_list(filter_p->drop_reason,
                                              span_session_info.drop_mirror.drop_reasons,
                                              span_session_info.drop_mirror.drop_reasons_count,
                                              &has_drop_reason);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Error searching for Drop Reason. rc= [%s]\n", sx_access_cmd_str(cmd));
                goto out;
            }
            if (!has_drop_reason) {
                span_session_id_ext++;
                continue;
            }
        }

        span_session_list_p[db_found_count] = span_session_id_ext;

        span_session_id_ext++;
        db_found_count++;
    }
    *span_session_cnt_p = db_found_count;

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __span_db_fw_mirror_port_set(IN sx_port_log_id_t           port_log_id,
                                                IN sx_span_session_id_int_t   span_session_id,
                                                IN span_mirror_direction_t    direction,
                                                IN sx_span_probability_rate_t rate,
                                                IN boolean_t                  enable)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t                   reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_mpar_reg               mpar_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t                     sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_port_type_t                   port_type;
    sxd_span_mirror_port_direction_t sxd_direction;

    SX_LOG_ENTER();

    /* Get list of LEAF devices */
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_DEBUG, "Empty device list [%s]: Zerodev config\n",
               sx_status_str(err));
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    port_type = SX_PORT_TYPE_ID_GET(port_log_id);
    if (SX_PORT_TYPE_LAG == port_type) {
        SX_LOG(SX_LOG_ERROR, "LAG port is not supported.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* dev_idx in SX_FDB_FOR_EACH_LEAF_DEV_VARS initialized to 0 */
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = SX_PORT_DEV_ID_GET(port_log_id); /* dev_info_arr[dev_idx].dev_id; */
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_ADD;

    SX_MEM_CLR(mpar_reg_data[dev_idx]);

    /* today we support only SXD_SPAN_MNGR_HYPERVISOR */
    mpar_reg_data[dev_idx].mngr_type = SXD_SPAN_MNGR_HYPERVISOR; /**<  mngr_type - Manager Type*/
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(mpar_reg_data[dev_idx].local_port,
                                        mpar_reg_data[dev_idx].lp_msb,
                                        SX_PORT_PHY_ID_GET(port_log_id));
    mpar_reg_data[dev_idx].pa_id = span_session_id;
    mpar_reg_data[dev_idx].enable = enable;
    mpar_reg_data[dev_idx].probability_rate = rate;

    /* Set the port mirroring directions */
    err = span_db_cnv_span_to_sxd_mirror_direction(direction,
                                                   &sxd_direction);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }
    mpar_reg_data[dev_idx].i_e = sxd_direction;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MPAR_E,
                                                     mpar_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed MPAR set: [%s] egress direction.\n",
               SXD_STATUS_MSG(sxd_status));

        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

#ifdef SPAN_DEBUG
static sx_status_t __span_db_fw_mirror_port_get(IN sx_port_log_id_t           port_log_id,
                                                IN span_mirror_direction_t    direction,
                                                OUT sx_span_session_id_int_t *span_session_id,
                                                OUT boolean_t                *enable)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t                   reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_mpar_reg               mpar_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t                     sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_port_type_t                   port_type;
    sxd_span_mirror_port_direction_t sxd_direction;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mpar_reg_data);

    /* Get list of LEAF devices */
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_DEBUG, "Empty device list [%s]: Zerodev config\n",
               sx_status_str(err));
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    port_type = SX_PORT_TYPE_ID_GET(port_log_id);
    if (SX_PORT_TYPE_LAG == port_type) {
        SX_LOG(SX_LOG_ERROR, "LAG port is not supported.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* dev_idx in SX_FDB_FOR_EACH_LEAF_DEV_VARS initialized to 0 */
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_GET;

    /* today we support only SXD_SPAN_MNGR_HYPERVISOR */
    mpar_reg_data[dev_idx].mngr_type = SXD_SPAN_MNGR_HYPERVISOR; /**<  mngr_type - Manager Type*/
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(mpar_reg_data[dev_idx].local_port,
                                        mpar_reg_data[dev_idx].lp_msb,
                                        SX_PORT_PHY_ID_GET(port_log_id));

    /* Set the port mirroring directions */
    err = span_db_cnv_span_to_sxd_mirror_direction(direction,
                                                   &sxd_direction);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }
    mpar_reg_data[dev_idx].i_e = sxd_direction;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MPAR_E, mpar_reg_data, reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed MPAR get: [%s].\n",
               SXD_STATUS_MSG(sxd_status));

        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    if (enable != NULL) {
        *enable = mpar_reg_data[dev_idx].enable ? TRUE : FALSE;
    }

    if (span_session_id != NULL) {
        *span_session_id = mpar_reg_data[dev_idx].pa_id;
    }

out:
    SX_LOG_EXIT();
    return err;
}
#endif /* ifdef SPAN_DEBUG */

static sx_status_t __span_db_sx_span_qos_mode_t_to_sxd_mpat_qos_t(const sx_span_qos_mode_t sx_qos,
                                                                  sxd_mpat_qos_t          *sxd_qos)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (sx_qos) {
    case SX_SPAN_QOS_CONFIGURED:
        *sxd_qos = SXD_MPAT_QOS_CONFIGURED_E;
        break;

    case SX_SPAN_QOS_MAINTAIN:
        *sxd_qos = SXD_MPAT_QOS_MAINTAIN_E;
        break;

    default:
        SX_LOG_ERR("Invalid QOS type [%d] for MPAT register.\n", sx_qos);
        err = SX_STATUS_ERROR;
        break;
    }

    SX_LOG_EXIT();
    return err;
}


static sx_status_t __span_db_fw_span_session_set(sx_span_session_id_int_t span_session_id,
                                                 span_session_info_t    * span_session_info)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t                  reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_mpat_reg              mpat_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t                    sxd_status = SXD_STATUS_SUCCESS;
    sxd_mpat_version_t              ver;
    sx_span_mirror_header_version_t header_version;
    sx_status_t                     err = SX_STATUS_SUCCESS;
    policer_manager_index_t         policer_hw_id = 0;
    policer_manager_block_length_t  policer_size = 0;
    length_t                        i = 0;

    SX_LOG_ENTER();

    if (span_session_info->policer_enable) {
        err = policer_manager_handle_lock(span_session_info->policer_id,
                                          POLICER_MANAGER_TYPE_SPAN_E,
                                          &policer_hw_id,
                                          &policer_size);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Error in policer_manager_handle_lock : error (%s)\n", sx_status_str(err));
            goto out;
        }
    }

    /* Get list of LEAF devices */
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_DEBUG, "Empty device list [%s]: Zerodev config\n",
               sx_status_str(err));
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    /* For each LEAF device */
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_ADD;

    SX_MEM_CLR(mpat_reg_data[dev_idx]);
    mpat_reg_data[dev_idx].mngr_type = SXD_MPAT_MNGR_TYPE_HYPERVISOR_E;

    mpat_reg_data[dev_idx].pa_id = span_session_id;
    if (span_session_info->system_port != SPAN_INVALID_SYSTEM_PORT) {
        mpat_reg_data[dev_idx].system_port = span_session_info->system_port;
    }

    if (span_session_info->is_multiport) {
        mpat_reg_data[dev_idx].imp = span_session_info->is_multiport;
        mpat_reg_data[dev_idx].nmp = span_session_info->multiport_nmp;
        mpat_reg_data[dev_idx].switch_prio = span_session_info->switch_prio;
        mpat_reg_data[dev_idx].tclass = span_session_info->tclass;
        for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
            if (span_session_info->multiport[i] != SPAN_INVALID_SYSTEM_PORT) {
                mpat_reg_data[dev_idx].multi_port[i] = span_session_info->multiport[i];
            }
        }
    }

    /* e - Indicating the Port Analyzer it enabled */
    mpat_reg_data[dev_idx].e = span_session_info->admin_state;
    /* be - Best Effort traffic handling */
    mpat_reg_data[dev_idx].be = (span_session_info->port_params.cng_mng == SX_SPAN_CNG_MNG_DISCARD);

    /* tr - truncate the packet to truncate size */
    mpat_reg_data[dev_idx].tr = span_session_info->truncate;
    /* truncation size - configurable in Spectrum */
    mpat_reg_data[dev_idx].truncation_size = span_session_info->truncation_size;
    err = span_mirror_truncation_hw_set_cb_wrapper(&mpat_reg_data[dev_idx]);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failure in span_mirror_truncation_hw_set_spectrum4 of SPAN session id %hu. err: %s.\n",
                   span_session_info->session_id, sx_status_str(err));
        goto out;
    }

    /* stclass - Stacking TClass */
    mpat_reg_data[dev_idx].stclass = span_session_info->stclass;

    if (span_session_info->policer_enable) {
        mpat_reg_data[dev_idx].pide = 1;
        mpat_reg_data[dev_idx].pid = policer_hw_id;
    }

    switch (span_session_info->span_type) {
    case SX_SPAN_TYPE_LOCAL_IB:
        mpat_reg_data[dev_idx].span_type = SXD_MPAT_SPAN_TYPE_LOCAL_IB_E;
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_localib.vl =
            span_session_info->span_type_format.local_ib.vl;
        break;

    case SX_SPAN_TYPE_LOCAL_ETH_TYPE1:
        mpat_reg_data[dev_idx].span_type = SXD_MPAT_SPAN_TYPE_LOCAL_ETH_E;
        err = __span_db_sx_span_qos_mode_t_to_sxd_mpat_qos_t(
            span_session_info->span_type_format.local_eth_type1.qos_mode,
            &mpat_reg_data[dev_idx].qos);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to convert QOS mode [%d] to SXD value, err: %s\n",
                       span_session_info->span_type_format.local_eth_type1.qos_mode, sx_status_str(err));
            goto out;
        }
        if ((span_session_info->span_type_format.local_eth_type1.qos_mode ==
             SX_SPAN_QOS_CONFIGURED) && !span_session_info->is_multiport) {
            mpat_reg_data[dev_idx].encapsulation.local_span.tclass =
                span_session_info->span_type_format.local_eth_type1.switch_prio;
        }
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1:
        mpat_reg_data[dev_idx].span_type = SXD_MPAT_SPAN_TYPE_REMOTE_ETH_E;
        err = __span_db_sx_span_qos_mode_t_to_sxd_mpat_qos_t(
            span_session_info->span_type_format.remote_eth_vlan_type1.qos_mode,
            &mpat_reg_data[dev_idx].qos);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to convert QOS mode [%d] to SXD value, err: %s\n",
                       span_session_info->span_type_format.remote_eth_vlan_type1.qos_mode, sx_status_str(err));
            goto out;
        }
        if (span_session_info->span_type_format.remote_eth_vlan_type1.qos_mode ==
            SX_SPAN_QOS_CONFIGURED) {
            mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethvlan.pcp =
                span_session_info->span_type_format.remote_eth_vlan_type1.pcp;
            mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethvlan.dei =
                span_session_info->span_type_format.remote_eth_vlan_type1.dei;
            if (!span_session_info->is_multiport) {
                mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethvlan.tclass =
                    span_session_info->span_type_format.remote_eth_vlan_type1.switch_prio;
            }
        }
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethvlan.vid =
            span_session_info->span_type_format.remote_eth_vlan_type1.vid;
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethvlan.vlan_et_id =
            span_session_info->span_type_format.remote_eth_vlan_type1.vlan_ethertype_id;
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1:
        mpat_reg_data[dev_idx].span_type = SXD_MPAT_SPAN_TYPE_REMOTE_ETH_L2_E;
        err = __span_db_sx_span_qos_mode_t_to_sxd_mpat_qos_t(
            span_session_info->span_type_format.remote_eth_l2_type1.qos_mode,
            &mpat_reg_data[dev_idx].qos);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to convert QOS mode [%d] to SXD value, err: %s\n",
                       span_session_info->span_type_format.remote_eth_l2_type1.qos_mode, sx_status_str(err));
            goto out;
        }
        if (span_session_info->params.version != SX_SPAN_MIRROR_HEADER_VERSION_INVALID) {
            header_version = span_session_info->params.version;
        } else {
            header_version = g_mirror_header_version;
        }
        err = span_db_cnv_span_to_sxd_header_version(header_version, &ver);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to convert span header version %u to SXD version, err: %s\n",
                       header_version, sx_status_str(err));
            goto out;
        }
        if (span_session_info->span_type_format.remote_eth_l2_type1.qos_mode ==
            SX_SPAN_QOS_CONFIGURED) {
            mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl2.pcp =
                span_session_info->span_type_format.remote_eth_l2_type1.pcp;
            mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl2.dei =
                span_session_info->span_type_format.remote_eth_l2_type1.dei;
            if (!span_session_info->is_multiport) {
                mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl2.tclass =
                    span_session_info->span_type_format.remote_eth_l2_type1.switch_prio;
            }
        }
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl2.version = ver;
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl2.vid =
            span_session_info->span_type_format.remote_eth_l2_type1.vid;

        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl2.tp =
            span_session_info->span_type_format.remote_eth_l2_type1.tp;
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl2.vlan_et_id =
            span_session_info->span_type_format.remote_eth_l2_type1.vlan_ethertype_id;
        memcpy(mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl2.mac,
               &span_session_info->span_type_format.remote_eth_l2_type1.mac,
               sizeof(span_session_info->span_type_format.remote_eth_l2_type1.mac));

        err = span_mirror_header_padding_cb_wrapper(header_version,
                                                    &span_session_info->params,
                                                    &mpat_reg_data[dev_idx].pc);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set padding to Mirror Header, error: %s\n", sx_status_str(err));
            goto out;
        }

        break;

    case SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1:
        mpat_reg_data[dev_idx].span_type = SXD_MPAT_SPAN_TYPE_REMOTE_ETH_L3_E;
        err = __span_db_sx_span_qos_mode_t_to_sxd_mpat_qos_t(
            span_session_info->span_type_format.remote_eth_l3_type1.qos_mode,
            &mpat_reg_data[dev_idx].qos);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to convert QOS mode [%d] to SXD value, err: %s\n",
                       span_session_info->span_type_format.remote_eth_l3_type1.qos_mode, sx_status_str(err));
            goto out;
        }
        if (span_session_info->params.version != SX_SPAN_MIRROR_HEADER_VERSION_INVALID) {
            header_version = span_session_info->params.version;
        } else {
            header_version = g_mirror_header_version;
        }
        err = span_db_cnv_span_to_sxd_header_version(header_version, &ver);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to convert span header version %u to SXD version, err: %s\n",
                       header_version, sx_status_str(err));
            goto out;
        }
        if (span_session_info->span_type_format.remote_eth_l3_type1.qos_mode ==
            SX_SPAN_QOS_CONFIGURED) {
            mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.pcp =
                span_session_info->span_type_format.remote_eth_l3_type1.pcp;
            mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.dei =
                span_session_info->span_type_format.remote_eth_l3_type1.dei;
            if (!span_session_info->is_multiport) {
                mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.tclass =
                    span_session_info->span_type_format.remote_eth_l3_type1.switch_prio;
            }
        }
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.version = ver;
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.vid =
            span_session_info->span_type_format.remote_eth_l3_type1.vid;
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.tp =
            span_session_info->span_type_format.remote_eth_l3_type1.tp;
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.vlan_et_id =
            span_session_info->span_type_format.remote_eth_l3_type1.vlan_ethertype_id;
        memcpy(mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.mac,
               &span_session_info->span_type_format.remote_eth_l3_type1.mac,
               sizeof(span_session_info->span_type_format.remote_eth_l3_type1.mac));
        memcpy(mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.smac,
               &span_session_info->span_type_format.remote_eth_l3_type1.smac,
               sizeof(span_session_info->span_type_format.remote_eth_l3_type1.smac));
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.dscp =
            span_session_info->span_type_format.remote_eth_l3_type1.dscp;
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.ecn =
            span_session_info->span_type_format.remote_eth_l3_type1.ecn;
        mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.ttl =
            span_session_info->span_type_format.remote_eth_l3_type1.ttl;
        if (span_session_info->span_type_format.remote_eth_l3_type1.dest_ip.version !=
            span_session_info->span_type_format.remote_eth_l3_type1.src_ip.version) {
            SX_LOG_ERR("Source (%u) and destination (%u) IP protocols are different\n",
                       span_session_info->span_type_format.remote_eth_l3_type1.src_ip.version,
                       span_session_info->span_type_format.remote_eth_l3_type1.dest_ip.version);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        switch (span_session_info->span_type_format.remote_eth_l3_type1.dest_ip.version) {
        case SX_IP_VERSION_IPV4:
            mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.protocol = 0;
            mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.dip[3] =
                span_session_info->span_type_format.remote_eth_l3_type1.dest_ip.addr.ipv4.s_addr;
            mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.sip[3] =
                span_session_info->span_type_format.remote_eth_l3_type1.src_ip.addr.ipv4.s_addr;
            break;

        case SX_IP_VERSION_IPV6:
            mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.protocol = 1;
            SX_MEM_CPY_ARRAY(mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.dip,
                             span_session_info->span_type_format.remote_eth_l3_type1.dest_ip.addr.ipv6.s6_addr32,
                             4, uint32_t);
            SX_MEM_CPY_ARRAY(mpat_reg_data[dev_idx].encapsulation.mpat_encap_rmtethl3gre.sip,
                             span_session_info->span_type_format.remote_eth_l3_type1.src_ip.addr.ipv6.s6_addr32,
                             4, uint32_t);
            break;

        default:
            SX_LOG_ERR("Wrong IP protocol version : (%d)\n",
                       span_session_info->span_type_format.remote_eth_l3_type1.dest_ip.version);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        err = span_mirror_header_padding_cb_wrapper(header_version,
                                                    &span_session_info->params,
                                                    &mpat_reg_data[dev_idx].pc);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set padding to Mirror Header, error: %s\n", sx_status_str(err));
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Wrong span_session type : (%d)\n",
                   span_session_info->span_type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (span_session_info->system_port == 0) {
        /* Set reserved values */
        mpat_reg_data[dev_idx].span_type = SXD_MPAT_SPAN_TYPE_LOCAL_ETH_E;
        mpat_reg_data[dev_idx].encapsulation.local_span.tclass = 0;
        mpat_reg_data[dev_idx].tr = 0;
        mpat_reg_data[dev_idx].truncation_size = 0;
    }

    mpat_reg_data[dev_idx].session_id = span_session_info->session_id;

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MPAT_E,
                                                     mpat_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed MPAT set: [%s] egress direction .\n",
               SXD_STATUS_MSG(sxd_status));

        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    sxd_status = sxd_dpt_span_session_map_set(SXD_ACCESS_CMD_ADD,
                                              span_session_info->session_id,
                                              span_session_id);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        err = sxd_status_to_sx_status(sxd_status);
        SX_LOG_ERR("sxd_dpt_span_session_map_set ADD failed for ext span_id:%d, hw span_id:%d, err: %s \n",
                   span_session_info->session_id, span_session_id, sx_status_str(err));
        goto out;
    }

out:
    if (span_session_info->policer_enable) {
        err = policer_manager_handle_release(span_session_info->policer_id,
                                             POLICER_MANAGER_TYPE_SPAN_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Error in policer_manager_handle_release : error (%s)\n", sx_status_str(err));
        }
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_fw_span_session_counter_get(const sx_access_cmd_t          cmd,
                                                         const sx_span_session_id_int_t span_session_id,
                                                         sx_span_counter_set_t         *counter_set_p)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t     reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_mpat_reg mpat_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR_P(counter_set_p);

    /* Get list of LEAF devices */
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_DEBUG, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    /* For each LEAF device */
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_GET;

    SX_MEM_CLR(mpat_reg_data[dev_idx]);

    switch (cmd) {
    case SX_ACCESS_CMD_READ:
        mpat_reg_data[dev_idx].c = 0;
        break;

    case SX_ACCESS_CMD_READ_CLEAR:
        mpat_reg_data[dev_idx].c = 1;
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d failed, err: %s.\n", cmd, sx_status_str(err));
        goto out;
    }
    mpat_reg_data[dev_idx].pa_id = span_session_id;

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MPAT_E,
                                                     mpat_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed MPAT get: [%s].\n",
               SXD_STATUS_MSG(sxd_status));

        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    /* For each LEAF device */
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    /* Returned counters is the sum of two in MPAT */
    counter_set_p->mirroring_best_effort_drop_packets = __span_db_build_64bit_counter(
        mpat_reg_data[dev_idx].buffer_drop_high,
        mpat_reg_data[dev_idx].buffer_drop_low) +
                                                        __span_db_build_64bit_counter(
        mpat_reg_data[dev_idx].be_drop_high,
        mpat_reg_data[dev_idx].be_drop_low);

    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_port_find(IN sx_port_log_id_t        port_log_id,
                                     IN span_mirror_direction_t mirror_direction,
                                     OUT cl_map_item_t       ** mirror_port_map_item_p)
{
    uint32_t       i;
    uint64_t       span_mirror_map_key;
    sx_status_t    err = SX_STATUS_ENTRY_NOT_FOUND;
    cl_map_item_t* map_item_p = NULL;

    SX_LOG_ENTER();

    for (i = 0; i <= rm_resource_global.span_session_id_max_internal; i++) {
        if (span_db.sx_span_sessions[i].used == FALSE) {
            continue;
        }

        /* is log port in map ? */
        span_mirror_map_key = BUILD_SPAN_MIRROR_KEY(port_log_id, mirror_direction);
        if (SX_CL_QMAP_KEY_EXISTS(&(span_db.sx_span_sessions[i].mirror_ports_db),
                                  span_mirror_map_key, map_item_p) == TRUE) {
            SX_LOG_DBG("Log port [0x%x] exist in SPAN %d mirror map. \n",
                       port_log_id, i);
            err = SX_STATUS_SUCCESS;
            if (mirror_port_map_item_p != NULL) {
                *mirror_port_map_item_p = map_item_p;
            }
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __span_db_get_lag_ports_list(sx_port_log_id_t log_port, uint32_t *ports_count,
                                         sx_port_log_id_t *ports_list)
{
    sx_lag_id_t    lid;
    sx_status_t    sx_status;
    sx_port_type_t port_type = SX_PORT_TYPE_ID_GET(log_port);

    SX_LOG_ENTER();

    if (SX_PORT_TYPE_NETWORK == port_type) {
        *ports_count = 1;
        ports_list[0] = log_port;
    } else if (SX_PORT_TYPE_LAG == port_type) {
        /* SX_PORT_TYPE_LAG */
        lid = SX_PORT_LAG_ID_GET(log_port);
        sx_status = sx_la_db_log_port_get(lid, 0, ports_list, ports_count);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Cannot retrieve ports from lag[0x%04X], err[%s]\n", lid, sx_status_str(sx_status));
            return sx_status;
        }
    }
    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}

sx_status_t span_db_mirror_phy_port_set(IN sx_port_log_id_t           log_port,
                                        IN span_mirror_direction_t    mirror_direction,
                                        IN sx_span_session_id_int_t   span_session_id,
                                        IN sx_span_probability_rate_t rate,
                                        IN boolean_t                  enable)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* set the fw */
    err = __span_db_fw_mirror_port_set(log_port, span_session_id, mirror_direction, rate, enable);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("add: __span_db_fw_mirror_port_set(log_port 0x%x, span_id: %d , dir:%d ) failed. err: %s\n",
                   log_port, span_session_id, mirror_direction, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t port_db_egress_mirror_buff_set(sx_port_log_id_t port_id, buffer_units_t egress_buff_size)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_port_info_t port_info;

    if (SX_CHECK_FAIL(rc = port_db_info_get(port_id, &port_info))) {
        SX_LOG_ERR("Can't Get Port %u Info (%s).\n", port_id, sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    port_info.port_mirror_egress_buff_size = egress_buff_size;
    port_info.fields = SX_PORT_INFO_FIELD_BIT_EGRESS_MIRROR_SIZE;
    port_db_info_set(port_id, &port_info, NULL);

    return rc;
}

sx_status_t span_db_egress_mirror_ref_count_set(const sx_access_cmd_t                cmd,
                                                sx_port_log_id_t                     port_id,
                                                uint32_t                            *ref_count_p,
                                                const span_egress_mirror_buff_type_e type)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_port_info_t port_info;

    SX_LOG_ENTER();
    UNUSED_PARAM(type);
    if (SX_CHECK_FAIL(rc = utils_check_pointer(ref_count_p, "ref_count_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(rc = port_db_info_get(port_id, &port_info))) {
        SX_LOG_ERR("Can't Get Port %u Info (%s).\n", port_id, sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        port_info.port_mirror_egress_ref_count++;

        break;

    case SX_ACCESS_CMD_DELETE:
        if (port_info.port_mirror_egress_ref_count == 0) {
            rc = SX_STATUS_ERROR;
            SX_LOG_ERR("Cannot decrement ref count of 0, port :0x%x\n", port_id);
            goto out;
        }
        port_info.port_mirror_egress_ref_count--;

        break;

    default:
        rc = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR("Unsupported cmd :%u \n", cmd);
        goto out;
    }
    port_info.fields = SX_PORT_INFO_FIELD_BIT_EGRESS_MIRROR_REF_COUNT;
    port_db_info_set(port_id, &port_info, NULL);
    *ref_count_p = port_info.port_mirror_egress_ref_count;

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t port_db_egress_mirror_buff_get(sx_port_log_id_t port_id, buffer_units_t* egress_buff_size)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_port_info_t port_info;

    if (SX_CHECK_FAIL(rc = port_db_info_get(port_id, &port_info))) {
        SX_LOG_ERR("Can't Get Port %u Info (%s).\n", port_id, sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    *egress_buff_size = port_info.port_mirror_egress_buff_size;

    return rc;
}

sx_status_t span_db_validate_mirror_port(const span_mirror_t *mirror_p, boolean_t *is_mirror_port_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    *is_mirror_port_p = FALSE;

    if (__span_spectrum2_feature_supported(brg_context.spec_cb_g.dev_type) == SX_STATUS_SUCCESS) {
        if ((mirror_p->mirror_direction >= SPAN_MIRROR_DIRECTION_EGRESS) &&
            (mirror_p->mirror_direction <= SPAN_MIRROR_DIRECTION_INGRESS)) {
            *is_mirror_port_p = TRUE;
        }
    } else {
        if ((mirror_p->mirror_direction >= SPAN_MIRROR_DIRECTION_EGRESS) &&
            (mirror_p->mirror_direction <= SPAN_MIRROR_DIRECTION_INGRESS_PG_CONGESTION)) {
            *is_mirror_port_p = TRUE;
        }
    }

    return err;
}

sx_status_t span_db_mirror_port_add(const span_mirror_t           *mirror,
                                    const sx_span_session_id_int_t span_session_id,
                                    const boolean_t                enable)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    span_mirror_map_item_t   * span_mirror_port_item_p = NULL;
    cl_pool_item_t            *pool_item_p = NULL;
    uint64_t                   span_mirror_map_key;
    sx_port_log_id_t           port_log_id = mirror->log_port;
    span_mirror_direction_t    mirror_direction = mirror->mirror_direction;
    uint32_t                   log_port_num = rm_resource_global.lag_port_members_max, i = 0;
    sx_port_log_id_t         * log_port_arr = NULL;
    boolean_t                  is_mirror_port = FALSE;
    sx_span_probability_rate_t rate = SPAN_DEFAULT_PROBABILITY_RATE;

    SX_LOG_ENTER();

    span_db_validate_mirror_port(mirror, &is_mirror_port);
    if (is_mirror_port == FALSE) {
        SX_LOG_DBG("Log port [0x%x] direction [%u] is not valid as mirror port.\n",
                   port_log_id, mirror_direction);
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    log_port_arr = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
    if (!log_port_arr) {
        return SX_STATUS_NO_MEMORY;
    }

    /* is log port in map ? */
    err = span_db_mirror_port_find(port_log_id, mirror_direction, NULL);
    if (SX_CHECK_PASS(err)) {
        SX_LOG_NTC("Log port [0x%x] already exists in SPAN mirror map. \n", port_log_id);
        err = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    /* get new pool item */
    pool_item_p = cl_qpool_get(&(span_db.mirror_ports_pool));
    if (pool_item_p == NULL) {
        SX_LOG_ERR("Couldn't create a new span_mirror_db entry (No Resources)\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    span_mirror_port_item_p = PARENT_STRUCT(pool_item_p, span_mirror_map_item_t, pool_item);
    SX_MEM_CLR(span_mirror_port_item_p->span_mirror_record);
    span_mirror_port_item_p->span_mirror_record.log_port = port_log_id;
    span_mirror_port_item_p->span_mirror_record.mirror_direction = mirror_direction;

    err = __span_db_mirror_port_probabilty_rate_get(span_mirror_port_item_p, &rate);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed retrieve port 0x%08X mirroring probability rate\n", port_log_id);
        goto out;
    }

    /*
     *  in case the LOG_PORT is LAG extract the LAG ports
     *  else return the same port
     */
    err = __span_db_get_lag_ports_list(port_log_id,
                                       &log_port_num, log_port_arr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__span_db_get_lag_ports_list for log_port [0x%x] failed. err: %s\n",
                   port_log_id, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < log_port_num; i++) {
        /* Allocate shared buffer if device type and mirror direction require it */
        err = span_egress_mirror_alloc_buffer_cb_wrapper(SX_ACCESS_CMD_ADD,
                                                         log_port_arr[i],
                                                         mirror_direction,
                                                         SPAN_EGRESS_MIRROR_BUFF_TYPE_SPAN_MIRROR);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("span_egress_mirror_alloc_buffer_cb_wrapper [cmd= ADD, port [0x%x] failed. err: %s]\n",
                       log_port_arr[i], sx_status_str(err));
            goto out;
        }

        /* Set port mirror probability rate.
         * If the log_port is a LAG - apply on all LAG members */
        err = __span_db_fw_mirror_port_set(log_port_arr[i], span_session_id, mirror_direction, rate, enable);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("add: __span_db_fw_mirror_port_set(log_port 0x%x, span_id: %d , dir:%d ) failed. err: %s\n",
                       port_log_id, span_session_id, mirror_direction,
                       sx_status_str(err));
            goto out;
        }
    }

    span_mirror_port_item_p->span_mirror_record.pa_id = span_session_id;
    span_mirror_port_item_p->span_mirror_record.enable = enable;

    span_mirror_map_key = BUILD_SPAN_MIRROR_KEY(port_log_id, mirror_direction);
    cl_qmap_insert(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db),
                   span_mirror_map_key, &(span_mirror_port_item_p->map_item));

out:
    if (err && pool_item_p) {
        /* free the pool item */
        cl_qpool_put(&(span_db.mirror_ports_pool), pool_item_p);
    }
    if (log_port_arr) {
        CL_FREE_N_NULL(log_port_arr);
    }
    SX_LOG_EXIT();
    return err;
}

/* Get the mirroring probability rate per mirror direction */
static sx_status_t __span_db_mirror_port_probabilty_rate_get(const span_mirror_map_item_t* span_mirror_port_item_p,
                                                             sx_span_probability_rate_t   *rate_p)
{
    sx_status_t                    status = SX_STATUS_SUCCESS;
    sx_port_usr_probability_rate_t prob_rate_attr;

    SX_LOG_ENTER();

    switch (span_mirror_port_item_p->span_mirror_record.mirror_direction) {
    /* Mirror triggers that are per port - take the rate from port DB */
    case SPAN_MIRROR_DIRECTION_INGRESS:
    case SPAN_MIRROR_DIRECTION_EGRESS:
        SX_MEM_CLR(prob_rate_attr);
        status = span_cnv_full_to_simple_mirror_direction(span_mirror_port_item_p->span_mirror_record.mirror_direction,
                                                          &prob_rate_attr.key.mirror_direction);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed in SPAN convert full mirror direction [%d] to simple mirror direction, err: %s\n",
                       span_mirror_port_item_p->span_mirror_record.mirror_direction,
                       sx_status_str(status));
            goto out;
        }

        status = span_db_mirror_port_prob_rate_get(span_mirror_port_item_p->span_mirror_record.log_port,
                                                   &prob_rate_attr);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed in retrieving SPAN log port [0x%x] mirroring probability rate, err: %s\n",
                       span_mirror_port_item_p->span_mirror_record.log_port,
                       sx_status_str(status));
            goto out;
        }

        *rate_p = prob_rate_attr.attr.rate;
        break;

    default:
        /* Mirror triggers that are Global - take the rate from SPAN */
        *rate_p = span_mirror_port_item_p->span_mirror_record.rate;
        break;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t __span_db_mirror_port_edit(const span_mirror_t           *mirror,
                                       const sx_span_session_id_int_t old_span_session_id,
                                       const sx_span_session_id_int_t new_span_session_id,
                                       const boolean_t                enable)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    cl_map_item_t             *map_item_p = NULL;
    span_mirror_map_item_t    *span_mirror_port_item_p = NULL;
    sx_port_log_id_t           port_log_id = mirror->log_port;
    span_mirror_direction_t    mirror_direction = mirror->mirror_direction;
    uint32_t                   log_port_num = rm_resource_global.lag_port_members_max, i = 0;
    sx_port_log_id_t          *log_port_arr = NULL;       /* [rm_resource_global.lag_port_members_max]; */
    uint64_t                   span_mirror_map_key;
    sx_span_probability_rate_t rate;
    boolean_t                  is_mirror_port = FALSE;

    SX_LOG_ENTER();

    span_db_validate_mirror_port(mirror, &is_mirror_port);
    if (is_mirror_port == FALSE) {
        SX_LOG_DBG("Log port [0x%x] direction [%u] is not valid as mirror port.\n",
                   port_log_id, mirror_direction);
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    log_port_arr = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
    if (!log_port_arr) {
        return SX_STATUS_NO_MEMORY;
    }
    memset(log_port_arr, 0, sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);

    err = span_db_mirror_port_find(port_log_id, mirror_direction, &map_item_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Log port [0x%x] DOESN'T exist in SPAN mirror map. \n", port_log_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    span_mirror_port_item_p = PARENT_STRUCT(map_item_p, span_mirror_map_item_t, map_item);

    /* Get the mirroring probability rate per mirror direction */
    err = __span_db_mirror_port_probabilty_rate_get(span_mirror_port_item_p, &rate);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed retrieve SPAN log port [0x%x] mirroring probability rate, err: %s\n",
                   span_mirror_port_item_p->span_mirror_record.log_port,
                   sx_status_str(err));
        goto out;
    }
    /*
     *  in case the LOG_PORT is LAG extract the LAG ports
     *  else return the same port
     */
    err = __span_db_get_lag_ports_list(port_log_id,
                                       &log_port_num, log_port_arr);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__span_db_get_lag_ports_list for log_port [0x%x] failed. err: %s\n",
                   port_log_id, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < log_port_num; i++) {
        /* set the fw */
        err = __span_db_fw_mirror_port_set(log_port_arr[i],
                                           new_span_session_id,
                                           mirror_direction,
                                           rate,
                                           enable);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("edit: __span_db_fw_mirror_port_set(log_port 0x%x, span_id: %d , dir:%d ) failed. err: %s\n",
                       port_log_id, new_span_session_id, mirror_direction,
                       sx_status_str(err));
            goto out;
        }
    }

    /* Move mirror port data from old to new session */
    span_mirror_port_item_p->span_mirror_record.pa_id = new_span_session_id;
    span_mirror_port_item_p->span_mirror_record.mirror_direction = mirror_direction;
    span_mirror_port_item_p->span_mirror_record.enable = enable;

    if (old_span_session_id != new_span_session_id) {
        span_mirror_map_key = BUILD_SPAN_MIRROR_KEY(port_log_id, mirror_direction);
        map_item_p = cl_qmap_remove(&(span_db.sx_span_sessions[old_span_session_id].mirror_ports_db),
                                    span_mirror_map_key);
        cl_qmap_insert(&(span_db.sx_span_sessions[new_span_session_id].mirror_ports_db),
                       span_mirror_map_key, &(span_mirror_port_item_p->map_item));
    }
out:
    if (log_port_arr) {
        CL_FREE_N_NULL(log_port_arr);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t __span_db_mirror_port_delete(const span_mirror_t *mirror)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint64_t                 span_mirror_map_key;
    cl_map_item_t          * map_item_p = NULL;
    const cl_map_item_t    * map_end = NULL;
    span_mirror_map_item_t * span_mirror_port_item_p = NULL;
    sx_port_log_id_t         port_log_id = mirror->log_port;
    span_mirror_direction_t  mirror_direction = mirror->mirror_direction;
    uint32_t                 log_port_num = rm_resource_global.lag_port_members_max, i = 0;
    sx_port_log_id_t        *log_port_arr = NULL; /* [rm_resource_global.lag_port_members_max]; */
    sx_span_session_id_int_t span_session_id;
    boolean_t                is_mirror_port = FALSE;

    SX_LOG_ENTER();

    span_db_validate_mirror_port(mirror, &is_mirror_port);
    if (is_mirror_port == FALSE) {
        SX_LOG_DBG("Log port [0x%x] direction [%u] is not valid as mirror port.\n",
                   port_log_id, mirror_direction);
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    log_port_arr = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
    if (!log_port_arr) {
        return SX_STATUS_NO_MEMORY;
    }
    memset(log_port_arr, 0, sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);

    err = span_db_mirror_port_find(port_log_id, mirror_direction, &map_item_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Log port [0x%x] DOESN'T exist in SPAN mirror map. \n", port_log_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    span_mirror_port_item_p = PARENT_STRUCT(map_item_p, span_mirror_map_item_t, map_item);
    span_session_id = span_mirror_port_item_p->span_mirror_record.pa_id;

    span_mirror_map_key = BUILD_SPAN_MIRROR_KEY(port_log_id, mirror_direction);
    map_item_p = cl_qmap_remove(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db),
                                span_mirror_map_key);
    map_end = cl_qmap_end(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db));
    if (map_item_p == map_end) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_ERROR, "Could not delete log_port [0x%x] from SPAN %d\n",
               port_log_id, span_session_id);
        goto  out;
    }

    cl_qpool_put(&(span_db.mirror_ports_pool), &(span_mirror_port_item_p->pool_item));


    /*
     *  in case the LOG_PORT is LAG extract the LAG ports
     *  else return the same port
     */
    err = __span_db_get_lag_ports_list(port_log_id,
                                       &log_port_num, log_port_arr);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__span_db_get_lag_ports_list for log_port [0x%x] failed. err: %s\n",
                   port_log_id, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < log_port_num; i++) {
        /* Free shared buffer if allocated */
        err = span_egress_mirror_alloc_buffer_cb_wrapper(SX_ACCESS_CMD_DELETE,
                                                         log_port_arr[i],
                                                         mirror_direction,
                                                         SPAN_EGRESS_MIRROR_BUFF_TYPE_SPAN_MIRROR);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_egress_mirror_alloc_buffer_cb_wrapper [cmd=DELETE, port [0x%x] failed. err: %s]\n",
                       log_port_arr[i], sx_status_str(err));
            goto out;
        }

        /* set the fw */
        err = __span_db_fw_mirror_port_set(log_port_arr[i], 0, mirror_direction, 0, FALSE);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("delete: __span_db_fw_mirror_port_set(log_port 0x%x, span_id: %d , dir:%d ) failed. err: %s\n",
                       port_log_id, span_session_id, mirror_direction,
                       sx_status_str(err));
            goto out;
        }
    }

out:
    if (log_port_arr) {
        CL_FREE_N_NULL(log_port_arr);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t __span_db_mirror_port_get(const span_mirror_t        *mirror_p,
                                      sx_span_session_id_int_t   *span_session_id,
                                      sx_span_probability_rate_t *rate_p,
                                      boolean_t                  *admin_state_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    cl_map_item_t          *map_item_p = NULL;
    span_mirror_map_item_t* span_mirror_port_item_p = NULL;
    boolean_t               is_mirror_port = FALSE;

    SX_LOG_ENTER();

    span_db_validate_mirror_port(mirror_p, &is_mirror_port);
    if (is_mirror_port == FALSE) {
        SX_LOG_DBG("Log port [0x%x] direction [%u] is not valid as mirror port.\n",
                   mirror_p->log_port, mirror_p->mirror_direction);
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    err = span_db_mirror_port_find(mirror_p->log_port, mirror_p->mirror_direction, &map_item_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Log port [0x%x] DOESN'T exist in SPAN mirror map. \n", mirror_p->log_port);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Debug validation */
    span_mirror_port_item_p = PARENT_STRUCT(map_item_p, span_mirror_map_item_t, map_item);
    if (span_session_id != NULL) {
        *span_session_id = span_mirror_port_item_p->span_mirror_record.pa_id;
    }
    if (rate_p != NULL) {
        /* Get the mirroring probability rate per mirror direction */
        err = __span_db_mirror_port_probabilty_rate_get(span_mirror_port_item_p, rate_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed retrieve SPAN log port [0x%x] mirroring probability rate, err: %s\n",
                       span_mirror_port_item_p->span_mirror_record.log_port,
                       sx_status_str(err));
            goto out;
        }
    }
    if (admin_state_p != NULL) {
        *admin_state_p = span_mirror_port_item_p->span_mirror_record.enable;
    }


#ifdef SPAN_DEBUG
    {
        uint32_t         log_port_num = rm_resource_global.lag_port_members_max, i;
        sx_port_log_id_t log_port_arr[rm_resource_global.lag_port_members_max];

        /*
         *  in case the LOG_PORT is LAG extract the LAG ports
         *  else return the same port
         */
        err = __span_db_get_lag_ports_list(mirror_p->log_port,
                                           &log_port_num, log_port_arr);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__span_db_get_lag_ports_list for log_port [0x%x] failed. err: %s\n",
                       mirror_p->log_port sx_status_str(err));
            goto out;
        }

        for (i = 0; i < log_port_num; i++) {
            /* get the fw */
            err = __span_db_fw_mirror_port_get(log_port_arr[i],
                                               mirror_p->mirror_direction,
                                               span_session_id,
                                               admin_state_p);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("get: __span_db_fw_mirror_port_get(log_port 0x%x, dir:%d ) failed. err: %s\n",
                           mirror_p->log_port, mirror_p->mirror_direction,
                           sx_status_str(err));
                goto out;
            }

            if (span_session_id != NULL) {
                if (span_mirror_port_item_p->span_mirror_record.pa_id != *span_session_id) {
                    SX_LOG_ERR(
                        "get: m_port 0x%x validation error span_mirror_record.pa_id [%d] != *span_session_id [%d]\n",
                        log_port_arr[i],
                        span_mirror_port_item_p->span_mirror_record.pa_id,
                        *span_session_id);
                }
            }

            if (admin_state_p != NULL) {
                if (span_mirror_port_item_p->span_mirror_record.enable != *admin_state_p) {
                    SX_LOG_ERR("get: m_port 0x%x validation error span_mirror_record.enable [%d] != *enable [%d] \n",
                               log_port_arr[i], span_mirror_port_item_p->span_mirror_record.enable, *admin_state_p);
                }
            }
        }
    }
#endif

out:
    SX_LOG_EXIT();
    return err;
}


/**
 *  This function bind/unbind SPAN from/to a log port
 *
 * @param[in]  cmd                  ADD (bind) / DELETE (unbind) / EDIT (move)
 * @param[in]  mirror_p             port ID and direction
 * @param[in]  old_span_session_id  SPAN session
 * @param[in]  new_span_session_id  same as old_span_session_id except for EDIT
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_ENTRY_NOT_FOUND - pid does not exist in the DB
 *         SX_STATUS_PARAM_ERROR - pid is not in range
 *         SX_STATUS_ERROR - general error
 *         SX_STATUS_PARAM_ERROR
 */
sx_status_t span_db_mirror_set(const sx_access_cmd_t          cmd,
                               const span_mirror_t           *mirror_p,
                               const sx_span_session_id_int_t old_span_session_id,
                               const sx_span_session_id_int_t new_span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   admin_state = FALSE;
    boolean_t   is_mirror_port = FALSE;

    SX_LOG_ENTER();

    span_db_validate_mirror_port(mirror_p, &is_mirror_port);
    if (is_mirror_port == FALSE) {
        SX_LOG_DBG("Log port [0x%x] direction [%u] is not valid as mirror port.\n",
                   mirror_p->log_port, mirror_p->mirror_direction);
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    /* check parameter range */
    err = span_db_session_find(old_span_session_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("SPAN session id [%d] not found. Set mirror port [0x%x] failed, rc: %s.\n",
                   old_span_session_id, mirror_p->log_port, sx_status_str(err));
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    err = span_db_session_find(new_span_session_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("SPAN session id [%d] not found. Set mirror port [0x%x] failed, rc: %s.\n",
                   new_span_session_id, mirror_p->log_port, sx_status_str(err));
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        err = span_db_mirror_port_add(mirror_p, new_span_session_id, TRUE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__span_db_mirror_port_add(port [0x%x], span %d, ...)  failed. err: %s\n",
                       mirror_p->log_port, new_span_session_id, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        err = span_db_mirror_get(mirror_p, NULL, NULL, &admin_state);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("span_db_mirror_get(port [0x%x], span %d, ...)  failed. err: %s\n",
                       mirror_p->log_port, old_span_session_id, sx_status_str(err));
            goto out;
        }
        err = __span_db_mirror_port_edit(mirror_p,
                                         old_span_session_id,
                                         new_span_session_id,
                                         admin_state);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__span_db_mirror_port edit(port [0x%x], span %d->%d, ...)  failed. err: %s\n",
                       mirror_p->log_port,
                       old_span_session_id,
                       new_span_session_id,
                       sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_ENABLE:
        err = __span_db_mirror_port_edit(mirror_p,
                                         old_span_session_id,
                                         new_span_session_id,
                                         TRUE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__span_db_mirror_port edit(port [0x%x], span %d, ...)  failed. err: %s\n",
                       mirror_p->log_port, new_span_session_id, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DISABLE:
        err = __span_db_mirror_port_edit(mirror_p,
                                         old_span_session_id,
                                         new_span_session_id,
                                         FALSE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__span_db_mirror_port_edit(port [0x%x], span %d, ...)  failed. err: %s\n",
                       mirror_p->log_port, new_span_session_id, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        err = __span_db_mirror_port_delete(mirror_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__span_db_mirror_port_delete(port [0x%x], span %d, ...)  failed. err: %s\n",
                       mirror_p->log_port, new_span_session_id, sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Invalid access command [%s]\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_get(const span_mirror_t        *mirror_p,
                               sx_span_session_id_int_t   *span_session_id,
                               sx_span_probability_rate_t *rate_p,
                               boolean_t                  *admin_state_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* check parameter range */

    err = __span_db_mirror_port_get(mirror_p, span_session_id, rate_p, admin_state_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_DBG("__span_db_mirror_port_get(port [0x%x],  ...)  failed. err: %d\n",
                   mirror_p->log_port, err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_flooding_set(const sx_span_session_id_int_t span_session_id)
{
    sx_swid_id_t      swid;
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_access_cmd_t   access_cmd;
    sx_port_log_id_t  analyzer_port = 0, log_port = 0;
    sx_port_type_t    analyzer_port_type = 0;
    length_t          analyzer_port_active_span_member_cnt = 0;
    length_t          i = 0;
    sx_port_log_id_t *analyzer_multiport_p = NULL;
    length_t          multiport_num = 0;

    SX_LOG_ENTER();

    if (span_db.sx_span_sessions[span_session_id].span_session_info.is_multiport) {
        if (span_db.sx_span_sessions[span_session_id].span_session_info.multiport[0] == SPAN_INVALID_SYSTEM_PORT) {
            return M_UTILS_SX_LOG_EXIT(err);
        }
    } else {
        if (span_db.sx_span_sessions[span_session_id].span_session_info.system_port == SPAN_INVALID_SYSTEM_PORT) {
            return M_UTILS_SX_LOG_EXIT(err);
        }
    }

    analyzer_port = span_db.sx_span_sessions[span_session_id].analyzer_port;
    analyzer_port_type = SX_PORT_TYPE_ID_GET(analyzer_port);
    if (analyzer_port_type == SX_PORT_TYPE_CPU) {
        return M_UTILS_SX_LOG_EXIT(err);
    }

    if ((span_db.sx_span_sessions[span_session_id].span_session_info.admin_state == TRUE) &&
        (span_db.sx_span_sessions[span_session_id].span_session_info.span_type == SX_SPAN_TYPE_LOCAL_ETH_TYPE1)) {
        access_cmd = SX_ACCESS_CMD_DISABLE;
    } else {
        access_cmd = SX_ACCESS_CMD_ENABLE;
    }

    /* remove the port from flooding */
    if (SX_CHECK_FAIL(err = port_db_swid_alloc_get(analyzer_port, &swid))) {
        SX_LOG_ERR("port_db_swid_alloc_get for log_port [0x%x] failed (%s)\n",
                   analyzer_port, sx_status_str(err));
        return M_UTILS_SX_LOG_EXIT(err);
    }
    if ((access_cmd == SX_ACCESS_CMD_ENABLE) &&
        (span_db.sx_span_sessions[span_session_id].span_session_info.span_type == SX_SPAN_TYPE_LOCAL_ETH_TYPE1)) {
        /* make sure that this analyzer port is not part of another LOCAL span session
         * before re-enabling flooding. Even if it is, we should only re-enable flooding
         * if all other sessions are admin-down
         */
        for (i = 0; i <= rm_resource_global.span_session_id_max_internal; i++) {
            if ((span_session_id == i) ||
                (span_db.sx_span_sessions[i].used == FALSE)) {
                /* skip current and unused sessions */
                continue;
            }
            if (span_db.sx_span_sessions[i].analyzer_port == analyzer_port) {
                if (span_db.sx_span_sessions[i].span_session_info.admin_state == TRUE) {
                    analyzer_port_active_span_member_cnt++;
                }
            }
        }
        if (analyzer_port_active_span_member_cnt) {
            SX_LOG(SX_LOG_INFO,
                   "Cannot enable flooding. Analyzer port [0x%x] belongs to %d other active span sessions.\n",
                   analyzer_port,
                   analyzer_port_active_span_member_cnt);
            goto out;
        }
    }
    if (analyzer_port_type == SX_PORT_TYPE_LAG) {
        analyzer_multiport_p = (sx_port_log_id_t *)cl_malloc(
            sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
        if (analyzer_multiport_p == NULL) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for port list, err: %s\n", sx_status_str(err));
            goto out;
        }
        SX_MEM_CLR_ARRAY(analyzer_multiport_p, rm_resource_global.lag_port_members_max, sx_port_id_t);
        multiport_num = rm_resource_global.lag_port_members_max;
        err = sx_lag_port_group_get(analyzer_port, analyzer_multiport_p, &multiport_num);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get LAG members of port 0x%x, err: %s\n", analyzer_port, sx_status_str(err));
            goto out;
        }
    } else {
        multiport_num = 1;
    }
    /*
     *   Config a BC to all added ports.
     *   So flooded traffic will be sent to all ports and than filtered by VLAN
     *   Should be in port_internal_init for splitter cables support
     */
    for (i = 0; i < multiport_num; ++i) {
        if (analyzer_port_type == SX_PORT_TYPE_LAG) {
            log_port = analyzer_multiport_p[i];
        } else {
            log_port = analyzer_port;
        }
        err = fdb_flood_port_set(access_cmd,
                                 swid,
                                 log_port);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_WRN("fdb_flood_port_set failed, swid: %d, port = 0x%x, sx_err = %s \n",
                       swid,  log_port, sx_status_str(err));
            return M_UTILS_SX_LOG_EXIT(err);
        }
    }

out:
    if (analyzer_multiport_p != NULL) {
        cl_free(analyzer_multiport_p);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_analyzer_port_set(sx_port_log_id_t                       port_log_id,
                                               const span_analyzer_port_set_params_t *port_params_p,
                                               span_session_info_t                   *span_session_info_p,
                                               sx_span_session_id_int_t               span_session_id)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_port_ucroute_id_t ucroute_id = SPAN_INVALID_SYSTEM_PORT;
    length_t             i = 0;

    SX_LOG_ENTER();

    err = port_ucroute_id_map_get(SX_ACCESS_CMD_GET, port_log_id, &ucroute_id);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get system port for the port (0x%08X). err %s \n",
                   port_log_id, sx_status_str(err));
        goto out;
    }

    span_session_info_p->system_port = ucroute_id;
    span_session_info_p->port_params = *port_params_p->sx_port_params;
    span_session_info_p->is_multiport = FALSE;
    span_session_info_p->multiport_nmp = SPAN_MULTIPORT_NUMBER_RESERVED_E;
    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        span_session_info_p->multiport[i] = SPAN_INVALID_SYSTEM_PORT;
    }

    err = span_db_session_set(span_session_id, span_session_info_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session %d set failed. err %s \n",
                   span_session_id, sx_status_str(err));
        goto out;
    }

    span_db.sx_span_sessions[span_session_id].analyzer_port = port_log_id;
    span_db.sx_span_sessions[span_session_id].multiport_num = 0;
    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        span_db.sx_span_sessions[span_session_id].analyzer_multiport[i] = SX_SPAN_INVALID_LOG_PORT;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_analyzer_multiport_select(sx_port_log_id_t  port_log_id,
                                                       sx_port_log_id_t *analyzer_multiport_p,
                                                       uint8_t          *multiport_num_p,
                                                       sx_port_log_id_t  port_to_exclude)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    length_t             i = 0;
    sx_port_log_id_t     selected_ports_p[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX];
    uint8_t              selected_cnt = 0;
    length_t             port_count = 0;
    sx_port_log_id_t    *port_list_p = NULL;
    sx_port_oper_state_t oper_state = SX_PORT_OPER_STATUS_NONE;

    SX_LOG_ENTER();

    if (SX_PORT_TYPE_ID_GET(port_log_id) != SX_PORT_TYPE_LAG) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to select multiple ports as SPAN analyzer for not a LAG (0x%08X). err %s \n",
                   port_log_id, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        selected_ports_p[i] = SX_SPAN_INVALID_LOG_PORT;
    }

    port_list_p = (sx_port_log_id_t *)cl_malloc(sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
    if (port_list_p == NULL) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for port list, err: %s\n", sx_status_str(err));
        goto out;
    }
    SX_MEM_CLR_ARRAY(port_list_p, rm_resource_global.lag_port_members_max, sx_port_id_t);

    port_count = rm_resource_global.lag_port_members_max;
    err = lag_log_port_distributor_enable_get(port_log_id, port_list_p, &port_count);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get SPAN analyzer LAG port (0x%08X) members. err %s \n",
                   port_log_id, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < port_count && selected_cnt < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        err = port_state_get(SX_ACCESS_CMD_GET, port_list_p[i], &oper_state, NULL, NULL);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve port state of (0x%x) from DB (%s)\n",
                       port_list_p[i], sx_status_str(err));
            goto out;
        }
        if ((oper_state == SX_PORT_OPER_STATUS_UP) && (port_list_p[i] != port_to_exclude)) {
            selected_ports_p[selected_cnt] = port_list_p[i];
            selected_cnt += 1;
        }
    }
    if (selected_cnt == SPAN_DB_ANALYZER_MULTI_PORT_NUM_UNSUPORTED) {
        selected_cnt -= 1;
        selected_ports_p[selected_cnt] = SX_SPAN_INVALID_LOG_PORT;
    }

    SX_MEM_CPY_ARRAY(analyzer_multiport_p, selected_ports_p, SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX, sx_port_log_id_t);
    *multiport_num_p = selected_cnt;

out:
    if (port_list_p != NULL) {
        cl_free(port_list_p);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_analyzer_multiport_num_to_nmp(uint8_t num, span_multiport_number_e *nmp)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (num) {
    case 0:
        *nmp = SPAN_MULTIPORT_NUMBER_RESERVED_E;
        break;

    case 1:
        *nmp = SPAN_MULTIPORT_NUMBER_ONE_E;
        break;

    case 2:
        *nmp = SPAN_MULTIPORT_NUMBER_TWO_E;
        break;

    case 4:
        *nmp = SPAN_MULTIPORT_NUMBER_FOUR_E;
        break;

    default:
        SX_LOG_ERR("Not supported multiport number (%d).\n", num);
        err = SX_STATUS_ERROR;
        break;
    }

    SX_LOG_EXIT();
    return err;
}


static sx_status_t __span_db_multiport_switch_prio_set(span_session_info_t *span_session_info)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (span_session_info->span_type) {
    case SX_SPAN_TYPE_LOCAL_IB:
        /* RESERVED */
        span_session_info->switch_prio = 0;
        break;

    case SX_SPAN_TYPE_LOCAL_ETH_TYPE1:
        if (span_session_info->span_type_format.local_eth_type1.qos_mode ==
            SX_SPAN_QOS_CONFIGURED) {
            if (span_session_info->is_multiport) {
                span_session_info->switch_prio = span_session_info->span_type_format.local_eth_type1.switch_prio;
            }
        }
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1:
        if (span_session_info->span_type_format.remote_eth_vlan_type1.qos_mode ==
            SX_SPAN_QOS_CONFIGURED) {
            span_session_info->switch_prio = span_session_info->span_type_format.remote_eth_vlan_type1.switch_prio;
        }
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1:
        if (span_session_info->span_type_format.remote_eth_l2_type1.qos_mode ==
            SX_SPAN_QOS_CONFIGURED) {
            span_session_info->switch_prio = span_session_info->span_type_format.remote_eth_l2_type1.switch_prio;
        }
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1:
        if (span_session_info->span_type_format.remote_eth_l3_type1.qos_mode ==
            SX_SPAN_QOS_CONFIGURED) {
            span_session_info->switch_prio = span_session_info->span_type_format.remote_eth_l3_type1.switch_prio;
        }
        break;

    default:
        SX_LOG_ERR("Wrong span_session type : (%d)\n",
                   span_session_info->span_type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __span_db_analyzer_lag_port_set(sx_port_log_id_t                       port_log_id,
                                                   const span_analyzer_port_set_params_t *port_params_p,
                                                   span_session_info_t                   *span_session_info_p,
                                                   sx_span_session_id_int_t               span_session_id)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_port_ucroute_id_t ucroute_id[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX];
    sx_port_log_id_t     analyzer_multiport[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX];
    uint8_t              multiport_num = 0;
    length_t             i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        ucroute_id[i] = SPAN_INVALID_SYSTEM_PORT;
        analyzer_multiport[i] = SX_SPAN_INVALID_LOG_PORT;
    }

    if (port_params_p->multiport_apply) {
        SX_MEM_CPY_ARRAY(analyzer_multiport,
                         port_params_p->analyzer_multiport,
                         SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX,
                         sx_port_log_id_t);
        multiport_num = port_params_p->multiport_num;
    } else {
        err = __span_db_analyzer_multiport_select(port_log_id,
                                                  analyzer_multiport,
                                                  &multiport_num,
                                                  SX_SPAN_INVALID_LOG_PORT);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get select analyzer multiport port (0x%08X). err %s \n",
                       port_log_id, sx_status_str(err));
            goto out;
        }
    }

    for (i = 0; i < multiport_num; ++i) {
        err = port_ucroute_id_map_get(SX_ACCESS_CMD_GET, analyzer_multiport[i], &ucroute_id[i]);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get system port for the port (0x%08X). err %s \n",
                       analyzer_multiport[i], sx_status_str(err));
            goto out;
        }
    }

    span_session_info_p->system_port = SPAN_INVALID_SYSTEM_PORT;
    span_session_info_p->port_params = *port_params_p->sx_port_params;
    span_session_info_p->is_multiport = TRUE;
    err = __span_db_analyzer_multiport_num_to_nmp(multiport_num, &span_session_info_p->multiport_nmp);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to map multiport number(%d) to MPAT field acceptable value, err %s \n",
                   multiport_num, sx_status_str(err));
        goto out;
    }
    err = __span_db_multiport_switch_prio_set(span_session_info_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set multiport switch priority, err %s \n", sx_status_str(err));
        goto out;
    }
    err = cos_port_tc_prio_map_get(port_log_id, span_session_info_p->switch_prio, &span_session_info_p->tclass);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set multiport TClass value, err %s \n", sx_status_str(err));
        goto out;
    }
    SX_MEM_CPY_ARRAY(span_session_info_p->multiport,
                     ucroute_id,
                     SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX,
                     sx_port_ucroute_id_t);

    err = span_db_session_set(span_session_id, span_session_info_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session %d set failed. err %s \n",
                   span_session_id, sx_status_str(err));
        goto out;
    }

    span_db.sx_span_sessions[span_session_id].analyzer_port = port_log_id;
    span_db.sx_span_sessions[span_session_id].multiport_num = multiport_num;
    SX_MEM_CPY_ARRAY(span_db.sx_span_sessions[span_session_id].analyzer_multiport,
                     analyzer_multiport,
                     SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX,
                     sx_port_log_id_t);

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __span_db_analyzer_port_add(sx_port_log_id_t                       port_log_id,
                                               const span_analyzer_port_set_params_t *port_params_p,
                                               sx_span_session_id_int_t               span_session_id)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    span_session_info_t span_session_info;
    uint8_t             port_is_lag_member;

    SX_LOG_ENTER();

    if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    span_session_info = span_db.sx_span_sessions[span_session_id].span_session_info;


    if (span_session_info.span_type == SX_SPAN_TYPE_LOCAL_ETH_TYPE1) {
        /* Reject if analyzer port is part of a LAG */
        if (SX_CHECK_FAIL(err = port_lag_member_state_get(SX_ACCESS_CMD_GET,
                                                          port_log_id,
                                                          &port_is_lag_member))) {
            SX_LOG_ERR("Failed to retrieve if port (0x%08X) is lag member (%s)\n",
                       port_log_id, sx_status_str(err));
            goto out;
        }
        if (port_is_lag_member) {
            err = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("Failure - port (0x%08X) is LAG member (%s)\n",
                       port_log_id, sx_status_str(err));
            goto out;
        }
    }

    if (SX_PORT_TYPE_ID_GET(port_log_id) == SX_PORT_TYPE_LAG) {
        err = __span_db_analyzer_lag_port_set(port_log_id, port_params_p, &span_session_info, span_session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set LAG (0x%08X) as SPAN analyzer (%s)\n",
                       port_log_id, sx_status_str(err));
            goto out;
        }
    } else { /* port_log_id is not LAG */
        err = __span_db_analyzer_port_set(port_log_id, port_params_p, &span_session_info, span_session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set port (0x%08X) as SPAN analyzer (%s)\n",
                       port_log_id, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_analyzer_port_delete(IN sx_port_log_id_t         port_log_id,
                                                  IN sx_span_session_id_int_t span_session_id)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    span_session_info_t span_session_info;
    sx_port_log_id_t    analyzer_port = SX_SPAN_INVALID_LOG_PORT;
    length_t            i = 0;

    SX_LOG_ENTER();

    /* check that SPAN is disabled */
    SX_MEM_CLR(span_session_info);
    err = span_db_session_get(span_session_id, &span_session_info,
                              &analyzer_port, NULL, NULL, NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, rc: %s.\n",
                   span_session_id, sx_status_str(err));
        goto out;
    }

    if (span_session_info.admin_state == TRUE) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("Can't remove analyzer port 0x%x. SPAN session id %d still enabled.\n",
                   port_log_id, span_session_id);
        goto out;
    }

    if (analyzer_port != port_log_id) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Can't remove analyzer port 0x%x. SPAN AN port = 0x%x .\n",
                   port_log_id, analyzer_port);
        goto out;
    }

    span_session_info.system_port = SPAN_INVALID_SYSTEM_PORT;
    span_session_info.admin_state = FALSE;
    span_session_info.is_multiport = FALSE;
    span_session_info.multiport_nmp = SPAN_MULTIPORT_NUMBER_RESERVED_E;
    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        span_session_info.multiport[i] = SPAN_INVALID_SYSTEM_PORT;
    }

    err = span_db_session_set(span_session_id,
                              &span_session_info);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__span_db_analyzer_port_delete(port [0x%x], span %d, ...) failed. err: %s\n",
                   port_log_id, span_session_id, sx_status_str(err));
        goto out;
    }

    span_db.sx_span_sessions[span_session_id].analyzer_port = SX_SPAN_INVALID_LOG_PORT;
    span_db.sx_span_sessions[span_session_id].multiport_num = 0;
    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        span_db.sx_span_sessions[span_session_id].analyzer_multiport[i] = SX_SPAN_INVALID_LOG_PORT;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_port_analyzer_set(sx_access_cmd_t                        cmd,
                                      sx_port_log_id_t                       port_log_id,
                                      const span_analyzer_port_set_params_t *port_params_p,
                                      sx_span_session_id_int_t               span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* check parameter range */
    err = span_db_session_find(span_session_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("SPAN session id [%d] not found. Set mirror port [0x%x] failed. err: %s.\n",
                   span_session_id, port_log_id, sx_status_str(err));
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        err = __span_db_analyzer_port_add(port_log_id, port_params_p, span_session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__span_db_mirror_port_add(port [0x%x], span %d, ...) failed. err: %s\n",
                       port_log_id, span_session_id, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        err = __span_db_analyzer_port_delete(port_log_id, span_session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__span_db_mirror_port_delete(port [0x%x], span %d, ...) failed. err: %s\n",
                       port_log_id, span_session_id, sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Invalid access command [%s]\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_port_analyzer_is_local_get(sx_port_log_id_t port_log_id, boolean_t        *is_local_span_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    span_session_info_t      span_session_info;
    sx_span_session_id_int_t curr_span_session_id = 0;
    sx_port_log_id_t         curr_an_port_log_id = 0;
    boolean_t                is_local_span = FALSE;

    SX_LOG_ENTER();

    if (is_local_span_p == NULL) {
        SX_LOG_ERR("is_local_span_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    for (curr_span_session_id = 0;
         curr_span_session_id <= rm_resource_global.span_session_id_max_internal;
         curr_span_session_id++) {
        SX_MEM_CLR(span_session_info);
        err = span_db_session_get(curr_span_session_id, &span_session_info, &curr_an_port_log_id,
                                  NULL, NULL, NULL, NULL);
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            err = SX_STATUS_SUCCESS;
            continue;
        } else if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("SPAN session id [%d] get failed. Get analyzer port [0x%x] failed, rc: %s.\n",
                       curr_span_session_id, port_log_id, sx_status_str(err));
            goto out;
        }

        if (curr_an_port_log_id == port_log_id) {
            if (span_session_info.span_type == SX_SPAN_TYPE_LOCAL_ETH_TYPE1) {
                is_local_span = TRUE;
                break;
            }
        }
    }

    *is_local_span_p = is_local_span;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_port_analyzer_get(sx_port_log_id_t                port_log_id,
                                      sx_span_analyzer_port_params_t *port_params_p,
                                      sx_span_session_id_int_t       *span_session_id_list_p,
                                      uint32_t                       *span_sessions_cnt_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    span_session_info_t      span_session_info;
    sx_span_session_id_int_t curr_span_session_id = 0;
    sx_port_log_id_t         curr_an_port_log_id;
    uint32_t                 found_spans = 0;

    SX_LOG_ENTER();

    if (span_sessions_cnt_p == NULL) {
        SX_LOG_ERR("Error: span_sessions_num == NULL !\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    for (curr_span_session_id = 0;
         curr_span_session_id <= rm_resource_global.span_session_id_max_internal;
         curr_span_session_id++) {
        SX_MEM_CLR(span_session_info);
        err = span_db_session_get(curr_span_session_id, &span_session_info, &curr_an_port_log_id,
                                  NULL, NULL, NULL, NULL);
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            continue;
        } else if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("SPAN session id [%d] get failed. Get analyzer port [0x%x] failed, rc: %s.\n",
                       curr_span_session_id, port_log_id, sx_status_str(err));
            err = SX_STATUS_ERROR;
            goto out;
        }

        if (curr_an_port_log_id == port_log_id) {
            /* fill the sessions */
            if ((found_spans < *span_sessions_cnt_p) && (span_session_id_list_p != NULL)) {
                span_session_id_list_p[found_spans] = curr_span_session_id;
            }
            found_spans++;

            /* fill port params */
            if (port_params_p != NULL) {
                *port_params_p = span_session_info.port_params;
            }
        }
    }

    *span_sessions_cnt_p = found_spans;

    if (found_spans) {
        err = SX_STATUS_SUCCESS;
    } else {
        err = SX_STATUS_ENTRY_NOT_FOUND;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_counter_get(const sx_access_cmd_t          cmd,
                                        const sx_span_session_id_int_t span_session_id,
                                        sx_span_counter_set_t         *counter_set_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Get counters from FW */
    err = __span_db_fw_span_session_counter_get(cmd, span_session_id, counter_set_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__span_db_fw_span_counter_get(cmd %d session %d)  failed. err: %s\n",
                   cmd, span_session_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_tables_set(const sx_access_cmd_t cmd, const sx_span_session_id_int_t span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Add or delete mapping of session to table mirror */
    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        g_mirror_tables_session = span_session_id;
        break;

    case SX_ACCESS_CMD_DELETE:
        if (span_session_id != g_mirror_tables_session) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
        g_mirror_tables_session = SPAN_NO_SESSION;
        break;

    default:
        SX_LOG_ERR("Invalid access command [%s]\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    /* Associate mirror trap group with session */
    err = host_ifc_span_mirror_tables_set(cmd, span_session_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_span_mirror_tables_set(cmd %d session %d)  failed. err: %s\n",
                   cmd, span_session_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_tables_get(sx_span_session_id_int_t *span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SPAN_NO_SESSION == g_mirror_tables_session) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    *span_session_id = g_mirror_tables_session;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirroring_move(const sx_span_session_id_int_t old_span_session_id,
                                   const sx_span_session_id_int_t new_span_session_id)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    span_session_info_t *old_span_session_info_p = NULL;

    SX_LOG_ENTER();
    old_span_session_info_p = &span_db.sx_span_sessions[old_span_session_id].span_session_info;

    if (old_span_session_id == g_mirror_tables_session) {
        err = span_db_mirror_tables_set(SX_ACCESS_CMD_ADD, new_span_session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Error moving mirror table for SPAN session %u. err: %s\n",
                       old_span_session_id, sx_status_str(err));
            goto out;
        }
    }

    if (old_span_session_info_p->drop_mirror.trap_group_valid) {
        /* Add new session id to trap group */
        err = host_ifc_trap_group_span_set(SX_ACCESS_CMD_ADD,
                                           old_span_session_info_p->drop_mirror.trap_group,
                                           new_span_session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Error moving drop mirroring for Trap Group %u. err: %s\n",
                       old_span_session_info_p->drop_mirror.trap_group, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_mirror_drop_reason_set(const sx_access_cmd_t       cmd,
                                                    const sx_trap_group_t       trap_group,
                                                    const sx_span_drop_reason_t drop_reason)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    uint32_t     trap_count = 0;
    uint32_t     trap_idx = 0;
    sx_trap_id_t trap_id = 0;

    if (cmd == SX_ACCESS_CMD_ADD) {
        if (sx_span_drop_reason_to_trap_map[drop_reason].in_use) {
            err = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("Error adding Drop Reason %u: Already in use\n", drop_reason);
            goto out;
        }
    } else if (cmd == SX_ACCESS_CMD_DELETE) {
        if (!sx_span_drop_reason_to_trap_map[drop_reason].in_use) {
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Invalid cmd %u\n", cmd);
        goto out;
    }

    trap_count = sx_span_drop_reason_to_trap_map[drop_reason].trap_id_count;
    for (trap_idx = 0; trap_idx < trap_count; trap_idx++) {
        trap_id = sx_span_drop_reason_to_trap_map[drop_reason].trap_id_list[trap_idx];
        err = host_ifc_set_trap_id_for_span(cmd, trap_id, trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Error for cmd %s of Trap ID %u to Trap Group %u. err: %s\n",
                       sx_access_cmd_str(cmd), trap_id, trap_group, sx_status_str(err));
            goto out;
        }
    }

    sx_span_drop_reason_to_trap_map[drop_reason].in_use = (cmd == SX_ACCESS_CMD_ADD) ? TRUE : FALSE;

out:
    return err;
}

static sx_status_t __span_db_mirror_drops_set_trap_group(sx_span_session_id_int_t span_session_id)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    span_session_info_t *span_session_info_p = NULL;
    uint32_t             trap_group_count = 0;
    uint32_t             trap_group_idx = 0;

    SX_LOG_ENTER();
    span_session_info_p = &span_db.sx_span_sessions[span_session_id].span_session_info;
    trap_group_count = rm_resource_global.span_session_id_max_internal + 1;

    /* Initialize trap group if needed */
    if (g_mirror_drops_hw_trap_groups_count == 0) {
        err = host_ifc_trap_group_for_span_get(g_mirror_drops_hw_trap_groups, &trap_group_count);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Trap groups init failed. err: %s\n", sx_status_str(err));
            goto out;
        }
        g_mirror_drops_hw_trap_groups_count = trap_group_count;
    }

    if (!span_session_info_p->drop_mirror.trap_group_valid) {
        for (trap_group_idx = 0; trap_group_idx < g_mirror_drops_hw_trap_groups_count; trap_group_idx++) {
            if (g_mirror_drops_hw_trap_groups[trap_group_idx] != SX_TRAP_GROUP_INVALID) {
                span_session_info_p->drop_mirror.trap_group = g_mirror_drops_hw_trap_groups[trap_group_idx];
                span_session_info_p->drop_mirror.trap_group_valid = TRUE;
                g_mirror_drops_hw_trap_groups[trap_group_idx] = SX_TRAP_GROUP_INVALID;

                /* Add new session id to trap group */
                err = host_ifc_trap_group_span_set(SX_ACCESS_CMD_ADD,
                                                   span_session_info_p->drop_mirror.trap_group,
                                                   span_session_id);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed adding session %d to Trap Group %u. err: %s\n",
                               span_session_id, span_session_info_p->drop_mirror.trap_group,
                               sx_status_str(err));
                    goto out;
                }
                break;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_mirror_drops_unset_trap_group(sx_span_session_id_int_t span_session_id)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    uint32_t             trap_group_idx = 0;
    span_session_info_t *span_session_info_p = NULL;

    span_session_info_p = &span_db.sx_span_sessions[span_session_id].span_session_info;
    if (span_session_info_p->drop_mirror.trap_group_valid &&
        (span_session_info_p->drop_mirror.drop_reasons_count == 0)) {
        for (trap_group_idx = 0; trap_group_idx < g_mirror_drops_hw_trap_groups_count; trap_group_idx++) {
            if (g_mirror_drops_hw_trap_groups[trap_group_idx] == SX_TRAP_GROUP_INVALID) {
                g_mirror_drops_hw_trap_groups[trap_group_idx] = span_session_info_p->drop_mirror.trap_group;
                span_session_info_p->drop_mirror.trap_group_valid = FALSE;

                /* Delete session id from trap group */
                err = host_ifc_trap_group_span_set(SX_ACCESS_CMD_DELETE,
                                                   span_session_info_p->drop_mirror.trap_group,
                                                   span_session_id);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed deleting session %d from Trap Group %u. err: %s\n",
                               span_session_info_p->pa_id, span_session_info_p->drop_mirror.trap_group,
                               sx_status_str(err));
                    goto out;
                }
                break;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_mirror_drops_set(const sx_span_session_id_int_t span_session_id,
                                              const sx_span_drop_reason_t   *drop_reason_list_p,
                                              uint32_t                       drop_reason_count)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    boolean_t             has_drop_reason = FALSE;
    uint32_t              drop_idx;
    uint32_t              insert_idx;
    uint32_t              read_idx;
    sx_span_drop_reason_t drop_reason = 0;
    span_session_info_t  *span_session_info_p = NULL;
    sx_trap_group_t       trap_group = 0;

    SX_LOG_ENTER();

    span_session_info_p = &span_db.sx_span_sessions[span_session_id].span_session_info;
    err = __span_db_mirror_drops_set_trap_group(span_session_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Drop Reason Add failed for session %d. err: %s\n",
                   span_session_id, sx_status_str(err));
        goto out;
    }

    trap_group = span_session_info_p->drop_mirror.trap_group;

    insert_idx = 0;

    /* Delete Drop-Reasons in old list but not in new list */
    for (read_idx = 0; read_idx < span_session_info_p->drop_mirror.drop_reasons_count; read_idx++) {
        drop_reason = span_session_info_p->drop_mirror.drop_reasons[read_idx];
        if (insert_idx != read_idx) {
            span_session_info_p->drop_mirror.drop_reasons[insert_idx] = drop_reason;
        }

        err = span_db_drop_reason_in_list(drop_reason, drop_reason_list_p, drop_reason_count,
                                          &has_drop_reason);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Drop Reason Delete failed for session %d. err: %s\n",
                       span_session_id, sx_status_str(err));
            goto out;
        }
        if (has_drop_reason) {
            insert_idx++;
        } else {
            err = __span_db_mirror_drop_reason_set(SX_ACCESS_CMD_DELETE, trap_group, drop_reason);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Drop Reason Delete failed for session %d. err: %s\n",
                           span_session_id, sx_status_str(err));
                goto out;
            }
        }
    }
    span_session_info_p->drop_mirror.drop_reasons_count = insert_idx;

    /* Add Drop-Reasons in new list but not in old list */
    for (drop_idx = 0; drop_idx < drop_reason_count; drop_idx++) {
        drop_reason = drop_reason_list_p[drop_idx];
        err = span_db_drop_reason_in_list(drop_reason,
                                          span_session_info_p->drop_mirror.drop_reasons,
                                          span_session_info_p->drop_mirror.drop_reasons_count,
                                          &has_drop_reason);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Drop Reason Add failed for session %d. err: %s\n",
                       span_session_id, sx_status_str(err));
            goto out;
        }
        if (!has_drop_reason) {
            span_session_info_p->drop_mirror.drop_reasons[insert_idx++] = drop_reason;
            err = __span_db_mirror_drop_reason_set(SX_ACCESS_CMD_ADD, trap_group, drop_reason);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Drop Reason Add failed for session %d. err: %s\n",
                           span_session_id, sx_status_str(err));
                goto out;
            }
            span_session_info_p->drop_mirror.drop_reasons_count = insert_idx;
        }
    }

    if (span_session_info_p->drop_mirror.drop_reasons_count == 0) {
        err = __span_db_mirror_drops_unset_trap_group(span_session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed deleting session %d from Trap Group %u. err: %s\n",
                       span_session_id, span_session_info_p->drop_mirror.trap_group,
                       sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_mirror_drops_add(const sx_span_session_id_int_t span_session_id,
                                              const sx_span_drop_reason_t   *drop_reason_list_p,
                                              uint32_t                       drop_reason_count)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    boolean_t             has_drop_reason = FALSE;
    uint32_t              drop_idx;
    uint32_t              insert_idx;
    sx_span_drop_reason_t drop_reason = 0;
    span_session_info_t  *span_session_info_p = NULL;
    sx_trap_group_t       trap_group = 0;

    SX_LOG_ENTER();

    err = __span_db_mirror_drops_set_trap_group(span_session_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Drop Reason Add failed for session %d. err: %s\n",
                   span_session_id, sx_status_str(err));
        goto out;
    }

    span_session_info_p = &span_db.sx_span_sessions[span_session_id].span_session_info;
    trap_group = span_session_info_p->drop_mirror.trap_group;
    insert_idx = span_session_info_p->drop_mirror.drop_reasons_count;

    for (drop_idx = 0; drop_idx < drop_reason_count; drop_idx++) {
        drop_reason = drop_reason_list_p[drop_idx];
        err = span_db_drop_reason_in_list(drop_reason,
                                          span_session_info_p->drop_mirror.drop_reasons,
                                          span_session_info_p->drop_mirror.drop_reasons_count,
                                          &has_drop_reason);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Drop Reason Add failed for session %d. err: %s\n",
                       span_session_id, sx_status_str(err));
            goto out;
        }
        if (!has_drop_reason) {
            span_session_info_p->drop_mirror.drop_reasons[insert_idx++] = drop_reason;
            err = __span_db_mirror_drop_reason_set(SX_ACCESS_CMD_ADD, trap_group, drop_reason);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Drop Reason Add failed for session %d. err: %s\n",
                           span_session_id, sx_status_str(err));
                goto out;
            }
            span_session_info_p->drop_mirror.drop_reasons_count = insert_idx;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_mirror_drops_delete(const sx_span_session_id_int_t span_session_id,
                                                 const sx_span_drop_reason_t   *drop_reason_list_p,
                                                 uint32_t                       drop_reason_count)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    boolean_t             has_drop_reason = FALSE;
    uint32_t              read_idx;
    uint32_t              insert_idx;
    sx_span_drop_reason_t drop_reason = 0;
    span_session_info_t  *span_session_info_p = NULL;
    sx_trap_group_t       trap_group = 0;

    SX_LOG_ENTER();

    span_session_info_p = &span_db.sx_span_sessions[span_session_id].span_session_info;
    trap_group = span_session_info_p->drop_mirror.trap_group;

    insert_idx = 0;
    for (read_idx = 0; read_idx < span_session_info_p->drop_mirror.drop_reasons_count; read_idx++) {
        drop_reason = span_session_info_p->drop_mirror.drop_reasons[read_idx];
        if (insert_idx != read_idx) {
            span_session_info_p->drop_mirror.drop_reasons[insert_idx] = drop_reason;
        }

        if (drop_reason_list_p != NULL) {
            err = span_db_drop_reason_in_list(drop_reason, drop_reason_list_p, drop_reason_count,
                                              &has_drop_reason);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Drop Reason Delete failed for session %d. err: %s\n",
                           span_session_id, sx_status_str(err));
                goto out;
            }
        } else {
            /* NULL means DROP ALL */
            has_drop_reason = TRUE;
        }
        if (has_drop_reason) {
            err = __span_db_mirror_drop_reason_set(SX_ACCESS_CMD_DELETE, trap_group, drop_reason);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Drop Reason Delete failed for session %d. err: %s\n",
                           span_session_id, sx_status_str(err));
                goto out;
            }
        } else {
            insert_idx++;
        }
    }
    span_session_info_p->drop_mirror.drop_reasons_count = insert_idx;

    if (span_session_info_p->drop_mirror.drop_reasons_count == 0) {
        err = __span_db_mirror_drops_unset_trap_group(span_session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed deleting session %d from Trap Group %u. err: %s\n",
                       span_session_id, span_session_info_p->drop_mirror.trap_group,
                       sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_drops_set(const sx_access_cmd_t                cmd,
                                     const sx_span_session_id_int_t       span_session_id,
                                     const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                     const sx_span_drop_reason_t         *drop_reason_list_p,
                                     uint32_t                             drop_reason_count)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    drop_idx = 0;

    SX_LOG_ENTER();

    UNUSED_PARAM(drop_mirroring_attr_p);

    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id)) {
        SX_LOG_ERR("Invalid internal SPAN session id %d.\n", span_session_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    switch (cmd) {
    case SX_ACCESS_CMD_SET:
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        for (drop_idx = 0; drop_idx < drop_reason_count; drop_idx++) {
            if (!SX_SPAN_DROP_REASON_CHECK_RANGE(drop_reason_list_p[drop_idx])) {
                SX_LOG_ERR("Invalid drop reason [%u]\n", drop_reason_list_p[drop_idx]);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
        break;

    default:
        break;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __span_db_mirror_drops_set(span_session_id, drop_reason_list_p, drop_reason_count);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Drop Reason set failed for span session %u. err: %s\n",
                       span_session_id, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_ADD:
        err = __span_db_mirror_drops_add(span_session_id, drop_reason_list_p, drop_reason_count);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Drop Reason add failed for span session %u. err: %s\n",
                       span_session_id, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        err = __span_db_mirror_drops_delete(span_session_id, drop_reason_list_p, drop_reason_count);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Drop Reason delete failed for span session %u. err: %s\n",
                       span_session_id, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        err = __span_db_mirror_drops_delete(span_session_id, NULL, 0);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Drop Reason delete-all failed for span session %u. err: %s\n",
                       span_session_id, sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Invalid access command [%s]\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_drops_get(const sx_span_session_id_int_t       span_session_id,
                                     const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                     sx_span_drop_reason_t               *drop_reason_list_p,
                                     uint32_t                            *drop_reason_count)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    span_session_info_t span_session_info;
    uint32_t            requesed_drop_reason_count = *drop_reason_count;

    SX_LOG_ENTER();

    UNUSED_PARAM(drop_mirroring_attr_p);

    err = span_db_session_get(span_session_id, &span_session_info, NULL, NULL, NULL, NULL, NULL);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed getting session info for span session %u. err: %s\n",
                   span_session_id, sx_status_str(err));
        goto out;
    }

    if (requesed_drop_reason_count > 0) {
        *drop_reason_count = MIN(requesed_drop_reason_count, span_session_info.drop_mirror.drop_reasons_count);
        SX_MEM_CPY_ARRAY(drop_reason_list_p, span_session_info.drop_mirror.drop_reasons,
                         *drop_reason_count, sx_span_drop_reason_t);
    } else {
        *drop_reason_count = span_session_info.drop_mirror.drop_reasons_count;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_mirror_direction_to_bind_type(span_mirror_direction_t     direction,
                                                           sx_span_mirror_bind_type_e *bind_type_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (direction) {
    case SPAN_MIRROR_DIRECTION_INGRESS_WRED:
        *bind_type_p = SX_SPAN_MIRROR_BIND_ING_WRED_E;
        break;

    case SPAN_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER:
        *bind_type_p = SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E;
        break;

    case SPAN_MIRROR_DIRECTION_INGRESS_PG_CONGESTION:
        *bind_type_p = SX_SPAN_MIRROR_BIND_ING_PG_CONGESTION_E;
        break;

    case SPAN_MIRROR_DIRECTION_INGRESS_TC_CONGESTION:
        *bind_type_p = SX_SPAN_MIRROR_BIND_ING_TC_CONGESTION_E;
        break;

    case SPAN_MIRROR_DIRECTION_EGRESS_ECN:
        *bind_type_p = SX_SPAN_MIRROR_BIND_EGR_ECN_E;
        break;

    case SPAN_MIRROR_DIRECTION_EGRESS_TC_LATENCY:
        *bind_type_p = SX_SPAN_MIRROR_BIND_EGR_TC_LATENCY_E;
        break;

    default:
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        break;
    }

    return err;
}

static sx_status_t __span_db_mirror_bind_type_to_direction(sx_span_mirror_bind_type_e bind_type,
                                                           span_mirror_direction_t   *direction_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (bind_type) {
    case SX_SPAN_MIRROR_BIND_ING_WRED_E:
        *direction_p = SPAN_MIRROR_DIRECTION_INGRESS_WRED;
        break;

    case SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E:
        *direction_p = SPAN_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER;
        break;

    case SX_SPAN_MIRROR_BIND_ING_PG_CONGESTION_E:
        *direction_p = SPAN_MIRROR_DIRECTION_INGRESS_PG_CONGESTION;
        break;

    case SX_SPAN_MIRROR_BIND_ING_TC_CONGESTION_E:
        *direction_p = SPAN_MIRROR_DIRECTION_INGRESS_TC_CONGESTION;
        break;

    case SX_SPAN_MIRROR_BIND_EGR_ECN_E:
        *direction_p = SPAN_MIRROR_DIRECTION_EGRESS_ECN;
        break;

    case SX_SPAN_MIRROR_BIND_EGR_TC_LATENCY_E:
        *direction_p = SPAN_MIRROR_DIRECTION_EGRESS_TC_LATENCY;
        break;

    default:
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        break;
    }

    return err;
}

static sx_status_t __span_db_mirror_enable_type_to_bind_type(sx_span_mirror_enable_type_e enable_type,
                                                             sx_span_mirror_bind_type_e  *bind_type_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (enable_type) {
    case SX_SPAN_MIRROR_ENABLE_ING_WRED_E:
        *bind_type_p = SX_SPAN_MIRROR_BIND_ING_WRED_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_UC_E:
        *bind_type_p = SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_MC_E:
        *bind_type_p = SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_PG_THRESHOLD_E:
        *bind_type_p = SX_SPAN_MIRROR_BIND_ING_PG_CONGESTION_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_TC_THRESHOLD_E:
        *bind_type_p = SX_SPAN_MIRROR_BIND_ING_TC_CONGESTION_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_ECN_E:
        *bind_type_p = SX_SPAN_MIRROR_BIND_EGR_ECN_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_TC_LATENCY_E:
        *bind_type_p = SX_SPAN_MIRROR_BIND_EGR_TC_LATENCY_E;
        break;

    default:
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        break;
    }

    return err;
}

static sx_status_t __span_db_mirror_bind_type_to_enable_type(sx_span_mirror_bind_type_e    bind_type,
                                                             sx_span_mirror_enable_type_e *enable_type_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (bind_type) {
    case SX_SPAN_MIRROR_BIND_ING_WRED_E:
        *enable_type_p = SX_SPAN_MIRROR_ENABLE_ING_WRED_E;
        break;

    case SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E:
        *enable_type_p = SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_UC_E;
        break;

    case SX_SPAN_MIRROR_BIND_ING_PG_CONGESTION_E:
        *enable_type_p = SX_SPAN_MIRROR_ENABLE_ING_PG_THRESHOLD_E;
        break;

    case SX_SPAN_MIRROR_BIND_ING_TC_CONGESTION_E:
        *enable_type_p = SX_SPAN_MIRROR_ENABLE_ING_TC_THRESHOLD_E;
        break;

    case SX_SPAN_MIRROR_BIND_EGR_ECN_E:
        *enable_type_p = SX_SPAN_MIRROR_ENABLE_EGR_ECN_E;
        break;

    case SX_SPAN_MIRROR_BIND_EGR_TC_LATENCY_E:
        *enable_type_p = SX_SPAN_MIRROR_ENABLE_EGR_TC_LATENCY_E;
        break;

    default:
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        break;
    }

    return err;
}

static sx_status_t __span_db_fw_mirror_bind_set(IN span_mirror_direction_t  direction,
                                                IN sx_span_session_id_int_t span_session_id,
                                                IN boolean_t                enable,
                                                IN uint32_t                 probability_rate)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t                   reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_mpagr_reg              mpagr_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t                     sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sxd_span_mirror_port_direction_t sxd_direction;

    SX_LOG_ENTER();

    if (probability_rate == 0) {
        probability_rate = 1;
    }
    enable = FALSE;

    /* Get list of LEAF devices */
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_DEBUG, "Empty device list [%s]: Zerodev config\n",
               sx_status_str(err));
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_ADD;

    SX_MEM_CLR(mpagr_reg_data[dev_idx]);

    /* Set the port mirroring directions */
    err = span_db_cnv_span_to_sxd_mirror_direction(direction,
                                                   &sxd_direction);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }
    mpagr_reg_data[dev_idx].trigger = sxd_direction;
    mpagr_reg_data[dev_idx].enable = enable;
    mpagr_reg_data[dev_idx].pa_id = span_session_id;
    mpagr_reg_data[dev_idx].probability_rate = probability_rate;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MPAGR_E,
                                                     mpagr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed MPAGR set: [%s] mirror trigger.\n",
               SXD_STATUS_MSG(sxd_status));

        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_bind(const sx_span_mirror_bind_key_t *key_p, const sx_span_mirror_bind_attr_t *attr_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    cl_pool_item_t          *pool_item_p = NULL;
    span_mirror_map_item_t  *span_mirror_port_item_p = NULL;
    uint64_t                 span_mirror_map_key;
    span_mirror_direction_t  mirror_direction = SPAN_MIRROR_DIRECTION_MIN;
    sx_span_session_id_int_t span_session_id;

    SX_LOG_ENTER();

    if (key_p == NULL) {
        SX_LOG_ERR("key_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (span_db.mirror_bind_entries[key_p->type].bound == TRUE) {
        err = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }

    __span_db_mirror_bind_type_to_direction(key_p->type, &mirror_direction);

    /* is bind type in map ? */
    err = span_db_mirror_port_find(0, mirror_direction, NULL);
    if (err == SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Bind type [0x%x] already exists in SPAN mirror map. \n", key_p->type);
        err = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }

    /* get new pool item */
    pool_item_p = cl_qpool_get(&(span_db.mirror_ports_pool));
    if (pool_item_p == NULL) {
        SX_LOG_ERR("Couldn't create a new span_mirror_db entry (No Resources)\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    /* Look up internal session */
    err = span_db_session_ext_to_int(attr_p->span_session_id, &span_session_id);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   attr_p->span_session_id, span_session_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    err = __span_db_fw_mirror_bind_set(mirror_direction, span_session_id, TRUE, attr_p->rate);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to bind mirror to session.\n");
        goto out;
    }

    span_mirror_port_item_p = PARENT_STRUCT(pool_item_p, span_mirror_map_item_t, pool_item);
    SX_MEM_CLR(span_mirror_port_item_p->span_mirror_record);
    span_mirror_port_item_p->span_mirror_record.bound = TRUE;
    span_mirror_port_item_p->span_mirror_record.mirror_direction = mirror_direction;
    span_mirror_port_item_p->span_mirror_record.pa_id = span_session_id;

    span_mirror_map_key = BUILD_SPAN_MIRROR_KEY(0, mirror_direction);
    cl_qmap_insert(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db),
                   span_mirror_map_key, &(span_mirror_port_item_p->map_item));

    span_db.mirror_bind_entries[key_p->type].bound = TRUE;
    span_db.mirror_bind_entries[key_p->type].key = *key_p;
    span_db.mirror_bind_entries[key_p->type].attr = *attr_p;

out:
    if (err && pool_item_p) {
        /* free the pool item */
        cl_qpool_put(&(span_db.mirror_ports_pool), pool_item_p);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_unbind(const sx_span_mirror_bind_key_t *key_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    span_mirror_map_item_t      *span_mirror_port_item_p = NULL;
    span_mirror_direction_t      mirror_direction = SPAN_MIRROR_DIRECTION_MIN;
    sx_span_mirror_enable_type_e enable_type = SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E;
    sx_span_session_id_int_t     span_session_id = 0;
    cl_map_item_t               *map_item_p = NULL;

    SX_LOG_ENTER();

    if (key_p == NULL) {
        SX_LOG_ERR("key_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (span_db.mirror_bind_entries[key_p->type].bound == FALSE) {
        err = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    __span_db_mirror_bind_type_to_enable_type(key_p->type, &enable_type);

    if (!cl_is_qmap_empty(&span_db.mirror_enable_entries[enable_type].mirror_enable_map)) {
        SX_LOG_ERR("There are still mirror enabled for bind type [0x%x]. \n", key_p->type);
        err = SX_STATUS_ERROR;
        goto out;
    }
    /* Shared buffer drop has two enable type, need to check shared buffer drop mc as well */
    if (key_p->type == SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E) {
        enable_type = SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_MC_E;
    }
    if (!cl_is_qmap_empty(&span_db.mirror_enable_entries[enable_type].mirror_enable_map)) {
        SX_LOG_ERR("There are still mirror enabled for bind type [0x%x]. \n", key_p->type);
        err = SX_STATUS_ERROR;
        goto out;
    }

    __span_db_mirror_bind_type_to_direction(key_p->type, &mirror_direction);

    /* is bind type in map ? */
    err = span_db_mirror_port_find(0, mirror_direction, &map_item_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Bind type [0x%x] does not exist in SPAN mirror map. \n", key_p->type);
        err = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    span_mirror_port_item_p = PARENT_STRUCT(map_item_p, span_mirror_map_item_t, map_item);
    span_session_id = span_mirror_port_item_p->span_mirror_record.pa_id;

    err = __span_db_fw_mirror_bind_set(mirror_direction, span_session_id, FALSE,
                                       span_mirror_port_item_p->span_mirror_record.rate);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to unbind mirror from session.\n");
        goto out;
    }

    cl_qmap_remove_item(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db),
                        map_item_p);

    cl_qpool_put(&(span_db.mirror_ports_pool), &(span_mirror_port_item_p->pool_item));

    SX_MEM_CLR(span_db.mirror_bind_entries[key_p->type]);


out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_bind_get(const sx_span_mirror_bind_key_t *key_p, sx_span_mirror_bind_attr_t      *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (key_p == NULL) {
        SX_LOG_ERR("key_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (span_db.mirror_bind_entries[key_p->type].bound == FALSE) {
        err = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    *attr_p = span_db.mirror_bind_entries[key_p->type].attr;
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_mirror_bound_get(const sx_span_session_id_int_t span_session_id,
                                             sx_span_mirror_bind_key_t     *mirror_bind_key_list_p,
                                             uint32_t                      *mirror_bind_key_cnt_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_status_t                conv_rc = SX_STATUS_SUCCESS;
    uint32_t                   idx = 0;
    uint32_t                   count = 0;
    uint32_t                   mirror_ports_cnt = 0;
    span_mirror_t             *mirror_ports_list_p = NULL;
    sx_span_mirror_bind_type_e bind_type;

    SX_LOG_ENTER();

    if (mirror_bind_key_cnt_p == NULL) {
        SX_LOG_ERR("mirror_bind_key_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*mirror_bind_key_cnt_p > 0) && (mirror_bind_key_list_p == NULL)) {
        SX_LOG_ERR("mirror_bind_key_list_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    mirror_ports_cnt = cl_qmap_count(&(span_db.sx_span_sessions[span_session_id].mirror_ports_db));
    if (mirror_ports_cnt == 0) {
        *mirror_bind_key_cnt_p = 0;
        goto out;
    }

    mirror_ports_list_p = (span_mirror_t*)cl_malloc(
        sizeof(span_mirror_t) * (mirror_ports_cnt));
    if (!mirror_ports_list_p) {
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    /* Get list of mirrored ports with all directions */
    err = span_db_session_get(span_session_id, NULL, NULL,
                              &mirror_ports_cnt, mirror_ports_list_p,
                              NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id, sx_status_str(err));
        goto out;
    }

    for (idx = 0; idx < mirror_ports_cnt; idx++) {
        if ((*mirror_bind_key_cnt_p > 0) && (count == *mirror_bind_key_cnt_p)) {
            break;
        }
        conv_rc = __span_db_mirror_direction_to_bind_type(mirror_ports_list_p[idx].mirror_direction, &bind_type);
        if (conv_rc != SX_STATUS_SUCCESS) {
            continue;
        }
        if (*mirror_bind_key_cnt_p > 0) {
            SX_MEM_CLR(mirror_bind_key_list_p[count]);
            mirror_bind_key_list_p[count].type = bind_type;
        }
        count++;
    }

    *mirror_bind_key_cnt_p = count;

out:
    if (mirror_ports_list_p) {
        CL_FREE_N_NULL(mirror_ports_list_p);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_bound_update(span_mirror_direction_t  direction,
                                        sx_span_session_id_int_t old_span_session_id,
                                        sx_span_session_id_int_t new_span_session_id)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_status_t                conv_rc = SX_STATUS_SUCCESS;
    sx_span_mirror_bind_type_e bind_type;
    span_mirror_map_item_t    *span_mirror_port_item_p = NULL;
    cl_map_item_t             *map_item_p = NULL;
    uint64_t                   span_mirror_map_key;

    SX_LOG_ENTER();

    conv_rc = __span_db_mirror_direction_to_bind_type(direction, &bind_type);
    if (conv_rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* is bind type in map ? */
    err = span_db_mirror_port_find(0, direction, &map_item_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Bind type [0x%x] does not exist in SPAN mirror map. \n", bind_type);
        err = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }
    span_mirror_port_item_p = PARENT_STRUCT(map_item_p, span_mirror_map_item_t, map_item);
    if (old_span_session_id != span_mirror_port_item_p->span_mirror_record.pa_id) {
        SX_LOG_ERR("Bind type [0x%x] bound to span session %d, not to span session %d.\n",
                   bind_type, span_mirror_port_item_p->span_mirror_record.pa_id, old_span_session_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = __span_db_fw_mirror_bind_set(direction,
                                       new_span_session_id,
                                       TRUE,
                                       span_db.mirror_bind_entries[bind_type].attr.rate);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to bind mirror to session.\n");
        goto out;
    }

    if (old_span_session_id != new_span_session_id) {
        span_mirror_port_item_p->span_mirror_record.pa_id = new_span_session_id;

        span_mirror_map_key = BUILD_SPAN_MIRROR_KEY(0, direction);
        map_item_p = cl_qmap_remove(&(span_db.sx_span_sessions[old_span_session_id].mirror_ports_db),
                                    span_mirror_map_key);
        cl_qmap_insert(&(span_db.sx_span_sessions[new_span_session_id].mirror_ports_db),
                       span_mirror_map_key, &(span_mirror_port_item_p->map_item));
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_cnv_span_to_sxd_mirror_enable_type(const sx_span_mirror_enable_type_e span_enable_type,
                                                                sxd_momte_type_t                  *sxd_enable_type_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (span_enable_type) {
    case SX_SPAN_MIRROR_ENABLE_ING_WRED_E:
        *sxd_enable_type_p = SXD_MOMTE_TYPE_WRED_EGRESS_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_UC_E:
        *sxd_enable_type_p = SXD_MOMTE_TYPE_SHARED_BUFFER_TCLASS_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_MC_E:
        *sxd_enable_type_p = SXD_MOMTE_TYPE_SHARED_BUFFER_EGRESS_PORT_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_PG_THRESHOLD_E:
        *sxd_enable_type_p = SXD_MOMTE_TYPE_ING_CONG_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_TC_THRESHOLD_E:
        *sxd_enable_type_p = SXD_MOMTE_TYPE_EGR_CONG_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_ECN_E:
        *sxd_enable_type_p = SXD_MOMTE_TYPE_ECN_E;
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_TC_LATENCY_E:
        *sxd_enable_type_p = SXD_MOMTE_TYPE_HIGH_LATENCY_E;
        break;

    default:
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        break;
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_fw_mirror_enable_set(IN sx_span_mirror_enable_type_e mirror_enable_type,
                                                  IN sx_port_log_id_t             log_port,
                                                  IN uint32_t                     tc_pg_en)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_momte_reg momte_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_momte_type_t    sxd_enable_type = 0;

    SX_LOG_ENTER();

    __span_db_cnv_span_to_sxd_mirror_enable_type(mirror_enable_type, &sxd_enable_type);

    /* Get list of LEAF devices */
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_DEBUG, "Empty device list [%s]: Zerodev config\n",
               sx_status_str(err));
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_ADD;

    SX_MEM_CLR(momte_reg_data[dev_idx]);

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(momte_reg_data[dev_idx].local_port,
                                        momte_reg_data[dev_idx].lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));
    momte_reg_data[dev_idx].type = sxd_enable_type;
    momte_reg_data[dev_idx].tclass_en_low = tc_pg_en;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOMTE_E,
                                                     momte_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed MOMTE set: [%s] mirror type.\n",
               SXD_STATUS_MSG(sxd_status));

        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_fw_mirror_enable_port_set(IN sx_port_log_id_t log_port,
                                                       IN uint16_t         disallow_nelp,
                                                       IN uint16_t         disallow_elp)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_mocmi_reg mocmi_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t         err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /*__span_db_cnv_span_to_sxd_mirror_enable_type(mirror_enable_type, &sxd_enable_type); */

    /* Get list of LEAF devices */
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_DEBUG, "Empty device list [%s]: Zerodev config\n",
               sx_status_str(err));
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_ADD;

    SX_MEM_CLR(mocmi_reg_data[dev_idx]);

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(mocmi_reg_data[dev_idx].local_port,
                                        mocmi_reg_data[dev_idx].lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));
    mocmi_reg_data[dev_idx].cond_nelp = MIRROR_BIND_TYPE_BITS_TO_MIRROR_TRIGGER_BITS(disallow_nelp);
    mocmi_reg_data[dev_idx].cond_elp = MIRROR_BIND_TYPE_BITS_TO_MIRROR_TRIGGER_BITS(disallow_elp);

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOCMI_E,
                                                     mocmi_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to set conditional mirroring register: [%s].\n",
               SXD_STATUS_MSG(sxd_status));

        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_mirror_enable_get_port_tc(const sx_span_mirror_enable_object_t *object_p,
                                                       sx_port_log_id_t                     *log_port_p,
                                                       uint32_t                             *tc_pg_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (object_p->type) {
    case SX_SPAN_MIRROR_ENABLE_ING_WRED_E:
        *log_port_p = object_p->object.ing_wred.port;
        *tc_pg_p = object_p->object.ing_wred.tc;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_UC_E:
        *log_port_p = object_p->object.ing_sb_drop_uc.port;
        *tc_pg_p = object_p->object.ing_sb_drop_uc.tc;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_MC_E:
        *log_port_p = object_p->object.ing_sb_drop_mc.port;
        *tc_pg_p = 0;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_PG_THRESHOLD_E:
        *log_port_p = object_p->object.ing_pg_threshold.port;
        *tc_pg_p = object_p->object.ing_pg_threshold.pg;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_TC_THRESHOLD_E:
        *log_port_p = object_p->object.ing_tc_threshold.port;
        *tc_pg_p = object_p->object.ing_tc_threshold.tc;
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_ECN_E:
        *log_port_p = object_p->object.egr_ecn.port;
        *tc_pg_p = object_p->object.egr_ecn.tc;
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_TC_LATENCY_E:
        *log_port_p = object_p->object.egr_latency.port;
        *tc_pg_p = object_p->object.egr_latency.tc;
        break;

    default:
        SX_LOG_ERR("Mirror enable object %u is invalid.\n", object_p->type);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        break;
    }

    return err;
}

sx_status_t span_db_mirror_enable_phy_port_set(sx_port_log_id_t             log_port,
                                               sx_span_mirror_enable_type_e mirror_enable_type,
                                               uint32_t                     tc_pg_en)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = __span_db_fw_mirror_enable_set(mirror_enable_type, log_port, tc_pg_en);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "add: __span_db_fw_mirror_port_set(log_port 0x%x, tc_pg_en: 0x%x , enable_type:%d ) failed. err: %s\n",
            log_port,
            tc_pg_en,
            mirror_enable_type,
            sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_enable_add(const sx_span_mirror_enable_object_t *object_p,
                                      const sx_span_mirror_enable_attr_t   *attr_p)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    cl_map_item_t                    *map_item_p = NULL;
    cl_pool_item_t                   *pool_item_p = NULL;
    span_mirror_enable_item_t        *enable_item_p = NULL;
    span_mirror_enable_object_item_t *enable_object_item_p = NULL;
    sx_span_mirror_bind_type_e        bind_type = SX_SPAN_MIRROR_BIND_TYPE_MIN_E;
    span_mirror_direction_t           mirror_direction = 0;
    uint64_t                          key = 0;
    uint32_t                          tc_pg = 0;
    uint32_t                          tc_pg_en = 0;
    sx_port_log_id_t                  log_port;
    sx_port_log_id_t                 *log_port_arr = NULL;
    uint32_t                          i = 0;
    uint32_t                          log_port_num = rm_resource_global.lag_port_members_max;

    SX_LOG_ENTER();

    if (object_p == NULL) {
        SX_LOG_ERR("object_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    __span_db_mirror_enable_type_to_bind_type(object_p->type, &bind_type);
    if (!span_db.mirror_bind_entries[bind_type].bound) {
        SX_LOG_ERR("Related mirror bind type is not bound yet[0x%x]. \n", object_p->type);
        err = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    err = __span_db_mirror_bind_type_to_direction(bind_type, &mirror_direction);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fail to get mirror direction for enable type %u.\n", object_p->type);
        goto out;
    }

    err = __span_db_mirror_enable_get_port_tc(object_p, &log_port, &tc_pg);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get port tc for enable type %u.\n", object_p->type);
        goto out;
    }

    log_port_arr = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
    if (!log_port_arr) {
        return SX_STATUS_NO_MEMORY;
    }

    key = log_port;

    map_item_p = cl_qmap_get(&span_db.mirror_enable_entries[object_p->type].mirror_enable_map, key);
    if (map_item_p != cl_qmap_end(&span_db.mirror_enable_entries[object_p->type].mirror_enable_map)) {
        SX_LOG_DBG("Mirror enable entry for log port 0x%x exist, update it.\n", log_port);
        enable_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_item_t, map_item);
        tc_pg_en = enable_item_p->tc_pg_en;
        if ((tc_pg_en >> tc_pg) & 1U) {
            SX_LOG_ERR("TC/PG %d on log port 0x%x already enabled.\n", tc_pg, log_port);
            err = SX_STATUS_ENTRY_ALREADY_EXISTS;
            goto out;
        }
    }

    tc_pg_en |= (1UL << tc_pg);

    /*
     *  in case the LOG_PORT is LAG extract the LAG ports
     *  else return the same port
     */
    err = __span_db_get_lag_ports_list(log_port,
                                       &log_port_num, log_port_arr);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__span_db_get_lag_ports_list for log_port [0x%x] failed. err: %s\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < log_port_num; i++) {
        /* Allocate shared buffer if device type and mirror direction require it */
        err = span_egress_mirror_alloc_buffer_cb_wrapper(SX_ACCESS_CMD_ADD,
                                                         log_port_arr[i],
                                                         mirror_direction,
                                                         SPAN_EGRESS_MIRROR_BUFF_TYPE_SPAN_MIRROR);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_egress_mirror_alloc_buffer_cb_wrapper [cmd= ADD, port [0x%x] failed. err: %s]\n",
                       log_port_arr[i], sx_status_str(err));
            goto out;
        }

        /* set the fw */
        err = __span_db_fw_mirror_enable_set(object_p->type, log_port_arr[i], tc_pg_en);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set mirror enable type %u for log_port 0x%x to FW.\n",
                       object_p->type, log_port_arr[i]);
            goto out;
        }
    }

    if (enable_item_p) {
        enable_item_p->tc_pg_en = tc_pg_en;
        if (attr_p) {
            enable_item_p->attr = *attr_p;
        }
    } else {
        SX_LOG_DBG("Mirror enable entry for log port 0x%x does not exist, create it.\n", log_port);
        pool_item_p = cl_qpool_get(&span_db.mirror_enable_pool);
        if (pool_item_p == NULL) {
            SX_LOG_ERR("Couldn't create a new span_mirror_enable_item_t entry (No Resources)\n");
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }

        enable_item_p = PARENT_STRUCT(pool_item_p, span_mirror_enable_item_t, pool_item);
        enable_item_p->log_port = log_port;
        enable_item_p->tc_pg_en = tc_pg_en;
        SX_MEM_CLR(enable_item_p->attr);
        if (attr_p) {
            enable_item_p->attr = *attr_p;
        }
        cl_qmap_insert(&span_db.mirror_enable_entries[object_p->type].mirror_enable_map,
                       key, &enable_item_p->map_item);
    }

    SX_LOG_DBG("Add to mirror enable object lookup.\n");
    pool_item_p = cl_qpool_get(&span_db.mirror_enable_object_pool);
    if (pool_item_p == NULL) {
        SX_LOG_ERR("Couldn't create a new span_mirror_enable_object_item_t entry (No Resources)\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    enable_object_item_p = PARENT_STRUCT(pool_item_p, span_mirror_enable_object_item_t, pool_item);
    enable_object_item_p->object = *object_p;
    SX_MEM_CLR(enable_object_item_p->attr);
    if (attr_p) {
        enable_object_item_p->attr = *attr_p;
    }
    key = MIRROR_ENABLE_OBJECT_KEY(log_port, tc_pg);
    cl_qmap_insert(&span_db.mirror_enable_entries[object_p->type].mirror_enable_object_lookup,
                   key, &enable_object_item_p->map_item);


out:
    if (log_port_arr) {
        CL_FREE_N_NULL(log_port_arr);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_enable_remove(const sx_span_mirror_enable_object_t *object_p)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    cl_map_item_t                    *map_item_p = NULL;
    span_mirror_enable_item_t        *enable_item_p = NULL;
    span_mirror_enable_object_item_t *enable_object_item_p = NULL;
    sx_span_mirror_bind_type_e        bind_type = SX_SPAN_MIRROR_BIND_TYPE_MIN_E;
    span_mirror_direction_t           mirror_direction = 0;
    uint64_t                          key;
    uint32_t                          tc_pg;
    uint32_t                          tc_pg_en;
    sx_port_log_id_t                  log_port;
    sx_port_log_id_t                 *log_port_arr = NULL;
    uint32_t                          i = 0;
    uint32_t                          log_port_num = rm_resource_global.lag_port_members_max;

    SX_LOG_ENTER();

    if (object_p == NULL) {
        SX_LOG_ERR("object_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    __span_db_mirror_enable_type_to_bind_type(object_p->type, &bind_type);
    if (!span_db.mirror_bind_entries[bind_type].bound) {
        SX_LOG_ERR("Related mirror bind type is not bound yet[0x%x]. \n", object_p->type);
        err = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    err = __span_db_mirror_bind_type_to_direction(bind_type, &mirror_direction);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fail to get mirror direction for enable type %u.\n", object_p->type);
        goto out;
    }

    err = __span_db_mirror_enable_get_port_tc(object_p, &log_port, &tc_pg);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get port tc for enable type %u.\n", object_p->type);
        goto out;
    }
    key = log_port;

    map_item_p = cl_qmap_get(&span_db.mirror_enable_entries[object_p->type].mirror_enable_map, key);
    if (map_item_p == cl_qmap_end(&span_db.mirror_enable_entries[object_p->type].mirror_enable_map)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Mirror enable object %u on log port 0x%x does not exist.\n",
                   object_p->type, log_port);
        goto out;
    }

    enable_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_item_t, map_item);

    tc_pg_en = enable_item_p->tc_pg_en;
    if (((tc_pg_en >> tc_pg) & 1U) == 0) {
        SX_LOG_ERR("TC/PG %d on log port 0x%x is not enabled.\n", tc_pg, log_port);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    tc_pg_en &= ~(1UL << tc_pg);

    log_port_arr = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
    if (!log_port_arr) {
        return SX_STATUS_NO_MEMORY;
    }

    /*
     *  in case the LOG_PORT is LAG extract the LAG ports
     *  else return the same port
     */
    err = __span_db_get_lag_ports_list(log_port,
                                       &log_port_num, log_port_arr);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__span_db_get_lag_ports_list for log_port [0x%x] failed. err: %s\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < log_port_num; i++) {
        /* Free shared buffer if allocated */
        err = span_egress_mirror_alloc_buffer_cb_wrapper(SX_ACCESS_CMD_DELETE,
                                                         log_port_arr[i],
                                                         mirror_direction,
                                                         SPAN_EGRESS_MIRROR_BUFF_TYPE_SPAN_MIRROR);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_egress_mirror_alloc_buffer_cb_wrapper [cmd=DELETE, port [0x%x] failed. err: %s]\n",
                       log_port_arr[i], sx_status_str(err));
            goto out;
        }

        err = __span_db_fw_mirror_enable_set(object_p->type, log_port_arr[i], tc_pg_en);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set mirror enable type %u to FW.\n", object_p->type);
            goto out;
        }
    }

    enable_item_p->tc_pg_en = tc_pg_en;
    if (enable_item_p->tc_pg_en == 0) {
        cl_qmap_remove_item(&span_db.mirror_enable_entries[object_p->type].mirror_enable_map, map_item_p);
        cl_qpool_put(&(span_db.mirror_enable_pool), &(enable_item_p->pool_item));
    }

    /* Remove from mirror enable object lookup */

    key = MIRROR_ENABLE_OBJECT_KEY(log_port, tc_pg);

    map_item_p = cl_qmap_get(&span_db.mirror_enable_entries[object_p->type].mirror_enable_object_lookup, key);
    if (map_item_p == cl_qmap_end(&span_db.mirror_enable_entries[object_p->type].mirror_enable_object_lookup)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Mirror enable object %u on log port 0x%x, tc/pg %d does not exist.\n",
                   object_p->type, log_port, tc_pg);
        goto out;
    }
    enable_object_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_object_item_t, map_item);
    cl_qmap_remove_item(&span_db.mirror_enable_entries[object_p->type].mirror_enable_object_lookup, map_item_p);
    cl_qpool_put(&(span_db.mirror_enable_object_pool), &(enable_object_item_p->pool_item));

out:
    if (log_port_arr) {
        CL_FREE_N_NULL(log_port_arr);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_enable_get(const sx_span_mirror_enable_object_t *object_p,
                                      sx_span_mirror_enable_attr_t         *attr_p)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    cl_map_item_t                    *map_item_p = NULL;
    span_mirror_enable_object_item_t *enable_object_item_p = NULL;
    uint64_t                          key;
    uint32_t                          tc_pg;
    sx_port_log_id_t                  log_port;
    sx_span_mirror_bind_type_e        bind_type = SX_SPAN_MIRROR_BIND_TYPE_MIN_E;

    SX_LOG_ENTER();

    if (object_p == NULL) {
        SX_LOG_ERR("object_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    __span_db_mirror_enable_type_to_bind_type(object_p->type, &bind_type);
    if (!span_db.mirror_bind_entries[bind_type].bound) {
        SX_LOG_ERR("Related mirror bind type is not bound yet[0x%x]. \n", object_p->type);
        err = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    err = __span_db_mirror_enable_get_port_tc(object_p, &log_port, &tc_pg);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get port tc for enable type %u.\n", object_p->type);
        goto out;
    }
    key = MIRROR_ENABLE_OBJECT_KEY(log_port, tc_pg);

    map_item_p = cl_qmap_get(&span_db.mirror_enable_entries[object_p->type].mirror_enable_object_lookup, key);
    if (map_item_p == cl_qmap_end(&span_db.mirror_enable_entries[object_p->type].mirror_enable_object_lookup)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Mirror enable object %u on log port 0x%x does not exist.\n",
                   object_p->type, log_port);
        goto out;
    }

    enable_object_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_object_item_t, map_item);
    if (attr_p) {
        *attr_p = enable_object_item_p->attr;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_enable_port_remove(sx_port_log_id_t log_port, sx_span_mirror_enable_type_e type)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    cl_map_item_t                    *map_item_p = NULL;
    span_mirror_enable_item_t        *enable_item_p = NULL;
    span_mirror_enable_object_item_t *enable_object_item_p = NULL;
    uint64_t                          key;
    uint32_t                          tc_pg;
    uint32_t                          tc_pg_en;
    sx_port_log_id_t                 *log_port_arr = NULL;
    uint32_t                          i = 0;
    uint32_t                          log_port_num = rm_resource_global.lag_port_members_max;

    SX_LOG_ENTER();

    key = log_port;

    map_item_p = cl_qmap_get(&span_db.mirror_enable_entries[type].mirror_enable_map, key);
    if (map_item_p == cl_qmap_end(&span_db.mirror_enable_entries[type].mirror_enable_map)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("Mirror enable object %u on log port 0x%x does not exist.\n",
                   type, log_port);
        goto out;
    }

    enable_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_item_t, map_item);

    tc_pg_en = enable_item_p->tc_pg_en;
    enable_item_p->tc_pg_en = 0;

    log_port_arr = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
    if (!log_port_arr) {
        return SX_STATUS_NO_MEMORY;
    }

    /*
     *  in case the LOG_PORT is LAG extract the LAG ports
     *  else return the same port
     */
    err = __span_db_get_lag_ports_list(log_port,
                                       &log_port_num, log_port_arr);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__span_db_get_lag_ports_list for log_port [0x%x] failed. err: %s\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < log_port_num; i++) {
        err = __span_db_fw_mirror_enable_set(type, log_port_arr[i], 0);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set mirror enable type %u to FW.\n", type);
            goto out;
        }
    }

    cl_qmap_remove_item(&span_db.mirror_enable_entries[type].mirror_enable_map, map_item_p);
    cl_qpool_put(&(span_db.mirror_enable_pool), &(enable_item_p->pool_item));

    /* Remove from mirror enable object lookup */
    for (tc_pg = 0; tc_pg <= SPAN_DB_MIRROR_ENABLE_TC_PG_MAX_VALUE; tc_pg++) {
        if (((tc_pg_en >> tc_pg) & 1UL) == 0) {
            continue;
        }

        key = MIRROR_ENABLE_OBJECT_KEY(log_port, tc_pg);

        map_item_p = cl_qmap_get(&span_db.mirror_enable_entries[type].mirror_enable_object_lookup, key);
        if (map_item_p == cl_qmap_end(&span_db.mirror_enable_entries[type].mirror_enable_object_lookup)) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_WRN("Mirror enable object %u on log port 0x%x, tc/pg %d does not exist.\n",
                       type, log_port, tc_pg);
            continue;
        }
        enable_object_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_object_item_t, map_item);
        cl_qmap_remove_item(&span_db.mirror_enable_entries[type].mirror_enable_object_lookup, map_item_p);
        cl_qpool_put(&(span_db.mirror_enable_object_pool), &(enable_object_item_p->pool_item));
    }

out:
    if (log_port_arr) {
        CL_FREE_N_NULL(log_port_arr);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_enable_port_get(sx_port_log_id_t             log_port,
                                           sx_span_mirror_enable_type_e type,
                                           uint32_t                    *tc_pg_en_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    cl_map_item_t             *map_item_p = NULL;
    span_mirror_enable_item_t *enable_item_p = NULL;
    uint64_t                   key;

    SX_LOG_ENTER();

    key = log_port;

    map_item_p = cl_qmap_get(&span_db.mirror_enable_entries[type].mirror_enable_map, key);
    if (map_item_p == cl_qmap_end(&span_db.mirror_enable_entries[type].mirror_enable_map)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("Mirror enable object %u on log port 0x%x does not exist.\n",
                   type, log_port);
        goto out;
    }

    enable_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_item_t, map_item);
    if (tc_pg_en_p) {
        *tc_pg_en_p = enable_item_p->tc_pg_en;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_enable_iter_get(const sx_access_cmd_t                cmd,
                                           sx_span_mirror_enable_object_t      *object_key_p,
                                           sx_span_mirror_enable_iter_filter_t *filter_p,
                                           sx_span_mirror_enable_object_t      *object_list_p,
                                           uint32_t                            *object_cnt_p)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    cl_map_item_t                    *map_item_p = NULL;
    span_mirror_enable_object_item_t *enable_object_item_p = NULL;
    uint64_t                          key;
    uint32_t                          tc_pg;
    sx_port_log_id_t                  log_port;
    uint32_t                          db_found_count = 0;

    SX_LOG_ENTER();

    if (object_key_p == NULL) {
        SX_LOG_ERR("object_key_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (object_cnt_p == NULL) {
        SX_LOG_ERR("object_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if ((*object_cnt_p > 0) && (object_list_p == NULL)) {
            SX_LOG_ERR("object_list_p is NULL.\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        if (*object_cnt_p > 0) {
            *object_cnt_p = 1;
        }

        break;

    case SX_ACCESS_CMD_GET_FIRST:
    /* Fallthrough */
    case SX_ACCESS_CMD_GETNEXT:
        if (*object_cnt_p == 0) {
            /* return empty list. */
            SX_LOG(SX_LOG_DEBUG, "[%s] Cmd = %s; but count is 0 return Empty List\n",
                   __func__, sx_access_cmd_str(cmd));
            goto out;
        }
        if (object_list_p == NULL) {
            SX_LOG_ERR("object_list_p is NULL.\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }
    /*if count =0 get all objects per type, start from head */
    if (*object_cnt_p == 0) {
        map_item_p = cl_qmap_head(&span_db.mirror_enable_entries[object_key_p->type].mirror_enable_object_lookup);
        enable_object_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_object_item_t, map_item);
        err = __span_db_mirror_enable_get_port_tc(&enable_object_item_p->object, &log_port, &tc_pg);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get port tc/pg for enable type %u.\n", enable_object_item_p->object.type);
            goto out;
        }
    } else {
        /*if count>0 start from the given object */
        err = __span_db_mirror_enable_get_port_tc(object_key_p, &log_port, &tc_pg);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get port tc/pg for enable type %u.\n", object_key_p->type);
            goto out;
        }
    }
    key = MIRROR_ENABLE_OBJECT_KEY(log_port, tc_pg);

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        map_item_p = cl_qmap_get(&span_db.mirror_enable_entries[object_key_p->type].mirror_enable_object_lookup, key);
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        map_item_p = cl_qmap_head(&span_db.mirror_enable_entries[object_key_p->type].mirror_enable_object_lookup);
        break;

    case SX_ACCESS_CMD_GETNEXT:
        map_item_p = cl_qmap_get_next(&span_db.mirror_enable_entries[object_key_p->type].mirror_enable_object_lookup,
                                      key);
        break;

    /* coverity[dead_error_begin] */
    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

    while (map_item_p != cl_qmap_end(&span_db.mirror_enable_entries[object_key_p->type].mirror_enable_object_lookup)) {
        enable_object_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_object_item_t, map_item);
        err = __span_db_mirror_enable_get_port_tc(&enable_object_item_p->object, &log_port, &tc_pg);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get port tc/pg for enable type %u.\n", enable_object_item_p->object.type);
            goto out;
        }
        if (filter_p != NULL) {
            if (((filter_p->port_filter_valid == SX_SPAN_MIRROR_ENABLE_KEY_PORT_FILTER_VALID_E) &&
                 (log_port != filter_p->port_filter)) ||
                ((filter_p->tc_filter_valid == SX_SPAN_MIRROR_ENABLE_KEY_TC_FILTER_VALID_E) &&
                 ((sx_cos_traffic_class_t)tc_pg != filter_p->tc_filter)) ||
                ((filter_p->pg_filter_valid == SX_SPAN_MIRROR_ENABLE_KEY_PG_FILTER_VALID_E) &&
                 ((sx_cos_priority_group_t)tc_pg != filter_p->pg_filter))) {
                if ((cmd == SX_ACCESS_CMD_GET) && (*object_cnt_p > 0)) {
                    /* Filter not match for GET and object_cnt is not 0 */
                    break;
                } else {
                    /* Filter not match */
                    map_item_p = cl_qmap_next(map_item_p);
                    continue;
                }
            }
        }

        if (*object_cnt_p > 0) {
            object_list_p[db_found_count] = enable_object_item_p->object;
        }
        db_found_count++;
        if (db_found_count == *object_cnt_p) {
            break;
        }
        map_item_p = cl_qmap_next(map_item_p);
    }

    *object_cnt_p = db_found_count;

out:
    SX_LOG_EXIT();
    return err;
}

static void __mirror_trigger_bitmap_to_disallow_list(uint16_t                                mirror_trigger_bitmap,
                                                     uint16_t                                mirror_trigger_set_bitmap,
                                                     sx_span_mirror_trigger_disallow_list_t *mirror_trigger_list)
{
    int i;
    int cnt = 0;

    SX_LOG_ENTER();

    for (i = SX_SPAN_MIRROR_BIND_TYPE_MIN_E; i <= SX_SPAN_MIRROR_BIND_TYPE_MAX_E; i++) {
        if (mirror_trigger_set_bitmap & (1 << i)) {
            mirror_trigger_list->mirror_trigger_disallow[cnt].type = i;
            if (mirror_trigger_bitmap & (1 << i)) {
                mirror_trigger_list->mirror_trigger_disallow[cnt].mirror_trigger_disallow = TRUE;
            } else {
                mirror_trigger_list->mirror_trigger_disallow[cnt].mirror_trigger_disallow = FALSE;
            }
            cnt++;
        }
    }
    mirror_trigger_list->mirror_trigger_disallow_cnt = cnt;

    SX_LOG_EXIT();
}

static void __mirror_trigger_db_to_config_format(sx_port_log_id_t                  log_port,
                                                 uint16_t                          disallow_elp,
                                                 uint16_t                          disallow_elp_sets,
                                                 uint16_t                          disallow_nelp,
                                                 uint16_t                          disallow_nelp_sets,
                                                 sx_span_mirror_enable_port_set_t *mirror_enable_cfg_list_p)
{
    sx_span_mirror_trigger_disallow_list_t mirror_enable_nelp;
    sx_span_mirror_trigger_disallow_list_t mirror_enable_elp;

    SX_LOG_ENTER();
    SX_MEM_CLR_BUF(&mirror_enable_nelp, sizeof(mirror_enable_nelp));
    SX_MEM_CLR_BUF(&mirror_enable_elp, sizeof(mirror_enable_elp));

    __mirror_trigger_bitmap_to_disallow_list(disallow_elp, disallow_elp_sets, &mirror_enable_elp);
    __mirror_trigger_bitmap_to_disallow_list(disallow_nelp, disallow_nelp_sets, &mirror_enable_nelp);

    SX_MEM_CPY_ARRAY(&(mirror_enable_cfg_list_p->mirror_disallow_elephant), &mirror_enable_elp,
                     1, sx_span_mirror_trigger_disallow_list_t);
    SX_MEM_CPY_ARRAY(&(mirror_enable_cfg_list_p->mirror_disallow_non_elephant), &mirror_enable_nelp,
                     1, sx_span_mirror_trigger_disallow_list_t);
    mirror_enable_cfg_list_p->ingress_log_port = log_port;

    SX_LOG_EXIT();
}

sx_status_t span_db_mirror_enable_port_iter_get(const sx_access_cmd_t                     cmd,
                                                sx_port_log_id_t                          log_port,
                                                sx_span_mirror_enable_port_iter_filter_t *filter_p,
                                                sx_span_mirror_enable_port_set_t         *mirror_enable_cfg_list_p,
                                                uint32_t                                 *mirror_enable_cnt_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    cl_map_item_t                  *map_item_p = NULL;
    uint64_t                        key;
    uint32_t                        db_found_count = 0;
    span_mirror_enable_port_item_t *port_item_p = NULL;

    SX_LOG_ENTER();
    UNUSED_PARAM(filter_p);

    if (mirror_enable_cnt_p == NULL) {
        SX_LOG_ERR("mirror_enable_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    key = log_port;

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*mirror_enable_cnt_p == 0) {
            /* count of 0 with GET implies return the total count of ports mirror-enabled */
            *mirror_enable_cnt_p = cl_qmap_count(&span_db.mirror_disallow_map);
            goto out;
        } else {
            map_item_p = cl_qmap_get(&span_db.mirror_disallow_map, key);
            if (map_item_p != cl_qmap_end(&span_db.mirror_disallow_map)) {
                port_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_port_item_t, map_item);
                __mirror_trigger_db_to_config_format(port_item_p->log_port,
                                                     port_item_p->mirror_trigger_disallow_elp,
                                                     port_item_p->mirror_trigger_disallow_elp_sets,
                                                     port_item_p->mirror_trigger_disallow_nelp,
                                                     port_item_p->mirror_trigger_disallow_nelp_sets,
                                                     mirror_enable_cfg_list_p);
                *mirror_enable_cnt_p = 1;
            } else {
                SX_LOG(SX_LOG_INFO, "mirror enable on port 0x%x isn't found.\n", log_port);
                err = SX_STATUS_SUCCESS;

                /* Return Empty List */
                *mirror_enable_cnt_p = 0;
            }
        }
        goto out;
        break;

    case SX_ACCESS_CMD_GET_FIRST:
    /* Fallthrough */
    case SX_ACCESS_CMD_GETNEXT:
        if (*mirror_enable_cnt_p == 0) {
            /* return empty list. */
            SX_LOG(SX_LOG_DEBUG, "[%s] Cmd = %s; but count is 0 return Empty List\n",
                   __func__, sx_access_cmd_str(cmd));
            goto out;
        }
        if (mirror_enable_cfg_list_p == NULL) {
            SX_LOG_ERR("mirror_enable_cfg_list_p is NULL.\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        map_item_p = cl_qmap_get(&span_db.mirror_disallow_map, key);
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        map_item_p = cl_qmap_head(&span_db.mirror_disallow_map);
        break;

    case SX_ACCESS_CMD_GETNEXT:
        map_item_p = cl_qmap_get_next(&span_db.mirror_disallow_map, key);
        break;

    /* coverity[dead_error_begin] */
    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

    while (map_item_p != cl_qmap_end(&span_db.mirror_disallow_map)) {
        port_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_port_item_t, map_item);

        if (*mirror_enable_cnt_p > 0) {
            __mirror_trigger_db_to_config_format(port_item_p->log_port,
                                                 port_item_p->mirror_trigger_disallow_elp,
                                                 port_item_p->mirror_trigger_disallow_elp_sets,
                                                 port_item_p->mirror_trigger_disallow_nelp,
                                                 port_item_p->mirror_trigger_disallow_nelp_sets,
                                                 mirror_enable_cfg_list_p + db_found_count);
        }
        db_found_count++;
        if (db_found_count == *mirror_enable_cnt_p) {
            break;
        }
        map_item_p = cl_qmap_next(map_item_p);
    }

    *mirror_enable_cnt_p = db_found_count;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_enable_port_set(sx_port_log_id_t                              log_port,
                                           const sx_span_mirror_trigger_disallow_list_t *disallow_elephant,
                                           const sx_span_mirror_trigger_disallow_list_t *disallow_none_elephant)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    cl_map_item_t                  *map_item_p = NULL;
    cl_pool_item_t                 *pool_item_p = NULL;
    span_mirror_enable_port_item_t *port_item_p = NULL;
    uint64_t                        key = 0;
    uint32_t                        i = 0;
    uint16_t                        existing_disallow_nelp = 0;
    uint16_t                        existing_disallow_elp = 0;
    uint16_t                        disallow_nelp = 0;
    uint16_t                        disallow_elp = 0;
    uint16_t                        disallow_nelp_sets = 0;
    uint16_t                        disallow_elp_sets = 0;

    SX_LOG_ENTER();

    if (disallow_elephant == NULL) {
        SX_LOG_ERR("disallow_elephant is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (disallow_none_elephant == NULL) {
        SX_LOG_ERR("disallow_none_elephant is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    key = log_port;

    map_item_p = cl_qmap_get(&span_db.mirror_disallow_map, key);
    if (map_item_p != cl_qmap_end(&span_db.mirror_disallow_map)) {
        port_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_port_item_t, map_item);
        existing_disallow_elp = port_item_p->mirror_trigger_disallow_elp;
        existing_disallow_nelp = port_item_p->mirror_trigger_disallow_nelp;
        disallow_nelp_sets = port_item_p->mirror_trigger_disallow_nelp_sets;
        disallow_elp_sets = port_item_p->mirror_trigger_disallow_elp_sets;
    }

    disallow_elp = existing_disallow_elp;
    disallow_nelp = existing_disallow_nelp;

    for (i = 0; i < disallow_elephant->mirror_trigger_disallow_cnt; i++) {
        if (disallow_elephant->mirror_trigger_disallow[i].mirror_trigger_disallow) {
            disallow_elp |= (1UL << (disallow_elephant->mirror_trigger_disallow[i].type));
        } else {
            disallow_elp &= ~(1UL << (disallow_elephant->mirror_trigger_disallow[i].type));
        }
        disallow_elp_sets |= (1UL << (disallow_elephant->mirror_trigger_disallow[i].type));
    }
    for (i = 0; i < disallow_none_elephant->mirror_trigger_disallow_cnt; i++) {
        if (disallow_none_elephant->mirror_trigger_disallow[i].mirror_trigger_disallow) {
            disallow_nelp |= (1UL << (disallow_none_elephant->mirror_trigger_disallow[i].type));
        } else {
            disallow_nelp &= ~(1UL << (disallow_none_elephant->mirror_trigger_disallow[i].type));
        }
        disallow_nelp_sets |= (1UL << (disallow_none_elephant->mirror_trigger_disallow[i].type));
    }

    if ((disallow_elp == existing_disallow_elp) && (disallow_nelp == existing_disallow_nelp)) {
        goto out;
    }

    /* set the fw */
    err = __span_db_fw_mirror_enable_port_set(log_port, disallow_nelp, disallow_elp);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set conditional mirror enable for log_port 0x%x to FW.\n", log_port);
        goto out;
    }

    if (port_item_p) {
        port_item_p->mirror_trigger_disallow_nelp = disallow_nelp;
        port_item_p->mirror_trigger_disallow_elp = disallow_elp;
        port_item_p->mirror_trigger_disallow_nelp_sets = disallow_nelp_sets;
        port_item_p->mirror_trigger_disallow_elp_sets = disallow_elp_sets;
    } else {
        pool_item_p = cl_qpool_get(&span_db.mirror_enable_port_pool);
        if (pool_item_p == NULL) {
            SX_LOG_ERR("Couldn't create a new span_mirror_enable_port_item_t entry (No Resources)\n");
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }
        port_item_p = PARENT_STRUCT(pool_item_p, span_mirror_enable_port_item_t, pool_item);
        port_item_p->log_port = log_port;
        port_item_p->mirror_trigger_disallow_nelp = disallow_nelp;
        port_item_p->mirror_trigger_disallow_elp = disallow_elp;
        port_item_p->mirror_trigger_disallow_nelp_sets = disallow_nelp_sets;
        port_item_p->mirror_trigger_disallow_elp_sets = disallow_elp_sets;
        cl_qmap_insert(&span_db.mirror_disallow_map, key, &port_item_p->map_item);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_mirror_enable_port_unset(sx_port_log_id_t                              log_port,
                                             const sx_span_mirror_trigger_disallow_list_t *disallow_elephant,
                                             const sx_span_mirror_trigger_disallow_list_t *disallow_none_elephant)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    cl_map_item_t                  *map_item_p = NULL;
    span_mirror_enable_port_item_t *port_item_p = NULL;
    uint64_t                        key = 0;
    uint32_t                        i = 0;
    uint16_t                        existing_disallow_nelp = 0;
    uint16_t                        existing_disallow_elp = 0;
    uint16_t                        disallow_nelp = 0;
    uint16_t                        disallow_elp = 0;
    uint16_t                        disallow_nelp_sets = 0;
    uint16_t                        disallow_elp_sets = 0;

    SX_LOG_ENTER();

    if (disallow_elephant == NULL) {
        SX_LOG_ERR("disallow_elephant is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (disallow_none_elephant == NULL) {
        SX_LOG_ERR("disallow_none_elephant is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    key = log_port;

    map_item_p = cl_qmap_get(&span_db.mirror_disallow_map, key);
    if (map_item_p != cl_qmap_end(&span_db.mirror_disallow_map)) {
        port_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_port_item_t, map_item);
        existing_disallow_elp = port_item_p->mirror_trigger_disallow_elp;
        existing_disallow_nelp = port_item_p->mirror_trigger_disallow_nelp;
        disallow_nelp_sets = port_item_p->mirror_trigger_disallow_nelp_sets;
        disallow_elp_sets = port_item_p->mirror_trigger_disallow_elp_sets;
    } else {
        SX_LOG_ERR("Conditional Mirroring config on log port 0x%x does not exists.\n", log_port);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    disallow_elp = existing_disallow_elp;
    disallow_nelp = existing_disallow_nelp;

    for (i = 0; i < disallow_elephant->mirror_trigger_disallow_cnt; i++) {
        if ((disallow_elp_sets & (1UL << (disallow_elephant->mirror_trigger_disallow[i].type))) == 0) {
            SX_LOG_ERR("Cannot unset the mirror trigger type (%d, elephant) not set on log port 0x%x before.\n",
                       disallow_elephant->mirror_trigger_disallow[i].type,
                       log_port);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        disallow_elp &= ~(1UL << (disallow_elephant->mirror_trigger_disallow[i].type));
        disallow_elp_sets &= ~(1UL << (disallow_elephant->mirror_trigger_disallow[i].type));
    }
    for (i = 0; i < disallow_none_elephant->mirror_trigger_disallow_cnt; i++) {
        if ((disallow_nelp_sets & (1UL << (disallow_none_elephant->mirror_trigger_disallow[i].type))) == 0) {
            SX_LOG_ERR("Cannot unset the mirror trigger type (%d, none-elephant) not set on log port 0x%x before.\n",
                       disallow_none_elephant->mirror_trigger_disallow[i].type,
                       log_port);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        disallow_nelp &= ~(1UL << (disallow_none_elephant->mirror_trigger_disallow[i].type));
        disallow_nelp_sets &= ~(1UL << (disallow_none_elephant->mirror_trigger_disallow[i].type));
    }

    if ((disallow_elp == existing_disallow_elp) && (disallow_nelp == existing_disallow_nelp)) {
        goto out;
    }

    if ((disallow_elp_sets == 0) && (disallow_nelp_sets == 0)) {
        if (disallow_elp || disallow_nelp) {
            SX_LOG_ERR(
                "Conditional mirror enable DB on log port 0x%x is wrong. Settings: (elephant: 0x%x, none-elephant: 0x%x).\n",
                log_port,
                disallow_elp,
                disallow_nelp);
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

    /* set the fw */
    err = __span_db_fw_mirror_enable_port_set(log_port, disallow_nelp, disallow_elp);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set conditional mirror enable for log_port 0x%x to FW.\n", log_port);
        goto out;
    }

    if ((disallow_elp_sets == 0) && (disallow_nelp_sets == 0)) {
        cl_qmap_remove_item(&span_db.mirror_disallow_map, map_item_p);
        cl_qpool_put(&(span_db.mirror_enable_port_pool), &(port_item_p->pool_item));
        goto out;
    }

    port_item_p->mirror_trigger_disallow_nelp = disallow_nelp;
    port_item_p->mirror_trigger_disallow_elp = disallow_elp;
    port_item_p->mirror_trigger_disallow_nelp_sets = disallow_nelp_sets;
    port_item_p->mirror_trigger_disallow_elp_sets = disallow_elp_sets;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_mirror_port_prob_rate_fw_set(const sx_port_log_id_t          *port_list_p,
                                                          const uint32_t                   port_list_num,
                                                          const sx_span_session_id_int_t   span_session_id,
                                                          const span_mirror_direction_t    mirror_direction,
                                                          const sx_span_probability_rate_t rate)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    for (i = 0; i < port_list_num; i++) {
        status = __span_db_fw_mirror_port_set(port_list_p[i],
                                              span_session_id,
                                              mirror_direction,
                                              rate,
                                              TRUE);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("__span_db_fw_mirror_port_set(log_port 0x%x, SPAN id: %d, dir:%d, rate: %u ) failed. err: %s\n",
                       port_list_p[i], span_session_id, mirror_direction, rate, sx_status_str(status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t span_db_mirror_port_prob_rate_set(sx_port_log_id_t                      log_port,
                                              const sx_port_usr_probability_rate_t *usr_probability_rate_p)
{
    sx_status_t             status = SX_STATUS_SUCCESS;
    sx_mirror_direction_t   mirror_direction;
    span_mirror_direction_t full_mirror_direction;
    sx_port_info_t          port_info;
    cl_map_item_t          *map_item_p = NULL;
    span_mirror_map_item_t *span_mirror_port_item_p = NULL;
    uint32_t                port_num = 0, i = 0;
    sx_port_id_t            port_list[MAX_LAG_MEMBERS_NUM + 1]; /* '+ 1' Used to store the log_port itself */
    sx_port_type_t          port_type = SX_PORT_TYPE_ID_GET(log_port);

    SX_LOG_ENTER();

    if (port_type == SX_PORT_TYPE_LAG) {
        /* Get all LAG port members */
        port_num = rm_resource_global.lag_port_members_max;
        SX_MEM_CLR_ARRAY(port_list, port_num,  port_num);
        status = sx_lag_port_group_get(log_port, port_list, &port_num);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to access LAG DB, log_port 0x%08X, err: %s\n",
                       log_port, sx_status_str(status));
            goto out;
        }
    }

    /* Set probability rate attribute for log_id and for each lag member (if its LAG with members) */
    port_list[port_num] = log_port;
    port_num++;

    mirror_direction = usr_probability_rate_p->key.mirror_direction;

    /* Update the SDK DB */
    for (i = 0; i < port_num; i++) {
        SX_MEM_CLR(port_info);

        status = port_db_info_get(port_list[i], &port_info);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", port_list[i]);
            goto out;
        }

        port_info.usr_probability_rate[mirror_direction -
                                       SX_SPAN_MIRROR_DIRECTION_MIN].rate = usr_probability_rate_p->attr.rate;
        port_info.fields = SX_PORT_INFO_FIELD_BIT_PROBABILITY_RATE;
        status = port_db_info_set(port_list[i], &port_info, NULL);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("port_db_info_set failed. (err = %s).\n", sx_status_str(status));
            goto out;
        }
    }

    /* Update the FW
     * Apply the probability rate only if the log_port (local port or the LAG) is bound to a SPAN session */
    status = span_cnv_simple_to_full_mirror_direction(mirror_direction, &full_mirror_direction);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Unsupported mirror direction %u, err: %s.\n",
                   mirror_direction, sx_status_str(status));
        goto out;
    }

    status = span_db_mirror_port_find(log_port, full_mirror_direction, &map_item_p);
    if (SX_CHECK_FAIL(status)) {
        /* Log port isn't bound to a SPAN session. No need set FW */
        status = SX_STATUS_SUCCESS;
    } else {
        /* Get the SPAN session ID*/
        span_mirror_port_item_p = PARENT_STRUCT(map_item_p, span_mirror_map_item_t, map_item);

        if (port_type == SX_PORT_TYPE_LAG) {
            /* Apply the probability rate for the LAG members, exclude the LAG logical ID */
            port_num--;
        }

        status = __span_db_mirror_port_prob_rate_fw_set(port_list,
                                                        port_num,
                                                        span_mirror_port_item_p->span_mirror_record.pa_id,
                                                        full_mirror_direction,
                                                        usr_probability_rate_p->attr.rate);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed apply the mirror port 0x%08X probability rate %u, err: %s.\n", log_port,
                       usr_probability_rate_p->attr.rate, sx_status_str(status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t span_db_mirror_port_prob_rate_get(sx_port_log_id_t                log_port,
                                              sx_port_usr_probability_rate_t *usr_probability_rate_p)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    sx_mirror_direction_t mirror_direction;
    sx_port_info_t        port_info;

    SX_LOG_ENTER();

    status = port_db_info_get(log_port, &port_info);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", log_port);
        goto out;
    }

    mirror_direction = usr_probability_rate_p->key.mirror_direction;
    usr_probability_rate_p->attr.rate =
        port_info.usr_probability_rate[mirror_direction - SX_SPAN_MIRROR_DIRECTION_MIN].rate;

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t span_db_mirror_tables_attr_set(const sx_access_cmd_t cmd, const sx_span_mirror_tables_attr_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (SPAN_NO_SESSION == g_mirror_tables_session) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Set or delete probability rate to table mirror */
    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        g_mirror_tables_probability_rate = attr_p->rate;
        break;

    case SX_ACCESS_CMD_DELETE:
        g_mirror_tables_probability_rate = SPAN_DEFAULT_PROBABILITY_RATE;
        break;

    default:
        SX_LOG_ERR("Invalid access command [%s]\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = host_ifc_trap_group_span_probability_rate_set(attr_p->rate);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("span_db_mirror_tables_attr_set(probability rate [%d], ...)  failed. err: %s\n",
                   attr_p->rate, sx_status_str(err));
        goto out;
    }

out:
    return err;
}

sx_status_t span_db_mirror_tables_attr_get(sx_span_mirror_tables_attr_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (SPAN_NO_SESSION == g_mirror_tables_session) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    attr_p->rate = g_mirror_tables_probability_rate;

out:
    return err;
}

sx_status_t span_db_attributes_get(sx_span_attrs_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *attr_p = span_db.span_attrs;

    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_attributes_set(sx_span_attrs_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    span_db.span_attrs.device_uid = attr_p->device_uid;

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_db_validate_user_handle(span_client_handle_t user_handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx;

    SX_LOG_ENTER();

    /* Check for null pointer */
    if (!user_handle) {
        SX_LOG_WRN("Handle NULL!\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Check for outside table range */
    if (((span_user_t*)user_handle < &span_db.user[0]) ||
        ((span_user_t*)user_handle >= &span_db.user[SPAN_DB_MAX_USERS])) {
        SX_LOG_WRN("Handle %p not in valid range!\n", user_handle);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Check inside table but not aligned with an entry */
    idx = (span_user_t*)user_handle - span_db.user;
    if ((span_user_t*)user_handle != &span_db.user[idx]) {
        SX_LOG_WRN("Handle %p is not aligned!\n", user_handle);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Verify that this user is allocated */
    if (!span_db.user[idx].used) {
        SX_LOG_WRN("Handle %p not active\n", user_handle);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_ref_cnt_inc(span_client_handle_t           user_handle,
                                        const sx_span_session_id_int_t span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Validate handle */
    err = __span_db_validate_user_handle(user_handle);
    if (err) {
        goto out;
    }

    /* Verify session ID */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id)) {
        SX_LOG_ERR("Invalid internal SPAN session id %d.\n", span_session_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
        SX_LOG_ERR("Internal SPAN session id %d not in use.\n", span_session_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Increment session reference count */
    span_db.sx_span_sessions[span_session_id].span_session_info.ref_cnt++;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_ref_cnt_dec(span_client_handle_t           user_handle,
                                        const sx_span_session_id_int_t span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Validate handle */
    err = __span_db_validate_user_handle(user_handle);
    if (err) {
        goto out;
    }

    /* Verify session ID */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id)) {
        SX_LOG_ERR("Invalid internal SPAN session id %d.\n", span_session_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (span_db.sx_span_sessions[span_session_id].used == FALSE) {
        SX_LOG_ERR("Internal SPAN session id %d not in use.\n", span_session_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Decrement session reference count */
    if (span_db.sx_span_sessions[span_session_id].span_session_info.ref_cnt > 0) {
        span_db.sx_span_sessions[span_session_id].span_session_info.ref_cnt--;
    } else {
        SX_LOG_WRN("Reference count for SPAN session id %d is already zero.\n",
                   span_session_id);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_lock(span_client_handle_t       user_handle,
                                 const sx_span_session_id_t span_session_id,
                                 sx_span_session_id_int_t  *span_session_id_int)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Validate handle */
    err = __span_db_validate_user_handle(user_handle);
    if (err) {
        goto out;
    }

    /* Validate output pointer */
    if (span_session_id_int == NULL) {
        SX_LOG_ERR("Null pointer for internal session\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Look up external session */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id)) {
        SX_LOG_ERR("invalid external session id %u\n", span_session_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Verify not already locked */
    if (span_db.locked[span_session_id]) {
        SX_LOG_ERR("SPAN session %d is already locked.\n",
                   span_session_id);
        err = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* Lock the session */
    span_db.locked[span_session_id] = TRUE;

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(*span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, *span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_unlock(span_client_handle_t user_handle, const sx_span_session_id_t span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Validate handle */
    err = __span_db_validate_user_handle(user_handle);
    if (err) {
        goto out;
    }

    /* Look up external session */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id)) {
        SX_LOG_ERR("invalid external session id %u\n", span_session_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Verify not already unlocked */
    if (!span_db.locked[span_session_id]) {
        SX_LOG_WRN("SPAN session %d is already unlocked.\n",
                   span_session_id);
        goto out;
    }

    /* Unlock the session */
    span_db.locked[span_session_id] = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_session_is_locked(const sx_span_session_id_t span_session_id, boolean_t                  *locked)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Validate output pointer */
    if (locked == NULL) {
        SX_LOG_ERR("Null pointer for locked\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Look up external session */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id)) {
        SX_LOG_ERR("invalid external session id %u\n", span_session_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Check whether locked */
    *locked = span_db.locked[span_session_id];

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_user_init(span_cb_relocate_t cb_relocate, span_client_handle_t  *user_handle_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx;

    SX_LOG_ENTER();

    /* Validate parameters */
    if (!user_handle_p) {
        SX_LOG_ERR("Null handle.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Allow null callback, it will not be called */

    /* Find a free user slot */
    for (idx = 0; idx < SPAN_DB_MAX_USERS; idx++) {
        if (!span_db.user[idx].used) {
            span_db.user[idx].used = TRUE;
            span_db.user[idx].cb_relocate = cb_relocate;
            *user_handle_p = &span_db.user[idx];
            break;
        }
    }

    /* Fail if no free slot */
    if (idx >= SPAN_DB_MAX_USERS) {
        SX_LOG_ERR("Maximum SPAN users exceeded.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_user_deinit(span_client_handle_t user_handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx;

    SX_LOG_ENTER();

    /* Validate handle */
    err = __span_db_validate_user_handle(user_handle);
    if (err) {
        goto out;
    }

    /* Derive index from valid user handle */
    idx = (span_user_t*)user_handle - span_db.user;

    /* Deinit - Don't clear associated data for debug */
    span_db.user[idx].used = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_db_advise_relocate(const sx_span_session_id_t     span_session_id,
                                    const sx_span_session_id_int_t old_span_session_id_int,
                                    const sx_span_session_id_int_t new_span_session_id_int)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx;

    SX_LOG_ENTER();

    /* Inform all registered modules */
    for (idx = 0; idx < SPAN_DB_MAX_USERS; idx++) {
        if (span_db.user[idx].used) {
            if (span_db.user[idx].cb_relocate) {
                err = span_db.user[idx].cb_relocate(span_session_id,
                                                    old_span_session_id_int,
                                                    new_span_session_id_int);
                if (err) {
                    SX_LOG_ERR("Callback #%u remapping SPAN session %u from %u to %u, rc = %s.\n",
                               idx, span_session_id, old_span_session_id_int,
                               new_span_session_id_int, sx_status_str(err));
                    goto out;
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

void span_db_header_version_set(const sx_span_mirror_header_version_t version)
{
    g_mirror_header_version = version;
}

sx_span_mirror_header_version_t span_db_header_version_get(void)
{
    return g_mirror_header_version;
}

static sx_status_t __span_db_dump_globals(dbg_dump_params_t *dbg_dump_params_p)
{
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "Session for table mirroring:",
                                   &g_mirror_tables_session, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "Header version:",
                                   &g_mirror_header_version, PARAM_UINT32_E);
    return SX_STATUS_SUCCESS;
}

static void __span_db_dump_span_type_part(dbg_dump_params_t *dbg_dump_params_p, char * type_name)
{
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "SPAN Type:", type_name, PARAM_STRING_E);
}

static void __span_db_dump_mac_part(dbg_dump_params_t *dbg_dump_params_p, sx_mac_addr_t * mac)
{
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "MAC:", mac, PARAM_MAC_ADDR_E);
}

static void __span_db_dump_qos_swprio_part(dbg_dump_params_t *dbg_dump_params_p,
                                           sx_span_qos_mode_t qos_mode,
                                           uint8_t            switch_prio)
{
    char s[SPAN_STRING_BUF_SIZE];

    switch (qos_mode) {
    case SX_SPAN_QOS_CONFIGURED:
        strncpy(s, "CONFIGURED", SPAN_STRING_BUF_SIZE);
        break;

    case SX_SPAN_QOS_MAINTAIN:
        strncpy(s, "MAINTAIN", SPAN_STRING_BUF_SIZE);
        break;

    default:
        snprintf(s, SPAN_STRING_BUF_SIZE, "Invalid %u", qos_mode);
        break;
    }
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "QOS Mode:", s, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "Switch Prio:", &switch_prio, PARAM_UINT8_E);
}

static void __span_db_dump_vid_ethtype_pcp_dei_part(dbg_dump_params_t *dbg_dump_params_p,
                                                    sx_vlan_id_t       vid,
                                                    uint8_t            vlan_ethertype_id,
                                                    sx_cos_pcp_t       pcp,
                                                    sx_cos_dei_t       dei)
{
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "VID:", &vid, PARAM_UINT16_E);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "VLAN Ethertype ID:", &vlan_ethertype_id, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "PCP:", &pcp, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "DEI:", &dei, PARAM_UINT8_E);
}

static void __span_db_dump_tp_part(dbg_dump_params_t *dbg_dump_params_p, uint8_t tp)
{
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "TP:", &tp, PARAM_UINT8_E);
}

static void __span_db_dump_ip_part(dbg_dump_params_t *dbg_dump_params_p, char             * name,
                                   sx_ip_addr_t     * ip)
{
    dbg_utils_param_type_e param_type;
    void                 * data;
    char                   s[SPAN_STRING_BUF_SIZE];

    if (ip->version == SX_IP_VERSION_IPV4) {
        param_type = PARAM_IPV4_E;
        data = &ip->addr.ipv4.s_addr;
    } else if (ip->version == SX_IP_VERSION_IPV6) {
        param_type = PARAM_IPV6_E;
        data = &ip->addr.ipv6.s6_addr32[0];
    } else {
        snprintf(s, SPAN_STRING_BUF_SIZE, "Invalid IP version %u", ip->version);
        param_type = PARAM_STRING_E;
        data = s;
    }
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, name, data, param_type);
}

static void __span_db_dump_smac_ips_dscp_ecn_ttl_part(dbg_dump_params_t *dbg_dump_params_p,
                                                      sx_mac_addr_t    * smac,
                                                      sx_ip_addr_t     * dest_ip,
                                                      sx_ip_addr_t     * src_ip,
                                                      uint8_t            dscp,
                                                      sx_cos_ecn_t       ecn,
                                                      uint8_t            ttl)
{
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "SMAC:", smac, PARAM_MAC_ADDR_E);
    __span_db_dump_ip_part(dbg_dump_params_p, "Dest IP:", dest_ip);
    __span_db_dump_ip_part(dbg_dump_params_p, "Src IP:", src_ip);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "DSCP:", &dscp, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "ECN:", &ecn, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "TTL:", &ttl, PARAM_UINT8_E);
}

static sx_status_t __span_db_dump_span_type_format(dbg_dump_params_t      *dbg_dump_params_p,
                                                   sx_span_type_t          span_type,
                                                   sx_span_type_format_t * span_format)
{
    char s[SPAN_STRING_BUF_SIZE];

    switch (span_type) {
    case SX_SPAN_TYPE_LOCAL_IB:
        __span_db_dump_span_type_part(dbg_dump_params_p, "LOCAL_IB");
        break;

    case SX_SPAN_TYPE_LOCAL_ETH_TYPE1:
        __span_db_dump_span_type_part(dbg_dump_params_p, "LOCAL_ETH_TYPE1");
        __span_db_dump_qos_swprio_part(dbg_dump_params_p,
                                       span_format->local_eth_type1.qos_mode,
                                       span_format->local_eth_type1.switch_prio);
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1:
        __span_db_dump_span_type_part(dbg_dump_params_p, "REMOTE_ETH_VLAN_TYPE1");
        __span_db_dump_qos_swprio_part(dbg_dump_params_p,
                                       span_format->remote_eth_vlan_type1.qos_mode,
                                       span_format->remote_eth_vlan_type1.switch_prio);
        __span_db_dump_vid_ethtype_pcp_dei_part(dbg_dump_params_p,
                                                span_format->remote_eth_vlan_type1.vid,
                                                span_format->remote_eth_vlan_type1.vlan_ethertype_id,
                                                span_format->remote_eth_vlan_type1.pcp,
                                                span_format->remote_eth_vlan_type1.dei);
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1:
        __span_db_dump_span_type_part(dbg_dump_params_p, "REMOTE_ETH_L2_TYPE1");
        __span_db_dump_qos_swprio_part(dbg_dump_params_p,
                                       span_format->remote_eth_l2_type1.qos_mode,
                                       span_format->remote_eth_l2_type1.switch_prio);
        __span_db_dump_vid_ethtype_pcp_dei_part(dbg_dump_params_p,
                                                span_format->remote_eth_l2_type1.vid,
                                                span_format->remote_eth_l2_type1.vlan_ethertype_id,
                                                span_format->remote_eth_l2_type1.pcp,
                                                span_format->remote_eth_l2_type1.dei);
        __span_db_dump_tp_part(dbg_dump_params_p, span_format->remote_eth_l2_type1.tp);
        __span_db_dump_mac_part(dbg_dump_params_p, &span_format->remote_eth_l2_type1.mac);
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1:
        __span_db_dump_span_type_part(dbg_dump_params_p, "REMOTE_ETH_L3_TYPE1");
        __span_db_dump_qos_swprio_part(dbg_dump_params_p,
                                       span_format->remote_eth_l3_type1.qos_mode,
                                       span_format->remote_eth_l3_type1.switch_prio);
        __span_db_dump_vid_ethtype_pcp_dei_part(dbg_dump_params_p,
                                                span_format->remote_eth_l3_type1.vid,
                                                span_format->remote_eth_l3_type1.vlan_ethertype_id,
                                                span_format->remote_eth_l3_type1.pcp,
                                                span_format->remote_eth_l3_type1.dei);
        __span_db_dump_tp_part(dbg_dump_params_p, span_format->remote_eth_l3_type1.tp);
        __span_db_dump_mac_part(dbg_dump_params_p, &span_format->remote_eth_l3_type1.mac);
        __span_db_dump_smac_ips_dscp_ecn_ttl_part(dbg_dump_params_p,
                                                  &span_format->remote_eth_l3_type1.smac,
                                                  &span_format->remote_eth_l3_type1.dest_ip,
                                                  &span_format->remote_eth_l3_type1.src_ip,
                                                  span_format->remote_eth_l3_type1.dscp,
                                                  span_format->remote_eth_l3_type1.ecn,
                                                  span_format->remote_eth_l3_type1.ttl);
        break;

    default:
        snprintf(s, SPAN_STRING_BUF_SIZE, "Invalid %u", span_type);
        __span_db_dump_span_type_part(dbg_dump_params_p, s);
        break;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __span_db_dump_session_params(dbg_dump_params_t         *dbg_dump_params_p,
                                                 sx_span_session_params_t * params)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    char        s[SPAN_SMALL_STRING_BUF_SIZE + 1];

    dbg_utils_pprinter_secondary_header_print(dbg_dump_params_p->stream, "SPAN params");
    strncpy(s, params->truncate ? "YES" : "NO", SPAN_SMALL_STRING_BUF_SIZE);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "Truncate:", s, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "Truncation Size:", &params->truncate_size,
                                   PARAM_UINT16_E);

    strncpy(s, params->padding ? "2 BYTES PADDING" : "NO PADDING", SPAN_SMALL_STRING_BUF_SIZE);
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "Header Padding:", s, PARAM_STRING_E);

    sx_status = __span_db_dump_span_type_format(dbg_dump_params_p,
                                                params->span_type,
                                                &params->span_type_format);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    return SX_STATUS_SUCCESS;
}

static sx_status_t __span_db_dump_session(dbg_dump_params_t *dbg_dump_params_p,
                                          span_session_t   * session,
                                          uint32_t           mirrors_num,
                                          span_mirror_t    * mirrors_arr)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    uint32_t                  i;
    sx_mirror_direction_t     mirror_direction = SX_SPAN_MIRROR_EGRESS;
    boolean_t                 admin_state;
    char                      admin_state_str[SPAN_SMALL_STRING_BUF_SIZE + 1] = {0};
    char                      s[SPAN_STRING_BUF_SIZE + 1] = {0};
    char                     *s_ptr;
    uint32_t                  s_len;
    uint32_t                  s_left;
    sx_span_drop_reason_t     reason;
    sx_port_log_id_t          mirror_port;
    dbg_utils_table_columns_t mirror_port_clmns[] = {
        { "Mirror port",    11,    PARAM_PORT_ID_E,     &mirror_port},
        { "Direction",      21,    PARAM_STRING_E,  s},
        { "Admin state",    11,    PARAM_STRING_E,  admin_state_str},
        {NULL, 0, 0, NULL}
    };
    FILE                     *stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_field_print(stream, "PA ID:", &session->span_session_info.pa_id, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Session ID:", &session->span_session_info.session_id, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Manager Type:", &session->span_session_info.mngr_type, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Analyzer Port:", &session->analyzer_port, PARAM_HEX_E);
    dbg_utils_pprinter_field_print(stream, "Analyzer Multiport Number:", &session->multiport_num, PARAM_UINT8_E);
    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        snprintf(s, SPAN_STRING_BUF_SIZE, "Analyzer Multiport[%u]:", i);
        dbg_utils_pprinter_field_print(stream, s, &session->analyzer_multiport[i], PARAM_HEX_E);
    }

    dbg_utils_pprinter_field_print(stream, "System Port:", &session->span_session_info.system_port, PARAM_HEX16_E);
    dbg_utils_pprinter_field_print(stream, "Is Multiport:", &session->span_session_info.is_multiport, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "Multiport nmp:", &session->span_session_info.multiport_nmp, PARAM_UINT8_E);
    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        snprintf(s, SPAN_STRING_BUF_SIZE, "System Multiport[%u]:", i);
        dbg_utils_pprinter_field_print(stream, s, &session->span_session_info.multiport[i], PARAM_HEX16_E);
    }
    dbg_utils_pprinter_field_print(stream, "Best Effort:", &session->span_session_info.be, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Stacking Class:", &session->span_session_info.stclass, PARAM_UINT8_E);
    strncpy(s, session->span_session_info.admin_state ? "UP" : "DOWN", SPAN_STRING_BUF_SIZE);
    dbg_utils_pprinter_field_print(stream, "Admin State:", s, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream, "Multiport Traffic Class:", &session->span_session_info.tclass,
                                   PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(stream, "Multiport Switch Priority:", &session->span_session_info.switch_prio,
                                   PARAM_UINT8_E);
    switch (session->span_session_info.port_params.cng_mng) {
    case SX_SPAN_CNG_MNG_DONT_DISCARD:
        strncpy(s, "DON'T DISCARD", SPAN_STRING_BUF_SIZE);
        break;

    case SX_SPAN_CNG_MNG_DISCARD:
        strncpy(s, "DISCARD", SPAN_STRING_BUF_SIZE);
        break;

    default:
        snprintf(s, SPAN_STRING_BUF_SIZE, "Invalid %u", session->span_session_info.port_params.cng_mng);
        break;
    }
    dbg_utils_pprinter_field_print(stream, "Congestion:", s, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream, "Reference Count:", &session->span_session_info.ref_cnt, PARAM_UINT32_E);
    strncpy(s, session->span_session_info.truncate ? "YES" : "NO", SPAN_STRING_BUF_SIZE);
    dbg_utils_pprinter_field_print(stream, "Truncate:", s, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Truncation Size:",
                                   &session->span_session_info.truncation_size,
                                   PARAM_UINT16_E);
    strncpy(s, session->span_session_info.policer_enable ? "YES" : "NO", SPAN_STRING_BUF_SIZE - 1);
    dbg_utils_pprinter_field_print(stream, "Policer:", s, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream, "Policer ID:", &session->span_session_info.policer_id, PARAM_UINT64_E);
    strncpy(s, session->span_session_info.drop_mirror.trap_group_valid ? "YES" : "NO", SPAN_STRING_BUF_SIZE - 1);
    dbg_utils_pprinter_field_print(stream, "Drop Mirroring:", s, PARAM_STRING_E);
    if (session->span_session_info.drop_mirror.trap_group_valid) {
        dbg_utils_pprinter_field_print(stream, "Drop Mirroring Trap Group:",
                                       &session->span_session_info.drop_mirror.trap_group, PARAM_UINT32_E);
        s[0] = '\0';
        s_ptr = s;
        s_left = sizeof(s);
        for (i = 0; i < session->span_session_info.drop_mirror.drop_reasons_count; i++) {
            reason = session->span_session_info.drop_mirror.drop_reasons[i];
            s_len = snprintf(s_ptr, s_left, "%s ", sx_span_drop_reason_str(reason));
            s_ptr += s_len;
            if (s_len > s_left) {
                SX_LOG_ERR("Couldn't dump all Drop reasons, no more space in the buffer\n");
                break;
            } else {
                s_left -= s_len;
            }
        }
        dbg_utils_pprinter_field_print(stream, "Drop Reasons:", s, PARAM_STRING_E);
    }

    sx_status = __span_db_dump_span_type_format(dbg_dump_params_p,
                                                session->span_session_info.span_type,
                                                &session->span_session_info.span_type_format);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = __span_db_dump_session_params(dbg_dump_params_p, &session->span_session_info.params);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    dbg_utils_pprinter_table_headline_print(stream, mirror_port_clmns);
    for (i = 0; i < mirrors_num; i++) {
        mirror_port = mirrors_arr[i].log_port;
        switch (mirrors_arr[i].mirror_direction) {
        case SPAN_MIRROR_DIRECTION_EGRESS:
            mirror_direction = SX_SPAN_MIRROR_EGRESS;
            strncpy(s, "EGRESS", SPAN_STRING_BUF_SIZE);
            break;

        case SPAN_MIRROR_DIRECTION_INGRESS:
            mirror_direction = SX_SPAN_MIRROR_INGRESS;
            strncpy(s, "INGRESS", SPAN_STRING_BUF_SIZE);
            break;

        case SPAN_MIRROR_DIRECTION_INGRESS_WRED:
            mirror_direction = SX_SPAN_MIRROR_INGRESS;
            strncpy(s, "INGRESS_WRED", SPAN_STRING_BUF_SIZE);
            break;

        case SPAN_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER:
            mirror_direction = SX_SPAN_MIRROR_INGRESS;
            strncpy(s, "INGRESS_SHARED_BUFFER", SPAN_STRING_BUF_SIZE);
            break;

        case SPAN_MIRROR_DIRECTION_INGRESS_PG_CONGESTION:
            mirror_direction = SX_SPAN_MIRROR_INGRESS;
            strncpy(s, "INGRESS_PG_CONGESTION", SPAN_STRING_BUF_SIZE);
            break;

        case SPAN_MIRROR_DIRECTION_INGRESS_TC_CONGESTION:
            mirror_direction = SX_SPAN_MIRROR_INGRESS;
            strncpy(s, "INGRESS_TC_CONGESTION", SPAN_STRING_BUF_SIZE);
            break;

        case SPAN_MIRROR_DIRECTION_EGRESS_TC_LATENCY:
            mirror_direction = SX_SPAN_MIRROR_EGRESS;
            strncpy(s, "EGRESS_TC_LATENCY", SPAN_STRING_BUF_SIZE);
            break;

        default:
            snprintf(s, SPAN_STRING_BUF_SIZE, "Invalid %u", mirrors_arr[i].mirror_direction);
            break;
        }
        /* Get port admin state */
        if (mirror_port == 0) {
            /* Not mirror port but mirror binding */
            strncpy(admin_state_str, "N/A", SPAN_SMALL_STRING_BUF_SIZE);
        } else {
            /* sx_status = span_mirror_state_get(mirror_port, mirror_direction, &admin_state); */
            UNUSED_PARAM(mirror_direction);
            sx_status = span_mirror_state_get_common(mirror_port, mirrors_arr[i].mirror_direction, &admin_state);

            CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

            if (admin_state == TRUE) {
                strncpy(admin_state_str, "UP", SPAN_SMALL_STRING_BUF_SIZE);
            } else {
                strncpy(admin_state_str, "DOWN", SPAN_SMALL_STRING_BUF_SIZE);
            }
        }

        dbg_utils_pprinter_table_data_line_print(stream, mirror_port_clmns);
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __span_db_dump_sessions(dbg_dump_params_t     *dbg_dump_params_p,
                                           span_session_t       * sessions,
                                           sx_span_session_id_t * int_to_ext)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    uint32_t        i;
    uint32_t        mirrors_num = 0;
    span_mirror_t * mirrors_arr = NULL;

    for (i = 0; i <= rm_resource_global.span_session_id_max_internal; i++, sessions++) {
        dbg_utils_pprinter_user_defined_header_print(dbg_dump_params_p->stream,
                                                     DBG_UTILS_LEVEL_USER_DEFINED_1_E,
                                                     "SPAN internal session %u",
                                                     i);
        dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "Internal session",  &i, PARAM_UINT32_E);
        dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "External session",  &(int_to_ext[i]),
                                       PARAM_UINT8_E);
        dbg_utils_pprinter_field_print(dbg_dump_params_p->stream,
                                       "Used",
                                       sessions->used ? "IN USE" : "FREE",
                                       PARAM_STRING_E);
        if (sessions->used) {
            mirrors_num = 0;
            mirrors_arr = NULL;
            sx_status = span_db_session_get(i, NULL, NULL, &mirrors_num, NULL, NULL, NULL);
            CL_ASSERT(SX_STATUS_SUCCESS == sx_status);
            if (mirrors_num > 0) {
                mirrors_arr = cl_malloc(mirrors_num * sizeof(span_mirror_t));
                CL_ASSERT(mirrors_arr != NULL);
            }
            sx_status = span_db_session_get(i, NULL, NULL, &mirrors_num, mirrors_arr, NULL, NULL);
            if ((SX_STATUS_SUCCESS != sx_status) && (NULL != mirrors_arr)) {
                CL_FREE_N_NULL(mirrors_arr);
            }
            CL_ASSERT(SX_STATUS_SUCCESS == sx_status);
            sx_status = __span_db_dump_session(dbg_dump_params_p, sessions, mirrors_num, mirrors_arr);
            if (NULL != mirrors_arr) {
                CL_FREE_N_NULL(mirrors_arr);
            }
            CL_ASSERT(SX_STATUS_SUCCESS == sx_status);
        }
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __span_db_dump_ext_sessions(dbg_dump_params_t         *dbg_dump_params_p,
                                               sx_span_session_id_int_t * ext_to_int,
                                               boolean_t                * locked)
{
    sx_span_session_id_t      ext_session_id;
    sx_span_session_id_int_t  int_session_id;
    char                      s[SPAN_SMALL_STRING_BUF_SIZE + 1];
    dbg_utils_table_columns_t ext_session_clmns[] = {
        { "SPAN External Session",  21, PARAM_UINT8_E, &ext_session_id},
        { "Internal Session",       16, PARAM_UINT8_E, &int_session_id},
        { "Locked",                 6,  PARAM_STRING_E, s},
        {NULL, 0, 0, NULL}
    };

    dbg_utils_pprinter_table_headline_print(dbg_dump_params_p->stream, ext_session_clmns);
    for (ext_session_id = 0;
         ext_session_id <= rm_resource_global.span_session_id_max_external;
         ext_session_id++) {
        int_session_id = ext_to_int[ext_session_id];
        strncpy(s, locked[ext_session_id] ? "YES" : "NO", SPAN_SMALL_STRING_BUF_SIZE);
        dbg_utils_pprinter_table_data_line_print(dbg_dump_params_p->stream, ext_session_clmns);
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __span_db_dump_session_users(dbg_dump_params_t *dbg_dump_params_p, span_user_t * users)
{
    uint32_t                  i;
    char                      s[SPAN_SMALL_STRING_BUF_SIZE + 1];
    void                    * fp;
    dbg_utils_table_columns_t user_clmns[] = {
        { "SPAN User",              9,  PARAM_UINT32_E, &i},
        { "Valid",                  5,  PARAM_STRING_E, s},
        { "Relocation Function",    19, PARAM_HEX_E,    &fp},
        {NULL, 0, 0, NULL}
    };

    dbg_utils_pprinter_table_headline_print(dbg_dump_params_p->stream, user_clmns);
    for (i = 0; i < SPAN_DB_MAX_USERS; i++) {
        strncpy(s, users[i].used ? "YES" : "NO ", SPAN_SMALL_STRING_BUF_SIZE);
        fp = users[i].cb_relocate;
        dbg_utils_pprinter_table_data_line_print(dbg_dump_params_p->stream, user_clmns);
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __span_db_dump_ports_info(dbg_dump_params_t *dbg_dump_params_p)
{
    uint32_t                  egress_mirror_ref_count, port_id, swid_num, i, pi, port_num;
    uint32_t                  span_egress_mirror_buf_size;
    sx_port_log_id_t         *port_swid_list = NULL;
    sx_swid_id_t             *swid_list_p = NULL;
    sx_status_t               rc;
    sx_port_info_t            port_info;
    dbg_utils_table_columns_t ports_info_clmns[] = {
        { "Port",              9,  PARAM_PORT_ID_E, &port_id},
        { "EGRESS MIRROR ref count",  25,  PARAM_UINT32_E, &egress_mirror_ref_count},
        { "Buffer size allocated in cells", 32, PARAM_UINT32_E, &span_egress_mirror_buf_size},
        {NULL, 0, 0, NULL}
    };
    FILE                     *stream = dbg_dump_params_p->stream;

    rc = port_swid_list_get(SX_ACCESS_CMD_COUNT, NULL, &swid_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" fdb_dbg_generate_dump - Failed to retrieve number of SWIDs  (%s).\n",
                   sx_status_str(rc));
        goto out;
    }

    /*allocate memory and get swids list*/
    swid_list_p = (sx_swid_id_t*)cl_malloc(swid_num * sizeof(sx_swid_id_t));
    if (swid_list_p == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("  __span_db_dump_ports_info- Failed in memory allocation (%s).\n",
                   sx_status_str(rc));
        goto out;
    }

    rc = port_swid_list_get(SX_ACCESS_CMD_GET, swid_list_p, &swid_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __span_db_dump_ports_info- Failed to retrieve SWIDs info (%s).\n",
                   sx_status_str(rc));
        goto out;
    }

    for (i = 0; i < swid_num; i++) {
        rc = port_swid_get_ext(SX_ACCESS_CMD_COUNT, swid_list_p[i], TRUE, NULL, &port_num);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed port_device_get get port_num, %s(%d)\n",
                       sx_status_str(rc), rc);
            goto out;
        }

        if (port_num == 0) {
            continue;
        }

        port_swid_list = (sx_port_log_id_t*)cl_malloc(port_num * sizeof(sx_port_log_id_t));
        if (port_swid_list == NULL) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed alloc memory for port_list.\n");
            goto out;
        }

        /*get device logical ports list*/
        rc = port_swid_get_ext(SX_ACCESS_CMD_GET, swid_list_p[i], TRUE, port_swid_list, &port_num);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed port_swid_get get logical ports list, %s(%d)\n",
                       sx_status_str(rc), rc);
            goto out;
        }

        dbg_utils_pprinter_table_headline_print(stream, ports_info_clmns);
        for (pi = 0; pi < port_num; pi++) {
            if (SX_PORT_TYPE_ID_GET(port_swid_list[pi]) != SX_PORT_TYPE_NETWORK) {
                continue;
            }
            port_id = port_swid_list[pi];
            if (SX_CHECK_FAIL(rc = port_db_info_get(port_id, &port_info))) {
                SX_LOG_ERR("Can't Get Port %u Info (%s).\n", port_id, sx_status_str(rc));
                goto out;
            }
            egress_mirror_ref_count = port_info.port_mirror_egress_ref_count;
            span_egress_mirror_buf_size = port_info.port_mirror_egress_buff_size;
            dbg_utils_pprinter_table_data_line_print(stream, ports_info_clmns);
        }

        CL_FREE_N_NULL(port_swid_list);
    }
out:
    if (port_swid_list) {
        cl_free(port_swid_list);
    }
    if (swid_list_p) {
        cl_free(swid_list_p);
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __span_db_dump_port_mirror_probability_rate(dbg_dump_params_t *dbg_dump_params_p)
{
    uint32_t                   port_id, swid_num, i, pi, port_num;
    sx_span_probability_rate_t prob_rate_ingress, prob_rate_egress;
    sx_port_log_id_t          *port_swid_list = NULL;
    sx_swid_id_t              *swid_list_p = NULL;
    sx_status_t                rc;
    sx_port_info_t             port_info;
    dbg_utils_table_columns_t  ports_info_clmns[] = {
        { "Port",              9,  PARAM_PORT_ID_E, &port_id},
        { "Egress",  10,  PARAM_UINT32_E, &prob_rate_egress},
        { "Ingress", 10,  PARAM_UINT32_E, &prob_rate_ingress},
        {NULL, 0, 0, NULL}
    };
    FILE                      *stream = dbg_dump_params_p->stream;

    rc = port_swid_list_get(SX_ACCESS_CMD_COUNT, NULL, &swid_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" Failed to retrieve number of SWIDs  (%s).\n",
                   sx_status_str(rc));
        goto out;
    }

    /*allocate memory and get SWIDs list*/
    swid_list_p = (sx_swid_id_t*)cl_malloc(swid_num * sizeof(sx_swid_id_t));
    if (swid_list_p == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed in memory allocation (%s).\n",
                   sx_status_str(rc));
        goto out;
    }

    rc = port_swid_list_get(SX_ACCESS_CMD_GET, swid_list_p, &swid_num);
    if (SX_CHECK_FAIL(SX_STATUS_SUCCESS)) {
        SX_LOG_ERR("Failed to retrieve SWIDs info (%s).\n",
                   sx_status_str(rc));
        goto out;
    }

    dbg_utils_pprinter_general_header_print(stream, "SPAN Port mirroring probability rate");

    for (i = 0; i < swid_num; i++) {
        rc = port_swid_get_ext(SX_ACCESS_CMD_COUNT, swid_list_p[i], TRUE, NULL, &port_num);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed port_device_get get port_num, %s(%d)\n",
                       sx_status_str(rc), rc);
            goto out;
        }

        if (port_num == 0) {
            continue;
        }

        port_swid_list = (sx_port_log_id_t*)cl_malloc(port_num * sizeof(sx_port_log_id_t));
        if (port_swid_list == NULL) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed alloc memory for port_list.\n");
            goto out;
        }

        /*get device logical ports list*/
        rc = port_swid_get_ext(SX_ACCESS_CMD_GET, swid_list_p[i], TRUE, port_swid_list, &port_num);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed port_swid_get get logical ports list, %s(%d)\n",
                       sx_status_str(rc), rc);
            goto out;
        }

        sx_port_type_t port_type;

        dbg_utils_pprinter_table_headline_print(stream, ports_info_clmns);
        for (pi = 0; pi < port_num; pi++) {
            port_type = SX_PORT_TYPE_ID_GET(port_swid_list[pi]);

            if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_LAG)) {
                continue;
            }
            port_id = port_swid_list[pi];
            if (SX_CHECK_FAIL(rc = port_db_info_get(port_id, &port_info))) {
                SX_LOG_ERR("Can't Get Port %u Info (%s).\n", port_id, sx_status_str(rc));
                goto out;
            }
            prob_rate_egress =
                port_info.usr_probability_rate[SX_SPAN_MIRROR_EGRESS - SX_SPAN_MIRROR_DIRECTION_MIN].rate;
            prob_rate_ingress =
                port_info.usr_probability_rate[SX_SPAN_MIRROR_INGRESS - SX_SPAN_MIRROR_DIRECTION_MIN].rate;
            dbg_utils_pprinter_table_data_line_print(stream, ports_info_clmns);
        }

        CL_FREE_N_NULL(port_swid_list);
    }
out:
    if (port_swid_list) {
        cl_free(port_swid_list);
    }
    if (swid_list_p) {
        cl_free(swid_list_p);
    }

    return SX_STATUS_SUCCESS;
}


static sx_status_t __span_db_dump_enable_type2str(sx_span_mirror_enable_type_e type_enum,
                                                  char                       * type,
                                                  length_t                     max_str_len)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    switch (type_enum) {
    case SX_SPAN_MIRROR_ENABLE_ING_WRED_E:
        strncpy(type, "Ingress WRED", max_str_len);
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_UC_E:
        strncpy(type, "Ingress shared buffer drop UC", max_str_len);
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_MC_E:
        strncpy(type, "Ingress shared buffer drop MC", max_str_len);
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_PG_THRESHOLD_E:
        strncpy(type, "Ingress PG threshold", max_str_len);
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_TC_THRESHOLD_E:
        strncpy(type, "Ingress TC threshold", max_str_len);
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_ECN_E:
        strncpy(type, "Egress ECN latency", max_str_len);
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_TC_LATENCY_E:
        strncpy(type, "Egress TC latency", max_str_len);
        break;

    default:
        strncpy(type, "N/A", max_str_len);
        sx_status = SX_STATUS_PARAM_ERROR;
        break;
    }
    return sx_status;
}


static sx_status_t __span_db_dump_enable_map(dbg_dump_params_t *dbg_dump_params_p)
{
    uint32_t                   i, tc_pg_en;
    sx_port_log_id_t           port_id;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    char                       type[SPAN_STRING_BUF_SIZE];
    boolean_t                  first_line;
    cl_map_item_t             *map_item_p = NULL;
    span_mirror_enable_item_t *enable_item_p = NULL;
    dbg_utils_table_columns_t  enable_info_clmns[] = {
        { "Type",              SPAN_STRING_BUF_SIZE,  PARAM_STRING_E, &type},
        { "Port",              9,   PARAM_PORT_ID_E, &port_id},
        { "tc_pg_en",          10,  PARAM_HEX_E, &tc_pg_en},
        {NULL, 0, 0, NULL}
    };
    FILE                      *stream = dbg_dump_params_p->stream;

    SX_LOG_ENTER();
    SX_MEM_CLR_BUF(type, sizeof(type));

    /*print the header*/
    dbg_utils_pprinter_general_header_print(stream, "SPAN enable map dump");
    dbg_utils_pprinter_table_headline_print(stream, enable_info_clmns);

    /* loop : for each type - check all log ports */
    for (i = SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E; i <= SX_SPAN_MIRROR_ENABLE_TYPE_MAX_E; i++) {
        if (SX_CHECK_FAIL(rc =
                              __span_db_dump_enable_type2str((sx_span_mirror_enable_type_e)i, type,
                                                             SPAN_STRING_BUF_SIZE))) {
            SX_LOG_ERR("mirror enable type NA \n");
            goto out;
        }
        first_line = TRUE;

        /*if map is empty -continue*/
        if (cl_is_qmap_empty(&span_db.mirror_enable_entries[i].mirror_enable_map)) {
            continue;
        }
        /*get head of map */
        map_item_p = cl_qmap_head(&span_db.mirror_enable_entries[i].mirror_enable_map);

        while (map_item_p != cl_qmap_end(&span_db.mirror_enable_entries[i].mirror_enable_map)) {
            enable_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_item_t, map_item);
            tc_pg_en = enable_item_p->tc_pg_en;
            port_id = enable_item_p->log_port;
            if (first_line) {
                /*print first line containing type of trigger*/
                dbg_utils_pprinter_table_data_line_print(stream, enable_info_clmns);
                /*no need to print trigger type for next lines*/
                strncpy(type, "", SPAN_STRING_BUF_SIZE);
                first_line = FALSE;
            } else {
                dbg_utils_pprinter_table_data_line_print(stream, enable_info_clmns);
            }

            /* key is port_id;*/
            map_item_p = cl_qmap_get_next(&span_db.mirror_enable_entries[i].mirror_enable_map, port_id);
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __span_db_dump_enable_object_lookup(dbg_dump_params_t *dbg_dump_params_p)
{
    uint32_t                              i, tc_pg;
    sx_port_log_id_t                      log_port;
    uint64_t                              key;
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    char                                  type[SPAN_STRING_BUF_SIZE];
    boolean_t                             first_line;
    cl_map_item_t                        *map_item_p = NULL;
    span_mirror_enable_object_item_t     *enable_object_item_p = NULL;
    const sx_span_mirror_enable_object_t *object_p;
    dbg_utils_table_columns_t             enable_info_clmns[] = {
        { "Type",                 SPAN_STRING_BUF_SIZE,  PARAM_STRING_E,  &type},
        { "Port",                 9,                     PARAM_PORT_ID_E, &log_port},
        { "tc_pg",                10,                    PARAM_UINT8_E,   &tc_pg},
        {NULL, 0, 0, NULL}
    };
    FILE                                 *stream = dbg_dump_params_p->stream;

    SX_LOG_ENTER();
    SX_MEM_CLR_BUF(type, sizeof(type));

    /*print the header*/
    dbg_utils_pprinter_general_header_print(stream, "SPAN enable object map dump");
    dbg_utils_pprinter_table_headline_print(stream, enable_info_clmns);

    /* loop : for each type - check all log ports  */
    for (i = SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E; i <= SX_SPAN_MIRROR_ENABLE_TYPE_MAX_E; i++) {
        if (SX_CHECK_FAIL(rc =
                              __span_db_dump_enable_type2str((sx_span_mirror_enable_type_e)i, type,
                                                             SPAN_STRING_BUF_SIZE))) {
            SX_LOG_ERR("mirror enable type NA \n");
            goto out;
        }
        first_line = TRUE;

        /*if map is empty -continue*/
        if (cl_is_qmap_empty(&span_db.mirror_enable_entries[i].mirror_enable_object_lookup)) {
            continue;
        }
        /*get head of map */
        map_item_p = cl_qmap_head(&span_db.mirror_enable_entries[i].mirror_enable_object_lookup);


        while (map_item_p != cl_qmap_end(&span_db.mirror_enable_entries[i].mirror_enable_object_lookup)) {
            enable_object_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_object_item_t, map_item);
            object_p = &(enable_object_item_p->object);
            if (SX_CHECK_FAIL(rc = __span_db_mirror_enable_get_port_tc(object_p, &log_port, &tc_pg))) {
                SX_LOG_ERR("Failed to get port tc (%s )\n", sx_status_str(rc));
                goto out;
            }

            if (first_line) {
                /*print first line containing type of trigger*/
                dbg_utils_pprinter_table_data_line_print(stream, enable_info_clmns);
                /*no need to print trigger type for next lines*/
                strncpy(type, "", SPAN_STRING_BUF_SIZE);
                first_line = FALSE;
            } else {
                dbg_utils_pprinter_table_data_line_print(stream, enable_info_clmns);
            }

            /* key is port and tc_pg;*/
            key = MIRROR_ENABLE_OBJECT_KEY(log_port, tc_pg);
            map_item_p = cl_qmap_get_next(&span_db.mirror_enable_entries[i].mirror_enable_object_lookup, key);
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __span_db_dbg_dump_bind_table(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    int                        i;
    sx_span_mirror_bind_type_e bind_type;
    sx_span_session_id_t       span_session_id;
    sx_span_probability_rate_t rate;
    char                       type[SPAN_STRING_BUF_SIZE];
    dbg_utils_table_columns_t  enable_info_clmns[] = {
        { "Bind Type",              SPAN_STRING_BUF_SIZE,  PARAM_STRING_E, &type},
        { "Session ID",              9,   PARAM_UINT8_E, &span_session_id},
        { "Rate",                  10,  PARAM_UINT32_E, &rate},
        {NULL, 0, 0, NULL}
    };
    FILE                      *stream = dbg_dump_params_p->stream;

    SX_LOG_ENTER();
    SX_MEM_CLR_BUF(type, sizeof(type));

    /*print the header*/
    dbg_utils_pprinter_general_header_print(stream, "SPAN bind table dump");
    dbg_utils_pprinter_table_headline_print(stream, enable_info_clmns);

    /*since we can bind only once each type we can use enum fro loop indexing */
    for (i = SX_SPAN_MIRROR_BIND_TYPE_MIN_E; i <= SX_SPAN_MIRROR_BIND_TYPE_MAX_E; i++) {
        /* check if current type is bound */
        if (!span_db.mirror_bind_entries[i].bound) {
            continue;
        }
        /*extract the table column content*/
        bind_type = span_db.mirror_bind_entries[i].key.type;
        span_session_id = span_db.mirror_bind_entries[i].attr.span_session_id;
        rate = span_db.mirror_bind_entries[i].attr.rate;

        switch (bind_type) {
        case SX_SPAN_MIRROR_BIND_ING_WRED_E:
            strncpy(type, "Ingress wred", SPAN_STRING_BUF_SIZE);
            break;

        case SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E:
            strncpy(type, "Ingress shared buffer drop", SPAN_STRING_BUF_SIZE);
            break;

        case SX_SPAN_MIRROR_BIND_ING_PG_CONGESTION_E:
            strncpy(type, "Ingress PG congestion", SPAN_STRING_BUF_SIZE);
            break;

        case SX_SPAN_MIRROR_BIND_ING_TC_CONGESTION_E:
            strncpy(type, "Ingress TC congestion", SPAN_STRING_BUF_SIZE);
            break;

        case SX_SPAN_MIRROR_BIND_EGR_ECN_E:
            strncpy(type, "Egress ECN latency", SPAN_STRING_BUF_SIZE);
            break;

        case SX_SPAN_MIRROR_BIND_EGR_TC_LATENCY_E:
            strncpy(type, "Egress TC latency", SPAN_STRING_BUF_SIZE);
            break;

        default:
            sx_status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        /*print table entry*/
        dbg_utils_pprinter_table_data_line_print(stream, enable_info_clmns);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __span_db_dump_span_db(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    sx_status = __span_db_dump_sessions(dbg_dump_params_p, span_db.sx_span_sessions, span_db.int_to_ext_id);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = __span_db_dump_ext_sessions(dbg_dump_params_p, span_db.ext_to_int_id, span_db.locked);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = __span_db_dump_session_users(dbg_dump_params_p, span_db.user);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = __span_db_dump_ports_info(dbg_dump_params_p);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = __span_db_dump_port_mirror_probability_rate(dbg_dump_params_p);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = __span_db_dbg_dump_bind_table(dbg_dump_params_p);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = __span_db_dump_enable_map(dbg_dump_params_p);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = __span_db_dump_mirror_enable_port_map(dbg_dump_params_p);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);


    sx_status = __span_db_dump_enable_object_lookup(dbg_dump_params_p);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    return SX_STATUS_SUCCESS;
}


sx_status_t span_db_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    sx_status = __span_db_dump_globals(dbg_dump_params_p);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = __span_db_dump_span_db(dbg_dump_params_p);
    CL_ASSERT(SX_STATUS_SUCCESS == sx_status);

    sx_status = SX_STATUS_SUCCESS;
out:
    return M_UTILS_SX_LOG_EXIT(sx_status);
}

static sx_status_t __span_db_dump_bind_type2str(sx_span_mirror_bind_type_e type_enum, char * type,
                                                length_t max_str_len)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    switch (type_enum) {
    case SX_SPAN_MIRROR_BIND_ING_WRED_E:
        strncpy(type, "Ingress WRED", max_str_len);
        break;

    case SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E:
        strncpy(type, "Ingress shared buffer drop", max_str_len);
        break;

    case SX_SPAN_MIRROR_BIND_ING_PG_CONGESTION_E:
        strncpy(type, "Ingress PG threshold", max_str_len);
        break;

    case SX_SPAN_MIRROR_BIND_ING_TC_CONGESTION_E:
        strncpy(type, "Ingress TC threshold", max_str_len);
        break;

    case SX_SPAN_MIRROR_BIND_EGR_ECN_E:
        strncpy(type, "Egress ECN latency", max_str_len);
        break;

    case SX_SPAN_MIRROR_BIND_EGR_TC_LATENCY_E:
        strncpy(type, "Egress TC latency", max_str_len);
        break;

    default:
        strncpy(type, "N/A", max_str_len);
        sx_status = SX_STATUS_PARAM_ERROR;
        break;
    }
    return sx_status;
}

static sx_status_t __span_db_dump_mirror_enable_port_map(dbg_dump_params_t *dbg_dump_params_p)
{
    uint32_t                         i;
    sx_port_log_id_t                 port_id;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    char                             flow_type[SPAN_STRING_BUF_SIZE];
    char                             mt_type[SPAN_STRING_BUF_SIZE];
    cl_map_item_t                   *map_item_p = NULL;
    span_mirror_enable_port_item_t  *port_item_p = NULL;
    sx_span_mirror_enable_port_set_t mirror_enable_cfg_list;
    boolean_t                        disallow;
    dbg_utils_table_columns_t        enable_info_clmns[] = {
        { "Port",               9,   PARAM_PORT_ID_E, &port_id},
        { "Flow_Type",          SPAN_STRING_BUF_SIZE,  PARAM_STRING_E, &flow_type},
        { "Mirror_Trigger_Type", SPAN_STRING_BUF_SIZE,  PARAM_STRING_E, &mt_type},
        { "Disallow",           10,  PARAM_BOOL_E, &disallow},
        {NULL, 0, 0, NULL}
    };
    FILE                            *stream = dbg_dump_params_p->stream;

    SX_LOG_ENTER();
    SX_MEM_CLR_BUF(mt_type, sizeof(mt_type));

    /*print the header*/
    dbg_utils_pprinter_general_header_print(stream, "SPAN mirror disallow port map dump");
    dbg_utils_pprinter_table_headline_print(stream, enable_info_clmns);

    /*if map is empty -continue*/
    if (cl_is_qmap_empty(&span_db.mirror_disallow_map)) {
        goto out;
    }
    /*get head of map */
    map_item_p = cl_qmap_head(&span_db.mirror_disallow_map);
    while (map_item_p != cl_qmap_end(&span_db.mirror_disallow_map)) {
        SX_MEM_CLR_BUF(flow_type, sizeof(flow_type));
        SX_MEM_CLR_BUF(mt_type, sizeof(mt_type));
        port_item_p = PARENT_STRUCT(map_item_p, span_mirror_enable_port_item_t, map_item);
        __mirror_trigger_db_to_config_format(port_item_p->log_port,
                                             port_item_p->mirror_trigger_disallow_elp,
                                             port_item_p->mirror_trigger_disallow_elp_sets,
                                             port_item_p->mirror_trigger_disallow_nelp,
                                             port_item_p->mirror_trigger_disallow_nelp_sets,
                                             &mirror_enable_cfg_list);
        port_id = mirror_enable_cfg_list.ingress_log_port;
        SX_MEM_CPY_BUF(flow_type, "Elephant", sizeof("Elephant"));
        for (i = 0; i < mirror_enable_cfg_list.mirror_disallow_elephant.mirror_trigger_disallow_cnt; i++) {
            if (SX_CHECK_FAIL(rc =
                                  __span_db_dump_bind_type2str(mirror_enable_cfg_list.mirror_disallow_elephant.
                                                               mirror_trigger_disallow[i].
                                                               type,
                                                               mt_type, SPAN_STRING_BUF_SIZE))) {
                SX_LOG_ERR("mirror bind type NA \n");
                goto out;
            }
            disallow =
                mirror_enable_cfg_list.mirror_disallow_elephant.mirror_trigger_disallow[i].mirror_trigger_disallow;
            dbg_utils_pprinter_table_data_line_print(stream, enable_info_clmns);
        }
        SX_MEM_CLR_BUF(flow_type, sizeof(flow_type));
        SX_MEM_CPY_BUF(flow_type, "None-elephant", sizeof("None-elephant"));
        for (i = 0; i < mirror_enable_cfg_list.mirror_disallow_non_elephant.mirror_trigger_disallow_cnt; i++) {
            if (SX_CHECK_FAIL(rc =
                                  __span_db_dump_bind_type2str(mirror_enable_cfg_list.mirror_disallow_non_elephant.
                                                               mirror_trigger_disallow[i
                                                               ].type,
                                                               mt_type, SPAN_STRING_BUF_SIZE))) {
                SX_LOG_ERR("mirror bind type NA \n");
                goto out;
            }
            disallow =
                mirror_enable_cfg_list.mirror_disallow_non_elephant.mirror_trigger_disallow[i].mirror_trigger_disallow;
            dbg_utils_pprinter_table_data_line_print(stream, enable_info_clmns);
        }
        map_item_p = cl_qmap_next(map_item_p);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t span_mirror_header_padding_cb_wrapper(const sx_span_mirror_header_version_t header_version,
                                                         const sx_span_session_params_t       *sx_span_session_params_p,
                                                         uint8_t                              *padding_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_header_padding_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_header_padding_cb(header_version,
                                                                 sx_span_session_params_p,
                                                                 padding_p);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }
    } else {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_db_analyzer_lag_port_become_active(const sx_port_id_t lag_port_log_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int = 0;
    length_t                 span_sessions_cnt = 1;
    sx_port_log_id_t         new_multiport[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX];
    uint8_t                  old_multiport_num = 0;
    uint8_t                  new_multiport_num = 0;
    length_t                 i = 0;

    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        new_multiport[i] = SX_SPAN_INVALID_LOG_PORT;
    }

    rc = span_db_port_analyzer_get(lag_port_log_id, NULL, &span_session_id_int, &span_sessions_cnt);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find SPAN session for analyzer port (0x%08X). err %s \n",
                   lag_port_log_id, sx_status_str(rc));
        goto out;
    }
    rc = span_db_analyzer_multiport_get(span_session_id_int, NULL, &old_multiport_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get multiport fields for SPAN session (%u). err %s \n",
                   span_session_id_int, sx_status_str(rc));
        goto out;
    }

    rc = __span_db_analyzer_multiport_select(lag_port_log_id,
                                             new_multiport,
                                             &new_multiport_num,
                                             SX_SPAN_INVALID_LOG_PORT);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to select new ports for Multiport SPAN session (%u). err %s \n",
                   span_session_id_int, sx_status_str(rc));
        goto out;
    }
    if (old_multiport_num == new_multiport_num) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }
    rc = __span_db_analyzer_active_sessions_apply(lag_port_log_id,
                                                  __span_db_analyzer_lag_port_update_mult_apply,
                                                  new_multiport);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update all sessions if LAG SPAN analyzer (0x%08X). err %s \n",
                   lag_port_log_id, sx_status_str(rc));
        goto out;
    }

out:
    return rc;
}

sx_status_t span_db_analyzer_lag_port_force_refresh(const sx_port_id_t lag_port_log_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int = 0;
    length_t                 span_sessions_cnt = 1;
    sx_port_log_id_t         new_multiport[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX];
    uint8_t                  old_multiport_num = 0;
    uint8_t                  new_multiport_num = 0;
    length_t                 i = 0;

    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        new_multiport[i] = SX_SPAN_INVALID_LOG_PORT;
    }

    rc = span_db_port_analyzer_get(lag_port_log_id, NULL, &span_session_id_int, &span_sessions_cnt);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find SPAN session for analyzer port (0x%08X). err %s \n",
                   lag_port_log_id, sx_status_str(rc));
        goto out;
    }
    rc = span_db_analyzer_multiport_get(span_session_id_int, NULL, &old_multiport_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get multiport fields for SPAN session (%u). err %s \n",
                   span_session_id_int, sx_status_str(rc));
        goto out;
    }

    rc = __span_db_analyzer_multiport_select(lag_port_log_id,
                                             new_multiport,
                                             &new_multiport_num,
                                             SX_SPAN_INVALID_LOG_PORT);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to select new ports for Multiport SPAN session (%u). err %s \n",
                   span_session_id_int, sx_status_str(rc));
        goto out;
    }
    rc = __span_db_analyzer_active_sessions_apply(lag_port_log_id,
                                                  __span_db_analyzer_lag_port_update_mult_apply,
                                                  new_multiport);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update all sessions if LAG SPAN analyzer (0x%08X). err %s \n",
                   lag_port_log_id, sx_status_str(rc));
        goto out;
    }

out:
    return rc;
}

sx_status_t span_db_analyzer_lag_port_become_inactive(const sx_port_id_t lag_port_log_id,
                                                      const sx_port_id_t port_log_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int = 0;
    length_t                 span_sessions_cnt = 1;
    sx_port_log_id_t         new_multiport[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX];
    sx_port_log_id_t         old_multiport[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX];
    uint8_t                  old_multiport_num = SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX;
    uint8_t                  new_multiport_num = 0;
    length_t                 i = 0;
    boolean_t                port_used = FALSE;

    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        old_multiport[i] = SX_SPAN_INVALID_LOG_PORT;
        new_multiport[i] = SX_SPAN_INVALID_LOG_PORT;
    }

    rc = span_db_port_analyzer_get(lag_port_log_id, NULL, &span_session_id_int, &span_sessions_cnt);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find SPAN session for analyzer port (0x%08X). err %s \n",
                   lag_port_log_id, sx_status_str(rc));
        goto out;
    }
    rc = span_db_analyzer_multiport_get(span_session_id_int, old_multiport, &old_multiport_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get multiport fields for SPAN session (%u). err %s \n",
                   span_session_id_int, sx_status_str(rc));
        goto out;
    }
    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        if (old_multiport[i] == port_log_id) {
            port_used = TRUE;
            break;
        }
    }
    if (!port_used) {
        /* Port is not used in the current Multiport SPAN session */
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = __span_db_analyzer_multiport_select(lag_port_log_id, new_multiport, &new_multiport_num, port_log_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to select new ports for Multiport SPAN session (%u). err %s \n",
                   span_session_id_int, sx_status_str(rc));
        goto out;
    }
    rc = __span_db_analyzer_active_sessions_apply(lag_port_log_id,
                                                  __span_db_analyzer_lag_port_update_mult_apply,
                                                  new_multiport);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update all sessions if LAG SPAN analyzer (0x%08X). err %s \n",
                   lag_port_log_id, sx_status_str(rc));
        goto out;
    }

out:
    return rc;
}

sx_status_t span_db_analyzer_active_sessions_get(const sx_port_id_t        analyzer_port_log_id,
                                                 sx_span_session_id_int_t *span_sessions_id_int_arr,
                                                 length_t                 *span_sessions_count)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int = 0;
    length_t                 span_sessions_found = 0;

    VALIDATE_POINTER_NOT_NULL(span_sessions_count);

    if (*span_sessions_count == 0) {
        *span_sessions_count = rm_resource_global.span_session_id_max_internal + 1;
    }

    for (span_session_id_int = 0;
         span_session_id_int <= rm_resource_global.span_session_id_max_internal &&
         span_sessions_found < *span_sessions_count;
         span_session_id_int++) {
        if (span_db.sx_span_sessions[span_session_id_int].used == FALSE) {
            continue;
        }

        if (span_db.sx_span_sessions[span_session_id_int].analyzer_port == analyzer_port_log_id) {
            if (span_sessions_id_int_arr != NULL) {
                span_sessions_id_int_arr[span_sessions_found] = span_session_id_int;
            }
            span_sessions_found++;
        }
    }

    *span_sessions_count = span_sessions_found;
    if (span_sessions_found == 0) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
    }

out:
    return err;
}

static sx_status_t __span_db_analyzer_active_sessions_apply(const sx_port_id_t              analyzer_port_log_id,
                                                            span_db_pfn_int_session_apply_t pfn_func,
                                                            void                          * context_p)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t *span_session_id_int_arr = NULL;
    length_t                  span_sessions_count = 0;
    length_t                  i = 0;


    span_session_id_int_arr = (sx_span_session_id_int_t*)cl_malloc(sizeof(sx_span_session_id_int_t) *
                                                                   (rm_resource_global.span_session_id_max_internal +
                                                                    1));
    if (span_session_id_int_arr == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for SPAN sessions ids, err %s \n", sx_status_str(rc));
        goto out;
    }
    span_sessions_count = rm_resource_global.span_session_id_max_internal + 1;

    rc = span_db_analyzer_active_sessions_get(analyzer_port_log_id, span_session_id_int_arr, &span_sessions_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find SPAN sessions for analyzer port (0x%08X). err %s \n",
                   analyzer_port_log_id, sx_status_str(rc));
        goto out;
    }

    for (i = 0; i < span_sessions_count; i++) {
        rc = pfn_func(span_session_id_int_arr[i], context_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed apply function to SPAN session(int id = %d) for analyzer port (0x%08X). err %s \n",
                       span_session_id_int_arr[i], analyzer_port_log_id, sx_status_str(rc));
            goto out;
        }
    }

out:
    if (span_session_id_int_arr) {
        CL_FREE_N_NULL(span_session_id_int_arr);
    }
    return rc;
}

static sx_status_t __span_db_analyzer_lag_port_update_mult_apply(const sx_span_session_id_int_t span_session_id_int,
                                                                 void                          *context_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    const sx_port_id_t             *new_multiport_p = (sx_port_id_t *)context_p;
    const sx_port_id_t              lag_port_log_id = span_db.sx_span_sessions[span_session_id_int].analyzer_port;
    sx_span_analyzer_port_params_t  sx_analyzer_port_params;
    span_analyzer_port_set_params_t analyzer_port_params;
    sx_span_session_id_t            span_session_id = 0;
    uint8_t                         i = 0;

    SX_MEM_CLR(sx_analyzer_port_params);
    SX_MEM_CLR(analyzer_port_params);

    sx_analyzer_port_params = span_db.sx_span_sessions[span_session_id_int].span_session_info.port_params;
    analyzer_port_params.sx_port_params = &sx_analyzer_port_params;
    analyzer_port_params.multiport_apply = TRUE;
    analyzer_port_params.multiport_on_the_fly_update = TRUE;
    SX_MEM_CPY_ARRAY(analyzer_port_params.analyzer_multiport,
                     new_multiport_p,
                     SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX,
                     sx_port_log_id_t);

    analyzer_port_params.multiport_num = 0;
    for (i = 0; i < SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX; ++i) {
        if (new_multiport_p[i] != SX_SPAN_INVALID_LOG_PORT) {
            analyzer_port_params.multiport_num += 1;
        } else {
            break;
        }
    }
    err = span_db_session_int_to_ext(span_session_id_int, &span_session_id);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed (%s) to convert internal session id (%d) to external.\n",
                   sx_status_str(err),
                   span_session_id_int);
        goto out;
    }

    err = span_analyzer_set(SX_ACCESS_CMD_ADD, lag_port_log_id, &analyzer_port_params, span_session_id);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fail (%s) to set analyzer port (0x%x) params.\n", sx_status_str(err), lag_port_log_id);
        goto out;
    }

out:
    return err;
}

static sx_port_cntr_t __span_db_build_64bit_counter(uint32_t counter_high, uint32_t counter_low)
{
    return (((sx_port_cntr_t)counter_high) << 32) | counter_low;
}
