/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include "sx_router_lib.h"
#include "ethl3/sx/router.h"
#include "ethl3/sx/router_mc.h"
#include "sx_core/sx_core_cmd_db.h"
#include "sx_api/sx_api_internal.h"
#include <include/resource_manager/resource_manager.h>

#undef  __MODULE__
#define __MODULE__ ROUTER

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/*************************************************
 *  Local Functions
 ************************************************/
static sx_status_t __router_verbosity(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                      uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_ecmp_hash_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                          uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_ecmp_hash_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                          uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_init_param(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                       uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_deinit_param(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                         uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_interface_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                          uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_interface_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                          uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_interface_state_set(sx_core_td_event_src_t *event,
                                                uint8_t                *cmd_body,
                                                uint32_t                cmd_body_size) __attribute__((used));
static sx_status_t __router_interface_state_get(sx_core_td_event_src_t *event,
                                                uint8_t                *cmd_body,
                                                uint32_t                cmd_body_size) __attribute__((used));
static sx_status_t __router_interface_mac_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                              uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_interface_mac_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                              uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_neigh_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                      uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_neigh_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                      uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_neigh_activity_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                               uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_uc_route_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                         uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_uc_route_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                         uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_uc_route_active_ecmp_get(sx_core_td_event_src_t *event,
                                                     uint8_t                *cmd_body,
                                                     uint32_t                cmd_body_size) __attribute__((used));
static sx_status_t __router_cntr_alloc_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                           uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_cntr_bind_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                          uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_cntr_bind_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                          uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_cntr_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                     uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_cntr_clear_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                           uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_mc_route_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                         uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_mc_route_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                         uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_mc_route_activity_get(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size) __attribute__((used));
static sx_status_t __router_mc_egress_rifs_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                               uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __router_mc_egress_rifs_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                               uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ecmp_background_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                         uint32_t cmd_body_size) __attribute__((used));
static sx_status_t __ecmp_load_balancing_background_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                                        uint32_t cmd_body_size) __attribute__((used));

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
/* IB needed for backward compatibility */
#define SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP                  \
    (SX_CHIP_TYPE_UNKNOWN_BIT_E | ALL_SX_ETH_ASIC_BITMAP | \
     ALL_ACTIVE_IB_ASIC_BITMAP)
static sx_api_command_t sx_core_api_sx_router_cmd_table[] = {
    {SX_API_INT_CMD_ROUTER_VERBOSITY_E,     "SX_API_INT_CMD_ROUTER_VERBOSITY_E",        __router_verbosity,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_HASH_SET_E,     "SX_API_INT_CMD_ROUTER_ECMP_HASH_SET_E",        __router_ecmp_hash_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_ECMP_HASH_GET_E,     "SX_API_INT_CMD_ROUTER_ECMP_HASH_GET_E",        __router_ecmp_hash_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INIT_E,          "SX_API_INT_CMD_ROUTER_INIT_E",         __router_init_param,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_DEINIT_E,            "SX_API_INT_CMD_ROUTER_DEINIT_E",           __router_deinit_param,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_SET_E,           "SX_API_INT_CMD_ROUTER_SET_E",          __router_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_GET_E,           "SX_API_INT_CMD_ROUTER_GET_E",          __router_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_SET_E,     "SX_API_INT_CMD_ROUTER_INTERFACE_SET_E",        __router_interface_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_GET_E,     "SX_API_INT_CMD_ROUTER_INTERFACE_GET_E",        __router_interface_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_STATE_SET_E,   "SX_API_INT_CMD_ROUTER_INTERFACE_STATE_SET_E",
     __router_interface_state_set,       SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_STATE_GET_E,   "SX_API_INT_CMD_ROUTER_INTERFACE_STATE_GET_E",
     __router_interface_state_get,       SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_MAC_SET_E, "SX_API_INT_CMD_ROUTER_INTERFACE_MAC_SET_E",
     __router_interface_mac_set,     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_MAC_GET_E, "SX_API_INT_CMD_ROUTER_INTERFACE_MAC_GET_E",
     __router_interface_mac_get,     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_NEIGH_SET_E,     "SX_API_INT_CMD_ROUTER_NEIGH_SET_E",        __router_neigh_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_NEIGH_GET_E,     "SX_API_INT_CMD_ROUTER_NEIGH_GET_E",        __router_neigh_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_NEIGH_ACTIVITY_GET_E,        "SX_API_INT_CMD_ROUTER_NEIGH_ACTIVITY_GET_E",
     __router_neigh_activity_get,            SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_UC_ROUTE_SET_E,      "SX_API_INT_CMD_ROUTER_UC_ROUTE_SET_E",     __router_uc_route_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_UC_ROUTE_GET_E,      "SX_API_INT_CMD_ROUTER_UC_ROUTE_GET_E",     __router_uc_route_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_UC_ROUTE_OPERATIONAL_ECMP_GET_E, "SX_API_INT_CMD_ROUTER_UC_ROUTE_OPERATIONAL_ECMP_GET_E",
     __router_uc_route_active_ecmp_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_CNTR_ALLOC_SET_E,        "SX_API_INT_CMD_ROUTER_CNTR_ALLOC_SET_E",
     __router_cntr_alloc_set,        SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_COUNTR_BIND_SET_E,     "SX_API_INT_CMD_ROUTER_INTERFACE_COUNTR_BIND_SET_E",
     __router_cntr_bind_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_INTERFACE_COUNTR_BIND_GET_E,     "SX_API_INT_CMD_ROUTER_INTERFACE_COUNTR_BIND_GET_E",
     __router_cntr_bind_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_CNTR_GET_E,      "SX_API_INT_CMD_ROUTER_CNTR_GET_E",     __router_cntr_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_CNTR_CLEAR_SET_E,        "SX_API_INT_CMD_ROUTER_CNTR_CLEAR_SET_E",
     __router_cntr_clear_set,        SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_SET_E,      "SX_API_INT_CMD_ROUTER_MC_ROUTE_SET_E",     __router_mc_route_set,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_GET_E,      "SX_API_INT_CMD_ROUTER_MC_ROUTE_GET_E",     __router_mc_route_get,
     SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_ACTIVITY_GET_E,     "SX_API_INT_CMD_ROUTER_MC_ROUTE_ACTIVITY_GET_E",
     __router_mc_route_activity_get,         SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_EGRESS_RIF_SET_E,   "SX_API_INT_CMD_ROUTER_MC_ROUTE_EGRESS_RIF_SET_E",
     __router_mc_egress_rifs_set,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ROUTER_MC_ROUTE_EGRESS_RIF_GET_E,   "SX_API_INT_CMD_ROUTER_MC_ROUTE_EGRESS_RIF_GET_E",
     __router_mc_egress_rifs_get,      SX_API_PROTOCOL_COMMON_E,   SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ECMP_BACKGROUND_SET_E,      "SX_API_INT_CMD_ECMP_BACKGROUND_SET_E",     __ecmp_background_set,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_ECMP_LOAD_BALANCING_BACKGROUND_SET_E,      "SX_API_INT_CMD_ECMP_LOAD_BALANCING_BACKGROUND_SET_E",
     __ecmp_load_balancing_background_set,
     SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E, SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP},
    {SX_API_INT_CMD_NUM_E, "", NULL, SX_API_PROTOCOL_COMMON_E, SX_API_CMD_PRIO_HIGH_E,
     SX_ROUTER_LIB_ALLOWED_ASIC_BITMAP}                                                                                                                                                                                                  /* NULL Entry. Keep at end!! */
};

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
int sx_router_lib_init(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type)
{
    int               iii = 0;
    sx_api_command_t* cmd = &sx_core_api_sx_router_cmd_table[iii++];
    sx_status_t       err = SX_STATUS_SUCCESS;

    SX_LOG(SX_LOG_DEBUG, "system ASIC bit="BYTE_TO_BINARY_PATTERN,  BYTE_TO_BINARY((uint32_t)(1UL << asic_type)));

    do {
        if ((cmd->supported_asic_types) & (1UL << asic_type)) {
            SX_LOG(SX_LOG_DEBUG, "i=%d Add cmd %s to Router Lib CMD table.\n", iii, cmd->name);

            err = sx_core_set_api_command(cmd);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("sx router api cmd initialization failed \n");
                goto out;
            }
        } else {
            SX_LOG(SX_LOG_DEBUG, "Supported ASIC bitmap="BYTE_TO_BINARY_PATTERN,
                   BYTE_TO_BINARY((uint32_t)(cmd->supported_asic_types)));
            SX_LOG(SX_LOG_DEBUG, "Skip adding unsupported cmd %s to SX Router table.\n", cmd->name);
        }
        cmd = &sx_core_api_sx_router_cmd_table[iii++];
    } while (cmd->cmd_id != SX_API_INT_CMD_NUM_E);

    LOG_VAR_NAME(__MODULE__) = default_verbosity;

    err = router_log_verbosity_level_set(default_verbosity);

    SX_LOG(SX_LOG_NOTICE, "SX ROUTER LIB is loaded\n");

out:
    return (int)err;
}

/************************************************
 *  ROUTER SECTION
 ***********************************************/

static sx_status_t __router_verbosity(sx_core_td_event_src_t *event, uint8_t * cmd_body, uint32_t cmd_body_size)
{
    sx_api_command_log_verbosity_t *params = NULL;
    sx_status_t                     err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_command_log_verbosity_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_command_log_verbosity_t*)cmd_body;

    switch (params->cmd) {
    case SX_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = params->verbosity_level;
        err = router_log_verbosity_level_set(params->verbosity_level);
        break;

    case SX_ACCESS_CMD_GET:
        err = router_log_verbosity_level_get(&(params->verbosity_level));
        break;

    default:
        break;
    }

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    params->cmd == SX_ACCESS_CMD_GET ?
                                    sizeof(sx_api_command_log_verbosity_t) : 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_ecmp_hash_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_ecmp_hash_set_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_ecmp_hash_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_ecmp_hash_set_params_t*)cmd_body;

    err = router_ecmp_hash_params_set(&(params->ecmp_hash_params));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_ecmp_hash_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_ecmp_hash_get_params_t params;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(cmd_body);

    if (cmd_body_size != 0) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = router_ecmp_hash_params_get(&(params.ecmp_hash_params));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)&params,
                                    sizeof(sx_api_router_ecmp_hash_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_init_param(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_init_params_t *params = NULL;
    sx_status_t                  err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_init_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_init_params_t*)cmd_body;
    err = router_init_param(&(params->general_params_p), &(params->router_resource_p));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_deinit_param(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    err = router_deinit_param();

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_set_params_t *params = NULL;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_set_params_t*)cmd_body;

    err = router_set(params->cmd, &params->vrid, &(params->router_attr));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, cmd_body, cmd_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_get_params_t *params = NULL;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_get_params_t*)cmd_body;

    err = router_get(params->vrid, &(params->router_attr));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_interface_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_interface_set_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_interface_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_set_params_t*)cmd_body;

    err = router_interface_set(params->cmd, params->vrid, &(params->ifc),
                               &(params->ifc_attr), &(params->rif));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_interface_set_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_interface_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_interface_get_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_interface_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_get_params_t*)cmd_body;

    err = router_interface_get(params->rif, &(params->vrid), &(params->ifc),
                               &(params->ifc_attr));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_interface_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_interface_state_set(sx_core_td_event_src_t *event,
                                                uint8_t                *cmd_body,
                                                uint32_t                cmd_body_size)
{
    sx_api_router_interface_state_set_params_t *params = NULL;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_interface_state_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_state_set_params_t*)cmd_body;

    err = router_interface_state_set(params->rif, &(params->rif_state));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_interface_state_get(sx_core_td_event_src_t *event,
                                                uint8_t                *cmd_body,
                                                uint32_t                cmd_body_size)
{
    sx_api_router_interface_state_get_params_t *params = NULL;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_interface_state_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_state_get_params_t*)cmd_body;

    err = router_interface_state_get(params->rif, &(params->rif_state));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_interface_state_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_interface_mac_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    uint32_t                                  size = 0;
    sx_api_router_interface_mac_set_params_t *params = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_interface_mac_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_mac_set_params_t*)cmd_body;
    size = sizeof(sx_api_router_interface_mac_set_params_t) +
           (params->mac_addr_num * sizeof(sx_mac_addr_t));

    if (cmd_body_size != size) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = router_interface_mac_set(params->cmd, params->rif,
                                   params->mac_addr_arr,
                                   params->mac_addr_num);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_interface_mac_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    uint32_t                                  size = 0;
    sx_api_router_interface_mac_get_params_t *params = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_interface_mac_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_interface_mac_get_params_t*)cmd_body;

    err = router_interface_mac_get(params->rif, params->mac_addr_arr,
                                   &(params->mac_addr_num));

    size = sizeof(sx_api_router_interface_mac_get_params_t) +
           (params->cmd == SX_ACCESS_CMD_COUNT ? 0 :
            (params->mac_addr_num * sizeof(sx_mac_addr_t)));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_neigh_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_neigh_set_params_t *params = NULL;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_neigh_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_neigh_set_params_t*)cmd_body;

    err = router_neigh_set(params->cmd, (sx_router_id_t)params->rif, &(params->ip_addr),
                           &(params->neigh_data.mac_addr), params->neigh_data.action,
                           params->neigh_data.rif, params->neigh_data.trap_attr);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_neigh_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_neigh_get_params_t *params = NULL;
    sx_status_t                       err = SX_STATUS_SUCCESS;
    uint32_t                          reply_body_size;
    uint32_t                          neigh_entry_cnt;

    if (cmd_body_size != sizeof(sx_api_router_neigh_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_neigh_get_params_t*)cmd_body;
    neigh_entry_cnt = params->neigh_entry_cnt;

    err = router_neigh_get(params->cmd,
                           (sx_router_id_t)params->rif,
                           &params->neigh_key,
                           &params->filter,
                           params->neigh_entry_list,
                           &neigh_entry_cnt);


    if (params->neigh_entry_cnt > 0) {
        reply_body_size = sizeof(sx_api_router_neigh_get_params_t) +
                          (neigh_entry_cnt * sizeof(sx_neigh_get_entry_t));
    } else {
        reply_body_size = sizeof(sx_api_router_neigh_get_params_t);
    }

    params->neigh_entry_cnt = neigh_entry_cnt;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, reply_body_size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_neigh_activity_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                               uint32_t cmd_body_size)
{
    sx_api_router_neigh_get_activity_params_t *params = NULL;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_neigh_get_activity_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_neigh_get_activity_params_t*)cmd_body;

    err = router_neigh_activity_get(params->cmd, (sx_router_id_t)params->rif, &(params->ip_addr),
                                    &(params->activity));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_neigh_get_activity_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_uc_route_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    uint32_t                             size = 0;
    sx_api_router_uc_route_set_params_t *params = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_uc_route_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_uc_route_set_params_t*)cmd_body;
    size = sizeof(sx_api_router_uc_route_set_params_t);

    if (cmd_body_size != size) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = router_uc_route_set(params->cmd, params->vrid, &(params->network_addr),
                              &(params->next_hop));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_uc_route_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    uint32_t                             size = 0;
    sx_api_router_uc_route_get_params_t *params = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;
    uint32_t                             entries_num = 0;

    if (cmd_body_size < sizeof(sx_api_router_uc_route_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_uc_route_get_params_t*)cmd_body;

    entries_num = params->uc_route_get_entries_cnt;

    err = router_uc_route_get(params->cmd, params->vrid, &(params->network_addr),
                              &(params->filter), params->uc_route_get_entries_list, &entries_num);

    if (params->uc_route_get_entries_cnt > 0) {
        size = sizeof(sx_api_router_uc_route_get_params_t) +
               (params->uc_route_get_entries_cnt * sizeof(sx_uc_route_get_entry_t));
    } else {
        size = sizeof(sx_api_router_uc_route_get_params_t);
    }
    params->uc_route_get_entries_cnt = entries_num;

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_uc_route_active_ecmp_get(sx_core_td_event_src_t *event,
                                                     uint8_t                *cmd_body,
                                                     uint32_t                cmd_body_size)
{
    uint32_t                             size = 0;
    sx_api_router_uc_route_get_params_t *params = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd_body_size < sizeof(sx_api_router_uc_route_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_uc_route_get_params_t*)cmd_body;

    if (params->cmd == SX_ACCESS_CMD_GET) {
        params->uc_route_get_entries_list[0].route_data.next_hop_cnt = RM_API_ROUTER_NEXT_HOP_MAX;
    } else if (params->cmd == SX_ACCESS_CMD_COUNT) {
        params->uc_route_get_entries_list[0].route_data.next_hop_cnt = 0;
    }

    err = router_uc_route_ecmp_get(params->vrid, &(params->network_addr),
                                   &(params->uc_route_get_entries_list[0]));

    size = sizeof(sx_api_router_uc_route_get_params_t) +
           sizeof(sx_uc_route_get_entry_t);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_cntr_alloc_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_cntr_alloc_set_params_t *params = NULL;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_cntr_alloc_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_alloc_set_params_t*)cmd_body;

    err = router_cntr_alloc_set(params->cmd, &(params->cntr));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_cntr_alloc_set_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_cntr_bind_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_cntr_bind_set_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_cntr_bind_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_bind_set_params_t*)cmd_body;

    err = router_cntr_bind_set(params->cmd, params->cntr, params->rif);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_cntr_bind_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_cntr_bind_get_params_t *params = NULL;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_cntr_bind_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_bind_get_params_t*)cmd_body;

    err = router_cntr_bind_get(params->cntr, &(params->rif));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params,
                                    sizeof(sx_api_router_cntr_bind_get_params_t));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_cntr_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    uint32_t                         size = 0;
    sx_api_router_cntr_get_params_t *params = NULL;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_cntr_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_get_params_t*)cmd_body;

    err = router_cntr_get(params->cmd, params->cntr, params->cntr_set);

    size = sizeof(sx_api_router_cntr_get_params_t) +
           sizeof(sx_router_counter_set_t);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_cntr_clear_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    sx_api_router_cntr_clear_set_params_t *params = NULL;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    if (cmd_body_size != sizeof(sx_api_router_cntr_clear_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_cntr_clear_set_params_t*)cmd_body;

    err = router_cntr_clear_set(params->cntr, params->all);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_mc_route_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    uint32_t                             size = 0;
    sx_api_router_mc_route_set_params_t *params = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_mc_route_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_route_set_params_t*)cmd_body;
    size = sizeof(sx_api_router_mc_route_set_params_t);

    if (cmd_body_size != size) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = router_mc_route_set(params->cmd, params->vrid, &(params->source_addr),
                              &(params->mc_group_addr), params->ingress_rif, &(params->mc_router_attr),
                              &(params->mc_route_data));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_mc_route_get(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    uint32_t                             size = 0;
    sx_api_router_mc_route_get_params_t *params = NULL;
    sx_status_t                          err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_mc_route_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_route_get_params_t*)cmd_body;

    err = router_mc_route_get(params->cmd, params->vrid, &(params->source_addr),
                              &(params->mc_group_addr), params->ingress_rif, params->mc_route_get_entries_list_p,
                              &(params->mc_route_get_entries_cnt_p));

    size = sizeof(sx_api_router_mc_route_get_params_t) + sizeof(sx_mc_route_get_entry_t);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_mc_route_activity_get(sx_core_td_event_src_t *event,
                                                  uint8_t                *cmd_body,
                                                  uint32_t                cmd_body_size)
{
    uint32_t                                      size = 0;
    sx_api_router_mc_route_activity_get_params_t *params = NULL;
    sx_status_t                                   err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_mc_route_activity_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_PARAM_EXCEEDS_RANGE, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_route_activity_get_params_t*)cmd_body;

    err = router_mc_route_activity_get(params->cmd, params->vrid, &(params->source_addr),
                                       &(params->mc_group_addr), params->ingress_rif, &(params->activity));

    size = sizeof(sx_api_router_mc_route_activity_get_params_t);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_mc_egress_rifs_set(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                               uint32_t cmd_body_size)
{
    uint32_t                                   size = 0;
    sx_api_router_mc_egress_rifs_set_params_t *params = NULL;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    if (cmd_body_size < sizeof(sx_api_router_mc_egress_rifs_set_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_egress_rifs_set_params_t*)cmd_body;
    size = sizeof(sx_api_router_mc_egress_rifs_set_params_t) +
           (params->egress_rifs_num * sizeof(sx_router_interface_t));

    if (cmd_body_size != size) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    err = router_mc_egress_rif_set(params->cmd,
                                   params->vrid,
                                   &(params->source_addr),
                                   &(params->mc_group_addr),
                                   params->ingress_rif,
                                   params->egress_rifs_arr,
                                   params->egress_rifs_num);

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, NULL, 0);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __router_mc_egress_rifs_get(sx_core_td_event_src_t *event, uint8_t *cmd_body,
                                               uint32_t cmd_body_size)
{
    uint32_t                                   size = 0;
    sx_api_router_mc_egress_rifs_get_params_t *params = NULL;
    sx_status_t                                err = SX_STATUS_SUCCESS;
    uint32_t                                   egress_rifs_num;

    if (cmd_body_size < sizeof(sx_api_router_mc_egress_rifs_get_params_t)) {
        err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
        goto out;
    }

    params = (sx_api_router_mc_egress_rifs_get_params_t*)cmd_body;

    egress_rifs_num = params->egress_rifs_num;

    err = router_mc_egress_rif_get(params->vrid, &(params->source_addr), &(params->mc_group_addr), params->ingress_rif,
                                   params->egress_rifs_arr, &(params->egress_rifs_num));

    /* if egress_rifs_num==0 than counter was asked so params->egress_rifs_num still contains counter */
    if (egress_rifs_num != 0) {
        params->egress_rifs_num = MIN(params->egress_rifs_num, egress_rifs_num);
        egress_rifs_num = params->egress_rifs_num;
    }

    size = sizeof(sx_api_router_mc_egress_rifs_get_params_t) +
           (egress_rifs_num * sizeof(sx_router_interface_t));

    err = sx_api_send_reply_wrapper(&(event->commchnl), err, (uint8_t*)params, size);

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __ecmp_background_set(sx_core_td_event_src_t *event, uint8_t *cmd_body, uint32_t cmd_body_size)
{
    UNUSED_PARAM(event);
    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    router_ecmp_background_checker();

    return SX_STATUS_SUCCESS;
}


static sx_status_t __ecmp_load_balancing_background_set(sx_core_td_event_src_t *event,
                                                        uint8_t                *cmd_body,
                                                        uint32_t                cmd_body_size)
{
    UNUSED_PARAM(event);
    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);

    /* nothing to do in sx */

    return SX_STATUS_SUCCESS;
}
