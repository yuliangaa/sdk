/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <linux/un.h>
#include <errno.h>

#include <sx/utils/debug_cmd.h>

int main(int argc, const char **argv)
{
    struct sockaddr_un sa;
    char               buff[SX_UTILS_DBG_CMD_BUFFER_SIZE] = "";
    size_t             buff_size = SX_UTILS_DBG_CMD_BUFFER_SIZE;
    size_t             arg_size = 0;
    int                fd_client, rc, i;

    fd_client = socket(AF_UNIX, SOCK_STREAM, 0);
    if (fd_client < 0) {
        printf("failed to create socket (errno=%d)\n", errno);
        return 1;
    }

    sa.sun_family = AF_UNIX;
    strcpy(sa.sun_path, SX_UTILS_DBG_CMD_PATH);
    rc = connect(fd_client, (struct sockaddr*)&sa, sizeof(sa));
    if (rc) {
        printf("failed to connect socket (errno=%d)\n", errno);
        return 1;
    }

    for (i = 1; i < argc; i++) {
        arg_size = strnlen(argv[i], buff_size);
        if (arg_size >= buff_size) {
            printf(
                "Too long command is received, stopped at argument #%d: %s [%ld],\n at this point the command is %s [%ld (%d)].\n",
                i,
                argv[i],
                arg_size,
                buff,
                buff_size,
                SX_UTILS_DBG_CMD_BUFFER_SIZE);
            return 1;
        }

        strncat(buff, argv[i], arg_size);
        buff_size -= arg_size;

        if (buff_size < 2) {
            printf(
                "Too long command is received, cannot add a trailing space, stopped at argument #%d: %s [%ld],\n at this point the command is %s [%ld (%d)].\n",
                i,
                argv[i],
                arg_size,
                buff,
                buff_size,
                SX_UTILS_DBG_CMD_BUFFER_SIZE);
            return 1;
        }

        strncat(buff, " ", 2);
        buff_size--;
    }

    rc = send(fd_client, buff, strlen(buff) + 1, 0);
    if (rc < 0) {
        printf("failed in send() [err=%d]\n", errno);
        goto out;
    }

    rc = sizeof(buff);

    do {
        rc = recv(fd_client, buff, sizeof(buff) - 1, 0);
        if (rc < 0) {
            printf("failed in recv() (errno=%d)\n", errno);
            break;
        }

        if (rc == 0) {
            break;
        }

        buff[rc] = '\0';
        printf("%s", buff);
    } while (1);

out:
    close(fd_client);
    return 0;
}
