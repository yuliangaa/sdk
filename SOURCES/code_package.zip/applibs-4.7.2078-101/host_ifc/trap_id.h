/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __TRAP_ID_H__
#define __TRAP_ID_H__

#include <sx/sdk/sx_types.h>
#include "host_ifc_common.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t trap_id_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
boolean_t trap_id_is_source(uint32_t hw_trap_id);
boolean_t trap_id_is_fw_event(uint32_t hw_trap_id);
boolean_t trap_id_is_event(uint16_t syndrome_id);
boolean_t trap_id_is_exclude_trap_issu_started(uint32_t trap_id);
sx_status_t trap_id_control_type_valid(sx_trap_id_t trap_id, sx_control_type_t control_type);
sx_status_t trap_id_implicitly_set_by_sdk(uint16_t trap_id);
sx_status_t trap_id_allowed_trap_action(sx_trap_id_t trap_id, sx_trap_action_t trap_action);
sx_status_t trap_id_is_supported_switchx(sx_trap_id_t trap_id);
sx_status_t trap_id_is_supported_spectrum(sx_trap_id_t trap_id);
sx_status_t trap_id_is_supported_spectrum2(sx_trap_id_t trap_id);
sx_status_t trap_id_is_supported_spectrum3(sx_trap_id_t trap_id);
sx_status_t trap_id_is_supported_spectrum4(sx_trap_id_t trap_id);
sx_status_t trap_id_is_supported_device(sx_trap_id_t trap_id);
sx_status_t trap_id_defaults_get(sx_trap_id_t        trap_id,
                                 boolean_t          *has_default_action_p,
                                 sx_hw_trap_group_e *hw_trap_group_p,
                                 sx_trap_action_t   *trap_action_p);
sx_status_t trap_id_conflicts_check(sx_trap_id_t trap_id);
sx_status_t trap_id_conflicts_check_spectrum(sx_trap_id_t trap_id);
sx_status_t trap_id_default_action_set_spectrum(const sx_trap_id_t trap_id,
                                                sx_trap_action_t * trap_action_p,
                                                boolean_t        * has_default_action_p);
sx_status_t trap_id_default_action_set_spectrum2(const sx_trap_id_t trap_id,
                                                 sx_trap_action_t * trap_action_p,
                                                 boolean_t        * has_default_action_p);
sx_status_t trap_id_default_action_set_ib(const sx_trap_id_t trap_id,
                                          sx_trap_action_t * trap_action_p,
                                          boolean_t        * has_default_action_p);

boolean_t trap_id_is_acl_key_supported(sx_trap_id_t trap_id);
boolean_t trap_id_is_acl_key_supported_spectrum(sx_trap_id_t trap_id);
boolean_t trap_id_is_acl_key_supported_spectrum4(sx_trap_id_t trap_id);
sx_status_t trap_id_hw_syndrome_get(sx_trap_id_t trap_id, uint16_t *hw_trap_id);

sx_status_t trap_id_hw_syndrome_db_init(void);
sx_status_t trap_id_hw_syndrome_db_deinit(void);
#endif /* __TRAP_ID_H__ */
