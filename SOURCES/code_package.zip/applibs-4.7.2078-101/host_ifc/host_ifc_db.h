/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __HOST_INTERFACE_DB_H_INCL__
#define __HOST_INTERFACE_DB_H_INCL__

#include <complib/sx_log.h>
#include <sx/sdk/sx_types.h>
#include <ethl2/port.h>
#include "host_ifc_common.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "span/span_db.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define HOST_INTERFACE_DB_STACKING_SWID_ID (RM_NUM_OF_SWIDS)

#define SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(TRAP_ID) \
    ((TRAP_ID - SX_TRAP_ID_DISCARD_BASE))

/************************************************
 *  Macros
 ***********************************************/
/************************************************
 *  Type definitions
 ***********************************************/

typedef struct host_ifc_trap_group_properties {
    uint8_t                            swid;
    uint8_t                            group;
    boolean_t                          policer_id_enabled;
    sx_policer_id_t                    policer_id;
    sxd_host_interface_path_type_e     type;
    sxd_host_interface_path_t          path;
    sx_truncate_mode_t                 truncate_mode;
    sx_truncate_size_t                 truncate_size;
    sx_trap_truncate_profile_id_t      trunc_profile_id;
    sx_trap_priority_t                 priority;
    sx_control_type_t                  control_type;
    sxd_host_interface_mirror_action_t mirror_action;
    sx_span_probability_rate_t         mirror_probability_rate;
    sx_span_session_id_int_t           mirror_agent;
    boolean_t                          add_timestamp;
    boolean_t                          is_tac_capable;
    boolean_t                          is_monitor;
    sx_fd_t                            monitor_fd;
    sx_packet_timestamp_source_e       timestamp_source;
} host_ifc_trap_group_properties_t;

typedef struct host_ifc_trap_group_properties_item {
    host_ifc_trap_group_properties_t trap_group_properties;
    cl_list_t                        associated_trap_id_list;
    boolean_t                        is_configured;
} host_ifc_trap_group_properties_item_t;

typedef struct host_ifc_trap_group_arr {
    sx_trap_group_t trap_groups[SX_TRAP_GROUP_MAX + 1];
} host_ifc_trap_group_arr_t;

typedef struct host_ifc_trap_id_properties {
    sx_trap_id_t       hw_trap_id;
    sx_trap_action_t   trap_action;
    sx_hw_trap_group_e hw_trap_group;
    sx_control_type_t  control_type;
    uint8_t            tr_prof; /**< Host truncation_profile, SX_TRAP_TRUNCATE_PROFILE_MIN..SX_TRAP_TRUNCATE_PROFILE_MAX, Configured using HGCR */
    boolean_t          tr_en; /**< Truncation enabled */
} host_ifc_trap_id_properties_t;

typedef struct host_ifc_trap_group_data {
    sx_trap_group_t                  trap_group_id;
    sx_hw_trap_group_e               hw_trap_group;
    sx_trap_action_t                 trap_action;
    boolean_t                        is_monitor;
    boolean_t                        is_tac_capable;
    sx_host_ifc_trap_cfg_flow_type_e is_ext_flow; /* indicates which flow we are using */
} host_ifc_trap_group_data_t;

typedef struct host_ifc_trap_group_queue_entry {
    cl_pool_item_t             pool_item;
    cl_list_item_t             list_item;
    host_ifc_trap_group_data_t data;
} host_ifc_trap_group_queue_entry_t;

typedef struct host_ifc_trap_group_queue {
    cl_qpool_t    pool;
    cl_qlist_t    list;
    cl_spinlock_t lock;
    boolean_t     on_pause;
} host_ifc_trap_group_queue_t;

typedef struct host_ifc_trap_id_item {
    host_ifc_trap_id_properties_t trap_id_properties;
    uint32_t                      ref_count; /*how many clients registered on that trap*/
    boolean_t                     is_associated; /*is trap id belongs to trap group*/
    host_ifc_trap_group_queue_t   trap_group_queue;
} host_ifc_trap_id_item_t;

typedef struct host_ifc_user_trap_id {
    sx_trap_id_t                         trap_id;
    host_ifc_trap_id_item_t              trap_id_item;
    sx_trap_id_user_defined_attributes_t trap_attributes;
} host_ifc_user_trap_id_t;

typedef struct host_ifc_trap_filter_item {
    sx_port_log_id_t log_port_id;
    cl_list_item_t   list_item;
} host_ifc_trap_filter_item_t;

typedef struct host_ifc_pid_item {
    pid_t          pid;
    cl_list_item_t list_item;
} host_ifc_pid_item_t;

typedef struct host_ifc_trap_register_item {
    sx_host_ifc_register_key_t register_key;
    sx_user_channel_t          user_channel;
    cl_list_item_t             list_item;
    cl_qlist_t                 pid_list;
} host_ifc_trap_register_item_t;

typedef struct host_ifc_trap_channel_filter_item {
    sx_host_ifc_filter_key_t filter_key;
    sx_user_channel_t        user_channel;
    cl_list_item_t           list_item;
    cl_qlist_t               pid_list;
} host_ifc_trap_channel_filter_item_t;

typedef struct host_ifc_trap_user_channel_item {
    sx_user_channel_t user_channel;
    cl_list_item_t    list_item;
    cl_qlist_t        pid_list;
} host_ifc_trap_user_channel_item_t;

typedef struct host_ifc_db {
    host_ifc_trap_group_arr_t              *trap_group_2_hw_trap_group;
    uint32_t                              **hw_trap_group_2_trap_group;
    host_ifc_trap_group_properties_item_t **swid_2_trap_groups;
    host_ifc_trap_id_item_t                 trap_id_2_trap_id_properties[SX_TRAP_ID_COUNT];
    host_ifc_user_trap_id_t                 user_trap_id[SX_USER_DEFINED_TRAPS_NUM + 1];
    cl_qlist_t                            **swid_2_trap_filters;
    cl_qlist_t                            **swid_2_trap_registers;
    cl_qlist_t                            **swid_2_trap_user_channels;
    cl_qlist_t                            **swid_2_trap_channels_filters;
} host_ifc_db_t;

typedef struct {
    boolean_t    trap_in_use;
    boolean_t    extended_trap_in_use;
    uint32_t     extended_trap_id_count;
    sx_trap_id_t extended_trap_id_list[SX_EXTENDED_DISCARD_TRAPS_NUM];
} host_ifc_db_discard_to_discard_extended_map_t;

typedef struct host_ifc_db_profile_cfg_ {
    sx_trap_truncate_profile_cfg_t cfg;
    boolean_t                      created;
} host_ifc_db_profile_cfg_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t host_ifc_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

/**
 *  This function initializes the host interface DB
 *
 * @return SX_STATUS_SUCCESS
 */
sx_status_t host_ifc_db_init(void);

/**
 *  This function deinitializes the host interface DB
 *
 * @return SX_STATUS_SUCCESS
 */
sx_status_t host_ifc_db_deinit(void);

/**
 *  This function sets the mapping between user trap group and hw trap group in the DB
 *
 * @param[in]  swid                           - Switch ID
 * @param[in]  trap_group_id                  - user trap group id
 * @param[in]  hw_trap_group_id		      - hw trap group id
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_ERROR - general error
 *         SX_STATUS_PARAM_ERROR - trap group is not in range / SWID is not in range
 */
sx_status_t host_ifc_db_trap_group_map_set(IN sx_access_cmd_t    cmd,
                                           IN sx_swid_t          swid,
                                           IN sx_trap_group_t    trap_group_id,
                                           IN sx_hw_trap_group_e hw_trap_group_id);

/**
 *  This function gets the mapping between user trap group and hw trap group in the DB
 *
 * @param[in]  swid                           - Switch ID
 * @param[in]  trap_group_id                  - user trap group id
 * @param[out] hw_trap_group_id		      - hw trap group id
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_ERROR - general error
 *         SX_STATUS_PARAM_ERROR - trap group is not in range / SWID is not in range
 */
sx_status_t host_ifc_db_trap_group_map_get(IN sx_swid_t           swid,
                                           IN sx_trap_group_t     trap_group_id,
                                           IN sx_hw_trap_group_e *hw_trap_group_id);

/**
 *  This function allocate a SW trap group from the DB
 *
 * @param[in]  swid                           - Switch ID
 * @param[out] trap_group_id_p                - sw trap group id
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_ERROR - general error
 *         SX_STATUS_PARAM_ERROR - trap group is not in range / SWID is not in range
 */
sx_status_t host_ifc_db_allocate_trap_group(sx_swid_t        swid,
                                            sx_trap_group_t *trap_group_id_p);

/**
 *  This function gets the mapping between HW trap group and user trap group in the DB
 *
 * @param[in]  swid                   - Switch ID
 * @param[in]  hw_trap_group_id       - HW trap group id
 * @param[out]  trap_group_id	      - user trap group id
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_ERROR - general error
 *         SX_STATUS_PARAM_ERROR - trap group is not in range / SWID is not in range
 */
sx_status_t host_ifc_db_trap_group_reverse_map_get(IN sx_swid_t          swid,
                                                   IN sx_hw_trap_group_e hw_trap_group_id,
                                                   OUT sx_trap_group_t  *trap_group_id);
/**
 *  This function add/change/delete trap group associated to specific switch ID
 *
 * @param[in]  cmd - SET: change an existing trap group item - if trap group does not exist it is created
 *                   DELETE: delete a trap group
 * @param[in]  swid                           - Switch ID
 * @param[in]  trap_group_id                  - trap group id
 * @param[in]  trap_group_properties          - trap group properties
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_ERROR - general error
 *         SX_STATUS_PARAM_ERROR - trap group is not in range / SWID is not in range
 */
sx_status_t host_ifc_db_trap_group_properties_set(IN sx_access_cmd_t                   cmd,
                                                  IN sx_swid_t                         swid,
                                                  IN sx_hw_trap_group_e                trap_group_id,
                                                  IN host_ifc_trap_group_properties_t *trap_group_properties);

/**
 *  This function retrieves trap group properties - associated to specific switch ID
 *
 * @param[in]  swid              - Switch ID
 * @param[in]  trap_group        - trap group id
 * @param[out] trap_group_properties - trap group properties
 * @param[out] is_configured         - is group configured in HW
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_ENTRY_NOT_FOUND - trap group does not exist in the DB
 *         SX_STATUS_ERROR - general error
 *         SX_STATUS_PARAM_ERROR - trap group is not in range / SWID is not in range
 */
sx_status_t host_ifc_db_trap_group_properties_get(IN sx_swid_t                          swid,
                                                  IN sx_hw_trap_group_e                 trap_group,
                                                  OUT host_ifc_trap_group_properties_t *trap_group_properties,
                                                  OUT boolean_t                        *is_configured);
/**
 * This function retrieves a list of one or more trap group IDs associated to specific switch ID.
 *
 * @param [in] cmd                     - GET/GET_FIRST/GET_NEXT
 * @param [in] swid                    - switch ID
 * @param [in] trap_group_id           - trap group ID
 * @param [in] filter_p                - specify a filter parameter (not supported yet)
 * @param [out] trap_group_id_list_p   - return list of trap group IDs
 * @param [in,out] trap_group_id_cnt_p - [in] number of trap group IDs to get
 *                                     - [out] number of trap group IDs returned
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL parameters
 *         SX_STATUS_PARAM_EXCEEDS_RANGE - SWID is not in range
 *         SX_STATUS_CMD_UNSUPPORTED -  cmd is not supported
 */
sx_status_t host_ifc_db_trap_group_iter_get(const sx_access_cmd_t         cmd,
                                            const sx_swid_id_t            swid,
                                            const sx_trap_group_t         trap_group_id,
                                            const sx_trap_group_filter_t *filter_p,
                                            sx_trap_group_t              *trap_group_id_list_p,
                                            uint32_t                     *trap_group_id_cnt_p);

/**
 *  This function sets a trap id properties
 *
 * @param[in]  trap_id                    - trap id
 * @param[in]  trap_id_properties         - trap id properties
 * @param[in]  is_associated              - is trap id associated to trap group
 * @param[in]  is_in_use                  - is trap id in use
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_ERROR - general error
 *         SX_STATUS_PARAM_ERROR - trap id is not in range
 */
sx_status_t host_ifc_db_trap_id_properties_set(IN sx_trap_id_t                  trap_id,
                                               IN host_ifc_trap_id_properties_t trap_id_properties,
                                               IN boolean_t                     is_associated,
                                               IN boolean_t                     is_in_use);

/**
 *  This function retrieves trap id properties
 *
 * @param[in]  trap_id             - trap id
 * @param[out] trap_id_properties  - trap id properties
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_ERROR - general error
 *         SX_STATUS_PARAM_ERROR - trap id is not in range
 */
sx_status_t host_ifc_db_trap_id_properties_get(sx_trap_id_t                   trap_id,
                                               host_ifc_trap_id_properties_t *trap_id_properties);

/**
 *  This function scans the HW trap group map and returns the first unallocated
 *  HW trap group ID.
 *  Note: This function should only be used on SPECTRUM devices.
 *
 * @param[in] swid            - SWID
 * @param[in] trap_priority   - Trap Priority
 * @param[in] pci_profile     - PCI profile
 * @param[out] hw_trap_group  - first free HW trap group
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_PARAM_NULL - NULL output parameter given
 *         SX_STATUS_PARAM_ERROR - invalid SWID
 *         SX_STATUS_NO_RESOURCES - no more unallocated HW trap groups left
 */
sx_status_t host_ifc_db_spectrum_hw_trap_group_get(sx_swid_t             swid,
                                                   sx_trap_priority_t    trap_priority,
                                                   sx_api_pci_profile_t *pci_profile,
                                                   uint32_t             *hw_trap_group);

sx_status_t host_ifc_db_user_trap_id_set(sx_access_cmd_t                       cmd,
                                         const sx_trap_id_t                    trap_id,
                                         sx_trap_id_user_defined_attributes_t *user_defined_attributes_p);

sx_status_t host_ifc_db_user_trap_id_get(const sx_trap_id_t                    trap_id,
                                         sx_trap_id_user_defined_attributes_t *user_defined_attributes_p);

sx_status_t host_ifc_db_trap_filter_get(const sx_access_cmd_t  cmd,
                                        const sx_swid_t        swid,
                                        const sx_trap_id_t     trap_id,
                                        const sx_port_log_id_t log_port_id,
                                        sx_port_log_id_t      *log_port_list_p,
                                        length_t              *log_port_cnt_p);

sx_status_t host_ifc_db_trap_filter_set(const sx_access_cmd_t  cmd,
                                        const sx_swid_t        swid,
                                        const sx_trap_id_t     trap_id,
                                        const sx_port_log_id_t log_port_id);

sx_status_t host_ifc_db_trap_id_register_get(const sx_access_cmd_t    cmd,
                                             const sx_swid_t          swid,
                                             const sx_trap_id_t       trap_id,
                                             const sx_user_channel_t *user_channel,
                                             const pid_t              client_pid,
                                             sx_user_channel_t       *user_channel_list_p,
                                             uint32_t                *user_channel_cnt_p);

sx_status_t host_ifc_db_trap_id_register_set(const sx_access_cmd_t    cmd,
                                             const sx_swid_t          swid,
                                             const sx_trap_id_t       trap_id,
                                             const sx_user_channel_t *user_channel_p,
                                             const pid_t              client_pid);

sx_status_t host_ifc_db_port_vlan_trap_id_register_get(const sx_access_cmd_t                   cmd,
                                                       const sx_swid_t                         swid,
                                                       const sx_trap_id_t                      trap_id,
                                                       const sx_host_ifc_register_get_entry_t *register_entry,
                                                       const pid_t                             client_pid,
                                                       sx_host_ifc_register_get_entry_t       *register_entry_list_p,
                                                       uint32_t                               *register_entry_cnt_p);

sx_status_t host_ifc_db_port_vlan_trap_id_register_set(const sx_access_cmd_t             cmd,
                                                       const sx_swid_t                   swid,
                                                       const sx_trap_id_t                trap_id,
                                                       const sx_host_ifc_register_key_t *register_key_p,
                                                       const sx_user_channel_t          *user_channel_p,
                                                       const pid_t                       client_pid);

sx_status_t host_ifc_db_remove_all_fd_user_channels(pid_t client_pid);

sx_status_t host_ifc_db_remove_fd_user_channels(const sx_fd_t *fd_p,
                                                const pid_t    client_pid);

sx_status_t host_ifc_db_extended_discard_trap_set(const sx_trap_id_t trap_id, boolean_t is_in_use);
sx_status_t host_ifc_db_discard_trap_set(const sx_trap_id_t trap_id, boolean_t is_in_use);
sx_status_t host_ifc_db_extended_discard_trap_check(const sx_trap_id_t trap_id);
sx_status_t host_ifc_db_discard_trap_check(const sx_trap_id_t trap_id);

sx_status_t host_ifc_db_trap_id_to_group_list_init(const sx_trap_id_t trap_id);
sx_status_t host_ifc_db_trap_id_to_group_list_deinit(const sx_trap_id_t trap_id);

sx_status_t host_ifc_db_trap_id_flow_type_set(const sx_trap_id_t               trap_id,
                                              sx_trap_group_t                  trap_group,
                                              sx_host_ifc_trap_cfg_flow_type_e flow_type);
sx_status_t host_ifc_db_trap_id_flow_type_get(const sx_trap_id_t                trap_id,
                                              sx_trap_group_t                   trap_group,
                                              sx_host_ifc_trap_cfg_flow_type_e *flow_type_p);


sx_status_t host_ifc_db_trap_id_to_group_associate_set(const sx_access_cmd_t cmd,
                                                       const sx_swid_t       swid,
                                                       const sx_trap_id_t    trap_id,
                                                       sx_trap_group_t      *trap_group_p,
                                                       sx_trap_action_t     *trap_action_p);
sx_status_t host_ifc_db_trap_id_to_group_associate_get(const sx_trap_id_t trap_id,
                                                       sx_trap_group_t   *trap_group_p,
                                                       sx_trap_action_t  *trap_action_p,
                                                       uint32_t          *trap_group_cnt_p);
sx_status_t host_ifc_db_trap_group_associated_attr_get(sx_trap_id_t        trap_id,
                                                       sx_trap_group_t     trap_group,
                                                       sx_hw_trap_group_e *hw_trap_group_p,
                                                       sx_trap_action_t   *trap_action_p,
                                                       boolean_t          *is_monitor_p,
                                                       boolean_t          *is_tac_capable_p);
sx_status_t host_ifc_db_trap_id_channel_filter_set(const sx_access_cmd_t           cmd,
                                                   const sx_swid_t                 swid,
                                                   const sx_trap_id_t              trap_id,
                                                   const sx_host_ifc_filter_key_t *filter_key_p,
                                                   const sx_user_channel_t        *user_channel_p,
                                                   const pid_t                     client_pid);
sx_status_t host_ifc_db_trap_id_channel_filter_get(const sx_access_cmd_t                         cmd,
                                                   const sx_swid_t                               swid,
                                                   const sx_trap_id_t                            trap_id,
                                                   const sx_host_ifc_channel_filter_get_entry_t *channel_filter_entry,
                                                   const pid_t                                   client_pid,
                                                   sx_host_ifc_channel_filter_get_entry_t       *channel_filter_entry_list_p,
                                                   uint32_t                                     *channel_filter_entry_cnt_p);

sx_status_t host_ifc_db_profile_cfg_set(const sx_trap_truncate_profile_id_t trunc_profile_id,
                                        const host_ifc_db_profile_cfg_t    *host_ifc_db_profile_cfg_p);
sx_status_t host_ifc_db_profile_cfg_get(const sx_trap_truncate_profile_id_t trunc_profile_id,
                                        host_ifc_db_profile_cfg_t          *host_ifc_db_profile_cfg_p);

sx_status_t host_ifc_db_trap_id_list_get(const sx_trap_group_t trap_group_id,
                                         sx_trap_id_t         *trap_id_arr_p,
                                         length_t             *trap_id_num_p);
sx_status_t host_ifc_db_trap_id_from_group_list_unset(sx_trap_group_t hw_trap_group, sx_trap_id_t trap_id);

#endif /* __HOST_INTERFACE_DB_H_INCL__ */
