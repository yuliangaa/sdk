/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#include "host_ifc.h"
#include "host_ifc_db.h"
#include "sx/sdk/sx_dev.h"
#include "ethl2/brg.h"
#include "complib/cl_mem.h"
#include <complib/cl_dbg.h>
#include <sx/sxd/sxd_dpt.h>

#undef  __MODULE__
#define __MODULE__ HOST_INTERFACE_DB

/************************************************
 *  Global variables
 ***********************************************/
extern sx_brg_context_t brg_context;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static host_ifc_db_t                                 __host_ifc_db_s;
static host_ifc_db_discard_to_discard_extended_map_t host_ifc_db_discard_to_discard_extended_map[] = {
    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_ING_PACKET)] =
    { FALSE, FALSE, 4, { SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC,
                         SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC,
                         SX_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC,
                         SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0 }
    },
    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_ING_SWITCH)] =
    { FALSE, FALSE, 3, { SX_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW,
                         SX_TRAP_ID_DISCARD_ING_SWITCH_VLAN,
                         SX_TRAP_ID_DISCARD_ING_SWITCH_STP }
    },
    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_LOOKUP_SWITCH)] =
    { FALSE, FALSE, 4, { SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC,
                         SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL,
                         SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB,
                         SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS }
    },
    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_ING_ROUTER)] =
    { FALSE, FALSE, 14, { SX_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL,
                          SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LINK_LOCAL }
    },
    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_ING_LSR)] =
    { FALSE, FALSE, 3, { SX_TRAP_ID_DISCARD_ING_LSR_NO_LABEL,
                         SX_TRAP_ID_DISCARD_ING_LSR_UC_ET,
                         SX_TRAP_ID_DISCARD_ING_LSR_MC_DMAC }
    },
    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_ROUTER)] =
    { FALSE, FALSE, 5, { SX_TRAP_ID_DISCARD_ROUTER_IRIF_EN,
                         SX_TRAP_ID_DISCARD_ROUTER_ERIF_EN,
                         SX_TRAP_ID_DISCARD_ROUTER_ERIF_FWD,
                         SX_TRAP_ID_DISCARD_ROUTER_LPM4,
                         SX_TRAP_ID_DISCARD_ROUTER_LPM6 }
    },
    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_LSR)] =
    { FALSE, FALSE, 3, { SX_TRAP_ID_DISCARD_LSR_MIN_LABEL,
                         SX_TRAP_ID_DISCARD_LSR_MAX_LABEL,
                         SX_TRAP_ID_DISCARD_LSR_LB }
    },

    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_DEC)] =
    { FALSE, FALSE, 3, { SX_TRAP_ID_DISCARD_DEC_PKT,
                         SX_TRAP_ID_DISCARD_DEC_DIS,
                         SX_TRAP_ID_DISCARD_DEC_NVE_OPTIONS }
    },

    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_OVERLAY_SWITCH)] =
    { FALSE, FALSE, 4, { SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC,
                         SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC,
                         SX_TRAP_ID_DISCARD_ENC_ISOLATION,
                         SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0 }
    },

    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_ISOLATION)] =
    { FALSE, FALSE, 0, { }
    },

    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_NON_ROUTED)] =
    { FALSE, FALSE, 0, { }
    },

    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_EGR_LSR)] =
    { FALSE, FALSE, 3, { SX_TRAP_ID_DISCARD_EGR_LSR_NO_LABEL,
                         SX_TRAP_ID_DISCARD_EGR_LSR_NO_IP,
                         SX_TRAP_ID_DISCARD_EGR_LSR_PHP_NO_IP }
    },
    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_MC_SCOPE)] =
    { FALSE, FALSE, 2, { SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0,
                         SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1 }
    },

    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_ROUTER2)] =
    { FALSE, FALSE, 0, { }
    },

    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_ROUTER3)] =
    { FALSE, FALSE, 0, { }
    },

    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_LSR2)] =
    { FALSE, FALSE, 0, { }
    },

    [SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(SX_TRAP_ID_DISCARD_LSR3)] =
    { FALSE, FALSE, 0, { }
    },
};

static boolean_t host_ifc_db_ipv6_unspecified_sip_is_in_use = FALSE;
static boolean_t host_ifc_db_ipv6_unspecified_dip_is_in_use = FALSE;

static host_ifc_db_profile_cfg_t truncate_profile_cfg_db[SX_TRAP_TRUNCATE_PROFILE_MAX + 1] = {
    {
        {SX_TRAP_TRUNCATE_PROFILE_MAX_SIZE}, FALSE
    },
    {
        {SX_TRAP_TRUNCATE_PROFILE_MAX_SIZE}, FALSE
    },
    {
        {SX_TRAP_TRUNCATE_PROFILE_MAX_SIZE}, FALSE
    }
};
#define __SX_LOG_EXIT(SX_STATUS) __sx_log_exit(SX_STATUS, __func__)
static boolean_t g_is_host_ifc_db_initialized = FALSE;
/************************************************
 *  Local function declarations
 ***********************************************/

static sx_status_t __sx_log_exit(sx_status_t sx_status,
                                 const char *func_name);
static sx_status_t __host_ifc_db_alloc_db(void);
static sx_status_t __host_ifc_db_free_db(void);
static sx_status_t __host_ifc_db_swid_2_trap_groups_alloc(void);
static sx_status_t __host_ifc_db_swid_2_trap_groups_alloc_logic(uint32_t trap_groups_num);
static sx_status_t __host_ifc_db_swid_2_trap_groups_free(void);
static sx_status_t __host_ifc_db_check_hw_trap_group(uint32_t hw_trap_group);
static sx_status_t __host_ifc_db_user_defined_trap_id_to_index(sx_trap_id_t trap_id, uint32_t *index_p);
static sx_status_t __host_ifc_db_extended_trap_id_to_index(const sx_trap_id_t trap_id, uint32_t *index_p);
static sx_status_t __host_ifc_db_discard_map_init();
static sx_status_t __host_ifc_db_trap_id_to_group_list_add(sx_trap_group_t hw_trap_group, sx_trap_id_t trap_id);
static sx_status_t __host_ifc_db_trap_id_from_group_list_remove(sx_trap_group_t hw_trap_group, sx_trap_id_t trap_id);

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t host_ifc_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

sx_status_t host_ifc_db_init(void)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    sxd_status_t sxd_rc = SXD_STATUS_SUCCESS;
    uint32_t     hw_trap_id;
    uint32_t     i = 0;
    uint8_t      j = 0;
    uint32_t     user_trap_index;

    SX_LOG_ENTER();

    memset(&(__host_ifc_db_s), 0, sizeof(host_ifc_db_t));

    rc = __host_ifc_db_alloc_db();
    if (SX_CHECK_FAIL(rc)) {
        return __SX_LOG_EXIT(rc);
    }

    /* set all trap IDs groups to SX_TRAP_GROUP_DISABLE */
    for (i = SX_TRAP_ID_MIN; i <= SX_TRAP_ID_MAX; i++) {
        /* get the hw_trap id from virtual trap id */
        sxd_rc = sxd_dpt_vtrap_virt_to_hw_mapping_get(i, &hw_trap_id);
        if (SXD_CHECK_FAIL(sxd_rc)) {
            SX_LOG_ERR("Failed in sxd_dpt_vtrap_mapping_get, trap id: [%u] , return value: [%s]\n", i,
                       SXD_STATUS_MSG(sxd_rc));
            rc = SX_STATUS_PARAM_ERROR;
            return __SX_LOG_EXIT(rc);
        }

        __host_ifc_db_s.trap_id_2_trap_id_properties[i].trap_id_properties.hw_trap_group = SX_HW_TRAP_GROUP_DISABLE_E;
        __host_ifc_db_s.trap_id_2_trap_id_properties[i].trap_id_properties.hw_trap_id = hw_trap_id;

        rc = host_ifc_db_trap_id_to_group_list_init(i);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to init Host IFC trap id to group list for trap_id: p%u], return value [%s]\n",
                       i, sx_status_str(rc));
            return __SX_LOG_EXIT(rc);
        }

        if (SX_TRAP_ID_USER_CHECK_RANGE(i) == TRUE) {
            rc = __host_ifc_db_user_defined_trap_id_to_index(i, &user_trap_index);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("__host_ifc_db_user_defined_trap_id_to_index for trap id:[%u] failed, return value: [%s]\n",
                           i, sx_status_str(rc));
                return __SX_LOG_EXIT(rc);
            }
            __host_ifc_db_s.user_trap_id[user_trap_index].trap_id_item.trap_id_properties.hw_trap_id = hw_trap_id;
        }
    }

    for (i = 0; i <= SX_USER_DEFINED_TRAPS_NUM; i++) {
        __host_ifc_db_s.user_trap_id[i].trap_id_item.trap_id_properties.hw_trap_group = SX_HW_TRAP_GROUP_DISABLE_E;
    }

    for (j = 0; j <= RM_NUM_OF_SWIDS; j++) {
        for (i = 0; i <= SX_TRAP_GROUP_MAX; i++) {
            __host_ifc_db_s.trap_group_2_hw_trap_group[j].trap_groups[i] = SX_HW_TRAP_GROUP_DISABLE_E;
        }

        for (i = 0; i < rm_resource_global.hw_total_trap_groups_num_max; i++) {
            __host_ifc_db_s.hw_trap_group_2_trap_group[j][i] = SX_TRAP_GROUP_MAX + 1;
        }
    }

    rc = __host_ifc_db_discard_map_init();
    if (SX_CHECK_FAIL(rc)) {
        return __SX_LOG_EXIT(rc);
    }

    g_is_host_ifc_db_initialized = TRUE;

    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_db_deinit(void)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sx_trap_id_t trap_id = SX_TRAP_ID_MIN;

    for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
        err = host_ifc_db_trap_id_to_group_list_deinit(trap_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to deinit Host IFC trap id to group association for trap id [%u].\n", trap_id);
        }
    }

    err = __host_ifc_db_free_db();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to free Host IFC DB.\n");
    }

    g_is_host_ifc_db_initialized = FALSE;
    return err;
}

sx_status_t host_ifc_db_trap_group_map_set(sx_access_cmd_t    cmd,
                                           sx_swid_t          swid,
                                           sx_trap_group_t    trap_group_id,
                                           sx_hw_trap_group_e hw_trap_group_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_group_map_set: swid exceed range\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (trap_group_id > SX_TRAP_GROUP_MAX) {
        SX_LOG_ERR("host_ifc_db_trap_group_map_set: trap group id is bigger than group max\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = __host_ifc_db_check_hw_trap_group(hw_trap_group_id);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        __host_ifc_db_s.trap_group_2_hw_trap_group[swid].trap_groups[trap_group_id] = hw_trap_group_id;
        __host_ifc_db_s.hw_trap_group_2_trap_group[swid][hw_trap_group_id] = trap_group_id;
        break;

    case SX_ACCESS_CMD_DELETE:
        __host_ifc_db_s.trap_group_2_hw_trap_group[swid].trap_groups[trap_group_id] = SX_HW_TRAP_GROUP_DISABLE_E;
        __host_ifc_db_s.hw_trap_group_2_trap_group[swid][hw_trap_group_id] = SX_TRAP_GROUP_MAX + 1;
        break;

    default:
        rc = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR("Received invalid command %u\n", cmd);
        goto out;
    }

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_db_trap_group_map_get(sx_swid_t           swid,
                                           sx_trap_group_t     trap_group_id,
                                           sx_hw_trap_group_e *hw_trap_group_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (hw_trap_group_id == NULL) {
        SX_LOG_ERR("host_ifc_db_trap_group_map_get: hw_trap_group_id is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_group_map_get: swid range error\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (trap_group_id > SX_TRAP_GROUP_MAX) {
        SX_LOG_ERR("host_ifc_db_trap_group_map_get: trap group id bigger than max group\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    *hw_trap_group_id = __host_ifc_db_s.trap_group_2_hw_trap_group[swid].trap_groups[trap_group_id];

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_db_allocate_trap_group(sx_swid_t swid, sx_trap_group_t *trap_group_id_p)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    sx_trap_group_t trap_group_id = 0;

    SX_LOG_ENTER();

    if (trap_group_id_p == NULL) {
        SX_LOG_ERR("host_ifc_db_allocate_trap_group: trap_group_id_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_group_map_get: swid range error\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    for (trap_group_id = 0; trap_group_id <= SX_TRAP_GROUP_MAX; trap_group_id++) {
        if (__host_ifc_db_s.trap_group_2_hw_trap_group[swid].trap_groups[trap_group_id] ==
            SX_HW_TRAP_GROUP_DISABLE_E) {
            *trap_group_id_p = trap_group_id;
            break;
        }
    }

    if (trap_group_id > SX_TRAP_GROUP_MAX) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to allocate SW trap group.\n");
        goto out;
    }

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_db_trap_group_reverse_map_get(sx_swid_t          swid,
                                                   sx_hw_trap_group_e hw_trap_group_id,
                                                   sx_trap_group_t   *trap_group_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (trap_group_id == NULL) {
        SX_LOG_ERR("host_ifc_db_trap_group_reverse_map_get: trap_group_id is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_group_reverse_map_get: swid range error\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = __host_ifc_db_check_hw_trap_group(hw_trap_group_id);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    *trap_group_id = __host_ifc_db_s.hw_trap_group_2_trap_group[swid][hw_trap_group_id];

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_db_trap_group_properties_set(sx_access_cmd_t                   cmd,
                                                  sx_swid_t                         swid,
                                                  sx_hw_trap_group_e                trap_group_id,
                                                  host_ifc_trap_group_properties_t *trap_group_properties)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(trap_group_properties,
                                          "trap_group_properties"))) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    rc = __host_ifc_db_check_hw_trap_group(trap_group_id);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_group_properties_set: swid range error\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        if (trap_group_properties->type == SXD_HOST_IF_PATH_TYPE_LOCAL_E) {
            /* Ignore the add_timestamp field, the trap group will always contain timestamp. */
            rc = rdq_timestamp_state_set(trap_group_properties->path.local_path.rdq,
                                         TRUE,
                                         trap_group_properties->timestamp_source ==
                                         SX_PACKET_TIMESTAMP_SOURCE_HW_UTC_E);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set trap group timestamp state, rdq: %u, return value: [%s]\n",
                           trap_group_properties->path.local_path.rdq, sx_status_str(rc));
                goto out;
            }

            /* if HW policer is configured, we want this to be high priority for CPU.
             * otherwise, it will be low priority */
            rc = rdq_cpu_priority_set(trap_group_properties->path.local_path.rdq,
                                      trap_group_properties->policer_id_enabled);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to set trap group CPU priority, rdq: %u, error: [%s]\n",
                           trap_group_properties->path.local_path.rdq, sx_status_str(rc));
                goto out;
            }
        }

        memcpy(&(__host_ifc_db_s.swid_2_trap_groups[swid][trap_group_id].trap_group_properties),
               trap_group_properties,
               sizeof(host_ifc_trap_group_properties_t));
        /* group is now configured */
        __host_ifc_db_s.swid_2_trap_groups[swid][trap_group_id].is_configured = TRUE;
        SX_LOG_DBG("Group [%u] properties were successfully inserted to HOST INTERFACE DB\n", trap_group_id);
        break;

    case SX_ACCESS_CMD_DELETE:
        /* set group as not configured */
        __host_ifc_db_s.swid_2_trap_groups[swid][trap_group_id].is_configured = FALSE;
        SX_LOG_DBG("Group [%u] was successfully removed from HOST INTERFACE DB\n", trap_group_id);
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("host_ifc_db_trap_group_properties_set: Reached default switch case , "
                   "wrong access command [%s]\n", sx_access_cmd_str(cmd));
        goto out;
    }

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_db_trap_group_properties_get(sx_swid_t                         swid,
                                                  sx_hw_trap_group_e                trap_group,
                                                  host_ifc_trap_group_properties_t *trap_group_properties,
                                                  boolean_t                        *is_configured)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(trap_group_properties, "Trap group properties"))) {
        SX_LOG_ERR("trap group properties is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(is_configured, "is_configured"))) {
        SX_LOG_ERR("trap group properties is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    rc = __host_ifc_db_check_hw_trap_group(trap_group);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("SWID [%u] is not in range [%u..%u]\n", swid, 0, rm_resource_global.swid_id_max);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    memcpy(trap_group_properties,
           &(__host_ifc_db_s.swid_2_trap_groups[swid][trap_group].trap_group_properties),
           sizeof(host_ifc_trap_group_properties_t));
    *is_configured = __host_ifc_db_s.swid_2_trap_groups[swid][trap_group].is_configured;
    SX_LOG_DBG("Group [%u] properties (SWID [%u]) were successfully fetched from HOST INTERFACE DB.\n",
               trap_group, swid);

out:
    return __SX_LOG_EXIT(rc);
}


static sx_status_t __host_ifc_db_user_defined_trap_id_to_index(sx_trap_id_t trap_id, uint32_t *index_p)
{
    uint32_t    index, i;
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (SX_TRAP_ID_USER_L4_PORT_CHECK_RANGE(trap_id) == TRUE) {
        index = trap_id - SX_TRAP_ID_USER_BASE;
    } else if (SX_TRAP_ID_USER_ATTR_CHECK_RANGE(trap_id) == TRUE) {
        for (i = 0; i < SX_USER_ATTR_TRAPS_NUM; i++) {
            if (user_attr_traps_list[i] == trap_id) {
                index = SX_USER_DEFINED_L4_PORTS_TRAPS_NUM + i;
                break;
            }
        }

        if (i == SX_USER_ATTR_TRAPS_NUM) {
            SX_LOG_ERR("__host_ifc_db_user_defined_trap_id_to_index failed , "
                       "unsupported trap id:%d \n", trap_id);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    } else if (SX_TRAP_ID_USER_ATTR_EXT_CHECK_RANGE(trap_id) == TRUE) {
        for (i = 0; i < SX_USER_ATTR_EXT_TRAPS_NUM; i++) {
            if (user_attr_ext_traps_list[i] == trap_id) {
                index = SX_USER_DEFINED_L4_PORTS_TRAPS_NUM + SX_USER_ATTR_TRAPS_NUM + i;
                break;
            }
        }

        if (i == SX_USER_ATTR_EXT_TRAPS_NUM) {
            SX_LOG_ERR("__host_ifc_db_user_defined_trap_id_to_index failed , "
                       "unsupported trap id:%d \n", trap_id);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    } else {
        SX_LOG_ERR("__host_ifc_db_user_defined_trap_id_to_index failed , "
                   "unsupported trap id:%d \n", trap_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (index >= SX_USER_DEFINED_TRAPS_NUM) {
        SX_LOG_ERR("trap_id %d calculated index %d is out of range [0..%d] \n",
                   trap_id, index, (int)(SX_USER_DEFINED_TRAPS_NUM - 1));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (index_p != NULL) {
        *index_p = index;
    }
out:
    return rc;
}

sx_status_t host_ifc_db_trap_id_properties_set(sx_trap_id_t                  trap_id,
                                               host_ifc_trap_id_properties_t trap_id_properties,
                                               boolean_t                     is_associated,
                                               boolean_t                     is_in_use)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    index = 0;

    SX_LOG_ENTER();

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_id_properties_set trap_id param error, trap_id: %u\n", trap_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_USER_CHECK_RANGE(trap_id) == TRUE) {
        rc = __host_ifc_db_user_defined_trap_id_to_index(trap_id, &index);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("__host_ifc_db_user_defined_trap_id_to_index for trap id:[%u] failed, return value: [%s]\n",
                       trap_id, sx_status_str(rc));
            return __SX_LOG_EXIT(rc);
        }
        memcpy(&(__host_ifc_db_s.user_trap_id[index].trap_id_item.trap_id_properties),
               &(trap_id_properties),
               sizeof(host_ifc_trap_id_properties_t));
        __host_ifc_db_s.user_trap_id[index].trap_id_item.is_associated = is_associated;
        goto out;
    }

    if (SX_TRAP_ID_EXTENDED_DISCARD_CHECK_RANGE(trap_id) == TRUE) {
        rc = host_ifc_db_extended_discard_trap_set(trap_id, is_in_use);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("host_ifc_db_extended_discard_trap_set for trap id:[%u] failed, return value: [%s]\n",
                       trap_id, sx_status_str(rc));
            return __SX_LOG_EXIT(rc);
        }
    }

    if (SX_TRAP_ID_DISCARD_CHECK_RANGE(trap_id) == TRUE) {
        rc = host_ifc_db_discard_trap_set(trap_id, is_in_use);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("host_ifc_db_discard_trap_set for trap id:[%u] failed, return value: [%s]\n",
                       trap_id, sx_status_str(rc));
            return __SX_LOG_EXIT(rc);
        }
    }

    if (trap_id == SX_TRAP_ID_IPV6_UNSPECIFIED_SIP) {
        host_ifc_db_ipv6_unspecified_sip_is_in_use = is_in_use;
    } else if (trap_id == SX_TRAP_ID_IPV6_UNSPECIFIED_DIP) {
        host_ifc_db_ipv6_unspecified_dip_is_in_use = is_in_use;
    }

    memcpy(&(__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id]),
           &(trap_id_properties),
           sizeof(host_ifc_trap_id_properties_t));
    __host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].is_associated = is_associated;
    SX_LOG_DBG("Trap id [%u] properties were successfully inserted to HOST INTERFACE DB\n", trap_id);

out:
    return __SX_LOG_EXIT(rc);
}

sx_status_t host_ifc_db_user_trap_id_set(sx_access_cmd_t                       cmd,
                                         const sx_trap_id_t                    trap_id,
                                         sx_trap_id_user_defined_attributes_t *user_defined_attributes_p)
{
    uint32_t    index = 0;
    sx_status_t rc;

    rc = __host_ifc_db_user_defined_trap_id_to_index(trap_id, &index);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("__host_ifc_db_user_defined_trap_id_to_index for trap id:[%u] failed, return value: [%s]\n",
                   trap_id, sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    if (cmd == SX_ACCESS_CMD_ADD) {
        __host_ifc_db_s.user_trap_id[index].trap_id = trap_id;
        __host_ifc_db_s.user_trap_id[index].trap_attributes = *user_defined_attributes_p;
    } else { /* cmd == SX_ACCESS_CMD_DELETE */
        __host_ifc_db_s.user_trap_id[index].trap_id = 0;
        SX_MEM_CLR(__host_ifc_db_s.user_trap_id[index].trap_attributes);
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t host_ifc_db_user_trap_id_get(const sx_trap_id_t                    trap_id,
                                         sx_trap_id_user_defined_attributes_t *user_defined_attributes_p)
{
    uint32_t    index = 0;
    sx_status_t rc;

    rc = __host_ifc_db_user_defined_trap_id_to_index(trap_id, &index);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("__host_ifc_db_user_defined_trap_id_to_index for trap id:[%u] failed, return value: [%s]\n",
                   trap_id, sx_status_str(rc));
        return __SX_LOG_EXIT(rc);
    }

    if (__host_ifc_db_s.user_trap_id[index].trap_id != trap_id) {
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    if (user_defined_attributes_p != NULL) {
        *user_defined_attributes_p = __host_ifc_db_s.user_trap_id[index].trap_attributes;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t host_ifc_db_trap_id_properties_get(sx_trap_id_t trap_id, host_ifc_trap_id_properties_t *trap_id_properties)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    index = 0;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(trap_id_properties, "trap_id_properties"))) {
        SX_LOG_ERR("host_ifc_db_trap_id_properties_get trap_id_properties param error\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_id_properties_get trap_id param error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_USER_CHECK_RANGE(trap_id) == TRUE) {
        err = __host_ifc_db_user_defined_trap_id_to_index(trap_id, &index);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__host_ifc_db_user_defined_trap_id_to_index for trap id:[%u] failed, return value: [%s]\n",
                       trap_id, sx_status_str(err));
            return __SX_LOG_EXIT(err);
        }

        memcpy(trap_id_properties,
               &(__host_ifc_db_s.user_trap_id[index].trap_id_item.trap_id_properties),
               sizeof(host_ifc_trap_id_properties_t));
        goto out;
    }

    memcpy(trap_id_properties,
           &(__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_id_properties),
           sizeof(host_ifc_trap_id_properties_t));

    SX_LOG_DBG("Trap id [%u] properties were successfully fetched from HOST INTERFACE DB\n", trap_id);

out:
    return err;
}

static sx_status_t __sx_log_exit(sx_status_t sx_status, const char *func_name)
{
    SX_LOG_FUNC_WRAP(func_name, "%s - left\n");
    return sx_status;
}

sx_status_t host_ifc_db_spectrum_hw_trap_group_get(sx_swid_t             swid,
                                                   sx_trap_priority_t    trap_priority,
                                                   sx_api_pci_profile_t *pci_profile,
                                                   uint32_t             *hw_trap_group)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    uint32_t                        trap_group_idx = 0;
    int64_t                         index_with_lowest_prio = -1;
    boolean_t                       found_same_prio = FALSE;
    uint8_t                         rdq_count = 0;
    host_ifc_internal_trap_groups_t internal_trap_groups;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(pci_profile, "pci_profile"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_trap_group, "hw_trap_group"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (swid > rm_resource_global.swid_id_max) {
        SX_LOG_ERR("%s: swid %u exceeds range\n", __func__, swid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (RM_TRAP_GROUP_PRIORITY_CHECK_RANGE(trap_priority) == FALSE) {
        SX_LOG_ERR("Priority (%u) exceeds range (%u - %u)\n", trap_priority,
                   rm_resource_global.trap_group_priority_min,
                   rm_resource_global.trap_group_priority_max);
        return __SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    err = host_ifc_internal_trap_groups_from_profile_get(pci_profile, &internal_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get internal trap groups, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    /*
     * Scan HW trap group map until the first free entry with the same priority is reached.
     * For the priorities other than the lowest priority, if no entry with the same priority
     * is found, then we try to find a free entry with the lowest priority. If entries with
     * the same priority are found but none of them are free, SX_STATUS_NO_RESOURCES is returned.
     * pci_profile.rdq_count[swid] number will be normalized according chip capability
     * For example , if user config 56 rdq but capability support 36 only , the number
     * of rdqs will be normalized to 36 by the driver.
     */
    rdq_count = (pci_profile->rdq_count[swid] == 0) ? 0 : pci_profile->rdq_count[swid] - 1;
    for (trap_group_idx = 0; trap_group_idx < rdq_count; trap_group_idx++) {
        /*
         * Skip internally allocated HW trap groups :
         *
         * Emad, Accuflow, SPAN Trap group, Mirror. MOCS trap group of Spectrum
         *
         * so user won't be able to override their configuration.
         */
        if ((pci_profile->emad_rdq == trap_group_idx) ||
            (internal_trap_groups.accuflow_trap_group == trap_group_idx) ||
            (internal_trap_groups.mocs_trap_group == trap_group_idx) ||
            (internal_trap_groups.mirror_trap_group == trap_group_idx) ||
            (SX_CHECK_RANGE(SPECTRUM_SPAN_TRAP_GROUPS_START, trap_group_idx,
                            (SPECTRUM_SPAN_TRAP_GROUPS_START + SPECTRUM_SPAN_TRAP_GROUPS_NUM - 1)))
            ) {
            /* EMAD RDQ can occur in between the normal RDQ with the addition of
             * What just happened feature in SPC
             */
            continue;
        }

        if ((pci_profile->rdq_properties[trap_group_idx].priority == trap_priority) &&
            (found_same_prio == FALSE)) {
            found_same_prio = TRUE;
        }

        if ((__host_ifc_db_s.hw_trap_group_2_trap_group[swid][trap_group_idx] ==
             SX_TRAP_GROUP_MAX + 1) &&
            (pci_profile->rdq_properties[trap_group_idx].priority == trap_priority)) {
            *hw_trap_group = trap_group_idx;
            break;
        } else {
            if ((__host_ifc_db_s.hw_trap_group_2_trap_group[swid][trap_group_idx] ==
                 SX_TRAP_GROUP_MAX + 1) &&
                (pci_profile->rdq_properties[trap_group_idx].priority ==
                 SX_TRAP_PRIORITY_MIN) &&
                (index_with_lowest_prio == -1)) {
                index_with_lowest_prio = trap_group_idx;
            }
        }
    }

    /* If no HW trap groups are free, inform the caller, but let them decide
     * whether or not to log an error */
    if (trap_group_idx == rdq_count) {
        if (index_with_lowest_prio == -1) {
            err = SX_STATUS_NO_RESOURCES;
        } else {
            if ((trap_priority != SX_TRAP_PRIORITY_MIN) && found_same_prio) {
                err = SX_STATUS_NO_RESOURCES;
            } else {
                *hw_trap_group = index_with_lowest_prio;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_db_alloc_db(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint8_t     i = 0;
    uint32_t    j = 0;

    /* Dynamically allocate memory for local DB based on resource manager values.
     * Always allocate 1 more than the number of SWIDs because of the stacking SWID. */
    __host_ifc_db_s.trap_group_2_hw_trap_group =
        cl_malloc((RM_NUM_OF_SWIDS + 1) * sizeof(host_ifc_trap_group_arr_t));
    if (!__host_ifc_db_s.trap_group_2_hw_trap_group) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for trap group map\n");
        goto out;
    }

    __host_ifc_db_s.hw_trap_group_2_trap_group =
        cl_malloc((RM_NUM_OF_SWIDS + 1) * sizeof(uint32_t *));
    if (!__host_ifc_db_s.hw_trap_group_2_trap_group) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for HW trap group map\n");
        goto out;
    }

    memset(__host_ifc_db_s.hw_trap_group_2_trap_group, 0,
           (RM_NUM_OF_SWIDS + 1) * sizeof(uint32_t *));
    for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
        __host_ifc_db_s.hw_trap_group_2_trap_group[i] =
            cl_malloc(rm_resource_global.hw_total_trap_groups_num_max * sizeof(uint32_t));
        if (!__host_ifc_db_s.hw_trap_group_2_trap_group[i]) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for HW trap group map, entry %u\n", i);
            goto out;
        }
        memset(__host_ifc_db_s.hw_trap_group_2_trap_group[i], 0,
               rm_resource_global.hw_total_trap_groups_num_max * sizeof(uint32_t));
    }

    __host_ifc_db_s.swid_2_trap_filters =
        cl_malloc((RM_NUM_OF_SWIDS + 1) * sizeof(cl_qlist_t*));
    if (!__host_ifc_db_s.swid_2_trap_filters) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for trap filter map\n");
        goto out;
    }
    memset(__host_ifc_db_s.swid_2_trap_filters, 0,
           (RM_NUM_OF_SWIDS + 1) * sizeof(cl_qlist_t*));

    for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
        __host_ifc_db_s.swid_2_trap_filters[i] =
            cl_malloc((SX_TRAP_ID_MAX + 1) * sizeof(cl_qlist_t));
        if (!__host_ifc_db_s.swid_2_trap_filters[i]) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for trap filter map, entry %u\n", i);
            goto out;
        }
        memset(__host_ifc_db_s.swid_2_trap_filters[i], 0,
               (SX_TRAP_ID_MAX + 1) * sizeof(cl_qlist_t));
        for (j = 0; j <= SX_TRAP_ID_MAX; j++) {
            cl_qlist_init(&(__host_ifc_db_s.swid_2_trap_filters[i][j]));
        }
    }

    __host_ifc_db_s.swid_2_trap_registers =
        cl_malloc((RM_NUM_OF_SWIDS + 1) * sizeof(cl_qlist_t*));
    if (!__host_ifc_db_s.swid_2_trap_registers) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for trap register map\n");
        goto out;
    }
    memset(__host_ifc_db_s.swid_2_trap_registers, 0,
           (RM_NUM_OF_SWIDS + 1) * sizeof(cl_qlist_t*));

    for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
        __host_ifc_db_s.swid_2_trap_registers[i] =
            cl_malloc((SX_TRAP_ID_MAX + 1) * sizeof(cl_qlist_t));
        if (!__host_ifc_db_s.swid_2_trap_registers[i]) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for trap register map, entry %u\n", i);
            goto out;
        }
        memset(__host_ifc_db_s.swid_2_trap_registers[i], 0,
               (SX_TRAP_ID_MAX + 1) * sizeof(cl_qlist_t));
        for (j = 0; j <= SX_TRAP_ID_MAX; j++) {
            cl_qlist_init(&(__host_ifc_db_s.swid_2_trap_registers[i][j]));
        }
    }

    __host_ifc_db_s.swid_2_trap_channels_filters =
        cl_malloc((RM_NUM_OF_SWIDS + 1) * sizeof(cl_qlist_t*));
    if (!__host_ifc_db_s.swid_2_trap_channels_filters) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for trap channel filter map\n");
        goto out;
    }
    memset(__host_ifc_db_s.swid_2_trap_channels_filters, 0,
           (RM_NUM_OF_SWIDS + 1) * sizeof(cl_qlist_t*));

    for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
        __host_ifc_db_s.swid_2_trap_channels_filters[i] =
            cl_malloc((SX_TRAP_ID_MAX + 1) * sizeof(cl_qlist_t));
        if (!__host_ifc_db_s.swid_2_trap_channels_filters[i]) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for trap channel filter map, entry %u\n", i);
            goto out;
        }
        memset(__host_ifc_db_s.swid_2_trap_channels_filters[i], 0,
               (SX_TRAP_ID_MAX + 1) * sizeof(cl_qlist_t));
        for (j = 0; j <= SX_TRAP_ID_MAX; j++) {
            cl_qlist_init(&(__host_ifc_db_s.swid_2_trap_channels_filters[i][j]));
        }
    }

    __host_ifc_db_s.swid_2_trap_user_channels =
        cl_malloc((RM_NUM_OF_SWIDS + 1) * sizeof(cl_qlist_t*));
    if (!__host_ifc_db_s.swid_2_trap_user_channels) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for trap user channel map\n");
        goto out;
    }
    memset(__host_ifc_db_s.swid_2_trap_user_channels, 0,
           (RM_NUM_OF_SWIDS + 1) * sizeof(cl_qlist_t*));

    for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
        __host_ifc_db_s.swid_2_trap_user_channels[i] =
            cl_malloc((SX_TRAP_ID_MAX + 1) * sizeof(cl_qlist_t));
        if (!__host_ifc_db_s.swid_2_trap_user_channels[i]) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for trap user channel map, entry %u\n", i);
            goto out;
        }
        memset(__host_ifc_db_s.swid_2_trap_user_channels[i], 0,
               (SX_TRAP_ID_MAX + 1) * sizeof(cl_qlist_t));
        for (j = 0; j <= SX_TRAP_ID_MAX; j++) {
            cl_qlist_init(&(__host_ifc_db_s.swid_2_trap_user_channels[i][j]));
        }
    }

    err = __host_ifc_db_swid_2_trap_groups_alloc();
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_db_free_db(void)
{
    sx_status_t                          status = SX_STATUS_SUCCESS;
    uint8_t                              i = 0;
    uint32_t                             j = 0;
    cl_qlist_t                          *db_list = NULL;
    cl_list_item_t                      *list_item = NULL;
    host_ifc_trap_filter_item_t         *filter_item = NULL;
    host_ifc_trap_register_item_t       *register_item = NULL;
    host_ifc_trap_user_channel_item_t   *user_channel_item = NULL;
    host_ifc_trap_channel_filter_item_t *channel_filter_item = NULL;
    cl_list_item_t                      *pid_list_item = NULL;
    host_ifc_pid_item_t                 *pid_item = NULL;
    cl_qlist_t                          *pid_list = NULL;

    if (__host_ifc_db_s.trap_group_2_hw_trap_group) {
        cl_free(__host_ifc_db_s.trap_group_2_hw_trap_group);
        __host_ifc_db_s.trap_group_2_hw_trap_group = NULL;
    }

    if (__host_ifc_db_s.hw_trap_group_2_trap_group) {
        for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
            if (__host_ifc_db_s.hw_trap_group_2_trap_group[i]) {
                cl_free(__host_ifc_db_s.hw_trap_group_2_trap_group[i]);
                __host_ifc_db_s.hw_trap_group_2_trap_group[i] = NULL;
            }
        }
        cl_free(__host_ifc_db_s.hw_trap_group_2_trap_group);
        __host_ifc_db_s.hw_trap_group_2_trap_group = NULL;
    }

    if (__host_ifc_db_s.swid_2_trap_filters) {
        for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
            if (__host_ifc_db_s.swid_2_trap_filters[i]) {
                for (j = 0; j <= SX_TRAP_ID_MAX; j++) {
                    db_list = &(__host_ifc_db_s.swid_2_trap_filters[i][j]);
                    while (!cl_is_qlist_empty(db_list)) {
                        list_item = cl_qlist_remove_head(db_list);
                        filter_item = cl_item_obj(list_item, filter_item, list_item);
                        cl_free(filter_item);
                    }
                }
                cl_free(__host_ifc_db_s.swid_2_trap_filters[i]);
                __host_ifc_db_s.swid_2_trap_filters[i] = NULL;
            }
        }
        cl_free(__host_ifc_db_s.swid_2_trap_filters);
        __host_ifc_db_s.swid_2_trap_filters = NULL;
    }

    if (__host_ifc_db_s.swid_2_trap_registers) {
        for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
            if (__host_ifc_db_s.swid_2_trap_registers[i]) {
                for (j = 0; j <= SX_TRAP_ID_MAX; j++) {
                    db_list = &(__host_ifc_db_s.swid_2_trap_registers[i][j]);
                    while (!cl_is_qlist_empty(db_list)) {
                        list_item = cl_qlist_remove_head(db_list);
                        register_item = cl_item_obj(list_item, register_item, list_item);
                        if (register_item->user_channel.type == SX_USER_CHANNEL_TYPE_FD) {
                            pid_list = &(register_item->pid_list);
                            while (!cl_is_qlist_empty(pid_list)) {
                                pid_list_item = cl_qlist_remove_head(pid_list);
                                pid_item = cl_item_obj(pid_list_item, pid_item, list_item);
                                cl_free(pid_item);
                            }
                        }
                        cl_free(register_item);
                    }
                }
                cl_free(__host_ifc_db_s.swid_2_trap_registers[i]);
                __host_ifc_db_s.swid_2_trap_registers[i] = NULL;
            }
        }
        cl_free(__host_ifc_db_s.swid_2_trap_registers);
        __host_ifc_db_s.swid_2_trap_registers = NULL;
    }

    if (__host_ifc_db_s.swid_2_trap_channels_filters) {
        for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
            if (__host_ifc_db_s.swid_2_trap_channels_filters[i]) {
                for (j = 0; j <= SX_TRAP_ID_MAX; j++) {
                    db_list = &(__host_ifc_db_s.swid_2_trap_channels_filters[i][j]);
                    while (!cl_is_qlist_empty(db_list)) {
                        list_item = cl_qlist_remove_head(db_list);
                        channel_filter_item = cl_item_obj(list_item, channel_filter_item, list_item);
                        if (channel_filter_item->user_channel.type == SX_USER_CHANNEL_TYPE_FD) {
                            pid_list = &(channel_filter_item->pid_list);
                            while (!cl_is_qlist_empty(pid_list)) {
                                pid_list_item = cl_qlist_remove_head(pid_list);
                                pid_item = cl_item_obj(pid_list_item, pid_item, list_item);
                                cl_free(pid_item);
                            }
                        }
                        cl_free(channel_filter_item);
                    }
                }
                cl_free(__host_ifc_db_s.swid_2_trap_channels_filters[i]);
                __host_ifc_db_s.swid_2_trap_channels_filters[i] = NULL;
            }
        }
        cl_free(__host_ifc_db_s.swid_2_trap_channels_filters);
        __host_ifc_db_s.swid_2_trap_channels_filters = NULL;
    }

    if (__host_ifc_db_s.swid_2_trap_user_channels) {
        for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
            if (__host_ifc_db_s.swid_2_trap_user_channels[i]) {
                for (j = 0; j <= SX_TRAP_ID_MAX; j++) {
                    db_list = &(__host_ifc_db_s.swid_2_trap_user_channels[i][j]);
                    while (!cl_is_qlist_empty(db_list)) {
                        list_item = cl_qlist_remove_head(db_list);
                        user_channel_item = cl_item_obj(list_item, user_channel_item, list_item);
                        if (user_channel_item->user_channel.type == SX_USER_CHANNEL_TYPE_FD) {
                            pid_list = &(user_channel_item->pid_list);
                            while (!cl_is_qlist_empty(pid_list)) {
                                pid_list_item = cl_qlist_remove_head(pid_list);
                                pid_item = cl_item_obj(pid_list_item, pid_item, list_item);
                                cl_free(pid_item);
                            }
                        }
                        cl_free(user_channel_item);
                    }
                }
                cl_free(__host_ifc_db_s.swid_2_trap_user_channels[i]);
                __host_ifc_db_s.swid_2_trap_user_channels[i] = NULL;
            }
        }
        cl_free(__host_ifc_db_s.swid_2_trap_user_channels);
        __host_ifc_db_s.swid_2_trap_user_channels = NULL;
    }

    status = __host_ifc_db_swid_2_trap_groups_free();
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to free HOST IFC swid_2_trap_groups DB, err: [%s]\n",
                   sx_status_str(status));
        goto out;
    }

out:
    return status;
}

static sx_status_t __host_ifc_db_swid_2_trap_groups_alloc(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    num_trap_groups = 0;

    err = host_ifc_hw_trap_group_num_get(&num_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get number of HW trap groups, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_db_swid_2_trap_groups_alloc_logic(num_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_db_swid_2_trap_groups_alloc_logic(uint32_t trap_groups_num)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint8_t     i = 0;
    uint32_t    trap_group_idx = 0;
    cl_status_t cl_rc = CL_SUCCESS;

    __host_ifc_db_s.swid_2_trap_groups =
        cl_malloc((RM_NUM_OF_SWIDS + 1) * sizeof(host_ifc_trap_group_properties_item_t *));
    if (!__host_ifc_db_s.swid_2_trap_groups) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for SWID to trap group map\n");
        goto out;
    }

    memset(__host_ifc_db_s.swid_2_trap_groups, 0,
           (RM_NUM_OF_SWIDS + 1) * sizeof(host_ifc_trap_group_properties_item_t *));
    for (i = 0; i <= RM_NUM_OF_SWIDS; i++) {
        __host_ifc_db_s.swid_2_trap_groups[i] =
            cl_malloc(trap_groups_num * sizeof(host_ifc_trap_group_properties_item_t));
        if (!__host_ifc_db_s.swid_2_trap_groups[i]) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for SWID to trap group map, entry %u\n", i);
            goto out;
        }
        memset(__host_ifc_db_s.swid_2_trap_groups[i], 0,
               trap_groups_num * sizeof(host_ifc_trap_group_properties_item_t));

        /* Init per trap group item the 'associated_trap_id_list' property */
        for (trap_group_idx = 0; trap_group_idx < trap_groups_num; trap_group_idx++) {
            cl_rc = cl_list_init(&(__host_ifc_db_s.swid_2_trap_groups[i][trap_group_idx].associated_trap_id_list), 1);
            if (CL_SUCCESS != cl_rc) {
                cl_list_destroy(&(__host_ifc_db_s.swid_2_trap_groups[i][trap_group_idx].associated_trap_id_list));
                SX_LOG_ERR("Failed to init list of trap IDs\n");
                err = cl_status_to_sx_status(cl_rc);
                goto out;
            }
        }
    }

out:
    return __SX_LOG_EXIT(err);
}

static sx_status_t __host_ifc_db_swid_2_trap_groups_free(void)
{
    sx_status_t  status = SX_STATUS_SUCCESS;
    uint32_t     trap_groups_num = 0;
    cl_list_t   *associated_trap_id_list_p = NULL;
    sx_swid_id_t swid = 0;
    uint32_t     group_id = 0;

    if (__host_ifc_db_s.swid_2_trap_groups) {
        for (swid = 0; swid <= RM_NUM_OF_SWIDS; swid++) {
            if (__host_ifc_db_s.swid_2_trap_groups[swid]) {
                status = host_ifc_hw_trap_group_num_get(&trap_groups_num);
                if (SX_CHECK_FAIL(status)) {
                    SX_LOG_ERR("Failed to get number of HW trap groups, return value: [%s]\n",
                               sx_status_str(status));
                    goto out;
                }
                for (group_id = 0; group_id < trap_groups_num; group_id++) {
                    associated_trap_id_list_p =
                        &(__host_ifc_db_s.swid_2_trap_groups[swid][group_id].associated_trap_id_list);
                    if (cl_is_list_inited(associated_trap_id_list_p)) {
                        cl_list_remove_all(associated_trap_id_list_p);
                        cl_list_destroy(associated_trap_id_list_p);
                    }
                }
                cl_free(__host_ifc_db_s.swid_2_trap_groups[swid]);
                __host_ifc_db_s.swid_2_trap_groups[swid] = NULL;
            }
        }
        cl_free(__host_ifc_db_s.swid_2_trap_groups);
        __host_ifc_db_s.swid_2_trap_groups = NULL;
    }

out:
    return status;
}

static sx_status_t __host_ifc_db_check_hw_trap_group(uint32_t hw_trap_group)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    num_trap_groups = 0;

    err = host_ifc_hw_trap_group_num_get(&num_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get number of HW trap groups, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    if (hw_trap_group >= num_trap_groups) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("HW trap group id %u exceeds max.\n", hw_trap_group);
        goto out;
    }

out:
    return __SX_LOG_EXIT(err);
}

sx_status_t host_ifc_db_trap_group_iter_get(const sx_access_cmd_t         cmd,
                                            const sx_swid_id_t            swid,
                                            const sx_trap_group_t         trap_group_id,
                                            const sx_trap_group_filter_t *filter_p,
                                            sx_trap_group_t              *trap_group_id_list_p,
                                            uint32_t                     *trap_group_id_cnt_p)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    length_t           size = 0;
    length_t           max_size = 0;
    sx_trap_group_t    current_trap_group = 0;
    sx_hw_trap_group_e hw_trap_group;
    boolean_t          is_get_count = FALSE;
    boolean_t          is_configured = FALSE;
    sx_swid_id_t       real_swid = swid;

    UNUSED_PARAM(filter_p);

    SX_LOG_ENTER();

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_group_iter_get: swid range error, swid: %u\n", swid);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (NULL == trap_group_id_cnt_p) {
        SX_LOG_ERR("trap_group_id_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*trap_group_id_cnt_p > 0) && (NULL == trap_group_id_list_p)) {
        SX_LOG_ERR("*trap_group_id_cnt_p is not 0 but trap_group_id_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        real_swid = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    size = 0;
    max_size = *trap_group_id_cnt_p;

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (max_size == 0) {
            /* Get the total count of trap group IDs */
            current_trap_group = 0;
            max_size = SX_TRAP_GROUP_MAX + 1;
            is_get_count = TRUE;
        } else {
            /* GET single trap group ID matching key. (force count to 1) */
            current_trap_group = trap_group_id;
            max_size = 1;
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        current_trap_group = 0;
        break;

    case SX_ACCESS_CMD_GETNEXT:
        current_trap_group = trap_group_id + 1;
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

    while (size < max_size) {
        if (current_trap_group > SX_TRAP_GROUP_MAX) {
            break;
        }
        hw_trap_group = __host_ifc_db_s.trap_group_2_hw_trap_group[real_swid].trap_groups[current_trap_group];
        if (hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
            ++current_trap_group;
            continue;
        }
        is_configured = __host_ifc_db_s.swid_2_trap_groups[real_swid][hw_trap_group].is_configured;
        if (is_configured) {
            if (!is_get_count) {
                trap_group_id_list_p[size] = current_trap_group;
            }
            ++size;
        }
        ++current_trap_group;
    }

    *trap_group_id_cnt_p = size;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_trap_filter_get(const sx_access_cmd_t  cmd,
                                        const sx_swid_t        swid,
                                        const sx_trap_id_t     trap_id,
                                        const sx_port_log_id_t log_port_id,
                                        sx_port_log_id_t      *log_port_list_p,
                                        length_t              *log_port_cnt_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_swid_t                    swid_in_db = swid;
    cl_list_item_t              *start_item = NULL;
    cl_qlist_t                  *db_list = NULL;
    host_ifc_trap_filter_item_t *filter_item = NULL;
    length_t                     size = 0;
    length_t                     max_size = 0;

    SX_LOG_ENTER();

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_filter_get: swid range error, swid: %u\n", swid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_filter_get trap_id range error\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == log_port_cnt_p) {
        SX_LOG_ERR("log_port_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*log_port_cnt_p > 0) && (NULL == log_port_list_p)) {
        SX_LOG_ERR("*log_port_cnt_p is not 0 but log_port_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid_in_db = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    db_list = &(__host_ifc_db_s.swid_2_trap_filters[swid_in_db][trap_id]);

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*log_port_cnt_p == 0) {
            *log_port_cnt_p = cl_qlist_count(db_list);
            goto out;
        } else {
            start_item = cl_qlist_head(db_list);
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        if (*log_port_cnt_p == 0) {
            goto out;
        } else {
            start_item = cl_qlist_head(db_list);
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
        if (*log_port_cnt_p == 0) {
            goto out;
        } else {
            start_item = cl_qlist_head(db_list);
            while (start_item != cl_qlist_end(db_list)) {
                filter_item = cl_item_obj(start_item, filter_item, list_item);
                if (filter_item->log_port_id > log_port_id) {
                    break;
                } else if (filter_item->log_port_id == log_port_id) {
                    start_item = cl_qlist_next(start_item);
                    break;
                } else {
                    start_item = cl_qlist_next(start_item);
                }
            }
            break;
        }

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

    size = 0;
    max_size = *log_port_cnt_p;

    while ((size < max_size) && (start_item != cl_qlist_end(db_list))) {
        filter_item = cl_item_obj(start_item, filter_item, list_item);
        log_port_list_p[size++] = filter_item->log_port_id;
        start_item = cl_qlist_next(start_item);
    }

    *log_port_cnt_p = size;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_trap_filter_set(const sx_access_cmd_t  cmd,
                                        const sx_swid_t        swid,
                                        const sx_trap_id_t     trap_id,
                                        const sx_port_log_id_t log_port_id)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_swid_t                    swid_in_db = swid;
    host_ifc_trap_filter_item_t *item_to_add = NULL;
    host_ifc_trap_filter_item_t *filter_item = NULL;
    cl_list_item_t              *list_item = NULL;
    cl_qlist_t                  *db_list = NULL;

    SX_LOG_ENTER();

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_filter_set: swid range error, swid: %u\n", swid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_filter_set trap_id range error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid_in_db = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    db_list = &(__host_ifc_db_s.swid_2_trap_filters[swid_in_db][trap_id]);

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        list_item = cl_qlist_head(db_list);
        while (list_item != cl_qlist_end(db_list)) {
            filter_item = cl_item_obj(list_item, filter_item, list_item);
            if (filter_item->log_port_id > log_port_id) {
                break;
            } else if (filter_item->log_port_id == log_port_id) {
                SX_LOG(SX_LOG_INFO, "Port 0x%x already exists in filter DB of swid %u trap_id %u\n",
                       log_port_id, swid, trap_id);
                goto out;
            } else {
                list_item = cl_qlist_next(list_item);
            }
        }

        item_to_add = cl_malloc(sizeof(host_ifc_trap_filter_item_t));
        if (item_to_add == NULL) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory\n");
            goto out;
        }

        SX_MEM_CLR_TYPE(item_to_add, host_ifc_trap_filter_item_t);
        item_to_add->log_port_id = log_port_id;
        cl_qlist_insert_prev(db_list, list_item, &(item_to_add->list_item));
        break;

    case SX_ACCESS_CMD_DELETE:
        list_item = cl_qlist_head(db_list);
        while (list_item != cl_qlist_end(db_list)) {
            filter_item = cl_item_obj(list_item, filter_item, list_item);
            if (filter_item->log_port_id == log_port_id) {
                break;
            }
            list_item = cl_qlist_next(list_item);
        }

        if (list_item == cl_qlist_end(db_list)) {
            SX_LOG(SX_LOG_INFO, "Port 0x%x was not found in filter DB of swid %u trap_id %u\n",
                   log_port_id, swid, trap_id);
            goto out;
        }

        cl_qlist_remove_item(db_list, list_item);
        filter_item = cl_item_obj(list_item, filter_item, list_item);
        cl_free(filter_item);

        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        while (!cl_is_qlist_empty(db_list)) {
            list_item = cl_qlist_remove_head(db_list);
            filter_item = cl_item_obj(list_item, filter_item, list_item);
            cl_free(filter_item);
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static int __host_ifc_db_compare_user_channel(const sx_user_channel_t *user_channel1,
                                              const sx_user_channel_t *user_channel2)
{
    if (user_channel1->type < user_channel2->type) {
        return -1;
    } else if (user_channel1->type > user_channel2->type) {
        return 1;
    } else {
        if (user_channel1->type == SX_USER_CHANNEL_TYPE_FD) {
            if (user_channel1->channel.fd.fd < user_channel2->channel.fd.fd) {
                return -1;
            } else if (user_channel1->channel.fd.fd > user_channel2->channel.fd.fd) {
                return 1;
            } else {
                if (user_channel1->channel.fd.driver_handle < user_channel2->channel.fd.driver_handle) {
                    return -1;
                } else if (user_channel1->channel.fd.driver_handle > user_channel2->channel.fd.driver_handle) {
                    return 1;
                } else {
                    if (!(user_channel1->channel.fd.valid) && user_channel2->channel.fd.valid) {
                        return -1;
                    } else if (user_channel1->channel.fd.valid && !(user_channel2->channel.fd.valid)) {
                        return 1;
                    } else {
                        return 0;
                    }
                }
            }
        } else if (user_channel1->type == SX_USER_CHANNEL_TYPE_L2_TUNNEL) {
            if (user_channel1->channel.l2_tunnel_params.dmac < user_channel2->channel.l2_tunnel_params.dmac) {
                return -1;
            } else if (user_channel1->channel.l2_tunnel_params.dmac > user_channel2->channel.l2_tunnel_params.dmac) {
                return 1;
            } else {
                if (user_channel1->channel.l2_tunnel_params.vid < user_channel2->channel.l2_tunnel_params.vid) {
                    return -1;
                } else if (user_channel1->channel.l2_tunnel_params.vid > user_channel2->channel.l2_tunnel_params.vid) {
                    return 1;
                } else {
                    if (user_channel1->channel.l2_tunnel_params.prio < user_channel2->channel.l2_tunnel_params.prio) {
                        return -1;
                    } else if (user_channel1->channel.l2_tunnel_params.prio >
                               user_channel2->channel.l2_tunnel_params.prio) {
                        return 1;
                    } else {
                        return 0;
                    }
                }
            }
        } else {
            return 0;
        }
    }
}

static int __host_ifc_db_compare_register_key_and_user_channel(const sx_host_ifc_register_key_t *register_key1,
                                                               const sx_user_channel_t          *user_channel1,
                                                               const sx_host_ifc_register_key_t *register_key2,
                                                               const sx_user_channel_t          *user_channel2)
{
    if (register_key1->key_type < register_key2->key_type) {
        return -1;
    } else if (register_key1->key_type > register_key2->key_type) {
        return 1;
    } else {
        if (register_key1->key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_PORT) {
            if (register_key1->key_value.port_id < register_key2->key_value.port_id) {
                return -1;
            } else if (register_key1->key_value.port_id > register_key2->key_value.port_id) {
                return 1;
            }
        } else if (register_key1->key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN) {
            if (register_key1->key_value.vlan_id < register_key2->key_value.vlan_id) {
                return -1;
            } else if (register_key1->key_value.vlan_id > register_key2->key_value.vlan_id) {
                return 1;
            }
        }
    }

    return __host_ifc_db_compare_user_channel(user_channel1, user_channel2);
}

static int __host_ifc_db_compare_filter_key_and_user_channel(const sx_host_ifc_filter_key_t *filter_key1,
                                                             const sx_user_channel_t        *user_channel1,
                                                             const sx_host_ifc_filter_key_t *filter_key2,
                                                             const sx_user_channel_t        *user_channel2)
{
    if (filter_key1->key_type < filter_key2->key_type) {
        return -1;
    } else if (filter_key1->key_type > filter_key2->key_type) {
        return 1;
    } else {
        if (filter_key1->key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_PORT) {
            if (filter_key1->key_value.port_id < filter_key2->key_value.port_id) {
                return -1;
            } else if (filter_key1->key_value.port_id > filter_key2->key_value.port_id) {
                return 1;
            }
        } else if (filter_key1->key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN) {
            if (filter_key1->key_value.vlan_id < filter_key2->key_value.vlan_id) {
                return -1;
            } else if (filter_key1->key_value.vlan_id > filter_key2->key_value.vlan_id) {
                return 1;
            }
        }
    }

    return __host_ifc_db_compare_user_channel(user_channel1, user_channel2);
}

static host_ifc_pid_item_t* __host_ifc_db_find_pid_item_from_list(cl_qlist_t* pid_list, pid_t client_pid)
{
    host_ifc_pid_item_t *pid_item = NULL;
    cl_list_item_t      *pid_list_item = NULL;

    pid_list_item = cl_qlist_head(pid_list);
    while (pid_list_item != cl_qlist_end(pid_list)) {
        pid_item = cl_item_obj(pid_list_item, pid_item, list_item);
        if (pid_item->pid == client_pid) {
            break;
        }
        pid_list_item = cl_qlist_next(pid_list_item);
    }

    if (pid_list_item == cl_qlist_end(pid_list)) {
        return NULL;
    } else {
        return pid_item;
    }
}

sx_status_t host_ifc_db_trap_id_register_get(const sx_access_cmd_t    cmd,
                                             const sx_swid_t          swid,
                                             const sx_trap_id_t       trap_id,
                                             const sx_user_channel_t *user_channel,
                                             const pid_t              client_pid,
                                             sx_user_channel_t       *user_channel_list_p,
                                             uint32_t                *user_channel_cnt_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_swid_t                          swid_in_db = swid;
    cl_list_item_t                    *start_item = NULL;
    cl_qlist_t                        *db_list = NULL;
    host_ifc_trap_user_channel_item_t *user_channel_item = NULL;
    length_t                           size = 0;
    length_t                           max_size = 0;
    int                                comparison_result = 0;

    SX_LOG_ENTER();

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_id_register_get: swid range error, swid: %u\n", swid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_id_register_get trap_id range error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == user_channel_cnt_p) {
        SX_LOG_ERR("user_channel_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*user_channel_cnt_p > 0) && (NULL == user_channel_list_p)) {
        SX_LOG_ERR("*user_channel_cnt_p is not 0 but user_channel_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid_in_db = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    db_list = &(__host_ifc_db_s.swid_2_trap_user_channels[swid_in_db][trap_id]);

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*user_channel_cnt_p == 0) {
            *user_channel_cnt_p = cl_qlist_count(db_list);
            goto out;
        } else {
            start_item = cl_qlist_head(db_list);
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        if (*user_channel_cnt_p == 0) {
            goto out;
        } else {
            start_item = cl_qlist_head(db_list);
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
        if (*user_channel_cnt_p == 0) {
            goto out;
        } else {
            if (user_channel == NULL) {
                SX_LOG_ERR("user_channel is NULL\n");
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            start_item = cl_qlist_head(db_list);
            while (start_item != cl_qlist_end(db_list)) {
                user_channel_item = cl_item_obj(start_item, user_channel_item, list_item);
                comparison_result = __host_ifc_db_compare_user_channel(&(user_channel_item->user_channel),
                                                                       user_channel);
                if (comparison_result > 0) {
                    break;
                } else if (comparison_result == 0) {
                    start_item = cl_qlist_next(start_item);
                    break;
                } else {
                    start_item = cl_qlist_next(start_item);
                }
            }
            break;
        }

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

    size = 0;
    max_size = *user_channel_cnt_p;

    while ((size < max_size) && (start_item != cl_qlist_end(db_list))) {
        user_channel_item = cl_item_obj(start_item, user_channel_item, list_item);
        SX_MEM_CPY_TYPE(&(user_channel_list_p[size]), &(user_channel_item->user_channel), sx_user_channel_t);
        if (user_channel_item->user_channel.type == SX_USER_CHANNEL_TYPE_FD) {
            if (__host_ifc_db_find_pid_item_from_list(&(user_channel_item->pid_list), client_pid) != NULL) {
                user_channel_list_p[size].channel.fd.valid = TRUE;
            } else {
                user_channel_list_p[size].channel.fd.valid = FALSE;
            }
        }
        size++;
        start_item = cl_qlist_next(start_item);
    }

    *user_channel_cnt_p = size;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_db_add_pid_item_to_list(cl_qlist_t* pid_list, pid_t client_pid)
{
    host_ifc_pid_item_t *pid_item_to_add = NULL;

    pid_item_to_add = cl_malloc(sizeof(host_ifc_pid_item_t));
    if (pid_item_to_add == NULL) {
        SX_LOG_ERR("Failed to allocate memory\n");
        return SX_STATUS_NO_MEMORY;
    }

    SX_MEM_CLR_TYPE(pid_item_to_add, host_ifc_pid_item_t);
    pid_item_to_add->pid = client_pid;
    cl_qlist_insert_head(pid_list, &(pid_item_to_add->list_item));

    return SX_STATUS_SUCCESS;
}

static sx_status_t __host_ifc_db_add_user_channel_register_key(const sx_swid_t                   swid,
                                                               const sx_trap_id_t                trap_id,
                                                               cl_qlist_t                       *db_list,
                                                               const sx_host_ifc_register_key_t *register_key_p,
                                                               const sx_user_channel_t          *user_channel_p,
                                                               const pid_t                       client_pid,
                                                               const boolean_t                   user_channel_only)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    void                              *item_to_add = NULL;
    host_ifc_trap_user_channel_item_t *user_channel_item = NULL;
    host_ifc_trap_register_item_t     *register_item = NULL;
    host_ifc_trap_user_channel_item_t *user_channel_item_to_add = NULL;
    host_ifc_trap_register_item_t     *register_item_to_add = NULL;
    cl_list_item_t                    *list_item = NULL;
    cl_qlist_t                        *pid_list = NULL;
    host_ifc_pid_item_t               *pid_item = NULL;
    int                                comparison_result = 0;

    SX_LOG_ENTER();

    /*
     * To make sure the list is always ordered, we need to find the first entry which is *bigger* than
     * the new entry, then insert the new entry before the found one. If no such entry is found,
     * the new entry will added to the tail.
     * If an equal entry is found:
     * 1) If the user channel type is not fd, then do nothing and return success.
     * 2) If the user channel type is fd, then add the input PID to the PID list of the entry
     *    if it is not in the list.
     */
    list_item = cl_qlist_head(db_list);
    while (list_item != cl_qlist_end(db_list)) {
        if (user_channel_only) {
            user_channel_item = cl_item_obj(list_item, user_channel_item, list_item);
            comparison_result = __host_ifc_db_compare_user_channel(&(user_channel_item->user_channel),
                                                                   user_channel_p);
        } else {
            register_item = cl_item_obj(list_item, register_item, list_item);
            comparison_result = __host_ifc_db_compare_register_key_and_user_channel(&(register_item->register_key),
                                                                                    &(register_item->user_channel),
                                                                                    register_key_p,
                                                                                    user_channel_p);
        }

        if (comparison_result > 0) {
            break;
        } else if (comparison_result == 0) {
            if (user_channel_only) {
                SX_LOG(SX_LOG_INFO, "The input user channel already exists in DB of swid %u trap_id %u\n",
                       swid, trap_id);
            } else {
                SX_LOG(SX_LOG_INFO,
                       "The input register key and user channel already exist in DB of swid %u trap_id %u\n",
                       swid,
                       trap_id);
            }
            if (user_channel_p->type == SX_USER_CHANNEL_TYPE_FD) {
                if (user_channel_only) {
                    pid_list = &(user_channel_item->pid_list);
                } else {
                    pid_list = &(register_item->pid_list);
                }

                pid_item = __host_ifc_db_find_pid_item_from_list(pid_list, client_pid);
                if (pid_item != NULL) {
                    if (user_channel_only) {
                        SX_LOG(SX_LOG_INFO, "The input user channel (with fd type) associated with PID %d "
                               "already exists in DB of swid %u trap_id %u\n", client_pid, swid, trap_id);
                    } else {
                        SX_LOG(SX_LOG_INFO,
                               "The input register key and user channel (with fd type) associated with PID %d "
                               "already exist in DB of swid %u trap_id %u\n",
                               client_pid,
                               swid,
                               trap_id);
                    }
                    goto out;
                }

                err = __host_ifc_db_add_pid_item_to_list(pid_list, client_pid);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("__host_ifc_db_add_pid_item_to_list failed, client_pid: %u, return value: [%s]\n",
                               client_pid, sx_status_str(err));
                    goto out;
                }
            }
            goto out;
        } else {
            list_item = cl_qlist_next(list_item);
        }
    }

    if (user_channel_only) {
        item_to_add = cl_malloc(sizeof(host_ifc_trap_user_channel_item_t));
    } else {
        item_to_add = cl_malloc(sizeof(host_ifc_trap_register_item_t));
    }
    if (item_to_add == NULL) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory\n");
        goto out;
    }

    if (user_channel_only) {
        user_channel_item_to_add = item_to_add;
        SX_MEM_CLR_TYPE(user_channel_item_to_add, host_ifc_trap_user_channel_item_t);
        pid_list = &(user_channel_item_to_add->pid_list);
    } else {
        register_item_to_add = item_to_add;
        SX_MEM_CLR_TYPE(register_item_to_add, host_ifc_trap_register_item_t);
        pid_list = &(register_item_to_add->pid_list);
    }

    if (user_channel_p->type == SX_USER_CHANNEL_TYPE_FD) {
        cl_qlist_init(pid_list);
        err = __host_ifc_db_add_pid_item_to_list(pid_list, client_pid);
        if (SX_CHECK_FAIL(err)) {
            cl_free(item_to_add);
            SX_LOG_ERR("__host_ifc_db_add_pid_item_to_list failed, client_pid: %u, return value: [%s]\n",
                       client_pid, sx_status_str(err));
            goto out;
        }
    }

    if (!user_channel_only) {
        SX_MEM_CPY_TYPE(&(register_item_to_add->register_key), register_key_p, sx_host_ifc_register_key_t);
        SX_MEM_CPY_TYPE(&(register_item_to_add->user_channel), user_channel_p, sx_user_channel_t);
        cl_qlist_insert_prev(db_list, list_item, &(register_item_to_add->list_item));
    } else {
        SX_MEM_CPY_TYPE(&(user_channel_item_to_add->user_channel), user_channel_p, sx_user_channel_t);
        cl_qlist_insert_prev(db_list, list_item, &(user_channel_item_to_add->list_item));
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_db_remove_user_channel_register_key(const sx_swid_t                   swid,
                                                                  const sx_trap_id_t                trap_id,
                                                                  cl_qlist_t                       *db_list,
                                                                  const sx_host_ifc_register_key_t *register_key_p,
                                                                  const sx_user_channel_t          *user_channel_p,
                                                                  const pid_t                       client_pid,
                                                                  const boolean_t                   user_channel_only)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    host_ifc_trap_user_channel_item_t *user_channel_item = NULL;
    host_ifc_trap_register_item_t     *register_item = NULL;
    cl_list_item_t                    *list_item = NULL;
    cl_qlist_t                        *pid_list = NULL;
    host_ifc_pid_item_t               *pid_item = NULL;
    int                                comparison_result = 0;

    SX_LOG_ENTER();

    /*
     * When the specified entry is not found from the list, success is returned.
     * When the specified entry is found:
     * 1) if the user channel type is not fd, the entry is removed.
     * 2) if the user channel type is fd, we need to check whether the specified PID is in
     *    the PID list of the entry or not. If input PID is not in the PID list, success is returned.
     *    If input PID is in the PID list, we remove the PID from the PID list. After that, if the PID
     *    list becomes empty, the entry is also removed.
     */
    list_item = cl_qlist_head(db_list);
    while (list_item != cl_qlist_end(db_list)) {
        if (user_channel_only) {
            user_channel_item = cl_item_obj(list_item, user_channel_item, list_item);
            comparison_result = __host_ifc_db_compare_user_channel(&(user_channel_item->user_channel),
                                                                   user_channel_p);
        } else {
            register_item = cl_item_obj(list_item, register_item, list_item);
            comparison_result = __host_ifc_db_compare_register_key_and_user_channel(&(register_item->register_key),
                                                                                    &(register_item->user_channel),
                                                                                    register_key_p,
                                                                                    user_channel_p);
        }
        if (comparison_result == 0) {
            break;
        }
        list_item = cl_qlist_next(list_item);
    }

    if (list_item == cl_qlist_end(db_list)) {
        if (user_channel_only) {
            SX_LOG(SX_LOG_INFO, "The input user channel was not found from DB of swid %u trap_id %u\n",
                   swid, trap_id);
        } else {
            SX_LOG(SX_LOG_INFO,
                   "The input register key and user channel were not found from DB of swid %u trap_id %u\n",
                   swid,
                   trap_id);
        }
        goto out;
    }

    if (user_channel_p->type == SX_USER_CHANNEL_TYPE_FD) {
        if (user_channel_only) {
            pid_list = &(user_channel_item->pid_list);
        } else {
            pid_list = &(register_item->pid_list);
        }
        pid_item = __host_ifc_db_find_pid_item_from_list(pid_list, client_pid);
        if (pid_item == NULL) {
            if (user_channel_only) {
                SX_LOG(SX_LOG_INFO, "The input user channel (with fd type) associated with PID %d "
                       "was not found from DB of swid %u trap_id %u\n", client_pid, swid, trap_id);
            } else {
                SX_LOG(SX_LOG_INFO, "The input register key and user channel (with fd type) associated with PID %d "
                       "were not found from DB of swid %u trap_id %u\n", client_pid, swid, trap_id);
            }
            goto out;
        }

        cl_qlist_remove_item(pid_list, &(pid_item->list_item));
        cl_free(pid_item);

        if (!cl_is_qlist_empty(pid_list)) {
            goto out;
        }
    }

    cl_qlist_remove_item(db_list, list_item);
    if (user_channel_only) {
        cl_free(user_channel_item);
    } else {
        cl_free(register_item);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_trap_id_register_set(const sx_access_cmd_t    cmd,
                                             const sx_swid_t          swid,
                                             const sx_trap_id_t       trap_id,
                                             const sx_user_channel_t *user_channel_p,
                                             const pid_t              client_pid)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_swid_t   swid_in_db = swid;
    cl_qlist_t *db_list = NULL;

    SX_LOG_ENTER();

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_id_register_set: swid range error, swid: %u\n", swid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_id_register_set trap_id range error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (user_channel_p == NULL) {
        SX_LOG_ERR("user_channel_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid_in_db = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    db_list = &(__host_ifc_db_s.swid_2_trap_user_channels[swid_in_db][trap_id]);

    switch (cmd) {
    case SX_ACCESS_CMD_REGISTER:
        err = __host_ifc_db_add_user_channel_register_key(swid,
                                                          trap_id,
                                                          db_list,
                                                          NULL,
                                                          user_channel_p,
                                                          client_pid,
                                                          TRUE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR(
                "__host_ifc_db_add_user_channel_register_key failed, trap_id: %u, client_pid: %u, return value: [%s]\n",
                trap_id,
                client_pid,
                sx_status_str(err));
        }
        break;

    case SX_ACCESS_CMD_DEREGISTER:
        err = __host_ifc_db_remove_user_channel_register_key(swid,
                                                             trap_id,
                                                             db_list,
                                                             NULL,
                                                             user_channel_p,
                                                             client_pid,
                                                             TRUE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR(
                "__host_ifc_db_remove_user_channel_register_key failed, trap_id: %u, client_pid: %u, return value: [%s]\n",
                trap_id,
                client_pid,
                sx_status_str(err));
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_port_vlan_trap_id_register_get(const sx_access_cmd_t                   cmd,
                                                       const sx_swid_t                         swid,
                                                       const sx_trap_id_t                      trap_id,
                                                       const sx_host_ifc_register_get_entry_t *register_entry,
                                                       const pid_t                             client_pid,
                                                       sx_host_ifc_register_get_entry_t       *register_entry_list_p,
                                                       uint32_t                               *register_entry_cnt_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_swid_t                      swid_in_db = swid;
    cl_list_item_t                *start_item = NULL;
    cl_qlist_t                    *db_list = NULL;
    host_ifc_trap_register_item_t *register_item = NULL;
    length_t                       size = 0;
    length_t                       max_size = 0;
    int                            comparison_result = 0;

    SX_LOG_ENTER();

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_port_vlan_trap_id_register_get: swid range error, swid: %u\n", swid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_port_vlan_trap_id_register_get trap_id range error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == register_entry_cnt_p) {
        SX_LOG_ERR("register_entry_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*register_entry_cnt_p > 0) && (NULL == register_entry_list_p)) {
        SX_LOG_ERR("*register_entry_cnt_p is not 0 but register_entry_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid_in_db = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    db_list = &(__host_ifc_db_s.swid_2_trap_registers[swid_in_db][trap_id]);

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*register_entry_cnt_p == 0) {
            *register_entry_cnt_p = cl_qlist_count(db_list);
            goto out;
        } else {
            start_item = cl_qlist_head(db_list);
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        if (*register_entry_cnt_p == 0) {
            goto out;
        } else {
            start_item = cl_qlist_head(db_list);
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
        if (*register_entry_cnt_p == 0) {
            goto out;
        } else {
            if (register_entry == NULL) {
                SX_LOG_ERR("register_entry is NULL\n");
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            start_item = cl_qlist_head(db_list);
            while (start_item != cl_qlist_end(db_list)) {
                register_item = cl_item_obj(start_item, register_item, list_item);
                comparison_result = __host_ifc_db_compare_register_key_and_user_channel(&(register_item->register_key),
                                                                                        &(register_item->user_channel),
                                                                                        &(register_entry->register_key),
                                                                                        &(register_entry->user_channel));
                if (comparison_result > 0) {
                    break;
                } else if (comparison_result == 0) {
                    start_item = cl_qlist_next(start_item);
                    break;
                } else {
                    start_item = cl_qlist_next(start_item);
                }
            }
            break;
        }

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

    size = 0;
    max_size = *register_entry_cnt_p;

    while ((size < max_size) && (start_item != cl_qlist_end(db_list))) {
        register_item = cl_item_obj(start_item, register_item, list_item);
        SX_MEM_CPY_TYPE(&(register_entry_list_p[size].register_key),
                        &(register_item->register_key),
                        sx_host_ifc_register_key_t);
        SX_MEM_CPY_TYPE(&(register_entry_list_p[size].user_channel), &(register_item->user_channel),
                        sx_user_channel_t);
        if (register_item->user_channel.type == SX_USER_CHANNEL_TYPE_FD) {
            if (__host_ifc_db_find_pid_item_from_list(&(register_item->pid_list), client_pid) != NULL) {
                register_entry_list_p[size].user_channel.channel.fd.valid = TRUE;
            } else {
                register_entry_list_p[size].user_channel.channel.fd.valid = FALSE;
            }
        }
        size++;
        start_item = cl_qlist_next(start_item);
    }

    *register_entry_cnt_p = size;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_port_vlan_trap_id_register_set(const sx_access_cmd_t             cmd,
                                                       const sx_swid_t                   swid,
                                                       const sx_trap_id_t                trap_id,
                                                       const sx_host_ifc_register_key_t *register_key_p,
                                                       const sx_user_channel_t          *user_channel_p,
                                                       const pid_t                       client_pid)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_swid_t   swid_in_db = swid;
    cl_qlist_t *db_list = NULL;

    SX_LOG_ENTER();

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_port_vlan_trap_id_register_set: swid range error, swid: %u\n", swid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_port_vlan_trap_id_register_set trap_id range error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (register_key_p == NULL) {
        SX_LOG_ERR("register_key_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (user_channel_p == NULL) {
        SX_LOG_ERR("user_channel_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid_in_db = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    db_list = &(__host_ifc_db_s.swid_2_trap_registers[swid_in_db][trap_id]);

    switch (cmd) {
    case SX_ACCESS_CMD_REGISTER:
        err = __host_ifc_db_add_user_channel_register_key(swid,
                                                          trap_id,
                                                          db_list,
                                                          register_key_p,
                                                          user_channel_p,
                                                          client_pid,
                                                          FALSE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR(
                "__host_ifc_db_add_user_channel_register_key failed, trap_id: %u, client_pid: %u, return value: [%s]\n",
                trap_id,
                client_pid,
                sx_status_str(err));
        }
        break;

    case SX_ACCESS_CMD_DEREGISTER:
        err = __host_ifc_db_remove_user_channel_register_key(swid,
                                                             trap_id,
                                                             db_list,
                                                             register_key_p,
                                                             user_channel_p,
                                                             client_pid,
                                                             FALSE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR(
                "__host_ifc_db_remove_user_channel_register_key failed, trap_id: %u, client_pid: %u, return value: [%s]\n",
                trap_id,
                client_pid,
                sx_status_str(err));
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static void __host_ifc_db_remove_all_fd_user_channels(pid_t client_pid, boolean_t user_channel_only)
{
    uint32_t                           i = 0;
    uint32_t                           j = 0;
    cl_qlist_t                        *db_list = NULL;
    cl_list_item_t                    *list_item = NULL;
    cl_list_item_t                    *next_list_item = NULL;
    host_ifc_trap_register_item_t     *register_item = NULL;
    cl_qlist_t                        *pid_list = NULL;
    host_ifc_pid_item_t               *pid_item = NULL;
    host_ifc_trap_user_channel_item_t *user_channel_item = NULL;
    sx_user_channel_type_t             user_channel_type;

    /*
     * Find out all the DB entries which contain the user channel with fd type,
     * delete the specified PID from the PID list of the entry. If the PID list
     * becomes empty after that, then delete the entry as well.
     */
    for (i = 0; i <= (uint32_t)(RM_NUM_OF_SWIDS); i++) {
        for (j = 0; j <= SX_TRAP_ID_MAX; j++) {
            if (user_channel_only) {
                db_list = &(__host_ifc_db_s.swid_2_trap_user_channels[i][j]);
            } else {
                db_list = &(__host_ifc_db_s.swid_2_trap_registers[i][j]);
            }
            list_item = cl_qlist_head(db_list);
            while (list_item != cl_qlist_end(db_list)) {
                next_list_item = cl_qlist_next(list_item);
                if (user_channel_only) {
                    user_channel_item = cl_item_obj(list_item, user_channel_item, list_item);
                    user_channel_type = user_channel_item->user_channel.type;
                } else {
                    register_item = cl_item_obj(list_item, register_item, list_item);
                    user_channel_type = register_item->user_channel.type;
                }
                if (user_channel_type == SX_USER_CHANNEL_TYPE_FD) {
                    if (user_channel_only) {
                        pid_list = &(user_channel_item->pid_list);
                    } else {
                        pid_list = &(register_item->pid_list);
                    }
                    pid_item = __host_ifc_db_find_pid_item_from_list(pid_list, client_pid);
                    if (pid_item != NULL) {
                        cl_qlist_remove_item(pid_list, &(pid_item->list_item));
                        cl_free(pid_item);
                        if (cl_is_qlist_empty(pid_list)) {
                            cl_qlist_remove_item(db_list, list_item);
                            if (user_channel_only) {
                                cl_free(user_channel_item);
                            } else {
                                cl_free(register_item);
                            }
                        }
                    }
                }
                list_item = next_list_item;
            }
        }
    }
}

sx_status_t host_ifc_db_remove_all_fd_user_channels(pid_t client_pid)
{
    __host_ifc_db_remove_all_fd_user_channels(client_pid, TRUE);
    __host_ifc_db_remove_all_fd_user_channels(client_pid, FALSE);

    return SX_STATUS_SUCCESS;
}

static boolean_t __host_ifc_db_compare_two_fds(const sx_fd_t *fd_p1, const sx_fd_t *fd_p2)
{
    if (fd_p1->driver_handle != fd_p2->driver_handle) {
        return FALSE;
    }

    if (fd_p1->fd != fd_p2->fd) {
        return FALSE;
    }

    if ((fd_p1->valid && !(fd_p2->valid)) || (!(fd_p1->valid) && fd_p2->valid)) {
        return FALSE;
    }

    return TRUE;
}

static void __host_ifc_db_remove_fd_user_channels(const sx_fd_t  *fd_p,
                                                  const pid_t     client_pid,
                                                  const boolean_t user_channel_only)
{
    uint32_t                           i = 0;
    uint32_t                           j = 0;
    cl_qlist_t                        *db_list = NULL;
    cl_list_item_t                    *list_item = NULL;
    cl_list_item_t                    *next_list_item = NULL;
    host_ifc_trap_register_item_t     *register_item = NULL;
    cl_qlist_t                        *pid_list = NULL;
    host_ifc_pid_item_t               *pid_item = NULL;
    host_ifc_trap_user_channel_item_t *user_channel_item = NULL;
    sx_user_channel_type_t             user_channel_type;
    boolean_t                          are_two_fds_equal = FALSE;

    /*
     * Find out all the DB entries which contain the user channel with fd type and the fd equals to
     * the specified fd, delete the specified PID from the PID list of the entry. If the PID list
     * becomes empty after that, then delete the entry as well.
     */
    for (i = 0; i <= (uint32_t)(RM_NUM_OF_SWIDS); i++) {
        for (j = 0; j <= SX_TRAP_ID_MAX; j++) {
            if (user_channel_only) {
                db_list = &(__host_ifc_db_s.swid_2_trap_user_channels[i][j]);
            } else {
                db_list = &(__host_ifc_db_s.swid_2_trap_registers[i][j]);
            }
            list_item = cl_qlist_head(db_list);
            while (list_item != cl_qlist_end(db_list)) {
                next_list_item = cl_qlist_next(list_item);
                if (user_channel_only) {
                    user_channel_item = cl_item_obj(list_item, user_channel_item, list_item);
                    user_channel_type = user_channel_item->user_channel.type;
                } else {
                    register_item = cl_item_obj(list_item, register_item, list_item);
                    user_channel_type = register_item->user_channel.type;
                }

                if (user_channel_type == SX_USER_CHANNEL_TYPE_FD) {
                    if (user_channel_only) {
                        pid_list = &(user_channel_item->pid_list);
                        are_two_fds_equal = __host_ifc_db_compare_two_fds(fd_p,
                                                                          &(user_channel_item->user_channel.channel.fd));
                    } else {
                        pid_list = &(register_item->pid_list);
                        are_two_fds_equal = __host_ifc_db_compare_two_fds(fd_p,
                                                                          &(register_item->user_channel.channel.fd));
                    }
                    if (are_two_fds_equal) {
                        pid_item = __host_ifc_db_find_pid_item_from_list(pid_list, client_pid);
                        if (pid_item != NULL) {
                            cl_qlist_remove_item(pid_list, &(pid_item->list_item));
                            cl_free(pid_item);
                            if (cl_is_qlist_empty(pid_list)) {
                                cl_qlist_remove_item(db_list, list_item);
                                if (user_channel_only) {
                                    cl_free(user_channel_item);
                                } else {
                                    cl_free(register_item);
                                }
                            }
                        }
                    }
                }
                list_item = next_list_item;
            }
        }
    }
}

sx_status_t host_ifc_db_remove_fd_user_channels(const sx_fd_t *fd_p, const pid_t client_pid)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (fd_p == NULL) {
        SX_LOG_ERR("fd_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    __host_ifc_db_remove_fd_user_channels(fd_p, client_pid, TRUE);
    __host_ifc_db_remove_fd_user_channels(fd_p, client_pid, FALSE);

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __host_ifc_db_extended_trap_id_to_index(const sx_trap_id_t trap_id, uint32_t *index_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0, j = 0;
    boolean_t   found = FALSE;
    uint32_t    count = sizeof(host_ifc_db_discard_to_discard_extended_map) /
                        sizeof(host_ifc_db_discard_to_discard_extended_map_t);

    if (SX_TRAP_ID_EXTENDED_DISCARD_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("__host_ifc_db_extended_trap_id_to_index trap_id range error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    for (i = 0; (i < count && found == FALSE); i++) {
        for (j = 0; j < host_ifc_db_discard_to_discard_extended_map[i].extended_trap_id_count; j++) {
            if (host_ifc_db_discard_to_discard_extended_map[i].extended_trap_id_list[j] == trap_id) {
                found = TRUE;
                break;
            }
        }
    }


    if (found) {
        *index_p = i - 1;
    } else {
        err = SX_STATUS_PARAM_ERROR;
    }


out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_discard_trap_check(const sx_trap_id_t trap_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (SX_TRAP_ID_DISCARD_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_port_vlan_trap_id_register_set trap_id range error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (host_ifc_db_discard_to_discard_extended_map[SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(trap_id)].extended_trap_in_use) {
        SX_LOG_ERR("Cannot configure while extended trap is in use\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t host_ifc_db_discard_trap_set(const sx_trap_id_t trap_id, boolean_t is_in_use)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = host_ifc_db_discard_trap_check(trap_id);

    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    host_ifc_db_discard_to_discard_extended_map[SX_TRAP_ID_DISCARD_TRAP_TO_INDEX(trap_id)].trap_in_use = is_in_use;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_extended_discard_trap_check(const sx_trap_id_t trap_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    index = 0;


    if (SX_TRAP_ID_EXTENDED_DISCARD_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_extended_discard_trap_check trap_id range error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = __host_ifc_db_extended_trap_id_to_index(trap_id, &index);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (host_ifc_db_discard_to_discard_extended_map[index].trap_in_use) {
        SX_LOG_ERR("Cannot configure while discard trap is in use\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }


out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_extended_discard_trap_set(const sx_trap_id_t trap_id, boolean_t is_in_use)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    index = 0;

    err = host_ifc_db_extended_discard_trap_check(trap_id);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = __host_ifc_db_extended_trap_id_to_index(trap_id, &index);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    host_ifc_db_discard_to_discard_extended_map[index].extended_trap_in_use = is_in_use;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_db_discard_map_init()
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    uint32_t    count = sizeof(host_ifc_db_discard_to_discard_extended_map) /
                        sizeof(host_ifc_db_discard_to_discard_extended_map_t);

    for (i = 0; i < count; i++) {
        host_ifc_db_discard_to_discard_extended_map[i].trap_in_use = FALSE;
        host_ifc_db_discard_to_discard_extended_map[i].extended_trap_in_use = FALSE;
    }
    return err;
}

sx_status_t host_ifc_db_trap_id_to_group_list_init(const sx_trap_id_t trap_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    cl_status_t cl_err = CL_SUCCESS;
    uint32_t    num_trap_groups = 0;

    SX_LOG_ENTER();

    err = host_ifc_hw_trap_group_num_get(&num_trap_groups);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get number of HW trap groups, return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    cl_spinlock_init(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    cl_spinlock_acquire(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    cl_err = CL_QPOOL_INIT(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.pool,
                           num_trap_groups, num_trap_groups, 0,
                           sizeof(host_ifc_trap_group_queue_entry_t),
                           NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to initialize associated trap groups qpool, cl_err = [%s]\n",
                   CL_STATUS_MSG(cl_err));
        goto out;
    }

    /* List init */
    cl_qlist_init(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);

out:
    cl_spinlock_release(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_trap_id_to_group_list_deinit(const sx_trap_id_t trap_id)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    const cl_list_item_t              *p_end = NULL;
    cl_list_item_t                    *p_iter = NULL;
    host_ifc_trap_group_queue_entry_t *p_object = NULL;

    SX_LOG_ENTER();

    cl_spinlock_acquire(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    p_end = cl_qlist_end(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);
    p_iter = cl_qlist_head(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);

    /* make sure that there are no leftovers in the list */
    while (p_end != p_iter) {
        p_object = PARENT_STRUCT(p_iter, host_ifc_trap_group_queue_entry_t, list_item);

        cl_qpool_put(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.pool,
                     &p_object->pool_item);
        p_iter = cl_qlist_next(p_iter);
        cl_qlist_remove_head(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);
    }

    CL_QPOOL_DESTROY(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.pool);
    cl_spinlock_release(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    cl_spinlock_destroy(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_db_trap_id_to_group_list_push(const sx_swid_t    swid,
                                                            const sx_trap_id_t trap_id,
                                                            sx_trap_group_t   *trap_group_p,
                                                            sx_trap_action_t  *trap_action_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    cl_pool_item_t                    *pool_item_p = NULL;
    const cl_list_item_t              *p_end = NULL;
    cl_list_item_t                    *p_iter = NULL;
    host_ifc_trap_group_queue_entry_t *p_object = NULL;
    uint32_t                           hw_trap_group = 0;
    sx_trap_group_t                    trap_group_id = 0;
    sx_trap_action_t                   trap_action = 0;

    SX_LOG_ENTER()

    cl_spinlock_acquire(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    if (trap_group_p == NULL) {
        hw_trap_group = __host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_id_properties.hw_trap_group;
        trap_group_id = __host_ifc_db_s.hw_trap_group_2_trap_group[swid][hw_trap_group];
    } else {
        hw_trap_group = __host_ifc_db_s.trap_group_2_hw_trap_group[swid].trap_groups[*trap_group_p];
        trap_group_id = *trap_group_p;
    }

    if (trap_action_p != NULL) {
        trap_action = *trap_action_p;
    } else {
        trap_action = __host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_id_properties.trap_action;
    }

    /* Do not push new instance of the data if DB already has the same */
    p_end = cl_qlist_end(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);
    p_iter = cl_qlist_head(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);

    while (p_end != p_iter) {
        p_object = PARENT_STRUCT(p_iter, host_ifc_trap_group_queue_entry_t, list_item);

        if (p_object->data.trap_group_id == trap_group_id) {
            if (hw_trap_group <= SX_TRAP_GROUP_MAX) {
                /* List already contains the same entry.
                 * Don't push one more item for the same Trap Group,
                 * but update its attributes with the new values which may be different. */
                p_object->data.trap_action = trap_action;
                p_object->data.is_monitor =
                    __host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].trap_group_properties.is_monitor;
                p_object->data.is_tac_capable =
                    __host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].trap_group_properties.is_tac_capable;
            }
            goto out;
        }

        if (hw_trap_group <= SX_TRAP_GROUP_MAX) {
            if (
                ((p_object->data.is_monitor == TRUE) &&
                 (p_object->data.is_monitor ==
                  __host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].trap_group_properties.is_monitor)) ||
                ((p_object->data.is_tac_capable == TRUE) &&
                 (p_object->data.is_tac_capable ==
                  __host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].trap_group_properties.is_tac_capable)) ||
                ((p_object->data.is_monitor == FALSE) && (p_object->data.is_tac_capable == FALSE) &&
                 (__host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].trap_group_properties.is_monitor == FALSE) &&
                 (__host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].trap_group_properties.is_tac_capable ==
                  FALSE))
                ) {
                /* List already contains the group of specific type (monitor / tac_capable / not monitor)
                 * Don't push one more item for the same Trap Group type,
                 * but update its attributes with the new values which may be different. */
                SX_MEM_CLR(p_object->data);

                p_object->data.trap_group_id = trap_group_id;
                p_object->data.hw_trap_group = hw_trap_group;
                p_object->data.trap_action = trap_action;
                p_object->data.is_monitor =
                    __host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].trap_group_properties.is_monitor;
                p_object->data.is_tac_capable =
                    __host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].trap_group_properties.is_tac_capable;
                goto out;
            }
        }

        /* get next */
        p_iter = cl_qlist_next(p_iter);
    }

    /* update DB */
    pool_item_p = cl_qpool_get(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.pool);
    if (pool_item_p == NULL) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("No memory left in GC post queue qpool\n");
        goto out;
    }

    p_object = PARENT_STRUCT(pool_item_p, host_ifc_trap_group_queue_entry_t, pool_item);

    SX_MEM_CLR(p_object->data);

    p_object->data.trap_group_id = trap_group_id;

    p_object->data.hw_trap_group = hw_trap_group;
    if (hw_trap_group != SX_HW_TRAP_GROUP_DISABLE_E) {
        if (hw_trap_group <= SX_TRAP_GROUP_MAX) {
            p_object->data.trap_action = trap_action;
            p_object->data.is_monitor =
                __host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].trap_group_properties.is_monitor;
            p_object->data.is_tac_capable =
                __host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].trap_group_properties.is_tac_capable;
        }
    }

    cl_qlist_insert_tail(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list,
                         &p_object->list_item);

    if (hw_trap_group != SX_HW_TRAP_GROUP_DISABLE_E) {
        err = __host_ifc_db_trap_id_to_group_list_add(hw_trap_group, trap_id);
        if (err == SX_STATUS_ENTRY_ALREADY_EXISTS) {
            err = SX_STATUS_SUCCESS;
        }
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to add trap id [%u] to group [%u] list, return value [%s].\n",
                       trap_id, *trap_group_p, sx_status_str(err));
            goto out;
        }
    }

out:
    cl_spinlock_release(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_db_trap_id_to_group_list_pop(const sx_trap_id_t trap_id, sx_trap_group_t *trap_group_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    const cl_list_item_t              *p_end = NULL;
    cl_list_item_t                    *p_iter = NULL;
    host_ifc_trap_group_queue_entry_t *p_object = NULL;
    sx_trap_group_t                    hw_trap_group;
    const sx_swid_t                    swid = 0;

    SX_LOG_ENTER();

    cl_spinlock_acquire(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    p_end = cl_qlist_end(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);
    p_iter = cl_qlist_head(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);

    while (p_iter != p_end) {
        p_object = PARENT_STRUCT(p_iter, host_ifc_trap_group_queue_entry_t, list_item);

        if (trap_group_p != NULL) {
            if (p_object->data.trap_group_id == *trap_group_p) {
                cl_qpool_put(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.pool,
                             &p_object->pool_item);
                cl_qlist_remove_item(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list,
                                     p_iter);

                hw_trap_group = __host_ifc_db_s.trap_group_2_hw_trap_group[swid].trap_groups[*trap_group_p];
                if (hw_trap_group != SX_HW_TRAP_GROUP_DISABLE_E) {
                    err = __host_ifc_db_trap_id_from_group_list_remove(hw_trap_group, trap_id);
                    if (SX_CHECK_FAIL(err)) {
                        SX_LOG_ERR("Failed to remove trap ID [%u] from HW trap group [%u] list, return value [%s].\n",
                                   trap_id, hw_trap_group, sx_status_str(err));
                        goto out;
                    }
                }
                break;
            } else {
                p_iter = cl_qlist_next(p_iter);
            }
        } else {
            if ((p_object->data.is_monitor == FALSE) &&
                (p_object->data.is_tac_capable == FALSE)) {
                cl_qpool_put(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.pool,
                             &p_object->pool_item);
                cl_qlist_remove_item(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list,
                                     p_iter);
                break;
            }
            p_iter = cl_qlist_next(p_iter);
        }
    }

out:
    cl_spinlock_release(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_trap_id_to_group_associate_set(const sx_access_cmd_t cmd,
                                                       const sx_swid_t       swid,
                                                       const sx_trap_id_t    trap_id,
                                                       sx_trap_group_t      *trap_group_p,
                                                       sx_trap_action_t     *trap_action_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd == SX_ACCESS_CMD_SET) {
        err = __host_ifc_db_trap_id_to_group_list_push(swid, trap_id, trap_group_p, trap_action_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to push trap id [%u] associated group to list, return value [%s].\n",
                       trap_id, sx_status_str(err));
            goto out;
        }
    } else if (cmd == SX_ACCESS_CMD_UNSET) {
        err = __host_ifc_db_trap_id_to_group_list_pop(trap_id, trap_group_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to pop trap id [%u] associated group to list, return value [%s].\n",
                       trap_id, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_trap_id_to_group_associate_get(const sx_trap_id_t trap_id,
                                                       sx_trap_group_t   *trap_group_p,
                                                       sx_trap_action_t  *trap_action_p,
                                                       uint32_t          *trap_group_cnt_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    const cl_list_item_t              *p_end = NULL;
    cl_list_item_t                    *p_iter = NULL;
    host_ifc_trap_group_queue_entry_t *p_object = NULL;
    uint32_t                           i = 0;

    SX_LOG_ENTER();

    if (trap_group_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Specified trap_group_p is NULL, return value [%s].\n",
                   sx_status_str(err));
        goto out;
    }

    if (trap_group_cnt_p == NULL) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Specified trap_group_cnt_p is NULL, return value [%s].\n",
                   sx_status_str(err));
        goto out;
    }

    cl_spinlock_acquire(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    *trap_group_cnt_p = cl_qlist_count(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);

    p_end = cl_qlist_end(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);
    p_iter = cl_qlist_head(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);

    while (p_end != p_iter) {
        p_object = PARENT_STRUCT(p_iter, host_ifc_trap_group_queue_entry_t, list_item);

        trap_group_p[i] = p_object->data.trap_group_id;

        if (trap_action_p != NULL) {
            trap_action_p[i] = p_object->data.trap_action;
        }

        /* get next */
        p_iter = cl_qlist_next(p_iter);
        i += 1;
    }

    cl_spinlock_release(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_trap_group_associated_attr_get(sx_trap_id_t        trap_id,
                                                       sx_trap_group_t     trap_group,
                                                       sx_hw_trap_group_e *hw_trap_group_p,
                                                       sx_trap_action_t   *trap_action_p,
                                                       boolean_t          *is_monitor_p,
                                                       boolean_t          *is_tac_capable_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    const cl_list_item_t              *p_end = NULL;
    cl_list_item_t                    *p_iter = NULL;
    host_ifc_trap_group_queue_entry_t *p_object = NULL;

    SX_LOG_ENTER();

    cl_spinlock_acquire(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    p_end = cl_qlist_end(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);
    p_iter = cl_qlist_head(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);

    while (p_end != p_iter) {
        p_object = PARENT_STRUCT(p_iter, host_ifc_trap_group_queue_entry_t, list_item);

        if (p_object->data.trap_group_id == trap_group) {
            if (is_monitor_p != NULL) {
                *is_monitor_p = p_object->data.is_monitor;
            }

            if (is_tac_capable_p != NULL) {
                *is_tac_capable_p = p_object->data.is_tac_capable;
            }

            if (hw_trap_group_p != NULL) {
                *hw_trap_group_p = p_object->data.hw_trap_group;
            }

            if (trap_action_p != NULL) {
                *trap_action_p = p_object->data.trap_action;
            }

            break;
        }

        /* get next */
        p_iter = cl_qlist_next(p_iter);
    }

    cl_spinlock_release(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_trap_id_flow_type_set(const sx_trap_id_t               trap_id,
                                              sx_trap_group_t                  trap_group,
                                              sx_host_ifc_trap_cfg_flow_type_e flow_type)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    const cl_list_item_t              *p_end = NULL;
    cl_list_item_t                    *p_iter = NULL;
    host_ifc_trap_group_queue_entry_t *p_object = NULL;
    boolean_t                          entry_found = FALSE;

    SX_LOG_ENTER();

    cl_spinlock_acquire(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    p_end = cl_qlist_end(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);
    p_iter = cl_qlist_head(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);

    while (p_end != p_iter) {
        p_object = PARENT_STRUCT(p_iter, host_ifc_trap_group_queue_entry_t, list_item);

        if (p_object->data.trap_group_id == trap_group) {
            p_object->data.is_ext_flow = flow_type;

            entry_found = TRUE;
            break;
        }

        /* get next */
        p_iter = cl_qlist_next(p_iter);
    }

    cl_spinlock_release(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    if (entry_found == FALSE) {
        SX_LOG_ERR("Failure: requested attributes for trap group %u were not found.\n", trap_group);
        err = SX_STATUS_ERROR;
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_trap_id_flow_type_get(const sx_trap_id_t                trap_id,
                                              sx_trap_group_t                   trap_group,
                                              sx_host_ifc_trap_cfg_flow_type_e *flow_type_p)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    const cl_list_item_t              *p_end = NULL;
    cl_list_item_t                    *p_iter = NULL;
    host_ifc_trap_group_queue_entry_t *p_object = NULL;

    SX_LOG_ENTER();

    cl_spinlock_acquire(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    p_end = cl_qlist_end(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);
    p_iter = cl_qlist_head(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.list);

    while (p_end != p_iter) {
        p_object = PARENT_STRUCT(p_iter, host_ifc_trap_group_queue_entry_t, list_item);

        if (p_object->data.trap_group_id == trap_group) {
            *flow_type_p = p_object->data.is_ext_flow;

            break;
        }

        /* get next */
        p_iter = cl_qlist_next(p_iter);
    }

    cl_spinlock_release(&__host_ifc_db_s.trap_id_2_trap_id_properties[trap_id].trap_group_queue.lock);

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_db_user_channel_filter_key_add(const sx_swid_t                 swid,
                                                             const sx_trap_id_t              trap_id,
                                                             cl_qlist_t                     *db_list,
                                                             const sx_host_ifc_filter_key_t *filter_key_p,
                                                             const sx_user_channel_t        *user_channel_p,
                                                             const pid_t                     client_pid)
{
    sx_status_t                          err = SX_STATUS_SUCCESS;
    host_ifc_trap_channel_filter_item_t *channel_filter_item = NULL;
    host_ifc_trap_channel_filter_item_t *channel_filter_item_to_add = NULL;
    cl_list_item_t                      *list_item = NULL;
    cl_qlist_t                          *pid_list = NULL;
    host_ifc_pid_item_t                 *pid_item = NULL;
    int                                  comparison_result = 0;

    SX_LOG_ENTER();

    /*
     * To make sure the list is always ordered, we need to find the first entry which is *bigger* than
     * the new entry, then insert the new entry before the found one. If no such entry is found,
     * the new entry will added to the tail.
     * If an equal entry is found:
     * 1) If the user channel type is not fd, then do nothing and return success.
     * 2) If the user channel type is fd, then add the input PID to the PID list of the entry
     *    if it is not in the list.
     */
    list_item = cl_qlist_head(db_list);
    while (list_item != cl_qlist_end(db_list)) {
        channel_filter_item = cl_item_obj(list_item, channel_filter_item, list_item);
        comparison_result = __host_ifc_db_compare_filter_key_and_user_channel(&(channel_filter_item->filter_key),
                                                                              &(channel_filter_item->user_channel),
                                                                              filter_key_p,
                                                                              user_channel_p);
        if (comparison_result > 0) {
            break;
        } else if (comparison_result == 0) {
            SX_LOG(SX_LOG_INFO,
                   "The input register key and user channel already exist in DB of swid %u trap_id %u\n",
                   swid,
                   trap_id);
            /*check if the client_pid exists and add it if not*/
            if (user_channel_p->type == SX_USER_CHANNEL_TYPE_FD) {
                pid_list = &(channel_filter_item->pid_list);
                pid_item = __host_ifc_db_find_pid_item_from_list(pid_list, client_pid);
                if (pid_item != NULL) {
                    SX_LOG(SX_LOG_INFO,
                           "The input register key and user channel (with fd type) associated with PID %d "
                           "already exist in DB of swid %u trap_id %u\n",
                           client_pid,
                           swid,
                           trap_id);
                    goto out;
                }
                /* adding client_pid to the pid list of the matching entry found */
                err = __host_ifc_db_add_pid_item_to_list(pid_list, client_pid);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("__host_ifc_db_add_pid_item_to_list failed, client_pid: %u, return value: [%s]\n",
                               client_pid, sx_status_str(err));
                    goto out;
                }
            }
            goto out;
        } else {
            list_item = cl_qlist_next(list_item);
        }
    }

    channel_filter_item_to_add = cl_malloc(sizeof(host_ifc_trap_channel_filter_item_t));

    if (channel_filter_item_to_add == NULL) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory\n");
        goto out;
    }
    SX_MEM_CLR_TYPE(channel_filter_item_to_add, host_ifc_trap_channel_filter_item_t);
    pid_list = &(channel_filter_item_to_add->pid_list);

    if (user_channel_p->type == SX_USER_CHANNEL_TYPE_FD) {
        cl_qlist_init(pid_list);
        err = __host_ifc_db_add_pid_item_to_list(pid_list, client_pid);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__host_ifc_db_add_pid_item_to_list failed, client_pid: %u, return value: [%s]\n",
                       client_pid, sx_status_str(err));
            goto out;
        }
    }

    SX_MEM_CPY_TYPE(&(channel_filter_item_to_add->filter_key), filter_key_p, sx_host_ifc_filter_key_t);
    SX_MEM_CPY_TYPE(&(channel_filter_item_to_add->user_channel), user_channel_p, sx_user_channel_t);
    cl_qlist_insert_prev(db_list, list_item, &(channel_filter_item_to_add->list_item));


out:
    if (SX_CHECK_FAIL(err) && (channel_filter_item_to_add != NULL)) {
        cl_free(channel_filter_item_to_add);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_db_user_channel_filter_key_delete(const sx_swid_t                 swid,
                                                                const sx_trap_id_t              trap_id,
                                                                cl_qlist_t                     *db_list,
                                                                const sx_host_ifc_filter_key_t *filter_key_p,
                                                                const sx_user_channel_t        *user_channel_p,
                                                                const pid_t                     client_pid)
{
    sx_status_t                          err = SX_STATUS_SUCCESS;
    host_ifc_trap_channel_filter_item_t *channel_filter_item = NULL;
    cl_list_item_t                      *list_item = NULL;
    cl_qlist_t                          *pid_list = NULL;
    host_ifc_pid_item_t                 *pid_item = NULL;
    int                                  comparison_result = 0;

    SX_LOG_ENTER();

    /*
     * When the specified entry is not found from the list, success is returned.
     * When the specified entry is found:
     * 1) if the user channel type is not fd, the entry is removed.
     * 2) if the user channel type is fd, we need to check whether the specified PID is in
     *    the PID list of the entry or not. If input PID is not in the PID list, success is returned.
     *    If input PID is in the PID list, we remove the PID from the PID list. After that, if the PID
     *    list becomes empty, the entry is also removed.
     */
    list_item = cl_qlist_head(db_list);
    while (list_item != cl_qlist_end(db_list)) {
        channel_filter_item = cl_item_obj(list_item, channel_filter_item, list_item);
        comparison_result = __host_ifc_db_compare_filter_key_and_user_channel(&(channel_filter_item->filter_key),
                                                                              &(channel_filter_item->user_channel),
                                                                              filter_key_p,
                                                                              user_channel_p);
        if (comparison_result == 0) {
            break;
        }
        list_item = cl_qlist_next(list_item);
    }

    if (list_item == cl_qlist_end(db_list)) {
        SX_LOG(SX_LOG_INFO,
               "The input register key and user channel were not found from DB of swid %u trap_id %u\n",
               swid,
               trap_id);
        goto out;
    }
    if (user_channel_p->type == SX_USER_CHANNEL_TYPE_FD) {
        pid_list = &(channel_filter_item->pid_list);
        pid_item = __host_ifc_db_find_pid_item_from_list(pid_list, client_pid);
        if (pid_item == NULL) {
            SX_LOG(SX_LOG_INFO, "The input register key and user channel (with fd type) associated with PID %d "
                   "were not found from DB of swid %u trap_id %u\n", client_pid, swid, trap_id);
            goto out;
        }
        cl_qlist_remove_item(pid_list, &(pid_item->list_item));
        cl_free(pid_item);

        if (!cl_is_qlist_empty(pid_list)) {
            goto out;
        }
    }

    cl_qlist_remove_item(db_list, list_item);
    cl_free(channel_filter_item);


out:
    SX_LOG_EXIT();
    return err;
}

static void __host_ifc_db_channel_filters_for_user_channel_delete_all(const sx_swid_t          swid,
                                                                      const sx_trap_id_t       trap_id,
                                                                      const sx_user_channel_t *user_channel_p,
                                                                      const pid_t              client_pid)
{
    cl_qlist_t                          *db_list = NULL;
    cl_list_item_t                      *list_item = NULL;
    cl_list_item_t                      *next_list_item = NULL;
    host_ifc_trap_channel_filter_item_t *channel_filter_item = NULL;
    cl_qlist_t                          *pid_list = NULL;
    host_ifc_pid_item_t                 *pid_item = NULL;
    sx_user_channel_type_t               user_channel_type;

    /*
     * Find out all the DB entries at the given trap ID which contain the user channel if its type is FD,
     * delete the specified PID from the PID list of the entry. If the PID list
     * becomes empty after that, then delete the entry as well.
     * if the user channel is not of type FD do nothing.
     */
    db_list = &(__host_ifc_db_s.swid_2_trap_channels_filters[swid][trap_id]);
    list_item = cl_qlist_head(db_list);
    while (list_item != cl_qlist_end(db_list)) {
        next_list_item = cl_qlist_next(list_item);
        channel_filter_item = cl_item_obj(list_item, channel_filter_item, list_item);
        user_channel_type = channel_filter_item->user_channel.type;
        if (__host_ifc_db_compare_user_channel(&(channel_filter_item->user_channel), user_channel_p) == 0) {
            if (user_channel_type == SX_USER_CHANNEL_TYPE_FD) {
                pid_list = &(channel_filter_item->pid_list);
                pid_item = __host_ifc_db_find_pid_item_from_list(pid_list, client_pid);
                if (pid_item != NULL) {
                    cl_qlist_remove_item(pid_list, &(pid_item->list_item));
                    cl_free(pid_item);
                    if (cl_is_qlist_empty(pid_list)) {
                        cl_qlist_remove_item(db_list, list_item);
                        cl_free(channel_filter_item);
                    }
                }
            } else {
                cl_qlist_remove_item(db_list, list_item);
                cl_free(channel_filter_item);
            }
        }
        list_item = next_list_item;
    }
}


sx_status_t host_ifc_db_trap_id_channel_filter_set(const sx_access_cmd_t           cmd,
                                                   const sx_swid_t                 swid,
                                                   const sx_trap_id_t              trap_id,
                                                   const sx_host_ifc_filter_key_t *filter_key_p,
                                                   const sx_user_channel_t        *user_channel_p,
                                                   const pid_t                     client_pid)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_swid_t   swid_in_db = swid;
    cl_qlist_t *db_list = NULL;

    SX_LOG_ENTER();

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_id_channel_filter_set: swid range error, swid: %u\n", swid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_id_channel_filter_set trap_id range error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (filter_key_p == NULL) {
        SX_LOG_ERR("filter_key_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (user_channel_p == NULL) {
        SX_LOG_ERR("user_channel_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid_in_db = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    db_list = &(__host_ifc_db_s.swid_2_trap_channels_filters[swid_in_db][trap_id]);

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        err = __host_ifc_db_user_channel_filter_key_add(swid,
                                                        trap_id,
                                                        db_list,
                                                        filter_key_p,
                                                        user_channel_p,
                                                        client_pid);

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR(
                "__host_ifc_db_add_user_channel_register_key failed, trap_id: %u, client_pid: %u, return value: [%s]\n",
                trap_id,
                client_pid,
                sx_status_str(err));
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        err = __host_ifc_db_user_channel_filter_key_delete(swid,
                                                           trap_id,
                                                           db_list,
                                                           filter_key_p,
                                                           user_channel_p,
                                                           client_pid);

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR(
                "__host_ifc_db_delete_user_channel_filter_key failed, trap_id: %u, client_pid: %u, return value: [%s]\n",
                trap_id,
                client_pid,
                sx_status_str(err));
        }
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        __host_ifc_db_channel_filters_for_user_channel_delete_all(swid,
                                                                  trap_id,
                                                                  user_channel_p,
                                                                  client_pid);
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_trap_id_channel_filter_get(const sx_access_cmd_t                         cmd,
                                                   const sx_swid_t                               swid,
                                                   const sx_trap_id_t                            trap_id,
                                                   const sx_host_ifc_channel_filter_get_entry_t *channel_filter_entry,
                                                   const pid_t                                   client_pid,
                                                   sx_host_ifc_channel_filter_get_entry_t       *channel_filter_entry_list_p,
                                                   uint32_t                                     *channel_filter_entry_cnt_p)
{
    sx_status_t                          err = SX_STATUS_SUCCESS;
    sx_swid_t                            swid_in_db = swid;
    cl_list_item_t                      *start_item = NULL;
    cl_qlist_t                          *db_list = NULL;
    host_ifc_trap_channel_filter_item_t *channel_filter_item = NULL;
    length_t                             size = 0;
    length_t                             max_size = 0;
    int                                  comparison_result = 0;

    SX_LOG_ENTER();

    if ((RM_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("host_ifc_db_rap_id_channel_filter_get: swid range error, swid: %u\n", swid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("host_ifc_db_trap_id_channel_filter_get trap_id range error, trap_id: %u\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == channel_filter_entry_cnt_p) {
        SX_LOG_ERR("channel_filter_entry_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*channel_filter_entry_cnt_p > 0) && (NULL == channel_filter_entry_list_p)) {
        SX_LOG_ERR("*channel_filter_entry_cnt_p is not 0 but channel_filter_entry_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_SWID_ID_STACKING == swid) {
        swid_in_db = HOST_INTERFACE_DB_STACKING_SWID_ID;
    }

    db_list = &(__host_ifc_db_s.swid_2_trap_channels_filters[swid_in_db][trap_id]);

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*channel_filter_entry_cnt_p == 0) {
            *channel_filter_entry_cnt_p = cl_qlist_count(db_list);
            goto out;
        } else {
            start_item = cl_qlist_head(db_list);
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        if (*channel_filter_entry_cnt_p == 0) {
            goto out;
        } else {
            start_item = cl_qlist_head(db_list);
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
        if (channel_filter_entry == NULL) {
            SX_LOG_ERR("channel_filter_entry is NULL.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        start_item = cl_qlist_head(db_list);
        while (start_item != cl_qlist_end(db_list)) {
            channel_filter_item = cl_item_obj(start_item, channel_filter_item, list_item);
            comparison_result = __host_ifc_db_compare_filter_key_and_user_channel(&(channel_filter_item->filter_key),
                                                                                  &(channel_filter_item->user_channel),
                                                                                  &(channel_filter_entry->filter_key),
                                                                                  &(channel_filter_entry->user_channel));
            if (comparison_result > 0) {
                SX_LOG_ERR("channel_filter_entry does not exist.\n");
                err = SX_STATUS_PARAM_ERROR;
                goto out;
                break;
            } else if (comparison_result == 0) {
                start_item = cl_qlist_next(start_item);
                break;
            } else {
                start_item = cl_qlist_next(start_item);
                if (start_item == cl_qlist_end(db_list)) {
                    SX_LOG_ERR("channel_filter_entry does not exist.\n");
                    err = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
            }
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

    size = 0;
    max_size = *channel_filter_entry_cnt_p;

    while ((size < max_size) && (start_item != cl_qlist_end(db_list))) {
        channel_filter_item = cl_item_obj(start_item, channel_filter_item, list_item);
        SX_MEM_CPY_TYPE(&(channel_filter_entry_list_p[size].filter_key),
                        &(channel_filter_item->filter_key),
                        sx_host_ifc_filter_key_t);
        SX_MEM_CPY_TYPE(&(channel_filter_entry_list_p[size].user_channel), &(channel_filter_item->user_channel),
                        sx_user_channel_t);
        if (channel_filter_item->user_channel.type == SX_USER_CHANNEL_TYPE_FD) {
            if (__host_ifc_db_find_pid_item_from_list(&(channel_filter_item->pid_list), client_pid) != NULL) {
                channel_filter_entry_list_p[size].user_channel.channel.fd.valid = TRUE;
            } else {
                channel_filter_entry_list_p[size].user_channel.channel.fd.valid = FALSE;
            }
        }
        size++;
        start_item = cl_qlist_next(start_item);
    }

    *channel_filter_entry_cnt_p = size;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t host_ifc_db_profile_cfg_set(const sx_trap_truncate_profile_id_t trunc_profile_id,
                                        const host_ifc_db_profile_cfg_t    *host_ifc_db_profile_cfg_p)
{
    if (!SX_TRAP_TRUNCATE_PROFILE_CHECK_RANGE(trunc_profile_id)) {
        SX_LOG_ERR("trunc_profile_id is out of range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }
    truncate_profile_cfg_db[trunc_profile_id] = *host_ifc_db_profile_cfg_p;
    return SX_STATUS_SUCCESS;
}

sx_status_t host_ifc_db_profile_cfg_get(const sx_trap_truncate_profile_id_t trunc_profile_id,
                                        host_ifc_db_profile_cfg_t          *host_ifc_db_profile_cfg_p)
{
    if (!SX_TRAP_TRUNCATE_PROFILE_CHECK_RANGE(trunc_profile_id)) {
        SX_LOG_ERR("trunc_profile_id is out of range\n");
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    *host_ifc_db_profile_cfg_p = truncate_profile_cfg_db[trunc_profile_id];
    return SX_STATUS_SUCCESS;
}


static cl_status_t __host_ifc_db_trap_id_list_compare(const void *const p_object, void *context)
{
    cl_status_t   cl_status = CL_SUCCESS;
    sx_trap_id_t *trap_id_p = (sx_trap_id_t*)context;
    sx_trap_id_t  trap_id_db = (intptr_t)p_object;

    if (*trap_id_p == trap_id_db) {
        goto out;
    }
    cl_status = CL_ERROR;

out:
    return cl_status;
}

static sx_status_t __host_ifc_db_trap_id_from_group_list_remove(sx_trap_group_t hw_trap_group, sx_trap_id_t trap_id)
{
    cl_list_iterator_t list_iter = NULL;
    sx_status_t        status = SX_STATUS_SUCCESS;
    const sx_swid_id_t swid = 0;
    cl_list_t         *associated_trap_id_list_p =
        &(__host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].associated_trap_id_list);

    SX_LOG_ENTER();

    list_iter = cl_list_find_from_head(associated_trap_id_list_p,
                                       __host_ifc_db_trap_id_list_compare,
                                       &trap_id);

    if (list_iter != cl_list_end(associated_trap_id_list_p)) {
        cl_list_remove_item(associated_trap_id_list_p, list_iter);
    } else {
        SX_LOG_DBG("Didn't find trap id [%u] in HW trap group [%u]\n", trap_id, hw_trap_group);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return (status);
}

static sx_status_t __host_ifc_db_trap_id_to_group_list_add(sx_trap_group_t hw_trap_group, sx_trap_id_t trap_id)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    cl_status_t        cl_status = CL_SUCCESS;
    const sx_swid_id_t swid = 0;
    cl_list_t         *associated_trap_id_list_p =
        &(__host_ifc_db_s.swid_2_trap_groups[swid][hw_trap_group].associated_trap_id_list);
    cl_list_iterator_t list_iter;

    SX_LOG_ENTER();

    list_iter = cl_list_find_from_head(associated_trap_id_list_p,
                                       __host_ifc_db_trap_id_list_compare,
                                       &trap_id);

    if (list_iter != cl_list_end(associated_trap_id_list_p)) {
        SX_LOG_DBG("Trap id [%u] already exists in then HW trap group [%u]\n", trap_id, hw_trap_group);
        status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    cl_status = cl_list_insert_tail(associated_trap_id_list_p, (void*)(intptr_t)trap_id);
    if (CL_SUCCESS != cl_status) {
        SX_LOG_ERR("Failed to insert trap id [%u] to HW trap group [%u]\n", trap_id, hw_trap_group);
        status = cl_status_to_sx_status(cl_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t host_ifc_db_trap_id_list_get(const sx_trap_group_t trap_group_id,
                                         OUT sx_trap_id_t     *trap_id_arr,
                                         INOUT length_t       *trap_id_num_p)
{
    sx_status_t        status = SX_STATUS_SUCCESS;
    const sx_swid_t    swid = 0;
    uint32_t           i;
    size_t             actual_list_count = 0;
    cl_list_iterator_t list_end, iter;
    const cl_list_t   *trap_id_list_p = NULL;

    SX_LOG_ENTER();

    if (g_is_host_ifc_db_initialized == FALSE) {
        status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG(SX_LOG_ERROR, "Host IFC DB isn't initialized\n");
        goto out;
    }

    if (__host_ifc_db_s.swid_2_trap_groups[swid][trap_group_id].is_configured == FALSE) {
        SX_LOG_ERR("Failed to retrieve trap IDs. HW trap group [%u] isn't configured, err: %s.\n",
                   trap_group_id, sx_status_str(status));
        goto out;
    }

    trap_id_list_p = &(__host_ifc_db_s.swid_2_trap_groups[swid][trap_group_id].associated_trap_id_list);

    actual_list_count = cl_list_count(trap_id_list_p);

    if (trap_id_arr == NULL) {
        *trap_id_num_p = actual_list_count;
        status = SX_STATUS_SUCCESS;
        goto out;
    }

    if (actual_list_count <= *trap_id_num_p) {
        /* only size required or array was big enough*/
        *trap_id_num_p = actual_list_count;
        status = SX_STATUS_SUCCESS;
    } else {
        /* actual list len is bigger than the passed array len*/
        status = SX_STATUS_CMD_INCOMPLETE;
    }

    iter = cl_list_head(trap_id_list_p);
    list_end = cl_list_end(trap_id_list_p);
    for (i = 0; (iter != list_end) && (i < *trap_id_num_p); i++) {
        trap_id_arr[i] = (intptr_t)cl_list_obj(iter);
        iter = cl_list_next(iter);
    }

out:
    SX_LOG_EXIT();
    return status;
}


sx_status_t host_ifc_db_trap_id_from_group_list_unset(sx_trap_group_t hw_trap_group, sx_trap_id_t trap_id)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_is_host_ifc_db_initialized == FALSE) {
        status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Host IFC DB isn't initialized\n");
        goto out;
    }

    if (hw_trap_group == SX_HW_TRAP_GROUP_DISABLE_E) {
        status = SX_STATUS_SUCCESS;
        goto out;
    }

    status = __host_ifc_db_trap_id_from_group_list_remove(hw_trap_group, trap_id);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to remove trap id [%u] from HW trap group [%u] list, return value [%s].\n",
                   trap_id, hw_trap_group, sx_status_str(status));
        goto out;
    }

    status = adviser_process_event(ADVISER_EVENT_POST_TRAP_ID_PRIO_CHANGE_E, &trap_id);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Could not process event '%s' for trap ID %u.\n",
                   ADVISER_EVENT_STR(ADVISER_EVENT_POST_TRAP_ID_PRIO_CHANGE_E), trap_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}
