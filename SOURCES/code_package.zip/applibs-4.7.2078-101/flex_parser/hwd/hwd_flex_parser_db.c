/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include <complib/cl_map.h>
#include <complib/cl_dbg.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "hwd_flex_parser.h"
#include "hwd_flex_parser_reg.h"
#include "hwd_flex_parser_db.h"
#include "utils/sx_mem.h"

#undef __MODULE__
#define __MODULE__ FLEX_PARSER

/************************************************
 *  Local definitions
 ***********************************************/

#define PORT_ROOT_DB_POOL_MIN_SIZE  0
#define PORT_ROOT_DB_POOL_MAX_SIZE  0
#define PORT_ROOT_DB_POOL_GROW_SIZE 8


/************************************************
 *  Local Type definitions
 ***********************************************/
/* The following structures are used to map a port to the flex program
 * to be used as a root for that port.
 */

typedef struct {
    cl_qpool_t port_root_pool;
    cl_qmap_t  port_root_map;
} flex_parser_db_port_root_db_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static uint32_t                              hwd_vxlan_udp_dport_val = 0; /* value configured by user written to register */
static uint32_t                              hwd_zero_dev_usr_conf_vxlan_udp_dport_val = 0; /* user configured value used for zero device configuration */
static hwd_flex_parser_gp_reg_ext_point_db_t g_gp_reg_ext_point_db[SX_GP_REGISTER_LAST_E];

/* This DB is used to store the info about the fixed-to-fixed transitions */
static fixed_transition_db_entry_t g_fixed_transition_db_spc2[] = {
    {SX_FLEX_PARSER_HEADER_MAC_E,  SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x800,  0x1,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_MPLS_E, SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE,
     FLEX_PARSER_GUESSING_TRANSITION_VALUE, 0x60,
     SX_FLEX_PARSER_ENCAP_INNER_E},
    {SX_FLEX_PARSER_HEADER_MPLS_E, SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE,
     FLEX_PARSER_GUESSING_TRANSITION_VALUE, 0x61,
     SX_FLEX_PARSER_ENCAP_INNER_E},
    {SX_FLEX_PARSER_HEADER_MAC_E,  SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x800,  0x81,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_MAC_E,  SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x86DD, 0x2,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_MAC_E,  SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x86DD, 0x82,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_MAC_E,  SX_FLEX_PARSER_HEADER_MPLS_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE,
     MAC_TO_MPLS_TRANSITION_VALUE_1, 0x3,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_MAC_E,  SX_FLEX_PARSER_HEADER_MPLS_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE,
     MAC_TO_MPLS_TRANSITION_VALUE_2, 0x4,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_MAC_E,  SX_FLEX_PARSER_HEADER_MPLS_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE,
     MAC_TO_MPLS_TRANSITION_VALUE_1, 0x83,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_MAC_E,  SX_FLEX_PARSER_HEADER_MPLS_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE,
     MAC_TO_MPLS_TRANSITION_VALUE_2, 0x84,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_MAC_E,  SX_FLEX_PARSER_HEADER_ARP_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x806,  0x5,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_MAC_E,  SX_FLEX_PARSER_HEADER_ARP_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x806,  0x85,
     SX_FLEX_PARSER_ENCAP_OUTER_E},

    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_UDP_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x11, 0x10,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_UDP_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x11, 0x90,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_TCP_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x6,  0x11,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_TCP_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x6,  0x91,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_GRE_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x2F, 0x12,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x4,  0x13,
     SX_FLEX_PARSER_ENCAP_INNER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x29, 0x14,
     SX_FLEX_PARSER_ENCAP_INNER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_ICMP_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x1,  0x15,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_ICMP_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x1,  0x95,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_IGMP_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x2,  0x16,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_IGMP_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x2,  0x96,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_IPSEC_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE,
     IPV4_TO_IPSEC_TRANSITION_VALUE_1, 0x17,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_HEADER_IPSEC_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE,
     IPV4_TO_IPSEC_TRANSITION_VALUE_1, 0x97,
     SX_FLEX_PARSER_ENCAP_OUTER_E},

    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_UDP_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x11, 0x20,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_UDP_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x11, 0xA0,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_TCP_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x6,  0x21,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_TCP_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x6,  0xA1,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_GRE_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x2F, 0x22,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x4,  0x23,
     SX_FLEX_PARSER_ENCAP_INNER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x29, 0x24,
     SX_FLEX_PARSER_ENCAP_INNER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_ICMP_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x1,  0x25,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_ICMP_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x1,  0xA5,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IGMP_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x2,  0x26,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IGMP_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x2,  0xA6,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPSEC_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x50, 0x27,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPSEC_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x50, 0xA7,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    /* Note: In order to keep backward compatible the UDP to VXLAN should be the first UDP transition */
    {SX_FLEX_PARSER_HEADER_UDP_E,  SX_FLEX_PARSER_HEADER_VXLAN_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 4789, 0x31,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_UDP_E,  SX_FLEX_PARSER_HEADER_BTH_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 4791, 0x30,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_UDP_E,  SX_FLEX_PARSER_HEADER_BTH_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 4791, 0xB0,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_UDP_E,  SX_FLEX_PARSER_HEADER_VXLAN_GPE_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 4790, 0x32,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_UDP_E,  SX_FLEX_PARSER_HEADER_GENEVE_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 6081, 0x33,
     SX_FLEX_PARSER_ENCAP_OUTER_E},

    {SX_FLEX_PARSER_HEADER_VXLAN_GPE_E, SX_FLEX_PARSER_HEADER_MAC_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0, 0x40,
     SX_FLEX_PARSER_ENCAP_INNER_E},
    {SX_FLEX_PARSER_HEADER_GENEVE_E, SX_FLEX_PARSER_HEADER_MAC_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0, 0x41,
     SX_FLEX_PARSER_ENCAP_INNER_E},

    {SX_FLEX_PARSER_HEADER_GRE_E,  SX_FLEX_PARSER_HEADER_MAC_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x6558,  0x50,
     SX_FLEX_PARSER_ENCAP_INNER_E},
    {SX_FLEX_PARSER_HEADER_GRE_E,  SX_FLEX_PARSER_HEADER_IPV4_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x800,   0x51,
     SX_FLEX_PARSER_ENCAP_INNER_E},
    {SX_FLEX_PARSER_HEADER_GRE_E,  SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x86DD0, 0x52,
     SX_FLEX_PARSER_ENCAP_INNER_E},

    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_HBH_EXT_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x0, 0x70,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_HBH_EXT_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x0, 0xF0,
     SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_DEST_EXT_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x0,
     0x71, SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_DEST_EXT_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x0,
     0xF1, SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_ROUTING_EXT_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x0,
     0x72, SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_ROUTING_EXT_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x0,
     0xF2, SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_FRAGMENT_EXT_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x0,
     0x73, SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_FRAGMENT_EXT_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x0,
     0xF3, SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_MOBILITY_EXT_E, SX_FLEX_PARSER_ENCAP_OUTER_E, TRUE, 0x0,
     0x74, SX_FLEX_PARSER_ENCAP_OUTER_E},
    {SX_FLEX_PARSER_HEADER_IPV6_E, SX_FLEX_PARSER_HEADER_IPV6_MOBILITY_EXT_E, SX_FLEX_PARSER_ENCAP_INNER_E, TRUE, 0x0,
     0xF4, SX_FLEX_PARSER_ENCAP_OUTER_E},
};
static uint32_t                    g_fixed_transition_db_size = sizeof(g_fixed_transition_db_spc2) /
                                                                sizeof(fixed_transition_db_entry_t);
static cl_map_t g_fixed_transition_map;

/* This DB is used to store the info about the fixed-to-flex/flex-to-flex/flex-to-fixed transitions */
static flex_transition_db_entry_t *g_flex_transition_db_spc2 = NULL;


/* This DB is used to store the info for a header defined by the system */
static header_db_entry_t g_fixed_header_db_spc2[SX_FLEX_PARSER_HEADER_LAST] = {
    [SX_FLEX_PARSER_HEADER_MAC_E] = {.valid = TRUE,
                                     .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                     .hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_MAC_E,
                                     .hw_entry_index = SXD_PARSER_HEADER_MAC,
                                     .fixed_data = {.can_have_tlv = FALSE,
                                                    .can_be_inner = TRUE,
                                                    .can_be_next_ph = TRUE,
                                                    .next_protocol_mask = 0xffff}, },
    [SX_FLEX_PARSER_HEADER_IPV4_E] = {.valid = TRUE,
                                      .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                      .hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV4_E,
                                      .hw_entry_index = SXD_PARSER_HEADER_IPV4,
                                      .fixed_data = {.can_have_tlv = TRUE,
                                                     .can_be_inner = TRUE,
                                                     .can_be_next_ph = TRUE,
                                                     .next_protocol_mask = 0xff}, },
    [SX_FLEX_PARSER_HEADER_IPV6_E] = {.valid = TRUE,
                                      .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                      .hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV6_E,
                                      .hw_entry_index = SXD_PARSER_HEADER_IPV6,
                                      .fixed_data = {.can_have_tlv = FALSE,
                                                     .can_be_inner = TRUE,
                                                     .can_be_next_ph = TRUE,
                                                     .next_protocol_mask = 0xff}, },
    [SX_FLEX_PARSER_HEADER_UDP_E] = {.valid = TRUE,
                                     .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                     .hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_UDP_E,
                                     .hw_entry_index = SXD_PARSER_HEADER_UDP,
                                     .fixed_data = {.can_have_tlv = FALSE,
                                                    .can_be_inner = TRUE,
                                                    .can_be_next_ph = TRUE,
                                                    .next_protocol_mask = 0xffff}, },
    [SX_FLEX_PARSER_HEADER_TCP_E] = {.valid = TRUE,
                                     .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                     .hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_TCP_E,
                                     .hw_entry_index = SXD_PARSER_HEADER_TCP,
                                     .fixed_data = {.can_have_tlv = TRUE,
                                                    .can_be_inner = TRUE,
                                                    .can_be_next_ph = TRUE,
                                                    .next_protocol_mask = 0xffff}, },
    [SX_FLEX_PARSER_HEADER_GRE_E] = {.valid = TRUE,
                                     .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                     .hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_GRE_E,
                                     .hw_entry_index = SXD_PARSER_HEADER_GRE,
                                     .fixed_data = {.can_have_tlv = FALSE,
                                                    .can_be_inner = FALSE,
                                                    .can_be_next_ph = TRUE,
                                                    .next_protocol_mask = 0xffff}, },
    [SX_FLEX_PARSER_HEADER_VXLAN_GPE_E] = {.valid = TRUE,
                                           .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                           .hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_VXLAN_GPE_E,
                                           .hw_entry_index = SXD_PARSER_HEADER_VXLAN_GPE,
                                           .fixed_data = {.can_have_tlv = FALSE,
                                                          .can_be_inner = FALSE,
                                                          .can_be_next_ph = TRUE,
                                                          .next_protocol_mask = 0xff}, },
    [SX_FLEX_PARSER_HEADER_GENEVE_E] = {.valid = TRUE,
                                        .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                        .hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_GENEVE_E,
                                        .hw_entry_index = SXD_PARSER_HEADER_GENEVE,
                                        .fixed_data = {.can_have_tlv = TRUE,
                                                       .can_be_inner = FALSE,
                                                       .can_be_next_ph = TRUE,
                                                       .next_protocol_mask = 0xffff}, },
    [SX_FLEX_PARSER_HEADER_MPLS_E] = {.valid = TRUE,
                                      .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                      .hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_MPLS_E,
                                      .hw_entry_index = SXD_PARSER_HEADER_MPLS,
                                      .fixed_data = {.can_have_tlv = TRUE,
                                                     .can_be_inner = TRUE,
                                                     .can_be_next_ph = TRUE,
                                                     .next_protocol_mask = 0xf}, },
    [SX_FLEX_PARSER_HEADER_IPV6_HBH_EXT_E] = {.valid = TRUE,
                                              .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                              .hdr.hdr_data.parser_hdr_fixed = SX_FLEX_PARSER_HEADER_IPV6_HBH_EXT_E,
                                              .hw_entry_index = SXD_PARSER_HEADER_IPV6_HBH_EXT,
                                              .fixed_data = {.can_have_tlv = TRUE,
                                                             .can_be_inner = TRUE,
                                                             .can_be_next_ph = FALSE,
                                                             .next_protocol_mask = 0xff}, },
    [SX_FLEX_PARSER_HEADER_IPV6_ROUTING_EXT_E] = {.valid = TRUE,
                                                  .hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E,
                                                  .hdr.hdr_data.parser_hdr_fixed =
                                                      SX_FLEX_PARSER_HEADER_IPV6_ROUTING_EXT_E,
                                                  .hw_entry_index = SXD_PARSER_HEADER_IPV6_HBH_EXT,
                                                  .fixed_data = {.can_have_tlv = TRUE,
                                                                 .can_be_inner = TRUE,
                                                                 .can_be_next_ph = TRUE,
                                                                 .next_protocol_mask = 0xff}, },
};

/* This DB is used to store the info for a flex header defined by the user */
static header_db_entry_t flex_header_db_spc2[SX_FLEX_PARSER_HEADER_FPP_LAST] = {
    [SX_FLEX_PARSER_HEADER_FPP0] =
    {.valid = FALSE, .hdr = {.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E, .hdr_data.parser_hdr_fpp =
                                 SX_FLEX_PARSER_HEADER_FPP0}, .hw_entry_index = SXD_PARSER_HEADER_FPH0, },
    [SX_FLEX_PARSER_HEADER_FPP1] =
    {.valid = FALSE, .hdr = {.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E, .hdr_data.parser_hdr_fpp =
                                 SX_FLEX_PARSER_HEADER_FPP1}, .hw_entry_index = SXD_PARSER_HEADER_FPH1, },
    [SX_FLEX_PARSER_HEADER_FPP2] =
    {.valid = FALSE, .hdr = {.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E, .hdr_data.parser_hdr_fpp =
                                 SX_FLEX_PARSER_HEADER_FPP2}, .hw_entry_index = SXD_PARSER_HEADER_FPH2, },
    [SX_FLEX_PARSER_HEADER_FPP3] =
    {.valid = FALSE, .hdr = {.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E, .hdr_data.parser_hdr_fpp =
                                 SX_FLEX_PARSER_HEADER_FPP3}, .hw_entry_index = SXD_PARSER_HEADER_FPH3, },
    [SX_FLEX_PARSER_HEADER_FPP4] =
    {.valid = FALSE, .hdr = {.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E, .hdr_data.parser_hdr_fpp =
                                 SX_FLEX_PARSER_HEADER_FPP4}, .hw_entry_index = SXD_PARSER_HEADER_FPH4, },
    [SX_FLEX_PARSER_HEADER_FPP5] =
    {.valid = FALSE, .hdr = {.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E, .hdr_data.parser_hdr_fpp =
                                 SX_FLEX_PARSER_HEADER_FPP5}, .hw_entry_index = SXD_PARSER_HEADER_FPH5, },
    [SX_FLEX_PARSER_HEADER_FPP6] =
    {.valid = FALSE, .hdr = {.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E, .hdr_data.parser_hdr_fpp =
                                 SX_FLEX_PARSER_HEADER_FPP6}, .hw_entry_index = SXD_PARSER_HEADER_FPH6, },
    [SX_FLEX_PARSER_HEADER_FPP7] =
    {.valid = FALSE, .hdr = {.parser_hdr_type = SX_FLEX_PARSER_HEADER_FPP_E, .hdr_data.parser_hdr_fpp =
                                 SX_FLEX_PARSER_HEADER_FPP7}, .hw_entry_index = SXD_PARSER_HEADER_FPH7, },
};

/* This DB is used to store information about flex extraction point. Currently only reference count is kept. */
static fexp_db_entry_t flex_extraction_point_db_spc2[SX_FLEX_PARSER_FEXP_LAST] = {
    [SX_FLEX_PARSER_FEXP0] = {.valid = FALSE, .fexp = SX_FLEX_PARSER_FEXP0, .refcount = 0},
    [SX_FLEX_PARSER_FEXP1] = {.valid = FALSE, .fexp = SX_FLEX_PARSER_FEXP1, .refcount = 0},
    [SX_FLEX_PARSER_FEXP2] = {.valid = FALSE, .fexp = SX_FLEX_PARSER_FEXP2, .refcount = 0},
    [SX_FLEX_PARSER_FEXP3] = {.valid = FALSE, .fexp = SX_FLEX_PARSER_FEXP3, .refcount = 0},
    [SX_FLEX_PARSER_FEXP4] = {.valid = FALSE, .fexp = SX_FLEX_PARSER_FEXP4, .refcount = 0},
    [SX_FLEX_PARSER_FEXP5] = {.valid = FALSE, .fexp = SX_FLEX_PARSER_FEXP5, .refcount = 0},
    [SX_FLEX_PARSER_FEXP6] = {.valid = FALSE, .fexp = SX_FLEX_PARSER_FEXP6, .refcount = 0},
    [SX_FLEX_PARSER_FEXP7] = {.valid = FALSE, .fexp = SX_FLEX_PARSER_FEXP7, .refcount = 0},
};

/* This DB is used to store the mapping of ports to the flex header that will act as a root for parsing */
static flex_parser_db_port_root_db_t port_root_db_spc2;
/************************************************
 *  Local function declarations
 ***********************************************/
static boolean_t __compare_parser_header(const sx_flex_parser_header_t *header1_p,
                                         const sx_flex_parser_header_t *header2_p);

/************************************************
 *  Function implementations
 ***********************************************/
const char* get_flex_header_ref_name(char* name_buf, size_t name_size, void *flex_header_p)
{
    snprintf(name_buf, name_size, "%s",
             sx_flex_parser_header_fpp_str(*((sx_flex_parser_header_fpp_e*)flex_header_p)));
    return name_buf;
}

const char* get_fixed_header_ref_name(char* name_buf, size_t name_size, void *fixed_header_p)
{
    snprintf(name_buf, name_size, "%s",
             sx_flex_parser_header_fixed_str(*((sx_flex_parser_header_fixed_e*)fixed_header_p)));
    return name_buf;
}


static uint64_t __create_fixed_transition_key(const sx_flex_parser_header_fixed_e from,
                                              const sx_flex_parser_header_fixed_e to,
                                              const sx_flex_parser_encap_level_e  encap_level,
                                              uint32_t                            transition)
{
    /* Take care of two special case where we cannot use the transition value as the key. */
    if ((from == SX_FLEX_PARSER_HEADER_UDP_E) &&
        (to == SX_FLEX_PARSER_HEADER_VXLAN_E) &&
        (encap_level == SX_FLEX_PARSER_ENCAP_OUTER_E)) {
        transition = 0;
    }
    /*"Guessing" transition value in the table. */
    if ((from == SX_FLEX_PARSER_HEADER_MPLS_E) &&
        ((to == SX_FLEX_PARSER_HEADER_IPV4_E) || (to == SX_FLEX_PARSER_HEADER_IPV6_E)) &&
        (encap_level == SX_FLEX_PARSER_ENCAP_OUTER_E)) {
        transition = 0;
    }
    /* Both transition values 0x33 and 0x32, are valid. */
    if ((from == SX_FLEX_PARSER_HEADER_IPV4_E) &&
        (to == SX_FLEX_PARSER_HEADER_IPSEC_E) &&
        ((encap_level == SX_FLEX_PARSER_ENCAP_OUTER_E) || (encap_level == SX_FLEX_PARSER_ENCAP_INNER_E))) {
        if ((transition == IPV4_TO_IPSEC_TRANSITION_VALUE_1) || (transition == IPV4_TO_IPSEC_TRANSITION_VALUE_2)) {
            transition = 0;
        }
    }
    return ((((uint64_t)transition) << 48) | ((uint64_t)from) <<
            32) | (((uint64_t)to) << 16) | ((uint64_t)encap_level);
}

static boolean_t __compare_parser_header(const sx_flex_parser_header_t *header1_p,
                                         const sx_flex_parser_header_t *header2_p)
{
    boolean_t equal = FALSE;

    if (header1_p->parser_hdr_type == header2_p->parser_hdr_type) {
        switch (header1_p->parser_hdr_type) {
        case SX_FLEX_PARSER_HEADER_FIXED_E:
            if (header1_p->hdr_data.parser_hdr_fixed == header2_p->hdr_data.parser_hdr_fixed) {
                equal = TRUE;
            }
            break;

        case SX_FLEX_PARSER_HEADER_FPP_E:
            if (header1_p->hdr_data.parser_hdr_fpp == header2_p->hdr_data.parser_hdr_fpp) {
                equal = TRUE;
            }
            break;

        default:
            break;
        }
    }

    return equal;
}

/* This is a utility function to retrieve the string of a parse header */
const char* get_flex_parser_header_string(const sx_flex_parser_header_t *header_p)
{
    const char* ret = NULL;

    switch (header_p->parser_hdr_type) {
    case SX_FLEX_PARSER_HEADER_FIXED_E:
        ret = sx_flex_parser_header_fixed_str(header_p->hdr_data.parser_hdr_fixed);
        break;

    case SX_FLEX_PARSER_HEADER_FPP_E:
        ret = sx_flex_parser_header_fpp_str(header_p->hdr_data.parser_hdr_fpp);
        break;

    default:
        ret = sx_flex_parser_header_type_str(header_p->parser_hdr_type);
        break;
    }
    return ret;
}

sx_status_t hwd_flex_parser_db_init()
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    cl_status_t                   cl_rc = CL_SUCCESS;
    sx_flex_parser_header_fpp_e   flex_header = 0;
    sx_flex_parser_header_fixed_e fixed_header = 0;
    uint32_t                      i = 0;
    uint64_t                      key = 0;
    ref_name_data_t               flex_ref_name_data = {.print_func_p = get_flex_header_ref_name,
                                                        .ref_data_p = &flex_header,
                                                        .data_size = sizeof(flex_header)};
    ref_name_data_t               fixed_ref_name_data = {.print_func_p = get_fixed_header_ref_name,
                                                         .ref_data_p = &fixed_header,
                                                         .data_size = sizeof(fixed_header)};

    SX_LOG_ENTER();

    /* Initialize the transition db. Only the valid and the entry index are necessary,
     * the rest are only nice to have for debugging.
     */
    g_flex_transition_db_spc2 = cl_calloc(MAX_HW_FLEX_TRANSITIONS, sizeof(flex_transition_db_entry_t));
    if (g_flex_transition_db_spc2 == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("No memory to allocate flex parser transition DB\n");
        goto out;
    }

    for (i = 0; i < MAX_HW_FLEX_TRANSITIONS; i++) {
        g_flex_transition_db_spc2[i].valid = FALSE;
        g_flex_transition_db_spc2[i].in_use = FALSE;
        g_flex_transition_db_spc2[i].hw_entry_index = i;
        g_flex_transition_db_spc2[i].transition_value = 0;
        g_flex_transition_db_spc2[i].from.parser_hdr_type = SX_FLEX_PARSER_HEADER_LAST_E;
        g_flex_transition_db_spc2[i].to.parser_hdr_type = SX_FLEX_PARSER_HEADER_LAST_E;
        g_flex_transition_db_spc2[i].encap_level = SX_FLEX_PARSER_ENCAP_LAST_E;
    }
    /* Initialize the reference count of the fixed and flex headers*/
    for (flex_header = 0; flex_header < SX_FLEX_PARSER_HEADER_FPP_LAST; flex_header++) {
        sdk_refcount_init(&flex_header_db_spc2[flex_header].from_refcount, &flex_ref_name_data, NULL);
        sdk_refcount_init(&flex_header_db_spc2[flex_header].to_refcount, &flex_ref_name_data, NULL);
        sdk_refcount_init(&flex_header_db_spc2[flex_header].fpp_data.ext_refcount, &flex_ref_name_data, NULL);
    }
    for (fixed_header = 0; fixed_header < SX_FLEX_PARSER_HEADER_LAST; fixed_header++) {
        if (g_fixed_header_db_spc2[fixed_header].valid) {
            sdk_refcount_init(&g_fixed_header_db_spc2[fixed_header].from_refcount, &fixed_ref_name_data, NULL);
            sdk_refcount_init(&g_fixed_header_db_spc2[fixed_header].to_refcount, &fixed_ref_name_data, NULL);
        }
    }

    /* Create a map for the fixed transitions so it will be easy to use */
    cl_rc = cl_map_init(&g_fixed_transition_map, g_fixed_transition_db_size);
    if (cl_rc != CL_SUCCESS) {
        SX_LOG_ERR("Failed to init flex parser fixed transition DB. Error: (%s).\n", CL_STATUS_MSG(cl_rc));
        rc = SX_STATUS_NO_MEMORY;
        goto cl_map_fail;
    }
    for (i = 0; i < g_fixed_transition_db_size; i++) {
        key = __create_fixed_transition_key(g_fixed_transition_db_spc2[i].from,
                                            g_fixed_transition_db_spc2[i].to,
                                            g_fixed_transition_db_spc2[i].curr_encap_level,
                                            g_fixed_transition_db_spc2[i].transition_value);
        cl_map_insert(&g_fixed_transition_map, key, &g_fixed_transition_db_spc2[i]);
    }

    /* Initialize the DB used to map ports to their root flex header (if relevant) */
    cl_rc = CL_QPOOL_INIT(&(port_root_db_spc2.port_root_pool),
                          PORT_ROOT_DB_POOL_MIN_SIZE,
                          PORT_ROOT_DB_POOL_MAX_SIZE,
                          PORT_ROOT_DB_POOL_GROW_SIZE,
                          sizeof(flex_parser_db_port_root_item_t),
                          NULL, NULL, NULL);

    if (cl_rc != CL_SUCCESS) {
        SX_LOG_ERR("Failed to init flex parser port root DB. Error: (%s).\n", CL_STATUS_MSG(cl_rc));
        rc = SX_STATUS_NO_MEMORY;
        goto qpool_fail;
    }
    cl_qmap_init(&(port_root_db_spc2.port_root_map));

    goto out;

qpool_fail:
    cl_map_destroy(&g_fixed_transition_map);
cl_map_fail:
    if (g_flex_transition_db_spc2 != NULL) {
        for (flex_header = 0; flex_header < SX_FLEX_PARSER_HEADER_FPP_LAST; flex_header++) {
            sdk_refcount_deinit(&flex_header_db_spc2[flex_header].from_refcount, TRUE);
            sdk_refcount_deinit(&flex_header_db_spc2[flex_header].to_refcount, TRUE);
        }
        for (fixed_header = 0; fixed_header < SX_FLEX_PARSER_HEADER_LAST; fixed_header++) {
            if (g_fixed_header_db_spc2[fixed_header].valid) {
                sdk_refcount_deinit(&g_fixed_header_db_spc2[fixed_header].from_refcount, TRUE);
                sdk_refcount_deinit(&g_fixed_header_db_spc2[fixed_header].to_refcount, TRUE);
            }
        }
        cl_free(g_flex_transition_db_spc2);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_deinit(boolean_t is_forced)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    uint32_t                      i = 0;
    sx_flex_parser_header_fpp_e   flex_header = 0;
    sx_flex_parser_header_fixed_e fixed_header = 0;


    SX_LOG_ENTER();

    /* Deinitialize the transition db*/

    if (is_forced == FALSE) {
        /* Do a validation before removing the transitions */
        for (i = 0; i < MAX_HW_FLEX_TRANSITIONS; i++) {
            if (g_flex_transition_db_spc2[i].valid == TRUE) {
                rc = SX_STATUS_DB_NOT_EMPTY;
                SX_LOG_ERR("Failed to deinit flex parser transition DB: flex transition %u in used.\n", i);
                goto out;
            }
        }
    }

    for (i = 0; i < MAX_HW_FLEX_TRANSITIONS; i++) {
        if (g_flex_transition_db_spc2[i].valid == TRUE) {
            g_flex_transition_db_spc2[i].valid = FALSE;
            g_flex_transition_db_spc2[i].in_use = FALSE;
            g_flex_transition_db_spc2[i].transition_value = 0;
            g_flex_transition_db_spc2[i].from.parser_hdr_type = SX_FLEX_PARSER_HEADER_LAST_E;
            g_flex_transition_db_spc2[i].to.parser_hdr_type = SX_FLEX_PARSER_HEADER_LAST_E;
            g_flex_transition_db_spc2[i].encap_level = SX_FLEX_PARSER_ENCAP_LAST_E;
        }
    }

    /* De-Initialize the reference count */
    for (flex_header = 0; flex_header < SX_FLEX_PARSER_HEADER_FPP_LAST; flex_header++) {
        sdk_refcount_deinit(&flex_header_db_spc2[flex_header].from_refcount, is_forced);
        sdk_refcount_deinit(&flex_header_db_spc2[flex_header].to_refcount,  is_forced);
        sdk_refcount_deinit(&flex_header_db_spc2[flex_header].fpp_data.ext_refcount,  is_forced);
    }
    for (fixed_header = 0; fixed_header < SX_FLEX_PARSER_HEADER_LAST; fixed_header++) {
        if (g_fixed_header_db_spc2[fixed_header].valid) {
            sdk_refcount_deinit(&g_fixed_header_db_spc2[fixed_header].from_refcount, is_forced);
            sdk_refcount_deinit(&g_fixed_header_db_spc2[fixed_header].to_refcount, is_forced);
        }
    }
    /* Destroy the map from the port to the flex header */
    CL_QPOOL_DESTROY(&(port_root_db_spc2.port_root_pool));
    /* Destroy the transition DB */
    cl_free(g_flex_transition_db_spc2);
    /* Destroy the fixed transition map */
    cl_map_remove_all(&g_fixed_transition_map);
    /* Destroy the fixed transition map */
    cl_map_destroy(&g_fixed_transition_map);

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t hwd_flex_parser_db_vxlan_udp_dport_init()
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    udp_dport_val = INVALID_UDP_PORT;

    SX_LOG_ENTER();

    if (hwd_vxlan_udp_dport_val == INVALID_UDP_PORT) {
        rc = hwd_flex_parser_reg_mprs_udp_dport_get(&udp_dport_val);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to retrieve value from mprs reg [%s].\n", sx_status_str(rc));
            goto out;
        }
        hwd_vxlan_udp_dport_val = udp_dport_val;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_vxlan_udp_dport_get(uint32_t *dport)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (dport == NULL) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hwd db udp dport get failed Null Parameter [%s].\n", sx_status_str(rc));
        goto out;
    }

    *dport = hwd_vxlan_udp_dport_val;
    SX_LOG_DBG(" hwd db vxlan get udp dport value :%u\n", hwd_vxlan_udp_dport_val);

out:
    SX_LOG_EXIT();
    return rc;
}

void hwd_flex_parser_db_vxlan_udp_dport_set(const uint32_t dport)
{
    SX_LOG_ENTER();

    SX_LOG_DBG("hwd vxlan set udp dport value :%u\n", dport);
    hwd_vxlan_udp_dport_val = dport;

    SX_LOG_EXIT();
}

void hwd_flex_parser_db_zero_dev_usr_conf_vxlan_udp_dport_value_set(uint32_t dport)
{
    SX_LOG_ENTER();

    SX_LOG_DBG(" hwd db update vxlan set udp dport usr zero dev conf set :%u\n", dport);
    hwd_zero_dev_usr_conf_vxlan_udp_dport_val = dport;

    SX_LOG_EXIT();
}

sx_status_t hwd_flex_parser_db_zero_dev_usr_conf_vxlan_udp_dport_value_get(uint32_t *dport)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (dport == NULL) {
        SX_LOG_ERR("hwd get vxlan dport usr zero dev conf from DB failed NULL param \n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *dport = hwd_zero_dev_usr_conf_vxlan_udp_dport_val;

    SX_LOG_DBG("hwd vxlan get udp dport usr zero dev conf value :%u\n", hwd_zero_dev_usr_conf_vxlan_udp_dport_val);

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t hwd_flex_parser_db_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    SX_LOG_EXIT();

    return rc;
}

sx_status_t hwd_flex_parser_db_gp_reg_ext_point_init()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    memset(g_gp_reg_ext_point_db, 0, sizeof(g_gp_reg_ext_point_db));

    SX_LOG_EXIT();

    return rc;
}

sx_status_t hwd_flex_parser_db_gp_reg_ext_point_deinit(boolean_t is_forced)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    int         i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < rm_resource_global.gp_register_num_max; i++) {
        if (g_gp_reg_ext_point_db[i].is_ext_point_set) {
            if (is_forced) {
                SX_LOG_INF("Forced deinit extraction point GP register DB: "
                           "register ID %d has extraction point list set.\n", i);
            } else {
                rc = SX_STATUS_DB_NOT_EMPTY;
                SX_LOG_ERR("Failed to deinit flex parser extraction point DB: register ID %d "
                           "has extraction point list set.\n", i);
                goto out;
            }
        }
    }

    memset(g_gp_reg_ext_point_db, 0, sizeof(g_gp_reg_ext_point_db));

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_gp_reg_is_ext_point_set(sx_gp_register_e gp_reg_id, boolean_t *is_ext_point_set)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    CL_ASSERT(is_ext_point_set != NULL);

    if (gp_reg_id >= rm_resource_global.gp_register_num_max) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *is_ext_point_set = g_gp_reg_ext_point_db[gp_reg_id].is_ext_point_set;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_gp_reg_ext_point_set(sx_gp_register_e       gp_reg_id,
                                                    uint32_t               ext_point_cnt,
                                                    sx_extraction_point_t *ext_point_list_p,
                                                    sdk_ref_t             *ref_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    CL_ASSERT(ref_p != NULL);
    CL_ASSERT(ext_point_list_p != NULL);

    if (gp_reg_id >= rm_resource_global.gp_register_num_max) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Reduce reference to old Flex extraction points */
    if (g_gp_reg_ext_point_db[gp_reg_id].is_ext_point_set) {
        for (i = 0; i < g_gp_reg_ext_point_db[gp_reg_id].ext_points_count; i++) {
            if ((g_gp_reg_ext_point_db[gp_reg_id].ext_points_list[i].type == SX_EXTRACTION_POINT_TYPE_FEXP_OUTER_E) ||
                (g_gp_reg_ext_point_db[gp_reg_id].ext_points_list[i].type == SX_EXTRACTION_POINT_TYPE_FEXP_INNER_E)) {
                rc = hwd_flex_parser_db_fexp_ref_dec(
                    g_gp_reg_ext_point_db[gp_reg_id].ext_points_list[i].attr.fexp_attr.fexp_id.fexp_id);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed decreasing reference for FEXP [%u]\n",
                               g_gp_reg_ext_point_db[gp_reg_id].ext_points_list[i].attr.fexp_attr.fexp_id.fexp_id);
                    rc = SX_STATUS_ERROR;
                    goto out;
                }
            }
        }
    }

    g_gp_reg_ext_point_db[gp_reg_id].ext_points_count = ext_point_cnt;
    if (ext_point_cnt > 0) {
        g_gp_reg_ext_point_db[gp_reg_id].gp_reg_id = gp_reg_id;
        g_gp_reg_ext_point_db[gp_reg_id].is_ext_point_set = TRUE;
        SX_MEM_CPY_ARRAY(g_gp_reg_ext_point_db[gp_reg_id].ext_points_list,
                         ext_point_list_p,
                         ext_point_cnt,
                         sx_extraction_point_t);
        g_gp_reg_ext_point_db[gp_reg_id].reference = *ref_p;

        /* Increase reference to new Flex extraction points */
        if (g_gp_reg_ext_point_db[gp_reg_id].is_ext_point_set) {
            for (i = 0; i < g_gp_reg_ext_point_db[gp_reg_id].ext_points_count; i++) {
                if ((g_gp_reg_ext_point_db[gp_reg_id].ext_points_list[i].type ==
                     SX_EXTRACTION_POINT_TYPE_FEXP_OUTER_E) ||
                    (g_gp_reg_ext_point_db[gp_reg_id].ext_points_list[i].type ==
                     SX_EXTRACTION_POINT_TYPE_FEXP_INNER_E)) {
                    rc = hwd_flex_parser_db_fexp_ref_inc(
                        g_gp_reg_ext_point_db[gp_reg_id].ext_points_list[i].attr.fexp_attr.fexp_id.fexp_id);
                    if (SX_CHECK_FAIL(rc)) {
                        SX_LOG_ERR("Failed increasing reference for FEXP [%u]\n",
                                   g_gp_reg_ext_point_db[gp_reg_id].ext_points_list[i].attr.fexp_attr.fexp_id.fexp_id);
                        rc = SX_STATUS_ERROR;
                        goto out;
                    }
                }
            }
        }
    } else {
        g_gp_reg_ext_point_db[gp_reg_id].gp_reg_id = SX_GP_REGISTER_LAST_E;
        g_gp_reg_ext_point_db[gp_reg_id].is_ext_point_set = FALSE;
        memset(g_gp_reg_ext_point_db[gp_reg_id].ext_points_list, 0,
               sizeof(g_gp_reg_ext_point_db[gp_reg_id].ext_points_list));
        *ref_p = g_gp_reg_ext_point_db[gp_reg_id].reference;
        g_gp_reg_ext_point_db[gp_reg_id].reference = 0;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_gp_reg_ext_point_get(sx_gp_register_e       gp_reg_id,
                                                    uint32_t              *ext_point_cnt_p,
                                                    sx_extraction_point_t *ext_point_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    cnt = 0, i = 0;

    SX_LOG_ENTER();

    CL_ASSERT(ext_point_cnt_p != NULL);

    if (gp_reg_id >= rm_resource_global.gp_register_num_max) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (ext_point_list_p == NULL) {
        *ext_point_cnt_p = g_gp_reg_ext_point_db[gp_reg_id].ext_points_count;
    } else {
        cnt = MIN(*ext_point_cnt_p, g_gp_reg_ext_point_db[gp_reg_id].ext_points_count);
        for (i = 0; i < cnt; i++) {
            ext_point_list_p[i] = g_gp_reg_ext_point_db[gp_reg_id].ext_points_list[i];
        }
        *ext_point_cnt_p = cnt;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_gp_reg_ext_point_foreach(hwd_flex_parser_gp_reg_ext_point_db_pfn_t func, void *param_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < rm_resource_global.gp_register_num_max; i++) {
        if (g_gp_reg_ext_point_db[i].is_ext_point_set == TRUE) {
            rc = func(&g_gp_reg_ext_point_db[i], param_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to apply function on GP register %d, error: [%s]\n",
                           i, sx_status_str(rc));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}
/* Get a transitions from a hw header to hw header.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_fixed_transition_get(const sx_flex_parser_header_fixed_e from,
                                                    const sx_flex_parser_header_fixed_e to,
                                                    const sx_flex_parser_encap_level_e  encap_level,
                                                    uint32_t                            transition_value,
                                                    fixed_transition_db_entry_t       **fixed_entry_pp)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    uint64_t                     key = 0;
    fixed_transition_db_entry_t *entry_p = NULL;


    SX_LOG_ENTER();

    key = __create_fixed_transition_key(from, to, encap_level, transition_value);
    entry_p = (fixed_transition_db_entry_t*)cl_map_get(&(g_fixed_transition_map), key);

    if (entry_p != (fixed_transition_db_entry_t*)cl_map_end(&(g_fixed_transition_map))) {
        *fixed_entry_pp = entry_p;
    } else {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
    }

    SX_LOG_EXIT();
    return rc;
}

/* Iterate over all the entries in the fixed headers DB and call the callback function */
sx_status_t hwd_flex_parser_db_fixed_transition_foreach(hwd_flex_parser_fixed_transition_db_pfn_t func, void *param_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < g_fixed_transition_db_size; i++) {
        rc = func(&g_fixed_transition_db_spc2[i], param_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed transition foreach callback.\n");
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* Allocate a flex transition - the unique key for this db is from + transition value.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_flex_transition_allocate(const sx_flex_parser_header_t from,
                                                        const uint32_t                transition_value,
                                                        const uint8_t                 transition_index,
                                                        const boolean_t               allocate_by_transition_index,
                                                        flex_transition_db_entry_t  **flex_entry_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint8_t     i = 0;
    uint8_t     new_transition_index = 0;

    SX_LOG_ENTER();

    if (allocate_by_transition_index == TRUE) {
        new_transition_index = transition_index;
        if (g_flex_transition_db_spc2[new_transition_index].valid == FALSE) {
            g_flex_transition_db_spc2[new_transition_index].in_use = FALSE;
        } else {
            rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
            goto out;
        }
    } else {
        /* Make sure this entry is not already in the DB */
        if (hwd_flex_parser_db_flex_transition_get(from, transition_value, NULL) != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("Failed allocating transition. Entry already exists.\n");
            rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
            goto out;
        }
        /* Go over all the flex transitions and check if one is available */
        for (i = 0; i < MAX_HW_FLEX_TRANSITIONS; i++) {
            if (!g_flex_transition_db_spc2[i].valid) {
                new_transition_index = i;
                g_flex_transition_db_spc2[new_transition_index].in_use = TRUE;
                break;
            }
        }
        if (i == MAX_HW_FLEX_TRANSITIONS) {
            rc = SX_STATUS_NO_RESOURCES;
            goto out;
        }
    }

    g_flex_transition_db_spc2[new_transition_index].valid = TRUE;
    g_flex_transition_db_spc2[new_transition_index].from = from;
    g_flex_transition_db_spc2[new_transition_index].transition_value = transition_value;
    *flex_entry_pp = &g_flex_transition_db_spc2[new_transition_index];

out:
    SX_LOG_EXIT();
    return rc;
}

/* Deallocate a flex transition - the unique key for this db is from + transition value.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_flex_transition_deallocate(const sx_flex_parser_header_t from,
                                                          const uint32_t                transition_value,
                                                          const uint8_t                 transition_index,
                                                          const boolean_t               deallocate_by_transition_index)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    flex_transition_db_entry_t *flex_entry_p = NULL;

    SX_LOG_ENTER();
    if (deallocate_by_transition_index == FALSE) {
        /* Make sure this entry exists in the DB */
        rc = hwd_flex_parser_db_flex_transition_get(from, transition_value, &flex_entry_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed deallocating transition. Entry does not exist.\n");
            goto out;
        }
    } else {
        flex_entry_p = &g_flex_transition_db_spc2[transition_index];
        /* check that resource is in use*/
        if (flex_entry_p->valid == FALSE) {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
    }
    /* Invalidate the entry (only the valid is necessary but we invalidate all) */
    flex_entry_p->valid = FALSE;
    flex_entry_p->in_use = FALSE;
    flex_entry_p->transition_value = 0;
    flex_entry_p->from.parser_hdr_type = SX_FLEX_PARSER_HEADER_LAST_E;
    flex_entry_p->to.parser_hdr_type = SX_FLEX_PARSER_HEADER_LAST_E;
    flex_entry_p->encap_level = SX_FLEX_PARSER_ENCAP_LAST_E;

out:
    SX_LOG_EXIT();
    return rc;
}
/* Get a flex transition - the unique key for this db is the transition index.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_flex_transition_index_get(const uint8_t                transition_index,
                                                         flex_transition_db_entry_t **flex_entry_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (flex_entry_pp != NULL) {
        *flex_entry_pp = &g_flex_transition_db_spc2[transition_index];
    }

    SX_LOG_EXIT();
    return rc;
}

/* Get a flex transition - the unique key for this db is from + transition value.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_flex_transition_get(const sx_flex_parser_header_t from,
                                                   const uint32_t                transition_value,
                                                   flex_transition_db_entry_t  **flex_entry_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    /* Go over all the flex transitions and check if we have one like the required */
    for (i = 0; i < MAX_HW_FLEX_TRANSITIONS; i++) {
        if (g_flex_transition_db_spc2[i].valid &&
            g_flex_transition_db_spc2[i].in_use &&
            __compare_parser_header(&from, &g_flex_transition_db_spc2[i].from) &&
            (transition_value == g_flex_transition_db_spc2[i].transition_value)) {
            if (flex_entry_pp != NULL) {
                *flex_entry_pp = &g_flex_transition_db_spc2[i];
            }
            goto out;
        }
    }
    rc = SX_STATUS_ENTRY_NOT_FOUND;

out:
    SX_LOG_EXIT();
    return rc;
}

/* Iterate over all the entries in the fixed headers DB and call the callback function */
sx_status_t hwd_flex_parser_db_flex_transition_foreach(hwd_flex_parser_flex_transition_db_pfn_t func, void *param_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < MAX_HW_FLEX_TRANSITIONS; i++) {
        if (g_flex_transition_db_spc2[i].valid && g_flex_transition_db_spc2[i].in_use) {
            rc = func(&g_flex_transition_db_spc2[i], param_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed flex transition foreach callback.\n");
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* Get the transitions from a specific header.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_transitions_get(const sx_flex_parser_header_t curr_ph,
                                               sx_flex_parser_transition_t  *next_trans_p,
                                               uint32_t                     *next_trans_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    uint32_t    trans_cnt = 0, max_cnt = UINT32_MAX;
    boolean_t   copy_transition = FALSE;

    SX_LOG_ENTER();

    /* Check if we're actually going to copy transitions and not only count them */
    if (*next_trans_cnt_p != 0) {
        copy_transition = TRUE;
        max_cnt = *next_trans_cnt_p;
    }

    /* Retrieve the fixed to fixed transitions */
    if (curr_ph.parser_hdr_type == SX_FLEX_PARSER_HEADER_FIXED_E) {
        /* Go over all the possible fixed transition from this header and collect all those that are valid/exist */
        for (i = 0; i < g_fixed_transition_db_size && trans_cnt < max_cnt; i++) {
            if ((g_fixed_transition_db_spc2[i].from == curr_ph.hdr_data.parser_hdr_fixed) &&
                g_fixed_transition_db_spc2[i].enabled) {
                if (copy_transition) {
                    /* Copy the transition info */
                    next_trans_p[trans_cnt].next_parser_hdr.parser_hdr_type = SX_FLEX_PARSER_HEADER_FIXED_E;
                    next_trans_p[trans_cnt].next_parser_hdr.hdr_data.parser_hdr_fixed =
                        g_fixed_transition_db_spc2[i].to;
                    next_trans_p[trans_cnt].current_encap = g_fixed_transition_db_spc2[i].curr_encap_level;
                    next_trans_p[trans_cnt].encap_level = g_fixed_transition_db_spc2[i].next_encap_level;
                    next_trans_p[trans_cnt].transition_value = g_fixed_transition_db_spc2[i].transition_value;
                }
                trans_cnt++;
            }
        }
    }
    /* Retrieve the flex transitions */
    for (i = 0; i < MAX_HW_FLEX_TRANSITIONS && trans_cnt < max_cnt; i++) {
        if (g_flex_transition_db_spc2[i].valid &&
            g_flex_transition_db_spc2[i].in_use &&
            __compare_parser_header(&curr_ph, &g_flex_transition_db_spc2[i].from)) {
            if (copy_transition) {
                /* Copy the transition info */
                next_trans_p[trans_cnt].next_parser_hdr = g_flex_transition_db_spc2[i].to;
                next_trans_p[trans_cnt].encap_level = g_flex_transition_db_spc2[i].encap_level;
                next_trans_p[trans_cnt].transition_value = g_flex_transition_db_spc2[i].transition_value;
            }
            trans_cnt++;
        }
    }
    /* Return the actual number of transactions retrieved */
    *next_trans_cnt_p = trans_cnt;

    SX_LOG_EXIT();
    return rc;
}

/* Get the number of transitions used */
sx_status_t hwd_flex_parser_db_transitions_count(uint32_t *transitions_count_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0, count = 0;

    for (i = 0; i < MAX_HW_FLEX_TRANSITIONS; i++) {
        if (g_flex_transition_db_spc2[i].valid && g_flex_transition_db_spc2[i].in_use) {
            count++;
        }
    }
    *transitions_count_p = count;

    SX_LOG_EXIT();
    return rc;
}


/* Get a fixed header information from the DB.
 * NOTE: It is assumed the caller function validates all the parameters*/
sx_status_t hwd_flex_parser_db_fixed_header_get(const sx_flex_parser_header_fixed_e fixed_header,
                                                header_db_entry_t                 **fixed_header_entry_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    /* Do a validation on the fixed header numbers */
    if (fixed_header >= SX_FLEX_PARSER_HEADER_LAST) {
        SX_LOG_ERR("Invalid value for fixed parse header [%u] get.\n", fixed_header);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (!g_fixed_header_db_spc2[fixed_header].valid) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    if (fixed_header_entry_pp != NULL) {
        *fixed_header_entry_pp = &g_fixed_header_db_spc2[fixed_header];
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* Iterate over all the entries in the fixed headers DB and call the callback function */
sx_status_t hwd_flex_parser_db_fixed_header_foreach(hwd_flex_parser_header_db_pfn_t func, void *param_p)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    sx_flex_parser_header_fixed_e fixed_header = 0;

    SX_LOG_ENTER();

    for (fixed_header = 0; fixed_header < SX_FLEX_PARSER_HEADER_LAST; fixed_header++) {
        if (g_fixed_header_db_spc2[fixed_header].valid) {
            rc = func(&g_fixed_header_db_spc2[fixed_header], param_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed fixed header foreach callback.\n");
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


/* Get a flex header information from the DB. */
sx_status_t hwd_flex_parser_db_flex_header_get(const sx_flex_parser_header_fpp_e fpp,
                                               header_db_entry_t               **flex_header_entry_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Do a validation on the flex header numbers */
    if (fpp >= SX_FLEX_PARSER_HEADER_FPP_LAST) {
        SX_LOG_ERR("Invalid value for flex parse header [%u] get.\n", fpp);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (flex_header_entry_pp != NULL) {
        *flex_header_entry_pp = &flex_header_db_spc2[fpp];
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* Get the number of flex headers used */
sx_status_t hwd_flex_parser_db_flex_header_count(uint32_t *flex_header_count_p)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_flex_parser_header_fpp_e fpp = 0;
    uint32_t                    count = 0;

    SX_LOG_ENTER();

    for (fpp = 0; fpp < SX_FLEX_PARSER_HEADER_FPP_LAST; fpp++) {
        if (flex_header_db_spc2[fpp].valid) {
            count++;
        }
    }
    *flex_header_count_p = count;

    SX_LOG_EXIT();
    return rc;
}


/* Iterate over all the entries in the fixed headers DB and call the callback function */
sx_status_t hwd_flex_parser_db_flex_header_foreach(hwd_flex_parser_header_db_pfn_t func, void *param_p)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_flex_parser_header_fpp_e fpp = 0;

    SX_LOG_ENTER();

    for (fpp = 0; fpp < SX_FLEX_PARSER_HEADER_FPP_LAST; fpp++) {
        if (flex_header_db_spc2[fpp].valid) {
            rc = func(&flex_header_db_spc2[fpp], param_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed FPP foreach callback.\n");
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


/* Get a fixed/flex header information from the DB. */
sx_status_t hwd_flex_parser_db_header_get(const sx_flex_parser_header_t header,
                                          header_db_entry_t           **flex_header_entry_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (header.parser_hdr_type) {
    case SX_FLEX_PARSER_HEADER_FIXED_E:
        rc = hwd_flex_parser_db_fixed_header_get(header.hdr_data.parser_hdr_fixed, flex_header_entry_pp);
        break;

    case SX_FLEX_PARSER_HEADER_FPP_E:
        rc = hwd_flex_parser_db_flex_header_get(header.hdr_data.parser_hdr_fpp, flex_header_entry_pp);
        break;

    default:
        SX_LOG_ERR("Invalid value for parse header type [%u].\n", header.parser_hdr_type);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
        break;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* Set some of the flex header fields into the DB. Extraction point info is set via a separate function. */
sx_status_t hwd_flex_parser_db_flex_header_set(const sx_flex_parser_header_fpp_e fpp,
                                               const sx_flex_parser_fpp_t       *fpp_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Do a validation on the flex header numbers */
    if (fpp >= SX_FLEX_PARSER_HEADER_FPP_LAST) {
        SX_LOG_ERR("Invalid value for flex parse header [%u] invalidate.\n", fpp);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    /* Set the fields in the DB */
    flex_header_db_spc2[fpp].valid = TRUE;
    SX_MEM_CPY_P(&flex_header_db_spc2[fpp].fpp_data.fpp_cfg, fpp_cfg_p);

out:
    SX_LOG_EXIT();
    return rc;
}

/* Invalidate a flex header entry in the DB */
sx_status_t hwd_flex_parser_db_flex_header_invalidate(const sx_flex_parser_header_fpp_e fpp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Do a validation on the flex header numbers */
    if (fpp >= SX_FLEX_PARSER_HEADER_FPP_LAST) {
        SX_LOG_ERR("Invalid value for flex parse header [%u] invalidate.\n", fpp);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    /* We only need to set the valid to false - but we clear other fields just to be nice */
    flex_header_db_spc2[fpp].valid = FALSE;
    SX_MEM_CLR(flex_header_db_spc2[fpp].fpp_data.fpp_cfg);

out:
    SX_LOG_EXIT();
    return rc;
}

/* Increase a reference count to flex extraction point. */
sx_status_t hwd_flex_parser_db_fexp_ref_inc(const sx_flex_parser_fexp_e fexp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Do a validation on the flex header numbers */
    if (fexp >= SX_FLEX_PARSER_FEXP_LAST) {
        SX_LOG_ERR("Invalid value for FEXP [%u] reference increase.\n", fexp);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (!flex_extraction_point_db_spc2[fexp].valid) {
        SX_LOG_ERR("FEXP [%u] not initialized for reference increase.\n", fexp);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    flex_extraction_point_db_spc2[fexp].refcount++;

out:
    SX_LOG_EXIT();
    return rc;
}

/* Decrease a reference count to flex extraction point. */
sx_status_t hwd_flex_parser_db_fexp_ref_dec(const sx_flex_parser_fexp_e fexp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Do a validation on the flex header numbers */
    if (fexp >= SX_FLEX_PARSER_FEXP_LAST) {
        SX_LOG_ERR("Invalid value for FEXP [%u] reference decrease.\n", fexp);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (!flex_extraction_point_db_spc2[fexp].valid) {
        SX_LOG_ERR("FEXP [%u] not initialized for reference decrease.\n", fexp);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    if (flex_extraction_point_db_spc2[fexp].refcount == 0) {
        SX_LOG_ERR("FEXP [%u] reference is zero and cannot be decreased.\n", fexp);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    flex_extraction_point_db_spc2[fexp].refcount--;

out:
    SX_LOG_EXIT();
    return rc;
}

/* Get the flex extraction point info from the DB. */
sx_status_t hwd_flex_parser_db_fexp_get(const sx_flex_parser_fexp_e fexp, fexp_db_entry_t           **fexp_db_entry_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Do a validation on the flex header numbers */
    if (fexp >= SX_FLEX_PARSER_FEXP_LAST) {
        SX_LOG_ERR("Invalid value for FEXP [%u] for get.\n", fexp);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (fexp_db_entry_pp != NULL) {
        *fexp_db_entry_pp = &flex_extraction_point_db_spc2[fexp];
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_fexp_count(uint32_t *fexp_count_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    uint32_t              count = 0;
    sx_flex_parser_fexp_e fexp = 0;


    SX_LOG_ENTER();

    for (fexp = 0; fexp < SX_FLEX_PARSER_FEXP_LAST; fexp++) {
        if (flex_extraction_point_db_spc2[fexp].valid) {
            count++;
        }
    }
    *fexp_count_p = count;

    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_port_root_add(const sx_port_log_id_t            log_port,
                                             const boolean_t                   reuse,
                                             flex_parser_db_port_root_item_t **port_root_item_pp)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    cl_map_item_t       *map_item_p = NULL;
    const cl_map_item_t *map_end_p = NULL;
    cl_pool_item_t      *pool_item_p = NULL;


    SX_LOG_ENTER();

    /* Find out if this port is already mapped */
    map_item_p = cl_qmap_get(&(port_root_db_spc2.port_root_map), log_port);
    map_end_p = cl_qmap_end(&(port_root_db_spc2.port_root_map));

    if (map_item_p != map_end_p) {  /* Entry already exists */
        if (!reuse) {
            SX_LOG_ERR("Flex parser logical port [0x%x] already attached to root header.\n", log_port);
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        } else {
            /* Return the item */
            *port_root_item_pp = PARENT_STRUCT(map_item_p, flex_parser_db_port_root_item_t, map_item);
        }
    } else {
        /* allocate a new entry in the DB for this port */
        pool_item_p = cl_qpool_get(&(port_root_db_spc2.port_root_pool));
        if (pool_item_p == NULL) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to add flex parser port root DB entry, rc=[%s]\n", sx_status_str(rc));
            goto out;
        }
        *port_root_item_pp = PARENT_STRUCT(pool_item_p, flex_parser_db_port_root_item_t, pool_item);
        cl_qmap_insert(&(port_root_db_spc2.port_root_map), log_port, &((*port_root_item_pp)->map_item));
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_port_root_delete(const sx_port_log_id_t log_port)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_parser_db_port_root_item_t *port_root_item_p = NULL;

    SX_LOG_ENTER();

    rc = hwd_flex_parser_db_port_root_get(log_port, &port_root_item_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex parser logical port [0x%x] root header cannot be deleted.\n", log_port);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    cl_qmap_remove_item(&(port_root_db_spc2.port_root_map), &(port_root_item_p->map_item));
    cl_qpool_put(&(port_root_db_spc2.port_root_pool), &(port_root_item_p->pool_item));

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_port_root_get(const sx_port_log_id_t            log_port,
                                             flex_parser_db_port_root_item_t **port_root_item_pp)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    cl_map_item_t       *map_item_p = NULL;
    const cl_map_item_t *map_end_p = NULL;

    SX_LOG_ENTER();

    /* Find out if this port is already mapped */
    map_item_p = cl_qmap_get(&(port_root_db_spc2.port_root_map), log_port);
    map_end_p = cl_qmap_end(&(port_root_db_spc2.port_root_map));

    if (map_item_p == map_end_p) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    if (port_root_item_pp != NULL) {
        *port_root_item_pp = PARENT_STRUCT(map_item_p, flex_parser_db_port_root_item_t, map_item);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_db_port_root_get_next(const sx_port_log_id_t            log_port,
                                                  flex_parser_db_port_root_item_t **port_root_item_pp)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    cl_map_item_t       *map_item_p = NULL;
    const cl_map_item_t *map_end_p = NULL;

    SX_LOG_ENTER();

    /* Find out if this port is already mapped */
    map_item_p = cl_qmap_get_next(&(port_root_db_spc2.port_root_map), log_port);
    map_end_p = cl_qmap_end(&(port_root_db_spc2.port_root_map));

    if (map_item_p == map_end_p) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    *port_root_item_pp = PARENT_STRUCT(map_item_p, flex_parser_db_port_root_item_t, map_item);

out:
    SX_LOG_EXIT();
    return rc;
}

/* Iterate over all the entries in the port root DB and call the callback function */
sx_status_t hwd_flex_parser_db_port_root_foreach(hwd_flex_parser_port_root_db_pfn_t func, void *param_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    cl_map_item_t                   *map_item_p = NULL;
    const cl_map_item_t             *map_end_p = NULL;
    flex_parser_db_port_root_item_t *port_root_item_p = NULL;

    SX_LOG_ENTER();

    /* Find out if this port is already mapped */
    map_item_p = cl_qmap_head(&(port_root_db_spc2.port_root_map));
    map_end_p = cl_qmap_end(&(port_root_db_spc2.port_root_map));

    while (map_item_p != map_end_p) {
        port_root_item_p = PARENT_STRUCT(map_item_p, flex_parser_db_port_root_item_t, map_item);
        rc = func(port_root_item_p, param_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed port root foreach callback.\n");
            goto out;
        }
        map_item_p = cl_qmap_next(map_item_p);
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t hwd_flex_parser_db_port_root_count(uint32_t *port_count_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    *port_count_p = cl_qmap_count(&(port_root_db_spc2.port_root_map));

    SX_LOG_EXIT();
    return rc;
}


void hwd_flex_parser_db_gp_reg_ext_point_dump(dbg_dump_params_t *dbg_dump_params_p, sx_gp_register_e gp_reg_id)
{
    sx_gp_register_e          first_reg_id = 0, last_reg_id = 0;
    sx_gp_register_e          reg_id = 0;
    char                      fexp_id[8];
    uint8_t                   i = 0;
    dbg_utils_table_columns_t gp_reg_ext_point_dump_clmns[] = {
        { "Ext point #",     12,    PARAM_UINT8_E,        &i},
        { "Type",            35,    PARAM_STRING_E,       NULL},
        { "Offset",          15,    PARAM_UINT32_E,       NULL},
        { "Fexp id",         12,    PARAM_STRING_E,       &fexp_id},
        {NULL, 0, 0, NULL}
    };
    FILE                     *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    if (gp_reg_id >= rm_resource_global.gp_register_num_max) {
        first_reg_id = 0;
        last_reg_id = rm_resource_global.gp_register_num_max;
        dbg_utils_pprinter_general_header_print(stream, "Flex parser extraction point Dump");
    } else {
        first_reg_id = gp_reg_id;
        last_reg_id = gp_reg_id + 1;
    }

    for (reg_id = first_reg_id; reg_id < last_reg_id; reg_id++) {
        if (g_gp_reg_ext_point_db[reg_id].is_ext_point_set) {
            dbg_utils_pprinter_secondary_header_print(stream, "Extraction point dump for GP Register [%d]", reg_id);
            dbg_utils_pprinter_table_headline_print(stream, gp_reg_ext_point_dump_clmns);
            for (i = 0; i < g_gp_reg_ext_point_db[reg_id].ext_points_count; i++) {
                gp_reg_ext_point_dump_clmns[1].data = sx_extraction_point_type_str(
                    g_gp_reg_ext_point_db[reg_id].ext_points_list[i].type);
                gp_reg_ext_point_dump_clmns[2].data = &g_gp_reg_ext_point_db[reg_id].ext_points_list[i].offset;
                if ((g_gp_reg_ext_point_db[reg_id].ext_points_list[i].type == SX_EXTRACTION_POINT_TYPE_FEXP_OUTER_E) ||
                    (g_gp_reg_ext_point_db[reg_id].ext_points_list[i].type == SX_EXTRACTION_POINT_TYPE_FEXP_INNER_E)) {
                    snprintf(fexp_id, sizeof(fexp_id), "FEXP%u",
                             g_gp_reg_ext_point_db[reg_id].ext_points_list[i].attr.fexp_attr.fexp_id.fexp_id);
                } else {
                    snprintf(fexp_id, sizeof(fexp_id), "N/A");
                }
                dbg_utils_pprinter_table_data_line_print(stream, gp_reg_ext_point_dump_clmns);
            }
        } else if (gp_reg_id < rm_resource_global.gp_register_num_max) {
            dbg_utils_pprinter_print(stream, "No extraction point for GP Register [%d]\n", gp_reg_id);
        }
    }

out:
    SX_LOG_EXIT();
    return;
}


void hwd_flex_parser_headers_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    int                       from_ref_count = 0, to_ref_count = 0;
    sx_utils_status_t         utils_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t                  i = 0;
    boolean_t                 is_first = TRUE;
    boolean_t                 is_tlv = FALSE;
    boolean_t                 is_empty = FALSE;
    int                       len_const = 0, len_shift = 0;
    FILE                     *stream = NULL;
    char                      start_exp[8];
    char                      offset_exp[8];
    char                      tlv_offset[8];
    dbg_utils_table_columns_t fixed_parser_header_table_dump_clmns[] = {
        { "Header",           19,    PARAM_STRING_E,       NULL},
        { "TLV",              14,    PARAM_STRING_E,       NULL},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t flex_parser_header_table_dump_clmns[] = {
        { "Header",           14,    PARAM_STRING_E,       NULL},
        { "Is TLV",           6,     PARAM_BOOL_E,         &is_tlv},
        { "Is Empty",         8,     PARAM_BOOL_E,         &is_empty},
        { "From Ref Cnt",     12,    PARAM_INT_E,          &from_ref_count},
        { "To Ref Cnt",       10,    PARAM_INT_E,          &to_ref_count},
        { "Hdr offset",       10,    PARAM_UINT8_E,        NULL},
        { "Hdr size",         8,     PARAM_UINT8_E,        NULL},
        { "Hdr mask",         8,     PARAM_HEX16_E,        NULL},
        { "Len offset",       10,    PARAM_UINT8_E,        NULL},
        { "Len size",         8,     PARAM_UINT8_E,        NULL},
        { "Len mask",         8,     PARAM_HEX16_E,        NULL},
        { "Len const",        9,     PARAM_INT_E,          &len_const},
        { "Len shift",        9,     PARAM_INT_E,          &len_shift},
        { "Extract Start",    14,    PARAM_STRING_E,       &start_exp},
        { "Extract Offset",   14,    PARAM_STRING_E,       &offset_exp},
        { "TLV Offset",       10,    PARAM_STRING_E,       &tlv_offset},
        {NULL, 0, 0, NULL}
    };

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Flex Parser Headers");

    dbg_utils_pprinter_secondary_header_print(stream, "Fixed headers");

    is_first = TRUE;
    for (i = 0; i < SX_FLEX_PARSER_HEADER_LAST; i++) {
        if (is_first) {
            dbg_utils_pprinter_table_headline_print(stream, fixed_parser_header_table_dump_clmns);
            is_first = FALSE;
        }

        fixed_parser_header_table_dump_clmns[0].data = sx_flex_parser_header_fixed_str(i);
        fixed_parser_header_table_dump_clmns[1].data =
            (g_fixed_header_db_spc2[i].fixed_data.hph_cfg.ftlv_mode != SX_FLEX_PARSER_TLV_PARSING_DISABLED) ?
            sx_flex_parser_header_fpp_str(
                g_fixed_header_db_spc2[i].fixed_data.hph_cfg.ftlv_id.fpp_id) : "None";
        dbg_utils_pprinter_table_data_line_print(stream, fixed_parser_header_table_dump_clmns);
    }

    dbg_utils_pprinter_secondary_header_print(stream, "FPP headers");

    is_first = TRUE;
    for (i = 0; i < SX_FLEX_PARSER_HEADER_FPP_LAST; i++) {
        if (flex_header_db_spc2[i].valid) {
            if (is_first) {
                dbg_utils_pprinter_table_headline_print(stream, flex_parser_header_table_dump_clmns);
                is_first = FALSE;
            }

            flex_parser_header_table_dump_clmns[0].data = sx_flex_parser_header_fpp_str(
                flex_header_db_spc2[i].hdr.hdr_data.parser_hdr_fpp);
            is_tlv = (flex_header_db_spc2[i].fpp_data.fpp_cfg.type == SX_FLEX_PARSER_FPP_TYPE_FTLV) ? TRUE : FALSE;
            is_empty =
                (flex_header_db_spc2[i].fpp_data.fpp_cfg.type == SX_FLEX_PARSER_FPP_TYPE_FPH_EMPTY) ? TRUE : FALSE;
            utils_err = sdk_refcount_get(&flex_header_db_spc2[i].from_refcount, &from_ref_count);
            if (utils_err != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get ref_cnt (err: %s)\n", SX_UTILS_STATUS_MSG(utils_err));
                goto out;
            }
            utils_err = sdk_refcount_get(&flex_header_db_spc2[i].to_refcount, &to_ref_count);
            if (utils_err != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get ref_cnt (err: %s)\n", SX_UTILS_STATUS_MSG(utils_err));
                goto out;
            }

            /* Dump the next header field */
            flex_parser_header_table_dump_clmns[5].data =
                &flex_header_db_spc2[i].fpp_data.fpp_cfg.protocol_field.offset;
            flex_parser_header_table_dump_clmns[6].data = &flex_header_db_spc2[i].fpp_data.fpp_cfg.protocol_field.size;
            flex_parser_header_table_dump_clmns[7].data = &flex_header_db_spc2[i].fpp_data.fpp_cfg.protocol_field.mask;
            /* Dump the header length field */
            flex_parser_header_table_dump_clmns[8].data =
                &flex_header_db_spc2[i].fpp_data.fpp_cfg.hdr_len_field.offset;
            flex_parser_header_table_dump_clmns[9].data = &flex_header_db_spc2[i].fpp_data.fpp_cfg.hdr_len_field.size;
            flex_parser_header_table_dump_clmns[10].data = &flex_header_db_spc2[i].fpp_data.fpp_cfg.hdr_len_field.mask;
            len_const = flex_header_db_spc2[i].fpp_data.fpp_cfg.hdr_len_field.constant;
            len_shift = flex_header_db_spc2[i].fpp_data.fpp_cfg.hdr_len_field.shift;

            /* Dump the extraction points */
            if (flex_header_db_spc2[i].fpp_data.fpp_cfg.fexp_start.enable) {
                snprintf(start_exp,
                         sizeof(start_exp),
                         "FEXP%u",
                         flex_header_db_spc2[i].fpp_data.fpp_cfg.fexp_start.fexp_id.fexp_id);
            } else {
                snprintf(start_exp, sizeof(start_exp), "NA");
            }
            if (flex_header_db_spc2[i].fpp_data.fpp_cfg.fexp_offset.enable) {
                snprintf(offset_exp,
                         sizeof(offset_exp),
                         "FEXP%u",
                         flex_header_db_spc2[i].fpp_data.fpp_cfg.fexp_offset.fexp_id.fexp_id);
            } else {
                snprintf(offset_exp, sizeof(offset_exp), "NA");
            }
            if (flex_header_db_spc2[i].fpp_data.fpp_cfg.my_tlv.enable) {
                snprintf(tlv_offset,
                         sizeof(tlv_offset),
                         "%u",
                         flex_header_db_spc2[i].fpp_data.fpp_cfg.my_tlv.tlv_start_offset);
            } else {
                snprintf(tlv_offset, sizeof(offset_exp), "NA");
            }
            dbg_utils_pprinter_table_data_line_print(stream, flex_parser_header_table_dump_clmns);
        }
    }

out:
    SX_LOG_EXIT();
    return;
}

void hwd_flex_parser_transitions_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    uint32_t                  transition_value = 0;
    boolean_t                 enabled = FALSE;
    boolean_t                 is_first = TRUE;
    boolean_t                 inner = FALSE;
    uint32_t                  i = 0;
    dbg_utils_table_columns_t flex_parser_hard_table_dump_clmns[] = {
        { "Header",           12,    PARAM_STRING_E,       NULL},
        { "Value",            7,     PARAM_UINT32_E,       &transition_value},
        { "Next Header",      12,    PARAM_STRING_E,       NULL},
        { "Curr Encap",       12,    PARAM_STRING_E,       NULL},
        { "Next Encap",       12,    PARAM_STRING_E,       NULL},
        { "Enabled",          15,    PARAM_BOOL_E,         &enabled},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t flex_parser_flex_table_dump_clmns[] = {
        { "Flex Transition",  15,    PARAM_UINT32_E,       &i},
        { "Header",           12,    PARAM_STRING_E,       NULL},
        { "Value",            7,     PARAM_UINT32_E,       &transition_value},
        { "Next Header",      14,    PARAM_STRING_E,       NULL},
        { "Next Inner",       15,    PARAM_BOOL_E,         &inner},
        {NULL, 0, 0, NULL}
    };
    FILE                     *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Flex parser transition tables");

    for (i = 0; i < g_fixed_transition_db_size; i++) {
        if (is_first) {
            dbg_utils_pprinter_secondary_header_print(stream, "Flex parser fixed transition table");
            dbg_utils_pprinter_table_headline_print(stream, flex_parser_hard_table_dump_clmns);
            is_first = FALSE;
        }
        flex_parser_hard_table_dump_clmns[0].data =
            sx_flex_parser_header_fixed_str(g_fixed_transition_db_spc2[i].from);
        flex_parser_hard_table_dump_clmns[2].data =
            sx_flex_parser_header_fixed_str(g_fixed_transition_db_spc2[i].to);
        transition_value = g_fixed_transition_db_spc2[i].transition_value;
        flex_parser_hard_table_dump_clmns[3].data = sx_flex_parser_encap_level_str(
            g_fixed_transition_db_spc2[i].curr_encap_level);
        flex_parser_hard_table_dump_clmns[4].data = sx_flex_parser_encap_level_str(
            g_fixed_transition_db_spc2[i].next_encap_level);
        enabled = g_fixed_transition_db_spc2[i].enabled;
        dbg_utils_pprinter_table_data_line_print(stream, flex_parser_hard_table_dump_clmns);
    }

    is_first = TRUE;

    for (i = 0; i < MAX_HW_FLEX_TRANSITIONS; i++) {
        if (g_flex_transition_db_spc2[i].valid && g_flex_transition_db_spc2[i].in_use) {
            if (is_first) {
                dbg_utils_pprinter_secondary_header_print(stream, "Flex parser flex transition table");
                dbg_utils_pprinter_table_headline_print(stream, flex_parser_flex_table_dump_clmns);
                is_first = FALSE;
            }
            flex_parser_flex_table_dump_clmns[1].data =
                get_flex_parser_header_string(&g_flex_transition_db_spc2[i].from);
            flex_parser_flex_table_dump_clmns[3].data =
                get_flex_parser_header_string(&g_flex_transition_db_spc2[i].to);
            transition_value = g_flex_transition_db_spc2[i].transition_value;
            inner = (g_flex_transition_db_spc2[i].encap_level == SX_FLEX_PARSER_ENCAP_INNER_E) ? TRUE : FALSE;
            dbg_utils_pprinter_table_data_line_print(stream, flex_parser_flex_table_dump_clmns);
        }
    }

out:
    SX_LOG_EXIT();
    return;
}

void hwd_flex_parser_root_cfg_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    cl_map_item_t                   *map_item_p = NULL;
    const cl_map_item_t             *map_end_p = NULL;
    flex_parser_db_port_root_item_t *port_root_item_p = NULL;
    boolean_t                        is_first = TRUE;
    static dbg_utils_table_columns_t root_cfg_dump_columns[] = {
        { "Port",    14,  PARAM_PORT_ID_E,     NULL }, /* 0 */
        { "Header",  14,  PARAM_STRING_E,      NULL }, /* 1 */
        {NULL, 0, 0, NULL}
    };
    FILE                            *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        return;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Flex parser root headers");

    /* Find out if this port is already mapped */
    map_item_p = cl_qmap_head(&(port_root_db_spc2.port_root_map));
    map_end_p = cl_qmap_end(&(port_root_db_spc2.port_root_map));

    while (map_item_p != map_end_p) {
        if (is_first) {
            dbg_utils_pprinter_table_headline_print(stream, root_cfg_dump_columns);
            is_first = FALSE;
        }
        port_root_item_p = PARENT_STRUCT(map_item_p, flex_parser_db_port_root_item_t, map_item);
        root_cfg_dump_columns[0].data = &port_root_item_p->log_port;
        root_cfg_dump_columns[1].data = sx_flex_parser_header_fpp_str(port_root_item_p->flex_header);
        map_item_p = cl_qmap_next(map_item_p);

        dbg_utils_pprinter_table_data_line_print(stream, root_cfg_dump_columns);
    }

    SX_LOG_EXIT();
    return;
}
