/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include "hwd_flex_parser_reg.h"
#include "ethl2/fdb_common.h"
#include "ethl2/topo.h"
#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ FLEX_PARSER


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local definitions
 ***********************************************/
#define ULONG_BIT_MASK(bit_num) ((1UL << (bit_num)) - 1)
#define BITS_PER_BYTE 8

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static const sx_dev_info_t __leaf_filter = {
    0,     /* dev_id */
    SX_DEV_NODE_TYPE_LEAF,     /* node_type */
    0,                                 /* num_ports */
    SX_CHIP_TYPE_UNKNOWN        /* sdk_chip_ver_t*/
};
static uint8_t             hwd_flex_parser_reg_ext_points_hw_data[] = {
    [SX_EXTRACTION_POINT_TYPE_L2_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_START_OF_PACKET,
    [SX_EXTRACTION_POINT_TYPE_L2_START_OF_MAC_HEADER_E] = SXD_ACL_EXTRACTION_POINT_MAC_HEADER,
    [SX_EXTRACTION_POINT_TYPE_L2_ETHER_TYPE_E] = SXD_ACL_EXTRACTION_POINT_ETHER_TYPE,
    [SX_EXTRACTION_POINT_TYPE_IPV4_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_IPV4_HEADER,
    [SX_EXTRACTION_POINT_TYPE_IPV4_START_OF_PAYLOAD_E] = SXD_ACL_EXTRACTION_POINT_IPV4_PAYLOAD,
    [SX_EXTRACTION_POINT_TYPE_ARP_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_ARP,
    [SX_EXTRACTION_POINT_TYPE_IPV6_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_IPV6_HEADER,
    [SX_EXTRACTION_POINT_TYPE_IPV6_START_OF_PAYLOAD_E] = SXD_ACL_EXTRACTION_POINT_IPV6_PAYLOAD,
    [SX_EXTRACTION_POINT_TYPE_IPV6_HBH_EXTENSION_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_IPV6_HBH,
    [SX_EXTRACTION_POINT_TYPE_IPV6_DESTINATION_EXTENSION_START_OF_HEADER_E] =
        SXD_ACL_EXTRACTION_POINT_IPV6_DESTINATION,
    [SX_EXTRACTION_POINT_TYPE_IPV6_ROUTING_EXTENSION_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_IPV6_ROUTING,
    [SX_EXTRACTION_POINT_TYPE_IPV6_FRAGMENT_EXTENSION_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_IPV6_FRAGMENT,
    [SX_EXTRACTION_POINT_TYPE_IPV6_MOBILITY_EXTENSION_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_IPV6_MOBILITY,
    [SX_EXTRACTION_POINT_TYPE_MPLS_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_MPLS_HEADER,
    [SX_EXTRACTION_POINT_TYPE_MPLS_START_OF_PAYLOAD_E] = SXD_ACL_EXTRACTION_POINT_MPLS_PAYLOAD,
    [SX_EXTRACTION_POINT_TYPE_GRE_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_GRE_HEADER,
    [SX_EXTRACTION_POINT_TYPE_GRE_PAYLOAD_E] = SXD_ACL_EXTRACTION_POINT_GRE_PAYLOLAD,
    [SX_EXTRACTION_POINT_TYPE_TCP_HEADER_E] = SXD_ACL_EXTRACTION_POINT_TCP_HEADER,
    [SX_EXTRACTION_POINT_TYPE_UDP_HEADER_E] = SXD_ACL_EXTRACTION_POINT_UDP_HEADER,
    [SX_EXTRACTION_POINT_TYPE_UDP_PAYLOAD_E] = SXD_ACL_EXTRACTION_POINT_UDP_PAYLOAD,
    [SX_EXTRACTION_POINT_TYPE_INNER_L2_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_INNER_MAC_HEADER,
    [SX_EXTRACTION_POINT_TYPE_INNER_L2_ETHER_TYPE_E] = SXD_ACL_EXTRACTION_POINT_INNER_ETHER_TYPE,
    [SX_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_INNER_IPV4_HEADER,
    [SX_EXTRACTION_POINT_TYPE_INNER_IPV4_START_OF_PAYLOAD_E] = SXD_ACL_EXTRACTION_POINT_INNER_IPV4_PAYLOAD,
    [SX_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_INNER_IPV6_HEADER,
    [SX_EXTRACTION_POINT_TYPE_INNER_IPV6_START_OF_PAYLOAD_E] = SXD_ACL_EXTRACTION_POINT_INNER_IPV6_PAYLOAD,
    [SX_EXTRACTION_POINT_TYPE_INNER_IPV6_HBH_EXTENSION_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_INNER_IPV6_HBH,
    [SX_EXTRACTION_POINT_TYPE_INNER_IPV6_DESTINATION_EXTENSION_START_OF_HEADER_E] =
        SXD_ACL_EXTRACTION_POINT_INNER_IPV6_DESTINATION,
    [SX_EXTRACTION_POINT_TYPE_INNER_IPV6_ROUTING_EXTENSION_START_OF_HEADER_E] =
        SXD_ACL_EXTRACTION_POINT_INNER_IPV6_ROUTING,
    [SX_EXTRACTION_POINT_TYPE_INNER_IPV6_FRAGMENT_EXTENSION_START_OF_HEADER_E] =
        SXD_ACL_EXTRACTION_POINT_INNER_IPV6_FRAGMENT,
    [SX_EXTRACTION_POINT_TYPE_INNER_IPV6_MOBILITY_EXTENSION_START_OF_HEADER_E] =
        SXD_ACL_EXTRACTION_POINT_INNER_IPV6_MOBILITY,
    [SX_EXTRACTION_POINT_TYPE_INNER_MPLS_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_INNER_MPLS_HEADER,
    [SX_EXTRACTION_POINT_TYPE_INNER_TCP_HEADER_E] = SXD_ACL_EXTRACTION_POINT_INNER_TCP_HEADER,
    [SX_EXTRACTION_POINT_TYPE_INNER_UDP_HEADER_E] = SXD_ACL_EXTRACTION_POINT_INNER_UDP_HEADER,
    [SX_EXTRACTION_POINT_TYPE_INNER_UDP_PAYLOAD_E] = SXD_ACL_EXTRACTION_POINT_INNER_UDP_PAYLOAD,
    [SX_EXTRACTION_POINT_TYPE_VXLAN_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_VXLAN_HEADER,
    [SX_EXTRACTION_POINT_TYPE_VXLAN_GPE_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_VXLAN_GPE_HEADER,
    [SX_EXTRACTION_POINT_TYPE_GENEVE_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_GENEVE_HEADER,
    [SX_EXTRACTION_POINT_TYPE_ICMP_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_ICMP_HEADER,
    [SX_EXTRACTION_POINT_TYPE_IGMP_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_IGMP_HEADER,
    [SX_EXTRACTION_POINT_TYPE_ROCE_BTH_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_ROCE_BTH_HEADER,
    [SX_EXTRACTION_POINT_TYPE_ROCE_GRH_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_ROCE_GRH_HEADER,
    [SX_EXTRACTION_POINT_TYPE_FCOE_FIRST_VFT_HEADER_E] = SXD_ACL_EXTRACTION_POINT_FCOE_VFT,
    [SX_EXTRACTION_POINT_TYPE_FCOE_FIRST_IFR_HEADER_E] = SXD_ACL_EXTRACTION_POINT_FCOE_IFR,
    [SX_EXTRACTION_POINT_TYPE_FCOE_FIRST_ENC_HEADER_E] = SXD_ACL_EXTRACTION_POINT_FCOE_ENC,
    [SX_EXTRACTION_POINT_TYPE_FCOE_CONFIGURABLE_HEADER_E] = SXD_ACL_EXTRACTION_POINT_FCOE_CONFIGURABLE,
    [SX_EXTRACTION_POINT_TYPE_FCOE_FRAME_HEADER_E] = SXD_ACL_EXTRACTION_POINT_FCOE_FRAME_HEADER,
    [SX_EXTRACTION_POINT_TYPE_FCOE_PAYLOAD_E] = SXD_ACL_EXTRACTION_POINT_FCOE_PAYLOAD,
    [SX_EXTRACTION_POINT_TYPE_PTP_START_OF_HEADER_E] = SXD_ACL_EXTRACTION_POINT_PTP,
    [SX_EXTRACTION_POINT_TYPE_FEXP_OUTER_E] = SXD_ACL_EXTRACTION_POINT_FLEX_HEADER0,
    [SX_EXTRACTION_POINT_TYPE_FEXP_INNER_E] = SXD_ACL_EXTRACTION_POINT_INNER_FLEX_HEADER0,
    [SX_EXTRACTION_POINT_TYPE_HASH_SIG0_E] = SXD_ACL_EXTRACTION_POINT_HASH_SIG0,
    [SX_EXTRACTION_POINT_TYPE_HASH_SIG1_E] = SXD_ACL_EXTRACTION_POINT_HASH_SIG1,
    [SX_EXTRACTION_POINT_TYPE_HASH_SIG2_E] = SXD_ACL_EXTRACTION_POINT_HASH_SIG2,
    [SX_EXTRACTION_POINT_TYPE_HASH_SIG3_E] = SXD_ACL_EXTRACTION_POINT_HASH_SIG3,
};

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __hwd_flex_parser_reg_mprs_read(struct ku_mprs_reg *mprs_reg_data,
                                                   sx_dev_info_t dev_info_arr[], length_t dev_info_arr_size);
static sx_status_t __hwd_flex_parser_reg_mprs_write(struct ku_mprs_reg *mprs_reg_data,
                                                    sx_dev_info_t dev_info_arr[], length_t dev_info_arr_size);


/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t __hwd_flex_parser_reg_mprs_read(struct ku_mprs_reg *mprs_reg_data,
                                            sx_dev_info_t       dev_info_arr[],
                                            length_t            dev_info_arr_size)
{
    sxd_reg_meta_t meta;
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_status;

    UNUSED_PARAM(dev_info_arr_size);

    SX_MEM_CLR(meta);

    meta.access_cmd = SXD_ACCESS_CMD_GET;
    meta.dev_id = dev_info_arr[0].dev_id;
    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MPRS_E, mprs_reg_data, &meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get MPRS reg. SXD err [%u]\n", sxd_status);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __hwd_flex_parser_reg_mprs_write(struct ku_mprs_reg *mprs_reg_data,
                                                    sx_dev_info_t       dev_info_arr[],
                                                    length_t            dev_info_arr_size)
{
    sxd_reg_meta_t meta;
    sx_status_t    rc = SX_STATUS_SUCCESS;
    length_t       dev_idx = 0;
    sxd_status_t   sxd_status;

    SX_MEM_CLR(meta);
    meta.access_cmd = SXD_ACCESS_CMD_SET;

    for (dev_idx = 0; dev_idx < dev_info_arr_size; dev_idx++) {
        meta.dev_id = dev_info_arr[dev_idx].dev_id;
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MPRS_E, mprs_reg_data, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set MPRS reg. SXD err [%u]\n", sxd_status);
            rc = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_reg_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    SX_LOG_EXIT();

    return err;
}

sx_status_t hwd_flex_parser_reg_mprs_udp_dport_get(uint32_t *udp_dport)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    length_t           dev_info_arr_size = SX_DEV_ID_MAX;
    sx_dev_info_t      dev_info_arr[SX_DEV_ID_MAX];
    struct ku_mprs_reg mprs_reg_data;

    SX_LOG_ENTER();
    SX_MEM_CLR(mprs_reg_data);

    if (NULL == udp_dport) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hwd reg udp dport get invalid parameter [%s]\n",  sx_status_str(rc));
        goto out;
    }

    SX_MEM_CLR_ARRAY(dev_info_arr, SX_DEV_ID_MAX, sx_dev_info_t);

    rc = topo_device_tbl_bulk_get(SX_ACCESS_CMD_GET, &__leaf_filter, dev_info_arr, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(rc));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* in case of zero device do nothing */
    if (dev_info_arr_size == 0) {
        SX_LOG_DBG("Device not initialized yet\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    SX_MEM_CLR(mprs_reg_data);

    rc = __hwd_flex_parser_reg_mprs_read(&mprs_reg_data, dev_info_arr, dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get MPRS reg. [%s].\n", sx_status_str(rc));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    *udp_dport = mprs_reg_data.vxlan_udp_dport;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_reg_mprs_udp_dport_set(uint32_t value)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_status_t        error_rc = SX_STATUS_SUCCESS;
    struct ku_mprs_reg mprs_reg_data;
    uint16_t           old_vxlan_udp_dport;
    length_t           dev_info_arr_size = SX_DEV_ID_MAX;
    sx_dev_info_t      dev_info_arr[SX_DEV_ID_MAX];


    SX_LOG_ENTER();
    SX_MEM_CLR_ARRAY(dev_info_arr, SX_DEV_ID_MAX, sx_dev_info_t);
    SX_MEM_CLR(mprs_reg_data);

    rc = topo_device_tbl_bulk_get(SX_ACCESS_CMD_GET, &__leaf_filter, dev_info_arr, &dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(rc));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* in case of zero device do nothing */
    if (dev_info_arr_size == 0) {
        SX_LOG_DBG("Device not initialized yet\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    SX_MEM_CLR(mprs_reg_data);

    rc = __hwd_flex_parser_reg_mprs_read(&mprs_reg_data, dev_info_arr, dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get MPRS reg. [%s].\n", sx_status_str(rc));
        rc = SX_STATUS_ERROR;
        goto out;
    }

    old_vxlan_udp_dport = mprs_reg_data.vxlan_udp_dport;
    mprs_reg_data.vxlan_udp_dport = value;

    rc = __hwd_flex_parser_reg_mprs_write(&mprs_reg_data, dev_info_arr, dev_info_arr_size);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to write MPRS reg. [%s].\n", sx_status_str(rc));
        rc = SX_STATUS_ERROR;
        goto error;
    }
    goto out;

error:
    /* rollback all devices that were set */
    mprs_reg_data.vxlan_udp_dport = old_vxlan_udp_dport;
    error_rc = __hwd_flex_parser_reg_mprs_write(&mprs_reg_data, dev_info_arr, dev_info_arr_size);
    if (SX_STATUS_SUCCESS != error_rc) {
        SX_LOG_ERR("Failed rollback set MPRS reg. [%s].\n", sx_status_str(rc));
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_reg_gp_register_ext_point_dev_set(sx_dev_id_t            dev_id,
                                                              sx_gp_register_key_t   gp_reg,
                                                              uint32_t               ext_point_cnt,
                                                              sx_extraction_point_t *ext_point_list_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_rc = SXD_STATUS_SUCCESS;
    struct ku_pecb_reg pecb;
    sxd_reg_meta_t     meta;
    uint32_t           i = 0;
    uint8_t            ext_point_index = 0;

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pecb);

    meta.dev_id = dev_id;
    meta.access_cmd = SXD_ACCESS_CMD_SET;

    pecb.cbset = gp_reg.reg_id;

    for (i = 0; i < ext_point_cnt; i++) {
        ext_point_index = hwd_flex_parser_reg_ext_points_hw_data[ext_point_list_p[i].type];
        /* For Flex extraction point we need to update the extraction point number*/
        if ((ext_point_list_p[i].type == SX_EXTRACTION_POINT_TYPE_FEXP_OUTER_E) ||
            (ext_point_list_p[i].type == SX_EXTRACTION_POINT_TYPE_FEXP_INNER_E)) {
            ext_point_index += ext_point_list_p[i].attr.fexp_attr.fexp_id.fexp_id;
        }
        pecb.extraction_points[ext_point_index].enable = 1;
        pecb.extraction_points[ext_point_index].offset = ext_point_list_p[i].offset;
    }

    sxd_rc = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PECB_E, &pecb, &meta, 1, NULL, NULL);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        rc = sxd_status_to_sx_status(sxd_rc);
        SX_LOG_ERR("Failed to set PECB: error [%s]\n", SXD_STATUS_MSG(sxd_rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_parser_reg_gp_register_ext_point_hw_set(sx_gp_register_key_t   gp_reg,
                                                             uint32_t               ext_point_cnt,
                                                             sx_extraction_point_t *ext_point_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    rc = hwd_flex_parser_reg_gp_register_ext_point_dev_set(dev_info_arr[dev_idx].dev_id,
                                                           gp_reg,
                                                           ext_point_cnt,
                                                           ext_point_list_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return rc;
}

/* Use the FPHTT register to set/unset a hard transition */
sx_status_t hwd_flex_parser_reg_fphtt_set(const sx_access_cmd_t cmd, const uint32_t entry_index)
{
    sx_status_t         rc = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    struct ku_fphtt_reg fphtt_reg_data;
    sxd_reg_meta_t      fphtt_reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(fphtt_reg_meta);
    SX_MEM_CLR(fphtt_reg_data);

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for FPHTT, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    fphtt_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    fphtt_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    fphtt_reg_data.tran_en = (cmd == SX_ACCESS_CMD_SET) ? 1 : 0;
    fphtt_reg_data.entry_index = entry_index;


    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FPHTT_E, &fphtt_reg_data, &fphtt_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure FPHTT flex parser hard transition [%u] for %s command\n",
                   entry_index,
                   sx_access_cmd_str(cmd));
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}

/* Use the FPFTT register to set/unset a flex transition */
sx_status_t hwd_flex_parser_reg_fpftt_set(const sx_access_cmd_t              cmd,
                                          const flex_parser_hw_entry_index_t hw_index,
                                          const flex_parser_hw_entry_index_t from,
                                          const flex_parser_hw_entry_index_t to,
                                          const uint16_t                     transition_value,
                                          const sx_flex_parser_encap_level_e encap_level)
{
    sx_status_t         rc = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    struct ku_fpftt_reg fpftt_reg_data;
    sxd_reg_meta_t      fpftt_reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(fpftt_reg_meta);
    SX_MEM_CLR(fpftt_reg_data);

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for FPFTT, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    fpftt_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    fpftt_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    fpftt_reg_data.tran_en = (cmd == SX_ACCESS_CMD_SET) ? 1 : 0;
    fpftt_reg_data.entry_index = hw_index;
    if (cmd == SX_ACCESS_CMD_SET) {
        fpftt_reg_data.next_protocol_value = transition_value;
        fpftt_reg_data.cur_ph = from;
        fpftt_reg_data.next_ph = to;
        fpftt_reg_data.next_ph_inner = (encap_level == SX_FLEX_PARSER_ENCAP_INNER_E) ? 1 : 0;
    }

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FPFTT_E, &fpftt_reg_data, &fpftt_reg_meta, 1, NULL, NULL);

    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure FPFTT flex parser transition [%u] from [%u] to [%u] for %s command\n",
                   hw_index, from, to, sx_access_cmd_str(cmd));
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}


/* Use the FPPC register to set/unset a flex header */
sx_status_t hwd_flex_parser_reg_fppc_set(const sx_flex_parser_header_fpp_e fpp,
                                         const sx_flex_parser_fpp_t       *fpp_cfg_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_fppc_reg fppc_reg_data;
    sxd_reg_meta_t     fppc_reg_meta;
    uint32_t           bitmask = 0;
    int8_t             constant_temp = 0;
    uint8_t            offset_temp = 0;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(fppc_reg_meta);
    SX_MEM_CLR(fppc_reg_data);

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for fppc, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    fppc_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    fppc_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    fppc_reg_data.fpp = fpp;
    fppc_reg_data.as_ftlv = (fpp_cfg_p->type == SX_FLEX_PARSER_FPP_TYPE_FTLV) ? 1 : 0;
    fppc_reg_data.empty_fph = (fpp_cfg_p->type == SX_FLEX_PARSER_FPP_TYPE_FPH_EMPTY) ? 1 : 0;

    /* Configure the location of the next protocol header */
    fppc_reg_data.protocol.field_offset_dword_prot = fpp_cfg_p->protocol_field.offset >> 2;
    fppc_reg_data.protocol.field_offset_bytes_prot = fpp_cfg_p->protocol_field.offset & 0x3;
    /* Cut down the mask to the required size */
    bitmask = ULONG_BIT_MASK(fpp_cfg_p->protocol_field.size * BITS_PER_BYTE);

    if (fpp_cfg_p->type == SX_FLEX_PARSER_FPP_TYPE_FTLV) {
        fppc_reg_data.protocol.field_mask_prot_tlv = fpp_cfg_p->protocol_field.mask & bitmask;
        fppc_reg_data.protocol.field_mask_prot_tlv <<= (3 - fpp_cfg_p->protocol_field.size) * BITS_PER_BYTE;
        /* We do not support offset higher than 1, so we need to modify the bytes and mask */
        if (fppc_reg_data.protocol.field_offset_bytes_prot > 1) {
            fppc_reg_data.protocol.field_mask_prot_tlv >>= BITS_PER_BYTE *
                                                           (fppc_reg_data.protocol.field_offset_bytes_prot - 1);
            fppc_reg_data.protocol.field_offset_bytes_prot = 1;
        }
    } else {
        fppc_reg_data.protocol.field_mask_prot_non_tlv = fpp_cfg_p->protocol_field.mask & bitmask;
        fppc_reg_data.protocol.field_mask_prot_non_tlv <<= (2 - fpp_cfg_p->protocol_field.size) * BITS_PER_BYTE;
        /* We do not support offset of higher than 2, so we need to modify the bytes and mask */
        if (fppc_reg_data.protocol.field_offset_bytes_prot > 2) {
            fppc_reg_data.protocol.field_mask_prot_non_tlv >>= BITS_PER_BYTE *
                                                               (fppc_reg_data.protocol.field_offset_bytes_prot - 2);
            fppc_reg_data.protocol.field_offset_bytes_prot = 2;
        }
    }

    /* Configure the location of the header length */
    if (fpp_cfg_p->type != SX_FLEX_PARSER_FPP_TYPE_FPH_EMPTY) {
        /* Due to a limitation in HW the header length is actually counted from the start of the dword where the length field was extracted!
         * We compensate for this be reducing the necessary amount from the
         */
        offset_temp = fpp_cfg_p->hdr_len_field.offset & 0xfc;
        constant_temp = fpp_cfg_p->hdr_len_field.constant - (int8_t)offset_temp;

        fppc_reg_data.header_length.field_offset_dword_length = fpp_cfg_p->hdr_len_field.offset >> 2;
        fppc_reg_data.header_length.field_offset_bytes_length = fpp_cfg_p->hdr_len_field.offset & 0x3;
        fppc_reg_data.header_length.field_mask_length = fpp_cfg_p->hdr_len_field.mask & 0xFF;
        fppc_reg_data.header_length.length_math_bitmap = (fpp_cfg_p->hdr_len_field.is_bitmap) ? 1 : 0;
        fppc_reg_data.header_length.length_math_add_pos = (constant_temp < 0) ? 1 : 0;
        fppc_reg_data.header_length.length_math_add = (constant_temp < 0) ? -constant_temp : constant_temp;
        fppc_reg_data.header_length.length_math_shift_left = (fpp_cfg_p->hdr_len_field.shift < 0) ? 1 : 0;
        fppc_reg_data.header_length.length_math_shift =
            (fpp_cfg_p->hdr_len_field.shift < 0) ? -fpp_cfg_p->hdr_len_field.shift : fpp_cfg_p->hdr_len_field.shift;
    }

    /* If we need to configure an extraction point from the start of the packet */
    if (fpp_cfg_p->fexp_start.enable) {
        fppc_reg_data.fexp_st.fexp_st_en = 1;
        fppc_reg_data.fexp_st.fexp_st_id = fpp_cfg_p->fexp_start.fexp_id.fexp_id;

        if (fpp_cfg_p->type == SX_FLEX_PARSER_FPP_TYPE_FTLV) {
            bitmask = ULONG_BIT_MASK(fpp_cfg_p->protocol_field.size * BITS_PER_BYTE);
            fppc_reg_data.fexp_st.fexp_st_tlv_type = fpp_cfg_p->fexp_start.tlv_type & bitmask;
            fppc_reg_data.fexp_st.fexp_st_tlv_type <<= (3 - fpp_cfg_p->protocol_field.size) * BITS_PER_BYTE;
        }
    }

    /* If we need to configure an extraction point from a specific offset in the header */
    if (fpp_cfg_p->fexp_offset.enable) {
        fppc_reg_data.fexp_of.fexp_of_en = 1;
        fppc_reg_data.fexp_of.fexp_of_id = fpp_cfg_p->fexp_offset.fexp_id.fexp_id;
        fppc_reg_data.fexp_of.field_offset_dword_fexp_of = fpp_cfg_p->fexp_offset.fexp_offset.offset >> 2;
        fppc_reg_data.fexp_of.field_offset_bytes_fexp_of = fpp_cfg_p->fexp_offset.fexp_offset.offset & 0x3;
        fppc_reg_data.fexp_of.field_mask_fexp_of = fpp_cfg_p->fexp_offset.fexp_offset.mask & 0xFF;
        fppc_reg_data.fexp_of.fexp_of_math_bitmap = (fpp_cfg_p->fexp_offset.fexp_offset.is_bitmap) ? 1 : 0;
        fppc_reg_data.fexp_of.fexp_of_math_add_pos = (fpp_cfg_p->fexp_offset.fexp_offset.constant < 0) ? 1 : 0;
        fppc_reg_data.fexp_of.fexp_of_math_add =
            (fpp_cfg_p->fexp_offset.fexp_offset.constant <
             0) ? -fpp_cfg_p->fexp_offset.fexp_offset.constant : fpp_cfg_p->fexp_offset.fexp_offset.constant;
        fppc_reg_data.fexp_of.fexp_of_math_shift_left = (fpp_cfg_p->fexp_offset.fexp_offset.shift < 0) ? 1 : 0;
        fppc_reg_data.fexp_of.fexp_of_math_shift =
            (fpp_cfg_p->fexp_offset.fexp_offset.shift <
             0) ? -fpp_cfg_p->fexp_offset.fexp_offset.shift : fpp_cfg_p->fexp_offset.fexp_offset.shift;

        if (fpp_cfg_p->type == SX_FLEX_PARSER_FPP_TYPE_FTLV) {
            bitmask = ULONG_BIT_MASK(fpp_cfg_p->protocol_field.size * BITS_PER_BYTE);
            fppc_reg_data.fexp_of.fexp_of_tlv_type = fpp_cfg_p->fexp_offset.tlv_type & bitmask;
            fppc_reg_data.fexp_of.fexp_of_tlv_type <<= (3 - fpp_cfg_p->protocol_field.size) * BITS_PER_BYTE;
        }
    }

    /* Configure the TLV if it exist */
    if (fpp_cfg_p->my_tlv.enable) {
        fppc_reg_data.my_tlv.my_ftlv_en = 1;
        fppc_reg_data.my_tlv.my_ftlv_fpp = fpp_cfg_p->my_tlv.fpp_id.fpp_id;
        fppc_reg_data.my_tlv.my_ftlv_start = fpp_cfg_p->my_tlv.tlv_start_offset >> 2;
    }

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FPPC_E, &fppc_reg_data, &fppc_reg_meta, 1, NULL, NULL);

    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure FPPC flex parser header [%u]\n", fpp);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}

/* Set the TLV FPP that will be used on a specified fixed header */
sx_status_t hwd_flex_parser_reg_fphhc_set(const flex_parser_hw_entry_index_t hw_index,
                                          const boolean_t                    outer_tlv_set,
                                          const boolean_t                    inner_tlv_set,
                                          const sx_flex_parser_header_fpp_e  tlv_fpp)
{
    sx_status_t         rc = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    struct ku_fphhc_reg fphhc_reg_data;
    sxd_reg_meta_t      fphhc_reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(fphhc_reg_meta);
    SX_MEM_CLR(fphhc_reg_data);

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for fppc, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    fphhc_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    fphhc_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    fphhc_reg_data.hph = hw_index;
    fphhc_reg_data.my_ftlv_outer_en = (outer_tlv_set) ? 1 : 0;
    fphhc_reg_data.my_ftlv_inner_en = (inner_tlv_set) ? 1 : 0;
    fphhc_reg_data.my_ftlv_fpp = tlv_fpp;

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FPHHC_E, &fphhc_reg_data, &fphhc_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure FPHHC for fixed header [0x%X]\n", hw_index);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }


    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}

/* Set the FPTS register which configures the flex parser for a local port */
sx_status_t hwd_flex_parser_reg_fpts_set(const sx_access_cmd_t              cmd,
                                         const boolean_t                    global,
                                         const sx_port_log_id_t             log_port,
                                         const flex_parser_hw_entry_index_t next_hw_index)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_fpts_reg fpts_reg_data;
    sxd_reg_meta_t     fpts_reg_meta;
    sx_port_phy_id_t   local_port = 0;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(fpts_reg_meta);
    SX_MEM_CLR(fpts_reg_data);

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for fppc, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    fpts_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    fpts_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    local_port = (global) ? 0 : SX_PORT_PHY_ID_GET(log_port);
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(fpts_reg_data.local_port,
                                        fpts_reg_data.lp_msb,
                                        local_port);
    fpts_reg_data.tran_type = (cmd == SX_ACCESS_CMD_SET) ? 1 : 0;
    fpts_reg_data.global = (global) ? 1 : 0;
    if (cmd == SX_ACCESS_CMD_SET) {
        fpts_reg_data.next_ph = next_hw_index;
    }

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FPTS_E, &fpts_reg_data, &fpts_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure FPTS for log_port [0x%X]\n", log_port);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}
