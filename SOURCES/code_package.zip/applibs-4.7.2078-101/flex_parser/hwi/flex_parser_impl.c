/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include "complib/cl_fcntl.h"
#include <sx/utils/debug_cmd.h>
#include "ethl2/brg.h"
#include "ethl2/topo.h"
#include "flex_parser_impl.h"
#include "flex_parser/hwd/hwd_flex_parser.h"

#undef __MODULE__
#define __MODULE__ FLEX_PARSER


/************************************************
 *  Global variables
 ***********************************************/
extern sx_brg_context_t      brg_context;
extern flex_parser_hwd_ops_t g_flex_parser_hwd_ops;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static flex_parser_transition_mode_e g_flex_parser_transition_mode = FLEX_PARSER_TRANSITION_MODE_NONE_E;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __flex_parser_set_hwd_init_ops();
static sx_status_t __flex_parser_hwd_transition_get_wrapper(const sx_flex_parser_header_t curr_ph,
                                                            sx_flex_parser_transition_t  *next_trans_ph_p,
                                                            uint32_t                     *next_trans_ph_cnt_p);
static sx_status_t __flex_parser_hwd_transition_set_wrapper(const sx_access_cmd_t             cmd,
                                                            const sx_flex_parser_header_t     from,
                                                            const sx_flex_parser_transition_t to,
                                                            const boolean_t                   validate_only);
static sx_status_t __flex_parser_hwd_init_wrapper(IN const sx_flex_parser_param_t *params_p);
static sx_status_t __flex_parser_hwd_deinit_wrapper();
static sx_status_t __flex_parser_hwd_device_ready_cb_wrapper(sx_access_cmd_t cmd);


/************************************************
 *  Function implementations
 ***********************************************/
static sx_status_t __flex_parser_set_hwd_init_ops()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    /* Set the hardware operations */
    if (brg_context.spec_cb_g.flex_parser_init_ops == NULL) {
        SX_LOG_ERR("flex_parser init ops cb is undefined\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = brg_context.spec_cb_g.flex_parser_init_ops();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("flex_parser init ops failed.\n");
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t sdk_flex_parser_transition_mode_test_and_set(flex_parser_transition_mode_e mode)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_valid_mode = FALSE;

    SX_LOG_ENTER();

    if (mode >= FLEX_PARSER_MODE_LAST_E) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid internal flex parser mode %d\n", mode);
        goto out;
    }

    is_valid_mode = (g_flex_parser_transition_mode == FLEX_PARSER_TRANSITION_MODE_NONE_E) ||
                    (g_flex_parser_transition_mode == mode);

    if (is_valid_mode == FALSE) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    g_flex_parser_transition_mode = mode;

out:
    SX_LOG_EXIT();
    return rc;
}

/*
 * The APIs sx_api_flex_parser_transition_set and sx_api_flex_parser_flex_transition_set are mutually exclusive,
 * so per single SDK life cycle only one of them can be used.
 * This function is internal back door to reset the mutual exclusion, for verification
 * NO RESET tests.
 * Usage:
 *     sx_debug_cmd_client flex_parser transition mode reset
 */
static void __flex_parser_mode_reset()
{
    if (g_flex_parser_transition_mode == FLEX_PARSER_MODE_USER_DEFINED_TRANSITION_SET_E) {
        SX_LOG_NTC(
            "Reset mutual exclusion between transition_set and flex_transition_set APIs while flex_transition_set (ISSU) is in used\n");
    } else if (g_flex_parser_transition_mode == FLEX_PARSER_MODE_TRANSITION_SET_E) {
        SX_LOG_NTC(
            "Reset mutual exclusion between transition_set and flex_transition_set APIs while transition_set (legacy) is in used\n");
    }

    g_flex_parser_transition_mode = FLEX_PARSER_TRANSITION_MODE_NONE_E;
}

static void __debug_cmd_flex_parser_reset_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    dbg_utils_print(stream, "Will reset mutual exclusion between legacy and ISSU support APIs\n");
    __flex_parser_mode_reset();
}


static sx_status_t __flex_parser_hwd_transition_get_wrapper(const sx_flex_parser_header_t curr_ph,
                                                            sx_flex_parser_transition_t  *next_trans_ph_p,
                                                            uint32_t                     *next_trans_ph_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    /* Call Hardware specific function */
    if (g_flex_parser_hwd_ops.flex_parser_transition_get_pfn == NULL) {
        SX_LOG_ERR("Hwd transition get not supported\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }
    rc = g_flex_parser_hwd_ops.flex_parser_transition_get_pfn(curr_ph, next_trans_ph_p, next_trans_ph_cnt_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving from hardware [%s].\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_hwd_transition_set_wrapper(const sx_access_cmd_t             cmd,
                                                            const sx_flex_parser_header_t     from,
                                                            const sx_flex_parser_transition_t to,
                                                            const boolean_t                   validate_only)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    /* Call Hardware specific function */
    if (g_flex_parser_hwd_ops.flex_parser_transition_set_pfn == NULL) {
        SX_LOG_ERR("Hwd transition set not supported\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }
    rc = g_flex_parser_hwd_ops.flex_parser_transition_set_pfn(cmd, from, to, validate_only);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed writing to hardware [%s].\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_hwd_flex_transition_set_wrapper(const sx_access_cmd_t               cmd,
                                                                 sx_flex_parser_transition_index_t  *transition_index_p,
                                                                 sx_flex_parser_transition_action_t *transition_cfg_p,
                                                                 const boolean_t                     validate_only)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    /* Call Hardware specific function */
    if (g_flex_parser_hwd_ops.flex_parser_flex_transition_set_pfn == NULL) {
        SX_LOG_ERR("Hwd flex transition set not supported\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }
    rc = g_flex_parser_hwd_ops.flex_parser_flex_transition_set_pfn(cmd,
                                                                   transition_index_p,
                                                                   transition_cfg_p,
                                                                   validate_only);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed writing to hardware [%s].\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_hwd_flex_transition_get_wrapper(
    const sx_flex_parser_transition_index_t transition_index,
    sx_flex_parser_transition_action_t     *transition_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    /* Call Hardware specific function */
    if (g_flex_parser_hwd_ops.flex_parser_flex_transition_get_pfn == NULL) {
        SX_LOG_ERR("Hwd transition flex get not supported\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }
    rc = g_flex_parser_hwd_ops.flex_parser_flex_transition_get_pfn(transition_index, transition_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed retrieving from hardware [%s].\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_hwd_init_wrapper(IN const sx_flex_parser_param_t *params_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_init_pfn != NULL) {
        rc = g_flex_parser_hwd_ops.flex_parser_init_pfn(params_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("HW flex parser init failed [%s].\n", sx_status_str(rc));
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_hwd_deinit_wrapper(boolean_t is_forced)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_deinit_pfn != NULL) {
        rc = g_flex_parser_hwd_ops.flex_parser_deinit_pfn(is_forced);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("HW flex parser deinit failed [%s].\n", sx_status_str(rc));
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_hwd_reg_ext_point_is_set_wrapper(sx_register_key_t reg_key, boolean_t *is_set_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_reg_ext_point_is_set_pfn != NULL) {
        rc = g_flex_parser_hwd_ops.flex_parser_reg_ext_point_is_set_pfn(reg_key, is_set_p);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_reg_ext_point_set_wrapper(sx_register_key_t      reg_key,
                                                           uint32_t               ext_point_cnt,
                                                           sx_extraction_point_t *ext_point_list_p,
                                                           sdk_ref_t             *ref_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_reg_ext_point_set_pfn != NULL) {
        rc = g_flex_parser_hwd_ops.flex_parser_reg_ext_point_set_pfn(reg_key, ext_point_cnt, ext_point_list_p, ref_p);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_reg_ext_point_validate_wrapper(sx_register_key_t      reg_key,
                                                                uint32_t               ext_point_cnt,
                                                                sx_extraction_point_t *ext_point_list_p,
                                                                boolean_t             *is_valid_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *is_valid_p = TRUE;

    if (g_flex_parser_hwd_ops.flex_parser_reg_ext_point_validate_pfn != NULL) {
        rc = g_flex_parser_hwd_ops.flex_parser_reg_ext_point_validate_pfn(reg_key,
                                                                          ext_point_cnt,
                                                                          ext_point_list_p,
                                                                          is_valid_p);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_reg_ext_point_get_wrapper(sx_register_key_t      reg_key,
                                                           uint32_t              *ext_point_cnt_p,
                                                           sx_extraction_point_t *ext_point_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_reg_ext_point_get_pfn != NULL) {
        rc = g_flex_parser_hwd_ops.flex_parser_reg_ext_point_get_pfn(reg_key, ext_point_cnt_p, ext_point_list_p);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_parser_hwd_device_ready_cb_wrapper(sx_access_cmd_t cmd)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_dev_ready_cb_pfn != NULL) {
        rc = adviser_register_event(cmd, ADVISER_EVENT_POST_DEVICE_READY_E,
                                    g_flex_parser_hwd_ops.flex_parser_dev_ready_cb_pfn);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in adviser register event , error: %s \n", sx_status_str(rc));
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static void __flex_parser_ext_point_gp_reg_dump_wrapper(dbg_dump_params_t *dbg_dump_params_p, sx_gp_register_e reg_id)
{
    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_gp_reg_ext_point_dump_pfn != NULL) {
        g_flex_parser_hwd_ops.flex_parser_gp_reg_ext_point_dump_pfn(dbg_dump_params_p, reg_id);
    }

    SX_LOG_EXIT();
}

static void __flex_parser_extended_dump_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_extended_dump_pfn != NULL) {
        g_flex_parser_hwd_ops.flex_parser_extended_dump_pfn(dbg_dump_params_p);
    }

    SX_LOG_EXIT();
}

static void __debug_cmd_ext_point_gp_reg_dump_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params = {
        .stream = stream,
        .thread_idx = 0,
        .thread_num = 1,
        .hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    };
    uint32_t                    gp_reg_id = 0;
    boolean_t                   dump_all = (boolean_t)(intptr_t)handler_context;

    SX_MEM_CLR(printer_params);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI:  failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    if (dump_all) {
        __flex_parser_ext_point_gp_reg_dump_wrapper(&dbg_dump_params, SX_GP_REGISTER_LAST_E);
    } else if ((argc > 0) && (sscanf(argv[0], "%u", &gp_reg_id) == 1)) {
        __flex_parser_ext_point_gp_reg_dump_wrapper(&dbg_dump_params, gp_reg_id);
    }

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}

static void __flex_parser_debug_cmd_register(void)
{
    sx_utils_debug_cmd_register_path("flex_parser ext_point get <gp_reg_id>", __debug_cmd_ext_point_gp_reg_dump_cb,
                                     (void*)FALSE);
    sx_utils_debug_cmd_register_path("flex_parser ext_point get all", __debug_cmd_ext_point_gp_reg_dump_cb,
                                     (void*)TRUE);
    sx_utils_debug_cmd_register_path("flex_parser transition set reset", __debug_cmd_flex_parser_reset_cb, NULL);
}

static void __flex_parser_debug_cmd_unregister(void)
{
    sx_utils_debug_cmd_unregister_path("flex_parser");
}

sx_status_t sdk_flex_parser_transition_set(const sx_access_cmd_t             cmd,
                                           const sx_flex_parser_header_t     from,
                                           const sx_flex_parser_transition_t to)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    sx_flex_parser_transition_t   dest_parser_hdr;
    sx_flex_parser_header_fixed_e from_parser_hdr_fixed;
    sx_flex_parser_header_fixed_e to_parser_hdr_fixed;
    sx_flex_parser_encap_level_e  to_encap_level;

    SX_LOG_ENTER();

    /* check if the access command is valid */
    if ((SX_ACCESS_CMD_SET != cmd) && (SX_ACCESS_CMD_UNSET != cmd)) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid command :%d error: [%s] \n", cmd, sx_status_str(rc));
        goto out;
    }
    /* user should always use this API for hard header to hard header */
    if ((from.parser_hdr_type == SX_FLEX_PARSER_HEADER_FPP_E) ||
        (to.next_parser_hdr.parser_hdr_type == SX_FLEX_PARSER_HEADER_FPP_E)) {
        rc = sdk_flex_parser_transition_mode_test_and_set(FLEX_PARSER_MODE_TRANSITION_SET_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("The flex transitions are already defined by user, using sx_api_flex_parser_flex_transition_set."
                       " Cannot change the flex transition mode to SDK defined transitions.\n");
            goto out;
        }
    }
    /* In case of UNSET some time default value has to be written, so make a copy of constant*/
    SX_MEM_CPY(dest_parser_hdr, to);

    from_parser_hdr_fixed = from.hdr_data.parser_hdr_fixed;
    to_parser_hdr_fixed = to.next_parser_hdr.hdr_data.parser_hdr_fixed;
    to_encap_level = to.encap_level;

    /* Check if the UNSET is done for UDP --> VxLAN transition */
    if ((SX_ACCESS_CMD_UNSET == cmd) && (from_parser_hdr_fixed == SX_FLEX_PARSER_HEADER_UDP_E) &&
        (to_parser_hdr_fixed == SX_FLEX_PARSER_HEADER_VXLAN_E) &&
        (to_encap_level == SX_FLEX_PARSER_ENCAP_OUTER_E)) {
        dest_parser_hdr.transition_value = FLEX_PARSER_VXLAN_DEFAULT_UDP_PORT;
    }

    /* Cal the hw specific API to set transition */
    rc = __flex_parser_hwd_transition_set_wrapper(cmd, from, dest_parser_hdr, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed hwd transition set [%s].\n", sx_status_str(rc));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_transition_get(const sx_flex_parser_header_t curr_ph,
                                           sx_flex_parser_transition_t  *next_trans_ph_p,
                                           uint32_t                     *next_trans_ph_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* check the count pointer */
    if (next_trans_ph_cnt_p == NULL) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hwi handle udp transition get NULL count_p input [%s].\n", sx_status_str(rc));
        goto out;
    }

    /* check if the count pointer is valid and list pointer is valid */
    if ((*next_trans_ph_cnt_p != 0) && (next_trans_ph_p == NULL)) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hwi handle udp transition get NULL array_p [%s].\n", sx_status_str(rc));
        goto out;
    }

    /* call hw specific functionality */
    rc = __flex_parser_hwd_transition_get_wrapper(curr_ph, next_trans_ph_p, next_trans_ph_cnt_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed hwd transition get [%s].\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_flex_transition_set(const sx_access_cmd_t               cmd,
                                                sx_flex_parser_transition_index_t  *transition_index_p,
                                                sx_flex_parser_transition_action_t *transition_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* check if the access command is valid */
    if ((SX_ACCESS_CMD_SET != cmd) && (SX_ACCESS_CMD_UNSET != cmd) && (SX_ACCESS_CMD_CREATE != cmd) &&
        (SX_ACCESS_CMD_DESTROY != cmd)) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid command :%d error: [%s] \n", cmd, sx_status_str(rc));
        goto out;
    }

    rc = sdk_flex_parser_transition_mode_test_and_set(FLEX_PARSER_MODE_USER_DEFINED_TRANSITION_SET_E);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("The flex transitions are already defined by the SDK, using sx_api_flex_parser_transition_set."
                   " Cannot change the flex transition mode to user defined transitions.\n");
        goto out;
    }

    /* Call the hw specific API to set transition */
    rc = __flex_parser_hwd_flex_transition_set_wrapper(cmd, transition_index_p, transition_cfg_p, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed hwd flex transition set [%s].\n", sx_status_str(rc));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_flex_transition_get(const sx_flex_parser_transition_index_t transition_index,
                                                sx_flex_parser_transition_action_t     *transition_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* check the count pointer */
    if (transition_cfg_p == NULL) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hwi handle transition get NULL transition_cfg_p input [%s].\n", sx_status_str(rc));
        goto out;
    }

    /* call hw specific functionality */
    rc = __flex_parser_hwd_flex_transition_get_wrapper(transition_index, transition_cfg_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed hwd flex transition get [%s].\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t sdk_flex_parser_impl_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    SX_LOG_EXIT();
    return rc;
}


sx_status_t sdk_flex_parser_init(IN const sx_flex_parser_param_t *params_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Set the hwd operations */
    rc = __flex_parser_set_hwd_init_ops();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("flex_parser hw init ops failed.\n");
        goto out;
    }

    /* initialize the hwd layer */
    rc = __flex_parser_hwd_init_wrapper(params_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in hwd init, error: %s \n", sx_status_str(rc));
        goto out;
    }

    /* Initialize the device ready callback at hwd layer */
    rc = __flex_parser_hwd_device_ready_cb_wrapper(SX_ACCESS_CMD_ADD);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed setting adviser callback, error: %s \n", sx_status_str(rc));
        goto error;
    }

    __flex_parser_debug_cmd_register();

    goto out;

error:
    /* Rollback init in case of error after init */
    rc = __flex_parser_hwd_deinit_wrapper(TRUE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in hwd deinit during rollback, error: %s \n", sx_status_str(rc));
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_deinit(boolean_t is_forced)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Deinit the hwd layer */
    rc = __flex_parser_hwd_deinit_wrapper(is_forced);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in flex parser hwd deinit, error: %s\n", sx_status_str(rc));
        goto out;
    }

    /* unregister the device ready cb */
    rc = __flex_parser_hwd_device_ready_cb_wrapper(SX_ACCESS_CMD_DELETE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed deleting adviser_register_event, error: %s\n", sx_status_str(rc));
        goto out;
    }

    __flex_parser_debug_cmd_unregister();

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_parser_init_ops_spc()
{
    hwd_flex_parser_set_impl_ops_spc();
    return SX_STATUS_SUCCESS;
}

sx_status_t flex_parser_init_ops_spc2()
{
    hwd_flex_parser_set_impl_ops_spc2();
    return SX_STATUS_SUCCESS;
}

sx_status_t flex_parser_init_ops_spc4()
{
    hwd_flex_parser_set_impl_ops_spc4();
    return SX_STATUS_SUCCESS;
}


static const char * get_reg_ext_point_ref_name(char *name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = "extraction point";

    return ref_name;
}


sx_status_t sdk_flex_parser_fpp_set(const sx_access_cmd_t         cmd,
                                    const sx_flex_parser_fpp_id_t fpp_id,
                                    const sx_flex_parser_fpp_t   *fpp_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_fpp_set_pfn == NULL) {
        SX_LOG_ERR("Flex parser FPP set command is not supported for this chip type.\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_flex_parser_hwd_ops.flex_parser_fpp_set_pfn(cmd, fpp_id.fpp_id, fpp_cfg_p);
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_fpp_get(const sx_access_cmd_t         cmd,
                                    const sx_flex_parser_fpp_id_t fpp_id,
                                    sx_flex_parser_fpp_t         *fpp_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_fpp_get_pfn == NULL) {
        SX_LOG_ERR("Flex parser FPP get command is not supported for this chip type.\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_flex_parser_hwd_ops.flex_parser_fpp_get_pfn(cmd, fpp_id.fpp_id, fpp_cfg_p);
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_root_set(const sx_access_cmd_t                cmd,
                                     const uint32_t                       root_cfg_count,
                                     const sx_flex_parser_root_sop_cfg_t *root_cfg_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_root_set_pfn == NULL) {
        SX_LOG_ERR("Flex parser root set command is not supported for this chip type.\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_flex_parser_hwd_ops.flex_parser_root_set_pfn(cmd, root_cfg_list_p, root_cfg_count);
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_root_get(const sx_access_cmd_t          cmd,
                                     const sx_port_log_id_t         log_port,
                                     uint32_t                      *root_cfg_count_p,
                                     sx_flex_parser_root_sop_cfg_t *root_cfg_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_root_get_pfn == NULL) {
        SX_LOG_ERR("Flex parser root get command is not supported for this chip type.\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_flex_parser_hwd_ops.flex_parser_root_get_pfn(cmd, log_port, root_cfg_list_p, root_cfg_count_p);
out:

    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_hph_set(const sx_access_cmd_t         cmd,
                                    const sx_flex_parser_hph_id_t hph_id,
                                    const sx_flex_parser_hph_t   *hph_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_hph_set_pfn == NULL) {
        SX_LOG_ERR("Flex parser HPH set command is not supported for this chip type.\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_flex_parser_hwd_ops.flex_parser_hph_set_pfn(cmd, hph_id.hph_id, hph_cfg_p);
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_hph_get(const sx_access_cmd_t         cmd,
                                    const sx_flex_parser_hph_id_t hph_id,
                                    sx_flex_parser_hph_t         *hph_cfg_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_hph_get_pfn == NULL) {
        SX_LOG_ERR("Flex parser HPH get command is not supported for this chip type.\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_flex_parser_hwd_ops.flex_parser_hph_get_pfn(cmd, hph_id.hph_id, hph_cfg_p);
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_fexp_set(const sx_access_cmd_t cmd, sx_flex_parser_fexp_id_t *fexp_id_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_fexp_set_pfn == NULL) {
        SX_LOG_ERR("Flex parser FEXP set command is not supported for this chip type.\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_flex_parser_hwd_ops.flex_parser_fexp_set_pfn(cmd, fexp_id_p->fexp_id);
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_flex_graph_set(const sx_access_cmd_t          cmd,
                                           const uint32_t                 actions_cnt,
                                           sx_flex_parser_graph_action_t *actions_list_p)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    uint32_t        i = 0;
    sx_access_cmd_t set_cmd;

    SX_LOG_ENTER();

    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        if (g_flex_parser_hwd_ops.flex_parser_transition_set_pfn == NULL) {
            SX_LOG_ERR("Hwd transition set not supported\n");
            rc = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        set_cmd = (cmd == SX_ACCESS_CMD_ADD) ? SX_ACCESS_CMD_SET : SX_ACCESS_CMD_UNSET;
        /* Do our best to validate all the transactions before they are executed in HWD*/
        for (i = 0; i < actions_cnt; i++) {
            if ((actions_list_p[i].from.parser_hdr_type != SX_FLEX_PARSER_HEADER_FPP_E) &&
                (actions_list_p[i].to.next_parser_hdr.parser_hdr_type != SX_FLEX_PARSER_HEADER_FPP_E)) {
                SX_LOG_ERR("Flex parser flex graph set does not support hard transitions.\n");
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            rc = g_flex_parser_hwd_ops.flex_parser_transition_set_pfn(set_cmd,
                                                                      actions_list_p[i].from,
                                                                      actions_list_p[i].to,
                                                                      TRUE);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed validating HWD for flex graph set [%s].\n", sx_status_str(rc));
                goto out;
            }
        }
        /* After we're done with the validations configure the actual graph */
        for (i = 0; i < actions_cnt; i++) {
            rc = g_flex_parser_hwd_ops.flex_parser_transition_set_pfn(set_cmd,
                                                                      actions_list_p[i].from,
                                                                      actions_list_p[i].to,
                                                                      FALSE);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed HWD for flex graph set [%s].\n", sx_status_str(rc));
                goto out;
            }
        }
    } else {
        /* Delete the whole graph */
        if (g_flex_parser_hwd_ops.flex_parser_transition_set_all_pfn == NULL) {
            SX_LOG_ERR("Hwd transition set not supported\n");
            rc = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        rc = g_flex_parser_hwd_ops.flex_parser_transition_set_all_pfn(cmd, SX_FLEX_PARSER_HEADER_FPP_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed HWD for flex graph delete all [%s].\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_hard_graph_set(const sx_access_cmd_t          cmd,
                                           const uint32_t                 actions_cnt,
                                           sx_flex_parser_graph_action_t *actions_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        if (g_flex_parser_hwd_ops.flex_parser_transition_set_pfn == NULL) {
            SX_LOG_ERR("Hwd transition set not supported\n");
            rc = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        /* Do our best to validate all the transactions before they are executed in HWD*/
        for (i = 0; i < actions_cnt; i++) {
            if ((actions_list_p[i].from.parser_hdr_type != SX_FLEX_PARSER_HEADER_FIXED_E) ||
                (actions_list_p[i].to.next_parser_hdr.parser_hdr_type != SX_FLEX_PARSER_HEADER_FIXED_E)) {
                SX_LOG_ERR("Flex parser hard graph set does not support flex transitions.\n");
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            rc = g_flex_parser_hwd_ops.flex_parser_transition_set_pfn(cmd,
                                                                      actions_list_p[i].from,
                                                                      actions_list_p[i].to,
                                                                      TRUE);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed validating HWD for flex graph set [%s].\n", sx_status_str(rc));
                goto out;
            }
        }
        /* After we're done with the validations configure the actual graph */
        for (i = 0; i < actions_cnt; i++) {
            rc = g_flex_parser_hwd_ops.flex_parser_transition_set_pfn(cmd,
                                                                      actions_list_p[i].from,
                                                                      actions_list_p[i].to,
                                                                      FALSE);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed HWD for flex graph set [%s].\n", sx_status_str(rc));
                goto out;
            }
        }
    } else {
        /* Delete the whole graph */
        if (g_flex_parser_hwd_ops.flex_parser_transition_set_all_pfn == NULL) {
            SX_LOG_ERR("Hwd transition set not supported\n");
            rc = SX_STATUS_UNSUPPORTED;
            goto out;
        }
        rc = g_flex_parser_hwd_ops.flex_parser_transition_set_all_pfn(cmd, SX_FLEX_PARSER_HEADER_FIXED_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed HWD for flex graph delete all [%s].\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_resources_get(const sx_access_cmd_t       cmd,
                                          sx_flex_parser_resources_t *flex_parser_resources_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_resources_get_pfn == NULL) {
        SX_LOG_ERR("Flex parser resources get is not supported for this chip type.\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_flex_parser_hwd_ops.flex_parser_resources_get_pfn(cmd, flex_parser_resources_p);
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t sdk_flex_parser_reg_ext_point_set(sx_register_key_t      reg_key,
                                              uint32_t               ext_point_cnt,
                                              sx_extraction_point_t *ext_point_list_p)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    boolean_t       is_allocated = FALSE, is_valid = FALSE;
    boolean_t       is_ext_point_set = FALSE;
    sdk_ref_t       reference = 0;
    ref_name_data_t ref_name_data = {.print_func_p = get_reg_ext_point_ref_name,
                                     .ref_data_p = NULL,
                                     .data_size = 0};

    SX_LOG_ENTER();

    rc = sdk_register_impl_is_allocated(reg_key, &is_allocated);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set extraction point: failed to fetch register, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    if (is_allocated == FALSE) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to set extraction point: register is not set, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    rc = __flex_parser_reg_ext_point_validate_wrapper(reg_key, ext_point_cnt, ext_point_list_p, &is_valid);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set extraction point on register, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    if (is_valid == FALSE) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to set extraction point: ext_points validation failed. error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    rc = __flex_parser_hwd_reg_ext_point_is_set_wrapper(reg_key, &is_ext_point_set);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get extraction point information from DB, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    if (is_ext_point_set == FALSE) {
        /* If set: lock register, extraction point list takes 1 reference */
        if (ext_point_cnt > 0) {
            rc = sdk_register_impl_ref_increase(reg_key, &ref_name_data, &reference);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to lock register, error: [%s]\n", sx_status_str(rc));
                goto out;
            }
        } else {
            SX_LOG_INF("Unset no exist extraction point list - do nothing.\n");
            goto out;
        }
    }

    rc = __flex_parser_reg_ext_point_set_wrapper(reg_key, ext_point_cnt, ext_point_list_p, &reference);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set extraction point on register, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    /* If unset: unlock register */
    if (ext_point_cnt == 0) {
        rc = sdk_register_impl_ref_decrease(reg_key, &reference);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to unlock register, error: [%s]\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_reg_ext_point_get(sx_register_key_t      reg_key,
                                              uint32_t              *ext_point_cnt_p,
                                              sx_extraction_point_t *ext_point_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_allocated = FALSE;

    SX_LOG_ENTER();

    rc = sdk_register_impl_is_allocated(reg_key, &is_allocated);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get extraction point: failed to fetch register, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    if (is_allocated == FALSE) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to get extraction point: register is not set, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

    rc = __flex_parser_reg_ext_point_get_wrapper(reg_key, ext_point_cnt_p, ext_point_list_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get extraction point from DB, error: [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_fpp_ref_inc(const sx_flex_parser_fpp_id_t fpp_id,
                                        const ref_name_data_t        *ref_name_data,
                                        sdk_ref_t                    *ref_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_fpp_ref_inc_pfn == NULL) {
        SX_LOG_ERR("Flex parser FPP ref increase command is not supported for this chip type.\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_flex_parser_hwd_ops.flex_parser_fpp_ref_inc_pfn(fpp_id.fpp_id, ref_name_data, ref_p);
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_flex_parser_fpp_ref_dec(const sx_flex_parser_fpp_id_t fpp_id, sdk_ref_t                    *ref_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_flex_parser_hwd_ops.flex_parser_fpp_ref_dec_pfn == NULL) {
        SX_LOG_ERR("Flex parser FPP ref decrease command is not supported for this chip type.\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    rc = g_flex_parser_hwd_ops.flex_parser_fpp_ref_dec_pfn(fpp_id.fpp_id, ref_p);
out:
    SX_LOG_EXIT();
    return rc;
}


void sdk_flex_parser_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }

    __flex_parser_ext_point_gp_reg_dump_wrapper(dbg_dump_params_p, SX_GP_REGISTER_LAST_E);

    __flex_parser_extended_dump_wrapper(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
}
