/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLEX_PARSER_BE_H_INCL__
#define __FLEX_PARSER_BE_H_INCL__

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_flex_parser.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


sx_status_t flex_parser_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

sx_status_t flex_parser_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

/**
 *  PARSE module initialization function.
 *
 * @param[in] sx_flex_parser_params -  SDK Parse init parameters.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_ERROR if unexpected behavior occurs
 */
sx_status_t flex_parser_init(const IN sx_flex_parser_param_t *params_p);


/**
 *  PARSE module deinitialization function.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *  other return codes are not provided
 */
sx_status_t flex_parser_deinit();


/**
 * Configure enable/disable for the transition between two existing parse headers in the parse
 * graph. Caller must specify the header to enable the transition from and to.
 * Depending on the next protocol field definition, the actual size of the value
 * used may be less than 32 bits.
 * Note that some combinations may be unsupported.
 * Parameters:
 *     [in]    cmd     - SX_ACCESS_CMD_SET/ SX_ACCESS_CMD_UNSET
 *     [in]    from    - the parse header to transition from
 *     [in]    to      - the flex parser next transition header information
 * Returns:
 *     SX_STATUS_SUCCESS if operation completes successfully
 *     SX_STATUS_PARAM_ERROR if any input parameter is invalid
 *     SX_STATUS_ERROR general error
 *     SX_STATUS_UNSUPPORTED if configuration is not supported by the platform
 *     SX_STATUS_NO_RESOURCES if configuration fails due to a lack of HW resources
 */
sx_status_t flex_parser_transition_set(const sx_access_cmd_t             cmd,
                                       const sx_flex_parser_header_t     from,
                                       const sx_flex_parser_transition_t to);

/**
 * Get the configuration of a transition from a given node in the parse graph.
 * Caller can start at the root and iterate over the results to traverse
 * the entire parse graph.
 * Supported devices: Spectrum
 * Parameters:
 * @param [in]  curr_ph    - the current flex parser header to transition from
 * @param [out] next_trans_p - a pointer to array of node transition structure.
 *                                If it is NULL, the next_trans_cnt variable is filled out
 *                                with numbers of transitions that could be retrieved. If
 *                                the pointer is valid, node transition info is placed
 *                                and next_trans_cnt takes actual number ports in array.
 * @param [out] next_trans_cnt - Specifies the number of items in the next_trans_p array
 *
 * Returns:
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_ERROR general error
 * @return SX_STATUS_NO_RESOURCES if configuration fails due to a lack of HW resources
 * @return SX_STATUS_MODULE_UNINITIALIZED - if API called without init
 */

sx_status_t flex_parser_transition_get(const sx_flex_parser_header_t curr_ph,
                                       sx_flex_parser_transition_t  *next_trans_p,
                                       uint32_t                     *next_trans_cnt_p);

sx_status_t flex_parser_flex_transition_set(const sx_access_cmd_t               cmd,
                                            sx_flex_parser_transition_index_t  *transition_index_p,
                                            sx_flex_parser_transition_action_t *transition_cfg_p);

sx_status_t flex_parser_flex_transition_get(const sx_flex_parser_transition_index_t transition_index,
                                            sx_flex_parser_transition_action_t     *transition_cfg_p);

sx_status_t flex_parser_fpp_set(const sx_access_cmd_t         cmd,
                                const sx_flex_parser_fpp_id_t fpp_id,
                                const sx_flex_parser_fpp_t   *fpp_cfg_p);

sx_status_t flex_parser_fpp_get(const sx_access_cmd_t         cmd,
                                const sx_flex_parser_fpp_id_t fpp_id,
                                sx_flex_parser_fpp_t         *fpp_cfg_p);

sx_status_t flex_parser_root_set(const sx_access_cmd_t                cmd,
                                 const uint32_t                       root_cfg_count,
                                 const sx_flex_parser_root_sop_cfg_t *root_cfg_list_p);

sx_status_t flex_parser_root_get(const sx_access_cmd_t          cmd,
                                 const sx_port_log_id_t         log_port,
                                 uint32_t                      *root_cfg_count_p,
                                 sx_flex_parser_root_sop_cfg_t *root_cfg_list_p);

sx_status_t flex_parser_hph_set(const sx_access_cmd_t         cmd,
                                const sx_flex_parser_hph_id_t hph_id,
                                const sx_flex_parser_hph_t   *hph_cfg_p);

sx_status_t flex_parser_hph_get(const sx_access_cmd_t         cmd,
                                const sx_flex_parser_hph_id_t hph_id,
                                sx_flex_parser_hph_t         *hph_cfg_p);

sx_status_t flex_parser_fexp_set(const sx_access_cmd_t     cmd,
                                 sx_flex_parser_fexp_id_t *fexp_id_p);

sx_status_t flex_parser_flex_graph_set(const sx_access_cmd_t          cmd,
                                       const uint32_t                 actions_cnt,
                                       sx_flex_parser_graph_action_t *actions_list_p);

sx_status_t flex_parser_hard_graph_set(const sx_access_cmd_t          cmd,
                                       const uint32_t                 actions_cnt,
                                       sx_flex_parser_graph_action_t *actions_list_p);

sx_status_t flex_parser_resources_get(const sx_access_cmd_t       cmd,
                                      sx_flex_parser_resources_t *flex_parser_resources_p);

sx_status_t flex_parser_reg_ext_point_set(sx_access_cmd_t        cmd,
                                          sx_register_key_t      reg_key,
                                          uint32_t               ext_point_cnt,
                                          sx_extraction_point_t *ext_point_list_p);

sx_status_t flex_parser_reg_ext_point_get(sx_access_cmd_t        cmd,
                                          sx_register_key_t      reg_key,
                                          uint32_t              *ext_point_cnt_p,
                                          sx_extraction_point_t *ext_point_list_p);

void flex_parser_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
#endif /*__FLEX_PARSER_BE_H_INCL__ */
