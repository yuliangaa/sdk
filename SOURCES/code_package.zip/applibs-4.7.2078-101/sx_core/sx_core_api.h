/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_CORE_API_H___E
#define __SX_CORE_API_H___E

#include <sx/sdk/sx_types.h>
#include "sx_core_td.h"
#include "sx_api/sx_api_internal.h"

/************************************************
 *  Local Defines
 ***********************************************/
/**
 * SX API maximum low priority buffer message size.
 */
#define MAX_STR_LEN (40)

/**
 * Boot mode attributes mask
 */
typedef enum sx_boot_mode_attr_mask {
    /* Chip reset is done with CTRL_CMD_PCI_REGISTER_DRIVER (as late as possible) */
    SX_BOOT_MODE_F_LATE_RESET = (1 << 0),

    /* Must NOT reset */
    SX_BOOT_MODE_F_NO_RESET = (1 << 1),

    /* Boot mode requires external resource manager before SDK init */
    SX_BOOT_MODE_F_EXT_RSRC_MGR = (1 << 2),

    /* Boot mode requires internal resource manager within SDK init */
    SX_BOOT_MODE_F_INT_RSRC_MGR = (1 << 3),

    /* Boot mode needs an ISSU initialization */
    SX_BOOT_MODE_F_NEEDS_ISSU_INIT = (1 << 4),

    /* CONFIG_PROFILE setting is not permitted */
    SX_BOOT_MODE_F_CONFIG_PROFILE_NOT_PERMITTED = (1 << 5)
} sx_boot_mode_attr_mask_e;

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
/**
 * sx_event_buffer_sizes_e indicates the sizes of all priority
 * buffers
 */
typedef enum {
    SX_CORE_HIGH_PRIO_BUFFER_SIZE_E = 256,
    SX_CORE_MED_PRIO_BUFFER_SIZE_E  = 4096,
    SX_CORE_LOW_PRIO_BUFFER_SIZE_E  = 20
} sx_event_buffer_sizes_e;

/************************************************
 *  Global variables
 ***********************************************/

extern boolean_t sx_core_api_initialized;

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function is used to validate reserved fields in PCI profile
 * @param[in] pci_profile - PCI profile
 *
 * @return SX_STATUS_SUCCESS operation completed successfully
 * @return SX_STATUS_PARAM_NULL PCI profile is not given
 * @return SX_STATUS_PARAM_ERROR reserved field didn't pass validation
 */
sx_status_t pci_profile_reserved_values_check_spectrum2(sx_api_pci_profile_t *pci_profile);

/**
 * This function is used to validate reserved fields in PCI profile
 * profile, as result we should not check them.
 * @param[in] pci_profile - PCI profile
 *
 * @return SX_STATUS_SUCCESS operation completed successfully
 */
sx_status_t pci_profile_reserved_values_no_check(sx_api_pci_profile_t *pci_profile);

/**
 * This function is used to validate reserved fields in device
 * profile for chip type spectrum
 * @param[in] profile - device profile
 *
 * @return SX_STATUS_SUCCESS operation completed successfully
 * @return SX_STATUS_PARAM_NULL device profile is not given
 * @return SX_STATUS_PARAM_ERROR reserved field didn't pass validation
 */
sx_status_t profile_reserved_values_check_spectrum(sx_api_profile_t *profile);

/**
 * This function is used to validate reserved fields in device
 * profile
 * @param[in] profile - device profile
 *
 * @return SX_STATUS_SUCCESS operation completed successfully
 * @return SX_STATUS_PARAM_NULL device profile is not given
 * @return SX_STATUS_PARAM_ERROR reserved field didn't pass validation
 */
sx_status_t profile_reserved_values_check_spectrum2(sx_api_profile_t *profile);

/**
 * This function is used to validate reserved fields in device
 * profile
 * @param[in] profile - device profile
 *
 * @return SX_STATUS_SUCCESS operation completed successfully
 * @return SX_STATUS_PARAM_NULL device profile is not given
 * @return SX_STATUS_PARAM_ERROR reserved field didn't pass validation
 */
sx_status_t profile_reserved_values_no_check(sx_api_profile_t *profile);

boolean_t sdk_sniffer_legacy_enable_check();

/**
 * This function sets the log verbosity level of CORE API MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sx_status_t core_api_log_verbosity_level(IN sx_access_cmd_t       cmd,
                                         IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function dispatch the SX-API command received at the
 *  event source and reply back to the client.
 *
 * @param[in] event - event source
 *
 * @return sx_status_t
 */
sx_status_t sx_core_api_dispatch(sx_core_td_event_src_t *event, uint8_t buffer_type);

/**
 *  This function deinit the SX SDK application libraries that
 *  were initialized previously by client command.
 *
 * @return sx_status_t
 */
sx_status_t sx_core_api_deinit(void);

/**
 * This function inserts a priority job into one of the priority
 * queue buffer. The job is the executed by worker thread
 *
 * @param[in] opcode - command opcode to execute
 * @param[in] buffer - buffer which contains the command
 * @param[in] cmd_size - the size of the command in the buffer
 * @param[in] buf_type - SX_CORE_LOW_PRIO_BUF_E
 *       /SX_CORE_MED_PRIO_BUF_E - the type of priority buffer
 *       used
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 * @return SX_STATUS_ERROR   general error
 * @return SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT the cmd_size is
 *              grater then maximum allowed
 * @return SX_STATUS_NO_RESOURCES
 */
sx_status_t sx_core_api_add_internal_job(uint32_t opcode, uint8_t *buffer, uint32_t cmd_size, uint8_t buf_idx);

sx_status_t sx_core_api_cmd_table_init(sxd_chip_types_t asic_type);

sx_status_t set_sdk_verbosity(sx_verbosity_level_t verbosity);

void sdk_init_params_debug_dump(dbg_dump_params_t* dbg_dump_params_p);
boolean_t is_fast_boot_mode(void);
sx_status_t sdk_init_resource_manager_main(sx_api_sx_sdk_init_t* sx_core_api_init_params,
                                           uint32_t              boot_mode_attr_mask,
                                           sx_log_cb_t           logging_cb);
sx_status_t sx_get_boot_mode_attr_mask(sx_boot_mode_e boot_mode,
                                       uint32_t      *boot_mode_attr_mask_p);

boolean_t sx_core_api_init_status_get(void);


static __attribute__((__used__)) const char* sx_swid_type_str[] = {
    "DONT CARE",
    "L2 TYPE IB",
    "L2 TYPE ETH",
    "L2 TYPE FC",
    "L2 TYPE ROUTER PORT"
};

#define SX_SWID_TYPE_STR_LEN (sizeof(sx_swid_type_str) / sizeof(char*))
#define SX_SWID_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SX_SWID_TYPE_STR_LEN - 1) ? \
     sx_swid_type_str[index] : "UNKNOWN")

static __attribute__((__used__)) const char* swid_type_str[] = {
    "DISABLED",
    "INFINIBAND",
    "ETHERNET",
    "ROUTER PORT",
};

#define SWID_TYPE_STR_LEN (sizeof(swid_type_str) / sizeof(char*))
#define SWID_TYPE_STR(index)                      \
    (SX_CHECK_MAX(index, SWID_TYPE_STR_LEN - 1) ? \
     swid_type_str[index] : "UNKNOWN")


#endif /* __SX_CORE_API_H___E */
