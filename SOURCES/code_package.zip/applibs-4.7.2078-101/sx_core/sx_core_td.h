/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_CORE_TD_H__
#define __SX_CORE_TD_H__

#include <complib/cl_types.h>
#include <complib/cl_commchnl.h>
#include <sx/sdk/sx_types.h>
#include "../sx_api/sx_api_internal.h"
#include <complib/cl_thread.h>
#include "../include/sx/utils/dbg_utils.h"
#include "../include/sx/utils/dbg_utils_pretty_printer.h"

/************************************************
 *  Local Defines
 ***********************************************/
#define SX_CORE_TD_WORKER_NUM 1

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/**
 * sx_core_prio_buffer_num_e enum is used to index different
 * priority buffer types
 */
typedef enum  {
    SX_CORE_LOW_PRIO_BUF_E = 0,
    SX_CORE_MED_PRIO_BUF_E,
    SX_CORE_HIGH_PRIO_BUF_E,

    SX_CORE_MIN_PRIO_BUF_E          = SX_CORE_LOW_PRIO_BUF_E,
    SX_CORE_MAX_PRIO_BUF_E          = SX_CORE_HIGH_PRIO_BUF_E,
    SX_CORE_MAX_NON_HIGH_PRIO_BUF_E = SX_CORE_MED_PRIO_BUF_E,

    SX_CORE_NUM_OF_PRIO_BUFS_E = (SX_CORE_MAX_PRIO_BUF_E + 1),
} sx_core_prio_buffer_num_e;

/* These weights were chosen such that Med = High Prio / 2 and Low = High / 4
 * In our SDK the LP queue is almost always  occupied, hence giving a higher priority
 * to the LP queue can sometimes lead to priority inversion */
typedef enum {
    SX_CORE_LOW_PRIO_WEIGHT_E  = 2,
    SX_CORE_MED_PRIO_WEIGHT_E  = 5,
    SX_CORE_HIGH_PRIO_WEIGHT_E = 10,
    SX_CORE_MIN_PRIO_WEIGHT_E  = SX_CORE_LOW_PRIO_WEIGHT_E,
    SX_CORE_MAX_PRIO_WEIGHT_E  = SX_CORE_HIGH_PRIO_WEIGHT_E
} sx_core_prio_buffer_weights_e;

typedef struct sx_core_worker_thread_prio_buf_context {
    cl_spinlock_t                 queue_lock_cons;
    cl_spinlock_t                 queue_lock_prod;
    sx_core_td_event_src_t      **work_queue;
    uint32_t                      work_queue_prod; /* iterator is used for adding new jobs to the work queue */
    uint32_t                      work_queue_read; /* iterator is used for reading jobs from the work queue */
    uint32_t                      work_queue_cons; /* iterator is used for freeing jobs from the work queue */
    uint32_t                      work_queue_size;
    sx_core_prio_buffer_weights_e prio_buff_weight;
} sx_core_worker_thread_prio_buf_context_t;


/**
 * sx_core_td_worker_data_t structure is used to store worker
 * threads data.
 */
typedef struct sx_core_td_worker_data {
    boolean_t                                active;
    cl_thread_t                              thread;
    int                                      work_queue_fd[2];  /* pipe fd for worker queue event */
    sx_core_worker_thread_prio_buf_context_t prio_buf_context[SX_CORE_NUM_OF_PRIO_BUFS_E];
    boolean_t                                worker_exit_signal_issued;
} sx_core_td_worker_data_t;

/**
 * sx_core_worker_thread_arb_t function is used for worker thread arbitrating
 *
 */
typedef sx_status_t (*sx_core_worker_thread_arb_t)(sx_core_td_worker_data_t **worker, uint8_t *cmd_body,
                                                   uint32_t cmd_body_size, uint32_t opcode);


/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
void sx_core_td_worker_arb_set_callback(sx_api_worker_arb_policy_t arb_policy);
sx_status_t sx_core_td_drop_counters_dbg_dump(dbg_dump_params_t *dbg_dump_params_p);


/************************************************
 *  API functions
 ***********************************************/

/**
 * This function sets the log verbosity level of CORE TD MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sx_status_t core_td_log_verbosity_level(IN sx_access_cmd_t       cmd,
                                        IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function initializes the various threads at the SDK
 *  core process.
 *
 * @return sx_status_t
 */
sx_status_t sx_core_td_init(void);

/**
 *  This function deinitializes the various threads at the SDK
 *  core process.
 *
 * @return sx_status_t
 */
sx_status_t sx_core_td_deinit(void);

/**
 *  This function run the main loop at the SDK core process.
 *
 * @return void
 */
void sx_core_td_start_loop(void);

/**
 *  This function exit the main loop at the SDK core process.
 *
 * @return sx_status_t
 */
sx_status_t sx_core_td_exit_loop(void);

/**
 * This function inserts a priority job into one of the priority
 * queue buffer. The job is the executed by worker thread
 *
 * @param[in] opcode - command opcode to execute
 * @param[in] buffer - buffer which contains the command
 * @param[in] cmd_size - the size of the command in the buffer
 * @param[in] buf_type - SX_CORE_LOW_PRIO_BUF_E
 *       /SX_CORE_MED_PRIO_BUF_E - the type of priority buffer
 *       used
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 * @return SX_STATUS_ERROR   general error
 * @return SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT the cmd_size is
 *              grater then maximum allowed
 * @return SX_STATUS_NO_RESOURCES
 */
sx_status_t sx_core_td_add_internal_job_to_queue(uint32_t opcode, uint8_t *buffer, uint32_t cmd_size,
                                                 uint8_t buf_type);

/**
 * This function increases consumer iterator for given prio
 * buffer
 *
 * @param[in] buffer_type - the type of priority buffer:
 *       SX_CORE_LOW_PRIO_BUF_E / SX_CORE_MED_PRIO_BUF_E /
 *       SX_CORE_HIGH_PRIO_BUF_E
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 * @return SX_STATUS_ERROR   general error
 */
sx_status_t sx_core_td_increase_consumer(sx_core_prio_buffer_num_e buffer_type);

#endif /* __SX_CORE_TD_H__ */
