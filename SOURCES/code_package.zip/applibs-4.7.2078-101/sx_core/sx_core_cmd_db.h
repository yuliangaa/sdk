/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SX_CORE_CMD_DB_H__
#define __SX_CORE_CMD_DB_H__


#include <complib/cl_qmap.h>
#include <complib/cl_passivelock.h>

#include <sx/sdk/sx_api.h>

#include "sx_api/sx_api_internal.h"


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef enum {
    SX_CORE_CMD_DB_GET_E,
    SX_CORE_CMD_DB_SET_E,
} sx_cmd_db_op_e;

typedef struct sx_core_cmd_db_data {
    cl_qmap_t        cmd_map;
    cl_plock_t       cmd_db_mutex;
    sxd_chip_types_t asic_type;
} sx_core_cmd_db_data_t;

typedef enum {
    SX_API_CMD_PRIO_LOW_E = 0,
    SX_API_CMD_PRIO_MEDIUM_E,
    SX_API_CMD_PRIO_HIGH_E,
} sx_api_cmd_priority_e;

typedef enum {
    SX_API_PROTOCOL_COMMON_E = 0,
    SX_API_PROTOCOL_ETH_E,
    SX_API_PROTOCOL_IB_E,
} sx_api_cmd_type_e;

typedef sx_status_t (*api_command_fp_t)(sx_core_td_event_src_t *, uint8_t *, uint32_t);

typedef struct sx_api_command {
    sx_api_int_cmd_e      cmd_id;        /* enum representing command								*/
    char                  name[100];         /* command name for logging purpose						*/
    api_command_fp_t      func;          /* func pointer											*/
    sx_api_cmd_type_e     protocol;      /* enum representing protocol such as ETH,IB,chip_mng		*/
    sx_api_cmd_priority_e priority;      /* priority within thread                                   */
    uint64_t              supported_asic_types; /* bitmap of ASICs on which this API is supported */
} sx_api_command_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
/*********************************************************************************************************/
/*************** Command DB initialization  **************************************************************/
/*********************************************************************************************************/
sx_status_t sx_core_init_command_db();
sx_status_t sx_core_deinit_command_db();
void sx_core_cmd_db_set_chip_type(sxd_chip_types_t asic_type);

/*********************************************************************************************************/
/*************** Command DB Access commands **************************************************************/
/*********************************************************************************************************/
sx_status_t sx_core_get_api_command_name(sx_api_int_cmd_e cmd_id, const char **cmd_name);
sx_status_t sx_core_get_api_command(sx_api_int_cmd_e cmd_id, sx_api_command_t *cmd_data);
sx_status_t sx_core_set_api_command(const sx_api_command_t *cmd_data);
/*********************************************************************************************************/
/*************** Command DB dump            **************************************************************/
/*********************************************************************************************************/
sx_status_t sx_core_cmd_db_dump_entries(int max_entries, sx_api_int_cmd_e last_command);

#endif /* ifndef __SX_CORE_CMD_DB_H__ */
