/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#define _MODULE_SX_CORE_TD_


#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <complib/cl_math.h>
#include <complib/cl_list.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_event.h>
#include <complib/cl_thread.h>
#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include "complib/cl_timer.h"
#include <complib/cl_dbg.h>

#include <sx/utils/debug_cmd.h>

#include "sx_core_td.h"
#include "sx_core_api.h"
#include "sx_core_cmd_db.h"
#include "sx_core_async.h"
#include "ethl2/fdb_uc_impl.h"
#include "dbg/dbg.h"

#undef  __MODULE__
#define __MODULE__ CORE_TD


/************************************************
 *  Type definitions
 ***********************************************/

/* 100 sec because TD worker thread run debug dump that can take around 40 sec*/
#define TD_WORKER_THREAD_HEALTH_MONITOR_MAX_ALLOWED_TIME 100

/**
 * this structure is used to store event
 * sources set of file descriptors.
 */
typedef struct sx_core_td_event_srcs_fd {
    fd_set fds;
    int    max_fd;
} sx_core_td_event_srcs_fd_t;

typedef struct sx_core_td_drop_counters {
    uint32_t fdb_poll_cnt;   /* drop SX_API_INT_CMD_FDB_POLL_SET_E job */
    uint32_t psort_bg_cnt;           /* drop SX_API_INT_CMD_PSORT_BACKGROUND_SET_E job */
    uint32_t ecmp_bg_cnt;         /* drop SX_API_INT_CMD_ECMP_BACKGROUND_SET_E) */
    uint32_t load_balancing_bg_cnt;         /* drop SX_API_INT_CMD_ECMP_LOAD_BALANCING_BACKGROUND_SET_E) */
    uint32_t ba_bg_cnt;         /* drop SX_API_INT_CMD_BA_BACKGROUND_SET_E */
    uint32_t gc_activate_bg_cnt;         /* drop SX_API_INT_CMD_GC_ACTIVATE_BACKGROUND_SET_E */
    uint32_t mc_container_bg_cnt;         /* drop SX_API_INT_CMD_MC_CONTAINER_BACKGROUND_SET_E */
    uint32_t gc_post_queue_cnt;         /* drop SX_API_INT_CMD_GC_HANDLE_POST_QUEUE_SET_E */
    uint32_t atcam_erp_opt_cnt;         /* drop SX_API_INT_CMD_ATCAM_ERP_OPTIMIZE_E */
    uint32_t port_profile_apply_cnt;    /* drop SX_API_INT_CMD_PORT_PROFILE_APPLY_JOB_PROCESS_E */
    uint32_t oper_status_event_cnt;     /* drop SX_API_INT_CMD_PORT_OPER_STATUS_EVENT_INT_E */
} sx_core_td_drop_counters;

/*************************************************
 *  Global variables
 ************************************************/

/* global variable because there is no API to control this variable */
sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

extern sx_api_sx_sdk_versions_t sx_core_versions;
extern sx_core_async_fd_t       core_async_fds;
sx_api_worker_arb_policy_t      worker_thread_arb_policy;
sx_core_worker_thread_arb_t     worker_arb_method;
sx_api_command_t                api_cmd;

/*************************************************
 *  Local variables
 ************************************************/
static cl_commchnl_t              sx_api_commchnl_s;
static sx_core_td_event_src_t     high_prio_event_srcs_s[SX_CORE_HIGH_PRIO_BUFFER_SIZE_E];
static sx_core_td_event_src_t    *med_low_prio_event_buffer_s[SX_CORE_NUM_OF_PRIO_BUFS_E];
static cl_spinlock_t              event_src_state_lock_s;
static sx_core_td_event_srcs_fd_t event_srcs_fd_s;
static int                        event_quit_fd_s[2];
sx_core_td_worker_data_t          td_worker[SX_CORE_TD_WORKER_NUM];
static sx_core_td_drop_counters   drop_counters_s;


/************************************************
 *  Local function declarations
 ***********************************************/
static void __sx_core_td_worker_thread(void *context);
static void __client_handler(uint32_t idx);
static void __accept_connection(uint32_t idx);
static void __init_event_src(sx_core_td_event_src_t        *src,
                             cl_commchnl_t                 *commchnl,
                             const char                    *desc,
                             sx_core_td_event_src_handler_t handler);
static sx_status_t __add_event_src(cl_commchnl_t                 *commchnl,
                                   const char                    *desc,
                                   sx_core_td_event_src_handler_t handler);
static void __close_event_src(sx_core_td_event_src_t *event);
static sx_status_t __select_event(void);
static void __update_fd_sets(void);
static sx_status_t __open_sx_worker_td(void);
static sx_status_t __open_sx_api_commchnl(void);
typedef struct {
    boolean_t   exit_signal_issued;
    cl_thread_t thread_h;
} g_hc_thread_t;
static g_hc_thread_t g_hc_thread;

void sx_core_async_debug_cmd_handler(void);

#define FD_SET_AND_UPDATE_MAX(fd, async_fds) \
    if ((fd) != -1) {                        \
        FD_SET((fd), &(async_fds)->fds);     \
        if ((fd) > (async_fds)->max_fd) {    \
            (async_fds)->max_fd = (fd);      \
        }                                    \
    }

#define LOW_MED_BUF_THRESHOLD 0.7
/************************************************
 *  Function implementations
 ***********************************************/
static void __sx_core_td_worker_thread(void *context)
{
    int32_t                                   worker_index = (int32_t)(uintptr_t)context;
    sx_core_td_worker_data_t                 *data = &(td_worker[worker_index]);
    sx_core_td_event_src_t                   *event = NULL;
    sx_api_command_head_t                    *cmd_head = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;
    int                                       buff_idx = SX_CORE_MIN_PRIO_BUF_E;
    sx_core_worker_thread_prio_buf_context_t *prio_buf;
    int                                       dbg_cmd_fd = 0;
    int32_t                                   ret = 0;
    int32_t                                   bytes = 0;
    int32_t                                   result = 0;
    boolean_t                                 waked_from_select = FALSE;
    boolean_t                                 is_async_api = FALSE;
    uint32_t                                  prio_idx = 0;
    boolean_t                                 api_dispatched = FALSE;
    uint32_t                                  loop_count = 0;
    int                                       buff_idx_loop = 0;
    int                                       last_buff_idx = 0;
    int                                       hc_fd = -1;
    cl_dbg_bp_ctl_db_entry_t                 *bp_ctl_db_entry_p = NULL;

    SX_LOG_ENTER();


    if (sx_utils_debug_cmd_get_fd(&dbg_cmd_fd) != SX_UTILS_STATUS_SUCCESS) {
        dbg_cmd_fd = -1;
        SX_LOG_ERR("Debug Command-line is not initialized!\n");
    }

    /* Set work queue fd to fd set of core async to handle api call and completion together */
    err = sx_core_async_set_fds(td_worker[worker_index].work_queue_fd);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at  sx_core_async_set_fds\n");
        goto out;
    }
    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, TRUE);

    if (bp_ctl_db_entry_p != NULL) {
        hc_fd = bp_ctl_db_entry_p->health_check_fd;
    }

    while (TRUE) {
        FD_SET_AND_UPDATE_MAX(dbg_cmd_fd, &core_async_fds);
        /* This code related to Health check Thread monitor. Indicate once this thread is a live*/

        FD_SET_AND_UPDATE_MAX(hc_fd, &core_async_fds);


        cl_fd_wait_on(core_async_fds.max_fd, &core_async_fds.fds, &core_async_fds.fds_err, NULL, &ret);
        if (ret < 0) {
            SX_LOG_ERR("Error in cl_fd_wait_on while calling select\n");
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &core_async_fds.fds, TRUE);
            goto out;
        }
        /* In case hc_fd is triggered this function will update that this thread is alive */
        if (hc_fd >= 0) {
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &core_async_fds.fds, FALSE);
        }
        waked_from_select = TRUE;
        cl_dbg_bp_ctl_thread_sync(&bp_ctl_db_entry_p);


        /* check if time to die */
        if (td_worker[worker_index].worker_exit_signal_issued == TRUE) {
            SX_LOG_DBG("Thread __sx_core_td_worker_thread (index %d) is gracefully ending.\n", worker_index);
            goto out;
        }

        if (FD_ISSET(dbg_cmd_fd, &core_async_fds.fds)) {
            sx_core_async_debug_cmd_handler();
        }

        if (FD_ISSET(td_worker[worker_index].work_queue_fd[0], &core_async_fds.fds_err)) {
            SX_LOG(SX_LOG_ERROR, "Receive error on work thread fd [%d]: %s\n",
                   td_worker[worker_index].work_queue_fd[0],
                   strerror(errno));
        } else if (FD_ISSET(td_worker[worker_index].work_queue_fd[0], &core_async_fds.fds)) {
            /* The socket_fd has data available to be read */
            /* Read from work_queue_fd to block pipe again */
            result = read(td_worker[worker_index].work_queue_fd[0], &bytes, sizeof(bytes));
            if (result == 0) {
                /* This means the other side closed the socket */
                close(td_worker[worker_index].work_queue_fd[0]);
                SX_LOG(SX_LOG_ERROR,
                       "Thread __sx_core_td_worker_thread (index %d) Failed to read work queue fd. remote side closed the socket [bytes=%d, errno=%s]\n",
                       worker_index,
                       bytes,
                       strerror(errno));
                err = SX_STATUS_ERROR;
                goto out;
            }
            api_dispatched = FALSE;
            loop_count = 0;
            /* Loop over all priorities */
            while (loop_count++ < (SX_CORE_MAX_PRIO_WEIGHT_E + 1)) {
                /* Break if API was handled, we want to read from the socket again*/
                if (api_dispatched) {
                    break;
                }
                /* Priority determines which queue can be taken next*/
                prio_idx = (prio_idx + 1) % (SX_CORE_MAX_PRIO_WEIGHT_E + 1);

                for (buff_idx_loop = 0; buff_idx_loop < SX_CORE_NUM_OF_PRIO_BUFS_E; buff_idx_loop++) {
                    /* Ensure we start from the next buffer on the next read */
                    buff_idx = (buff_idx_loop + last_buff_idx + 1) % SX_CORE_NUM_OF_PRIO_BUFS_E;
                    prio_buf = &(data->prio_buf_context[buff_idx]);

                    /* No need to lock lock_prod - if you miss this time, you can read the job next round
                     * cl_spinlock_acquire(&(prio_buf->queue_lock_prod)); */
                    /* If there is something to read from this buffer & Priority allows then process it */
                    if ((prio_buf->work_queue_read != prio_buf->work_queue_prod) &&
                        (prio_buf->prio_buff_weight >= prio_idx)) {
                        /* No need to release lock_prod
                         * cl_spinlock_release(&(prio_buf->queue_lock_prod)); */

                        SX_LOG(SX_LOG_FRAMES,
                               "Event #%u buffer #%u taken by worker thread #%u\n",
                               prio_buf->work_queue_read,
                               buff_idx,
                               0);
                        event = prio_buf->work_queue[prio_buf->work_queue_read];
                        api_dispatched = TRUE;
                        last_buff_idx = buff_idx;
                        cmd_head = (sx_api_command_head_t*)(event->buffer);

                        if (cmd_head == NULL) {
                            SX_LOG_ERR(
                                "__sx_core_td_worker_thread: cmd_head is NULL, skip it. buff_idx=%d, read=%d, prod=%d\n",
                                buff_idx,
                                prio_buf->work_queue_read,
                                prio_buf->work_queue_prod);

                            cl_spinlock_acquire(&(prio_buf->queue_lock_cons));
                            prio_buf->work_queue_read = (prio_buf->work_queue_read + 1) % prio_buf->work_queue_size;
                            cl_spinlock_release(&(prio_buf->queue_lock_cons));

                            err = sx_core_td_increase_consumer(buff_idx);
                            if (err != SX_STATUS_SUCCESS) {
                                SX_LOG_ERR("Failed to increase consumer for prio buff [idx=%u] n\n", buff_idx);
                            }
                            continue;
                        }

                        err = sx_core_is_api_command_async(cmd_head->opcode,
                                                           &is_async_api);
                        if (err != SX_STATUS_SUCCESS) {
                            SX_LOG(SX_LOG_INFO, "SX-API client command %u is not supported\n", cmd_head->opcode);

                            cl_spinlock_acquire(&(prio_buf->queue_lock_cons));
                            prio_buf->work_queue_read = (prio_buf->work_queue_read + 1) % prio_buf->work_queue_size;
                            cl_spinlock_release(&(prio_buf->queue_lock_cons));

                            /* Increase the consumer to free space in the ring buffer */
                            err = sx_core_td_increase_consumer(buff_idx);
                            if (err != SX_STATUS_SUCCESS) {
                                SX_LOG_ERR("Failed to increase consumer for prio buff [idx=%u] n\n", buff_idx);
                            }
                            continue;
                        }

                        /* Mark flag not to wait in select loop in order to continue read elements from the high,medium and low buffers */
                        err = sx_core_api_dispatch(event, (uint8_t)buff_idx);
                        switch (err) {
                        case SX_STATUS_SUCCESS:
                            SX_LOG(SX_LOG_FRAMES, "SX-API request completed\n");
                            break;

                        case SX_STATUS_ACCEPTED:
                            SX_LOG(SX_LOG_FRAMES, "SX-API request accepted\n");
                            break;

                        case SX_STATUS_ISSU_IN_PROGRESS:
                            SX_LOG(SX_LOG_NOTICE,
                                   "SX-API client call while ISSU in progress , error : [%s]\n",
                                   sx_status_str(err));
                            break;

                        case SX_STATUS_INT_COMM_CLOSE:
                            SX_LOG(SX_LOG_INFO, "SX-API client closed , error : [%s]\n", sx_status_str(err));
                            __close_event_src(event);
                            break;

                        case SX_STATUS_COMM_ERROR:
                            SX_LOG(SX_LOG_ERROR, "SX-API client closed , error : [%s]\n", sx_status_str(err));
                            __close_event_src(event);
                            break;

                        default:
                            SX_LOG(SX_LOG_ERROR, "SX-API client closed , UNEXPECTED error : %d[%s]\n", err,
                                   sx_status_str(err));
                            /* __close_event_src(event); */
                        }

                        /*
                         * If SDK client is closed, then process the relevant adviser event.
                         */
                        if ((err != SX_STATUS_SUCCESS) &&
                            (err != SX_STATUS_ACCEPTED) &&
                            sx_core_api_initialized) {
                            err = adviser_process_event(ADVISER_EVENT_POST_SDK_CLIENT_CLOSE_E, &(event->sender_pid));
                            if (SX_CHECK_FAIL(err)) {
                                SX_LOG_ERR("Failed to process adviser event '%s'.\n",
                                           ADVISER_EVENT_STR(ADVISER_EVENT_POST_SDK_CLIENT_CLOSE_E));
                            }
                        }

                        cl_spinlock_acquire(&(prio_buf->queue_lock_cons));
                        prio_buf->work_queue_read = (prio_buf->work_queue_read + 1) % prio_buf->work_queue_size;
                        cl_spinlock_release(&(prio_buf->queue_lock_cons));

                        if (is_async_api == FALSE) {
                            /* Sync job is handled at this point, increase the consumer */
                            err = sx_core_td_increase_consumer(buff_idx);
                            if (err != SX_STATUS_SUCCESS) {
                                SX_LOG_ERR("Failed to increase consumer for prio buff [idx=%u] n\n", buff_idx);
                            }
                        }

                        SX_LOG(SX_LOG_FRAMES,
                               "Work queue for buffer %u prio %u(prod, read, cons) - (%u, %u, %u)\n",
                               buff_idx,
                               prio_idx,
                               prio_buf->work_queue_prod,
                               prio_buf->work_queue_read,
                               prio_buf->work_queue_cons);
                        /* Once handled break out of both loops so we read from socket again */
                        break;
                    }
                    /* No need to release lock
                     *  else
                     *  {
                     *   cl_spinlock_release(&(prio_buf->queue_lock_prod));
                     *  }*/
                }  /* for */
            } /* prio loop */
        }

        /* Handle case... of no select and we need to read ... */
        err = sx_core_async_handle_completion(waked_from_select);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at handling completion fds.\n");
        }

        waked_from_select = FALSE;


        /* check if time to die */
        if (td_worker[worker_index].worker_exit_signal_issued == TRUE) {
            SX_LOG_DBG("Thread __sx_core_td_worker_thread (index %d) is gracefully ending.\n", worker_index);
            goto out;
        }

        /* Set work queue fd to fd set of core async to handle api call and completion together */
        err = sx_core_async_set_fds(td_worker[worker_index].work_queue_fd);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at  sx_core_async_set_fds\n");
            goto out;
        }
    } /* forever */
out:
    FD_CLR(td_worker[worker_index].work_queue_fd[0], &core_async_fds.fds);
    FD_CLR(td_worker[worker_index].work_queue_fd[0], &core_async_fds.fds_err);
    SX_LOG_EXIT();
    return;
}

static sx_status_t sx_core_worker_thread_fixed_arb(sx_core_td_worker_data_t** worker,
                                                   uint8_t                   *cmd_body,
                                                   uint32_t                   cmd_body_size,
                                                   uint32_t                   opcode)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(cmd_body);
    UNUSED_PARAM(cmd_body_size);
    UNUSED_PARAM(opcode);

    *worker = &td_worker[0];

    return err;
}

void sx_core_td_worker_arb_set_callback(sx_api_worker_arb_policy_t arb_policy)
{
    worker_thread_arb_policy = arb_policy;

    worker_arb_method = sx_core_worker_thread_fixed_arb;
}

static void __client_handler(uint32_t idx)
{
    sx_core_td_event_src_t                   *event = &high_prio_event_srcs_s[idx];
    sx_core_td_worker_data_t                 *worker_td = NULL;
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                    *close_cmd = NULL;
    sx_api_command_head_t                    *cmd_head = NULL;
    sx_api_command_t                          cmd_data;
    sx_core_worker_thread_prio_buf_context_t *prio_buf;
    int32_t                                   bytes = 0;
    int32_t                                   result = 0;
    boolean_t                                 is_async_api = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(cmd_data);

    if (event->buffer) {
        CL_FREE_N_NULL(event->buffer);
    }

    err = sx_api_receive_command(&(event->commchnl), &(event->buffer), &(event->pos));

    if (err == SX_STATUS_CMD_INCOMPLETE) {
        goto out;
    } else if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_DEBUG, "Failed to receive from client, Disconnecting...\n");
        /* Insert msg to close event src. Will be done by Worker thread.*/
        cl_spinlock_acquire(&event_src_state_lock_s);
        event->state = SX_EVENT_SRC_STATE_TERMINATING_E;
        __update_fd_sets();
        cl_spinlock_release(&event_src_state_lock_s);
        close_cmd = (sx_api_command_head_t*)event->buffer;
        close_cmd->opcode = SX_API_INT_CMD_CLOSE_EVENT_SRC_E;
        close_cmd->version = SX_API_INT_VERSION;
        close_cmd->msg_size = sizeof(sx_api_command_head_t);
        close_cmd->list_size = 0;
    }

    cmd_head = (sx_api_command_head_t*)event->buffer;

    if (cmd_head->opcode != SX_API_INT_CMD_CLOSE_EVENT_SRC_E) {
        err = sx_core_is_api_command_async(cmd_head->opcode,
                                           &is_async_api);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_INFO, "SX-API client command %u is not supported\n", cmd_head->opcode);
            err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
            goto out;
        }

        if (is_async_api != TRUE) {
            err = sx_core_get_api_command(cmd_head->opcode, &cmd_data);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_INFO, "SX-API client command %u is not supported\n", cmd_head->opcode);
                err = sx_api_send_reply_wrapper(&(event->commchnl), SX_STATUS_CMD_ERROR, NULL, 0);
                goto out;
            }
        } else {
            cmd_data.priority = SX_API_CMD_PRIO_HIGH_E;
        }
    } else {
        cmd_data.priority = SX_API_CMD_PRIO_HIGH_E;
    }

    err = worker_arb_method(&worker_td, event->buffer + sizeof(sx_api_command_head_t),
                            cmd_head->msg_size - sizeof(sx_api_command_head_t), cmd_head->opcode);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SX-API worker arbitration failed\n");
        goto out;
    }

    prio_buf = &(worker_td->prio_buf_context[cmd_data.priority]);

    cl_spinlock_acquire(&(prio_buf->queue_lock_prod));

    prio_buf->work_queue[prio_buf->work_queue_prod] = &(high_prio_event_srcs_s[idx]);
    SX_LOG(SX_LOG_FRAMES, "Event #%u passed into worker thread #%u\n", idx, 0);

    prio_buf->work_queue_prod = (prio_buf->work_queue_prod + 1) % prio_buf->work_queue_size;
    SX_LOG(SX_LOG_FRAMES, "Work queue (prod, read, cons) - (%u, %u, %u)\n",
           prio_buf->work_queue_prod,
           prio_buf->work_queue_read,
           prio_buf->work_queue_cons);

    cl_spinlock_release(&(prio_buf->queue_lock_prod));

    /* Write to work_queue_fd to signal pipe */
    bytes = 1;
    result = write(worker_td->work_queue_fd[1], &bytes, sizeof(bytes));
    if (result != sizeof(bytes)) {
        SX_LOG(SX_LOG_ERROR, "Failed to write to work queue fd [bytes=%d, errno=%s].\n", bytes, strerror(errno));
        err = SX_STATUS_ERROR;
    }

out:
    SX_LOG_EXIT();
    return;
}

static sx_status_t __open_device(int *fd_p)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    int             rc = 0;
    char           *dev_name[1];
    uint32_t        dev_num = 1;
    sxd_ctrl_pack_t ctrl_pack;

    SX_LOG_ENTER();

    SX_MEM_CLR(ctrl_pack);
    SX_MEM_CLR_BUF(dev_name, sizeof(dev_name));

    dev_name[0] = cl_calloc(MAX_NAME_LEN, sizeof(*(dev_name[0])));
    if (!dev_name[0]) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for device name\n");
        goto out;
    }

    /* get device list from the devices directory */
    rc = sxd_get_dev_list(dev_name, &dev_num);
    if (rc != 0) {
        SX_LOG_ERR("Failed to get device list, errno = [%s]\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    /* open the first device */
    rc = sxd_open_device_ext(dev_name[0], fd_p);
    if (rc != 0) {
        SX_LOG_ERR("Failed to open device, errno = [%s]\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

out:
    if (dev_name[0]) {
        cl_free(dev_name[0]);
    }
    SX_LOG_EXIT();
    return err;
}

static void __accept_connection(uint32_t idx)
{
    sx_core_td_event_src_t *event = &high_prio_event_srcs_s[idx];
    cl_commchnl_t           commchnl_client = {0};
    cl_status_t             cl_err = CL_SUCCESS;
    sx_status_t             err = SX_STATUS_SUCCESS;
    uint32_t                len;
    int                     fd = -1;
    int                     sxd_err = 0;
    boolean_t               device_opened = FALSE;
    boolean_t               commchnl_accepted = FALSE;

    SX_LOG_ENTER();

    cl_err = cl_commchnl_accept(&(event->commchnl), &commchnl_client);

    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_WARNING, "Failed accepting new connection: %s\n", strerror(errno));
        goto out;
    }
    commchnl_accepted = TRUE;

    err = __add_event_src(&commchnl_client, "SX-API client", __client_handler);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_WARNING, "Could not add SX-API client communication channel into event array\n");
        goto out;
    }

    err = __open_device(&fd);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to open device, err = [%s]\n", sx_status_str(err));
        goto out;
    }
    device_opened = TRUE;

    /* two-way handshake*/
    len = sizeof(sx_core_versions);
    cl_err = cl_commchnl_send_fd(&commchnl_client, (uint8_t*)&sx_core_versions,
                                 &len, fd);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_WARNING, "Failed sending to new connection: %s\n",
               strerror(errno));
        goto out;
    }

    SX_LOG(SX_LOG_DEBUG, "New connection accepted\n");

out:
    if (SX_CHECK_FAIL(err)) {
        if (commchnl_accepted) {
            cl_commchnl_destroy(&commchnl_client);
        }
    }
    if (device_opened) {
        sxd_err = sxd_close_device_ext(fd);
        if (sxd_err != 0) {
            SX_LOG_ERR("Failed to close FD %d, sxd_err = [%d], errno = [%s]\n",
                       fd, sxd_err, strerror(errno));
        }
    }
    SX_LOG_EXIT();
    return;
}

static sx_status_t __init_quit_event_src()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* create termination for thread */
    if (pipe(event_quit_fd_s) == -1) {
        err = SX_STATUS_ERROR;
        goto out;
    }

    cl_spinlock_acquire(&event_src_state_lock_s);
    __update_fd_sets();
    cl_spinlock_release(&event_src_state_lock_s);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __deinit_quit_event_src()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    close(event_quit_fd_s[0]);
    close(event_quit_fd_s[1]);

    SX_LOG_EXIT();
    return err;
}

static void __init_event_src(sx_core_td_event_src_t        *event,
                             cl_commchnl_t                 *commchnl,
                             const char                    *desc,
                             sx_core_td_event_src_handler_t handler)
{
    SX_LOG_ENTER();

    event->pos = 0;
    event->desc = desc;
    event->commchnl = *commchnl;
    event->handler = handler;
    event->state = SX_EVENT_SRC_STATE_ACTIVE_E;

    SX_LOG_EXIT();
}

static sx_status_t __add_event_src(cl_commchnl_t *commchnl, const char *desc, sx_core_td_event_src_handler_t handler)
{
    int         i;
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    cl_spinlock_acquire(&event_src_state_lock_s);

    for (i = 0; i < SX_CORE_HIGH_PRIO_BUFFER_SIZE_E; ++i) {
        if (high_prio_event_srcs_s[i].state == SX_EVENT_SRC_STATE_NOT_ACTIVE_E) {
            __init_event_src(high_prio_event_srcs_s + i, commchnl, desc, handler);
            __update_fd_sets();
            goto out;
        }
    }

    err = SX_STATUS_NO_RESOURCES;

out:
    cl_spinlock_release(&event_src_state_lock_s);
    SX_LOG_EXIT();
    return err;
}

static void __close_event_src(sx_core_td_event_src_t *event)
{
    SX_LOG_ENTER();

    cl_spinlock_acquire(&event_src_state_lock_s);

    if (event->state != SX_EVENT_SRC_STATE_NOT_ACTIVE_E) {
        cl_commchnl_destroy(&(event->commchnl));
        event->state = SX_EVENT_SRC_STATE_NOT_ACTIVE_E;
        __update_fd_sets();
    }

    if (event->buffer) {
        CL_FREE_N_NULL(event->buffer);
    }

    cl_spinlock_release(&event_src_state_lock_s);

    SX_LOG_EXIT();
}

static sx_status_t __select_event()
{
    fd_set      fds_in;
    fd_set      fds_err;
    int         i = 0, ret = 0, max_fd = 0;
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    cl_spinlock_acquire(&event_src_state_lock_s);
    memcpy(&fds_in, &event_srcs_fd_s.fds, sizeof(fds_in));
    memcpy(&fds_err, &event_srcs_fd_s.fds, sizeof(fds_err));
    max_fd = event_srcs_fd_s.max_fd;
    cl_spinlock_release(&event_src_state_lock_s);

    ret = select(max_fd + 1, &fds_in, NULL, &fds_err, NULL);
    if (ret > 0) {
        /* Check if it is time to quit */
        if (FD_ISSET(event_quit_fd_s[0], &fds_in) || FD_ISSET(event_quit_fd_s[0], &fds_err)) {
            SX_LOG_NTC("SX Core main loop exit.\n");
            err = SX_STATUS_ERROR;
            goto out;
        }

        for (i = 0; i < SX_CORE_HIGH_PRIO_BUFFER_SIZE_E; ++i) {
            int commchnl_fd = 0;

            if (high_prio_event_srcs_s[i].state != SX_EVENT_SRC_STATE_ACTIVE_E) {
                continue;
            }

            commchnl_fd = cl_commchnl_get_fd(&(high_prio_event_srcs_s[i].commchnl));
            if (FD_ISSET(commchnl_fd, &fds_err)) {
                SX_LOG(SX_LOG_ERROR, "Receive error on %s communication channel: %s\n",
                       high_prio_event_srcs_s[i].desc,
                       strerror(errno));
            } else if (FD_ISSET(commchnl_fd, &fds_in)) {
                SX_LOG(SX_LOG_FRAMES, "Receive event on %s communication channel\n",
                       high_prio_event_srcs_s[i].desc);
                high_prio_event_srcs_s[i].handler(i);
            }
        }
    } else if (ret == -1) {
        if (errno == EINTR) {
            SX_LOG(SX_LOG_DEBUG, "Select system call was interrupted\n");
        } else {
            SX_LOG(SX_LOG_ERROR, "Select failed: %s\n", strerror(errno));
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}


static void __sx_core_hc_monitor_init_thread(void *context)
{
    UNUSED_PARAM(context);

    cl_dbg_bp_ctl_db_entry_t *bp_ctl_db_entry_p = NULL;

    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, TRUE);


    while (TRUE) {
        sleep(SX_DBG_HEALTH_PERIODIC_TIME_DEFAULT / 1000);
        if (g_hc_thread.exit_signal_issued == TRUE) {
            SX_LOG_NTC(
                "Thread __sx_core_hc_monitor_init_thread is gracefully ending.\n");
            return;
        }

        if (TRUE == fatal_failure_detection_active_get()) {
            dbg_health_check_monitor_sdk_threads();
        }
    }
}
/* MUST BE CALLED WHEN event_src_state_lock_s IS LOCKED! */
static void __update_fd_sets(void)
{
    int i = 0;

    SX_LOG_ENTER();

    FD_ZERO(&(event_srcs_fd_s.fds));
    event_srcs_fd_s.max_fd = 0;

    for (i = 0; i < SX_CORE_HIGH_PRIO_BUFFER_SIZE_E; ++i) {
        if (high_prio_event_srcs_s[i].state == SX_EVENT_SRC_STATE_ACTIVE_E) {
            int commchnl_fd = cl_commchnl_get_fd(&(high_prio_event_srcs_s[i].commchnl));
            FD_SET((unsigned int)commchnl_fd, &(event_srcs_fd_s.fds));
            event_srcs_fd_s.max_fd = MAX(event_srcs_fd_s.max_fd, commchnl_fd);
        }
    }

    FD_SET((unsigned int)event_quit_fd_s[0], &(event_srcs_fd_s.fds));
    event_srcs_fd_s.max_fd = MAX(event_srcs_fd_s.max_fd, event_quit_fd_s[0]);

    SX_LOG_EXIT();
}

static sx_status_t __open_sx_worker_td()
{
    uint32_t                                  i, j = 0;
    cl_status_t                               cl_err = CL_SUCCESS;
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_core_prio_buffer_num_e                 buff_idx;
    sx_core_worker_thread_prio_buf_context_t *prio_buf;

    SX_LOG_ENTER();

    memset(td_worker, 0, sizeof(td_worker));

    for (i = 0; i < SX_CORE_TD_WORKER_NUM; ++i) {
        /* Init pipe fd for td worker */
        if (pipe(td_worker[i].work_queue_fd) < 0) {
            SX_LOG(SX_LOG_ERROR, "Could not initialize work queue pipe fd\n");
            err = SX_STATUS_ERROR;
            goto out;
        }

        td_worker[i].prio_buf_context[SX_CORE_HIGH_PRIO_BUF_E].work_queue_size = SX_CORE_HIGH_PRIO_BUFFER_SIZE_E;
        td_worker[i].prio_buf_context[SX_CORE_MED_PRIO_BUF_E].work_queue_size = SX_CORE_MED_PRIO_BUFFER_SIZE_E;
        td_worker[i].prio_buf_context[SX_CORE_LOW_PRIO_BUF_E].work_queue_size = SX_CORE_LOW_PRIO_BUFFER_SIZE_E;

        if (sxd_cr_mode()) {
            SX_LOG_NTC("In CR-Space mode\n");
            td_worker[i].prio_buf_context[SX_CORE_HIGH_PRIO_BUF_E].work_queue_size *= 100;
            td_worker[i].prio_buf_context[SX_CORE_MED_PRIO_BUF_E].work_queue_size *= 100;
            td_worker[i].prio_buf_context[SX_CORE_LOW_PRIO_BUF_E].work_queue_size *= 100;
        }

        for (buff_idx = SX_CORE_MIN_PRIO_BUF_E; buff_idx <= SX_CORE_MAX_PRIO_BUF_E; buff_idx++) {
            prio_buf = &(td_worker[i].prio_buf_context[buff_idx]);

            prio_buf->work_queue = cl_malloc(sizeof(sx_core_td_event_src_t *) * prio_buf->work_queue_size);
            if (prio_buf->work_queue == NULL) {
                err = SX_STATUS_NO_MEMORY;
                SX_LOG_ERR("%d buffer pointer memory alloc fail\n", buff_idx);
                goto out;
            }

            SX_MEM_CLR_ARRAY(prio_buf->work_queue, prio_buf->work_queue_size, sx_core_td_event_src_t *);

            prio_buf->work_queue_prod = 0;
            prio_buf->work_queue_read = 0;
            prio_buf->work_queue_cons = 0;

            cl_spinlock_init(&(prio_buf->queue_lock_cons));
            cl_spinlock_init(&(prio_buf->queue_lock_prod));
        }

        g_hc_thread.exit_signal_issued = FALSE;
        cl_err = cl_thread_init(&g_hc_thread.thread_h,
                                __sx_core_hc_monitor_init_thread,
                                NULL,
                                "hc_thread_monitor_init",
                                0);
        if (cl_err != CL_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not create __sx_core_hc_monitor_init_thread \n");
            err = SX_STATUS_ERROR;
            goto out;
        }

        cl_err = cl_thread_init(&(td_worker[i].thread),
                                __sx_core_td_worker_thread,
                                (void*)(uintptr_t)i,
                                "tdWorker",
                                TD_WORKER_THREAD_HEALTH_MONITOR_MAX_ALLOWED_TIME);
        if (cl_err != CL_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not create thread\n");
            err = SX_STATUS_ERROR;
            goto out;
        }

        td_worker[i].active = TRUE;

        SX_LOG(SX_LOG_INFO, "SX worker thread #%u opened\n", i);
    }

    for (buff_idx = SX_CORE_MIN_PRIO_BUF_E; buff_idx <= SX_CORE_MAX_NON_HIGH_PRIO_BUF_E; buff_idx++) {
        med_low_prio_event_buffer_s[buff_idx] = cl_malloc(sizeof(sx_core_td_event_src_t) *
                                                          (td_worker[0].prio_buf_context[buff_idx].work_queue_size));
        if (!(med_low_prio_event_buffer_s[buff_idx])) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("%d buffer memory alloc fail\n", buff_idx);
            goto out;
        }

        memset(med_low_prio_event_buffer_s[buff_idx], 0, sizeof(sx_core_td_event_src_t) *
               (td_worker[0].prio_buf_context[buff_idx].work_queue_size));

        for (j = 0; j < td_worker[0].prio_buf_context[buff_idx].work_queue_size; j++) {
            td_worker[0].prio_buf_context[buff_idx].work_queue[j] = &(med_low_prio_event_buffer_s[buff_idx][j]);
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __close_sx_worker_td()
{
    uint32_t    i = 0, j = 0;
    sx_status_t err = SX_STATUS_SUCCESS;
    int32_t     bytes = 0;
    int32_t     result = 0;

    g_hc_thread.exit_signal_issued = TRUE;
    cl_thread_destroy(&(g_hc_thread.thread_h));

    for (i = 0; i < SX_CORE_TD_WORKER_NUM; ++i) {
        if (td_worker[i].active == TRUE) {
            td_worker[i].worker_exit_signal_issued = TRUE;
            /* Write to work_queue_fd to signal pipe */
            bytes = 1;
            result = write(td_worker[i].work_queue_fd[1], &bytes, sizeof(bytes));
            if (result != sizeof(bytes)) {
                SX_LOG(SX_LOG_ERROR, "Failed to write to work queue fd [bytes=%d, errno=%s].\n", bytes,
                       strerror(errno));
                err = SX_STATUS_ERROR;
                return err;
            }
            cl_thread_destroy(&(td_worker[i].thread));
            /* Close pipe fds of td worker */
            close(td_worker[i].work_queue_fd[0]);
            close(td_worker[i].work_queue_fd[1]);
        }
    }

    for (i = SX_CORE_MIN_PRIO_BUF_E; i <= SX_CORE_MAX_NON_HIGH_PRIO_BUF_E; ++i) {
        for (j = 0; j < td_worker[0].prio_buf_context[i].work_queue_size; j++) {
            if (med_low_prio_event_buffer_s[i][j].buffer) {
                cl_free(med_low_prio_event_buffer_s[i][j].buffer);
            }
        }
        cl_free(med_low_prio_event_buffer_s[i]);
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __open_sx_api_commchnl()
{
    cl_status_t cl_err = CL_SUCCESS;
    sx_status_t err = SX_STATUS_SUCCESS;
    char      * sx_api_commchnl_addr = NULL;

    SX_LOG_ENTER();

    sx_api_commchnl_addr = getenv("SX_API_SOCKET_FILE");
    if (sx_api_commchnl_addr == NULL) {
        sx_api_commchnl_addr = SX_API_COMMCHNL_ADDRESS;
    }

    cl_err = cl_commchnl_init(&sx_api_commchnl_s, sx_api_commchnl_addr, CL_COMMCHNL_SIDE_SERVER);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not open SX-API server communication channel\n");
        err = SX_STATUS_COMM_ERROR;
        goto out;
    }

    err = __add_event_src(&sx_api_commchnl_s, "SX-API server", __accept_connection);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not add SX-API server communication channel into event array\n");
        cl_commchnl_destroy(&sx_api_commchnl_s);
        goto out;
    }

    SX_LOG(SX_LOG_INFO, "SX-API server is ready for connections.\n");

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __close_sx_api_commchnl()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    cl_commchnl_destroy(&sx_api_commchnl_s);

    SX_LOG(SX_LOG_INFO, "SX-API server is closed for connections.\n");

    SX_LOG_EXIT();
    return err;
}

sx_status_t core_td_log_verbosity_level(IN sx_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SX_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sx_status_t sx_core_td_init()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR(drop_counters_s);

    SX_MEM_CLR(td_worker);
    SX_MEM_CLR(high_prio_event_srcs_s);

    cl_spinlock_init(&event_src_state_lock_s);

    err = __init_quit_event_src();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed Init SX Quit Event Source.\n");
        goto out;
    }

    /* worker thread arbitration method */
    worker_arb_method = sx_core_worker_thread_fixed_arb;

    err = __open_sx_worker_td();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed opening SX worker threads.\n");
        goto out;
    }

    err = __open_sx_api_commchnl();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed opening SX API communication channel.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_core_td_deinit()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = __deinit_quit_event_src();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed deinit SX Quit Event Source.\n");
        goto out;
    }

    err = __close_sx_worker_td();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed closing SX worker threads.\n");
        goto out;
    }

    cl_spinlock_destroy(&event_src_state_lock_s);

    err = __close_sx_api_commchnl();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed closing SX API communication channel.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

void sx_core_td_start_loop()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    while (err == SX_STATUS_SUCCESS) {
        err = __select_event();
    }

    SX_LOG_EXIT();
    return;
}

sx_status_t sx_core_td_exit_loop()
{
    int         bytes = 0;
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    bytes = write(event_quit_fd_s[1], &bytes, sizeof(bytes));
    if (bytes != sizeof(bytes)) {
        SX_LOG(SX_LOG_ERROR, "SX Core exit loop failed [bytes=%d, errno=%s].\n", bytes, strerror(errno));
        err = SX_STATUS_ERROR;
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_core_td_add_internal_job_to_queue(uint32_t opcode, uint8_t *buffer, uint32_t cmd_size, uint8_t buf_idx)
{
    sx_status_t                               sx_status = SX_STATUS_SUCCESS;
    sx_core_td_event_src_t                   *sx_event = NULL;
    sx_core_td_worker_data_t                 *data = NULL;
    sx_core_worker_thread_prio_buf_context_t *prio_buf = NULL;
    sx_api_command_head_t                    *cmd;
    uint32_t                                  index;
    sx_api_fdb_swid_device_mask_t            *swid_dev_mask = NULL;
    int                                       bytes = 0;
    int32_t                                   result = 0;

    sx_status = worker_arb_method(&data, buffer, cmd_size, opcode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SX-API worker arbitration failed\n");
        goto end_no_unlock;
    }

    SX_LOG(SX_LOG_FRAMES, "Add internal job opcode: #%u to buffer #%u of size %u\n", opcode, buf_idx, cmd_size);

    if (FALSE == SX_PRIO_BUFF_SX_CHECK_RANGE(buf_idx)) {
        SX_LOG(SX_LOG_ERROR, "Wrong buffer index\n");
        sx_status = SX_STATUS_ERROR;
        goto end_no_unlock;
    }
    prio_buf = &(data->prio_buf_context[buf_idx]);

    /* cl_spinlock_acquire(&(prio_buf->queue_lock_cons)); no need to lock lock_cons - only one worker thread*/

    cl_spinlock_acquire(&(prio_buf->queue_lock_prod));

    /* prevent overflow, drop if there's no space */
    if (((opcode == SX_API_INT_CMD_FDB_POLL_SET_E) ||
         (opcode == SX_API_INT_CMD_PSORT_BACKGROUND_SET_E) ||
         (opcode == SX_API_INT_CMD_ECMP_BACKGROUND_SET_E) ||
         (opcode == SX_API_INT_CMD_BA_BACKGROUND_SET_E) ||
         (opcode == SX_API_INT_CMD_GC_ACTIVATE_BACKGROUND_SET_E) ||
         (opcode == SX_API_INT_CMD_MC_CONTAINER_BACKGROUND_SET_E) ||
         (opcode == SX_API_INT_CMD_GC_HANDLE_POST_QUEUE_SET_E) ||
         (opcode == SX_API_INT_CMD_PORT_PROFILE_APPLY_JOB_PROCESS_E) ||
         (opcode == SX_API_INT_CMD_ATCAM_ERP_OPTIMIZE_E) ||
         (opcode == SX_API_INT_CMD_DBG_GENERATE_DUMP_EXT_E)) &&
        (((prio_buf->work_queue_prod + 1 - prio_buf->work_queue_cons +
           prio_buf->work_queue_size) % (prio_buf->work_queue_size + 1)) >
         (prio_buf->work_queue_size * LOW_MED_BUF_THRESHOLD))) {
        if (opcode == SX_API_INT_CMD_FDB_POLL_SET_E) {
            swid_dev_mask = (sx_api_fdb_swid_device_mask_t*)buffer;
            fdb_polling_data_polling_enabled_set(swid_dev_mask->swid, TRUE);
            SX_LOG_DBG("%s: %d dropping add_internal_job (FDB_POLL_SET) buf_idx=%d\n", __FILE__, __LINE__, buf_idx);
            (drop_counters_s.fdb_poll_cnt)++;
        } else if (opcode == SX_API_INT_CMD_PSORT_BACKGROUND_SET_E) {
            SX_LOG_DBG("%s: %d dropping add_internal_job (PSORT_BACKGROUND_SET) buf_idx=%d\n", __FILE__, __LINE__,
                       buf_idx);
            (drop_counters_s.psort_bg_cnt)++;
        } else if (opcode == SX_API_INT_CMD_ECMP_BACKGROUND_SET_E) {
            SX_LOG_DBG("%s: %d dropping add_internal_job (ECMP_BACKGROUND_SET) buf_idx=%d\n", __FILE__, __LINE__,
                       buf_idx);
            (drop_counters_s.ecmp_bg_cnt)++;
        } else if (opcode == SX_API_INT_CMD_BA_BACKGROUND_SET_E) {
            SX_LOG_DBG("%s: %d dropping add_internal_job (BA_BACKGROUND_SET) buf_idx=%d\n", __FILE__, __LINE__,
                       buf_idx);
            (drop_counters_s.ba_bg_cnt)++;
        } else if (opcode == SX_API_INT_CMD_ECMP_LOAD_BALANCING_BACKGROUND_SET_E) {
            SX_LOG_DBG(
                "%s: %d dropping add_internal_job (SX_API_INT_CMD_ECMP_LOAD_BALANCING_BACKGROUND_SET_E) buf_idx=%d\n",
                __FILE__,
                __LINE__,
                buf_idx);
            (drop_counters_s.load_balancing_bg_cnt)++;
        } else if (opcode == SX_API_INT_CMD_GC_ACTIVATE_BACKGROUND_SET_E) {
            SX_LOG_DBG(
                "%s: %d dropping add_internal_job (SX_API_INT_CMD_GC_ACTIVATE_BACKGROUND_SET_E) buf_idx=%d\n",
                __FILE__,
                __LINE__,
                buf_idx);
            (drop_counters_s.gc_activate_bg_cnt)++;
            sx_status = SX_STATUS_NO_RESOURCES;
            goto end_unlock;
        } else if (opcode == SX_API_INT_CMD_MC_CONTAINER_BACKGROUND_SET_E) {
            SX_LOG_DBG(
                "%s: %d dropping add_internal_job (SX_API_INT_CMD_MC_CONTAINER_BACKGROUND_SET_E) buf_idx=%d\n",
                __FILE__,
                __LINE__,
                buf_idx);
            (drop_counters_s.mc_container_bg_cnt)++;
        } else if (opcode == SX_API_INT_CMD_GC_HANDLE_POST_QUEUE_SET_E) {
            SX_LOG_DBG(
                "%s: %d dropping add_internal_job (SX_API_INT_CMD_GC_HANDLE_POST_QUEUE_SET_E) buf_idx=%d\n",
                __FILE__,
                __LINE__,
                buf_idx);
            sx_status = SX_STATUS_NO_RESOURCES;
            (drop_counters_s.gc_post_queue_cnt)++;
            goto end_unlock;
        } else if (opcode == SX_API_INT_CMD_PORT_PROFILE_APPLY_JOB_PROCESS_E) {
            SX_LOG_DBG(
                "%s: %d dropping add_internal_job (SX_API_INT_CMD_PORT_PROFILE_APPLY_JOB_PROCESS_E) buf_idx=%d\n",
                __FILE__,
                __LINE__,
                buf_idx);
            (drop_counters_s.port_profile_apply_cnt)++;
            sx_status = SX_STATUS_NO_RESOURCES;
            goto end_unlock;
        } else if (opcode == SX_API_INT_CMD_ATCAM_ERP_OPTIMIZE_E) {
            SX_LOG_DBG(
                "%s: %d dropping add_internal_job (SX_API_INT_CMD_ATCAM_ERP_OPTIMIZE_E) buf_idx=%d\n",
                __FILE__,
                __LINE__,
                buf_idx);
            (drop_counters_s.atcam_erp_opt_cnt)++;
            sx_status = SX_STATUS_NO_RESOURCES;
            goto end_unlock;
        } else if (opcode == SX_API_INT_CMD_DBG_GENERATE_DUMP_EXT_E) {
            SX_LOG_ERR("Dropping internal command to get FW dump (buf_idx=%d)\n", buf_idx);
            sx_status = SX_STATUS_NO_RESOURCES;
            goto end_unlock;
        }

        /* cl_spinlock_release(&(prio_buf->queue_lock_cons)); no need to release lock_cons - only one worker thread */
        sx_status = SX_STATUS_SUCCESS;
    } else if (prio_buf->work_queue_cons != (prio_buf->work_queue_prod + 1) % prio_buf->work_queue_size) {
        /* cl_spinlock_release(&(prio_buf->queue_lock_cons)); no need to release lock_cons - only one worker thread */

        index = prio_buf->work_queue_prod;
        sx_event = prio_buf->work_queue[index];

        if (sx_event->buffer) {
            cmd = (sx_api_command_head_t*)sx_event->buffer;
            if (cmd->msg_size < sizeof(sx_api_command_head_t) + cmd_size) {
                CL_FREE_N_NULL(sx_event->buffer);
            }
        }
        if (cmd_size < SX_API_LOW_PRIO_MESSAGE_SIZE_LIMIT) {
            if (!sx_event->buffer) {
                sx_event->buffer = cl_malloc(cmd_size + sizeof(sx_api_command_head_t));
                if (!sx_event->buffer) {
                    sx_status = SX_STATUS_NO_MEMORY;
                    SX_LOG_ERR("%d buffer memory alloc fail\n", buf_idx);
                    goto end_unlock;
                }
            }
        } else {
            SX_LOG(SX_LOG_ERROR, "job size is too large %d\n", cmd_size);
            sx_status = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
            goto end_unlock;
        }

        cmd = (sx_api_command_head_t*)sx_event->buffer;
        cmd->opcode = opcode;
        cmd->version = SX_API_INT_VERSION;
        cmd->msg_size = sizeof(sx_api_command_head_t) + cmd_size;
        cmd->list_size = 0;

        if (cmd_size > 0) {
            if (!buffer) {
                SX_LOG(SX_LOG_ERROR, "buffer is NULL but command size is %d\n", cmd_size);
                sx_status = SX_STATUS_ERROR;
                goto end_unlock;
            }
            SX_MEM_CPY_BUF(sx_event->buffer + sizeof(sx_api_command_head_t), buffer, cmd_size);
        }

        prio_buf->work_queue_prod = (prio_buf->work_queue_prod + 1) % prio_buf->work_queue_size;

        /* Write to work_queue_fd to signal pipe */
        bytes = 1;
        result = write(data->work_queue_fd[1], &bytes, sizeof(bytes));
        if (result != sizeof(bytes)) {
            SX_LOG(SX_LOG_ERROR, "Failed to write to work queue fd [bytes=%d, errno=%s].\n", bytes, strerror(errno));
            sx_status = SX_STATUS_ERROR;
            goto end_unlock;
        }
        sx_status = SX_STATUS_SUCCESS;
        goto end_unlock;
    } else {
        /* cl_spinlock_release(&(prio_buf->queue_lock_cons)); no need to release lock_cons - only one worker thread */
        SX_LOG(SX_LOG_WARNING, "Failed to insert in low priority buffer\n");
        sx_status = SX_STATUS_NO_RESOURCES;
    }

end_unlock:
    cl_spinlock_release(&(prio_buf->queue_lock_prod));
end_no_unlock:
    return sx_status;
}


sx_status_t sx_core_td_increase_consumer(sx_core_prio_buffer_num_e buffer_type)
{
    sx_status_t                               sx_status = SX_STATUS_SUCCESS;
    sx_core_worker_thread_prio_buf_context_t *prio_buf = NULL;

    SX_LOG_ENTER();

    if (buffer_type > SX_CORE_MAX_PRIO_BUF_E) {
        SX_LOG(SX_LOG_ERROR, "Wrong buffer type: [%u]\n", buffer_type);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    prio_buf = &(td_worker[0].prio_buf_context[buffer_type]); /* only one worker thread */

    cl_spinlock_acquire(&(prio_buf->queue_lock_cons));
    prio_buf->work_queue_cons = (prio_buf->work_queue_cons + 1) % prio_buf->work_queue_size;
    cl_spinlock_release(&(prio_buf->queue_lock_cons));

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sx_core_td_drop_counters_dbg_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    FILE                    *stream = NULL;
    sx_core_td_drop_counters counters;
    sx_status_t              err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    stream = dbg_dump_params_p->stream;
    SX_MEM_CPY(counters, drop_counters_s);


    dbg_utils_pprinter_module_header_print(stream, "Internal jobs drop counters");


    dbg_utils_pprinter_field_print(stream, "ATCAM ERP optimization ",
                                   (void *)&(counters.atcam_erp_opt_cnt),
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "BA background set ",
                                   (void *)&(counters.ba_bg_cnt),
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "ECMP background set ",
                                   (void *)&(counters.ecmp_bg_cnt),
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "FDB poll ",
                                   (void *)&(counters.fdb_poll_cnt),
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "GC activate background",
                                   (void *)&(counters.gc_activate_bg_cnt),
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "GC post queue ",
                                   (void *)&counters.gc_post_queue_cnt,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Load balancing background",
                                   (void *)&counters.load_balancing_bg_cnt,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "MC container background set ",
                                   (void *)&counters.mc_container_bg_cnt,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Port profile apply process job ",
                                   (void *)&counters.port_profile_apply_cnt,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Psort background ",
                                   (void *)&counters.psort_bg_cnt,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Port operational status event ",
                                   (void *)&counters.oper_status_event_cnt,
                                   PARAM_UINT32_E);

    return err;
}
