/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#include <errno.h>

#include <complib/sx_log.h>

#include "sx_core_cmd_db.h"
#include "sx_core_api.h"

#undef  __MODULE__
#define __MODULE__ CORE_CMD_DB

typedef struct sx_mapped_api_command {
    cl_map_item_t    map_item;
    sx_api_command_t cmd;
} sx_mapped_api_command_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/*************************************************
 *  Local Functions
 ************************************************/

/************************************************
 *  Global variables
 ***********************************************/
sx_core_cmd_db_data_t cmd_db_data;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

/*********************************************************************************************************/
/*************** Command DB initialization  **************************************************************/
/*********************************************************************************************************/
sx_status_t sx_core_init_command_db()
{
    sx_status_t err = SX_STATUS_SUCCESS;
    cl_status_t cl_err;

    SX_LOG_ENTER();

    cl_qmap_init(&(cmd_db_data.cmd_map));

    cl_err = cl_plock_init(&(cmd_db_data.cmd_db_mutex));
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "sx core cmd db mutex init faild: %u\n", cl_err);
        err = SX_STATUS_ERROR;
        goto out;
    }
    /* SDK process is starting. We dont know chip type yet.
     * User will provide it with sdk init api*/
    err = sx_core_api_cmd_table_init(SXD_CHIP_TYPE_UNKNOWN);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "sx core api cmd table initialization failed\n");
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t free_cmd_map_items(cl_qmap_t *map)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t *map_item_p = NULL;
    cl_map_item_t *next_map_item_p = NULL;

    next_map_item_p = cl_qmap_head(map);
    map_item_p = next_map_item_p;

    while (map_item_p != &map->nil) {
        next_map_item_p = cl_qmap_next(map_item_p);
        M_UTILS_MEM_PUT(map_item_p, UTILS_MEM_TYPE_ID_API_E, "releasing cmd db item", sx_status);
        if (sx_status != SX_STATUS_SUCCESS) {
            goto out;
        }
        map_item_p = next_map_item_p;
    }

out:
    return sx_status;
}

sx_status_t sx_core_deinit_command_db()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    cl_plock_destroy(&(cmd_db_data.cmd_db_mutex));
    err = free_cmd_map_items(&cmd_db_data.cmd_map);

    return err;
}

void sx_core_cmd_db_set_chip_type(sxd_chip_types_t asic_type)
{
    cmd_db_data.asic_type = asic_type;
}

/*********************************************************************************************************/
/*************** Command DB mutexed access  **************************************************************/
/*********************************************************************************************************/
void get_cmd_table_access(sx_cmd_db_op_e op)
{
    switch (op) {
    case SX_CORE_CMD_DB_GET_E:
        cl_plock_acquire(&(cmd_db_data.cmd_db_mutex));
        break;

    case SX_CORE_CMD_DB_SET_E:
        cl_plock_excl_acquire(&(cmd_db_data.cmd_db_mutex));
        break;
    }
}
void release_cmd_table_access()
{
    cl_plock_release(&(cmd_db_data.cmd_db_mutex));
}

/*********************************************************************************************************/
/*************** Command DB Access commands **************************************************************/
/*********************************************************************************************************/
sx_status_t sx_core_get_api_command_name(sx_api_int_cmd_e cmd_id, const char** cmd_name)
{
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t           *map_item_p = NULL;
    sx_mapped_api_command_t *cmd;

    get_cmd_table_access(SX_CORE_CMD_DB_GET_E);

    map_item_p = cl_qmap_get(&(cmd_db_data.cmd_map), (uint64_t)cmd_id);

    if (map_item_p == &cmd_db_data.cmd_map.nil) {
        SX_LOG_ERR("command %u not found in api_cmd_db\n", cmd_id);
        sx_status = SX_STATUS_ERROR;
        goto end;
    }

    cmd = (sx_mapped_api_command_t*)map_item_p;
    *cmd_name = cmd->cmd.name;

end:
    release_cmd_table_access();
    return sx_status;
}

sx_status_t sx_core_get_api_command(sx_api_int_cmd_e cmd_id, sx_api_command_t *cmd_data)
{
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t           *map_item_p = NULL;
    sx_mapped_api_command_t *cmd;

    get_cmd_table_access(SX_CORE_CMD_DB_GET_E);

    map_item_p = cl_qmap_get(&(cmd_db_data.cmd_map), (uint64_t)cmd_id);

    if (map_item_p == &cmd_db_data.cmd_map.nil) {
        SX_LOG_ERR("command %u not found in api_cmd_db for chip type %s\n", cmd_id,
                   sx_chip_types_str((sx_chip_types_t)cmd_db_data.asic_type));
        sx_status = SX_STATUS_ERROR;
        goto end;
    }

    cmd = (sx_mapped_api_command_t*)map_item_p;
    memcpy(cmd_data, &(cmd->cmd), sizeof(sx_api_command_t));

end:
    release_cmd_table_access();
    return sx_status;
}

sx_status_t sx_core_set_api_command(const sx_api_command_t *cmd_data)
{
    sx_mapped_api_command_t *cmd_2b_inserted;
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t           *map_item_p = NULL;

    get_cmd_table_access(SX_CORE_CMD_DB_SET_E);

    map_item_p = cl_qmap_get(&(cmd_db_data.cmd_map), (uint64_t)(cmd_data->cmd_id));
    if ((map_item_p->key != (uint64_t)cmd_data->cmd_id) || (map_item_p == &cmd_db_data.cmd_map.nil)) {
        M_UTILS_CLR_MEM_GET(&cmd_2b_inserted,
                            1,
                            sizeof(sx_mapped_api_command_t),
                            UTILS_MEM_TYPE_ID_API_E,
                            "",
                            sx_status);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("mem allocation failed\n");
            goto out;
        }
        memcpy(&(cmd_2b_inserted->cmd), cmd_data, sizeof(sx_api_command_t));
        cl_qmap_insert(&(cmd_db_data.cmd_map), (uint64_t)cmd_data->cmd_id, (cl_map_item_t*)cmd_2b_inserted);
    } else {
        cmd_2b_inserted = (sx_mapped_api_command_t*)map_item_p;
        memcpy((void*)(&(cmd_2b_inserted->cmd)), (void*)(cmd_data), sizeof(sx_api_command_t));
    }
out:
    release_cmd_table_access();
    return sx_status;
}

/*********************************************************************************************************/
/*************** Command DB dump            **************************************************************/
/*********************************************************************************************************/
sx_status_t sx_core_cmd_db_dump_entries(int max_entries, sx_api_int_cmd_e last_command)
{
    sx_api_command_t *command;
    cl_map_item_t    *map_item_p = NULL;
    sx_status_t       err = SX_STATUS_SUCCESS;
    char              prio[10];
    char              protocol[10];
    int               itter = 0;

    SX_LOG_ENTER();

    if (cmd_db_data.cmd_map.state != CL_INITIALIZED) {
        err = SX_STATUS_SDK_NOT_INITIALIZED;
        SX_LOG_ERR("cmd db is not initialized\n");
        goto end;
    }

    if (last_command != SX_API_INT_CMD_NUM_E) {
        map_item_p = cl_qmap_get(&(cmd_db_data.cmd_map), (uint64_t)(last_command));
    }

    while (itter < max_entries) {
        if (map_item_p != NULL) {
            map_item_p = cl_qmap_next(map_item_p);
        } else {
            map_item_p = cl_qmap_head(&(cmd_db_data.cmd_map));
        }

        if (map_item_p == &cmd_db_data.cmd_map.nil) {
            break;
        }

        command = &((sx_mapped_api_command_t*)map_item_p)->cmd;

        switch (command->priority) {
        case SX_API_CMD_PRIO_LOW_E:
            strcpy(prio, "LOW");
            break;

        case SX_API_CMD_PRIO_MEDIUM_E:
            strcpy(prio, "MEDIUM");
            break;

        case SX_API_CMD_PRIO_HIGH_E:
            strcpy(prio, "HIGH");
            break;
        }

        switch (command->protocol) {
        case SX_API_PROTOCOL_COMMON_E:
            strcpy(protocol, "COMMON");
            break;

        case SX_API_PROTOCOL_IB_E:
            strcpy(protocol, "IB");
            break;

        case SX_API_PROTOCOL_ETH_E:
            strcpy(protocol, "ETH");
            break;
        }

        if ((itter % 30) == 0) {
            SX_LOG(SX_LOG_NOTICE, "|---------------------------------------------------|------------|------------|\n");
            SX_LOG(SX_LOG_NOTICE, "|%-50s | %-10s | %-10s |\n", "NAME", "PRIO", "PROTOCOL");
            SX_LOG(SX_LOG_NOTICE, "|---------------------------------------------------|------------|------------|\n");
        }
        SX_LOG(SX_LOG_NOTICE, "|%-50s | %-10s | %-10s |\n", command->name, prio, protocol);
        itter++;
    }
    SX_LOG(SX_LOG_NOTICE, "|---------------------------------------------------|------------|------------|\n");
end:
    SX_LOG_EXIT();
    return err;
}
