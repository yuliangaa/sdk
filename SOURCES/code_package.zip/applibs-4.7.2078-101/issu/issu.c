/*
 * SPDX-FileCopyrightText: Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "issu.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "dbg_dump_modules/dbg_dump_modules.h"
#include "ethl2/fdb.h"
#include "ethl2/fdb_uc_impl.h"
#include "acl/flex_acl.h"
#include "ethl2/la_db.h"
#include "ethl2/lag.h"
#include "ethl2/port.h"
#include "ethl2/topo_db.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "sx/utils/gc.h"
#include "sx/utils/crc16.h"
#include "timer/timer.h"
#include "tele/hwi/tele_impl.h"
#include <include/resource_manager/resource_manager.h>
#include <complib/cl_fcntl.h>
#include "ethl3/hwi/sdk_router/sdk_router_impl.h"
#include "ethl3/hwd/hwd_ecmp/hwd_router_ecmp_arlpgt.h"
#include "tunnel/hwi/tunnel_impl.h"
#include "atcam/atcam_erps_manager/atcam_bloom_filter.h"
#include "ethl2/fdb_flood.h"
#include "ethl2/brg.h"
#include "ethl2/cos.h"
#include "dbg/dbg.h"
#include "flex_modifier/flex_modifier.h"
#include "sx/utils/cJSON.h"
#include "bulk_counter/bulk_counter.h"
#include "counters/counter_manager/af_counter_manager.h"
#include "sx_core/sx_core_async.h"
#include <ethl2/cos_sb.h>


#undef  __MODULE__
#define __MODULE__ ISSU

/************************************************
 *  Local Defines
 ***********************************************/
#define PROFILE_CRC_POLY   0x1abf
#define PROFILE_CRC_LENGTH 16

#define SX_PORT_MAPPING_V1_SIZE 16
/* structure of port map version 1 stored in pdb with padding
 * as recognized by compiler.
 *  typedef struct sx_port_mapping_v1 {
 *   sx_port_phy_id_t       local_port;
 *   uint8_t                pad_0[3];
 *   sx_port_mapping_mode_t mapping_mode;
 *   sx_port_mod_id_t       module_port;
 *   sx_port_width_t        width;
 *   sx_port_lane_bmap_t    lane_bmap;
 *   uint8_t                pad_1[1];
 *   boolean_t              reserved;
 *  } sx_port_mapping_v1_t;
 */

/************************************************
 *  Global variables
 ***********************************************/
extern sx_brg_context_t brg_context;
boolean_t               g_issu_mocs_in_session = FALSE;
/************************************************
 *  Local Macros
 ***********************************************/

#define PROFILE_FIELD_IS_MATCHING(old_field, new_field, disc, sx_status)                          \
    if (old_field != new_field) {                                                                 \
        sx_status = SX_STATUS_PARAM_ERROR;                                                        \
        SX_LOG_ERR("%s fields mismatch, old field = %" PRIu64                                     \
                   " new_field = %" PRIu64 "\n", disc, (uint64_t)old_field, (uint64_t)new_field); \
    }

#define ISSU_JSON_OBJ_GET_CHECK(object, disc)                \
    if (object == NULL) {                                    \
        SX_LOG_NTC("Could not retrieve object: %s\n", disc); \
    }

#define ISSU_JSON_OBJ_GET(object, disc, value) \
    ISSU_JSON_OBJ_GET_CHECK(object, disc);     \
    if (object != NULL) {                      \
        value = object->valuedouble;           \
    }


#define ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(object, err) \
    if (object == NULL) {                                \
        SX_LOG_NTC("Could not create JSON object\n");    \
        err = SX_STATUS_ERROR;                           \
        goto out;                                        \
    }

#define CONVERT_LAG_LOG_ID_FROM_V1(lag_id) \
    ((lag_id & 0x0000FF00) >> 8) | (lag_id & 0xFFFF0000);
/************************************************
 *  Local Type definitions
 ***********************************************/
typedef struct sx_port_mapping_v2 {
    uint8_t                local_port;   /**< 1,    2,      3,      4,      5,      6,      7,      ...,    62,     63,     64; */
    sx_port_mapping_mode_t mapping_mode; /**< EN,   DIS,    EN,     DIS,    EN,     EN,     DIS,    ...,    EN,     DIS,    EN; */
    sx_port_mod_id_t       module_port;  /**< 1,    0,      2,      0,      3,      4,      0,      ...,    31,     0,      32; */
    sx_port_width_t        width;        /**< 4,    0,      4,      0,      4,      4,      0,      ...,    4,      0,      4; */
    sx_port_lane_bmap_t    lane_bmap;
    boolean_t              reserved;     /**< This field changed to reserved */
    sx_slot_id_t           slot;         /**< SLOT ID */
} sx_port_mapping_v2_t;

typedef struct sx_issu_lag_info {
    uint32_t          port_recreated_count;
    uint32_t          port_list_cnt;
    sx_port_log_id_t *log_port_list;
    boolean_t         lid_exist;
} sx_issu_lag_info_t;

typedef struct sx_issu_port_map_info {
    sx_port_mapping_t *port_mapping_list_p;
    boolean_t         *port_mapping_done_p;
    uint32_t           list_size;
    uint32_t           port_num;
    boolean_t          restore_flag;
    boolean_t          persistent_flag;
} sx_issu_port_map_info_t;

typedef enum timer_thread_type {
    SX_TIMER_THREAD_GENERAL_E = 0,
    SX_TIMER_THREAD_FDB_E,
    SX_TIMER_THREAD_MAX_E = SX_TIMER_THREAD_FDB_E
} sx_timer_thread_type_e;

typedef enum issu_pdb_file_version {
    ISSU_PDB_FILE_VERSION_INVALID,
    ISSU_PDB_FILE_VERSION_1, /* version 1*/
    ISSU_PDB_FILE_VERSION_2,     /*version 2*/
    ISSU_PDB_FILE_VERSION_3,     /*version 3 - json*/
    ISSU_PDB_FILE_MIN_VERSION = ISSU_PDB_FILE_VERSION_1,
    ISSU_PDB_FILE_MAX_VERSION = ISSU_PDB_FILE_VERSION_3
} issu_pdb_file_version_e;

typedef enum issu_pdb_file_xlate_oper {
    ISSU_PDB_FILE_XLATE_OPER_STORE,
    ISSU_PDB_FILE_XLATE_OPER_RESTORE,
    ISSU_PDB_FILE_XLATE_OPER_MIN = ISSU_PDB_FILE_XLATE_OPER_STORE,
    ISSU_PDB_FILE_XLATE_OPER_MAX = ISSU_PDB_FILE_XLATE_OPER_RESTORE
} issu_pdb_file_xlate_oper_e;

typedef enum issu_pdb_file_info_type {
    ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E,
    ISSU_PDB_FILE_INFO_TYPE_BANK_E,
    ISSU_PDB_FILE_INFO_TYPE_PROFILE_E,
    ISSU_PDB_FILE_INFO_TYPE_LAG_E,
    ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E,
    ISSU_PDB_FILE_INFO_TYPE_FDB_E,
    ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E,
    ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E,
    ISSU_PDB_FILE_INFO_TYPE_MIN = ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E,
    ISSU_PDB_FILE_INFO_TYPE_MAX = ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E
} issu_pdb_file_info_type_e;

typedef struct issu_pdb_file_xlate_info {
    issu_pdb_file_xlate_oper_e file_oper_e;
    issu_pdb_file_info_type_e  file_info_type_e;
    issu_pdb_file_version_e    pdb_file_version;
} issu_pdb_file_xlate_info_t;

typedef sx_status_t (*issu_pdb_file_xlate_func_t) (issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p, void *ctxt,
                                                   void* param);

typedef struct issu_pdb_file_version_db_entity {
    issu_pdb_file_version_e     latest_version_e;
    char                      **issu_pdb_version_file_name_map;
    issu_pdb_file_xlate_func_t *issu_pdb_file_xlate_map;
} issu_pdb_file_version_db_entity_t;

typedef struct issu_profile_pdb_data {
    uint16_t          profile_csum;
    sx_api_profile_t *profile;
} issu_profile_pdb_data_t;

typedef struct issu_mocs_data {
    uint64_t      event_id;
    boolean_t     done;
    cl_spinlock_t event_spinlock;
} issu_mocs_data_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static sx_issu_params_t        g_issu_params = {SX_ISSU_BANK_1_E};
static sx_issu_lag_info_t     *g_lag_to_ports_mapping = NULL;
static sx_lag_id_t            *g_port_to_lag_mapping = NULL;
static sx_issu_port_map_info_t g_port_map_info;
static boolean_t               g_lag_db_initialized = FALSE;
static boolean_t               g_issu_lag_config_restore_flag = FALSE;
static boolean_t               g_issu_lag_fdb_not_recoverable = FALSE;
static boolean_t               g_issu_empty_lags_created_flag = FALSE;
static struct ku_sx_core_db   *core_kernel_db_p_s = NULL;
extern rm_resources_t          rm_resource_global;
static issu_mocs_data_t        g_issu_counter_mocs[2];
static boolean_t               g_is_sb_pools_pdb_exists = FALSE;
static sx_api_profile_t        g_profile;
static boolean_t               g_infiniband_issu = FALSE;

static sx_status_t __dump_module_issu_wrapper(dbg_dump_params_t *dbg_dump_params_p);

static sx_status_t __port_map_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                                void                       *ctxt_p,
                                                void                      * param);
static sx_status_t __port_map_pdb_file_xlate_v2(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                                void                       *ctxt_p,
                                                void                      * param);
static sx_status_t __port_map_pdb_file_xlate_v3(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                                void                       *ctxt_p,
                                                void                      * param);
static sx_status_t __bank_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                            void                       *ctxt_p,
                                            void                      * param);
static sx_status_t __bank_pdb_file_xlate_v2(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                            void                       *ctxt_p,
                                            void                      * param);
static sx_status_t __profile_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                               void                       *ctxt_p,
                                               void                      * param);
static sx_status_t __profile_pdb_file_xlate_v2(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                               void                       *ctxt_p,
                                               void                      * param);
static sx_status_t __lag_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                           void                       *ctxt_p,
                                           void                      * param);
static sx_status_t __lag_pdb_file_xlate_v2(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                           void                       *ctxt_p,
                                           void                      * param);
static sx_status_t __fdb_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                           void                       *ctxt_p,
                                           void                      * param);
static sx_status_t __sb_pools_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                                void                       *ctxt_p,
                                                void                       *param);
static sx_status_t __issu_cfg_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                                void                       *ctxt_p,
                                                void                       *param);
static sx_status_t __issu_arlpgt_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                               void                       *ctxt_p,
                                               void                       *param);

/* pdb file names for port map db.*/
static char *issu_pdb_files_name[ISSU_PDB_FILE_INFO_TYPE_MAX + 1][ISSU_PDB_FILE_MAX_VERSION + 1] = {
    {"port_map.txt", "port_map_v2.txt", "port_map_v3.json"},/* ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E */
    {"issu_bank.txt", "issu_bank_v2.json", NULL}, /* ISSU_PDB_FILE_INFO_TYPE_BANK_E */
    {"issu_profile.txt", "issu_profile_v2.json", NULL}, /* ISSU_PDB_FILE_INFO_TYPE_PROFILE_E */
    {"issu_lag.txt", "issu_lag_v2.json", NULL}, /* ISSU_PDB_FILE_INFO_TYPE_LAG_E */
    {"issu_sb_pools.json", NULL, NULL}, /* ISSU_PDB_FILE_INFO_TYPE_SHARED_POOLS_E */
    {"issu_fdb.json", NULL, NULL}, /* ISSU_PDB_FILE_INFO_TYPE_FDB_E */
    {"issu_cfg.json", NULL, NULL}, /* ISSU_PDB_FILE_INFO_TYPE_ISSU_CFG_E */
    {"issu_arlpgt.json", NULL, NULL} /* ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E */
};

/* Inter version translation table indexed by pdb file version for port map*/
issu_pdb_file_xlate_func_t issu_pdb_file_port_map_xlate[ISSU_PDB_FILE_VERSION_3] = {
    __port_map_pdb_file_xlate_v1,
    __port_map_pdb_file_xlate_v2,
    __port_map_pdb_file_xlate_v3
};

/* Inter version translation table indexed by pdb file version for bank*/
issu_pdb_file_xlate_func_t issu_pdb_file_bank_xlate[ISSU_PDB_FILE_VERSION_2] = {
    __bank_pdb_file_xlate_v1,
    __bank_pdb_file_xlate_v2
};

/* Inter version translation table indexed by pdb file version for profile*/
issu_pdb_file_xlate_func_t issu_pdb_file_profile_xlate[ISSU_PDB_FILE_VERSION_2] = {
    __profile_pdb_file_xlate_v1,
    __profile_pdb_file_xlate_v2
};

/* Inter version translation table indexed by pdb file version for lag*/
issu_pdb_file_xlate_func_t issu_pdb_file_lag_xlate[ISSU_PDB_FILE_VERSION_2] = {
    __lag_pdb_file_xlate_v1,
    __lag_pdb_file_xlate_v2
};

/* Inter version translation table indexed by pdb file version for fdb*/
issu_pdb_file_xlate_func_t issu_pdb_file_fdb_xlate[ISSU_PDB_FILE_VERSION_1] = {
    __fdb_pdb_file_xlate_v1
};

/* Inter version translation table indexed by pdb file version for shared buffer pools*/
issu_pdb_file_xlate_func_t issu_pdb_file_shared_pools_xlate[ISSU_PDB_FILE_VERSION_1] = {
    __sb_pools_pdb_file_xlate_v1,
};

/* Inter version translation table indexed by pdb file version for ISSU configuration*/
issu_pdb_file_xlate_func_t issu_pdb_file_issu_cfg_xlate[ISSU_PDB_FILE_VERSION_1] = {
    __issu_cfg_pdb_file_xlate_v1
};

issu_pdb_file_xlate_func_t issu_pdb_file_arlpgt_xlate[ISSU_PDB_FILE_VERSION_1] = {
    __issu_arlpgt_file_xlate_v1
};

/* PDB version database indexed by file info type */
issu_pdb_file_version_db_entity_t g_issu_pdb_version_db[ISSU_PDB_FILE_INFO_TYPE_MAX + 1] = {
    {ISSU_PDB_FILE_VERSION_3, issu_pdb_files_name[ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E], issu_pdb_file_port_map_xlate}, /* ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E */
    {ISSU_PDB_FILE_VERSION_2,  issu_pdb_files_name[ISSU_PDB_FILE_INFO_TYPE_BANK_E], issu_pdb_file_bank_xlate}, /* ISSU_PDB_FILE_INFO_TYPE_BANK_E */
    {ISSU_PDB_FILE_VERSION_2,  issu_pdb_files_name[ISSU_PDB_FILE_INFO_TYPE_PROFILE_E], issu_pdb_file_profile_xlate}, /* ISSU_PDB_FILE_INFO_TYPE_PROFILE_E */
    {ISSU_PDB_FILE_VERSION_2,  issu_pdb_files_name[ISSU_PDB_FILE_INFO_TYPE_LAG_E], issu_pdb_file_lag_xlate}, /* ISSU_PDB_FILE_INFO_TYPE_LAG_E */
    {ISSU_PDB_FILE_VERSION_1,  issu_pdb_files_name[ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E],
     issu_pdb_file_shared_pools_xlate},                                                                                    /* ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E */
    {ISSU_PDB_FILE_VERSION_1,  issu_pdb_files_name[ISSU_PDB_FILE_INFO_TYPE_FDB_E], issu_pdb_file_fdb_xlate},  /* ISSU_PDB_FILE_INFO_TYPE_FDB_E */
    {ISSU_PDB_FILE_VERSION_1,  issu_pdb_files_name[ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E],
     issu_pdb_file_issu_cfg_xlate},                                                                                        /* ISSU_PDB_FILE_INFO_TYPE_ISSU_CFG_E */
    {ISSU_PDB_FILE_VERSION_1,  issu_pdb_files_name[ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E], issu_pdb_file_arlpgt_xlate}, /* ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E */
};

static char g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_MAX + 1][ISSU_PERSISTENT_PATH_LEN_MAX] = {
    {0}, {0}, {0}, {0}, {0}, {0}, {0}
};
static char g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_MAX + 1][ISSU_PERSISTENT_PATH_LEN_MAX] = {
    {0}, {0}, {0}, {0}, {0}, {0}, {0}
};

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __issu_old_bank_entries_mark(sx_access_cmd_t cmd);
static sx_status_t __issu_bank_init(sx_boot_mode_e issu_boot_mode);
static sx_status_t __issu_bank_set(sx_issu_bank_e issu_bank);
static sx_status_t __issu_sfn_session_stop();
static sx_status_t __issu_fdb_learn_mode_reset();
static sx_status_t __issu_default_trap_disable();
static sx_status_t __issu_stop_polling_timer_thread();
static sx_status_t __issu_port_phy_consolidation_set(sx_access_cmd_t cmd);
static sx_status_t __issu_lag_info_ex_store(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p, FILE *stream);
static sx_status_t __issu_lag_info_ex_restore(issu_pdb_file_xlate_info_t * issu_pdb_file_xlate_info_p, FILE *stream);
static sx_status_t __issu_lag_port_list_json_add(sx_port_log_id_t  lag_log_port,
                                                 sx_port_log_id_t *log_port_list,
                                                 uint32_t          port_list_cnt,
                                                 cJSON           **json_obj);
static sx_status_t __issu_lag_create_empty_lags();
static sx_status_t __issu_fdb_records_store(FILE *stream, void *ctxt_p);
static sx_status_t __issu_fdb_records_restore(FILE *stream, void *ctxt_p);
static sx_status_t __issu_fdb_uc_mac_addr_set(sx_fdb_uc_mac_addr_params_t *mac_list,
                                              sx_tunnel_vni_t             *vni_list,
                                              uint32_t                     mac_list_cnt);
static sx_status_t __issu_fdb_mac_list_json_add(sx_fdb_uc_mac_addr_params_t *mac_list,
                                                uint32_t                    *mac_list_cnt,
                                                cJSON                      **arr_obj);
static sx_status_t __issu_fdb_single_mac_json_add(sx_fdb_uc_mac_addr_params_t *mac_entry_p, cJSON  **json_obj);
static sx_status_t __issu_persistent_info_storage_open(const char *filename, const char *mode, FILE **stream);
static sx_status_t __issu_persistent_info_storage_open_ex(issu_pdb_file_info_type_e file_info_type_e,
                                                          const char               *mode,
                                                          FILE                    **stream,
                                                          issu_pdb_file_version_e  *pdb_file_version_e_p);
static sx_status_t __issu_persistent_info_read_from_storage(void *ptr, size_t size, size_t nmemb, FILE *stream);
static sx_status_t __issu_persistent_info_write_to_storage(const void *ptr, size_t size, size_t nmemb, FILE *stream);
static sx_status_t __issu_persistent_info_storage_close(FILE **stream);
static sx_status_t __issu_prepare_persistent_paths(const char *persistent_path);
static sx_status_t __issu_persistent_info_remove();
static sx_status_t __issu_profile_checksum_calc(const sx_api_profile_t *profile, uint16_t *csum);
static sx_status_t __issu_profile_checksum_store(FILE *stream, const uint16_t csum);
static sx_status_t __issu_profile_checksum_restore(FILE *stream, uint16_t *csum);
static sx_status_t __issu_profile_checksum_json_restore(FILE* f_p, uint16_t *csum);
static sx_status_t __issu_profile_data_store(FILE *stream, sx_api_profile_t *profile);
static sx_status_t __issu_profile_data_restore(FILE *stream, sx_api_profile_t *profile);
static sx_status_t __issu_profile_data_json_restore(FILE *stream, sx_api_profile_t *profile);
static sx_status_t __issu_invalidate_acl(sx_dev_id_t dev_id);
static sx_status_t __issu_fw_update();
static sx_status_t __issu_profile_store(FILE* profile_file, sx_api_profile_t *profile);
static sx_status_t __issu_profile_compare(sx_api_profile_t *profile_p);
static sx_status_t __issu_profile_json_store(FILE* profile_file, sx_api_profile_t *profile);
static sx_status_t __issu_port_map_ex_store(issu_pdb_file_version_e version, void *ctxt_p);
static sx_status_t __issu_port_map_ex_restore(issu_pdb_file_version_e version, FILE *stream);
static sx_status_t __issu_restore_ex_wrapper(issu_pdb_file_info_type_e file_info_type_e,
                                             FILE *stream, issu_pdb_file_version_e version, void* param);
static sx_status_t __issu_store_ex_wrapper(issu_pdb_file_info_type_e file_info_type_e,
                                           void                    * param);
static sx_status_t __issu_profile_data_compare(sx_api_profile_t *old_profile_p, sx_api_profile_t *profile_p);
static sx_status_t __issu_disable_mocs_transactions_wrapper();
static sx_status_t __issu_disable_mocs_transactions(sxd_mocs_type_t *mocs_type_list_p, uint32_t mocs_type_cnt);
static sx_status_t __issu_pdb_get_db_index_by_file_version(issu_pdb_file_version_e version);
static sx_status_t __issu_counter_clear_all();
static sx_status_t __issu_mocs_counter_clear();
static sx_status_t __issu_fdb_pdb_operation_set(issu_pdb_file_xlate_oper_e file_oper_e);
static sx_status_t __issu_health_check_set(boolean_t issu_on);

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t issu_ports_map_is_persistent_get(boolean_t* persistent_map_exists_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(persistent_map_exists_p, "persistent_map_exists_p")) {
        goto out;
    }

    *persistent_map_exists_p = g_port_map_info.persistent_flag;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_lag_config_restore_flag_get(boolean_t *issu_lag_config_restore_flag)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(issu_lag_config_restore_flag, "issu_lag_config_restore_flag")) {
        goto out;
    }
    *issu_lag_config_restore_flag = g_issu_lag_config_restore_flag;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_lag_fdb_recovery_flag_get(boolean_t *lag_fdb_not_recoverable)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(lag_fdb_not_recoverable, "lag_fdb_not_recoverable")) {
        goto out;
    }
    *lag_fdb_not_recoverable = g_issu_lag_fdb_not_recoverable;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_lag_fdb_recovery_flag_set(boolean_t lag_fdb_not_recoverable)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    g_issu_lag_fdb_not_recoverable = lag_fdb_not_recoverable;

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_db_lag_port_list_clear(sx_lag_id_t lid)
{
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    sx_port_phy_id_t local_port;
    uint32_t         i = 0;

    SX_LOG_ENTER();

    if (g_lag_db_initialized != TRUE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    for (i = 0; i < g_lag_to_ports_mapping[lid].port_list_cnt; i++) {
        /* Remove ports from g_port_to_lag_mapping, than clear entry at g_lag_to_ports_mapping: */
        local_port = SX_PORT_PHY_ID_GET(g_lag_to_ports_mapping[lid].log_port_list[i]);
        if (local_port <= rm_resource_global.port_ext_num_max) {
            g_port_to_lag_mapping[local_port - 1] = INVALID_LAG_ID;
        } else {
            goto out;
        }
    }

    memset(g_lag_to_ports_mapping[lid].log_port_list, 0,
           sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
    g_lag_to_ports_mapping[lid].port_list_cnt = 0;
    g_lag_to_ports_mapping[lid].lid_exist = FALSE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_db_lag_destroy(sx_lag_id_t lid)
{
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    sx_port_phy_id_t local_port;
    uint32_t         i = 0;

    SX_LOG_ENTER();

    if (g_lag_db_initialized != TRUE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    g_lag_to_ports_mapping[lid].lid_exist = FALSE;

    for (i = 0; i < g_lag_to_ports_mapping[lid].port_list_cnt; i++) {
        local_port = SX_PORT_PHY_ID_GET(g_lag_to_ports_mapping[lid].log_port_list[i]);
        g_port_to_lag_mapping[local_port - 1] = INVALID_LAG_ID;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_lag_port_list_get(sx_lag_id_t lid, sx_port_log_id_t *log_port_list, uint32_t *port_list_cnt)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_lag_db_initialized != TRUE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (g_lag_to_ports_mapping[lid].lid_exist == FALSE) {
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (NULL == log_port_list) {
        *port_list_cnt = g_lag_to_ports_mapping[lid].port_list_cnt;
        goto out;
    }

    if (g_lag_to_ports_mapping[lid].log_port_list == NULL) {
        *port_list_cnt = 0;
        goto out;
    }

    if (g_lag_to_ports_mapping[lid].port_list_cnt <= *port_list_cnt) {
        *port_list_cnt = g_lag_to_ports_mapping[lid].port_list_cnt;
    }

    memcpy(log_port_list,
           g_lag_to_ports_mapping[lid].log_port_list,
           g_lag_to_ports_mapping[lid].port_list_cnt * sizeof(sx_port_log_id_t));

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_lag_id_get(sx_port_log_id_t log_port, sx_lag_id_t *lag_id_p)
{
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    sx_port_phy_id_t local_port;

    SX_LOG_ENTER();

    if (NULL == lag_id_p) {
        SX_LOG_ERR("Input param is NULL.\n");
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (g_lag_db_initialized != TRUE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    local_port = SX_PORT_PHY_ID_GET(log_port);

    if (g_port_to_lag_mapping[local_port - 1] == INVALID_LAG_ID) {
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *lag_id_p = g_port_to_lag_mapping[local_port - 1];

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_lag_with_no_ports_get(sx_lag_id_t *lag_id_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    if (g_lag_db_initialized != TRUE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    for (i = 0; i < rm_resource_global.lag_num_max; i++) {
        if ((g_lag_to_ports_mapping[i].lid_exist == TRUE) &&
            (g_lag_to_ports_mapping[i].port_list_cnt == 0)) {
            *lag_id_p = i;
            goto out;
        }
    }
    *lag_id_p = INVALID_LAG_ID;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_lag_port_count_get(sx_lag_id_t lid, uint32_t *lag_port_count)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (NULL == lag_port_count) {
        SX_LOG_ERR("Input parameter is NULL.\n");
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (g_lag_db_initialized != TRUE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    *lag_port_count = g_lag_to_ports_mapping[lid].port_list_cnt;

out:
    SX_LOG_EXIT();
    return sx_status;
}

/* The function is invoked to get the max lag id
 * that was restored from the persistent lag db on
 * issu init (ISSU_STARTED).
 */
sx_status_t issu_lag_max_exist_get(sx_lag_id_t *max_lid_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    int16_t lid_index = rm_resource_global.lag_num_max - 1;

    if (g_lag_db_initialized != TRUE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (utils_check_pointer(max_lid_p, "max_lid_p")) {
        goto out;
    }

    /*find max exist lid*/
    while ((lid_index >= 0) && (g_lag_to_ports_mapping[lid_index].lid_exist == FALSE)) {
        lid_index--;
    }

    *max_lid_p = (lid_index < 0) ? INVALID_LAG_ID : (sx_lag_id_t)lid_index;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_lag_exist_get(sx_lag_id_t lid, boolean_t *lag_exists_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_lag_db_initialized != TRUE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (utils_check_pointer(lag_exists_p, "lag_exists_p")) {
        goto out;
    }

    /* Check if we already have such a lid (no need to re-create it in FW) */
    *lag_exists_p = g_lag_to_ports_mapping[lid].lid_exist;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_dpt_access_control_set(dpt_access_control_t access_control)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    int                i = 0, device_cnt = SX_DEV_ID_MAX;
    topo_device_item_t dev_attrib[SX_DEV_ID_MAX];

    SX_LOG_ENTER();

    sx_status = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed in topo_db_device_list_get err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (device_cnt == 0) {
        SX_LOG_ERR("can't get topo device list register values , device list is empty\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    for (i = 0; i < device_cnt; i++) {
        /* DPT to dev NULL, only ISFU IFC will get through */
        sxd_status = sxd_dpt_set_access_control(dev_attrib[i].dev_id, access_control);

        sx_status = sxd_status_to_sx_status(sxd_status);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("sxd_dpt_set_access_control status = %s\n", sx_status_str(sx_status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_port_phy_consolidation_set(sx_access_cmd_t cmd)
{
    sx_status_t               sx_status = SX_STATUS_SUCCESS;
    port_consolidation_data_t cons_data;
    boolean_t                 expected_isfu_enable;

    SX_LOG_ENTER();
    SX_MEM_CLR(cons_data);

    switch (cmd) {
    case SX_ACCESS_CMD_ENABLE:
        expected_isfu_enable = TRUE;
        cons_data.cpld = TRUE;
        cons_data.fans = TRUE;
        cons_data.gearbox = TRUE;
        cons_data.leds = TRUE;
        cons_data.module_mng = TRUE;
        cons_data.power = TRUE;
        cons_data.thermal = TRUE;
        cons_data.voltage_current = TRUE;
        if (g_infiniband_issu) {
            cons_data.mads = TRUE;
        }
        break;

    case SX_ACCESS_CMD_DISABLE:
        expected_isfu_enable = FALSE;
        cons_data.ports = TRUE;
        break;

    default:
        SX_LOG_ERR("CMD is unsupported %u \n", cmd);
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    /*configure first group of consolidation data*/
    sx_status = port_phy_consolidation_set(cmd, cons_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" port_phy_consolidation_set failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    /*check that the first group of consolidation data had finished*/
    sx_status = port_phy_consolidation_check(cons_data, expected_isfu_enable);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" port_phy_consolidation_check failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    /*configure the rest of the consolidation data*/
    cons_data.cpld = !cons_data.cpld;
    cons_data.fans = !cons_data.fans;
    cons_data.gearbox = !cons_data.gearbox;
    cons_data.leds = !cons_data.leds;
    cons_data.module_mng = !cons_data.module_mng;
    cons_data.power = !cons_data.power;
    cons_data.thermal = !cons_data.thermal;
    cons_data.voltage_current = !cons_data.voltage_current;
    cons_data.ports = !cons_data.ports;
    if (g_infiniband_issu) {
        cons_data.mads = !cons_data.mads;
    }

    /*configure second group of consolidation data*/
    sx_status = port_phy_consolidation_set(cmd, cons_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" port_phy_consolidation_set failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    /*check that the second group of consolidation data had finished*/
    sx_status = port_phy_consolidation_check(cons_data, expected_isfu_enable);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" port_phy_consolidation_check failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_stop_polling_timer_thread(sx_timer_thread_type_e thread_type)
{
    sx_status_t  sx_status = SX_STATUS_SUCCESS;
    cl_thread_t* obj = NULL;
    sx_swid_id_t swid = rm_resource_global.swid_id_max;

    SX_LOG_ENTER();
    if (thread_type == SX_TIMER_THREAD_GENERAL_E) {
        obj = sx_timer_get_thread_obj();
    } else if (thread_type == SX_TIMER_THREAD_FDB_E) {
        obj = fdb_uc_impl_get_polling_timer_thread_object(swid);
    } else {
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((obj != NULL) && (obj->osd.id != (pthread_t)NULL)) {
        SX_LOG_DBG("terminating polling timer thread, swid %u, tid %u...\n",
                   swid, (unsigned int)obj->osd.id);

        /* raise the termination flag */
        if (thread_type == SX_TIMER_THREAD_GENERAL_E) {
            sx_timer_set_exit_signal_issued(TRUE);
        } else if (thread_type == SX_TIMER_THREAD_FDB_E) {
            fdb_uc_impl_set_polling_timer_exit_signal_issued(swid, TRUE);
        }

        /* thread will wake up as it is using usleep() broken to 100 millisecond periods */
        SX_LOG_DBG("waiting for thread %u to end...\n", (unsigned int)obj->osd.id);
        cl_thread_destroy(obj);
        SX_LOG_DBG("thread %u has ended\n\n",
                   (unsigned int)obj->osd.id);

        if (thread_type == SX_TIMER_THREAD_GENERAL_E) {
            sx_timer_clear_thread_tid();
        } else if (thread_type == SX_TIMER_THREAD_FDB_E) {
            fdb_uc_impl_clear_timer_thread_tid(swid);
        }
    } else {
        SX_LOG_DBG("polling timer thread for swid %u is ended or not created.\n",
                   (unsigned int)swid);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_old_bank_entries_mark(sx_access_cmd_t cmd)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     iicr_reg_meta;
    struct ku_iicr_reg iicr_reg_data;
    int                device_cnt = SX_DEV_ID_MAX;
    topo_device_item_t dev_attrib[SX_DEV_ID_MAX];
    sx_issu_bank_e     issu_bank = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(iicr_reg_meta);
    SX_MEM_CLR(iicr_reg_data);

    sx_status = issu_bank_get(&issu_bank);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_bank_get failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed in topo_db_device_list_get err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (device_cnt == 0) {
        SX_LOG_ERR("can't get IICR register values , device list is empty\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    /* get the info from the first device in the list */
    iicr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    iicr_reg_meta.dev_id = dev_attrib[0].dev_id;

    switch (cmd) {
    case SX_ACCESS_CMD_MARK:
        iicr_reg_data.kvh_mark_clear = SX_IICR_OP_MARK;
        break;

    case SX_ACCESS_CMD_CLEAR:

        /* Division is made by odd and even rif/region ids/acl groups, determinate by the first bit */
        issu_bank = (issu_bank == SX_ISSU_BANK_1_E) ? SX_ISSU_BANK_2_E : SX_ISSU_BANK_1_E;

        iicr_reg_data.clear_mc_rtr_tcam_mask = 0x0001;
        iicr_reg_data.clear_mc_rtr_tcam_value = issu_bank;

        iicr_reg_data.clear_pe_regions_mask = 0x0001;
        iicr_reg_data.clear_pe_regions_value = issu_bank;

        iicr_reg_data.clear_acl_group_elements_mask = 0x0001;
        iicr_reg_data.clear_acl_group_elements_value = issu_bank;
        /* Never clear the KVH BEFORE deleting old RIFs, we have no way to know if
         * they are still used by HW and cleaning KVH could delete an active route
         * (this is actually taken care of by FW but we do it anyway for safety)*/
        iicr_reg_data.clear_rifs_mask = 0x0002;
        iicr_reg_data.clear_rifs_value = (issu_bank << 1);

        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_IICR_E,
                                                         &iicr_reg_data,
                                                         &iicr_reg_meta,
                                                         1,
                                                         NULL,
                                                         NULL);
        if (SXD_CHECK_FAIL(sxd_status)) {
            SX_LOG_ERR("IICR Clear RIF and ACL entries failure (%s)\n",
                       SXD_STATUS_MSG(sxd_status));
            sx_status = SXD_STATUS_TO_SX_STATUS(sxd_status);
            goto out;
        }

        SX_MEM_CLR(iicr_reg_data);

        iicr_reg_data.kvh_mark_clear = SX_IICR_OP_CLEAR;

        break;

    default:
        SX_LOG_ERR("CMD is unsupported %u \n", cmd);
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_IICR_E, &iicr_reg_data, &iicr_reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("IICR Clear entries failure (%s)\n",
                   SXD_STATUS_MSG(sxd_status));
        sx_status = SXD_STATUS_TO_SX_STATUS(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_bank_set(sx_issu_bank_e issu_bank)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    sx_status_t             rc = SX_STATUS_SUCCESS;
    FILE                   *f_p = NULL;
    issu_pdb_file_version_e version = ISSU_PDB_FILE_VERSION_INVALID;

    SX_LOG_ENTER();

    sx_status = __issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_BANK_E, "w", &f_p, &version);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to open issu bank file\n");
        goto out;
    }

    /* write bank to file */
    sx_status = __issu_store_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_BANK_E, (void*)&issu_bank);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Error writing issu bank to storage \n");
        goto out;
    }

    g_issu_params.issu_bank = issu_bank;

out:
    if (f_p != NULL) {
        rc = __issu_persistent_info_storage_close(&f_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                       g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_BANK_E]);
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_fdb_learn_mode_reset()
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    sx_swid_id_t        swid = rm_resource_global.swid_id_max;
    sx_fdb_learn_mode_t glob_learn_mode = SX_FDB_LEARN_MODE_DONT_LEARN;

    SX_LOG_ENTER();

    sx_status = fdb_learn_mode_get(swid, &glob_learn_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve swid (%u) learn mode, %s(%d).\n",
                   swid, sx_status_str(sx_status), sx_status);
        goto out;
    }

    if (SX_FDB_LEARN_MODE_DONT_LEARN == glob_learn_mode) {
        goto out;
    }

    /* No FDB flush */
    sx_status = fdb_learn_mode_set(swid, glob_learn_mode, FALSE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed fdb_learn_mode_set, %s(%d)\n",
                   sx_status_str(sx_status), sx_status);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_fdb_poll_devices()
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_swid_id_t                  swid = rm_resource_global.swid_id_max;
    sx_api_fdb_swid_device_mask_t vector_mask;
    boolean_t                     need_to_process = TRUE;

    SX_LOG_ENTER();

    vector_mask.dev_mask = SX_FDB_UC_ALL_DEVICES_MASK;
    vector_mask.swid = swid;

    /* Remove internal job cb*/
    fdb_uc_impl_deregister_cb();

    while (need_to_process == TRUE) {
        sx_status = fdb_uc_impl_poll_devices(&vector_mask, &need_to_process);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed fdb_uc_impl_poll_devices, %s(%d)\n", sx_status_str(sx_status), sx_status);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_sfn_session_stop()
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    sx_swid_id_t        swid = rm_resource_global.swid_id_max;
    sx_fdb_learn_mode_t curr_learn_mode = SX_FDB_LEARN_MODE_DONT_LEARN;


    SX_LOG_ENTER();
    /*Get current state*/
    sx_status = fdb_learn_mode_get(swid, &curr_learn_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve swid (%u) learn mode, %s(%d).\n",
                   swid, sx_status_str(sx_status), sx_status);
        goto out;
    }

    if (curr_learn_mode != SX_FDB_LEARN_MODE_DONT_LEARN) {
        /* Stop all learning on the swid for now*/
        sx_status = fdb_learn_mode_set(swid, SX_FDB_LEARN_MODE_DONT_LEARN, FALSE);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed fdb_learn_mode_set, %s(%d)\n", sx_status_str(sx_status), sx_status);
            goto out;
        }
    }

    sx_status = __issu_stop_polling_timer_thread(SX_TIMER_THREAD_FDB_E);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to stop SFN polling thread\n");
        goto out;
    }

    /* Consume any leftover entries in SFN*/
    sx_status = __issu_fdb_poll_devices();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to poll devices in ISSU mode\n");
        goto out;
    }

    /* Thread has exited, RPC job queue disabled, stop the SFN FW session */
    sx_status = fdb_sfn_session_stop();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to stop SFN session\n");
        goto out;
    }

    /* Restore DB learn mode, ensure learnt dynamic entries are restored */
    sx_status = fdb_uc_db_learn_mode_set(swid, curr_learn_mode);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to restore DB learn mode\n");
        goto out;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __issu_persistent_info_storage_open(const char *filename, const char *mode, FILE **stream)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *stream = cl_fopen(filename, mode);
    if (*stream == NULL) {
        SX_LOG_INF("Failed to open ISSU persistent file %s\n", filename);
        sx_status = SX_STATUS_ERROR;
    }
    SX_LOG_EXIT();
    return sx_status;
}

/* Applicable for multi-versioned pdb. This API returns the file stream
 * and latest version of file in pdb.
 */

static sx_status_t __issu_persistent_info_storage_open_ex(issu_pdb_file_info_type_e file_info_type_e,
                                                          const char               *mode,
                                                          FILE                    **stream,
                                                          issu_pdb_file_version_e  *pdb_file_version_e_p)
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS;
    issu_pdb_file_version_db_entity_t *db_entity_p = NULL;
    issu_pdb_file_version_e            latest_version = ISSU_PDB_FILE_VERSION_INVALID;
    issu_pdb_file_version_e            cur_version = ISSU_PDB_FILE_VERSION_INVALID;
    char                               pdb_path[ISSU_PERSISTENT_PATH_LEN_MAX] = {0};
    uint8_t                            version_idx = 0;

    SX_LOG_ENTER();

    db_entity_p = &g_issu_pdb_version_db[file_info_type_e];
    if (utils_check_pointer(db_entity_p, "db_entity_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    latest_version = db_entity_p->latest_version_e;
    for (cur_version = latest_version; cur_version >= ISSU_PDB_FILE_VERSION_1; cur_version--) {
        SX_MEM_CLR_ARRAY(pdb_path, ISSU_PERSISTENT_PATH_LEN_MAX, char);
        version_idx = __issu_pdb_get_db_index_by_file_version(cur_version);
        /* coverity[buffer_size_warning] */
        strncpy(pdb_path,
                g_issu_pdb_base_paths_db[file_info_type_e],
                ISSU_PERSISTENT_PATH_LEN_MAX);
        strncat(pdb_path, db_entity_p->issu_pdb_version_file_name_map[version_idx],
                sizeof(pdb_path) - strlen(pdb_path) - 1);

        *stream = cl_fopen(pdb_path, mode);
        if (*stream != NULL) {
            strncpy(g_issu_pdb_paths_db[file_info_type_e], pdb_path, ISSU_PERSISTENT_PATH_LEN_MAX);
            *pdb_file_version_e_p = cur_version;
            break;
        }
    }

    if (*stream == NULL) {
        SX_LOG_INF("Failed to open ISSU persistent file.\n");
        sx_status = SX_STATUS_ERROR;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_persistent_info_read_from_storage(void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    if (cl_fread(ptr, size, nmemb, stream) == nmemb) {
        return SX_STATUS_SUCCESS;
    } else {
        return SX_STATUS_ERROR;
    }
}

static sx_status_t __issu_persistent_info_write_to_storage(const void *ptr, size_t size, size_t nmemb, FILE *stream)
{
    if (cl_fwrite(ptr, size, nmemb, stream) == nmemb) {
        return SX_STATUS_SUCCESS;
    } else {
        return SX_STATUS_ERROR;
    }
}

static sx_status_t __issu_persistent_info_storage_close(FILE **stream)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    cl_status_t cl_status = CL_SUCCESS;

    SX_LOG_ENTER();

    if (*stream != NULL) {
        cl_status = cl_fflush(*stream);
        if (cl_status != CL_SUCCESS) {
            SX_LOG_ERR("Failed to flush ISSU persistent file\n");
            sx_status = SX_STATUS_ERROR;
        }

        cl_status = cl_fsync(*stream);
        if (cl_status != CL_SUCCESS) {
            SX_LOG_ERR("Failed to sync ISSU persistent file\n");
            sx_status = SX_STATUS_ERROR;
        }

        cl_status = cl_fclose(*stream);
        if (cl_status != CL_SUCCESS) {
            SX_LOG_ERR("Failed to close ISSU persistent file\n");
            sx_status = SX_STATUS_ERROR;
        }
        *stream = NULL;
    }

    SX_LOG_EXIT();
    return sx_status;
}


/* Applicable for multi-versioned pdb. This API removes the file stream
 * and all version of file in pdb.
 */
static sx_status_t __issu_persistent_info_remove()
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS;
    issu_pdb_file_version_db_entity_t *db_entity_p = NULL;
    issu_pdb_file_version_e            latest_version = ISSU_PDB_FILE_VERSION_INVALID;
    issu_pdb_file_version_e            cur_version = ISSU_PDB_FILE_VERSION_INVALID;
    char                               pdb_path[ISSU_PERSISTENT_PATH_LEN_MAX] = {0};
    uint8_t                            version_idx = 0;
    issu_pdb_file_info_type_e          file_info_type_e;
    FILE                              *stream = NULL;
    cl_status_t                        cl_status = CL_SUCCESS;

    SX_LOG_ENTER();


    /* for each persistent file */
    for (file_info_type_e = ISSU_PDB_FILE_INFO_TYPE_MIN;
         file_info_type_e <= ISSU_PDB_FILE_INFO_TYPE_MAX;
         file_info_type_e++) {
        db_entity_p = &g_issu_pdb_version_db[file_info_type_e];
        if (utils_check_pointer(db_entity_p, "db_entity_p")) {
            sx_status = SX_STATUS_PARAM_NULL;
            goto out;
        }
        /*try to remove the file for each file version */
        latest_version = db_entity_p->latest_version_e;
        for (cur_version = latest_version; cur_version >= ISSU_PDB_FILE_VERSION_1; cur_version--) {
            SX_MEM_CLR_ARRAY(pdb_path, ISSU_PERSISTENT_PATH_LEN_MAX, char);
            stream = NULL;
            version_idx = __issu_pdb_get_db_index_by_file_version(cur_version);

            strncpy(pdb_path,
                    g_issu_pdb_base_paths_db[file_info_type_e],
                    (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
            strncat(pdb_path, db_entity_p->issu_pdb_version_file_name_map[version_idx],
                    sizeof(pdb_path) - strlen(pdb_path) - 1);

            /* check if file exist */
            stream = cl_fopen(pdb_path, "rb");
            if (stream != NULL) {
                cl_status = cl_fclose(stream);
                if (cl_status != CL_SUCCESS) {
                    SX_LOG_ERR("Failed to close ISSU persistent file\n");
                    sx_status = SX_STATUS_ERROR;
                }

                cl_status = cl_remove(pdb_path);
                if (cl_status != CL_SUCCESS) {
                    SX_LOG_ERR("Failed to remove ISSU persistent file\n");
                    sx_status = SX_STATUS_ERROR;
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __issu_lag_port_list_json_add(sx_port_log_id_t  lag_log_port,
                                                 sx_port_log_id_t *log_port_list,
                                                 uint32_t          port_list_cnt,
                                                 cJSON           **json_obj)
{
    cJSON      *arr_obj = NULL, *tmp_obj = NULL;
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    tmp_obj = cJSON_CreateNumber(lag_log_port);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);

    cJSON_AddItemToObject(*json_obj, "lag_log_port", tmp_obj);
    tmp_obj = cJSON_CreateNumber(port_list_cnt);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(*json_obj, "port_list_cnt", tmp_obj);
    arr_obj = cJSON_CreateArray();
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(arr_obj, sx_status);
    cJSON_AddItemToObject(*json_obj, "log_ports_list", arr_obj);

    for (i = 0; i < port_list_cnt; i++) {
        tmp_obj = cJSON_CreateNumber(log_port_list[i]);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
        cJSON_AddItemToArray(arr_obj, tmp_obj);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_lag_info_ex_store(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p, FILE *stream)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_port_log_id_t  lag_log_port;
    sx_port_log_id_t *log_port_list = NULL;
    uint32_t          lag_log_port_count = 1;
    uint32_t          port_list_cnt = rm_resource_global.lag_port_members_max;
    sx_access_cmd_t   cmd = SX_ACCESS_CMD_GET_FIRST;
    sx_port_log_id_t  current_lag_log_port = 0;
    cJSON            *json_obj = NULL, *arr_obj = NULL, *tmp_obj = NULL;
    char             *json_obj_str = NULL;

    SX_LOG_ENTER();

    log_port_list = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * port_list_cnt);
    if (log_port_list == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }
    if (issu_pdb_file_xlate_info_p->pdb_file_version == ISSU_PDB_FILE_VERSION_2) {
        json_obj = cJSON_CreateObject();
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(json_obj, sx_status);
        arr_obj = cJSON_CreateArray();
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(arr_obj, sx_status);
        cJSON_AddItemToObject(json_obj, "lag_map_list", arr_obj);
    }
    /* Get LAG info as long as iter does not return lag_log_port_count=0 */
    while (lag_log_port_count == 1) {
        sx_status = sx_lag_port_group_iter_get(cmd,
                                               0,
                                               current_lag_log_port,
                                               NULL,
                                               &lag_log_port,
                                               &lag_log_port_count);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get LAG iterator, err[%s]\n", sx_status_str(sx_status));
            goto out;
        }

        if ((lag_log_port_count == 0)) {
            break;
        }

        /* Get its port list */
        port_list_cnt = rm_resource_global.lag_port_members_max;
        sx_status = sx_la_db_log_port_get(SX_PORT_LAG_ID_GET(lag_log_port), 0, log_port_list, &port_list_cnt);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Get LAG ports list failed for [0x%08X], "
                       "err[%s]\n", lag_log_port,
                       sx_status_str(sx_status));
            goto out;
        }
        if (issu_pdb_file_xlate_info_p->pdb_file_version == ISSU_PDB_FILE_VERSION_1) {
            /* Write LAG info to file */
            /* lag_log_port(32), port_list_cnt(32), sx_port_log_id_t(32*port_list_cnt) */
            sx_status = __issu_persistent_info_write_to_storage(&lag_log_port, sizeof(sx_port_log_id_t), 1, stream);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Error writing LAG data to storage \n");
                goto out;
            }

            sx_status = __issu_persistent_info_write_to_storage(&port_list_cnt, sizeof(uint32_t), 1, stream);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Error writing LAG data to storage \n");
                goto out;
            }

            sx_status = __issu_persistent_info_write_to_storage(log_port_list,
                                                                sizeof(sx_port_log_id_t),
                                                                port_list_cnt,
                                                                stream);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Error writing LAG data to storage \n");
                goto out;
            }
        } else if (issu_pdb_file_xlate_info_p->pdb_file_version == ISSU_PDB_FILE_VERSION_2) {
            tmp_obj = cJSON_CreateObject();
            ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
            cJSON_AddItemToObject(arr_obj, "lag_entry", tmp_obj);
            sx_status = __issu_lag_port_list_json_add(lag_log_port, log_port_list, port_list_cnt, &tmp_obj);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Error writing LAG data to storage \n");
                goto out;
            }
        } else {
            sx_status = SX_STATUS_ERROR;
            SX_LOG_ERR("Invalid file version for LAG data to storage \n");
            goto out;
        }

        /* Next LAG in next iteration: */
        cmd = SX_ACCESS_CMD_GETNEXT;
        current_lag_log_port = lag_log_port;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version == ISSU_PDB_FILE_VERSION_2) {
        json_obj_str = cJSON_Print(json_obj);
        if (json_obj_str == NULL) {
            sx_status = SX_STATUS_ERROR;
            SX_LOG_ERR("Failed to print the JSON object into a string (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }
        fprintf(stream, "%s", json_obj_str);
    }

out:
    if (log_port_list != NULL) {
        CL_FREE_N_NULL(log_port_list);
    }
    if (json_obj) {
        cJSON_Delete(json_obj);
    }
    if (json_obj_str != NULL) {
        cJSON_free(json_obj_str);
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_lag_info_json_restore(FILE* stream)
{
    sx_status_t sx_status = 0;
    size_t      length = 0;
    cl_status_t cl_status;
    char      * buffer = NULL;
    const char *error_ptr = NULL;
    cJSON      *json_obj = NULL, *log_ports_obj = NULL,
               *log_port_obj = NULL, *lags_mapping_obj = NULL,
               *lag_ports_obj = NULL, *tmp_obj = NULL;
    uint32_t         i = 0;
    sx_port_log_id_t lag_log_port = 0;
    sx_port_phy_id_t local_port = 0;
    sx_lag_id_t      lid;

    fseek(stream, 0, SEEK_SET);
    cl_status = cl_file_size(stream, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    buffer = cl_malloc(length + 1);
    if (!buffer) {
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    if (cl_fread(buffer, 1, length, stream) != length) {
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer[length] = 0;

    json_obj = cJSON_Parse(buffer);
    if (json_obj == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("LAG restore - Error before: %s\n", error_ptr);
        }
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    lags_mapping_obj = cJSON_GetObjectItemCaseSensitive(json_obj, "lag_map_list");
    if (lags_mapping_obj == NULL) {
        SX_LOG_NTC("lag_map_list get from JSON PDB failed\n");
        goto out;
    }
    cJSON_ArrayForEach(lag_ports_obj, lags_mapping_obj) {
        tmp_obj = cJSON_GetObjectItemCaseSensitive(lag_ports_obj, "lag_log_port");
        ISSU_JSON_OBJ_GET(tmp_obj, "lag_log_port", lag_log_port);

        lid = SX_PORT_LAG_ID_GET(lag_log_port);
        if (lid >= rm_resource_global.lag_num_max) {
            sx_status = SX_STATUS_ERROR;
            SX_LOG_ERR("Error reading LAG data from storage LID not valid \n");
            goto out;
        }
        g_lag_to_ports_mapping[lid].lid_exist = TRUE;
        tmp_obj = cJSON_GetObjectItemCaseSensitive(lag_ports_obj, "port_list_cnt");
        ISSU_JSON_OBJ_GET(tmp_obj, "port_list_cnt", g_lag_to_ports_mapping[lid].port_list_cnt);

        log_ports_obj = cJSON_GetObjectItemCaseSensitive(lag_ports_obj, "log_ports_list");
        if (log_ports_obj == NULL) {
            SX_LOG_NTC("log_ports_list get from JSON PDB failed\n");
            goto out;
        }
        i = 0;
        cJSON_ArrayForEach(log_port_obj, log_ports_obj) {
            if (!cJSON_IsNumber(log_port_obj)) {
                goto out;
            }
            g_lag_to_ports_mapping[lid].log_port_list[i] = log_port_obj->valuedouble;
            i++;
        }

        for (i = 0; i < g_lag_to_ports_mapping[lid].port_list_cnt; i++) {
            local_port = SX_PORT_PHY_ID_GET(g_lag_to_ports_mapping[lid].log_port_list[i]);
            if (local_port <= rm_resource_global.port_ext_num_max) {
                g_port_to_lag_mapping[local_port - 1] = lid;
            } else {
                SX_LOG_ERR("out of range local_port(%d)\n", local_port);
                goto out;
            }
        }
    }

out:
    if (buffer) {
        cl_free(buffer);
    }
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    return sx_status;
}

static sx_status_t __issu_lag_info_ex_restore(issu_pdb_file_xlate_info_t * issu_pdb_file_xlate_info_p, FILE *stream)
{
    uint32_t         i = 0;
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    sx_port_log_id_t lag_log_port;
    sx_lag_id_t      lid;
    size_t           file_size = 0;
    cl_status_t      rc = 0;
    sx_port_phy_id_t local_port;

    SX_LOG_ENTER();

    rc = cl_file_size(stream, &file_size);
    if (rc != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(rc));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    g_lag_to_ports_mapping =
        (sx_issu_lag_info_t*)cl_malloc(sizeof(sx_issu_lag_info_t) * rm_resource_global.lag_num_max);
    if (g_lag_to_ports_mapping == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(g_lag_to_ports_mapping, 0, sizeof(sx_issu_lag_info_t) * rm_resource_global.lag_num_max);

    for (i = 0; i < rm_resource_global.lag_num_max; i++) {
        g_lag_to_ports_mapping[i].log_port_list =
            (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
        if (g_lag_to_ports_mapping[i].log_port_list == NULL) {
            sx_status = SX_STATUS_NO_MEMORY;
            goto out;
        }
        memset(g_lag_to_ports_mapping[i].log_port_list,
               0,
               sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
    }

    g_port_to_lag_mapping =
        (sx_lag_id_t*)cl_malloc(sizeof(sx_lag_id_t) * rm_resource_global.port_ext_num_max);
    if (g_port_to_lag_mapping == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }

    for (i = 0; i < rm_resource_global.port_ext_num_max; i++) {
        g_port_to_lag_mapping[i] = INVALID_LAG_ID;
    }

    g_issu_lag_fdb_not_recoverable = FALSE;
    g_lag_db_initialized = TRUE;

    switch (issu_pdb_file_xlate_info_p->pdb_file_version) {
    case ISSU_PDB_FILE_VERSION_1:
        while (file_size > 0) {
            /* Read a "record":
             * |--------|--------|--------|-------|--------|
             * | _port  |list_cnt| port 1 | ....  | port N |
             * |--------|--------|--------|-------|--------|*/

            sx_status = __issu_persistent_info_read_from_storage(&lag_log_port, sizeof(sx_port_log_id_t), 1, stream);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error reading LAG data from storage \n");
                goto out;
            }
            lag_log_port = CONVERT_LAG_LOG_ID_FROM_V1(lag_log_port);

            file_size -= sizeof(sx_port_log_id_t);

            lid = SX_PORT_LAG_ID_GET(lag_log_port);
            if (lid >= rm_resource_global.lag_num_max) {
                sx_status = SX_STATUS_ERROR;
                SX_LOG_ERR("Error reading LAG data from storage LID not valid \n");
                goto out;
            }

            sx_status = __issu_persistent_info_read_from_storage(&g_lag_to_ports_mapping[lid].port_list_cnt,
                                                                 sizeof(uint32_t),
                                                                 1,
                                                                 stream);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error reading LAG data from storage \n");
                goto out;
            }

            file_size -= sizeof(uint32_t);

            if (g_lag_to_ports_mapping[lid].port_list_cnt > rm_resource_global.lag_port_members_max) {
                sx_status = SX_STATUS_ERROR;
                SX_LOG_ERR("Error reading port data from storage, port list count (%d) exceeds max (%d)\n",
                           g_lag_to_ports_mapping[lid].port_list_cnt,  rm_resource_global.lag_port_members_max);
                goto out;
            }


            sx_status = __issu_persistent_info_read_from_storage(g_lag_to_ports_mapping[lid].log_port_list,
                                                                 sizeof(sx_port_log_id_t),
                                                                 g_lag_to_ports_mapping[lid].port_list_cnt,
                                                                 stream);

            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error reading LAG data from storage \n");
                goto out;
            }

            for (i = 0; i < g_lag_to_ports_mapping[lid].port_list_cnt; i++) {
                g_lag_to_ports_mapping[lid].log_port_list[i] =
                    CONVERT_LAG_LOG_ID_FROM_V1(g_lag_to_ports_mapping[lid].log_port_list[i]);
            }

            file_size -= (sizeof(sx_port_log_id_t) * g_lag_to_ports_mapping[lid].port_list_cnt);

            g_lag_to_ports_mapping[lid].lid_exist = TRUE;

            for (i = 0; i < g_lag_to_ports_mapping[lid].port_list_cnt; i++) {
                local_port = SX_PORT_PHY_ID_GET(g_lag_to_ports_mapping[lid].log_port_list[i]);
                if (local_port <= rm_resource_global.port_ext_num_max) {
                    g_port_to_lag_mapping[local_port - 1] = lid;
                } else {
                    SX_LOG_ERR("out of range local_port(%d)\n", local_port);
                    goto out;
                }
            }
        }
        break;

    case ISSU_PDB_FILE_VERSION_2:
        sx_status = __issu_lag_info_json_restore(stream);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error restoring LAG data from JSON storage \n");
            goto out;
        }
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("LAG PDB file version is invalid , version = %d \n",
                   issu_pdb_file_xlate_info_p->pdb_file_version);
        goto out;
    }

out:
    if (sx_status != SX_STATUS_SUCCESS) {
        if (g_lag_to_ports_mapping != NULL) {
            for (i = 0; i < rm_resource_global.lag_num_max; i++) {
                if (g_lag_to_ports_mapping[i].log_port_list != NULL) {
                    CL_FREE_N_NULL(g_lag_to_ports_mapping[i].log_port_list);
                }
            }
            CL_FREE_N_NULL(g_lag_to_ports_mapping);
        }

        if (g_port_to_lag_mapping != NULL) {
            CL_FREE_N_NULL(g_port_to_lag_mapping);
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_lag_create_empty_lags()
{
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    uint32_t         i = 0;
    sx_port_log_id_t lag_port = 0;

    SX_LOG_ENTER();

    if ((g_lag_db_initialized == TRUE) &&
        (g_issu_lag_config_restore_flag == TRUE)) {
        for (i = 0; i < rm_resource_global.lag_num_max; i++) {
            if ((g_lag_to_ports_mapping[i].lid_exist == TRUE) && (g_lag_to_ports_mapping[i].port_list_cnt == 0)) {
                lag_port = 0;
                SX_PORT_TYPE_ID_SET(lag_port, SX_PORT_TYPE_LAG);
                SX_PORT_LAG_ID_SET(lag_port, i);
                sx_status = sx_lag_port_group_set(SX_ACCESS_CMD_CREATE,
                                                  0 /*swid*/,
                                                  &lag_port,
                                                  NULL,
                                                  0);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("sx_lag_port_group_set CREATE failed. LAG 0x%x\n", lag_port);
                    goto out;
                }
                g_lag_to_ports_mapping[i].lid_exist = FALSE;
            }
        }
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __port_map_json_store(FILE* stream, sx_port_attributes_t *port_attributes_list_p,
                                         uint32_t *port_num)
{
    cJSON      *json_obj = NULL;
    cJSON      *ports = NULL;
    cJSON      *port = NULL;
    cJSON      *tmp = NULL;
    char       *json_obj_str = NULL;
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    i = 0, num_stored = 0;

    SX_LOG_ENTER();

    json_obj = cJSON_CreateObject();
    if (json_obj == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to create JSON object for ISSU port map store (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    ports = cJSON_CreateArray();
    if (ports == NULL) {
        SX_LOG_ERR("Failed to create JSON array");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    cJSON_AddItemToObject(json_obj, "ports_attributes_list", ports);

    for (i = 0; i < (*port_num); i++) {
        if (port_attributes_list_p[i].port_mapping.mapping_mode != SX_PORT_MAPPING_MODE_ENABLE) {
            /* Write to storage only mapped ports*/
            continue;
        }
        port = cJSON_CreateObject();
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(port, sx_status);
        cJSON_AddItemToArray(ports, port);
        tmp = cJSON_CreateNumber(port_attributes_list_p[i].port_mapping.local_port);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp, sx_status);
        cJSON_AddItemToObject(port, "local_port", tmp);
        tmp = cJSON_CreateNumber(port_attributes_list_p[i].port_mapping.lane_bmap);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp, sx_status);
        cJSON_AddItemToObject(port, "lane_bmap", tmp);
        tmp = cJSON_CreateNumber(port_attributes_list_p[i].port_mapping.mapping_mode);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp, sx_status);
        cJSON_AddItemToObject(port, "mapping_mode", tmp);
        tmp = cJSON_CreateNumber(port_attributes_list_p[i].port_mapping.module_port);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp, sx_status);
        cJSON_AddItemToObject(port, "module_port", tmp);
        tmp = cJSON_CreateNumber(port_attributes_list_p[i].port_mapping.slot);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp, sx_status);
        cJSON_AddItemToObject(port, "slot", tmp);
        tmp = cJSON_CreateNumber(port_attributes_list_p[i].port_mapping.width);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp, sx_status);
        cJSON_AddItemToObject(port, "width", tmp);
        num_stored++;
    }
    tmp = cJSON_CreateNumber(num_stored);
    if (tmp == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to create JSON object for ISSU port map store (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    cJSON_AddItemToObject(json_obj, "port_num", tmp);

    json_obj_str = cJSON_Print(json_obj);
    if (json_obj_str == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to print the JSON object into a string (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    fprintf(stream, "%s", json_obj_str);
out:
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }

    if (json_obj_str != NULL) {
        cJSON_free(json_obj_str);
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_port_map_json_restore(void *stream)
{
    sx_status_t sx_status = 0;
    size_t      length = 0;
    cl_status_t cl_status = 0;
    char      * buffer = NULL;
    const char *error_ptr = NULL;
    cJSON      *json_obj = NULL, *tmp_obj = NULL,
               *port_mapping_list = NULL, *port_mapping = NULL;
    sx_port_phy_id_t local_port = 0;

    fseek(stream, 0, SEEK_SET);
    cl_status = cl_file_size(stream, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer = cl_malloc(length + 1);
    if (!buffer) {
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    if (cl_fread(buffer, 1, length, stream) != length) {
        SX_LOG_ERR("Error reading port map JSON file \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer[length] = 0;

    json_obj = cJSON_Parse(buffer);
    if (json_obj == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("Port map restore - Error before: %s\n", error_ptr);
        }
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    tmp_obj = cJSON_GetObjectItemCaseSensitive(json_obj, "port_num");
    ISSU_JSON_OBJ_GET(tmp_obj, "port_num",  g_port_map_info.port_num);

    if (g_port_map_info.port_num > rm_resource_global.port_ext_num_max) {
        SX_LOG_ERR("g_port_map_info.port_num exceeded range\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    port_mapping_list = cJSON_GetObjectItemCaseSensitive(json_obj, "ports_attributes_list");
    if (port_mapping_list == NULL) {
        SX_LOG_NTC("port_mapping_list field get from JSON pdb failed\n");
    } else {
        cJSON_ArrayForEach(port_mapping, port_mapping_list)
        {
            tmp_obj = cJSON_GetObjectItemCaseSensitive(port_mapping, "local_port");
            ISSU_JSON_OBJ_GET(tmp_obj, "local_port", local_port);
            g_port_map_info.port_mapping_list_p[local_port - 1].local_port = local_port;

            tmp_obj = cJSON_GetObjectItemCaseSensitive(port_mapping, "lane_bmap");
            ISSU_JSON_OBJ_GET(tmp_obj, "lane_bmap", g_port_map_info.port_mapping_list_p[local_port - 1].lane_bmap);

            tmp_obj = cJSON_GetObjectItemCaseSensitive(port_mapping, "mapping_mode");
            ISSU_JSON_OBJ_GET(tmp_obj, "mapping_mode",
                              g_port_map_info.port_mapping_list_p[local_port - 1].mapping_mode);

            tmp_obj = cJSON_GetObjectItemCaseSensitive(port_mapping, "module_port");
            ISSU_JSON_OBJ_GET(tmp_obj, "module_port", g_port_map_info.port_mapping_list_p[local_port - 1].module_port);

            tmp_obj = cJSON_GetObjectItemCaseSensitive(port_mapping, "slot");
            ISSU_JSON_OBJ_GET(tmp_obj, "slot", g_port_map_info.port_mapping_list_p[local_port - 1].slot);

            tmp_obj = cJSON_GetObjectItemCaseSensitive(port_mapping, "width");
            ISSU_JSON_OBJ_GET(tmp_obj, "width", g_port_map_info.port_mapping_list_p[local_port - 1].width);
        }
    }
out:
    if (buffer) {
        cl_free(buffer);
    }
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    return sx_status;
}

static sx_status_t __issu_port_map_ex_store(issu_pdb_file_version_e version, void *ctxt_p)
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS, sx_status_out = SX_STATUS_SUCCESS;
    uint32_t                           j = 0, port_num = 0, port_num_to_store = 0;
    sx_port_attributes_t              *port_attributes_p = NULL;
    int                                i = 0, device_cnt = SX_DEV_ID_MAX;
    topo_device_item_t                 dev_attrib[SX_DEV_ID_MAX];
    sx_swid_t                          swid = rm_resource_global.swid_id_max;
    sx_dev_id_t                        dev_id;
    uint32_t                           port_mapping_struct_sz = 0;
    FILE                              *stream = NULL;
    issu_pdb_file_xlate_info_t        *issu_pdb_xlate_info_p = NULL;
    issu_pdb_file_version_db_entity_t *db_entity_p = NULL;
    issu_pdb_file_version_e            current_version = ISSU_PDB_FILE_VERSION_INVALID;
    char                              *file_name_p = NULL;
    uint8_t                            version_idx = 0;
    char                               port_map_path[ISSU_PERSISTENT_PATH_LEN_MAX] = {0};

    SX_LOG_ENTER();

    issu_pdb_xlate_info_p = (issu_pdb_file_xlate_info_t*)ctxt_p;
    db_entity_p = &g_issu_pdb_version_db[issu_pdb_xlate_info_p->file_info_type_e];

    if (utils_check_pointer(db_entity_p, "db_entity_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (g_infiniband_issu) {
        swid = 0;
    }

    for (current_version = version; current_version >= ISSU_PDB_FILE_MIN_VERSION; current_version--) {
        version_idx = __issu_pdb_get_db_index_by_file_version(current_version);
        file_name_p = db_entity_p->issu_pdb_version_file_name_map[version_idx];
        SX_MEM_CLR_ARRAY(port_map_path, ISSU_PERSISTENT_PATH_LEN_MAX, char);
        /* coverity[buffer_size_warning] */
        strncpy(port_map_path, g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E],
                ISSU_PERSISTENT_PATH_LEN_MAX);
        strncat(port_map_path, file_name_p, sizeof(port_map_path) - strlen(port_map_path) - 1);

        sx_status = __issu_persistent_info_storage_open(port_map_path, "wb", &stream);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_open failed (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("failed in topo_db_device_list_get err = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        if (device_cnt == 0) {
            SX_LOG_ERR("can't get topo device list register values , device list is empty\n");
            sx_status = SX_STATUS_ERROR;
            goto out;
        }

        for (i = 0; i < device_cnt; i++) {
            dev_id = dev_attrib[i].dev_id;
            sx_status = port_device_get(SX_ACCESS_CMD_COUNT, dev_id, swid, NULL, &port_num);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(" __issu_port_map_store - Failed to retrieve number of ports on device (%u)"
                           "and swid (%u)  (%s).\n",
                           dev_id, swid, sx_status_str(sx_status));
                goto out;
            }

            if (port_num == 0) {
                if ((current_version == ISSU_PDB_FILE_VERSION_1) || (current_version == ISSU_PDB_FILE_VERSION_2)) {
                    /* Write zero ports as well, as this is a valid condition for modular systems */
                    sx_status =
                        __issu_persistent_info_write_to_storage(&port_num_to_store, sizeof(uint32_t), 1, stream);
                    if (SX_CHECK_FAIL(sx_status)) {
                        SX_LOG_ERR("Error writing PORT MAP data to storage \n");
                        goto out;
                    }
                } else if (current_version == ISSU_PDB_FILE_VERSION_3) {
                    sx_status = __port_map_json_store(stream, NULL, &port_num);
                    if (SX_CHECK_FAIL(sx_status)) {
                        SX_LOG_ERR("Error writing PORT MAP data to JSON storage \n");
                        goto out;
                    }
                }
                continue;
            }

            port_attributes_p = (sx_port_attributes_t*)cl_malloc(port_num * sizeof(sx_port_attributes_t));
            if (port_attributes_p == NULL) {
                sx_status = SX_STATUS_NO_MEMORY;
                SX_LOG_ERR("__issu_port_map_store - Failed in memory allocation (%s).\n",
                           sx_status_str(sx_status));
                goto out;
            }

            /*get device logical ports list*/
            sx_status = port_device_get(SX_ACCESS_CMD_GET, dev_id, swid, port_attributes_p, &port_num);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(" __issu_port_map_store - Failed to retrieve ports info on device (%u)"
                           "and swid (%u)  (%s).\n",
                           dev_id, swid, sx_status_str(sx_status));
                goto out;
            }

            for (j = 0; j < port_num; j++) {
                if (port_attributes_p[j].port_mapping.mapping_mode == SX_PORT_MAPPING_MODE_ENABLE) {
                    if ((current_version == ISSU_PDB_FILE_VERSION_1) &&
                        (port_attributes_p[j].port_mapping.slot != 0)) {
                        continue;
                    }
                    /* Write to storage only mapped ports*/
                    port_num_to_store++;
                }
            }
            if ((current_version == ISSU_PDB_FILE_VERSION_1) || (current_version == ISSU_PDB_FILE_VERSION_2)) {
                sx_status = __issu_persistent_info_write_to_storage(&port_num_to_store, sizeof(uint32_t), 1, stream);
                if (SX_CHECK_FAIL(sx_status)) {
                    SX_LOG_ERR("Error writing PORT MAP data to storage \n");
                    goto out;
                }

                if (current_version == ISSU_PDB_FILE_VERSION_1) {
                    port_mapping_struct_sz = SX_PORT_MAPPING_V1_SIZE;
                } else if (current_version == ISSU_PDB_FILE_VERSION_2) {
                    port_mapping_struct_sz = sizeof(sx_port_mapping_v2_t);
                }

                for (j = 0; j < port_num; j++) {
                    if (port_attributes_p[j].port_mapping.mapping_mode != SX_PORT_MAPPING_MODE_ENABLE) {
                        /* Write to storage only mapped ports*/
                        continue;
                    }
                    if ((current_version == ISSU_PDB_FILE_VERSION_1) &&
                        (port_attributes_p[j].port_mapping.slot != 0)) {
                        /* Write to storage only mapping with slotID(0)
                         * version(1) was used by only 1U systems.
                         * and 1U systems cannot process non zero slots.
                         */
                        continue;
                    }
                    sx_status = __issu_persistent_info_write_to_storage(&port_attributes_p[j].port_mapping,
                                                                        port_mapping_struct_sz, 1, stream);
                    if (SX_CHECK_FAIL(sx_status)) {
                        SX_LOG_ERR("Error writing PORT MAP data to storage, local port - %d \n",
                                   port_attributes_p[j].port_mapping.local_port);
                        goto out;
                    }
                }
            } else if (current_version == ISSU_PDB_FILE_VERSION_3) {
                sx_status = __port_map_json_store(stream, port_attributes_p, &port_num);
                if (SX_CHECK_FAIL(sx_status)) {
                    SX_LOG_ERR("Error writing PORT MAP data to JSON storage \n");
                    goto out;
                }
            } else {
                sx_status = SX_STATUS_ERROR;
                SX_LOG_ERR("Error writing PORT MAP data, incompatible version.\n");
                goto out;
            }

            /* Clean list for each device (just a formality since there is only one device...)*/
            if (port_attributes_p != NULL) {
                CL_FREE_N_NULL(port_attributes_p);
                port_num = 0;
                port_num_to_store = 0;
            }
        } /*for (i = 0; i < device_cnt; i++) */
        sx_status = __issu_persistent_info_storage_close(&stream);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n", port_map_path);
            goto out;
        }
        stream = NULL;
        file_name_p = NULL;
    } /*for (current_version=version; current_version >= ISSU_PORT_MAP_FILE_MIN_VERSION; current_version--)*/

out:
    if (port_attributes_p != NULL) {
        CL_FREE_N_NULL(port_attributes_p);
    }
    if (stream != NULL) {
        sx_status_out = __issu_persistent_info_storage_close(&stream);
        if (sx_status_out != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s. err = %s\n", port_map_path,
                       sx_status_str(sx_status_out));
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

static void __issu_port_mapping_fields_copy(sx_port_mapping_t* cur_mapping, sx_port_mapping_v2_t* v2_mapping)
{
    cur_mapping->lane_bmap = v2_mapping->lane_bmap;
    cur_mapping->local_port = v2_mapping->local_port;
    cur_mapping->mapping_mode = v2_mapping->mapping_mode;
    cur_mapping->module_port = v2_mapping->module_port;
    cur_mapping->slot = v2_mapping->slot;
    cur_mapping->width = v2_mapping->width;
    return;
}

static sx_status_t __issu_port_map_ex_restore(issu_pdb_file_version_e version, FILE *stream)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    size_t               file_size = 0;
    sx_port_mapping_v2_t port_map_tmp;
    cl_status_t          rc = 0;
    uint32_t             port_mapping_struct_sz = 0;

    SX_LOG_ENTER();


    rc = cl_file_size(stream, &file_size);
    if (rc != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(rc));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    /* No need to allocate memory and read an empty file. */
    if (file_size == 0) {
        goto out;
    }

    g_port_map_info.port_mapping_list_p =
        (sx_port_mapping_t*)cl_malloc(sizeof(sx_port_mapping_t) * rm_resource_global.port_ext_num_max);
    if (g_port_map_info.port_mapping_list_p == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(g_port_map_info.port_mapping_list_p, 0, sizeof(sx_port_mapping_t) * rm_resource_global.port_ext_num_max);

    g_port_map_info.port_mapping_done_p =
        (boolean_t*)cl_malloc(sizeof(boolean_t) * rm_resource_global.port_ext_num_max);
    if (g_port_map_info.port_mapping_done_p == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(g_port_map_info.port_mapping_done_p, 0, sizeof(boolean_t) * rm_resource_global.port_ext_num_max);

    g_port_map_info.list_size = rm_resource_global.port_ext_num_max;

    switch (version) {
    case ISSU_PDB_FILE_VERSION_1:
    case ISSU_PDB_FILE_VERSION_2:
        sx_status = __issu_persistent_info_read_from_storage(&g_port_map_info.port_num, sizeof(uint32_t), 1, stream);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error reading PORT MAP data from storage \n");
            goto out;
        }
        file_size -= sizeof(uint32_t);

        if (g_port_map_info.port_num > rm_resource_global.port_ext_num_max) {
            SX_LOG_ERR("g_port_map_info.port_num exceeded range\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        /* restore from v1 */
        if (version == ISSU_PDB_FILE_VERSION_1) {
            port_mapping_struct_sz = SX_PORT_MAPPING_V1_SIZE;
        } else {
            port_mapping_struct_sz = sizeof(sx_port_mapping_v2_t);
        }

        if (file_size != (port_mapping_struct_sz * g_port_map_info.port_num)) {
            SX_LOG_ERR("Error reading PORT MAP data, incorrect file size\n");
            sx_status = SX_STATUS_ERROR;
            goto out;
        }

        while (file_size > 0) {
            memset(&port_map_tmp, 0, sizeof(sx_port_mapping_v2_t));
            sx_status = __issu_persistent_info_read_from_storage(&port_map_tmp,
                                                                 port_mapping_struct_sz, 1, stream);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error reading PORT MAP from storage \n");
                goto out;
            }

            if ((port_map_tmp.local_port > rm_resource_global.port_ext_num_max) ||
                (port_map_tmp.local_port == 0)) {
                SX_LOG_ERR("Error reading PORT MAP data, incorrect local port data\n");
                sx_status = SX_STATUS_ERROR;
                goto out;
            }
            __issu_port_mapping_fields_copy(&g_port_map_info.port_mapping_list_p[port_map_tmp.local_port - 1],
                                            &port_map_tmp);
            file_size -= port_mapping_struct_sz;
        }
        break;

    case ISSU_PDB_FILE_VERSION_3:
        sx_status = __issu_port_map_json_restore(stream);
        break;

    default:
        SX_LOG_ERR("Invalid version passed\n");
        sx_status = SX_STATUS_PARAM_ERROR;
        break;
    }

    g_port_map_info.persistent_flag = TRUE;

out:
    if (sx_status != SX_STATUS_SUCCESS) {
        if (g_port_map_info.port_mapping_list_p != NULL) {
            CL_FREE_N_NULL(g_port_map_info.port_mapping_list_p);
        }
        if (g_port_map_info.port_mapping_done_p != NULL) {
            CL_FREE_N_NULL(g_port_map_info.port_mapping_done_p);
        }
        g_port_map_info.port_num = 0;
        g_port_map_info.list_size = 0;
    }

    SX_LOG_EXIT();
    return sx_status;
}
static sx_status_t __issu_pdb_get_db_index_by_file_version(issu_pdb_file_version_e version)
{
    switch (version) {
    case ISSU_PDB_FILE_VERSION_1:
        return 0;

    case ISSU_PDB_FILE_VERSION_2:
        return 1;

    case ISSU_PDB_FILE_VERSION_3:
        return 2;

    default:
    case ISSU_PDB_FILE_VERSION_INVALID:
        return 0;
    }
}

/* Version based extended restore from older version or latest version to
 * to latest version.
 */
static sx_status_t __issu_restore_ex_wrapper(issu_pdb_file_info_type_e file_info_type_e,
                                             FILE                     *stream,
                                             issu_pdb_file_version_e   version,
                                             void                    * param)
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS;
    issu_pdb_file_version_db_entity_t *db_entity_p = NULL;
    issu_pdb_file_xlate_func_t         pdb_xlate_func = NULL;
    issu_pdb_file_xlate_info_t         issu_pdb_xlate_info;
    uint8_t                            version_idx = 0;

    SX_LOG_ENTER();


    db_entity_p = &g_issu_pdb_version_db[file_info_type_e];
    if (utils_check_pointer(db_entity_p, "db_entity_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    version_idx = __issu_pdb_get_db_index_by_file_version(version);
    pdb_xlate_func = db_entity_p->issu_pdb_file_xlate_map[version_idx];
    if (pdb_xlate_func == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("version[%u] translation is not available, sx_status = %s\n",
                   version, sx_status_str(sx_status));
        goto out;
    }

    SX_MEM_CLR(issu_pdb_xlate_info);
    issu_pdb_xlate_info.file_oper_e = ISSU_PDB_FILE_XLATE_OPER_RESTORE;
    issu_pdb_xlate_info.pdb_file_version = version;
    sx_status = pdb_xlate_func(&issu_pdb_xlate_info, (void*)stream, param);

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] restore operation[%u] failed, sx_status = %s\n",
                   issu_pdb_xlate_info.pdb_file_version,
                   issu_pdb_xlate_info.file_oper_e, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __issu_store_ex_wrapper(issu_pdb_file_info_type_e file_info_type_e, void* param)
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS;
    issu_pdb_file_version_db_entity_t *db_entity_p = NULL;
    issu_pdb_file_xlate_func_t         pdb_xlate_func = NULL;
    issu_pdb_file_xlate_info_t         issu_pdb_xlate_info;
    uint8_t                            version_idx = 0;
    FILE                             * f_p = NULL;

    SX_LOG_ENTER();

    db_entity_p = &g_issu_pdb_version_db[file_info_type_e];
    if (utils_check_pointer(db_entity_p, "db_entity_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    /*Store current version and all below versions.*/
    version_idx = __issu_pdb_get_db_index_by_file_version(db_entity_p->latest_version_e);
    pdb_xlate_func = db_entity_p->issu_pdb_file_xlate_map[version_idx];
    if (pdb_xlate_func == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("version[%u] translation is not available, sx_status = %s\n",
                   db_entity_p->latest_version_e, sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_persistent_info_storage_open_ex(file_info_type_e, "w", &f_p, &db_entity_p->latest_version_e);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to open issu bank file\n");
        goto out;
    }
    SX_MEM_CLR(issu_pdb_xlate_info);
    issu_pdb_xlate_info.file_oper_e = ISSU_PDB_FILE_XLATE_OPER_STORE;
    issu_pdb_xlate_info.file_info_type_e = file_info_type_e;
    issu_pdb_xlate_info.pdb_file_version = db_entity_p->latest_version_e;
    sx_status = pdb_xlate_func(&issu_pdb_xlate_info, f_p, param);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] store operation[%u] failed, sx_status = %s\n",
                   issu_pdb_xlate_info.pdb_file_version,
                   issu_pdb_xlate_info.file_oper_e, sx_status_str(sx_status));
        goto out;
    }

out:
    if (f_p) {
        sx_status = __issu_persistent_info_storage_close(&f_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                       g_issu_pdb_paths_db[db_entity_p->latest_version_e]);
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __port_map_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                                void                       *ctxt_p,
                                                void                      * param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(param);

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_1) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s] \n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        /* Restore from port map pdb version 1 */
        sx_status = __issu_port_map_ex_restore(issu_pdb_file_xlate_info_p->pdb_file_version, (FILE*)ctxt_p);
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        /* version(1) is the minimal version for port map pdb file, so a store
         * operation will never be required. This code is added as a guideline
         * for porting to issu pdb version framework if version(1) is the only
         * and the latest version. Store is applicable only for non minimal
         * version. Store operation generates pdb file in all versions.
         */
        sx_status = __issu_port_map_ex_store(issu_pdb_file_xlate_info_p->pdb_file_version, issu_pdb_file_xlate_info_p);
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
    }

out:
    return sx_status;
}

static sx_status_t __port_map_pdb_file_xlate_v2(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                                void                       *ctxt_p,
                                                void                      * param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(param);

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_2) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        /* Restore from port map pdb version 2.*/
        sx_status = __issu_port_map_ex_restore(issu_pdb_file_xlate_info_p->pdb_file_version, (FILE*)ctxt_p);
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        /* store port map pdb version 2 and below versions for current and previous SDK versions*/
        sx_status = __issu_port_map_ex_store(issu_pdb_file_xlate_info_p->pdb_file_version, issu_pdb_file_xlate_info_p);
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}

static sx_status_t __port_map_pdb_file_xlate_v3(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                                void                       *ctxt_p,
                                                void                      * param)
{
    UNUSED_PARAM(param);
    UNUSED_PARAM(ctxt_p);
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_3) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_port_map_ex_restore(issu_pdb_file_xlate_info_p->pdb_file_version, (FILE*)ctxt_p);
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        /* store port map pdb version 3 and below versions for current and previous SDK versions*/
        sx_status = __issu_port_map_ex_store(issu_pdb_file_xlate_info_p->pdb_file_version, issu_pdb_file_xlate_info_p);
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}
static sx_status_t __issu_pdb_bank_json_store(FILE* stream, sx_issu_bank_e store_bank)
{
    cJSON      *json_obj = NULL;
    cJSON      *bank = NULL;
    char       *json_obj_str = NULL;
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    json_obj = cJSON_CreateObject();
    if (json_obj == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to create JSON object for ISSU port map store (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    bank = cJSON_CreateNumber(store_bank);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(bank, sx_status);

    cJSON_AddItemToObject(json_obj, "bank", bank);
    json_obj_str = cJSON_Print(json_obj);
    if (json_obj_str == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to print the JSON object into a string (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    fprintf(stream, "%s", json_obj_str);
out:
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    if (json_obj_str != NULL) {
        cJSON_free(json_obj_str);
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_pdb_bank_json_restore(FILE* stream, uint8_t* bank)
{
    sx_status_t sx_status = 0;
    size_t      length = 0;
    cl_status_t cl_status = 0;
    char      * buffer = NULL;
    const char *error_ptr = NULL;
    cJSON      *json_obj = NULL;
    cJSON      *bank_obj = NULL;

    cl_status = cl_file_size(stream, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    buffer = cl_malloc(length + 1);
    if (!buffer) {
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    if (fread(buffer, 1, length, stream) != length) {
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer[length] = 0;

    json_obj = cJSON_Parse(buffer);
    if (json_obj == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("Bank restore - Error before: %s\n", error_ptr);
        }
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    bank_obj = cJSON_GetObjectItemCaseSensitive(json_obj, "bank");
    if ((bank_obj == NULL) || (!cJSON_IsNumber(bank_obj))) {
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    *bank = (uint8_t)bank_obj->valuedouble;
out:
    if (buffer) {
        cl_free(buffer);
    }
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    return sx_status;
}

sx_status_t __bank_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p, void *ctxt_p, void* param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    char        bank = '0';
    uint8_t     store_bank = 0;

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_1) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_persistent_info_read_from_storage(&bank, sizeof(bank), 1, ctxt_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error reading ISSU bank from storage \n");
            break;
        }
        if ((bank - '0' != SX_ISSU_BANK_1_E) &&
            (bank - '0' != SX_ISSU_BANK_2_E)) {
            SX_LOG_ERR("ISSU bank in file is not valid %u\n", bank - '0');
            sx_status = SX_STATUS_ERROR;
            break;
        }
        g_issu_params.issu_bank = bank - '0';
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        if (utils_check_pointer(param, "param")) {
            sx_status = SX_STATUS_PARAM_NULL;
            goto out;
        }
        store_bank = (*((sx_issu_bank_e*)param) == SX_ISSU_BANK_1_E) ? '0' : '1';
        sx_status = __issu_persistent_info_write_to_storage(&store_bank, sizeof(store_bank), 1, ctxt_p);

        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}

static sx_status_t __bank_pdb_file_xlate_v2(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                            void                       *ctxt_p,
                                            void                      * param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     bank = 0;


    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_2) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_pdb_bank_json_restore(ctxt_p, &bank);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error reading ISSU bank from storage \n");
            break;
        }
        if (bank > SX_ISSU_BANK_MAX_E) {
            SX_LOG_ERR("ISSU bank in file is not valid %u\n", bank);
            sx_status = SX_STATUS_ERROR;
            break;
        }
        g_issu_params.issu_bank = bank;

        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        if (utils_check_pointer(param, "param")) {
            sx_status = SX_STATUS_PARAM_NULL;
            goto out;
        }
        sx_status = __issu_pdb_bank_json_store(ctxt_p, (*(sx_issu_bank_e*)param));
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}

static sx_status_t __lag_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                           void                       *ctxt_p,
                                           void                      * param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(param);

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_1) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_lag_info_ex_restore(issu_pdb_file_xlate_info_p, ctxt_p);
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        sx_status = __issu_lag_info_ex_store(issu_pdb_file_xlate_info_p, ctxt_p);
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}

static sx_status_t __lag_pdb_file_xlate_v2(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                           void                       *ctxt_p,
                                           void                      * param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(param);

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_2) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_lag_info_ex_restore(issu_pdb_file_xlate_info_p, ctxt_p);
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        sx_status = __issu_lag_info_ex_store(issu_pdb_file_xlate_info_p, ctxt_p);
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}

static sx_status_t __profile_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                               void                       *ctxt_p,
                                               void                      * param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_1) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_profile_checksum_restore(ctxt_p, &((issu_profile_pdb_data_t*)param)->profile_csum);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error reading old Profile checksum from storage\n");
            goto out;
        }
        sx_status = __issu_profile_data_restore(ctxt_p, ((issu_profile_pdb_data_t*)param)->profile);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error reading old Profile from storage\n");
            goto out;
        }
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        sx_status = __issu_profile_store(ctxt_p, ((sx_api_profile_t*)param));
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}

static sx_status_t __profile_pdb_file_xlate_v2(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                               void                       *ctxt_p,
                                               void                      * param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_2) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_profile_checksum_json_restore(ctxt_p, &((issu_profile_pdb_data_t*)param)->profile_csum);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error reading old Profile checksum from storage\n");
            goto out;
        }
        sx_status = __issu_profile_data_json_restore(ctxt_p, ((issu_profile_pdb_data_t*)param)->profile);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error reading old Profile from storage\n");
            goto out;
        }
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        sx_status = __issu_profile_json_store(ctxt_p, ((issu_profile_pdb_data_t*)param)->profile);
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}

static int __issu_sb_pools_port_field_cmpr(const void* const p1, const void* const p2)
{
    return (*(sx_port_log_id_t*)p1 - *(sx_port_log_id_t*)p2);
}

static sx_status_t __issu_sb_pools_data_restore(FILE* stream, sx_cos_sb_issu_pools_pdb_data_t* sb_pools_pdb_p)
{
    sx_status_t sx_status = 0;
    size_t      length = 0;
    cl_status_t cl_status = 0;
    char      * buffer = NULL;
    const char *error_ptr = NULL;
    cJSON      *json_obj = NULL, *tmp_obj = NULL, *buff_attr_obj = NULL,
               *pools_arr = NULL, *pool_obj = NULL,
               *ports_arr = NULL, *port_obj = NULL;
    uint32_t pool_idx, port_idx;

    fseek(stream, 0, SEEK_SET);
    cl_status = cl_file_size(stream, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer = cl_malloc(length + 1);
    if (!buffer) {
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    if (cl_fread(buffer, 1, length, stream) != length) {
        SX_LOG_ERR("Error reading port map JSON file \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer[length] = 0;

    json_obj = cJSON_Parse(buffer);
    if (json_obj == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("SB pools restore - Error before: %s\n", error_ptr);
        }
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    pools_arr = cJSON_GetObjectItemCaseSensitive(json_obj, "pools");
    if (pools_arr == NULL) {
        SX_LOG_ERR("Failed get pools field from JSON pdb\n");
    } else {
        sb_pools_pdb_p->pools_num = cJSON_GetArraySize(pools_arr);

        if (sb_pools_pdb_p->pools_num > rm_resource_global.shared_buff_total_num_pools) {
            SX_LOG_ERR("sb_pools_pdb_p->pools_num exceeded range\n");
            sx_status = SX_STATUS_ERROR;
            goto out;
        }

        sb_pools_pdb_p->pools = (cos_sb_issu_pool_data_t*)cl_calloc(sb_pools_pdb_p->pools_num,
                                                                    sizeof(cos_sb_issu_pool_data_t));

        pool_idx = 0;
        cJSON_ArrayForEach(pool_obj, pools_arr)
        {
            tmp_obj = cJSON_GetObjectItemCaseSensitive(pool_obj, "hw_id");
            ISSU_JSON_OBJ_GET(tmp_obj, "hw_id", sb_pools_pdb_p->pools[pool_idx].hw_pool_id);

            tmp_obj = cJSON_GetObjectItemCaseSensitive(pool_obj, "direction");
            ISSU_JSON_OBJ_GET(tmp_obj, "direction", sb_pools_pdb_p->pools[pool_idx].direction);

            tmp_obj = cJSON_GetObjectItemCaseSensitive(pool_obj, "buff_type");
            ISSU_JSON_OBJ_GET(tmp_obj, "buff_type", sb_pools_pdb_p->pools[pool_idx].buffer_type);

            /* buff_attr */
            buff_attr_obj = cJSON_GetObjectItemCaseSensitive(pool_obj, "buff_attr");
            ISSU_JSON_OBJ_GET_CHECK(tmp_obj, "buff_attr");
            tmp_obj = cJSON_GetObjectItemCaseSensitive(buff_attr_obj, "size");
            ISSU_JSON_OBJ_GET(tmp_obj, "size", sb_pools_pdb_p->pools[pool_idx].pool_shared_size);
            tmp_obj = cJSON_GetObjectItemCaseSensitive(buff_attr_obj, "infinite_size");
            ISSU_JSON_OBJ_GET(tmp_obj, "infinite_size", sb_pools_pdb_p->pools[pool_idx].infinite_size);
            tmp_obj = cJSON_GetObjectItemCaseSensitive(buff_attr_obj, "mode");
            ISSU_JSON_OBJ_GET(tmp_obj, "mode", sb_pools_pdb_p->pools[pool_idx].mode);
            tmp_obj = cJSON_GetObjectItemCaseSensitive(buff_attr_obj, "pool_info");
            ISSU_JSON_OBJ_GET(tmp_obj, "pool_info", sb_pools_pdb_p->pools[pool_idx].pool_info);

            /* Ports */
            ports_arr = cJSON_GetObjectItemCaseSensitive(pool_obj, "ports");
            if (ports_arr == NULL) {
                SX_LOG_NTC("ports field get from JSON pdb failed\n");
            } else {
                sb_pools_pdb_p->pools[pool_idx].ports_num = cJSON_GetArraySize(ports_arr);
                sb_pools_pdb_p->pools[pool_idx].ports = (sx_port_log_id_t*)cl_malloc(
                    sizeof(sx_port_log_id_t) * sb_pools_pdb_p->pools[pool_idx].ports_num);

                port_idx = 0;
                cJSON_ArrayForEach(port_obj, ports_arr)
                {
                    sb_pools_pdb_p->pools[pool_idx].ports[port_idx] = port_obj->valuedouble;
                    port_idx++;
                }

                /* Sort ports array in ascending order*/
                qsort(sb_pools_pdb_p->pools[pool_idx].ports, sb_pools_pdb_p->pools[pool_idx].ports_num,
                      sizeof(sx_port_log_id_t), __issu_sb_pools_port_field_cmpr);
            }

            pool_idx++;
        }
    }

out:
    if (buffer) {
        cl_free(buffer);
    }
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    return sx_status;
}

static sx_status_t __issu_sb_pools_data_store(FILE* stream)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    cJSON             *json_obj = NULL;
    char              *json_obj_str = NULL;
    cJSON             *pools_arr_obj = NULL, *pool_obj = NULL;
    cJSON             *ports_arr_obj = NULL, *port_obj = NULL;
    cJSON             *buff_attr_obj = NULL;
    length_t           pools_cnt, pools_num = rm_resource_global.shared_buff_total_num_pools;
    sx_cos_pool_id_t  *pools_list_p = NULL;
    sx_shared_pool_t   pool_properties;
    sx_cos_pool_info_e pool_info;
    uint32_t           ports_arr[rm_resource_global.port_system_ports_max];
    uint32_t           ports_cnt;
    uint32_t           pool_idx, port_idx;

    SX_LOG_ENTER();

    /* Create JSON file object */
    json_obj = cJSON_CreateObject();
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(json_obj, sx_status);

    /* Get list of active pools */
    pools_list_p = (sx_cos_pool_id_t*)cl_malloc(pools_num * sizeof(sx_cos_pool_id_t));
    if (NULL == pools_list_p) {
        SX_LOG(SX_LOG_DEBUG, "Failed to allocate memory for pools_list_p.\n");
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }

    sx_status = cos_pool_list_get_cb_wrapper(SX_ACCESS_CMD_GET, &pools_num, pools_list_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get list of active pools, status - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    /* Write pools entries to PDB */
    pools_arr_obj = cJSON_CreateArray();
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(pools_arr_obj, sx_status);

    /* Prepare DB that holds the mapping of SW SB pool IDs to ports. */
    sx_status = cos_sb_issu_pools_to_ports_list_db(SX_ACCESS_CMD_CREATE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed in cos_db_sb_pool_ports_list_db CREATE, err: %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = cos_sb_issu_ports_to_sw_pool_map();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed in mapping ports to SW SB pool ID, status - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    pools_cnt = 0;
    for (pool_idx = 0; pool_idx < pools_num; pool_idx++) {
        SX_MEM_CLR(pool_properties);

        pool_properties.sw_pool_id = pools_list_p[pool_idx];
        sx_status = cos_pool_param_get_cb_wrapper(pool_properties.sw_pool_id,
                                                  &pool_properties.buffer_type,
                                                  &pool_properties.pool_shared_size,
                                                  &pool_properties.mode,
                                                  &pool_properties.direction,
                                                  &pool_properties.infinite_size,
                                                  &pool_info,
                                                  &pool_properties.hw_pool_id);
        /* skip if:
         * 1. pool isn't active or not found
         * 2. MC pool-has reserved hw_id=15 */
        if (SX_CHECK_FAIL(sx_status) || (SX_COS_POOL_INFO_DEFAULT_MULTICAST_E == pool_info)) {
            continue;
        }

        pool_obj = cJSON_CreateObject();
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(pool_obj, sx_status);

        /* Fill buff_attr */
        buff_attr_obj = cJSON_CreateObject();
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(buff_attr_obj, sx_status);

        cJSON_AddNumberToObject(buff_attr_obj, "size", pool_properties.pool_shared_size);
        cJSON_AddNumberToObject(buff_attr_obj, "infinite_size", pool_properties.infinite_size == TRUE ? 1 : 0);
        cJSON_AddNumberToObject(buff_attr_obj, "mode", pool_properties.mode);
        cJSON_AddNumberToObject(buff_attr_obj, "pool_info", pool_info);


        /* Fill Ports array */
        SX_MEM_CLR(ports_arr);
        sx_status = cos_sb_pool_ports_list_get(pool_properties.sw_pool_id, ports_arr, &ports_cnt);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get list of ports associated with SW pool id[%d], status - %s.\n",
                       pool_properties.sw_pool_id,
                       sx_status_str(sx_status));
            goto out;
        }

        ports_arr_obj = cJSON_CreateArray();
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(ports_arr_obj, sx_status);

        for (port_idx = 0; port_idx < ports_cnt; port_idx++) {
            port_obj = cJSON_CreateNumber(ports_arr[port_idx]);
            ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(port_obj, sx_status);
            cJSON_AddItemToArray(ports_arr_obj, port_obj);
        }

        /* Fill Pool attributes */
        cJSON_AddNumberToObject(pool_obj, "hw_id", pool_properties.hw_pool_id);
        cJSON_AddNumberToObject(pool_obj, "direction", pool_properties.direction);
        cJSON_AddNumberToObject(pool_obj, "buff_type", pool_properties.buffer_type);
        cJSON_AddItemToObject(pool_obj, "buff_attr", buff_attr_obj);
        cJSON_AddItemToObject(pool_obj, "ports", ports_arr_obj);

        /* Add filled pool object to array */
        cJSON_AddItemToArray(pools_arr_obj, pool_obj);
        pools_cnt++;
    }

    cJSON_AddItemToObject(json_obj, "pools", pools_arr_obj);

    json_obj_str = cJSON_Print(json_obj);
    if (json_obj_str == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to print the JSON object into a string (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    fprintf(stream, "%s", json_obj_str);

    sx_status = cos_sb_issu_pools_to_ports_list_db(SX_ACCESS_CMD_DESTROY);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed in cos_db_sb_pool_ports_list_db DESTROY, err: %s\n", sx_status_str(sx_status));
        goto out;
    }

out:
    if (pools_list_p) {
        CL_FREE_N_NULL(pools_list_p);
    }

    /* free all objects under json_obj and json_obj itself */
    if (json_obj) {
        cJSON_Delete(json_obj);
    }

    if (json_obj_str != NULL) {
        cJSON_free(json_obj_str);
    }

    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __sb_pools_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                                void                       *ctxt_p,
                                                void                       *param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_1) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_sb_pools_data_restore(ctxt_p, (sx_cos_sb_issu_pools_pdb_data_t*)param);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error reading old Profile from storage\n");
            goto out;
        }
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        sx_status = __issu_sb_pools_data_store(ctxt_p);
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}


static sx_status_t __sb_pools_pdb_set()
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    FILE                           *file_p = NULL;
    issu_pdb_file_version_e         version = ISSU_PDB_FILE_VERSION_INVALID;
    sx_cos_sb_issu_pools_pdb_data_t sb_pools_pdb;

    SX_LOG_ENTER();

    SX_MEM_CLR(sb_pools_pdb);

    /* Load the SB pools from the PDB */
    if (TRUE == g_is_sb_pools_pdb_exists) {
        sx_status =
            __issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E, "rb", &file_p, &version);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_WRN(" __issu_persistent_info_storage_open_ex SB_POOLS failed, (%s)\n", sx_status_str(sx_status));
            g_is_sb_pools_pdb_exists = FALSE;
        }

        if (file_p != NULL) {
            sx_status = __issu_restore_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E, file_p, version, &sb_pools_pdb);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_WRN(" __issu_restore_ex_wrapper SB_POOLS failed (%s), continue as no COS SB PDB\n",
                           sx_status_str(sx_status));
                g_is_sb_pools_pdb_exists = FALSE;
            }

            sx_status = __issu_persistent_info_storage_close(&file_p);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                           g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E]);
                sx_status = SX_STATUS_ERROR;
                goto out;
            }
        }
    }
    sb_pools_pdb.is_pdb_exists = g_is_sb_pools_pdb_exists;
    sx_status = cos_sb_pools_pdb_set(&sb_pools_pdb);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" cos_sb_pools_pdb_set failed %s\n",
                   g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E]);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __fdb_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                           void                       *ctxt_p,
                                           void                      * param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_translate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_1) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_fdb_records_restore(ctxt_p, param);
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        sx_status = __issu_fdb_records_store(ctxt_p, param);
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}


static sx_status_t __issu_cfg_data_restore(FILE* stream, sx_issu_cfg_pdb_params* issu_cfg_pdb_params_p)
{
    sx_status_t sx_status = 0;
    size_t      length = 0;
    cl_status_t cl_status = 0;
    char      * buffer = NULL;
    const char *error_ptr = NULL;
    cJSON      *json_obj = NULL, *tmp_obj = NULL;

    fseek(stream, 0, SEEK_SET);
    cl_status = cl_file_size(stream, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer = cl_malloc(length + 1);
    if (!buffer) {
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    if (cl_fread(buffer, 1, length, stream) != length) {
        SX_LOG_ERR("Error reading port map JSON file \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer[length] = 0;

    json_obj = cJSON_Parse(buffer);
    if (json_obj == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("ISSU cfg restore - Error before: %s\n", error_ptr);
        }
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    tmp_obj = cJSON_GetObjectItemCaseSensitive(json_obj, "acl_default_actions_en");
    if (tmp_obj != NULL) {
        ISSU_JSON_OBJ_GET(tmp_obj, "acl_default_actions_en", issu_cfg_pdb_params_p->acl_default_actions_en);
    }
    tmp_obj = cJSON_GetObjectItemCaseSensitive(json_obj, "acl_pagt_v2_support");
    if (tmp_obj != NULL) {
        ISSU_JSON_OBJ_GET(tmp_obj, "acl_pagt_v2_support", issu_cfg_pdb_params_p->acl_pagt_v2_support);
    }


out:
    if (buffer) {
        cl_free(buffer);
    }
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    return sx_status;
}


static sx_status_t __issu_cfg_data_store(FILE* stream)
{
    sx_status_t            sx_status = SX_STATUS_SUCCESS;
    cJSON                 *json_obj = NULL;
    char                  *json_obj_str = NULL;
    sx_issu_cfg_pdb_params issu_cfg_pdb_params;

    SX_LOG_ENTER();

    SX_MEM_CLR(issu_cfg_pdb_params);

    /* Create JSON file object */
    json_obj = cJSON_CreateObject();
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(json_obj, sx_status);

    /* Add items to JSON */
    issu_cfg_pdb_params.acl_default_actions_en = TRUE;
    issu_cfg_pdb_params.acl_pagt_v2_support = TRUE;
    cJSON_AddNumberToObject(json_obj,
                            "acl_default_actions_en",
                            issu_cfg_pdb_params.acl_default_actions_en == TRUE ? 1 : 0);
    cJSON_AddNumberToObject(json_obj,
                            "acl_pagt_v2_support",
                            issu_cfg_pdb_params.acl_pagt_v2_support == TRUE ? 1 : 0);

    json_obj_str = cJSON_Print(json_obj);
    if (json_obj_str == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to print the JSON object into a string (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    fprintf(stream, "%s", json_obj_str);

out:
    /* free all objects under json_obj and json_obj itself */
    if (json_obj) {
        cJSON_Delete(json_obj);
    }

    if (json_obj_str != NULL) {
        cJSON_free(json_obj_str);
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_cfg_pdb_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                                void                       *ctxt_p,
                                                void                       *param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_xlate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_1) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_cfg_data_restore(ctxt_p, (sx_issu_cfg_pdb_params*)param);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error reading ISSU configuration from storage\n");
            goto out;
        }
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        sx_status = __issu_cfg_data_store(ctxt_p);
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}

static sx_status_t __issu_cfg_pdb_set()
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    FILE                   *file_p = NULL;
    issu_pdb_file_version_e version = ISSU_PDB_FILE_VERSION_INVALID;
    sx_issu_cfg_pdb_params  issu_cfg_pdb_params;

    SX_LOG_ENTER();

    SX_MEM_CLR(issu_cfg_pdb_params);

    /* Load the ISSU CFG from the PDB if exists */
    if (__issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E, "rb", &file_p,
                                               &version) == SX_STATUS_SUCCESS) {
        sx_status =
            __issu_restore_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E, file_p, version, &issu_cfg_pdb_params);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_restore_ex_wrapper ISSU_CFG failed (%s)\n",
                       sx_status_str(sx_status));
            sx_status = SX_STATUS_ERROR;
            goto out;
        }

        sx_status = __issu_persistent_info_storage_close(&file_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                       g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E]);
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
    }

    sx_status = flex_acl_issu_default_actions_support(issu_cfg_pdb_params.acl_default_actions_en);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_issu_default_actions_support failed %s\n",
                   g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E]);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sx_status = flex_acl_issu_pagt_v2_support(issu_cfg_pdb_params.acl_pagt_v2_support);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL ISSU PAGT_V2 support failed %s\n",
                   g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E]);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_arlpgt_restore(FILE* stream)
{
    sx_status_t        sx_status = 0;
    size_t             length = 0;
    cl_status_t        cl_status = 0;
    char              *buffer = NULL;
    const char        *error_ptr = NULL;
    cJSON             *json_port_group_array = NULL;
    cJSON             *json_port_group = NULL;
    cJSON             *json_ports_array = NULL;
    cJSON             *json_group_index = NULL;
    int                iii = 0, jjj = 0;
    int                port_group_array_size = 0;
    int                ports_count = 0;
    issu_arlgpt_info_t issu_arlgpt_info;


    fseek(stream, 0, SEEK_SET);
    cl_status = cl_file_size(stream, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for ARLPGT file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer = cl_malloc(length + 1);
    if (buffer == NULL) {
        SX_LOG_ERR("Error allocating ARLPGT JSON file buffer\n");
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    if (cl_fread(buffer, 1, length, stream) != length) {
        SX_LOG_ERR("Error reading ARLPGT JSON file \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    buffer[length] = 0;

    SX_MEM_CLR(issu_arlgpt_info);

    json_port_group_array = cJSON_Parse(buffer);
    if (json_port_group_array == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("ISSU ARLPGT restore - Error before: %s\n", error_ptr);
        }
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    port_group_array_size = cJSON_GetArraySize(json_port_group_array);

    for (iii = 0; iii < port_group_array_size; iii++) {
        json_port_group = cJSON_GetArrayItem(json_port_group_array, iii);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(json_port_group, sx_status);
        json_group_index = cJSON_GetObjectItem(json_port_group, "index");
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(json_group_index, sx_status);
        json_ports_array = cJSON_GetObjectItem(json_port_group, "ports");
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(json_ports_array, sx_status);

        ports_count = cJSON_GetArraySize(json_ports_array);

        if (ports_count > MAX_PHYPORT_NUM) {
            SX_LOG_ERR("ISSU ARLPGT restore port count [%d] exceeds allowed [%d]\n",
                       ports_count, MAX_PHYPORT_NUM);
            sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        issu_arlgpt_info.arlgpt_port_groups[iii].group_idx = (int)cJSON_GetNumberValue(json_group_index);
        for (jjj = 0; jjj < ports_count; jjj++) {
            /* Fill out the ports in this group */
            issu_arlgpt_info.arlgpt_port_groups[iii].port_phy_id[jjj] =
                (int)cJSON_GetNumberValue(cJSON_GetArrayItem(json_ports_array, jjj));
        }
        issu_arlgpt_info.arlgpt_port_groups[iii].port_count = ports_count;
    }
    issu_arlgpt_info.groups_cout = port_group_array_size;

    /* Inform the ARLPGT about this persistent DB that was loaded */
    sx_status = hwd_router_ecmp_arlpgt_issu_persistent_data_set(&issu_arlgpt_info);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("ISSU ARLPGT persistent data set failed\n");
        goto out;
    }

out:
    if (buffer != NULL) {
        cl_free(buffer);
    }
    if (json_port_group_array != NULL) {
        cJSON_Delete(json_port_group_array);
    }
    return sx_status;
}


static sx_status_t __issu_arlpgt_store(FILE* stream)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    cJSON             *json_port_group_array = NULL;
    cJSON             *json_port_group = NULL;
    cJSON             *json_ports_array = NULL;
    char              *json_obj_str = NULL;
    issu_arlgpt_info_t issu_arlgpt_info;
    int                iii = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(issu_arlgpt_info);

    /* Create JSON file array in which the port lists will be filled */
    json_port_group_array = cJSON_CreateArray();
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(json_port_group_array, sx_status);

    /* Get the ARLPGT info from the module */
    sx_status = hwd_router_ecmp_arlpgt_store_port_groups(&issu_arlgpt_info);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to retrieve ARLPGT info for ISSU store, (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    /* Go over all the port groups and set each group in the array we've created */
    for (iii = 0; iii < issu_arlgpt_info.groups_cout; iii++) {
        /* Create an object to this specific group */
        json_port_group = cJSON_CreateObject();
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(json_port_group, sx_status);

        /* Store the index of the group */
        cJSON_AddNumberToObject(json_port_group, "index", issu_arlgpt_info.arlgpt_port_groups[iii].group_idx);
        /* Store all the ports in the group */
        json_ports_array = cJSON_CreateIntArray(issu_arlgpt_info.arlgpt_port_groups[iii].port_phy_id,
                                                issu_arlgpt_info.arlgpt_port_groups[iii].port_count);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(json_ports_array, sx_status);
        cJSON_AddItemToObject(json_port_group, "ports", json_ports_array);

        /* Add this group to the groups array */
        cJSON_AddItemToArray(json_port_group_array, json_port_group);
    }

    /* Get the string representing the JSON objects */
    json_obj_str = cJSON_Print(json_port_group_array);
    if (json_obj_str == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to print the JSON object into a string (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    fprintf(stream, "%s", json_obj_str);

out:
    /* free all objects under json_obj and json_obj itself */
    if (json_obj_str != NULL) {
        cJSON_free(json_obj_str);
    }
    if (json_port_group_array) {
        cJSON_Delete(json_port_group_array);
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_arlpgt_file_xlate_v1(issu_pdb_file_xlate_info_t *issu_pdb_file_xlate_info_p,
                                               void                       *ctxt_p,
                                               void                       *param)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(param);

    if (utils_check_pointer(issu_pdb_file_xlate_info_p, "issu_pdb_file_xlate_info_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (issu_pdb_file_xlate_info_p->pdb_file_version != ISSU_PDB_FILE_VERSION_1) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error pdb file version[%d] store/restore failed, incompatible translate function, err[%s].\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version, sx_status_str(sx_status));
        goto out;
    }

    switch (issu_pdb_file_xlate_info_p->file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:
        sx_status = __issu_arlpgt_restore(ctxt_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error reading ISSU configuration from storage\n");
            goto out;
        }
        break;

    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        sx_status = __issu_arlpgt_store(ctxt_p);
        break;

    default:
        sx_status = SX_STATUS_ERROR;
        break;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("version[%u] translation operation[%u] failed, sx_status = %s\n",
                   issu_pdb_file_xlate_info_p->pdb_file_version,
                   issu_pdb_file_xlate_info_p->file_oper_e, sx_status_str(sx_status));
        goto out;
    }
out:
    return sx_status;
}

static sx_status_t __issu_arlpgt_set()
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    FILE                   *file_p = NULL;
    issu_pdb_file_version_e version = ISSU_PDB_FILE_VERSION_INVALID;

    SX_LOG_ENTER();

    /* Load the ARLPGT from the PDB if exists */
    if (__issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E, "rb", &file_p,
                                               &version) == SX_STATUS_SUCCESS) {
        sx_status =
            __issu_restore_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E, file_p, version, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_restore_ex_wrapper ISSU_CFG failed (%s)\n",
                       sx_status_str(sx_status));
            sx_status = SX_STATUS_ERROR;
            goto out;
        }

        sx_status = __issu_persistent_info_storage_close(&file_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                       g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E]);
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_invalidate_acl(sx_dev_id_t dev_id)
{
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    struct ku_pacl_reg pacl_reg_data;
    sxd_reg_meta_t     pacl_reg_meta;
    sx_issu_bank_e     issu_bank = SX_ISSU_BANK_1_E;
    sx_acl_id_t        acl_id = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(pacl_reg_meta);
    SX_MEM_CLR(pacl_reg_data);

    pacl_reg_meta.dev_id = dev_id;
    pacl_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pacl_reg_data.valid = FALSE;

    sx_status = issu_bank_get(&issu_bank);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Issu_bank_get failed. sx_status = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    issu_bank = (issu_bank == SX_ISSU_BANK_1_E) ? SX_ISSU_BANK_2_E : SX_ISSU_BANK_1_E;

    /* Iterate non-used acl indexes - half of the resources, odd or even, depend on current used bank: */
    for (acl_id = issu_bank; acl_id < rm_resource_global.acl_tables_max; acl_id += 2) {
        pacl_reg_data.acl_id = acl_id;

        sxd_status =
            sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PACL_E, &pacl_reg_data, &pacl_reg_meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("ISSU : Failed to configure PACL to dev_idx [%u] acl_id [%u]\n", dev_id, acl_id);
            sx_status = sxd_status_to_sx_status(sxd_status);
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_port_map_restore_flag_get(boolean_t *issu_port_map_restore_flag_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(issu_port_map_restore_flag_p, "issu_port_map_restore_flag_p")) {
        goto out;
    }
    *issu_port_map_restore_flag_p = g_port_map_info.restore_flag;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_port_map_list_get(sx_port_mapping_t** port_mapping_list_pp, uint32_t* size_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(port_mapping_list_pp, "port_mapping_list_pp")) {
        goto out;
    }
    *port_mapping_list_pp = g_port_map_info.port_mapping_list_p;

    if (utils_check_pointer(size_p, "size_p")) {
        goto out;
    }
    *size_p = g_port_map_info.list_size;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_port_map_by_id_get(sx_port_phy_id_t local_port, sx_port_mapping_t* port_mapping_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(port_mapping_p, "port_mapping_p")) {
        goto out;
    }

    if (local_port > g_port_map_info.list_size) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("local_port value is out of range.\n");
        goto out;
    }

    memcpy(port_mapping_p, &g_port_map_info.port_mapping_list_p[local_port - 1], sizeof(sx_port_mapping_t));

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t issu_mapping_done(sx_port_phy_id_t local_port)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_port_map_info.persistent_flag == FALSE) {
        goto out;
    }
    if (local_port > g_port_map_info.list_size) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("local_port value is out of range.\n");
        goto out;
    }

    g_port_map_info.port_mapping_done_p[local_port - 1] = TRUE;

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t issu_disable_mocs_transactions_spc()
{
    sx_status_t     status = SX_STATUS_SUCCESS;
    sxd_mocs_type_t mocs_type_list[SXD_MOCS_TYPE_MAX + 1];
    uint32_t        i = 0, cnt = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR_ARRAY(mocs_type_list, SXD_MOCS_TYPE_MAX + 1,  sxd_mocs_type_t);

    for (i = SXD_MOCS_TYPE_MIN; i <= SXD_MOCS_TYPE_MOPCE_E; ++i) {
        if ((i == SXD_MOCS_TYPE_CEER_E) || (i == SXD_MOCS_TYPE_MAFBI_E)) {
            continue;
        }
        mocs_type_list[cnt] = i;
        cnt++;
    }

    status = __issu_disable_mocs_transactions(mocs_type_list, cnt);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed in __issu_disable_mocs_transactions on chip type SPC.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t issu_disable_mocs_transactions_spc2()
{
    sx_status_t     status = SX_STATUS_SUCCESS;
    sxd_mocs_type_t mocs_type_list[SXD_MOCS_TYPE_MAX + 1];
    uint32_t        i = 0, cnt = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR_ARRAY(mocs_type_list, SXD_MOCS_TYPE_MAX + 1,  sxd_mocs_type_t);

    for (i = SXD_MOCS_TYPE_MIN; i <= SXD_MOCS_TYPE_MOPCE_E; ++i) {
        mocs_type_list[cnt] = i;
        cnt++;
    }

    status = __issu_disable_mocs_transactions(mocs_type_list, cnt);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed in __issu_disable_mocs_transactions on chip type SPC2.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t issu_disable_mocs_transactions_spc4()
{
    sx_status_t     status = SX_STATUS_SUCCESS;
    sxd_mocs_type_t mocs_type_list[SXD_MOCS_TYPE_MAX + 1];
    uint32_t        i = 0, cnt = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR_ARRAY(mocs_type_list, SXD_MOCS_TYPE_MAX + 1,  sxd_mocs_type_t);

    for (i = SXD_MOCS_TYPE_MIN; i <= SXD_MOCS_TYPE_MAX; ++i) {
        if (i >= 9) { /*Hole in enum (9) sxd_mocs_type_t and types 10,11,12,13 are not supported in FW yet*/
            continue;
        }
        mocs_type_list[cnt] = i;
        cnt++;
    }

    status = __issu_disable_mocs_transactions(mocs_type_list, cnt);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed in __issu_disable_mocs_transactions on chip type SPC4.\n");
        goto out;
    }
out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __issu_disable_mocs_transactions_wrapper()
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.issu_disable_mocs_transactions_cb != NULL) {
        status = brg_context.spec_cb_g.issu_disable_mocs_transactions_cb();
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed in issu_disable_mocs_transactions_cb on chip type %s .\n",
                       sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}


static sx_status_t __issu_disable_mocs_transactions(sxd_mocs_type_t *mocs_type_list_p, uint32_t mocs_type_cnt)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     mocs_meta;
    struct ku_mocs_reg mocs_data;
    uint32_t           mocs_type_idx = 0;
    int                device_cnt = SX_DEV_ID_MAX;
    topo_device_item_t dev_attrib[SX_DEV_ID_MAX];
    uint32_t           num_of_times = 3, sleep_time_us = 1000, i = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(mocs_meta);
    SX_MEM_CLR(mocs_data);

    sx_status = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed in topo_db_device_list_get err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (device_cnt == 0) {
        SX_LOG_ERR("can't disable all MOCS , device list is empty\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    mocs_meta.access_cmd = SXD_ACCESS_CMD_SET;
    mocs_meta.dev_id = dev_attrib[0].dev_id;
    mocs_meta.swid = 0;
    mocs_data.opcode = 1; /*Cancel*/

    for (mocs_type_idx = 0; mocs_type_idx < mocs_type_cnt; ++mocs_type_idx) {
        mocs_data.type = mocs_type_list_p[mocs_type_idx];
        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOCS_E, &mocs_data, &mocs_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_status)) {
            sx_status = sxd_status_to_sx_status(sxd_status);
            SX_LOG_ERR("Failed to access MOCS register SET (err=%s)\n", sx_status_str(sx_status));
            goto out;
        }
    }

    mocs_meta.access_cmd = SXD_ACCESS_CMD_GET;
    for (mocs_type_idx = 0; mocs_type_idx < mocs_type_cnt; ++mocs_type_idx) {
        mocs_data.type = mocs_type_list_p[mocs_type_idx];
        for (i = 0; i < num_of_times; ++i) {
            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOCS_E, &mocs_data, &mocs_meta, 1, NULL, NULL);
            if (SXD_CHECK_FAIL(sxd_status)) {
                sx_status = sxd_status_to_sx_status(sxd_status);
                SX_LOG_ERR("Failed to access MOCS register GET (err=%s)\n", sx_status_str(sx_status));
                goto out;
            }
            if (mocs_data.status != SXD_MOCS_STATUS_IDLE_E) {
                usleep(sleep_time_us);
            } else {
                break;
            }
        }
        if (i == num_of_times) {
            SX_LOG_ERR("MOCS didn't stop before ISSU: Type %d status %d\n", mocs_data.type, mocs_data.status);
            sx_status = SX_STATUS_ERROR;
            break;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_default_trap_disable()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = port_state_event_disable();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("port_state_event_disable failed, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_disable_mocs_transactions_wrapper();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("__issu_disable_mocs_transactions_wrapper failed, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = host_ifc_disable_accuflow_trap_group();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed in host_ifc_disable_accuflow_trap_group on chip type SPC2.\n");
        goto out;
    }

    if (brg_context.spec_cb_g.sb_snapshot_trigger_enable_set_cb != NULL) {
        sx_status = sb_snapshot_issu_handling();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("sb snapshot issu handling failed, err = %s\n", sx_status_str(sx_status));
            goto out;
        }
    }
    /* In worst case, this call may sleep up to 240ms to wait running crs-dump to cancel. */
    sx_status = sxd_status_to_sx_status(sxd_allow_secure_fw_dump(FALSE));
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("sxd_allow_secure_fw_dump failed, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_fdb_pdb_operation_set(issu_pdb_file_xlate_oper_e file_oper_e)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    sx_swid_id_t            swid = rm_resource_global.swid_id_max;
    FILE                   *file_p = NULL;
    issu_pdb_file_version_e version = ISSU_PDB_FILE_VERSION_1;
    sx_fdb_learn_mode_t     glob_learn_mode = SX_FDB_LEARN_MODE_DONT_LEARN;

    sx_status = fdb_learn_mode_get(swid, &glob_learn_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve swid (%u) learn mode, %s(%d).\n",
                   swid, sx_status_str(sx_status), sx_status);
        goto out;
    }

    /*store/restore dynamic ageable mac entries only in case the user
     * configured AUTO_LEARN.
     */
    if (SX_FDB_LEARN_MODE_AUTO_LEARN != glob_learn_mode) {
        goto out;
    }

    switch (file_oper_e) {
    case ISSU_PDB_FILE_XLATE_OPER_STORE:
        sx_status = __issu_store_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_FDB_E, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_restore_ex_wrapper failed (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }
        break;

    case ISSU_PDB_FILE_XLATE_OPER_RESTORE:

        sx_status =
            __issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_FDB_E, "rb", &file_p, &version);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_INF(" ISSU persistent storage TYPE_FDB does not exist, (%s)\n", sx_status_str(sx_status));
            sx_status = SX_STATUS_SUCCESS;
            goto out;
        }

        sx_status = __issu_restore_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_FDB_E, file_p, version, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_restore_ex_wrapper failed (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR(" Invalid persistent db file operation err: %s\n", sx_status_str(sx_status));
        goto out;
    }

out:
    if (file_p) {
        sx_status = __issu_persistent_info_storage_close(&file_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                       g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_FDB_E]);
            sx_status = SX_STATUS_ERROR;
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_prepare_persistent_paths(const char *persistent_path)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     len = 0;

    if ((persistent_path == NULL) || !strcmp(persistent_path, "")) {
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_BANK_E], ISSU_PERSISTENT_DEFAULT_PATH,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_LAG_E], ISSU_PERSISTENT_DEFAULT_PATH,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_PROFILE_E], ISSU_PERSISTENT_DEFAULT_PATH,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E], ISSU_PERSISTENT_DEFAULT_PATH,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E], ISSU_PERSISTENT_DEFAULT_PATH,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_FDB_E], ISSU_PERSISTENT_DEFAULT_PATH,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E], ISSU_PERSISTENT_DEFAULT_PATH,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E], ISSU_PERSISTENT_DEFAULT_PATH,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
    } else {
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_BANK_E], persistent_path,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_LAG_E], persistent_path,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_PROFILE_E], persistent_path,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E], persistent_path,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E], persistent_path,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_FDB_E], persistent_path,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E], persistent_path,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        strncpy(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E], persistent_path,
                (ISSU_PERSISTENT_PATH_LEN_MAX - 1));
        len = strlen(persistent_path) - 1;
        if (persistent_path[len] != '/') {
            strcat(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_BANK_E], "/");
            strcat(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_LAG_E], "/");
            strcat(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_PROFILE_E], "/");
            strcat(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E], "/");
            strcat(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E], "/");
            strcat(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_FDB_E], "/");
            strcat(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E], "/");
            strcat(g_issu_pdb_base_paths_db[ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E], "/");
        }
    }

    return sx_status;
}

sx_status_t issu_init(const sx_boot_mode_init_params_t *issu_init_param_p, sx_api_profile_t *profile_p)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS, rb_sx_status = SX_STATUS_SUCCESS;
    sx_boot_mode_e          issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    FILE                   *file_p = NULL;
    issu_pdb_file_version_e version = ISSU_PDB_FILE_VERSION_INVALID;

    SX_LOG_ENTER();

    if (utils_check_pointer(issu_init_param_p, "issu_init_param_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    DBG_DUMP_MODULES_REGISTER(sx_status, ISSU, ISSU, issu, FALSE, FALSE, FALSE);

    sx_status = issu_infiniband_set(profile_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ISSU - Failed to initialize infiniband flag.\n");
        goto out;
    }

    if (g_infiniband_issu) {
        sx_status = ib_issu_init(issu_init_param_p, profile_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("IB ISSU init failed!\n");
        }
        goto out;
    }

    SX_MEM_CPY_P(&g_profile, profile_p);
    g_issu_lag_config_restore_flag = issu_init_param_p->pdb_lag_init;
    g_port_map_info.restore_flag = issu_init_param_p->pdb_port_map_init;
    sx_status = __issu_prepare_persistent_paths(issu_init_param_p->issu_persistent_path);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ISSU persistent path too long.\n");
        goto out;
    }

    sx_status = issu_boot_mode_get(&issu_boot_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to issu_boot_mode_get. sx_status = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_bank_init(issu_boot_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ISSU bank init failed\n");
        goto out;
    }


    if (issu_boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        sx_status = __issu_profile_compare(profile_p);
        if (sx_status == SX_STATUS_PARAM_ERROR) {
            SX_LOG_ERR("Profile is different from \"PreIssu\" profile\n");
            goto out;
        } else if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_profile_compare failed (%s)\n", sx_status_str(sx_status));
            goto out;
        }

        sx_status =
            __issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_LAG_E, "rb", &file_p, &version);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_open_ex failed, (%s)\n", sx_status_str(sx_status));
            file_p = NULL;
            goto out;
        }
        sx_status = __issu_restore_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_LAG_E, file_p, version, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_restore_ex_wrapper failed (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = __issu_persistent_info_storage_close(&file_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                       g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_LAG_E]);
        }

        /* ISSU port map file has multiple versions, use extended open that checks for
         * for the existence of latest version of port map and returns the file pointer
         * for restore operation.
         */
        sx_status =
            __issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E, "rb", &file_p, &version);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_INF(" __issu_persistent_info_storage_open_ex failed, (%s)\n", sx_status_str(sx_status));
            file_p = NULL;
            sx_status = SX_STATUS_SUCCESS;
            g_port_map_info.persistent_flag = FALSE;
            goto out;
        }

        /* Use extended restore functionality that has translation embedded from one version
         * to the other version. This is required to support ISSU upgrade from older pdb file
         * versions.
         */
        sx_status = __issu_restore_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E, file_p, version, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_port_map_restore_wrapper failed (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = __issu_persistent_info_storage_close(&file_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                       g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E]);
        }


        /* Check if the SB pools PDB JSON file is exists */
        if (__issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E, "rb", &file_p,
                                                   &version) == SX_STATUS_SUCCESS) {
            g_is_sb_pools_pdb_exists = TRUE;

            sx_status = __issu_persistent_info_storage_close(&file_p);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                           g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E]);
            }
        }

        sx_status = __issu_cfg_pdb_set();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR(" __issu_cfg_pdb_set failed (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = __issu_arlpgt_set();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR(" __issu_arlpgt_set failed (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }


        file_p = NULL;
    }

out:
    if (file_p != NULL) {
        rb_sx_status = __issu_persistent_info_storage_close(&file_p);
        if (rb_sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed\n");
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t ib_issu_init(const sx_boot_mode_init_params_t *issu_init_param_p, sx_api_profile_t *profile_p)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS, rb_sx_status = SX_STATUS_SUCCESS;
    sx_boot_mode_e          issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    FILE                   *file_p = NULL;
    issu_pdb_file_version_e version = ISSU_PDB_FILE_VERSION_INVALID;

    SX_LOG_ENTER();

    if (utils_check_pointer(issu_init_param_p, "issu_init_param_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    sx_status = issu_infiniband_set(profile_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ISSU - Failed to initialize infiniband flag.\n");
        goto out;
    }

    SX_MEM_CPY_P(&g_profile, profile_p);
    g_issu_lag_config_restore_flag = issu_init_param_p->pdb_lag_init;
    g_port_map_info.restore_flag = issu_init_param_p->pdb_port_map_init;
    sx_status = __issu_prepare_persistent_paths(issu_init_param_p->issu_persistent_path);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ISSU persistent path too long.\n");
        goto out;
    }

    sx_status = issu_boot_mode_get(&issu_boot_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to issu_boot_mode_get. sx_status = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_bank_init(issu_boot_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ISSU bank init failed\n");
        goto out;
    }


    if (issu_boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        sx_status = __issu_profile_compare(profile_p);
        if (sx_status == SX_STATUS_PARAM_ERROR) {
            SX_LOG_ERR("Profile is different from \"PreIssu\" profile\n");
            goto out;
        } else if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_profile_compare failed (%s)\n", sx_status_str(sx_status));
            goto out;
        }

        /* ISSU port map file has multiple versions, use extended open that checks for
         * for the existence of latest version of port map and returns the file pointer
         * for restore operation.
         */
        sx_status =
            __issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E, "rb", &file_p, &version);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_INF(" __issu_persistent_info_storage_open_ex failed, (%s)\n", sx_status_str(sx_status));
            file_p = NULL;
            sx_status = SX_STATUS_SUCCESS;
            g_port_map_info.persistent_flag = FALSE;
            goto out;
        }

        /* Use extended restore functionality that has translation embedded from one version
         * to the other version. This is required to support ISSU upgrade from older pdb file
         * versions.
         */
        sx_status = __issu_restore_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E, file_p, version, NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_port_map_restore_wrapper failed (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = __issu_persistent_info_storage_close(&file_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                       g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E]);
        }

        file_p = NULL;
    }

out:
    if (file_p != NULL) {
        rb_sx_status = __issu_persistent_info_storage_close(&file_p);
        if (rb_sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed\n");
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_boot_mode_get(sx_boot_mode_e *boot_mode_p)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sx_boot_mode_e utils_boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_LOG_ENTER();

    sx_status = utils_check_pointer(boot_mode_p, "boot_mode_p");
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to get issu mode, parameter issu_mode_p is NULL\n");
        goto out;
    }

    sx_status = utils_boot_mode_get(&utils_boot_mode);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to get utils boot mode err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    switch (utils_boot_mode) {
    case SX_BOOT_MODE_ISSU_NORMAL_E:
    case SX_BOOT_MODE_ISSU_FAST_E:
    case SX_BOOT_MODE_ISSU_STARTED_E:
        *boot_mode_p = utils_boot_mode;
        break;

    default:
        *boot_mode_p = SX_BOOT_MODE_DISABLED_E;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

boolean_t is_infiniband_issu()
{
    return g_infiniband_issu;
}

sx_status_t issu_bank_get(sx_issu_bank_e *issu_bank_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = utils_check_pointer(issu_bank_p, "issu_bank_p");
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to get issu bank, parameter issu_bank_p is NULL\n");
        goto out;
    }

    *issu_bank_p = g_issu_params.issu_bank;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_start_set()
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS, rb_sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t       utils_status = SX_UTILS_STATUS_SUCCESS;
    sxd_status_t            sxd_status = SXD_STATUS_SUCCESS;
    sx_boot_mode_e          utils_boot_mode = SX_BOOT_MODE_DISABLED_E;
    sx_issu_bank_e          issu_bank = 0;
    FILE                   *file_p = NULL;
    issu_pdb_file_version_e version = ISSU_PDB_FILE_VERSION_INVALID;
    issu_profile_pdb_data_t profile_data_store;

    SX_LOG_ENTER();

    SX_MEM_CLR(profile_data_store);

    sx_status = utils_boot_mode_get(&utils_boot_mode);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" failed to get utils boot mode err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    if ((utils_boot_mode != SX_BOOT_MODE_ISSU_NORMAL_E) &&
        (utils_boot_mode != SX_BOOT_MODE_ISSU_FAST_E)) {
        SX_LOG_ERR(" SDK boot mode does not support ISSU!\n");
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if (g_infiniband_issu) {
        sx_status = ib_issu_start_set();
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("IB ISSU start set failed!\n");
        }
        goto out;
    }

    sx_status = __issu_health_check_set(TRUE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to prepare health check for ISSU, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* ISSU doesn't support SPAN sessions. So, disable all enabled SPAN sessions. */
    sx_status = span_issu_sessions_check();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG(SX_LOG_ERROR, "Fail in check SPAN sessions. ISSU isn't allowed when SPAN sessions are enabled.\n");
        goto out;
    }

    /* Notify HW Manage that ISSU start*/
    sxd_status = sxd_access_reg_send_issu_notification(TRUE);
    if (SXD_CHECK_FAIL(sxd_status)) {
        sx_core_async_issu_in_progress_disable();

        SX_LOG_ERR("Fail to perform issu notification update, err [%s]\n", SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    /* delete all histograms*/
    sx_status = sdk_tele_impl_histogram_delete_all(TRUE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to delete all histograms, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Force removal of all stateful DB partitions */
    sx_status = stateful_db_issu_start_set();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to delete all stateful DB partitions, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Stop BER monitor for all ports */
    sx_status = port_ber_monitor_stop_all();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to stop BER monitor, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Stop ACL activity notification process */
    sx_status = flex_acl_activity_notify_stop();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to stop acl activity notification process, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Stop all sessions */

    /* At this stage no more APIs are processed, no SFN job is pending.
     * The same is valid for RAUHTD except there is no thread to close. */
    sx_status = __issu_sfn_session_stop();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" failed to stop SFN session, err = %s\n", sx_status_str(sx_status));
        goto out;
    }
    /* Stop polling timer thread */
    sx_status = __issu_stop_polling_timer_thread(SX_TIMER_THREAD_GENERAL_E);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" failed to stop polling timer thread, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Wait for GC completion */
    utils_status = gc_object_fence(GC_FENCE_TYPE_SLOW);
    sx_status = sx_utils_status_to_sx_status(utils_status);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to process GC queue, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* close bulk counters interface to kernel */
    sx_status = sx_bulk_counter_deinit();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to deinit bulk counters, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Disable event traps */
    sx_status = __issu_default_trap_disable();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to disable event traps err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Lock Phy consolidation */
    sx_status = __issu_port_phy_consolidation_set(SX_ACCESS_CMD_ENABLE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to lock PHY consolidation err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* SXD to dev NULL, only ISFU IFC can get thru to FW */
    sx_status = issu_dpt_access_control_set(READ_ONLY);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to set dpt access control = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Trigger actual FW update */
    sx_status = __issu_fw_update();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed update FW = %s\n", sx_status_str(sx_status));

        /* Allow writing to FW again */
        rb_sx_status = issu_dpt_access_control_set(READ_WRITE);
        if (SX_CHECK_FAIL(rb_sx_status)) {
            SX_LOG_ERR(" Failed to set dpt access control = %s\n", sx_status_str(rb_sx_status));
        }

        /* Unlock Phy consolidation */
        rb_sx_status = __issu_port_phy_consolidation_set(SX_ACCESS_CMD_DISABLE);
        if (SX_CHECK_FAIL(rb_sx_status)) {
            SX_LOG_ERR(" Failed to unlock PHY consolidation err = %s\n", sx_status_str(rb_sx_status));
        }
        goto out;
    }

    /* Allow writing to FW again */
    sx_status = issu_dpt_access_control_set(READ_WRITE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to set dpt access control = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Unlock Phy consolidation */
    sx_status = __issu_port_phy_consolidation_set(SX_ACCESS_CMD_DISABLE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to unlock PHY consolidation err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Mark all KVD hash old entries (to be deleted when ISSU is done */
    sx_status = __issu_old_bank_entries_mark(SX_ACCESS_CMD_MARK);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" failed to mark KVD old entries, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = issu_bank_get(&issu_bank);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_bank_get failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    issu_bank = (issu_bank == SX_ISSU_BANK_2_E) ? SX_ISSU_BANK_1_E : SX_ISSU_BANK_2_E;

    sx_status = __issu_bank_set(issu_bank);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_bank_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_LAG_E, "wb", &file_p, &version);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_persistent_info_storage_open_ex failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_store_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_LAG_E, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_lag_info_store failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_persistent_info_storage_close(&file_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_persistent_info_storage_close failed, path - %s, %s\n",
                   g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_LAG_E], sx_status_str(sx_status));
    }
    file_p = NULL;

    /* Extended port map store handles multi versions of pdb.*/
    sx_status = __issu_store_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_store_ex_wrapper failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_store_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_SB_POOLS_E, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_store_ex_wrapper failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_store_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_ISSU_CONFIG_E, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_store_ex_wrapper ISSU_CFG failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_store_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_ARLPGT_E, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_store_ex_wrapper ARLPGT failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_fdb_pdb_operation_set(ISSU_PDB_FILE_XLATE_OPER_STORE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" __issu_fdb_pdb_operation_set failed to store (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    profile_data_store.profile = &g_profile;
    sx_status = __issu_store_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_PROFILE_E, &profile_data_store);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_profile_store failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    utils_issue_start_flag_set();

out:
    if (file_p != NULL) {
        rb_sx_status = __issu_persistent_info_storage_close(&file_p);
        if (rb_sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n", sx_status_str(rb_sx_status));
        }
    }

    SX_LOG_EXIT();

    return sx_status;
}

sx_status_t ib_issu_start_set()
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS, rb_sx_status = SX_STATUS_SUCCESS;
    sxd_status_t            sxd_status = SXD_STATUS_SUCCESS;
    issu_profile_pdb_data_t profile_data_store;

    SX_LOG_ENTER();

    SX_MEM_CLR(profile_data_store);

    sx_status = __issu_health_check_set(TRUE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to prepare health check for ISSU, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Notify HW Manage that ISSU start*/
    sxd_status = sxd_access_reg_send_issu_notification(TRUE);
    if (SXD_CHECK_FAIL(sxd_status)) {
        sx_core_async_issu_in_progress_disable();

        SX_LOG_ERR("Fail to perform issu notification update, err [%s]\n", SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    /* Stop polling timer thread */
    sx_status = __issu_stop_polling_timer_thread(SX_TIMER_THREAD_GENERAL_E);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" failed to stop polling timer thread, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Disable event traps */
    sx_status = __issu_default_trap_disable();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to disable event traps err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Lock Phy consolidation */
    sx_status = __issu_port_phy_consolidation_set(SX_ACCESS_CMD_ENABLE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to lock PHY consolidation err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* SXD to dev NULL, only ISFU IFC can get thru to FW */
    sx_status = issu_dpt_access_control_set(READ_ONLY);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to set dpt access control = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Trigger actual FW update */
    sx_status = __issu_fw_update();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed update FW = %s\n", sx_status_str(sx_status));

        /* Allow writing to FW again */
        rb_sx_status = issu_dpt_access_control_set(READ_WRITE);
        if (SX_CHECK_FAIL(rb_sx_status)) {
            SX_LOG_ERR(" Failed to set dpt access control = %s\n", sx_status_str(rb_sx_status));
        }

        /* Unlock Phy consolidation */
        rb_sx_status = __issu_port_phy_consolidation_set(SX_ACCESS_CMD_DISABLE);
        if (SX_CHECK_FAIL(rb_sx_status)) {
            SX_LOG_ERR(" Failed to unlock PHY consolidation err = %s\n", sx_status_str(rb_sx_status));
        }
        goto out;
    }

    /* Allow writing to FW again */
    sx_status = issu_dpt_access_control_set(READ_WRITE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to set dpt access control = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Unlock Phy consolidation */
    sx_status = __issu_port_phy_consolidation_set(SX_ACCESS_CMD_DISABLE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" Failed to unlock PHY consolidation err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Extended port map store handles multi versions of pdb.*/
    sx_status = __issu_store_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_PORT_MAP_E, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_store_ex_wrapper failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    profile_data_store.profile = &g_profile;
    sx_status = __issu_store_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_PROFILE_E, &profile_data_store);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_profile_store failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    utils_issue_start_flag_set();

out:
    SX_LOG_EXIT();

    return sx_status;
}

sx_status_t issu_end_set()
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_boot_mode_e     issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    int                device_cnt = SX_DEV_ID_MAX;
    topo_device_item_t dev_attrib[SX_DEV_ID_MAX];
    uint32_t           i = 0;
    sx_device_info_t   device_info;
    sx_port_log_id_t   lag_port = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(device_info);
    memset(dev_attrib, 0, sizeof(dev_attrib));

    if (g_infiniband_issu) {
        sx_status = ib_issu_end_set();
        goto out;
    }

    sx_status = issu_boot_mode_get(&issu_boot_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to issu_boot_mode_get. sx_status = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (issu_boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
        SX_LOG_ERR("boot mode is NOT in issu start therefore cant do issu END.\n");
        sx_status = SX_STATUS_CMD_UNPERMITTED;
        goto out;
    }

    if (g_port_map_info.restore_flag == FALSE) {
        for (i = 0; i < g_port_map_info.list_size; i++) {
            if (g_port_map_info.port_mapping_done_p[i] == TRUE) {
                g_port_map_info.port_num--;
            }
        }

        if (g_port_map_info.port_num != 0) {
            SX_LOG_ERR("Port mapping was not completed.\n");
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
    }

    sx_status = utils_boot_mode_set(SX_BOOT_MODE_ISSU_FAST_E);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" utils_boot_mode_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (g_lag_db_initialized == TRUE) {
        if (g_lag_to_ports_mapping != NULL) {
            for (i = 0; i < rm_resource_global.lag_num_max; i++) {
                /* Destroy all LAGs that still exist in db but not recreated: */
                if (g_lag_to_ports_mapping[i].lid_exist == TRUE) {
                    lag_port = 0;
                    SX_PORT_TYPE_ID_SET(lag_port, SX_PORT_TYPE_LAG);
                    SX_PORT_LAG_ID_SET(lag_port, i);

                    if (g_lag_to_ports_mapping[i].port_list_cnt == 0) {
                        sx_status = sx_lag_destroy_group_in_hw(lag_port);
                        if (sx_status != SX_STATUS_SUCCESS) {
                            SX_LOG_ERR("issu_end_set:sx_lag_port_group_set DESTROY failed\n");
                        }
                    }
                }
                if (g_lag_to_ports_mapping[i].log_port_list != NULL) {
                    CL_FREE_N_NULL(g_lag_to_ports_mapping[i].log_port_list);
                }
            }
            CL_FREE_N_NULL(g_lag_to_ports_mapping);
        }

        if (g_port_to_lag_mapping != NULL) {
            CL_FREE_N_NULL(g_port_to_lag_mapping);
        }
    }
    g_lag_db_initialized = FALSE;

    /* handle lag table if managed in sw */
    if (RM_SDK_LAG_TABLE_SDK_MNGR == rm_resource_global.lag_table_mngr) {
        sx_status = sx_lag_table_issu_end();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("sx_lag_table_issu_end Failed, error: %s\n", sx_status_str(sx_status));
            goto out;
        }
    }

    sx_status = __issu_fdb_pdb_operation_set(ISSU_PDB_FILE_XLATE_OPER_RESTORE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" __issu_fdb_pdb_operation_set failed to restore (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed in topo_db_device_list_get, err [%s].\n", sx_status_str(sx_status));
        goto out;
    }

    if (device_cnt == 0) {
        SX_LOG_ERR("device list is empty.\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    device_info.dev_id = dev_attrib[0].dev_id;
    device_info.node_type = SX_DEV_NODE_TYPE_ALL;

    sx_status = flex_acl_issu_bind_acl_set(SX_ACCESS_CMD_ADD);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" flex_acl_bind_acl_trigger failed (%s) CMD: ADD\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = fdb_flood_issu_end_callback((void*)&device_info);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("fdb_flood_issu_end_callback Failed, error: %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = flex_modifier_issu_set();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" flex_modifier_issu_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_tunnel_impl_issu_set(TRUE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" sdk_tunnel_impl_issu_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = rif_impl_issu_ingress_rif_set();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" rif_impl_issu_ingress_rif_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = port_issu_vport_fid_set();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" port_issu_vport_fid_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = port_issu_type_speed_set();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" port_issu_type_speed_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __sb_pools_pdb_set();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR(" __sb_pools_pdb_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    /* Need to reconfigure vid to fid before deleting old KVH*/

    sx_status = adviser_process_event(ADVISER_EVENT_PRE_ISSU_END_E, &device_info);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Could not process adviser_process_event '%s'.\n",
                   ADVISER_EVENT_STR(ADVISER_EVENT_PRE_ISSU_END_E));
        goto out;
    }

    sx_status = hwd_router_ecmp_arlpgt_issu_end();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" hwd_router_ecmp_arlpgt_issu_end failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    sx_status = sdk_tunnel_impl_issu_set(FALSE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" sdk_tunnel_impl_issu_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_tele_impl_threshold_issu_set();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" sdk_tele_threshold_issu_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = flex_acl_issu_bind_acl_set(SX_ACCESS_CMD_BIND);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" flex_acl_bind_acl_trigger failed (%s) CMD: SET\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = atcam_bloom_filter_issu_set();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" bloom_filter_issu_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    for (i = 0; i < (uint32_t)device_cnt; i++) {
        sx_status = __issu_invalidate_acl(dev_attrib[i].dev_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_invalidate_acl failed (%s), dev_id %d\n",
                       sx_status_str(sx_status), dev_attrib[i].dev_id);
            goto out;
        }
    }

    sx_status = __issu_old_bank_entries_mark(SX_ACCESS_CMD_CLEAR);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_old_bank_entries_mark failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_fdb_learn_mode_reset();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("__issu_reset_fdb_global_learn_mode failed\n");
        goto out;
    }

    sx_status = fdb_polling_data_polling_enabled_set(rm_resource_global.swid_id_max, TRUE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" fdb_polling_data_polling_enabled_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_ar_impl_issu_end();
    SX_CHECK_RC_OUT_ERR(sx_status, "AR end failed.");

    sx_status = sdk_router_ecmp_impl_issu_end();
    SX_CHECK_RC_OUT_ERR(sx_status, "Router ecmp end failed.");

    sx_status = __issu_counter_clear_all();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("issu_counter_clear_all failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = sxd_status_to_sx_status(sxd_allow_secure_fw_dump(TRUE));
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("sxd_allow_secure_fw_dump failed, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_health_check_set(FALSE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to enable all health check features after ISSU, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_persistent_info_remove();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__issu_persistent_info_remove failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

out:
    /* free and clean issu port map info (it is stored at this point)*/
    if (g_port_map_info.port_mapping_list_p != NULL) {
        CL_FREE_N_NULL(g_port_map_info.port_mapping_list_p);
    }
    if (g_port_map_info.port_mapping_done_p != NULL) {
        CL_FREE_N_NULL(g_port_map_info.port_mapping_done_p);
    }
    g_port_map_info.port_num = 0;
    g_port_map_info.restore_flag = FALSE;

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t ib_issu_end_set()
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_boot_mode_e     issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    int                device_cnt = SX_DEV_ID_MAX;
    topo_device_item_t dev_attrib[SX_DEV_ID_MAX];
    uint32_t           i = 0;
    sx_device_info_t   device_info;

    SX_LOG_ENTER();

    SX_MEM_CLR(device_info);
    memset(dev_attrib, 0, sizeof(dev_attrib));

    sx_status = issu_boot_mode_get(&issu_boot_mode);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to issu_boot_mode_get. sx_status = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    if (issu_boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
        SX_LOG_ERR("boot mode is NOT in issu start therefore cant do issu END.\n");
        sx_status = SX_STATUS_CMD_UNPERMITTED;
        goto out;
    }

    if (g_port_map_info.restore_flag == FALSE) {
        for (i = 0; i < g_port_map_info.list_size; i++) {
            if (g_port_map_info.port_mapping_done_p[i] == TRUE) {
                g_port_map_info.port_num--;
            }
        }

        if (g_port_map_info.port_num != 0) {
            SX_LOG_ERR("Port mapping was not completed, %u ports were not mapped!\n", g_port_map_info.port_num);
            sx_status = SX_STATUS_ERROR;
            goto out;
        }
    }

    sx_status = utils_boot_mode_set(SX_BOOT_MODE_ISSU_NORMAL_E);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" utils_boot_mode_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed in topo_db_device_list_get, err [%s].\n", sx_status_str(sx_status));
        goto out;
    }

    if (device_cnt == 0) {
        SX_LOG_ERR("device list is empty.\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    device_info.dev_id = dev_attrib[0].dev_id;
    device_info.node_type = SX_DEV_NODE_TYPE_ALL;

    sx_status = port_issu_type_speed_set();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" port_issu_type_speed_set failed (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = sxd_status_to_sx_status(sxd_allow_secure_fw_dump(TRUE));
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("sxd_allow_secure_fw_dump failed, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_health_check_set(FALSE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to enable all health check features after ISSU, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = __issu_persistent_info_remove();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__issu_persistent_info_remove failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

out:
    /* free and clean issu port map info (it is stored at this point)*/
    if (g_port_map_info.port_mapping_list_p != NULL) {
        CL_FREE_N_NULL(g_port_map_info.port_mapping_list_p);
    }
    if (g_port_map_info.port_mapping_done_p != NULL) {
        CL_FREE_N_NULL(g_port_map_info.port_mapping_done_p);
    }
    g_port_map_info.port_num = 0;
    g_port_map_info.restore_flag = FALSE;

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_pause_set()
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sxd_status_t      sxd_status = SXD_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = fdb_transaction_mode_set(SX_ACCESS_CMD_DISABLE, rm_resource_global.swid_id_max);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to disable transaction mode (%s)\n", sx_status_str(err));
        goto out;
    }

    utils_err = gc_clean();
    if (utils_err != SX_UTILS_STATUS_SUCCESS) {
        err = SX_UTILS_STATUS_TO_SX_STATUS(utils_err);
        SX_LOG(SX_LOG_ERROR, "failed to clean gc (%s)\n", sx_status_str(err));
        goto out;
    }

    err = port_state_event_disable();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to disable port event generation (%s)\n", sx_status_str(err));
        goto out;
    }

    err = host_ifc_pause();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to pause host ifc (%s)\n", sx_status_str(err));
        goto out;
    }

    core_kernel_db_p_s = cl_malloc(sizeof(struct ku_sx_core_db));
    if (core_kernel_db_p_s == NULL) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate sx core kernel db\n");
        goto out;
    }
    SX_MEM_CLR_BUF(core_kernel_db_p_s, sizeof(struct ku_sx_core_db));
    sxd_status = sxd_access_reg_sx_core_db_save(core_kernel_db_p_s);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        err = sxd_status_to_sx_status(sxd_status);
        SX_LOG(SX_LOG_ERROR, "failed to save kernel db (%s)\n", sx_status_str(err));
        goto out;
    }

    sxd_status = sxd_access_reg_deinit();
    if (sxd_status != SXD_STATUS_SUCCESS) {
        err = sxd_status_to_sx_status(sxd_status);
        SX_LOG(SX_LOG_ERROR, "failed to deinit sxd access reg (%s)\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t issu_resume_set(sx_issu_resume_params_t resume_params)
{
    sx_status_t   err = SX_STATUS_SUCCESS;
    sxd_status_t  sxd_status = SXD_STATUS_SUCCESS;
    sxd_boolean_t kernel_restore_allowed = 0;

    SX_LOG_ENTER();

    sxd_status = sxd_access_reg_init(resume_params.app_id, resume_params.logging_cb,
                                     resume_params.verbosity_level);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        err = sxd_status_to_sx_status(sxd_status);
        SX_LOG(SX_LOG_ERROR, "failed to init sxd access reg (%s)\n", sx_status_str(err));
        goto out;
    }

    sxd_status = sxd_access_reg_sx_core_db_restore_allowed(&kernel_restore_allowed);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        err = sxd_status_to_sx_status(sxd_status);
        SX_LOG(SX_LOG_ERROR, "failed to check kernel db (%s)\n", sx_status_str(err));
        goto out;
    }
    if (kernel_restore_allowed) {
        if (core_kernel_db_p_s) {
            sxd_status = sxd_access_reg_sx_core_db_restore(core_kernel_db_p_s);
            if (sxd_status != SXD_STATUS_SUCCESS) {
                err = sxd_status_to_sx_status(sxd_status);
                SX_LOG_ERR("Failed to restore kernel data.\n");
                goto out;
            }
        } else {
            err = SX_STATUS_ERROR;
            SX_LOG(SX_LOG_ERROR, "No kernel db saved to restore\n");
            goto out;
        }
    }
    if (core_kernel_db_p_s) {
        CL_FREE_N_NULL(core_kernel_db_p_s);
    }

    err = host_ifc_resume();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to resume host ifc (%s)\n", sx_status_str(err));
        goto out;
    }

    err = port_module_state_sync();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to sync port module state (%s)\n", sx_status_str(err));
        goto out;
    }

    if (resume_params.sdk_transaction_mode != FALSE) {
        err = fdb_transaction_mode_set(SX_ACCESS_CMD_ENABLE, rm_resource_global.swid_id_max);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "failed to restore transaction mode (%s)\n", sx_status_str(err));
            goto out;
        }
    }

    fdb_polling_data_polling_enabled_set(0, TRUE);

out:

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __dump_module_issu_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    issu_debug_dump(dbg_dump_params_p);

    return err;
}

void issu_debug_dump(dbg_dump_params_t* dbg_dump_params_p)
{
    sx_boot_mode_e boot_mode = SX_BOOT_MODE_DISABLED_E;
    sx_issu_bank_e issu_bank = 0;
    sx_status_t    err = SX_STATUS_SUCCESS;
    FILE          *stream = NULL;

    SX_LOG_ENTER();

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_module_header_print(stream, "ISSU");
    err = utils_boot_mode_get(&boot_mode);
    if (err) {
        SX_LOG_ERR("Failed to get boot mode err = %s\n", sx_status_str(err));
    } else {
        dbg_utils_pprinter_field_print(stream, "Boot Mode", sx_boot_mode_str(boot_mode), PARAM_STRING_E);
    }

    err = issu_bank_get(&issu_bank);
    if (err) {
        SX_LOG_ERR("Failed to get ISSU bank err = %s\n", sx_status_str(err));
    } else {
        dbg_utils_pprinter_field_print(stream, "ISSU Bank", &issu_bank, PARAM_UINT32_E);
    }

    dbg_utils_print_field(stream, "Infiniband ISSU", &g_infiniband_issu, PARAM_BOOL_E);

out:
    SX_LOG_EXIT();
}

sx_status_t issu_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    *verbosity_level = LOG_VAR_NAME(__MODULE__);

    return rc;
}

static sx_status_t __issu_bank_init(sx_boot_mode_e issu_boot_mode)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    sx_status_t             rc = SX_STATUS_SUCCESS;
    cl_status_t             cl_status = CL_SUCCESS;
    FILE                   *f_p = NULL;
    uint8_t                 bank = 0;
    size_t                  file_size = 0;
    boolean_t               corrupted_file = FALSE;
    issu_pdb_file_version_e version = ISSU_PDB_FILE_VERSION_INVALID;

    SX_LOG_ENTER();

    sx_status =
        __issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_BANK_E, "rb", &f_p, &version);
    if (sx_status != SX_STATUS_SUCCESS) { /* file does not exist, create file */
        /* write default issu bank */
        g_issu_params.issu_bank = SX_ISSU_BANK_1_E;
        sx_status = SX_STATUS_SUCCESS;
    } else { /* file exists, read file */
        cl_status = cl_file_size(f_p, &file_size);
        if (cl_status != CL_SUCCESS) {
            corrupted_file = TRUE;
            sx_status = SX_STATUS_ERROR;
            SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
            goto out;
        }
        if (version == ISSU_PDB_FILE_VERSION_1) {
            if (file_size != (uint32_t)sizeof(bank)) {
                corrupted_file = TRUE;
                SX_LOG_ERR("Error, file size is not as expected, expected(%u), file size(%u)\n",
                           (uint32_t)sizeof(bank),
                           (uint32_t)file_size);
                sx_status = SX_STATUS_ERROR;
                goto out;
            }
        }
        sx_status = __issu_restore_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_BANK_E,
                                              f_p,
                                              version,
                                              NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            corrupted_file = TRUE;
            SX_LOG_ERR("Error reading issu bank from storage \n");
            goto out;
        }
    }

out:
    if (f_p != NULL) {
        rc = __issu_persistent_info_storage_close(&f_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                       g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_BANK_E]);
        }
    }

    if (corrupted_file) {
        if (issu_boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
            rc = __issu_bank_set(SX_ISSU_BANK_1_E);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(" __issu_bank_set failed (%s)\n",
                           sx_status_str(sx_status));
            } else {
                sx_status = SX_STATUS_SUCCESS;
                g_issu_params.issu_bank = SX_ISSU_BANK_1_E;
            }
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_fw_update()
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    int                device_cnt = SX_DEV_ID_MAX;
    topo_device_item_t dev_attrib[SX_DEV_ID_MAX];
    int                i = 0;

    SX_LOG_ENTER();

    memset(dev_attrib, 0, sizeof(dev_attrib));

    sx_status = topo_db_device_list_get(SX_ACCESS_CMD_GET, &device_cnt, dev_attrib);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed in topo_db_device_list_get, err [%s].\n", sx_status_str(sx_status));
        goto out;
    }

    if (device_cnt == 0) {
        SX_LOG_ERR("Can not update fw: device list is empty.\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    for (i = 0; i < device_cnt; i++) {
        sxd_status = sxd_access_reg_issu_fw(dev_attrib[i].dev_id);
        if (SXD_CHECK_FAIL(sxd_status)) {
            SX_LOG_ERR("Fail to perform fw update, err [%s]\n", SXD_STATUS_MSG(sxd_status));
            sx_status = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_profile_store(FILE* profile_file, sx_api_profile_t *profile)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint16_t    profile_csum = 0;

    SX_LOG_ENTER();

    sx_status = __issu_profile_checksum_calc(profile, &profile_csum);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error in Profile checksum calculation\n");
        goto out;
    }

    sx_status = __issu_profile_checksum_store(profile_file, profile_csum);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error in Profile checksum store\n");
        goto out;
    }

    sx_status = __issu_profile_data_store(profile_file, profile);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error in Profile data store\n");
        goto out;
    }
    goto out;

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_profile_checksum_calc(const sx_api_profile_t *profile, uint16_t *csum)
{
    sx_status_t   sx_status = SX_STATUS_SUCCESS;
    crc16_table_t crc16_table;

    crc16_table.table_init = FALSE;
    *csum = crc_16(&crc16_table, (uint8_t*)profile, sizeof(*profile), PROFILE_CRC_POLY);

    return sx_status;
}

static sx_status_t __issu_profile_checksum_store(FILE *stream, const uint16_t csum)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Checksum is being written in the first 16 bits of the file: */
    if (fseek(stream, 0, SEEK_SET) != 0) {
        SX_LOG_ERR("Failed to set pointer to the beginning of Profile persistent file \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sx_status = __issu_persistent_info_write_to_storage(&csum, sizeof(uint16_t), 1, stream);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Error writing Profile checksum to storage \n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_profile_data_store(FILE *stream, sx_api_profile_t *profile)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Profile data is being written 16bits after the beginning of the file (checksum in 1st 16b): */
    if (fseek(stream, PROFILE_CRC_LENGTH, SEEK_SET) != 0) {
        SX_LOG_ERR("Failed to set pointer to the beginning of Profile persistent file \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sx_status = __issu_persistent_info_write_to_storage(profile, sizeof(*profile), 1, stream);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Error writing Profile data to storage \n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_profile_checksum_restore(FILE *stream, uint16_t *csum)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (fseek(stream, 0, SEEK_SET) != 0) {
        SX_LOG_ERR("Failed to set pointer to the beginning of Profile persistent file \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sx_status = __issu_persistent_info_read_from_storage(csum, sizeof(uint16_t), 1, stream);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error reading Profile Checksum from storage \n");
        goto out;
    }

out:

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_profile_data_restore(FILE *stream, sx_api_profile_t *profile)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Profile data is being written 16bits after the beginning of the file (checksum in 1st 16b): */
    if (fseek(stream, PROFILE_CRC_LENGTH, SEEK_SET) != 0) {
        SX_LOG_ERR("Failed to set pointer to the beginning of Profile persistent file \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sx_status = __issu_persistent_info_read_from_storage(profile, sizeof(*profile), 1, stream);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error reading Profile data from storage \n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_profile_data_json_restore(FILE *stream, sx_api_profile_t *profile)
{
    sx_status_t sx_status = 0;
    size_t      length = 0;
    cl_status_t cl_status;
    char      * buffer = NULL;
    const char *error_ptr = NULL;
    cJSON      *json_obj = NULL, *tmp = NULL, *tmp_arr_obj = NULL, *profile_obj = NULL;
    uint32_t    i = 0;

    fseek(stream, 0, SEEK_SET);
    cl_status = cl_file_size(stream, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    buffer = cl_malloc(length + 1);
    if (!buffer) {
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    if (cl_fread(buffer, 1, length, stream) != length) {
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer[length] = 0;

    json_obj = cJSON_Parse(buffer);
    if (json_obj == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("profile data restore - Error before: %s\n", error_ptr);
        }
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    profile_obj = cJSON_GetObjectItemCaseSensitive(json_obj, "profile");
    ISSU_JSON_OBJ_GET_CHECK(profile_obj, "profile");
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "adaptive_routing_group_cap");
    ISSU_JSON_OBJ_GET(tmp, "adaptive_routing_group_cap", profile->adaptive_routing_group_cap);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "ar_sec");
    ISSU_JSON_OBJ_GET(tmp, "ar_sec", profile->ar_sec);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "arn");
    ISSU_JSON_OBJ_GET(tmp, "arn", profile->arn);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "chip_type");
    ISSU_JSON_OBJ_GET(tmp, "chip_type", profile->chip_type);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "dev_id");
    ISSU_JSON_OBJ_GET(tmp, "dev_id", profile->dev_id);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "do_not_config_profile_to_device");
    ISSU_JSON_OBJ_GET(tmp, "do_not_config_profile_to_device", profile->do_not_config_profile_to_device);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "fid_offset_table_size");
    ISSU_JSON_OBJ_GET(tmp, "fid_offset_table_size", profile->fid_offset_table_size);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "flood_mode");
    ISSU_JSON_OBJ_GET(tmp, "flood_mode", profile->flood_mode);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "ib_router_ecmp");
    ISSU_JSON_OBJ_GET(tmp, "ib_router_ecmp", profile->ib_router_ecmp);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "ib_router_ecmp_lid_range");
    ISSU_JSON_OBJ_GET(tmp, "ib_router_ecmp_lid_range", profile->ib_router_ecmp_lid_range);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "ib_router_en");
    ISSU_JSON_OBJ_GET(tmp, "ib_router_en", profile->ib_router_en);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "ib_router_mcf");
    ISSU_JSON_OBJ_GET(tmp, "ib_router_mcf", profile->ib_router_mcf);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "lag_mode");
    ISSU_JSON_OBJ_GET(tmp, "lag_mode", profile->lag_mode);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "kvd_hash_double_size");
    ISSU_JSON_OBJ_GET(tmp, "kvd_hash_double_size", profile->kvd_hash_double_size);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "kvd_hash_single_size");
    ISSU_JSON_OBJ_GET(tmp, "kvd_hash_single_size", profile->kvd_hash_single_size);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "kvd_linear_size");
    ISSU_JSON_OBJ_GET(tmp, "kvd_linear_size", profile->kvd_linear_size);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_active_vlans");
    ISSU_JSON_OBJ_GET(tmp, "max_active_vlans", profile->max_active_vlans);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_fid");
    ISSU_JSON_OBJ_GET(tmp, "max_fid", profile->max_fid);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_fid_offset_flood_tables");
    ISSU_JSON_OBJ_GET(tmp, "max_fid_offset_flood_tables", profile->max_fid_offset_flood_tables);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_flood_tables");
    ISSU_JSON_OBJ_GET(tmp, "max_flood_tables", profile->max_flood_tables);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_ib_mc");
    ISSU_JSON_OBJ_GET(tmp, "max_ib_mc", profile->max_ib_mc);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_lag");
    ISSU_JSON_OBJ_GET(tmp, "max_lag", profile->max_lag);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_mid");
    ISSU_JSON_OBJ_GET(tmp, "max_mid", profile->max_mid);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_per_fid_flood_table");
    ISSU_JSON_OBJ_GET(tmp, "max_per_fid_flood_table", profile->max_per_fid_flood_table);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_pgt");
    ISSU_JSON_OBJ_GET(tmp, "max_pgt", profile->max_pgt);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_pkey");
    ISSU_JSON_OBJ_GET(tmp, "max_pkey", profile->max_pkey);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_port_per_lag");
    ISSU_JSON_OBJ_GET(tmp, "max_port_per_lag", profile->max_port_per_lag);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_regions");
    ISSU_JSON_OBJ_GET(tmp, "max_regions", profile->max_regions);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_system_port");
    ISSU_JSON_OBJ_GET(tmp, "max_system_port", profile->max_system_port);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "max_vepa_channels");
    ISSU_JSON_OBJ_GET(tmp, "max_vepa_channels", profile->max_vepa_channels);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "per_fid_table_size");
    ISSU_JSON_OBJ_GET(tmp, "per_fid_table_size", profile->per_fid_table_size);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "set_mask_0_63");
    ISSU_JSON_OBJ_GET(tmp, "set_mask_0_63", profile->set_mask_0_63);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "set_mask_64_127");
    ISSU_JSON_OBJ_GET(tmp, "set_mask_64_127", profile->set_mask_64_127);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "split_ready");
    ISSU_JSON_OBJ_GET(tmp, "split_ready", profile->split_ready);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "ubridge_mode");
    ISSU_JSON_OBJ_GET(tmp, "ubridge_mode", profile->ubridge_mode);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "umlabel");
    ISSU_JSON_OBJ_GET(tmp, "umlabel", profile->umlabel);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_0_mask");
    ISSU_JSON_OBJ_GET(tmp, "swid_0_mask", profile->swid0_config_type.mask);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_0_properties");
    ISSU_JSON_OBJ_GET(tmp, "swid_0_properties", profile->swid0_config_type.properties);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_0_type");
    ISSU_JSON_OBJ_GET(tmp, "swid_0_type", profile->swid0_config_type.type);

    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_1_mask");
    ISSU_JSON_OBJ_GET(tmp, "swid_1_mask", profile->swid1_config_type.mask);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_1_type");
    ISSU_JSON_OBJ_GET(tmp, "swid_1_type", profile->swid1_config_type.type);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_1_properties");
    ISSU_JSON_OBJ_GET(tmp, "swid_1_properties", profile->swid1_config_type.properties);

    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_2_mask");
    ISSU_JSON_OBJ_GET(tmp, "swid_2_mask", profile->swid2_config_type.mask);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_2_properties");
    ISSU_JSON_OBJ_GET(tmp, "swid_2_properties", profile->swid2_config_type.properties);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_2_type");
    ISSU_JSON_OBJ_GET(tmp, "swid_2_type", profile->swid2_config_type.type);

    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_3_mask");
    ISSU_JSON_OBJ_GET(tmp, "swid_3_mask", profile->swid3_config_type.mask);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_3_properties");
    ISSU_JSON_OBJ_GET(tmp, "swid_3_properties", profile->swid3_config_type.properties);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_3_type");
    ISSU_JSON_OBJ_GET(tmp, "swid_3_type", profile->swid3_config_type.type);

    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_4_mask");
    ISSU_JSON_OBJ_GET(tmp, "swid_4_mask", profile->swid4_config_type.mask);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_4_properties");
    ISSU_JSON_OBJ_GET(tmp, "swid_4_properties", profile->swid4_config_type.properties);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_4_type");
    ISSU_JSON_OBJ_GET(tmp, "swid_4_type", profile->swid4_config_type.type);

    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_5_mask");
    ISSU_JSON_OBJ_GET(tmp, "swid_5_mask", profile->swid5_config_type.mask);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_5_properties");
    ISSU_JSON_OBJ_GET(tmp, "swid_5_properties", profile->swid5_config_type.properties);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_5_type");
    ISSU_JSON_OBJ_GET(tmp, "swid_5_type", profile->swid5_config_type.type);

    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_6_mask");
    ISSU_JSON_OBJ_GET(tmp, "swid_6_mask", profile->swid6_config_type.mask);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_6_properties");
    ISSU_JSON_OBJ_GET(tmp, "swid_6_properties", profile->swid6_config_type.properties);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_6_type");
    ISSU_JSON_OBJ_GET(tmp, "swid_6_type", profile->swid6_config_type.type);

    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_7_mask");
    ISSU_JSON_OBJ_GET(tmp, "swid_7_mask", profile->swid7_config_type.mask);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_7_properties");
    ISSU_JSON_OBJ_GET(tmp, "swid_7_properties", profile->swid7_config_type.properties);
    tmp = cJSON_GetObjectItemCaseSensitive(profile_obj, "swid_7_type");
    ISSU_JSON_OBJ_GET(tmp, "swid_7_type", profile->swid7_config_type.type);

    tmp_arr_obj = cJSON_GetObjectItemCaseSensitive(profile_obj, "sup_revs_by_type");
    ISSU_JSON_OBJ_GET_CHECK(tmp_arr_obj, "sup_revs_by_type");

    if (tmp_arr_obj != NULL) {
        i = 0;
        cJSON_ArrayForEach(tmp, tmp_arr_obj)
        {
            ISSU_JSON_OBJ_GET(tmp, "sup_revs_by_type", profile->sup_revs_by_type[i]);
            i++;
        }
    }
out:
    if (buffer) {
        cl_free(buffer);
    }
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    return sx_status;
}
static sx_status_t __issu_profile_compare(sx_api_profile_t *profile)
{
    sx_status_t             sx_status = SX_STATUS_SUCCESS, rb_sx_status = SX_STATUS_SUCCESS;
    uint16_t                new_profile_csum = 0;
    issu_profile_pdb_data_t old_profile_data;
    sx_api_profile_t        old_profile;
    FILE                   *profile_file = NULL;
    issu_pdb_file_version_e version = ISSU_PDB_FILE_VERSION_INVALID;

    SX_LOG_ENTER();
    memset(&old_profile_data, 0, sizeof(old_profile_data));
    memset(&old_profile, 0, sizeof(old_profile));
    old_profile_data.profile = &old_profile;

    sx_status =
        __issu_persistent_info_storage_open_ex(ISSU_PDB_FILE_INFO_TYPE_PROFILE_E, "rb", &profile_file, &version);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_INF(" __issu_persistent_info_storage_open_ex failed (%s)\n",
                   sx_status_str(sx_status));
        sx_status = SX_STATUS_SUCCESS;
        goto out_no_persistent;
    }

    sx_status = __issu_restore_ex_wrapper(ISSU_PDB_FILE_INFO_TYPE_PROFILE_E, profile_file, version, &old_profile_data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error reading Profile checksum from storage\n");
        goto out;
    }
    sx_status = __issu_profile_checksum_calc(profile, &new_profile_csum);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error in Profile checksum calculation\n");
        goto out;
    }

    if (old_profile_data.profile_csum != new_profile_csum) {
        sx_status = __issu_profile_data_compare(old_profile_data.profile, profile);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Profile is not equal to pre-ISSU profile\n");
            goto out;
        } else {
            SX_LOG_NTC("Profile is not equal to pre-ISSU profile\n");
        }
    }

out:
    rb_sx_status = __issu_persistent_info_storage_close(&profile_file);
    if (rb_sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __issu_persistent_info_storage_close failed %s\n",
                   g_issu_pdb_paths_db[ISSU_PDB_FILE_INFO_TYPE_PROFILE_E]);
    }

out_no_persistent:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_profile_checksum_json_restore(FILE* f_p, uint16_t *csum)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    cJSON      *json_obj = NULL, *csum_obj = NULL;
    cl_status_t cl_status = 0;
    char      * buffer = NULL;
    const char* error_ptr = NULL;
    size_t      length = 0;


    fseek(f_p, 0, SEEK_SET);
    cl_status = cl_file_size(f_p, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    buffer = cl_malloc(length + 1);
    if (!buffer) {
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    if (cl_fread(buffer, 1, length, f_p) != length) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Error reading profile checksum from JSON file\n");
        goto out;
    }

    buffer[length] = 0;

    json_obj = cJSON_Parse(buffer);
    if (json_obj == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("profile checksum restore - Error before: %s\n", error_ptr);
        }
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    csum_obj = cJSON_GetObjectItem(json_obj, "csum");
    ISSU_JSON_OBJ_GET_CHECK(csum_obj, "csum");
    *csum = csum_obj->valuedouble;
out:
    if (buffer) {
        cl_free(buffer);
    }
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_profile_json_store(FILE* profile_file, sx_api_profile_t *profile)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint16_t    profile_csum = 0;
    cJSON      *json_obj = NULL;
    cJSON      *profile_obj = NULL;
    cJSON      *tmp_arr_obj = NULL;
    cJSON      *tmp_obj = NULL;
    uint8_t     i = 0;
    char       *json_obj_str = NULL;

    SX_LOG_ENTER();

    sx_status = __issu_profile_checksum_calc(profile, &profile_csum);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error in Profile checksum calculation\n");
        goto out;
    }

    json_obj = cJSON_CreateObject();
    if (json_obj == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to create JSON object for ISSU port map store (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }

    tmp_obj = cJSON_CreateNumber(profile_csum);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(json_obj, "csum", tmp_obj);

    profile_obj = cJSON_CreateObject();
    if (profile_obj == NULL) {
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    cJSON_AddItemToObject(json_obj, "profile", profile_obj);

    tmp_obj = cJSON_CreateNumber(profile->adaptive_routing_group_cap);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "adaptive_routing_group_cap", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->ar_sec);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "ar_sec", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->arn);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "arn", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->chip_type);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "chip_type", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->dev_id);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "dev_id", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->do_not_config_profile_to_device);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "do_not_config_profile_to_device", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->fid_offset_table_size);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "fid_offset_table_size", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->flood_mode);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "flood_mode", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->ib_router_ecmp);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "ib_router_ecmp", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->ib_router_ecmp_lid_range);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "ib_router_ecmp_lid_range", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->ib_router_en);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "ib_router_en", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->ib_router_mcf);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "ib_router_mcf", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->lag_mode);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "lag_mode", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->kvd_hash_double_size);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "kvd_hash_double_size", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->kvd_hash_single_size);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "kvd_hash_single_size", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->kvd_linear_size);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "kvd_linear_size", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_active_vlans);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_active_vlans", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_fid);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_fid", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_fid_offset_flood_tables);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_fid_offset_flood_tables", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_ib_mc);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_ib_mc", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_flood_tables);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_flood_tables", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_lag);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_lag", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_mid);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_mid", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_per_fid_flood_table);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_per_fid_flood_table", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_per_vid_flood_tables);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_per_vid_flood_tables", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_pgt);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_pgt", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_pkey);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_pkey", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_port_per_lag);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_port_per_lag", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_regions);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_regions", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_system_port);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_system_port", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->max_vepa_channels);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "max_vepa_channels", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->per_fid_table_size);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "per_fid_table_size", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->set_mask_0_63);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "set_mask_0_63", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->set_mask_64_127);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "set_mask_64_127", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->split_ready);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "split_ready", tmp_obj);
    tmp_arr_obj = cJSON_CreateArray();
    if (tmp_arr_obj == NULL) {
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    cJSON_AddItemToObject(profile_obj, "sup_revs_by_type", tmp_arr_obj);
    for (i = 0; i < SXD_CHIP_TYPES_MAX_ISSU; i++) {
        tmp_obj = cJSON_CreateNumber(profile->sup_revs_by_type[i]);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
        cJSON_AddItemToObject(tmp_arr_obj, "sup_revs_by_type element", tmp_obj);
    }
    tmp_obj = cJSON_CreateNumber(profile->ubridge_mode);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "ubridge_mode", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->umlabel);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "umlabel", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid0_config_type.mask);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_0_mask", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid0_config_type.properties);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_0_properties", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid0_config_type.type);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_0_type", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid1_config_type.mask);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_1_mask", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid1_config_type.properties);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_1_properties", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid1_config_type.type);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_1_type", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid2_config_type.mask);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_2_mask", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid2_config_type.properties);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_2_properties", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid2_config_type.type);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_2_type", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid3_config_type.mask);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_3_mask", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid3_config_type.properties);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_3_properties", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid3_config_type.type);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_3_type", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid4_config_type.mask);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_4_mask", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid4_config_type.properties);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_4_properties", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid4_config_type.type);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_4_type", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid5_config_type.mask);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_5_mask", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid5_config_type.properties);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_5_properties", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid5_config_type.type);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_5_type", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid6_config_type.mask);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_6_mask", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid6_config_type.properties);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_6_properties", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid6_config_type.type);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_6_type", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid7_config_type.mask);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_7_mask", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid7_config_type.properties);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_7_properties", tmp_obj);
    tmp_obj = cJSON_CreateNumber(profile->swid7_config_type.type);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(profile_obj, "swid_7_type", tmp_obj);

    json_obj_str = cJSON_Print(json_obj);
    if (json_obj_str == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to print the JSON object into a string (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    fprintf(profile_file, "%s", json_obj_str);
out:
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    if (json_obj_str != NULL) {
        cJSON_free(json_obj_str);
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_port_post_init(sx_port_log_id_t log_port)
{
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    sx_port_log_id_t lid;
    sx_port_log_id_t lag_port = 0;
    sx_port_phy_id_t local_port;

    SX_LOG_ENTER();

    if (g_lag_db_initialized != TRUE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (g_issu_empty_lags_created_flag == FALSE) {
        sx_status = __issu_lag_create_empty_lags();
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" Creation of empty LAGs failed (%s)\n",
                       sx_status_str(sx_status));
            goto out;
        }
        g_issu_empty_lags_created_flag = TRUE;
    }

    local_port = SX_PORT_PHY_ID_GET(log_port);
    if (local_port <= rm_resource_global.port_ext_num_max) {
        ATOMIC_LOAD_VAL(lid, g_port_to_lag_mapping[local_port - 1]);
        if ((lid == INVALID_LAG_ID) || (lid >= rm_resource_global.lag_num_max)) {
            goto out;
        }
    } else {
        SX_LOG_ERR("out of range port(%d)\n", local_port);
        goto out;
    }

    g_lag_to_ports_mapping[lid].port_recreated_count++;

    if (g_lag_to_ports_mapping[lid].port_recreated_count == g_lag_to_ports_mapping[lid].port_list_cnt) {
        SX_PORT_TYPE_ID_SET(lag_port, SX_PORT_TYPE_LAG);
        SX_PORT_LAG_ID_SET(lag_port, lid);
        sx_status = sx_lag_port_group_set(SX_ACCESS_CMD_CREATE,
                                          0 /*swid*/,
                                          &lag_port,
                                          g_lag_to_ports_mapping[lid].log_port_list,
                                          g_lag_to_ports_mapping[lid].port_list_cnt);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("issu_port_post_init:sx_lag_port_group_set CREATE failed\n");
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_profile_data_compare(sx_api_profile_t *old_profile_p, sx_api_profile_t *profile_p)
{
    char             buffer[70] = {0};
    sxd_chip_types_t type = 0;
    sx_status_t      sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    PROFILE_FIELD_IS_MATCHING(old_profile_p->dev_id, profile_p->dev_id, "dev_id", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->set_mask_0_63, profile_p->set_mask_0_63, "set_mask_0_63", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->set_mask_64_127,
                              profile_p->set_mask_64_127,
                              "set_mask_64_127", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_vepa_channels,
                              profile_p->max_vepa_channels,
                              "max_vepa_channels", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_lag, profile_p->max_lag, "max_lag", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_port_per_lag,
                              profile_p->max_port_per_lag,
                              "max_port_per_lag", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_mid, profile_p->max_mid, "max_mid", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_pgt, profile_p->max_pgt, "max_pgt", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_system_port,
                              profile_p->max_system_port,
                              "max_system_port", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_active_vlans,
                              profile_p->max_active_vlans,
                              "max_active_vlans", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_regions, profile_p->max_regions, "max_regions", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_flood_tables,
                              profile_p->max_flood_tables,
                              "max_flood_tables", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_per_vid_flood_tables,
                              profile_p->max_per_vid_flood_tables,
                              "max_per_vid_flood_tables", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->flood_mode, profile_p->flood_mode, "flood_mode", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_fid_offset_flood_tables,
                              profile_p->max_fid_offset_flood_tables,
                              "max_fid_offset_flood_tables", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->fid_offset_table_size,
                              profile_p->fid_offset_table_size,
                              "fid_offset_table_size", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_per_fid_flood_table,
                              profile_p->max_per_fid_flood_table,
                              "max_per_fid_flood_table", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->per_fid_table_size,
                              profile_p->per_fid_table_size,
                              "per_fid_table_size", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_fid, profile_p->max_fid, "max_fid", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_ib_mc, profile_p->max_ib_mc, "max_ib_mc", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->max_pkey, profile_p->max_pkey, "max_pkey", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->ar_sec, profile_p->ar_sec, "ar_sec", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->adaptive_routing_group_cap,
                              profile_p->adaptive_routing_group_cap,
                              "adaptive_routing_group_cap", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->arn, profile_p->arn, "arn", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->lag_mode, profile_p->lag_mode, "lag_mode", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->kvd_linear_size,
                              profile_p->kvd_linear_size,
                              "kvd_linear_size", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->kvd_hash_single_size,
                              profile_p->kvd_hash_single_size,
                              "kvd_hash_single_size", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->kvd_hash_double_size,
                              profile_p->kvd_hash_double_size,
                              "kvd_hash_double_size", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid0_config_type.mask,
                              profile_p->swid0_config_type.mask,
                              "swid0_config_type.mask", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid0_config_type.properties,
                              profile_p->swid0_config_type.properties,
                              "swid0_config_type.properties", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid0_config_type.type,
                              profile_p->swid0_config_type.type,
                              "swid0_config_type.type", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid1_config_type.mask,
                              profile_p->swid1_config_type.mask,
                              "swid1_config_type.mask", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid1_config_type.properties,
                              profile_p->swid1_config_type.properties,
                              "swid1_config_type.properties", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid1_config_type.type,
                              profile_p->swid1_config_type.type,
                              "swid1_config_type.type", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid2_config_type.mask,
                              profile_p->swid2_config_type.mask,
                              "swid2_config_type.mask", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid2_config_type.properties,
                              profile_p->swid2_config_type.properties,
                              "swid2_config_type.properties", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid2_config_type.type,
                              profile_p->swid2_config_type.type,
                              "swid2_config_type.type", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid3_config_type.mask,
                              profile_p->swid3_config_type.mask,
                              "swid3_config_type.mask", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid3_config_type.properties,
                              profile_p->swid3_config_type.properties,
                              "swid3_config_type.properties", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid3_config_type.type,
                              profile_p->swid3_config_type.type,
                              "swid3_config_type.type", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid4_config_type.mask,
                              profile_p->swid4_config_type.mask,
                              "swid4_config_type.mask", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid4_config_type.properties,
                              profile_p->swid4_config_type.properties,
                              "swid4_config_type.properties", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid4_config_type.type,
                              profile_p->swid4_config_type.type,
                              "swid4_config_type.type", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid5_config_type.mask,
                              profile_p->swid5_config_type.mask,
                              "swid5_config_type.mask", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid5_config_type.properties,
                              profile_p->swid5_config_type.properties,
                              "swid5_config_type.properties", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid5_config_type.type,
                              profile_p->swid5_config_type.type,
                              "swid5_config_type.type", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid6_config_type.mask,
                              profile_p->swid6_config_type.mask,
                              "swid6_config_type.mask", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid6_config_type.properties,
                              profile_p->swid6_config_type.properties,
                              "swid6_config_type.properties", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid6_config_type.type,
                              profile_p->swid6_config_type.type,
                              "swid6_config_type.type", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid7_config_type.mask,
                              profile_p->swid7_config_type.mask,
                              "swid7_config_type.mask", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid7_config_type.properties,
                              profile_p->swid7_config_type.properties,
                              "swid7_config_type.properties", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->swid7_config_type.type,
                              profile_p->swid7_config_type.type,
                              "swid7_config_type.type", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->ib_router_en, profile_p->ib_router_en, "ib_router_en", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->ib_router_ecmp, profile_p->ib_router_ecmp, "ib_router_ecmp", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->ib_router_mcf, profile_p->ib_router_mcf, "ib_router_mcf", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->ib_router_ecmp_lid_range,
                              profile_p->ib_router_ecmp_lid_range,
                              "ib_router_ecmp_lid_range", sx_status);

    if (old_profile_p->ubridge_mode != profile_p->ubridge_mode) { /* ubridge_mode use is deprecated */
        SX_LOG_NTC("ubridge_mode fields mismatch, old field = %u" PRIu64
                   " new_field = %u" PRIu64 "\n", old_profile_p->ubridge_mode, profile_p->ubridge_mode);
    }

    for (; type < SXD_CHIP_TYPES_MAX_ISSU; type++) {
        snprintf(buffer,
                 strlen("sup_revs_by_type for chip type ") + strlen(sx_chip_type_str(
                                                                        (sx_chip_types_t)type)) + 2,
                 "%s%s",
                 "sup_revs_by_type for chip type ",
                 sx_chip_type_str((sx_chip_types_t)type));
        PROFILE_FIELD_IS_MATCHING(old_profile_p->sup_revs_by_type[type],
                                  profile_p->sup_revs_by_type[type],
                                  buffer, sx_status);
    }

    PROFILE_FIELD_IS_MATCHING(old_profile_p->chip_type, profile_p->chip_type, "chip_type", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->do_not_config_profile_to_device,
                              profile_p->do_not_config_profile_to_device,
                              "do_not_config_profile_to_device", sx_status);
    PROFILE_FIELD_IS_MATCHING(old_profile_p->split_ready, profile_p->split_ready, "split_ready", sx_status);

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_fdb_single_mac_json_add(sx_fdb_uc_mac_addr_params_t *mac_entry_p, cJSON  **json_obj)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    sx_tunnel_map_entry_t map_entry;
    cJSON                *tmp_obj = NULL, *arr_obj = NULL;
    uint8_t               i = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(map_entry);


    arr_obj = cJSON_CreateArray();
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(arr_obj, sx_status);
    cJSON_AddItemToObject(*json_obj, "mac_addr", arr_obj);

    for (i = 0; i < ETHER_ADDR_LEN; i++) {
        tmp_obj = cJSON_CreateNumber(mac_entry_p->mac_addr.ether_addr_octet[i]);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
        cJSON_AddItemToObject(arr_obj, "ether_addr_octet", tmp_obj);
    }

    tmp_obj = cJSON_CreateNumber(mac_entry_p->log_port);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(*json_obj, "log_port", tmp_obj);

    /*stored fid is applicable only in case vlan
     * for tunnel/bridge fid will be set post SU*/
    if ((!IS_VPORT_OR_VLAG(mac_entry_p->log_port)) &&
        (mac_entry_p->dest_type != SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP)) {
        tmp_obj = cJSON_CreateNumber(mac_entry_p->fid_vid);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
        cJSON_AddItemToObject(*json_obj, "fid_vid", tmp_obj);
    }

    tmp_obj = cJSON_CreateNumber(mac_entry_p->dest_type);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(*json_obj, "dest_type", tmp_obj);

    if (mac_entry_p->dest_type == SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP) {
        tmp_obj = cJSON_CreateNumber(mac_entry_p->dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
        cJSON_AddItemToObject(*json_obj, "tunnel_id", tmp_obj);

        tmp_obj = cJSON_CreateNumber(
            mac_entry_p->dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip.addr.ipv4.s_addr);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
        cJSON_AddItemToObject(*json_obj, "ipv4_s_addr", tmp_obj);

        /*get vni from map entry*/
        sx_status = sdk_tunnel_impl_mapping_get_by_fid(
            mac_entry_p->dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id,
            mac_entry_p->fid_vid,
            &map_entry);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get from tunnel[0x%08x] entry with FID %u , err = %s\n",
                       mac_entry_p->dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id,
                       mac_entry_p->fid_vid, sx_status_str(sx_status));
            goto out;
        }

        tmp_obj = cJSON_CreateNumber(map_entry.params.nve.vni);
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
        cJSON_AddItemToObject(*json_obj, "vni", tmp_obj);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_fdb_mac_list_json_add(sx_fdb_uc_mac_addr_params_t *mac_list,
                                                uint32_t                    *mac_list_cnt,
                                                cJSON                      **arr_obj)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    list_idx = 0;
    uint32_t    list_cnt = 0;
    uint32_t    valid_cnt = 0;
    cJSON      *tmp_obj = NULL;

    SX_LOG_ENTER();


    if (!SX_FDB_CHECK_GET_UC_RANGE((*mac_list_cnt))) {
        SX_LOG_ERR(
            "__issu_fdb_mac_list_json_add:  mac_list_cnt invalid param(%u)\n",
            (*mac_list_cnt));
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    list_cnt = *mac_list_cnt;

    for (; list_idx < list_cnt; list_idx++) {
        sx_status = fdb_uc_impl_store_issu_sort_validate(&mac_list[list_idx]);
        if (SX_CHECK_FAIL(sx_status)) {
            if (sx_status == SX_STATUS_UNSUPPORTED) {
                sx_status = SX_STATUS_SUCCESS;
                SX_LOG_NTC("__issu_fdb_mac_list_json_add: Invalid Mac entry for ISSU persistent db \n");
                continue;
            } else {
                SX_LOG_ERR("__issu_fdb_mac_list_json_add: Mac entry PDB store validation failure  \n");
                goto out;
            }
        }

        tmp_obj = cJSON_CreateObject();
        ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
        cJSON_AddItemToObject(*arr_obj, "mac_entry", tmp_obj);

        sx_status = __issu_fdb_single_mac_json_add(&mac_list[list_idx], &tmp_obj);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("__issu_fdb_mac_list_json_add: Error writing MAC record to Persistent data base \n");
            goto out;
        }

        valid_cnt++;
    }

    *mac_list_cnt = valid_cnt;
    if (valid_cnt != list_cnt) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR(
            "__issu_fdb_mac_list_json_add: Error MAC record store failure expected num of entries: %d valid: %d \n",
            list_cnt,
            valid_cnt);
        goto out;
    }

out:

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_fdb_records_store(FILE *stream, void *ctxt_p)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    sx_swid_id_t                swid = rm_resource_global.swid_id_max;
    sx_fdb_uc_mac_addr_params_t key, mac_list[SX_FDB_MAX_GET_ENTRIES];
    sx_fdb_uc_key_filter_t      key_filter;
    uint32_t                    cnt = SX_FDB_MAX_GET_ENTRIES, valid_cnt = 0;
    uint32_t                    total_entries_count = 0;
    sx_access_cmd_t             access_cmd = SX_ACCESS_CMD_GET_FIRST;
    cJSON                      *json_obj = NULL, *arr_obj = NULL, *tmp_obj = NULL;
    char                       *json_obj_str = NULL;

    UNUSED_PARAM(ctxt_p);
    SX_MEM_CLR(mac_list);
    SX_MEM_CLR(key_filter);
    SX_MEM_CLR(key);
    SX_LOG_ENTER();

    /* create json object */
    json_obj = cJSON_CreateObject();
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(json_obj, sx_status);

    /* create mac_list json object */
    arr_obj = cJSON_CreateArray();
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(arr_obj, sx_status);
    cJSON_AddItemToObject(json_obj, "mac_entry_list", arr_obj);


    /* Get max bulk entries from db and process */
    do {
        sx_status = fdb_uc_mac_addr_get(access_cmd, swid, SX_FDB_UC_AGEABLE, key, key_filter, mac_list, &cnt);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("fdb_uc_mac_addr_get failed.\n");
            goto out;
        }

        /* no ageable entries */
        if (0 == cnt) {
            break;
        }
        valid_cnt = cnt;

        sx_status = __issu_fdb_mac_list_json_add(mac_list, &valid_cnt, &arr_obj);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Error writing MAC list of records to Persistent data base \n");
            goto out;
        }
        /*cont. from last record*/
        key.fid_vid = mac_list[cnt - 1].fid_vid;
        key.mac_addr = mac_list[cnt - 1].mac_addr;
        access_cmd = SX_ACCESS_CMD_GETNEXT;
        total_entries_count += valid_cnt;
    } while (cnt == SX_FDB_MAX_GET_ENTRIES);

    /* nothing to store in the pdb */
    if (0 == total_entries_count) {
        goto out;
    }

    /* add total_entries_count */
    tmp_obj = cJSON_CreateNumber(total_entries_count);
    ISSU_JSON_CREATE_OBJ_NULL_CHECK_OUT(tmp_obj, sx_status);
    cJSON_AddItemToObject(json_obj, "total_entries_count", tmp_obj);

    /* write to file */
    json_obj_str = cJSON_Print(json_obj);
    if (json_obj_str == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to print the JSON object into a string (%s)\n",
                   sx_status_str(sx_status));
        goto out;
    }
    fprintf(stream, "%s", json_obj_str);


out:
    if (json_obj) {
        cJSON_Delete(json_obj);
    }

    if (json_obj_str != NULL) {
        cJSON_free(json_obj_str);
    }

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_fdb_uc_mac_addr_set(sx_fdb_uc_mac_addr_params_t *mac_list,
                                              sx_tunnel_vni_t             *vni_list,
                                              uint32_t                     mac_list_cnt)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    list_idx = 0, valid_cnt = 0;

    SX_LOG_ENTER();

    /*filter only validated FDB's*/
    for (; list_idx < mac_list_cnt; list_idx++) {
        sx_status = fdb_uc_impl_restore_issu_sort(&mac_list[list_idx], vni_list[list_idx]);
        if (SX_CHECK_FAIL(sx_status)) {
            sx_status = SX_STATUS_SUCCESS;
            continue;
        }
        /* list only validated records */
        if (list_idx != valid_cnt) {
            memcpy(&mac_list[valid_cnt], &mac_list[list_idx], sizeof(sx_fdb_uc_mac_addr_params_t));
        }
        valid_cnt++;
    }
    /* if none valid no need to set*/
    if (valid_cnt == 0) {
        goto out;
    }

    sx_status = fdb_uc_mac_addr_set(SX_ACCESS_CMD_ADD, 0 /*swid*/, mac_list, &valid_cnt);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("__issu_fdb_uc_mac_addr_set: Failed to add mac entry to fdb, err= %s.\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_fdb_records_restore(FILE *stream, void *fdb_params)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    cl_status_t cl_status = 0;
    size_t      length = 0;
    char       *buffer = NULL;
    const char *error_ptr = NULL;
    cJSON      *json_obj = NULL, *mac_entry_arr = NULL, *mac_addr_arr = NULL,
               *mac_entry_obj = NULL, *mac_addr_obj = NULL, *tmp_obj = NULL;
    uint32_t                     total_entries_count = 0;
    sx_fdb_uc_mac_addr_params_t *mac_list = NULL;
    sx_tunnel_vni_t             *vni_list = NULL;
    uint32_t                     mac_cnt = 0, octet_idx = 0;

    UNUSED_PARAM(fdb_params);
    SX_LOG_ENTER();

    fseek(stream, 0, SEEK_SET);
    cl_status = cl_file_size(stream, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    /* No need to allocate memory and read an empty file. */
    if (length == 0) {
        goto out;
    }

    buffer = cl_malloc(length + 1);
    if (!buffer) {
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    if (cl_fread(buffer, 1, length, stream) != length) {
        SX_LOG_ERR("Error reading FDB records JSON file \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    buffer[length] = 0;

    json_obj = cJSON_Parse(buffer);
    if (json_obj == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("FDB records restore - Error before: %s\n", error_ptr);
        }
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    mac_entry_arr = cJSON_GetObjectItemCaseSensitive(json_obj, "mac_entry_list");
    ISSU_JSON_OBJ_GET_CHECK(mac_entry_arr, "mac_entry_list");


    tmp_obj = cJSON_GetObjectItemCaseSensitive(json_obj, "total_entries_count");
    ISSU_JSON_OBJ_GET(tmp_obj, "total_entries_count", total_entries_count);

    if ((total_entries_count == 0) || ((uint32_t)cJSON_GetArraySize(mac_entry_arr) != total_entries_count)) {
        SX_LOG_NTC("Invalid mac entry count from JSON PDB - FDB recovery failure \n");
        goto out;
    }

    mac_list = (sx_fdb_uc_mac_addr_params_t *)cl_calloc(total_entries_count, sizeof(sx_fdb_uc_mac_addr_params_t));
    if (mac_list == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }

    vni_list = (sx_tunnel_vni_t *)cl_calloc(total_entries_count, sizeof(sx_tunnel_vni_t));
    if (vni_list == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cJSON_ArrayForEach(mac_entry_obj, mac_entry_arr) {
        mac_list[mac_cnt].entry_type = SX_FDB_UC_AGEABLE;
        mac_list[mac_cnt].action = SX_FDB_ACTION_FORWARD;
        mac_list[mac_cnt].fid_vid = 0xFFFF; /*SX_FID_ID_INVALID*/

        tmp_obj = cJSON_GetObjectItemCaseSensitive(mac_entry_obj, "dest_type");
        ISSU_JSON_OBJ_GET(tmp_obj, "det_type", mac_list[mac_cnt].dest_type);

        tmp_obj = cJSON_GetObjectItemCaseSensitive(mac_entry_obj, "log_port");
        ISSU_JSON_OBJ_GET(tmp_obj, "log_port", mac_list[mac_cnt].log_port);

        /* fid is usable only in case of vlan fid*/
        if (!IS_VPORT_OR_VLAG(mac_list[mac_cnt].log_port) &&
            ((SX_PORT_TYPE_ID_GET(mac_list[mac_cnt].log_port) != SX_PORT_TYPE_TUNNEL))) {
            tmp_obj = cJSON_GetObjectItemCaseSensitive(mac_entry_obj, "fid_vid");
            ISSU_JSON_OBJ_GET(tmp_obj, "fid_vid", mac_list[mac_cnt].fid_vid);
        }

        mac_addr_arr = cJSON_GetObjectItemCaseSensitive(mac_entry_obj, "mac_addr");
        ISSU_JSON_OBJ_GET_CHECK(mac_addr_arr, "mac_addr");

        if (cJSON_GetArraySize(mac_addr_arr) != ETHER_ADDR_LEN) {
            SX_LOG_NTC("Invalid mac address octet count from JSON PDB - FDB recovery failure \n");
            continue;
        }

        octet_idx = 0;
        cJSON_ArrayForEach(mac_addr_obj, mac_addr_arr) {
            mac_list[mac_cnt].mac_addr.ether_addr_octet[octet_idx] = mac_addr_obj->valuedouble;
            octet_idx++;
        }

        if (mac_list[mac_cnt].dest_type == SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP) {
            mac_list[mac_cnt].dest.next_hop.next_hop_key.type = SX_NEXT_HOP_TYPE_TUNNEL_ENCAP;
            mac_list[mac_cnt].dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip.version =
                SX_IP_VERSION_IPV4;

            tmp_obj = cJSON_GetObjectItemCaseSensitive(mac_entry_obj, "tunnel_id");
            ISSU_JSON_OBJ_GET(tmp_obj,
                              "tunnel_id",
                              mac_list[mac_cnt].dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.tunnel_id);

            tmp_obj = cJSON_GetObjectItemCaseSensitive(mac_entry_obj, "ipv4_s_addr");
            ISSU_JSON_OBJ_GET(tmp_obj,
                              "ipv4_s_addr",
                              mac_list[mac_cnt].dest.next_hop.next_hop_key.next_hop_key_entry.ip_tunnel.underlay_dip.addr.ipv4.s_addr);

            tmp_obj = cJSON_GetObjectItemCaseSensitive(mac_entry_obj, "vni");
            ISSU_JSON_OBJ_GET(tmp_obj,
                              "vni",
                              vni_list[mac_cnt]);
        }

        mac_cnt++;
    }

    sx_status = __issu_fdb_uc_mac_addr_set(mac_list, vni_list, mac_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to recover mac FDB entries during ISSU \n");
        goto out;
    }

out:
    if (vni_list) {
        cl_free(vni_list);
    }
    if (mac_list) {
        cl_free(mac_list);
    }
    if (buffer) {
        cl_free(buffer);
    }
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t __issu_health_check_set(boolean_t issu_on)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_dbg_health_sample_params_t health_params;

    SX_LOG_ENTER();
    SX_MEM_CLR(health_params);

    if (sxd_health_check_active_get()) {
        if (issu_on == TRUE) {
            health_params.issu_on = TRUE;
            health_params.issu_off = FALSE;
        } else {
            health_params.issu_off = TRUE;
            health_params.issu_on = FALSE;
        }

        sx_status = dbg_fatal_failure_detect(SX_ACCESS_CMD_ENABLE, &health_params);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("failed to set health check ISSU mode, err = %s\n", sx_status_str(sx_status));
            goto out;
        }
    }

out:

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_mocs_counter_clear()
{
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    boolean_t                in_progress = FALSE;
    uint8_t                  i = 0;
    uint8_t                  mocs_cnt = 0;
    sxd_bulk_cntr_event_id_t ev_id;
    uint8_t                  intrvl = 0, max_interval = 20;
    uint32_t                 time_value = 500000;
    uint8_t                  free_idx = 0;
    uint32_t                 max_accuflow_counters = 0;

#ifdef PD_BU
    SX_LOG(SX_LOG_INFO, "############# MOCS counter clear is with increased timeout in Palladium mode.\n");
    time_value = 5000000;
    max_interval = 200;
#endif

    SX_LOG_ENTER();

    for (i = SX_BULK_CNTR_KEY_TYPE_PORT_E; i <= SX_BULK_CNTR_KEY_TYPE_ELEPHANT_E; i++) {
        sx_status = bulk_counter_transaction_in_progress_get(i, &in_progress);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get MOCS transaction in progress status err - %s\n", sx_status_str(sx_status));
            goto out;
        }

        if (in_progress) {
            SX_LOG_WRN("MOCS in progress - for counter type %u", i);
            mocs_cnt++;
        }
    }

    if (mocs_cnt) {
        SX_LOG_WRN("MOCS in progress - ISSU Counter clear will not be performed");
        goto out;
    }

    g_issu_mocs_in_session = TRUE;
    cl_spinlock_init(&g_issu_counter_mocs[0].event_spinlock);
    cl_spinlock_init(&g_issu_counter_mocs[1].event_spinlock);

    ev_id.event_id_fields.id = 0;
    ev_id.event_id_fields.type = SXD_BULK_CNTR_KEY_TYPE_ISSU_E;

    cl_spinlock_acquire(&g_issu_counter_mocs[0].event_spinlock);
    cl_spinlock_acquire(&g_issu_counter_mocs[1].event_spinlock);

    g_issu_counter_mocs[0].done = TRUE;
    g_issu_counter_mocs[1].done = TRUE;

    g_issu_counter_mocs[0].event_id = ev_id.event_id_value;
    /*Start flow/RIF counters clear*/
    sx_status = bulk_counter_issu_mocs_clear(SXD_MOCS_TYPE_MGPCB_E, &ev_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get MOCS transaction in progress status err - %s\n", sx_status_str(sx_status));
        goto out;
    }

    g_issu_counter_mocs[0].done = FALSE;
    cl_spinlock_release(&g_issu_counter_mocs[0].event_spinlock);

    ev_id.event_id_fields.id++;
    g_issu_counter_mocs[1].event_id = ev_id.event_id_value;
    /*Start port counters clear*/
    sx_status = bulk_counter_issu_mocs_clear(SXD_MOCS_TYPE_PPCNT_SES1_E, &ev_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get MOCS transaction in progress status err - %s\n", sx_status_str(sx_status));
        goto out;
    }

    g_issu_counter_mocs[1].done = FALSE;
    cl_spinlock_release(&g_issu_counter_mocs[1].event_spinlock);

    sx_status = flow_counter_accumulated_num_get(&max_accuflow_counters);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get max number of ACCUFLOW counters status err - %s\n", sx_status_str(sx_status));
        goto out;
    }

    if (max_accuflow_counters) {
        /*waiting until the first MOCS is done*/
        for (intrvl = 0; intrvl < max_interval; ++intrvl) {
            if (g_issu_counter_mocs[0].done) {
                free_idx = 0;
                break;
            } else if (g_issu_counter_mocs[1].done) {
                free_idx = 1;
                break;
            } else {
                usleep(time_value);
            }
        }

        if (intrvl == max_interval) {
            SX_LOG_ERR("Clearing counter didn't finish after 10 seconds\n");
            goto out;
        }

        /*Start ACCUFLOW counters clear*/
        cl_spinlock_acquire(&g_issu_counter_mocs[free_idx].event_spinlock);

        ev_id.event_id_fields.id++;
        g_issu_counter_mocs[free_idx].event_id = ev_id.event_id_value;

        sx_status = bulk_counter_issu_mocs_clear(SXD_MOCS_TYPE_MAFBI_E, &ev_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get MOCS transaction in progress status err - %s\n", sx_status_str(sx_status));
            goto out;
        }

        g_issu_counter_mocs[free_idx].done = FALSE;
        cl_spinlock_release(&g_issu_counter_mocs[free_idx].event_spinlock);

        sx_status = afcm_counter_clear_all();
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to clear ACCUFLOW counters from kernel err - %s\n", sx_status_str(sx_status));
            goto out;
        }
    }
    /*waiting until the all MOCS transactions are done*/
    for (intrvl = 0; intrvl < max_interval; ++intrvl) {
        if (g_issu_counter_mocs[0].done && g_issu_counter_mocs[1].done) {
            break;
        } else {
            usleep(time_value);
        }
    }

    if (intrvl == max_interval) {
        SX_LOG_ERR("MOCS transactions didn't finish after 10 seconds\n");
        goto out;
    }

out:
    g_issu_mocs_in_session = FALSE;
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __issu_counter_clear_all()
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR_ARRAY(g_issu_counter_mocs, 2, issu_mocs_data_t);

    sx_status = __issu_mocs_counter_clear();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("issu_mocs_counter_clear failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = host_ifc_accuflow_counter_clear();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("host_ifc_accuflow_counter_clear failed (%s)\n", sx_status_str(sx_status));
        goto out;
    }

out:

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t issu_handle_mocs_done(uint64_t event_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < 2; ++i) {
        if (g_issu_counter_mocs[i].event_id == event_id) {
            cl_spinlock_acquire(&g_issu_counter_mocs[i].event_spinlock);
            g_issu_counter_mocs[i].done = TRUE;
            cl_spinlock_release(&g_issu_counter_mocs[i].event_spinlock);
            goto out;
        }
    }

    sx_status = SX_STATUS_ENTRY_NOT_FOUND;
    SX_LOG_ERR("Couldn't find the event id 0x%" PRIx64 "err %s", event_id, sx_status_str(sx_status));

out:

    SX_LOG_EXIT();
    return sx_status;
}
boolean_t issu_mocs_session_status_check()
{
    return g_issu_mocs_in_session;
}

sx_status_t issu_infiniband_set(sx_api_profile_t* profile)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    switch (profile->chip_type) {
    case SXD_CHIP_TYPE_QUANTUM3:
        g_infiniband_issu = TRUE;
        break;

    case SXD_CHIP_TYPE_QUANTUM:
    case SXD_CHIP_TYPE_QUANTUM2:
        SX_LOG_ERR("IB ISSU is only supported on QTM3!");
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        break;

    default:
        break;
    }
    return sx_status;
}
