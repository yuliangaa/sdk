/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_qpool.h>
#include <complib/cl_dbg.h>
#include <complib/cl_qmap.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <utils/utils.h>

#include "bfd_db.h"

#undef  __MODULE__
#define __MODULE__ BFD

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cl_qmap_t  session_qmap;
static cl_qpool_t session_qpool;
static boolean_t  g_initialized = FALSE;
struct pool_context {
    uint32_t index;
};


/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t bfd_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return status;
}

cl_status_t __bfd_db_session_constructor(void *const p_object, void *context, cl_pool_item_t ** const pp_pool_item)
{
    struct pool_context   *pool_context = (struct pool_context*)context;
    bfd_session_db_item_t *session = (bfd_session_db_item_t*)p_object;

    /* UNUSED_PARAM(context); */

    session->session_id = pool_context->index++;
    *pp_pool_item = &(session->pool_item);

    return CL_SUCCESS;
}

sx_status_t bfd_db_init(const uint32_t session_max_count)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    cl_status_t         cl_rc = CL_SUCCESS;
    struct pool_context context;

    SX_LOG_ENTER();
    SX_LOG_DBG("BFD DB Init\n");

    if (TRUE == g_initialized) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("BFD DB is already initialized\n");
        goto out;
    }

    if (session_max_count > rm_resource_global_default.bfd_session_num_max) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("BFD DB can't allocate more sessions (%d) than supported(%d)\n",
                   session_max_count,
                   rm_resource_global_default.bfd_session_num_max);
        goto out;
    }
    memset(&context, 0, sizeof(context));
    cl_rc = CL_QPOOL_INIT(&session_qpool,
                          session_max_count,
                          session_max_count,
                          session_max_count,
                          sizeof(bfd_session_db_item_t),
                          __bfd_db_session_constructor,
                          NULL, &context);

    if (cl_rc != CL_SUCCESS) {
        SX_LOG_ERR("BFD session pool init failure - %s.\n", CL_STATUS_MSG(cl_rc));
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cl_qmap_init(&session_qmap);

    g_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t bfd_db_deinit()
{
    cl_map_item_t         *map_item = NULL;
    const cl_map_item_t   *map_end = NULL;
    bfd_session_db_item_t *session_item = NULL;
    sx_status_t            rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_initialized == FALSE) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("BFD session DB is not initialized (%s).\n", SX_STATUS_MSG(rc));
        goto out;
    }

    map_item = cl_qmap_head(&session_qmap);
    map_end = cl_qmap_end(&session_qmap);

    while (map_item != map_end) {
        session_item = PARENT_STRUCT(map_item, bfd_session_db_item_t, map_item);
        map_item = cl_qmap_next(map_item);

        cl_qmap_remove_item(&session_qmap, &session_item->map_item);
        cl_qpool_put(&session_qpool, &session_item->pool_item);
    }

    CL_QPOOL_DESTROY(&session_qpool);

    g_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t bfd_db_session_create(const sx_bfd_session_db_attrib_t *session_attr, sx_bfd_session_id_t *session_id_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    cl_pool_item_t        *pool_item = NULL;
    bfd_session_db_item_t *session_item = NULL;

    SX_LOG_ENTER();

    pool_item = cl_qpool_get(&session_qpool);
    if (pool_item == NULL) {
        SX_LOG_ERR("Could not find free BFD session in DB.\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    session_item = PARENT_STRUCT(pool_item, bfd_session_db_item_t, pool_item);
    SX_MEM_CPY_P(&session_item->session_atrrib, session_attr);
    *session_id_p = session_item->session_id;

    cl_qmap_insert(&session_qmap, session_item->session_id, &session_item->map_item);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t bfd_db_session_destroy(const sx_bfd_session_id_t session_id)
{
    bfd_session_db_item_t *session_item = NULL;
    cl_map_item_t         *map_item = NULL;
    const cl_map_item_t   *map_end = NULL;
    sx_status_t            rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    map_item = cl_qmap_get(&session_qmap, session_id);
    map_end = cl_qmap_end(&session_qmap);

    if (map_item == map_end) {
        SX_LOG_ERR("Could not find BFD session (%" PRIu32 ") in DB.\n", session_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    session_item = PARENT_STRUCT(map_item, bfd_session_db_item_t, map_item);
    cl_qmap_remove_item(&session_qmap, &session_item->map_item);
    cl_qpool_put(&session_qpool, &session_item->pool_item);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t bfd_db_session_attrib_set(const sx_bfd_session_id_t         session_id,
                                      const sx_bfd_session_db_attrib_t *session_attr)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    cl_map_item_t         *map_item = NULL;
    const cl_map_item_t   *map_end = NULL;
    bfd_session_db_item_t *session_item = NULL;

    SX_LOG_ENTER();

    map_item = cl_qmap_get(&session_qmap, session_id);
    map_end = cl_qmap_end(&session_qmap);

    if (map_item == map_end) {
        SX_LOG_ERR("Could not find BFD session ID (%" PRIu32 ") in DB.\n", session_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    session_item = PARENT_STRUCT(map_item, bfd_session_db_item_t, map_item);
    SX_MEM_CPY_P(&session_item->session_atrrib, session_attr);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t bfd_db_session_attrib_get(const sx_bfd_session_id_t session_id, sx_bfd_session_db_attrib_t *session_attr)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    cl_map_item_t         *map_item = NULL;
    const cl_map_item_t   *map_end = NULL;
    bfd_session_db_item_t *session_item = NULL;

    SX_LOG_ENTER();

    map_item = cl_qmap_get(&session_qmap, session_id);
    map_end = cl_qmap_end(&session_qmap);

    if (map_item == map_end) {
        SX_LOG_ERR("Could not find BFD session ID (%" PRIu32 ") in DB.\n", session_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    session_item = PARENT_STRUCT(map_item, bfd_session_db_item_t, map_item);
    SX_MEM_CPY_P(session_attr, &session_item->session_atrrib);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t bfd_db_iter_get(const sx_access_cmd_t             access_cmd,
                            const sx_bfd_session_id_t         session_id_key,
                            const sx_bfd_session_id_filter_t *session_id_filter_p,
                            sx_bfd_session_id_t              *session_id_list_p,
                            uint32_t                         *session_id_cnt_p)
{
    sx_status_t            sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t         *start_map_item_p = NULL;
    cl_map_item_t         *map_item_p = NULL;
    const cl_map_item_t   *map_end_p = NULL;
    bfd_session_db_item_t *session_item = NULL;
    uint32_t               ii = 0;
    uint32_t               data_count = 0;

    UNUSED_PARAM(session_id_filter_p);

    SX_LOG_ENTER();

    if (g_initialized == FALSE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("BFD DB is not initialized (%s).\n", SX_STATUS_MSG(sx_status));
        goto out;
    }

    data_count = *session_id_cnt_p;

    switch (access_cmd) {
    case SX_ACCESS_CMD_GETNEXT:
        start_map_item_p = cl_qmap_get_next(&session_qmap, session_id_key);
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        start_map_item_p = cl_qmap_head(&session_qmap);
        break;

    case SX_ACCESS_CMD_GET:
        if (*session_id_cnt_p == 0) {
            *session_id_cnt_p = cl_qmap_count(&session_qmap);
        } else {
            if (cl_qmap_contains(&session_qmap, session_id_key)) {
                session_id_list_p[0] = session_id_key;
                *session_id_cnt_p = 1;
            } else {
                *session_id_cnt_p = 0;
            }
        }
        goto out;

    default:
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is unsupported, err: %s.\n",
                   access_cmd, SX_ACCESS_CMD_STR(access_cmd), SX_STATUS_MSG(sx_status));
        goto out;
    }

    if (data_count && start_map_item_p) {
        ii = 0;
        map_item_p = start_map_item_p;
        map_end_p = cl_qmap_end(&session_qmap);
        while (map_item_p != map_end_p) {
            session_item = PARENT_STRUCT(map_item_p, bfd_session_db_item_t, map_item);
            session_id_list_p[ii] = session_item->session_id;
            map_item_p = cl_qmap_next(map_item_p);
            if (++ii >= data_count) {
                break;
            }
        }
        *session_id_cnt_p = ii;
    } else {
        *session_id_cnt_p = 0;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __bfd_session_db_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    cl_map_item_t                             *map_item = NULL;
    const cl_map_item_t                       *map_end = NULL;
    bfd_session_db_item_t                     *session_item = NULL;
    sx_bfd_session_id_t                        session_id = 0;
    char                                       session_type[17], opaque_data[11];
    char                                       session_traffic_class[17], encap_type[19];
    char /*src_ip_addr[20], dst_ip_addr[20],*/ src_port[20], dst_port[20], ttl[20], dscp[20];
    uint32_t                                   src_ip_addr, dst_ip_addr;
    uint32_t                                   interval = 0;
    dbg_utils_table_columns_t                  tx_sessions_attributes_clmns[] = {
        { "ID",            4,  PARAM_UINT32_E, &session_id},
        { "Type",          16, PARAM_STRING_E, &session_type},
        { "Interval",      10,  PARAM_UINT32_E, &interval},
        { "Traffic-Class", 13, PARAM_STRING_E, session_traffic_class},
        { "Encap-type",    18,  PARAM_STRING_E, encap_type},
        { "Src-ip-addr",   18, PARAM_IPV4_E, &src_ip_addr},
        { "Dst-ip-addr",   18,  PARAM_IPV4_E, &dst_ip_addr},
        { "Src-port",      13, PARAM_STRING_E, src_port},
        { "Dst-port",      13, PARAM_STRING_E, dst_port},
        { "TTL",           8,  PARAM_STRING_E, ttl},
        { "DSCP",          8,  PARAM_STRING_E, dscp},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t                  rx_sessions_attributes_clmns[] = {
        { "ID",            4,  PARAM_UINT32_E, &session_id},
        { "Type",          16, PARAM_STRING_E, &session_type},
        { "Interval",      10,  PARAM_UINT32_E, &interval},
        { "Opaque-data",   13, PARAM_STRING_E, &opaque_data},
        {NULL, 0, 0, NULL}
    };
    FILE                                      *stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "BFD TX Sessions");
    dbg_utils_pprinter_table_headline_print(stream, tx_sessions_attributes_clmns);

    map_item = cl_qmap_head(&session_qmap);
    map_end = cl_qmap_end(&session_qmap);

    while (map_item != map_end) {
        session_item = PARENT_STRUCT(map_item, bfd_session_db_item_t, map_item);
        session_id = session_item->session_id;

        if (session_item->session_atrrib.session_data.type == SX_BFD_ASYNC_ACTIVE_TX) {
            tx_sessions_attributes_clmns[1].data = SX_BFD_SESSION_TYPE_STR(
                session_item->session_atrrib.session_data.type);

            snprintf(session_type, sizeof(session_type), "%s", "Async active TX");
            snprintf(session_traffic_class,
                     sizeof(session_traffic_class),
                     "%u",
                     session_item->session_atrrib.session_data.data.tx_data.traffic_class);

            src_ip_addr =
                session_item->session_atrrib.session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.src_ip_addr.
                addr.ipv4.s_addr;
            dst_ip_addr =
                session_item->session_atrrib.session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.dest_ip_addr
                .addr.ipv4.s_addr;

            snprintf(src_port,
                     sizeof(src_port),
                     "%u",
                     session_item->session_atrrib.session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.src_udp_port);
            snprintf(dst_port,
                     sizeof(dst_port),
                     "%u",
                     session_item->session_atrrib.session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.dest_udp_port);

            snprintf(ttl,
                     sizeof(ttl),
                     "%u",
                     session_item->session_atrrib.session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.ttl);
            snprintf(dscp,
                     sizeof(dscp),
                     "%u",
                     session_item->session_atrrib.session_data.data.tx_data.packet_encap.encap_data.udp_over_ip.dscp);

            interval = session_item->session_atrrib.session_data.data.tx_data.interval / 1000;

            switch (session_item->session_atrrib.session_data.data.tx_data.packet_encap.encap_type) {
            case SX_BFD_UDP_OVER_IP:
                snprintf(encap_type, sizeof(encap_type), "BFD_UDP_OVER_IP");
                break;

            default:
                snprintf(encap_type, sizeof(encap_type), "UNKNOWN");
            }


            dbg_utils_pprinter_table_data_line_print(stream, tx_sessions_attributes_clmns);
        }

        map_item = cl_qmap_next(&session_item->map_item);
    }

    dbg_utils_pprinter_general_header_print(stream, "BFD RX Sessions");
    dbg_utils_pprinter_table_headline_print(stream, rx_sessions_attributes_clmns);

    map_item = cl_qmap_head(&session_qmap);
    map_end = cl_qmap_end(&session_qmap);

    while (map_item != map_end) {
        session_item = PARENT_STRUCT(map_item, bfd_session_db_item_t, map_item);
        session_id = session_item->session_id;

        if (session_item->session_atrrib.session_data.type == SX_BFD_ASYNC_ACTIVE_RX) {
            rx_sessions_attributes_clmns[1].data = SX_BFD_SESSION_TYPE_STR(
                session_item->session_atrrib.session_data.type);

            snprintf(session_type, sizeof(session_type), "%s", "Async active RX");
            interval = session_item->session_atrrib.session_data.data.rx_data.interval / 1000;
            snprintf(opaque_data,
                     sizeof(opaque_data),
                     "%" PRIu64 "",
                     (uint64_t)session_item->session_atrrib.session_data.data.rx_data.opaque_data);
            dbg_utils_pprinter_table_data_line_print(stream, rx_sessions_attributes_clmns);
        }

        map_item = cl_qmap_next(&session_item->map_item);
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t bfd_db_dbg_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    dbg_utils_pprinter_secondary_header_print(dbg_dump_params_p->stream, "BFD Module");
    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "Module initialized",  &g_initialized, PARAM_BOOL_E);
    if (g_initialized == FALSE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    sx_status = __bfd_session_db_dump(dbg_dump_params_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__bfd_session_db_dump failed. Error: %s.\n",
                   SX_STATUS_MSG(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
