/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __BFD_DB_H__
#define __BFD_DB_H__

#include <sx/sdk/sx_types.h>
#include "sx/utils/sdk_refcount.h"


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct sx_bfd_session_db_attrib {
    sx_bfd_session_t session_data;
    sx_bfd_peer_t    peer;
} sx_bfd_session_db_attrib_t;

typedef struct bfd_session_db_item {
    cl_pool_item_t             pool_item;
    cl_map_item_t              map_item;
    sx_bfd_session_id_t        session_id;
    sx_bfd_session_db_attrib_t session_atrrib;
} bfd_session_db_item_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t bfd_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t bfd_db_init(const uint32_t session_max_count);

sx_status_t bfd_db_deinit(void);

sx_status_t bfd_db_session_create(const sx_bfd_session_db_attrib_t *session_attr,
                                  sx_bfd_session_id_t              *session_id_p);

sx_status_t bfd_db_session_destroy(const sx_bfd_session_id_t session_id);

sx_status_t bfd_db_session_attrib_set(const sx_bfd_session_id_t         session_id,
                                      const sx_bfd_session_db_attrib_t *session_attr);

sx_status_t bfd_db_session_attrib_get(const sx_bfd_session_id_t   session_id,
                                      sx_bfd_session_db_attrib_t *session_attr);

sx_status_t bfd_db_iter_get(const sx_access_cmd_t             access_cmd,
                            const sx_bfd_session_id_t         session_id_key,
                            const sx_bfd_session_id_filter_t *session_id_filter_p,
                            sx_bfd_session_id_t              *session_id_list_p,
                            uint32_t                         *session_id_cnt_p);


sx_status_t bfd_db_dbg_dump(dbg_dump_params_t *dbg_dump_params_p);

#endif    /* __BFD_DB_H__ */
