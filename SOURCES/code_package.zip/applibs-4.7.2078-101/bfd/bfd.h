/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __BFD_H_INCL__
#define __BFD_H_INCL__

#include <sx_api/sx_api_internal.h>


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t bfd_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t bfd_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level);

sx_status_t bfd_init(sx_bfd_init_params_t *init_params);
sx_status_t bfd_deinit(void);

sx_status_t bfd_offload_counter_get(sx_bfd_offload_stats_t *params);

sx_status_t bfd_offload_set(sx_api_bfd_offload_set_params_t *params);

sx_status_t bfd_session_iter_get(const sx_access_cmd_t             access_cmd,
                                 const sx_bfd_session_id_t         session_id_key,
                                 const sx_bfd_session_id_filter_t *session_filter_p,
                                 sx_bfd_session_id_t              *session_id_list_p,
                                 uint32_t                         *session_id_cnt_p);

void bfd_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

#endif /* ifndef __BFD_H_INCL__ */
