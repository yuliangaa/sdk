/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/utils/psort.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <sx/sdk/sx_status_convertor.h>

#include "hwd_decap_table.h"
#include "hwd_decap_table_db.h"
#include "acl/flex_acl.h"
#include "acl/flex_acl_db.h"
#include "acl/flex_acl_binding.h"
#include "acl/flex_acl_tcam_manager.h"
#include "resource_manager/resource_manager_sdk_table.h"
#include "ethl3/router_common.h"
#include "ethl3/hwi/rif/rif_impl.h"
#include "ethl3/hwi/sdk_router_vrid/sdk_router_vrid_impl.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/sx_ip_utils.h"
#include "flex_parser/hwi/flex_parser_impl.h"
#include "ethl3/common/router_utils.h"

#undef  __MODULE__
#define __MODULE__ TUNNEL

/************************************************
 *  Global variables
 ***********************************************/
extern rm_sdk_table_resource_t sdk_table_resources_g[RM_SDK_TABLE_TYPE_NUMBER];

/************************************************
 *  Local variables
 ***********************************************/

#define PSORT_IPV4_MAX_PRIO             SX_TUNNEL_IPINIP_DECAP_RULE_PRIO_MAX - 1
#define PSORT_IPV6_MAX_PRIO             PSORT_IPV4_MAX_PRIO
#define PSORT_MIN_PRIO                  0
#define PSORT_PRIO_REG_DELTA_SIZE       4
#define PSORT_SHRINK_THRESHOLD_PERCENT  65
#define PSORT_ENLARGE_THRESHOLD_PERCENT 90

#define MAX_ACL_KEY_NUMBER 6

/* there is no real limitation behind this define */
#define MAX_ACL_ACTION_NUMBER 5

static boolean_t g_is_initialized = FALSE;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t g_rm_check_in_progress = FALSE;

static sx_ip_version_t        psort_context_ipv4 = SX_IP_VERSION_IPV4;
static sx_ip_version_t        psort_context_ipv6 = SX_IP_VERSION_IPV6;
static sx_router_interface_t *g_rif_list_p = NULL;

#define IP_VERSION_TO_ACL_CLIENT(ip_version) \
    system_acl_tunnel_client_id_get(ip_version)

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __hwd_decap_table_rm_entries_check(sx_ip_version_t protocol,
                                                      sx_access_cmd_t access_cmd,
                                                      uint32_t        num_of_entries);
static sx_status_t __hwd_decap_table_rm_entries_update(sx_ip_version_t protocol,
                                                       sx_access_cmd_t access_cmd,
                                                       uint32_t        num_of_entries);
static sx_status_t __hwd_decap_rm_entries_set(sx_ip_version_t protocol,
                                              sx_access_cmd_t access_cmd,
                                              uint32_t        num_of_entries,
                                              boolean_t       is_system);

sx_status_t __hwd_decap_rm_deinit(sx_ip_version_t ip_version, boolean_t force_deinit);

static sx_ip_version_t __hwd_decap_table_tunnel_type_to_ip_version(sx_tunnel_type_e type);


/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t hwd_decap_table_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    hwd_decap_table_db_log_verbosity_level_set(verbosity_level);

    return err;
}

static void __decap_table_dump_key(const sx_tunnel_decap_entry_key_t *key)
{
    struct in_addr ip;
    char           dip_addr[20];
    char           dip_mask[20];
    char           sip_addr[20];
    char           sip_mask[20];

    if ((key->underlay_dip.version == SX_IP_VERSION_IPV4) && (key->underlay_sip.version == SX_IP_VERSION_IPV4)) {
        ip.s_addr = htonl(*(uint32_t*)(&key->underlay_dip.addr.ipv4));
        if (!inet_ntop(AF_INET, &ip, dip_addr, 20)) {
            strncpy(dip_addr, "invalid", sizeof(dip_addr) - 1);
            dip_addr[sizeof(dip_addr) - 1] = '\0';
        }

        ip.s_addr = htonl(*(uint32_t*)(&key->underlay_dip_mask.addr.ipv4));
        if (!inet_ntop(AF_INET, &ip, dip_mask, 20)) {
            strncpy(dip_mask, "invalid", sizeof(dip_mask) - 1);
            dip_mask[sizeof(dip_mask) - 1] = '\0';
        }

        ip.s_addr = htonl(*(uint32_t*)(&key->underlay_sip.addr.ipv4));
        if (!inet_ntop(AF_INET, &ip, sip_addr, 20)) {
            strncpy(sip_addr, "invalid", sizeof(sip_addr) - 1);
            sip_addr[sizeof(sip_addr) - 1] = '\0';
        }

        ip.s_addr = htonl(*(uint32_t*)(&key->underlay_sip_mask.addr.ipv4));
        if (!inet_ntop(AF_INET, &ip, sip_mask, 20)) {
            strncpy(sip_mask, "invalid", sizeof(sip_mask) - 1);
            sip_mask[sizeof(sip_mask) - 1] = '\0';
        }

        SX_LOG_DBG("decap entry key: tunnel type [%u], field type [%u], vr id [%u],"
                   "dip version [%s], addr [%s], mask [%s], sip version [%s], addr [%s], mask [%s], priority [%d]\n",
                   key->tunnel_type, key->type, key->underlay_vrid,
                   sx_ip_version_str(key->underlay_dip.version), dip_addr, dip_mask,
                   sx_ip_version_str(key->underlay_sip.version), sip_addr, sip_mask, key->priority);
    }
}

static void __decap_table_dump_data(const sx_tunnel_decap_entry_data_t *data)
{
    sx_flex_acl_flex_action_set_user_token_t user_token;

    SX_MEM_CLR(user_token);

    if (data->set_user_token == TRUE) {
        user_token.user_token = data->user_token.user_token;
        user_token.mask = data->user_token.mask;
    }

    SX_LOG_DBG("decap entry data: tunnel id [%u], action [%u], trap prio [%u],"
               "counter id [%u], span session id[%u], user token[%u], user token mask[0x%x]\n",
               data->tunnel_id, data->action, data->trap_attr.prio, data->counter_id, data->span_session_id,
               user_token.user_token, user_token.mask);
}

static sx_status_t __decap_table_verify_key(const sx_tunnel_decap_entry_key_t *key)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    sx_ip_version_t ip_version = __hwd_decap_table_tunnel_type_to_ip_version(key->tunnel_type);

    if (SX_TUNNEL_TYPE_CHECK_RANGE(key->tunnel_type) == FALSE) {
        SX_LOG_ERR("decap key tunnel type [%u] is out of range.\n",
                   key->tunnel_type);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_CHECK_RANGE(key->type) == FALSE) {
        SX_LOG_ERR("decap key field type [%u] is out of range.\n",
                   key->type);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (ip_version != key->underlay_dip.version) {
        SX_LOG(SX_LOG_ERROR, "dip version %s is not supported for [%u] tunnel.\n",
               sx_ip_version_str(key->underlay_dip.version), key->tunnel_type);
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (((key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP) ||
         (key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET)) &&
        (ip_version != key->underlay_sip.version)) {
        SX_LOG(SX_LOG_ERROR, "sip version %s is not supported for [%u] tunnel.\n",
               sx_ip_version_str(key->underlay_sip.version), key->tunnel_type);
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (((key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP) ||
         (key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET)) &&
        ((SX_TUNNEL_TYPE_NVE_VXLAN_IPV6 == key->tunnel_type) ||
         (SX_TUNNEL_TYPE_NVE_NVGRE_IPV6 == key->tunnel_type) ||
         (SX_TUNNEL_TYPE_L2_FLEX_IPV6 == key->tunnel_type))) {
        SX_LOG(SX_LOG_ERROR, "Key type [%u] is not supported for NVE IPv6 tunnel.\n", key->type);
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __decap_table_verify_data(const sx_tunnel_decap_entry_data_t *data)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (SX_ROUTER_ACTION_CHECK_RANGE(data->action) == FALSE) {
        SX_LOG_ERR("decap data action (%u) is out of range.\n",
                   data->action);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (SX_TRAP_PRIORITY_CHECK_RANGE(data->trap_attr.prio) == FALSE) {
        SX_LOG_ERR("decap data trap priority (%u) is out of range.\n",
                   data->trap_attr.prio);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (data->set_user_token == TRUE) {
        if (data->user_token.mask & ACL_SYSTEM_TOKEN_MASK) {
            SX_LOG_ERR("User token mask is invalid, Max Mask value :%x\n", ACL_USER_TOKEN_MASK);
            sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (data->user_token.user_token & ACL_SYSTEM_TOKEN_MASK) {
            SX_LOG_ERR("User token value is invalid, Max value :%x\n", ACL_USER_TOKEN_MASK);
            sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
    }

out:
    return sx_status;
}

static sx_status_t __decap_table_verify_entry(const sx_tunnel_decap_entry_key_t  *key,
                                              const sx_tunnel_decap_entry_data_t *data)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    /* verify the value of key */
    sx_status = __decap_table_verify_key(key);
    if (SX_STATUS_SUCCESS != sx_status) {
        goto out;
    }

    /* verify the value of data */
    sx_status = __decap_table_verify_data(data);
    if (SX_STATUS_SUCCESS != sx_status) {
        goto out;
    }

    /* Check that the key and data tunnel types are compatible */
    if (SX_TUNNEL_TYPE_ID_CHECK(data->tunnel_id, key->tunnel_type) == FALSE) {
        /* We allow an NVE tunnel key to be paired with a FLEX tunnel as long as the IP version match */
        if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, key->tunnel_type, SX_TUNNEL_TYPE_NVE_MAX) &&
            SX_TUNNEL_TYPE_L2_FLEX_CHECK(data->tunnel_id)) {
            if ((SX_TUNNEL_TYPE_ID_GET(data->tunnel_id) == SX_TUNNEL_TYPE_L2_FLEX_IPV6) &&
                !(SX_TUNNEL_TYPE_IP_CONSISTENCY_CHECK(key->tunnel_type, SX_IP_VERSION_IPV6))) {
                SX_LOG_ERR("decap tunnel id [%u] doesn't match tunnel type [%s] IP version.\n",
                           data->tunnel_id, sx_tunnel_type_str(key->tunnel_type));
                sx_status = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        } else {
            SX_LOG_ERR("decap tunnel id [%u] doesn't match tunnel type [%s].\n",
                       data->tunnel_id, sx_tunnel_type_str(key->tunnel_type));
            sx_status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    return sx_status;
}

static sx_status_t __decap_table_init_region(sx_ip_version_t ip_version)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_acl_region_id_t region_id = 0;
    uint32_t           client = 0;

    SX_LOG_DBG("system acl init region client [%s]\n", sx_ip_version_str(ip_version));

    client = IP_VERSION_TO_ACL_CLIENT(ip_version);
    sx_status = system_acl_client_init(client, 0, &region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to init system acl client [%s]\n", sx_ip_version_str(ip_version));
        goto out;
    }
    decap_table_db_set_region_id(ip_version, region_id);

out:
    return sx_status;
}

static sx_status_t __decap_table_deinit_region(sx_ip_version_t ip_version)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    client = 0;

    SX_LOG_DBG("system acl deinit region client [%s]\n", sx_ip_version_str(ip_version));

    client = IP_VERSION_TO_ACL_CLIENT(ip_version);
    sx_status = system_acl_client_deinit(client, 0);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to deinit system acl client [%s]\n", sx_ip_version_str(ip_version));
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __decap_table_resize_region(sx_ip_version_t ip_version,
                                               uint32_t        new_size,
                                               uint32_t        delta,
                                               uint32_t       *updated_size)
{
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    sx_status_t                    rb_status = SX_STATUS_SUCCESS;
    sx_api_acl_region_set_params_t params;
    boolean_t                      resume_rm_check = FALSE;
    uint32_t                       client = SYSTEM_ACL_CLIENT_ID_INVALID_E;

    SX_LOG_ENTER();
    SX_LOG_DBG("resize region [%s] to %u\n", sx_ip_version_str(ip_version), new_size);

    SX_MEM_CLR(params);

    params.cmd = SX_ACCESS_CMD_EDIT;
    decap_table_db_get_region_id(ip_version, &(params.region_id));
    if (params.region_id == ACL_INVALID_ID) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG(SX_LOG_ERROR, "region [%s] id is invalid\n", sx_ip_version_str(ip_version));
        goto out;
    }

    params.region_size = new_size;
    params.cmd = SX_ACCESS_CMD_EDIT;

    client = IP_VERSION_TO_ACL_CLIENT(ip_version);
    sx_status = flex_acl_region_set_internal(&params, client);
    if (sx_status != SX_STATUS_SUCCESS) {
        if (sx_status == SX_STATUS_NO_RESOURCES) {
            /* First, cancel any ongoing checks in RM, otherwise we won't be
             * able to free the unused memory.
             */
            if (g_rm_check_in_progress) {
                sx_status = __hwd_decap_table_rm_entries_update(ip_version, SX_ACCESS_CMD_ADD, 0);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to update 0 entries in RM, err = [%s]\n",
                               sx_status_str(sx_status));
                    goto out;
                }
                g_rm_check_in_progress = FALSE;
                resume_rm_check = TRUE;
            }

            sx_status = flex_acl_tcam_manager_free_unused_entries(FLEX_ACL_TCAM_MANAGER_INVALID_HANDLE);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to free unused entries, err = [%s]\n",
                           sx_status_str(sx_status));
                goto out;
            }

            if (resume_rm_check) {
                sx_status = __hwd_decap_table_rm_entries_check(ip_version,
                                                               SX_ACCESS_CMD_ADD,
                                                               delta);

                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to check %u entries in RM, err = [%s]\n",
                               delta, sx_status_str(sx_status));
                    goto out;
                }
                g_rm_check_in_progress = TRUE;
            }

            client = IP_VERSION_TO_ACL_CLIENT(ip_version);
            sx_status = flex_acl_region_set_internal(&params, client);
            if (SX_CHECK_FAIL(sx_status)) {
                if (sx_status == SX_STATUS_NO_RESOURCES) {
                    SX_LOG_INF("Failed to resize system acl region (%u) to size (%u), err = [%s]\n",
                               params.region_id, params.region_size,
                               sx_status_str(sx_status));
                } else {
                    SX_LOG_ERR("Failed to resize system acl region (%u) to size (%u), err = [%s]\n",
                               params.region_id, params.region_size,
                               sx_status_str(sx_status));
                }
                goto out;
            }
        } else {
            SX_LOG_ERR("Failed to resize system acl region (%u) to size (%u), err = [%s]\n",
                       params.region_id, params.region_size,
                       sx_status_str(sx_status));
            goto out;
        }
    }

    sx_status = system_acl_region_get_hw_size(params.region_id, updated_size);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get region %u params, err = [%s]\n",
                   params.region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    *updated_size = new_size;
    /* Update DB with actual new size */
    decap_table_db_set_region_size(ip_version, *updated_size);

    SX_LOG_DBG("New decap table region [%s] size set to %u.\n", sx_ip_version_str(ip_version), *updated_size);

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (g_rm_check_in_progress) {
            rb_status = __hwd_decap_table_rm_entries_update(ip_version, SX_ACCESS_CMD_ADD, 0);
            if (rb_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update 0 entries in RM, err = [%s]\n",
                           sx_status_str(rb_status));
            }
            g_rm_check_in_progress = FALSE;
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __decap_table_set_acl_rule(sx_access_cmd_t          cmd,
                                              sx_flex_acl_flex_rule_t* rule,
                                              sx_acl_rule_offset_t     index,
                                              sx_ip_version_t          ip_version)
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS;
    sx_api_flex_acl_rules_set_params_t params;

    SX_LOG_DBG("set acl rule, cmd (%u), index (%u)\n", cmd, index);

    if ((cmd != SX_ACCESS_CMD_SET) &&
        (cmd != SX_ACCESS_CMD_DELETE)) {
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG(SX_LOG_ERROR, "Unsupported cmd to set [%s] acl rule\n", sx_ip_version_str(ip_version));
        goto out;
    }

    if ((rule == NULL) && (cmd == SX_ACCESS_CMD_SET)) {
        sx_status = SX_STATUS_PARAM_NULL;
        SX_LOG(SX_LOG_ERROR, "Set [%s] acl rule with NULL rule\n", sx_ip_version_str(ip_version));
        goto out;
    }

    SX_MEM_CLR(params);

    params.cmd = cmd;
    decap_table_db_get_region_id(ip_version, &params.region_id);
    params.rules_count = 1;
    if (rule) {
        params.rules = rule;
    }
    params.offsets_list_p = &index;

    sx_status = flex_acl_rules_set_internal(&params);

    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to set acl rules on [%s] region(%u)\n",
               sx_ip_version_str(ip_version), params.region_id);
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __decap_table_move_acl_rules(sx_ip_version_t ip_version,
                                                uint32_t        old_index,
                                                uint32_t        new_index,
                                                uint32_t        block_size)
{
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    sx_api_acl_block_move_params_t params;

    SX_LOG_DBG("move [%s] acl rule from (%u) to (%u) with size (%u)\n",
               sx_ip_version_str(ip_version), old_index, new_index, block_size);

    params.block_size = block_size;
    params.block_start = old_index;
    params.new_block_start = new_index;
    decap_table_db_get_region_id(ip_version, &(params.region_id));
    sx_status = flex_acl_rules_move_internal(&params, TRUE);

    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to move [%s] acl rules from (%u) to (%u) with size(%u) .\n",
                   sx_ip_version_str(ip_version), old_index, new_index, block_size);
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __decap_table_resize_alloc(sx_ip_version_t ip_version,
                                              sx_access_cmd_t cmd,
                                              uint32_t        old_size,
                                              uint32_t        delta)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    sx_status_t rb_sx_status = SX_STATUS_SUCCESS;
    uint32_t    new_size = 0, updated_size = 0;

    SX_LOG_ENTER();
    SX_LOG_DBG("Resize TCAM table for [%s] decap rules cmd [%u], old_size[%u], delta [%u].\n",
               sx_ip_version_str(ip_version), cmd, old_size, delta);

    if (cmd == SX_ACCESS_CMD_ADD) {
        new_size = old_size + delta;
    } else {
        new_size = old_size - delta;
    }

    /* Allocate RM resources */
    sx_status = __hwd_decap_table_rm_entries_check(ip_version,
                                                   cmd, delta);
    if (SX_CHECK_FAIL(sx_status)) {
        if ((sx_status == SX_STATUS_NO_RESOURCES) && (cmd == SX_ACCESS_CMD_ADD)) {
            SX_LOG_INF("Failed to add TCAM resources for decap table, err = [%s]\n",
                       sx_status_str(sx_status));
        } else {
            SX_LOG_ERR("Can't %s %u entries %s TCAM table, err = [%s]\n",
                       sx_access_cmd_str(cmd), delta,
                       cmd == SX_ACCESS_CMD_ADD ? "to" : "from",
                       sx_status_str(sx_status));
        }
        goto out;
    }
    g_rm_check_in_progress = TRUE;

    sx_status = __decap_table_resize_region(ip_version, new_size, delta, &updated_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set [%s] region with size (%u).\n", sx_ip_version_str(ip_version), new_size);
        goto out;
    }

    sx_status = __hwd_decap_table_rm_entries_update(ip_version,  cmd, delta);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update resource for %u entries, err = [%s]\n",
                   delta, sx_status_str(sx_status));
        goto out;
    }
    g_rm_check_in_progress = FALSE;

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (g_rm_check_in_progress) {
            rb_sx_status = __hwd_decap_table_rm_entries_update(ip_version, cmd, 0);
            if (SX_CHECK_FAIL(rb_sx_status)) {
                SX_LOG_ERR("Failed to update 0 entries in table , err = [%s]\n",
                           sx_status_str(rb_sx_status));
            }
            g_rm_check_in_progress = FALSE;
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

static sx_utils_status_t __psort_callback(psort_notification_type_e notif_type,
                                          void                     *shift_count,
                                          void                     *cookie)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t util_status = SX_UTILS_STATUS_SUCCESS;
    sx_access_cmd_t   cmd = SX_ACCESS_CMD_NONE;
    uint32_t          delta = 0;
    sx_ip_version_t   ip_version = SX_IP_VERSION_NONE;
    psort_handle_t    psort_handle = 0;
    uint32_t          table_size = 0;
    uint32_t          new_table_size = 0;
    uint32_t          table_free = 0;
    uint32_t          table_used = 0;

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(cookie, "cookie"))) {
        goto out;
    }

    ip_version = *((sx_ip_version_t*)cookie);
    decap_table_db_get_psort_handle(ip_version, &psort_handle);

    switch (notif_type) {
    case PSORT_TABLE_ALMOST_FULL_E: /*Resize*/
    case PSORT_TABLE_ALMOST_EMPTY_E: /*Shrink*/
        psort_get_table_free_space(psort_handle, &table_free);
        psort_get_table_used_space(psort_handle, &table_used);
        table_size = table_used + table_free;
        if (PSORT_TABLE_ALMOST_FULL_E == notif_type) {
            SX_LOG(SX_LOG_INFO, "PSORT_TABLE_ALMOST_FULL_E: Table resize \n");
            cmd = SX_ACCESS_CMD_ADD;
            delta = SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE;
            new_table_size = table_size + delta;
        } else {
            SX_LOG(SX_LOG_INFO, "PSORT_TABLE_ALMOST_EMPTY_E: Table resize \n");
            cmd = SX_ACCESS_CMD_DELETE;
            delta = SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE;
            new_table_size = table_size - delta;
            if (new_table_size < table_used) {
                SX_LOG(SX_LOG_INFO,
                       "PSORT_TABLE_ALMOST_EMPTY_E: Skip table shrink, can not shrink without data loss \n");
                sx_status = SX_STATUS_SUCCESS;
                goto out;
            }
        }

        if (new_table_size < SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE) {
            new_table_size = SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE;
            delta = table_size - SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE;
            if (delta == 0) {
                SX_LOG(SX_LOG_INFO, "PSORT_TABLE_ALMOST_EMPTY_E: Skip table shrink, already minimum table size \n");
                sx_status = SX_STATUS_SUCCESS;
                goto out;
            }
        }

        util_status = psort_table_resize(psort_handle, new_table_size, FALSE, NULL);
        if (SX_UTILS_CHECK_FAIL(util_status)) {
            sx_status = sx_utils_status_to_sx_status(util_status);
            SX_LOG_ERR("psort table resize failed for [%s] region with size (%u).\n",
                       sx_ip_version_str(ip_version), new_table_size);
            goto out;
        }

        sx_status = __decap_table_resize_alloc(ip_version, cmd, table_size, delta);
        if (SX_CHECK_FAIL(sx_status)) {
            if (SX_STATUS_NO_RESOURCES == sx_status) {
                SX_LOG_INF("Failed to set [%s] region with size (%u).\n",
                           sx_ip_version_str(ip_version), new_table_size);
            } else {
                SX_LOG_ERR("Failed to set [%s] region with size (%u).\n",
                           sx_ip_version_str(ip_version), new_table_size);
            }
            goto out;
        }
        break;

    case PSORT_TABLE_SHIFT_E: /*move entries*/
        ;
        psort_shift_param_t shift_param = *(psort_shift_param_t*)shift_count;
        SX_LOG(SX_LOG_INFO, "old_index=%u, new_index=%u, size=%u\n",
               shift_param.old_index, shift_param.new_index, shift_param.size);
        sx_status = __decap_table_move_acl_rules(ip_version,
                                                 shift_param.old_index,
                                                 shift_param.new_index,
                                                 shift_param.size);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to move [%s] rules from (%u) to (%u) with size(%u) .\n",
                       sx_ip_version_str(ip_version), shift_param.old_index,
                       shift_param.new_index, shift_param.size);
            goto out;
        }
        sx_status = decap_table_db_map_entry_move(ip_version,
                                                  shift_param.old_index,
                                                  shift_param.new_index,
                                                  shift_param.size);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to move index from (%u) to (%u) with size(%u) from index map .\n",
                       shift_param.old_index, shift_param.new_index, shift_param.size);
            goto out;
        }
        break;
    }
out:
    return SX_STATUS_TO_SX_UTILS_STATUS(sx_status);
}

static sx_status_t __decap_table_set_entry_key(const sx_tunnel_decap_entry_key_t *key, sx_flex_acl_flex_rule_t *rule)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    sx_ip_addr_t    mask;
    uint32_t        key_desc_index = 0;
    sx_ip_version_t ip_version = __hwd_decap_table_tunnel_type_to_ip_version(key->tunnel_type);

    SX_MEM_CLR(mask);
    mask.version = ip_version;

    rule->key_desc_list_p = (sx_flex_acl_key_desc_t*)cl_malloc(sizeof(sx_flex_acl_key_desc_t) * MAX_ACL_KEY_NUMBER);
    SX_MEM_CLR_P(rule->key_desc_list_p);
    rule->valid = 1;
    rule->key_desc_list_p[key_desc_index].key_id = FLEX_ACL_KEY_VIRTUAL_ROUTER;
    rule->key_desc_list_p[key_desc_index].key.virtual_router = key->underlay_vrid;
    rule->key_desc_list_p[key_desc_index].mask.virtual_router = TRUE;
    key_desc_index++;

    if (ip_version == SX_IP_VERSION_IPV4) {
        if (SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET == key->type) {
            mask.addr.ipv4 = key->underlay_dip_mask.addr.ipv4;
        } else {
            SX_MEM_SET(mask.addr.ipv4, 0xFFFFFFFF);
        }

        rule->key_desc_list_p[key_desc_index].key_id = FLEX_ACL_KEY_DIP;
        rule->key_desc_list_p[key_desc_index].key.dip = key->underlay_dip;
        /* set mask to all 1 and with the version from underlay destination IP */
        rule->key_desc_list_p[key_desc_index].mask.dip = mask;
        key_desc_index++;

        if ((key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP) ||
            (key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET)) {
            if (SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET == key->type) {
                mask.addr.ipv4 = key->underlay_sip_mask.addr.ipv4;
            } else {
                SX_MEM_SET(mask.addr.ipv4, 0xFFFFFFFF);
            }
            rule->key_desc_list_p[key_desc_index].key_id = FLEX_ACL_KEY_SIP;
            rule->key_desc_list_p[key_desc_index].key.sip = key->underlay_sip;
            /* set mask to all 1 and with the version from underlay source IP */
            rule->key_desc_list_p[key_desc_index].mask.sip = mask;
            key_desc_index++;
        }

        rule->key_desc_list_p[key_desc_index].key.l3_type = SX_ACL_L3_TYPE_IPV4;
        rule->key_desc_list_p[key_desc_index].key_id = FLEX_ACL_KEY_L3_TYPE;
        rule->key_desc_list_p[key_desc_index].mask.l3_type = TRUE;
        key_desc_index++;
    } else {
        if (SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET == key->type) {
            mask.addr.ipv6 = key->underlay_dip_mask.addr.ipv6;
        } else {
            SX_MEM_SET(mask.addr.ipv6, 0xFFFFFFFF);
        }

        rule->key_desc_list_p[key_desc_index].key_id = FLEX_ACL_KEY_DIPV6;
        rule->key_desc_list_p[key_desc_index].key.dipv6 = key->underlay_dip;
        /* set mask to all 1 and with the version from underlay destination IP */
        rule->key_desc_list_p[key_desc_index].mask.dipv6 = mask;
        key_desc_index++;

        if ((key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP) ||
            (key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET)) {
            if (SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET == key->type) {
                mask.addr.ipv6 = key->underlay_sip_mask.addr.ipv6;
            } else {
                SX_MEM_SET(mask.addr.ipv6, 0xFFFFFFFF);
            }
            rule->key_desc_list_p[key_desc_index].key_id = FLEX_ACL_KEY_SIPV6;
            rule->key_desc_list_p[key_desc_index].key.sipv6 = key->underlay_sip;
            /* set mask to all 1 and with the version from underlay source IP */
            rule->key_desc_list_p[key_desc_index].mask.sipv6 = mask;
            key_desc_index++;
        }

        rule->key_desc_list_p[key_desc_index].key.l3_type = SX_ACL_L3_TYPE_IPV6;
        rule->key_desc_list_p[key_desc_index].key_id = FLEX_ACL_KEY_L3_TYPE;
        rule->key_desc_list_p[key_desc_index].mask.l3_type = TRUE;
        key_desc_index++;
    }

    /* Due to HW limitation we don't have a flex tunnel type. We have to rely on fpp key */
    if ((key->tunnel_type == SX_TUNNEL_TYPE_L2_FLEX) || (key->tunnel_type == SX_TUNNEL_TYPE_L2_FLEX_IPV6)) {
        rule->key_desc_list_p[key_desc_index].key_id = FLEX_ACL_KEY_FPP_TOUCHED_START +
                                                       key->tunnel_attributes.l2_flex_decap_attributes.fpp_id.fpp_id;
        rule->key_desc_list_p[key_desc_index].key.fpp_touched = TRUE;
        rule->key_desc_list_p[key_desc_index].mask.fpp_touched = TRUE;
        key_desc_index++;
    } else {
        rule->key_desc_list_p[key_desc_index].key.tunnel_type = key->tunnel_type;
        rule->key_desc_list_p[key_desc_index].key_id = FLEX_ACL_KEY_TUNNEL_TYPE;
        rule->key_desc_list_p[key_desc_index].mask.tunnel_type = TRUE;
        key_desc_index++;

        if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, key->tunnel_type, SX_TUNNEL_TYPE_NVE_MAX)) {
            rule->key_desc_list_p[key_desc_index].key.tunnel_nve_type = key->tunnel_type;
            rule->key_desc_list_p[key_desc_index].key_id = FLEX_ACL_KEY_TUNNEL_NVE_TYPE;
            rule->key_desc_list_p[key_desc_index].mask.tunnel_nve_type = TRUE;
            key_desc_index++;
        }
    }

    rule->key_desc_count = key_desc_index;

    if (rule->key_desc_count > MAX_ACL_KEY_NUMBER) {
        /* Should not happen */
        SX_LOG(SX_LOG_ERROR, "Key number exceed range\n");
        sx_status = SX_STATUS_ERROR;
    }

    return sx_status;
}

static sx_status_t __decap_table_set_entry_data(const sx_tunnel_decap_entry_data_t *data,
                                                sx_acl_id_t                         acl_group_id,
                                                sx_flex_acl_flex_rule_t            *rule)
{
    sx_status_t  sx_status = SX_STATUS_SUCCESS;
    sx_trap_id_t trap_id = SX_TRAP_ID_DECAP_TABLE_0;
    uint32_t     action_index = 0;

    rule->action_list_p = (sx_flex_acl_flex_action_t*)cl_malloc(
        sizeof(sx_flex_acl_flex_action_t) * MAX_ACL_ACTION_NUMBER);
    SX_MEM_CLR_P(rule->action_list_p);
    switch (data->action) {
    case SX_ROUTER_ACTION_DROP:
        rule->action_list_p[action_index].type =
            SX_FLEX_ACL_ACTION_FORWARD;
        rule->action_list_p[action_index].fields.action_forward.action =
            SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD;
        action_index++;
        break;

    case SX_ROUTER_ACTION_TRAP:
        rule->action_list_p[action_index].type =
            SX_FLEX_ACL_ACTION_TRAP;
        rule->action_list_p[action_index].fields.action_trap.action =
            SX_ACL_TRAP_ACTION_TYPE_TRAP;
        switch (data->trap_attr.prio) {
        case SX_TRAP_PRIORITY_BEST_EFFORT:
        case SX_TRAP_PRIORITY_LOW:
        case SX_TRAP_PRIORITY_MED:
            trap_id = SX_TRAP_ID_DECAP_TABLE_0;
            break;

        case SX_TRAP_PRIORITY_HIGH:
        case SX_TRAP_PRIORITY_CRITICAL:
            trap_id = SX_TRAP_ID_DECAP_TABLE_1;
            break;
        }
        rule->action_list_p[action_index].fields.action_trap.trap_id =
            trap_id;
        action_index++;
        break;

    case SX_ROUTER_ACTION_FORWARD:
        /* Need to get the exact definition from ACL team */
        rule->action_list_p[action_index].type =
            SX_FLEX_ACL_ACTION_TUNNEL_DECAP;
        rule->action_list_p[action_index].fields.action_tunnel_decap.tunnel_id =
            data->tunnel_id;
        action_index++;
        break;

    case SX_ROUTER_ACTION_TRAP_FORWARD:
        rule->action_list_p[action_index].type =
            SX_FLEX_ACL_ACTION_TRAP;
        rule->action_list_p[action_index].fields.action_trap.action =
            SX_ACL_TRAP_ACTION_TYPE_TRAP;
        switch (data->trap_attr.prio) {
        case SX_TRAP_PRIORITY_BEST_EFFORT:
        case SX_TRAP_PRIORITY_LOW:
        case SX_TRAP_PRIORITY_MED:
            trap_id = SX_TRAP_ID_DECAP_TABLE_0;
            break;

        case SX_TRAP_PRIORITY_HIGH:
        case SX_TRAP_PRIORITY_CRITICAL:
            trap_id = SX_TRAP_ID_DECAP_TABLE_1;
            break;
        }
        rule->action_list_p[action_index].fields.action_trap.trap_id =
            trap_id;
        action_index++;

        rule->action_list_p[action_index].type =
            SX_FLEX_ACL_ACTION_TUNNEL_DECAP;
        rule->action_list_p[action_index].fields.action_tunnel_decap.tunnel_id =
            data->tunnel_id;
        action_index++;
        break;

    case SX_ROUTER_ACTION_SPAN:
        rule->action_list_p[action_index].type =
            SX_FLEX_ACL_ACTION_MIRROR;
        rule->action_list_p[action_index].fields.action_mirror.session_id =
            data->span_session_id;
        action_index++;

        rule->action_list_p[action_index].type =
            SX_FLEX_ACL_ACTION_TUNNEL_DECAP;
        rule->action_list_p[action_index].fields.action_tunnel_decap.tunnel_id =
            data->tunnel_id;
        action_index++;
        break;
    }

    if (data->counter_id != SX_FLOW_COUNTER_ID_INVALID) {
        rule->action_list_p[action_index].type =
            SX_FLEX_ACL_ACTION_COUNTER;
        rule->action_list_p[action_index].fields.action_counter.counter_id =
            data->counter_id;
        action_index++;
    }

    if (data->set_user_token == TRUE) {
        rule->action_list_p[action_index].type = SX_FLEX_ACL_ACTION_SET_USER_TOKEN;
        rule->action_list_p[action_index].fields.action_set_user_token.user_token = data->user_token.user_token;
        rule->action_list_p[action_index].fields.action_set_user_token.mask = data->user_token.mask;
        action_index++;
    }

    if (acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
        rule->action_list_p[action_index].type = SX_FLEX_ACL_ACTION_GOTO;
        rule->action_list_p[action_index].fields.action_goto.acl_group_id = acl_group_id;
        rule->action_list_p[action_index].fields.action_goto.goto_action_cmd =
            SX_ACL_ACTION_GOTO_CALL;
        action_index++;
    }

    rule->action_count = action_index;

    if (rule->action_count > MAX_ACL_ACTION_NUMBER) {
        /* Should not happen */
        SX_LOG(SX_LOG_ERROR, "Action number exceed range\n");
        sx_status = SX_STATUS_ERROR;
    }

    return sx_status;
}

static sx_status_t __decap_table_set_entry(const sx_tunnel_decap_entry_key_t  *key,
                                           const sx_tunnel_decap_entry_data_t *data,
                                           sx_acl_id_t                         acl_group_id,
                                           sx_acl_rule_offset_t                index)
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS;
    sx_api_flex_acl_rules_set_params_t params;
    sx_flex_acl_flex_rule_t            rule;
    sx_ip_version_t                    ip_version = SX_IP_VERSION_NONE;

    SX_MEM_CLR(params);
    SX_MEM_CLR(rule);

    ip_version = __hwd_decap_table_tunnel_type_to_ip_version(key->tunnel_type);

    /* set rule key */
    sx_status = __decap_table_set_entry_key(key, &rule);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "Failed to set [%s] entry key.\n", sx_ip_version_str(ip_version));
        goto out;
    }
    /* set rule action */
    sx_status = __decap_table_set_entry_data(data, acl_group_id, &rule);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "Failed to set [%s] entry data.\n", sx_ip_version_str(ip_version));
        goto out;
    }

    sx_status = __decap_table_set_acl_rule(SX_ACCESS_CMD_SET, &rule, index, ip_version);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "Failed to set [%s] acl rule.\n", sx_ip_version_str(ip_version));
        goto out;
    }

out:
    if (rule.key_desc_list_p) {
        cl_free(rule.key_desc_list_p);
        rule.key_desc_list_p = NULL;
    }
    if (rule.action_list_p) {
        cl_free(rule.action_list_p);
        rule.action_list_p = NULL;
    }
    return sx_status;
}

static const char * __hwd_decap_table_vrid_ref_name(char *name_buf, size_t name_size, void *id)
{
    uint32_t *id_p = (uint32_t*)id;

    snprintf(name_buf, name_size, "DECAP_RULE_ENTRY_ID_%u", *id_p);
    return name_buf;
}

sx_status_t __hwd_decap_rm_init(sx_ip_version_t ip_version, uint32_t rm_min_size)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    sx_status_t         rb_sx_status = SX_STATUS_SUCCESS;
    boolean_t           rm_inited = FALSE;
    rm_sdk_table_type_e resource;

    SX_LOG_ENTER();

    resource =
        (ip_version ==
         SX_IP_VERSION_IPV4 ? RM_SDK_TABLE_TYPE_DECAP_RULES_IPV4_E : RM_SDK_TABLE_TYPE_DECAP_RULES_IPV6_E);

    rm_resource_global.rm_sdk_tables_db[resource].is_initialized = TRUE;
    sx_status = rm_sdk_table_init_resource(resource);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialize decap rules resource in resource-manager: %s\n",
                   sx_status_str(sx_status));
        goto out;
    }
    rm_inited = TRUE;

    /* Check if we have sufficient resources for ACL init & WC */
    sx_status = rm_allocate_entries_check(resource,
                                          SX_ACCESS_CMD_ADD, rm_min_size + 1, NULL);

    g_rm_check_in_progress = TRUE;

    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Insufficient resources to initialize Tunnel ACL: %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (rm_inited) {
            rm_resource_global.rm_sdk_tables_db[resource].is_initialized = FALSE;
            rb_sx_status = rm_sdk_table_deinit_resource(resource, TRUE);
            if (SX_CHECK_FAIL(rb_sx_status)) {
                SX_LOG_ERR("Failed to rollback initialization of decap table in resource-manager: %s\n",
                           sx_status_str(rb_sx_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t __hwd_decap_wc_init(sx_ip_version_t ip_version, uint32_t rm_min_size)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_rm_check_in_progress) {
        sx_status = __hwd_decap_table_rm_entries_update(ip_version,  SX_ACCESS_CMD_ADD, rm_min_size);
        g_rm_check_in_progress = FALSE;
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update resource for %u entries, err = [%s]\n",
                       rm_min_size, sx_status_str(sx_status));
            goto out;
        }
    }

    /* Add + 1 to size for wildcard rule, table was initialized with rm_min_size already */
    sx_status = __decap_table_resize_alloc(ip_version, SX_ACCESS_CMD_ADD, rm_min_size, 1);
    if (SX_CHECK_FAIL(sx_status)) {
        if (sx_status == SX_STATUS_NO_RESOURCES) {
            SX_LOG_INF("Failed to init TCAM resources for decap table for %u entries, err = [%s]\n",
                       rm_min_size, sx_status_str(sx_status));
        } else {
            SX_LOG_ERR("Failed to init TCAM resources for decap table for %u entries, err = [%s]\n",
                       rm_min_size, sx_status_str(sx_status));
        }
        goto out;
    }

    /* set wildcard rule */
    sx_status = __hwd_decap_rm_entries_set(ip_version, SX_ACCESS_CMD_ADD, 1, FALSE);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to add wildcard rule for decap table, err = [%s]\n",
                   sx_status_str(sx_status));
    }

out:

    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t hwd_decap_table_init(void)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t  sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    sx_ip_version_t    ip_version = SX_IP_VERSION_NONE;
    psort_init_param_t psort_init_param;
    psort_handle_t     psort_handle;

    SX_LOG_ENTER();
    SX_LOG(SX_LOG_DEBUG, "Init decap table\n");

    if (TRUE == g_is_initialized) {
        sx_status = SX_STATUS_DB_ALREADY_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    g_rif_list_p = cl_malloc(rm_resource_global.router_rifs_max * sizeof(sx_router_interface_t));
    if (g_rif_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for rif list, error = %s\n",
                   sx_status_str(sx_status));
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    sx_status = decap_table_db_init(SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("db init failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    /* Init sorting algo*/
    SX_MEM_CLR(psort_init_param);
    psort_init_param.table_size = SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE; /*16 */
    psort_init_param.delta_size = PSORT_PRIO_REG_DELTA_SIZE; /* how region for specific prio grows */
    psort_init_param.min_priority = PSORT_MIN_PRIO;
    psort_init_param.table_almost_empty_precentage_threshold = PSORT_SHRINK_THRESHOLD_PERCENT;
    psort_init_param.table_almost_full_precentage_threshold = PSORT_ENLARGE_THRESHOLD_PERCENT;
    psort_init_param.notif_callback = __psort_callback;

    for (ip_version = SX_IP_VERSION_IPV4; ip_version < SX_IP_VERSION_MAX; ip_version++) {
        if (SX_IP_VERSION_IPV4 == ip_version) {
            psort_init_param.max_priority = PSORT_IPV4_MAX_PRIO;
            psort_init_param.cookie = &psort_context_ipv4;
        } else {
            psort_init_param.max_priority = PSORT_IPV6_MAX_PRIO;
            psort_init_param.cookie = &psort_context_ipv6;
        }

        sx_utils_status = psort_init(&psort_handle, &psort_init_param);
        if (sx_utils_status != SX_UTILS_STATUS_SUCCESS) {
            sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
            decap_table_db_deinit(TRUE);
            goto out;
        }
        sx_utils_status = psort_background_register(psort_handle, SX_UTILS_CMD_ADD);
        if (SX_UTILS_CHECK_FAIL(sx_utils_status)) {
            sx_status = sx_utils_status_to_sx_status(sx_utils_status);
            SX_LOG_ERR("Failed to register %s psort client to background process, utils_err = [%s]\n",
                       sx_ip_version_str(ip_version), SX_UTILS_STATUS_MSG(sx_utils_status));
            goto out;
        }

        decap_table_db_set_psort_handle(ip_version, psort_handle);

        sx_status = __hwd_decap_rm_init(ip_version, SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to init RM for decap table, err - %s.\n",
                       sx_status_str(sx_status));
            psort_background_register(psort_handle, SX_UTILS_CMD_DELETE);
            psort_clear_table(psort_handle);
            decap_table_db_deinit(TRUE);
            goto out;
        }


        sx_status = __decap_table_init_region(ip_version);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("region [%s] init failure - %s.\n", sx_ip_version_str(ip_version), sx_status_str(sx_status));
            psort_background_register(psort_handle, SX_UTILS_CMD_DELETE);
            psort_clear_table(psort_handle);
            decap_table_db_deinit(TRUE);
            if (g_rm_check_in_progress) {
                /* Unlock RM table */
                __hwd_decap_table_rm_entries_update(ip_version, SX_ACCESS_CMD_ADD, 0);
                g_rm_check_in_progress = FALSE;
            }
            __hwd_decap_rm_deinit(ip_version, TRUE);
            goto out;
        }

        sx_status = __hwd_decap_wc_init(ip_version, SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to init RM for decap table, err - %s.\n",
                       sx_status_str(sx_status));
            psort_background_register(psort_handle, SX_UTILS_CMD_DELETE);
            psort_clear_table(psort_handle);
            decap_table_db_deinit(TRUE);
            __decap_table_deinit_region(ip_version);
            __hwd_decap_rm_deinit(ip_version, TRUE);
            goto out;
        }
    }

    g_is_initialized = TRUE;

out:
    if (sx_status != SX_STATUS_SUCCESS) {
        if (g_rif_list_p != NULL) {
            CL_FREE_N_NULL(g_rif_list_p);
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t __hwd_decap_rm_deinit(sx_ip_version_t ip_version, boolean_t force_deinit)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    sx_status_t         rb_status = SX_STATUS_SUCCESS;
    uint32_t            size = 0;
    boolean_t           rm_checked = FALSE;
    rm_sdk_table_type_e resource;

    SX_LOG_ENTER();

    resource =
        (ip_version ==
         SX_IP_VERSION_IPV4 ? RM_SDK_TABLE_TYPE_DECAP_RULES_IPV4_E : RM_SDK_TABLE_TYPE_DECAP_RULES_IPV6_E);

    if (force_deinit) {
        size = sdk_table_resources_g[resource].curr_num_of_entries;
        if (size > 0) {
            sx_status = __hwd_decap_rm_entries_set(ip_version, SX_ACCESS_CMD_DELETE, size, FALSE);

            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to delete %u entry form RM, err = %s\n",
                           size, sx_status_str(sx_status));
                goto out;
            }
        }
    }

    if (sdk_table_resources_g[resource].table_allocated_size > 0) {
        sx_status = __hwd_decap_table_rm_entries_check(ip_version,
                                                       SX_ACCESS_CMD_DELETE,
                                                       sdk_table_resources_g[resource].table_allocated_size);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to check resource for %u entries, err = [%s]\n",
                       size, sx_status_str(sx_status));
            goto out;
        }
        rm_checked = TRUE;

        sx_status = __hwd_decap_table_rm_entries_update(ip_version,
                                                        SX_ACCESS_CMD_DELETE,
                                                        sdk_table_resources_g[resource].table_allocated_size);

        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update resource for %u entries, err = [%s]\n",
                       size, sx_status_str(sx_status));
            goto out;
        }

        /* Remove ACL region */
        sx_status = __decap_table_deinit_region(ip_version);

        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG(SX_LOG_ERROR, "Failed to deinit acl v4 region\n");
            goto out;
        }
    }

    rm_resource_global.rm_sdk_tables_db[resource].is_initialized = FALSE;
    sx_status = rm_sdk_table_deinit_resource(resource, force_deinit);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to deinit decap rules in RM, err = [%s]\n",
                   sx_status_str(sx_status));
        goto out;
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (rm_checked) {
            rb_status = __hwd_decap_table_rm_entries_update(ip_version,
                                                            SX_ACCESS_CMD_DELETE, 0);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to update resource for %u entries, err = [%s]\n",
                           0, sx_status_str(rb_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_decap_table_deinit(boolean_t force_deinit)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    psort_handle_t    psort_handle;
    sx_ip_version_t   ip_version = SX_IP_VERSION_NONE;

    SX_LOG(SX_LOG_DEBUG, "Deinit decap table with force_deinit (%u)\n", force_deinit);

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = decap_table_db_deinit(force_deinit);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "Failed to deinit db\n");
        goto out;
    }

    for (ip_version = SX_IP_VERSION_IPV4; ip_version < SX_IP_VERSION_MAX; ip_version++) {
        decap_table_db_get_psort_handle(ip_version, &psort_handle);
        sx_utils_status = psort_background_register(psort_handle, SX_UTILS_CMD_DELETE);
        if (SX_UTILS_CHECK_FAIL(sx_utils_status)) {
            sx_status = sx_utils_status_to_sx_status(sx_utils_status);
            SX_LOG_ERR("Failed to deregister %s psort client, utils_err = [%s]\n",
                       sx_ip_version_str(ip_version), SX_UTILS_STATUS_MSG(sx_utils_status));
            goto out;
        }
        sx_utils_status = psort_clear_table(psort_handle);

        if (sx_utils_status != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to deinit [%s] sorting algorithm\n", sx_ip_version_str(ip_version));
            sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
            goto out;
        }
        sx_status = __hwd_decap_rm_deinit(ip_version, force_deinit);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("Failed to deinit RM for decap table, err - %s.\n",
                       sx_status_str(sx_status));
            goto out;
        }
    }

    if (g_rif_list_p != NULL) {
        CL_FREE_N_NULL(g_rif_list_p);
    }

    g_is_initialized = FALSE;

out:
    if (SX_CHECK_FAIL(sx_status) && (!force_deinit)) {
    }
    return sx_status;
}

static sx_status_t __hwd_decap_table_vrid_decap_refcnt_inc(sx_router_id_t vrid)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    refcount = 0;
    uint32_t    i = 0;
    uint32_t    rif_count = rm_resource_global.router_rifs_max;
    sx_acl_id_t group_id = FLEX_ACL_INVALID_ACL_ID;

    sx_status = sdk_router_vrid_impl_decap_refcnt_inc(vrid);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to increase the decap refcounter for VRID %u, error = %s\n",
                   vrid, sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_router_vrid_impl_decap_refcnt_get(vrid, &refcount);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get decap refcount for VRID %u, error = %s\n",
                   vrid, sx_status_str(sx_status));
        goto out;
    }

    if (refcount == 1) {
        sx_status = sdk_rif_impl_get_decap_rif_ids_per_vrid(vrid, g_rif_list_p, &rif_count);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get decap rif ids for vrid %u, error = %s\n", vrid, sx_status_str(sx_status));
            goto out;
        }

        /* [DECAP_SYSTEM_ACL] Workaround :
         *  Please read the commit message for this change first.
         *
         *  The code below assumes that only system ACLs that can be bound to RIFs in
         *  the ingress direction are decap system ACLs.
         */
        sx_status = flex_acl_db_get_system_acl_group(SX_ACL_DIRECTION_RIF_INGRESS, &group_id);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get system ACL group id for the RIF INGRESS direction, error = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }

        if (group_id == FLEX_ACL_INVALID_ACL_ID) {
            sx_status = SX_STATUS_ERROR;
            SX_LOG_ERR("Failed to find a system decap ACL group, error = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }

        for (i = 0; i < rif_count; i++) {
            sx_status = flex_acl_rif_bind_internal(g_rif_list_p[i],
                                                   group_id,
                                                   TRUE);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to bind RIF [%u] to group_id[%u], error = %s\n",
                           g_rif_list_p[i], group_id, sx_status_str(sx_status));
                goto out;
            }
        }
    }

out:
    return sx_status;
}

static sx_status_t __hwd_decap_table_vrid_decap_refcnt_dec(sx_router_id_t vrid)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    uint32_t                   refcount = 0;
    uint32_t                   i = 0;
    uint32_t                   rif_count = rm_resource_global.router_rifs_max;
    sx_acl_id_t                group_id = FLEX_ACL_INVALID_ACL_ID;
    sx_acl_direction_t         direction = SX_ACL_DIRECTION_LAST;
    flex_acl_bind_attribs_id_t attribs_id_from_rif = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_bind_attribs_id_t system_bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    sx_status = sdk_router_vrid_impl_decap_refcnt_get(vrid, &refcount);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get decap refcount for VRID %u, error = %s\n",
                   vrid, sx_status_str(sx_status));
        goto out;
    }

    if (refcount == 1) {
        sx_status = sdk_rif_impl_get_decap_rif_ids_per_vrid(vrid, g_rif_list_p, &rif_count);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get decap rif ids for vrid %u, error = %s\n", vrid, sx_status_str(sx_status));
            goto out;
        }

        /* [DECAP_SYSTEM_ACL] Workaround :
         *  Please read the commit message for this change first.
         *
         *  The code below assumes that only system ACLs that can be bound to RIFs in
         *  the ingress direction are decap system ACLs.
         */
        sx_status = flex_acl_db_get_system_acl_group(SX_ACL_DIRECTION_RIF_INGRESS, &group_id);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get system ACL group id for the RIF INGRESS direction, error = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }

        if (group_id == FLEX_ACL_INVALID_ACL_ID) {
            sx_status = SX_STATUS_ERROR;
            SX_LOG_ERR("Failed to find a system decap ACL group, error = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }

        sx_status = flex_acl_get_bind_attribs(group_id, &system_bind_attribs_id, &direction, NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get bind attributes id for system group id, error = %s\n",
                       sx_status_str(sx_status));
            goto out;
        }

        for (i = 0; i < rif_count; i++) {
            sx_status = flex_acl_db_get_rif_bind(g_rif_list_p[i], direction, &attribs_id_from_rif);
            if ((sx_status != SX_STATUS_SUCCESS) && (sx_status != SX_STATUS_ENTRY_NOT_FOUND)) {
                SX_LOG_ERR("Failed to get bind attributes for RIF %u, error = %s\n", g_rif_list_p[i],
                           sx_status_str(sx_status));
                goto out;
            }

            if (attribs_id_from_rif == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
                attribs_id_from_rif = system_bind_attribs_id;
            }

            sx_status = flex_acl_rif_unbind_internal(group_id, g_rif_list_p[i], attribs_id_from_rif);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to unbind RIF [%u], error = %s\n", g_rif_list_p[i], sx_status_str(sx_status));
                goto out;
            }
        }
    }

    sx_status = sdk_router_vrid_impl_decap_refcnt_dec(vrid);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to decrease the decap refcounter for VRID %u, error = %s\n",
                   vrid, sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

sx_status_t hwd_decap_table_add_entry(const sx_tunnel_decap_entry_key_t *key, const sx_tunnel_decap_entry_data_t *data)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    sx_status_t       rb_status = SX_STATUS_SUCCESS;
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    psort_entry_t     psort_entry;
    psort_handle_t    psort_handle;
    boolean_t         psort_added = FALSE;
    sx_utils_status_t rb_psort_status = SX_UTILS_STATUS_SUCCESS;
    uint32_t          reg_size = 0;
    boolean_t         rm_added = FALSE;
    sx_status_t       vrid_ref_set_status = SX_STATUS_SUCCESS;
    boolean_t         vrid_ref_set = FALSE;
    sx_status_t       decap_vrid_ref_set_status = SX_STATUS_SUCCESS;
    boolean_t         decap_vrid_ref_set = FALSE;
    sdk_ref_t         vrid_ref = 0;
    sx_status_t       fpp_ref_set_status = SX_STATUS_SUCCESS;
    boolean_t         fpp_ref_set = FALSE;
    sdk_ref_t         fpp_ref = 0;
    sx_ip_version_t   ip_version = SX_IP_VERSION_NONE;
    uint32_t          decap_entry_id = 0;
    boolean_t         decap_entry_id_allocated = FALSE;
    sx_status_t       rb_decap_id_status = SX_STATUS_SUCCESS;
    ref_name_data_t   ref_name_data = {.print_func_p = __hwd_decap_table_vrid_ref_name,
                                       .ref_data_p = (void*)&decap_entry_id,
                                       .data_size = sizeof(uint32_t)};
    sx_acl_id_t       acl_group_id = FLEX_ACL_INVALID_ACL_ID;
    int               prio = key->priority;
    uint32_t          table_size = 0;
    uint32_t          table_free = 0;
    uint32_t          table_used = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(psort_entry);
    SX_MEM_CLR(psort_handle);

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    /* verify the value of key and data */
    sx_status = __decap_table_verify_entry(key, data);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("decap entry is invalid.\n");
        __decap_table_dump_key(key);
        __decap_table_dump_data(data);
        goto out;
    }

    /* check if the key existed */
    sx_status = decap_table_db_map_entry_find(key, NULL, NULL, NULL);
    if (sx_status != SX_STATUS_ENTRY_NOT_FOUND) {
        if (sx_status == SX_STATUS_SUCCESS) {
            sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        }
        goto out;
    }

    sx_status = decap_table_db_generate_unique_entry_id(&decap_entry_id);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "Failed to generate unique ID for the entry - %s.\n", sx_status_str(sx_status));
        goto out;
    }
    decap_entry_id_allocated = TRUE;

    ip_version = __hwd_decap_table_tunnel_type_to_ip_version(key->tunnel_type);

    switch (key->type) {
    case SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET:
        psort_entry.priority = prio;
        break;

    case SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP:
        if (SX_IP_VERSION_IPV4 == ip_version) {
            psort_entry.priority = PSORT_IPV4_MAX_PRIO;
        } else {
            psort_entry.priority = PSORT_IPV6_MAX_PRIO;
        }
        break;

    case SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP:
        psort_entry.priority = PSORT_MIN_PRIO;
        break;

    default:
        SX_LOG(SX_LOG_ERROR, "Unknown key type [%d].\n", key->type);
        goto out;
    }

    decap_table_db_get_psort_handle(ip_version, &psort_handle);
    sx_utils_status = psort_entry_set(psort_handle, SX_UTILS_CMD_ADD, &psort_entry);

    if (SX_UTILS_STATUS_SUCCESS != sx_utils_status) {
        if (sx_utils_status == SX_UTILS_STATUS_NO_RESOURCES) {
            psort_get_table_free_space(psort_handle, &table_free);
            psort_get_table_used_space(psort_handle, &table_used);
            table_size = table_used + table_free;
            sx_utils_status = psort_table_resize(psort_handle,
                                                 table_size + SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE,
                                                 FALSE,
                                                 NULL);
            if (SX_UTILS_STATUS_SUCCESS != sx_utils_status) {
                SX_LOG(SX_LOG_ERROR, "pSort DB of type [%s] resize failed.\n", sx_ip_version_str(ip_version));
                sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
                goto out;
            }
            sx_utils_status = psort_entry_set(psort_handle, SX_UTILS_CMD_ADD, &psort_entry);
            if (SX_UTILS_STATUS_SUCCESS != sx_utils_status) {
                SX_LOG(SX_LOG_ERROR, "Failed to add [%s] entry to pSort DB.\n", sx_ip_version_str(ip_version));
                sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
                goto out;
            }
        } else {
            SX_LOG(SX_LOG_ERROR, "Failed to add [%s] entry to pSort DB.\n", sx_ip_version_str(ip_version));
            sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
            goto out;
        }
    }

    psort_added = TRUE;

    sx_status = __hwd_decap_rm_entries_set(ip_version, SX_ACCESS_CMD_ADD, 1, FALSE);
    if (SX_STATUS_SUCCESS != sx_status) {
        if (SX_STATUS_NO_RESOURCES == sx_status) {
            decap_table_db_get_region_size(ip_version, &reg_size);
            sx_status = __decap_table_resize_alloc(ip_version,
                                                   SX_ACCESS_CMD_ADD,
                                                   reg_size,
                                                   SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE);
            if (SX_CHECK_FAIL(sx_status)) {
                if (SX_STATUS_NO_RESOURCES == sx_status) {
                    SX_LOG_INF("Failed to add decap rule, err - %s.\n", sx_status_str(sx_status));
                } else {
                    SX_LOG_ERR("Failed to add decap rule, err - %s.\n", sx_status_str(sx_status));
                }
                goto out;
            }

            /* try again add a rule */
            sx_status = __hwd_decap_rm_entries_set(ip_version, SX_ACCESS_CMD_ADD, 1, FALSE);
        }

        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Decap Table : RM denied to set decap rule, err = [%s]\n",
                       sx_status_str(sx_status));
            goto out;
        }
    }
    rm_added = TRUE;

    /* increase ref counter for underlay_vrid */
    sx_status = sdk_router_vrid_impl_refcnt_inc(key->underlay_vrid, &ref_name_data, &vrid_ref);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to increase vrid[%d] ref count, err = %s\n",
                   key->underlay_vrid,
                   sx_status_str(sx_status));
        goto out;
    }
    vrid_ref_set = TRUE;

    sx_status = __hwd_decap_table_vrid_decap_refcnt_inc(key->underlay_vrid);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to increase vrid[%d] decap ref count, err = %s\n",
                   key->underlay_vrid,
                   sx_status_str(sx_status));
        goto out;
    }
    decap_vrid_ref_set = TRUE;

    /* increase ref counter for fpp for flex tunnels decap */
    if ((key->tunnel_type == SX_TUNNEL_TYPE_L2_FLEX) || (key->tunnel_type == SX_TUNNEL_TYPE_L2_FLEX_IPV6)) {
        sx_status = sdk_flex_parser_fpp_ref_inc(key->tunnel_attributes.l2_flex_decap_attributes.fpp_id,
                                                &ref_name_data,
                                                &fpp_ref);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to increase fpp [%u] ref count for tunnel decap rule, err = %s\n",
                       key->tunnel_attributes.l2_flex_decap_attributes.fpp_id.fpp_id,
                       sx_status_str(sx_status));
            goto out;
        }
        fpp_ref_set = TRUE;
    }

    sx_status = decap_table_db_map_entry_add(key,
                                             data,
                                             psort_entry.priority,
                                             psort_entry.index,
                                             vrid_ref,
                                             fpp_ref,
                                             &acl_group_id, decap_entry_id);

    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "Failed to add entry to maps.\n");
        goto out;
    }

    sx_status = __decap_table_set_entry(key, data, acl_group_id, psort_entry.index);

    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "Failed to set [%s] acl rule.\n", sx_ip_version_str(ip_version));
        decap_table_db_map_entry_delete(ip_version, psort_entry.index);
        decap_entry_id_allocated = FALSE;
        goto out;
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (rm_added) {
            rb_status = __hwd_decap_rm_entries_set(ip_version, SX_ACCESS_CMD_DELETE, 1, FALSE);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to rollback adding entry to RM, err = [%s]\n",
                           sx_status_str(rb_status));
            }
        }
        if (decap_vrid_ref_set) {
            decap_vrid_ref_set_status = __hwd_decap_table_vrid_decap_refcnt_dec(key->underlay_vrid);
            if (SX_STATUS_SUCCESS != decap_vrid_ref_set_status) {
                SX_LOG_ERR("Failed to decrease vrid[%d] decap ref count, err= %s.\n",
                           key->underlay_vrid,
                           sx_status_str(decap_vrid_ref_set_status));
            }
        }
        if (vrid_ref_set) {
            vrid_ref_set_status = sdk_router_vrid_impl_refcnt_dec(key->underlay_vrid, &vrid_ref);
            if (SX_STATUS_SUCCESS != vrid_ref_set_status) {
                SX_LOG_ERR("Failed to decrease vrid[%d] ref count, err= %s.\n",
                           key->underlay_vrid,
                           sx_status_str(vrid_ref_set_status));
            }
        }
        if (fpp_ref_set) {
            fpp_ref_set_status = sdk_flex_parser_fpp_ref_dec(key->tunnel_attributes.l2_flex_decap_attributes.fpp_id,
                                                             &fpp_ref);
            if (SX_CHECK_FAIL(fpp_ref_set_status)) {
                SX_LOG_ERR("Failed to decrease rollback fpp [%u] ref count for tunnel decap rule, err = %s\n",
                           key->tunnel_attributes.l2_flex_decap_attributes.fpp_id.fpp_id,
                           sx_status_str(fpp_ref_set_status));
            }
        }
        if (psort_added) {
            rb_psort_status = psort_entry_set(psort_handle, SX_UTILS_CMD_DELETE, &psort_entry);
            if (SX_UTILS_STATUS_SUCCESS != rb_psort_status) {
                SX_LOG_ERR("Failed to remove [%s] pSort entry - %s.\n", sx_ip_version_str(ip_version),
                           sx_status_str(SX_UTILS_STATUS_TO_SX_STATUS(rb_psort_status)));
            }
        }
        if (decap_entry_id_allocated) {
            rb_decap_id_status = decap_table_db_free_unique_entry_id(decap_entry_id);
            if (SX_CHECK_FAIL(rb_decap_id_status)) {
                SX_LOG(SX_LOG_ERROR,
                       "Failed to free unique ID [%d] of the entry - %s.\n",
                       decap_entry_id,
                       sx_status_str(rb_decap_id_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_decap_table_edit_entry(const sx_tunnel_decap_entry_key_t  *key,
                                       const sx_tunnel_decap_entry_data_t *data)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_status_t                  rollback_err = SX_STATUS_SUCCESS;
    sx_acl_rule_offset_t         index;
    sx_tunnel_decap_entry_data_t old_data;
    boolean_t                    db_edited = FALSE;
    sx_acl_id_t                  acl_group_id = FLEX_ACL_INVALID_ACL_ID;

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    /* check if the key existed */
    sx_status = decap_table_db_map_entry_find(key, &old_data, &index, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to find entry.\n");
        goto out;
    }

    /* verify the value of key and data */
    sx_status = __decap_table_verify_entry(key, data);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("decap entry is invalid.\n");
        __decap_table_dump_key(key);
        __decap_table_dump_data(data);
        goto out;
    }

    sx_status = decap_table_db_map_entry_edit(key, data, &acl_group_id);

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG(SX_LOG_ERROR, "Failed to edit decap entry in db with new data.\n");
        goto out;
    }
    db_edited = TRUE;

    sx_status = __decap_table_set_entry(key, data, acl_group_id, index);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG(SX_LOG_ERROR, "Failed to set acl rule.\n");
        goto out;
    }

out:
    if (SX_CHECK_FAIL(sx_status) && (db_edited == TRUE)) {
        rollback_err = decap_table_db_map_entry_edit(key, &old_data, &acl_group_id);
        if (SX_CHECK_FAIL(rollback_err)) {
            SX_LOG(SX_LOG_ERROR, "Failed to rollback decap entry db to old data.\n");
        }
    }
    return sx_status;
}

sx_status_t hwd_decap_table_get_entry(const sx_tunnel_decap_entry_key_t *key, sx_tunnel_decap_entry_data_t *data)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    /* check if the key existed */
    sx_status = decap_table_db_map_entry_find(key, data, NULL, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to find entry.\n");
        goto out;
    }

out:
    return sx_status;
}

sx_status_t hwd_decap_table_rule_iter_get(const sx_access_cmd_t                 cmd,
                                          const sx_tunnel_decap_entry_key_t     key,
                                          const sx_tunnel_decap_entry_filter_t *filter_p,
                                          sx_tunnel_decap_entry_key_t          *rule_list_p,
                                          uint32_t                             *rule_cnt_p)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_tunnel_decap_entry_data_t tmp_data;

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (utils_check_pointer(rule_cnt_p, "rule_cnt_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    SX_MEM_CLR(tmp_data);
    /* All basic validations(except key and filter) have been performed prior to reaching here.
     * So  . Lets go */
    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        /* Two options apply with GET Cmd
         * 1. we expect to check for a single rule in the db that match the key
         *    with/without filter.
         * 2. Get count of rules that match filter. Without filter has already
         *    been handled earlier.
         */
        if ((*rule_cnt_p == 0) && (filter_p)) {
            sx_status = decap_table_db_iter_rule_list_get(NULL, filter_p,
                                                          rule_list_p, rule_cnt_p);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to get count of filtered Tunnel decap rules, err=(%s).\n",
                           sx_status_str(sx_status));
                goto out;
            }
        } else {
            sx_status = decap_table_db_map_entry_find(&key, &tmp_data, NULL, NULL);
            if (sx_status != SX_STATUS_SUCCESS) {
                if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
                    /* we must return success and an empty list since this is an
                     * iterator and not the get api. see SDK+Iterator+API+guidelines wiki*/
                    sx_status = SX_STATUS_SUCCESS;
                    SX_MEM_CLR_P(rule_list_p);
                    *rule_cnt_p = 0;
                    goto out;
                } else {
                    SX_LOG_ERR("Failed to get rule from db , err (%s).\n",  sx_status_str(sx_status));
                    goto out;
                }
            }
            if (filter_p) {
                /* filter is Not Null. Lets check the read data against the filter */
                if (filter_p->filter_by_tunnel_id) {
                    if (tmp_data.tunnel_id != filter_p->tunnel_id) {
                        /* filter doesn't match. Return success and count = 0 */
                        sx_status = SX_STATUS_SUCCESS;
                        SX_MEM_CLR_P(rule_list_p);
                        *rule_cnt_p = 0;
                        goto out;
                    }
                }
                if (filter_p->filter_by_tunnel_type) {
                    if (filter_p->tunnel_type != key.tunnel_type) {
                        /* filter doesn't match. for GET command, since type is in key
                         * it must match. Return param error */
                        sx_status = SX_STATUS_PARAM_ERROR;
                        SX_LOG_ERR("Tunnel type in filter doesn't match the type in "
                                   "provided Key for cmd (%s), err (%s).\n",  sx_access_cmd_str(cmd),
                                   sx_status_str(sx_status));
                        goto out;
                    }
                }
            }

            /* All Done. Copy the data to return params*/
            SX_MEM_CPY(rule_list_p[0], key);
            *rule_cnt_p = 1;
        }


        break;

    case SX_ACCESS_CMD_GET_FIRST:
        SX_MEM_CLR_ARRAY(rule_list_p, *rule_cnt_p, sx_tunnel_decap_entry_key_t);

        /* with GET_FIRST the key provided is treated as Dont Care. So we pass NULL */
        sx_status = decap_table_db_iter_rule_list_get(NULL, filter_p,
                                                      rule_list_p, rule_cnt_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to %s %u Tunnel decap rules, err=(%s).\n",
                       sx_access_cmd_str(cmd), *rule_cnt_p, sx_status_str(sx_status));
            goto out;
        }

        break;

    case SX_ACCESS_CMD_GETNEXT:
        SX_MEM_CLR_ARRAY(rule_list_p, *rule_cnt_p, sx_tunnel_decap_entry_key_t);
        sx_status = decap_table_db_iter_rule_list_get(&key, filter_p,
                                                      rule_list_p, rule_cnt_p);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to %s %u Tunnel decap rules, err=(%s).\n",
                       sx_access_cmd_str(cmd), *rule_cnt_p, sx_status_str(sx_status));
            goto out;
        }

        break;

    default:
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not supported.\n", sx_access_cmd_str(cmd));
        goto out;
        break;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
sx_status_t hwd_decap_table_delete_entry(const sx_tunnel_decap_entry_key_t* key)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t    sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    sx_acl_rule_offset_t index;
    psort_entry_t        psort_entry;
    psort_handle_t       psort_handle;
    sdk_ref_t            vrid_ref = 0;
    sdk_ref_t            fpp_ref = 0;
    sx_ip_version_t      ip_version = SX_IP_VERSION_NONE;
    int                  prio = 0;

    SX_LOG_ENTER();

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }


    sx_status = decap_table_db_map_entry_find(key, NULL, &index, &prio);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to find entry.\n");
        goto out;
    }

    /* Get vrid ref */
    sx_status = decap_table_db_get_ref(key, &vrid_ref, &fpp_ref);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to find vrid_ref, err= %s.\n",
                   sx_status_str(sx_status));
        goto out;
    }

    ip_version = __hwd_decap_table_tunnel_type_to_ip_version(key->tunnel_type);
    decap_table_db_get_psort_handle(ip_version, &psort_handle);
    psort_entry.index = index;
    psort_entry.priority = prio;

    sx_utils_status = psort_entry_set(psort_handle, SX_UTILS_CMD_DELETE, &psort_entry);
    if (SX_UTILS_STATUS_SUCCESS != sx_utils_status) {
        SX_LOG(SX_LOG_ERROR, "Failed to delete [%s] psort entry.\n", sx_ip_version_str(ip_version));
        sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
        goto out;
    }

    sx_status = __decap_table_set_acl_rule(SX_ACCESS_CMD_DELETE, NULL, psort_entry.index, ip_version);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to delete [%s] acl rule (%u).\n",
                   sx_ip_version_str(ip_version), psort_entry.index);
        goto out;
    }

    sx_status = decap_table_db_map_entry_delete(ip_version, psort_entry.index);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to delete index from index map (%u).\n", psort_entry.index);
        goto out;
    }

    sx_status = __hwd_decap_table_vrid_decap_refcnt_dec(key->underlay_vrid);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to decrease vrid[%d] decap ref count, err= %s.\n",
                   key->underlay_vrid,
                   sx_status_str(sx_status));
        goto out;
    }

    /* Decrease vrid ref count */
    sx_status = sdk_router_vrid_impl_refcnt_dec(key->underlay_vrid, &vrid_ref);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to decrease vrid[%d] ref count, err= %s.\n",
                   key->underlay_vrid,
                   sx_status_str(sx_status));
        goto out;
    }

    if ((key->tunnel_type == SX_TUNNEL_TYPE_L2_FLEX) || (key->tunnel_type == SX_TUNNEL_TYPE_L2_FLEX_IPV6)) {
        sx_status = sdk_flex_parser_fpp_ref_dec(key->tunnel_attributes.l2_flex_decap_attributes.fpp_id, &fpp_ref);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to decrease fpp [%u] ref count for tunnel decap rule, err = %s\n",
                       key->tunnel_attributes.l2_flex_decap_attributes.fpp_id.fpp_id,
                       sx_status_str(sx_status));
            goto out;
        }
    }

    sx_status = __hwd_decap_rm_entries_set(ip_version, SX_ACCESS_CMD_DELETE, 1, FALSE);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to delete entry form RM, err = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t __decap_table_bind_acl_rules(sx_port_log_id_t nve_port, sx_acl_id_t acl_group_id)
{
    sx_status_t                        sx_status = SX_STATUS_SUCCESS;
    sx_acl_rule_offset_t              *offsets_list_p = NULL;
    sx_tunnel_decap_entry_key_t      **key_p_list_p = NULL;
    sx_tunnel_decap_entry_data_t     **data_p_list_p = NULL;
    sx_flex_acl_flex_rule_t           *rules_list_p = NULL;
    uint16_t                           rules_count = 0;
    sx_api_flex_acl_rules_set_params_t params;
    uint32_t                           i;
    sx_ip_version_t                    ip_version = SX_IP_VERSION_IPV4;

    sx_status = decap_table_db_get_bound_entries(nve_port, NULL, NULL, NULL, &rules_count);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get bound rules count of nve port 0x%08x.\n", nve_port);
        goto out;
    }

    if (rules_count == 0) {
        SX_LOG_DBG("No bound rules.\n");
        goto out;
    }

    offsets_list_p = cl_malloc(sizeof(sx_acl_rule_offset_t) * rules_count);
    if (offsets_list_p == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed allocate offsets list.\n");
        goto out;
    }
    key_p_list_p = cl_malloc(sizeof(sx_tunnel_decap_entry_key_t*) * rules_count);
    if (key_p_list_p == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed allocate key list.\n");
        goto out;
    }
    data_p_list_p = cl_malloc(sizeof(sx_tunnel_decap_entry_data_t*) * rules_count);
    if (data_p_list_p == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed allocate data list.\n");
        goto out;
    }
    sx_status = decap_table_db_get_bound_entries(nve_port, key_p_list_p, data_p_list_p, offsets_list_p, &rules_count);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get bound entries of nve port 0x%08x.\n", nve_port);
        goto out;
    }

    rules_list_p = cl_malloc(sizeof(sx_flex_acl_flex_rule_t) * rules_count);
    if (rules_list_p == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed allocate rules list.\n");
        goto out;
    }
    SX_MEM_CLR_ARRAY(rules_list_p, rules_count, sx_flex_acl_flex_rule_t);
    for (i = 0; i < rules_count; i++) {
        /* set rule key */
        sx_status = __decap_table_set_entry_key(key_p_list_p[i], &(rules_list_p[i]));
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG(SX_LOG_ERROR, "Failed to set entry key.\n");
            goto out;
        }
        /* set rule action */
        sx_status = __decap_table_set_entry_data(data_p_list_p[i], acl_group_id, &(rules_list_p[i]));
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG(SX_LOG_ERROR, "Failed to set entry data.\n");
            goto out;
        }
    }

    /* get version from first entry. It must be same for all entries as we support only one NVE tunnel */
    ip_version = key_p_list_p[0]->underlay_dip.version;

    SX_MEM_CLR(params);
    params.cmd = SX_ACCESS_CMD_SET;
    decap_table_db_get_region_id(ip_version, &params.region_id);
    params.rules_count = rules_count;
    params.rules = rules_list_p;
    params.offsets_list_p = offsets_list_p;

    sx_status = flex_acl_rules_set_internal(&params);

    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to set acl rules on region(%u)\n", params.region_id);
        goto out;
    }

out:
    if (rules_list_p) {
        for (i = 0; i < rules_count; i++) {
            if (rules_list_p[i].key_desc_list_p) {
                CL_FREE_N_NULL(rules_list_p[i].key_desc_list_p);
            }
            if (rules_list_p[i].action_list_p) {
                CL_FREE_N_NULL(rules_list_p[i].action_list_p);
            }
        }
    }
    if (offsets_list_p) {
        CL_FREE_N_NULL(offsets_list_p);
    }
    if (key_p_list_p) {
        CL_FREE_N_NULL(key_p_list_p);
    }
    if (data_p_list_p) {
        CL_FREE_N_NULL(data_p_list_p);
    }
    if (rules_list_p) {
        CL_FREE_N_NULL(rules_list_p);
    }
    return sx_status;
}

sx_status_t hwd_decap_table_bind_acl(sx_port_log_id_t nve_port, sx_acl_id_t acl_group_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(nve_port) != SX_PORT_TYPE_TUNNEL) {
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (acl_group_id == FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    sx_status = decap_table_db_bind_acl(nve_port, acl_group_id);
    if (SX_STATUS_ENTRY_ALREADY_BOUND == sx_status) {
        SX_LOG_DBG("The same acl group %d is already bound.\n", acl_group_id);
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    }
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to bind acl %u to nve port 0x%08x in db.\n", acl_group_id, nve_port);
        goto out;
    }

    sx_status = __decap_table_bind_acl_rules(nve_port, acl_group_id);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to bind acl %u to nve port 0x%08x.\n", acl_group_id, nve_port);
        goto out;
    }

out:
    return sx_status;
}

sx_status_t hwd_decap_table_unbind_acl(sx_port_log_id_t nve_port)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (FALSE == g_is_initialized) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(nve_port) != SX_PORT_TYPE_TUNNEL) {
        SX_LOG_DBG("Failure - %s.\n", sx_status_str(sx_status));
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    sx_status = __decap_table_bind_acl_rules(nve_port, FLEX_ACL_INVALID_ACL_ID);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to unbind acl from nve port 0x%08x\n", nve_port);
        goto out;
    }

    sx_status = decap_table_db_unbind_acl(nve_port);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to unbind acl from nve port 0x%08x in db\n", nve_port);
        goto out;
    }

out:
    return sx_status;
}

sx_status_t hwd_decap_table_assign_ops(hwi_decap_table_ops_t* valid_operations)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(valid_operations, "valid_operations")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    valid_operations->hwd_decap_table_init_pfn = hwd_decap_table_init;
    valid_operations->hwd_decap_table_deinit_pfn = hwd_decap_table_deinit;
    valid_operations->hwd_decap_table_add_entry_pfn = hwd_decap_table_add_entry;
    valid_operations->hwd_decap_table_delete_entry_pfn = hwd_decap_table_delete_entry;
    valid_operations->hwd_decap_table_edit_entry_pfn = hwd_decap_table_edit_entry;
    valid_operations->hwd_decap_table_dbg_generate_dump_pfn = hwd_decap_table_dbg_generate_dump;
    valid_operations->hwd_decap_table_get_entry_pfn = hwd_decap_table_get_entry;
    valid_operations->hwd_decap_table_bind_acl_pfn = hwd_decap_table_bind_acl;
    valid_operations->hwd_decap_table_unbind_acl_pfn = hwd_decap_table_unbind_acl;
    valid_operations->hwd_decap_table_iter_get_pfn = hwd_decap_table_rule_iter_get;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_decap_table_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    psort_handle_t  psort_handle;
    sx_ip_version_t ip_version = SX_IP_VERSION_NONE;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

#ifdef _DEBUG_
    sx_status = decap_table_db_integrity_verification();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Decap Table DB is corrupted\n");
    }
#endif

    dbg_utils_pprinter_general_header_print(dbg_dump_params_p->stream, "Decap Table Structure");

    for (ip_version = SX_IP_VERSION_IPV4; ip_version < SX_IP_VERSION_MAX; ip_version++) {
        decap_table_db_get_psort_handle(ip_version, &psort_handle);
        dbg_utils_pprinter_secondary_header_print(dbg_dump_params_p->stream, "ip version %d", ip_version);
        psort_debug_dump(psort_handle, dbg_dump_params_p->stream);
    }

    sx_status = decap_table_db_dump_index_map(dbg_dump_params_p);

out:
    return sx_status;
}

static sx_status_t __hwd_decap_table_rm_entries_check(sx_ip_version_t ip_version,
                                                      sx_access_cmd_t access_cmd,
                                                      uint32_t        num_of_entries)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         client = SYSTEM_ACL_CLIENT_ID_INVALID_E;
    rm_sdk_table_params_t            params;
    system_acl_client_table_entry_t *client_table_entry_p = NULL;
    rm_sdk_table_type_e              resource;

    resource =
        (ip_version ==
         SX_IP_VERSION_IPV4 ? RM_SDK_TABLE_TYPE_DECAP_RULES_IPV4_E : RM_SDK_TABLE_TYPE_DECAP_RULES_IPV6_E);


    if (access_cmd == SX_ACCESS_CMD_ADD) {
        client = IP_VERSION_TO_ACL_CLIENT(ip_version);

        err = system_acl_client_get_by_id(client, &client_table_entry_p);
        if ((err != SX_STATUS_SUCCESS) || (client_table_entry_p == NULL)) {
            SX_LOG_ERR("ACL : cannot find system ACL entry for client[%u]\n", client);
            goto out;
        }

        params.attrs.acl_attr.is_ctcam = TRUE;

        err = rm_allocate_entries_check(resource,
                                        access_cmd, num_of_entries, &params);
    } else {
        err = rm_allocate_entries_check(resource,
                                        access_cmd, num_of_entries, NULL);
    }
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to check RM with %d entries, CMD=[%s], err=[%s]\n",
                   num_of_entries, sx_access_cmd_str(access_cmd), sx_status_str(err));
        goto out;
    }
out:
    return err;
}


static sx_status_t __hwd_decap_table_rm_entries_update(sx_ip_version_t ip_version,
                                                       sx_access_cmd_t access_cmd,
                                                       uint32_t        num_of_entries)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    uint32_t                         client = SYSTEM_ACL_CLIENT_ID_INVALID_E;
    rm_sdk_table_params_t            params;
    system_acl_client_table_entry_t *client_table_entry_p = NULL;
    rm_sdk_table_type_e              resource;

    resource =
        (ip_version ==
         SX_IP_VERSION_IPV4 ? RM_SDK_TABLE_TYPE_DECAP_RULES_IPV4_E : RM_SDK_TABLE_TYPE_DECAP_RULES_IPV6_E);


    if (access_cmd == SX_ACCESS_CMD_ADD) {
        client = IP_VERSION_TO_ACL_CLIENT(ip_version);

        err = system_acl_client_get_by_id(client, &client_table_entry_p);
        if ((err != SX_STATUS_SUCCESS) || (client_table_entry_p == NULL)) {
            SX_LOG_ERR("ACL : cannot find system ACL entry for client[%u]\n", client);
            goto out;
        }

        params.attrs.acl_attr.is_ctcam = TRUE;
        err = rm_allocate_entries_update(resource,
                                         access_cmd, num_of_entries,  &params);
    } else {
        err = rm_allocate_entries_update(resource,
                                         access_cmd, num_of_entries,  NULL);
    }
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to update RM with %d entries, CMD=[%s], err=[%s]\n",
                   num_of_entries, sx_access_cmd_str(access_cmd), sx_status_str(err));
        goto out;
    }
out:
    return err;
}

static sx_status_t __hwd_decap_rm_entries_set(sx_ip_version_t ip_version,
                                              sx_access_cmd_t access_cmd,
                                              uint32_t        num_of_entries,
                                              boolean_t       is_system)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    rm_sdk_table_type_e resource;

    resource =
        (ip_version ==
         SX_IP_VERSION_IPV4 ? RM_SDK_TABLE_TYPE_DECAP_RULES_IPV4_E : RM_SDK_TABLE_TYPE_DECAP_RULES_IPV6_E);

    if (is_system) {
        err = rm_system_entries_set(resource, access_cmd, num_of_entries, NULL);
    } else {
        err = rm_entries_set(resource, access_cmd, num_of_entries, NULL);
    }

    return err;
}

static sx_ip_version_t __hwd_decap_table_tunnel_type_to_ip_version(sx_tunnel_type_e type)
{
    sx_ip_version_t ip_version = SX_IP_VERSION_NONE;

    switch (type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        ip_version = SX_IP_VERSION_IPV6;
        break;

    default:
        ip_version = SX_IP_VERSION_IPV4;
        break;
    }

    return ip_version;
}
