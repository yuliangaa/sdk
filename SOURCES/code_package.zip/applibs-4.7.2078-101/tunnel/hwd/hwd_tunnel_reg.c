/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/utils/sx_utils_status.h>
#include <stdio.h>
#include <string.h>
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/sx_mem.h"
#include <complib/cl_mem.h>

#include "sx/sdk/sx_status_convertor.h"
#include "resource_manager/resource_manager_sdk_table.h"
#include "include/resource_manager/resource_manager.h"

#include "hwd_tunnel_reg.h"
#include "hwd_tunnel.h"
#include "ethl2/port.h"
#include "ethl2/lag.h"
#include "ethl2/fdb.h"
#include "ethl2/fdb_common.h"
#include "ethl3/common/router_utils.h"
#include "issu/issu.h"

#include "sx_reg_bulk/sx_reg_bulk.h"
#include <sx/sxd/sxd_registers.h>

#undef __MODULE__
#define __MODULE__ TUNNEL

#define TUNNEL_IPIP_TTLC_DEFAULT    SXD_TIGCR_TTLC_COPY_FROM_PKT
#define TUNNEL_ENC_SET_DSCP_DEFAULT SXD_TUNNEL_ENC_DSCP_COPY
#define TUNNEL_ENC_SET_SP_DEFAULT   SXD_TUNNEL_ENC_SP_PRESERVE
#define TUNNEL_ENC_DSCP_RW_DEFAULT  SXD_TUNNEL_DSCP_RW_PRESERVE
#define TUNNEL_ENC_PCP_RW_DEFAULT   SXD_TUNNEL_PCP_RW_PRESERVE
#define TUNNEL_DEC_SET_DSCP_DEFAULT SXD_TUNNEL_DEC_DSCP_COPY
#define TUNNEL_DEC_SET_SP_DEFAULT   SXD_TUNNEL_DEC_SP_PRESERVE
#define TUNNEL_DEC_SET_PCP_DEFAULT  SXD_TUNNEL_DEC_PCP_COPY
#define TUNNEL_DEC_DSCP_RW_DEFAULT  SXD_TUNNEL_DSCP_RW_PRESERVE
#define TUNNEL_DEC_PCP_RW_DEFAULT   SXD_TUNNEL_PCP_RW_PRESERVE

#define TUNNEL_RTDP_TYPE_CHECK_DEFAULT       7 /* Set all Bit0 Bit1 Bit2 by default */
#define TUNNEL_NVE_GS_FLOOD_DEFAULT_DISABLED 1
#define TUNNEL_NVE_GS_MC_DEFAULT_DISABLED    1
#define TUNNEL_NVE_UDP_DPORT_DEFAULT         4789

#define RTDP_TUNNEL_TYPE_DECAP_DISABLE_MASK     0x0F
#define RTDP_TUNNEL_TYPE_VXLAN_DECAP_ENABLE     0
#define RTDP_TUNNEL_TYPE_VXLAN_GPE_DECAP_ENABLE 1
#define RTDP_TUNNEL_TYPE_GENEVE_DECAP_ENABLE    2
#define RTDP_TUNNEL_TYPE_NVGRE_DECAP_ENABLE     3

#define RTDP_TUNNEL_TYPE_L3_DECAP_ENABLE   0
#define RTDP_TUNNEL_TYPE_MPLS_DECAP_ENABLE 1
#define RTDP_TUNNEL_TYPE_L2_DECAP_ENABLE   2

#define TNPC_LOOPBACK_ALLOWED_ALL_PORTS 0x0F

#define HWD_TUNNEL_REG_IS_IPV6_USIP_NULL(ipv6_usip) \
    (((ipv6_usip)[0] == 0) && ((ipv6_usip)[1] == 0) && ((ipv6_usip)[2] == 0) && ((ipv6_usip)[3] == 0))


typedef struct hwd_tunnel_reg_internal_callbacks {
    sx_status_t (*hwd_tunnel_tngcr_reg_write_pfn)(struct ku_tngcr_reg *ku_tngcr);
    void (*hwd_tunnel_tngcr_reg_reserved_bits_set_pfn)(struct ku_tngcr_reg *ku_tngcr,
                                                       boolean_t            dis_nve_opt_chk,
                                                       uint64_t             hdr_bits);
    void (*hwd_tunnel_tngcr_to_reserved_bits_unpack_pfn)(struct ku_tngcr_reg *ku_tngcr,
                                                         boolean_t           *dis_nve_opt_chk_p,
                                                         uint64_t            *hdr_bits_p);
} hwd_tunnel_reg_internal_callbacks_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static hwd_tunnel_reg_internal_callbacks_t g_hwd_tunnel_reg_internal_callbacks;
static sx_status_t __hwd_tunnel_tngcr_reg_write_uvrid(struct ku_tngcr_reg *ku_tngcr_p);
static sx_status_t __hwd_tunnel_tngcr_reg_write_urif(struct ku_tngcr_reg *ku_tngcr_p);
static void __hwd_tunnel_tngcr_reg_reserved_bits_set_spectrum(struct ku_tngcr_reg *ku_tngcr_p,
                                                              boolean_t            dis_nve_opt_chk,
                                                              uint64_t             hdr_bits);
static void __hwd_tunnel_tngcr_reg_reserved_bits_set_spectrum4(struct ku_tngcr_reg *ku_tngcr_p,
                                                               boolean_t            dis_nve_opt_chk,
                                                               uint64_t             hdr_bits);
static void __hwd_tunnel_tngcr_to_reserved_bits_unpack_spectrum(struct ku_tngcr_reg *ku_tngcr,
                                                                boolean_t           *dis_nve_opt_chk_p,
                                                                uint64_t            *hdr_bits_p);
static void __hwd_tunnel_tngcr_to_reserved_bits_unpack_spectrum4(struct ku_tngcr_reg *ku_tngcr,
                                                                 boolean_t           *dis_nve_opt_chk_p,
                                                                 uint64_t            *hdr_bits_p);

/* Callbacks for SPC */
static hwd_tunnel_reg_internal_callbacks_t g_hwd_tunnel_reg_internal_callbacks_uvrid = {
    .hwd_tunnel_tngcr_reg_write_pfn = __hwd_tunnel_tngcr_reg_write_uvrid,
    .hwd_tunnel_tngcr_reg_reserved_bits_set_pfn = __hwd_tunnel_tngcr_reg_reserved_bits_set_spectrum,
    .hwd_tunnel_tngcr_to_reserved_bits_unpack_pfn = __hwd_tunnel_tngcr_to_reserved_bits_unpack_spectrum,
};
/* Callbacks for SPC 2 */
static hwd_tunnel_reg_internal_callbacks_t g_hwd_tunnel_reg_internal_callbacks_urif = {
    .hwd_tunnel_tngcr_reg_write_pfn = __hwd_tunnel_tngcr_reg_write_urif,
    .hwd_tunnel_tngcr_reg_reserved_bits_set_pfn = __hwd_tunnel_tngcr_reg_reserved_bits_set_spectrum,
    .hwd_tunnel_tngcr_to_reserved_bits_unpack_pfn = __hwd_tunnel_tngcr_to_reserved_bits_unpack_spectrum,
};
/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __hwd_tunnel_tngcr_reg_write(struct ku_tngcr_reg *ku_tngcr);

sx_status_t hwd_tunnel_reg_urif_internal_callbacks_register()
{
    g_hwd_tunnel_reg_internal_callbacks = g_hwd_tunnel_reg_internal_callbacks_urif;
    return SX_STATUS_SUCCESS;
}

sx_status_t hwd_tunnel_reg_urif_internal_callbacks_register_spectrum4()
{
    g_hwd_tunnel_reg_internal_callbacks = g_hwd_tunnel_reg_internal_callbacks_urif;
    g_hwd_tunnel_reg_internal_callbacks.hwd_tunnel_tngcr_reg_reserved_bits_set_pfn =
        __hwd_tunnel_tngcr_reg_reserved_bits_set_spectrum4;
    g_hwd_tunnel_reg_internal_callbacks.hwd_tunnel_tngcr_to_reserved_bits_unpack_pfn =
        __hwd_tunnel_tngcr_to_reserved_bits_unpack_spectrum4;
    return SX_STATUS_SUCCESS;
}

sx_status_t hwd_tunnel_reg_uvrid_internal_callbacks_register()
{
    g_hwd_tunnel_reg_internal_callbacks = g_hwd_tunnel_reg_internal_callbacks_uvrid;
    return SX_STATUS_SUCCESS;
}

static sx_status_t __tunnel_init_tigcr(const sx_tunnel_general_params_t *tunnel_general_params_p,
                                       hwd_tunnel_global_config_t       *tunnel_global_params_p)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    hwd_tigcr_t   *tigcr_cfg = &tunnel_global_params_p->tigcr_config;
    sx_boot_mode_e boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_MEM_CLR_P(tigcr_cfg);

    SX_LOG_ENTER();

    sx_status = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get boot mode, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    tigcr_cfg->ku_tigcr.ipip_ttlc = TUNNEL_IPIP_TTLC_DEFAULT;
    tigcr_cfg->ku_tigcr.ipip_flh = SXD_TUNNEL_FLH_NO_LABEL;
    tigcr_cfg->ku_tigcr.ipip_gre_key_for_hash = tunnel_general_params_p->ipinip.encap_gre_hash;

    if (boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
        sx_status = hwd_tunnel_tigcr_reg_write(SXD_ACCESS_CMD_SET, &tigcr_cfg->ku_tigcr);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
static sx_status_t __tunnel_deinit_tngcr(hwd_tunnel_global_config_t *tunnel_global_params_p)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    hwd_tngcr_t   *tngcr_cfg = &tunnel_global_params_p->tngcr_config;
    sx_boot_mode_e boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_LOG_ENTER();

    sx_status = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get boot mode, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
        tngcr_cfg->ku_tngcr.nve_valid = FALSE;
        sx_status = hwd_tunnel_tngcr_reg_write(&tngcr_cfg->ku_tngcr);
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_init_tngcr(hwd_tunnel_global_config_t *tunnel_global_params_p)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    hwd_tngcr_t   *tngcr_cfg = &tunnel_global_params_p->tngcr_config;
    sx_boot_mode_e boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_MEM_CLR_P(tngcr_cfg);

    SX_LOG_ENTER();

    sx_status = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get boot mode, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    tngcr_cfg->ku_tngcr.nve_valid = TRUE;
    tngcr_cfg->ku_tngcr.nve_flh = SXD_TUNNEL_FLH_NO_LABEL;
    tngcr_cfg->ku_tngcr.nve_udp_sport_type = SXD_TUNNEL_SPORT_SET_FIX_BITS_E;
    tngcr_cfg->ku_tngcr.nve_udp_sport_prefix = 0;
    tngcr_cfg->ku_tngcr.nve_ttl_uc = TUNNEL_NVE_UC_TTL_DEFAULT;
    tngcr_cfg->ku_tngcr.nve_ttl_mc = TUNNEL_NVE_UC_TTL_DEFAULT;
    tngcr_cfg->ku_tngcr.et_vlan = TUNNEL_NVE_VLAN_DECAP_ETH_TYPE_INDEX_DEFAULT;
    if (tunnel_global_params_p->general_params.nve.flood_ecmp_enabled) {
        if (tunnel_global_params_p->general_params.nve.ecmp_max_size != 0) {
            tngcr_cfg->ku_tngcr.nve_group_size_flood = tunnel_global_params_p->general_params.nve.ecmp_max_size;
        } else {
            tngcr_cfg->ku_tngcr.nve_group_size_flood = TUNNEL_NVE_GS_FLOOD_DEFAULT_ENABLED;
        }
    } else {
        tngcr_cfg->ku_tngcr.nve_group_size_flood = TUNNEL_NVE_GS_FLOOD_DEFAULT_DISABLED;
    }
    if (tunnel_global_params_p->general_params.nve.mc_ecmp_enabled) {
        if (tunnel_global_params_p->general_params.nve.ecmp_max_size != 0) {
            tngcr_cfg->ku_tngcr.nve_group_size_mc = tunnel_global_params_p->general_params.nve.ecmp_max_size;
        } else {
            tngcr_cfg->ku_tngcr.nve_group_size_mc = TUNNEL_NVE_GS_MC_DEFAULT_ENABLED;
        }
    } else {
        tngcr_cfg->ku_tngcr.nve_group_size_mc = TUNNEL_NVE_GS_MC_DEFAULT_DISABLED;
    }

    tngcr_cfg->ku_tngcr.dis_nve_opt_chk = 0;
    tngcr_cfg->ku_tngcr.nvgre_hdr_bits_en = 0;
    tngcr_cfg->ku_tngcr.geneve_hdr_bits_en = 0;
    tngcr_cfg->ku_tngcr.gpe_hdr_bits_en = 0;
    tngcr_cfg->ku_tngcr.vxlan_hdr_bits_en = 0;
    tngcr_cfg->ku_tngcr.vxlan_hdr_bits = 0;
    tngcr_cfg->ku_tngcr.gpe_hdr_bits = 0;
    tngcr_cfg->ku_tngcr.geneve_hdr_bits = 0;
    tngcr_cfg->ku_tngcr.nvgre_hdr_bits = 0;

    if (boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
        sx_status = hwd_tunnel_tngcr_reg_write(&tngcr_cfg->ku_tngcr);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_init_tiqcr()
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    struct ku_tiqcr_reg ku_tiqcr;

    SX_MEM_CLR(ku_tiqcr);

    SX_LOG_ENTER();

    ku_tiqcr.enc_set_dscp = TUNNEL_ENC_SET_DSCP_DEFAULT;
    ku_tiqcr.enc_set_sp = TUNNEL_ENC_SET_SP_DEFAULT;
    ku_tiqcr.enc_dscp_rw = TUNNEL_ENC_DSCP_RW_DEFAULT;
    ku_tiqcr.enc_pcp_rw = TUNNEL_ENC_PCP_RW_DEFAULT;
    ku_tiqcr.dec_set_dscp = TUNNEL_DEC_SET_DSCP_DEFAULT;
    ku_tiqcr.dec_set_sp = TUNNEL_DEC_SET_SP_DEFAULT;
    ku_tiqcr.dec_dscp_rw = TUNNEL_DEC_DSCP_RW_DEFAULT;
    ku_tiqcr.dec_pcp_rw = TUNNEL_DEC_PCP_RW_DEFAULT;

    sx_status = hwd_tunnel_tiqcr_reg_write(SXD_ACCESS_CMD_SET, &ku_tiqcr);

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_init_tnqcr()
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    struct ku_tnqcr_reg ku_tnqcr;

    SX_MEM_CLR(ku_tnqcr);

    SX_LOG_ENTER();

    ku_tnqcr.enc_set_dscp = TUNNEL_ENC_SET_DSCP_DEFAULT;
    ku_tnqcr.enc_set_sp = TUNNEL_ENC_SET_SP_DEFAULT;
    ku_tnqcr.enc_dscp_rw = TUNNEL_ENC_DSCP_RW_DEFAULT;
    ku_tnqcr.enc_pcp_rw = TUNNEL_ENC_PCP_RW_DEFAULT;
    ku_tnqcr.dec_set_dscp = TUNNEL_DEC_SET_DSCP_DEFAULT;
    ku_tnqcr.dec_set_sp = TUNNEL_DEC_SET_SP_DEFAULT;
    ku_tnqcr.dec_set_pcp = TUNNEL_DEC_SET_PCP_DEFAULT;
    ku_tnqcr.dec_dscp_rw = TUNNEL_DEC_DSCP_RW_DEFAULT;
    ku_tnqcr.dec_pcp_rw = TUNNEL_DEC_PCP_RW_DEFAULT;

    sx_status = hwd_tunnel_tnqcr_reg_write(SXD_ACCESS_CMD_SET, &ku_tnqcr);

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_tncr_clear(sx_port_tunnel_phy_id_t phy_tunnel_port)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    struct ku_tncr_reg ku_tncr;

    UNUSED_PARAM(phy_tunnel_port);

    SX_MEM_CLR(ku_tncr);

    SX_LOG_ENTER();

    ku_tncr.clear_counters = 1;

    sx_status = hwd_tunnel_tncr_reg_write(SXD_ACCESS_CMD_GET, &ku_tncr);

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_tncr_v2_clear(sx_port_tunnel_phy_id_t phy_tunnel_port)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    struct ku_tncr_v2_reg ku_tncr_v2;

    SX_MEM_CLR(ku_tncr_v2);

    SX_LOG_ENTER();

    ku_tncr_v2.clear_counters = 1;
    ku_tncr_v2.tunnel_port = phy_tunnel_port;

    sx_status = hwd_tunnel_tncr_v2_reg_write(SXD_ACCESS_CMD_GET, &ku_tncr_v2);

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_init_tieem(hwd_tunnel_cos_global_attr_t *cos_attr)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    uint32_t            i = SX_COS_ECN_TYPE_MIN_E;
    struct ku_tieem_reg ku_tieem;

    SX_LOG_ENTER();

    for (i = SX_COS_ECN_TYPE_MIN_E; i <= SX_COS_ECN_TYPE_MAX_E; i++) {
        SX_MEM_CLR(ku_tieem);
        ku_tieem.overlay_ecn = i;
        ku_tieem.underlay_ecn =
            cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_IPINIP_E].encap_cos_data.cos_ecn_params.ecn_encap.ecn_encap_map[i].
            egress_ecn;
        sx_status = hwd_tunnel_tieem_reg_write(SXD_ACCESS_CMD_SET, &ku_tieem);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to set TIEEM REG for overlay ecn [%u].\n", i);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_init_tidem(hwd_tunnel_cos_global_attr_t *cos_attr)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    uint32_t            i = SX_COS_ECN_TYPE_MIN_E;
    uint32_t            j = SX_COS_ECN_TYPE_MIN_E;
    struct ku_tidem_reg ku_tidem;

    SX_LOG_ENTER();
    for (i = SX_COS_ECN_TYPE_MIN_E; i <= SX_COS_ECN_TYPE_MAX_E; i++) {
        for (j = SX_COS_ECN_TYPE_MIN_E; j <= SX_COS_ECN_TYPE_MAX_E; j++) {
            SX_MEM_CLR(ku_tidem);
            ku_tidem.overlay_ecn = i;
            ku_tidem.underlay_ecn = j;
            ku_tidem.eip_ecn =
                cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_IPINIP_E].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j
                ].egress_ecn;
            if (cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_IPINIP_E].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j
                ].trap_enable) {
                ku_tidem.trap_en =
                    cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_IPINIP_E].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[
                        i][j].trap_enable;
                ku_tidem.trap_id =
                    (cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_IPINIP_E].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map
                     [i][j].trap_attr.prio ==
                     SX_TRAP_PRIORITY_LOW) ?
                    SXD_TRAP_ID_DECAP_ECN0 : SXD_TRAP_ID_DECAP_ECN1;
            }
            sx_status = hwd_tunnel_tidem_reg_write(SXD_ACCESS_CMD_SET, &ku_tidem);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to set TIDEM REG for overlay ecn [%u], underlay ecn [%u].\n", i, j);
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_init_tneem(hwd_tunnel_cos_global_attr_t *cos_attr)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    uint32_t            i = SX_COS_ECN_TYPE_MIN_E;
    struct ku_tneem_reg ku_tneem;

    SX_LOG_ENTER();

    for (i = SX_COS_ECN_TYPE_MIN_E; i <= SX_COS_ECN_TYPE_MAX_E; i++) {
        SX_MEM_CLR(ku_tneem);
        ku_tneem.overlay_ecn = i;
        ku_tneem.underlay_ecn =
            cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_NVE_E].encap_cos_data.cos_ecn_params.ecn_encap.ecn_encap_map[i].
            egress_ecn;
        sx_status = hwd_tunnel_tneem_reg_write(SXD_ACCESS_CMD_SET, &ku_tneem);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to set TIEEM REG for overlay ecn [%u].\n", i);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_init_tndem(hwd_tunnel_cos_global_attr_t *cos_attr)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    uint32_t            i = SX_COS_ECN_TYPE_MIN_E;
    uint32_t            j = SX_COS_ECN_TYPE_MIN_E;
    struct ku_tndem_reg ku_tndem;

    SX_LOG_ENTER();
    for (i = SX_COS_ECN_TYPE_MIN_E; i <= SX_COS_ECN_TYPE_MAX_E; i++) {
        for (j = SX_COS_ECN_TYPE_MIN_E; j <= SX_COS_ECN_TYPE_MAX_E; j++) {
            SX_MEM_CLR(ku_tndem);
            ku_tndem.overlay_ecn = i;
            ku_tndem.underlay_ecn = j;
            ku_tndem.eip_ecn =
                cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_NVE_E].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].
                egress_ecn;
            if (cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_NVE_E].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][j].
                trap_enable) {
                ku_tndem.trap_en =
                    cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_NVE_E].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i][
                        j].trap_enable;
                ku_tndem.trap_id =
                    (cos_attr[SX_TUNNEL_QOS_TUNNEL_TYPE_NVE_E].decap_cos_data.cos_ecn_params.ecn_decap.ecn_decap_map[i]
                     [j].trap_attr.prio ==
                     SX_TRAP_PRIORITY_LOW) ?
                    SXD_TRAP_ID_DECAP_ECN0 : SXD_TRAP_ID_DECAP_ECN1;
            }
            sx_status = hwd_tunnel_tndem_reg_write(SXD_ACCESS_CMD_SET, &ku_tndem);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to set TNDEM REG for overlay ecn [%u], underlay ecn [%u].\n", i, j);
                goto out;
            }
        }
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t hwd_tunnel_reg_log_verbosity_level_set(sx_verbosity_level_t verbosity)
{
    SX_LOG_ENTER();

    LOG_VAR_NAME(__MODULE__) = verbosity;

    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}

sx_status_t hwd_tunnel_write_rtdp_to_dev(hwd_rtdp_t *db_elem_p, const void *params_p)
{
    sx_dev_id_t   *dev_id = (sx_dev_id_t*)params_p;
    sxd_status_t   sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);

    SX_LOG(SX_LOG_DEBUG, "HWD tunnel, Write RTDP to dev ID %u\n", *dev_id);

    reg_meta.dev_id = *dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RTDP_E, &db_elem_p->ku_rtdp, &reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to RTDP set: [%s].\n", SXD_STATUS_MSG(sxd_status));

        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_default_registers_write(hwd_tunnel_global_config_t *tunnel_global_params_p)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sx_boot_mode_e boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_LOG_ENTER();
    SX_LOG_DBG("Init tunnel registers.\n");

    sx_status = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get boot mode, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(tunnel_global_params_p,
                                                      "tunnel_global_params_p"))) {
        goto out;
    }

    sx_status = __tunnel_init_tngcr(tunnel_global_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    sx_status = __tunnel_init_tigcr(&tunnel_global_params_p->general_params,
                                    tunnel_global_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    if (boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
        sx_status = __tunnel_init_tiqcr();
        if (SX_CHECK_FAIL(sx_status)) {
            goto out;
        }

        sx_status = __tunnel_init_tnqcr();
        if (SX_CHECK_FAIL(sx_status)) {
            goto out;
        }

        sx_status = __tunnel_init_tieem(tunnel_global_params_p->cos_attr);
        if (SX_CHECK_FAIL(sx_status)) {
            goto out;
        }

        sx_status = __tunnel_init_tidem(tunnel_global_params_p->cos_attr);
        if (SX_CHECK_FAIL(sx_status)) {
            goto out;
        }

        sx_status = __tunnel_init_tneem(tunnel_global_params_p->cos_attr);
        if (SX_CHECK_FAIL(sx_status)) {
            goto out;
        }
        sx_status = __tunnel_init_tndem(tunnel_global_params_p->cos_attr);
        if (SX_CHECK_FAIL(sx_status)) {
            goto out;
        }
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to init tunnel registers.\n");
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_deinit_registers(hwd_tunnel_global_config_t *global_config_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Deinit tunnel registers.\n");

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(global_config_p,
                                                      "global_config_p"))) {
        goto out;
    }

    sx_status = hwd_tunnel_update_tngcr(global_config_p, NULL, 0, 0, FALSE, FALSE,
                                        TUNNEL_NVE_VLAN_DECAP_ETH_TYPE_INDEX_DEFAULT, FALSE, 0);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }


out:
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to deinit tunnel registers.\n");
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_update_tngcr(hwd_tunnel_global_config_t             *global_config_p,
                                    const sx_tunnel_nve_encap_attributes_t *nve_encap_p,
                                    hwd_rif_id_t                            underlay_rif,
                                    sxd_tunnel_nve_type_t                   type,
                                    boolean_t                               is_valid,
                                    boolean_t                               learn_enable,
                                    uint8_t                                 et_vlan,
                                    boolean_t                               dis_nve_opt_chk,
                                    uint64_t                                hdr_bits)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    struct ku_tngcr_reg ku_tngcr_bcp;
    hwd_tngcr_t        *tngcr_cfg = NULL;
    sx_ip_addr_t        old_ul_sip;
    boolean_t           is_old_ul_sip_null = FALSE;
    sx_boot_mode_e      boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_MEM_CLR(old_ul_sip);

    SX_LOG_ENTER();
    SX_LOG_DBG("Update TNGCR reg.\n");

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(global_config_p,
                                                      "global_config_p"))) {
        goto out;
    }

    tngcr_cfg = &global_config_p->tngcr_config;
    SX_MEM_CPY(ku_tngcr_bcp, tngcr_cfg->ku_tngcr);

    if (is_valid) {
        tngcr_cfg->ku_tngcr.nve_valid = is_valid;
        tngcr_cfg->ku_tngcr.type = type;
        tngcr_cfg->ku_tngcr.learn_enable = learn_enable;

        g_hwd_tunnel_reg_internal_callbacks.hwd_tunnel_tngcr_reg_reserved_bits_set_pfn(&tngcr_cfg->ku_tngcr,
                                                                                       dis_nve_opt_chk,
                                                                                       hdr_bits);

        if (nve_encap_p) {
            tngcr_cfg->ku_tngcr.underlay_virtual_router = nve_encap_p->underlay_vrid;
            tngcr_cfg->ku_tngcr.underlay_rif = underlay_rif;
            switch (nve_encap_p->underlay_sip.version) {
            case SX_IP_VERSION_IPV4:
                sdk_router_utils_assign_ip(&tngcr_cfg->ku_tngcr.usipv4, &nve_encap_p->underlay_sip);
                SX_MEM_CLR_ARRAY(tngcr_cfg->ku_tngcr.usipv6, IPV6_SIZE_IN_DWORD, uint32_t);
                break;

            case SX_IP_VERSION_IPV6:
                SX_MEM_CLR_TYPE(&tngcr_cfg->ku_tngcr.usipv4, uint32_t);

                is_old_ul_sip_null = HWD_TUNNEL_REG_IS_IPV6_USIP_NULL(tngcr_cfg->ku_tngcr.usipv6);

                if (FALSE == is_old_ul_sip_null) {
                    old_ul_sip.version = SX_IP_VERSION_IPV6;
                    SX_MEM_CPY_ARRAY(old_ul_sip.addr.ipv6.s6_addr32,
                                     tngcr_cfg->ku_tngcr.usipv6,
                                     IPV6_SIZE_IN_DWORD, uint32_t);

                    if (0 != sdk_router_utils_compare_ip_address(&old_ul_sip,
                                                                 &nve_encap_p->underlay_sip)) {
                        tngcr_cfg->ku_tngcr.nve_valid = TRUE;
                    }
                }

                sdk_router_utils_assign_ip(tngcr_cfg->ku_tngcr.usipv6, &nve_encap_p->underlay_sip);
                break;

            default:
                sx_status = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        tngcr_cfg->ku_tngcr.learn_enable = learn_enable;
        tngcr_cfg->ku_tngcr.et_vlan = et_vlan;

        sx_status = issu_boot_mode_get(&boot_mode);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get boot mode, err = %s.\n", sx_status_str(sx_status));
            goto out;
        }

        if (boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
            sx_status = hwd_tunnel_tngcr_reg_write(&tngcr_cfg->ku_tngcr);
        }
    } else {
        sx_status = __tunnel_deinit_tngcr(global_config_p);
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update TNGCR REG, err = %s.\n", sx_status_str(sx_status));
        if (NULL != global_config_p) {
            SX_MEM_CPY(global_config_p->tngcr_config.ku_tngcr, ku_tngcr_bcp);
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_update_tnpc(uint8_t tunnel_port, boolean_t learn_enable, boolean_t filter_enable)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_boot_mode_e     boot_mode = SX_BOOT_MODE_DISABLED_E;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    uint32_t           lb_tx_uc_tunnel_port = 0;
    struct ku_tnpc_reg tnpc_reg_data;
    sxd_reg_meta_t     reg_meta;

    SX_LOG_ENTER();

    sx_status = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get boot mode, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        goto out;
    }

    SX_MEM_CLR(tnpc_reg_data);
    SX_MEM_CLR(reg_meta);

    reg_meta.dev_id = 1;
    reg_meta.swid = 0;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    tnpc_reg_data.learn_enable_v4 = learn_enable;

    /* Enable or disable only the bit relevant to this TPORT */
    lb_tx_uc_tunnel_port = (TNPC_LOOPBACK_ALLOWED_ALL_PORTS ^ (1 << tunnel_port)) | (filter_enable << tunnel_port);
    tnpc_reg_data.lb_tx_uc_tunnel_port = lb_tx_uc_tunnel_port;
    tnpc_reg_data.tunnel_port = tunnel_port;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNPC_E,
                                                     &tnpc_reg_data,
                                                     &reg_meta,
                                                     1,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("The TNPC register with the SET command fail: [%s]\n", SXD_STATUS_MSG(sxd_status));
    }

out:
    SX_LOG_EXIT();
    return sxd_status_to_sx_status(sxd_status);
}


uint8_t hwd_tunnel_nve_decap_disable_get(sx_tunnel_type_e type)
{
    uint8_t mask = 0x01;

    switch (type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        mask = mask << RTDP_TUNNEL_TYPE_VXLAN_DECAP_ENABLE;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        mask = mask << RTDP_TUNNEL_TYPE_VXLAN_GPE_DECAP_ENABLE;
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        mask = mask << RTDP_TUNNEL_TYPE_GENEVE_DECAP_ENABLE;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        mask = mask << RTDP_TUNNEL_TYPE_NVGRE_DECAP_ENABLE;
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        break;
    }
    mask = ~mask;
    mask = mask & RTDP_TUNNEL_TYPE_DECAP_DISABLE_MASK;
    return mask;
}

sx_status_t hwd_tunnel_rtdp_prepare(const sx_tunnel_attribute_t     *tunnel_attr_p,
                                    hwd_rif_id_t                     overlay_rif,
                                    hwd_rif_id_t                     underlay_rif,
                                    const kvd_linear_manager_index_t rtdp_index,
                                    hwd_rtdp_t                      *hwd_rtdp_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(tunnel_attr_p,
                                                      "tunnel_attr_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(hwd_rtdp_p,
                                                      "hwd_rtdp_p"))) {
        goto out;
    }

    SX_MEM_CLR_P(hwd_rtdp_p);

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
        hwd_rtdp_p->ku_rtdp.type = SXD_RTDP_TYPE_IPINIP_E;
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_ipinip.irif = overlay_rif;
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_ipinip.gre_key_check = 0;
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_ipinip.type_check = TUNNEL_RTDP_TYPE_CHECK_DEFAULT;
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        hwd_rtdp_p->ku_rtdp.type = SXD_RTDP_TYPE_IPINIP_E;
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_ipinip.irif = overlay_rif;
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_ipinip.gre_key_check =
            tunnel_attr_p->attributes.ipinip_p2p_gre.decap.gre_check_key;
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_ipinip.expected_gre_key =
            tunnel_attr_p->attributes.ipinip_p2p_gre.decap.gre_expected_key;
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_ipinip.type_check = TUNNEL_RTDP_TYPE_CHECK_DEFAULT;
        break;

    /* NVE Tunnels */
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
    case SX_TUNNEL_TYPE_NVE_GENEVE:
    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        hwd_rtdp_p->ku_rtdp.type = SXD_RTDP_TYPE_NVE_E;
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_nve_decap.decap_disable = hwd_tunnel_nve_decap_disable_get(
            tunnel_attr_p->type);
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        hwd_rtdp_p->ku_rtdp.type = SXD_RTDP_TYPE_GENERIC_DECAP_E;
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_generic.allow_decap = (1 << RTDP_TUNNEL_TYPE_L2_DECAP_ENABLE);
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_generic.tunnel_port = SX_PORT_PHY_ID_GET(
            tunnel_attr_p->attributes.l2_flex.log_port);
        hwd_rtdp_p->ku_rtdp.rtdp_entry.rtdp_generic.tqos_profile_l2 =
            tunnel_attr_p->attributes.l2_flex.tunnel_qos_profile.profile_id;
        break;
    }

    hwd_rtdp_p->ku_rtdp.tunnel_index = (uint32_t)rtdp_index;
    hwd_rtdp_p->ku_rtdp.egress_router_interface = underlay_rif;
out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_tncr_get(boolean_t is_clear, struct ku_tncr_reg ** ku_tncr, uint32_t *size)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tncr_reg tncr_reg_data[SX_DEVICE_ID_COUNT];
    uint8_t            clear_counters = 0;

    SX_LOG_ENTER();

    M_UTILS_CLR_MEM_GET(ku_tncr,
                        SX_DEVICE_ID_COUNT,
                        sizeof(struct ku_tncr_reg),
                        UTILS_MEM_TYPE_ID_TUNNEL_E,
                        "tncr reg",
                        sx_status);

    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot allocate space for TNCR counters.\n");
        goto out;
    }

    /* Get list of LEAF devices */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Cannot retrieve device list, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (TRUE == is_clear) {
        clear_counters = 1;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_GET;
    SX_MEM_CLR(tncr_reg_data[dev_idx]);
    tncr_reg_data[dev_idx].clear_counters = clear_counters;
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNCR_E,
                                                     tncr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get TNCR, err = %s.\n", SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    ku_tncr[dev_idx]->count_decap_discards_high = tncr_reg_data[dev_idx].count_decap_discards_high;
    ku_tncr[dev_idx]->count_decap_discards_low = tncr_reg_data[dev_idx].count_decap_discards_low;
    ku_tncr[dev_idx]->count_decap_errors_high = tncr_reg_data[dev_idx].count_decap_errors_high;
    ku_tncr[dev_idx]->count_decap_errors_low = tncr_reg_data[dev_idx].count_decap_errors_low;
    ku_tncr[dev_idx]->count_decap_high = tncr_reg_data[dev_idx].count_decap_high;
    ku_tncr[dev_idx]->count_decap_low = tncr_reg_data[dev_idx].count_decap_low;
    ku_tncr[dev_idx]->count_encap_high = tncr_reg_data[dev_idx].count_encap_high;
    ku_tncr[dev_idx]->count_encap_low = tncr_reg_data[dev_idx].count_encap_low;
    SX_FDB_FOR_EACH_LEAF_DEV_END;
    if (size) {
        *size = dev_info_arr_size;
    }

out:
    if (sx_status != SX_STATUS_SUCCESS) {
        if (*ku_tncr) {
            M_UTILS_MEM_PUT(*ku_tncr, UTILS_MEM_TYPE_ID_TUNNEL_E, "De-alloc of TNCR reg", sx_status);
            *ku_tncr = NULL;
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_tnifr_prepare(const sx_access_cmd_t         cmd,
                                     const sx_swid_t               swid,
                                     const sx_device_id_t          device_id,
                                     const sx_port_log_id_t        log_port,
                                     const sx_port_isolate_table_e isolation_table,
                                     const sx_port_log_id_t      * isolate_port_list,
                                     const uint32_t                log_port_num,
                                     struct ku_tnifr_v2_reg      * tnifr_v2_reg_data)
{
    sx_status_t       sx_status = SX_STATUS_SUCCESS;
    uint32_t          i = 0, j = 0, port_num = 0;
    uint8_t           value = 0;
    sx_port_phy_id_t  local_port = 0;
    sx_port_log_id_t *port_swid_list = NULL;
    sx_port_log_id_t *log_port_list = NULL;
    length_t          port_swid_num = 0;
    sx_lag_id_t       lag_id = 0;

#define PORT_FILTER_ARR_SIZE      (sizeof(tnifr_v2_reg_data->port_filter) / sizeof(tnifr_v2_reg_data->port_filter[0]))
#define PORT_FILTER_ARR_ELEM_BITS (sizeof(tnifr_v2_reg_data->port_filter[0]) * 8)
#define PORT_FILTER_UPDATE_ARR_SIZE                     \
    (sizeof(tnifr_v2_reg_data->port_filter_update_en) / \
     sizeof(tnifr_v2_reg_data->port_filter_update_en[0]))
#define PORT_FILTER_UPDATE_ARR_ELEM_BITS (sizeof(tnifr_v2_reg_data->port_filter_update_en[0]) * 8)

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(isolate_port_list,
                                                      "isolate_port_list"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(tnifr_v2_reg_data,
                                                      "tnifr_v2_reg_data"))) {
        goto out;
    }

    log_port_list = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);
    if (log_port_list == NULL) {
        SX_LOG_ERR("Failed to allocate memory\n");
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }

    memset(log_port_list, 0, sizeof(sx_port_log_id_t) * rm_resource_global.lag_port_members_max);

    tnifr_v2_reg_data->tunnel_port = SX_PORT_PHY_ID_GET(log_port);

    if ((SX_ACCESS_CMD_SET == cmd) || (SX_ACCESS_CMD_DELETE_ALL == cmd)) {
        if (SX_CHECK_FAIL(sx_status = port_swid_get(SX_ACCESS_CMD_COUNT, swid, NULL, &port_swid_num))) {
            SX_LOG_ERR("port_swid_get fails swid[%u]\n",
                       swid);
            goto out;
        }

        sx_status = utils_memory_get((void**)&port_swid_list,
                                     (sizeof(sx_port_log_id_t) * port_swid_num),
                                     UTILS_MEM_TYPE_ID_PORT_E);

        if (sx_status != SX_STATUS_SUCCESS) {
            sx_status = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory\n");
            goto out;
        }
        if (SX_CHECK_FAIL(sx_status = utils_check_pointer(port_swid_list,
                                                          "port_swid_list"))) {
            goto out;
        }
        /* getting list of log ports for swid */
        if (SX_CHECK_FAIL(sx_status = port_swid_get(SX_ACCESS_CMD_GET, swid, port_swid_list, &port_swid_num))) {
            SX_LOG_ERR("port_swid_get fails for swid[%u], err = %s\n", swid, sx_status_str(sx_status));
            goto out;
        }

        for (i = 0; i < port_swid_num; i++) {
            if (SX_PORT_DEV_ID_GET(port_swid_list[i]) == device_id) {
                local_port = SX_PORT_PHY_ID_GET(port_swid_list[i]);
                SXD_BITMAP_REVERSE_CLR(tnifr_v2_reg_data->port_filter,
                                       PORT_FILTER_ARR_SIZE,
                                       PORT_FILTER_ARR_ELEM_BITS,
                                       local_port);
                SXD_BITMAP_REVERSE_SET(tnifr_v2_reg_data->port_filter_update_en,
                                       PORT_FILTER_UPDATE_ARR_SIZE,
                                       PORT_FILTER_UPDATE_ARR_ELEM_BITS,
                                       local_port);
            }
        }
    }

    value = 0;
    switch (cmd) {
    case SX_ACCESS_CMD_SET:
    /* fall through */
    case SX_ACCESS_CMD_ADD:
        value = 1;

    /* fall through */
    case SX_ACCESS_CMD_DELETE:
        for (i = 0; i < log_port_num; i++) {
            if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(isolate_port_list[i])) {
                lag_id = SX_PORT_LAG_ID_GET(isolate_port_list[i]);

                port_num = rm_resource_global.lag_port_members_max;
                if (SX_CHECK_FAIL(sx_status = sx_lag_port_group_get(isolate_port_list[i], log_port_list, &port_num))) {
                    SX_LOG_ERR("LAG DB access fail on lag_id[0x%04X], err[%s]\n", lag_id, sx_status_str(sx_status));
                    goto out;
                }
            } else {
                port_num = 1;
                log_port_list[0] = isolate_port_list[i];
            }
            for (j = 0; j < port_num; j++) {
                if (SX_PORT_DEV_ID_GET(log_port_list[j]) == device_id) {
                    local_port = SX_PORT_PHY_ID_GET(log_port_list[j]);
                    if (value) {
                        SXD_BITMAP_REVERSE_SET(tnifr_v2_reg_data->port_filter,
                                               PORT_FILTER_ARR_SIZE,
                                               PORT_FILTER_ARR_ELEM_BITS,
                                               local_port);
                    } else {
                        SXD_BITMAP_REVERSE_CLR(tnifr_v2_reg_data->port_filter,
                                               PORT_FILTER_ARR_SIZE,
                                               PORT_FILTER_ARR_ELEM_BITS,
                                               local_port);
                    }

                    SXD_BITMAP_REVERSE_SET(tnifr_v2_reg_data->port_filter_update_en,
                                           PORT_FILTER_UPDATE_ARR_SIZE,
                                           PORT_FILTER_UPDATE_ARR_ELEM_BITS,
                                           local_port);
                }
            }
        }
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        break;

    default:
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

    tnifr_v2_reg_data->table_id = isolation_table;

out:
    if (log_port_list != NULL) {
        free(log_port_list);
    }
    if (port_swid_list != NULL) {
        utils_memory_put(port_swid_list, UTILS_MEM_TYPE_ID_PORT_E);
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_tncr_v2_get(const boolean_t          is_clear,
                                   const uint8_t            tunnel_port,
                                   struct ku_tncr_v2_reg ** ku_tncr_v2,
                                   uint32_t                *size)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    sxd_status_t          sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t        reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tncr_v2_reg tncr_v2_reg_data[SX_DEVICE_ID_COUNT];
    uint8_t               clear_counters = 0;

    SX_LOG_ENTER();

    M_UTILS_CLR_MEM_GET(ku_tncr_v2,
                        SX_DEVICE_ID_COUNT,
                        sizeof(struct ku_tncr_v2_reg),
                        UTILS_MEM_TYPE_ID_TUNNEL_E,
                        "tncr reg",
                        sx_status);

    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot allocate space for TNCR counters.\n");
        goto out;
    }

    /* Get list of LEAF devices */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Cannot retrieve device list, err = %s.\n", sx_status_str(sx_status));
        goto out;
    }

    if (TRUE == is_clear) {
        clear_counters = 1;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_GET;
    SX_MEM_CLR(tncr_v2_reg_data[dev_idx]);
    tncr_v2_reg_data[dev_idx].clear_counters = clear_counters;
    tncr_v2_reg_data[dev_idx].tunnel_port = tunnel_port;
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNCR_V2_E,
                                                     tncr_v2_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get TNCR, err = %s.\n", SXD_STATUS_MSG(sxd_status));
        sx_status = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    ku_tncr_v2[dev_idx]->count_decap_discards_high = tncr_v2_reg_data[dev_idx].count_decap_discards_high;
    ku_tncr_v2[dev_idx]->count_decap_discards_low = tncr_v2_reg_data[dev_idx].count_decap_discards_low;
    ku_tncr_v2[dev_idx]->count_encap_discards_high = tncr_v2_reg_data[dev_idx].count_encap_discards_high;
    ku_tncr_v2[dev_idx]->count_encap_discards_low = tncr_v2_reg_data[dev_idx].count_encap_discards_low;
    SX_FDB_FOR_EACH_LEAF_DEV_END;
    if (size) {
        *size = dev_info_arr_size;
    }

out:
    if (sx_status != SX_STATUS_SUCCESS) {
        if (*ku_tncr_v2) {
            M_UTILS_MEM_PUT(*ku_tncr_v2, UTILS_MEM_TYPE_ID_TUNNEL_E, "De-alloc of TNCR reg", sx_status);
            *ku_tncr_v2 = NULL;
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_tunnel_tigcr_reg_write(sxd_access_cmd_t access_cmd, struct ku_tigcr_reg *ku_tigcr)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tigcr_reg tigcr_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tigcr, "ku_tigcr"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tigcr_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tigcr_reg_data[dev_idx], ku_tigcr);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TIGCR_E,
                                                     tigcr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TIGCR set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_tunnel_tngcr_reg_write_urif(struct ku_tngcr_reg *ku_tngcr_p)
{
    struct ku_tngcr_reg clear_tngcr;

    SX_MEM_CPY_P(&clear_tngcr, ku_tngcr_p);


    clear_tngcr.nve_enc_orig = 0; /* Reserved for SPC 2 */
    clear_tngcr.nve_enc_orig_we = 0; /* Reserved for SPC 2 */
    clear_tngcr.et_vlan = 0; /* Reserved for SPC 2 */

    if (clear_tngcr.type == SXD_TUNNEL_NVE_NVGRE) {
        clear_tngcr.nve_udp_sport_prefix = 0;
    }

    clear_tngcr.nve_group_size_flood = 0; /* Reserved for SPC 2 */
    clear_tngcr.nve_group_size_mc = 0; /* Reserved for SPC 2 */
    clear_tngcr.learn_enable = 0; /* Reserved for SPC 2 */
    clear_tngcr.underlay_virtual_router = 0; /* Reserved for SPC 2 */

    return __hwd_tunnel_tngcr_reg_write(&clear_tngcr);
}

static sx_status_t __hwd_tunnel_tngcr_reg_write_uvrid(struct ku_tngcr_reg *ku_tngcr_p)
{
    struct ku_tngcr_reg clear_tngcr;

    SX_MEM_CPY_P(&clear_tngcr, ku_tngcr_p);

    if (clear_tngcr.nve_flh == 0) {
        clear_tngcr.nve_fl_prefix = 0; /* Reserved for SPC if clear_tngcr.nve_flh == 0 */
    }

    if (clear_tngcr.type == SXD_TUNNEL_NVE_NVGRE) {
        clear_tngcr.nve_udp_sport_prefix = 0;
    }

    clear_tngcr.underlay_rif = 0; /* Reserved for SPC */

    return __hwd_tunnel_tngcr_reg_write(&clear_tngcr);
}

sx_status_t hwd_tunnel_tngcr_reg_write(struct ku_tngcr_reg *ku_tngcr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tngcr_p, "ku_tngcr_p"))) {
        goto out;
    }

    if (g_hwd_tunnel_reg_internal_callbacks.hwd_tunnel_tngcr_reg_write_pfn == NULL) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Internal error: a callback for TNGCR is null.\n");
        goto out;
    }

    err = g_hwd_tunnel_reg_internal_callbacks.hwd_tunnel_tngcr_reg_write_pfn(ku_tngcr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to write TNGCR, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tngcr_to_reserved_bits_unpack(struct ku_tngcr_reg *ku_tngcr_p,
                                                     boolean_t           *dis_nve_opt_chk_p,
                                                     uint64_t            *hdr_bits_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_hwd_tunnel_reg_internal_callbacks.hwd_tunnel_tngcr_to_reserved_bits_unpack_pfn == NULL) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Internal error: cannot get the reserved bits from TNGCR, a callback is null.\n");
        goto out;
    }

    g_hwd_tunnel_reg_internal_callbacks.hwd_tunnel_tngcr_to_reserved_bits_unpack_pfn(ku_tngcr_p,
                                                                                     dis_nve_opt_chk_p,
                                                                                     hdr_bits_p);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_tunnel_tngcr_reg_write(struct ku_tngcr_reg *ku_tngcr)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tngcr_reg tngcr_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_SET;
    SX_MEM_CLR(tngcr_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tngcr_reg_data[dev_idx], ku_tngcr);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNGCR_E,
                                                     tngcr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TNGCR set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t hwd_tunnel_hccr_reg_write(struct ku_hccr_reg *ku_hccr)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_hccr_reg hccr_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_hccr, "ku_hccr"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_SET;
    SX_MEM_CLR(hccr_reg_data[dev_idx]);
    SX_MEM_CPY_P(&hccr_reg_data[dev_idx], ku_hccr);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HCCR_E,
                                                     hccr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to set HCCR: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_hpkt_reg_write(struct ku_hpkt_reg *ku_hpkt)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_hpkt_reg hpkt_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_hpkt, "ku_hpkt"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_SET;
    SX_MEM_CLR(hpkt_reg_data[dev_idx]);
    SX_MEM_CPY_P(&hpkt_reg_data[dev_idx], ku_hpkt);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_HPKT_E,
                                                     hpkt_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to set HPKT: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tiqdr_reg_write(sxd_access_cmd_t access_cmd, struct ku_tiqdr_reg *ku_tiqdr)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tiqdr_reg tiqdr_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tiqdr, "ku_tiqdr"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tiqdr_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tiqdr_reg_data[dev_idx], ku_tiqdr);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TIQDR_E,
                                                     tiqdr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TIQDR set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tiqcr_reg_write(sxd_access_cmd_t access_cmd, struct ku_tiqcr_reg *ku_tiqcr)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tiqcr_reg tiqcr_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tiqcr, "ku_tiqcr"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tiqcr_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tiqcr_reg_data[dev_idx], ku_tiqcr);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TIQCR_E,
                                                     tiqcr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TIQCR set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tnqdr_reg_write(sxd_access_cmd_t access_cmd, struct ku_tnqdr_reg *ku_tnqdr)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tnqdr_reg tnqdr_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tnqdr, "ku_tnqdr"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tnqdr_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tnqdr_reg_data[dev_idx], ku_tnqdr);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNQDR_E,
                                                     tnqdr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TNQDR set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tnqcr_reg_write(sxd_access_cmd_t access_cmd, struct ku_tnqcr_reg *ku_tnqcr)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tnqcr_reg tnqcr_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tnqcr, "ku_tnqcr"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tnqcr_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tnqcr_reg_data[dev_idx], ku_tnqcr);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNQCR_E,
                                                     tnqcr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TNQCR set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tncr_reg_write(sxd_access_cmd_t access_cmd, struct ku_tncr_reg *ku_tncr)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tncr_reg tncr_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tncr, "ku_tncr"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tncr_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tncr_reg_data[dev_idx], ku_tncr);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNCR_E,
                                                     tncr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TNCR set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tieem_reg_write(sxd_access_cmd_t access_cmd, struct ku_tieem_reg *ku_tieem)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tieem_reg tieem_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tieem, "ku_tieem"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tieem_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tieem_reg_data[dev_idx], ku_tieem);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TIEEM_E,
                                                     tieem_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TIEEM set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tidem_reg_write(sxd_access_cmd_t access_cmd, struct ku_tidem_reg *ku_tidem)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tidem_reg tidem_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tidem, "ku_tidem"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tidem_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tidem_reg_data[dev_idx], ku_tidem);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TIDEM_E,
                                                     tidem_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TIDEM set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tneem_reg_write(sxd_access_cmd_t access_cmd, struct ku_tneem_reg *ku_tneem)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tneem_reg tneem_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tneem, "ku_tneem"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tneem_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tneem_reg_data[dev_idx], ku_tneem);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNEEM_E,
                                                     tneem_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TNEEM set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tndem_reg_write(sxd_access_cmd_t access_cmd, struct ku_tndem_reg *ku_tndem)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tndem_reg tndem_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tndem, "ku_tndem"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tndem_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tndem_reg_data[dev_idx], ku_tndem);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNDEM_E,
                                                     tndem_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TNDEM set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_rtdp_reg_write(sxd_access_cmd_t access_cmd, struct ku_rtdp_reg *ku_rtdp)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_rtdp_reg rtdp_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_rtdp, "ku_rtdp"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(rtdp_reg_data[dev_idx]);
    SX_MEM_CPY_P(&rtdp_reg_data[dev_idx], ku_rtdp);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RTDP_E,
                                                     rtdp_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to RTDP set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_tunnel_tncr_v2_reg_write(sxd_access_cmd_t access_cmd, struct ku_tncr_v2_reg *ku_tncr_v2)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t           err = SX_STATUS_SUCCESS;
    sxd_status_t          sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t        reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_tncr_v2_reg tncr_v2_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_tncr_v2, "ku_tncr_v2"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    SX_MEM_CLR(tncr_v2_reg_data[dev_idx]);
    SX_MEM_CPY_P(&tncr_v2_reg_data[dev_idx], ku_tncr_v2);
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_TNCR_V2_E,
                                                     tncr_v2_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to TNCRV2 set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static void __hwd_tunnel_tngcr_reg_reserved_bits_set_spectrum(struct ku_tngcr_reg *ku_tngcr_p,
                                                              boolean_t            dis_nve_opt_chk,
                                                              uint64_t             hdr_bits)
{
    UNUSED_PARAM(hdr_bits);
    ku_tngcr_p->dis_nve_opt_chk = dis_nve_opt_chk;
    ku_tngcr_p->nvgre_hdr_bits_en = 0;
    ku_tngcr_p->geneve_hdr_bits_en = 0;
    ku_tngcr_p->gpe_hdr_bits_en = 0;
    ku_tngcr_p->vxlan_hdr_bits_en = 0;
    ku_tngcr_p->vxlan_hdr_bits = 0;
    ku_tngcr_p->gpe_hdr_bits = 0;
    ku_tngcr_p->geneve_hdr_bits = 0;
    ku_tngcr_p->nvgre_hdr_bits = 0;
}

static void __hwd_tunnel_tngcr_reg_reserved_bits_set_spectrum4(struct ku_tngcr_reg *ku_tngcr_p,
                                                               boolean_t            dis_nve_opt_chk,
                                                               uint64_t             hdr_bits)
{
    UNUSED_PARAM(dis_nve_opt_chk);

    ku_tngcr_p->dis_nve_opt_chk = 0;
    ku_tngcr_p->nvgre_hdr_bits_en = 0;
    ku_tngcr_p->geneve_hdr_bits_en = 0;
    ku_tngcr_p->gpe_hdr_bits_en = 0;
    ku_tngcr_p->vxlan_hdr_bits_en = 0;
    ku_tngcr_p->vxlan_hdr_bits = 0;
    ku_tngcr_p->gpe_hdr_bits = 0;
    ku_tngcr_p->geneve_hdr_bits = 0;
    ku_tngcr_p->nvgre_hdr_bits = 0;

    switch (ku_tngcr_p->type) {
    case SXD_TUNNEL_NVE_VXLAN:
        ku_tngcr_p->vxlan_hdr_bits_en = 0x1;
        ku_tngcr_p->vxlan_hdr_bits = hdr_bits;
        break;

    case SXD_TUNNEL_NVE_VXLAN_GPE:
        ku_tngcr_p->gpe_hdr_bits_en = 0x1;
        ku_tngcr_p->gpe_hdr_bits = hdr_bits;
        break;

    case SXD_TUNNEL_NVE_GENEVE:
        ku_tngcr_p->geneve_hdr_bits_en = 0x1;
        ku_tngcr_p->geneve_hdr_bits = hdr_bits;
        break;

    case SXD_TUNNEL_NVE_NVGRE:
        ku_tngcr_p->nvgre_hdr_bits_en = 0x1;
        ku_tngcr_p->nvgre_hdr_bits = hdr_bits;
        break;

    default:
        break;
    }
}

static void __hwd_tunnel_tngcr_to_reserved_bits_unpack_spectrum(struct ku_tngcr_reg *ku_tngcr,
                                                                boolean_t           *dis_nve_opt_chk_p,
                                                                uint64_t            *hdr_bits_p)
{
    *dis_nve_opt_chk_p = ku_tngcr->dis_nve_opt_chk;
    *hdr_bits_p = 0;
}

static void __hwd_tunnel_tngcr_to_reserved_bits_unpack_spectrum4(struct ku_tngcr_reg *ku_tngcr,
                                                                 boolean_t           *dis_nve_opt_chk_p,
                                                                 uint64_t            *hdr_bits_p)
{
    switch (ku_tngcr->type) {
    case SXD_TUNNEL_NVE_VXLAN:
        *dis_nve_opt_chk_p = ku_tngcr->vxlan_hdr_bits_en;
        *hdr_bits_p = ku_tngcr->vxlan_hdr_bits;
        break;

    case SXD_TUNNEL_NVE_VXLAN_GPE:
        *dis_nve_opt_chk_p = ku_tngcr->gpe_hdr_bits_en;
        *hdr_bits_p = ku_tngcr->gpe_hdr_bits;
        break;

    case SXD_TUNNEL_NVE_GENEVE:
        *dis_nve_opt_chk_p = ku_tngcr->geneve_hdr_bits_en;
        *hdr_bits_p = ku_tngcr->geneve_hdr_bits;
        break;

    case SXD_TUNNEL_NVE_NVGRE:
        *dis_nve_opt_chk_p = ku_tngcr->nvgre_hdr_bits_en;
        *hdr_bits_p = ku_tngcr->nvgre_hdr_bits;
        break;

    default:
        *dis_nve_opt_chk_p = 0;
        *hdr_bits_p = 0;
        break;
    }
}
