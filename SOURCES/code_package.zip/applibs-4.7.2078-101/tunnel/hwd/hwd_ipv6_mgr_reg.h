/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __HWD_IPV6_MGR_REG_H__
#define __HWD_IPV6_MGR_REG_H__

#include <sx/sxd/sxd_emad_router.h>
#include "hwd_ipv6_mgr_db.h"
#include "hwd_ipv6_mgr.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t hwd_ipv6_mgr_reg_log_verbosity_level_set(sx_verbosity_level_t verbosity);

sx_status_t hwd_ipv6_mgr_rips_reg_write(sxd_access_cmd_t    access_cmd,
                                        struct ku_rips_reg *ku_rips);

#endif /* __HWD_IPV6_MGR_REG_H__ */
