/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#undef  __MODULE__
#define __MODULE__ IPV6_MGR

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/sx_mem.h"
#include "utils/sx_adviser.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "resource_manager/resource_manager_sdk_table.h"
#include "include/resource_manager/resource_manager.h"
#include "hwd_ipv6_mgr.h"
#include "hwd_ipv6_mgr_db.h"
#include "hwd_ipv6_mgr_reg.h"

/************************************************
 *  Local defines
 ***********************************************/

#define RIPS_TABLE_ENTRY_SIZE 1

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/
extern rm_sdk_table_resource_t sdk_table_resources_g[RM_SDK_TABLE_TYPE_NUMBER];
extern hwi_ipv6_mgr_ops_t      ipv6_mgr_ops_g;
extern boolean_t               ipv6_mgr_ops_init_g;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t g_is_initialized = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/
static inline sx_status_t __sdk_ipv6_check_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (FALSE == g_is_initialized) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("IPv6 MGR module is not initialized\n");
    }
    return err;
}

static void __hwd_ipv6_mgr_rips_prepare(hwd_ipv6_data_t *rips_data_p, hwd_rips_t *hwd_rips_p)
{
    SX_LOG_ENTER();

    hwd_rips_p->ku_rips.index = rips_data_p->hw_index;
    hwd_rips_p->ku_rips.ipv6[0] = rips_data_p->ip_addr.addr.ipv6.s6_addr32[0];
    hwd_rips_p->ku_rips.ipv6[1] = rips_data_p->ip_addr.addr.ipv6.s6_addr32[1];
    hwd_rips_p->ku_rips.ipv6[2] = rips_data_p->ip_addr.addr.ipv6.s6_addr32[2];
    hwd_rips_p->ku_rips.ipv6[3] = rips_data_p->ip_addr.addr.ipv6.s6_addr32[3];

    SX_LOG_EXIT();
    return;
}

/*
 * Callback for KVDL manager.
 * Writes a new copy of RIPS block, and generate adviser IPV6_CHANGE event.
 *
 * @param [in]     handle      - A handle to the block.
 * @param [in]     size        - block size.
 * @param [in]     offset      - unused.
 * @param [in]     old_index_p - rips block old index.
 * @param [in]     new_index   - rips block new index.
 */
static sx_status_t __kvd_linear_manager_ipv6_block_relocate_cb(kvd_linear_manager_handle_t       handle,
                                                               kvd_linear_manager_block_length_t size,
                                                               kvd_linear_manager_block_length_t offset,
                                                               const kvd_linear_manager_index_t* old_index_p,
                                                               kvd_linear_manager_index_t        new_index)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    hwd_ipv6_data_t ipv6_entry;
    hwd_rips_t      rips_entry;
    hwd_ipv6_cb_t   relocate_context;

    UNUSED_PARAM(size);
    UNUSED_PARAM(offset);

    SX_MEM_CLR(ipv6_entry);
    SX_MEM_CLR(rips_entry);
    SX_MEM_CLR(relocate_context);

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(old_index_p, "old_index_p"))) {
        goto out;
    }

    SX_LOG_DBG("IPv6 MGR: Relocate RIPS block: handle [0x%" PRIx64 "], index changed from %u to %d.\n",
               handle, *old_index_p, new_index);

    err = hwd_rips_db_get_by_handle(handle, &ipv6_entry);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("IPv6 MGR: Failed to get RIPS entry by handle [0x%" PRIx64 "] from DB, err = %s.\n",
                   handle, sx_status_str(err));
        goto out;
    }

    ipv6_entry.hw_index = new_index;
    __hwd_ipv6_mgr_rips_prepare(&ipv6_entry, &rips_entry);

    /* Write to RIPS */
    err = hwd_ipv6_mgr_rips_reg_write(SXD_ACCESS_CMD_SET, &rips_entry.ku_rips);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("IPv6 MGR: Failed to write RIPS register, err = %s.\n", sx_status_str(err));
        goto out;
    }

    /* Update DB */
    err = hwd_rips_db_update(handle, &ipv6_entry);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("IPv6 MGR: Failed to update RIPS entry in RIPS DB, err = %s.\n", sx_status_str(err));
        goto out;
    }

    /* Generate adviser event */
    relocate_context.handle = handle;
    relocate_context.old_index = *old_index_p;
    relocate_context.new_index = new_index;
    err = adviser_process_event(ADVISER_EVENT_POST_IPV6_CHANGE_E, &relocate_context);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("IPv6 MGR: Could not process adviser event '%s'.\n",
                   ADVISER_EVENT_STR(ADVISER_EVENT_POST_IPV6_CHANGE_E));
        goto out;
    }

    SX_LOG_DBG("IPv6 MGR: Relocated IPV6 block successfully\n");
out:
    SX_LOG_EXIT();
    return err;
}

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t hwd_ipv6_mgr_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    hwd_rips_db_log_verbosity_level_set(verbosity_level);
    hwd_ipv6_mgr_reg_log_verbosity_level_set(verbosity_level);

    return status;
}

sx_status_t hwd_ipv6_mgr_init_set(boolean_t is_ipv6_mgr_init_done_p)
{
    g_is_initialized = is_ipv6_mgr_init_done_p;
    return SX_STATUS_SUCCESS;
}

sx_status_t hwd_ipv6_assign_ops(hwi_ipv6_mgr_ops_t* ops_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(ops_p, "ops_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    ops_p->hwd_ipv6_init_pfn = hwd_ipv6_init;
    ops_p->hwd_ipv6_deinit_pfn = hwd_ipv6_deinit;
    ops_p->hwd_ipv6_add_pfn = hwd_ipv6_add;
    ops_p->hwd_ipv6_delete_pfn = hwd_ipv6_delete;
    ops_p->hwd_ipv6_get_pfn = hwd_ipv6_get;
    ops_p->hwd_ipv6_get_by_handle_pfn = hwd_ipv6_get_by_handle;
    ops_p->hwd_ipv6_block_lock_pfn = hwd_hw_ipv6_lock;
    ops_p->hwd_ipv6_block_unlock_pfn = hwd_hw_ipv6_unlock;
    ops_p->hwd_ipv6_debug_dump_pfn = hwd_rips_db_debug_dump;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_ipv6_register_hwd_ops(hwi_ipv6_mgr_ops_t *ops_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("IPv6 MGR impl register hwd ops\n");

    if (utils_check_pointer(ops_p, "ops_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_ipv6_init_pfn,
                            "hwd_ipv6_init_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_ipv6_deinit_pfn,
                            "hwd_ipv6_deinit_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_ipv6_add_pfn,
                            "hwd_ipv6_add_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_ipv6_delete_pfn,
                            "hwd_ipv6_delete_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_ipv6_get_pfn,
                            "hwd_ipv6_get_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_ipv6_get_by_handle_pfn,
                            "hwd_ipv6_get_by_handle_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_ipv6_block_lock_pfn,
                            "hwd_ipv6_block_lock_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_ipv6_block_unlock_pfn,
                            "hwd_ipv6_block_unlock_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_ipv6_debug_dump_pfn,
                            "hwd_ipv6_debug_dump_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    ipv6_mgr_ops_g = *ops_p;
    ipv6_mgr_ops_init_g = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_ipv6_unregister_hwd_ops(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("IPv6 MGR impl unregister hwd ops\n");

    if (TRUE == g_is_initialized) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("IPv6 MGR: Failed to unregister hwd ops\n");
        goto out;
    }

    ipv6_mgr_ops_init_g = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_ipv6_init(void)
{
    sx_status_t                      sx_status = SX_STATUS_SUCCESS;
    sx_status_t                      rb_status = SX_STATUS_SUCCESS;
    boolean_t                        kvd_initialized = FALSE;
    boolean_t                        db_initialized = FALSE;
    boolean_t                        rm_rips_initialized = FALSE;
    kvd_linear_manager_user_params_t kvd_params;

    KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_ITERATORS;

    SX_MEM_CLR(kvd_params);

    SX_LOG_ENTER();
    SX_LOG(SX_LOG_DEBUG, "Init HWD IPv6 MGR module\n");

    if (TRUE == g_is_initialized) {
        sx_status = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("IPv6 MGR: Failed to init HWD module, module is already initialized.\n");
        goto out;
    }

    sx_status = hwd_rips_db_init();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("IPv6 MGR: Failed to initialize HWD DB , err = %s\n", sx_status_str(sx_status));
        goto out;
    }
    db_initialized = TRUE;

    kvd_params.block_type = LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E;
    kvd_params.block_relocate = __kvd_linear_manager_ipv6_block_relocate_cb;
    KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_INIT(kvd_params);

    sx_status = kvd_linear_manager_init_user(KVD_LINEAR_MANAGER_USER_IPV6_E, kvd_params);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("IPv6 MGR: Failed to initialize user for KVD linear manager, err = %s\n", sx_status_str(sx_status));
        goto out;
    }
    kvd_initialized = TRUE;

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_RIPS_E].is_initialized = TRUE;
    sx_status = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_RIPS_E);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("IPv6 MGR: Failed to initialize RM for RIPS resource type: %s\n", sx_status_str(sx_status));
        goto out;
    }
    rm_rips_initialized = TRUE;

    g_is_initialized = TRUE;
    SX_LOG_DBG("IPV6 MGR: HWD Module initialized successfully.\n");

out:
    if (SX_CHECK_FAIL(sx_status)) {
        /* coverity[dead_error_condition] */
        if (rm_rips_initialized) {
            /* coverity[dead_error_begin] */
            rb_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_RIPS_E, TRUE);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("IPv6 MGR: Failed to roll back initialization of RM for RIPS resource: %s\n",
                           sx_status_str(rb_status));
            }
        }
        if (kvd_initialized) {
            rb_status = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_IPV6_E);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("IPv6 MGR: Failed to de-initialize IPV6 user in KVD linear manager, err = %s\n",
                           sx_status_str(rb_status));
            }
        }
        if (db_initialized) {
            rb_status = hwd_rips_db_deinit(FALSE);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("IPv6 MGR: Failed to de-initialize RIPS HWD DB, err = %s\n",
                           sx_status_str(rb_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_ipv6_deinit(boolean_t is_forced)
{
    sx_status_t                      sx_status = SX_STATUS_SUCCESS;
    sx_status_t                      rb_status = SX_STATUS_SUCCESS;
    boolean_t                        kvd_initialized = TRUE;
    boolean_t                        db_initialized = TRUE;
    kvd_linear_manager_user_params_t kvd_params;
    uint32_t                         rips_num = 0;

    KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_ITERATORS;

    SX_MEM_CLR(kvd_params);

    SX_LOG_ENTER();
    SX_LOG(SX_LOG_DEBUG, "IPv6 MGR: Deinit HWD module, is_forced[%d]\n", is_forced);

    if (FALSE == g_is_initialized) {
        if (FALSE == is_forced) {
            sx_status = SX_STATUS_DB_NOT_INITIALIZED;
            SX_LOG_ERR("IPv6 MGR: Failed to deinit HWD module, module is not initialized.\n");
        }
        goto out;
    }

    sx_status = hwd_rips_db_total_rips_get(&rips_num);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("IPv6 MGR: Failed to get number of RIPS entries, err = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = hwd_rips_db_deinit(is_forced);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("IPv6 MGR: Failed to deinit HWD DB, err = %s\n", sx_status_str(sx_status));
        goto out;
    }
    db_initialized = FALSE;

    sx_status = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_IPV6_E);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("IPv6 MGR: Failed to de-initialize user for KVD linear manager, err = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }
    kvd_initialized = FALSE;

    if (rips_num > 0) {
        sx_status = rm_entries_set(RM_SDK_TABLE_TYPE_RIPS_E,
                                   SX_ACCESS_CMD_DELETE, rips_num, NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("IPv6 MGR: Failed to delete %u RIPS entries from RM, err = [%s]\n",
                       rips_num, sx_status_str(sx_status));
            goto out;
        }
    }

    sx_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_RIPS_E, is_forced);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("IPv6 MGR: Failed to de-initialize of RM for RIPS resource: %s\n",
                   sx_status_str(sx_status));
    }
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_RIPS_E].is_initialized = FALSE;

    g_is_initialized = FALSE;
    SX_LOG_DBG("IPv6 MGR: HWD module de-initialized successfully.\n");

out:
    if (SX_CHECK_FAIL(sx_status) && (!is_forced)) {
        if (!kvd_initialized) {
            kvd_params.block_type = LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E;
            kvd_params.block_relocate = __kvd_linear_manager_ipv6_block_relocate_cb;
            KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_INIT(kvd_params);

            rb_status = kvd_linear_manager_init_user(KVD_LINEAR_MANAGER_USER_IPV6_E, kvd_params);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("IPv6 MGR: Failed to initialize user for KVD linear manager, err = %s\n",
                           sx_status_str(rb_status));
            }
        }
        if (!db_initialized) {
            rb_status = hwd_rips_db_init();
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("IPv6 MGR: Failed to roll back deinit of RIPS HWD DB , err = %s\n",
                           sx_status_str(rb_status));
            }
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t hwd_ipv6_add(const sx_ip_addr_t *ip_addr_p, hwi_ipv6_hw_handle_t *handle_p)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    sx_status_t     roll = SX_STATUS_SUCCESS;
    hwd_ipv6_data_t rips_data;
    char            ip_addr_str[FORMAT_BUFFER_SIZE] = {0};
    uint32_t        size = RIPS_TABLE_ENTRY_SIZE;
    hwd_rips_t      hwd_rips;
    boolean_t       rm_entry_added = FALSE;
    boolean_t       kvd_block_add = FALSE;
    boolean_t       kvd_lock_set = FALSE;
    boolean_t       db_entry_create = FALSE;

    SX_LOG_ENTER();
    SX_MEM_CLR(rips_data);
    SX_MEM_CLR(hwd_rips);

    if (utils_check_pointer(ip_addr_p, "ip_addr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(handle_p, "handle_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((err = __sdk_ipv6_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = hwd_rips_db_get(ip_addr_p, &rips_data);
    if (SX_STATUS_SUCCESS == err) {
        SX_LOG_DBG("IPv6 MGR: RIPS entry [%s] already exists in HWD DB\n",
                   format_ip_addr(ip_addr_p, ip_addr_str));

        rips_data.instance_cnt += 1;
        err = hwd_rips_db_update(rips_data.ipv6_block_handle, &rips_data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("IPv6 MGR: Failed to update RIPS entry [%s] in HWD DB, err = %s.\n",
                       format_ip_addr(ip_addr_p, ip_addr_str), sx_status_str(err));
            goto out;
        }
    } else if (SX_STATUS_ENTRY_NOT_FOUND == err) {
        SX_LOG_DBG("IPv6 MGR: Create new RIPS entry [%s] in HWD DB.\n",
                   format_ip_addr(ip_addr_p, ip_addr_str));

        err = rm_entries_set(RM_SDK_TABLE_TYPE_RIPS_E, SX_ACCESS_CMD_ADD, size, NULL);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("IPv6 MGR: Failed to add RM entry for RIPS.\n");
            goto out;
        }
        rm_entry_added = TRUE;

        err = kvd_linear_manager_block_add(KVD_LINEAR_MANAGER_USER_IPV6_E, size,
                                           FALSE, &rips_data.ipv6_block_handle);
        if (SX_CHECK_FAIL(err)) {
            if (err == SX_STATUS_NO_RESOURCES) {
                SX_LOG_ERR("IPv6 MGR: Tried to allocate a new block but got no resources from KVD.\n");
                goto out;
            } else {
                SX_LOG_ERR("IPv6 MGR: Failed to add RIPS to KVD, err = %s\n", sx_status_str(err));
                goto out;
            }
        }
        SX_LOG_DBG("IPv6 MGR: KVD block was added kvd_handle [0x%" PRIx64 "] \n", rips_data.ipv6_block_handle);
        kvd_block_add = TRUE;

        err = kvd_linear_manager_handle_lock(rips_data.ipv6_block_handle,
                                             &rips_data.hw_index, &size);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("IPv6 MGR: Failed to lock kvd block 0x%" PRIx64 ", err = %s.\n",
                       rips_data.ipv6_block_handle, sx_status_str(err));
            err = SX_STATUS_ERROR;
            goto out;
        }
        SX_LOG_DBG("IPv6 MGR: KVDL index of new RIPS block is [0x%" PRIx32 "]\n", rips_data.hw_index);
        kvd_lock_set = TRUE;

        SX_MEM_CPY_P(&rips_data.ip_addr, ip_addr_p);
        rips_data.instance_cnt = 1;

        err = hwd_rips_db_add(&rips_data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_DBG("IPv6 MGR: Failed to add RIPS entry [%s] to DB.\n",
                       format_ip_addr(ip_addr_p, ip_addr_str));
            goto out;
        }
        db_entry_create = TRUE;

        /* Write to RIPS register */
        __hwd_ipv6_mgr_rips_prepare(&rips_data, &hwd_rips);
        err = hwd_ipv6_mgr_rips_reg_write(SXD_ACCESS_CMD_ADD, &(hwd_rips.ku_rips));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_DBG("IPv6 MGR: Failed to write RIPS register for [%s] to HW.\n",
                       format_ip_addr(ip_addr_p, ip_addr_str));
            goto out;
        }

        err = kvd_linear_manager_handle_release(rips_data.ipv6_block_handle);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("IPv6 MGR: Failed to release kvd block 0x%" PRIx64 ", err = %s.\n",
                       rips_data.ipv6_block_handle, sx_status_str(err));
            err = SX_STATUS_ERROR;
            goto out;
        }
    } else {
        SX_LOG_ERR("IPv6 MGR: Failed to get RIPS entry [%s] from HWD DB, err = %s.\n",
                   format_ip_addr(ip_addr_p, ip_addr_str), sx_status_str(err));
        goto out;
    }

    *handle_p = rips_data.ipv6_block_handle;

out:
    if (SX_CHECK_FAIL(err)) {
        if (kvd_lock_set) {
            roll = kvd_linear_manager_handle_release(rips_data.ipv6_block_handle);
            if (SX_CHECK_FAIL(roll)) {
                SX_LOG_ERR("IPv6 MGR: Failed to rollback lock of kvd block 0x%" PRIx64 ", err = %s.\n",
                           rips_data.ipv6_block_handle, sx_status_str(roll));
            }
        }
        if (kvd_block_add) {
            roll = kvd_linear_manager_block_delete(rips_data.ipv6_block_handle, FALSE);
            if (SX_CHECK_FAIL(roll)) {
                SX_LOG_ERR("IPv6 MGR: Failed to rollback create of kvd block 0x%" PRIx64 ", err = %s.\n",
                           rips_data.ipv6_block_handle, sx_status_str(roll));
            }
        }
        if (rm_entry_added) {
            roll = rm_entries_set(RM_SDK_TABLE_TYPE_RIPS_E, SX_ACCESS_CMD_DELETE, size, NULL);
            if (SX_CHECK_FAIL(roll)) {
                SX_LOG_ERR("IPv6 MGR: Failed to rollback RM add, err = %s.\n", sx_status_str(roll));
            }
        }
        if (db_entry_create) {
            roll = hwd_rips_db_delete(rips_data.ipv6_block_handle);
            if (SX_CHECK_FAIL(roll)) {
                SX_LOG_ERR("IPv6 MGR: Failed to rollback RIPS DB entry create, err = %s.\n", sx_status_str(roll));
            }
        }
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_ipv6_delete(hwi_ipv6_hw_handle_t handle)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    sx_status_t     roll = SX_STATUS_SUCCESS;
    hwd_ipv6_data_t rips_data;
    char            ip_addr_str[FORMAT_BUFFER_SIZE] = {0};
    uint32_t        size = RIPS_TABLE_ENTRY_SIZE;
    boolean_t       rm_entry_deleted = FALSE;

    SX_LOG_ENTER();
    SX_MEM_CLR(rips_data);

    if ((err = __sdk_ipv6_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = hwd_rips_db_get_by_handle(handle, &rips_data);
    if (SX_STATUS_ENTRY_NOT_FOUND == err) {
        SX_LOG_ERR("IPv6 MGR: RIPS entry with handle [0x%" PRIx64 "] does not exists in HWD DB\n", handle);
        goto out;
    } else if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("IPv6 MGR: Failed to get RIPS entry with handle [0x%" PRIx64 "].\n", handle);
        goto out;
    } else {
        SX_LOG_DBG("IPv6 MGR: Delete RIPS entry by handle [0x%" PRIx64 "] in HWD DB.\n", handle);

        if (rips_data.instance_cnt == 1) {
            err = rm_entries_set(RM_SDK_TABLE_TYPE_RIPS_E, SX_ACCESS_CMD_DELETE, size, NULL);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("IPv6 MGR: Failed to delete RM entry from RIPS.\n");
                goto out;
            }
            rm_entry_deleted = TRUE;

            err = kvd_linear_manager_block_delete(handle, FALSE);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("IPv6 MGR: Failed to delete RIPS from KVD, err = %s\n", sx_status_str(err));
                goto out;
            }
            SX_LOG_DBG("IPv6 MGR: KVD block was deleted kvd_handle [0x%" PRIx64 "] \n", handle);

            err = hwd_rips_db_delete(handle);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_DBG("IPv6 MGR: Failed to delete RIPS entry [%s] from DB.\n",
                           format_ip_addr(&rips_data.ip_addr, ip_addr_str));
                goto out;
            }
        } else {
            rips_data.instance_cnt -= 1;
            err = hwd_rips_db_update(handle, &rips_data);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_DBG("IPv6 MGR: Failed to update RIPS entry [%s] in DB.\n",
                           format_ip_addr(&rips_data.ip_addr, ip_addr_str));
                goto out;
            }
        }
    }

out:
    if (SX_CHECK_FAIL(err)) {
        if (rm_entry_deleted) {
            roll = rm_entries_set(RM_SDK_TABLE_TYPE_RIPS_E, SX_ACCESS_CMD_ADD, size, NULL);
            if (SX_CHECK_FAIL(roll)) {
                SX_LOG_ERR("IPv6 MGR: Failed to rollback RM delete, err = %s.\n", sx_status_str(roll));
            }
        }
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_ipv6_get(const sx_ip_addr_t *ip_addr_p, hwi_ipv6_hw_handle_t *handle_p)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    hwd_ipv6_data_t rips_data;
    char            ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();
    SX_MEM_CLR(rips_data);

    if (SX_CHECK_FAIL(err = utils_check_pointer(handle_p, "handle_p"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(err = utils_check_pointer(ip_addr_p, "ip_addr_p"))) {
        goto out;
    }
    SX_LOG_DBG("IPv6 MGR: get RIPS entry from DB by address [%s]\n", format_ip_addr(ip_addr_p, ip_addr_str));

    if ((err = __sdk_ipv6_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = hwd_rips_db_get(ip_addr_p, &rips_data);
    if (SX_STATUS_ENTRY_NOT_FOUND == err) {
        SX_LOG_ERR("IPv6 MGR: RIPS entry [%s] does not exist in DB.\n",
                   format_ip_addr(ip_addr_p, ip_addr_str));
        goto out;
    } else if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("IPv6 MGR: Failed to get RIPS entry [%s] from DB.\n",
                   format_ip_addr(ip_addr_p, ip_addr_str));
        goto out;
    }
    *handle_p = rips_data.ipv6_block_handle;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_ipv6_get_by_handle(hwi_ipv6_hw_handle_t handle, sx_ip_addr_t *ip_addr_p)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    hwd_ipv6_data_t ipv6_entry;

    SX_LOG_ENTER();
    SX_MEM_CLR(ipv6_entry);

    if (SX_CHECK_FAIL(err = utils_check_pointer(ip_addr_p, "ip_addr_p"))) {
        goto out;
    }
    SX_LOG_DBG("IPv6 MGR: get RIPS entry from DB by handle 0x%" PRIx64 "\n", handle);

    if ((err = __sdk_ipv6_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = hwd_rips_db_get_by_handle(handle, &ipv6_entry);
    if (SX_STATUS_ENTRY_NOT_FOUND == err) {
        SX_LOG_ERR("IPv6 MGR: RIPS handle [0x%" PRIx64 "] does not exist in DB.\n", handle);
        goto out;
    } else if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("IPv6 MGR: Failed to get RIPS entry [0x%" PRIx64 "] from DB.\n", handle);
        goto out;
    }

    SX_MEM_CPY_P(ip_addr_p, &ipv6_entry.ip_addr);

out:
    SX_LOG_EXIT();
    return err;
}

/* hw_index_p - index in KVDL of RIPS block */
sx_status_t hwd_hw_ipv6_lock(hwi_ipv6_hw_handle_t handle, hwi_ipv6_hw_index_t *hw_index_p)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    hwd_ipv6_data_t rips_data;
    uint32_t        size = RIPS_TABLE_ENTRY_SIZE;
    char            ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();
    SX_MEM_CLR(rips_data);

    SX_LOG_DBG("IPv6 MGR: lock RIPS entry in KVD by handle [0x%" PRIx64 "]\n", handle);

    if ((err = __sdk_ipv6_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = hwd_rips_db_get_by_handle(handle, &rips_data);
    if (SX_STATUS_ENTRY_NOT_FOUND == err) {
        SX_LOG_ERR("IPv6 MGR: RIPS handle [0x%" PRIx64 "] does not exist in DB.\n", handle);
        goto out;
    } else if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("IPv6 MGR: Failed to get RIPS entry [0x%" PRIx64 "] from DB.\n", handle);
        goto out;
    }

    if (rips_data.lock_cnt == 0) {
        err = kvd_linear_manager_handle_lock(rips_data.ipv6_block_handle,
                                             &rips_data.hw_index, &size);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("IPv6 MGR: Failed to lock kvd block [0x%" PRIx64 "], err = %s.\n",
                       rips_data.ipv6_block_handle, sx_status_str(err));
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

    rips_data.lock_cnt += 1;
    err = hwd_rips_db_update(handle, &rips_data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_DBG("IPv6 MGR: Failed to update RIPS entry [%s] in DB.\n",
                   format_ip_addr(&rips_data.ip_addr, ip_addr_str));
        goto out;
    }

    *hw_index_p = rips_data.hw_index;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t hwd_hw_ipv6_unlock(hwi_ipv6_hw_handle_t handle)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    hwd_ipv6_data_t rips_data;
    char            ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();
    SX_MEM_CLR(rips_data);

    SX_LOG_DBG("IPv6 MGR: unlock RIPS entry in KVD by handle [0x%" PRIx64 "]\n", handle);

    if ((err = __sdk_ipv6_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = hwd_rips_db_get_by_handle(handle, &rips_data);
    if (SX_STATUS_ENTRY_NOT_FOUND == err) {
        SX_LOG_ERR("IPv6 MGR: RIPS handle [0x%" PRIx64 "] does not exist in DB.\n", handle);
        goto out;
    } else if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("IPv6 MGR: Failed to get RIPS entry [0x%" PRIx64 "] from DB.\n", handle);
        goto out;
    }


    if (rips_data.lock_cnt == 0) {
        SX_LOG_ERR("IPv6 MGR: Failed to unlock RIPS entry [0x%" PRIx64 "] from DB, entry not locked.\n", handle);
        err = SX_STATUS_ERROR;
        goto out;
    } else if (rips_data.lock_cnt == 1) {
        err = kvd_linear_manager_handle_release(handle);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("IPv6 MGR: Failed to release kvd block [0x%" PRIx64 "], err = %s.\n",
                       handle, sx_status_str(err));
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

    rips_data.lock_cnt -= 1;
    err = hwd_rips_db_update(handle, &rips_data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_DBG("IPv6 MGR: Failed to update RIPS entry [%s] in DB.\n",
                   format_ip_addr(&rips_data.ip_addr, ip_addr_str));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}
