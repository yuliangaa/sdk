/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __IPV6_MGR_H__
#define __IPV6_MGR_H__

#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <complib/cl_fleximap.h>
#include <sx/sdk/sx_types.h>
#include <kvd/kvd_linear_manager.h>
#include <sx/utils/sx_utils_status.h>
#include "utils/sx_ip_utils.h"
#include "tunnel/hwi/ipv6_mgr_impl.h"


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

#define HWD_IPV6_INVALID_HANDLE 0

/************************************************
 *  Type definitions
 ***********************************************/

/* A structure for notifying ipv6 relocation */
typedef struct hwd_ipv6_cb {
    hwi_ipv6_hw_handle_t handle;
    uint32_t             old_index;
    uint32_t             new_index;
} hwd_ipv6_cb_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t hwd_ipv6_mgr_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t hwd_ipv6_mgr_init_set(boolean_t is_ipv6_mgr_init_done_p);
sx_status_t hwd_ipv6_assign_ops(hwi_ipv6_mgr_ops_t *ops_p);
sx_status_t hwd_ipv6_register_hwd_ops(hwi_ipv6_mgr_ops_t *ops_p);
sx_status_t hwd_ipv6_unregister_hwd_ops(void);
sx_status_t hwd_ipv6_init(void);
sx_status_t hwd_ipv6_deinit(boolean_t is_forced);
sx_status_t hwd_ipv6_add(const sx_ip_addr_t *ip_addr_p, hwi_ipv6_hw_handle_t *handle_p);
sx_status_t hwd_ipv6_delete(hwi_ipv6_hw_handle_t handler);
sx_status_t hwd_ipv6_get(const sx_ip_addr_t *ip_addr_p, hwi_ipv6_hw_handle_t *handle_p);
sx_status_t hwd_ipv6_get_by_handle(hwi_ipv6_hw_handle_t handle, sx_ip_addr_t *ip_addr_p);

/* hw_index_p - index in KVDL of RIPS block */
sx_status_t hwd_hw_ipv6_lock(hwi_ipv6_hw_handle_t handle,
                             hwi_ipv6_hw_index_t *hw_index_p);
sx_status_t hwd_hw_ipv6_unlock(hwi_ipv6_hw_handle_t handle);


#endif /* __IPV6_MGR_H__ */
