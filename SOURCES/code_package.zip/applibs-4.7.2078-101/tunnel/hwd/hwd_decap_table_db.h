/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWD_DECAP_TABLE_DB_H__
#define __HWD_DECAP_TABLE_DB_H__

#include "sx/utils/sdk_refcount.h"

#define ACL_INVALID_ID 0xFFFFFFFF

/* Set log level */
sx_status_t hwd_decap_table_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
/* Get region id */
void decap_table_db_get_region_id(sx_ip_version_t ip_version, sx_acl_region_id_t *region_id);
/* Set region id*/
void decap_table_db_set_region_id(sx_ip_version_t ip_version, sx_acl_region_id_t region_id);
/* Get current region size */
void decap_table_db_get_region_size(sx_ip_version_t ip_version, uint32_t *region_size);
/* Set new region size */
void decap_table_db_set_region_size(sx_ip_version_t ip_version, uint32_t region_size);
/* Get psort handle */
void decap_table_db_get_psort_handle(sx_ip_version_t ip_version, psort_handle_t *psort_handle);
/* Set psort handle */
void decap_table_db_set_psort_handle(sx_ip_version_t ip_version, psort_handle_t psort_handle);
/* Generate unique id*/
sx_status_t decap_table_db_generate_unique_entry_id(uint32_t *decap_entry_id_p);
/* Free unique id*/
sx_status_t decap_table_db_free_unique_entry_id(uint32_t decap_entry_id);
/* Add entry to maps */
sx_status_t decap_table_db_map_entry_add(const sx_tunnel_decap_entry_key_t  *key,
                                         const sx_tunnel_decap_entry_data_t *data,
                                         int                                 priority,
                                         sx_acl_rule_offset_t                acl_rule_offset,
                                         sdk_ref_t                           vrid_ref,
                                         sdk_ref_t                           fpp_ref,
                                         sx_acl_id_t                        *acl_group_id,
                                         uint32_t                            decap_entry_id);
/* Edit entry in maps */
sx_status_t decap_table_db_map_entry_edit(const sx_tunnel_decap_entry_key_t  *key,
                                          const sx_tunnel_decap_entry_data_t *data,
                                          sx_acl_id_t                        *acl_group_id);
/* Delete entry from maps */
sx_status_t decap_table_db_map_entry_delete(sx_ip_version_t version, const sx_acl_rule_offset_t index);
/* Move entry in maps */
sx_status_t decap_table_db_map_entry_move(const sx_ip_version_t      version,
                                          const sx_acl_rule_offset_t old_index,
                                          const sx_acl_rule_offset_t new_index,
                                          const uint32_t             size);
/* Find an entry in key map */
sx_status_t decap_table_db_map_entry_find(const sx_tunnel_decap_entry_key_t *key,
                                          sx_tunnel_decap_entry_data_t      *data,
                                          sx_acl_rule_offset_t              *offset_p,
                                          int                               *priority);

/* Get vrid ref by key */
sx_status_t decap_table_db_get_ref(const sx_tunnel_decap_entry_key_t *key,
                                   sdk_ref_t                         *vrid_ref_p,
                                   sdk_ref_t                         *fpp_ref_p);

/* Bind acl to nve port */
sx_status_t decap_table_db_bind_acl(sx_port_log_id_t nve_port, sx_acl_id_t acl_group_id);

/* Unbind acl from nve port */
sx_status_t decap_table_db_unbind_acl(sx_port_log_id_t nve_port);

/* Get bound acl of nve port */
sx_status_t decap_table_db_get_bound_acl(sx_port_log_id_t nve_port, sx_acl_id_t *acl_group_id_p);

/* Get bound decap entries */
sx_status_t decap_table_db_get_bound_entries(sx_port_log_id_t               nve_port,
                                             sx_tunnel_decap_entry_key_t  **key_p_list_p,
                                             sx_tunnel_decap_entry_data_t **data_p_list_p,
                                             sx_acl_rule_offset_t          *index_list_p,
                                             uint16_t                      *entries_count_p);

/* Init db with initial region size */
sx_status_t decap_table_db_init(uint32_t region_size);
/* Deinit db */
sx_status_t decap_table_db_deinit(boolean_t force_deinit);
/* Verify the integrity of db */
sx_status_t decap_table_db_integrity_verification(void);
/* Dump the table in order of index */
sx_status_t decap_table_db_dump_index_map(dbg_dump_params_t *dbg_dump_params_p);
/* Returns total num decap rules in hwd db */
uint32_t decap_table_db_key_map_count_get(void);
/* Iterator to get matching decap table rules */
sx_status_t decap_table_db_iter_rule_list_get(const sx_tunnel_decap_entry_key_t    *key,
                                              const sx_tunnel_decap_entry_filter_t *filter_p,
                                              sx_tunnel_decap_entry_key_t          *rule_list_p,
                                              uint32_t                             *rule_cnt_p);

#endif /* ifndef __HWD_DECAP_TABLE_DB_H__ */
