/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWD_TUNNEL_DB_H__
#define __HWD_TUNNEL_DB_H__

#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <sx/sdk/sx_types.h>

#include "tunnel/hwi/tunnel_impl.h"
#include "ethl3/hwd/hwd_rif/hwd_rif.h"
#include <kvd/kvd_linear_manager.h>

#include <sx/sdk/sx_tunnel.h>
#include <sx/sdk/sx_tunnel_id.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct hwd_rtdp {
    struct ku_rtdp_reg ku_rtdp;
} hwd_rtdp_t;

typedef struct hwd_tngcr {
    struct ku_tngcr_reg ku_tngcr;
} hwd_tngcr_t;

typedef struct hwd_tigcr {
    struct ku_tigcr_reg ku_tigcr;
} hwd_tigcr_t;

typedef struct hwd_tnpc {
    struct ku_tnpc_reg ku_tnpc;
} hwd_tnpc_t;

typedef struct hwd_tunnel_db {
    cl_qmap_t  rtdp_map;    /* key is hwi_tunnel_hw_decap_handle_t */
    cl_qpool_t rtdp_pool;
    cl_qmap_t  encap_map;   /* key is hwi_tunnel_hw_encap_handle_t */
    cl_qpool_t encap_pool;
    uint32_t   encap_index_last;
    cl_qpool_t free_vtep_id_pool;
    uint32_t   next_vtep_index;
} hwd_tunnel_db_t;

typedef struct hwd_tunnel_decap_entry {
    cl_pool_item_t pool_item;
    cl_map_item_t  map_item;
    hwd_rtdp_t     data;
} hwd_tunnel_decap_entry_t;

typedef struct hwd_tunnel_vtep_entry {
    cl_pool_item_t           pool_item;
    hwd_tunnel_encap_index_t vtep_id;
} hwd_tunnel_vtep_entry_t;

typedef sx_status_t (*hwd_rtdp_db_apply_pfn_t)(hwd_rtdp_t *db_elem_p,
                                               const void *params_p);

typedef struct hwd_tunnel_encap_data {
    hwd_tunnel_encap_index_t hw_tunnel_index; /* index is initialized on new entry create. Should not be modified */
    sx_tunnel_type_e         type;
    union {
        hwd_rif_id_t             rif_id;
        hwd_tunnel_vtep_entry_t *vtep_entry;
    } encap_attr;
} hwd_tunnel_encap_data_t;

typedef struct hwd_tunnel_encap_entry {
    cl_pool_item_t          pool_item;
    cl_map_item_t           map_item;
    hwd_tunnel_encap_data_t data;
} hwd_tunnel_encap_entry_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t hwd_tunnel_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t hwd_tunnel_db_init(const uint32_t tunnel_max_count);
sx_status_t hwd_tunnel_db_deinit(boolean_t is_forced);

/* RTDP DB related operations */
sx_status_t hwd_rtdp_db_get(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle,
                            hwd_rtdp_t                        *hwd_rtdp_p);
sx_status_t hwd_rtdp_db_get_first(hwd_rtdp_t *hwd_rtdp_p);
sx_status_t hwd_rtdp_db_get_next(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle,
                                 hwd_rtdp_t                        *hwd_rtdp_p);
sx_status_t hwd_rtdp_db_add(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle,
                            const hwd_rtdp_t                  *hwd_rtdp_p);
sx_status_t hwd_rtdp_db_update(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle,
                               const hwd_rtdp_t                  *hwd_rtdp_p);
sx_status_t hwd_rtdp_db_delete(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle);
sx_status_t hwd_rtdp_db_apply(hwd_rtdp_db_apply_pfn_t pfn, const void *params_p);

sx_status_t hwd_rtdp_db_index_get(const hwi_tunnel_hw_decap_handle_t tunnel_block_handle,
                                  hwd_tunnel_decap_index_t          *hw_tunnel_index_p);
sx_status_t hwd_rtdp_db_total_rtdp_get(uint32_t *rtdp_cnt_p);

/* Encap DB operations */
sx_status_t hwd_encap_db_add(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                             const hwd_tunnel_encap_data_t     *hwd_encap_p);
sx_status_t hwd_encap_db_create(hwi_tunnel_hw_encap_handle_t *tunnel_encap_handle_p,
                                hwd_tunnel_encap_data_t      *hwd_encap_p);
sx_status_t hwd_encap_db_delete(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle);
sx_status_t hwd_encap_db_update(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                hwd_tunnel_encap_data_t           *hwd_encap_p);
sx_status_t hwd_encap_db_get(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                             hwd_tunnel_encap_data_t           *hwd_encap_p);
sx_status_t hwd_encap_db_get_first(hwd_tunnel_encap_data_t *hwd_encap_p);
sx_status_t hwd_encap_db_get_next(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                  hwd_tunnel_encap_data_t           *hwd_encap_p);
sx_status_t hwd_encap_db_index_get(const hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                   hwd_tunnel_encap_index_t          *hw_tunnel_index_p);
sx_status_t hwd_encap_db_total_count_get(uint32_t *encap_cnt_p);

sx_status_t hwd_tunnel_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

#endif /* __HWD_TUNNEL_DB_H__ */
