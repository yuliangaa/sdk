/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __IPV6_MGR_DB_H__
#define __IPV6_MGR_DB_H__

#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <complib/cl_fleximap.h>
#include <sx/sdk/sx_types.h>
#include <kvd/kvd_linear_manager.h>
#include <sx/utils/sx_utils_status.h>

#include "hwd_ipv6_mgr.h"
#include "hwd_ipv6_mgr_reg.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define IPV6_POOL_MIN_SIZE  0
#define IPV6_POOL_SIZE_MAX  256000
#define IPV6_POOL_GROW_SIZE 1000

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct hwd_rips {
    struct ku_rips_reg ku_rips;
} hwd_rips_t;

typedef struct hwd_ipv6_db {
    cl_fmap_t  rips_ip_map;     /* key is IPv6 address */
    cl_qmap_t  rips_handle_map; /* key is hwi_ipv6_hw_handle_t */
    cl_qpool_t rips_pool;
} hwd_ipv6_db_t;

typedef struct hwd_ipv6_data {
    sx_ip_addr_t         ip_addr;
    hwi_ipv6_hw_index_t  hw_index;
    hwi_ipv6_hw_handle_t ipv6_block_handle;
    uint32_t             instance_cnt;
    uint32_t             lock_cnt;
} hwd_ipv6_data_t;

typedef struct hwd_ipv6_entry {
    cl_pool_item_t       pool_item;
    cl_fmap_item_t       ip_map_item;
    cl_map_item_t        handle_map_item;
    sx_ip_addr_t         ip_addr;
    hwi_ipv6_hw_index_t  hw_index;
    hwi_ipv6_hw_handle_t ipv6_block_handle;
    uint32_t             instance_cnt;
    uint32_t             lock_cnt;
} hwd_ipv6_entry_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t hwd_rips_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t hwd_rips_db_init_get(boolean_t *is_rips_db_init_done_p);
sx_status_t hwd_rips_db_init_set(boolean_t is_rips_db_init_done_p);

sx_status_t hwd_rips_db_init(void);
sx_status_t hwd_rips_db_deinit(boolean_t is_forced);
sx_status_t hwd_rips_db_add(hwd_ipv6_data_t *rips_data_p);
sx_status_t hwd_rips_db_delete(hwi_ipv6_hw_handle_t ipv6_block_handle);
sx_status_t hwd_rips_db_get(const sx_ip_addr_t *ip_addr_p, hwd_ipv6_data_t *rips_data_p);
sx_status_t hwd_rips_db_get_by_handle(hwi_ipv6_hw_handle_t ipv6_block_handle, hwd_ipv6_data_t *rips_data_p);
sx_status_t hwd_rips_db_update(hwi_ipv6_hw_handle_t ipv6_handle, const hwd_ipv6_data_t *rips_data_p);
sx_status_t hwd_rips_db_total_rips_get(uint32_t *rips_cnt_p);
sx_status_t hwd_rips_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

#endif /* __IPV6_MGR_DB_H__ */
