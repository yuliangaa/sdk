/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __HWD_TUNNEL_REG_H__
#define __HWD_TUNNEL_REG_H__

#include <sx/sxd/sxd_emad_tunnel.h>
#include "tunnel/hwi/tunnel_impl.h"
#include "ethl3/hwd/hwd_rif/hwd_rif.h"
#include "hwd_tunnel_db.h"
#include "hwd_tunnel.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define TUNNEL_NVE_VLAN_DECAP_ETH_TYPE_INDEX_DEFAULT 0
#define TUNNEL_NVE_VLAN_DECAP_ETH_TYPE_DEFAULT       0x8100

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t hwd_tunnel_reg_log_verbosity_level_set(sx_verbosity_level_t verbosity);

sx_status_t hwd_tunnel_reg_urif_internal_callbacks_register();
sx_status_t hwd_tunnel_reg_urif_internal_callbacks_register_spectrum4();
sx_status_t hwd_tunnel_reg_uvrid_internal_callbacks_register();

sx_status_t hwd_tunnel_tigcr_reg_write(sxd_access_cmd_t     access_cmd,
                                       struct ku_tigcr_reg *ku_tigcr);

sx_status_t hwd_tunnel_tngcr_reg_write(struct ku_tngcr_reg *ku_tngcr_p);
sx_status_t hwd_tunnel_hccr_reg_write(struct ku_hccr_reg *ku_hccr_p);
sx_status_t hwd_tunnel_hpkt_reg_write(struct ku_hpkt_reg *ku_hpkt);

sx_status_t hwd_tunnel_tiqdr_reg_write(sxd_access_cmd_t     access_cmd,
                                       struct ku_tiqdr_reg *ku_tiqdr);
sx_status_t hwd_tunnel_tiqcr_reg_write(sxd_access_cmd_t     access_cmd,
                                       struct ku_tiqcr_reg *ku_tiqcr);
sx_status_t hwd_tunnel_tnqdr_reg_write(sxd_access_cmd_t     access_cmd,
                                       struct ku_tnqdr_reg *ku_tnqdr);
sx_status_t hwd_tunnel_tnqcr_reg_write(sxd_access_cmd_t     access_cmd,
                                       struct ku_tnqcr_reg *ku_tnqcr);
sx_status_t hwd_tunnel_tncr_reg_write(sxd_access_cmd_t    access_cmd,
                                      struct ku_tncr_reg *ku_tncr);
sx_status_t hwd_tunnel_tncr_v2_reg_write(sxd_access_cmd_t       access_cmd,
                                         struct ku_tncr_v2_reg *ku_tncr_v2);
sx_status_t hwd_tunnel_tieem_reg_write(sxd_access_cmd_t     access_cmd,
                                       struct ku_tieem_reg *ku_tieem);
sx_status_t hwd_tunnel_tidem_reg_write(sxd_access_cmd_t     access_cmd,
                                       struct ku_tidem_reg *ku_tidem);
sx_status_t hwd_tunnel_tneem_reg_write(sxd_access_cmd_t     access_cmd,
                                       struct ku_tneem_reg *ku_tneem);
sx_status_t hwd_tunnel_tndem_reg_write(sxd_access_cmd_t     access_cmd,
                                       struct ku_tndem_reg *ku_tndem);
sx_status_t hwd_tunnel_rtdp_reg_write(sxd_access_cmd_t    access_cmd,
                                      struct ku_rtdp_reg *ku_rtdp);

sx_status_t hwd_tunnel_write_rtdp_to_dev(hwd_rtdp_t *db_elem_p, const void *params_p);

sx_status_t hwd_tunnel_default_registers_write(hwd_tunnel_global_config_t *tunnel_global_params_p);

sx_status_t hwd_tunnel_deinit_registers(hwd_tunnel_global_config_t *global_config_p);

sx_status_t hwd_tunnel_update_tngcr(hwd_tunnel_global_config_t *global_config_p,
                                    const sx_tunnel_nve_encap_attributes_t *nve_encap_p,
                                    hwd_rif_id_t underlay_rif,
                                    sxd_tunnel_nve_type_t type, boolean_t is_valid,
                                    boolean_t learn_enable,
                                    uint8_t et_vlan,
                                    boolean_t dis_nve_opt_chk,
                                    uint64_t hdr_bits);
sx_status_t hwd_tunnel_update_tnpc(uint8_t   tunnel_port,
                                   boolean_t learn_enable,
                                   boolean_t filter_enable);
sx_status_t hwd_tunnel_rtdp_prepare(const sx_tunnel_attribute_t     *tunnel_attr_p,
                                    hwd_rif_id_t                     overlay_rif,
                                    hwd_rif_id_t                     underlay_rif,
                                    const kvd_linear_manager_index_t rtdp_index,
                                    hwd_rtdp_t                      *hwd_rtdp_p);

sx_status_t hwd_tunnel_tncr_get(boolean_t is_clear, struct ku_tncr_reg ** ku_tncr, uint32_t *size);
sx_status_t hwd_tunnel_tncr_v2_get(const boolean_t is_clear,
                                   const uint8_t tunnel_port,
                                   struct ku_tncr_v2_reg ** ku_tncr, uint32_t *size);

sx_status_t hwd_tunnel_tnifr_prepare(const sx_access_cmd_t         cmd,
                                     const sx_swid_t               swid,
                                     const sx_device_id_t          device_id,
                                     const sx_port_log_id_t        log_port,
                                     const sx_port_isolate_table_e isolation_table,
                                     const sx_port_log_id_t      * isolate_port_list,
                                     const uint32_t                log_port_num,
                                     struct ku_tnifr_v2_reg      * tnifr_v2_reg_data);


sx_status_t hwd_tunnel_tncr_clear();

sx_status_t hwd_tunnel_tncr_v2_clear();

sx_status_t hwd_tunnel_tngcr_to_reserved_bits_unpack(struct ku_tngcr_reg *ku_tngcr_p,
                                                     boolean_t           *dis_nve_opt_chk_p,
                                                     uint64_t            *hdr_bits_p);
#endif /* __HWD_TUNNEL_REG_H__ */
