/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __DECAP_TABLE_H__
#define __DECAP_TABLE_H__

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_tunnel.h>
#include <sx/sdk/sx_status.h>
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/* function pointers for HWD APIs */
typedef struct hwi_decap_table_ops {
    sx_status_t (*hwd_decap_table_add_entry_pfn)(const sx_tunnel_decap_entry_key_t * key,
                                                 const sx_tunnel_decap_entry_data_t* data);

    sx_status_t (*hwd_decap_table_edit_entry_pfn)(const sx_tunnel_decap_entry_key_t * key,
                                                  const sx_tunnel_decap_entry_data_t* data);

    sx_status_t (*hwd_decap_table_delete_entry_pfn)(const sx_tunnel_decap_entry_key_t* key);

    sx_status_t (*hwd_decap_table_get_entry_pfn)(const sx_tunnel_decap_entry_key_t * key,
                                                 sx_tunnel_decap_entry_data_t      * data);

    sx_status_t (*hwd_decap_table_bind_acl_pfn)(sx_port_log_id_t nve_port, sx_acl_id_t acL_group_id);

    sx_status_t (*hwd_decap_table_unbind_acl_pfn)(sx_port_log_id_t nve_port);

    sx_status_t (*hwd_decap_table_init_pfn)();

    sx_status_t (*hwd_decap_table_deinit_pfn)(boolean_t force_deinit);

    sx_status_t (*hwd_decap_table_dbg_generate_dump_pfn)(dbg_dump_params_t *dbg_dump_params_p);
    sx_status_t (*hwd_decap_table_iter_get_pfn)(const sx_access_cmd_t                 cmd,
                                                const sx_tunnel_decap_entry_key_t     key,
                                                const sx_tunnel_decap_entry_filter_t *filter_p,
                                                sx_tunnel_decap_entry_key_t          *rule_list_p,
                                                uint32_t                             *rule_cnt_p);
} hwi_decap_table_ops_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/* Set log level */
sx_status_t sdk_decap_table_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
/* Init decap table */
sx_status_t decap_table_impl_init();
/* Deinit decap table */
sx_status_t decap_table_impl_deinit(boolean_t force_deinit);
/* Add an entry to decap table with key and data */
sx_status_t decap_table_impl_add_entry(const sx_tunnel_decap_entry_key_t * key,
                                       const sx_tunnel_decap_entry_data_t* data);
/* Update an existed entry with the new data */
sx_status_t decap_table_impl_edit_entry(const sx_tunnel_decap_entry_key_t * key,
                                        const sx_tunnel_decap_entry_data_t* data);
/* Delete an entry from decap table */
sx_status_t decap_table_impl_delete_entry(const sx_tunnel_decap_entry_key_t* key);
/* Get an entry from decap table */
sx_status_t decap_table_impl_get_entry(const sx_tunnel_decap_entry_key_t* key,
                                       sx_tunnel_decap_entry_data_t     * data);
/* Bind acl group to nve port */
sx_status_t decap_table_impl_bind_acl(sx_port_log_id_t nve_port, sx_acl_id_t acl_group_id);
/* Unbind acl group from nve port */
sx_status_t decap_table_impl_unbind_acl(sx_port_log_id_t nve_port);

/* Dump the decap table */
sx_status_t decap_table_impl_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);

sx_status_t decap_table_impl_register_hwd_ops(hwi_decap_table_ops_t *ops);

sx_status_t decap_table_impl_unregister_hwd_ops(void);

sx_status_t hwd_decap_table_assign_ops(hwi_decap_table_ops_t *ops);

sx_status_t decap_table_impl_params_set(boolean_t is_tunnel_init_done);

sx_status_t decap_table_rule_total_count_get(uint32_t *count_p);

sx_status_t decap_table_impl_rule_iter_get(const sx_access_cmd_t                 cmd,
                                           const sx_tunnel_decap_entry_key_t     key,
                                           const sx_tunnel_decap_entry_filter_t *filter_p,
                                           sx_tunnel_decap_entry_key_t          *key_list_p,
                                           uint32_t                             *key_cnt_p);
#endif /* ifndef __DECAP_TABLE_H__ */
