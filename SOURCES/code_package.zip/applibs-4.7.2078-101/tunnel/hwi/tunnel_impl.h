/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWI_TUNNEL_IMPL_H__
#define __HWI_TUNNEL_IMPL_H__

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_tunnel.h>
#include "tunnel_db.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define TUNNEL_REF_NAME_MAX_LEN     14
#define SPECTRUM_NVE_URIF           0x3FF
#define TUNNEL_NVE_FLOOD_PROFILE_ID 0
#define TUNNEL_NVE_FLOOD_OFFSET     0

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef enum sx_tunnel_capability_type {
    SX_TUNNEL_CAP_ACL_DECAP_E            = 1,
    SX_TUNNEL_CAP_FDB_ENCAP_E            = 2,
    SX_TUNNEL_CAP_NEXTHOP_ENCAP_E        = 4,
    SX_TUNNEL_CAP_COUNTER_READ_E         = 8,                           /**< Capability to read the global tunnel counter;
                                                                         *    applicable to NVE and Flex tunnels */
    SX_TUNNEL_CAP_BRIDGE_DECAP_COUNTER_E = 0x10,
    SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E = 0x20,
    SX_TUNNEL_CAP_ACL_ENCAP_E            = 0x40,                        /**< Capability to do encapsulation with UC ACL with a single next-hop;
                                                                         *     not checked by MC tunnel ACL and UC ACL with ECMP for unknown reason */
    SX_TUNNEL_CAP_IPV6_E                 = 0x80,
    SX_TUNNEL_CAP_RPF_E                  = 0x100,
    SX_TUNNEL_CAP_MC_NVE_DECAP_ERIF_E    = 0x200,
    SX_TUNNEL_CAP_MIN_E                  = SX_TUNNEL_CAP_ACL_DECAP_E,
    SX_TUNNEL_CAP_MAX_E                  = SX_TUNNEL_CAP_IPV6_E
} sx_tunnel_capability_type_e;

typedef struct sdk_tunnel_init_params {
    sx_tunnel_general_params_t general_param;
} sdk_tunnel_init_params_t;

typedef struct {
    sx_tunnel_id_t        tunnel_id;
    sx_router_interface_t rif;
} rif_tunnel_t;

typedef struct {
    sx_tunnel_id_t            tunnel_id;
    sx_tunnel_type_e          tunnel_type;
    sx_router_interface_t     encap_urif;
    sx_cos_tq_profile_id_e    qos_profile;
    sx_flex_modifier_emt_id_e emt_id;
    sx_port_tunnel_phy_id_t   port_tunnel_phy_id;
} tunnel_info_t;

typedef struct post_tunnel_attrs_edit_event_data {
    sx_tunnel_id_t tunnel_id;
    tunnel_info_t  old_tunnel_info;
    tunnel_info_t  new_tunnel_info;
} post_tunnel_attrs_edit_event_data_t;

/* Function pointers for HWI APIs */
typedef struct tunnel_ops {
    sx_status_t (*hwi_tunnel_impl_init_hwd_pfn)(void);
    sx_status_t (*hwi_tunnel_impl_prepare_create_pfn)(sx_tunnel_attribute_t * tunnel_attr_p,
                                                      sx_tunnel_id_t        * tunnel_id_p);
    sx_status_t (*hwi_tunnel_impl_prepare_create_rollback_pfn)(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                               sx_tunnel_id_t              * tunnel_id_p);
    sx_status_t (*hwi_tunnel_impl_delete_action_pfn)(sx_tunnel_id_t              tunnel_id,
                                                     const sdk_db_tunnel_data_t *tunnel_params_p);
    sx_status_t (*hwi_tunnel_impl_delete_action_rollback_pfn)(sx_tunnel_id_t              tunnel_id,
                                                              const sdk_db_tunnel_data_t *tunnel_params_p);
    sx_status_t (*hwi_tunnel_impl_edit_action_pfn)(sx_tunnel_id_t              tunnel_id,
                                                   const sdk_db_tunnel_data_t *tunnel_params_p,
                                                   sx_tunnel_attribute_t      *old_tunnel_attr,
                                                   sx_tunnel_attribute_t     * new_tunnel_attr_p);
    sx_status_t (*hwi_tunnel_impl_post_edit_action_pfn)(sx_tunnel_id_t                tunnel_id,
                                                        sx_tunnel_attribute_t        *old_tunnel_attr,
                                                        const sx_tunnel_attribute_t * new_tunnel_attr_p);
    sx_status_t (*hwi_tunnel_impl_edit_action_rollback_pfn)(sx_tunnel_id_t                tunnel_id,
                                                            const sdk_db_tunnel_data_t   *tunnel_params_p,
                                                            sx_tunnel_attribute_t        *old_tunnel_attr,
                                                            const sx_tunnel_attribute_t * new_tunnel_attr_p);
    sx_status_t (*hwi_tunnel_impl_check_learn_mode_pfn)(sx_port_log_id_t    log_port,
                                                        sx_fdb_learn_mode_t learn_mode);
    sx_status_t (*hwi_tunnel_impl_counter_get_pfn)(const sx_tunnel_id_t        tunnel_id,
                                                   const sdk_db_tunnel_data_t *tunnel_params_p,
                                                   boolean_t                   is_clear,
                                                   sx_tunnel_counter_t        *counter);
    sx_status_t (*hwi_tunnel_impl_check_init_params_pfn)(sx_tunnel_general_params_t * params_p);
    boolean_t (*hwi_tunnel_impl_l3_gw_supported)(sx_tunnel_id_t tunnel_id);
    sx_status_t (*hwi_tunnel_impl_attr_validate_pfn)(sx_tunnel_attribute_t * tunnel_attr_p);
} tunnel_ops_t;

/************************************************
 *  Forward declarations
 ***********************************************/

struct hwd_tunnel_ops;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/*
 * Init tunneling module ops function callback structure
 */
sx_status_t sdk_tunnel_init_ops(void);

sx_status_t sdk_tunnel_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_router_id_t tunnel_impl_get_underlay_vrid(const sx_tunnel_attribute_t * tunnel_attr_p);

sx_port_log_id_t tunnel_impl_get_l2_log_port(const sx_tunnel_attribute_t * tunnel_attr_p);

sx_status_t tunnel_impl_get_ipinip_overlay_rif(const sx_tunnel_attribute_t * tunnel_attr_p,
                                               sx_router_interface_t       * ipinip_overlay_rif);


sx_status_t tunnel_impl_get_underlay_rif(const sx_tunnel_attribute_t * tunnel_attr_p,
                                         sx_router_interface_t       * underlay_rif_p);

sx_status_t tunnel_impl_set_encap_underlay_rif(sx_tunnel_attribute_t * tunnel_attr_p,
                                               sx_router_interface_t   underlay_rif);

sx_status_t tunnel_impl_set_underlay_rif(sx_tunnel_attribute_t * tunnel_attr_p, sx_router_interface_t underlay_rif);

sx_status_t tunnel_impl_set_decap_underlay_rif(sx_tunnel_attribute_t * tunnel_attr_p,
                                               sx_router_interface_t   underlay_rif);

sx_status_t tunnel_impl_get_underlay_decap_rif(const sx_tunnel_attribute_t * tunnel_attr_p,
                                               sx_router_interface_t       * underlay_rif_p);

sx_tunnel_underlay_domain_type_e tunnel_impl_get_underlay_domain_type(const sx_tunnel_attribute_t * tunnel_attr_p);

const char* get_tunnel_rif_ref_name(char* name_buf, size_t name_size, void* data);

sx_status_t sdk_tunnel_impl_init(sx_tunnel_general_params_t * tunnel_gen_params_p);

sx_status_t sdk_tunnel_impl_deinit(boolean_t is_forced);

sx_status_t sdk_tunnel_impl_create(const sx_tunnel_attribute_t * tunnel_attr_p,
                                   sx_tunnel_id_t              * tunnel_id_p);

sx_status_t sdk_tunnel_impl_delete(sx_tunnel_id_t tunnel_id);

/* API is not protected with a check the lazy delete state of tunnel.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_edit(sx_tunnel_id_t                tunnel_id,
                                 const sx_tunnel_attribute_t * tunnel_attr_p);

/* API is not proceed with the lazy delete state check. Use it carefully */
sx_status_t sdk_tunnel_impl_get(sx_tunnel_id_t          tunnel_id,
                                sx_tunnel_attribute_t * tunnel_attr_p);

sx_status_t sdk_tunnel_impl_register_hwd_ops(struct hwd_tunnel_ops *ops);
sx_status_t sdk_tunnel_impl_unregister_hwd_ops(void);

sx_status_t sdk_tunnel_impl_register_tunnel_ops(tunnel_ops_t *ops_p);
sx_status_t sdk_tunnel_impl_unregister_tunnel_ops(void);

sx_status_t sdk_tunnel_impl_params_get(boolean_t *is_tunnel_init_done_p);
sx_status_t sdk_tunnel_impl_params_set(boolean_t is_tunnel_init_done_p);

sx_status_t sdk_tunnel_impl_ref_increase(sx_tunnel_id_t    tunnel_id,
                                         ref_name_data_t * ref_name_data,
                                         sdk_ref_t       * ref_p,
                                         uint64_t          capability_mask);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t sdk_tunnel_impl_capability_check(sx_tunnel_id_t tunnel_id,
                                             uint64_t       capability_mask);

sx_status_t sdk_tunnel_impl_ref_decrease(sx_tunnel_id_t tunnel_id, const sdk_ref_t* ref_p);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t sdk_tunnel_impl_hw_decap_lock(sx_tunnel_id_t            tunnel_id,
                                          hwd_tunnel_decap_index_t *tunnel_hwd_index_p);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t sdk_tunnel_impl_hw_decap_unlock(sx_tunnel_id_t tunnel_id);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t sdk_tunnel_impl_hw_encap_lock(sx_tunnel_id_t            tunnel_id,
                                          hwd_tunnel_encap_index_t *tunnel_hwd_index_p);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t sdk_tunnel_impl_hw_encap_unlock(sx_tunnel_id_t tunnel_id);

/* API is not protected with a check the lazy delete state of tunnel.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_counter_get(const sx_tunnel_id_t tunnel_id,
                                        boolean_t            is_clear,
                                        sx_tunnel_counter_t *counter);

/* SET/DELETE tunnel FID counter */
/* API is not protected with a check the lazy delete state of tunnel.
 * The lazy delete state check is done in the sdk_bridge_tunnel_counter_bind_set */
sx_status_t sdk_tunnel_impl_fid_counter_set(const sx_access_cmd_t           cmd,
                                            sx_tunnel_id_t                  tunnel_id,
                                            sx_fid_t                        fid,
                                            sx_bridge_tunnel_counter_type_t counter_type,
                                            sx_flow_counter_id_t            counter_id);

/* Get tunnel FID counter */
/* API is not protected with a check the lazy delete state of tunnel.
 * The lazy delete state check is done in the sdk_bridge_tunnel_counter_bind_set */
sx_status_t sdk_tunnel_impl_fid_counter_get(sx_tunnel_id_t                  tunnel_id,
                                            sx_fid_t                        fid,
                                            sx_bridge_tunnel_counter_type_t counter_type,
                                            sx_flow_counter_id_t           *counter_id_p);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t sdk_tunnel_impl_log_port_by_tunnel_id_get(sx_tunnel_id_t    tunnel_id,
                                                      sx_port_log_id_t *log_port_p);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t sdk_tunnel_impl_tunnel_id_by_log_port_get(sx_port_log_id_t log_port,
                                                      sx_tunnel_id_t  *tunnel_id_p);

void sdk_tunnel_impl_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

/* API is not protected with a check the lazy delete state of tunnel.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_mapping_add(const sx_tunnel_id_t         tunnel_id,
                                        const sx_tunnel_map_entry_t *map_entries_p,
                                        const uint32_t               map_entries_cnt);

sx_status_t sdk_tunnel_impl_mapping_delete(const sx_tunnel_id_t         tunnel_id,
                                           const sx_tunnel_map_entry_t *map_entries_p,
                                           const uint32_t               map_entries_cnt);

sx_status_t sdk_tunnel_impl_mapping_delete_all(const sx_tunnel_id_t tunnel_id);

/* API is not protected with a check the lazy delete state of tunnel.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_mapping_get_first(const sx_tunnel_id_t   tunnel_id,
                                              sx_tunnel_map_entry_t *map_entries_p,
                                              uint32_t              *map_entries_cnt);

/* API is not protected with a check the lazy delete state of tunnel.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_mapping_get_next(const sx_tunnel_id_t   tunnel_id,
                                             sx_tunnel_map_entry_t  map_entry_key,
                                             sx_tunnel_map_entry_t *map_entries_p,
                                             uint32_t              *map_entries_cnt);

/* API is protected with a check of the lazy delete state of tunnel.
 * If tunnel is deleted by user, it returns ENTRY_NOT_FOUND */
sx_status_t sdk_tunnel_impl_mapping_ref_cnt_increase(const sx_tunnel_id_t tunnel_id,
                                                     const sx_fid_t       fid,
                                                     ref_name_data_t     *ref_name_data,
                                                     sdk_ref_t           *ref_p);

sx_status_t sdk_tunnel_impl_mapping_ref_cnt_decrease(const sx_tunnel_id_t tunnel_id,
                                                     const sx_fid_t       fid,
                                                     const sdk_ref_t     *ref_p);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t sdk_tunnel_impl_mapping_get_by_fid(sx_tunnel_id_t         tunnel_id,
                                               sx_fid_t               fid,
                                               sx_tunnel_map_entry_t *map_entry);

sx_status_t sdk_tunnel_impl_port_isolate_set(const sx_access_cmd_t         cmd,
                                             const sx_swid_t               swid,
                                             const sx_device_id_t          device_id,
                                             const sx_port_log_id_t        log_port,
                                             const sx_port_isolate_table_e isolation_table,
                                             const sx_port_log_id_t      * port_list_p,
                                             const uint32_t                log_port_num);

/* API is not protected with the lazy delete state check.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_ttl_set(const sx_tunnel_id_t        tunnel_id,
                                    const sx_tunnel_ttl_data_t *ttl_data_p);

/* API is not protected with the lazy delete state check.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_ttl_get(const sx_tunnel_id_t  tunnel_id,
                                    sx_tunnel_ttl_data_t *ttl_data_p);

/* API is not protected with the lazy delete state check.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_hash_set(const sx_tunnel_id_t         tunnel_id,
                                     const sx_tunnel_hash_data_t *hash_data_p);

/* API is not protected with the lazy delete state check.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_hash_get(const sx_tunnel_id_t   tunnel_id,
                                     sx_tunnel_hash_data_t *hash_data_p);

/* API is not protected with the lazy delete state check.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_cos_set(const sx_tunnel_id_t        tunnel_id,
                                    const sx_tunnel_cos_data_t *cos_data_p);

/* API is not protected with the lazy delete state check.
 * The lazy delete state check is done on the BE layer */
sx_status_t sdk_tunnel_impl_cos_get(const sx_tunnel_id_t  tunnel_id,
                                    sx_tunnel_cos_data_t *cos_data_p);

/* API is protected with a check of the lazy delete state of tunnel.
 * If tunnel is deleted by user, it returns ENTRY_NOT_FOUND */
sx_status_t sdk_tunnel_impl_mapping_exists(sx_tunnel_id_t tunnel_id, sx_fid_t fid);

/* API is protected with a check of the lazy delete state of tunnel.
 * If tunnel is deleted by user, it returns ENTRY_NOT_FOUND */
sx_status_t sdk_tunnel_check_learn_mode(sx_port_log_id_t    log_port,
                                        sx_fdb_learn_mode_t learn_mode);

sx_status_t sdk_tunnel_impl_assign_hwd_ops(void);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t spectrum_tunnel_impl_rif_by_tunnel_id_get(const sx_tunnel_id_t   tunnel_id,
                                                      sx_router_interface_t *encap_urif_p,
                                                      sx_router_interface_t *decap_urif_p);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t spectrum2_tunnel_impl_rif_by_tunnel_id_get(const sx_tunnel_id_t   tunnel_id,
                                                       sx_router_interface_t *encap_urif_p,
                                                       sx_router_interface_t *decap_urif_p);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t tunnel_impl_rif_by_tunnel_id_get(const sx_tunnel_id_t   tunnel_id,
                                             sx_router_interface_t *encap_urif_p,
                                             sx_router_interface_t *decap_urif_p);

/* API is not protected with the lazy delete state check. Use it carefully */
sx_status_t tunnel_impl_tunnel_info_get(const sx_tunnel_id_t tunnel_id,
                                        tunnel_info_t       *tunnel_info);

/* Configure a tunnel flexible header */
sx_status_t sdk_tunnel_impl_flex_header_create(const sx_tunnel_flex_header_cfg_t *header_cfg,
                                               sx_tunnel_flex_header_id_t        *header_id);
sx_status_t sdk_tunnel_impl_flex_header_edit(const sx_tunnel_flex_header_id_t   header_id,
                                             const sx_tunnel_flex_header_cfg_t *header_cfg);
sx_status_t sdk_tunnel_impl_flex_header_destroy(const sx_tunnel_flex_header_id_t header_id);

sx_status_t sdk_tunnel_impl_flex_header_bind(const sx_tunnel_flex_header_id_t header_id,
                                             const sx_tunnel_id_t             tunnel_id,
                                             const sx_router_interface_t      uirif);
sx_status_t sdk_tunnel_impl_flex_header_unbind(const sx_tunnel_flex_header_id_t header_id,
                                               const sx_tunnel_id_t             tunnel_id);
sx_status_t sdk_tunnel_impl_flex_header_bind_get(const sx_tunnel_flex_header_id_t header_id,
                                                 sx_tunnel_id_t                  *tunnel_id_p);

sx_status_t sdk_tunnel_impl_issu_set();
sx_status_t sdk_tunnel_impl_nve_learn_set(sx_port_log_id_t log_port, boolean_t learn_enable);
sx_status_t sdk_tunnel_impl_nve_loopback_filter_set(const sx_port_log_id_t         nve_log_port,
                                                    sx_port_loopback_filter_mode_t lbf_mode);

sx_status_t sdk_tunnel_impl_object_refcount_get(const sx_object_id_t *object_p, uint32_t *refcount_p);
sx_status_t sdk_tunnel_impl_map_entry_ref_inc_dec(sx_access_cmd_t  cmd,
                                                  sx_tunnel_id_t   tunnel_id,
                                                  sx_fid_t         fid,
                                                  ref_name_data_t *ref_name_data_p,
                                                  sdk_ref_t       *ref_p);

sx_status_t sdk_tunnel_impl_ecmp_nve_flood_size_get(uint32_t *ecmp_nve_flood_size_p);
sx_status_t sdk_tunnel_impl_ecmp_nve_mc_size_get(uint32_t *ecmp_nve_mc_size_p);
sx_status_t sdk_tunnel_impl_zeroed_reserved_tngee_index_get(kvd_linear_manager_index_t *kvd_index_p);

/* The helper function to check if given tunnel supports overlay routing.
 *  The function is not not protected with the lazy delete state check. Use it carefully.
 *  Should be called once all other checks on tunnel passed. */
boolean_t sdk_tunnel_impl_l3_gw_supported(sx_tunnel_id_t tunnel_id);

sx_status_t sdk_tunnel_impl_attr_validate(sx_tunnel_attribute_t *tunnel_attr_p);

sx_status_t sdk_tunnel_trap_nve_options_set(const struct ku_hpkt_reg *nve_options_hpkt_p,
                                            boolean_t                *skip_sending_hpkt_p);

#endif /* __HWI_TUNNEL_IMPL_H__ */
