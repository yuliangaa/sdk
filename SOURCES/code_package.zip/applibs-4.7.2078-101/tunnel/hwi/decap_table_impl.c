/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "acl/flex_acl_db.h"
#include "hwi/decap_table_impl.h"
#include "hwd/hwd_decap_table.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"

#undef  __MODULE__
#define __MODULE__ TUNNEL

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static boolean_t g_is_initialized = FALSE;
static uint32_t  g_decap_table_size = 0;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static hwi_decap_table_ops_t g_ops;
static boolean_t             g_ops_init = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __decap_table_impl_verify_data(const sx_tunnel_decap_entry_data_t *data)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if ((data->action == SX_ROUTER_ACTION_TRAP) || (data->action == SX_ROUTER_ACTION_TRAP_FORWARD)) {
        if (data->trap_attr.prio > SX_TRAP_PRIORITY_MAX) {
            SX_LOG(SX_LOG_ERROR, "Wrong trap priority.\n");
            sx_status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    return sx_status;
}

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sdk_decap_table_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    hwd_decap_table_log_verbosity_level_set(verbosity_level);

    return err;
}

sx_status_t decap_table_impl_params_set(boolean_t is_tunnel_init_done)
{
    g_is_initialized = is_tunnel_init_done;
    return SX_STATUS_SUCCESS;
}

sx_status_t decap_table_impl_init()
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    hwi_decap_table_ops_t hwi_decap_table_ops;

    SX_LOG_DBG("decap table init\n");

    if (g_is_initialized) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Decap table already initialized\n");
        goto out;
    }

    err = hwd_decap_table_assign_ops(&hwi_decap_table_ops);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init decap table, hwd ops assign error = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = decap_table_impl_register_hwd_ops(&hwi_decap_table_ops);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init decap table, hwd ops register error = %s\n",
                   sx_status_str(err));
        goto out;
    }
    if (g_ops.hwd_decap_table_init_pfn == NULL) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to init decap table, error = %s\n", sx_status_str(err));
        goto out;
    }
    err = g_ops.hwd_decap_table_init_pfn();

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init decap table hwd\n");
        goto out;
    }

    g_is_initialized = TRUE;
    g_decap_table_size = 0;

out:

    SX_LOG_EXIT();

    return err;
}

sx_status_t decap_table_impl_add_entry(const sx_tunnel_decap_entry_key_t  *key,
                                       const sx_tunnel_decap_entry_data_t *data)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_DBG("add decap entry, g_decap_table_size (%u)\n", g_decap_table_size);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(key, "key"))) {
        SX_LOG(SX_LOG_ERROR, "decap entry key is NULL\n");
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(data, "data"))) {
        SX_LOG(SX_LOG_ERROR, "decap entry data is NULL\n");
        goto out;
    }

    /* verify the value of data */
    rc = __decap_table_impl_verify_data(data);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Decap Table : Wrong data. \n");
        goto out;
    }
    if (g_ops.hwd_decap_table_add_entry_pfn == NULL) {
        rc = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR("Cannot add decap entry before tunnel creation\n");
        goto out;
    }
    rc = g_ops.hwd_decap_table_add_entry_pfn(key, data);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Decap Table: Failed to add decap entry\n");
        goto out;
    }

    g_decap_table_size++;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t decap_table_impl_edit_entry(const sx_tunnel_decap_entry_key_t  *key,
                                        const sx_tunnel_decap_entry_data_t *data)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_DBG("edit decap entry\n");

    if (SX_CHECK_FAIL(rc = utils_check_pointer(key, "key"))) {
        SX_LOG(SX_LOG_ERROR, "decap entry key is NULL\n");
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(data, "data"))) {
        SX_LOG(SX_LOG_ERROR, "decap entry data is NULL\n");
        goto out;
    }

    /* verify the value of data */
    rc = __decap_table_impl_verify_data(data);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Decap Table : Wrong data. \n");
        goto out;
    }
    if (g_ops.hwd_decap_table_edit_entry_pfn == NULL) {
        rc = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR("Cannot edit decap entry rule before tunnel creation\n");
        goto out;
    }
    rc = g_ops.hwd_decap_table_edit_entry_pfn(key, data);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t decap_table_impl_delete_entry(const sx_tunnel_decap_entry_key_t *key)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_DBG("delete decap entry, g_decap_table_size (%u)\n", g_decap_table_size);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(key, "key"))) {
        SX_LOG(SX_LOG_ERROR, "decap entry key is NULL\n");
        goto out;
    }

    if (g_ops.hwd_decap_table_delete_entry_pfn == NULL) {
        rc = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR("Cannot delete decap rule before tunnel creation\n");
        goto out;
    }
    rc = g_ops.hwd_decap_table_delete_entry_pfn(key);

    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Decap Table : Failed to delete decap rule\n");
        goto out;
    }

    g_decap_table_size--;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t decap_table_impl_get_entry(const sx_tunnel_decap_entry_key_t *key, sx_tunnel_decap_entry_data_t *data)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(key, "key"))) {
        SX_LOG(SX_LOG_ERROR, "decap entry key is NULL\n");
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(data, "data"))) {
        SX_LOG(SX_LOG_ERROR, "decap entry data is NULL\n");
        goto out;
    }

    if (g_ops.hwd_decap_table_get_entry_pfn == NULL) {
        rc = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR("Cannot get decap table entry before tunnel creation\n");
        goto out;
    }
    rc = g_ops.hwd_decap_table_get_entry_pfn(key, data);

    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG(SX_LOG_ERROR, "Failed to get decap table entry\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t decap_table_impl_bind_acl(sx_port_log_id_t nve_port, sx_acl_id_t acl_group_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (SX_PORT_TYPE_ID_GET(nve_port) != SX_PORT_TYPE_TUNNEL) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Cannot bind to 0x%x which is not nve port\n", nve_port);
        goto out;
    }

    if (acl_group_id == FLEX_ACL_INVALID_ACL_ID) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Cannot bind invalid acl group\n");
        goto out;
    }

    if (g_ops.hwd_decap_table_bind_acl_pfn == NULL) {
        rc = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR("Cannot bind ACLs to tport before tunnel creation\n");
        goto out;
    }
    rc = g_ops.hwd_decap_table_bind_acl_pfn(nve_port, acl_group_id);

    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG(SX_LOG_ERROR, "Failed to bind acl\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t decap_table_impl_unbind_acl(sx_port_log_id_t nve_port)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (SX_PORT_TYPE_ID_GET(nve_port) != SX_PORT_TYPE_TUNNEL) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Cannot bind to 0x%x which is not nve port\n", nve_port);
        goto out;
    }

    if (g_ops.hwd_decap_table_unbind_acl_pfn == NULL) {
        rc = SX_STATUS_CMD_UNPERMITTED;
        SX_LOG_ERR("Cannot unbind ACLs from tport before tunnel creation\n");
        goto out;
    }
    rc = g_ops.hwd_decap_table_unbind_acl_pfn(nve_port);

    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG(SX_LOG_ERROR, "Failed to unbind acl\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t decap_table_impl_deinit(boolean_t force_deinit)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_DBG("decap table deinit, force_deinit(%u), g_decap_table_size(%u)\n", force_deinit, g_decap_table_size);

    if (!g_is_initialized) {
        /* on force deinit if not initialized return success */
        if (force_deinit == FALSE) {
            rc = SX_STATUS_MODULE_UNINITIALIZED;
            SX_LOG_ERR("Decap table not initialized\n");
        }
        goto out;
    }

    if ((force_deinit == FALSE) && (g_decap_table_size > 0)) {
        rc = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("Decap table is not empty, resource in use\n");
        goto out;
    }
    if (g_ops.hwd_decap_table_deinit_pfn == NULL) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed to deinit decap table, rc = %s\n", sx_status_str(rc));
        goto out;
    }
    rc = g_ops.hwd_decap_table_deinit_pfn(force_deinit);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deinit decap table\n");
        goto out;
    }

    decap_table_impl_params_set(FALSE);
    rc = decap_table_impl_unregister_hwd_ops();
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to unregister hwd ops, rc = %s\n",
                   sx_status_str(rc));
        goto out;
    }

    g_is_initialized = FALSE;
    g_decap_table_size = 0;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t decap_table_impl_register_hwd_ops(hwi_decap_table_ops_t *ops_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Decap table impl register hwd ops\n");

    if (utils_check_pointer(ops_p, "ops_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_decap_table_init_pfn,
                            "hwd_decap_table_init_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_decap_table_deinit_pfn,
                            "hwd_decap_table_deinit_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_decap_table_delete_entry_pfn,
                            "hwd_decap_table_delete_entry_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_decap_table_edit_entry_pfn,
                            "hwd_decap_table_edit_entry_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_decap_table_get_entry_pfn,
                            "hwd_decap_table_get_entry_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_decap_table_dbg_generate_dump_pfn,
                            "hwd_tunnel_debug_generate_dump_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_decap_table_iter_get_pfn,
                            "hwd_decap_table_iter_get_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    g_ops = *ops_p;
    g_ops_init = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t decap_table_impl_unregister_hwd_ops(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Decap table impl unregister hwd ops\n");

    if (g_is_initialized) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("Failed to unregister hwd ops\n");
        goto out;
    }

    g_ops_init = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t decap_table_impl_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    if (g_ops.hwd_decap_table_dbg_generate_dump_pfn) {
        sx_status = g_ops.hwd_decap_table_dbg_generate_dump_pfn(dbg_dump_params_p);
        if (sx_status == SX_STATUS_DB_NOT_INITIALIZED) {
            SX_LOG_NTC("Failed to print debug dump of HWD decap table, err= %s.\n", sx_status_str(sx_status));
            sx_status = SX_STATUS_SUCCESS;
        } else if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("Failed to print debug dump of HWD decap table, err= %s.\n", sx_status_str(sx_status));
        }
    }

out:
    return sx_status;
}

sx_status_t decap_table_rule_total_count_get(uint32_t *count_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (utils_check_pointer(count_p, "count_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *count_p = g_decap_table_size;
out:
    return sx_status;
}
sx_status_t decap_table_impl_rule_iter_get(const sx_access_cmd_t                 cmd,
                                           const sx_tunnel_decap_entry_key_t     key,
                                           const sx_tunnel_decap_entry_filter_t *filter_p,
                                           sx_tunnel_decap_entry_key_t          *rule_list_p,
                                           uint32_t                             *rule_cnt_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Decap table impl rule iter get\n");
    if (g_ops.hwd_decap_table_iter_get_pfn) {
        sx_status = g_ops.hwd_decap_table_iter_get_pfn(cmd, key, filter_p, rule_list_p, rule_cnt_p);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("hwd_decap_table_iter_get_pfn failed, err= %s.\n", sx_status_str(sx_status));
            goto out;
        }
    }
out:
    return sx_status;
}
