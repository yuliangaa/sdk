/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#undef  __MODULE__
#define __MODULE__ IPV6_MGR

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/sx_mem.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "ipv6_mgr_impl.h"
#include "tunnel/hwd/hwd_ipv6_mgr.h"

/************************************************
 *  Local defines
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t   g_is_initialized = FALSE;
hwi_ipv6_mgr_ops_t ipv6_mgr_ops_g;
boolean_t          ipv6_mgr_ops_init_g = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t sdk_ipv6_mgr_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    hwd_ipv6_mgr_log_verbosity_level_set(verbosity_level);

    return status;
}

sx_status_t sdk_ipv6_init_hwd_ops(void)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    hwi_ipv6_mgr_ops_t hwi_ipv6_ops;

    SX_LOG_ENTER();

    SX_MEM_CLR(hwi_ipv6_ops);

    err = hwd_ipv6_assign_ops(&hwi_ipv6_ops);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("IPv6 MGR: Failed to init hwd ops. Assign error, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = hwd_ipv6_register_hwd_ops(&hwi_ipv6_ops);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("IPv6 MGR: Failed to register hwd ops, err = %s\n", sx_status_str(err));
        goto out;
    }

out:

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ipv6_impl_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("IPv6 MGR module impl initialize\n");

    if (TRUE == g_is_initialized) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("IPv6 MGR: impl module is already initialized\n");
        goto out;
    }

    err = sdk_ipv6_init_hwd_ops();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init IPv6 MGR. hwd ops assign error, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = ipv6_mgr_ops_g.hwd_ipv6_init_pfn();
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("IPv6 MGR: Failed to init hwd module, err = %s\n", sx_status_str(err));
        goto out;
    }

    g_is_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ipv6_impl_deinit(boolean_t is_forced)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("IPv6 MGR module impl de-initialize\n");

    if (FALSE == g_is_initialized) {
        if (FALSE == is_forced) {
            err = SX_STATUS_MODULE_UNINITIALIZED;
            SX_LOG_ERR("IPv6 MGR module is not initialized.\n");
        }
        /* return success on force de-init if not initialized */
        goto out;
    }

    err = ipv6_mgr_ops_g.hwd_ipv6_deinit_pfn(is_forced);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("IPv6 MGR: Failed to de-init hwd, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = hwd_ipv6_unregister_hwd_ops();
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("IPv6 MGR: Failed to de-init hwd, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    g_is_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ipv6_impl_add(const sx_ip_addr_t *ip_addr_p, hwi_ipv6_hw_handle_t *handle_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    char        ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    if (utils_check_pointer(ip_addr_p, "ip_addr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(handle_p, "handle_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG_DBG("IPv6 MGR impl: add new address [%s]\n", format_ip_addr(ip_addr_p, ip_addr_str));

    if (FALSE == g_is_initialized) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("IPv6 MGR module is not initialized.\n");
        goto out;
    }

    err = ipv6_mgr_ops_g.hwd_ipv6_add_pfn(ip_addr_p, handle_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("IPv6 MGR: Failed to add IPv6 entry [%s] to hwd, err = %s\n",
                   format_ip_addr(ip_addr_p, ip_addr_str), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ipv6_impl_delete(hwi_ipv6_hw_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG_DBG("IPv6 MGR impl: delete ipv6 entry [0x%" PRIx64 "]\n", handle);

    if (FALSE == g_is_initialized) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("IPv6 MGR module is not initialized.\n");
        goto out;
    }

    err = ipv6_mgr_ops_g.hwd_ipv6_delete_pfn(handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("IPv6 MGR: Failed to delete handle [0x%" PRIx64 "] in hwd, err = %s\n",
                   handle, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ipv6_impl_get(const sx_ip_addr_t *ip_addr_p, hwi_ipv6_hw_handle_t *handle_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    char        ip_addr_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    if (utils_check_pointer(ip_addr_p, "ip_addr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(handle_p, "handle_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG_DBG("IPv6 MGR impl: get hwd handle for address [%s]\n", format_ip_addr(ip_addr_p, ip_addr_str));

    if (FALSE == g_is_initialized) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("IPv6 MGR module is not initialized.\n");
        goto out;
    }

    err = ipv6_mgr_ops_g.hwd_ipv6_get_pfn(ip_addr_p, handle_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("IPv6 MGR: Failed to get handle for IPv6 entry [%s] from hwd, err = %s\n",
                   format_ip_addr(ip_addr_p, ip_addr_str), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ipv6_impl_get_by_handle(hwi_ipv6_hw_handle_t handle, sx_ip_addr_t *ip_addr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(ip_addr_p, "ip_addr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG_DBG("IPv6 MGR: get address by hwd handle [0x%" PRIx64 "]\n", handle);

    if (FALSE == g_is_initialized) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("IPv6 MGR module is not initialized.\n");
        goto out;
    }

    err = ipv6_mgr_ops_g.hwd_ipv6_get_by_handle_pfn(handle, ip_addr_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("IPv6 MGR: Failed to get address by hwd handle [0x%" PRIx64 "], err =%s\n", handle,
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ipv6_impl_block_lock(hwi_ipv6_hw_handle_t handle, hwi_ipv6_hw_index_t *hw_index_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(hw_index_p, "hw_index_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG_DBG("IPv6 MGR impl: lock handle [0x%" PRIx64 "]\n", handle);

    if (FALSE == g_is_initialized) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("IPv6 MGR module is not initialized.\n");
        goto out;
    }

    err = ipv6_mgr_ops_g.hwd_ipv6_block_lock_pfn(handle, hw_index_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("IPv6 MGR: Failed to lock handle [0x%" PRIx64 "] in hwd, err = %s\n",
                   handle, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ipv6_impl_block_unlock(hwi_ipv6_hw_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG_DBG("IPv6 MGR impl: unlock handle [0x%" PRIx64 "]\n", handle);

    if (FALSE == g_is_initialized) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("IPv6 MGR module is not initialized.\n");
        goto out;
    }

    err = ipv6_mgr_ops_g.hwd_ipv6_block_unlock_pfn(handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("IPv6 MGR: Failed to unlock handle [0x%" PRIx64 "] in hwd, err = %s\n",
                   handle, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ipv6_impl_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (ipv6_mgr_ops_g.hwd_ipv6_debug_dump_pfn) {
        err = ipv6_mgr_ops_g.hwd_ipv6_debug_dump_pfn(dbg_dump_params_p);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("IPv6 MGR: Failed to call hwd debug dump, err = %s\n", sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}
