/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWI_IPV6_MGR_IMPL_H__
#define __HWI_IPV6_MGR_IMPL_H__

#include <sx/sdk/sx_types.h>
#include <kvd/kvd_linear_manager.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef kvd_linear_manager_handle_t hwi_ipv6_hw_handle_t;
typedef kvd_linear_manager_index_t hwi_ipv6_hw_index_t;

/* function pointers for HWD APIs */
typedef struct hwi_ipv6_mgr_ops {
    sx_status_t (*hwd_ipv6_init_pfn)(void);
    sx_status_t (*hwd_ipv6_deinit_pfn)(boolean_t is_forced);
    sx_status_t (*hwd_ipv6_add_pfn)(const sx_ip_addr_t *ip_addr_p, hwi_ipv6_hw_handle_t *handle_p);
    sx_status_t (*hwd_ipv6_delete_pfn)(hwi_ipv6_hw_handle_t handle);
    sx_status_t (*hwd_ipv6_get_pfn)(const sx_ip_addr_t *ip_addr_p, hwi_ipv6_hw_handle_t *handle_p);
    sx_status_t (*hwd_ipv6_get_by_handle_pfn)(hwi_ipv6_hw_handle_t handle, sx_ip_addr_t *ip_addr_p);
    sx_status_t (*hwd_ipv6_block_lock_pfn)(hwi_ipv6_hw_handle_t handle, hwi_ipv6_hw_index_t *hw_index_p);
    sx_status_t (*hwd_ipv6_block_unlock_pfn)(hwi_ipv6_hw_handle_t handle);
    sx_status_t (*hwd_ipv6_debug_dump_pfn)(dbg_dump_params_t *dbg_dump_params_p);
} hwi_ipv6_mgr_ops_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t sdk_ipv6_mgr_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t sdk_ipv6_init_hwd_ops(void);
sx_status_t sdk_ipv6_impl_init(void);
sx_status_t sdk_ipv6_impl_deinit(boolean_t is_forced);
sx_status_t sdk_ipv6_impl_add(const sx_ip_addr_t *ip_addr_p, hwi_ipv6_hw_handle_t *handle_p);
sx_status_t sdk_ipv6_impl_delete(hwi_ipv6_hw_handle_t handle);
sx_status_t sdk_ipv6_impl_get(const sx_ip_addr_t *ip_addr_p, hwi_ipv6_hw_handle_t *handle_p);
sx_status_t sdk_ipv6_impl_get_by_handle(hwi_ipv6_hw_handle_t handle, sx_ip_addr_t *ip_addr_p);
sx_status_t sdk_ipv6_impl_block_lock(hwi_ipv6_hw_handle_t handle, hwi_ipv6_hw_index_t *hw_index_p);
sx_status_t sdk_ipv6_impl_block_unlock(hwi_ipv6_hw_handle_t handle);
sx_status_t sdk_ipv6_impl_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

#endif /* __HWI_IPV6_MGR_IMPL_H__ */
