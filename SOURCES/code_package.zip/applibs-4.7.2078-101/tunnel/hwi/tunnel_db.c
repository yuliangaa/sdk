/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_qpool.h>
#include <complib/cl_dbg.h>
#include <complib/cl_qmap.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <sx/utils/sdk_refcount.h>
#include <sx/sdk/sx_status_convertor.h>
#include <utils/utils.h>

#include "tunnel_impl.h"
#include "tunnel_db.h"
#include "ethl2/fdb.h"
#include "ethl2/vlan.h"
#include "ethl2/fid_manager.h"
#include "flow_counter/flow_counter.h"
#include "counters/counter_manager/counter_manager.h"

#undef  __MODULE__
#define __MODULE__ TUNNEL


#define TUNNEL_MAP_ENTRY_MAX                        (rm_resource_global.bridge_num_max + VLAN_NUMS_MAX)
#define TUNNEL_MAPPING_COUNTERS_LIST_POOL_GROW_SIZE (3)

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/
typedef enum dgb_tunnel {
    DBG_TUNNEL_ID_E,
    DBG_TUNNEL_TYPE_E,
    DBG_TUNNEL_DIR_E,
    DBG_TUNNEL_REF_CNT_E,
} dgb_tunnel_e;

typedef struct tunnel_counter_ref {
    sx_bridge_tunnel_counter_type_t counter_type;
    sx_flow_counter_id_t            flow_counter_id;
} tunnel_counter_ref_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static id_allocator_t                   tunnel_id_allocator;
static cl_qpool_t                       tunnel_pool;
static cl_qmap_t                        tunnel_map;
static cl_qpool_t                       tunnel_mapper_pool;
static cl_qmap_t                        nve_log_port_to_tunnel_map;
static cl_qpool_t                       vrid_to_default_rif_pool;
static cl_qmap_t                        vrid_to_default_rif_map;
static uint32_t                         ipinip_tunnel_cnt = 0;
static uint32_t                         nve_tunnel_cnt = 0;
static uint32_t                         l2_flex_tunnel_cnt = 0;
static uint32_t                         total_flex_header_cnt = 0;
static tunnel_flex_header_entry_t      *flex_header_entries = NULL;
static nve_tunnel_delete_func_p         g_nve_tunnel_delete_func_cb;
static nve_tunnel_mapping_delete_func_p g_nve_tunnel_mapping_delete_func_cb;
static struct {
    cl_qpool_t tunnel_mapping_counters_list_pool;
    cl_fmap_t  tunnel_mapping_counters_list_map;
} tunnel_mapping_counters_list_db;

/************************************************
 *  Local function declarations
 ***********************************************/
static int __tunnel_mapping_counters_list_map_cmp_pfn(const void *const p_key1, const void *const p_key2);
static sx_status_t __tunnel_mapping_counters_list_add(tunnel_mapping_item_t          *tunnel_map_item_p,
                                                      sx_bridge_tunnel_counter_type_t counter_type,
                                                      sx_flow_counter_id_t            counter_id);
static sx_status_t __tunnel_mapping_counters_list_remove(tunnel_mapping_item_t          *tunnel_map_item_p,
                                                         sx_bridge_tunnel_counter_type_t counter_type,
                                                         sx_flow_counter_id_t            counter_id);
static sx_status_t __get_tunnel_map_entry(const sx_tunnel_id_t tunnel_id, sdk_db_tunnel_entry_t  **tunnel_entry_p)
{
    cl_map_item_t         *map_item_p = NULL;
    sx_status_t            err = SX_STATUS_SUCCESS;
    uint32_t               tunnel_identifier = 0;
    sdk_db_tunnel_entry_t *tunnel_db_entry_p = NULL;
    sx_tunnel_type_e       tunnel_type = 0;
    sx_tunnel_direction_e  tunnel_dir = 0;

    SX_LOG_ENTER();
    SX_LOG_DBG("__get_tunnel_map_entry tunnel ID [0x08%x]\n", tunnel_id);

    tunnel_identifier = SX_TUNNEL_IDENTIFIER_GET(tunnel_id);
    if (tunnel_identifier >= (rm_resource_global.tunnel_ipinip_num_max +
                              rm_resource_global.tunnel_nve_num_max +
                              rm_resource_global.tunnel_l2_flex_num_max)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Wrong tunnel id 0x%08x\n", tunnel_id);
        goto out;
    }

    map_item_p = cl_qmap_get(&tunnel_map, tunnel_identifier);
    if (cl_qmap_end(&tunnel_map) == map_item_p) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("Tunnel[0x%08x] entry doesn't exists\n", tunnel_id);
        goto out;
    }

    tunnel_db_entry_p = PARENT_STRUCT(map_item_p, sdk_db_tunnel_entry_t, map_item);
    tunnel_type = SX_TUNNEL_TYPE_ID_GET(tunnel_id);
    tunnel_dir = SX_TUNNEL_DIRECTION_GET(tunnel_id);

    if ((tunnel_type != tunnel_db_entry_p->data.tun_attr.type) ||
        (tunnel_dir != tunnel_db_entry_p->data.tun_attr.direction)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Wrong tunnel id 0x%08x\n", tunnel_id);
        goto out;
    }

    *tunnel_entry_p = tunnel_db_entry_p;

out:
    SX_LOG_EXIT();
    return err;
}

static void __tunnel_mapping_to_uin64_t(sx_tunnel_id_t tunnel_id, sx_fid_t fid, uint64_t *id_p)
{
    *id_p = fid;
    *id_p = (*id_p << 32) | tunnel_id;
}

/************************************************
 *  Function implementations
 ***********************************************/
static int __tunnel_mapping_counters_list_map_cmp_pfn(const void *const p_key1, const void *const p_key2)
{
    const tunnel_mapping_counters_list_map_key_t *map_key_1_p = p_key1;
    const tunnel_mapping_counters_list_map_key_t *map_key_2_p = p_key2;
    int                                           res = 0;

    if (map_key_1_p->type != map_key_2_p->type) {
        if (map_key_1_p->type > map_key_2_p->type) {
            res = 1;
        } else {
            res = -1;
        }
    } else if (map_key_1_p->flow_counter_id != map_key_2_p->flow_counter_id) {
        if (map_key_1_p->flow_counter_id > map_key_2_p->flow_counter_id) {
            res = 1;
        } else {
            res = -1;
        }
    } else {
        res = 0;
    }

    return res;
}

const char* get_tunnel_ref_name(char* name_buf, size_t name_size, void* tunnel_id)
{
    snprintf(name_buf, name_size, "TUN[0x%x]", *(sx_tunnel_id_t*)tunnel_id);
    return name_buf;
}

const char* get_tunnel_map_ref_name(char* name_buf, size_t name_size, void* bridge_id)
{
    snprintf(name_buf, name_size, "TUNMAP%d", *(sx_bridge_id_t*)bridge_id);
    return name_buf;
}

const char * get_tunnel_counter_ref_name(char* name_buf, size_t name_size, void *data)
{
    tunnel_counter_ref_t* tunnel_counter_ref_p = (tunnel_counter_ref_t*)data;

    switch (tunnel_counter_ref_p->counter_type) {
    case SX_BRIDGE_COUNTER_TUNNEL_DECAP_E:
        snprintf(name_buf, name_size, "DECAP CNT %u", tunnel_counter_ref_p->flow_counter_id);
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E:
        snprintf(name_buf, name_size, "ENCAP UC CNT %u", tunnel_counter_ref_p->flow_counter_id);
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E:
        snprintf(name_buf, name_size, "ENCAP MC CNT %u", tunnel_counter_ref_p->flow_counter_id);
        break;

    default:
        snprintf(name_buf, name_size, "UNKNOWN CNT %u", tunnel_counter_ref_p->flow_counter_id);
        break;
    }

    return name_buf;
}

sx_status_t sdk_tunnel_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return status;
}

sx_status_t sdk_tunnel_db_init(const uint32_t                   ipinip_tunnel_max_count,
                               const uint32_t                   nve_tunnel_max_count,
                               const uint32_t                   l2_flex_tunnel_max_count,
                               nve_tunnel_delete_func_p         nve_tunnel_delete_func_cb,
                               nve_tunnel_mapping_delete_func_p nve_tunnel_mapping_delete_func_cb)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    uint32_t          i = 0;
    cl_status_t       cl_status = CL_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    boolean_t         qpool_init = FALSE;
    boolean_t         qpool_mapper_init = FALSE;
    boolean_t         id_allocator_inited = FALSE;
    boolean_t         flex_header_init = FALSE;
    boolean_t         qpool_vrid_to_default_rif_init = FALSE;
    uint32_t          total_tunnel_max_count = 0;
    uint32_t          total_tunnel_map_entry_max = 0;
    uint32_t          total_tunnel_vrid_to_default_rif_entry_max = 0;
    boolean_t         initialised = FALSE;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel hwi DB Init\n");

    sdk_tunnel_impl_params_get(&initialised);

    if (TRUE == initialised) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Tunnel module is already initialized\n");
        goto out;
    }

    if (ipinip_tunnel_max_count > rm_resource_global_default.tunnel_ipinip_num_max) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("DB can't allocate more IPINIP(%d) tunnels than supported(%d)\n",
                   ipinip_tunnel_max_count,
                   rm_resource_global_default.tunnel_ipinip_num_max);
        goto out;
    }

    if (nve_tunnel_max_count > rm_resource_global_default.tunnel_nve_num_max) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("DB can't allocate more NVE(%d) tunnels than supported(%d)\n",
                   nve_tunnel_max_count,
                   rm_resource_global_default.tunnel_nve_num_max);
        goto out;
    }

    if (l2_flex_tunnel_max_count > rm_resource_global_default.tunnel_l2_flex_num_max) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("DB can't allocate more L2 flex (%d) tunnels than supported(%d)\n",
                   l2_flex_tunnel_max_count,
                   rm_resource_global_default.tunnel_l2_flex_num_max);
        goto out;
    }

    ipinip_tunnel_cnt = 0;
    nve_tunnel_cnt = 0;
    l2_flex_tunnel_cnt = 0;
    total_tunnel_max_count = ipinip_tunnel_max_count + nve_tunnel_max_count + l2_flex_tunnel_max_count;
    total_tunnel_map_entry_max = rm_resource_global.tunnel_nve_num_max * TUNNEL_MAP_ENTRY_MAX;
    rm_resource_global.tunnel_ipinip_num_max = ipinip_tunnel_max_count;
    rm_resource_global.tunnel_nve_num_max = nve_tunnel_max_count;
    rm_resource_global.tunnel_l2_flex_num_max = l2_flex_tunnel_max_count;
    total_tunnel_vrid_to_default_rif_entry_max = rm_resource_global.router_vrid_max;
    SX_MEM_CLR(tunnel_id_allocator);
    utils_err = id_allocator_init(total_tunnel_max_count, total_tunnel_max_count, 0, &tunnel_id_allocator);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to init tunnel id allocator.\n");
        goto out;
    }
    id_allocator_inited = TRUE;

    /* Allocate room for the flex headers (if they exist).
     * Currently only L2 flex is supported. Double the size to allow edit in place.
     */
    total_flex_header_cnt = l2_flex_tunnel_max_count * 2;
    if (total_flex_header_cnt > 0) {
        err = utils_clr_memory_get((void**)(&flex_header_entries),
                                   total_flex_header_cnt, sizeof(tunnel_flex_header_entry_t),
                                   UTILS_MEM_TYPE_ID_TUNNEL_E);

        if (SX_STATUS_SUCCESS != err) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to allocate memory for the tunnel flex headers\n");
            goto out;
        }
        for (i = 0; i < total_flex_header_cnt; i++) {
            flex_header_entries[i].header_id = i;
            flex_header_entries[i].uirif = FM_INVALID_RIF_ID;
        }
        flex_header_init = TRUE;
    }

    cl_status = CL_QPOOL_INIT(&tunnel_pool, total_tunnel_max_count, total_tunnel_max_count, 0,
                              sizeof(sdk_db_tunnel_entry_t), NULL, NULL, NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate tunnel pool.\n");
        goto out;
    }
    qpool_init = TRUE;
    cl_status = CL_QPOOL_INIT(&tunnel_mapper_pool, total_tunnel_map_entry_max, total_tunnel_map_entry_max, 0,
                              sizeof(tunnel_mapping_item_t), NULL, NULL, NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate tunnel mapper pool.\n");
        goto out;
    }
    qpool_mapper_init = TRUE;

    cl_status = CL_QPOOL_INIT(&vrid_to_default_rif_pool,
                              total_tunnel_vrid_to_default_rif_entry_max,
                              total_tunnel_vrid_to_default_rif_entry_max,
                              0,
                              sizeof(tunnel_vrid_to_default_rif_map_item_t),
                              NULL,
                              NULL,
                              NULL);

    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to allocate tunnel vrid to default rif pool.\n");
        goto out;
    }
    qpool_vrid_to_default_rif_init = TRUE;

    cl_status = CL_QPOOL_INIT(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_pool,
                              0, 0, TUNNEL_MAPPING_COUNTERS_LIST_POOL_GROW_SIZE,
                              sizeof(tunnel_mapping_counters_list_t),
                              NULL, NULL, NULL);
    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Failed to init tunnel mapping counters lists pool.\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_NO_RESOURCES);
    }

    cl_qmap_init(&tunnel_map);
    cl_qmap_init(&nve_log_port_to_tunnel_map);
    cl_qmap_init(&vrid_to_default_rif_map);
    cl_fmap_init(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map,
                 __tunnel_mapping_counters_list_map_cmp_pfn);

    g_nve_tunnel_delete_func_cb = nve_tunnel_delete_func_cb;
    g_nve_tunnel_mapping_delete_func_cb = nve_tunnel_mapping_delete_func_cb;

out:
    if (SX_STATUS_SUCCESS != err) {
        if (TRUE == qpool_init) {
            CL_QPOOL_DESTROY(&tunnel_pool);
        }

        if (TRUE == qpool_mapper_init) {
            CL_QPOOL_DESTROY(&tunnel_mapper_pool);
        }

        if (TRUE == qpool_vrid_to_default_rif_init) {
            CL_QPOOL_DESTROY(&vrid_to_default_rif_pool);
        }

        if (TRUE == flex_header_init) {
            utils_memory_put(flex_header_entries, UTILS_MEM_TYPE_ID_TUNNEL_E);
            flex_header_entries = NULL;
        }

        if (TRUE == id_allocator_inited) {
            id_allocator_destroy(&tunnel_id_allocator);
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_deinit(boolean_t is_forced)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    sx_utils_status_t                      utils_err = SX_UTILS_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t                 *tunnel_entry_p = NULL;
    tunnel_vrid_to_default_rif_map_item_t *tunnel_vrid_to_default_rif_map_item_p = NULL;
    cl_map_item_t                         *map_item = NULL;
    const cl_map_item_t                   *map_end = NULL;
    cl_fmap_item_t                        *fmap_item_p = NULL;
    const cl_fmap_item_t                  *fmap_end_p = NULL;
    uint32_t                               tunnel_id = 0, log_tunnel_id = 0;
    boolean_t                              initialised = FALSE;
    tunnel_mapping_counters_list_t        *map_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel hwi DB deinit\n");

    sdk_tunnel_impl_params_get(&initialised);
    if (FALSE == initialised) {
        if (FALSE == is_forced) {
            err = SX_STATUS_MODULE_UNINITIALIZED;
            SX_LOG_ERR("Tunnel module is not initialized.\n");
        }
        /* return success on force deinit if not initialized. */
        goto out;
    }

    /* Clear tunnel DB */
    map_item = cl_qmap_head(&tunnel_map);
    map_end = cl_qmap_end(&tunnel_map);
    if ((FALSE == is_forced) && (map_item != map_end)) {
        err = SX_STATUS_DB_NOT_EMPTY;
        SX_LOG_ERR("Failed to DB deinit, there are still %u tunnels allocated\n",
                   (ipinip_tunnel_cnt + nve_tunnel_cnt + l2_flex_tunnel_cnt));
        goto out;
    }

    while (map_item != map_end) {
        tunnel_entry_p = PARENT_STRUCT(map_item, sdk_db_tunnel_entry_t, map_item);
        map_item = cl_qmap_next(map_item);
        tunnel_id = tunnel_entry_p->data.tunnel_identifier;

        /* delete the tunnel map entries from DB */
        log_tunnel_id = SX_TUNNEL_MAKE_ID(tunnel_id,
                                          tunnel_entry_p->data.tun_attr.type,
                                          tunnel_entry_p->data.tun_attr.direction);
        err = sdk_tunnel_db_tunnel_mapping_delete_all(log_tunnel_id, is_forced);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to delete all entries from tunnel[0x%08x] , err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        utils_err = sdk_refcount_deinit(&tunnel_entry_p->data.ref_count, is_forced);
        if (SX_UTILS_STATUS_SUCCESS != utils_err) {
            SX_LOG_ERR("Failed to deinit refcount for tunnel[0x%08x], utils_err = %s\n",
                       tunnel_id, SX_UTILS_STATUS_MSG(utils_err));
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }

        if (SX_TUNNEL_TYPE_NVE_CHECK(log_tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(log_tunnel_id)) {
            cl_qmap_remove_item(&nve_log_port_to_tunnel_map, &(tunnel_entry_p->log_port_map_item));
        }

        cl_qmap_remove_item(&tunnel_map, &(tunnel_entry_p->map_item));
        cl_qpool_put(&tunnel_pool, &(tunnel_entry_p->pool_item));
    }

    /* Clear tunnel vid to default RIF DB */
    map_item = cl_qmap_head(&vrid_to_default_rif_map);
    map_end = cl_qmap_end(&vrid_to_default_rif_map);
    while (map_item != map_end) {
        tunnel_vrid_to_default_rif_map_item_p =
            PARENT_STRUCT(map_item, tunnel_vrid_to_default_rif_map_item_t, map_item);
        map_item = cl_qmap_next(map_item);
        cl_qmap_remove_item(&vrid_to_default_rif_map, &(tunnel_vrid_to_default_rif_map_item_p->map_item));
        cl_qpool_put(&vrid_to_default_rif_pool, &(tunnel_vrid_to_default_rif_map_item_p->pool_item));
    }

    fmap_item_p = cl_fmap_head(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map);
    fmap_end_p = cl_fmap_end(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map);
    while (fmap_item_p != fmap_end_p) {
        map_entry_p = PARENT_STRUCT(fmap_item_p, tunnel_mapping_counters_list_t, list_map_item);
        fmap_item_p = cl_fmap_next(fmap_item_p);

        cl_fmap_remove_item(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map,
                            &map_entry_p->list_map_item);
        cl_qpool_put(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_pool, &map_entry_p->list_pool_item);
    }
    CL_QPOOL_DESTROY(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_pool);

    CL_QPOOL_DESTROY(&tunnel_pool);
    CL_QPOOL_DESTROY(&tunnel_mapper_pool);
    CL_QPOOL_DESTROY(&vrid_to_default_rif_pool);
    utils_err = id_allocator_destroy(&tunnel_id_allocator);
    if ((FALSE == is_forced) && SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to deinit tunnel id allocator.\n");
        goto out;
    }
    if (NULL != flex_header_entries) {
        err = utils_memory_put(flex_header_entries, UTILS_MEM_TYPE_ID_TUNNEL_E);
        if (err) {
            SX_LOG_ERR("Failed to put tunnel flex header memory, utils_memory_put failed, err = %s\n",
                       sx_status_str(err));
            goto out;
        }
    }
    ipinip_tunnel_cnt = 0;
    nve_tunnel_cnt = 0;
    l2_flex_tunnel_cnt = 0;
    total_flex_header_cnt = 0;
    flex_header_entries = NULL;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tunnel_mapping_counters_list_remove(tunnel_mapping_item_t          *tunnel_map_item_p,
                                                         sx_bridge_tunnel_counter_type_t counter_type,
                                                         sx_flow_counter_id_t            counter_id)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    cl_fmap_item_t                        *map_item_p = NULL;
    const cl_fmap_item_t                  *end_map_item_p = NULL;
    tunnel_mapping_counters_list_t        *map_entry_p = NULL;
    tunnel_mapping_counters_list_map_key_t map_key;

    SX_LOG_ENTER();

    SX_MEM_CLR(map_key);
    map_key.type = counter_type;
    map_key.flow_counter_id = counter_id;

    map_item_p = cl_fmap_get(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map, &map_key);
    end_map_item_p = cl_fmap_end(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map);
    if (map_item_p == end_map_item_p) {
        SX_LOG_ERR("The counter [%s] [%u] is not found in the map\n",
                   sx_bridge_tunnel_counter_type_str(counter_type), counter_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto end;
    }

    map_entry_p = PARENT_STRUCT(map_item_p, tunnel_mapping_counters_list_t, list_map_item);

    switch (counter_type) {
    case SX_BRIDGE_COUNTER_TUNNEL_DECAP_E:
        cl_qlist_remove_item(&map_entry_p->counters_list, &tunnel_map_item_p->decap_flow_counter_list_item);
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E:
        cl_qlist_remove_item(&map_entry_p->counters_list, &tunnel_map_item_p->encap_uc_flow_counter_list_item);
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E:
        cl_qlist_remove_item(&map_entry_p->counters_list, &tunnel_map_item_p->encap_mc_flow_counter_list_item);
        break;

    default:
        SX_LOG_ERR("Invalid counter type %s %u\n", sx_bridge_tunnel_counter_type_str(counter_type), counter_type);
        sx_status = SX_STATUS_PARAM_ERROR;
        goto end;
    }

    if (cl_is_qlist_empty(&map_entry_p->counters_list)) {
        cl_fmap_remove_item(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map,
                            &map_entry_p->list_map_item);
        cl_qpool_put(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_pool, &map_entry_p->list_pool_item);
    }

end:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_mapping_counters_list_add(tunnel_mapping_item_t          *tunnel_map_item_p,
                                                      sx_bridge_tunnel_counter_type_t counter_type,
                                                      sx_flow_counter_id_t            counter_id)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    cl_pool_item_t                        *pool_item_p = NULL;
    cl_fmap_item_t                        *map_item_p = NULL;
    const cl_fmap_item_t                  *end_map_item_p = NULL;
    tunnel_mapping_counters_list_t        *map_entry_p = NULL;
    tunnel_mapping_counters_list_map_key_t map_key;

    SX_LOG_ENTER();

    SX_MEM_CLR(map_key);
    map_key.type = counter_type;
    map_key.flow_counter_id = counter_id;

    map_item_p = cl_fmap_get(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map, &map_key);
    end_map_item_p = cl_fmap_end(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map);
    if (map_item_p == end_map_item_p) {
        pool_item_p = cl_qpool_get(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_pool);
        if (pool_item_p == NULL) {
            SX_LOG_ERR("Could not find free entry in tunnel counters pool\n");
            sx_status = SX_STATUS_NO_RESOURCES;
            goto end;
        }

        map_entry_p = PARENT_STRUCT(pool_item_p, tunnel_mapping_counters_list_t, list_pool_item);
        map_entry_p->list_map_key.type = counter_type;
        map_entry_p->list_map_key.flow_counter_id = counter_id;
        cl_qlist_init(&map_entry_p->counters_list);
        cl_fmap_insert(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map,
                       &map_entry_p->list_map_key,
                       &map_entry_p->list_map_item);
    } else {
        map_entry_p = PARENT_STRUCT(map_item_p, tunnel_mapping_counters_list_t, list_map_item);
    }


    switch (counter_type) {
    case SX_BRIDGE_COUNTER_TUNNEL_DECAP_E:
        cl_qlist_insert_head(&map_entry_p->counters_list, &tunnel_map_item_p->decap_flow_counter_list_item);
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E:
        cl_qlist_insert_head(&map_entry_p->counters_list, &tunnel_map_item_p->encap_uc_flow_counter_list_item);
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E:
        cl_qlist_insert_head(&map_entry_p->counters_list, &tunnel_map_item_p->encap_mc_flow_counter_list_item);
        break;

    default:
        SX_LOG_ERR("Invalid counter type %d\n", counter_type);
        sx_status = SX_STATUS_PARAM_ERROR;
        goto end;
    }

end:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t tunnel_mapping_counters_list_get(sx_bridge_tunnel_counter_type_t counter_type,
                                             sx_flow_counter_id_t            counter_id,
                                             const cl_qlist_t              **tunnel_mapping_counters_list)
{
    sx_status_t                            sx_status = SX_STATUS_SUCCESS;
    cl_fmap_item_t                        *map_item_p = NULL;
    const cl_fmap_item_t                  *end_map_item_p = NULL;
    tunnel_mapping_counters_list_t        *map_entry_p = NULL;
    tunnel_mapping_counters_list_map_key_t map_key;

    SX_LOG_ENTER();

    SX_MEM_CLR(map_key);
    map_key.type = counter_type;
    map_key.flow_counter_id = counter_id;

    map_item_p = cl_fmap_get(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map, &map_key);
    end_map_item_p = cl_fmap_end(&tunnel_mapping_counters_list_db.tunnel_mapping_counters_list_map);
    if (map_item_p == end_map_item_p) {
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    map_entry_p = PARENT_STRUCT(map_item_p, tunnel_mapping_counters_list_t, list_map_item);

    *tunnel_mapping_counters_list = &map_entry_p->counters_list;

out:
    SX_LOG_EXIT();
    return sx_status;
}

static int __sdk_tunnel_db_fid_map_entry_key_cmp(const void *const p_key1, const void *const p_key2)
{
    int                    ret = 0;
    sx_tunnel_map_entry_t *p_map_key1 = (sx_tunnel_map_entry_t*)p_key1;
    sx_tunnel_map_entry_t *p_map_key2 = (sx_tunnel_map_entry_t*)p_key2;

    CL_ASSERT(p_map_key1);
    CL_ASSERT(p_map_key2);

    if (p_map_key1->type != p_map_key2->type) {
        return (p_map_key1->type - p_map_key2->type);
    }

    if (p_map_key1->params.nve.bridge_id != p_map_key2->params.nve.bridge_id) {
        return (p_map_key1->params.nve.bridge_id - p_map_key2->params.nve.bridge_id);
    }

    return ret;
}

static int __sdk_tunnel_db_vni_map_entry_key_cmp(const void *const p_key1, const void *const p_key2)
{
    int                    ret = 0;
    sx_tunnel_map_entry_t *p_map_key1 = (sx_tunnel_map_entry_t*)p_key1;
    sx_tunnel_map_entry_t *p_map_key2 = (sx_tunnel_map_entry_t*)p_key2;

    CL_ASSERT(p_map_key1);
    CL_ASSERT(p_map_key2);

    if (p_map_key1->params.nve.vni != p_map_key2->params.nve.vni) {
        return (p_map_key1->params.nve.vni - p_map_key2->params.nve.vni);
    }

    return ret;
}

static sx_status_t __sdk_tunnel_db_allocate_entry(sdk_db_tunnel_entry_t **tunnel_entry_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;
    cl_pool_item_t        *pool_item_p = NULL;
    sdk_db_tunnel_entry_t *new_tunnel_entry_p = NULL;
    uint32_t               tunnel_identifier = 0;
    boolean_t              id_get_passed_rollback = FALSE;

    utils_err = id_allocator_get(&tunnel_id_allocator, &tunnel_identifier);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to get tunnel identifier.\n");
        goto out;
    }

    id_get_passed_rollback = TRUE;

    pool_item_p = cl_qpool_get(&tunnel_pool);
    if (NULL == pool_item_p) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Out resources in tunnel DB\n");
        goto out;
    }

    new_tunnel_entry_p = PARENT_STRUCT(pool_item_p, sdk_db_tunnel_entry_t, pool_item);

    SX_MEM_CLR(new_tunnel_entry_p->data);
    new_tunnel_entry_p->data.hwd_encap_handle = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;
    new_tunnel_entry_p->data.hwd_decap_handle = SDK_TUNNEL_INVALID_DECAP_HWD_HDL;
    new_tunnel_entry_p->data.tunnel_identifier = tunnel_identifier;
    new_tunnel_entry_p->data.entry_count = 0;
    cl_fmap_init(&new_tunnel_entry_p->data.tunnel_fid_map, __sdk_tunnel_db_fid_map_entry_key_cmp);
    cl_fmap_init(&new_tunnel_entry_p->data.tunnel_vni_map, __sdk_tunnel_db_vni_map_entry_key_cmp);
    cl_qmap_insert(&tunnel_map, tunnel_identifier, &new_tunnel_entry_p->map_item);

    *tunnel_entry_p = new_tunnel_entry_p;

out:
    if (SX_STATUS_SUCCESS != err) {
        if (id_get_passed_rollback) {
            utils_err = id_allocator_put(&tunnel_id_allocator, tunnel_identifier);
            if (utils_err != CL_SUCCESS) {
                SX_LOG_ERR("Failed to rollback, id [%d], err = [%s]\n",
                           tunnel_identifier, SX_UTILS_STATUS_MSG(utils_err));
            }
        }
    }
    return err;
}

static sx_status_t __sdk_tunnel_db_mapping_item_get_by_vni(sx_tunnel_id_t          tunnel_id,
                                                           sx_tunnel_vni_t         vni,
                                                           tunnel_mapping_item_t **map_entry_item_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    cl_fmap_item_t        *map_item = NULL;
    const cl_fmap_item_t  *map_end = NULL;
    sx_tunnel_map_entry_t  map_entry;

    SX_LOG_ENTER();

    SX_MEM_CLR(map_entry);

    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    map_entry.type = tunnel_entry_p->data.tun_attr.type;
    /* map_entry.params.nve.direction = 0
     *  We cannot translate the direction of tunnel to the direction of tunnel map entry.
     *  Also, we can have only one tunnel map entry for given tunnel & FID.
     *  Thus, the direction of tunnel map entry is not used in the lookup operation &
     *  comparison operations
     */
    map_entry.params.nve.vni = vni;

    map_end = cl_fmap_end(&tunnel_entry_p->data.tunnel_vni_map);
    map_item = cl_fmap_get(&tunnel_entry_p->data.tunnel_vni_map, &map_entry);
    if (map_item == map_end) {
        SX_LOG_DBG("Could not find the entry in the tunnel entries map\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *map_entry_item_p = PARENT_STRUCT(map_item, tunnel_mapping_item_t, vni_map_item);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tunnel_db_mapping_item_get_by_fid(sx_tunnel_id_t          tunnel_id,
                                                           sx_fid_t                fid,
                                                           tunnel_mapping_item_t **map_entry_item_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    cl_fmap_item_t        *map_item = NULL;
    const cl_fmap_item_t  *map_end = NULL;
    sx_tunnel_map_entry_t  map_entry;

    SX_LOG_ENTER();

    SX_MEM_CLR(map_entry);

    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    map_entry.type = tunnel_entry_p->data.tun_attr.type;
    /* map_entry.params.nve.direction = 0
     *  We cannot translate the direction of tunnel to the direction of tunnel map entry.
     *  Also, we can have only one tunnel map entry for given tunnel & FID.
     *  Thus, the direction of tunnel map entry is not used in the lookup operation &
     *  comparison operations
     */
    map_entry.params.nve.bridge_id = fid;

    map_end = cl_fmap_end(&tunnel_entry_p->data.tunnel_fid_map);
    map_item = cl_fmap_get(&tunnel_entry_p->data.tunnel_fid_map, &map_entry);
    if (map_item == map_end) {
        SX_LOG_ERR("Could not find the entry in the tunnel entries map\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *map_entry_item_p = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);

out:
    SX_LOG_EXIT();
    return err;
}

/* SET/DELETE tunnel fid counter to mapping DB */
sx_status_t sdk_tunnel_db_fid_counter_set(sx_tunnel_id_t                  tunnel_id,
                                          sx_fid_t                        fid,
                                          sx_bridge_tunnel_counter_type_t counter_type,
                                          sx_flow_counter_id_t            counter_id)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    tunnel_mapping_item_t *tunnel_map_item_p = NULL;
    sx_flow_counter_id_t  *flow_counter_id_p = NULL;

    SX_LOG_ENTER();

    err = __sdk_tunnel_db_mapping_item_get_by_fid(tunnel_id, fid, &tunnel_map_item_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get map entry for tunnel[0x%08x] fid[0x%08x], err = %s\n",
                   tunnel_id, fid, sx_status_str(err));
        goto out;
    }

    switch (counter_type) {
    case SX_BRIDGE_COUNTER_TUNNEL_DECAP_E:
        flow_counter_id_p = &tunnel_map_item_p->decap_flow_counter_id;
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E:
        flow_counter_id_p = &tunnel_map_item_p->encap_uc_flow_counter_id;
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E:
        flow_counter_id_p = &tunnel_map_item_p->encap_mc_flow_counter_id;
        break;

    default:
        SX_LOG_ERR("Invalid counter type %d\n", counter_type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_FLOW_COUNTER_ID_INVALID == counter_id) {
        err = __tunnel_mapping_counters_list_remove(tunnel_map_item_p, counter_type, *flow_counter_id_p);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR(
                "Failed to remove the counter [%u] from the counters list for tunnel[0x%08x] fid[0x%08x], err = %s\n",
                *flow_counter_id_p,
                tunnel_id,
                fid,
                sx_status_str(err));
            goto out;
        }
    } else {
        err = __tunnel_mapping_counters_list_add(tunnel_map_item_p, counter_type, counter_id);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR(
                "Failed to add the counter [%u] to the counters list for tunnel[0x%08x] fid[0x%08x], err = %s\n",
                counter_id,
                tunnel_id,
                fid,
                sx_status_str(err));
            goto out;
        }
    }

    *flow_counter_id_p = counter_id;

out:
    SX_LOG_EXIT();
    return err;
}

/* Get tunnel fid counter from mapping DB */
sx_status_t sdk_tunnel_db_fid_counter_get(sx_tunnel_id_t                  tunnel_id,
                                          sx_fid_t                        fid,
                                          sx_bridge_tunnel_counter_type_t counter_type,
                                          sx_flow_counter_id_t           *counter_id_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    tunnel_mapping_item_t *tunnel_map_item_p = NULL;

    SX_LOG_ENTER();

    if (utils_check_pointer(counter_id_p, "counter_id_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __sdk_tunnel_db_mapping_item_get_by_fid(tunnel_id, fid, &tunnel_map_item_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get map entry for tunnel[0x%08x] fid [0x%08x], err = %s\n",
                   tunnel_id, fid, sx_status_str(err));
        goto out;
    }

    switch (counter_type) {
    case SX_BRIDGE_COUNTER_TUNNEL_DECAP_E:
        *counter_id_p = tunnel_map_item_p->decap_flow_counter_id;
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E:
        *counter_id_p = tunnel_map_item_p->encap_uc_flow_counter_id;
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E:
        *counter_id_p = tunnel_map_item_p->encap_mc_flow_counter_id;
        break;

    default:
        SX_LOG_ERR("Invalid counter type %d\n", counter_type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static boolean_t __sdk_tunnel_db_comp_tunnel_attr(const sx_tunnel_attribute_t *lhs_tunnel_attr_p,
                                                  const sx_tunnel_attribute_t *rhs_tunnel_attr_p)
{
    boolean_t                  is_equal = FALSE;
    sx_tunnel_nve_attribute_t *nve_attribute_lhs_p = NULL;
    sx_tunnel_nve_attribute_t *nve_attribute_rhs_p = NULL;

    if (lhs_tunnel_attr_p->type != rhs_tunnel_attr_p->type) {
        goto out;
    } else if (lhs_tunnel_attr_p->direction != rhs_tunnel_attr_p->direction) {
        goto out;
    }

    switch (lhs_tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        nve_attribute_lhs_p = (sx_tunnel_nve_attribute_t*)&lhs_tunnel_attr_p->attributes.vxlan;
        nve_attribute_rhs_p = (sx_tunnel_nve_attribute_t*)&rhs_tunnel_attr_p->attributes.vxlan;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        nve_attribute_lhs_p = (sx_tunnel_nve_attribute_t*)&lhs_tunnel_attr_p->attributes.nvgre;
        nve_attribute_rhs_p = (sx_tunnel_nve_attribute_t*)&rhs_tunnel_attr_p->attributes.nvgre;
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        if (lhs_tunnel_attr_p->attributes.l2_flex.log_port == rhs_tunnel_attr_p->attributes.l2_flex.log_port) {
            return TRUE;
        } else {
            return FALSE;
        }
        break;

    default:
        goto out;
    }


    if (nve_attribute_lhs_p->nve_log_port != nve_attribute_rhs_p->nve_log_port) {
        goto out;
    } else if (nve_attribute_lhs_p->underlay_domain_type !=
               nve_attribute_rhs_p->underlay_domain_type) {
        goto out;
    }

    if (lhs_tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_ENCAP) {
        if (nve_attribute_lhs_p->encap.underlay_vrid !=
            nve_attribute_rhs_p->encap.underlay_vrid) {
            goto out;
        } else if (sdk_router_utils_compare_ip_address(&nve_attribute_lhs_p->encap.underlay_sip,
                                                       &nve_attribute_rhs_p->encap.underlay_sip) != 0) {
            goto out;
        }

        if (nve_attribute_lhs_p->underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) {
            if (nve_attribute_lhs_p->encap.underlay_rif !=
                nve_attribute_rhs_p->encap.underlay_rif) {
                goto out;
            }
        }
    }

    if (lhs_tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_DECAP) {
        if (nve_attribute_lhs_p->decap.tag_mode !=
            nve_attribute_rhs_p->decap.tag_mode) {
            goto out;
        }

        if (nve_attribute_lhs_p->decap.egress_et_set !=
            nve_attribute_rhs_p->decap.egress_et_set) {
            goto out;
        }

        if (nve_attribute_lhs_p->underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) {
            if (nve_attribute_lhs_p->decap.underlay_rif !=
                nve_attribute_rhs_p->decap.underlay_rif) {
                goto out;
            }
        }
    }

    is_equal = TRUE;

out:
    return is_equal;
}

static sx_status_t __sdk_tunnel_db_tunnel_entry_get_by_tunnel_attr(const sx_tunnel_attribute_t *tunnel_attr_p,
                                                                   sdk_db_tunnel_entry_t      **tunnel_entry_p)
{
    sx_status_t            err = SX_STATUS_ENTRY_NOT_FOUND;
    sdk_db_tunnel_entry_t *cur_tunnel_entry_p = NULL;
    cl_map_item_t         *map_item = NULL;
    const cl_map_item_t   *map_end = NULL;

    SX_LOG_ENTER();

    *tunnel_entry_p = NULL;

    map_item = cl_qmap_head(&tunnel_map);
    map_end = cl_qmap_end(&tunnel_map);

    while (map_item != map_end) {
        cur_tunnel_entry_p = PARENT_STRUCT(map_item, sdk_db_tunnel_entry_t, map_item);
        map_item = cl_qmap_next(map_item);

        if (__sdk_tunnel_db_comp_tunnel_attr(&cur_tunnel_entry_p->data.tun_attr, tunnel_attr_p)) {
            err = SX_STATUS_SUCCESS;
            *tunnel_entry_p = cur_tunnel_entry_p;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_add(const sx_tunnel_attribute_t *tunnel_attr_p,
                              const sdk_ref_t             *vrid_ref_p,
                              sx_tunnel_id_t              *tunnel_id_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;
    char                   tun_name[TUNNEL_NAME_MAX_LEN];
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    boolean_t              entry_allocation_rollback = FALSE;
    uint32_t               tunnel_identifier = 0;
    sx_tunnel_id_t         new_tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_port_log_id_t       log_port = 0;
    ref_name_data_t        ref_name_data = {.print_func_p = get_tunnel_ref_name,
                                            .ref_data_p = &new_tunnel_id,
                                            .data_size = sizeof(new_tunnel_id)};
    ref_delete_data_t      nve_ref_delete_data = {.delete_func_p = NULL,
                                                  .id = DELETE_ID_INVALID};

    SX_LOG_ENTER();
    SX_LOG_DBG("Add Tunnel to hwi DB\n");

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_attr_p, "tunnel_attr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(tunnel_id_p, "tunnel_id_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(tun_name);
    SX_MEM_CLR(new_tunnel_id);

    new_tunnel_id = SX_TUNNEL_TYPE_ID_SET(new_tunnel_id, tunnel_attr_p->type);

    if ((SX_TUNNEL_TYPE_IPINIP_CHECK(new_tunnel_id)) &&
        (ipinip_tunnel_cnt >= rm_resource_global.tunnel_ipinip_num_max)) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("Can't add new IPinIP tunnel entry to DB (reach maximum entries %u)\n",
                   rm_resource_global.tunnel_ipinip_num_max);
        goto out;
    }

    if (SX_TUNNEL_TYPE_NVE_CHECK(new_tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(new_tunnel_id)) {
        /* When the user tries to re-create a NVE/FLEX tunnel or a tunnel map entry that was marked deleted
         *  but still exists, SDK should return to the user SX_STATUS_RESOURCE_IN_USE. */
        err = __sdk_tunnel_db_tunnel_entry_get_by_tunnel_attr(tunnel_attr_p, &tunnel_entry_p);
        if (err == SX_STATUS_SUCCESS) {
            if (tunnel_entry_p != NULL) {
                if (tunnel_entry_p->data.pending_delete == TRUE) {
                    err = SX_STATUS_RESOURCE_IN_USE;
                    new_tunnel_id = SX_TUNNEL_MAKE_ID(tunnel_entry_p->data.tunnel_identifier,
                                                      tunnel_attr_p->type,
                                                      tunnel_attr_p->direction);
                    SX_LOG_ERR("Tunnel[0x%x] with requested attributes exists. Error: %s \n",
                               new_tunnel_id, sx_status_str(err));
                    goto out;
                }
            }
        }

        if (SX_TUNNEL_TYPE_NVE_CHECK(new_tunnel_id)) {
            if (nve_tunnel_cnt >= rm_resource_global.tunnel_nve_num_max) {
                err = SX_STATUS_NO_RESOURCES;
                SX_LOG_ERR("Can't add new NVE tunnel entry to DB (reach maximum entries %u)\n",
                           rm_resource_global.tunnel_nve_num_max);
                goto out;
            }
        } else if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(new_tunnel_id)) {
            if (err == SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Flex tunnel[0x%x] with requested attributes exists\n", new_tunnel_id);
                err = SX_STATUS_ENTRY_ALREADY_EXISTS;
                goto out;
            }

            if (l2_flex_tunnel_cnt >= rm_resource_global.tunnel_l2_flex_num_max) {
                err = SX_STATUS_NO_RESOURCES;
                SX_LOG_ERR("Can't add new FLEX tunnel entry to DB (reach maximum entries %u)\n",
                           rm_resource_global.tunnel_l2_flex_num_max);
                goto out;
            }
        }
    }

    err = __sdk_tunnel_db_allocate_entry(&tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Tunnel entry allocation error\n");
        goto out;
    }
    entry_allocation_rollback = TRUE;

    tunnel_identifier = tunnel_entry_p->data.tunnel_identifier;
    new_tunnel_id = SX_TUNNEL_IDENTIFIER_SET(new_tunnel_id, tunnel_identifier);
    new_tunnel_id = SX_TUNNEL_DIRECTION_SET(new_tunnel_id, tunnel_attr_p->direction);

    if (SX_TUNNEL_TYPE_IPINIP_CHECK(new_tunnel_id)) {
        utils_err = sdk_refcount_init(&tunnel_entry_p->data.ref_count, &ref_name_data, NULL);
        if (SX_UTILS_STATUS_SUCCESS != utils_err) {
            SX_LOG_ERR("Failed to init refcount, utils_err = %s\n", SX_UTILS_STATUS_MSG(utils_err));
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }

        ipinip_tunnel_cnt++;
    } else if (SX_TUNNEL_TYPE_NVE_CHECK(new_tunnel_id)) {
        nve_ref_delete_data.delete_func_p = g_nve_tunnel_delete_func_cb;
        nve_ref_delete_data.id = new_tunnel_id;
        utils_err = sdk_refcount_init(&tunnel_entry_p->data.ref_count, &ref_name_data, &nve_ref_delete_data);
        if (SX_UTILS_STATUS_SUCCESS != utils_err) {
            SX_LOG_ERR("Failed to init refcount, utils_err = %s\n", SX_UTILS_STATUS_MSG(utils_err));
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }

        nve_tunnel_cnt++;
    } else if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(new_tunnel_id)) {
        nve_ref_delete_data.delete_func_p = g_nve_tunnel_delete_func_cb;
        nve_ref_delete_data.id = new_tunnel_id;
        utils_err = sdk_refcount_init(&tunnel_entry_p->data.ref_count, &ref_name_data, &nve_ref_delete_data);
        if (SX_UTILS_STATUS_SUCCESS != utils_err) {
            SX_LOG_ERR("Failed to init L2 flex tunnel refcount, utils_err = %s\n", SX_UTILS_STATUS_MSG(utils_err));
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }
        l2_flex_tunnel_cnt++;
    }

    SX_MEM_CPY_P(&tunnel_entry_p->data.tun_attr, tunnel_attr_p);
    tunnel_entry_p->data.pending_delete = FALSE;
    if (vrid_ref_p) {
        tunnel_entry_p->data.vrid_ref = *vrid_ref_p;
    }

    if (SX_TUNNEL_TYPE_NVE_CHECK(new_tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(new_tunnel_id)) {
        log_port = tunnel_impl_get_l2_log_port(tunnel_attr_p);
        cl_qmap_insert(&nve_log_port_to_tunnel_map, log_port, &tunnel_entry_p->log_port_map_item);
    }

    utils_err = bit_vector_allocate(SX_TUNNEL_VNI_VALUE_MAX + 1, &tunnel_entry_p->data.vni_to_fid_vector);
    if (SX_UTILS_STATUS_SUCCESS != utils_err) {
        SX_LOG_ERR("Failed to init vni to fid bit vector, err = %s\n",
                   SX_UTILS_STATUS_MSG(utils_err));
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

    *tunnel_id_p = new_tunnel_id;

out:
    if (SX_STATUS_SUCCESS != err) {
        if (entry_allocation_rollback) {
            cl_qmap_remove(&tunnel_map, tunnel_entry_p->data.tunnel_identifier);
            utils_err = id_allocator_put(&tunnel_id_allocator, tunnel_entry_p->data.tunnel_identifier);
            if (utils_err != CL_SUCCESS) {
                SX_LOG_ERR("Failed to rollback, id [%d], err = [%s]\n",
                           tunnel_entry_p->data.tunnel_identifier, SX_UTILS_STATUS_MSG(utils_err));
            }
            cl_qpool_put(&tunnel_pool, &tunnel_entry_p->pool_item);
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_delete(sx_tunnel_id_t tunnel_id)
{
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    cl_map_item_t         *map_item_p = NULL;
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t               tunnel_identifier = 0;

    SX_LOG_ENTER();
    SX_LOG_DBG("Delete Tunnel[0x%08x] from hwi DB\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    tunnel_identifier = SX_TUNNEL_IDENTIFIER_GET(tunnel_id);

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    utils_err = sdk_refcount_deinit(&tunnel_entry_p->data.ref_count, FALSE);
    if (SX_UTILS_STATUS_SUCCESS != utils_err) {
        SX_LOG_ERR("Failed to deinit tunnel[0x%08x] reference count, utils_err = %s\n",
                   tunnel_id, SX_UTILS_STATUS_MSG(utils_err));
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

    map_item_p = cl_qmap_remove(&tunnel_map, tunnel_identifier);

    tunnel_entry_p = PARENT_STRUCT(map_item_p, sdk_db_tunnel_entry_t, map_item);

    if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        cl_qmap_remove_item(&nve_log_port_to_tunnel_map, &(tunnel_entry_p->log_port_map_item));
    }

    utils_err = id_allocator_put(&tunnel_id_allocator, tunnel_identifier);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to put tunnel identifier.\n");
        goto out;
    }

    if (SX_TUNNEL_TYPE_IPINIP_CHECK(tunnel_id)) {
        ipinip_tunnel_cnt--;
    } else if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id)) {
        nve_tunnel_cnt--;
    } else if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        l2_flex_tunnel_cnt--;
    }

    utils_err = bit_vector_free(tunnel_entry_p->data.vni_to_fid_vector);
    if (SX_UTILS_STATUS_SUCCESS != utils_err) {
        SX_LOG_ERR("Failed to deinit vni to fid bit vector, err = %s\n",
                   SX_UTILS_STATUS_MSG(utils_err));
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }
    SX_MEM_CLR(tunnel_entry_p->data.vni_to_fid_vector);
    cl_qpool_put(&tunnel_pool, &tunnel_entry_p->pool_item);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_edit(sx_tunnel_id_t tunnel_id, const sx_tunnel_attribute_t * new_tunnel_attr_p)
{
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    sx_status_t            err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel[0x%08x] params from DB\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(new_tunnel_attr_p, "new_tunnel_attr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_MEM_CPY(tunnel_entry_p->data.tun_attr.attributes,
               new_tunnel_attr_p->attributes);

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tunnel_db_get(sx_tunnel_id_t               tunnel_id,
                              const sdk_db_tunnel_data_t **tunnel_params_p,
                              boolean_t                    ignore_pending_delete)
{
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    sx_status_t            err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel[0x%08x] params from DB\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_params_p, "tunnel_params_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (ignore_pending_delete == FALSE) {
        if (tunnel_entry_p->data.pending_delete) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to get the tunnel[0x%08x], err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
    }

    *tunnel_params_p = &tunnel_entry_p->data;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_id_by_log_port_get(sx_port_log_id_t log_port, sx_tunnel_id_t *tunnel_id_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    cl_map_item_t         *map_item_p = NULL;
    uint32_t               tunnel_id_tmp = 0;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel_id by log_port(%u) DB\n", log_port);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_id_p, "tunnel_id_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    map_item_p = cl_qmap_get(&nve_log_port_to_tunnel_map, log_port);
    if (cl_qmap_end(&nve_log_port_to_tunnel_map) == map_item_p) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("Log port(%u) entry doesn't exists\n", log_port);
        goto out;
    }

    tunnel_entry_p = PARENT_STRUCT(map_item_p, sdk_db_tunnel_entry_t, log_port_map_item);

    tunnel_id_tmp = SX_TUNNEL_IDENTIFIER_SET(tunnel_id_tmp, tunnel_entry_p->data.tunnel_identifier);
    tunnel_id_tmp = SX_TUNNEL_DIRECTION_SET(tunnel_id_tmp, tunnel_entry_p->data.tun_attr.direction);
    tunnel_id_tmp = SX_TUNNEL_TYPE_ID_SET(tunnel_id_tmp, tunnel_entry_p->data.tun_attr.type);

    *tunnel_id_p = tunnel_id_tmp;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_nve_tunnel_attr_get(sdk_db_tunnel_data_t const **tunnel_data_p)
{
    sx_status_t            err = SX_STATUS_ENTRY_NOT_FOUND;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    cl_map_item_t         *map_item = NULL;
    const cl_map_item_t   *map_end = NULL;

    SX_LOG_ENTER();

    if (utils_check_pointer(tunnel_data_p, "tunnel_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    map_item = cl_qmap_head(&nve_log_port_to_tunnel_map);
    map_end = cl_qmap_end(&nve_log_port_to_tunnel_map);
    if (map_end == map_item) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    while (map_item != map_end) {
        tunnel_entry_p = PARENT_STRUCT(map_item, sdk_db_tunnel_entry_t, log_port_map_item);
        map_item = cl_qmap_next(map_item);

        if (SX_CHECK_RANGE((SX_TUNNEL_TYPE_NVE_MIN), (tunnel_entry_p->data.tun_attr.type), (SX_TUNNEL_TYPE_NVE_MAX))) {
            err = SX_STATUS_SUCCESS;
            *tunnel_data_p = &tunnel_entry_p->data;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_total_tunnel_get(uint32_t * total_ipinip_count,
                                           uint32_t * total_nve_count,
                                           uint32_t * total_l2_flex_count)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get total tunnels count from DB\n");

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (total_ipinip_count) {
        *total_ipinip_count = ipinip_tunnel_cnt;
    }

    if (total_nve_count) {
        *total_nve_count = nve_tunnel_cnt;
    }

    if (total_l2_flex_count) {
        *total_l2_flex_count = l2_flex_tunnel_cnt;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_ref_increase(sx_tunnel_id_t tunnel_id, ref_name_data_t *ref_name_data, sdk_ref_t* ref)
{
    sdk_db_tunnel_entry_t * tunnel_entry_p = NULL;
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_utils_status_t       utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();
    if (LOG_VAR_NAME(__MODULE__) >= SX_VERBOSITY_LEVEL_DEBUG) {
        SX_LOG_DBG("Increase Tunnel[0x%08x] reference \"%s\"\n", tunnel_id,
                   print_reference_name(ref_name_data));
    }

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(ref, "ref")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    if (tunnel_entry_p->data.pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to increase a ref counter of tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    utils_err = sdk_refcount_inc(&(tunnel_entry_p->data.ref_count), ref_name_data, ref);
    if (SX_UTILS_STATUS_SUCCESS != utils_err) {
        SX_LOG_ERR("Failed increase tunnel[0x%08x] refcount, err = %s\n",
                   tunnel_id, SX_UTILS_STATUS_MSG(utils_err));

        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_ref_decrease(sx_tunnel_id_t tunnel_id, const sdk_ref_t* ref)
{
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Decrease Tunnel[0x%08x] reference counter\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(ref, "ref")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    utils_err = sdk_refcount_dec(&(tunnel_entry_p->data.ref_count), ref);
    if (SX_UTILS_STATUS_SUCCESS != utils_err) {
        SX_LOG_ERR("Failed decreasing tunnel[0x%08x] refcount, utils_err = %s\n",
                   tunnel_id, SX_UTILS_STATUS_MSG(utils_err));

        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_ref_count_get(sx_tunnel_id_t tunnel_id,
                                        uint32_t      *refcount_p,
                                        uint32_t       buf_size,
                                        char         * references_name)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel[0x%08x] reference count\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(refcount_p, "refcount_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    utils_err = sdk_refcount_get(&tunnel_entry_p->data.ref_count, (int32_t*)refcount_p);
    if (SX_UTILS_STATUS_SUCCESS != utils_err) {
        SX_LOG_ERR("Failed getting tunnel[0x%08x] refcount value, utils_err = %s\n",
                   tunnel_id, SX_UTILS_STATUS_MSG(utils_err));

        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

    if (references_name != NULL) {
        utils_err = sdk_refcount_getname_ref(&tunnel_entry_p->data.ref_count, buf_size, references_name);
        if (SX_UTILS_STATUS_SUCCESS != utils_err) {
            SX_LOG_ERR("Failed getting tunnel[0x%08x] references name, utils_err = %s\n",
                       tunnel_id, SX_UTILS_STATUS_MSG(utils_err));
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }
    }

    SX_LOG_DBG("Tunnel[0x%08x] has %u references\n", tunnel_id, *refcount_p);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_pending_delete_set(sx_tunnel_id_t tunnel_id, boolean_t pending_delete)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    tunnel_entry_p->data.pending_delete = pending_delete;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_pending_delete_get(sx_tunnel_id_t tunnel_id, boolean_t      *pending_delete_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(pending_delete_p, "pending_delete_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    *pending_delete_p = FALSE;

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    *pending_delete_p = tunnel_entry_p->data.pending_delete;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_hw_decap_handle_get(sx_tunnel_id_t                tunnel_id,
                                              hwi_tunnel_hw_decap_handle_t *tunnel_decap_handle_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel[0x%08x] hw decap handle\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_decap_handle_p, "tunnel_decap_handle_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    *tunnel_decap_handle_p = tunnel_entry_p->data.hwd_decap_handle;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_hw_encap_handle_get(sx_tunnel_id_t                tunnel_id,
                                              hwi_tunnel_hw_encap_handle_t *tunnel_encap_handle_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel[0x%08x] hw decap handle\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_encap_handle_p, "tunnel_encap_handle_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    *tunnel_encap_handle_p = tunnel_entry_p->data.hwd_encap_handle;

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tunnel_db_hw_handle_set(sx_tunnel_id_t               tunnel_id,
                                        hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                        hwi_tunnel_hw_decap_handle_t tunnel_decap_handle)
{
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    sx_status_t            err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Set tunnel[0x%08x] hw encap/decap handles\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    tunnel_entry_p->data.hwd_encap_handle = tunnel_encap_handle;
    tunnel_entry_p->data.hwd_decap_handle = tunnel_decap_handle;

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tunnel_db_vrid_ref_set(sx_tunnel_id_t tunnel_id, const sdk_ref_t *vrid_ref_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel[0x%08x] decap handle from DB\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(vrid_ref_p, "vrid_ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    tunnel_entry_p->data.vrid_ref = *vrid_ref_p;
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_vrid_ref_get(sx_tunnel_id_t tunnel_id, sdk_ref_t *vrid_ref_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel[0x%08x] VRID reference\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(vrid_ref_p, "vrid_ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    *vrid_ref_p = tunnel_entry_p->data.vrid_ref;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_rif_ref_set(const sx_tunnel_id_t tunnel_id, const sdk_ref_t *rif_ref_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Set tunnel[0x%08x] RIF reference\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(rif_ref_p, "rif_ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    tunnel_entry_p->data.rif_ref = *rif_ref_p;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_rif_ref_get(const sx_tunnel_id_t tunnel_id, sdk_ref_t *rif_ref_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel[0x%08x] RIF reference\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(rif_ref_p, "rif_ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    *rif_ref_p = tunnel_entry_p->data.rif_ref;

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tunnel_db_ulay_rif_ref_set(const sx_tunnel_id_t tunnel_id, const sdk_ref_t *rif_ref_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Set tunnel[0x%08x] RIF reference\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(rif_ref_p, "rif_ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    tunnel_entry_p->data.underlay_rif_ref = *rif_ref_p;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_ulay_rif_ref_get(const sx_tunnel_id_t tunnel_id, sdk_ref_t *rif_ref_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel[0x%08x] RIF reference\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(rif_ref_p, "rif_ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    *rif_ref_p = tunnel_entry_p->data.underlay_rif_ref;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_ulay_rif_decap_ref_set(const sx_tunnel_id_t tunnel_id, const sdk_ref_t *rif_ref_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Set tunnel[0x%08x] Underlay RIF decap reference\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(rif_ref_p, "rif_ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    tunnel_entry_p->data.underlay_rif_decap_ref = *rif_ref_p;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_ulay_rif_decap_ref_get(const sx_tunnel_id_t tunnel_id, sdk_ref_t *rif_ref_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel[0x%08x] Underlay RIF decap reference\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(rif_ref_p, "rif_ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    *rif_ref_p = tunnel_entry_p->data.underlay_rif_decap_ref;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_id_by_hw_decap_get(hwi_tunnel_hw_decap_handle_t tunnel_decap_handle,
                                                    sx_tunnel_id_t              *tunnel_id_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t       *tunnel_entry_p = NULL;
    cl_map_item_t               *map_item = NULL;
    const cl_map_item_t         *map_end = NULL;
    const sx_tunnel_attribute_t *tunnel_attr_p;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel id by hw decap handle[%d]\n", (uint32_t)tunnel_decap_handle);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_id_p, "tunnel_id_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    map_item = cl_qmap_head(&tunnel_map);
    map_end = cl_qmap_end(&tunnel_map);

    while (map_item != map_end) {
        tunnel_entry_p = PARENT_STRUCT(map_item, sdk_db_tunnel_entry_t, map_item);
        map_item = cl_qmap_next(map_item);

        if (tunnel_entry_p->data.hwd_decap_handle == tunnel_decap_handle) {
            tunnel_attr_p = &tunnel_entry_p->data.tun_attr;
            *tunnel_id_p = SX_TUNNEL_MAKE_ID(tunnel_entry_p->data.tunnel_identifier,
                                             tunnel_attr_p->type,
                                             tunnel_attr_p->direction);
            goto out;
        }
    }
    err = SX_STATUS_INVALID_HANDLE;
    *tunnel_id_p = SX_TUNNEL_ID_INVALID;
    SX_LOG_ERR("Failed to get tunnel\n");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_id_by_hw_encap_get(hwi_tunnel_hw_encap_handle_t tunnel_encap_handle,
                                                    sx_tunnel_id_t              *tunnel_id_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t       *tunnel_entry_p = NULL;
    cl_map_item_t               *map_item = NULL;
    const cl_map_item_t         *map_end = NULL;
    const sx_tunnel_attribute_t *tunnel_attr_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Get tunnel id by hw encap handle[%d]\n", (uint32_t)tunnel_encap_handle);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_id_p, "tunnel_id_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    map_item = cl_qmap_head(&tunnel_map);
    map_end = cl_qmap_end(&tunnel_map);

    while (map_item != map_end) {
        tunnel_entry_p = PARENT_STRUCT(map_item, sdk_db_tunnel_entry_t, map_item);
        map_item = cl_qmap_next(map_item);

        if (tunnel_entry_p->data.hwd_encap_handle == tunnel_encap_handle) {
            tunnel_attr_p = &tunnel_entry_p->data.tun_attr;
            *tunnel_id_p = SX_TUNNEL_MAKE_ID(tunnel_entry_p->data.tunnel_identifier,
                                             tunnel_attr_p->type,
                                             tunnel_attr_p->direction);
            goto out;
        }
    }
    err = SX_STATUS_INVALID_HANDLE;
    *tunnel_id_p = SX_TUNNEL_ID_INVALID;
    SX_LOG_ERR("Failed to get tunnel\n");

out:
    SX_LOG_EXIT();
    return err;
}

void sdk_tunnel_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    cl_map_item_t                         *map_item_p = NULL;
    sdk_db_tunnel_entry_t                 *tunnel_entry_p = NULL;
    tunnel_vrid_to_default_rif_map_item_t *tunnel_vrid_to_default_rif_map_item_p = NULL;
    sdk_db_tunnel_data_t                  *tunnel_data_p = NULL;
    sx_tunnel_attribute_t                 *tunnel_attr_p = NULL;
    cl_fmap_item_t                        *entry_map_item = NULL;
    const cl_fmap_item_t                  *entry_map_end = NULL;
    tunnel_mapping_item_t                 *tunnel_map_item = NULL;
    sx_tunnel_id_t                         tunnel_id = SX_TUNNEL_ID_INVALID;
    char                                   tunnel_id_str[11];
    boolean_t                              pending_delete = FALSE;
    uint32_t                               ref_cnt = 0;
    uint32_t                               ipinip_count = 0, nve_count = 0, l2_flex_count = 0;
    uint32_t                               i = 0;
    sx_fid_t                               fid = SX_FID_ID_INVALID;
    sx_tunnel_vni_t                        vni = 0;
    sx_tunnel_underlay_domain_type_e       underlay_domain_type = 0;
    sx_flow_counter_id_t                   decap_counter_id = 0;
    sx_flow_counter_id_t                   encap_uc_counter_id = 0;
    sx_flow_counter_id_t                   encap_mc_counter_id = 0;
    sx_flow_counter_set_t                  decap_counter_val = {0, 0};
    sx_flow_counter_set_t                  encap_uc_counter_val = {0, 0};
    sx_flow_counter_set_t                  encap_mc_counter_val = {0, 0};
    char                                   ref_name[10 * (REFERENCE_NAME_MAX_LEN + 2)] = "\0"; /* No need to print more than 10 reference */
    sx_tunnel_ipinip_gre_mode_e            gre_mode;
    dbg_utils_table_columns_t              tunnel_entry_table[] = {
        {"ID", 10, PARAM_STRING_E, NULL},
        {"Type", 9, PARAM_STRING_E, NULL},
        {"Dir", 10, PARAM_STRING_E, NULL},
        {"RefCnt", 7, PARAM_UINT32_E, NULL},
        {"Pending Delete", 15, PARAM_UINT32_E, &pending_delete},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    dbg_utils_table_columns_t              tunnel_bridge_to_vni_table[] = {
        { "FID",  15, PARAM_UINT16_E, &fid},
        { "VNI",  15, PARAM_UINT32_E, &vni},
        { "Decap cntr ID",  15, PARAM_UINT32_E, &decap_counter_id},
        { "Decap packets count",  25, PARAM_UINT64_E, &decap_counter_val.flow_counter_packets},
        { "Decap bytes count",  20, PARAM_UINT64_E, &decap_counter_val.flow_counter_bytes},
        { "Encap UC cntr ID",  16, PARAM_UINT32_E, &encap_uc_counter_id},
        { "Encap UC packets count",  25, PARAM_UINT64_E, &encap_uc_counter_val.flow_counter_packets},
        { "Encap UC bytes count",  20, PARAM_UINT64_E, &encap_uc_counter_val.flow_counter_bytes},
        { "Encap MC cntr ID",  16, PARAM_UINT32_E, &encap_mc_counter_id},
        { "Encap MC packets count",  25, PARAM_UINT64_E, &encap_uc_counter_val.flow_counter_packets},
        { "Encap MC bytes count",  25, PARAM_UINT64_E, &encap_uc_counter_val.flow_counter_bytes},
        { "Pending Delete",  15, PARAM_UINT32_E, &pending_delete},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t              flex_tunnel_header_table[] = {
        {"ID", 5, PARAM_UINT32_E, NULL},              /* 0 */
        {"Underlay RIF", 13, PARAM_UINT32_E, NULL},   /* 1 */
        {"EMT_ID",  8, PARAM_UINT32_E, NULL},         /* 2 */
        {"IP Type", 8, PARAM_STRING_E, NULL},         /* 3 */
        {"IP Proto", 9, PARAM_UINT8_E, NULL},         /* 4 */
        {"IPv4 ID", 8, PARAM_UINT16_E, NULL},         /* 5 */
        {"IPv4 Flags", 11, PARAM_UINT8_E, NULL},      /* 6 */
        {"Tunnel ID", 10, PARAM_STRING_E, NULL},      /* 7 */
        {NULL, 0, 0, NULL}
    };
    FILE                                  *stream = NULL;

    SX_LOG_ENTER();

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "HWI TUNNEL DB");

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = sdk_tunnel_db_total_tunnel_get(&ipinip_count, &nve_count, &l2_flex_count);

    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Can't get tunnel count statistic\n");
        goto out;
    }

    dbg_utils_pprinter_field_print(stream, "Total IPINIP tunnels:", &ipinip_count, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Total NVE tunnels:", &nve_count, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Total L2 Flex tunnels:", &l2_flex_count, PARAM_UINT32_E);

    dbg_utils_pprinter_print(stream, "\n");

    dbg_utils_pprinter_table_headline_print(stream, tunnel_entry_table);

    if (cl_is_qmap_empty(&tunnel_map)) {
        goto out;
    }

    map_item_p = cl_qmap_head(&tunnel_map);
    while (cl_qmap_end(&tunnel_map) != map_item_p) {        /* first stage. Print brief tunnels data */
        tunnel_entry_p = PARENT_STRUCT(map_item_p, sdk_db_tunnel_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        tunnel_data_p = &tunnel_entry_p->data;
        tunnel_attr_p = &tunnel_entry_p->data.tun_attr;
        tunnel_id = SX_TUNNEL_MAKE_ID(tunnel_entry_p->data.tunnel_identifier,
                                      tunnel_attr_p->type,
                                      tunnel_attr_p->direction);

        snprintf(tunnel_id_str, sizeof(tunnel_id_str), "0x%.8x", tunnel_id);
        tunnel_entry_table[DBG_TUNNEL_ID_E].data = tunnel_id_str;
        if (SX_TUNNEL_TYPE_IPINIP_CHECK(tunnel_id)) {
            tunnel_entry_table[DBG_TUNNEL_TYPE_E].data = "IPINIP";
        } else if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id)) {
            tunnel_entry_table[DBG_TUNNEL_TYPE_E].data = "NVE";
        } else if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
            tunnel_entry_table[DBG_TUNNEL_TYPE_E].data = "L2 FLEX";
        } else {
            tunnel_entry_table[DBG_TUNNEL_TYPE_E].data = "Unknown";
        }

        tunnel_entry_table[DBG_TUNNEL_DIR_E].data =
            SX_TUNNEL_DIRECTION_SHORT_STR(tunnel_attr_p->direction);

        err = sdk_tunnel_db_ref_count_get(tunnel_id, &ref_cnt, sizeof(ref_name), ref_name);
        if (SX_STATUS_SUCCESS == err) {
            tunnel_entry_table[DBG_TUNNEL_REF_CNT_E].data = &ref_cnt;
        }

        pending_delete = tunnel_entry_p->data.pending_delete;

        dbg_utils_pprinter_table_data_line_print(stream, tunnel_entry_table);
    }

    dbg_utils_pprinter_general_header_print(stream, "Tunnel detailed data");

    map_item_p = cl_qmap_head(&tunnel_map);
    while (cl_qmap_end(&tunnel_map) != map_item_p) {    /* second stage. Print detailed tunnels data */
        tunnel_entry_p = PARENT_STRUCT(map_item_p, sdk_db_tunnel_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        tunnel_data_p = &tunnel_entry_p->data;
        tunnel_attr_p = &tunnel_entry_p->data.tun_attr;

        tunnel_id = SX_TUNNEL_MAKE_ID(tunnel_entry_p->data.tunnel_identifier,
                                      tunnel_attr_p->type,
                                      tunnel_attr_p->direction);

        dbg_utils_pprinter_secondary_header_print(stream, "TUNNEL 0x%.8x", tunnel_id);
        dbg_utils_pprinter_field_print(stream, "TUNNEL",  &tunnel_id, PARAM_HEX_E);
        dbg_utils_pprinter_field_print(stream, "Identifier", &tunnel_entry_p->data.tunnel_identifier, PARAM_UINT32_E);
        dbg_utils_pprinter_field_print(stream, "Type",
                                       sx_tunnel_type_str(tunnel_attr_p->type),
                                       PARAM_STRING_E);
        dbg_utils_pprinter_field_print(stream, "Dir",
                                       SX_TUNNEL_DIRECTION_SHORT_STR(tunnel_attr_p->direction),
                                       PARAM_STRING_E);
        underlay_domain_type = tunnel_impl_get_underlay_domain_type(tunnel_attr_p);
        dbg_utils_pprinter_field_print(stream, "Underlay Domain Type",
                                       sx_tunnel_underlay_domain_type_str(underlay_domain_type),
                                       PARAM_STRING_E);

        if (SX_TUNNEL_TYPE_IPINIP_CHECK(tunnel_id)) {
            dbg_utils_pprinter_field_print(stream, "Overlay RIF",
                                           &tunnel_attr_p->attributes.ipinip_p2p.overlay_rif,
                                           PARAM_UINT16_E);

            dbg_utils_pprinter_field_print(stream, "Underlay RIF",
                                           &tunnel_attr_p->attributes.ipinip_p2p.underlay_rif,
                                           PARAM_UINT16_E);

            if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
                dbg_utils_pprinter_field_print(stream, "Underlay VRID",
                                               &tunnel_attr_p->attributes.ipinip_p2p.encap.underlay_vrid,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream,
                                               "Underlay SIP",
                                               &tunnel_attr_p->attributes.ipinip_p2p.encap.underlay_sip.addr.ipv4.s_addr,
                                               PARAM_IPV4_E);
                if (SX_TUNNEL_TYPE_ID_GET(tunnel_id) == SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE) {
                    gre_mode = tunnel_attr_p->attributes.ipinip_p2p.encap.gre_mode;
                    dbg_utils_pprinter_field_print(stream, "GRE mode",
                                                   sx_tunnel_ipinip_gre_mode_str(gre_mode),
                                                   PARAM_STRING_E);
                    dbg_utils_pprinter_field_print(stream, "GRE key",
                                                   &tunnel_attr_p->attributes.ipinip_p2p.encap.gre_key,
                                                   PARAM_UINT32_E);
                }
            }

            if (SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id)) {
                if ((tunnel_attr_p->type == SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE) ||
                    (tunnel_attr_p->type == SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE) ||
                    (tunnel_attr_p->type == SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE) ||
                    (tunnel_attr_p->type == SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE)) {
                    dbg_utils_pprinter_field_print(stream, "GRE check KEY",
                                                   &tunnel_attr_p->attributes.ipinip_p2p.decap.gre_check_key,
                                                   PARAM_BOOL_E);
                    dbg_utils_pprinter_field_print(stream, "GRE expected KEY",
                                                   &tunnel_attr_p->attributes.ipinip_p2p.decap.gre_expected_key,
                                                   PARAM_UINT32_E);
                }
            }
        } else if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id)) {
            if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
                dbg_utils_pprinter_field_print(stream, "Underlay VRID",
                                               &tunnel_attr_p->attributes.geneve.encap.underlay_vrid,
                                               PARAM_UINT8_E);

                if (SX_IP_VERSION_IPV6 == tunnel_attr_p->attributes.geneve.encap.underlay_sip.version) {
                    dbg_utils_pprinter_field_print(stream, "Underlay SIP",
                                                   &tunnel_attr_p->attributes.geneve.encap.underlay_sip.addr.ipv6,
                                                   PARAM_IPV6_E);
                } else {
                    dbg_utils_pprinter_field_print(stream,
                                                   "Underlay SIP",
                                                   &tunnel_attr_p->attributes.geneve.encap.underlay_sip.addr.ipv4.s_addr,
                                                   PARAM_IPV4_E);
                }

                dbg_utils_pprinter_field_print(stream, "Underlay RIF Encap",
                                               &tunnel_attr_p->attributes.geneve.encap.underlay_rif,
                                               PARAM_UINT8_E);
            }

            if (SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id)) {
                dbg_utils_pprinter_field_print(stream, "Underlay RIF Decap",
                                               &tunnel_attr_p->attributes.geneve.decap.underlay_rif,
                                               PARAM_UINT8_E);

                dbg_utils_pprinter_field_print(stream, "Tag mode",
                                               sx_vlan_tag_mode_str(tunnel_attr_p->attributes.geneve.decap.tag_mode),
                                               PARAM_STRING_E);
                dbg_utils_pprinter_field_print(stream, "Egress Eth",
                                               &tunnel_attr_p->attributes.geneve.decap.egress_et_set,
                                               PARAM_BOOL_E);


                dbg_utils_pprinter_field_print(stream, "Reserved bits check mode",
                                               sx_tunnel_nve_reserved_bits_mode_str(tunnel_attr_p->attributes.geneve.
                                                                                    decap
                                                                                    .reserved_bits_check.mode),
                                               PARAM_STRING_E);
                dbg_utils_pprinter_field_print(stream, "Mask",
                                               &tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mask,
                                               PARAM_HEX64_E);
            }
        } else if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
            dbg_utils_pprinter_field_print(stream, "Port ID",
                                           &tunnel_attr_p->attributes.l2_flex.log_port,
                                           PARAM_PORT_ID_E);
            dbg_utils_pprinter_field_print(stream, "QoS Profile",
                                           &tunnel_attr_p->attributes.l2_flex.tunnel_qos_profile.profile_id,
                                           PARAM_UINT32_E);

            if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
                if (SX_IP_VERSION_IPV6 == tunnel_attr_p->attributes.l2_flex.encap.underlay_sip.version) {
                    dbg_utils_pprinter_field_print(stream, "Underlay SIP",
                                                   &tunnel_attr_p->attributes.l2_flex.encap.underlay_sip.addr.ipv6,
                                                   PARAM_IPV6_E);
                } else {
                    dbg_utils_pprinter_field_print(stream,
                                                   "Underlay SIP",
                                                   &tunnel_attr_p->attributes.l2_flex.encap.underlay_sip.addr.ipv4.s_addr,
                                                   PARAM_IPV4_E);
                }

                dbg_utils_pprinter_field_print(stream, "Underlay RIF Encap",
                                               &tunnel_attr_p->attributes.l2_flex.encap.underlay_rif,
                                               PARAM_UINT8_E);

                dbg_utils_pprinter_field_print(stream, "Flex Tunnel Header Id",
                                               &tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                                               PARAM_UINT32_E);
            }

            if (SX_TUNNEL_DIRECTION_CHECK_DECAP(tunnel_id)) {
                dbg_utils_pprinter_field_print(stream, "Underlay RIF Decap",
                                               &tunnel_attr_p->attributes.l2_flex.decap.underlay_rif,
                                               PARAM_UINT8_E);
                dbg_utils_pprinter_field_print(stream, "Tag mode",
                                               sx_vlan_tag_mode_str(tunnel_attr_p->attributes.l2_flex.decap.tag_mode),
                                               PARAM_STRING_E);
                dbg_utils_pprinter_field_print(stream, "Egress Eth",
                                               &tunnel_attr_p->attributes.l2_flex.decap.egress_et_set,
                                               PARAM_BOOL_E);
            }
        }

        dbg_utils_pprinter_field_print(stream, "HWD Encap handler",
                                       &tunnel_data_p->hwd_encap_handle,
                                       PARAM_HEX_E);
        dbg_utils_pprinter_field_print(stream, "HWD Decap handler",
                                       &tunnel_data_p->hwd_decap_handle,
                                       PARAM_HEX_E);

        err = sdk_tunnel_db_ref_count_get(tunnel_id, &ref_cnt, sizeof(ref_name), ref_name);
        if (SX_STATUS_SUCCESS == err) {
            dbg_utils_pprinter_field_print(stream, "Ref cnt", &ref_cnt, PARAM_UINT32_E);
        }
    }

    dbg_utils_pprinter_general_header_print(stream, "Tunnel, Bridge to VNI mapping");
    map_item_p = cl_qmap_head(&tunnel_map);
    while (cl_qmap_end(&tunnel_map) != map_item_p) {    /*  Print detailed tunnels map entries data */
        tunnel_entry_p = PARENT_STRUCT(map_item_p, sdk_db_tunnel_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        tunnel_data_p = &tunnel_entry_p->data;
        tunnel_attr_p = &tunnel_entry_p->data.tun_attr;
        tunnel_id = SX_TUNNEL_MAKE_ID(tunnel_data_p->tunnel_identifier,
                                      tunnel_attr_p->type,
                                      tunnel_attr_p->direction);

        dbg_utils_pprinter_secondary_header_print(stream, "Bridge to VNI - Tunnel 0x%.8x", tunnel_id);
        dbg_utils_pprinter_table_headline_print(stream, tunnel_bridge_to_vni_table);

        entry_map_end = cl_fmap_end(&tunnel_entry_p->data.tunnel_fid_map);
        entry_map_item = cl_fmap_head(&tunnel_entry_p->data.tunnel_fid_map);
        while (entry_map_end != entry_map_item) {
            tunnel_map_item = PARENT_STRUCT(entry_map_item, tunnel_mapping_item_t, fid_map_item);
            entry_map_item = cl_fmap_next(entry_map_item);
            fid = tunnel_map_item->map_entry.params.nve.bridge_id;
            vni = tunnel_map_item->map_entry.params.nve.vni;
            decap_counter_id = tunnel_map_item->decap_flow_counter_id;
            encap_uc_counter_id = tunnel_map_item->encap_uc_flow_counter_id;
            encap_mc_counter_id = tunnel_map_item->encap_mc_flow_counter_id;

            SX_MEM_CLR(decap_counter_val);
            if (decap_counter_id != SX_FLOW_COUNTER_ID_INVALID) {
                err = flow_counter_get(decap_counter_id, &decap_counter_val);
            }
            SX_MEM_CLR(encap_uc_counter_val);
            if (encap_uc_counter_id != SX_FLOW_COUNTER_ID_INVALID) {
                err = flow_counter_get(encap_uc_counter_id, &encap_uc_counter_val);
            }
            SX_MEM_CLR(encap_mc_counter_val);
            if (encap_mc_counter_id != SX_FLOW_COUNTER_ID_INVALID) {
                err = flow_counter_get(encap_mc_counter_id, &encap_mc_counter_val);
            }

            pending_delete = tunnel_map_item->pending_delete;

            dbg_utils_pprinter_table_data_line_print(stream, tunnel_bridge_to_vni_table);
        }
    }

    dbg_utils_pprinter_general_header_print(stream, "Tunnel, Vrid to Default RIF mapping");
    map_item_p = cl_qmap_head(&vrid_to_default_rif_map);
    while (cl_qmap_end(&vrid_to_default_rif_map) != map_item_p) {    /*  Print detailed tunnels map entries data */
        tunnel_vrid_to_default_rif_map_item_p = PARENT_STRUCT(map_item_p,
                                                              tunnel_vrid_to_default_rif_map_item_t,
                                                              map_item);
        map_item_p = cl_qmap_next(map_item_p);

        dbg_utils_pprinter_secondary_header_print(stream, "VRID 0x%.8x", tunnel_vrid_to_default_rif_map_item_p->vrid);
        dbg_utils_pprinter_field_print(stream, "VRID",  &(tunnel_vrid_to_default_rif_map_item_p->vrid), PARAM_HEX16_E);
        dbg_utils_pprinter_field_print(stream,
                                       "Default RIF",
                                       &tunnel_vrid_to_default_rif_map_item_p->rif,
                                       PARAM_UINT32_E);
    }

    dbg_utils_pprinter_general_header_print(stream, "Flex Tunnel Headers");

    ref_cnt = 0;
    for (i = 0; i < total_flex_header_cnt; i++) {
        if (flex_header_entries[i].allocated) {
            if (ref_cnt == 0) {
                dbg_utils_pprinter_table_headline_print(stream, flex_tunnel_header_table);
            }

            flex_tunnel_header_table[0].data = &flex_header_entries[i].header_id;
            flex_tunnel_header_table[1].data = &flex_header_entries[i].uirif;
            flex_tunnel_header_table[2].data = &flex_header_entries[i].header_cfg.tunnel_header_emt_id.emt_id;
            flex_tunnel_header_table[3].data = sx_ip_version_str(flex_header_entries[i].header_cfg.ip_version);
            flex_tunnel_header_table[4].data = &flex_header_entries[i].header_cfg.enc_ip_next_header;
            flex_tunnel_header_table[5].data = &flex_header_entries[i].header_cfg.underlay_ip_enc.uipv4.id;
            flex_tunnel_header_table[6].data = &flex_header_entries[i].header_cfg.underlay_ip_enc.uipv4.flags;

            if (flex_header_entries[i].used_by_tunnel) {
                flex_tunnel_header_table[7].type = PARAM_HEX_E;
                flex_tunnel_header_table[7].data = &flex_header_entries[i].tunnel_id;
            } else {
                flex_tunnel_header_table[7].type = PARAM_STRING_E;
                flex_tunnel_header_table[7].data = "NA";
            }

            dbg_utils_pprinter_table_data_line_print(stream, flex_tunnel_header_table);
            ref_cnt++;
        }
    }


out:
    SX_LOG_EXIT();
    return;
}

static sx_status_t __sdk_tunnel_db_check_exist_entry(sdk_db_tunnel_entry_t       *tunnel_entry_p,
                                                     const sx_tunnel_map_entry_t *map_entry_p)
{
    /*check if there is already entry bound to this tunnel that contain the same bridge or vni*/
    sx_status_t            err = SX_STATUS_SUCCESS;
    cl_fmap_item_t        *map_item = NULL;
    const cl_fmap_item_t  *map_end = NULL;
    boolean_t              enable = FALSE;
    tunnel_mapping_item_t *tunnel_map_item = NULL;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;

    map_item = cl_fmap_get(&tunnel_entry_p->data.tunnel_fid_map, map_entry_p);
    map_end = cl_fmap_end(&tunnel_entry_p->data.tunnel_fid_map);
    if (map_item != map_end) {
        tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);
        if (tunnel_map_item->pending_delete) {
            err = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("entry still exists-- map_entry_key(bridge %u & vni %u) is still in map -- err = %s \n",
                       map_entry_p->params.nve.bridge_id,
                       map_entry_p->params.nve.vni,
                       sx_status_str(err));
        } else {
            err = SX_STATUS_ENTRY_ALREADY_EXISTS;
            SX_LOG_ERR("entry already exists-- map_entry_key(bridge %u & vni %u) is already in map -- err = %s \n",
                       map_entry_p->params.nve.bridge_id,
                       map_entry_p->params.nve.vni,
                       sx_status_str(err));
        }
        return err;
    }
    utils_err = bit_vector_get(tunnel_entry_p->data.vni_to_fid_vector,
                               map_entry_p->params.nve.vni, &enable);
    if (SX_UTILS_STATUS_SUCCESS != utils_err) {
        SX_LOG_ERR("Failed to get bit %u in VNI to FID bit vector, err = %s\n",
                   map_entry_p->params.nve.vni, SX_UTILS_STATUS_MSG(utils_err));
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }
    if (enable == TRUE) {
        err = SX_STATUS_ENTRY_ALREADY_EXISTS;
        SX_LOG_ERR("entry already exists-- map_entry_key(bridge & vni) is already in map -- err = %s \n",
                   sx_status_str(err));
        goto out;
    }

out:
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_mapping_pending_delete_set(sx_tunnel_id_t                tunnel_id,
                                                            const sx_tunnel_map_entry_t * map_entry_p,
                                                            boolean_t                     pending_delete)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    cl_fmap_item_t        *map_item = NULL;
    const cl_fmap_item_t  *map_end = NULL;
    tunnel_mapping_item_t *tunnel_map_item = NULL;

    SX_LOG_ENTER();

    if (utils_check_pointer(map_entry_p, "map_entry_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    map_end = cl_fmap_end(&tunnel_entry_p->data.tunnel_fid_map);
    map_item = cl_fmap_get(&tunnel_entry_p->data.tunnel_fid_map, map_entry_p);
    if (map_item == map_end) {
        SX_LOG_ERR("didn't find the entry in the tunnel entries map so it cannot be removed\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);
    tunnel_map_item->pending_delete = pending_delete;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_mapping_pending_delete_get(sx_tunnel_id_t               tunnel_id,
                                                            const sx_tunnel_map_entry_t *map_entry_p,
                                                            boolean_t                   *pending_delete_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    cl_fmap_item_t        *map_item = NULL;
    const cl_fmap_item_t  *map_end = NULL;
    tunnel_mapping_item_t *tunnel_map_item = NULL;

    SX_LOG_ENTER();

    if (utils_check_pointer(map_entry_p, "map_entry_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(pending_delete_p, "pending_delete_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    map_end = cl_fmap_end(&tunnel_entry_p->data.tunnel_fid_map);
    map_item = cl_fmap_get(&tunnel_entry_p->data.tunnel_fid_map, map_entry_p);
    if (map_item == map_end) {
        SX_LOG_ERR("didn't find the entry in the tunnel entries map so it cannot be removed\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);
    *pending_delete_p = tunnel_map_item->pending_delete;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_mapping_add(const sx_tunnel_id_t         tunnel_id,
                                             const sx_tunnel_map_entry_t *map_entry_p,
                                             const uint32_t               map_entry_cnt)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_status_t            rb_err = SX_STATUS_SUCCESS;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    uint32_t               i = 0, j = 0;
    tunnel_mapping_item_t *tunnel_map_item = NULL;
    cl_pool_item_t        *pool_item = NULL;
    cl_fmap_item_t        *map_item = NULL;
    boolean_t              tunnel_rb = FALSE, mapper_rb = FALSE, pool_rb = FALSE;
    ref_name_data_t        tunnel_map_ref_name_data = {.print_func_p = get_tunnel_map_ref_name,
                                                       .ref_data_p = NULL,
                                                       .data_size = 0};
    ref_delete_data_t      tunnel_map_ref_delete_data = {.delete_func_p = NULL,
                                                         .id = DELETE_ID_INVALID};

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel hwi DB mapping add\n");


    if (utils_check_pointer(map_entry_p, "map_entry_p")) {
        SX_LOG_ERR("map_entry_p is NUll\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (map_entry_cnt == 0) {
        SX_LOG_ERR("number of entries to add is 0 did not add any\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    if (tunnel_entry_p->data.pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to get the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (tunnel_entry_p->data.entry_count + map_entry_cnt > TUNNEL_MAP_ENTRY_MAX) {
        SX_LOG_ERR("number of entries exist in tunnel + number of entries to add is larger then MAX %u err - %s",
                   TUNNEL_MAP_ENTRY_MAX, sx_status_str(err));
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    for (i = 0; i < map_entry_cnt; ++i) {
        err = __sdk_tunnel_db_check_exist_entry(tunnel_entry_p, &map_entry_p[i]);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("entry already exist in tunnel[0x%08x]  -- err = %s \n", tunnel_id, sx_status_str(err));
            goto out;
        }

        for (j = i + 1; j < map_entry_cnt; ++j) {
            if ((map_entry_p[i].params.nve.bridge_id == map_entry_p[j].params.nve.bridge_id) ||
                (map_entry_p[i].params.nve.vni == map_entry_p[j].params.nve.vni)) {
                SX_LOG_ERR("entry already exist in tunnel[0x%08x]  -- err = %s \n", tunnel_id, sx_status_str(err));
                err = SX_STATUS_ENTRY_ALREADY_EXISTS;
                goto out;
            }
        }
    }

    for (i = 0; i < map_entry_cnt; ++i) {
        pool_item = cl_qpool_get(&tunnel_mapper_pool);
        if (pool_item == NULL) {
            SX_LOG(SX_LOG_ERROR, "Could not find free map_entry in tunnel_db.\n");
            err = SX_STATUS_NO_RESOURCES;
            pool_rb = TRUE;
            rb_err = err;
            goto out;
        }

        tunnel_map_item = PARENT_STRUCT(pool_item, tunnel_mapping_item_t, pool_item);
        SX_MEM_CPY_P(&tunnel_map_item->map_entry, &map_entry_p[i]);
        cl_fmap_insert(&(tunnel_entry_p->data.tunnel_fid_map),
                       &tunnel_map_item->map_entry, &tunnel_map_item->fid_map_item);
        cl_fmap_insert(&(tunnel_entry_p->data.tunnel_vni_map),
                       &tunnel_map_item->map_entry, &tunnel_map_item->vni_map_item);
        utils_err = bit_vector_set(tunnel_entry_p->data.vni_to_fid_vector,
                                   tunnel_map_item->map_entry.params.nve.vni);
        if (SX_UTILS_STATUS_SUCCESS != utils_err) {
            SX_LOG_ERR("Failed to set bit %u in mac add bit vector, err = [%s]\n",
                       tunnel_map_item->map_entry.params.nve.vni, SX_UTILS_STATUS_MSG(utils_err));
            err = sx_utils_status_to_sx_status(utils_err);
            pool_rb = TRUE;
            rb_err = err;
            goto out;
        }

        tunnel_map_ref_name_data.ref_data_p = &tunnel_map_item->map_entry.params.nve.bridge_id;
        tunnel_map_ref_name_data.data_size = sizeof(tunnel_map_item->map_entry.params.nve.bridge_id);
        tunnel_map_ref_delete_data.delete_func_p = g_nve_tunnel_mapping_delete_func_cb;
        __tunnel_mapping_to_uin64_t(tunnel_id, tunnel_map_item->map_entry.params.nve.bridge_id,
                                    &tunnel_map_ref_delete_data.id);
        utils_err = sdk_refcount_init(&tunnel_map_item->ref_count, &tunnel_map_ref_name_data,
                                      &tunnel_map_ref_delete_data);
        if (SX_UTILS_STATUS_SUCCESS != utils_err) {
            err = sx_utils_status_to_sx_status(utils_err);
            SX_LOG_ERR("Failed to tunnel[0x%08x] init reference, err = %s\n",
                       tunnel_id, sx_status_str(err));
            tunnel_rb = TRUE;
            rb_err = err;
            goto out;
        }
        tunnel_map_item->pending_delete = FALSE;

        err = sdk_tunnel_db_ref_increase(tunnel_id, &tunnel_map_ref_name_data, &(tunnel_map_item->tunnel_ref));
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to tunnel[0x%08x] increase reference, err = %s\n",
                       tunnel_id, sx_status_str(err));
            mapper_rb = TRUE;
            rb_err = err;
            goto out;
        }

        tunnel_entry_p->data.entry_count++;
    }

out:
    if (tunnel_rb || mapper_rb || pool_rb) {
        for (j = 0; j < i; ++j) {
            cl_fmap_remove(&tunnel_entry_p->data.tunnel_vni_map, &map_entry_p[j]);
            map_item = cl_fmap_remove(&tunnel_entry_p->data.tunnel_fid_map, &map_entry_p[j]);
            utils_err = bit_vector_clear(tunnel_entry_p->data.vni_to_fid_vector,
                                         map_entry_p[j].params.nve.vni);
            if (SX_UTILS_STATUS_SUCCESS != utils_err) {
                SX_LOG_ERR("Failed to clear bit %u in VNI to FID bit vector rollback, err = [%s]\n",
                           tunnel_map_item->map_entry.params.nve.vni, SX_UTILS_STATUS_MSG(utils_err));
                err = sx_utils_status_to_sx_status(utils_err);
                SX_LOG_EXIT();
                return err;
            }
            tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);

            err = sdk_tunnel_db_ref_decrease(tunnel_id, &(tunnel_map_item->tunnel_ref));
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to tunnel[0x%08x] decrease reference, err = %s\n",
                           tunnel_id, sx_status_str(err));
                SX_LOG_EXIT();
                return err;
            }

            utils_err = sdk_refcount_deinit(&tunnel_map_item->ref_count, FALSE);
            if (SX_UTILS_STATUS_SUCCESS != utils_err) {
                SX_LOG_ERR("Failed to deinit map entry refcount for tunnel[0x%08x], utils_err = %s\n",
                           tunnel_id, SX_UTILS_STATUS_MSG(utils_err));
                err = sx_utils_status_to_sx_status(utils_err);
                SX_LOG_EXIT();
                return err;
            }

            tunnel_map_item->map_entry.type = 0;
            tunnel_map_item->map_entry.params.nve.bridge_id = 0;
            tunnel_map_item->map_entry.params.nve.vni = 0;
            cl_qpool_put(&tunnel_mapper_pool, &tunnel_map_item->pool_item);
            tunnel_entry_p->data.entry_count--;
        }
        if (tunnel_rb || mapper_rb) {
            cl_fmap_remove(&tunnel_entry_p->data.tunnel_vni_map, &map_entry_p[j]);
            map_item = cl_fmap_remove(&tunnel_entry_p->data.tunnel_fid_map, &map_entry_p[j]);
            utils_err = bit_vector_clear(tunnel_entry_p->data.vni_to_fid_vector,
                                         map_entry_p[j].params.nve.vni);
            if (SX_UTILS_STATUS_SUCCESS != utils_err) {
                SX_LOG_ERR("Failed to clear bit %u in VNI to FID bit vector, err = [%s]\n",
                           tunnel_map_item->map_entry.params.nve.vni, SX_UTILS_STATUS_MSG(utils_err));
                err = sx_utils_status_to_sx_status(utils_err);
                SX_LOG_EXIT();
                return err;
            }
            tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);
            tunnel_map_item->map_entry.type = 0;
            tunnel_map_item->map_entry.params.nve.bridge_id = 0;
            tunnel_map_item->map_entry.params.nve.vni = 0;
            cl_qpool_put(&tunnel_mapper_pool, &tunnel_map_item->pool_item);

            if (mapper_rb) {
                utils_err = sdk_refcount_deinit(&tunnel_map_item->ref_count, FALSE);
                if (SX_UTILS_STATUS_SUCCESS != utils_err) {
                    SX_LOG_ERR("Failed to deinit map entry refcount for tunnel[0x%08x], utils_err = %s\n",
                               tunnel_id, SX_UTILS_STATUS_MSG(utils_err));
                    err = sx_utils_status_to_sx_status(utils_err);
                    SX_LOG_EXIT();
                    return err;
                }
            }
        }
        SX_LOG_EXIT();
        return rb_err;
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_mapping_check_if_can_deleted(const sx_tunnel_id_t         tunnel_id,
                                                              const sx_tunnel_map_entry_t *map_entry_p,
                                                              const uint32_t               map_entry_cnt)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    uint32_t               i = 0;
    cl_fmap_item_t        *map_item = NULL;
    const cl_fmap_item_t  *map_end = NULL;
    tunnel_mapping_item_t *tunnel_map_item = NULL;
    int32_t                count_val = 0;

    SX_LOG_ENTER();

    if (utils_check_pointer(map_entry_p, "map_entry_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (map_entry_cnt == 0) {
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    if (tunnel_entry_p->data.entry_count < map_entry_cnt) {
        SX_LOG_ERR("trying to delete more entries(%x) then there is (%u)\n",
                   map_entry_cnt,
                   tunnel_entry_p->data.entry_count);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    map_end = cl_fmap_end(&tunnel_entry_p->data.tunnel_fid_map);
    for (i = 0; i < map_entry_cnt; ++i) {
        map_item = cl_fmap_get(&tunnel_entry_p->data.tunnel_fid_map, &map_entry_p[i]);
        if (map_item == map_end) {
            SX_LOG_ERR("didn't find the entry in the tunnel entries map so it cannot be removed\n");
            err = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);

        utils_err = sdk_refcount_get(&tunnel_map_item->ref_count, &count_val);
        if (SX_UTILS_STATUS_SUCCESS != utils_err) {
            SX_LOG_ERR("Failed to get val of tunnel[0x%08x] map entry refcount, err = %s\n",
                       tunnel_id, SX_UTILS_STATUS_MSG(utils_err));
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }

        if (count_val != 0) {
            SX_LOG_ERR("ref_count of entry is not 0 cannot be removed key:type %u , vni = %u bridge = %u \n",
                       tunnel_map_item->map_entry.type,
                       tunnel_map_item->map_entry.params.nve.vni,
                       tunnel_map_item->map_entry.params.nve.bridge_id);
            err = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }

        /* Check if mapping is not referenced in Lazy Delete mode off */
        if ((tunnel_map_item->decap_flow_counter_id != SX_FLOW_COUNTER_ID_INVALID) ||
            (tunnel_map_item->encap_uc_flow_counter_id != SX_FLOW_COUNTER_ID_INVALID) ||
            (tunnel_map_item->encap_mc_flow_counter_id != SX_FLOW_COUNTER_ID_INVALID)) {
            err = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_mapping_delete(const sx_tunnel_id_t         tunnel_id,
                                                const sx_tunnel_map_entry_t *map_entry_p,
                                                const uint32_t               map_entry_cnt)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_status_t            rb_err = SX_STATUS_SUCCESS;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    uint32_t               i = 0, j = 0;
    cl_fmap_item_t        *map_item = NULL;
    tunnel_mapping_item_t *tunnel_map_item = NULL;
    cl_pool_item_t        *pool_item = NULL;
    boolean_t              tunnel_rb = FALSE, mapper_rb = FALSE;
    boolean_t              is_forced = FALSE;
    ref_name_data_t        tunnel_map_ref_name_data = {.print_func_p = get_tunnel_map_ref_name,
                                                       .ref_data_p = NULL,
                                                       .data_size = 0};
    ref_delete_data_t      tunnel_map_ref_delete_data = {.delete_func_p = NULL,
                                                         .id = DELETE_ID_INVALID};

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel hwi DB mapping delete\n");

    if (utils_check_pointer(map_entry_p, "map_entry_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (map_entry_cnt == 0) {
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    if (tunnel_entry_p->data.entry_count < map_entry_cnt) {
        SX_LOG_ERR("trying to delete more entries(%x) then there is (%u)\n",
                   map_entry_cnt,
                   tunnel_entry_p->data.entry_count);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = sdk_tunnel_check_terminated();
    if (err == SX_STATUS_SUCCESS) {
        is_forced = TRUE;
    }

    for (i = 0; i < map_entry_cnt; ++i) {
        map_item = cl_fmap_get(&tunnel_entry_p->data.tunnel_fid_map, &map_entry_p[i]);
        tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);

        utils_err = sdk_refcount_deinit(&tunnel_map_item->ref_count, is_forced);
        if (SX_UTILS_STATUS_SUCCESS != utils_err) {
            SX_LOG_ERR("Failed to deinit map entry refcount for tunnel[0x%08x], utils_err = %s\n",
                       tunnel_id, SX_UTILS_STATUS_MSG(utils_err));
            err = sx_utils_status_to_sx_status(utils_err);
            mapper_rb = TRUE;
            rb_err = err;
            goto out;
        }
        cl_fmap_remove(&tunnel_entry_p->data.tunnel_vni_map, &map_entry_p[i]);
        map_item = cl_fmap_remove(&tunnel_entry_p->data.tunnel_fid_map, &map_entry_p[i]);
        utils_err = bit_vector_clear(tunnel_entry_p->data.vni_to_fid_vector,
                                     map_entry_p[j].params.nve.vni);
        if (SX_UTILS_STATUS_SUCCESS != utils_err) {
            SX_LOG_ERR("Failed to clear VNI to FID vector for VNI[%u], utils_err = %s\n",
                       map_entry_p[j].params.nve.vni, SX_UTILS_STATUS_MSG(utils_err));
            err = sx_utils_status_to_sx_status(utils_err);
            tunnel_rb = TRUE;
            rb_err = err;
            goto out;
        }

        err = sdk_tunnel_db_ref_decrease(tunnel_id, &(tunnel_map_item->tunnel_ref));
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to tunnel[0x%08x] decrease reference, err = %s\n",
                       tunnel_id, sx_status_str(err));
            tunnel_rb = TRUE;
            rb_err = err;
            goto out;
        }

        tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);
        tunnel_map_item->map_entry.type = 0;
        tunnel_map_item->map_entry.params.nve.bridge_id = 0;
        tunnel_map_item->map_entry.params.nve.vni = 0;
        cl_qpool_put(&tunnel_mapper_pool, &tunnel_map_item->pool_item);

        tunnel_entry_p->data.entry_count--;
    }


out:
    if (tunnel_rb || mapper_rb) {
        for (j = 0; j <= i; ++j) {
            pool_item = cl_qpool_get(&tunnel_mapper_pool);
            if (pool_item == NULL) {
                SX_LOG(SX_LOG_ERROR,
                       "Could not find free map_entry in tunnel_db rollback sdk_tunnel_db_tunnel_mapping_delete .\n");
                SX_LOG_EXIT();
                return err;
            }

            tunnel_map_item = PARENT_STRUCT(pool_item, tunnel_mapping_item_t, pool_item);
            SX_MEM_CPY_P(&tunnel_map_item->map_entry, &map_entry_p[j]);
            cl_fmap_insert(&(tunnel_entry_p->data.tunnel_fid_map),
                           &tunnel_map_item->map_entry, &tunnel_map_item->fid_map_item);
            cl_fmap_insert(&(tunnel_entry_p->data.tunnel_vni_map),
                           &tunnel_map_item->map_entry, &tunnel_map_item->vni_map_item);
            utils_err = bit_vector_set(tunnel_entry_p->data.vni_to_fid_vector,
                                       map_entry_p[j].params.nve.vni);
            if (SX_UTILS_STATUS_SUCCESS != utils_err) {
                SX_LOG_ERR("Failed to set VNI %u to FID vector rollback, err = %s\n",
                           map_entry_p[j].params.nve.vni, SX_UTILS_STATUS_MSG(utils_err));
                SX_LOG_EXIT();
                return err;
            }

            tunnel_map_ref_name_data.ref_data_p = &tunnel_map_item->map_entry.params.nve.bridge_id;
            tunnel_map_ref_name_data.data_size = sizeof(tunnel_map_item->map_entry.params.nve.bridge_id);
            tunnel_map_ref_delete_data.delete_func_p = g_nve_tunnel_mapping_delete_func_cb;
            __tunnel_mapping_to_uin64_t(tunnel_id, tunnel_map_item->map_entry.params.nve.bridge_id,
                                        &tunnel_map_ref_delete_data.id);
            utils_err = sdk_refcount_init(&tunnel_map_item->ref_count,
                                          &tunnel_map_ref_name_data,
                                          &tunnel_map_ref_delete_data);
            if (SX_UTILS_STATUS_SUCCESS != utils_err) {
                SX_LOG_ERR("Failed to tunnel[0x%08x] increase reference rollback, err = %s\n",
                           tunnel_id, SX_UTILS_STATUS_MSG(utils_err));
                err = sx_utils_status_to_sx_status(utils_err);
                SX_LOG_EXIT();
                return err;
            }

            err = sdk_tunnel_db_ref_increase(tunnel_id, &tunnel_map_ref_name_data, &(tunnel_map_item->tunnel_ref));
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to tunnel[0x%08x] increase reference rollback, err = %s\n",
                           tunnel_id, sx_status_str(err));
                SX_LOG_EXIT();
                return err;
            }
            tunnel_entry_p->data.entry_count++;
        }
        if (tunnel_rb) {
            map_item = cl_fmap_get(&tunnel_entry_p->data.tunnel_fid_map, &map_entry_p[i]);
            tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);

            tunnel_map_ref_name_data.ref_data_p = &tunnel_map_item->map_entry.params.nve.bridge_id;
            tunnel_map_ref_name_data.data_size = sizeof(tunnel_map_item->map_entry.params.nve.bridge_id);
            tunnel_map_ref_delete_data.delete_func_p = g_nve_tunnel_mapping_delete_func_cb;
            __tunnel_mapping_to_uin64_t(tunnel_id, tunnel_map_item->map_entry.params.nve.bridge_id,
                                        &tunnel_map_ref_delete_data.id);
            utils_err = sdk_refcount_init(&tunnel_map_item->ref_count,
                                          &tunnel_map_ref_name_data,
                                          &tunnel_map_ref_delete_data);
            if (SX_UTILS_STATUS_SUCCESS != utils_err) {
                SX_LOG_ERR("Failed to tunnel[0x%08x] increase reference rollback, err = %s\n",
                           tunnel_id, SX_UTILS_STATUS_MSG(utils_err));
                err = sx_utils_status_to_sx_status(utils_err);
                SX_LOG_EXIT();
                return err;
            }
        }
        SX_LOG_EXIT();
        return rb_err;
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_mapping_delete_all(const sx_tunnel_id_t tunnel_id, boolean_t is_forced)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    uint32_t               map_entry_count = 0;
    uint32_t               i = 0;
    sx_port_log_id_t       log_port = 0;
    sx_tunnel_map_entry_t *map_entry_p;
    boolean_t              allc_mem = FALSE;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel hwi DB mapping delete all\n");
    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }
    if (tunnel_entry_p->data.entry_count == 0) {
        err = SX_STATUS_SUCCESS;
        /* No entries to delete */
        goto out;
    }

    err = sdk_tunnel_db_map_entries_list_get(tunnel_id, NULL, &map_entry_count, is_forced);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get count of map list from tunnel[0x%08x] , err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = utils_memory_get((void**)&map_entry_p, map_entry_count * sizeof(sx_tunnel_map_entry_t),
                           UTILS_MEM_TYPE_ID_TUNNEL_E);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to allocate memory for map_entry_list , err = %s\n", sx_status_str(err));
        goto out;
    }
    allc_mem = TRUE;
    err = sdk_tunnel_db_map_entries_list_get(tunnel_id, map_entry_p, &map_entry_count, is_forced);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get map list from tunnel[0x%08x] , err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    /* Get log port from tunnel id */
    err = sdk_tunnel_impl_log_port_by_tunnel_id_get(tunnel_id, &log_port);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get log_port for tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < map_entry_count; ++i) {
        /* Flush ageable FDB entries */
        err = fdb_flush_ageable_tunnel_mapping_macs_set(log_port, map_entry_p[i].params.nve.bridge_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to flush FDB by log_port[%u] for tunnel[0x%08x], err = %s\n",
                       log_port, tunnel_id, sx_status_str(err));
            goto out;
        }
    }

    err = sdk_tunnel_db_tunnel_mapping_delete(tunnel_id, map_entry_p, map_entry_count);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to delete, in tunnel DB , from tunnel[0x%08x] -- all map entries, err = %s\n",
                   tunnel_id,
                   sx_status_str(err));
    }

out:
    if (allc_mem) {
        if (utils_memory_put(map_entry_p, UTILS_MEM_TYPE_ID_TUNNEL_E)) {
            SX_LOG_ERR("Failed to free map list from tunnel[0x%08x] \n", tunnel_id);
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_mapping_get_first(const sx_tunnel_id_t   tunnel_id,
                                                   sx_tunnel_map_entry_t *map_entry_p,
                                                   uint32_t              *map_entry_cnt)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    cl_fmap_item_t        *map_item = NULL;
    const cl_fmap_item_t  *map_end = NULL;
    tunnel_mapping_item_t *tunnel_map_item = NULL;
    uint32_t               i = 0, j = 0;


    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel hwi DB mapping get first\n");

    if (utils_check_pointer(map_entry_p, "map_entry_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(map_entry_cnt, "map_entry_cnt")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (*map_entry_cnt == 0) {
        SX_LOG_ERR("number of entries to get is 0\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    map_item = cl_fmap_head(&tunnel_entry_p->data.tunnel_fid_map);
    map_end = cl_fmap_end(&tunnel_entry_p->data.tunnel_fid_map);
    for (i = 0; i < *map_entry_cnt; ++i) {
        if (map_item == map_end) {
            break;
        }
        tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);
        map_item = cl_fmap_next(map_item);
        if (tunnel_map_item->pending_delete == FALSE) {
            SX_MEM_CPY_P(&map_entry_p[i], &tunnel_map_item->map_entry);
            j++;
        }
    }
    *map_entry_cnt = j;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_tunnel_mapping_get_next(const sx_tunnel_id_t   tunnel_id,
                                                  sx_tunnel_map_entry_t  map_entry_key,
                                                  sx_tunnel_map_entry_t *map_entry_p,
                                                  uint32_t              *map_entry_cnt)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    cl_fmap_item_t        *map_item = NULL;
    const cl_fmap_item_t  *map_end = NULL;
    tunnel_mapping_item_t *tunnel_map_item = NULL;
    uint32_t               i = 0, j = 0;


    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel hwi DB mapping get next\n");

    if (utils_check_pointer(map_entry_p, "map_entry_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(map_entry_cnt, "map_entry_cnt")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (*map_entry_cnt == 0) {
        SX_LOG_ERR("number of entries to get is 0\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    map_item = cl_fmap_get_next(&tunnel_entry_p->data.tunnel_fid_map, &map_entry_key);
    map_end = cl_fmap_end(&tunnel_entry_p->data.tunnel_fid_map);
    for (i = 0; i < *map_entry_cnt; ++i) {
        if (map_item == map_end) {
            break;
        }
        tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);
        map_item = cl_fmap_next(map_item);
        if (tunnel_map_item->pending_delete == FALSE) {
            SX_MEM_CPY_P(&map_entry_p[i], &tunnel_map_item->map_entry);
            j++;
        }
    }
    *map_entry_cnt = j;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_map_entries_list_get(const sx_tunnel_id_t   tunnel_id,
                                               sx_tunnel_map_entry_t *map_entry_p,
                                               uint32_t              *map_entry_cnt,
                                               boolean_t              ignore_pending_delete)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sdk_db_tunnel_entry_t *tunnel_entry_p = NULL;
    cl_fmap_item_t        *map_item = NULL;
    const cl_fmap_item_t  *map_end = NULL;
    uint32_t               cnt = 0;
    tunnel_mapping_item_t *tunnel_map_item = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel hwi DB mapping get map entry list\n");


    if (utils_check_pointer(map_entry_cnt, "map_entry_cnt")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __get_tunnel_map_entry(tunnel_id, &tunnel_entry_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get Tunnel[0x%08x] entry -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    map_item = cl_fmap_head(&tunnel_entry_p->data.tunnel_fid_map);
    map_end = cl_fmap_end(&tunnel_entry_p->data.tunnel_fid_map);
    while (map_item != map_end) {
        tunnel_map_item = PARENT_STRUCT(map_item, tunnel_mapping_item_t, fid_map_item);
        if (ignore_pending_delete == TRUE) {
            if (map_entry_p != NULL) {
                SX_MEM_CPY_P(&map_entry_p[cnt], &tunnel_map_item->map_entry);
            }
            cnt++;
        } else {
            if (tunnel_map_item->pending_delete == FALSE) {
                if (map_entry_p != NULL) {
                    SX_MEM_CPY_P(&map_entry_p[cnt], &tunnel_map_item->map_entry);
                }
                cnt++;
            }
        }
        map_item = cl_fmap_next(map_item);
    }
    *map_entry_cnt = cnt;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_mapping_unbind_flow_counters(sx_tunnel_id_t tunnel_id, sx_fid_t fid)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    tunnel_mapping_item_t *tunnel_map_item_p = NULL;

    /* Get tunnel map item to access flow counters id */
    err = __sdk_tunnel_db_mapping_item_get_by_fid(tunnel_id, fid, &tunnel_map_item_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("failed to get Tunnel[0x%08x] map entry item -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    /* Go through all 3 flow counters (decap, encap_uc, encap_mc) */
    if (tunnel_map_item_p->decap_flow_counter_id != SX_FLOW_COUNTER_ID_INVALID) {
        /* Decrease refcount of decap flow counter and invalidate it */
        err = flow_counter_ref_dec(tunnel_map_item_p->decap_flow_counter_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to decrement reference for counter(%u), err = %s\n",
                       tunnel_map_item_p->decap_flow_counter_id, sx_status_str(err));
            goto out;
        }

        err = __tunnel_mapping_counters_list_remove(tunnel_map_item_p,
                                                    SX_BRIDGE_COUNTER_TUNNEL_DECAP_E,
                                                    tunnel_map_item_p->decap_flow_counter_id);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR(
                "Failed to internally unbind decap counter [%u] from the counters list for tunnel[0x%08x] fid[0x%08x], err = %s\n",
                tunnel_map_item_p->decap_flow_counter_id,
                tunnel_id,
                fid,
                sx_status_str(err));
            goto out;
        }

        tunnel_map_item_p->decap_flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;
    }

    if (tunnel_map_item_p->encap_uc_flow_counter_id != SX_FLOW_COUNTER_ID_INVALID) {
        /* Decrease refcount of encap UC flow counter and invalidate it */
        err = flow_counter_ref_dec(tunnel_map_item_p->encap_uc_flow_counter_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to decrement reference for counter(%u), err = %s\n",
                       tunnel_map_item_p->encap_uc_flow_counter_id, sx_status_str(err));
            goto out;
        }

        err = __tunnel_mapping_counters_list_remove(tunnel_map_item_p,
                                                    SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E,
                                                    tunnel_map_item_p->encap_uc_flow_counter_id);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR(
                "Failed to internally unbind encap UC counter [%u] from the counters list for tunnel[0x%08x] fid[0x%08x], err = %s\n",
                tunnel_map_item_p->encap_uc_flow_counter_id,
                tunnel_id,
                fid,
                sx_status_str(err));
            goto out;
        }

        tunnel_map_item_p->encap_uc_flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;
    }

    if (tunnel_map_item_p->encap_mc_flow_counter_id != SX_FLOW_COUNTER_ID_INVALID) {
        /* Decrease refcount of encap MC flow counter and invalidate it */
        err = flow_counter_ref_dec(tunnel_map_item_p->encap_mc_flow_counter_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to decrement reference for counter(%u), err = %s\n",
                       tunnel_map_item_p->encap_mc_flow_counter_id, sx_status_str(err));
            goto out;
        }

        err = __tunnel_mapping_counters_list_remove(tunnel_map_item_p,
                                                    SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E,
                                                    tunnel_map_item_p->encap_mc_flow_counter_id);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR(
                "Failed to internally unbind encap MC counter [%u] from the counters list for tunnel[0x%08x] fid[0x%08x], err = %s\n",
                tunnel_map_item_p->encap_mc_flow_counter_id,
                tunnel_id,
                fid,
                sx_status_str(err));
            goto out;
        }

        tunnel_map_item_p->encap_mc_flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_mapping_get_by_fid(sx_tunnel_id_t tunnel_id, sx_fid_t fid, sx_tunnel_map_entry_t *map_entry)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    tunnel_mapping_item_t *tunnel_map_item_p = NULL;

    if (utils_check_pointer(map_entry, "map_entry")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __sdk_tunnel_db_mapping_item_get_by_fid(tunnel_id, fid, &tunnel_map_item_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("failed to get Tunnel[0x%08x] map entry item by fid -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(map_entry, &tunnel_map_item_p->map_entry);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_mapping_get_by_vni(sx_tunnel_id_t         tunnel_id,
                                             sx_tunnel_vni_t        vni,
                                             sx_tunnel_map_entry_t *map_entry)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    tunnel_mapping_item_t *tunnel_map_item_p = NULL;

    if (utils_check_pointer(map_entry, "map_entry")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __sdk_tunnel_db_mapping_item_get_by_vni(tunnel_id, vni, &tunnel_map_item_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("failed to get Tunnel[0x%08x] map entry item by vni -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(map_entry, &tunnel_map_item_p->map_entry);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_mapping_ref_cnt_get(const sx_tunnel_id_t tunnel_id,
                                              const sx_fid_t       fid,
                                              uint32_t            *refcount_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    tunnel_mapping_item_t *tunnel_map_item_p = NULL;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(refcount_p, "refcount_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __sdk_tunnel_db_mapping_item_get_by_fid(tunnel_id, fid, &tunnel_map_item_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("failed to get Tunnel[0x%08x] map entry item -- err = %s \n", tunnel_id, sx_status_str(err));
        goto out;
    }

    if (tunnel_map_item_p->pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to get a ref counter of map entry for tunnel[0x%08x] and fid[%u], err = %s\n",
                   tunnel_id, fid, sx_status_str(err));
        goto out;
    }

    utils_err = sdk_refcount_get(&tunnel_map_item_p->ref_count, (int32_t*)refcount_p);
    if (SX_UTILS_STATUS_SUCCESS != utils_err) {
        SX_LOG_ERR("Failed getting tunnel[0x%08x] map refcount value, utils_err = %s\n",
                   tunnel_id, SX_UTILS_STATUS_MSG(utils_err));

        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_mapping_ref_cnt_increase(const sx_tunnel_id_t tunnel_id,
                                                   const sx_fid_t       fid,
                                                   ref_name_data_t     *ref_name_data,
                                                   sdk_ref_t           *ref_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;
    tunnel_mapping_item_t *tunnel_map_item_p = NULL;

    SX_LOG_ENTER();

    if (utils_check_pointer(ref_name_data, "ref_name_data")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(ref_p, "ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __sdk_tunnel_db_mapping_item_get_by_fid(tunnel_id, fid, &tunnel_map_item_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get map entry from tunnel[0x%08x] with fid [%u], err = %s\n",
                   tunnel_id, fid, SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    if (tunnel_map_item_p->pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to increase a ref counter of map entry for tunnel[0x%08x] and fid[%u], err = %s\n",
                   tunnel_id, fid, sx_status_str(err));
        goto out;
    }

    utils_err = sdk_refcount_inc(&(tunnel_map_item_p->ref_count), ref_name_data, ref_p);
    if (SX_UTILS_STATUS_SUCCESS != utils_err) {
        SX_LOG_ERR("Failed increase tunnel[0x%08x] map entry refcount, err = %s\n",
                   tunnel_id, SX_UTILS_STATUS_MSG(utils_err));
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_mapping_ref_cnt_decrease(const sx_tunnel_id_t tunnel_id,
                                                   const sx_fid_t       fid,
                                                   const sdk_ref_t     *ref_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_utils_status_t      utils_err = SX_UTILS_STATUS_SUCCESS;
    tunnel_mapping_item_t *tunnel_map_item_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Decrease Tunnel[0x%08x] map entry reference counter with fid [%u] \n", tunnel_id, fid);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(ref_p, "ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __sdk_tunnel_db_mapping_item_get_by_fid(tunnel_id, fid, &tunnel_map_item_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get map entry from tunnel[0x%08x] with fid [%u], err = %s\n",
                   tunnel_id, fid, SX_UTILS_STATUS_MSG(err));
        goto out;
    }

    utils_err = sdk_refcount_dec(&(tunnel_map_item_p->ref_count), ref_p);
    if (SX_UTILS_STATUS_SUCCESS != utils_err) {
        SX_LOG_ERR("Failed decreasing tunnel[0x%08x] map entry refcount with fid [%u], err = %s\n",
                   tunnel_id, fid, SX_UTILS_STATUS_MSG(utils_err));
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tunnel_db_vrid_to_default_rif_mapping_add(sx_router_id_t vrid, sx_router_interface_t rif)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    cl_pool_item_t                        *pool_item_p = NULL;
    tunnel_vrid_to_default_rif_map_item_t *tunnel_vrid_to_default_rif_map_item_p = NULL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Add vrid to default rif map item\n");

    /*new element needs to be created*/
    pool_item_p =
        cl_qpool_get(&vrid_to_default_rif_pool);
    if (!pool_item_p) {
        SX_LOG(SX_LOG_ERROR, "Could not find free map_entry in vrid_to_default_rif db.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    tunnel_vrid_to_default_rif_map_item_p = SX_CL_QPOOL_PARENT_STRUCT(tunnel_vrid_to_default_rif_map_item_t);
    cl_qmap_insert(&vrid_to_default_rif_map, vrid, &tunnel_vrid_to_default_rif_map_item_p->map_item);
    tunnel_vrid_to_default_rif_map_item_p->rif = rif;
    tunnel_vrid_to_default_rif_map_item_p->vrid = vrid;


out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_vrid_to_default_rif_mapping_get(sx_router_id_t vrid, sx_router_interface_t *rif_p)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    tunnel_vrid_to_default_rif_map_item_t *tunnel_vrid_to_default_rif_map_item_p = NULL;
    cl_map_item_t                         *map_item_p = NULL;

    *rif_p = 0;

    map_item_p = cl_qmap_get(&vrid_to_default_rif_map, vrid);

    if (cl_qmap_end(&vrid_to_default_rif_map) != map_item_p) {
        tunnel_vrid_to_default_rif_map_item_p = SX_CL_QMAP_PARENT_STRUCT(tunnel_vrid_to_default_rif_map_item_t);
        *rif_p = tunnel_vrid_to_default_rif_map_item_p->rif;
    } else {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_db_vrid_to_default_rif_mapping_delete(sx_router_id_t vrid)
{
    sx_status_t                            err = SX_STATUS_SUCCESS;
    tunnel_vrid_to_default_rif_map_item_t *tunnel_vrid_to_default_rif_map_item_p = NULL;
    cl_map_item_t                         *map_item_p = NULL;

    map_item_p = cl_qmap_get(&vrid_to_default_rif_map, vrid);

    if (cl_qmap_end(&vrid_to_default_rif_map) != map_item_p) {
        tunnel_vrid_to_default_rif_map_item_p = SX_CL_QMAP_PARENT_STRUCT(tunnel_vrid_to_default_rif_map_item_t);
        cl_qmap_remove(&vrid_to_default_rif_map, vrid);
        cl_qpool_put(&vrid_to_default_rif_pool,
                     &tunnel_vrid_to_default_rif_map_item_p->pool_item);
    } else {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static inline sx_status_t __sdk_tunnel_db_filter_check_range(const sx_tunnel_filter_t *filter_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (filter_p != NULL) {
        if ((filter_p->filter_by_type == SX_TUNNEL_KEY_FILTER_FIELD_VALID) &&
            (!SX_TUNNEL_TYPE_CHECK_RANGE(filter_p->type))) {
            SX_LOG_ERR("Invalid filter type %d .\n", filter_p->type);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if ((filter_p->filter_by_direction == SX_TUNNEL_KEY_FILTER_FIELD_VALID) &&
            (!SX_TUNNEL_DIRECTION_CHECK_RANGE(filter_p->direction))) {
            SX_LOG_ERR("Invalid filter direction %d .\n", filter_p->direction);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    return err;
}

static inline sx_status_t __sdk_tunnel_db_filter_check_match(const sx_tunnel_filter_t    *filter_p,
                                                             const sdk_db_tunnel_entry_t *tunnel_db_entry_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (filter_p != NULL) {
        if ((filter_p->filter_by_type == SX_TUNNEL_KEY_FILTER_FIELD_VALID) &&
            (tunnel_db_entry_p->data.tun_attr.type != filter_p->type)) {
            err = SX_STATUS_ERROR;
            goto out;
        }
        /* If tunnel is symmetric, then it's encap and decap, so can be matched by any direction filter */
        /* Otherwise, it can only match the same filter */
        if ((filter_p->filter_by_direction == SX_TUNNEL_KEY_FILTER_FIELD_VALID) &&
            (tunnel_db_entry_p->data.tun_attr.direction != SX_TUNNEL_DIRECTION_SYMMETRIC) &&
            (tunnel_db_entry_p->data.tun_attr.direction != filter_p->direction)) {
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

out:
    return err;
}

sx_status_t sdk_tunnel_db_iter_get(const sx_access_cmd_t     cmd,
                                   const sx_tunnel_id_t      tunnel_id,
                                   const sx_tunnel_filter_t *filter_p,
                                   sx_tunnel_id_t           *tunnel_id_list_p,
                                   uint32_t                 *tunnel_id_cnt_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    cl_map_item_t         *map_item_p = NULL;
    const cl_map_item_t   *map_end_p = NULL;
    sdk_db_tunnel_entry_t *tunnel_db_entry_p = NULL;
    uint32_t               tunnel_identifier = 0;
    sx_tunnel_id_t         new_tunnel_id = 0;
    uint32_t               tunnel_cnt = 0;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_id_cnt_p, "tunnel_id_cnt_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (*tunnel_id_cnt_p == 0) {
        if (cmd != SX_ACCESS_CMD_GET) {
            goto out;
        }
    } else {
        if (utils_check_pointer(tunnel_id_list_p, "tunnel_id_list_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*tunnel_id_cnt_p > 0) {
            err = __get_tunnel_map_entry(tunnel_id, &tunnel_db_entry_p);
            if (SX_STATUS_ENTRY_NOT_FOUND == err) {
                err = SX_STATUS_SUCCESS;
                *tunnel_id_cnt_p = 0;
                goto out;
            }
            if (SX_STATUS_SUCCESS != err) {
                goto out;
            }
            if (tunnel_db_entry_p->data.pending_delete) {
                *tunnel_id_cnt_p = 0;
                goto out;
            }
            err = __sdk_tunnel_db_filter_check_range(filter_p);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Invalid filter .\n");
                goto out;
            }
            err = __sdk_tunnel_db_filter_check_match(filter_p, tunnel_db_entry_p);
            if (SX_STATUS_SUCCESS == err) {
                *tunnel_id_cnt_p = 1;
                tunnel_id_list_p[0] = tunnel_id;
            } else {
                err = SX_STATUS_SUCCESS;
                *tunnel_id_cnt_p = 0;
            }
            goto out;
        } else {
            if ((filter_p == NULL) ||
                ((filter_p->filter_by_type == SX_TUNNEL_KEY_FILTER_FIELD_NOT_VALID) &&
                 (filter_p->filter_by_direction == SX_TUNNEL_KEY_FILTER_FIELD_NOT_VALID))) {
                *tunnel_id_cnt_p = cl_qmap_count(&tunnel_map);
                goto out;
            }
            map_item_p = cl_qmap_head(&tunnel_map);
        }

        break;

    case SX_ACCESS_CMD_GET_FIRST:
        map_item_p = cl_qmap_head(&tunnel_map);
        break;

    case SX_ACCESS_CMD_GETNEXT:
        err = __get_tunnel_map_entry(tunnel_id, &tunnel_db_entry_p);
        if (SX_STATUS_ENTRY_NOT_FOUND == err) {
            err = SX_STATUS_SUCCESS;
            *tunnel_id_cnt_p = 0;
            goto out;
        }
        if (SX_STATUS_SUCCESS != err) {
            goto out;
        }
        if (tunnel_db_entry_p->data.pending_delete) {
            *tunnel_id_cnt_p = 0;
            goto out;
        }
        tunnel_identifier = SX_TUNNEL_IDENTIFIER_GET(tunnel_id);
        map_item_p = cl_qmap_get_next(&tunnel_map, tunnel_identifier);
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported cmd %s.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    err = __sdk_tunnel_db_filter_check_range(filter_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Invalid filter .\n");
        goto out;
    }
    map_end_p = cl_qmap_end(&tunnel_map);
    while (map_end_p != map_item_p) {
        tunnel_db_entry_p = PARENT_STRUCT(map_item_p, sdk_db_tunnel_entry_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        if (tunnel_db_entry_p->data.pending_delete) {
            continue;
        }

        err = __sdk_tunnel_db_filter_check_match(filter_p, tunnel_db_entry_p);
        if (SX_STATUS_SUCCESS != err) {
            err = SX_STATUS_SUCCESS;
            continue;
        }

        if (cmd == SX_ACCESS_CMD_GET) {
            tunnel_cnt++;
        } else {
            new_tunnel_id = 0;
            new_tunnel_id = SX_TUNNEL_TYPE_ID_SET(new_tunnel_id, tunnel_db_entry_p->data.tun_attr.type);
            new_tunnel_id = SX_TUNNEL_IDENTIFIER_SET(new_tunnel_id, tunnel_db_entry_p->data.tunnel_identifier);
            new_tunnel_id = SX_TUNNEL_DIRECTION_SET(new_tunnel_id, tunnel_db_entry_p->data.tun_attr.direction);
            tunnel_id_list_p[tunnel_cnt] = new_tunnel_id;
            tunnel_cnt++;
            if (tunnel_cnt == *tunnel_id_cnt_p) {
                break;
            }
        }
    }

    *tunnel_id_cnt_p = tunnel_cnt;

out:
    SX_LOG_EXIT();
    return err;
}

/* Get the tunnel flex header information from the DB. */
sx_status_t sdk_tunnel_db_tunnel_flex_header_get(const sx_tunnel_flex_header_id_t tunnel_flex_header_id,
                                                 tunnel_flex_header_entry_t     **tunnel_flex_header_entry_pp)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (tunnel_flex_header_id >= total_flex_header_cnt) {
        SX_LOG_ERR("Invalid value tunnel flex header [%u] get.\n", tunnel_flex_header_id);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (flex_header_entries[tunnel_flex_header_id].allocated != TRUE) {
        SX_LOG_ERR("Flex tunnel header [%u] was not created.\n", tunnel_flex_header_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (tunnel_flex_header_entry_pp != NULL) {
        *tunnel_flex_header_entry_pp = &flex_header_entries[tunnel_flex_header_id];
    }

out:
    SX_LOG_EXIT();
    return err;
}

/* Find an unused flex header  */
sx_status_t sdk_tunnel_db_find_free_tunnel_flex_header(tunnel_flex_header_entry_t **tunnel_flex_header_entry_pp)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_tunnel_flex_header_id_t tunnel_flex_header_id = 0;

    for (tunnel_flex_header_id = 0; tunnel_flex_header_id < total_flex_header_cnt; tunnel_flex_header_id++) {
        if (flex_header_entries[tunnel_flex_header_id].allocated != TRUE) {
            *tunnel_flex_header_entry_pp = &flex_header_entries[tunnel_flex_header_id];
            goto out;
        }
    }

    err = SX_STATUS_NO_RESOURCES;

out:
    SX_LOG_EXIT();
    return err;
}
