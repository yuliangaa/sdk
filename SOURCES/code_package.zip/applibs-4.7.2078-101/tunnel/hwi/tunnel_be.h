/*
 * Copyright (C) 2011-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWI_TUNNEL_BE_H__
#define __HWI_TUNNEL_BE_H__

#include <sx/sdk/sx_types.h>

/************************************************
 *  Local Defines
 ***********************************************/
#define TUNNEL_MAP_GET_MAX_NUM                    1000
#define SX_TUNNEL_IPINIP_DECAP_RULE_USER_PRIO_MIN 1
#define SX_TUNNEL_IPINIP_DECAP_RULE_USER_PRIO_MAX SX_TUNNEL_IPINIP_DECAP_RULE_PRIO_MAX - 2

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t sdk_tunnel_be_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t sdk_tunnel_be_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);
sx_status_t tunnel_impl_vrid_by_tunnel_id_get(const sx_tunnel_id_t tunnel_id,
                                              sx_router_id_t      *vrid_p);

/*
 * Init tunneling module.
 */
sx_status_t sdk_tunnel_init(sx_tunnel_general_params_t * params_p);

/*
 * Deinit tunneling module.
 */
sx_status_t sdk_tunnel_deinit(boolean_t is_forced);

/*
 * Create / delete tunnel.
 */
sx_status_t sdk_tunnel_set(const sx_access_cmd_t   cmd,
                           sx_tunnel_attribute_t * tunnel_attr_p,
                           sx_tunnel_id_t        * tunnel_id_p);
/*
 * Get tunnel attributes for specified tunnel id.
 */
sx_status_t sdk_tunnel_get(const sx_tunnel_id_t    tunnel_id,
                           sx_tunnel_attribute_t * tunnel_attr_p);

sx_status_t sdk_tunnel_counter_get(const sx_access_cmd_t cmd,
                                   const sx_tunnel_id_t  tunnel_id,
                                   sx_tunnel_counter_t  *counter);
/*
 * Generate debug dump for tunneling module.
 */
void sdk_tunnel_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

sx_status_t sdk_tunnel_decap_rules_set(const sx_access_cmd_t               cmd,
                                       const sx_tunnel_decap_entry_key_t  *entry_key,
                                       const sx_tunnel_decap_entry_data_t *entry_data);

sx_status_t sdk_tunnel_decap_rules_get(const sx_tunnel_decap_entry_key_t *entry_key,
                                       sx_tunnel_decap_entry_data_t      *entry_data);
sx_status_t sdk_tunnel_decap_rule_iter_get(const sx_access_cmd_t                 cmd,
                                           const sx_tunnel_decap_entry_key_t     key,
                                           const sx_tunnel_decap_entry_filter_t *filter_p,
                                           sx_tunnel_decap_entry_key_t          *key_list_p,
                                           uint32_t                             *key_cnt_p);
sx_status_t sdk_tunnel_map_set(const sx_access_cmd_t         cmd,
                               const sx_tunnel_id_t          tunnel_id,
                               const sx_tunnel_map_entry_t * map_entries_p,
                               const uint32_t                map_entries_cnt);

sx_status_t sdk_tunnel_map_get(const sx_access_cmd_t  cmd,
                               const sx_tunnel_id_t   tunnel_id,
                               sx_tunnel_map_entry_t  map_entry_key,
                               sx_tunnel_map_entry_t *map_entries_p,
                               uint32_t              *map_entries_cnt);

sx_status_t sdk_tunnel_ttl_set(const sx_tunnel_id_t        tunnel_id,
                               const sx_tunnel_ttl_data_t *ttl_data_p);

sx_status_t sdk_tunnel_ttl_get(const sx_tunnel_id_t  tunnel_id,
                               sx_tunnel_ttl_data_t *ttl_data_p);

sx_status_t sdk_tunnel_hash_set(const sx_tunnel_id_t         tunnel_id,
                                const sx_tunnel_hash_data_t *hash_data_p);

sx_status_t sdk_tunnel_hash_get(const sx_tunnel_id_t   tunnel_id,
                                sx_tunnel_hash_data_t *hash_data_p);

sx_status_t sdk_tunnel_cos_set(const sx_tunnel_id_t        tunnel_id,
                               const sx_tunnel_cos_data_t *cos_data_p);

sx_status_t sdk_tunnel_cos_get(const sx_tunnel_id_t  tunnel_id,
                               sx_tunnel_cos_data_t *cos_data_p);

sx_status_t sdk_tunnel_iter_get(const sx_access_cmd_t     cmd,
                                const sx_tunnel_id_t      tunnel_id,
                                const sx_tunnel_filter_t *filter_p,
                                sx_tunnel_id_t           *tunnel_id_list_p,
                                uint32_t                 *tunnel_id_cnt_p);

sx_status_t sdk_tunnel_object_refcount_get(const sx_object_id_t *object_p, uint32_t *refcount_p);

sx_status_t sdk_tunnel_flex_header_set(const sx_access_cmd_t        cmd,
                                       sx_tunnel_flex_header_cfg_t *header_cfg,
                                       sx_tunnel_flex_header_id_t  *header_id);

sx_status_t sdk_tunnel_flex_header_get(const sx_tunnel_flex_header_id_t header_id,
                                       sx_tunnel_flex_header_cfg_t     *header_cfg);


#endif      /* __HWI_TUNNEL_BE_H__ */
