/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap.h>
#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <complib/cl_mem.h>
#include <utils/utils.h>
#include <sx/sdk/sx_types.h>

#include <ethl3/hwi/sdk_router_vrid/sdk_router_vrid_impl.h>
#include <ethl3/hwi/rif/rif_db.h>
#include <ethl3/hwi/rif/rif_impl.h>
#include <ethl2/fdb.h>
#include <ethl3/hwi/neigh/router_neigh_impl.h>
#include <ethl2/vlan.h>
#include "ethl2/brg.h"
#include "tunnel_impl.h"
#include "decap_table_impl.h"
#include "mc_container/hwi/mc_container_impl.h"
#include "tunnel/hwd/hwd_tunnel.h"
#include "ipv6_mgr_impl.h"
#include "ethl2/fid_manager.h"
#include "ethl3/router_common.h"
#include "host_ifc/host_ifc.h"
#include "ethl2/fdb_igmpv3_impl.h"
#include "flex_modifier/flex_modifier.h"

#undef  __MODULE__
#define __MODULE__ TUNNEL


/************************************************
 *  Global variables
 ***********************************************/
extern rm_resources_t   rm_resource_global;
extern sx_brg_context_t brg_context;

/************************************************
 *  Local defines
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t                g_is_tunnel_initialized = FALSE;
static boolean_t                g_is_tunnel_terminated = FALSE;
static hwd_tunnel_ops_t         g_hwd_tunnel_ops;
static boolean_t                g_hwd_tunnel_ops_init = FALSE;
static sdk_tunnel_init_params_t g_sdk_tunnel_init_params;
static boolean_t                g_tunnel_ops_init = FALSE;
static tunnel_ops_t             g_tunnel_ops;
boolean_t                       g_ld_enabled = TRUE;
sx_fdb_learn_mode_t             g_ld_learn_mode = SX_FDB_LEARN_MODE_DONT_LEARN; /* assume that we have 1 NVE tunnel at a time */
boolean_t                       g_ld_learn_mode_changed = FALSE;
static cntr_client_handle_t     g_cm_handle = NULL;


/* Capabilities that are supported / included per tunnel type */
static const uint64_t g_tunnel_cap_by_type_support[SX_TUNNEL_TYPE_MAX + 1] =
{SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_NEXTHOP_ENCAP_E, /* IPinIP over IPv4 */
 SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_NEXTHOP_ENCAP_E, /* IPinIP over IPv4 with GRE */
 SX_TUNNEL_CAP_ACL_DECAP_E, /* 6in4 */
 SX_TUNNEL_CAP_ACL_DECAP_E, /* 6in4 with GRE */
 SX_TUNNEL_CAP_ACL_DECAP_E, /* 4in6 */
 SX_TUNNEL_CAP_ACL_DECAP_E, /* 4in6 with GRE */
 SX_TUNNEL_CAP_ACL_DECAP_E, /* 6in6 */
 SX_TUNNEL_CAP_ACL_DECAP_E, /* 6in6 with GRE */

 SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_ACL_ENCAP_E | SX_TUNNEL_CAP_FDB_ENCAP_E | SX_TUNNEL_CAP_COUNTER_READ_E |
 SX_TUNNEL_CAP_BRIDGE_DECAP_COUNTER_E | SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E | SX_TUNNEL_CAP_RPF_E |
 SX_TUNNEL_CAP_MC_NVE_DECAP_ERIF_E,  /* VXLAN */

 SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_ACL_ENCAP_E | SX_TUNNEL_CAP_FDB_ENCAP_E | SX_TUNNEL_CAP_COUNTER_READ_E |
 SX_TUNNEL_CAP_BRIDGE_DECAP_COUNTER_E | SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E,  /* VXLAN-GPE */

 SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_ACL_ENCAP_E | SX_TUNNEL_CAP_FDB_ENCAP_E | SX_TUNNEL_CAP_COUNTER_READ_E |
 SX_TUNNEL_CAP_BRIDGE_DECAP_COUNTER_E | SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E,  /* GENEVE */

 SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_ACL_ENCAP_E | SX_TUNNEL_CAP_FDB_ENCAP_E | SX_TUNNEL_CAP_COUNTER_READ_E |
 SX_TUNNEL_CAP_BRIDGE_DECAP_COUNTER_E | SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E | SX_TUNNEL_CAP_RPF_E |
 SX_TUNNEL_CAP_MC_NVE_DECAP_ERIF_E,  /* NVGRE */

 SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_ACL_ENCAP_E | SX_TUNNEL_CAP_FDB_ENCAP_E | SX_TUNNEL_CAP_COUNTER_READ_E |
 SX_TUNNEL_CAP_BRIDGE_DECAP_COUNTER_E | SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E | SX_TUNNEL_CAP_RPF_E |
 SX_TUNNEL_CAP_MC_NVE_DECAP_ERIF_E | SX_TUNNEL_CAP_IPV6_E,  /* VXLAN IPv6 */

 SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_ACL_ENCAP_E | SX_TUNNEL_CAP_FDB_ENCAP_E | SX_TUNNEL_CAP_COUNTER_READ_E |
 SX_TUNNEL_CAP_BRIDGE_DECAP_COUNTER_E | SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E | SX_TUNNEL_CAP_RPF_E |
 SX_TUNNEL_CAP_MC_NVE_DECAP_ERIF_E | SX_TUNNEL_CAP_IPV6_E,  /* NVGRE IPv6 */

 SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_FDB_ENCAP_E | SX_TUNNEL_CAP_COUNTER_READ_E |
 SX_TUNNEL_CAP_RPF_E | SX_TUNNEL_CAP_MC_NVE_DECAP_ERIF_E,   /* Flex Tunnel */

 SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_FDB_ENCAP_E | SX_TUNNEL_CAP_COUNTER_READ_E |
 SX_TUNNEL_CAP_RPF_E | SX_TUNNEL_CAP_MC_NVE_DECAP_ERIF_E | SX_TUNNEL_CAP_IPV6_E,          /* Flex Tunnel IPv6 */
};


/* Capabilities that are not supported / excluded per direction */
static const uint64_t g_tunnel_cap_by_direction_support[SX_TUNNEL_DIRECTION_MAX + 1] =
{ 0,
  (SX_TUNNEL_CAP_ACL_DECAP_E | SX_TUNNEL_CAP_BRIDGE_DECAP_COUNTER_E),    /* Encap */
  (SX_TUNNEL_CAP_NEXTHOP_ENCAP_E | SX_TUNNEL_CAP_FDB_ENCAP_E
   | SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E | SX_TUNNEL_CAP_ACL_ENCAP_E),  /* Decap */
  0                                                                      /* Symmetric */
};

static const char* tunnel_capability_name[] = {
    "decapsulation using ACL",
    "encapsulation using FDB",
    "next hop encapsulation",
    "counters",
    "per bridge decap counter",
    "per bridge encap counter",
    "encapsulation using ACL",
    "ipv6"
};

/************************************************
 *  Local function declarations
 ***********************************************/

static sx_status_t __tunnel_impl_counter_relocate_cb(cm_logical_id_t lid,
                                                     uint32_t        offset,
                                                     cm_type_e       type,
                                                     cm_hw_type_t    hw_type,
                                                     cm_index_t      old_index,
                                                     cm_index_t      new_index);
static sx_utils_status_t __delete_pending_tunnel_mapping_cb(uint64_t id);
static sx_utils_status_t __delete_pending_tunnel_cb(uint64_t id);
static sx_status_t __sdk_tunnel_nve_delete(sx_tunnel_id_t              tunnel_id,
                                           const sdk_db_tunnel_data_t *tunnel_params_p,
                                           boolean_t                   fatal_error);

/* Print name of first capability in mask */
static const char * __print_tunnel_capability(uint64_t capability_mask)
{
    uint32_t i;

    for (i = 0; (i < sizeof(tunnel_capability_name) / sizeof(tunnel_capability_name[0])); i++) {
        if (capability_mask & (1 << i)) {
            return tunnel_capability_name[i];
        }
    }

    return "Unknown";
}

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

static sx_status_t __tunnel_impl_check_init_params(sx_tunnel_general_params_t * params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (NULL != g_tunnel_ops.hwi_tunnel_impl_check_init_params_pfn) {
        sx_status = g_tunnel_ops.hwi_tunnel_impl_check_init_params_pfn(params_p);
    }

    return sx_status;
}

sx_tunnel_underlay_domain_type_e tunnel_impl_get_underlay_domain_type(const sx_tunnel_attribute_t * tunnel_attr_p)
{
    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        return tunnel_attr_p->attributes.ipinip_p2p.underlay_domain_type;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        return tunnel_attr_p->attributes.ipinip_p2p_gre.underlay_domain_type;

    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        return tunnel_attr_p->attributes.vxlan.underlay_domain_type;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        return tunnel_attr_p->attributes.vxlan_gpe.underlay_domain_type;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        return tunnel_attr_p->attributes.geneve.underlay_domain_type;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        return tunnel_attr_p->attributes.nvgre.underlay_domain_type;

    /* The Flex tunnel supports only the rif domain type */
    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        return SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF;
    }

    return 0;
}

sx_router_id_t tunnel_impl_get_underlay_vrid(const sx_tunnel_attribute_t * tunnel_attr_p)
{
    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        return tunnel_attr_p->attributes.ipinip_p2p.encap.underlay_vrid;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        return tunnel_attr_p->attributes.ipinip_p2p_gre.encap.underlay_vrid;

    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        return tunnel_attr_p->attributes.vxlan.encap.underlay_vrid;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        return tunnel_attr_p->attributes.vxlan_gpe.encap.underlay_vrid;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        return tunnel_attr_p->attributes.geneve.encap.underlay_vrid;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        return tunnel_attr_p->attributes.nvgre.encap.underlay_vrid;

    /* L2 Flex tunnel does not support VRID domain type */
    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        return 0xFFFF;
    }

    return 0;
}


sx_status_t tunnel_impl_get_ipinip_overlay_rif(const sx_tunnel_attribute_t * tunnel_attr_p,
                                               sx_router_interface_t       * ipinip_overlay_rif)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        *ipinip_overlay_rif = tunnel_attr_p->attributes.ipinip_p2p.overlay_rif;
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        *ipinip_overlay_rif = tunnel_attr_p->attributes.ipinip_p2p_gre.overlay_rif;
        break;

    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Can't get ipinip_overlay_rif. Invalid tunnel type %d\n", tunnel_attr_p->type);
        break;
    }

    return err;
}


sx_status_t tunnel_impl_get_underlay_rif(const sx_tunnel_attribute_t * tunnel_attr_p,
                                         sx_router_interface_t       * underlay_rif_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        *underlay_rif_p = tunnel_attr_p->attributes.ipinip_p2p.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        *underlay_rif_p = tunnel_attr_p->attributes.ipinip_p2p_gre.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        *underlay_rif_p = tunnel_attr_p->attributes.vxlan.encap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        *underlay_rif_p = tunnel_attr_p->attributes.vxlan_gpe.encap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        *underlay_rif_p = tunnel_attr_p->attributes.geneve.encap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        *underlay_rif_p = tunnel_attr_p->attributes.nvgre.encap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        *underlay_rif_p = tunnel_attr_p->attributes.l2_flex.encap.underlay_rif;
        break;

    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Can't get underlay_rif. Invalid tunnel type %d\n", tunnel_attr_p->type);
        break;
    }

    return err;
}

sx_status_t tunnel_impl_get_underlay_decap_rif(const sx_tunnel_attribute_t * tunnel_attr_p,
                                               sx_router_interface_t       * underlay_rif_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        *underlay_rif_p = tunnel_attr_p->attributes.ipinip_p2p.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        *underlay_rif_p = tunnel_attr_p->attributes.ipinip_p2p_gre.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        *underlay_rif_p = tunnel_attr_p->attributes.vxlan.decap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        *underlay_rif_p = tunnel_attr_p->attributes.vxlan_gpe.decap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        *underlay_rif_p = tunnel_attr_p->attributes.geneve.decap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        *underlay_rif_p = tunnel_attr_p->attributes.nvgre.decap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        *underlay_rif_p = tunnel_attr_p->attributes.l2_flex.decap.underlay_rif;
        break;

    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Can't get underlay RIF decap. Invalid tunnel type %d\n", tunnel_attr_p->type);
        break;
    }

    return err;
}

sx_status_t tunnel_impl_set_underlay_rif(sx_tunnel_attribute_t * tunnel_attr_p, sx_router_interface_t underlay_rif)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        tunnel_attr_p->attributes.ipinip_p2p.underlay_rif = underlay_rif;
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        tunnel_attr_p->attributes.ipinip_p2p_gre.underlay_rif = underlay_rif;
        break;

    /* For VXLAN set encap direction only */
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        tunnel_attr_p->attributes.vxlan.encap.underlay_rif = underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        tunnel_attr_p->attributes.vxlan_gpe.encap.underlay_rif = underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        tunnel_attr_p->attributes.geneve.encap.underlay_rif = underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        tunnel_attr_p->attributes.nvgre.encap.underlay_rif = underlay_rif;
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        tunnel_attr_p->attributes.l2_flex.encap.underlay_rif = underlay_rif;
        break;

    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Can't set underlay_rif. Invalid tunnel type %d\n", tunnel_attr_p->type);
        break;
    }

    return err;
}
sx_status_t tunnel_impl_set_decap_underlay_rif(sx_tunnel_attribute_t * tunnel_attr_p,
                                               sx_router_interface_t   underlay_rif)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        /* no decap underlay RIF in IPinIP */
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        tunnel_attr_p->attributes.vxlan.decap.underlay_rif = underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        tunnel_attr_p->attributes.vxlan_gpe.decap.underlay_rif = underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        tunnel_attr_p->attributes.geneve.decap.underlay_rif = underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        tunnel_attr_p->attributes.nvgre.decap.underlay_rif = underlay_rif;
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        tunnel_attr_p->attributes.l2_flex.decap.underlay_rif = underlay_rif;
        break;

    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Can't get decap underlay_rif. Invalid tunnel type %d\n", tunnel_attr_p->type);
        break;
    }

    return err;
}

sx_port_log_id_t tunnel_impl_get_l2_log_port(const sx_tunnel_attribute_t * tunnel_attr_p)
{
    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        return tunnel_attr_p->attributes.vxlan.nve_log_port;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        return tunnel_attr_p->attributes.vxlan_gpe.nve_log_port;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        return tunnel_attr_p->attributes.geneve.nve_log_port;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        return tunnel_attr_p->attributes.nvgre.nve_log_port;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        return tunnel_attr_p->attributes.l2_flex.log_port;

    default:
        SX_LOG_ERR("Can't get l2_log_port. Invalid tunnel type (0x%08x)\n",
                   tunnel_attr_p->type);
        return SX_INVALID_PORT;
    }

    return SX_INVALID_PORT;
}

const char * get_tunnel_rif_ref_name(char * name_buf, size_t name_size, void * data)
{
    rif_tunnel_t *rip_tunnel_p = (rif_tunnel_t *)data;

    snprintf(name_buf, name_size, "TUN%d_RIF%d", rip_tunnel_p->tunnel_id, rip_tunnel_p->rif);
    return name_buf;
}


sx_status_t sdk_tunnel_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    hwd_tunnel_log_verbosity_level_set(verbosity_level);

    sdk_ipv6_mgr_log_verbosity_level_set(verbosity_level);

    return status;
}

sx_status_t sdk_tunnel_impl_params_get(boolean_t * is_tunnel_init_done_p)
{
    if (is_tunnel_init_done_p) {
        *is_tunnel_init_done_p = g_is_tunnel_initialized;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t sdk_tunnel_impl_params_set(boolean_t is_tunnel_init_done)
{
    g_is_tunnel_initialized = is_tunnel_init_done;
    return SX_STATUS_SUCCESS;
}

sx_status_t sdk_tunnel_check_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (FALSE == g_is_tunnel_initialized) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Tunnel module is not initialized\n");
    }

    return err;
}

sx_status_t sdk_tunnel_check_terminated(void)
{
    sx_status_t err = SX_STATUS_ERROR;

    if (TRUE == g_is_tunnel_terminated) {
        SX_LOG_DBG("Tunnel module is terminated\n");
        err = SX_STATUS_SUCCESS;
    }
    return err;
}


sx_status_t sdk_tunnel_check_learn_mode(sx_port_log_id_t log_port, sx_fdb_learn_mode_t learn_mode)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (NULL != g_tunnel_ops.hwi_tunnel_impl_check_learn_mode_pfn) {
        sx_status = (g_tunnel_ops.hwi_tunnel_impl_check_learn_mode_pfn(log_port, learn_mode));
    }

    return sx_status;
}

static sx_status_t __sdk_tunnel_rif_adviser_cb(adviser_event_e event_type, void * param)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    hwi_rif_state_event_data_t *rif_event_data_p = (hwi_rif_state_event_data_t*)param;
    sx_fid_t                    fid;
    hwd_tunnel_map_entry_t      hwd_map_entry;
    uint32_t                    hwd_map_entry_cnt = 1;
    sx_tunnel_id_t              tunnel_id;

    SX_LOG_ENTER();
    SX_MEM_CLR(hwd_map_entry);

    switch (event_type) {
    case ADVISER_EVENT_POST_RIF_ENABLE_E:
        hwd_map_entry.v_rif = TRUE;
        hwd_map_entry.hw_rif_id = rif_event_data_p->hw_rif_id;
        break;

    case ADVISER_EVENT_PRE_RIF_DISABLE_E:
        hwd_map_entry.v_rif = FALSE;
        break;

    default:
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Received an unexpected event[%s]\n",
                   ADVISER_EVENT_STR(event_type));
        goto out;
    }

    switch (rif_event_data_p->ifc.type) {
    case SX_L2_INTERFACE_TYPE_VLAN:
        fid = rif_event_data_p->ifc.ifc.vlan.vlan;
        break;

    case SX_L2_INTERFACE_TYPE_BRIDGE:
        fid = rif_event_data_p->ifc.ifc.bridge.bridge;
        break;

    default:
        /* Nothing to do */
        goto out;
    }

    rc = sdk_fid_manager_tunnel_get(fid, &tunnel_id);
    if (SX_CHECK_FAIL(rc)) {
        if (SX_STATUS_ENTRY_NOT_FOUND == rc) {
            rc = SX_STATUS_SUCCESS;
        } else {
            SX_LOG_ERR("Failed to get tunnel ID from FID %d, err = %s\n",
                       fid, sx_status_str(rc));
        }
        goto out;
    }

    rc = sdk_tunnel_db_mapping_get_by_fid(tunnel_id, fid, &(hwd_map_entry.map_entry));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get decap counter for FID[%u], error: %s \n",
                   fid, sx_status_str(rc));
        goto out;
    }

    rc = sdk_tunnel_db_fid_counter_get(tunnel_id, fid,
                                       SX_BRIDGE_COUNTER_TUNNEL_DECAP_E,
                                       &(hwd_map_entry.decap_flow_counter_id));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get decap counter for FID[%u], error: %s \n",
                   fid, sx_status_str(rc));
        goto out;
    }

    rc = g_hwd_tunnel_ops.hwd_tunnel_tunnel_mapping_update_pfn(tunnel_id, &hwd_map_entry, hwd_map_entry_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to update (in HW) to tunnel[0x%08x] -- %u map entries, err = %s\n",
                   tunnel_id, hwd_map_entry_cnt, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __sdk_tunnel_counters_clear()
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_port_tunnel_phy_id_t tunnel_port = 0;

    /* Clear the counters of all tunnel ports */
    for (tunnel_port = SX_PORT_TUNNEL_MIN; tunnel_port <= SX_PORT_TUNNEL_MAX; tunnel_port++) {
        if (tunnel_port == SX_PORT_TUNNEL_RESERVED) {
            continue;
        }

        /* NOTE: This is a workaround that should be remove once the FW is done */
        if ((tunnel_port == SX_PORT_TUNNEL_FLEX0) || (tunnel_port == SX_PORT_TUNNEL_FLEX1)) {
            continue;
        }

        err = g_hwd_tunnel_ops.hwd_tunnel_counter_clear_pfn(tunnel_port);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to clear counters for tunnel %s, err = %s\n",
                       sx_port_tunnel_phy_id_str(tunnel_port),
                       sx_status_str(err));
            goto out;
        }
    }

out:
    return err;
}

sx_status_t sdk_tunnel_impl_init(sx_tunnel_general_params_t * tunnel_gen_params_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_status_t                   rollback_err = SX_STATUS_SUCCESS;
    boolean_t                     rollback_db_init = FALSE;
    boolean_t                     rollback_decap_table = FALSE;
    boolean_t                     rollback_mc_container_nve_params_set = FALSE;
    boolean_t                     rollback_hwd_tunnel = FALSE;
    boolean_t                     rollback_fdb_resolution_action_set = FALSE;
    boolean_t                     rollback_mc_container_impl_register_tunnel_ops = FALSE;
    boolean_t                     post_rif_enable_added = FALSE;
    boolean_t                     pre_rif_disable_added = FALSE;
    hwi_mc_container_tunnel_ops_t mc_container_ops;
    sx_utils_status_t             utils_status = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE == g_is_tunnel_initialized) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Tunnel impl module is already initialized\n");
        goto out;
    }

    if (!g_tunnel_ops_init) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Tunnel impl module ops not prepared\n");
        goto out;
    }

    /* Validate init parameters & reset reserved ones */
    err = __tunnel_impl_check_init_params(tunnel_gen_params_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to verify tunnel general parameters, error: [%s].\n",
                   sx_status_str(err));
        goto out;
    }

    utils_status = gc_lazy_delete_mode_get(&g_ld_enabled);
    if (utils_status != SX_UTILS_STATUS_SUCCESS) {
        err = SX_UTILS_STATUS_TO_SX_STATUS(utils_status);
        SX_LOG_ERR("gc_lazy_delete_mode_get() failed, err = %s.\n", sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_db_init(rm_resource_global.tunnel_ipinip_num_max,
                             rm_resource_global.tunnel_nve_num_max,
                             rm_resource_global.tunnel_l2_flex_num_max,
                             __delete_pending_tunnel_cb,
                             __delete_pending_tunnel_mapping_cb);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to init tunnel HWI DB, err = %s\n", sx_status_str(err));
        goto out;
    }
    rollback_db_init = TRUE;

    SX_MEM_CPY_P(&g_sdk_tunnel_init_params.general_param, tunnel_gen_params_p);

    err = decap_table_impl_init();
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to init tunnel decap table, err = %s\n",
                   sx_status_str(err));
        goto out;
    }
    rollback_decap_table = TRUE;

    err = g_hwd_tunnel_ops.hwd_tunnel_init_pfn(&g_sdk_tunnel_init_params);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to init tunnel HWD module, err = %s\n", sx_status_str(err));
        goto out;
    }
    rollback_hwd_tunnel = TRUE;

    /* Clear counter after HWD init */
    err = __sdk_tunnel_counters_clear();
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to clear counters for tunnel, err = %s\n", sx_status_str(err));
        goto out;
    }

    if (TRUE == tunnel_gen_params_p->nve.fdb_resolution_valid) {
        err = sdk_router_neigh_impl_fdb_resolution_action_set(SX_ACCESS_CMD_SET,
                                                              tunnel_gen_params_p->nve.fdb_resolution_action);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to set resolution action to neighbor. [%s]\n",
                   sx_status_str(err));
            goto out;
        }
        rollback_fdb_resolution_action_set = TRUE;
    }

    /* Provide router callbacks to mc_container module.
     * Note - mc_container module cannot link against router module directly, due to circular dependencies */
    SX_MEM_CLR(mc_container_ops);
    mc_container_ops.tun_ref_increase_pfn = &sdk_tunnel_impl_ref_increase;
    mc_container_ops.tun_ref_decrease_pfn = &sdk_tunnel_impl_ref_decrease;

    err = sdk_mc_container_impl_register_tunnel_ops(&mc_container_ops);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to register MC Container tunnel ops. [%s]\n",
               sx_status_str(err));
        goto out;
    }
    rollback_mc_container_impl_register_tunnel_ops = TRUE;

    err = sdk_mc_container_nve_params_set(tunnel_gen_params_p->nve.flood_ecmp_enabled,
                                          tunnel_gen_params_p->nve.mc_ecmp_enabled);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to register MC Container tunnel params. [%s]\n",
               sx_status_str(err));
        goto out;
    }
    rollback_mc_container_nve_params_set = TRUE;

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_RIF_ENABLE_E,
                                 __sdk_tunnel_rif_adviser_cb);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up RIF enable adviser, rc = %s\n", sx_status_str(err));
        goto out;
    }
    post_rif_enable_added = TRUE;

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_PRE_RIF_DISABLE_E,
                                 __sdk_tunnel_rif_adviser_cb);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up RIF disable adviser, rc = %s\n", sx_status_str(err));
        goto out;
    }
    pre_rif_disable_added = TRUE;

    err = cm_user_init(__tunnel_impl_counter_relocate_cb, NULL, NULL, &g_cm_handle);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to init CM.\n");
        goto out;
    }

    sdk_tunnel_impl_params_set(TRUE);

out:
    if (SX_STATUS_SUCCESS != err) {
        if (post_rif_enable_added == TRUE) {
            rollback_err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_RIF_ENABLE_E,
                                                  __sdk_tunnel_rif_adviser_cb);
            if (rollback_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set up RIF enable adviser, rc = %s\n", sx_status_str(rollback_err));
            }
        }

        if (pre_rif_disable_added == TRUE) {
            rollback_err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PRE_RIF_DISABLE_E,
                                                  __sdk_tunnel_rif_adviser_cb);
            if (rollback_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set up RIF disable adviser, rc = %s\n", sx_status_str(rollback_err));
            }
        }

        if (TRUE == rollback_mc_container_impl_register_tunnel_ops) {
            rollback_err = sdk_mc_container_impl_unregister_tunnel_ops();
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback, register MC Container tunnel ops failed, err = %s\n",
                    sx_status_str(rollback_err));
            }
        }

        if (TRUE == rollback_mc_container_nve_params_set) {
            rollback_err = sdk_mc_container_nve_params_set(FALSE, FALSE);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback, register MC Container tunnel params failed, err = %s\n",
                    sx_status_str(rollback_err));
            }
        }

        if (TRUE == rollback_fdb_resolution_action_set) {
            rollback_err = sdk_router_neigh_impl_fdb_resolution_action_set(SX_ACCESS_CMD_UNSET,
                                                                           SX_ROUTER_ACTION_FORWARD);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback, set FDB resolution action to neighbor failed, err = %s\n",
                    sx_status_str(rollback_err));
            }
        }

        if (TRUE == rollback_hwd_tunnel) {
            rollback_err = g_hwd_tunnel_ops.hwd_tunnel_deinit_pfn(FALSE);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback, tunnel HWD de-init failed, err = %s\n",
                    sx_status_str(rollback_err));
            }
        }

        if (TRUE == rollback_db_init) {
            rollback_err = sdk_tunnel_db_deinit(FALSE);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback, tunnel HWI DB de-init failed, err = %s\n",
                    sx_status_str(rollback_err));
            }
        }

        if (TRUE == rollback_decap_table) {
            rollback_err = decap_table_impl_deinit(FALSE);

            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback, tunnel decap table de-init failed, err = %s\n",
                    sx_status_str(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_deinit(boolean_t is_forced)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_status_t rb_err = SX_STATUS_SUCCESS;
    boolean_t   post_rif_enable_removed = FALSE;
    boolean_t   pre_rif_disable_removed = FALSE;

    SX_LOG_ENTER();

    if (FALSE == g_is_tunnel_initialized) {
        if (FALSE == is_forced) {
            err = SX_STATUS_MODULE_UNINITIALIZED;
            SX_LOG_ERR("Tunnel module is not initialized.\n");
        }

        /* return success on force de-init if not initialized */
        goto out;
    } else if (TRUE == is_forced) {
        g_is_tunnel_terminated = TRUE;
    }

    if (g_cm_handle != NULL) {
        err = cm_user_deinit(g_cm_handle);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to deinit the tunnel's counter manager user.\n");
            goto out;
        }
        g_cm_handle = NULL;
    }

    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_RIF_ENABLE_E,
                                 __sdk_tunnel_rif_adviser_cb);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up RIF enable adviser, rc = %s\n", sx_status_str(err));
        goto out;
    }
    post_rif_enable_removed = TRUE;

    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PRE_RIF_DISABLE_E,
                                 __sdk_tunnel_rif_adviser_cb);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up RIF disable adviser, rc = %s\n", sx_status_str(err));
        goto out;
    }
    pre_rif_disable_removed = TRUE;

    err = g_hwd_tunnel_ops.hwd_tunnel_deinit_pfn(is_forced);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to de-init tunnel HWD, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = decap_table_impl_deinit(is_forced);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to de-init tunnel decap table, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_db_deinit(is_forced);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to de-init tunnel HWI DB, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    sdk_tunnel_impl_params_set(FALSE);
    err = sdk_tunnel_impl_unregister_hwd_ops();
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to unregister HWD ops, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_impl_unregister_tunnel_ops();
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to unregister tunnel ops, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_mc_container_impl_unregister_tunnel_ops();
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to unregister mc_cont. tunnel ops, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_router_neigh_impl_fdb_resolution_action_set(SX_ACCESS_CMD_UNSET, SX_ROUTER_ACTION_FORWARD);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to unset resolution action from neighbor. [%s]\n",
               sx_status_str(err));
        goto out;
    }

    err = sdk_mc_container_nve_params_set(FALSE, FALSE);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to register MC Container tunnel params. [%s]\n",
               sx_status_str(err));
        goto out;
    }

out:
    if (SX_CHECK_FAIL(err)) {
        if (post_rif_enable_removed == TRUE) {
            rb_err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_RIF_ENABLE_E,
                                            __sdk_tunnel_rif_adviser_cb);
            if (rb_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set up RIF enable adviser, rc = %s\n", sx_status_str(rb_err));
            }
        }

        if (pre_rif_disable_removed == TRUE) {
            rb_err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_PRE_RIF_DISABLE_E,
                                            __sdk_tunnel_rif_adviser_cb);
            if (rb_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set up RIF disable adviser, rc = %s\n", sx_status_str(rb_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tunnel_impl_create(const sx_tunnel_attribute_t * tunnel_attr_p, sx_tunnel_id_t * tunnel_id_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_status_t                  rollback_err = SX_STATUS_SUCCESS;
    sdk_ref_t                    rif_ref;
    boolean_t                    db_add_rollback = FALSE;
    boolean_t                    hwd_create_rollback = FALSE;
    boolean_t                    prepare_create_rollback = FALSE;
    hwi_tunnel_hw_encap_handle_t tunnel_encap_handle;
    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle;
    sdk_db_tunnel_data_t         tunnel_params;
    sx_tunnel_id_t               tmp_tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_router_interface_t        ipinip_overlay_rif;
    sx_tunnel_attribute_t        modified_tunnel_attr;
    boolean_t                    first_enable;
    sx_port_log_id_t             l2_log_port = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_params);

    SX_MEM_CLR(rif_ref);
    SX_MEM_CLR(tunnel_encap_handle);
    SX_MEM_CLR(tunnel_decap_handle);
    SX_MEM_CLR(ipinip_overlay_rif);
    SX_MEM_CLR(tmp_tunnel_id);

    SX_MEM_CPY_P(&modified_tunnel_attr, tunnel_attr_p);

    err = sdk_tunnel_db_add(&modified_tunnel_attr, NULL, &tmp_tunnel_id);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to add tunnel to database, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    db_add_rollback = TRUE;
    err = g_tunnel_ops.hwi_tunnel_impl_prepare_create_pfn(&modified_tunnel_attr, &tmp_tunnel_id);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to prepare create tunnel, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    prepare_create_rollback = TRUE;
    err = g_hwd_tunnel_ops.hwd_tunnel_create_pfn(&modified_tunnel_attr, &tunnel_encap_handle, &tunnel_decap_handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to create tunnel on hardware, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }
    hwd_create_rollback = TRUE;

    if (SX_TUNNEL_TYPE_NVE_CHECK(tmp_tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(tmp_tunnel_id)) {
        l2_log_port = tunnel_impl_get_l2_log_port(tunnel_attr_p);
        err = g_hwd_tunnel_ops.hwd_tunnel_counter_clear_pfn(SX_PORT_PHY_ID_GET(l2_log_port));
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to clear counter for tunnel on hardware, err = %s\n",
                       sx_status_str(err));
            goto out;
        }
    }

    err = sdk_tunnel_db_hw_handle_set(tmp_tunnel_id, tunnel_encap_handle, tunnel_decap_handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to set decap/encap handles to tunnel[0x%08x] , err = %s\n",
                   tmp_tunnel_id, sx_status_str(err));
        goto out;
    }

    if (SX_TUNNEL_TYPE_NVE_CHECK(tmp_tunnel_id)) {
        /* Validate that IGMPv3 enabled */
        first_enable = is_igmpv3_first_enable();
        if (first_enable == FALSE) {
            /* first_enable = FALSE means that IGMP module already initialized */
            /* Enable IGMPv3 tunnel decap functionality */
            err = igmpv3_tunnel_decap_support_state_set_wrap(IGMPV3_TUNNEL_DECAP_ENABLE);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to enable igmpv3_tunnel_decap_support_state_set_wrap on hardware, rc = %s\n",
                           sx_status_str(err));
                goto out;
            }
        } else {
            SX_LOG_INF("*** Tunnel create flow: IGMPV3 was not initialized yet - No restore VLAN region\n");
        }
    }

    *tunnel_id_p = tmp_tunnel_id;

out:
    if (SX_STATUS_SUCCESS != err) {
        if (hwd_create_rollback) {
            rollback_err = g_hwd_tunnel_ops.hwd_tunnel_delete_pfn(tunnel_encap_handle,
                                                                  tunnel_decap_handle,
                                                                  &modified_tunnel_attr);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to delete tunnel on hardware, err = %s\n",
                           sx_status_str(rollback_err));
            }
        }

        if (prepare_create_rollback) {
            rollback_err = g_tunnel_ops.hwi_tunnel_impl_prepare_create_rollback_pfn(&modified_tunnel_attr,
                                                                                    &tmp_tunnel_id);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to rollback tunnel creation preparation, err = %s\n",
                           sx_status_str(rollback_err));
            }
        }

        if (db_add_rollback) {
            rollback_err = sdk_tunnel_db_delete(tmp_tunnel_id);
            if (rollback_err) {
                SX_LOG_ERR("Failed to delete tunnel[0x%08x] from DB, err = %s\n",
                           tmp_tunnel_id, sx_status_str(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tunnel_nve_delete(sx_tunnel_id_t               tunnel_id,
                                           const sdk_db_tunnel_data_t * tunnel_params_p,
                                           boolean_t                    fatal_error)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_status_t                  rollback_err = SX_STATUS_SUCCESS;
    boolean_t                    tunnel_delete_action_rollback = FALSE;
    boolean_t                    hwd_delete_rollback = FALSE;
    hwi_tunnel_hw_encap_handle_t tunnel_encap_handle;
    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle;
    sx_event_info_t              event_info;
    boolean_t                    first_enable;

    SX_MEM_CLR(event_info.deleted_object);
    SX_MEM_CLR(tunnel_encap_handle);
    SX_MEM_CLR(tunnel_decap_handle);

    if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id)) {
        /* Validate that IGMPv3 enabled */
        first_enable = is_igmpv3_first_enable();
        if (first_enable == FALSE) {
            /* first_enable = FALSE means that IGMP module already initialized */
            /* Disable IGMPv3 tunnel decap functionality */
            err = igmpv3_tunnel_decap_support_state_set_wrap(IGMPV3_TUNNEL_DECAP_DISABLE);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to disable igmpv3_tunnel_decap_support_state_set_wrap on hardware, rc = %s\n",
                           sx_status_str(err));
                goto out;
            }
        } else {
            SX_LOG_INF("*** Tunnel destroy flow: IGMPV3 was not initialized yet - No restore VLAN region\n");
        }
    }

    err = g_tunnel_ops.hwi_tunnel_impl_delete_action_pfn(tunnel_id, tunnel_params_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to delete tunnel, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }
    tunnel_delete_action_rollback = TRUE;

    err = g_hwd_tunnel_ops.hwd_tunnel_delete_pfn(tunnel_params_p->hwd_encap_handle,
                                                 tunnel_params_p->hwd_decap_handle,
                                                 &tunnel_params_p->tun_attr);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to delete tunnel on hardware, err = %s\n",
                   sx_status_str(err));
        goto out;
    }
    hwd_delete_rollback = TRUE;

    err = sdk_tunnel_db_delete(tunnel_id);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to DB tunnel[0x%08x] delete, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }
    fatal_error = TRUE; /* tunnel_id is built by sdk_tunnel_db_add, so no rollback */

    if (g_ld_enabled) {
        event_info.deleted_object.object_cnt = 1;
        event_info.deleted_object.object[0].object_type = SX_OBJECT_TYPE_TUNNEL;
        event_info.deleted_object.object[0].object_id.tunnel_id = tunnel_id;

        err = host_ifc_send_event(SX_TRAP_ID_OBJECT_DELETED_EVENT,
                                  &(event_info.deleted_object),
                                  sizeof(event_info.deleted_object),
                                  SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Could not send the OBJECT_DELETED_EVENT event for the tunnel[0x%08x], err = [%s]\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
    }

out:
    if ((FALSE == fatal_error) && (SX_STATUS_SUCCESS != err)) {
        if (hwd_delete_rollback) {
            rollback_err = g_hwd_tunnel_ops.hwd_tunnel_create_pfn(&tunnel_params_p->tun_attr,
                                                                  &tunnel_encap_handle,
                                                                  &tunnel_decap_handle);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Rollback: Failed to create tunnel on hardware, err = %s\n",
                           sx_status_str(rollback_err));
            }

            rollback_err = sdk_tunnel_db_hw_handle_set(tunnel_id,
                                                       tunnel_encap_handle,
                                                       tunnel_decap_handle);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Rollback: Failed to set decap/encap handles to tunnel[0x%08x] , err = %s\n",
                    tunnel_id, sx_status_str(rollback_err));
            }
        }

        if (tunnel_delete_action_rollback) {
            rollback_err = g_tunnel_ops.hwi_tunnel_impl_delete_action_rollback_pfn(tunnel_id, tunnel_params_p);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to rollback tunnel delete action, err= %s.\n",
                           sx_status_str(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_delete(sx_tunnel_id_t tunnel_id)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_status_t                  rollback_err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t        tunnel_attr;
    const sdk_db_tunnel_data_t  *tunnel_params_p = NULL;
    sdk_ref_t                    ref;
    boolean_t                    tunnel_delete_action_rollback = FALSE;
    boolean_t                    rif_impl_ref_decrease_rollback = FALSE;
    boolean_t                    hwd_delete_rollback = FALSE;
    boolean_t                    rif_ref_tunnel_deattach_rollback = FALSE;
    sx_router_interface_t        ipinip_overlay_rif;
    hwi_tunnel_hw_encap_handle_t tunnel_encap_handle;
    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle;
    rif_tunnel_t                 rif_tunnel_data;
    char                         ref_name[10 * (REFERENCE_NAME_MAX_LEN + 2)] = "\0"; /* No need to print more than 10 reference */
    boolean_t                    pending_delete = FALSE;
    sx_port_log_id_t             log_port = 0;
    uint32_t                     tunnel_refcount = 0;
    ref_name_data_t              tunnel_rif_name_data = {.print_func_p = get_tunnel_rif_ref_name,
                                                         .ref_data_p = &rif_tunnel_data,
                                                         .data_size = sizeof(rif_tunnel_data)};

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_attr);
    SX_MEM_CLR(ref);
    SX_MEM_CLR(ipinip_overlay_rif);
    SX_MEM_CLR(tunnel_encap_handle);
    SX_MEM_CLR(tunnel_decap_handle);

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_get(tunnel_id, &tunnel_params_p, TRUE); /* pending delete state is checked later */
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] from DB, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (SX_TUNNEL_TYPE_IPINIP_CHECK(tunnel_id)) {
        err = sdk_tunnel_db_ref_count_get(tunnel_id, &tunnel_refcount, sizeof(ref_name), ref_name);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get ref.count for tunnel[0x%08x], err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        if (tunnel_refcount != 0) {
            err = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("Can't destroy tunnel[0x%08x], as it still has %d references: %s\n",
                       tunnel_id, tunnel_refcount, ref_name);
            goto out;
        }

        SX_MEM_CPY(tunnel_attr, tunnel_params_p->tun_attr);
        ipinip_overlay_rif = tunnel_attr.attributes.ipinip_p2p.overlay_rif;

        err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_DELETE,
                                             ipinip_overlay_rif,
                                             &tunnel_attr);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to detach tunnel from overlay_rif[%d], err = %s\n",
                       ipinip_overlay_rif, sx_status_str(err));
            goto out;
        }
        rif_ref_tunnel_deattach_rollback = TRUE;

        err = sdk_tunnel_db_rif_ref_get(tunnel_id, &ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed get tunnel[0x%08x] RIF[%d] reference, err = %s\n",
                       tunnel_id, tunnel_attr.attributes.ipinip_p2p.overlay_rif,
                       sx_status_str(err));
            goto out;
        }

        err = sdk_rif_impl_ref_decrease(tunnel_attr.attributes.ipinip_p2p.overlay_rif, &ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed decrease RIF[%d] reference, err = %s\n",
                       tunnel_attr.attributes.ipinip_p2p.overlay_rif, sx_status_str(err));
            goto out;
        }

        rif_impl_ref_decrease_rollback = TRUE;
    } else if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto end;
        }

        if (pending_delete) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto end;
        }

        /* Get log port from tunnel ID */
        err = sdk_tunnel_impl_log_port_by_tunnel_id_get(tunnel_id, &log_port);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get log_port for tunnel[0x%08x], err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto end;
        }

        /* Save learning mode */
        err = fdb_port_learn_mode_get(log_port, &g_ld_learn_mode);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get learning for log_port[0x%08x], tunnel[0x%08x], err = %s\n",
                       log_port, tunnel_id, sx_status_str(err));
            goto end;
        }

        if (SX_FDB_LEARN_MODE_DONT_LEARN != g_ld_learn_mode) {
            /* Disable learning */
            err = fdb_port_learn_mode_set(log_port, SX_FDB_LEARN_MODE_DONT_LEARN, FALSE);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to disable learning on log_port[0x%08x] for tunnel[0x%08x], err = %s\n",
                           log_port, tunnel_id, sx_status_str(err));
                goto end;
            }
            g_ld_learn_mode_changed = TRUE;

            if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id)) {
                /* Flush ageable FDB entries */
                err = fdb_flush_ageable_tunnel_macs_set(log_port);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to flush FDB by log_port[0x%08x] for tunnel[0x%08x], err = %s\n",
                               log_port, tunnel_id, sx_status_str(err));
                    goto end;
                }
            }
        }

        err = sdk_tunnel_db_ref_count_get(tunnel_id, &tunnel_refcount, 0, NULL);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get the tunnel[0x%08x] ref.count from DB, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto end;
        }

        if (0 != tunnel_refcount) {
            if (g_ld_enabled) {
                err = sdk_tunnel_db_pending_delete_set(tunnel_id, TRUE);
                if (SX_STATUS_SUCCESS != err) {
                    SX_LOG_ERR("Failed to set pending delete on the tunnel[0x%08x], err= %s.\n",
                               tunnel_id, sx_status_str(err));
                    goto end;
                }

                /* Restore learning mode configuration for NVE port after we delete tunnel on HW */
                goto end_2;
            } else {
                err = SX_STATUS_RESOURCE_IN_USE;
                SX_LOG_ERR("Failed to delete the tunnel[0x%08x]: ref.count isn't 0, err= %s.\n",
                           tunnel_id, sx_status_str(err));
                goto end;
            }
        }

        err = __sdk_tunnel_nve_delete(tunnel_id, tunnel_params_p, FALSE);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed delete a NVE tunnel[0x%08x], err = %s\n",
                       tunnel_id, sx_status_str(err));
        }
        goto end;
    }

    err = g_tunnel_ops.hwi_tunnel_impl_delete_action_pfn(tunnel_id, tunnel_params_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to delete tunnel, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    tunnel_delete_action_rollback = TRUE;

    err = g_hwd_tunnel_ops.hwd_tunnel_delete_pfn(tunnel_params_p->hwd_encap_handle,
                                                 tunnel_params_p->hwd_decap_handle,
                                                 &tunnel_attr);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to delete tunnel on hardware, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    hwd_delete_rollback = TRUE;

    err = sdk_tunnel_db_delete(tunnel_id);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to DB tunnel[0x%08x] delete, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    if (SX_STATUS_SUCCESS != err) {
        if (hwd_delete_rollback) {
            rollback_err = g_hwd_tunnel_ops.hwd_tunnel_create_pfn(&tunnel_attr,
                                                                  &tunnel_encap_handle,
                                                                  &tunnel_decap_handle);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to create tunnel on hardware, err = %s\n",
                           sx_status_str(rollback_err));
            }

            rollback_err = sdk_tunnel_db_hw_handle_set(tunnel_id,
                                                       tunnel_encap_handle,
                                                       tunnel_decap_handle);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to set decap/encap handles to tunnel[0x%08x], err = %s\n",
                           tunnel_id, sx_status_str(rollback_err));
            }
        }

        if (tunnel_delete_action_rollback) {
            rollback_err = g_tunnel_ops.hwi_tunnel_impl_delete_action_rollback_pfn(tunnel_id, tunnel_params_p);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to rollback tunnel delete action, err= %s.\n",
                           sx_status_str(rollback_err));
            }
        }

        rif_tunnel_data.rif = ipinip_overlay_rif;
        rif_tunnel_data.tunnel_id = tunnel_id;

        if (rif_impl_ref_decrease_rollback) {
            rollback_err = sdk_rif_impl_ref_increase(ipinip_overlay_rif,
                                                     &tunnel_rif_name_data,
                                                     &ref);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to increase RIF[%d] reference, err = %s\n",
                           ipinip_overlay_rif, sx_status_str(rollback_err));
            }

            rollback_err = sdk_tunnel_db_rif_ref_set(tunnel_id, &ref);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to assign RIF[%d] to tunnel, err = %s\n",
                           tunnel_id, sx_status_str(rollback_err));
            }
        }

        if (rif_ref_tunnel_deattach_rollback) {
            rollback_err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_ADD,
                                                          ipinip_overlay_rif,
                                                          &tunnel_attr);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback detach overlay RIF[%d] for tunnel, err = %s\n",
                    ipinip_overlay_rif, sx_status_str(rollback_err));
            }
        }
    }

end:
    /* Restore learning mode for NVE log_port */
    if (TRUE == g_ld_learn_mode_changed) {
        rollback_err = fdb_port_learn_mode_set(log_port, g_ld_learn_mode, TRUE);
        if (rollback_err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to rollback learning on log_port[0x%08x] for tunnel[0x%08x], err = %s\n",
                       log_port, tunnel_id, sx_status_str(rollback_err));
            goto end_2;
        }

        g_ld_learn_mode_changed = FALSE;
        g_ld_learn_mode = SX_FDB_LEARN_MODE_DONT_LEARN;
    }

end_2:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tunnel_impl_attr_changed_notify(sx_tunnel_id_t        tunnel_id,
                                                     const tunnel_info_t * old_tunnel_info_p,
                                                     const tunnel_info_t * new_tunnel_info_p)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    post_tunnel_attrs_edit_event_data_t event_data;

    SX_LOG_ENTER();

    SX_MEM_CLR(event_data);

    event_data.tunnel_id = tunnel_id;
    SX_MEM_CPY(event_data.old_tunnel_info, *old_tunnel_info_p);
    SX_MEM_CPY(event_data.new_tunnel_info, *new_tunnel_info_p);

    err = adviser_process_event(ADVISER_EVENT_POST_TUNNEL_ATTRIBUTES_CHANGE_E, &event_data);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Fatal error, failed to process adviser event[%s], err= %s.\n",
                   ADVISER_EVENT_STR(ADVISER_EVENT_POST_TUNNEL_ATTRIBUTES_CHANGE_E), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_edit(sx_tunnel_id_t tunnel_id, const sx_tunnel_attribute_t * new_tunnel_attr_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_status_t                 rollback_err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t       old_tunnel_attr;
    const sdk_db_tunnel_data_t *tunnel_params_p = NULL;
    sx_router_interface_t       ipinip_overlay_rif;
    boolean_t                   tunnel_db_edit_rollback = FALSE;
    boolean_t                   rif_ref_tunnel_attach_rollback = FALSE;
    boolean_t                   edit_action_rollback = FALSE;
    sx_tunnel_attribute_t       modified_tunnel_attr;
    tunnel_info_t               old_tunnel_info, new_tunnel_info;

    SX_LOG_ENTER();

    SX_MEM_CLR(old_tunnel_attr);
    SX_MEM_CLR(ipinip_overlay_rif);
    SX_MEM_CLR(old_tunnel_info);
    SX_MEM_CLR(new_tunnel_info);

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_get(tunnel_id, &tunnel_params_p, FALSE);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x], err = %s\n", tunnel_id,
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY(old_tunnel_attr, tunnel_params_p->tun_attr);
    SX_MEM_CPY_P(&modified_tunnel_attr, new_tunnel_attr_p);

    err = tunnel_impl_tunnel_info_get(tunnel_id, &old_tunnel_info);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get old tunnel info for tunnel edit tunnel id [0x%x], error: %s \n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = g_tunnel_ops.hwi_tunnel_impl_edit_action_pfn(tunnel_id,
                                                       tunnel_params_p,
                                                       &old_tunnel_attr,
                                                       &modified_tunnel_attr);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to edit tunnel, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    edit_action_rollback = TRUE;

    err = sdk_tunnel_db_edit(tunnel_id, &modified_tunnel_attr);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to set tunnel[%d] attr to DB, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }
    tunnel_db_edit_rollback = TRUE;

    if (SX_TUNNEL_TYPE_IPINIP_CHECK(tunnel_id)) {
        err = tunnel_impl_get_ipinip_overlay_rif(&modified_tunnel_attr, &ipinip_overlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] overlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_EDIT,
                                             ipinip_overlay_rif,
                                             &modified_tunnel_attr);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to edit attached overlay_rif[%d], err = %s\n",
                       ipinip_overlay_rif, sx_status_str(err));
            goto out;
        }
        rif_ref_tunnel_attach_rollback = TRUE;
    }

    err = g_hwd_tunnel_ops.hwd_tunnel_edit_pfn(tunnel_params_p->hwd_encap_handle,
                                               tunnel_params_p->hwd_decap_handle,
                                               &old_tunnel_attr,
                                               &modified_tunnel_attr);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to edit tunnel on hardware, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = g_tunnel_ops.hwi_tunnel_impl_post_edit_action_pfn(tunnel_id, &old_tunnel_attr, &modified_tunnel_attr);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed at post edit tunnel, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        err = tunnel_impl_tunnel_info_get(tunnel_id, &new_tunnel_info);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get new tunnel info for tunnel edit tunnel id [0x%x], error: %s \n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = __tunnel_impl_attr_changed_notify(tunnel_id, &old_tunnel_info, &new_tunnel_info);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to notify about changes in tunnel's attributes, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
    }

out:
    if (SX_STATUS_SUCCESS != err) {
        if (rif_ref_tunnel_attach_rollback) {
            rollback_err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_EDIT,
                                                          ipinip_overlay_rif,
                                                          &old_tunnel_attr);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback edit tunnel on hardware, err = %s\n",
                    sx_status_str(rollback_err));
            }
        }

        if (edit_action_rollback) {
            rollback_err = g_tunnel_ops.hwi_tunnel_impl_edit_action_rollback_pfn(tunnel_id,
                                                                                 tunnel_params_p,
                                                                                 &old_tunnel_attr,
                                                                                 &modified_tunnel_attr);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback edit tunnel, err = %s\n",
                    sx_status_str(rollback_err));
            }
        }

        if (tunnel_db_edit_rollback) {
            rollback_err = sdk_tunnel_db_edit(tunnel_id, &old_tunnel_attr);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback edit tunnel on hardware, err = %s\n",
                    sx_status_str(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_get(sx_tunnel_id_t tunnel_id, sx_tunnel_attribute_t * tunnel_attr_p)
{
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t            tunnel_attr;
    const sdk_db_tunnel_data_t      *tunnel_params = NULL;
    sx_tunnel_underlay_domain_type_e underlay_domain_type;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel[0x%08x] impl get attributes\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(tunnel_attr);

    err = sdk_tunnel_db_get(tunnel_id, &tunnel_params, TRUE);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x], err = %s\n", tunnel_id,
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(tunnel_attr_p, &(tunnel_params->tun_attr));
    underlay_domain_type = tunnel_impl_get_underlay_domain_type(tunnel_attr_p);

    if (underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
        /* If underlay domain type is VRID need to mask underlay RIF from the user */
        err = tunnel_impl_set_underlay_rif(tunnel_attr_p,  0);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error masking tunnel[0x%08x] underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }

        err = tunnel_impl_set_decap_underlay_rif(tunnel_attr_p,  0);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error masking tunnel[0x%08x] decap underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }
    } else if (underlay_domain_type == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) {
        /* Different decap underlay RIF is currently not supported, mask the value */
        err = tunnel_impl_set_decap_underlay_rif(tunnel_attr_p,  0);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error masking tunnel[0x%08x] decap underlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_register_hwd_ops(struct hwd_tunnel_ops * hwd_tunnel_ops_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_init_pfn,
                            "hwd_tunnel_init_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_deinit_pfn,
                            "hwd_tunnel_deinit_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_create_pfn,
                            "hwd_tunnel_create_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_delete_pfn,
                            "hwd_tunnel_delete_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_edit_pfn,
                            "hwd_tunnel_edit_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_debug_dump_pfn,
                            "hwd_tunnel_debug_dump_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_decap_block_lock_pfn,
                            "hwd_tunnel_decap_block_lock")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_decap_block_unlock_pfn,
                            "hwd_tunnel_decap_block_unlock")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_encap_block_lock_pfn,
                            "hwd_tunnel_encap_block_lock")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_encap_block_unlock_pfn,
                            "hwd_tunnel_encap_block_unlock")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_counter_get_pfn,
                            "hwd_tunnel_counter_get_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_tunnel_mapping_add_pfn,
                            "hwd_tunnel_tunnel_mapping_add_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_tunnel_mapping_update_pfn,
                            "hwd_tunnel_tunnel_mapping_update_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_tunnel_mapping_delete_pfn,
                            "hwd_tunnel_tunnel_mapping_delete_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_port_isolate_hw_set_pfn,
                            "hwd_tunnel_port_isolate_hw_set_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_ttl_set_pfn,
                            "hwd_tunnel_ttl_set_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_ttl_get_pfn,
                            "hwd_tunnel_ttl_get_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_hash_set_pfn,
                            "hwd_tunnel_hash_set_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_hash_get_pfn,
                            "hwd_tunnel_hash_get_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_cos_set_pfn,
                            "hwd_tunnel_cos_set_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_cos_get_pfn,
                            "hwd_tunnel_cos_get_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_debug_dump_pfn, "hwd_tunnel_debug_dump_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_counter_clear_pfn, "hwd_tunnel_counter_clear_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_nve_reg_deinit_pfn, "hwd_tunnel_nve_reg_deinit_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_issu_vni_set_pfn, "hwd_tunnel_issu_vni_set_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /*
     * hwd_tunnel_nve_loopback_filter_set_pfn can be NULL
     * hwd_tunnel_nve_port_issu_end_set_pfn can be NULL
     */

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_nve_group_size_flood_get_pfn,
                            "hwd_tunnel_nve_group_size_flood_get_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(hwd_tunnel_ops_p->hwd_tunnel_nve_group_size_mc_get_pfn,
                            "hwd_tunnel_nve_group_size_mc_get_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* hwd_tunnel_zeroed_reserved_tngee_index_get_pfn can be NULL */

    g_hwd_tunnel_ops = *hwd_tunnel_ops_p;
    g_hwd_tunnel_ops_init = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_unregister_hwd_ops(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE == g_is_tunnel_initialized) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("Failed to unregister HWD ops\n");
        goto out;
    }

    g_hwd_tunnel_ops_init = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_register_tunnel_ops(tunnel_ops_t * ops_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(ops_p->hwi_tunnel_impl_prepare_create_pfn,
                            "hwi_tunnel_impl_prepare_create_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwi_tunnel_impl_prepare_create_rollback_pfn,
                            "hwi_tunnel_impl_prepare_create_rollback_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwi_tunnel_impl_delete_action_pfn,
                            "hwi_tunnel_impl_delete_action_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwi_tunnel_impl_delete_action_rollback_pfn,
                            "hwi_tunnel_impl_delete_action_rollback_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwi_tunnel_impl_edit_action_pfn,
                            "hwi_tunnel_impl_edit_action_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwi_tunnel_impl_edit_action_rollback_pfn,
                            "hwi_tunnel_impl_edit_action_rollback_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwi_tunnel_impl_check_learn_mode_pfn,
                            "hwi_tunnel_impl_check_learn_mode_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* hwi_tunnel_impl_check_init_params_pfn can be NULL */

    if (utils_check_pointer(ops_p->hwi_tunnel_impl_attr_validate_pfn,
                            "hwi_tunnel_impl_attr_validate_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    g_tunnel_ops = *ops_p;
    g_tunnel_ops_init = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_unregister_tunnel_ops(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE == g_is_tunnel_initialized) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("Failed to unregister tunnel ops\n");
        goto out;
    }

    g_tunnel_ops_init = FALSE;
    SX_MEM_CLR(g_tunnel_ops);

out:
    SX_LOG_EXIT();
    return err;
}

/* Validate if current tunnel support all capabilities from mask */
sx_status_t sdk_tunnel_impl_capability_check(sx_tunnel_id_t tunnel_id, uint64_t capability_mask)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint64_t    err_cap_mask = 0;
    uint32_t    direction = SX_TUNNEL_DIRECTION_GET(tunnel_id);
    uint32_t    type = SX_TUNNEL_TYPE_ID_GET(tunnel_id);

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel[0x%08x] capability[%" PRIu64 "] check\n", tunnel_id, capability_mask);

    if ((SX_TUNNEL_DIRECTION_CHECK_RANGE(direction) == FALSE) ||
        (SX_TUNNEL_TYPE_CHECK_RANGE(type) == FALSE) ||
        (capability_mask == 0)) {
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err_cap_mask = (((g_tunnel_cap_by_type_support[type] & capability_mask) ^ capability_mask) |
                    (g_tunnel_cap_by_direction_support[direction] & capability_mask));

    if (err_cap_mask != 0) {
        sx_status = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Tunnel [0x%08x] does not support %s\n", tunnel_id, __print_tunnel_capability(err_cap_mask));
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_ref_increase(sx_tunnel_id_t    tunnel_id,
                                         ref_name_data_t * ref_name_data,
                                         sdk_ref_t       * ref_p,
                                         uint64_t          capability_mask)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(capability_mask);

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel[0x%08x] increase reference\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(ref_name_data, "ref_name_data")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ref_p, "ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sdk_tunnel_impl_capability_check(tunnel_id, capability_mask);
    if (SX_STATUS_SUCCESS != err) {
        goto out;
    }

    err = sdk_tunnel_db_ref_increase(tunnel_id, ref_name_data, ref_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to tunnel[0x%08x] increase reference, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_ref_decrease(sx_tunnel_id_t tunnel_id, const sdk_ref_t * ref_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel[0x%08x] reference decrease\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(ref_p, "ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sdk_tunnel_db_ref_decrease(tunnel_id, ref_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to decrease tunnel[0x%08x] reference, err = %s\n",
                   tunnel_id, sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_hw_decap_lock(sx_tunnel_id_t tunnel_id, hwd_tunnel_decap_index_t * tunnel_hwd_index_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle;

    SX_LOG_ENTER();
    SX_LOG_DBG("Lock decap index for tunnel[0x%08x] \n", tunnel_id);

    SX_MEM_CLR(tunnel_decap_handle);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(tunnel_hwd_index_p, "tunnel_hwd_index_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sdk_tunnel_db_hw_decap_handle_get(tunnel_id, &tunnel_decap_handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to lock tunnel[0x%08x] HW decap handle, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (tunnel_decap_handle == SDK_TUNNEL_INVALID_DECAP_HWD_HDL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Invalid tunnel[0x%08x] HWD decap handle, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = g_hwd_tunnel_ops.hwd_tunnel_decap_block_lock_pfn(tunnel_decap_handle,
                                                           tunnel_hwd_index_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HWD decap block index, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_hw_decap_unlock(sx_tunnel_id_t tunnel_id)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    hwi_tunnel_hw_decap_handle_t tunnel_decap_handle = SDK_TUNNEL_INVALID_DECAP_HWD_HDL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Unlock decap index for tunnel[0x%08x] \n", tunnel_id);

    SX_MEM_CLR(tunnel_decap_handle);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_hw_decap_handle_get(tunnel_id, &tunnel_decap_handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW decap handle, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (tunnel_decap_handle == SDK_TUNNEL_INVALID_DECAP_HWD_HDL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Invalid tunnel[0x%08x] HWD decap handle, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = g_hwd_tunnel_ops.hwd_tunnel_decap_block_unlock_pfn(tunnel_decap_handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to unlock tunnel[0x%08x] HWD decap block index, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_hw_encap_lock(sx_tunnel_id_t tunnel_id, hwd_tunnel_encap_index_t * tunnel_hwd_index_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    hwi_tunnel_hw_encap_handle_t tunnel_encap_handle = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Lock encap index for tunnel[0x%08x] \n", tunnel_id);

    SX_MEM_CLR(tunnel_encap_handle);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(tunnel_hwd_index_p, "tunnel_hwd_index_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sdk_tunnel_db_hw_encap_handle_get(tunnel_id, &tunnel_encap_handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW encap handle, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (tunnel_encap_handle == SDK_TUNNEL_INVALID_ENCAP_HWD_HDL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Invalid tunnel[0x%08x] HWD encap handle, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = g_hwd_tunnel_ops.hwd_tunnel_encap_block_lock_pfn(tunnel_encap_handle,
                                                           tunnel_hwd_index_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HWD encap block index, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_hw_encap_unlock(sx_tunnel_id_t tunnel_id)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    hwi_tunnel_hw_encap_handle_t tunnel_encap_handle = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;

    SX_LOG_ENTER();
    SX_LOG_DBG("Unlock encap index for tunnel[0x%08x] \n", tunnel_id);

    SX_MEM_CLR(tunnel_encap_handle);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_hw_encap_handle_get(tunnel_id, &tunnel_encap_handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW encap handle, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (tunnel_encap_handle == SDK_TUNNEL_INVALID_ENCAP_HWD_HDL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Invalid tunnel[0x%08x] HWD encap handle, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = g_hwd_tunnel_ops.hwd_tunnel_encap_block_unlock_pfn(tunnel_encap_handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to unlock tunnel[0x%08x] HWD encap block index, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tunnel_impl_sfdb_hw_update(struct ku_sfdb_reg * sfdb_reg_data_p)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t sfdb_reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(sfdb_reg_meta);

    /* Go over leaf devices to set SFDB */
    sx_status = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Get LEAF devices list: (%s)\n",
                   sx_status_str(sx_status));
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sfdb_reg_meta.access_cmd = SXD_ACCESS_CMD_ADD;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    /* Let's do SFDB reg specific info */
    sfdb_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    /* SET SFDB reg */
    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SFDB_E, sfdb_reg_data_p, &sfdb_reg_meta, 1, NULL, NULL);

    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("SFDB register set failure sxd_err = %s, dev_id = %u \n",
                   SXD_STATUS_MSG(sxd_status), dev_info_arr[dev_idx].dev_id);
        sx_status = SXD_STATUS_TO_SX_STATUS(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    return sx_status;
}

static sx_status_t __tunnel_impl_fdb_bulk_update(cm_hw_type_t hw_type, cm_index_t old_index, cm_index_t new_index)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    struct ku_sfdb_reg sfdb_reg_data;

    SX_LOG_ENTER();

    SX_MEM_CLR(sfdb_reg_data);

    sfdb_reg_data.gfid = TRUE;
    sfdb_reg_data.update_type = SFD_BULK_UPDATE_TYPE_COUNTER_SET_E;
    sfdb_reg_data.parameter = SFDB_FILED_COUNTER_BUILD(hw_type, old_index);
    sfdb_reg_data.new_parameter = SFDB_FILED_COUNTER_BUILD(hw_type, new_index);

    sx_status = __tunnel_impl_sfdb_hw_update(&sfdb_reg_data);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to do global bulk update for FDB entries, "
                   "old counter index[%u], new counter index[%u], error %s\n",
                   sfdb_reg_data.parameter, sfdb_reg_data.new_parameter, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tunnel_impl_hw_rif_by_fid_get(sx_fid_t fid, boolean_t * v_rif_p, hwd_rif_id_t * hw_rif_id_p)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    sx_router_interface_t rif = rm_resource_global.router_rifs_dontcare;

    SX_LOG_ENTER();

    *v_rif_p = FALSE;
    *hw_rif_id_p = 0;

    status = sdk_fid_manager_rif_get(fid, &rif);
    if (status == SX_STATUS_SUCCESS) {
        status = sdk_router_cmn_rif_impl_is_enabled(rif, v_rif_p, hw_rif_id_p);
        if (status == SX_STATUS_ENTRY_NOT_FOUND) {
            status = SX_STATUS_SUCCESS;
            *v_rif_p = FALSE;
            *hw_rif_id_p = 0;
        } else if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to check a state of RIF[%u], error: %s \n", rif, sx_status_str(status));
            goto out;
        }
    } else if (status == SX_STATUS_ENTRY_NOT_FOUND) {
        /* In case we don't have a FID RIF on top of this FID */
        status = SX_STATUS_SUCCESS;
        *v_rif_p = FALSE;
        *hw_rif_id_p = 0;
    } else if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to get RIF ID for FID [%u], error: %s \n",
                   fid, sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __tunnel_impl_counter_relocate(sx_bridge_tunnel_counter_type_t counter_type,
                                                  sx_flow_counter_id_t            counter_id,
                                                  cm_hw_type_t                    hw_type,
                                                  cm_index_t                      old_index,
                                                  cm_index_t                      new_index,
                                                  boolean_t                     * encap_counter_was_relocated_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    const cl_qlist_t      *tunnel_mapping_counters_list_p = NULL;
    tunnel_mapping_item_t *entry_p = NULL;
    cl_list_item_t        *list_item_p = NULL;
    boolean_t              v_rif = FALSE;
    hwd_rif_id_t           hwd_rif_id = 0;

    SX_LOG_ENTER();

    *encap_counter_was_relocated_p = FALSE;

    rc = tunnel_mapping_counters_list_get(counter_type, counter_id, &tunnel_mapping_counters_list_p);
    if (rc != SX_STATUS_SUCCESS) {
        if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
            rc = SX_STATUS_SUCCESS;
        } else {
            SX_LOG_ERR("Failed to get a tunnel counter list for counter [%u], error: %s \n",
                       counter_id, sx_status_str(rc));
        }
        goto out;
    }

    list_item_p = cl_qlist_head(tunnel_mapping_counters_list_p);
    while (list_item_p != cl_qlist_end(tunnel_mapping_counters_list_p)) {
        if (counter_type == SX_BRIDGE_COUNTER_TUNNEL_DECAP_E) {
            entry_p = PARENT_STRUCT(list_item_p, tunnel_mapping_item_t, decap_flow_counter_list_item);

            rc = __tunnel_impl_hw_rif_by_fid_get(entry_p->map_entry.params.nve.bridge_id, &v_rif, &hwd_rif_id);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get HW RIF ID by FID [%u], error: %s\n",
                           entry_p->map_entry.params.nve.bridge_id, sx_status_str(rc));
                goto out;
            }

            rc = sdk_fid_manager_tunnel_decap_mapping_set(SX_ACCESS_CMD_EDIT, entry_p->map_entry.params.nve.bridge_id,
                                                          entry_p->map_entry.params.nve.vni,
                                                          hw_type, new_index,
                                                          v_rif, hwd_rif_id);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to relocate decap counter [%u] for FID (%u), err = %s\n",
                           counter_id, entry_p->map_entry.params.nve.bridge_id, sx_status_str(rc));
                goto out;
            }
        } else {
            /* counter_type == SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E or SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E */

            rc = __tunnel_impl_fdb_bulk_update(hw_type, old_index, new_index);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to relocate %s counter [%u] for FID (%u), err = %s\n",
                           sx_bridge_tunnel_counter_type_str(counter_type), counter_id,
                           entry_p->map_entry.params.nve.bridge_id, sx_status_str(rc));
                goto out;
            }

            *encap_counter_was_relocated_p = TRUE;

            /* We did global update on all FIDs of all FDB entries: UC and MC for given counter,
             * so no need to iterate over other tunnel mapping for other FIDs */
            break;
        }

        list_item_p = cl_qlist_next(list_item_p);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __tunnel_impl_counter_relocate_cb(cm_logical_id_t lid,
                                                     uint32_t        offset,
                                                     cm_type_e       type,
                                                     cm_hw_type_t    hw_type,
                                                     cm_index_t      old_index,
                                                     cm_index_t      new_index)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sx_flow_counter_id_t counter_id = LID_OFFSET_TO_FLOW_CNTR_ID(lid, offset);
    boolean_t            encap_counter_was_relocated = FALSE;

    UNUSED_PARAM(type);

    SX_LOG_ENTER();

    rc = __tunnel_impl_counter_relocate(SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E, counter_id,
                                        hw_type, old_index, new_index, &encap_counter_was_relocated);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to relocate counter [%u] for the encap UC direction. \n", counter_id);
        goto out;
    }

    if (encap_counter_was_relocated == FALSE) {
        rc = __tunnel_impl_counter_relocate(SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E, counter_id,
                                            hw_type, old_index, new_index, &encap_counter_was_relocated);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to relocate counter [%u] for the encap MC direction. \n", counter_id);
            goto out;
        }
    }

    rc = __tunnel_impl_counter_relocate(SX_BRIDGE_COUNTER_TUNNEL_DECAP_E, counter_id,
                                        hw_type, old_index, new_index, &encap_counter_was_relocated);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to relocate counter [%u] for the decap direction. \n", counter_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* SET/DELETE tunnel bridge counter */
sx_status_t sdk_tunnel_impl_fid_counter_set(const sx_access_cmd_t           cmd,
                                            sx_tunnel_id_t                  tunnel_id,
                                            sx_fid_t                        fid,
                                            sx_bridge_tunnel_counter_type_t counter_type,
                                            sx_flow_counter_id_t            counter_id)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_flow_counter_id_t counter_id_set = SX_FLOW_COUNTER_ID_INVALID;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (fid == SX_FID_ID_INVALID) {
        SX_LOG_ERR("Invalid FID [%u]\n", fid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        counter_id_set = counter_id;
        break;

    case SX_ACCESS_CMD_UNBIND:
        counter_id_set = SX_FLOW_COUNTER_ID_INVALID;
        break;

    default:
        SX_LOG_ERR("Failed to set tunnel bridge counter. Unsupported CMD:%s\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_tunnel_db_fid_counter_set(tunnel_id, fid, counter_type, counter_id_set);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to set tunnel bridge counter for tunnel[0x%08x] FID[0x%08x] err = %s\n",
                   tunnel_id, fid, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

/* Get tunnel FID counter */
sx_status_t sdk_tunnel_impl_fid_counter_get(sx_tunnel_id_t                  tunnel_id,
                                            sx_fid_t                        fid,
                                            sx_bridge_tunnel_counter_type_t counter_type,
                                            sx_flow_counter_id_t           *counter_id_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(counter_id_p, "counter_id_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (SX_TUNNEL_ID_RANGE_CHECK(tunnel_id) != TRUE) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (fid == SX_FID_ID_INVALID) {
        SX_LOG_ERR("Invalid FID [%u]\n", fid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_fid_counter_get(tunnel_id, fid, counter_type, counter_id_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel bridge counter for tunnel[0x%08x] FID[0x%08x] err = %s\n",
                   tunnel_id, fid, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

void sdk_tunnel_impl_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    boolean_t                   is_tunnel_init_done = FALSE;
    sx_tunnel_general_params_t *gen_param;
    FILE                       *stream = NULL;

    SX_LOG_ENTER();

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "HWI TUNNEL");

    sdk_tunnel_impl_params_get(&is_tunnel_init_done);
    dbg_utils_pprinter_field_print(stream, "Module initialized", &is_tunnel_init_done, PARAM_BOOL_E);

    if (FALSE == is_tunnel_init_done) {
        /* Error stays success */
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    gen_param = &g_sdk_tunnel_init_params.general_param;
    dbg_utils_pprinter_general_header_print(stream, "IPinIP tunnel module general params");
    dbg_utils_pprinter_field_print(stream, "encap flow label",
                                   &gen_param->ipinip.encap_flowlabel,
                                   PARAM_UINT16_E);

    dbg_utils_pprinter_field_print(stream, "encap GRE hash",
                                   &gen_param->ipinip.encap_gre_hash,
                                   PARAM_UINT32_E);

    dbg_utils_pprinter_general_header_print(stream, "NVE tunnel module general params");
    dbg_utils_pprinter_field_print(stream, "encap source port",
                                   &gen_param->nve.encap_sport,
                                   PARAM_UINT8_E);

    dbg_utils_pprinter_field_print(stream, "encap flow label",
                                   &gen_param->nve.encap_flowlabel,
                                   PARAM_UINT16_E);

    dbg_utils_pprinter_field_print(stream, "flood ecmp enabled",
                                   &gen_param->nve.flood_ecmp_enabled,
                                   PARAM_BOOL_E);

    dbg_utils_pprinter_field_print(stream, "mc ecmp enabled",
                                   &gen_param->nve.mc_ecmp_enabled,
                                   PARAM_BOOL_E);

    dbg_utils_pprinter_field_print(stream, "FDB resolution action",
                                   sx_router_action_str(gen_param->nve.fdb_resolution_action),
                                   PARAM_STRING_E);

    dbg_utils_pprinter_field_print(stream, "FDB resolution valid",
                                   &gen_param->nve.fdb_resolution_valid,
                                   PARAM_BOOL_E);

    dbg_utils_pprinter_field_print(stream, "ecmp max size",
                                   &gen_param->nve.ecmp_max_size,
                                   PARAM_UINT32_E);

    sdk_tunnel_db_debug_dump(dbg_dump_params_p);

    decap_table_impl_dbg_generate_dump(dbg_dump_params_p);

    if (g_hwd_tunnel_ops.hwd_tunnel_debug_dump_pfn) {
        err = g_hwd_tunnel_ops.hwd_tunnel_debug_dump_pfn(dbg_dump_params_p);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to print debug dump of HWD tunnel, err= %s.\n", sx_status_str(err));
        }
    }

    sdk_ipv6_impl_debug_dump(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
}

sx_status_t sdk_tunnel_impl_mapping_add(const sx_tunnel_id_t          tunnel_id,
                                        const sx_tunnel_map_entry_t * map_entries_p,
                                        const uint32_t                map_entries_cnt)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_status_t              rollback_err = SX_STATUS_SUCCESS;
    uint32_t                 i = 0, j = 0;
    hwd_tunnel_encap_index_t tunnel_hwd_index = 0;
    boolean_t                db_mapping_add_rollback = FALSE;
    boolean_t                encap_lock_rollback = FALSE;
    boolean_t                hwd_mapping_add_rollback = FALSE;
    boolean_t                tun_map_set_rollback = FALSE;
    boolean_t                hw_unlocked_flag = FALSE;
    sx_fm_fid_type_t         fid_type = SX_FM_FID_TYPE_INVALID;
    hwd_tunnel_map_entry_t  *hwd_map_entries_p = NULL;
    sx_router_interface_t    rif = rm_resource_global.router_rifs_dontcare;
    sx_fdb_igmpv3_state_t    fid_igmpv3_state;

    SX_LOG_ENTER();

    if (map_entries_cnt == 0) {
        SX_LOG_ERR("Number of entries to add is 0 did not add any.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    hwd_map_entries_p = cl_calloc(map_entries_cnt, sizeof(*hwd_map_entries_p));
    if (hwd_map_entries_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for HWD mapping entries[%u] \n",
                   map_entries_cnt);
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    for (i = 0; i < map_entries_cnt; ++i) {
        if ((map_entries_p[i].type != SX_TUNNEL_TYPE_NVE_VXLAN) &&
            (map_entries_p[i].type != SX_TUNNEL_TYPE_NVE_VXLAN_IPV6) &&
            (map_entries_p[i].type != SX_TUNNEL_TYPE_NVE_NVGRE) &&
            (map_entries_p[i].type != SX_TUNNEL_TYPE_NVE_NVGRE_IPV6)) {
            SX_LOG_ERR("Entry type is not VXLAN and not NVGRE, all other types are not supported\n");
            err = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        err = sdk_fid_manager_get_fid_type(map_entries_p[i].params.nve.bridge_id, &fid_type);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not find FID[0x%08x] in the FID manager.\n",
                   map_entries_p[i].params.nve.bridge_id);
            goto out;
        }

        if ((fid_type != SX_FM_FID_TYPE_VLAN_REWRITE_E) &&
            (fid_type != SX_FM_FID_TYPE_BRIDGE_REWRITE_E)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG(SX_LOG_ERROR, "FID[0x%08x] has unsupported type[%s]. \n",
                   map_entries_p[i].params.nve.bridge_id, sx_fm_fid_type_str(fid_type));
            goto out;
        }

        if (!SX_TUNNEL_VNI_RANGE_CHECK(map_entries_p[i].params.nve.vni)) {
            SX_LOG_ERR("Invalid VNI [%u]\n", map_entries_p[i].params.nve.vni);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (fid_type == SX_FM_FID_TYPE_VLAN_REWRITE_E) {
            if ((map_entries_p[i].params.nve.direction != SX_TUNNEL_MAP_DIR_DECAP) &&
                (map_entries_p[i].params.nve.direction != SX_TUNNEL_MAP_DIR_BIDIR)) {
                SX_LOG_ERR("Invalid direction [%u]\n", map_entries_p[i].params.nve.direction);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        } else {
            if (map_entries_p[i].params.nve.direction != SX_TUNNEL_MAP_DIR_BIDIR) {
                SX_LOG_ERR("Invalid direction [%u]\n", map_entries_p[i].params.nve.direction);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
    }

    /* Update DB */
    err = sdk_tunnel_db_tunnel_mapping_add(tunnel_id, map_entries_p, map_entries_cnt);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to add, in tunnel DB, to tunnel[0x%08x] -- %d map entries, err = %s\n",
                   tunnel_id, map_entries_cnt, sx_status_str(err));
        goto out;
    }

    db_mapping_add_rollback = TRUE;

    for (i = 0; i < map_entries_cnt; ++i) {
        err = sdk_fid_manager_tunnel_set(SX_ACCESS_CMD_ADD, map_entries_p[i].params.nve.bridge_id, tunnel_id);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to set tunnel_id[0x%08x] for FID[0x%08x]\n",
                       tunnel_id, map_entries_p[i].params.nve.bridge_id);
            tun_map_set_rollback = TRUE;
            goto out;
        }
        SX_MEM_CPY(hwd_map_entries_p[i].map_entry, map_entries_p[i]);

        err = sdk_tunnel_db_fid_counter_get(tunnel_id, map_entries_p[i].params.nve.bridge_id,
                                            SX_BRIDGE_COUNTER_TUNNEL_DECAP_E,
                                            &(hwd_map_entries_p[i].decap_flow_counter_id));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get decap counter for FID[%u], error: %s \n",
                       map_entries_p[i].params.nve.bridge_id, sx_status_str(err));
            goto out;
        }

        err = sdk_fid_manager_rif_get(map_entries_p[i].params.nve.bridge_id, &rif);
        if (err == SX_STATUS_SUCCESS) {
            err = sdk_router_cmn_rif_impl_is_enabled(rif, &hwd_map_entries_p[i].v_rif,
                                                     &hwd_map_entries_p[i].hw_rif_id);
            if (err == SX_STATUS_ENTRY_NOT_FOUND) {
                err = SX_STATUS_SUCCESS;
                hwd_map_entries_p[i].v_rif = FALSE;
                hwd_map_entries_p[i].hw_rif_id = 0;
            } else if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to check a state of RIF[%u], error: %s \n", rif, sx_status_str(err));
                goto out;
            }
        } else if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            err = SX_STATUS_SUCCESS;
            hwd_map_entries_p[i].v_rif = FALSE;
            hwd_map_entries_p[i].hw_rif_id = 0;
        } else if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get RIF ID for FID [%u], error: %s \n",
                       map_entries_p[i].params.nve.bridge_id, sx_status_str(err));
            goto out;
        }
    }

    tun_map_set_rollback = TRUE;

    err = sdk_tunnel_impl_hw_encap_lock(tunnel_id, &tunnel_hwd_index);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to (encap) lock the tunnel[0x%08x], err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    encap_lock_rollback = TRUE;

    err = g_hwd_tunnel_ops.hwd_tunnel_tunnel_mapping_add_pfn(tunnel_id, hwd_map_entries_p, map_entries_cnt);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to add (in HW) to tunnel[0x%08x] -- %u map entries, err = %s\n", tunnel_id, map_entries_cnt,
                   sx_status_str(err));
        goto out;
    }

    hwd_mapping_add_rollback = TRUE;

    err = sdk_tunnel_impl_hw_encap_unlock(tunnel_id);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to (encap) unlock the tunnel[0x%08x], err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    hw_unlocked_flag = TRUE;

    /* Support restore VLAN functionality - add ACL rule (convert VNI->VLAN)*/
    for (i = 0; i < map_entries_cnt; i++) {
        err = igmpv3_fid_to_vid_state_get(map_entries_p[i].params.nve.bridge_id, &fid_igmpv3_state);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to igmpv3_fid_to_vid_state_get (ADD: FID=%d), rc = %s\n",
                       map_entries_p[i].params.nve.bridge_id, sx_status_str(err));
            goto out;
        }

        if (fid_igmpv3_state == SX_FDB_IGMPV3_STATE_ENABLE_E) {
            err = sdk_igmpv3_tunnel_map_vni_to_fid_set_wrap(SX_ACCESS_CMD_ADD,
                                                            map_entries_p[i].params.nve.bridge_id,
                                                            0);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to sdk_igmpv3_tunnel_map_vni_to_fid_set (ADD: FID=%d), rc = %s\n",
                           map_entries_p[i].params.nve.bridge_id, sx_status_str(err));
                goto out;
            }
        } /* if(fid_igmpv3_state == SX_FDB_IGMPV3_STATE_ENABLE_E) */
    } /* for(i = 0; i < map_entries_cnt; i++) */

out:
    if (SX_STATUS_SUCCESS != err) {
        if (hwd_mapping_add_rollback) {
            /* coverity[dead_error_condition] */
            if (hw_unlocked_flag) {
                /* coverity[dead_error_begin] */
                rollback_err = sdk_tunnel_impl_hw_encap_lock(tunnel_id, &tunnel_hwd_index);
                if (SX_STATUS_SUCCESS != rollback_err) {
                    SX_LOG_ERR("Failed to rollback add mapping to tunnel[0x%08x] - can't (encap) lock the tunnel\n",
                               tunnel_id);
                    return err;
                }
            }

            rollback_err = g_hwd_tunnel_ops.hwd_tunnel_tunnel_mapping_delete_pfn(tunnel_id,
                                                                                 hwd_map_entries_p,
                                                                                 map_entries_cnt);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to rollback add (in HW) to tunnel[0x%08x] -- %u map entries, err = %s\n",
                           tunnel_id, map_entries_cnt, sx_status_str(rollback_err));
            }
        }

        if (encap_lock_rollback) {
            rollback_err = sdk_tunnel_impl_hw_encap_unlock(tunnel_id);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to (encap) unlock the tunnel[0x%08x], err = %s\n", tunnel_id,
                           sx_status_str(rollback_err));
            }
        }

        if (tun_map_set_rollback) {
            for (j = 0; j < i; ++j) {
                rollback_err = sdk_fid_manager_tunnel_set(SX_ACCESS_CMD_DELETE,
                                                          map_entries_p[j].params.nve.bridge_id,
                                                          tunnel_id);
                if (SX_STATUS_SUCCESS != rollback_err) {
                    SX_LOG_ERR("Failed to delete tunnel_id[0x%08x] from FID[0x%08x], err = %s\n", tunnel_id,
                               map_entries_p[j].params.nve.bridge_id, sx_status_str(rollback_err));
                }
            }
        }

        if (db_mapping_add_rollback) {
            rollback_err = sdk_tunnel_db_tunnel_mapping_delete(tunnel_id, map_entries_p, map_entries_cnt);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to delete, in tunnel DB (Rollback), from tunnel[0x%08x] -- %u map entries, err = %s\n",
                    tunnel_id,
                    map_entries_cnt,
                    sx_status_str(rollback_err));
            }
        }
    }

    if (hwd_map_entries_p != NULL) {
        CL_FREE_N_NULL(hwd_map_entries_p);
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tunnel_impl_mapping_delete_internal(const sx_tunnel_id_t          tunnel_id,
                                                      const sx_tunnel_map_entry_t * map_entries_p,
                                                      const uint32_t                map_entries_cnt,
                                                      boolean_t                     fatal_error)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_status_t              rollback_err = SX_STATUS_SUCCESS;
    hwd_tunnel_encap_index_t tunnel_hwd_index = 0;
    boolean_t                encap_lock_rollback = FALSE;
    boolean_t                hwd_mapping_del_rollback = FALSE;
    boolean_t                fid_tun_map_del_rollback = FALSE;
    boolean_t                hw_unlocked_flag = FALSE;
    uint32_t                 i = 0, j = 0;
    sx_port_log_id_t         log_port = 0;
    hwd_tunnel_map_entry_t  *hwd_map_entries_p = NULL;
    sx_fdb_igmpv3_state_t    fid_igmpv3_state;

    SX_LOG_ENTER();

    if (map_entries_cnt == 0) {
        SX_LOG_DBG("Number of entries to delete is 0.\n");
        goto out;
    }

    /* Get log port from tunnel ID */
    err = sdk_tunnel_impl_log_port_by_tunnel_id_get(tunnel_id, &log_port);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get log_port for tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    hwd_map_entries_p = cl_calloc(map_entries_cnt, sizeof(*hwd_map_entries_p));
    if (hwd_map_entries_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for HWD mapping entries[%u]\n",
                   map_entries_cnt);
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    for (i = 0; i < map_entries_cnt; ++i) {
        if (g_ld_enabled == TRUE) {
            /* Unbind existing flow counter from tunnel map entry if lazy delete enabled*/
            err = sdk_tunnel_db_mapping_unbind_flow_counters(tunnel_id,
                                                             map_entries_p[i].params.nve.bridge_id);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to unbind flow counters on the tunnel_map entry (tunnel=0x%08x; FID=%d; err=%s).\n",
                           tunnel_id, map_entries_p[i].params.nve.bridge_id, sx_status_str(err));
                goto out;
            }
        }

        if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id)) {
            /* Flush ageable FDB entries */
            err = fdb_flush_ageable_tunnel_mapping_macs_set(log_port, map_entries_p[i].params.nve.bridge_id);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to flush FDB by log_port[%u] for tunnel[0x%08x], err = %s\n",
                           log_port, tunnel_id, sx_status_str(err));
                goto out;
            }
        }

        err = sdk_fid_manager_tunnel_set(SX_ACCESS_CMD_DELETE, map_entries_p[i].params.nve.bridge_id, tunnel_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to delete tunnel_id(0x%08x) for fid(%d)\n",
                       tunnel_id, map_entries_p[i].params.nve.bridge_id);
            fid_tun_map_del_rollback = TRUE;
            goto out;
        }

        SX_MEM_CPY(hwd_map_entries_p[i].map_entry, map_entries_p[i]);
        hwd_map_entries_p[i].decap_flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;
        hwd_map_entries_p[i].v_rif = FALSE;
        hwd_map_entries_p[i].hw_rif_id = 0;

        /* Support restore VLAN functionality - delete ACL rule (convert VNI->VLAN*/
        err = igmpv3_fid_to_vid_state_get(map_entries_p[i].params.nve.bridge_id, &fid_igmpv3_state);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to igmpv3_fid_to_vid_state_get (DEL: FID=%d), rc = %s\n",
                       map_entries_p[i].params.nve.bridge_id, sx_status_str(err));
            goto out;
        }

        if (fid_igmpv3_state == SX_FDB_IGMPV3_STATE_ENABLE_E) {
            err = sdk_igmpv3_tunnel_map_vni_to_fid_set_wrap(SX_ACCESS_CMD_DELETE,
                                                            map_entries_p[i].params.nve.bridge_id,
                                                            0);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to sdk_igmpv3_tunnel_map_vni_to_fid_set (DELETE: FID=%d), rc = %s\n",
                           map_entries_p[i].params.nve.bridge_id, sx_status_str(err));
                goto out;
            }
        } /* if(fid_igmpv3_state == SX_FDB_IGMPV3_STATE_ENABLE_E) */
    }

    fid_tun_map_del_rollback = TRUE;

    err = sdk_tunnel_impl_hw_encap_lock(tunnel_id, &tunnel_hwd_index);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to (encap) lock the tunnel[0x%08x], err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }
    encap_lock_rollback = TRUE;

    err = g_hwd_tunnel_ops.hwd_tunnel_tunnel_mapping_delete_pfn(tunnel_id, hwd_map_entries_p, map_entries_cnt);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to (HWD) delete from tunnel[0x%08x] -- %d map entries, err = %s\n",
                   tunnel_id,
                   map_entries_cnt,
                   sx_status_str(err));
        goto out;
    }
    hwd_mapping_del_rollback = TRUE;

    err = sdk_tunnel_impl_hw_encap_unlock(tunnel_id);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to (encap) unlock the tunnel[0x%08x], err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }
    hw_unlocked_flag = TRUE;

    /* Update DB */
    err = sdk_tunnel_db_tunnel_mapping_delete(tunnel_id, map_entries_p, map_entries_cnt);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to delete, in tunnel DB, from tunnel[0x%08x] -- %d map entries, err = %s\n",
                   tunnel_id, map_entries_cnt, sx_status_str(err));
        goto out;
    }

out:
    if ((SX_STATUS_SUCCESS != err) && (fatal_error == FALSE)) {
        if (hwd_mapping_del_rollback) {
            if (hw_unlocked_flag) {
                rollback_err = sdk_tunnel_impl_hw_encap_lock(tunnel_id, &tunnel_hwd_index);
                if (SX_STATUS_SUCCESS == rollback_err) {
                    SX_LOG_ERR("Failed to rollback del mapping to tunnel - "
                               "can't (encap) lock the tunnel[0x%08x]\n", tunnel_id);
                    return err;
                }
            }

            rollback_err = g_hwd_tunnel_ops.hwd_tunnel_tunnel_mapping_add_pfn(tunnel_id,
                                                                              hwd_map_entries_p,
                                                                              map_entries_cnt);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR(
                    "Failed to rollback del mapping to tunnel - "
                    "can't add (in HW) to tunnel[0x%08x] -- %u map entries, err = %s\n",
                    tunnel_id, map_entries_cnt,
                    sx_status_str(rollback_err));
            }
        }

        if (encap_lock_rollback) {
            rollback_err = sdk_tunnel_impl_hw_encap_unlock(tunnel_id);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to rollback del mapping to tunnel - "
                           "can't (encap) unlock the tunnel[0x%08x], err = %s\n", tunnel_id,
                           sx_status_str(rollback_err));
            }
        }

        if (fid_tun_map_del_rollback) {
            for (j = 0; j < i; ++j) {
                rollback_err = sdk_fid_manager_tunnel_set(SX_ACCESS_CMD_ADD,
                                                          map_entries_p[j].params.nve.bridge_id,
                                                          tunnel_id);
                if (SX_STATUS_SUCCESS != rollback_err) {
                    SX_LOG_ERR("Failed to rollback del mapping to tunnel - "
                               "can't add the tunnel[0x%08x] to FID[0x%08x], err = %s\n",
                               map_entries_p[j].params.nve.bridge_id,
                               tunnel_id,
                               sx_status_str(rollback_err));
                }
            }
        }
    }

    if (hwd_map_entries_p != NULL) {
        CL_FREE_N_NULL(hwd_map_entries_p);
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tunnel_impl_mapping_lazy_delete(const sx_tunnel_id_t          tunnel_id,
                                                  const sx_tunnel_map_entry_t * map_entries_p,
                                                  const uint32_t                map_entries_cnt)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    uint32_t        mapping_refcount = 0;
    boolean_t       pending_delete = FALSE;
    uint32_t        i = 0, j = 0;
    sx_event_info_t event_info;

    SX_LOG_ENTER();

    SX_MEM_CLR(event_info.deleted_object);

    for (i = 0; i < map_entries_cnt; i++) {
        err = sdk_tunnel_db_tunnel_mapping_pending_delete_get(tunnel_id, &map_entries_p[i], &pending_delete);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x] map entry for FID[%u], err = %s\n",
                       tunnel_id, map_entries_p[i].params.nve.bridge_id, sx_status_str(err));
            goto out;
        }

        if (pending_delete == TRUE) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to delete the tunnel[0x%08x] map entry for FID[%u], err = %s\n",
                       tunnel_id, map_entries_p[i].params.nve.bridge_id, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_mapping_ref_cnt_get(tunnel_id, map_entries_p[i].params.nve.bridge_id,
                                                &mapping_refcount);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get the tunnel[0x%08x] map ref count for FID[%u] from DB, err = %s\n",
                       tunnel_id, map_entries_p[i].params.nve.bridge_id, sx_status_str(err));
            goto out;
        }

        if (0 != mapping_refcount) {
            err = sdk_tunnel_db_tunnel_mapping_pending_delete_set(tunnel_id, &(map_entries_p[i]), TRUE);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to set pending delete on the tunnel[0x%08x], err= %s.\n",
                           tunnel_id, sx_status_str(err));
            }
            continue;
        } else {
            err = __sdk_tunnel_impl_mapping_delete_internal(tunnel_id, &(map_entries_p[i]), 1, TRUE);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed delete a tunnel mapping - [0x%08x], err = %s\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }

            event_info.deleted_object.object_cnt++;
            event_info.deleted_object.object[j].object_type = SX_OBJECT_TYPE_TUNNEL_MAP_OBJECT;
            event_info.deleted_object.object[j].object_id.tunnel_map_object.tunnel_id = tunnel_id;
            SX_MEM_CPY(event_info.deleted_object.object[j].object_id.tunnel_map_object.map_entry, map_entries_p[i]);
            j++;
        }

        /* if (( there are no more map entries to delete AND event_info is not empty ) OR
         *      ( event_info is full )) { send a notification to user } */
        if ((((i + 1) >= map_entries_cnt) && (j > 0)) ||
            (j >= SX_EVENT_DELETED_OBJECT_CNT_MAX)) {
            err = host_ifc_send_event(SX_TRAP_ID_OBJECT_DELETED_EVENT,
                                      &(event_info.deleted_object),
                                      sizeof(event_info.deleted_object),
                                      SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Could not send the OBJECT_DELETED_EVENT event for tunnel[0x%08x], err = [%s]\n",
                           tunnel_id, sx_status_str(err));
                goto out;
            }

            SX_MEM_CLR(event_info);
            j = 0;
        }
    } /* for (i = 0; i < map_entries_cnt; ++i) */

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_mapping_delete(const sx_tunnel_id_t          tunnel_id,
                                           const sx_tunnel_map_entry_t * map_entries_p,
                                           const uint32_t                map_entries_cnt)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_ld_enabled == FALSE) {
        err = sdk_tunnel_db_tunnel_mapping_check_if_can_deleted(tunnel_id, map_entries_p, map_entries_cnt);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to check if all tunnel[0x%08x] map entries can be deleted, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = __sdk_tunnel_impl_mapping_delete_internal(tunnel_id, map_entries_p, map_entries_cnt, FALSE);
    } else {
        err = __sdk_tunnel_impl_mapping_lazy_delete(tunnel_id, map_entries_p, map_entries_cnt);
    }

    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to delete tunnel[0x%08x] map entries, err = %s\n",
                   tunnel_id, sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_mapping_delete_all(const sx_tunnel_id_t tunnel_id)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_status_t            out_err = SX_STATUS_SUCCESS;
    sx_tunnel_map_entry_t *map_entry_p = NULL;
    uint32_t               map_entry_cnt;

    SX_LOG_ENTER();

    err = sdk_tunnel_db_map_entries_list_get(tunnel_id, NULL, &map_entry_cnt, FALSE);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get count of map list from tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (map_entry_cnt == 0) {
        err = SX_STATUS_SUCCESS;
        SX_LOG_DBG("Tunnel %d mapping table is empty.\n", tunnel_id);
        goto out;
    }

    err = utils_memory_get((void**)&map_entry_p,
                           map_entry_cnt * sizeof(sx_tunnel_map_entry_t),
                           UTILS_MEM_TYPE_ID_TUNNEL_E);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to allocate memory for map_entry_list, err = %s\n", sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_db_map_entries_list_get(tunnel_id, map_entry_p, &map_entry_cnt, FALSE);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get map list from tunnel[0x%08x], err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    if (g_ld_enabled == FALSE) {
        err = sdk_tunnel_db_tunnel_mapping_check_if_can_deleted(tunnel_id, map_entry_p, map_entry_cnt);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to check if all tunnel[0x%08x] map entries can be deleted, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = __sdk_tunnel_impl_mapping_delete_internal(tunnel_id, map_entry_p, map_entry_cnt, FALSE);
    } else {
        err = __sdk_tunnel_impl_mapping_lazy_delete(tunnel_id, map_entry_p, map_entry_cnt);
    }

    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to delete all tunnel[0x%08x] map entries, err = %s\n",
                   tunnel_id, sx_status_str(err));
    }

out:
    if (map_entry_p) {
        out_err = utils_memory_put(map_entry_p, UTILS_MEM_TYPE_ID_TUNNEL_E);
        if (out_err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to deallocate memory for map_entry_p - OUT, err = %s\n", sx_status_str(out_err));
        }
        map_entry_p = NULL;
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_mapping_get_first(const sx_tunnel_id_t    tunnel_id,
                                              sx_tunnel_map_entry_t * map_entries_p,
                                              uint32_t              * map_entries_cnt)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_tunnel_db_tunnel_mapping_get_first(tunnel_id, map_entries_p, map_entries_cnt);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] first %d map entries, err = %s\n",
                   tunnel_id, *map_entries_cnt, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_mapping_get_next(const sx_tunnel_id_t    tunnel_id,
                                             sx_tunnel_map_entry_t   map_entry_key,
                                             sx_tunnel_map_entry_t * map_entries_p,
                                             uint32_t              * map_entries_cnt)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_tunnel_db_tunnel_mapping_get_next(tunnel_id, map_entry_key, map_entries_p, map_entries_cnt);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get the tunnel[0x%08x] next %x map entries from the given map_entry, err = %s\n",
                   tunnel_id, *map_entries_cnt, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_mapping_get_by_fid(sx_tunnel_id_t          tunnel_id,
                                               sx_fid_t                fid,
                                               sx_tunnel_map_entry_t * map_entry)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(map_entry, "map_entry")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    err = sdk_tunnel_db_mapping_get_by_fid(tunnel_id, fid, map_entry);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get from tunnel[0x%08x] entry with FID %u , err = %s\n",
                   tunnel_id, fid, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_mapping_ref_cnt_increase(const sx_tunnel_id_t tunnel_id,
                                                     const sx_fid_t       fid,
                                                     ref_name_data_t    * ref_name_data,
                                                     sdk_ref_t          * ref_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   pending_delete = FALSE;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel[0x%08x] mapping_ref_cnt_increase FID [%u] \n", tunnel_id, fid);

    /* If SDK is in termination flow do nothing */
    if ((err = sdk_tunnel_check_terminated()) == SX_STATUS_SUCCESS) {
        goto out;
    }

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(ref_name_data, "ref_name_data")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ref_p, "ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_db_mapping_ref_cnt_increase(tunnel_id, fid, ref_name_data, ref_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to tunnel[0x%08x] increase mapping_ref_cnt reference, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_mapping_ref_cnt_decrease(const sx_tunnel_id_t tunnel_id,
                                                     const sx_fid_t       fid,
                                                     const sdk_ref_t    * ref_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Tunnel[0x%08x] mapping_ref_cnt_decrease bridge_id [%u]\n", tunnel_id, fid);

    /* If SDK is in termination flow do nothing */
    if ((err = sdk_tunnel_check_terminated()) == SX_STATUS_SUCCESS) {
        goto out;
    }

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(ref_p, "ref_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    err = sdk_tunnel_db_mapping_ref_cnt_decrease(tunnel_id, fid, ref_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to decrease tunnel[0x%08x] reference, err = %s\n",
                   tunnel_id, sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_port_isolate_set(const sx_access_cmd_t         cmd,
                                             const sx_swid_t               swid,
                                             const sx_device_id_t          device_id,
                                             const sx_port_log_id_t        log_port,
                                             const sx_port_isolate_table_e isolation_table,
                                             const sx_port_log_id_t      * port_list_p,
                                             const uint32_t                log_port_num)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        if (utils_check_pointer(port_list_p, "port_list_p")) {
            sx_status = SX_STATUS_PARAM_NULL;
            goto out;
        }

        if (log_port_num == 0) {
            SX_LOG_ERR("Failed to set NVE port isolate, port list is empty\n");
            sx_status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    if (SX_PORT_TYPE_TUNNEL != SX_PORT_TYPE_ID_GET(log_port)) {
        SX_LOG_ERR("Failed to set NVE port isolate, invalid log_port 0x%08x \n", log_port);
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    sx_status = g_hwd_tunnel_ops.hwd_tunnel_port_isolate_hw_set_pfn(cmd, swid, device_id, log_port,
                                                                    isolation_table,
                                                                    port_list_p, log_port_num);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set NVE port isolate, err = %s\n", sx_status_str(sx_status));
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_log_port_by_tunnel_id_get(sx_tunnel_id_t tunnel_id, sx_port_log_id_t * log_port_p)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    const sdk_db_tunnel_data_t *tunnel_params = NULL;

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!SX_TUNNEL_ID_RANGE_CHECK(tunnel_id)) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (utils_check_pointer(log_port_p, "log_port_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    sx_status = sdk_tunnel_db_get(tunnel_id, &tunnel_params, TRUE);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x], err = %s\n", tunnel_id,
                   sx_status_str(sx_status));
        goto out;
    }

    *log_port_p = tunnel_impl_get_l2_log_port(&tunnel_params->tun_attr);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_tunnel_id_by_log_port_get(sx_port_log_id_t log_port, sx_tunnel_id_t   * tunnel_id_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (log_port == SX_INVALID_PORT) {
        SX_LOG_ERR("Invalid log_port [0x%08x]\n", log_port);
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(tunnel_id_p, "tunnel_id_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    sx_status = sdk_tunnel_db_tunnel_id_by_log_port_get(log_port, tunnel_id_p);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_NTC("Failed to get tunnel_id by log_port(0x%08x), err = %s\n", log_port,
                   sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_ttl_set(const sx_tunnel_id_t tunnel_id, const sx_tunnel_ttl_data_t * ttl_data_p)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    hwi_tunnel_hw_decap_handle_t decap_handle = SDK_TUNNEL_INVALID_DECAP_HWD_HDL;
    hwi_tunnel_hw_encap_handle_t encap_handle = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;
    sx_tunnel_type_e             tun_type = SX_TUNNEL_TYPE_ID_GET(tunnel_id);

    SX_LOG_ENTER();

    /* Validate that tunnel support direction from the ttl_data */
    if ((SX_TUNNEL_DIRECTION_GET(tunnel_id) & ttl_data_p->direction) !=
        ttl_data_p->direction) {
        SX_LOG_ERR("Failed to set TTL for tunnel[0x%x], can't set direction[%d] for the tunnel\n",
                   tunnel_id, ttl_data_p->direction);
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    sx_status = sdk_tunnel_db_hw_decap_handle_get(tunnel_id, &decap_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW decap handle, err = %s\n",
                   tunnel_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_tunnel_db_hw_encap_handle_get(tunnel_id, &encap_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW encap handle, err = %s\n",
                   tunnel_id, sx_status_str(sx_status));
        goto out;
    }

    /* Set to HW */
    sx_status = g_hwd_tunnel_ops.hwd_tunnel_ttl_set_pfn(encap_handle, decap_handle,
                                                        ttl_data_p, tun_type);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set TTL on HW for tunnel[0x%x], err - %s\n", tunnel_id,
                   sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_ttl_get(const sx_tunnel_id_t tunnel_id, sx_tunnel_ttl_data_t * ttl_data_p)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    hwi_tunnel_hw_decap_handle_t decap_handle = SDK_TUNNEL_INVALID_DECAP_HWD_HDL;
    hwi_tunnel_hw_encap_handle_t encap_handle = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;
    sx_tunnel_type_e             tun_type = SX_TUNNEL_TYPE_ID_GET(tunnel_id);

    SX_LOG_ENTER();

    sx_status = sdk_tunnel_db_hw_decap_handle_get(tunnel_id, &decap_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW decap handle, err = %s\n",
                   tunnel_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_tunnel_db_hw_encap_handle_get(tunnel_id, &encap_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW encap handle, err = %s\n",
                   tunnel_id, sx_status_str(sx_status));
        goto out;
    }

    /* Get from HW */
    sx_status = g_hwd_tunnel_ops.hwd_tunnel_ttl_get_pfn(encap_handle, decap_handle, ttl_data_p, tun_type);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get TTL from HW for tunnel[0x%x], err - %s\n", tunnel_id,
                   sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_hash_set(const sx_tunnel_id_t tunnel_id, const sx_tunnel_hash_data_t * hash_data_p)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    hwi_tunnel_hw_decap_handle_t decap_handle = SDK_TUNNEL_INVALID_DECAP_HWD_HDL;
    hwi_tunnel_hw_encap_handle_t encap_handle = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;

    SX_LOG_ENTER();

    sx_status = sdk_tunnel_db_hw_decap_handle_get(tunnel_id, &decap_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW decap handle, err = %s\n",
                   tunnel_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_tunnel_db_hw_encap_handle_get(tunnel_id, &encap_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW encap handle, err = %s\n",
                   tunnel_id, sx_status_str(sx_status));
        goto out;
    }

    /* Set to HW */
    sx_status = g_hwd_tunnel_ops.hwd_tunnel_hash_set_pfn(encap_handle, decap_handle, hash_data_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set hash on HW for tunnel[0x%x], err - %s\n",
                   tunnel_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_hash_get(const sx_tunnel_id_t tunnel_id, sx_tunnel_hash_data_t * hash_data_p)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    hwi_tunnel_hw_decap_handle_t decap_handle = SDK_TUNNEL_INVALID_DECAP_HWD_HDL;
    hwi_tunnel_hw_encap_handle_t encap_handle = SDK_TUNNEL_INVALID_ENCAP_HWD_HDL;

    SX_LOG_ENTER();

    sx_status = sdk_tunnel_db_hw_decap_handle_get(tunnel_id, &decap_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW decap handle, err = %s\n",
                   tunnel_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_tunnel_db_hw_encap_handle_get(tunnel_id, &encap_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] HW encap handle, err = %s\n",
                   tunnel_id, sx_status_str(sx_status));
        goto out;
    }

    /* Get from HW */
    sx_status = g_hwd_tunnel_ops.hwd_tunnel_hash_get_pfn(encap_handle, decap_handle, hash_data_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get hash from HW for tunnel[0x%x], err - %s\n",
                   tunnel_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_cos_set(const sx_tunnel_id_t tunnel_id, const sx_tunnel_cos_data_t * cos_data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = g_hwd_tunnel_ops.hwd_tunnel_cos_set_pfn(SX_TUNNEL_TYPE_ID_GET(tunnel_id), cos_data_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to (HWD) set tunnel[0x%08x] -- CoS attribute, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_cos_get(const sx_tunnel_id_t tunnel_id, sx_tunnel_cos_data_t * cos_data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = g_hwd_tunnel_ops.hwd_tunnel_cos_get_pfn(tunnel_id, cos_data_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to (HWD) get tunnel[0x%08x] -- CoS attribute, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_zeroed_reserved_tngee_index_get(kvd_linear_manager_index_t * kvd_index_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(kvd_index_p, "kvd_index_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (g_hwd_tunnel_ops.hwd_tunnel_zeroed_reserved_tngee_index_get_pfn != NULL) {
        err = g_hwd_tunnel_ops.hwd_tunnel_zeroed_reserved_tngee_index_get_pfn(kvd_index_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get the KVD index of the reserved TNGEE entry, error: %s.\n",
                       sx_status_str(err));
            goto out;
        }
    } else {
        SX_LOG_ERR("Cannot get the KVD index of the reserved TNGEE entry on chip type %s.\n",
                   sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_mapping_exists(sx_tunnel_id_t tunnel_id, sx_fid_t fid)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    sx_tunnel_map_entry_t map_entry;
    boolean_t             pending_delete = FALSE;

    SX_MEM_CLR(map_entry);

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    sx_status = sdk_tunnel_db_mapping_get_by_fid(tunnel_id, fid, &map_entry);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to find a tunnel[0x%08x] map entry for FID[%u], err = %s\n",
                   tunnel_id, fid, sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_tunnel_db_tunnel_mapping_pending_delete_get(tunnel_id, &map_entry, &pending_delete);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x] map entry for FID[%u], err = %s\n",
                   tunnel_id, fid, sx_status_str(sx_status));
        goto out;
    }
    if (pending_delete) {
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_NTC("The tunnel[0x%08x] map entry for FID[%u] is marked for deletion, err = %s\n",
                   tunnel_id, fid, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_counter_get(const sx_tunnel_id_t  tunnel_id,
                                        boolean_t             is_clear,
                                        sx_tunnel_counter_t * counter)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    const sdk_db_tunnel_data_t *tunnel_params_p = NULL;
    sx_port_log_id_t            l2_log_port = 0;

    SX_LOG_ENTER();

    SX_LOG_DBG("Tunnel[0x%08x] impl counter get\n", tunnel_id);

    err = sdk_tunnel_db_get(tunnel_id, &tunnel_params_p, FALSE);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x], err = %s\n", tunnel_id,
                   sx_status_str(err));
        goto out;
    }

    /* Only L2 tunnels support counters */
    if ((!SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id)) &&
        (!SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id))) {
        goto out;
    }

    /* Get HW counter 1st and then use tunnel CB to complete */
    if (!g_hwd_tunnel_ops.hwd_tunnel_counter_get_pfn) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("hwd_tunnel_counter_get_pfn not initialized, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    l2_log_port = tunnel_impl_get_l2_log_port(&tunnel_params_p->tun_attr);
    err =
        g_hwd_tunnel_ops.hwd_tunnel_counter_get_pfn(is_clear, SX_PORT_PHY_ID_GET(l2_log_port), &counter->counter);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("hwd_tunnel_counter_get_pfn failed, err = %s\n",
                   sx_status_str(err));
        goto out;
    }
    counter->type = tunnel_params_p->tun_attr.type;

    if (!g_tunnel_ops.hwi_tunnel_impl_counter_get_pfn) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("hwi_tunnel_impl_counter_get_pfn not initialized, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = (g_tunnel_ops.hwi_tunnel_impl_counter_get_pfn(tunnel_id, tunnel_params_p, is_clear, counter));
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("hwd_tunnel_counter_get_pfn failed, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_assign_hwd_ops(void)
{
    sx_status_t err = SX_STATUS_MODULE_UNINITIALIZED;

    SX_LOG_ENTER();

    if (g_tunnel_ops.hwi_tunnel_impl_init_hwd_pfn == NULL) {
        SX_LOG_ERR("hwi_tunnel_impl_init_hwd_pfn not initialized, HWD ops assign error, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = g_tunnel_ops.hwi_tunnel_impl_init_hwd_pfn();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init tunnel. HWD ops assign error, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t spectrum2_tunnel_impl_rif_by_tunnel_id_get(const sx_tunnel_id_t    tunnel_id,
                                                       sx_router_interface_t * ingress_urif_p,
                                                       sx_router_interface_t * egress_urif_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    const sdk_db_tunnel_data_t *tunnel_params = NULL;
    sx_router_interface_t       ingress_underlay_rif = 0;
    sx_router_interface_t       egress_underlay_rif = 0;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_get(tunnel_id, &tunnel_params, TRUE);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x], err = %s\n", tunnel_id,
                   sx_status_str(err));
        goto out;
    }

    switch (tunnel_params->tun_attr.type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        ingress_underlay_rif = tunnel_params->tun_attr.attributes.vxlan.encap.underlay_rif;
        egress_underlay_rif = tunnel_params->tun_attr.attributes.vxlan.decap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        ingress_underlay_rif = tunnel_params->tun_attr.attributes.nvgre.encap.underlay_rif;
        egress_underlay_rif = tunnel_params->tun_attr.attributes.nvgre.decap.underlay_rif;
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        ingress_underlay_rif = tunnel_params->tun_attr.attributes.l2_flex.encap.underlay_rif;
        egress_underlay_rif = tunnel_params->tun_attr.attributes.l2_flex.decap.underlay_rif;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Wrong tunnel[0x%08x] type:%d, err = %s\n",
                   tunnel_id, tunnel_params->tun_attr.type, sx_status_str(err));
        goto out;
    }

    if (ingress_urif_p != NULL) {
        *ingress_urif_p = ingress_underlay_rif;
    }

    if (egress_urif_p != NULL) {
        *egress_urif_p = egress_underlay_rif;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t spectrum_tunnel_impl_rif_by_tunnel_id_get(const sx_tunnel_id_t    tunnel_id,
                                                      sx_router_interface_t * ingress_urif_p,
                                                      sx_router_interface_t * egress_urif_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t tunnel_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_attr);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_impl_get(tunnel_id, &tunnel_attr);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] attributes, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    switch (tunnel_attr.type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        if (ingress_urif_p != NULL) {
            *ingress_urif_p = SPECTRUM_NVE_URIF;
        }

        if (egress_urif_p != NULL) {
            *egress_urif_p = SPECTRUM_NVE_URIF;
        }

        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Wrong tunnel[0x%08x] type:%d, err = %s\n",
                   tunnel_id, tunnel_attr.type, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t tunnel_impl_rif_by_tunnel_id_get(const sx_tunnel_id_t    tunnel_id,
                                             sx_router_interface_t * encap_urif_p,
                                             sx_router_interface_t * decap_urif_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.tunnel_impl_rif_by_tunnel_id_get_cb != NULL) {
        err = brg_context.spec_cb_g.tunnel_impl_rif_by_tunnel_id_get_cb(tunnel_id,
                                                                        encap_urif_p, decap_urif_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in tunnel_impl_rif_by_tunnel_id_get_cb on chip type %s .\n",
                       sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
            return err;
        }
    } else {
        err = SX_STATUS_ERROR;
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t tunnel_impl_tunnel_info_get(const sx_tunnel_id_t tunnel_id, tunnel_info_t        *tunnel_info)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    const sdk_db_tunnel_data_t *tunnel_params = NULL;
    tunnel_flex_header_entry_t *tunnel_flex_header_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x] for tunnel info get\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_get(tunnel_id, &tunnel_params, TRUE);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] for tunnel info get, err = %s\n", tunnel_id,
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CLR_P(tunnel_info);

    tunnel_info->tunnel_id = tunnel_id;
    tunnel_info->tunnel_type = tunnel_params->tun_attr.type;

    err = tunnel_impl_get_underlay_rif(&tunnel_params->tun_attr, &tunnel_info->encap_urif);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get rif tunnel[0x%08x] tunnel info get, err = %s\n",
                   tunnel_id,
                   sx_status_str(err));
        goto out;
    }

    /* Get parameters relevant only for L2 tunnels */
    if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id) || SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        tunnel_info->port_tunnel_phy_id = SX_PORT_PHY_ID_GET(tunnel_impl_get_l2_log_port(&tunnel_params->tun_attr));

        if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
            tunnel_info->qos_profile = tunnel_params->tun_attr.attributes.l2_flex.tunnel_qos_profile.profile_id;

            err = sdk_tunnel_db_tunnel_flex_header_get(
                tunnel_params->tun_attr.attributes.l2_flex.encap.tunnel_flex_header_id,
                &tunnel_flex_header_entry_p);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to get tunnel[0x%08x] flex header [%u] for tunnel info get, err = %s\n",
                           tunnel_id,
                           tunnel_params->tun_attr.attributes.l2_flex.encap.tunnel_flex_header_id,
                           sx_status_str(err));
                goto out;
            }
            tunnel_info->emt_id = tunnel_flex_header_entry_p->header_cfg.tunnel_header_emt_id.emt_id;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tunnel_impl_issu_set(boolean_t encap)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    uint32_t                    tunnel_cnt = 0, i = 0, j = 0;
    sx_tunnel_id_t             *tunnel_id_list_p = NULL;
    const sdk_db_tunnel_data_t *tunnel_params_p = NULL;
    boolean_t                   tunnel_nve_exist = FALSE;
    sx_tunnel_map_entry_t      *map_entry_p = NULL;
    uint32_t                    map_entry_cnt;
    hwd_tunnel_map_entry_t      hwd_map_entry;
    sx_router_interface_t       rif;

    SX_LOG_ENTER();

    if (!g_is_tunnel_initialized) {
        goto out;
    }

    err = sdk_tunnel_db_iter_get(SX_ACCESS_CMD_GET, 0, NULL, NULL, &tunnel_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in sdk_tunnel_db_iter_get on count get for ISSU.\n");
        goto out;
    }

    tunnel_id_list_p = cl_malloc(sizeof(sx_tunnel_id_t) * tunnel_cnt);
    if (tunnel_id_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for tunnel list for ISSU\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    err = sdk_tunnel_db_iter_get(SX_ACCESS_CMD_GET_FIRST, 0, NULL, tunnel_id_list_p, &tunnel_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in sdk_tunnel_db_iter_get on list get for ISSU.\n");
        goto out;
    }

    for (i = 0; i < tunnel_cnt; ++i) {
        err = sdk_tunnel_db_get(tunnel_id_list_p[i], &tunnel_params_p, TRUE);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get tunnel[0x%08x] from DB, err = %s\n",
                       tunnel_id_list_p[i], sx_status_str(err));
            goto out;
        }

        if (encap) {
            err = g_hwd_tunnel_ops.hwd_tunnel_edit_pfn(tunnel_params_p->hwd_encap_handle,
                                                       tunnel_params_p->hwd_decap_handle,
                                                       &tunnel_params_p->tun_attr,
                                                       &tunnel_params_p->tun_attr);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to re-set tunnel[0x%08x] for ISSU, err = %s\n",
                           tunnel_id_list_p[i], sx_status_str(err));
                goto out;
            }
        }

        if (SX_TUNNEL_TYPE_NVE_CHECK(tunnel_id_list_p[i])) {
            tunnel_nve_exist = TRUE;

            if ((g_hwd_tunnel_ops.hwd_tunnel_nve_port_issu_end_set_pfn != NULL) && encap) {
                err = g_hwd_tunnel_ops.hwd_tunnel_nve_port_issu_end_set_pfn();
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("hwd_tunnel_nve_port_issu_end_set_pfn failed, err = %s\n",
                               sx_status_str(err));
                    goto out;
                }
            }

            err = sdk_tunnel_db_map_entries_list_get(tunnel_id_list_p[i], NULL, &map_entry_cnt, TRUE);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to get count of map list from tunnel[0x%08x], err = %s\n",
                           tunnel_id_list_p[i], sx_status_str(err));
                goto out;
            }

            if (map_entry_cnt == 0) {
                err = SX_STATUS_SUCCESS;
                SX_LOG_DBG("Tunnel %d mapping table is empty.\n", tunnel_id_list_p[i]);
                continue;
            }

            err = utils_memory_get((void**)&map_entry_p,
                                   map_entry_cnt * sizeof(sx_tunnel_map_entry_t),
                                   UTILS_MEM_TYPE_ID_TUNNEL_E);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to allocate memory for map_entry_list, err = %s\n", sx_status_str(err));
                goto out;
            }

            err = sdk_tunnel_db_map_entries_list_get(tunnel_id_list_p[i], map_entry_p, &map_entry_cnt, TRUE);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to get map list from tunnel[0x%08x], err = %s\n",
                           tunnel_id_list_p[i], sx_status_str(err));
                goto out;
            }

            for (j = 0; j < map_entry_cnt; ++j) {
                SX_MEM_CPY(hwd_map_entry.map_entry, map_entry_p[j]);

                err = sdk_tunnel_db_fid_counter_get(tunnel_id_list_p[i],
                                                    map_entry_p[j].params.nve.bridge_id,
                                                    SX_BRIDGE_COUNTER_TUNNEL_DECAP_E,
                                                    &hwd_map_entry.decap_flow_counter_id);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("sdk_tunnel_db_fid_counter_get for FID %u failed, err = %s\n",
                               map_entry_p[j].params.nve.bridge_id,
                               sx_status_str(err));
                    goto out;
                }

                err = sdk_fid_manager_rif_get(map_entry_p[j].params.nve.bridge_id, &rif);
                if (err == SX_STATUS_SUCCESS) {
                    err = sdk_router_cmn_rif_impl_is_enabled(rif, &hwd_map_entry.v_rif, &hwd_map_entry.hw_rif_id);
                    if (err == SX_STATUS_ENTRY_NOT_FOUND) {
                        err = SX_STATUS_SUCCESS;
                        hwd_map_entry.v_rif = FALSE;
                        hwd_map_entry.hw_rif_id = 0;
                    } else if (SX_CHECK_FAIL(err)) {
                        SX_LOG_ERR("Failed to check a state of RIF[%u], error: %s \n", rif, sx_status_str(err));
                        goto out;
                    }
                } else if (err == SX_STATUS_ENTRY_NOT_FOUND) {
                    err = SX_STATUS_SUCCESS;
                    hwd_map_entry.v_rif = FALSE;
                    hwd_map_entry.hw_rif_id = 0;
                } else if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to get RIF ID for FID [%u], error: %s \n",
                               map_entry_p[j].params.nve.bridge_id, sx_status_str(err));
                    goto out;
                }

                err = g_hwd_tunnel_ops.hwd_tunnel_issu_vni_set_pfn(&hwd_map_entry, encap);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("hwd_tunnel_issu_vni_set_pfn failed, err = %s\n",
                               sx_status_str(err));
                    goto out;
                }
            }

            if (map_entry_p) {
                err = utils_memory_put(map_entry_p, UTILS_MEM_TYPE_ID_TUNNEL_E);
                if (SX_STATUS_SUCCESS != err) {
                    SX_LOG_ERR("Failed to deallocate memory for map_entry_list, err = %s\n", sx_status_str(err));
                    goto out;
                }

                map_entry_p = NULL;
            }
        }
    }

    if (!tunnel_nve_exist && encap) {
        err = g_hwd_tunnel_ops.hwd_tunnel_nve_reg_deinit_pfn();
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("hwd_tunnel_nve_reg_deinit_pfn failed, err = %s\n",
                       sx_status_str(err));
            goto out;
        }
    }


out:
    if (map_entry_p) {
        err = utils_memory_put(map_entry_p, UTILS_MEM_TYPE_ID_TUNNEL_E);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to deallocate memory for map_entry_list - OUT, err = %s\n", sx_status_str(err));
        }

        map_entry_p = NULL;
    }

    if (tunnel_id_list_p) {
        cl_free(tunnel_id_list_p);
    }

    SX_LOG_EXIT();
    return err;
}

static sx_utils_status_t __delete_pending_tunnel_cb(uint64_t id)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_tunnel_id_t              tunnel_id = (sx_tunnel_id_t)id;
    boolean_t                   pending_delete = FALSE;
    sx_port_log_id_t            log_port = 0;
    const sdk_db_tunnel_data_t *tunnel_params_p = NULL;

    err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get pending delete flag from DB for tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (pending_delete) {
        err = sdk_tunnel_db_get(tunnel_id, &tunnel_params_p, TRUE);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get tunnel[0x%08x] from DB, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_impl_log_port_by_tunnel_id_get(tunnel_id, &log_port);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get log_port for tunnel[0x%08x], err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = __sdk_tunnel_nve_delete(tunnel_id, tunnel_params_p, TRUE);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed delete a tunnel[0x%08x] NVE, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        /* Restore learning mode for NVE log_port */
        if (TRUE == g_ld_learn_mode_changed) {
            err = fdb_port_learn_mode_set(log_port, g_ld_learn_mode, TRUE);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to rollback learning on log_port[0x%08x] for tunnel[0x%08x], err = %s\n",
                           log_port, tunnel_id, sx_status_str(err));
                goto out;
            }

            g_ld_learn_mode_changed = FALSE;
            g_ld_learn_mode = SX_FDB_LEARN_MODE_DONT_LEARN;
        }
    }

out:
    return SX_STATUS_TO_SX_UTILS_STATUS(err);
}

static inline void __uin64_t_to_tunnel_mapping(uint64_t id, sx_tunnel_id_t * tunnel_id_p, sx_fid_t * fid_p)
{
    *tunnel_id_p = id & 0xFFFFFFFF;
    *fid_p = (id >> 32) & 0xFFFFFFFF;
}

static sx_utils_status_t __delete_pending_tunnel_mapping_cb(uint64_t id)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_tunnel_id_t        tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_fid_t              fid = SX_FID_ID_INVALID;
    sx_tunnel_map_entry_t map_entry;
    sx_event_info_t       event_info;
    boolean_t             pending_delete = FALSE;

    SX_MEM_CLR(map_entry);
    SX_MEM_CLR(event_info.deleted_object);

    __uin64_t_to_tunnel_mapping(id, &tunnel_id, &fid);

    err = sdk_tunnel_db_mapping_get_by_fid(tunnel_id, fid, &map_entry);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x] map entry for FID[%u], err = %s\n",
                   tunnel_id, map_entry.params.nve.bridge_id, sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_db_tunnel_mapping_pending_delete_get(tunnel_id, &map_entry, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x] map entry for FID[%u], err = %s\n",
                   tunnel_id, map_entry.params.nve.bridge_id, sx_status_str(err));
        goto out;
    }

    if (pending_delete) {
        err = __sdk_tunnel_impl_mapping_delete_internal(tunnel_id, &map_entry, 1, TRUE);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed delete a tunnel[0x%08x] mapping, err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        event_info.deleted_object.object_cnt = 1;
        event_info.deleted_object.object[0].object_type = SX_OBJECT_TYPE_TUNNEL_MAP_OBJECT;
        event_info.deleted_object.object[0].object_id.tunnel_map_object.tunnel_id = tunnel_id;
        SX_MEM_CPY(event_info.deleted_object.object[0].object_id.tunnel_map_object.map_entry, map_entry);

        err = host_ifc_send_event(SX_TRAP_ID_OBJECT_DELETED_EVENT,
                                  &(event_info.deleted_object),
                                  sizeof(event_info.deleted_object),
                                  SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Could not send the OBJECT_DELETED_EVENT event for tunnel[0x%08x], err = [%s]\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
    }

out:
    return SX_STATUS_TO_SX_UTILS_STATUS(err);
}

sx_status_t sdk_tunnel_impl_object_refcount_get(const sx_object_id_t * object_p, uint32_t * refcount_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    char        ref_name[REFERENCE_NAME_MAX_LEN] = "\0";
    boolean_t   pending_delete = FALSE;
    uint32_t    fdb_refcount = 0;

    SX_LOG_ENTER();

    switch (object_p->object_type) {
    case SX_OBJECT_TYPE_TUNNEL:
        /* coverity[result_independent_of_operands] */
        if (!(SX_TUNNEL_ID_RANGE_CHECK(object_p->object_id.tunnel_id))) {
            SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", object_p->object_id.tunnel_id);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        err = sdk_tunnel_db_pending_delete_get(object_p->object_id.tunnel_id, &pending_delete);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                       object_p->object_id.tunnel_id, sx_status_str(err));
            goto out;
        }

        if (pending_delete) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                       object_p->object_id.tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_ref_count_get(object_p->object_id.tunnel_id, refcount_p, sizeof(ref_name), ref_name);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get ref count for tunnel[0x%08x], err = %s\n",
                       object_p->object_id.tunnel_id, sx_status_str(err));
            goto out;
        }
        break;

    case SX_OBJECT_TYPE_TUNNEL_MAP_OBJECT:
        /* coverity[result_independent_of_operands] */
        if (!(SX_TUNNEL_ID_RANGE_CHECK(object_p->object_id.tunnel_map_object.tunnel_id))) {
            SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", object_p->object_id.tunnel_map_object.tunnel_id);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        err = sdk_tunnel_db_mapping_ref_cnt_get(object_p->object_id.tunnel_map_object.tunnel_id,
                                                object_p->object_id.tunnel_map_object.map_entry.params.nve.bridge_id,
                                                refcount_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get ref count for tunnel map entry for tunnel[0x%08x] and FID[%u], err = %s\n",
                       object_p->object_id.tunnel_map_object.tunnel_id,
                       object_p->object_id.tunnel_map_object.map_entry.params.nve.bridge_id,
                       sx_status_str(err));
            goto out;
        }

        err = sdk_fid_manager_tunnel_fdb_counter_get(
            object_p->object_id.tunnel_map_object.map_entry.params.nve.bridge_id,
            object_p->object_id.tunnel_map_object.tunnel_id,
            &fdb_refcount);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to get ref count for tunnel map entry for tunnel[0x%08x] and FID[%u] from FID Manager, err = %s\n",
                object_p->object_id.tunnel_map_object.tunnel_id,
                object_p->object_id.tunnel_map_object.map_entry.params.nve.bridge_id,
                sx_status_str(err));
            goto out;
        }

        if (fdb_refcount > 0) {
            /* First FDB entry will also increase global ref.count
             * that we read with sdk_tunnel_db_mapping_ref_cnt_get */
            *refcount_p += (fdb_refcount - 1);
        }

        break;

    default:
        SX_LOG_ERR("Invalid object type %u received\n", object_p->object_type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_impl_nve_learn_set(sx_port_log_id_t log_port, boolean_t learn_enable)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Set to HW */
    if (g_hwd_tunnel_ops.hwd_tunnel_nve_learn_set_pfn != NULL) {
        sx_status = g_hwd_tunnel_ops.hwd_tunnel_nve_learn_set_pfn(log_port, learn_enable);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to set NVE port learning mode, err - %s\n",
                       sx_status_str(sx_status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

/* Increase/decrease a reference counter of relevant tunnel map entry */
sx_status_t sdk_tunnel_impl_map_entry_ref_inc_dec(sx_access_cmd_t   cmd,
                                                  sx_tunnel_id_t    tunnel_id,
                                                  sx_fid_t          fid,
                                                  ref_name_data_t * ref_name_data_p,
                                                  sdk_ref_t       * ref_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (cmd == SX_ACCESS_CMD_ADD) {
        rc = sdk_tunnel_impl_mapping_ref_cnt_increase(tunnel_id, fid, ref_name_data_p, ref_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to increase tunnel mapping ref for tunnel[0x%08x] and FID (%u)\n",
                       tunnel_id, fid);
            goto out;
        }
    } else {
        rc = sdk_tunnel_impl_mapping_ref_cnt_decrease(tunnel_id, fid, ref_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to decrease tunnel mapping ref for tunnel[0x%08x] and FID (%u)\n",
                       tunnel_id, fid);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t sdk_tunnel_impl_nve_loopback_filter_set(const sx_port_log_id_t         nve_log_port,
                                                    sx_port_loopback_filter_mode_t lbf_mode)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sx_tunnel_id_t tunnel_id = SX_TUNNEL_ID_INVALID;

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    sx_status = sdk_tunnel_db_tunnel_id_by_log_port_get(nve_log_port, &tunnel_id);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_DBG("Tunnel is not bound to the NVE port: 0x%x\n", nve_log_port);
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    }

    if (g_hwd_tunnel_ops.hwd_tunnel_nve_loopback_filter_set_pfn != NULL) {
        sx_status = g_hwd_tunnel_ops.hwd_tunnel_nve_loopback_filter_set_pfn(nve_log_port, lbf_mode);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to set the state of the loopback filter[%u] on a NVE port[0x%x] to HW, error: %s.\n",
                       lbf_mode, nve_log_port, sx_status_str(sx_status));
            goto out;
        }
    } else {
        SX_LOG_ERR("Cannot change the state of loopback filter on a NVE port[0x%x] on chip type %s.\n",
                   nve_log_port, sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
        return SX_STATUS_UNSUPPORTED;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_ecmp_nve_flood_size_get(uint32_t * ecmp_nve_flood_size_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(ecmp_nve_flood_size_p, "ecmp_nve_flood_size_p"))) {
        goto out;
    }

    if (g_hwd_tunnel_ops.hwd_tunnel_nve_group_size_flood_get_pfn == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Internal error: a callback that returns the size of ECMP FLOOD containers is null.\n");
        goto out;
    }

    sx_status = g_hwd_tunnel_ops.hwd_tunnel_nve_group_size_flood_get_pfn(ecmp_nve_flood_size_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get the size of ECMP NVE FLOOD containers, err = [%s] (%d)\n",
                   sx_status_str(sx_status), sx_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_ecmp_nve_mc_size_get(uint32_t * ecmp_nve_mc_size_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(ecmp_nve_mc_size_p, "ecmp_nve_mc_size_p"))) {
        goto out;
    }

    if (g_hwd_tunnel_ops.hwd_tunnel_nve_group_size_mc_get_pfn == NULL) {
        sx_status = SX_STATUS_ERROR;
        SX_LOG_ERR("Internal error: a callback that returns the size of ECMP MC containers is null.\n");
        goto out;
    }

    sx_status = g_hwd_tunnel_ops.hwd_tunnel_nve_group_size_mc_get_pfn(ecmp_nve_mc_size_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get the size of ECMP NVE MC containers, err = [%s] (%d)\n",
                   sx_status_str(sx_status), sx_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static const char* _get_flex_tunnel_hdr_ref_name(char* buffer, size_t name_size, void *entry)
{
    snprintf(buffer, name_size, "Flex Tunnel Hdr %u", *(sx_tunnel_flex_header_id_t*)entry);

    return buffer;
}

sx_status_t sdk_tunnel_impl_flex_header_create(const sx_tunnel_flex_header_cfg_t *header_cfg_p,
                                               sx_tunnel_flex_header_id_t        *header_id_p)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    tunnel_flex_header_entry_t *tunnel_flex_header_entry_p = NULL;

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(header_cfg_p, "header_cfg_p"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(header_id_p, "header_id_p"))) {
        goto out;
    }

    /* Sanity test for the EMT header */
    sx_status = flex_modifier_get(SX_ACCESS_CMD_GET, header_cfg_p->tunnel_header_emt_id.emt_id, NULL);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get EMT [%u] to set flex tunnel header, err = [%s] \n",
                   header_cfg_p->tunnel_header_emt_id.emt_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_tunnel_db_find_free_tunnel_flex_header(&tunnel_flex_header_entry_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to find free flex tunnel header for EMT [%u], err = [%s] \n",
                   header_cfg_p->tunnel_header_emt_id.emt_id, sx_status_str(sx_status));
        goto out;
    }
    /* We don't have the irif yet but that's ok since the header is not used yet */
    sx_status = flex_modifier_tunnel_set(header_cfg_p, 0);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to create flex tunnel header for EMT [%u], err = [%s] \n",
                   header_cfg_p->tunnel_header_emt_id.emt_id, sx_status_str(sx_status));
        goto out;
    }

    tunnel_flex_header_entry_p->allocated = TRUE;
    tunnel_flex_header_entry_p->header_cfg = *header_cfg_p;
    *header_id_p = tunnel_flex_header_entry_p->header_id;

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t sdk_tunnel_impl_flex_header_edit(const sx_tunnel_flex_header_id_t   header_id,
                                             const sx_tunnel_flex_header_cfg_t *header_cfg_p)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    tunnel_flex_header_entry_t *tunnel_flex_header_entry_p = NULL;
    sx_flex_modifier_emt_id_e   old_emt_id = 0;
    sx_router_interface_t       uirif = 0;
    sx_tunnel_flex_header_id_t  tmp_header_id = header_id;
    ref_name_data_t             ref_name_data = {.print_func_p = _get_flex_tunnel_hdr_ref_name,
                                                 .ref_data_p = &tmp_header_id,
                                                 .data_size = sizeof(sx_tunnel_flex_header_id_t)};

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(header_cfg_p, "header_cfg_p"))) {
        goto out;
    }

    /* Sanity test for the EMT header */
    sx_status = flex_modifier_get(SX_ACCESS_CMD_GET, header_cfg_p->tunnel_header_emt_id.emt_id, NULL);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get EMT [%u] to set flex tunnel header, err = [%s] \n",
                   header_cfg_p->tunnel_header_emt_id.emt_id, sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_tunnel_db_tunnel_flex_header_get(header_id, &tunnel_flex_header_entry_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get flex tunnel header [%u] to edit, err = [%s] \n",
                   header_id, sx_status_str(sx_status));
        goto out;
    }
    old_emt_id = tunnel_flex_header_entry_p->header_cfg.tunnel_header_emt_id.emt_id;
    /* The irif could have been configured before */
    uirif = (tunnel_flex_header_entry_p->uirif != FM_INVALID_RIF_ID) ? tunnel_flex_header_entry_p->uirif : 0;

    /* Note: since (for now) all the flex header configurations are done in the EMT
     * which can be edited on the fly - we just pass the parameters to the flex modifier.
     * It is possible that the uirif is not configured yet but we assume
     * that configuring zero is ok until it's updated to the correct value.
     */
    sx_status = flex_modifier_tunnel_set(header_cfg_p, uirif);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set flex tunnel header for EMT [%u], err = [%s] \n",
                   header_cfg_p->tunnel_header_emt_id.emt_id, sx_status_str(sx_status));
        goto out;
    }

    /* If we changed the EMT used in this tunnel we need to release the old reference. */
    if (old_emt_id != header_cfg_p->tunnel_header_emt_id.emt_id) {
        /* Check if this tunnel header is used by an actual tunnel. If so the EMT is used as well. */
        if (tunnel_flex_header_entry_p->used_by_tunnel) {
            sx_status = flex_modifier_emt_ref_dec(old_emt_id, &tunnel_flex_header_entry_p->emt_ref);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed decreasing reference for EMT [%u] flex tunnel header [%u], err = [%s] \n",
                           old_emt_id, header_id, sx_status_str(sx_status));
                goto out;
            }
            sx_status = flex_modifier_emt_ref_inc(header_cfg_p->tunnel_header_emt_id.emt_id,
                                                  &ref_name_data,
                                                  &tunnel_flex_header_entry_p->emt_ref);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed increasing reference for EMT [%u] flex tunnel header [%u], err = [%s] \n",
                           tunnel_flex_header_entry_p->header_cfg.tunnel_header_emt_id.emt_id,
                           header_id,
                           sx_status_str(sx_status));
                goto out;
            }
        }
        /* Remove the configuration from the old EMT */
        sx_status = flex_modifier_tunnel_unset(old_emt_id);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed removing flex tunnel settings for EMT [%u] flex tunnel header [%u], err = [%s] \n",
                       old_emt_id, header_id, sx_status_str(sx_status));
            goto out;
        }
    }

    tunnel_flex_header_entry_p->header_cfg = *header_cfg_p;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_flex_header_destroy(const sx_tunnel_flex_header_id_t header_id)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    tunnel_flex_header_entry_t *tunnel_flex_header_entry_p = NULL;

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    sx_status = sdk_tunnel_db_tunnel_flex_header_get(header_id, &tunnel_flex_header_entry_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get flex tunnel header [%u] to destroy, err = [%s] \n",
                   header_id, sx_status_str(sx_status));
        goto out;
    }

    /* Check if this tunnel header is used by an actual tunnel.*/
    if (tunnel_flex_header_entry_p->used_by_tunnel) {
        SX_LOG_ERR("Flex tunnel header [%u] is used by [0x%08x] tunnel and cannot be destroyed.\n",
                   header_id,
                   tunnel_flex_header_entry_p->tunnel_id);
        sx_status = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    sx_status = flex_modifier_tunnel_unset(tunnel_flex_header_entry_p->header_cfg.tunnel_header_emt_id.emt_id);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed removing flex tunnel settings for EMT [%u] flex tunnel header [%u], err = [%s] \n",
                   tunnel_flex_header_entry_p->header_cfg.tunnel_header_emt_id.emt_id,
                   header_id,
                   sx_status_str(sx_status));
        goto out;
    }
    tunnel_flex_header_entry_p->allocated = FALSE;
    tunnel_flex_header_entry_p->uirif = FM_INVALID_RIF_ID;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_flex_header_bind(const sx_tunnel_flex_header_id_t header_id,
                                             const sx_tunnel_id_t             tunnel_id,
                                             const sx_router_interface_t      uirif)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    tunnel_flex_header_entry_t *tunnel_flex_header_entry_p = NULL;
    ref_name_data_t             ref_name_data = {.print_func_p = _get_flex_tunnel_hdr_ref_name,
                                                 .ref_data_p = NULL,
                                                 .data_size = sizeof(sx_tunnel_flex_header_id_t)};

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    sx_status = sdk_tunnel_db_tunnel_flex_header_get(header_id, &tunnel_flex_header_entry_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get flex tunnel header [%u] to bind tunnel, err = [%s] \n", header_id,
                   sx_status_str(sx_status));
        goto out;
    }

    if (tunnel_flex_header_entry_p->used_by_tunnel) {
        SX_LOG_ERR("Flex tunnel header [%u] is already bound to tunnel.\n", header_id);
        sx_status = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }

    /* Update the flex modifier with the correct uirif */
    sx_status = flex_modifier_tunnel_set(&tunnel_flex_header_entry_p->header_cfg, uirif);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set flex modifier for flex header [%u] binding tunnel [0x%08x], err = [%s] \n",
                   header_id, tunnel_id, sx_status_str(sx_status));
        goto out;
    }

    /* Indicate to the EMT that it's now in use */
    ref_name_data.ref_data_p = &tunnel_flex_header_entry_p->header_id;
    sx_status = flex_modifier_emt_ref_inc(tunnel_flex_header_entry_p->header_cfg.tunnel_header_emt_id.emt_id,
                                          &ref_name_data,
                                          &tunnel_flex_header_entry_p->emt_ref);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed increasing reference for EMT [%u] flex tunnel header [%u], err = [%s] \n",
                   tunnel_flex_header_entry_p->header_cfg.tunnel_header_emt_id.emt_id,
                   tunnel_flex_header_entry_p->header_id,
                   sx_status_str(sx_status));
        goto out;
    }

    tunnel_flex_header_entry_p->used_by_tunnel = TRUE;
    tunnel_flex_header_entry_p->uirif = uirif;
    tunnel_flex_header_entry_p->tunnel_id = tunnel_id;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_flex_header_unbind(const sx_tunnel_flex_header_id_t header_id,
                                               const sx_tunnel_id_t             tunnel_id)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    tunnel_flex_header_entry_t *tunnel_flex_header_entry_p = NULL;

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    sx_status = sdk_tunnel_db_tunnel_flex_header_get(header_id, &tunnel_flex_header_entry_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get flex tunnel header [%u] to bind tunnel, err = [%s] \n", header_id,
                   sx_status_str(sx_status));
        goto out;
    }

    if ((tunnel_flex_header_entry_p->used_by_tunnel != TRUE) ||
        (tunnel_id != tunnel_flex_header_entry_p->tunnel_id)) {
        SX_LOG_ERR("Flex tunnel header [%u] is not bound to tunnel [0x%08x]. Cannot unbind.\n",
                   header_id, tunnel_id);
        sx_status = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    /* Indicate to the EMT that it's now not used by an actual tunnel */
    sx_status = flex_modifier_emt_ref_dec(tunnel_flex_header_entry_p->header_cfg.tunnel_header_emt_id.emt_id,
                                          &tunnel_flex_header_entry_p->emt_ref);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed decreasing reference for EMT [%u] flex tunnel header [%u], err = [%s] \n",
                   tunnel_flex_header_entry_p->header_cfg.tunnel_header_emt_id.emt_id,
                   tunnel_flex_header_entry_p->header_id,
                   sx_status_str(sx_status));
        goto out;
    }

    /* Update the flex modifier with the correct uirif just in case */
    sx_status = flex_modifier_tunnel_set(&tunnel_flex_header_entry_p->header_cfg, 0);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set flex modifier for flex header [%u] unbinding tunnel [0x%08x], err = [%s] \n",
                   header_id, tunnel_id, sx_status_str(sx_status));
        goto out;
    }

    tunnel_flex_header_entry_p->used_by_tunnel = FALSE;
    tunnel_flex_header_entry_p->uirif = 0;
    tunnel_flex_header_entry_p->tunnel_id = 0;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tunnel_impl_flex_header_bind_get(const sx_tunnel_flex_header_id_t header_id,
                                                 sx_tunnel_id_t                  *tunnel_id_p)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    tunnel_flex_header_entry_t *tunnel_flex_header_entry_p = NULL;

    SX_LOG_ENTER();

    if ((sx_status = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    sx_status = sdk_tunnel_db_tunnel_flex_header_get(header_id, &tunnel_flex_header_entry_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get flex tunnel header [%u] to bind tunnel, err = [%s] \n", header_id,
                   sx_status_str(sx_status));
        goto out;
    }

    if (tunnel_flex_header_entry_p->used_by_tunnel) {
        if (tunnel_id_p != NULL) {
            *tunnel_id_p = tunnel_flex_header_entry_p->tunnel_id;
        }
    } else {
        if (tunnel_id_p != NULL) {
            *tunnel_id_p = SX_TUNNEL_ID_INVALID;
        }
        sx_status = SX_STATUS_ENTRY_NOT_BOUND;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

boolean_t sdk_tunnel_impl_l3_gw_supported(sx_tunnel_id_t tunnel_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   supported = FALSE;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    supported = g_tunnel_ops.hwi_tunnel_impl_l3_gw_supported(tunnel_id);

out:
    SX_LOG_EXIT();
    return supported;
}

sx_status_t sdk_tunnel_impl_attr_validate(sx_tunnel_attribute_t *tunnel_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = g_tunnel_ops.hwi_tunnel_impl_attr_validate_pfn(tunnel_attr_p);

out:
    SX_LOG_EXIT();
    return err;
}

static inline boolean_t __sdk_tunnel_reserved_bit_mode_is_check_mask(const sx_tunnel_attribute_t * attrs_p)
{
    boolean_t is_check_mask = FALSE;

    switch (attrs_p->type) {
    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        if (attrs_p->attributes.vxlan.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            is_check_mask = TRUE;
        }
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        if (attrs_p->attributes.vxlan_gpe.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            is_check_mask = TRUE;
        }
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        if (attrs_p->attributes.geneve.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            is_check_mask = TRUE;
        }
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        if (attrs_p->attributes.nvgre.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            is_check_mask = TRUE;
        }
        break;

    default:
        break;
    }

    return is_check_mask;
}

sx_status_t sdk_tunnel_trap_nve_options_set(const struct ku_hpkt_reg *nve_options_hpkt_p, boolean_t *skip_sending_hpkt)
{
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    sdk_db_tunnel_data_t const *tunnel_data_p = NULL;

    SX_LOG_ENTER();

    if (utils_check_pointer(nve_options_hpkt_p, "nve_options_hpkt_p")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(skip_sending_hpkt, "skip_sending_hpkt")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *skip_sending_hpkt = FALSE;
    hwd_tunnel_trap_nve_options_set(nve_options_hpkt_p);

    if (g_is_tunnel_initialized == FALSE) {
        sx_status = SX_STATUS_SUCCESS;
        *skip_sending_hpkt = TRUE;
        goto out;
    }

    sx_status = sdk_tunnel_db_nve_tunnel_attr_get(&tunnel_data_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        sx_status = SX_STATUS_SUCCESS;
        *skip_sending_hpkt = TRUE;
        goto out;
    }

    if (__sdk_tunnel_reserved_bit_mode_is_check_mask(&tunnel_data_p->tun_attr) == FALSE) {
        *skip_sending_hpkt = TRUE;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
