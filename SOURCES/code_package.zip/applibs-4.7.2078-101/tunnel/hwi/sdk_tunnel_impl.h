/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWI_SDK_TUNNEL_IMPL_H__
#define __HWI_SDK_TUNNEL_IMPL_H__

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_tunnel.h>
#include "tunnel_impl.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Forward declarations
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/*
 * Init tunneling module ops function callback structure.
 */
sx_status_t sdk_tunnel_init_ops(void);

sx_status_t sdk_tunnel_impl_orig_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

#endif         /* __HWI_SDK_TUNNEL_IMPL_H__ */
