/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include "hwd_register_reg.h"

#undef __MODULE__
#define __MODULE__ REGISTER


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t hwd_register_reg_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    SX_LOG_EXIT();

    return err;
}
