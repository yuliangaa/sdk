/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWD_REGISTER_DB_H__
#define __HWD_REGISTER_DB_H__


#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_register.h>
#include "sx/sdk/sx_strings.h"
#include <sx/utils/sdk_refcount.h>
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct {
    boolean_t      is_used;
    boolean_t      is_protected;           /* GPP is locked for specific feature such as stateful DB  */
    sdk_refcount_t ref_count;
} hwd_gp_register_db_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t hwd_register_db_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

sx_status_t hwd_gp_register_db_init();

sx_status_t hwd_gp_register_db_deinit(boolean_t is_forced);

sx_status_t hwd_gp_register_db_is_allocated(sx_gp_register_e gp_reg_id, boolean_t *is_allocated_p);

sx_status_t hwd_gp_register_db_is_protected(sx_gp_register_e gp_reg_id, boolean_t *is_protected_p);

sx_status_t hwd_gp_register_db_reg_ref_counter_update(sx_gp_register_e gp_reg_id,
                                                      boolean_t        increase,
                                                      ref_name_data_t *ref_name_data_p,
                                                      sdk_ref_t       *ref_p);

sx_status_t hwd_gp_register_db_refcount_get(sx_gp_register_e gp_reg_id, uint32_t *ref_count_p);

sx_status_t hwd_gp_register_db_reg_create(sx_gp_register_e gp_reg_id);

sx_status_t hwd_gp_register_db_protected_reg_enable(sx_gp_register_e gp_reg_id);

sx_status_t hwd_gp_register_db_reg_destroy(sx_gp_register_e gp_reg_id);

sx_status_t hwd_gp_register_db_protected_reg_disable(sx_gp_register_e gp_reg_id);

sx_status_t hwd_gp_register_db_iter_get(sx_access_cmd_t       cmd,
                                        sx_register_key_t     reg_key,
                                        sx_register_filter_t *filter_p,
                                        sx_register_key_t    *reg_key_list_p,
                                        uint32_t             *reg_key_cnt_p);

void hwd_gp_register_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

void hwd_gp_register_db_debug_dump_spectrum4(dbg_dump_params_t *dbg_dump_params_p);

#endif /*__HWD_REGISTER_DB_H__ */
