/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/sx_log.h>
#include <complib/cl_mem.h>
#include <sx/sdk/sx_status_convertor.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <sx/utils/sdk_refcount.h>
#include "hwd_register_db.h"

#undef __MODULE__
#define __MODULE__ REGISTER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static hwd_gp_register_db_t g_gp_register_db[SX_GP_REGISTER_LAST_E];

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t hwd_register_db_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    SX_LOG_EXIT();

    return rc;
}

sx_status_t hwd_gp_register_db_init()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    memset(g_gp_register_db, 0, sizeof(g_gp_register_db));

    SX_LOG_EXIT();

    return rc;
}

sx_status_t hwd_gp_register_db_deinit(boolean_t is_forced)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;
    int               i = 0;

    SX_LOG_ENTER();

    for (i = 0; i < rm_resource_global.gp_register_num_max; i++) {
        if (g_gp_register_db[i].is_protected) {
            if (is_forced) {
                SX_LOG_INF("Forced deinit GP register DB: register ID %d is protected.\n", i);
                rc = hwd_gp_register_db_protected_reg_disable(i);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to destroy GP register DB: register ID %d is protected .\n", i);
                    goto out;
                }
            } else {
                rc = SX_STATUS_DB_NOT_EMPTY;
                SX_LOG_ERR("Failed to deinit GP register DB: register ID %d is protected .\n", i);
                goto out;
            }
        }

        if (g_gp_register_db[i].is_used) {
            if (is_forced) {
                SX_LOG_INF("Forced deinit GP register DB: register ID %d in used.\n", i);
            } else {
                rc = SX_STATUS_DB_NOT_EMPTY;
                SX_LOG_ERR("Failed to deinit GP register DB: register ID %d in used.\n", i);
                goto out;
            }

            utils_rc = sdk_refcount_deinit(&g_gp_register_db[i].ref_count, is_forced);
            if (SX_UTILS_CHECK_FAIL(utils_rc)) {
                SX_LOG_ERR("Failed to deinit GP register %d reference counter, error: [%s]\n",
                           i, SX_UTILS_STATUS_MSG(utils_rc));
                rc = sx_utils_status_to_sx_status(utils_rc);
                goto out;
            }
        }
    }

    memset(g_gp_register_db, 0, sizeof(g_gp_register_db));

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_gp_register_db_is_allocated(sx_gp_register_e gp_reg_id, boolean_t *is_allocated_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    CL_ASSERT(is_allocated_p != NULL);

    if (gp_reg_id >= rm_resource_global.gp_register_num_max) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *is_allocated_p = g_gp_register_db[gp_reg_id].is_used;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_gp_register_db_is_protected(sx_gp_register_e gp_reg_id, boolean_t *is_protected_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    CL_ASSERT(is_protected_p != NULL);

    if (gp_reg_id >= SX_GP_REGISTER_LAST_E) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *is_protected_p = g_gp_register_db[gp_reg_id].is_protected;

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t hwd_gp_register_db_refcount_get(sx_gp_register_e gp_reg_id, uint32_t *ref_count_p)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    CL_ASSERT(ref_count_p != NULL);

    if (gp_reg_id >= rm_resource_global.gp_register_num_max) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    utils_rc = sdk_refcount_get(&g_gp_register_db[gp_reg_id].ref_count, (int32_t*)ref_count_p);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to get GP register %d reference counter, error: [%s]\n",
                   gp_reg_id, SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

const char* get_gp_register_ref_name(char *name_buf, size_t name_size, void *gp_reg_id)
{
    snprintf(name_buf, name_size, "GP register [%d]", *(sx_gp_register_e*)gp_reg_id);
    return name_buf;
}

sx_status_t hwd_gp_register_db_reg_create(sx_gp_register_e gp_reg_id)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;
    ref_name_data_t   ref_name_data = {.print_func_p = get_gp_register_ref_name,
                                       .ref_data_p = &gp_reg_id,
                                       .data_size = sizeof(gp_reg_id)};

    SX_LOG_ENTER();

    if (gp_reg_id >= rm_resource_global.gp_register_num_max) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    g_gp_register_db[gp_reg_id].is_used = TRUE;
    utils_rc = sdk_refcount_init(&g_gp_register_db[gp_reg_id].ref_count, &ref_name_data, NULL);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to init GP register %d reference counter, error: [%s]\n",
                   gp_reg_id, SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_gp_register_db_protected_reg_enable(sx_gp_register_e gp_reg_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    ref_count = 0;

    SX_LOG_ENTER();

    if (gp_reg_id >= SX_GP_REGISTER_LAST_E) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (g_gp_register_db[gp_reg_id].is_used == FALSE) {
        SX_LOG_ERR(" GP register %d is not used. Need to be created before protection\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = hwd_gp_register_db_refcount_get(gp_reg_id, &ref_count);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot get refcount for register ID %d.\n", gp_reg_id);
        goto out;
    }
    if (ref_count > 0) {
        SX_LOG_ERR(" GP register %d refcount is not zero. Cannot set protection\n", gp_reg_id);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }


    g_gp_register_db[gp_reg_id].is_protected = TRUE;


out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t hwd_gp_register_db_reg_destroy(sx_gp_register_e gp_reg_id)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (gp_reg_id >= rm_resource_global.gp_register_num_max) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (g_gp_register_db[gp_reg_id].is_protected == TRUE) {
        SX_LOG_ERR(" GP register %d is protected.\n", gp_reg_id);
        rc = SX_STATUS_CMD_ERROR;
        goto out;
    }

    g_gp_register_db[gp_reg_id].is_used = FALSE;
    utils_rc = sdk_refcount_deinit(&g_gp_register_db[gp_reg_id].ref_count, FALSE);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to deinit GP register %d reference counter, error: [%s]\n",
                   gp_reg_id, SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t hwd_gp_register_db_protected_reg_disable(sx_gp_register_e gp_reg_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;


    SX_LOG_ENTER();

    if (gp_reg_id >= SX_GP_REGISTER_LAST_E) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (g_gp_register_db[gp_reg_id].is_protected == FALSE) {
        SX_LOG_ERR(" GP register %d is not protected. Protection cannot be cleared.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    g_gp_register_db[gp_reg_id].is_protected = FALSE;


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_gp_register_db_reg_ref_counter_update(sx_gp_register_e gp_reg_id,
                                                      boolean_t        increase,
                                                      ref_name_data_t *ref_name_data_p,
                                                      sdk_ref_t       *ref_p)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (gp_reg_id >= rm_resource_global.gp_register_num_max) {
        SX_LOG_ERR("Invalid value for GP register ID %d.\n", gp_reg_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (increase) {
        utils_rc = sdk_refcount_inc(&g_gp_register_db[gp_reg_id].ref_count, ref_name_data_p, ref_p);
    } else {
        utils_rc = sdk_refcount_dec(&g_gp_register_db[gp_reg_id].ref_count, ref_p);
    }
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed update reference counter to GP register %d, error: [%s]\n", gp_reg_id,
                   SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_gp_register_db_iter_get(sx_access_cmd_t       cmd,
                                        sx_register_key_t     reg_key,
                                        sx_register_filter_t *filter_p,
                                        sx_register_key_t    *reg_key_list_p,
                                        uint32_t             *reg_key_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint8_t     start_reg = 0;
    uint32_t    i = 0;
    uint32_t    reg_count = 0;

    UNUSED_PARAM(filter_p);

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_GETNEXT:
        start_reg = reg_key.key.gp_reg.reg_id + 1;
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        start_reg = 0;
        break;

    case SX_ACCESS_CMD_GET:
        if (*reg_key_cnt_p == 0) {
            for (i = 0; i < rm_resource_global.gp_register_num_max; i++) {
                if (g_gp_register_db[i].is_used == TRUE) {
                    reg_count++;
                }
            }
            *reg_key_cnt_p = reg_count;
        } else {
            if (g_gp_register_db[reg_key.key.gp_reg.reg_id].is_used == TRUE) {
                reg_key_list_p[0] = reg_key;
                *reg_key_cnt_p = 1;
            } else {
                *reg_key_cnt_p = 0;
            }
        }
        goto out;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is unsupported, error: [%s].\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(rc));
        goto out;
    }

    for (i = start_reg; i < rm_resource_global.gp_register_num_max && reg_count < *reg_key_cnt_p; i++) {
        if (g_gp_register_db[i].is_used == TRUE) {
            reg_key_list_p[reg_count].type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
            reg_key_list_p[reg_count].key.gp_reg.reg_id = i;
            reg_count++;
        }
    }

    *reg_key_cnt_p = reg_count;

out:
    SX_LOG_EXIT();
    return rc;
}

void hwd_gp_register_db_debug_dump_spectrum4(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_gp_register_e          reg_id = 0;
    uint32_t                  ref_count = 0;
    dbg_utils_table_columns_t gp_register_db_dump_clmns[] = {
        { "GP register",     12,    PARAM_UINT8_E,        &reg_id},
        { "In use",          7,     PARAM_BOOL_E,         NULL},
        { "Protected",          10,     PARAM_BOOL_E,         NULL},
        { "Ref count",       10,    PARAM_UINT32_E,       &ref_count},
        {NULL, 0, 0, NULL}
    };
    FILE                     *stream = NULL;

    SX_LOG_ENTER();

    rc = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "GP Register Dump");

    dbg_utils_pprinter_table_headline_print(stream, gp_register_db_dump_clmns);

    for (reg_id = 0; reg_id < SX_GP_REGISTER_LAST_E; reg_id++) {
        gp_register_db_dump_clmns[1].data = &g_gp_register_db[reg_id].is_used;
        gp_register_db_dump_clmns[2].data = &g_gp_register_db[reg_id].is_protected;
        if (g_gp_register_db[reg_id].is_used == TRUE) {
            rc = hwd_gp_register_db_refcount_get(reg_id, &ref_count);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get ref count for GP register ID %d, error: %s.\n",
                           reg_id, sx_status_str(rc));
                ref_count = 0;
            }
        } else {
            ref_count = 0;
        }
        dbg_utils_pprinter_table_data_line_print(stream, gp_register_db_dump_clmns);
    }

out:
    SX_LOG_EXIT();
    return;
}

void hwd_gp_register_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_gp_register_e          reg_id = 0;
    uint32_t                  ref_count = 0;
    dbg_utils_table_columns_t gp_register_db_dump_clmns[] = {
        { "GP register",     12,    PARAM_UINT8_E,        &reg_id},
        { "In use",          7,     PARAM_BOOL_E,         NULL},
        { "Ref count",       10,    PARAM_UINT32_E,       &ref_count},
        {NULL, 0, 0, NULL}
    };
    FILE                     *stream = NULL;

    SX_LOG_ENTER();

    rc = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "GP Register Dump");

    dbg_utils_pprinter_table_headline_print(stream, gp_register_db_dump_clmns);

    for (reg_id = 0; reg_id < rm_resource_global.gp_register_num_max; reg_id++) {
        gp_register_db_dump_clmns[1].data = &g_gp_register_db[reg_id].is_used;
        if (g_gp_register_db[reg_id].is_used == TRUE) {
            rc = hwd_gp_register_db_refcount_get(reg_id, &ref_count);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get ref count for GP register ID %d, error: %s.\n",
                           reg_id, sx_status_str(rc));
                ref_count = 0;
            }
        } else {
            ref_count = 0;
        }
        dbg_utils_pprinter_table_data_line_print(stream, gp_register_db_dump_clmns);
    }

out:
    SX_LOG_EXIT();
    return;
}
