/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __REGISTER_BE_H__
#define __REGISTER_BE_H__

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_register.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t register_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

sx_status_t register_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

sx_status_t register_set(sx_access_cmd_t    cmd,
                         uint32_t           reg_key_cnt,
                         sx_register_key_t* reg_key_list_p);

sx_status_t register_iter_get(sx_access_cmd_t       cmd,
                              sx_register_key_t     reg_key,
                              sx_register_filter_t *filter_p,
                              sx_register_key_t    *reg_key_list_p,
                              uint32_t             *reg_key_cnt_p);

#endif /*__REGISTER_BE_H__ */
