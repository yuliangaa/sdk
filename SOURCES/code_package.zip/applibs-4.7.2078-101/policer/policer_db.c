/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_qpool.h>
#include <complib/cl_dbg.h>
#include <complib/cl_qmap.h>

#include "policer.h"
#include "policer_db.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "sdk_policer.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "../ethl2/port_db.h"
#include <complib/cl_mem.h>

#undef  __MODULE__
#define __MODULE__ POLICER_DB

extern rm_resources_t rm_resource_global;

/************************************************
 *  Global variables
 ***********************************************/

/*************************************************
 *  Local variables
 ************************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t  policer_db_init_done = FALSE;
static cl_qmap_t  global_policer_qmap;
static cl_qpool_t global_policer_qpool;
/* static policer_db_item_t *mapping_table; */

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t policer_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}


cl_status_t __policer_db_global_init(void *const p_object, void *context, cl_pool_item_t ** const pp_pool_item)
{
    static uint32_t    pid_s = 0;
    policer_db_item_t *policer_item = (policer_db_item_t*)p_object;

    UNUSED_PARAM(context);

    policer_item->policer_id = pid_s++;
    *pp_pool_item = &(policer_item->pool_item);

    return CL_SUCCESS;
}

void __policer_db_find(const sx_policer_id_t policer_id, policer_db_item_t **policer_item)
{
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;

    SX_LOG_ENTER();

    map_item = cl_qmap_get(&(global_policer_qmap), policer_id);
    map_end = cl_qmap_end(&(global_policer_qmap));

    if (map_item != map_end) {
        *policer_item = PARENT_STRUCT(map_item, policer_db_item_t, map_item);
    } else {
        *policer_item = NULL;
    }

    SX_LOG_EXIT();
}

void __policer_db_get_head(policer_db_item_t **head_item)
{
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;

    SX_LOG_ENTER();

    map_item = cl_qmap_head(&(global_policer_qmap));
    map_end = cl_qmap_end(&(global_policer_qmap));

    if (map_item != map_end) {
        *head_item = PARENT_STRUCT(map_item, policer_db_item_t, map_item);
    } else {
        *head_item = NULL;
    }

    SX_LOG_EXIT();
}

void __policer_db_get_next(const policer_db_item_t *current_item, policer_db_item_t **next_item)
{
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;

    SX_LOG_ENTER();

    map_item = cl_qmap_next(&current_item->map_item);
    map_end = cl_qmap_end(&(global_policer_qmap));

    if (map_item != map_end) {
        *next_item = PARENT_STRUCT(map_item, policer_db_item_t, map_item);
    } else {
        *next_item = NULL;
    }

    SX_LOG_EXIT();
}

sx_status_t policer_db_init(const uint32_t max_global_policer)
{
    cl_status_t cl_rc = CL_SUCCESS;
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE == policer_db_init_done) {
        SX_LOG_ERR("Can't Init DB Pool (%s).\n", sx_status_str(SX_STATUS_DB_ALREADY_INITIALIZED));
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_DB_ALREADY_INITIALIZED);
    }

    cl_rc = CL_QPOOL_INIT(&global_policer_qpool,
                          max_global_policer,
                          max_global_policer,
                          max_global_policer,
                          sizeof(policer_db_item_t),
                          __policer_db_global_init,
                          NULL, NULL);

    if (cl_rc != CL_SUCCESS) {
        SX_LOG_ERR("Policer Pool Init Failure - %s.\n", CL_STATUS_MSG(cl_rc));
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_NO_MEMORY);
    }

    cl_qmap_init(&global_policer_qmap);

    policer_db_init_done = TRUE;

    SX_LOG_EXIT();

    return rc;
}

sx_status_t sx_policer_db_create(const sx_policer_db_attrib_t *policer_attr, sx_policer_id_t *policer_id_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    cl_pool_item_t    *pool_item = NULL;
    policer_db_item_t *policer_item = NULL;

    SX_LOG_ENTER();

    pool_item = cl_qpool_get(&global_policer_qpool);
    if (pool_item == NULL) {
        SX_LOG_ERR("Could not find free policer in global policer DB.\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_NO_RESOURCES);
    }

    policer_item = PARENT_STRUCT(pool_item, policer_db_item_t, pool_item);
    policer_item->bind_num = 0;
    SX_MEM_CPY_P(&(policer_item->policer_atrrib), policer_attr);
    *policer_id_p = policer_item->policer_id;

    cl_qmap_insert(&global_policer_qmap, policer_item->policer_id, &(policer_item->map_item));

    SX_LOG_EXIT();

    return rc;
}

sx_status_t sdk_policer_db_create(const sx_policer_db_attrib_t *policer_attr, sx_policer_id_t *policer_id_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    cl_pool_item_t    *pool_item = NULL;
    policer_db_item_t *policer_item = NULL;

    SX_LOG_ENTER();

    pool_item = cl_qpool_get(&global_policer_qpool);
    if (pool_item == NULL) {
        SX_LOG_ERR("Could not find free policer in global policer DB.\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_NO_RESOURCES);
    }

    policer_item = PARENT_STRUCT(pool_item, policer_db_item_t, pool_item);
    policer_item->bind_num = 0;
    policer_item->policer_id = *policer_id_p;
    SX_MEM_CPY_P(&(policer_item->policer_atrrib), policer_attr);

    cl_qmap_insert(&global_policer_qmap, policer_item->policer_id, &(policer_item->map_item));

    SX_LOG_EXIT();

    return rc;
}

void policer_db_is_allocated_policer(const sx_policer_id_t policer_id, boolean_t *is_allocated)
{
    policer_db_item_t *policer_item = NULL;

    SX_LOG_ENTER();

    __policer_db_find(policer_id, &policer_item);
    *is_allocated = (policer_item != NULL);

    SX_LOG_EXIT();
}

sx_status_t policer_db_type_get(const sx_policer_id_t policer_id, sx_policer_type_e *policer_type)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    policer_db_item_t *policer_item = NULL;

    SX_LOG_ENTER();

    __policer_db_find(policer_id, &policer_item);

    if (policer_item == NULL) {
        SX_LOG_ERR("Could not find policer (%" PRIu64 ") in global policer DB.\n", policer_id);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_ENTRY_NOT_FOUND);
    }

    *policer_type = policer_item->policer_atrrib.policer_type;

    SX_LOG_EXIT();

    return rc;
}

sx_status_t policer_db_attrib_set(const sx_policer_id_t policer_id, const sx_policer_db_attrib_t *policer_attr)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    policer_db_item_t *policer_item = NULL;

    SX_LOG_ENTER();

    __policer_db_find(policer_id, &policer_item);

    if (policer_item == NULL) {
        SX_LOG_ERR("Could not find policer (%" PRIu64 ") in global policer DB.\n", policer_id);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_ENTRY_NOT_FOUND);
    }

    SX_MEM_CPY_P(&(policer_item->policer_atrrib), policer_attr);

    SX_LOG_EXIT();

    return rc;
}

sx_status_t policer_db_foreach_policer_on_lag_port(sx_access_cmd_t cmd, sx_port_id_t lag_id, sx_port_id_t port_id)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    policer_db_item_t *policer_item = NULL;
    sx_policer_id_t    policer_id = 0;
    uint32_t           i = 0;
    sx_policer_info_t  policer_info;


    SX_LOG_ENTER();
    SX_MEM_CLR(policer_info);

    policer_info.type_base_params.log_port = lag_id;

    switch (cmd) {
    case SX_ACCESS_CMD_DESTROY:
        for (i = 0; i <= SX_PORT_STORM_CONTROL_ID_MAX; i++) {
            SX_POLICER_PID_SET(policer_id, i);
            SX_POLICER_LOG_PORT_SET(policer_id, lag_id);
            __policer_db_find(policer_id, &policer_item);

            if (policer_item != NULL) {
                rc = sdk_policer_get(policer_id, &policer_info.policer_attributes);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("policer_get failed, error %s\n", sx_status_str(rc));
                    break;
                }
                rc = sdk_policer_set(SX_ACCESS_CMD_DESTROY, SX_POLICER_MODE_POLICER_E, &policer_id, &policer_info);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("policer_set failed, error %s\n", sx_status_str(rc));
                    break;
                }
            }
        }
        break;

    case SX_ACCESS_CMD_BIND:
    case SX_ACCESS_CMD_UNBIND:
        for (i = 0; i <= SX_PORT_STORM_CONTROL_ID_MAX; i++) {
            SX_POLICER_PID_SET(policer_id, i);
            SX_POLICER_LOG_PORT_SET(policer_id, lag_id);
            __policer_db_find(policer_id, &policer_item);

            if (policer_item != NULL) {
                rc = sdk_handle_qpbr(cmd, port_id, policer_id, policer_item->policer_atrrib.packet_types);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Storm control policer bind HW failure - port  %#08X (%s)\n",
                               port_id, sx_status_str(rc));
                    break;
                }
            }
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }


    SX_LOG_EXIT();

    return rc;
}

sx_status_t policer_db_foreach_policer_on_log_port(sx_access_cmd_t cmd, sx_port_id_t lag_id, sx_port_id_t port_id)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    policer_db_item_t *policer_item = NULL;
    sx_policer_id_t    policer_id = 0;
    uint32_t           i = 0;
    sx_access_cmd_t    intl_cmd = cmd;
    sx_policer_info_t  policer_info;


    SX_LOG_ENTER();
    SX_MEM_CLR(policer_info);

    policer_info.type_base_params.log_port = lag_id;

    switch (cmd) {
    case SX_ACCESS_CMD_DESTROY:
        intl_cmd = SX_ACCESS_CMD_UNBIND;

    /* fall through */
    case SX_ACCESS_CMD_BIND:
    case SX_ACCESS_CMD_UNBIND:
        for (i = 0; i <= SX_PORT_STORM_CONTROL_ID_MAX; i++) {
            SX_POLICER_PID_SET(policer_id, i);
            SX_POLICER_LOG_PORT_SET(policer_id, port_id);
            __policer_db_find(policer_id, &policer_item);

            if (policer_item != NULL) {
                rc = sdk_handle_qpbr(intl_cmd, port_id, policer_id, policer_item->policer_atrrib.packet_types);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Storm control policer bind HW failure - port  %#08X (%s)\n",
                               port_id, sx_status_str(rc));
                    break;
                }
                if (cmd == SX_ACCESS_CMD_DESTROY) {
                    rc = sdk_policer_get(policer_id, &policer_info.policer_attributes);
                    if (SX_CHECK_FAIL(rc)) {
                        SX_LOG_ERR("policer_get failed, error %s\n", sx_status_str(rc));
                        break;
                    }
                    rc = sdk_policer_set(SX_ACCESS_CMD_DESTROY, SX_POLICER_MODE_POLICER_E, &policer_id, &policer_info);
                    if (SX_CHECK_FAIL(rc)) {
                        SX_LOG_ERR("policer_set failed, error %s\n", sx_status_str(rc));
                        break;
                    }
                }
            }
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }


    SX_LOG_EXIT();

    return rc;
}

sx_status_t policer_db_attrib_get(const sx_policer_id_t policer_id, sx_policer_db_attrib_t *policer_attr_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    policer_db_item_t *policer_item = NULL;

    SX_LOG_ENTER();

    __policer_db_find(policer_id, &policer_item);

    if (policer_item == NULL) {
        SX_LOG_ERR("Could not find policer (%" PRIu64 ") in global policer DB.\n", policer_id);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_ENTRY_NOT_FOUND);
    }

    SX_MEM_CPY_P(policer_attr_p, &(policer_item->policer_atrrib));

    SX_LOG_EXIT();

    return rc;
}

sx_status_t policer_db_iter_get(const sx_access_cmd_t         access_cmd,
                                const sx_policer_id_t         policer_id_key,
                                const sx_policer_id_filter_t *policer_id_filter_p,
                                sx_policer_id_t              *policer_id_list_p,
                                uint32_t                     *policer_id_cnt_p)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t       *start_map_item_p = NULL;
    cl_map_item_t       *map_item_p = NULL;
    const cl_map_item_t *map_end_p = NULL;
    policer_db_item_t   *policer_item = NULL;
    uint32_t             ii = 0;
    uint32_t             data_count = 0;

    UNUSED_PARAM(policer_id_filter_p);


    SX_LOG_ENTER();


    /* Check count != NULL */
    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(policer_id_cnt_p, "policer_id_cnt_p"))) {
        goto out;
    }

    if (*policer_id_cnt_p != 0) {
        if (SX_CHECK_FAIL(sx_status = utils_check_pointer(policer_id_list_p,
                                                          "policer_id_list_p"))) {
            goto out;
        }
    }

    if (policer_db_init_done == FALSE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Policer DB is not initialized (%s).\n", sx_status_str(sx_status));
        goto out;
    }

    data_count = *policer_id_cnt_p;

    switch (access_cmd) {
    case SX_ACCESS_CMD_GETNEXT:
        start_map_item_p = cl_qmap_get_next(&(global_policer_qmap), policer_id_key);
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        start_map_item_p = cl_qmap_head(&(global_policer_qmap));
        break;

    case SX_ACCESS_CMD_GET:
        if (*policer_id_cnt_p == 0) {
            *policer_id_cnt_p = cl_qmap_count(&(global_policer_qmap));
        } else {
            if (cl_qmap_contains(&(global_policer_qmap), policer_id_key)) {
                policer_id_list_p[0] = policer_id_key;
                *policer_id_cnt_p = 1;
            } else {
                *policer_id_cnt_p = 0;
            }
        }
        goto out;

    default:
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) is unsupported, err: %s.\n",
                   access_cmd, sx_access_cmd_str(access_cmd), sx_status_str(sx_status));
        goto out;
    }

    if (data_count && start_map_item_p) {
        ii = 0;
        map_item_p = start_map_item_p;
        map_end_p = cl_qmap_end(&(global_policer_qmap));
        while (map_item_p != map_end_p) {
            policer_item = PARENT_STRUCT(map_item_p, policer_db_item_t, map_item);
            policer_id_list_p[ii] = policer_item->policer_id;
            map_item_p = cl_qmap_next(map_item_p);
            if (++ii >= data_count) {
                break;
            }
        }
        *policer_id_cnt_p = ii;
    } else {
        *policer_id_cnt_p = 0;
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t policer_db_find_policer(const sx_policer_id_t policer_id, boolean_t *is_policer_valid_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    policer_db_item_t *policer_item = NULL;
    boolean_t          is_found = FALSE;

    SX_LOG_ENTER();

    if (policer_db_init_done == FALSE) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Policer DB is not initialized (%s).\n", sx_status_str(rc));
        goto out;
    }

    __policer_db_find(policer_id, &policer_item);

    if (policer_item != NULL) {
        is_found = TRUE;
    }

    *is_policer_valid_p = is_found;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t policer_db_binds_get(const sx_policer_id_t policer_id, uint32_t *bind_num_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    policer_db_item_t *policer_item = NULL;

    SX_LOG_ENTER();

    __policer_db_find(policer_id, &policer_item);

    if (policer_item == NULL) {
        SX_LOG_ERR("Could not find policer (%" PRIu64 ") in global policer DB.\n", policer_id);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_ENTRY_NOT_FOUND);
    }

    *bind_num_p = policer_item->bind_num;

    SX_LOG_EXIT();

    return rc;
}

sx_status_t policer_db_bind_set(const sx_access_cmd_t cmd, const sx_policer_id_t policer_id)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    policer_db_item_t *policer_item = NULL;

    SX_LOG_ENTER();

    __policer_db_find(policer_id, &policer_item);

    if (policer_item == NULL) {
        SX_LOG_ERR("Could not find policer (%" PRIu64 ") in global policer DB.\n", policer_id);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_ENTRY_NOT_FOUND);
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        policer_item->bind_num++;
        break;

    case SX_ACCESS_CMD_UNBIND:
        policer_item->bind_num--;
        break;

    default:
        SX_LOG_ERR("Reach default command access, cmd not supported (%s).\n", sx_access_cmd_str(cmd));
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_CMD_UNSUPPORTED);
    }

    SX_LOG_EXIT();

    return rc;
}

sx_status_t policer_db_destroy(const sx_policer_id_t policer_id)
{
    policer_db_item_t *policer_item = NULL;
    sx_status_t        rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    __policer_db_find(policer_id, &policer_item);

    if (policer_item == NULL) {
        SX_LOG_ERR("Could not find policer (%" PRIu64 ") in global policer DB.\n", policer_id);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_ENTRY_NOT_FOUND);
    }

    cl_qmap_remove_item(&(global_policer_qmap), &(policer_item->map_item));
    cl_qpool_put(&(global_policer_qpool), &(policer_item->pool_item));

    SX_LOG_EXIT();

    return rc;
}

sx_status_t policer_db_deinit()
{
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;
    policer_db_item_t   *policer_item = NULL;
    sx_status_t          rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (policer_db_init_done == FALSE) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Policer DB is not initialized (%s).\n", sx_status_str(rc));
        goto out;
    }

    map_item = cl_qmap_head(&(global_policer_qmap));
    map_end = cl_qmap_end(&(global_policer_qmap));

    while (map_item != map_end) {
        policer_item = PARENT_STRUCT(map_item, policer_db_item_t, map_item);
        map_item = cl_qmap_next(map_item);

        cl_qmap_remove_item(&(global_policer_qmap), &(policer_item->map_item));
        cl_qpool_put(&(global_policer_qpool), &(policer_item->pool_item));
    }

    CL_QPOOL_DESTROY(&(global_policer_qpool));

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t policer_db_add_device_foreach(policer_db_pfn_t func, void *data)
{
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;
    policer_db_item_t   *policer_item = NULL;
    sx_status_t          rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    map_item = cl_qmap_head(&(global_policer_qmap));
    map_end = cl_qmap_end(&(global_policer_qmap));

    while (map_item != map_end) {
        policer_item = PARENT_STRUCT(map_item, policer_db_item_t, map_item);
        map_item = cl_qmap_next(map_item);

        rc = func(policer_item, data);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to apply func on policer db item rc (%s)\n", sx_status_str(rc));
            return M_UTILS_SX_LOG_EXIT(rc);
        }
    }

    SX_LOG_EXIT();

    return rc;
}

static sx_status_t __policer_db_dump_globals(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    policer_db_item_t        *policer_item = NULL, *current_item = NULL;
    sx_policer_id_t           policer_id = 0;
    uint32_t                  cbs = 0, ebs = 0, cir = 0, eir = 0;
    boolean_t                 color_aware = 0, is_host_ifc_policer = 0, is_span_policer = 0;
    const char                empty_string[] = "";
    uint64_t                  actual_cbs = 0, actual_ebs = 0, actual_cir = 0, actual_eir = 0;
    sx_policer_counters_t     policer_counters;
    dbg_utils_table_columns_t policer_attributes_clmns[] = {
        { "ID",            4,  PARAM_UINT64_E, &policer_id},
        { "Meter",         7,  PARAM_STRING_E, NULL},
        { "CBS",           3,  PARAM_UINT32_E, &cbs},
        { "Actual CBS",    12, PARAM_UINT64_E, &actual_cbs},
        { "EBS",           3,  PARAM_UINT32_E, &ebs},
        { "Actual EBS",    12, PARAM_UINT64_E, &actual_ebs},
        { "CIR",           10, PARAM_UINT32_E, &cir},
        { "Actual CIR",    16, PARAM_UINT64_E, &actual_cir},
        { "Yellow A",      8,  PARAM_STRING_E, NULL},
        { "Red A",         8,  PARAM_STRING_E, NULL},
        { "EIR",           10, PARAM_UINT32_E, &eir},
        { "Actual EIR",    16, PARAM_UINT64_E, &actual_eir},
        { "Rate",          6,  PARAM_STRING_E, NULL},
        { "Color",         5,  PARAM_BOOL_E,   &color_aware},
        { "HostIFC",       7,  PARAM_BOOL_E,   &is_host_ifc_policer},
        { "IRUnit",        6,  PARAM_STRING_E, NULL},
        { "SPAN",          5,  PARAM_BOOL_E,   &is_span_policer},
        { "Drop Counter", 20,  PARAM_UINT64_E, &(policer_counters.violation_counter)},
        {NULL, 0, 0, NULL}
    };
    FILE                     *stream = dbg_dump_params_p->stream;

    SX_MEM_CLR(policer_counters);

    dbg_utils_pprinter_general_header_print(stream, "Global Policer");
    dbg_utils_pprinter_table_headline_print(stream, policer_attributes_clmns);

    __policer_db_get_head(&policer_item);
    while (policer_item != NULL) {
        if ((policer_item->policer_atrrib.policer_type == SX_POLICER_TYPE_GLOBAL_E) ||
            (policer_item->policer_atrrib.policer_type == SX_POLICER_TYPE_GLOBAL_SLOW_E)) {
            policer_attributes_clmns[4].type = PARAM_UINT32_E;
            policer_attributes_clmns[4].data = &ebs;
            policer_attributes_clmns[5].type = PARAM_UINT64_E;
            policer_attributes_clmns[5].data = &actual_ebs;
            policer_attributes_clmns[10].type = PARAM_UINT32_E;
            policer_attributes_clmns[10].data = &eir;
            policer_attributes_clmns[11].type = PARAM_UINT64_E;
            policer_attributes_clmns[11].data = &actual_eir;
            if (policer_item->policer_atrrib.rate_type == SX_POLICER_RATE_TYPE_DUAL_RATE_E) {
                ebs = policer_item->policer_atrrib.ebs;
                if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_PACKETS) {
                    actual_ebs = ((uint64_t)(1)) << ebs;
                } else if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_TRAFFIC) {
                    actual_ebs = ((uint64_t)(512)) * (1 << ebs);
                }
                policer_attributes_clmns[8].data = sx_policer_action_str(policer_item->policer_atrrib.yellow_action);
                eir = policer_item->policer_atrrib.eir;
                if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_PACKETS) {
                    actual_eir = eir;
                } else if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_TRAFFIC) {
                    if (policer_item->policer_atrrib.ir_units == SX_POLICER_IR_UNITS_10_POWER_6_E) {
                        actual_eir = ((uint64_t)(eir)) * SX_POLICER_IR_UNIT_1M;
                    } else if (policer_item->policer_atrrib.ir_units == SX_POLICER_IR_UNITS_10_POWER_3_E) {
                        actual_eir = ((uint64_t)(eir)) * SX_POLICER_IR_UNIT_1K;
                    }
                }
            } else if (policer_item->policer_atrrib.rate_type == SX_POLICER_RATE_TYPE_SINGLE_RATE_E) {
                /* For single rate policer, ebs, eir, yellow action are not configured */
                policer_attributes_clmns[4].type = PARAM_STRING_E;
                policer_attributes_clmns[4].data = &empty_string;
                policer_attributes_clmns[5].type = PARAM_STRING_E;
                policer_attributes_clmns[5].data = &empty_string;
                policer_attributes_clmns[8].type = PARAM_STRING_E;
                policer_attributes_clmns[8].data = &empty_string;
                policer_attributes_clmns[10].type = PARAM_STRING_E;
                policer_attributes_clmns[10].data = &empty_string;
                policer_attributes_clmns[11].type = PARAM_STRING_E;
                policer_attributes_clmns[11].data = &empty_string;
            } else if (policer_item->policer_atrrib.rate_type == SX_POLICER_RATE_TYPE_SX_E) {
                cbs = policer_item->policer_atrrib.cbs;
                actual_cbs = cbs;
                ebs = policer_item->policer_atrrib.ebs;
                actual_ebs = ebs;
                cir = policer_item->policer_atrrib.cir;
                actual_cir = cir;
                if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_TRAFFIC) {
                    /* Cir Unit is 5Mbps */
                    actual_cir = ((uint64_t)(cir)) * SX_POLICER_CIR_UNIT_TRAFFIC_RATE * 1000000;
                }
                policer_attributes_clmns[8].data = sx_policer_action_str(policer_item->policer_atrrib.yellow_action);
                policer_attributes_clmns[10].type = PARAM_STRING_E;
                policer_attributes_clmns[10].data = &empty_string;
                policer_attributes_clmns[11].type = PARAM_STRING_E;
                policer_attributes_clmns[11].data = &empty_string;
                policer_attributes_clmns[13].type = PARAM_STRING_E;
                policer_attributes_clmns[13].data = &empty_string;
                policer_attributes_clmns[14].type = PARAM_STRING_E;
                policer_attributes_clmns[14].data = &empty_string;
                policer_attributes_clmns[15].type = PARAM_STRING_E;
                policer_attributes_clmns[15].data = &empty_string;
            }

            policer_id = policer_item->policer_id;
            policer_attributes_clmns[1].data = sx_policer_meter_type_str(policer_item->policer_atrrib.meter_type);
            policer_attributes_clmns[9].data = sx_policer_action_str(policer_item->policer_atrrib.red_action);
            /* coverity[overrun-local] */
            policer_attributes_clmns[12].data = sx_policer_rate_type_str(policer_item->policer_atrrib.rate_type);

            if (policer_item->policer_atrrib.rate_type != SX_POLICER_RATE_TYPE_SX_E) {
                cbs = policer_item->policer_atrrib.cbs;
                if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_PACKETS) {
                    actual_cbs = ((uint64_t)(1)) << cbs;
                } else if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_TRAFFIC) {
                    actual_cbs = ((uint64_t)(512)) * (1 << cbs);
                }
                cir = policer_item->policer_atrrib.cir;
                if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_PACKETS) {
                    actual_cir = cir;
                } else if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_TRAFFIC) {
                    if (policer_item->policer_atrrib.ir_units == SX_POLICER_IR_UNITS_10_POWER_6_E) {
                        actual_cir = ((uint64_t)(cir)) * SX_POLICER_IR_UNIT_1M;
                    } else if (policer_item->policer_atrrib.ir_units == SX_POLICER_IR_UNITS_10_POWER_3_E) {
                        actual_cir = ((uint64_t)(cir)) * SX_POLICER_IR_UNIT_1K;
                    }
                }
                color_aware = policer_item->policer_atrrib.color_aware;
                is_host_ifc_policer = policer_item->policer_atrrib.is_host_ifc_policer;
                policer_attributes_clmns[15].data = sx_policer_ir_units_str(policer_item->policer_atrrib.ir_units);
                is_span_policer = policer_item->policer_atrrib.is_span_session_policer;
                err = sdk_policer_counters_get(policer_id, &policer_counters);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to get policer %" PRIu64 " counters, err %s\n",
                               policer_id, sx_status_str(err));
                    goto out;
                }
            }
            dbg_utils_pprinter_table_data_line_print(stream, policer_attributes_clmns);
        }

        current_item = policer_item;
        __policer_db_get_next(current_item, &policer_item);
    }

out:
    return SX_STATUS_SUCCESS;
}

static sx_status_t __policer_db_dump_storm_control(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    policer_db_item_t         *policer_item = NULL;
    sx_port_log_id_t           port = 0;
    sx_port_storm_control_id_t storm_control_id = 0;
    sx_policer_id_t            policer_id = 0;
    sx_port_packet_types_t     packet_types;
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    sx_device_id_t             device_id = 1;
    sx_swid_id_t               swid = 0;
    sx_port_attributes_t      *port_attributes_p = NULL;
    sx_device_info_t          *device_info_list_p = NULL;
    uint32_t                   port_num = 0, device_index = 0, dev_num = 0, port_index = 0;
    uint32_t                   cbs = 0, cir = 0, i = 0, index = 0;
    uint64_t                   actual_cbs = 0, actual_cir = 0;
    sx_policer_counters_t      policer_counters;
    dbg_utils_table_columns_t  storm_control_attributes_clmns[] = {
        { "ID",            2,  PARAM_UINT32_E,  &storm_control_id},
        { "Port",          10, PARAM_PORT_ID_E, &port},
        { "UC",            5,  PARAM_BOOL_E,    &packet_types.uc},
        { "MC",            5,  PARAM_BOOL_E,    &packet_types.mc},
        { "BC",            5,  PARAM_BOOL_E,    &packet_types.bc},
        { "UUC",           5,  PARAM_BOOL_E,    &packet_types.uuc},
        { "UMC",           5,  PARAM_BOOL_E,    &packet_types.umc},
        { "Meter Type",    10, PARAM_STRING_E,  NULL},
        { "CBS",           3,  PARAM_UINT32_E,  &cbs},
        { "Actual CBS",    12, PARAM_UINT64_E,  &actual_cbs},
        { "CIR",           12, PARAM_UINT32_E,  &cir},
        { "Actual CIR",    16, PARAM_UINT64_E,  &actual_cir},
        { "Red Action",    10, PARAM_STRING_E,  NULL},
        { "Ir Units",      8,  PARAM_STRING_E,  NULL},
        { "Drop Counter",  20, PARAM_UINT64_E,  &(policer_counters.violation_counter)},
        {NULL, 0, 0, NULL}
    };
    FILE                      *stream = dbg_dump_params_p->stream;

    SX_MEM_CLR(packet_types);
    SX_MEM_CLR(policer_counters);

    dbg_utils_pprinter_general_header_print(stream, "Storm Control");
    dbg_utils_pprinter_table_headline_print(stream, storm_control_attributes_clmns);

    /*get number of devices*/
    sx_status = port_device_list_get(SX_ACCESS_CMD_COUNT, NULL, &dev_num);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve number of devices  (%s).\n",
                   sx_status_str(sx_status));
        goto out;
    }
    /*allocate memory and get device list*/
    device_info_list_p = (sx_device_info_t*)cl_malloc(dev_num * sizeof(sx_device_info_t));
    if (device_info_list_p == NULL) {
        sx_status = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed in memory allocation (%s).\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = port_device_list_get(SX_ACCESS_CMD_GET, device_info_list_p, &dev_num);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve device info (%s).\n",
                   sx_status_str(sx_status));
        goto out;
    }
    for (device_index = 0; device_index < dev_num; device_index++) {
        device_id = device_info_list_p[device_index].dev_id;
        /*get device's number of ports*/
        sx_status = port_device_get(SX_ACCESS_CMD_COUNT, device_id, swid, NULL, &port_num);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" Failed to retrieve number of ports on device (%u)"
                       "and swid (%u)  (%s).\n",
                       device_id, swid, sx_status_str(sx_status));
            goto out;
        }

        if (port_num == 0) {
            continue;
        }

        port_attributes_p = (sx_port_attributes_t*)cl_malloc(port_num * sizeof(sx_port_attributes_t));
        if (port_attributes_p == NULL) {
            sx_status = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed in memory allocation (%s).\n", sx_status_str(sx_status));
            goto out;
        }

        /*get device logical ports list*/
        sx_status = port_device_get(SX_ACCESS_CMD_GET, device_id, swid, port_attributes_p, &port_num);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" Failed to retrieve ports info on device (%u) and swid (%u)  (%s).\n",
                       device_id, swid, sx_status_str(sx_status));
            goto out;
        }

        /* for each port */
        for (port_index = 0; port_index < port_num; port_index++) {
            if (IS_PORT_TYPE_NETWORK_OR_LAG(port_attributes_p[port_index].log_port) == FALSE) {
                continue;
            }

            /* for each storm control id */
            for (i = 0; i <= SX_PORT_STORM_CONTROL_ID_MAX; i++) {
                port = port_attributes_p[port_index].log_port;
                SX_POLICER_PID_SET(policer_id, i);
                SX_POLICER_LOG_PORT_SET(policer_id, port);
                __policer_db_find(policer_id, &policer_item);

                if (policer_item != NULL) {
                    storm_control_id = i;
                    packet_types = policer_item->policer_atrrib.packet_types;
                    storm_control_attributes_clmns[7].data = sx_policer_meter_type_str(
                        policer_item->policer_atrrib.meter_type);
                    cbs = policer_item->policer_atrrib.cbs;
                    if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_PACKETS) {
                        actual_cbs = ((uint64_t)(1)) << cbs;
                    } else if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_TRAFFIC) {
                        actual_cbs = ((uint64_t)(512)) * (1 << cbs);
                    }
                    cir = policer_item->policer_atrrib.cir;
                    if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_PACKETS) {
                        actual_cir = cir;
                    } else if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_TRAFFIC) {
                        if (policer_item->policer_atrrib.ir_units == SX_POLICER_IR_UNITS_10_POWER_6_E) {
                            actual_cir = ((uint64_t)(cir)) * SX_POLICER_IR_UNIT_1M;
                        } else if (policer_item->policer_atrrib.ir_units == SX_POLICER_IR_UNITS_10_POWER_3_E) {
                            actual_cir = ((uint64_t)(cir)) * SX_POLICER_IR_UNIT_1K;
                        }
                    }
                    storm_control_attributes_clmns[12].data = sx_policer_action_str(
                        policer_item->policer_atrrib.red_action);
                    storm_control_attributes_clmns[13].data = sx_policer_ir_units_str(
                        policer_item->policer_atrrib.ir_units);
                    err = sdk_policer_counters_get(policer_id, &policer_counters);
                    if (SX_CHECK_FAIL(err)) {
                        SX_LOG_ERR("Failed to get policer %" PRIu64 " counters, err %s\n",
                                   policer_id, sx_status_str(err));
                        goto out;
                    }
                    dbg_utils_pprinter_table_data_line_print(stream, storm_control_attributes_clmns);
                }
                policer_item = NULL;
            }
        }
        if (port_attributes_p) {
            CL_FREE_N_NULL(port_attributes_p);
        }
    } /*Device for loop*/

    /* for each lag id */
    for (index = 0; index < rm_resource_global.lag_num_max; index++) {
        port = 0;
        SX_PORT_TYPE_ID_SET(port, SX_PORT_TYPE_LAG);
        SX_PORT_LAG_ID_SET(port, index);
        for (i = 0; i <= SX_PORT_STORM_CONTROL_ID_MAX; i++) {
            SX_POLICER_PID_SET(policer_id, i);
            SX_POLICER_LOG_PORT_SET(policer_id, port);
            __policer_db_find(policer_id, &policer_item);

            if (policer_item != NULL) {
                storm_control_id = i;
                packet_types = policer_item->policer_atrrib.packet_types;
                storm_control_attributes_clmns[7].data = sx_policer_meter_type_str(
                    policer_item->policer_atrrib.meter_type);
                cbs = policer_item->policer_atrrib.cbs;
                if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_PACKETS) {
                    actual_cbs = ((uint64_t)(1)) << cbs;
                } else if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_TRAFFIC) {
                    actual_cbs = ((uint64_t)(512)) * (1 << cbs);
                }
                cir = policer_item->policer_atrrib.cir;
                if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_PACKETS) {
                    actual_cir = cir;
                } else if (policer_item->policer_atrrib.meter_type == SX_POLICER_METER_TRAFFIC) {
                    if (policer_item->policer_atrrib.ir_units == SX_POLICER_IR_UNITS_10_POWER_6_E) {
                        actual_cir = ((uint64_t)(cir)) * SX_POLICER_IR_UNIT_1M;
                    } else if (policer_item->policer_atrrib.ir_units == SX_POLICER_IR_UNITS_10_POWER_3_E) {
                        actual_cir = ((uint64_t)(cir)) * SX_POLICER_IR_UNIT_1K;
                    }
                }
                storm_control_attributes_clmns[12].data =
                    sx_policer_action_str(policer_item->policer_atrrib.red_action);
                storm_control_attributes_clmns[13].data =
                    sx_policer_ir_units_str(policer_item->policer_atrrib.ir_units);
                err = sdk_policer_counters_get(policer_id, &policer_counters);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to get policer %" PRIu64 " counters, err %s\n",
                               policer_id, sx_status_str(err));
                    goto out;
                }
                dbg_utils_pprinter_table_data_line_print(stream, storm_control_attributes_clmns);
            }
            policer_item = NULL;
        }
    }

out:
    if (device_info_list_p) {
        CL_FREE_N_NULL(device_info_list_p);
    }
    return M_UTILS_SX_LOG_EXIT(sx_status);
}

sx_status_t policer_db_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream,
                                   "SDK Policer Module initialized",
                                   &(policer_db_init_done),
                                   PARAM_BOOL_E);
    if (policer_db_init_done == FALSE) {
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    sx_status = __policer_db_dump_globals(dbg_dump_params_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__policer_db_dump_globals failed. Error: %s.\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = __policer_db_dump_storm_control(dbg_dump_params_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__policer_db_dump_storm_control failed. Error: %s.\n",
                   sx_status_str(sx_status));
        goto out;
    }

out:
    return M_UTILS_SX_LOG_EXIT(sx_status);
}
