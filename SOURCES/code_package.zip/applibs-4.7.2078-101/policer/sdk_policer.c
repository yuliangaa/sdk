/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>

#include <complib/cl_types.h>
#include <complib/cl_mem.h>

#include <sx/sxd/sxd_access_register.h>

#include "sdk_policer.h"
#include "policer_db.h"
#include "ethl2/port.h"
#include "ethl2/port_db.h"
#include "utils/sx_adviser.h"
#include "ethl2/fdb_common.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/port_type_validate.h"
#include "ethl2/lag_sink.h"
#include "policer_manager.h"
#include "ethl2/brg.h"
#include "ethl2/lag.h"
#include "policer.h"
#include "issu/issu.h"

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ POLICER


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __policer_validate_traffic_type_reoccurance(const sx_port_log_id_t           log_port,
                                                               const sx_port_storm_control_id_t storm_control_id,
                                                               const sx_port_packet_types_t     port_packet_types);
static uint32_t __calculate_policer_cbs_value(sx_policer_db_attrib_t *policer_db_attrib_p);
static uint32_t __calculate_policer_ebs_value(sx_policer_db_attrib_t *policer_db_attrib_p);

/************************************************
 *  Function implementations
 ***********************************************/

/**
 * This function is a callback for the lag sink port change event
 *
 * @param[in]  lag_port_log_id  - notify on this lag log port
 * @param[in]  event_type    - new event type (CREATE/DESTORY)
 * @param[in]  port_log_id   - notify on this logical port id
 * @param[in]  context_p     - adviser context to be called from callback
 *
 * @return sx_status_t
 */
sx_status_t sdk_policer_lag_port_update(IN sx_port_id_t          lag_port_log_id,
                                        IN lag_sink_event_type_e event_type,
                                        IN sx_port_id_t          port_log_id,
                                        IN void                 *context_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(context_p);

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_POST_PORT_ADDED_E:
        break;

    case LAG_SINK_EVENT_TYPE_LAG_PORT_REMOVED_E:
        /* Should unbind port from storm controls */
        rc = policer_db_foreach_policer_on_lag_port(SX_ACCESS_CMD_UNBIND, lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR(
                "Failed removing storm control from port (0x%08X), error: %s\n",
                port_log_id, sx_status_str(rc));
            return rc;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        rc = policer_db_foreach_policer_on_lag_port(SX_ACCESS_CMD_DESTROY, lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("policer_db_foreach_policer Failed : %s\n", sx_status_str(rc));
            return rc;
        }

        /* unadvise destroyed lag id */
        rc = lag_sink_lag_unadvise(lag_port_log_id, sdk_policer_lag_port_update);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in lag_sink_lag_unadvise , error: %s\n", sx_status_str(rc));
            return rc;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_PRE_PORT_ADDED_VALIDATIONS_E:
        /* Unbind port from storm controls */
        rc = policer_db_foreach_policer_on_log_port(SX_ACCESS_CMD_UNBIND, lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR(
                "Failed removing storm control from port (0x%08X), error: %s\n",
                port_log_id,
                sx_status_str(rc));
            break;
        }
        /* Destroy the port storm controls */
        rc = policer_db_foreach_policer_on_log_port(SX_ACCESS_CMD_DESTROY, lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR(
                "Failed removing storm control from port (0x%08X), error: %s\n",
                port_log_id,
                sx_status_str(rc));
            break;
        }
        /* bind lag port storm controls to the log port */
        rc = policer_db_foreach_policer_on_lag_port(SX_ACCESS_CMD_BIND, lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR(
                "Failed removing storm control from port (0x%08X), error: %s\n",
                port_log_id,
                sx_status_str(rc));
            break;
        }
        break;

    default:
        SX_LOG_ERR("Wrong event type , event type: (%d)\n", event_type);
        return SX_STATUS_CMD_ERROR;
    }
    return rc;
}


sx_status_t sdk_policer_lag_global_update(IN sx_port_id_t          lag_port_log_id,
                                          IN lag_sink_event_type_e event_type,
                                          IN void                 *context_p)
{
    sx_status_t rc;

    UNUSED_PARAM(context_p);

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_CREATED_E:
        /* advise for the new lag */
        rc = lag_sink_lag_advise(lag_port_log_id, sdk_policer_lag_port_update,
                                 NULL, 0);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in lag_sink_lag_advise , error: %s\n", sx_status_str(rc));
            return rc;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        break;

    default:
        SX_LOG_ERR(
            "Wrong event type , event type: (%d)\n",
            event_type);
        return SX_STATUS_CMD_ERROR;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t sdk_handle_qpcr(sx_access_cmd_t         cmd,
                            sx_policer_id_t         policer_id,
                            sx_policer_db_attrib_t *policer_attrib_p,
                            sx_port_log_id_t        log_port)
{
    struct ku_qpcr_reg             qpcr_reg_data;
    sxd_reg_meta_t                 qpcr_reg_meta;
    sx_status_t                    rc = SX_STATUS_SUCCESS, rb_status = SX_STATUS_SUCCESS;
    uint32_t                       device_index = 0;
    length_t                       device_cnt = 0;
    sx_dev_info_t                  device_list_arr[SX_DEV_ID_MAX];
    policer_manager_index_t        policer_hw_id = 0;
    policer_manager_block_length_t policer_size = 0;
    policer_manager_policer_type_e policer_type = 0;

    SX_LOG_ENTER();
    UNUSED_PARAM(log_port);

    SX_MEM_CLR(qpcr_reg_meta);
    SX_MEM_CLR(qpcr_reg_data);
    SX_MEM_CLR(device_list_arr);

    qpcr_reg_meta.swid = policer_attrib_p->type_base_params.swid;
    if (policer_attrib_p->policer_type == SX_POLICER_TYPE_STORM_CONTROL_E) {
        rc = port_db_swid_alloc_get(policer_attrib_p->type_base_params.log_port, &qpcr_reg_meta.swid);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("fail to get logical port SWID (%s)\n", sx_status_str(rc));
            goto out;
        }
        device_cnt = 1;
        /* Spectrum port param is on QPBR - dev_id is only a place holder */
        qpcr_reg_meta.dev_id = 1;
    }

    if (policer_attrib_p->policer_type == SX_POLICER_TYPE_GLOBAL_E) {
        rc = port_device_list_get(SX_ACCESS_CMD_COUNT, NULL, &device_cnt);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in port_device_list_get : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        if (device_cnt == 0) {
            rc = SX_STATUS_SUCCESS;
            goto out;
        }

        rc = port_device_list_get(SX_ACCESS_CMD_GET, device_list_arr, &device_cnt);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in port_device_list_get : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        if (policer_attrib_p->is_host_ifc_policer) {
            policer_type = POLICER_MANAGER_TYPE_HOST_IFC_E;
        } else {
            if (policer_attrib_p->is_span_session_policer) {
                policer_type = POLICER_MANAGER_TYPE_SPAN_E;
            } else {
                policer_type = POLICER_MANAGER_TYPE_ACL_E;
            }
        }
    } else {
        policer_type = POLICER_MANAGER_TYPE_STORM_CONTROL_E;
    }

    rc = policer_manager_handle_lock(policer_id,
                                     policer_type,
                                     &policer_hw_id,
                                     &policer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in policer_manager_block_add : error (%s)\n", sx_status_str(rc));
        goto out;
    }


    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        qpcr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        qpcr_reg_data.global_policer = policer_attrib_p->policer_type;
        qpcr_reg_data.pid = policer_hw_id;
        qpcr_reg_data.color_aware = policer_attrib_p->color_aware;
        qpcr_reg_data.use_bytes = policer_attrib_p->meter_type;
        qpcr_reg_data.ir_units = policer_attrib_p->ir_units;
        qpcr_reg_data.type = policer_attrib_p->rate_type;
        qpcr_reg_data.mode = SX_POLICER_MODE_POLICER_E;
        qpcr_reg_data.committed_burst_size = policer_attrib_p->cbs;
        qpcr_reg_data.committed_information_rate = policer_attrib_p->cir;
        if (qpcr_reg_data.type == SX_POLICER_RATE_TYPE_DUAL_RATE_E) {
            /* The following are relevant for dual rate policer only */
            qpcr_reg_data.extended_burst_size = policer_attrib_p->ebs;
            qpcr_reg_data.excess_information_rate = policer_attrib_p->eir;
            qpcr_reg_data.exceed_action = SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR;
        }
        qpcr_reg_data.violate_action = policer_attrib_p->red_action;
        qpcr_reg_data.clear_counter = policer_attrib_p->clear_counter;
        qpcr_reg_data.add_counter = policer_attrib_p->add_counter;


        for (device_index = 0; device_index < device_cnt; device_index++) {
            if (policer_attrib_p->policer_type == SX_POLICER_TYPE_GLOBAL_E) {
                qpcr_reg_meta.dev_id = device_list_arr[device_index].dev_id;
            }
            rc =
                sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_QPCR_E, &qpcr_reg_data,
                                                                            &qpcr_reg_meta, 1, NULL, NULL));
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("sxd_access_reg_qpcr failed, error: %s\n", sx_status_str(rc));
                goto out_release_policer;
            }
        }
        break;

    case SX_ACCESS_CMD_GET:
        qpcr_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        qpcr_reg_data.global_policer = policer_attrib_p->policer_type;
        qpcr_reg_data.pid = policer_hw_id;
        if (policer_attrib_p->policer_type == SX_POLICER_TYPE_GLOBAL_E) {
            qpcr_reg_meta.dev_id = device_list_arr[device_index].dev_id;
        }
        rc =
            sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_QPCR_E, &qpcr_reg_data,
                                                                        &qpcr_reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("sxd_access_reg_qpcr failed, error: %s\n", sx_status_str(rc));
            goto out_release_policer;
        }
        policer_attrib_p->color_aware = qpcr_reg_data.color_aware;
        policer_attrib_p->meter_type = qpcr_reg_data.use_bytes;
        policer_attrib_p->ir_units = qpcr_reg_data.ir_units;
        policer_attrib_p->rate_type = qpcr_reg_data.type;
        policer_attrib_p->mode = SX_POLICER_MODE_POLICER_E;
        policer_attrib_p->cbs = qpcr_reg_data.committed_burst_size;
        policer_attrib_p->cir = qpcr_reg_data.committed_information_rate;
        policer_attrib_p->ebs = qpcr_reg_data.extended_burst_size;
        policer_attrib_p->eir = qpcr_reg_data.excess_information_rate;
        policer_attrib_p->red_action = qpcr_reg_data.violate_action;
        policer_attrib_p->violate_count = qpcr_reg_data.violate_count;
        break;

    default:
        SX_LOG_ERR("Wrong access command , access command: (%u)\n", cmd);
        rc = SX_STATUS_CMD_ERROR;
        break;
    }

out_release_policer:
    rb_status = policer_manager_handle_release(policer_id, policer_type);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Error in policer_manager_block_add : error (%s)\n", sx_status_str(rb_status));
    }
    /* if handle_release failed and it's the first failure */
    if (SX_CHECK_PASS(rc) && SX_CHECK_FAIL(rb_status)) {
        rc = rb_status;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __policer_set_attributes_to_dev(policer_db_item_t *policer_item, void *param_p)
{
    UNUSED_PARAM(param_p);
    return sdk_handle_qpcr(SX_ACCESS_CMD_SET,
                           policer_item->policer_id,
                           &(policer_item->policer_atrrib),
                           SX_POLICER_LOG_PORT_GET(policer_item->policer_id));
}

sx_status_t sdk_policer_device_ready_callback(adviser_event_e event, void *param)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (event != ADVISER_EVENT_POST_DEVICE_READY_E) {
        SX_LOG_ERR("Wrong event type, expected event type is ADVISER_EVENT_DEVICE_READY, "
                   "received event type : [%s].\n",
                   ADVISER_EVENT_STR(event));
        err = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    err = policer_db_add_device_foreach(__policer_set_attributes_to_dev, param);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Error in add device : error (%s)\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_policer_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    policer_db_log_verbosity_level_set(verbosity_level);

    return err;
}

sx_status_t sdk_policer_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

    return err;
}


sx_status_t sdk_policer_init(void)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_boot_mode_e issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    uint32_t       policer_host_ifc_pool_size = rm_resource_global.policer_host_ifc_pool_size;
    uint32_t       policer_pool_size = rm_resource_global.policer_pool_size;
    uint32_t       policer_span_start_index = policer_pool_size + policer_host_ifc_pool_size;
    uint32_t       policer_span_end_index = policer_span_start_index + rm_resource_global.policer_span_pool_size;

    SX_LOG_ENTER();

    err = issu_boot_mode_get(&issu_boot_mode);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get boot mode. status = %s\n",
                   sx_status_str(err));
        goto out;
    }

    if (issu_boot_mode != SX_BOOT_MODE_DISABLED_E) {
        policer_pool_size /= 2;
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 sdk_policer_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event, error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

    err = lag_sink_global_advise(sdk_policer_lag_global_update, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in lag_sink_global_advise, error: %s \n", sx_status_str(err));
        goto out;
    }


    err = policer_manager_init(policer_host_ifc_pool_size,
                               policer_pool_size + policer_host_ifc_pool_size,
                               0,
                               policer_host_ifc_pool_size,
                               0,
                               rm_resource_global.policer_storm_control_pool_size,
                               policer_span_start_index,
                               policer_span_end_index,
                               policer_block_copy,
                               policer_increase_counters);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in policer_manager_init, error: %s \n", sx_status_str(err));
        goto out;
    }


    err = policer_db_init(
        rm_resource_global.policer_host_ifc_pool_size + rm_resource_global.policer_pool_size +
        rm_resource_global.policer_storm_control_pool_size + rm_resource_global.policer_span_pool_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in policer_db_init, error: %s \n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_policer_deinit(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = policer_manager_deinit();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in policer_manager_deinit, error: %s \n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 sdk_policer_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event, error: %s.\n",
                   sx_status_str(err));
        goto out;
    }
    err = lag_sink_global_unadvise(sdk_policer_lag_global_update);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in lag_sink_global_unadvise, error: %s \n", sx_status_str(err));
        goto out;
    }

    err = policer_db_deinit();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in policer_db_deinit, error: %s \n", sx_status_str(err));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return err;
}

static uint32_t __calculate_policer_cbs_value(sx_policer_db_attrib_t *policer_db_attrib_p)
{
    /* acc to PRM.  QPCR register CBS is input as a power of 2. Therefore for Spc family
     * actual CBS = 2^CBS (pps) or 2^CBS * 512 (bits)
     * Actual Cbs can be calculated from CIR as follows (max 32GBps)
     * Actual CBS = ((cir * rate * 400) / (10^6 * 512))
     *     when bytes = 1; rate == 10^3 (if ir_units = 1)
     *                     rate == 10^6 (if ir_units = 0)
     *     when bytes = 0; cbs == cir
     * CBS is rounded up to the nearest power of 2 or = Ceil(log2(actual cbs))
     */
    uint64_t tmp_cbs = 0;
    uint32_t pwr_of_2 = 0;
    uint32_t rate = 0;

    /* find the rate to use first */
    if (policer_db_attrib_p->meter_type == SX_POLICER_METER_TRAFFIC) {
        /* PRM formula asks to do cir * rate
         * for meter type traffic (bytes/sec) rate is dependent on ir_units(so cir * 10^3 or cir * 10^6)
         * but since the time is in micro-sec, we must also div by 10^6. as they may cancel out
         * its simpler to div by corresponding rate instead*/
        if (policer_db_attrib_p->ir_units == SX_POLICER_IR_UNITS_10_POWER_3_E) {
            rate = 1000;
        } else {
            rate = 1;
        }
        /* compute actual CBS */
        tmp_cbs =
            (((uint64_t)(policer_db_attrib_p->cir) * rm_resource_global.policer_cbs_bytes_multiplier) / (rate * 512));
    } else {
        /* for bytes = 0, cbs should be equal to cir converted as power of 2*/
        tmp_cbs = (policer_db_attrib_p->cir);
    }

    /* now convert actual CBS to the nearest power of 2  */
    while (tmp_cbs) {
        pwr_of_2++;
        tmp_cbs >>= 1;
    }

    /* we must ensure we do not cross the max allowed values */
    if (policer_db_attrib_p->meter_type == SX_POLICER_METER_PACKETS) {
        return MIN(pwr_of_2, rm_resource_global.policer_bs_max_value_packets);
    } else {
        return MIN(pwr_of_2, rm_resource_global.policer_bs_max_value_bytes);
    }
}

static uint32_t __calculate_policer_ebs_value(sx_policer_db_attrib_t *policer_db_attrib_p)
{
    /* acc to PRM. for Spc family
     * Actual EBS = (cir or eir) * rate * 50uSec (max 32GBps)
     *     use cir when rate_type = single rate, eir when rate_type =  double rate.
     *     when bytes = 0; rate == 10^3
     *     when bytes = 1; rate == 10^3 (if ir_units = 1)
     *                     rate == 10^6 (if ir_units = 0)
     * QPCR register EBS is input as a power of 2. Therefore above value is
     * then rounded up to the nearest 2^x
     */
    uint64_t tmp_ebs = 0;
    uint32_t pwr_of_2 = 0;
    uint32_t rate = 0;
    uint64_t cir_or_eir = 0;

    /* find whether to use cir or eir */
    if (policer_db_attrib_p->rate_type == SX_POLICER_RATE_TYPE_SINGLE_RATE_E) {
        cir_or_eir = (uint64_t)policer_db_attrib_p->cir;
    } else {
        cir_or_eir = (uint64_t)policer_db_attrib_p->eir;
    }

    /* find the rate to use  */
    if (policer_db_attrib_p->meter_type == SX_POLICER_METER_TRAFFIC) {
        /* for meter type traffic (bytes/sec) rate is dependent on ir_units */
        if (policer_db_attrib_p->ir_units == SX_POLICER_IR_UNITS_10_POWER_3_E) {
            rate = 1000; /*equivalent to div by 10^3 */
        } else {
            rate = 1; /*10^6 */
        }
        /* compute the EBS next */
        tmp_ebs = ((cir_or_eir * 50) / (rate * 512));
    } else {
        /* for bytes = 0, EBS is equal to cir or eir */
        tmp_ebs = cir_or_eir;
    }

    /* now convert actual EBS to the highest power of 2 factor */
    while (tmp_ebs) {
        pwr_of_2++;
        tmp_ebs >>= 1;
    }

    /* we must ensure we do not cross the max allowed values */
    if (policer_db_attrib_p->meter_type == SX_POLICER_METER_PACKETS) {
        return MIN(pwr_of_2, rm_resource_global.policer_bs_max_value_packets);
    } else {
        return MIN(pwr_of_2, rm_resource_global.policer_bs_max_value_bytes);
    }
}
sx_status_t sdk_policer_validate_attrib(sx_policer_mode_e       mode,
                                        sx_policer_info_t      *policer_info_p,
                                        sx_policer_db_attrib_t *policer_db_attrib_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    multiplier = 1;
    uint64_t    rate = 0;
    uint32_t    tmp_cbs_ebs = 0;


    SX_LOG_ENTER();

    if (mode != SX_POLICER_MODE_POLICER_E) {
        SX_LOG_ERR("Policer mode [%u] != SX_POLICER_MODE_POLICER_E.\n",
                   mode);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((policer_info_p->policer_type != SX_POLICER_TYPE_GLOBAL_E) &&
        (policer_info_p->policer_type != SX_POLICER_TYPE_STORM_CONTROL_E)) {
        SX_LOG_ERR("Policer type (%u) exceeds range (%u...%u)\n",
                   policer_info_p->policer_type,
                   SX_POLICER_TYPE_GLOBAL_E,
                   SX_POLICER_TYPE_STORM_CONTROL_E);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    policer_db_attrib_p->policer_type = policer_info_p->policer_type;
    policer_db_attrib_p->type_base_params = policer_info_p->type_base_params;

    policer_db_attrib_p->meter_type = policer_info_p->policer_attributes.meter_type;
    policer_db_attrib_p->cbs = policer_info_p->policer_attributes.cbs;
    policer_db_attrib_p->ebs = policer_info_p->policer_attributes.ebs;
    policer_db_attrib_p->cir = policer_info_p->policer_attributes.cir;
    policer_db_attrib_p->yellow_action = policer_info_p->policer_attributes.yellow_action;
    policer_db_attrib_p->red_action = policer_info_p->policer_attributes.red_action;
    policer_db_attrib_p->eir = policer_info_p->policer_attributes.eir;
    policer_db_attrib_p->rate_type = policer_info_p->policer_attributes.rate_type;
    policer_db_attrib_p->color_aware = policer_info_p->policer_attributes.color_aware;
    policer_db_attrib_p->is_host_ifc_policer = policer_info_p->policer_attributes.is_host_ifc_policer;
    policer_db_attrib_p->is_span_session_policer = policer_info_p->policer_attributes.is_span_session_policer;
    policer_db_attrib_p->ir_units = policer_info_p->policer_attributes.ir_units;

    if (policer_info_p->policer_type == SX_POLICER_TYPE_STORM_CONTROL_E) {
        SX_MEM_CPY(policer_db_attrib_p->packet_types, policer_info_p->packet_types);
    }

    if (policer_db_attrib_p->meter_type > SX_POLICER_METER_MAX) {
        SX_LOG_ERR("Meter type (%u) exceeds range (%u)\n",
                   policer_db_attrib_p->meter_type,
                   SX_POLICER_METER_MAX);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (policer_db_attrib_p->ir_units > SX_POLICER_IR_UNITS_MAX_E) {
        SX_LOG_ERR("ir units (%u) exceeds range (%u)\n",
                   policer_db_attrib_p->ir_units,
                   SX_POLICER_IR_UNITS_MAX_E);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((policer_db_attrib_p->meter_type == SX_POLICER_METER_PACKETS)) {
        if (policer_db_attrib_p->cir > SDK_POLICER_MAX_IR_PPS) {
            SX_LOG_ERR("CIR (%u) is greater than max size 2G packets per second.\n", policer_db_attrib_p->cir);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib_p->eir > SDK_POLICER_MAX_IR_PPS) {
            SX_LOG_ERR("EIR (%u) is greater than max size 2G packets per second.\n", policer_db_attrib_p->eir);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib_p->cbs > rm_resource_global.policer_bs_max_value_packets) {
            SX_LOG_ERR("CBS (%u) exceeds range (%u)\n",
                       policer_db_attrib_p->cbs,
                       rm_resource_global.policer_bs_max_value_packets);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib_p->ebs > rm_resource_global.policer_bs_max_value_packets) {
            SX_LOG_ERR("EBS (%u) exceeds range (%u)\n",
                       policer_db_attrib_p->ebs,
                       rm_resource_global.policer_bs_max_value_packets);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        /* Ensure minimum value for CBS and EBS */
        if (policer_db_attrib_p->cbs < rm_resource_global.policer_bs_min_value_packets) {
            tmp_cbs_ebs = __calculate_policer_cbs_value(policer_db_attrib_p);
            policer_db_attrib_p->cbs = MAX(tmp_cbs_ebs,
                                           rm_resource_global.policer_bs_min_value_packets);
        }

        if (policer_db_attrib_p->ebs < rm_resource_global.policer_bs_min_value_packets) {
            tmp_cbs_ebs = __calculate_policer_ebs_value(policer_db_attrib_p);
            policer_db_attrib_p->ebs = MAX(tmp_cbs_ebs,
                                           rm_resource_global.policer_bs_min_value_packets);
        }
    }

    if (policer_db_attrib_p->meter_type == SX_POLICER_METER_TRAFFIC) {
        multiplier = (policer_db_attrib_p->ir_units) ? SX_POLICER_IR_UNIT_1K : SX_POLICER_IR_UNIT_1M;

        rate = (uint64_t)policer_db_attrib_p->cir * (uint64_t)multiplier;
        if (rate > SDK_POLICER_MAX_IR_BPS) {
            SX_LOG_ERR("CIR (%u) is greater than max size 2T byte per second.\n", policer_db_attrib_p->cir);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        rate = (uint64_t)policer_db_attrib_p->eir * (uint64_t)multiplier;
        if (rate > SDK_POLICER_MAX_IR_BPS) {
            SX_LOG_ERR("EIR (%u) is greater than max size 2T byte per second.\n", policer_db_attrib_p->eir);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib_p->cbs > rm_resource_global.policer_bs_max_value_bytes) {
            SX_LOG_ERR("CBS (%u) exceeds range (%u)\n",
                       policer_db_attrib_p->cbs,
                       rm_resource_global.policer_bs_max_value_bytes);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib_p->ebs > rm_resource_global.policer_bs_max_value_bytes) {
            SX_LOG_ERR("EBS (%u) exceeds range (%u)\n",
                       policer_db_attrib_p->ebs,
                       rm_resource_global.policer_bs_max_value_bytes);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        /* Ensure minimum value for CBS and EBS */
        if (policer_db_attrib_p->cbs < rm_resource_global.policer_bs_min_value_bytes) {
            tmp_cbs_ebs = __calculate_policer_cbs_value(policer_db_attrib_p);
            policer_db_attrib_p->cbs = MAX(tmp_cbs_ebs,
                                           rm_resource_global.policer_bs_min_value_bytes);
        }

        if (policer_db_attrib_p->ebs < rm_resource_global.policer_bs_min_value_bytes) {
            tmp_cbs_ebs = __calculate_policer_ebs_value(policer_db_attrib_p);
            policer_db_attrib_p->ebs = MAX(tmp_cbs_ebs,
                                           rm_resource_global.policer_bs_min_value_bytes);
        }
    }

    if ((policer_info_p->policer_type == SX_POLICER_TYPE_GLOBAL_E) &&
        (policer_db_attrib_p->rate_type != SX_POLICER_RATE_TYPE_SINGLE_RATE_E) &&
        (policer_db_attrib_p->rate_type != SX_POLICER_RATE_TYPE_DUAL_RATE_E)) {
        SX_LOG_ERR("rate type (%u) is invalid.\n", policer_db_attrib_p->rate_type);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((policer_info_p->policer_type == SX_POLICER_TYPE_STORM_CONTROL_E) &&
        (policer_db_attrib_p->rate_type != SX_POLICER_RATE_TYPE_SINGLE_RATE_E)) {
        SX_LOG_ERR("rate type (%u) is invalid.\n", policer_db_attrib_p->rate_type);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((policer_db_attrib_p->red_action != SX_POLICER_ACTION_DISCARD) &&
        (policer_db_attrib_p->red_action != SX_POLICER_ACTION_FORWARD_SET_RED_COLOR) &&
        (policer_db_attrib_p->red_action != SX_POLICER_ACTION_SOFT_DONT_TRAP)) {
        SX_LOG_ERR("Red action (%u) is not valid. The valid values are %u, %u or %u\n",
                   policer_db_attrib_p->red_action,
                   SX_POLICER_ACTION_DISCARD,
                   SX_POLICER_ACTION_FORWARD_SET_RED_COLOR,
                   SX_POLICER_ACTION_SOFT_DONT_TRAP);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((policer_db_attrib_p->rate_type == SX_POLICER_RATE_TYPE_DUAL_RATE_E) &&
        (policer_db_attrib_p->yellow_action != SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR)) {
        SX_LOG_ERR("Yellow action (%u) is not valid. The valid value is %u\n",
                   policer_db_attrib_p->yellow_action,
                   SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (policer_db_attrib_p->policer_type == SX_POLICER_TYPE_STORM_CONTROL_E) {
        rc = sx_fdb_check_swid(policer_db_attrib_p->type_base_params.swid);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in swid validation\n");
            goto out;
        }
        if (SX_POLICER_ACTION_DISCARD != policer_db_attrib_p->red_action) {
            SX_LOG_ERR("Storm control red action (%u) cannot be different than DISCARD (%u)\n",
                       policer_db_attrib_p->red_action,
                       SX_POLICER_ACTION_DISCARD);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (policer_db_attrib_p->is_host_ifc_policer == TRUE) {
            SX_LOG_ERR("Storm controls cannot be a host_ifc policer\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (policer_db_attrib_p->is_span_session_policer == TRUE) {
            SX_LOG_ERR("Storm controls cannot be a SPAN policer\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    if (policer_db_attrib_p->is_host_ifc_policer == TRUE) {
        if (policer_db_attrib_p->rate_type != SX_POLICER_RATE_TYPE_SINGLE_RATE_E) {
            SX_LOG_ERR("Cannot create a host interface policer with a different "
                       "policer type than one rate, two colors marker.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (policer_db_attrib_p->red_action == SX_POLICER_ACTION_SOFT_DONT_TRAP) {
            SX_LOG_ERR("Cannot create a host interface policer with a don't trap action.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    if (policer_db_attrib_p->is_span_session_policer == TRUE) {
        if (policer_db_attrib_p->is_host_ifc_policer != FALSE) {
            SX_LOG_ERR("Policer cannot be both SPAN AND host interface.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (policer_db_attrib_p->color_aware != FALSE) {
            SX_LOG_ERR("SPAN policer color aware is invalid (%u). Must be FALSE.\n", policer_db_attrib_p->color_aware);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (policer_db_attrib_p->rate_type != SX_POLICER_RATE_TYPE_SINGLE_RATE_E) {
            SX_LOG_ERR("SPAN policer rate type is invalid (%u). Must be SINGLE RATE.\n",
                       policer_db_attrib_p->rate_type);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (policer_db_attrib_p->red_action != SX_POLICER_ACTION_DISCARD) {
            SX_LOG_ERR("SPAN policer red action is invalid (%u). Must be DISCARD.\n",
                       policer_db_attrib_p->red_action);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    return M_UTILS_SX_LOG_EXIT(rc);
}

sx_status_t sdk_policer_validate_attrib_spectrum(sx_policer_mode_e       mode,
                                                 sx_policer_info_t      *policer_info_p,
                                                 sx_policer_db_attrib_t *policer_db_attrib_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (policer_info_p->policer_attributes.is_span_session_policer == TRUE) {
        SX_LOG_ERR("Spectrum does not support SPAN session policer.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = sdk_policer_validate_attrib(mode, policer_info_p, policer_db_attrib_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (policer_info_p->policer_attributes.red_action == SX_POLICER_ACTION_SOFT_DONT_TRAP) {
        SX_LOG_ERR("Policer red action: soft don't trap is not supported by this chip type.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return M_UTILS_SX_LOG_EXIT(rc);
}

sx_status_t sdk_policer_validate_attrib_spectrum2(sx_policer_mode_e       mode,
                                                  sx_policer_info_t      *policer_info_p,
                                                  sx_policer_db_attrib_t *policer_db_attrib_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = sdk_policer_validate_attrib(mode, policer_info_p, policer_db_attrib_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    if (policer_info_p->policer_attributes.red_action == SX_POLICER_ACTION_SOFT_DONT_TRAP) {
        SX_LOG_ERR("Policer red action: soft don't trap is not supported by this chip type.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return M_UTILS_SX_LOG_EXIT(rc);
}

sx_status_t sdk_policer_validate_attrib_spectrum4(sx_policer_mode_e       mode,
                                                  sx_policer_info_t      *policer_info_p,
                                                  sx_policer_db_attrib_t *policer_db_attrib_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = sdk_policer_validate_attrib(mode, policer_info_p, policer_db_attrib_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

out:
    return M_UTILS_SX_LOG_EXIT(rc);
}


sx_status_t sdk_policer_set(const sx_access_cmd_t   cmd,
                            const sx_policer_mode_e mode,
                            sx_policer_id_t       * policer_id_p,
                            sx_policer_info_t     * policer_info)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_policer_type_e      policer_type;
    sx_policer_db_attrib_t policer_db_attrib;

    SX_LOG_ENTER();

    SX_MEM_CLR(policer_db_attrib);

    policer_type = (cmd == SX_ACCESS_CMD_DESTROY) ? SDK_POLICER_TYPE_GET(*policer_id_p) : policer_info->policer_type;
    if (policer_type == SX_POLICER_TYPE_PER_PORT_E) {
        policer_type = SX_POLICER_TYPE_STORM_CONTROL_E;
        policer_info->policer_type = SX_POLICER_TYPE_STORM_CONTROL_E;
    }

    if (policer_type == SX_POLICER_TYPE_GLOBAL_E) {
        rc = sdk_policer_global_set(cmd, mode, policer_id_p, policer_info);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_RESOURCE_COND(rc, "Failed to set global policer, err: %s\n",
                                     sx_status_str(rc));
            goto out;
        }
    }
    if (policer_type == SX_POLICER_TYPE_STORM_CONTROL_E) {
        rc = sdk_policer_storm_control_set(cmd, mode, policer_id_p, policer_info);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_RESOURCE_COND(rc, "Failed to set storm control, err: %s\n",
                                     sx_status_str(rc));
            goto out;
        }
    }
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Wrong policer type (%u)\n", policer_type);
    }

out:
    return M_UTILS_SX_LOG_EXIT(rc);
}

sx_status_t sdk_policer_global_set(const sx_access_cmd_t   cmd,
                                   const sx_policer_mode_e mode,
                                   sx_policer_id_t       * policer_id_p,
                                   sx_policer_info_t     * policer_info)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS, rb_status = SX_STATUS_SUCCESS;
    sx_policer_db_attrib_t         old_policer_attrib;
    uint32_t                       bind_num = 0;
    sx_policer_type_e              policer_type;
    sx_policer_db_attrib_t         policer_db_attrib;
    policer_manager_block_length_t policer_size = 0;
    sx_policer_id_t                policer_id = (cmd != SX_ACCESS_CMD_CREATE) ? *policer_id_p : 0;
    policer_manager_policer_type_e policer_manager_type;

    SX_LOG_ENTER();

    SX_MEM_CLR(policer_db_attrib);

    policer_type = (cmd == SX_ACCESS_CMD_DESTROY) ? SDK_POLICER_TYPE_GET(policer_id) : policer_info->policer_type;
    if (policer_type == SX_POLICER_TYPE_PER_PORT_E) {
        policer_type = SX_POLICER_TYPE_STORM_CONTROL_E;
        policer_info->policer_type = SX_POLICER_TYPE_STORM_CONTROL_E;
    }

    if (policer_type != SX_POLICER_TYPE_GLOBAL_E) {
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        rc = policer_validate_attrib(mode, policer_info, &policer_db_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in validation of policer_info : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        policer_db_attrib.clear_counter = TRUE;
        policer_db_attrib.add_counter = FALSE;

        if (policer_info->policer_attributes.rate_type == SX_POLICER_RATE_TYPE_DUAL_RATE_E) {
            policer_size = SX_POLICER_RATE_TYPE_DUAL_RATE_E;
        } else { /* rate_type == SX_POLICER_RATE_TYPE_SINGLE_RATE_E */
            policer_size = SX_POLICER_RATE_TYPE_SINGLE_RATE_E;
        }

        if (policer_info->policer_attributes.is_host_ifc_policer) {
            policer_manager_type = POLICER_MANAGER_TYPE_HOST_IFC_E;
        } else {
            if (policer_info->policer_attributes.is_span_session_policer) {
                policer_manager_type = POLICER_MANAGER_TYPE_SPAN_E;
            } else {
                policer_manager_type = POLICER_MANAGER_TYPE_ACL_E;
            }
        }
        rc = policer_manager_block_add(policer_size,
                                       policer_manager_type,
                                       &policer_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_RESOURCE_COND(rc, "Failed to add policer to policer manager, err: %s\n",
                                     sx_status_str(rc));
            goto out;
        }

        rc = policer_db_create(&policer_db_attrib, &policer_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in allocation policer : error (%s)\n", sx_status_str(rc));
            goto rollback1;
        }

        rc = sdk_handle_qpcr(SX_ACCESS_CMD_SET,
                             policer_id,
                             &policer_db_attrib,
                             SX_POLICER_LOG_PORT_GET(policer_id));
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in sdk_handle_qpcr : error (%s)\n", sx_status_str(rc));
            goto rollback2;
        }
        *policer_id_p = policer_id;

        break; /* CREATE */

    case SX_ACCESS_CMD_DESTROY:

        rc = policer_db_attrib_get(policer_id, &old_policer_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        rc = policer_db_binds_get(policer_id, &bind_num);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error receiving number of bound policer : error (%s)\n", sx_status_str(rc));
            goto out;
        }
        if (bind_num == 0) {
            rc = policer_db_destroy(policer_id);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in policer destroy : error (%s)\n", sx_status_str(rc));
                goto out;
            }
        } else {
            SX_LOG_ERR("Error in policer destroy : can't destroy bound policer.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        if (old_policer_attrib.is_host_ifc_policer) {
            policer_manager_type = POLICER_MANAGER_TYPE_HOST_IFC_E;
        } else {
            if (old_policer_attrib.is_span_session_policer) {
                policer_manager_type = POLICER_MANAGER_TYPE_SPAN_E;
            } else {
                policer_manager_type = POLICER_MANAGER_TYPE_ACL_E;
            }
        }
        rc = policer_manager_block_delete(policer_id, policer_manager_type);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in policer_manager_block_delete : error (%s)\n", sx_status_str(rc));
            /* DB rollback */
            rb_status = policer_db_create(&old_policer_attrib, &policer_id);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Error in allocation policer : error (%s)\n", sx_status_str(rb_status));
            }
            goto out;
        }
        break; /* DESTROY */

    case SX_ACCESS_CMD_EDIT:
        if (SX_POLICER_TYPE_GET(policer_id) != SX_POLICER_TYPE_GLOBAL_E) {
            SX_LOG_ERR("Cannot change policer type\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        rc = sdk_policer_validate_attrib(mode, policer_info, &policer_db_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in validation of policer_info : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        rc = policer_db_attrib_get(policer_id, &old_policer_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        if (policer_db_attrib.meter_type != old_policer_attrib.meter_type) {
            SX_LOG_ERR("Can't edit policer meter type.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib.red_action != old_policer_attrib.red_action) {
            SX_LOG_ERR("Can't edit policer red action.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib.color_aware != old_policer_attrib.color_aware) {
            SX_LOG_ERR("Can't edit policer color awareness mode.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib.is_host_ifc_policer != old_policer_attrib.is_host_ifc_policer) {
            SX_LOG_ERR("Can't edit policer is_host_ifc field.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib.is_span_session_policer != old_policer_attrib.is_span_session_policer) {
            SX_LOG_ERR("Can't edit policer is_span_session_policer field.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        rc = policer_db_binds_get(policer_id, &bind_num);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error receiving number of bound policers : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        if ((bind_num > 0) && (policer_info->policer_type == SX_POLICER_TYPE_GLOBAL_E)
            && (old_policer_attrib.meter_type != policer_info->policer_attributes.meter_type)) {
            SX_LOG_ERR("Cannot change policer metering type while the policer is bound\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib.is_host_ifc_policer) {
            policer_manager_type = POLICER_MANAGER_TYPE_HOST_IFC_E;
        } else {
            if (policer_db_attrib.is_span_session_policer) {
                policer_manager_type = POLICER_MANAGER_TYPE_SPAN_E;
            } else {
                policer_manager_type = POLICER_MANAGER_TYPE_ACL_E;
            }
        }
        rc = policer_manager_block_size_get(policer_id,
                                            policer_manager_type,
                                            &policer_size);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in policer_manager_block_size_get : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        if (((policer_info->policer_attributes.rate_type == SX_POLICER_RATE_TYPE_DUAL_RATE_E) &&
             (policer_size != 2)) ||
            ((policer_info->policer_attributes.rate_type == SX_POLICER_RATE_TYPE_SINGLE_RATE_E) &&
             (policer_size != 1))) {
            SX_LOG_ERR("Can't edit policer rate type.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        rc = policer_db_attrib_set(policer_id, &policer_db_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in editing policer attributes : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        policer_db_attrib.clear_counter = FALSE;
        policer_db_attrib.add_counter = FALSE;

        rc = sdk_handle_qpcr(SX_ACCESS_CMD_SET,
                             policer_id,
                             &policer_db_attrib,
                             SX_POLICER_LOG_PORT_GET(policer_id));
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in sdk_handle_qpcr : error (%s)\n", sx_status_str(rc));
            rb_status = policer_db_attrib_set(policer_id, &old_policer_attrib);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Error in editing policer attributes : error (%s)\n", sx_status_str(rb_status));
            }
            goto out;
        }


        break; /* EDIT */

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    goto out;


rollback2:
    rb_status = policer_db_destroy(policer_id);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Error in policer destroy : error (%s)\n", sx_status_str(rb_status));
    }

rollback1:
    rb_status = policer_manager_block_delete(policer_id, policer_manager_type);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Error in policer_manager_block_delete : error (%s)\n", sx_status_str(rb_status));
    }

out:
    return M_UTILS_SX_LOG_EXIT(rc);
}

sx_status_t sdk_policer_storm_control_set(const sx_access_cmd_t   cmd,
                                          const sx_policer_mode_e mode,
                                          sx_policer_id_t       * policer_id_p,
                                          sx_policer_info_t     * policer_info)
{
    sx_status_t            rc = SX_STATUS_SUCCESS, rb_status = SX_STATUS_SUCCESS;
    sx_policer_db_attrib_t old_policer_attrib;
    sx_policer_db_attrib_t policer_db_attrib;
    sx_policer_id_t        policer_id = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(policer_db_attrib);

    if (policer_id_p == NULL) {
        SX_LOG_ERR("policer_id_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }
    policer_id = *policer_id_p;

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        rc = sdk_policer_validate_attrib(mode, policer_info, &policer_db_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in validation of policer_info : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        policer_db_attrib.clear_counter = TRUE;
        policer_db_attrib.add_counter = FALSE;

        rc = policer_manager_block_add(SX_POLICER_RATE_TYPE_SINGLE_RATE_E,
                                       POLICER_MANAGER_TYPE_STORM_CONTROL_E,
                                       &policer_db_attrib.lid);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_RESOURCE_COND(rc, "Failed to add policer in policer manager, err: %s\n",
                                     sx_status_str(rc));
            goto out;
        }

        rc = policer_db_create(&policer_db_attrib, &policer_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in allocation policer : error (%s)\n", sx_status_str(rc));
            goto rollback1;
        }

        rc = sdk_handle_qpcr(SX_ACCESS_CMD_SET,
                             policer_db_attrib.lid,
                             &policer_db_attrib,
                             SX_POLICER_LOG_PORT_GET(policer_id));
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in sdk_handle_qpcr : error (%s)\n", sx_status_str(rc));
            goto rollback2;
        }

        break; /* CREATE */

    case SX_ACCESS_CMD_DESTROY:

        rc = policer_db_attrib_get(policer_id, &old_policer_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        rc = policer_db_destroy(policer_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in policer destroy : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        rc = policer_manager_block_delete(old_policer_attrib.lid,
                                          POLICER_MANAGER_TYPE_STORM_CONTROL_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in policer_manager_block_delete : error (%s)\n", sx_status_str(rc));
            /* DB rollback */
            rb_status = policer_db_create(&old_policer_attrib, &policer_id);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Error in allocation policer : error (%s)\n", sx_status_str(rb_status));
            }
            goto out;
        }
        break; /* DESTROY */

    case SX_ACCESS_CMD_EDIT:
        if (SDK_POLICER_TYPE_GET(policer_id) != SX_POLICER_TYPE_STORM_CONTROL_E) {
            SX_LOG_ERR("Cannot change policer type\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (SX_POLICER_LOG_PORT_GET(policer_id) != policer_info->type_base_params.log_port) {
            SX_LOG_ERR("Cannot change port for per port policer\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        rc = sdk_policer_validate_attrib(mode, policer_info, &policer_db_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in validation of policer_info : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        rc = policer_db_attrib_get(policer_id, &old_policer_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        if (policer_db_attrib.meter_type != old_policer_attrib.meter_type) {
            SX_LOG_ERR("Can't edit policer meter type.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib.red_action != old_policer_attrib.red_action) {
            SX_LOG_ERR("Can't edit policer red action.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (policer_db_attrib.color_aware != old_policer_attrib.color_aware) {
            SX_LOG_ERR("Can't edit policer color awareness mode.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        policer_db_attrib.lid = old_policer_attrib.lid;

        rc = policer_db_attrib_set(policer_id, &policer_db_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in editing policer attributes : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        policer_db_attrib.clear_counter = FALSE;
        policer_db_attrib.add_counter = FALSE;

        rc = sdk_handle_qpcr(SX_ACCESS_CMD_SET,
                             policer_db_attrib.lid,
                             &policer_db_attrib,
                             SX_POLICER_LOG_PORT_GET(policer_id));
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in sdk_handle_qpcr : error (%s)\n", sx_status_str(rc));
            rb_status = policer_db_attrib_set(policer_id, &old_policer_attrib);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Error in editing policer attributes : error (%s)\n", sx_status_str(rb_status));
            }
            goto out;
        }

        break; /* EDIT */

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    goto out;

rollback2:
    rb_status = policer_db_destroy(policer_id);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Error in policer destroy : error (%s)\n", sx_status_str(rb_status));
    }

rollback1:
    rb_status = policer_manager_block_delete(policer_db_attrib.lid,
                                             POLICER_MANAGER_TYPE_STORM_CONTROL_E);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Error in policer_manager_block_delete : error (%s)\n", sx_status_str(rb_status));
    }
out:
    return M_UTILS_SX_LOG_EXIT(rc);
}

sx_status_t sdk_policer_get(const sx_policer_id_t policer_id, sx_policer_attributes_t *policer_attr_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_policer_db_attrib_t policer_attrib;

    SX_LOG_ENTER();

    rc = policer_db_attrib_get(policer_id, &policer_attrib);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in retrieving policer information : error (%s)\n", sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    policer_attr_p->meter_type = policer_attrib.meter_type;
    policer_attr_p->cbs = policer_attrib.cbs;
    policer_attr_p->ebs = policer_attrib.ebs;
    policer_attr_p->cir = policer_attrib.cir;
    policer_attr_p->yellow_action = policer_attrib.yellow_action;
    policer_attr_p->red_action = policer_attrib.red_action;
    policer_attr_p->eir = policer_attrib.eir;
    policer_attr_p->rate_type = policer_attrib.rate_type;
    policer_attr_p->color_aware = policer_attrib.color_aware;
    policer_attr_p->is_host_ifc_policer = policer_attrib.is_host_ifc_policer;
    policer_attr_p->ir_units = policer_attrib.ir_units;
    policer_attr_p->is_span_session_policer = policer_attrib.is_span_session_policer;


    return M_UTILS_SX_LOG_EXIT(rc);
}

sx_status_t sdk_policer_iter_get(const sx_access_cmd_t         access_cmd,
                                 const sx_policer_id_t         policer_id_key,
                                 const sx_policer_id_filter_t *policer_filter_p,
                                 sx_policer_id_t              *policer_id_list_p,
                                 uint32_t                     *policer_id_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Check count != NULL */
    if (SX_CHECK_FAIL(rc = utils_check_pointer(policer_id_cnt_p, "policer_id_cnt_p"))) {
        goto out;
    }

    if (*policer_id_cnt_p != 0) {
        if (SX_CHECK_FAIL(rc = utils_check_pointer(policer_id_list_p,
                                                   "policer_id_list_p"))) {
            goto out;
        }
    }

    rc = policer_db_iter_get(access_cmd,
                             policer_id_key,
                             policer_filter_p,
                             policer_id_list_p,
                             policer_id_cnt_p);


out:
    return M_UTILS_SX_LOG_EXIT(rc);
}


sx_status_t sdk_policer_counters_get(const sx_policer_id_t policer_id, sx_policer_counters_t *policer_counters_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_policer_db_attrib_t policer_db_attrib;
    sx_policer_id_t        int_policer_id = policer_id;

    UNUSED_PARAM(policer_id);
    UNUSED_PARAM(policer_counters_p);

    rc = policer_db_attrib_get(policer_id, &policer_db_attrib);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
        goto out;
    }

    if (policer_db_attrib.policer_type == SX_POLICER_TYPE_STORM_CONTROL_E) {
        int_policer_id = policer_db_attrib.lid;
    }
    rc = sdk_handle_qpcr(SX_ACCESS_CMD_GET,
                         int_policer_id,
                         &policer_db_attrib,
                         SX_POLICER_LOG_PORT_GET(policer_id));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in sdk_handle_qpcr : error (%s)\n", sx_status_str(rc));
        goto out;
    }
    policer_counters_p->violation_counter = policer_db_attrib.violate_count;

out:
    return M_UTILS_SX_LOG_EXIT(rc);
}

sx_status_t sdk_policer_counters_clear_set(const sx_policer_id_t              policer_id,
                                           const sx_policer_counters_clear_t *clear_counters_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_policer_db_attrib_t policer_db_attrib;
    sx_policer_id_t        int_policer_id = policer_id;

    rc = policer_db_attrib_get(policer_id, &policer_db_attrib);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
        goto out;
    }
    policer_db_attrib.clear_counter = clear_counters_p->clear_violation_counter;

    if (policer_db_attrib.policer_type == SX_POLICER_TYPE_STORM_CONTROL_E) {
        int_policer_id = policer_db_attrib.lid;
    }

    rc = sdk_handle_qpcr(SX_ACCESS_CMD_SET,
                         int_policer_id,
                         &policer_db_attrib,
                         SX_POLICER_LOG_PORT_GET(policer_id));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in sdk_handle_qpcr : error (%s)\n", sx_status_str(rc));
        goto out;
    }


out:
    return M_UTILS_SX_LOG_EXIT(rc);
}

sx_status_t policer_block_copy(sx_policer_id_t                policer_id,
                               policer_manager_block_length_t size,
                               policer_manager_index_t        old_index,
                               policer_manager_index_t        new_index)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_policer_db_attrib_t policer_attr;
    struct ku_qpcr_reg     qpcr_reg_data;
    sxd_reg_meta_t         qpcr_reg_meta;
    uint32_t               device_index = 0;
    length_t               device_cnt = 0;
    sx_dev_info_t          device_list_arr[SX_DEV_ID_MAX];
    sx_boot_mode_e         issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    sx_issu_bank_e         issu_bank = SX_ISSU_BANK_1_E;


    SX_LOG_ENTER();

    UNUSED_PARAM(size);
    UNUSED_PARAM(old_index);
    SX_MEM_CLR(policer_attr);
    SX_MEM_CLR(qpcr_reg_data);
    SX_MEM_CLR(qpcr_reg_meta);
    SX_MEM_CLR(device_list_arr);

    rc = issu_boot_mode_get(&issu_boot_mode);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" failed to issu_boot_mode_get sx_status = %s\n",
                   sx_status_str(rc));
        goto out;
    }

    if (issu_boot_mode != SX_BOOT_MODE_DISABLED_E) {
        rc = issu_bank_get(&issu_bank);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get ISSU bank, err: %s\n",
                       sx_status_str(rc));
            goto out;
        }
    }

    new_index += (issu_bank * rm_resource_global.policer_pool_size / 2);

    rc = policer_db_attrib_get(policer_id, &policer_attr);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
        goto out;
    }

    rc = port_device_list_get(SX_ACCESS_CMD_COUNT, NULL, &device_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in port_device_list_get : error (%s)\n", sx_status_str(rc));
        goto out;
    }

    if (device_cnt == 0) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = port_device_list_get(SX_ACCESS_CMD_GET, device_list_arr, &device_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in port_device_list_get : error (%s)\n", sx_status_str(rc));
        goto out;
    }

    qpcr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    qpcr_reg_data.global_policer = policer_attr.policer_type;
    qpcr_reg_data.pid = new_index;
    qpcr_reg_data.color_aware = policer_attr.color_aware;
    qpcr_reg_data.use_bytes = policer_attr.meter_type;
    qpcr_reg_data.ir_units = policer_attr.ir_units;
    qpcr_reg_data.type = policer_attr.rate_type;
    qpcr_reg_data.mode = SX_POLICER_MODE_POLICER_E;
    qpcr_reg_data.committed_burst_size = policer_attr.cbs;
    qpcr_reg_data.committed_information_rate = policer_attr.cir;
    qpcr_reg_data.extended_burst_size = policer_attr.ebs;
    qpcr_reg_data.excess_information_rate = policer_attr.eir;
    qpcr_reg_data.violate_action = policer_attr.red_action;
    qpcr_reg_data.exceed_action = SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR;
    qpcr_reg_data.clear_counter = policer_attr.clear_counter;
    qpcr_reg_data.add_counter = policer_attr.add_counter;


    for (device_index = 0; device_index < device_cnt; device_index++) {
        qpcr_reg_meta.dev_id = device_list_arr[device_index].dev_id;
        rc =
            sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_QPCR_E, &qpcr_reg_data,
                                                                        &qpcr_reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("sxd_access_reg_qpcr failed, error: %s\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    return M_UTILS_SX_LOG_EXIT(rc);
}


sx_status_t policer_increase_counters(sx_policer_id_t                policer_id,
                                      policer_manager_block_length_t size,
                                      policer_manager_index_t        old_index,
                                      policer_manager_index_t        new_index)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_policer_db_attrib_t policer_attr;
    struct ku_qpcr_reg     qpcr_reg_data;
    sxd_reg_meta_t         qpcr_reg_meta;
    uint32_t               device_index = 0;
    length_t               device_cnt = 0;
    sx_dev_info_t          device_list_arr[SX_DEV_ID_MAX];
    sx_boot_mode_e         issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    sx_issu_bank_e         issu_bank = SX_ISSU_BANK_1_E;

    UNUSED_PARAM(size);
    SX_MEM_CLR(policer_attr);
    SX_MEM_CLR(device_list_arr);


    rc = policer_db_attrib_get(policer_id, &policer_attr);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
        goto out;
    }

    rc = port_device_list_get(SX_ACCESS_CMD_COUNT, NULL, &device_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in port_device_list_get : error (%s)\n", sx_status_str(rc));
        goto out;
    }

    if (device_cnt == 0) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = issu_boot_mode_get(&issu_boot_mode);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" failed to issu_boot_mode_get sx_status = %s\n",
                   sx_status_str(rc));
        goto out;
    }

    if (issu_boot_mode != SX_BOOT_MODE_DISABLED_E) {
        rc = issu_bank_get(&issu_bank);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get ISSU bank, err: %s\n",
                       sx_status_str(rc));
            goto out;
        }
    }

    new_index += (issu_bank * rm_resource_global.policer_pool_size / 2);
    old_index += (issu_bank * rm_resource_global.policer_pool_size / 2);

    rc = port_device_list_get(SX_ACCESS_CMD_GET, device_list_arr, &device_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in port_device_list_get : error (%s)\n", sx_status_str(rc));
        goto out;
    }

    for (device_index = 0; device_index < device_cnt; device_index++) {
        qpcr_reg_meta.dev_id = device_list_arr[device_index].dev_id;
        qpcr_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        qpcr_reg_data.global_policer = policer_attr.policer_type;
        qpcr_reg_data.pid = old_index;
        rc =
            sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_QPCR_E, &qpcr_reg_data,
                                                                        &qpcr_reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("sxd_access_reg_qpcr failed, error: %s\n", sx_status_str(rc));
            goto out;
        }
        qpcr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        qpcr_reg_data.pid = new_index;
        /* we got qpcr_reg_data.violate_count from sxd_access_reg_qpcr GET */
        qpcr_reg_data.add_counter = TRUE;

        rc =
            sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_QPCR_E, &qpcr_reg_data,
                                                                        &qpcr_reg_meta, 1, NULL, NULL));
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("sxd_access_reg_qpcr failed, error: %s\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    return M_UTILS_SX_LOG_EXIT(rc);
}


sx_status_t sdk_policer_storm_control_set_impl(const sx_access_cmd_t                 cmd,
                                               const sx_port_log_id_t                log_port,
                                               const sx_port_storm_control_id_t      storm_control_id,
                                               const sx_port_storm_control_params_t *storm_control_params_p)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    sx_policer_id_t         policer_id = 0;
    sx_policer_info_t       policer_info;
    sx_policer_db_attrib_t  old_policer_db_attr;
    sx_policer_attributes_t old_policer_attributes;
    sx_access_cmd_t         access_cmd = 0;
    boolean_t               is_polcier_exists = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(old_policer_db_attr);
    SX_MEM_CLR(old_policer_attributes);
    SX_MEM_CLR(policer_info);

    if (NULL == storm_control_params_p) {
        SX_LOG_ERR("Null param\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_POLICER_LOG_PORT_SET(policer_id, log_port);
    SX_POLICER_PID_SET(policer_id, storm_control_id);

    policer_info.type_base_params.log_port = log_port;
    policer_info.policer_attributes = storm_control_params_p->policer_params;

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        rc = policer_db_find_policer(policer_id, &is_polcier_exists);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("policer_db_find_policer failed (%s)\n",
                       sx_status_str(rc));
            goto out;
        }
        if (is_polcier_exists == TRUE) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("storm control ID (%u) on port %#08X already exists. err (%s)\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        rc = policer_db_attrib_get(policer_id, &old_policer_db_attr);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("policer_db_attrib_get failed (%s)\n",
                       sx_status_str(rc));
            goto out;
        }
        rc = policer_get(policer_id, &old_policer_attributes);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("policer_get failed (%s)\n", sx_status_str(rc));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        rc = policer_db_attrib_get(policer_id, &old_policer_db_attr);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("policer_db_attrib_get failed (%s)\n",
                       sx_status_str(rc));
            goto out;
        }
        rc = policer_get(policer_id, &old_policer_attributes);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("policer_get failed (%s)\n", sx_status_str(rc));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    SX_MEM_CPY(policer_info.packet_types, storm_control_params_p->packet_types);

    if (cmd == SX_ACCESS_CMD_DELETE) {
        access_cmd = SX_ACCESS_CMD_DESTROY;
    } else {
        access_cmd = cmd;
    }

    rc = policer_set(access_cmd,
                     SX_POLICER_MODE_POLICER_E,
                     &policer_id,
                     &policer_info);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Storm control %d port %#08X - policer creation failure (%s)\n",
                   storm_control_id, log_port, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_handle_qpbr(const sx_access_cmd_t        cmd,
                            const sx_port_log_id_t       log_port,
                            const sx_policer_id_t        policer_id,
                            const sx_port_packet_types_t port_packet_types)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS, rb_status = SX_STATUS_SUCCESS;
    struct ku_qpbr_reg             qpbr_reg_data;
    sxd_reg_meta_t                 qpbr_reg_meta;
    sx_policer_db_attrib_t         policer_db_attr;
    policer_manager_index_t        hw_id = 0;
    policer_manager_block_length_t size = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(qpbr_reg_meta);
    SX_MEM_CLR(qpbr_reg_data);
    SX_MEM_CLR(policer_db_attr);


    if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(log_port)) {
        SX_LOG_ERR("Failure - port is LAG\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }


    if (SX_CHECK_FAIL(rc = port_swid_alloc_get(SX_ACCESS_CMD_GET, log_port, &qpbr_reg_meta.swid))) {
        SX_LOG_ERR("Can't Retrieve SwID of Port 0x%08X (%s). (bind policer)\n", log_port, sx_status_str(rc));
        goto out;
    }

    rc = policer_db_attrib_get(policer_id, &policer_db_attr);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("policer_db_attrib_get failed (%s)\n",
                   sx_status_str(rc));
        goto out;
    }

    rc = policer_manager_handle_lock(policer_db_attr.lid,
                                     POLICER_MANAGER_TYPE_STORM_CONTROL_E,
                                     &hw_id,
                                     &size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in policer_manager_block_add : error (%s)\n", sx_status_str(rc));
        goto out;
    }

    /* QPBR meta: */
    qpbr_reg_meta.dev_id = SX_PORT_DEV_ID_GET(log_port);
    qpbr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    /* QPBR data: */
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(qpbr_reg_data.port, qpbr_reg_data.lp_msb, SX_PORT_PHY_ID_GET(log_port));
    qpbr_reg_data.global_policer = 0;
    qpbr_reg_data.pid = hw_id;
    qpbr_reg_data.unicast = port_packet_types.uc;
    qpbr_reg_data.multicast = port_packet_types.mc;
    qpbr_reg_data.broadcast = port_packet_types.bc;
    qpbr_reg_data.unknown_unicast = port_packet_types.uuc;
    qpbr_reg_data.unregistered_multicast = port_packet_types.umc;

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        qpbr_reg_data.operation = SXD_PORT_POLICER_BIND;
        break;

    case SX_ACCESS_CMD_UNBIND:
        qpbr_reg_data.operation = SXD_PORT_POLICER_UNBIND;
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out_release_policer;
    }

    rc =
        sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_QPBR_E, &qpbr_reg_data,
                                                                    &qpbr_reg_meta, 1,
                                                                    NULL, NULL));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Can't send SET-QPBR EMAD (%s)\n", sx_status_str(rc));
    }

out_release_policer:
    rb_status = policer_manager_handle_release(policer_db_attr.lid,
                                               POLICER_MANAGER_TYPE_STORM_CONTROL_E);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Error in policer_manager_block_add : error (%s)\n", sx_status_str(rb_status));
    }
    /* if handle_release failed and it's the first failure */
    if (SX_CHECK_PASS(rc) && SX_CHECK_FAIL(rb_status)) {
        rc = rb_status;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_port_storm_control_set(const sx_access_cmd_t                 cmd,
                                       const sx_port_log_id_t                log_port,
                                       const sx_port_storm_control_id_t      storm_control_id,
                                       const sx_port_storm_control_params_t *storm_control_params_p)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS, rb_status = SX_STATUS_SUCCESS;
    uint8_t                        lag_member = 0;
    sx_policer_id_t                policer_id = 0;
    sx_port_id_t                 * port_list = NULL;
    uint32_t                       port_num = rm_resource_global.lag_port_members_max;
    uint32_t                       port_index = 0, i = 0;
    sx_swid_id_t                   swid;
    sx_access_cmd_t                rb_cmd = 0, intl_cmd = 0;
    sx_policer_attributes_t        old_policer_attributes;
    sx_policer_db_attrib_t         old_policer_db_attr;
    sx_port_storm_control_params_t rb_storm_control_params_p;
    sx_port_packet_types_t         traffic_types;

    SX_LOG_ENTER();

    SX_MEM_CLR(old_policer_attributes);
    SX_MEM_CLR(old_policer_db_attr);
    SX_MEM_CLR(rb_storm_control_params_p);
    SX_MEM_CLR(traffic_types);

    /* Validate Port */
    VALIDATE_PORT(sdk_port_storm_control_set, log_port);
    VALIDATE_PORT_PROFILE_CMD(cmd, log_port);

    /* Check if storm_control_id is in range */
    if (FALSE == SX_POLICER_PID_CHECK_RANGE(storm_control_id)) {
        SX_LOG_ERR("Storm Control id (%u) exceeds range (0...%u)\n",
                   storm_control_id,
                   SX_POLICER_MAX_POLICERS_PER_PORT - 1);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    port_list = (sx_port_id_t*)cl_malloc(sizeof(sx_port_id_t) * rm_resource_global.lag_port_members_max);
    if (port_list == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(port_list, 0, sizeof(sx_port_id_t) * rm_resource_global.lag_port_members_max);

    if (NULL == storm_control_params_p) {
        SX_LOG_ERR("storm_control_params_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        intl_cmd = SX_ACCESS_CMD_BIND;
        rb_cmd = SX_ACCESS_CMD_UNBIND;
        break;

    case SX_ACCESS_CMD_EDIT:
        intl_cmd = SX_ACCESS_CMD_BIND;
        rb_cmd = SX_ACCESS_CMD_BIND;
        break;

    case SX_ACCESS_CMD_DELETE:
        intl_cmd = SX_ACCESS_CMD_UNBIND;
        rb_cmd = SX_ACCESS_CMD_BIND;
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    /* exit if port is lag member */
    if (SX_CHECK_FAIL(rc = port_lag_member_state_get(SX_ACCESS_CMD_GET, log_port, &lag_member))) {
        SX_LOG_ERR("Failed to get lag status of port (0x%08X) (%s)\n", log_port, sx_status_str(rc));
        goto out;
    }
    if (lag_member) {
        SX_LOG_ERR("Port 0x%08X storm control - port is a LAG member\n", log_port);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = port_swid_alloc_get(SX_ACCESS_CMD_GET, log_port, &swid))) {
        SX_LOG_ERR("Failed to retrieve SwID of Port 0x%08X (%s).\n", log_port, sx_status_str(rc));
        goto out;
    }

    rc = swid_validation_func_ptr(swid);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SWID(%d) type mismatch\n", swid);
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_EDIT)) {
        rc = policer_validate_packet_type(storm_control_params_p->packet_types);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in validation of storm_control_params_p : "
                       "error (%s)\n", sx_status_str(rc));
            goto out;
        }

        /* Check if any entered packet type is already being policed on the same port */
        rc = __policer_validate_traffic_type_reoccurance(log_port,
                                                         storm_control_id,
                                                         storm_control_params_p->packet_types);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in validation of storm_control_params_p : "
                       "error (%s)\n", sx_status_str(rc));
            goto out;
        }
    }

    if (SX_PORT_TYPE_LAG != SX_PORT_TYPE_ID_GET(log_port)) {
        port_num = 1;
        port_list[0] = log_port;
    } else {
        rc = sx_lag_port_group_get(log_port, port_list, &port_num);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to retrieve lag members of lag %#08X (%s)\n",
                       log_port, sx_status_str(rc));
            goto out;
        }
    }
    SX_POLICER_LOG_PORT_SET(policer_id, log_port);
    SX_POLICER_PID_SET(policer_id, storm_control_id);

    if ((cmd == SX_ACCESS_CMD_EDIT) || (cmd == SX_ACCESS_CMD_DELETE)) {
        rc = policer_get(policer_id, &old_policer_attributes);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("policer_get failed (%s)\n", sx_status_str(rc));
            goto out;
        }

        rc = policer_db_attrib_get(policer_id, &old_policer_db_attr);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("policer_db_attrib_get failed (%s)\n",
                       sx_status_str(rc));
            goto out;
        }
    }

    /* For deleting a storm control we would like to unbind it first
     *  before destroying the configuration */
    if (cmd != SX_ACCESS_CMD_DELETE) {
        /* This call will create/edit the policer configuration */
        rc = sdk_policer_storm_control_set_impl(cmd,
                                                log_port,
                                                storm_control_id,
                                                storm_control_params_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("storm control operation failed for port %#08X (%s)\n",
                       log_port, sx_status_str(rc));
            goto out;
        }
        SX_MEM_CPY(traffic_types, storm_control_params_p->packet_types);
    } else { /* cmd == DELETE */
        SX_MEM_CPY(traffic_types, old_policer_db_attr.packet_types);
    }

    /* This call will bind/unbind the policer to the port/s */
    for (port_index = 0; port_index < port_num; port_index++) {
        if (cmd == SX_ACCESS_CMD_EDIT) {
            rc = sdk_handle_qpbr(SX_ACCESS_CMD_UNBIND,
                                 port_list[port_index],
                                 policer_id,
                                 old_policer_db_attr.packet_types);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Storm control policer unbind HW failure - port  %#08X (%s)\n",
                           log_port, sx_status_str(rc));
                goto rollback_out;
            }
        }
        rc = sdk_handle_qpbr(intl_cmd, port_list[port_index], policer_id, traffic_types);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control policer bind HW failure - port  %#08X (%s)\n",
                       log_port, sx_status_str(rc));
            goto rollback_out;
        }
    }

    if (cmd == SX_ACCESS_CMD_DELETE) {
        rc = sdk_policer_storm_control_set_impl(cmd,
                                                log_port,
                                                storm_control_id,
                                                storm_control_params_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("storm control operation failed for port %#08X (%s)\n",
                       log_port, sx_status_str(rc));
            goto rollback_out;
        }
    }

    goto out;

rollback_out:
    for (i = 0; i < port_index; i++) {
        if (cmd == SX_ACCESS_CMD_EDIT) {
            rb_status = sdk_handle_qpbr(SX_ACCESS_CMD_UNBIND, port_list[i], policer_id, traffic_types);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Storm control policer unbind HW failure - port  %#08X (%s)\n",
                           port_list[i], sx_status_str(rb_status));
            }
        }
        rb_status = sdk_handle_qpbr(rb_cmd, port_list[i], policer_id, old_policer_db_attr.packet_types);
        if (SX_CHECK_FAIL(rb_status)) {
            SX_LOG_ERR("Storm control policer bind HW failure - port  %#08X (%s)\n",
                       port_list[i], sx_status_str(rb_status));
        }
    }
    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        rb_cmd = SX_ACCESS_CMD_DELETE;
        break;

    case SX_ACCESS_CMD_EDIT:
        rb_cmd = SX_ACCESS_CMD_EDIT;
        rb_storm_control_params_p.policer_params = old_policer_attributes;
        rb_storm_control_params_p.packet_types = old_policer_db_attr.packet_types;
        break;

    default:
        goto out;
    }
    rb_status = sdk_policer_storm_control_set_impl(rb_cmd, log_port, storm_control_id, &rb_storm_control_params_p);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("storm control operation failed for port %#08X (%s)\n",
                   log_port, sx_status_str(rb_status));
    }

out:
    if (port_list != NULL) {
        CL_FREE_N_NULL(port_list);
    }
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_policer_storm_control_get(const sx_port_log_id_t           log_port,
                                          const sx_port_storm_control_id_t storm_control_id,
                                          sx_port_storm_control_params_t  *storm_control_params_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_policer_db_attrib_t policer_attrib;
    sx_policer_id_t        policer_id = 0;

    SX_LOG_ENTER();

    SX_POLICER_LOG_PORT_SET(policer_id, log_port);
    SX_POLICER_PID_SET(policer_id, storm_control_id);

    /* Validate Port */
    VALIDATE_PORT(sdk_policer_storm_control_get, log_port);

    if (NULL == storm_control_params_p) {
        SX_LOG_ERR("storm_control_params_p is NULL\n");
        rc = SX_STATUS_PARAM_NULL;
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    rc = policer_db_attrib_get(policer_id, &policer_attrib);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in retrieving policer information : error (%s)\n", sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    storm_control_params_p->policer_params.meter_type = policer_attrib.meter_type;
    storm_control_params_p->policer_params.cbs = policer_attrib.cbs;
    storm_control_params_p->policer_params.ebs = policer_attrib.ebs;
    storm_control_params_p->policer_params.cir = policer_attrib.cir;
    storm_control_params_p->policer_params.yellow_action = policer_attrib.yellow_action;
    storm_control_params_p->policer_params.red_action = policer_attrib.red_action;
    storm_control_params_p->policer_params.eir = policer_attrib.eir;
    storm_control_params_p->policer_params.rate_type = policer_attrib.rate_type;
    storm_control_params_p->policer_params.color_aware = policer_attrib.color_aware;
    storm_control_params_p->policer_params.is_host_ifc_policer = policer_attrib.is_host_ifc_policer;
    storm_control_params_p->policer_params.ir_units = policer_attrib.ir_units;
    SX_MEM_CPY(storm_control_params_p->packet_types, policer_attrib.packet_types);

    return M_UTILS_SX_LOG_EXIT(rc);
}

static sx_status_t __policer_validate_traffic_type_reoccurance(const sx_port_log_id_t           log_port,
                                                               const sx_port_storm_control_id_t storm_control_id,
                                                               const sx_port_packet_types_t     port_packet_types)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_policer_db_attrib_t     policer_attrib;
    sx_policer_id_t            policer_id = 0;
    sx_port_storm_control_id_t i = 0;
    boolean_t                  is_polcier_exists = FALSE;

    SX_LOG_ENTER();

    for (i = 0; i < SX_POLICER_MAX_POLICERS_PER_PORT; i++) {
        if (storm_control_id == i) {
            continue;
        }

        SX_POLICER_LOG_PORT_SET(policer_id, log_port);
        SX_POLICER_PID_SET(policer_id, i);

        rc = policer_db_find_policer(policer_id, &is_polcier_exists);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("policer_db_find_policer failed (%s)\n",
                       sx_status_str(rc));
            goto out;
        }

        if (!is_polcier_exists) {
            continue;
        }

        rc = policer_db_attrib_get(policer_id, &policer_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in retrieving policer information : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        if (policer_attrib.packet_types.uc & port_packet_types.uc) {
            SX_LOG_ERR("UC traffic is already being policed by storm control (%u) on port 0x%08X\n",
                       i, log_port);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        } else if (policer_attrib.packet_types.bc & port_packet_types.bc) {
            SX_LOG_ERR("BC traffic is already being policed by storm control (%u) on port 0x%08X\n",
                       i, log_port);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        } else if (policer_attrib.packet_types.mc & port_packet_types.mc) {
            SX_LOG_ERR("MC traffic is already being policed by storm control (%u) on port 0x%08X\n",
                       i, log_port);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        } else if (policer_attrib.packet_types.uuc & port_packet_types.uuc) {
            SX_LOG_ERR("UUC traffic is already being policed by storm control (%u) on port 0x%08X\n",
                       i, log_port);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        } else if (policer_attrib.packet_types.umc & port_packet_types.umc) {
            SX_LOG_ERR("UMC traffic is already being policed by storm control (%u) on port 0x%08X\n",
                       i, log_port);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    return M_UTILS_SX_LOG_EXIT(rc);
}
