/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __POLICER_H__
#define __POLICER_H__

#include <sx/sdk/sx_types.h>
#include "utils/sx_adviser.h"
#include "policer_db.h"
#include "ethl2/lag_sink.h"

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/

/**
 * SX_POLICER_CIR_MAX_PACKET_SAMPLING define packet sampling max
 * rate
 */
#define SX_POLICER_CIR_MAX_PACKET_SAMPLING (16777215)

/**
 * SX_POLICER_CIR_METER_PACKETS_SLOW_STEP define packet sampling slow policer step
 * rate
 */
#define SX_POLICER_CIR_METER_PACKETS_SLOW_STEP (100)

/**
 * SX_POLICER_CIR_METER_PACKETS_GLOBAL_STEP define packet sampling global policer step
 * rate
 */
#define SX_POLICER_CIR_METER_PACKETS_GLOBAL_STEP (6536)

/*
 * +------------------------------+------------------------------+
 * |     Logical Port [63:32]     |           PID [31:0]         |
 * +------------------------------+------------------------------+
 */

#define SX_POLICER_LOG_PORT_MASK (0xFFFFFFFF00000000ULL)
#define SX_POLICER_PID_MASK      (0xFFFFFFFFULL)
#define SX_POLICER_ZERO_PID_MASK (0xFFFFFFFFFFFF0ULL)

#define SX_POLICER_LOG_PORT_OFFS (32)
#define SX_POLICER_PID_OFFS      (0)

/************************************************
 *  Macros
 ***********************************************/

#define SX_POLICER_LOG_PORT_ISO(id) ((uint64_t)(id) & (SX_POLICER_LOG_PORT_MASK))
#define SX_POLICER_PID_ISO(id)      ((id) & (SX_POLICER_PID_MASK))

#define SX_POLICER_LOG_PORT_GET(id) ((sx_port_log_id_t)(SX_POLICER_LOG_PORT_ISO(id) >> SX_POLICER_LOG_PORT_OFFS))
#define SX_POLICER_PID_GET(id)      (SX_POLICER_PID_ISO(id) >> SX_POLICER_PID_OFFS)
#define SX_POLICER_ZERO_PID_GET(id) ((id) & (SX_POLICER_ZERO_PID_MASK))

#define SX_POLICER_LOG_PORT_CLR(id) ((id) &= ~(SX_POLICER_LOG_PORT_MASK))
#define SX_POLICER_PID_CLR(id)      ((id) &= ~(SX_POLICER_PID_MASK))

#define SX_POLICER_LOG_PORT_SET_INT(id, PORT_ID)        \
    ((id) |=                                            \
         SX_POLICER_LOG_PORT_ISO((uint64_t)(PORT_ID) << \
                                 (SX_POLICER_LOG_PORT_OFFS)))
#define SX_POLICER_PID_SET_INT(id, PID) ((id) |= SX_POLICER_PID_ISO((PID) << (SX_POLICER_PID_OFFS)))

#define SX_POLICER_LOG_PORT_SET(id, PORT_ID) {SX_POLICER_LOG_PORT_CLR(id); SX_POLICER_LOG_PORT_SET_INT(id, PORT_ID); }
#define SX_POLICER_PID_SET(id, PID)          {SX_POLICER_PID_CLR(id); SX_POLICER_PID_SET_INT(id, PID); }

#define SX_POLICER_TYPE_GET(id)      \
    ((SX_POLICER_LOG_PORT_GET(id) == \
      0) ? SX_POLICER_TYPE_GLOBAL_E : SX_POLICER_TYPE_PER_PORT_E)

#define SDK_POLICER_TYPE_GET(id)     \
    ((SX_POLICER_LOG_PORT_GET(id) == \
      0) ? SX_POLICER_TYPE_GLOBAL_E : SX_POLICER_TYPE_STORM_CONTROL_E)

#define SX_POLICER_METER_TYPE_CHECK_RANGE(val) SX_CHECK_MAX(val, SX_POLICER_METER_MAX)
#define SX_POLICER_CBS_CHECK_RANGE(val)        SX_CHECK_RANGE(SX_POLICER_CBS_MIN, val, SX_POLICER_CBS_MAX)
#define SX_POLICER_EBS_CHECK_RANGE(val)        SX_CHECK_RANGE(SX_POLICER_EBS_MIN, val, SX_POLICER_EBS_MAX)
#define SX_POLICER_CIR_CHECK_RANGE(val, max)   SX_CHECK_RANGE(SX_POLICER_CIR_MIN, val, max)
#define SX_POLICER_CIR_PACKET_SAMPLING_CHECK_RANGE(val) \
    SX_CHECK_RANGE(SX_POLICER_CIR_MIN,                  \
                   val,                                 \
                   SX_POLICER_CIR_MAX_PACKET_SAMPLING)
#define SX_POLICER_YELLOW_ACTION_CHECK_RANGE(val) SX_CHECK_MAX(val, SX_POLICER_ACTION_MAX)
#define SX_POLICER_RED_ACTION_CHECK_RANGE(val)    SX_CHECK_MAX(val, SX_POLICER_ACTION_MAX)
#define SX_POLICER_TYPE_CHECK_RANGE(val)          SX_CHECK_MAX(val, SX_POLICER_TYPE_MAX_E)
#define SX_POLICER_MODE_CHECK_RANGE(val)  \
    SX_CHECK_RANGE(SX_POLICER_MODE_MIN_E, \
                   val,                   \
                   SX_POLICER_MODE_MAX_E)


/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t sx_policer_init(void);

sx_status_t sx_policer_deinit(void);

sx_status_t sx_policer_set(const sx_access_cmd_t   cmd,
                           const sx_policer_mode_e mode,
                           sx_policer_id_t       * policer_id_p,
                           sx_policer_info_t     * policer_info);

sx_status_t sx_policer_get(const sx_policer_id_t    policer_id,
                           sx_policer_attributes_t *policer_attr_p);

sx_status_t sx_policer_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t sx_policer_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

sx_status_t sx_policer_validate_attrib(sx_policer_mode_e       mode,
                                       sx_policer_info_t      *policer_info_p,
                                       sx_policer_db_attrib_t *policer_db_attrib_p);

sx_status_t sx_handle_qpcr(sx_access_cmd_t         cmd,
                           sx_policer_id_t         policer_id,
                           sx_policer_db_attrib_t *policer_attrib_p,
                           length_t                device_cnt,
                           sx_dev_info_t          *device_list_arr);

sx_status_t sx_policer_device_ready_callback(adviser_event_e event,
                                             void           *param);

sx_status_t sx_policer_lag_port_update(IN sx_port_id_t          lag_port_log_id,
                                       IN lag_sink_event_type_e event_type,
                                       IN sx_port_id_t          port_log_id,
                                       IN void                 *context_p);

sx_status_t sx_policer_lag_global_update(IN sx_port_id_t          lag_port_log_id,
                                         IN lag_sink_event_type_e event_type,
                                         IN void                 *context_p);

sx_status_t sx_policer_storm_control_set_impl(const sx_access_cmd_t                 cmd,
                                              const sx_port_log_id_t                log_port,
                                              const sx_port_storm_control_id_t      storm_control_id,
                                              const sx_port_storm_control_params_t *storm_control_params_p,
                                              int                                  *new_policer_p);

sx_status_t sx_policer_storm_control_bind_validations(const sx_access_cmd_t        cmd,
                                                      const sx_port_log_id_t       log_port,
                                                      const sx_policer_id_t        policer_id,
                                                      const sx_port_packet_types_t port_packet_types,
                                                      const sx_policer_mode_e      mode,
                                                      boolean_t                   *is_update_packet_type_p);

sx_status_t sx_handle_qpbr(const sx_access_cmd_t        cmd,
                           const sx_port_log_id_t       log_port,
                           const sx_policer_id_t        policer_id,
                           const sx_port_packet_types_t port_packet_types);

/**
 *  Create/delete storm control to / from port (QPBR Register).
 *
 * @param[in] cmd - CREATE / DELETE
 * @param[in] log_port - Logical Port ID
 * @param[in] storm_control_id - Storm Control Id
 * @param[in] storm_control_params - Storm Control parameters.
 *
 * @return sx_status_t - SX_STATUS_SUCCESS if function completed OK.
 * O/W, the appropriate error code it returned.
 */
sx_status_t sx_port_storm_control_set(const sx_access_cmd_t                 cmd,
                                      const sx_port_log_id_t                log_port,
                                      const sx_port_storm_control_id_t      storm_control_id,
                                      const sx_port_storm_control_params_t *storm_control_params);

sx_status_t sx_policer_storm_control_set(const sx_access_cmd_t                 cmd,
                                         const sx_port_log_id_t                log_port,
                                         const sx_port_storm_control_id_t      storm_control_id,
                                         const sx_port_storm_control_params_t *storm_control_params_p);

sx_status_t sx_policer_storm_control_get(const sx_port_log_id_t           log_port,
                                         const sx_port_storm_control_id_t storm_control_id,
                                         sx_port_storm_control_params_t  *storm_control_params_p);


#endif /* __POLICER_H__ */
