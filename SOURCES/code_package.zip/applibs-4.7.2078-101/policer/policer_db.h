/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __POLICER_DB_H__
#define __POLICER_DB_H__

#include <complib/cl_types.h>
#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>

#include <complib/sx_log.h>

#include <sx/sdk/sx_types.h>
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

typedef enum sx_policer_mode {
    SX_POLICER_MODE_POLICER_E         = SXD_POLICER_MODE_POLICER, /**< policer mode */
    SX_POLICER_MODE_PACKET_SAMPLING_E = SXD_POLICER_MODE_PACKET_SAMPLING,      /**< packet sampling mode */
    SX_POLICER_MODE_MIN_E             = SX_POLICER_MODE_POLICER_E,
    SX_POLICER_MODE_MAX_E             = SX_POLICER_MODE_PACKET_SAMPLING_E,
} sx_policer_mode_e;

typedef enum sx_policer_type {
    SX_POLICER_TYPE_PER_PORT_E      = 0, /**< per port policer type */
    SX_POLICER_TYPE_GLOBAL_E        = 2, /**< global policer type */
    SX_POLICER_TYPE_STORM_CONTROL_E = 3, /**< storm control policer type */
    SX_POLICER_TYPE_GLOBAL_SLOW_E   = 4, /**< global slow policer type, can be bound only to traffic to CPU */
    SX_POLICER_TYPE_PER_PORT_SLOW_E = 5,    /**< per port slow policer type */
    SX_POLICER_TYPE_MIN_E           = SX_POLICER_TYPE_PER_PORT_E,
    SX_POLICER_TYPE_MAX_E           = SX_POLICER_TYPE_PER_PORT_SLOW_E,
} sx_policer_type_e;

typedef struct sx_policer_type_base_param {
    sx_swid_t        swid; /**< Switch ID. Global policer / Global Slow policer */
    sx_port_log_id_t log_port; /**< Logical port ID. Per Port policer */
} sx_policer_type_base_param_t;

/**
 * sx_policer_info_t structure is used to store policer configuration information.
 */
typedef struct sx_policer_info {
    sx_policer_type_e            policer_type; /**< global / per port / slow global */
    sx_policer_attributes_t      policer_attributes; /**< general policer attribute / slow policer attributes */
    sx_policer_type_base_param_t type_base_params; /**< swid / log port */
    sx_port_packet_types_t       packet_types;       /**< Packet types (for storm controls) */
} sx_policer_info_t;

typedef struct sx_policer_db_attrib {
    uint32_t                     meter_type; /**<  bytes per sec (1) / packets per sec (0) */
    sx_policer_mode_e            mode; /**< policer mode*/
    uint32_t                     cbs; /**< Committed Burst Size */
    uint32_t                     ebs; /**< Extended Burst Size */
    uint32_t                     cir; /**< Committed Information Rate */
    sx_policer_action_t          yellow_action; /**< exceed CBS: Discard (1), Forward (0) */
    sx_policer_action_t          red_action; /**< exceed EBS: Discard (1), Forward (0) */
    sx_policer_type_e            policer_type;
    sx_policer_type_base_param_t type_base_params;
    uint32_t                     eir; /** Valid only on Spectrum <Excess Information Rate */
    sx_policer_rate_type_e       rate_type; /** valid only on Spectrum. SX/single-rate/dual-rate */
    boolean_t                    color_aware; /** valid only on Spectrum. is the policer color aware */
    sx_policer_ir_units_e        ir_units; /**< cir and eir units. Supported devices: Spectrum
                                            * 0 - 10^6
                                            * 1 - 10^3 */
    boolean_t              is_host_ifc_policer; /**<  will the policer will be bound to host_ifc trap group */
    boolean_t              clear_counter;
    boolean_t              add_counter;
    uint64_t               violate_count;
    sx_port_packet_types_t packet_types;        /**< Packet types (for storm controls) */
    sx_policer_id_t        lid; /**< Logical ID (for Spectrum storm controls)  */
    boolean_t              is_span_session_policer; /**< Is the policer a SPAN session policer.
                                                    * Supported device: Spectrum2, Spectrum3 */
} sx_policer_db_attrib_t;

typedef struct policer_db_item {
    cl_pool_item_t         pool_item;
    cl_map_item_t          map_item;
    sx_policer_id_t        policer_id;
    sx_policer_db_attrib_t policer_atrrib;
    uint32_t               bind_num;
} policer_db_item_t;


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t policer_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t policer_db_init(const uint32_t max_global_policer);

sx_status_t sx_policer_db_create(const sx_policer_db_attrib_t *policer_attr,
                                 sx_policer_id_t              *policer_id_p);

sx_status_t sdk_policer_db_create(const sx_policer_db_attrib_t *policer_attr,
                                  sx_policer_id_t              *policer_id_p);

void policer_db_is_allocated_policer(const sx_policer_id_t policer_id,
                                     boolean_t            *is_allocated);

sx_status_t policer_db_type_get(const sx_policer_id_t policer_id,
                                sx_policer_type_e    *policer_type);

sx_status_t policer_db_attrib_set(const sx_policer_id_t         policer_id,
                                  const sx_policer_db_attrib_t *policer_attr);

sx_status_t policer_db_attrib_get(const sx_policer_id_t   policer_id,
                                  sx_policer_db_attrib_t *policer_attr_p);

sx_status_t policer_db_iter_get(const sx_access_cmd_t         access_cmd,
                                const sx_policer_id_t         policer_id_key,
                                const sx_policer_id_filter_t *policer_id_filter_p,
                                sx_policer_id_t              *policer_id_list_p,
                                uint32_t                     *policer_id_cnt_p);

sx_status_t policer_db_find_policer(const sx_policer_id_t policer_id,
                                    boolean_t            *is_policer_valid_p);

sx_status_t policer_db_binds_get(const sx_policer_id_t policer_id,
                                 uint32_t             *bind_num);

sx_status_t policer_db_bind_set(const sx_access_cmd_t cmd,
                                const sx_policer_id_t policer_id);

sx_status_t policer_db_destroy(const sx_policer_id_t policer_id);

sx_status_t policer_db_deinit();

sx_status_t policer_db_add_device(sx_dev_info_t *dev_info_p);

typedef sx_status_t (*policer_db_pfn_t)(policer_db_item_t *, void *param_p);

sx_status_t policer_db_add_device_foreach(policer_db_pfn_t func, void *data);

sx_status_t policer_db_foreach_policer_on_lag_port(sx_access_cmd_t cmd, sx_port_id_t lag_id, sx_port_id_t port_id);

sx_status_t policer_db_foreach_policer_on_log_port(sx_access_cmd_t cmd, sx_port_id_t lag_id, sx_port_id_t port_id);

sx_status_t policer_db_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);

#endif /* __POLICER_DB_H__ */
