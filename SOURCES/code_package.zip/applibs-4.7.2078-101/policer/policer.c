/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>

#include <complib/cl_types.h>

#include <sx/sxd/sxd_access_register.h>

#include "policer.h"
#include "policer_db.h"
#include "ethl2/port.h"
#include "ethl2/port_db.h"
#include "utils/sx_adviser.h"
#include "ethl2/fdb_common.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/port_type_validate.h"
#include "ethl2/lag_sink.h"
#include "policer_manager.h"
#include "ethl2/brg.h"
#include "ethl2/lag.h"
#include <complib/cl_mem.h>
#include "policer_lib/policer_common.h"
#include "kvd/kvd_linear_manager.h"
#include "resource_manager/resource_manager_sdk_table.h"

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ POLICER


/************************************************
 *  Global variables
 ***********************************************/

#define IS_POWER_OF_2(val) ((val != 0) && ((val & (val - 1)) == 0))

uint8_t tcam_region_info[SXD_TCAM_REGION_INFO_SIZE_BYTES] = {0};


/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

/**
 * This function is a callback for the lag sink port change event
 *
 * @param[in]  lag_port_log_id  - notify on this lag log port
 * @param[in]  event_type    - new event type (CREATE/DESTORY)
 * @param[in]  port_log_id   - notify on this logical port id
 * @param[in]  context_p     - adviser context to be called from callback
 *
 * @return sx_status_t
 */
sx_status_t sx_policer_lag_port_update(IN sx_port_id_t          lag_port_log_id,
                                       IN lag_sink_event_type_e event_type,
                                       IN sx_port_id_t          port_log_id,
                                       IN void                 *context_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(context_p);

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_POST_PORT_ADDED_E:
        /* Should bind the port to policer/sflow if such exist on the LAG */
        rc = port_db_foreach_policer(SX_ACCESS_CMD_ADD, lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR(
                "Failed updating policer configuration on port (0x%08X) that was added to lag (0x%08X), error: %s\n",
                port_log_id,
                lag_port_log_id,
                sx_status_str(rc));
            return rc;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_PORT_REMOVED_E:
        /* Should Unbind port from policer/sflow */
        rc = port_db_foreach_policer(SX_ACCESS_CMD_DELETE, lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR(
                "Failed updating policer configuration on port (0x%08X) that was removed from lag (0x%08X), error: %s\n",
                port_log_id,
                lag_port_log_id,
                sx_status_str(rc));
            return rc;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        rc = port_db_foreach_policer(SX_ACCESS_CMD_DESTROY, lag_port_log_id, lag_port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("port_db_foreach_policer Failed : %s\n", sx_status_str(rc));
            return rc;
        }

        /* unadvise destroyed lag id */
        rc = lag_sink_lag_unadvise(lag_port_log_id, sx_policer_lag_port_update);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in lag_sink_lag_unadvise , error: %s\n", sx_status_str(rc));
            return rc;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_PRE_PORT_ADDED_VALIDATIONS_E:
        break;

    default:
        SX_LOG_ERR("Wrong event type , event type: (%d)\n", event_type);
        return SX_STATUS_CMD_ERROR;
    }
    return rc;
}


sx_status_t sx_policer_lag_global_update(IN sx_port_id_t          lag_port_log_id,
                                         IN lag_sink_event_type_e event_type,
                                         IN void                 *context_p)
{
    sx_status_t rc;

    UNUSED_PARAM(context_p);

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_CREATED_E:
        /* advise for the new lag */
        rc = lag_sink_lag_advise(lag_port_log_id, sx_policer_lag_port_update,
                                 NULL, 0);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in lag_sink_lag_advise , error: %s\n", sx_status_str(rc));
            return rc;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        break;

    default:
        SX_LOG_ERR(
            "Wrong event type , event type: (%d)\n",
            event_type);
        return SX_STATUS_CMD_ERROR;
    }

    return SX_STATUS_SUCCESS;
}

/*
 * Calculate CBS value to write to QPCR when policer type is global or per port.
 * CBS units is in Mega, and the return value is the power-of-2 of the given cbs.
 * Assume that cbs is legal.
 */
static uint32_t __policer_cbs_calc(uint32_t cbs, uint32_t meter_type)
{
    uint32_t factor = 1;

    if (meter_type == SX_POLICER_METER_PACKETS) {
        /** CBS and EBS possible values for packet metering and CIR > 6500fps:
         * - Unit is 1 frame
         * - Values: 8000000, 16000000, 32000000, 64000000, 128000000, 256000000,
         *           512000000, 1024000000*/
        factor = 1000000;
    } else if (meter_type == SX_POLICER_METER_TRAFFIC) {
        /** CBS and EBS possible values for traffic metering
         * - Unit is 1MByte
         * - Values: 8, 16, 32, 64, 128, 256, 512, 1024
         * - Resulting rate is limited to the range of 8 MByte to 1024 MByte*/
        factor = 1;
    }

    if (cbs == 8 * factor) {
        return 23;
    } else if (cbs == 16 * factor) {
        return 24;
    } else if (cbs == 32 * factor) {
        return 25;
    } else if (cbs == 64 * factor) {
        return 26;
    } else if (cbs == 128 * factor) {
        return 27;
    } else if (cbs == 256 * factor) {
        return 28;
    } else if (cbs == 512 * factor) {
        return 29;
    } else if (cbs == 1024 * factor) {
        return 30;
    }

    return 0;
}

/*
 * Calculate CBS value to write to QPCR when policer type is slow global.
 * Return value is the power-of-2 of the given cbs.
 * Assume that cbs is legal (power-of-2).
 */
static uint32_t __policer_cbs_slow_calc(uint32_t cbs)
{
    uint32_t power = 0;

    while ((cbs = cbs >> 1)) {
        power++;
    }

    return power;
}

/*
 * Calculate EBS value to write to QPCR when policer type is global or per port.
 * EBS units is in Mega, and the return value is the power-of-2 of the given ebs.
 * Assume that ebs is legal.
 */
static uint32_t __policer_ebs_calc(uint32_t ebs, uint32_t meter_type)
{
    uint32_t factor = 1;

    if (meter_type == SX_POLICER_METER_PACKETS) {
        /** CBS and EBS possible values for packet metering and CIR > 6500fps:
         * - Unit is 1 frame
         * - Values: 8000000, 16000000, 32000000, 64000000, 128000000, 256000000,
         *           512000000, 1024000000*/
        factor = 1000000;
    } else if (meter_type == SX_POLICER_METER_TRAFFIC) {
        /** CBS and EBS possible values for traffic metering
         * - Unit is 1MByte
         * - Values: 8, 16, 32, 64, 128, 256, 512, 1024
         * - Resulting rate is limited to the range of 8 MByte to 1024 MByte*/
        factor = 1;
    }

    if (ebs == 8 * factor) {
        return 23;
    } else if (ebs == 16 * factor) {
        return 24;
    } else if (ebs == 32 * factor) {
        return 25;
    } else if (ebs == 64 * factor) {
        return 26;
    } else if (ebs == 128 * factor) {
        return 27;
    } else if (ebs == 256 * factor) {
        return 28;
    } else if (ebs == 512 * factor) {
        return 29;
    } else if (ebs == 1024 * factor) {
        return 30;
    }

    return 0;
}

/*
 * Calculate EBS value to write to QPCR when policer type is slow global.
 * Return value is the power-of-2 of the given ebs.
 * Assume that ebs is legal (power-of-2).
 */
static uint32_t __policer_ebs_slow_calc(uint32_t ebs)
{
    uint32_t power = 0;

    while ((ebs = ebs >> 1)) {
        power++;
    }

    return power;
}

/*
 * Calculate CIR value to write to QPCR when policer type is global or per port.
 * CIR units is determined by the metering type.
 * Assume that CIR is legal.
 */
static uint32_t __policer_cir_calc(uint32_t cir, uint32_t meter_type)
{
    if (meter_type == SX_POLICER_METER_PACKETS) {
        return cir * SX_POLICER_CIR_UNIT_PACKET_RATE;
    } else if (meter_type == SX_POLICER_METER_TRAFFIC) {
        return cir * SX_POLICER_CIR_UNIT_TRAFFIC_RATE;
    }
    return 0;
}

/*
 * Calculate CIR value to write to QPCR when policer type is slow global.
 * Assume that CIR is legal.
 */
static uint32_t __policer_cir_slow_calc(uint32_t cir)
{
    /* No calculation is needed for slow policer */
    return cir;
}

sx_status_t sx_handle_qpcr(sx_access_cmd_t         cmd,
                           sx_policer_id_t         policer_id,
                           sx_policer_db_attrib_t *policer_attrib_p,
                           length_t                device_cnt,
                           sx_dev_info_t          *device_list_arr)
{
    struct ku_qpcr_reg qpcr_reg_data;
    sxd_reg_meta_t     qpcr_reg_meta;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        rc = SX_STATUS_SUCCESS;
    uint32_t           device_index = 0;
    boolean_t          is_global_slow_policer, is_port_slow_policer;

    SX_LOG_ENTER();

    SX_MEM_CLR(qpcr_reg_meta);
    SX_MEM_CLR(qpcr_reg_data);

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        qpcr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

        is_global_slow_policer = (policer_attrib_p->policer_type == SX_POLICER_TYPE_GLOBAL_SLOW_E);
        is_port_slow_policer = (policer_attrib_p->policer_type == SX_POLICER_TYPE_PER_PORT_SLOW_E);
        if (is_global_slow_policer) {
            qpcr_reg_data.global_policer = SX_POLICER_TYPE_GLOBAL_E;
            qpcr_reg_data.committed_burst_size = __policer_cbs_slow_calc(policer_attrib_p->cbs);
            qpcr_reg_data.extended_burst_size = __policer_ebs_slow_calc(policer_attrib_p->ebs);
            qpcr_reg_data.committed_information_rate = __policer_cir_slow_calc(policer_attrib_p->cir);
        } else if (is_port_slow_policer) {
            qpcr_reg_data.global_policer = SX_POLICER_TYPE_PER_PORT_E;
            qpcr_reg_data.committed_burst_size = __policer_cbs_slow_calc(policer_attrib_p->cbs);
            qpcr_reg_data.extended_burst_size = __policer_ebs_slow_calc(policer_attrib_p->ebs);
            qpcr_reg_data.committed_information_rate = __policer_cir_slow_calc(policer_attrib_p->cir);
        } else {
            qpcr_reg_data.global_policer = policer_attrib_p->policer_type;
            qpcr_reg_data.extended_burst_size =
                __policer_ebs_calc(policer_attrib_p->ebs, policer_attrib_p->meter_type);
            if (SX_POLICER_MODE_PACKET_SAMPLING_E == policer_attrib_p->mode) {
                qpcr_reg_data.committed_burst_size = policer_attrib_p->cbs;
                qpcr_reg_data.committed_information_rate = policer_attrib_p->cir;
            } else {
                qpcr_reg_data.committed_burst_size = __policer_cbs_calc(policer_attrib_p->cbs,
                                                                        policer_attrib_p->meter_type);
                qpcr_reg_data.committed_information_rate = __policer_cir_calc(policer_attrib_p->cir,
                                                                              policer_attrib_p->meter_type);
            }
        }
        qpcr_reg_data.pid = SX_POLICER_PID_GET(policer_id);
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(qpcr_reg_data.port, qpcr_reg_data.lp_msb,
                                            SX_PORT_PHY_ID_GET(SX_POLICER_LOG_PORT_GET(policer_id)));
        qpcr_reg_data.use_bytes = policer_attrib_p->meter_type;
        qpcr_reg_data.exceed_action = policer_attrib_p->yellow_action;
        qpcr_reg_data.violate_action = policer_attrib_p->red_action;
        qpcr_reg_data.mode = policer_attrib_p->mode;

        switch (qpcr_reg_data.global_policer) {
        case SX_POLICER_TYPE_PER_PORT_E:
            rc = port_db_swid_alloc_get(policer_attrib_p->type_base_params.log_port, &qpcr_reg_meta.swid);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("fail to get logical port SWID (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }
            qpcr_reg_meta.dev_id = SX_PORT_DEV_ID_GET(policer_attrib_p->type_base_params.log_port);
            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_QPCR_E,
                                                             &qpcr_reg_data,
                                                             &qpcr_reg_meta,
                                                             1,
                                                             NULL,
                                                             NULL);
            break;

        case SX_POLICER_TYPE_GLOBAL_E:
            qpcr_reg_meta.swid = policer_attrib_p->type_base_params.swid;
            /* move across all devices and send to driver */
            for (device_index = 0; device_index < device_cnt && sxd_status == SXD_STATUS_SUCCESS; device_index++) {
                qpcr_reg_meta.dev_id = device_list_arr[device_index].dev_id;
                SX_LOG_DBG(
                    "QPCR Policer attributes: pid[]=%u, meter=%u, cbs=%u, ebs=%u, cir=%u, police_type=%u, swid=%u, y_act=%u, r_act=%u\n",
                    qpcr_reg_data.pid,
                    qpcr_reg_data.use_bytes,
                    qpcr_reg_data.committed_burst_size,
                    qpcr_reg_data.extended_burst_size,
                    qpcr_reg_data.committed_information_rate,
                    qpcr_reg_data.global_policer,
                    qpcr_reg_meta.swid,
                    qpcr_reg_data.exceed_action,
                    qpcr_reg_data.violate_action);

                sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_QPCR_E,
                                                                 &qpcr_reg_data,
                                                                 &qpcr_reg_meta,
                                                                 1,
                                                                 NULL,
                                                                 NULL);
            }
            break;

        default:
            SX_LOG_ERR("Wrong policer type (%u)\n", policer_attrib_p->policer_type);
            return M_UTILS_SX_LOG_EXIT(SX_STATUS_WRONG_POLICER_TYPE);
        }
        break;

    default:
        SX_LOG_ERR("Wrong access command , access command: (%u)\n", cmd);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_CMD_ERROR);
    }


    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("QPCR register read/update failed on SxD , SxD return value: (%u)\n", sxd_status);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_SXD_RETURNED_NON_ZERO);
    }

    return M_UTILS_SX_LOG_EXIT(rc);
}

static sx_status_t __policer_set_attributes_to_dev(policer_db_item_t *policer_item, void *param_p)
{
    return sx_handle_qpcr(SX_ACCESS_CMD_SET, policer_item->policer_id, &(policer_item->policer_atrrib), 1,
                          (sx_dev_info_t*)(param_p));
}

sx_status_t sx_policer_device_ready_callback(adviser_event_e event, void *param)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (event != ADVISER_EVENT_POST_DEVICE_READY_E) {
        SX_LOG_ERR("Wrong event type, expected event type is ADVISER_EVENT_DEVICE_READY, "
                   "received event type : [%s].\n",
                   ADVISER_EVENT_STR(event));
        err = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    err = policer_db_add_device_foreach(__policer_set_attributes_to_dev, param);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Error in add device : error (%s)\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_policer_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    policer_db_log_verbosity_level_set(verbosity_level);

    return err;
}

sx_status_t sx_policer_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

    return err;
}

sx_status_t sx_policer_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 sx_policer_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event, error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

    err = lag_sink_global_advise(sx_policer_lag_global_update, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in lag_sink_global_advise, error: %s \n", sx_status_str(err));
    }


    err = policer_db_init(SX_POLICER_MAX_POLICERS_GLOBAL);

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sx_policer_deinit(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 sx_policer_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event, error: %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_policer_validate_attrib(sx_policer_mode_e       mode,
                                       sx_policer_info_t      *policer_info_p,
                                       sx_policer_db_attrib_t *policer_db_attrib_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    mod = 0;

    SX_LOG_ENTER();

    if (FALSE == SX_POLICER_TYPE_CHECK_RANGE(policer_info_p->policer_type)) {
        SX_LOG_ERR("Policer type (%u) exceeds range (%u...%u)\n",
                   policer_info_p->policer_type,
                   SX_POLICER_TYPE_MIN_E,
                   SX_POLICER_TYPE_MAX_E);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_WRONG_POLICER_TYPE);
    }

    policer_db_attrib_p->policer_type = policer_info_p->policer_type;
    policer_db_attrib_p->type_base_params = policer_info_p->type_base_params;

    if ((policer_db_attrib_p->policer_type != SX_POLICER_TYPE_GLOBAL_SLOW_E) &&
        (policer_db_attrib_p->policer_type != SX_POLICER_TYPE_PER_PORT_SLOW_E)) {
        policer_db_attrib_p->meter_type = policer_info_p->policer_attributes.meter_type;
        policer_db_attrib_p->cir = policer_info_p->policer_attributes.cir;
        policer_db_attrib_p->mode = mode;
        policer_db_attrib_p->cbs = policer_info_p->policer_attributes.cbs;
        policer_db_attrib_p->ebs = policer_info_p->policer_attributes.ebs;
        policer_db_attrib_p->yellow_action = policer_info_p->policer_attributes.yellow_action;
        policer_db_attrib_p->red_action = policer_info_p->policer_attributes.red_action;
        if (policer_db_attrib_p->meter_type == SX_POLICER_METER_PACKETS) {
            if (policer_db_attrib_p->mode == SX_POLICER_MODE_POLICER_E) {
                if (FALSE ==
                    SX_POLICER_CIR_CHECK_RANGE(policer_db_attrib_p->cir, SX_POLICER_CIR_MAX_UNITS_PACKET_RATE)) {
                    SX_LOG_ERR("CIR (%u) exceeds range (%u...%u)\n",
                               policer_db_attrib_p->cir,
                               SX_POLICER_CIR_MIN,
                               SX_POLICER_CIR_MAX_UNITS_PACKET_RATE);
                    return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
                }

                mod = policer_db_attrib_p->cir % SX_POLICER_CIR_METER_PACKETS_GLOBAL_STEP;
                if (mod != 0) {
                    SX_LOG_ERR("CIR (%u) exceeds range. should be at step of (%u)\n",
                               policer_db_attrib_p->cir,
                               SX_POLICER_CIR_METER_PACKETS_GLOBAL_STEP);
                    return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
                }
            }

            if ((policer_db_attrib_p->mode == SX_POLICER_MODE_PACKET_SAMPLING_E) &&
                (FALSE == SX_POLICER_CIR_PACKET_SAMPLING_CHECK_RANGE(policer_db_attrib_p->cir))) {
                SX_LOG_ERR("CIR (%u) exceeds range (%u...%u)\n",
                           policer_db_attrib_p->cir,
                           SX_POLICER_CIR_MIN,
                           SX_POLICER_CIR_MAX_PACKET_SAMPLING);
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
            }
        } else if (policer_db_attrib_p->meter_type == SX_POLICER_METER_TRAFFIC) {
            if (FALSE == SX_POLICER_CIR_CHECK_RANGE(policer_db_attrib_p->cir, SX_POLICER_CIR_MAX_UNITS_TRAFFIC_RATE)) {
                SX_LOG_ERR("CIR (%u) exceeds range (%u...%u)\n",
                           policer_db_attrib_p->cir,
                           SX_POLICER_CIR_MIN,
                           SX_POLICER_CIR_MAX_UNITS_TRAFFIC_RATE);
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
            }
        } else {
            SX_LOG_ERR("Meter type (%u) exceeds range (%u...%u)\n",
                       policer_db_attrib_p->meter_type,
                       SX_POLICER_METER_PACKETS,
                       SX_POLICER_METER_TRAFFIC);
            return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
        }

        if (SX_POLICER_MODE_PACKET_SAMPLING_E == mode) {
            if (policer_db_attrib_p->ebs) {
                SX_LOG_ERR("EBS in packet sampling mode must be 0. Instead, EBS = %u \n", policer_db_attrib_p->ebs);
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
            }
            if (policer_db_attrib_p->cbs > 100) {
                SX_LOG_ERR(
                    "CBS in packet sampling mode must be < than CIR. Instead, CBS = %u, CIR (in percentage)= %u \n",
                    policer_db_attrib_p->ebs,
                    policer_db_attrib_p->cir);
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
            }
        } else {
            if (policer_db_attrib_p->meter_type == SX_POLICER_METER_TRAFFIC) {
                switch (policer_db_attrib_p->cbs) {
                case 8:
                case 16:
                case 32:
                case 64:
                case 128:
                case 256:
                case 512:
                case 1024:
                    break;

                default:
                    SX_LOG_ERR("CBS (%u) is not one of pre defined values\n", policer_db_attrib_p->cbs);
                    return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
                }

                switch (policer_db_attrib_p->ebs) {
                case 8:
                case 16:
                case 32:
                case 64:
                case 128:
                case 256:
                case 512:
                case 1024:
                    break;

                default:
                    SX_LOG_ERR("EBS (%u) is not one of pre defined values\n", policer_db_attrib_p->ebs);
                    return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
                }
            } else if (policer_db_attrib_p->meter_type == SX_POLICER_METER_PACKETS) {
                switch (policer_db_attrib_p->cbs) {
                case 8000000:
                case 16000000:
                case 32000000:
                case 64000000:
                case 128000000:
                case 256000000:
                case 512000000:
                case 1024000000:
                    break;

                default:
                    SX_LOG_ERR("CBS (%u) is not one of pre defined values\n", policer_db_attrib_p->cbs);
                    return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
                }

                switch (policer_db_attrib_p->ebs) {
                case 8000000:
                case 16000000:
                case 32000000:
                case 64000000:
                case 128000000:
                case 256000000:
                case 512000000:
                case 1024000000:
                    break;

                default:
                    SX_LOG_ERR("EBS (%u) is not one of pre defined values\n", policer_db_attrib_p->ebs);
                    return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
                }
            }
        }

        if (FALSE == SX_POLICER_YELLOW_ACTION_CHECK_RANGE(policer_db_attrib_p->yellow_action)) {
            SX_LOG_ERR("Yellow Action (%u) exceeds range (%u...%u)\n",
                       policer_db_attrib_p->yellow_action,
                       SX_POLICER_ACTION_MIN,
                       SX_POLICER_ACTION_MAX);
            return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
        }

        if (FALSE == SX_POLICER_RED_ACTION_CHECK_RANGE(policer_db_attrib_p->red_action)) {
            SX_LOG_ERR("Red Action (%u) exceeds range (%u...%u)\n",
                       policer_db_attrib_p->red_action,
                       SX_POLICER_ACTION_MIN,
                       SX_POLICER_ACTION_MAX);
            return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
        }

        if (policer_db_attrib_p->policer_type == SX_POLICER_TYPE_GLOBAL_E) {
            rc = sx_fdb_check_swid(policer_db_attrib_p->type_base_params.swid);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed in swid validation\n");
                return M_UTILS_SX_LOG_EXIT(rc);
            }
        }
    } else { /* SX_POLICER_TYPE_GLOBAL_SLOW or SX_POLICER_TYPE_PER_PORT_SLOW*/
        if (policer_info_p->policer_attributes.meter_type != SX_POLICER_METER_PACKETS) {
            SX_LOG_WRN("CIR (%u) meter type parameter is not packet\n", policer_db_attrib_p->cir);
        }

        policer_db_attrib_p->meter_type = SX_POLICER_METER_PACKETS;
        policer_db_attrib_p->cir = policer_info_p->policer_attributes.cir;
        policer_db_attrib_p->cbs = policer_info_p->policer_attributes.cbs;

        /* EBS has no effect on slow policer */
        policer_db_attrib_p->ebs = policer_db_attrib_p->cbs;

        if (policer_info_p->policer_attributes.yellow_action != SX_POLICER_ACTION_DISCARD) {
            SX_LOG_WRN("CIR (%u) input parameter yellow action is not discard\n", policer_db_attrib_p->cir);
        }

        if (policer_info_p->policer_attributes.red_action != SX_POLICER_ACTION_DISCARD) {
            SX_LOG_WRN("CIR (%u) input parameter red action is not discard\n", policer_db_attrib_p->cir);
        }
        policer_db_attrib_p->yellow_action = SX_POLICER_ACTION_DISCARD;
        policer_db_attrib_p->red_action = SX_POLICER_ACTION_DISCARD;

        if (policer_db_attrib_p->policer_type == SX_POLICER_TYPE_GLOBAL_SLOW_E) {
            policer_db_attrib_p->mode = 0;
            if (FALSE == SX_POLICER_CIR_CHECK_RANGE(policer_db_attrib_p->cir, SX_POLICER_CIR_MAX_UNITS_PACKET_RATE)) {
                SX_LOG_ERR("CIR (%u) exceeds range (%u...%u)\n",
                           policer_db_attrib_p->cir,
                           SX_POLICER_CIR_MIN,
                           SX_POLICER_CIR_MAX_UNITS_PACKET_RATE);
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
            }
        } else { /* SX_POLICER_TYPE_PER_PORT_SLOW */
            if (FALSE ==
                SX_POLICER_CIR_CHECK_RANGE(policer_db_attrib_p->cir, SX_POLICER_CIR_METER_PACKETS_GLOBAL_STEP)) {
                SX_LOG_ERR("CIR (%u) exceeds range (%u...%u)\n",
                           policer_db_attrib_p->cir,
                           SX_POLICER_CIR_MIN,
                           SX_POLICER_CIR_METER_PACKETS_GLOBAL_STEP);
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
            }
        }

        mod = policer_db_attrib_p->cir % SX_POLICER_CIR_METER_PACKETS_SLOW_STEP;
        if (mod != 0) {
            SX_LOG_ERR("CIR (%u) exceeds range. should be at step of (%u)\n",
                       policer_db_attrib_p->cir,
                       SX_POLICER_CIR_METER_PACKETS_SLOW_STEP);
            return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
        }

        /* validate cbs is power of 2 */
        if (FALSE == IS_POWER_OF_2(policer_db_attrib_p->cbs)) {
            SX_LOG_ERR("CBS (%u) is not power of 2\n", policer_db_attrib_p->cbs);
            return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
        } else if (FALSE == SX_POLICER_CBS_CHECK_RANGE(policer_db_attrib_p->cbs)) {
            SX_LOG_ERR("CBS (%u) exceeds range (%u...%u)\n",
                       policer_db_attrib_p->cbs,
                       SX_POLICER_CBS_MIN,
                       SX_POLICER_CBS_MAX);
            return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
        }

        rc = sx_fdb_check_swid(policer_db_attrib_p->type_base_params.swid);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in swid validation\n");
            return M_UTILS_SX_LOG_EXIT(rc);
        }
    }
    return rc;
}

sx_status_t sx_policer_set(const sx_access_cmd_t   cmd,
                           const sx_policer_mode_e mode,
                           sx_policer_id_t       * policer_id_p,
                           sx_policer_info_t     * policer_info)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_policer_db_attrib_t old_policer_attrib;
    uint32_t               bind_num = 0;
    length_t               device_cnt = 0;
    sx_dev_info_t          device_list_arr[SX_DEVICE_ID_MAX];
    sx_policer_type_e      policer_type;
    sx_policer_db_attrib_t policer_db_attrib;

    SX_LOG_ENTER();

    SX_MEM_CLR(policer_db_attrib);

    policer_type = (cmd == SX_ACCESS_CMD_DESTROY) ? SX_POLICER_TYPE_GET(*policer_id_p) : policer_info->policer_type;

    switch (policer_type) {
    case SX_POLICER_TYPE_GLOBAL_E:
    case SX_POLICER_TYPE_GLOBAL_SLOW_E:
        switch (cmd) {
        case SX_ACCESS_CMD_CREATE:
            rc = sx_policer_validate_attrib(mode, policer_info, &policer_db_attrib);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in validation of policer_info : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            rc = policer_db_create(&policer_db_attrib, policer_id_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in allocation policer : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            rc = port_device_list_get(SX_ACCESS_CMD_COUNT, NULL, &device_cnt);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in port_device_list_get : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            if (device_cnt == 0) {
                SX_LOG_DBG("Zero device\n");
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_SUCCESS);
            }

            rc = port_device_list_get(SX_ACCESS_CMD_GET, device_list_arr, &device_cnt);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in port_device_list_get : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            rc = sx_handle_qpcr(SX_ACCESS_CMD_SET, *policer_id_p, &policer_db_attrib, device_cnt, device_list_arr);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in handle_qpcr : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            break; /* CREATE */

        case SX_ACCESS_CMD_DESTROY:
            rc = policer_db_binds_get(*policer_id_p, &bind_num);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error receiving number of bound policer : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }
            if (bind_num == 0) {
                rc = policer_db_destroy(*policer_id_p);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Error in policer destroy : error (%s)\n", sx_status_str(rc));
                    return M_UTILS_SX_LOG_EXIT(rc);
                }
            } else {
                SX_LOG_ERR("Error in policer destroy : can't destroy bound policer.\n");
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_RESOURCE_IN_USE);
            }
            break; /* DESTROY */

        case SX_ACCESS_CMD_EDIT:
            if (SX_POLICER_TYPE_GET(*policer_id_p) != SX_POLICER_TYPE_GLOBAL_E) {
                SX_LOG_ERR("Cannot change policer type\n");
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
            }

            rc = sx_policer_validate_attrib(mode, policer_info, &policer_db_attrib);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in validation of policer_info : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            rc = policer_db_attrib_get(*policer_id_p, &old_policer_attrib);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            rc = policer_db_binds_get(*policer_id_p, &bind_num);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error receiving number of bound policers : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            if ((bind_num > 0) && (policer_info->policer_type == SX_POLICER_TYPE_GLOBAL_E)
                && (old_policer_attrib.meter_type != policer_info->policer_attributes.meter_type)) {
                SX_LOG_ERR("Cannot change policer metering type while the policer is bound\n");
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
            }

            rc = policer_db_attrib_set(*policer_id_p, &policer_db_attrib);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in editing policer attributes : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            rc = port_device_list_get(SX_ACCESS_CMD_COUNT, NULL, &device_cnt);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in port_device_list_get : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            if (device_cnt == 0) {
                SX_LOG_DBG("Zero device\n");
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_SUCCESS);
            }

            rc = port_device_list_get(SX_ACCESS_CMD_GET, device_list_arr, &device_cnt);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in port_device_list_get : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            rc = sx_handle_qpcr(SX_ACCESS_CMD_SET, *policer_id_p, &policer_db_attrib, device_cnt, device_list_arr);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in handle_qpcr: error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }
            break; /* EDIT */

        default:
            SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
            rc = SX_STATUS_CMD_UNSUPPORTED;
        }
        break; /* GLOBAL POLICER */

    case SX_POLICER_TYPE_PER_PORT_E:
    case SX_POLICER_TYPE_PER_PORT_SLOW_E:
        switch (cmd) {
        case SX_ACCESS_CMD_CREATE:
            rc = sx_policer_validate_attrib(mode, policer_info, &policer_db_attrib);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in validation of policer_info : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }
            if (policer_type == SX_POLICER_TYPE_PER_PORT_SLOW_E) {
                *policer_id_p = 0;
                rc = port_db_specific_policer_db_create(&policer_db_attrib, policer_id_p);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Error in allocation policer : error (%s)\n", sx_status_str(rc));
                    return M_UTILS_SX_LOG_EXIT(rc);
                }
            } else {
                rc = port_db_higher_policer_db_create(&policer_db_attrib, policer_id_p);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Error in allocation policer : error (%s)\n", sx_status_str(rc));
                    return M_UTILS_SX_LOG_EXIT(rc);
                }
            }

            rc = sx_handle_qpcr(SX_ACCESS_CMD_SET, *policer_id_p, &policer_db_attrib, 0, NULL);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in handle_qpcr : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }
            break; /* CREATE */

        case SX_ACCESS_CMD_DESTROY:
            rc = port_db_policer_db_binds_get(*policer_id_p, &bind_num);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error receiving number of bound policer : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }
            if (bind_num == 0) {
                rc = port_db_policer_db_destroy(*policer_id_p);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Error in policer destroy : error (%s)\n", sx_status_str(rc));
                    return M_UTILS_SX_LOG_EXIT(rc);
                }
            } else {
                SX_LOG_ERR("Error in policer destroy : can't destroy bound policer.\n");
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_RESOURCE_IN_USE);
            }
            break; /* DESTROY */

        case SX_ACCESS_CMD_EDIT:
            if (SX_POLICER_TYPE_GET(*policer_id_p) != SX_POLICER_TYPE_PER_PORT_E) {
                SX_LOG_ERR("Cannot change policer type\n");
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
            }

            if (SX_POLICER_LOG_PORT_GET(*policer_id_p) != policer_info->type_base_params.log_port) {
                SX_LOG_ERR("Cannot change port for per port policer\n");
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
            }

            rc = sx_policer_validate_attrib(mode, policer_info, &policer_db_attrib);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in validation of policer_info : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            rc = port_db_policer_db_binds_get(*policer_id_p, &bind_num);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error receiving number of bound policers : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            rc = port_db_policer_db_attrib_get(*policer_id_p, &old_policer_attrib);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            if ((bind_num > 0) && (old_policer_attrib.meter_type != policer_info->policer_attributes.meter_type)) {
                SX_LOG_ERR("Cannot change policer metering type while the police is bound\n");
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
            }

            rc = sx_handle_qpcr(SX_ACCESS_CMD_SET, *policer_id_p, &policer_db_attrib, 0, NULL);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in handle_qpcr : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }

            rc = port_db_policer_db_attrib_set(*policer_id_p, &policer_db_attrib);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Error in editing policer attributes : error (%s)\n", sx_status_str(rc));
                return M_UTILS_SX_LOG_EXIT(rc);
            }
            break; /* EDIT */

        default:
            SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
            rc = SX_STATUS_CMD_UNSUPPORTED;
        }
        break;

    default:
        SX_LOG_ERR("Wrong policer type (%u)\n", policer_type);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_WRONG_POLICER_TYPE);
    }

    return M_UTILS_SX_LOG_EXIT(rc);
}


sx_status_t sx_policer_get(const sx_policer_id_t policer_id, sx_policer_attributes_t *policer_attr_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_policer_type_e      policer_type;
    sx_policer_db_attrib_t policer_attrib;

    SX_LOG_ENTER();

    policer_type = SX_POLICER_TYPE_GET(policer_id);

    switch (policer_type) {
    case SX_POLICER_TYPE_GLOBAL_E:
        rc = policer_db_attrib_get(policer_id, &policer_attrib);
        break;

    case SX_POLICER_TYPE_PER_PORT_E:
        rc = port_db_policer_db_attrib_get(policer_id, &policer_attrib);
        break;

    /* coverity[dead_error_begin] */
    default:
        SX_LOG_ERR("Wrong policer type (%u)\n", policer_type);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_WRONG_POLICER_TYPE);
    }

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in retrieving policer information : error (%s)\n", sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }


    policer_attr_p->cbs = policer_attrib.cbs;
    policer_attr_p->ebs = policer_attrib.ebs;
    policer_attr_p->cir = policer_attrib.cir;
    policer_attr_p->meter_type = policer_attrib.meter_type;
    policer_attr_p->yellow_action = policer_attrib.yellow_action;
    policer_attr_p->red_action = policer_attrib.red_action;

    return M_UTILS_SX_LOG_EXIT(rc);
}

sx_status_t sx_policer_storm_control_bind_validations(const sx_access_cmd_t        cmd,
                                                      const sx_port_log_id_t       log_port,
                                                      const sx_policer_id_t        policer_id,
                                                      const sx_port_packet_types_t port_packet_types,
                                                      const sx_policer_mode_e      mode,
                                                      boolean_t                   *is_update_packet_type_p)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_policer_type_e policer_type;
    boolean_t         is_bound = FALSE;

    SX_LOG_ENTER();

    if (NULL == is_update_packet_type_p) {
        SX_LOG_ERR("Null pointer\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_NULL);
    }
    *is_update_packet_type_p = TRUE;
    policer_type = SX_POLICER_TYPE_GET(policer_id);

    if (FALSE == port_post_init_done()) {
        SX_LOG_ERR("Failure - %s\n", sx_status_str(SX_STATUS_DB_NOT_INITIALIZED));
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
    }

    rc = port_db_is_policer_bound(log_port, policer_id, &is_bound);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in receiving bound information : error (%s)\n", sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        if (SX_POLICER_MODE_POLICER_E == mode) {
            /* validate legality of policer */
            switch (policer_type) {
            case SX_POLICER_TYPE_PER_PORT_E:
            case SX_POLICER_TYPE_PER_PORT_SLOW_E:
                if (SX_POLICER_LOG_PORT_GET(policer_id) != log_port) {
                    SX_LOG_ERR("Can't bind per port (0x%08X) policer to log_port (0x%08X).\n",
                               SX_POLICER_LOG_PORT_GET(policer_id), log_port);
                    return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
                }
                break;

            case SX_POLICER_TYPE_STORM_CONTROL_E:
                break;

            case SX_POLICER_TYPE_GLOBAL_E:
            default:
                SX_LOG_ERR("Wrong policer type (%d)\n", policer_type);
                return M_UTILS_SX_LOG_EXIT(SX_STATUS_WRONG_POLICER_TYPE);
            }
        }

        rc = port_policer_pre_bind_validate(log_port,
                                            policer_id,
                                            &port_packet_types,
                                            is_bound,
                                            is_update_packet_type_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in validation of port_packet_types : error (%s)\n", sx_status_str(rc));
            return M_UTILS_SX_LOG_EXIT(rc);
        }
        break;

    case SX_ACCESS_CMD_UNBIND:
        if (!is_bound) {
            SX_LOG_DBG("Policer is not bound\n");
            return M_UTILS_SX_LOG_EXIT(SX_STATUS_ENTRY_NOT_BOUND);
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
    }

    SX_LOG_EXIT();

    return rc;
}

sx_status_t sx_policer_storm_control_set_impl(const sx_access_cmd_t                 cmd,
                                              const sx_port_log_id_t                log_port,
                                              const sx_port_storm_control_id_t      storm_control_id,
                                              const sx_port_storm_control_params_t *storm_control_params_p,
                                              int                                  *new_policer_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    boolean_t              is_update_packet_type = TRUE;
    sx_policer_id_t        policer_id = 0;
    sx_policer_info_t      policer_info;
    sx_access_cmd_t        cmd_intl = SX_ACCESS_CMD_NONE;
    boolean_t              policer_allocated = FALSE;
    sx_policer_id_t        policer_zero_id = 0;
    sx_policer_db_attrib_t policer_zero_attr;
    sx_policer_db_attrib_t old_policer_attr;
    boolean_t              is_sflow = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(policer_zero_attr);
    SX_MEM_CLR(old_policer_attr);
    SX_MEM_CLR(policer_info);

    /* Validate Port */
    VALIDATE_PORT(sx_policer_storm_control_set_impl, log_port);

    if (NULL == storm_control_params_p) {
        SX_LOG_ERR("Null param\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_NULL);
    }

    if (NULL == new_policer_p) {
        SX_LOG_ERR("Null param\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_NULL);
    }


    if ((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_EDIT)) {
        if ((storm_control_params_p->policer_params.cir < SX_POLICER_CIR_METER_PACKETS_GLOBAL_STEP) &&
            (storm_control_params_p->policer_params.meter_type == SX_POLICER_METER_PACKETS)) {
            policer_info.policer_type = SX_POLICER_TYPE_PER_PORT_SLOW_E;
        } else {
            policer_info.policer_type = SX_POLICER_TYPE_PER_PORT_E;
        }
    }
    policer_info.type_base_params.log_port = log_port;
    policer_info.policer_attributes = storm_control_params_p->policer_params;

    *new_policer_p = FALSE;
    /* Storm control mapping to the policer */
    rc = port_db_storm_control_policer_id_get(log_port, storm_control_id, &policer_id, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Storm control %d port%#08X - DB get failure (%s)\n",
                   storm_control_id, log_port, sx_status_str(rc));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        if (policer_id != SX_POLICER_ID_INVALID) {
            rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
            SX_LOG_ERR("Storm control id %d already exists on port (0x%08X)"
                       " (%s).\n", storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }

        /* Policer allocation */
        rc = policer_set(SX_ACCESS_CMD_CREATE, SX_POLICER_MODE_POLICER_E, &policer_id, &policer_info);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control %d port %#08X - policer creation failure (%s)\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }
        SX_LOG_DBG("Storm control %d, allocated policer %#" PRIx64 ". Port %#08x\n",
                   storm_control_id, policer_id, log_port);

        /* update port database with policer id */
        rc = port_db_storm_control_policer_id_set(log_port, storm_control_id, policer_id, FALSE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control %d port%#08X - DB set failure (%s)\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }
        *new_policer_p = TRUE;
        cmd_intl = SX_ACCESS_CMD_BIND;
        break;

    case SX_ACCESS_CMD_EDIT:
        if (policer_id == SX_POLICER_ID_INVALID) {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Storm control id %d not found on port (0x%08X)(%s).\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }

        /* Get old policer attributes */
        rc = port_db_policer_db_attrib_get(policer_id, &old_policer_attr);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control policer get attribute fail\n");
            goto out;
        }
        if ((policer_info.policer_attributes.meter_type != SX_POLICER_METER_PACKETS) &&
            (policer_info.policer_attributes.meter_type != SX_POLICER_METER_TRAFFIC)) {
            SX_LOG_ERR("Meter type (%u) exceeds range (%u...%u)\n",
                       policer_info.policer_attributes.meter_type,
                       SX_POLICER_METER_PACKETS,
                       SX_POLICER_METER_TRAFFIC);
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        /* Check if policer will change its path type */
        if (old_policer_attr.policer_type != policer_info.policer_type) {
            policer_zero_id = policer_id & SX_POLICER_ZERO_PID_MASK;
            if (policer_info.policer_type == SX_POLICER_TYPE_PER_PORT_SLOW_E) {    /* New path type is slow */
                /* Check if policer 0 allocated */
                port_db_policer_db_is_allocated_policer(policer_zero_id, &policer_allocated);
                if (policer_allocated) {    /* Policer 0 allocated , cannot configure slow policer on other policers */
                    rc = SX_STATUS_NO_RESOURCES;
                    goto out;
                }
                /* Need to move the policer to policer 0 , then edit its values */
                rc = port_policer_atomic_id_change(policer_id,
                                                   policer_zero_id,
                                                   storm_control_id,
                                                   &policer_info,
                                                   FALSE);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Storm control %d port %#08X - atomic id change fail (%s)\n",
                               storm_control_id, log_port, sx_status_str(rc));
                    goto out;
                }
                policer_id = policer_zero_id;
                cmd_intl = SX_ACCESS_CMD_BIND;
                break;
            } else {     /* Policer new path type is fast */
                /* Check if policers 1-4 are allocated */
                int ii = 0;
                for (ii = SX_POLICER_MAX_POLICERS_PER_PORT - 1; ii > 0; ii--) {
                    port_db_policer_db_is_allocated_policer(policer_zero_id + ii, &policer_allocated);
                    if (policer_allocated == FALSE) {
                        break;
                    }
                }
                if (!policer_allocated) {    /* found free Policers in policers 1-4 */
                    /* Need to move policer 0 to free policer , then edit its values */
                    rc = port_policer_atomic_id_change(policer_zero_id,
                                                       policer_zero_id + ii,
                                                       storm_control_id,
                                                       &policer_info,
                                                       FALSE);
                    if (SX_CHECK_FAIL(rc)) {
                        SX_LOG_ERR("Storm control %d port %#08X - atomic id change fail (%s)\n",
                                   storm_control_id, log_port, sx_status_str(rc));
                        goto out;
                    }
                    policer_id = policer_zero_id + ii;
                    cmd_intl = SX_ACCESS_CMD_BIND;
                    break;
                }
            }
        }
        /* Update policer */
        rc = policer_set(SX_ACCESS_CMD_EDIT, SX_POLICER_MODE_POLICER_E, &policer_id, &policer_info);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control %d port %#08X - policer edit failure (%s)\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }
        cmd_intl = SX_ACCESS_CMD_BIND;
        break;

    case SX_ACCESS_CMD_DELETE:
        if (policer_id == SX_POLICER_ID_INVALID) {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Storm control id %d not found on port (0x%08X) (%s).\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }
        cmd_intl = SX_ACCESS_CMD_UNBIND;
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    rc = policer_storm_control_bind_validations(cmd_intl, log_port, policer_id,
                                                storm_control_params_p->packet_types,
                                                SX_POLICER_MODE_POLICER_E,
                                                &is_update_packet_type);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Storm control %d port %#08X - validation failure (%s)\n",
                   storm_control_id, log_port, sx_status_str(rc));
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_EDIT) && (FALSE == is_update_packet_type)) {
        /* no change */
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = port_policer_bind_hw_db_set(cmd_intl, log_port, policer_id, storm_control_params_p->packet_types);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Storm control policer bind HW failure - port  %#08X (%s)\n",
                   log_port, sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    /* Complete DELETE actions */
    if (cmd == SX_ACCESS_CMD_DELETE) {
        uint32_t bind_num = 0;

        /* Self-check */
        rc = port_db_policer_db_binds_get(policer_id, &bind_num);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control %d port %#08X policer %#" PRIx64
                       ":failed to get binds number (%s)\n",
                       storm_control_id, log_port, policer_id, sx_status_str(rc));
            goto out;
        }

        if (bind_num != 0) {
            rc = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("Storm control %d port %#08X policer %#" PRIx64
                       " is bound - cannot destroy (%s)\n",
                       storm_control_id, log_port, policer_id, sx_status_str(rc));
            goto out;
        }

        /* Return policer to pool */
        rc = port_db_policer_db_destroy(policer_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control %d port %#08X policer %#" PRIx64
                       ":failed to destroy policer(%s)\n",
                       storm_control_id, log_port, policer_id, sx_status_str(rc));
            goto out;
        }

        rc = port_db_storm_control_policer_id_clean(log_port, storm_control_id, FALSE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control %d port%#08X - policer id clean failure (%s)\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }

        /*Check if fast path policer located on policer 0 , if yes move to free policer*/
        policer_zero_id = SX_POLICER_ZERO_PID_GET(policer_id);
        port_db_policer_db_is_allocated_policer(policer_zero_id, &policer_allocated);
        if (policer_allocated) {
            /* Get policer 0 attributes */
            rc = port_db_policer_db_attrib_get(policer_zero_id, &policer_zero_attr);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Storm control policer get attribute fail\n");
                goto out;
            }
            /* If policer 0 fast path , move it */
            if (policer_zero_attr.policer_type == SX_POLICER_TYPE_PER_PORT_E) {
                policer_info.policer_attributes.cbs = policer_zero_attr.cbs;
                policer_info.policer_attributes.cir = policer_zero_attr.cir;
                policer_info.policer_attributes.ebs = policer_zero_attr.ebs;
                policer_info.policer_attributes.meter_type = policer_zero_attr.meter_type;
                policer_info.policer_attributes.red_action = policer_zero_attr.red_action;
                policer_info.policer_attributes.yellow_action = policer_zero_attr.yellow_action;
                policer_info.policer_type = policer_zero_attr.policer_type;

                /* Get policer 0 storm control id */
                sx_port_storm_control_id_t zero_storm_control_id = 0;
                rc =
                    port_db_storm_control_policer_id_find(log_port, policer_zero_id, &zero_storm_control_id,
                                                          &is_sflow);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Storm control port_db_storm_control_policer_id_find fail (%s)\n", sx_status_str(rc));
                    goto out;
                }

/*                if (is_sflow) {
 *                   rc = port_db_storm_control_policer_id_clean(log_port, storm_control_id, is_sflow);
 *                   if (SX_CHECK_FAIL(rc)) {
 *                       SX_LOG_ERR("Storm control %d port%#08X - policer id clean failure (%s)\n",
 *                                  storm_control_id, log_port, sx_status_str(rc));
 *                       goto out;
 *                   }
 *               }
 */
                rc = port_policer_atomic_id_change(policer_zero_id,
                                                   policer_id,
                                                   zero_storm_control_id,
                                                   &policer_info,
                                                   is_sflow);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Storm control %d port %#08X - atomic id change fail (%s)\n",
                               zero_storm_control_id, log_port, sx_status_str(rc));
                    goto out;
                }
/*
 *                if (is_sflow) {
 *                   rc = port_db_storm_control_policer_id_set(log_port, storm_control_id, policer_id, is_sflow);
 *                   if (SX_CHECK_FAIL(rc)) {
 *                       SX_LOG_ERR("port_db_storm_control_policer_id_set failure (%s)\n",
 *                                  sx_status_str(rc));
 *                       goto out;
 *                   }
 *               }
 */
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sx_handle_qpbr(const sx_access_cmd_t        cmd,
                           const sx_port_log_id_t       log_port,
                           const sx_policer_id_t        policer_id,
                           const sx_port_packet_types_t port_packet_types)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    boolean_t          is_bound = FALSE;
    struct ku_qpbr_reg qpbr_reg_data;
    sxd_reg_meta_t     qpbr_reg_meta;

    SX_LOG_ENTER();

    SX_MEM_CLR(qpbr_reg_meta);
    SX_MEM_CLR(qpbr_reg_data);


    if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(log_port)) {
        SX_LOG_ERR("Failure - port is LAG\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    rc = port_db_is_policer_bound(log_port, policer_id, &is_bound);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in receiving bound information : error (%s)\n", sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    if (SX_CHECK_FAIL(rc = port_swid_alloc_get(SX_ACCESS_CMD_GET, log_port, &qpbr_reg_meta.swid))) {
        SX_LOG_ERR("Can't Retrieve SwID of Port 0x%08X (%s). (bind policer)\n", log_port, sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    /* QPBR meta: */
    qpbr_reg_meta.dev_id = SX_PORT_DEV_ID_GET(log_port);
    qpbr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    /* QPBR data: */
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(qpbr_reg_data.port, qpbr_reg_data.lp_msb, SX_PORT_PHY_ID_GET(log_port));
    qpbr_reg_data.global_policer = SX_POLICER_TYPE_GET(policer_id);
    qpbr_reg_data.pid = SX_POLICER_PID_GET(policer_id);
    qpbr_reg_data.unicast = port_packet_types.uc;
    qpbr_reg_data.multicast = port_packet_types.mc;
    qpbr_reg_data.broadcast = port_packet_types.bc;
    qpbr_reg_data.unknown_unicast = port_packet_types.uuc;
    qpbr_reg_data.unregistered_multicast = port_packet_types.umc;

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        if (is_bound) {
            qpbr_reg_data.operation = SXD_PORT_POLICER_UPDATE;
        } else {
            qpbr_reg_data.operation = SXD_PORT_POLICER_BIND;
        }
        break;

    case SX_ACCESS_CMD_UNBIND:
        qpbr_reg_data.operation = SXD_PORT_POLICER_UNBIND;
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    rc =
        sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_QPBR_E, &qpbr_reg_data,
                                                                    &qpbr_reg_meta, 1,
                                                                    NULL, NULL));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Can't send SET-QPBR EMAD (%s)\n", sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    SX_LOG_EXIT();

    return rc;
}

static sx_status_t __policer_storm_control_set_lag_attrs(const sx_access_cmd_t                 cmd,
                                                         const sx_port_log_id_t                log_port,
                                                         const sx_port_storm_control_id_t      storm_control_id,
                                                         const sx_port_storm_control_params_t *storm_control_params)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_policer_info_t      policer_info;
    sx_policer_id_t        policer_id = 0;
    sx_policer_db_attrib_t policer_db_attrib;
    sx_policer_db_attrib_t old_policer_attrib;

    SX_LOG_ENTER();

    SX_MEM_CLR(policer_db_attrib);
    SX_MEM_CLR(old_policer_attrib);
    SX_MEM_CLR(policer_info);

    /* Storm control mapping to the policer */
    rc = port_db_storm_control_policer_id_get(log_port, storm_control_id, &policer_id, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Storm control %d port%#08X - DB get failure (%s)\n",
                   storm_control_id, log_port, sx_status_str(rc));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        if (policer_id != SX_POLICER_ID_INVALID) {
            rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
            SX_LOG_ERR("Storm control id %d already exists on port (0x%08X)"
                       " (%s).\n", storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }

        policer_info.policer_type = SX_POLICER_TYPE_PER_PORT_E;
        policer_info.type_base_params.log_port = log_port;
        policer_info.policer_attributes = storm_control_params->policer_params;

        /* validate parameters range */
        rc = policer_validate_attrib(SX_POLICER_MODE_POLICER_E, &policer_info, &policer_db_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in validation of policer_info : error (%s)\n"
                       , sx_status_str(rc));
            return M_UTILS_SX_LOG_EXIT(rc);
        }

        rc = port_db_policer_db_create(&policer_db_attrib, &policer_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in allocation policer : error (%s)\n", sx_status_str(rc));
            return M_UTILS_SX_LOG_EXIT(rc);
        }

        rc = port_db_storm_control_policer_id_set(log_port, storm_control_id, policer_id, FALSE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control %d port%#08X - DB set failure (%s)\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }

        rc = port_policer_bind_db_set(SX_ACCESS_CMD_BIND, log_port,
                                      policer_id, storm_control_params->packet_types);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Policer bind lag 0x%08X failure (%s)\n", log_port, sx_status_str(rc));
            goto out;
        }

        rc = port_db_storm_control_policer_id_set(log_port, storm_control_id, policer_id, FALSE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control %d port%#08X - DB set failure (%s)\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        if (policer_id == SX_POLICER_ID_INVALID) {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Storm control id %d not found on port (0x%08X)(%s).\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }

        policer_info.policer_type = SX_POLICER_TYPE_PER_PORT_E;
        policer_info.type_base_params.log_port = log_port;
        policer_info.policer_attributes = storm_control_params->policer_params;

        /* validate parameters range */
        rc = policer_validate_attrib(SX_POLICER_MODE_POLICER_E, &policer_info, &policer_db_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in validation of policer_info : error (%s)\n"
                       , sx_status_str(rc));
            goto out;
        }

        rc = port_db_policer_db_attrib_get(policer_id, &old_policer_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in receiving current policer attributes : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        /* Following limitation extended to LAGs and ports */
        if (old_policer_attrib.meter_type != policer_info.policer_attributes.meter_type) {
            SX_LOG_ERR("Cannot change policer metering type.\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        /* Update attributes in DB */
        rc = port_db_policer_db_attrib_set(policer_id, &policer_db_attrib);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in editing policer attributes : error (%s)\n", sx_status_str(rc));
            goto out;
        }

        /* Update packet types */
        rc = port_policer_bind_db_set(SX_ACCESS_CMD_BIND, log_port,
                                      policer_id, storm_control_params->packet_types);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Policer bind lag 0x%08X failure (%s)\n", log_port, sx_status_str(rc));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        if (policer_id == SX_POLICER_ID_INVALID) {
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Storm control id %d not found on port (0x%08X)(%s).\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }

        rc = port_policer_bind_db_set(SX_ACCESS_CMD_UNBIND, log_port,
                                      policer_id, storm_control_params->packet_types);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Policer unbind lag 0x%08X failure (%s)\n", log_port, sx_status_str(rc));
            return rc;
        }
        rc = port_db_policer_db_destroy(policer_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in policer destroy : error (%s)\n", sx_status_str(rc));
            return M_UTILS_SX_LOG_EXIT(rc);
        }

        rc = port_db_storm_control_policer_id_clean(log_port, storm_control_id, FALSE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Storm control %d port%#08X - DB set failure (%s)\n",
                       storm_control_id, log_port, sx_status_str(rc));
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        return M_UTILS_SX_LOG_EXIT(rc);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sx_policer_storm_control_set(const sx_access_cmd_t                 cmd,
                                         const sx_port_log_id_t                log_port,
                                         const sx_port_storm_control_id_t      storm_control_id,
                                         const sx_port_storm_control_params_t *storm_control_params_p)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    uint8_t         lag_member = 0;
    sx_status_t     rc1;
    sx_policer_id_t policer_id = 0;
    sx_port_id_t  * port_list = NULL;
    uint32_t        port_num = rm_resource_global.lag_port_members_max;
    uint32_t        iii = 0;
    sx_swid_id_t    swid;
    boolean_t       is_bound = FALSE;
    int             new_policer = FALSE;

    SX_LOG_ENTER();

    /* Validate Port */
    VALIDATE_PORT(sx_policer_storm_control_set, log_port);

    port_list = (sx_port_id_t*)cl_malloc(sizeof(sx_port_id_t) * rm_resource_global.lag_port_members_max);
    if (port_list == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(port_list, 0, sizeof(sx_port_id_t) * rm_resource_global.lag_port_members_max);

    if (NULL == storm_control_params_p) {
        SX_LOG_ERR("Null param\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* exit if port is lag member */
    if (SX_CHECK_FAIL(rc = port_lag_member_state_get(SX_ACCESS_CMD_GET, log_port, &lag_member))) {
        SX_LOG_ERR("Failed to get lag status of port (0x%08X) (%s)\n", log_port, sx_status_str(rc));
        goto out;
    }
    if (lag_member) {
        SX_LOG_ERR("Port 0x%08X storm control - port is a LAG member\n", log_port);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = port_swid_alloc_get(SX_ACCESS_CMD_GET, log_port, &swid))) {
        SX_LOG_ERR("Failed to retrieve SwID of Port 0x%08X (%s).\n", log_port, sx_status_str(rc));
        goto out;
    }

    rc = swid_validation_func_ptr(swid);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SWID(%d) type mismatch\n", swid);
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_EDIT)) {
        rc = policer_validate_packet_type(storm_control_params_p->packet_types);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Error in validation of storm_control_params_p : "
                       "error (%s)\n", sx_status_str(rc));
            goto out;
        }
    }

    if (SX_PORT_TYPE_LAG != SX_PORT_TYPE_ID_GET(log_port)) {
        port_num = 1;
        port_list[0] = log_port;
    } else {
        rc = sx_lag_port_group_get(log_port, port_list, &port_num);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to retrieve lag members of lag %#08X (%s)\n",
                       log_port, sx_status_str(rc));
            goto out;
        }
    }

    for (iii = 0; iii < port_num; iii++) {
        rc =
            sx_policer_storm_control_set_impl(cmd, port_list[iii], storm_control_id, storm_control_params_p,
                                              &new_policer);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Port 0x%08X: storm control operation failed for port %#08X (%s)\n",
                       log_port, port_list[iii], sx_status_str(rc));
            goto out_rollback;
        }
    }

    /* Set policer attributes and packet types in port db for LAG log-port  */
    if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(log_port)) {
        rc = __policer_storm_control_set_lag_attrs(cmd, log_port, storm_control_id, storm_control_params_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set storm control for lag %#08X (%s)\n",
                       log_port, sx_status_str(rc));
            goto out;
        }
    }

    goto out;

out_rollback:
    /* For ADD operation destroy policers, which already were allocated - and not bound */
    if ((cmd == SX_ACCESS_CMD_ADD) && new_policer) {
        for (iii = 0; iii < port_num; iii++) {
            rc1 = port_db_storm_control_policer_id_get(port_list[iii], storm_control_id, &policer_id, FALSE);
            if (SX_CHECK_FAIL(rc1)) {
                SX_LOG_ERR("Port 0x%08X storm control %d - rollback DB get failure, port %#08X (%s)\n",
                           storm_control_id, log_port, port_list[iii], sx_status_str(rc1));
                goto out;
            }
            if (policer_id != SX_POLICER_ID_INVALID) {
                rc1 = port_db_is_policer_bound(port_list[iii], policer_id, &is_bound);
                if (SX_CHECK_FAIL(rc1)) {
                    SX_LOG_ERR("Storm control %d - failed to get policer %#" PRIx64
                               " binding to port %#08X (%s)\n",
                               storm_control_id, policer_id, port_list[iii], sx_status_str(rc1));
                    goto out;
                }

                if (!is_bound) {
                    SX_LOG_DBG("Storm control %d, policer %#" PRIx64 " rollback. Port %#08x\n",
                               storm_control_id, policer_id, port_list[iii]);
                    rc1 = policer_set(SX_ACCESS_CMD_DESTROY, SX_POLICER_MODE_POLICER_E, &policer_id, NULL);
                    if (SX_CHECK_FAIL(rc1)) {
                        SX_LOG_ERR("Storm control %d port 0x%08X - rollback policer "
                                   "destroy failure, port %#08X (%s)\n", storm_control_id,
                                   log_port, port_list[iii], sx_status_str(rc1));
                        goto out;
                    }
                    rc1 = port_db_storm_control_policer_id_clean(port_list[iii], storm_control_id, FALSE);
                    if (SX_CHECK_FAIL(rc1)) {
                        SX_LOG_ERR("Port 0x%08X storm control %d - rollback DB get failure, port %#08X (%s)\n",
                                   storm_control_id, log_port, port_list[iii], sx_status_str(rc1));
                        goto out;
                    }
                }
            }
        }
    }

out:
    if (port_list != NULL) {
        CL_FREE_N_NULL(port_list);
    }
    SX_LOG_EXIT();
    return rc;
}


sx_status_t sx_policer_storm_control_get(const sx_port_log_id_t           log_port,
                                         const sx_port_storm_control_id_t storm_control_id,
                                         sx_port_storm_control_params_t  *storm_control_params_p)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    sx_policer_id_t         policer_id;
    sx_policer_attributes_t policer_attributes;

    SX_LOG_ENTER();

    SX_MEM_CLR(policer_attributes);

    /* Validate Port */
    VALIDATE_PORT(sx_policer_storm_control_get, log_port);

    if (!RM_PORT_STORM_CONTROL_CHECK_MAX(storm_control_id)) {
        SX_LOG_ERR("storm_control_id param exceeds range\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
    }

    if (NULL == storm_control_params_p) {
        SX_LOG_ERR("Null param\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_NULL);
    }

    /*
     *  if (FALSE == port_post_init_done_s) {
     *   SX_LOG_ERR("Failure - %s\n", sx_status_str(SX_STATUS_DB_NOT_INITIALIZED));
     *   return M_UTILS_SX_LOG_EXIT(SX_STATUS_DB_NOT_INITIALIZED);
     *  }
     */

    rc = port_db_storm_control_policer_id_get(log_port, storm_control_id, &policer_id, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Storm control %d port%#08X - DB get failure (%s)\n",
                   storm_control_id, log_port, sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }
    if (policer_id == SX_POLICER_ID_INVALID) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Storm control id %d not defined on port (0x%08X)(%s).\n",
                   storm_control_id, log_port, sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    rc = policer_get(policer_id, &policer_attributes);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Storm control %d - failed to get policer %#" PRIx64 " of port %#08X (%s).\n",
                   storm_control_id, policer_id, log_port, sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }
    storm_control_params_p->policer_params = policer_attributes;

    rc = port_db_bound_policer_packet_type_get(log_port, policer_id, &storm_control_params_p->packet_types);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Storm control %d port %#08X policer %#" PRIx64 "- packet types get failure : (%s)\n",
                   storm_control_id, log_port, policer_id, sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    SX_LOG_EXIT();

    return rc;
}
