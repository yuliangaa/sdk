/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __HWD_TELE_H__
#define __HWD_TELE_H__

#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <sx/sdk/sx_types.h>

#include "tele/hwi/tele_impl.h"

/************************************************
 *  Local Defines
 ***********************************************/
#define SXD_IHSR_HASH_TYPE_CRC 0

#define SXD_IHSR_SYMMETRIC_HASH_OUTER  0
#define SXD_IHSR_SYMMETRIC_HASH_INNER  1
#define SXD_IHSR_SYMMETRIC_HASH_GP_REG 2

#define BITS_IN_UINT32 32

#define SXD_HGCR_TAC_CRAWLER_STOP 31

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/* This enum represent TAC action values for HGCR and HTACG registers */
typedef enum {
    SXD_TAC_ACTION_FLUSH_AND_REPORT_E = 0,
    SXD_TAC_ACTION_FLUSH_ONLY_E       = 1,
    SXD_TAC_ACTION_REPORT_ONLY_E      = 2,
} sxd_tac_actions_e;

/* This enum represent TAC action status values for HTACG register */
typedef enum {
    SXD_TAC_ACTION_STATUS_IDLE_E = 0,
    SXD_TAC_ACTION_STATUS_BUSY_E = 1,
} sxd_tac_actions_status_e;


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

#define TELE_THRESHOLD_STATIC_MAX_VALUE                   \
    CEILING(rm_resource_global.shared_buff_max_pool_size, \
            rm_resource_global.shared_buff_buffer_unit_size)

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum tac_opt_tlv_type {
    TAC_OPT_TLV_TYPE_UID_LSB_E          = 1,
    TAC_OPT_TLV_TYPE_UID_MSB_E          = 2,
    TAC_OPT_TLV_TYPE_MAX_LIFETIME_E     = 3,
    TAC_OPT_TLV_TYPE_TAC_COMMAND_E      = 4,
    TAC_OPT_TLV_TYPE_LIST_LOCAL_PORTS_E = 5,
    TAC_OPT_TLV_TYPE_USER_DEFINED_E     = 6,
    TAC_OPT_TLV_TYPE_NOP_E              = 0xFF,
} tac_opt_tlv_types_e;

#define TAC_OPT_TLV_TYPE_INVALID_LEN          0
#define TAC_OPT_TLV_TYPE_UID_LSB_LEN          2
#define TAC_OPT_TLV_TYPE_UID_MSB_LEN          2
#define TAC_OPT_TLV_TYPE_MAX_LIFETIME_LEN     2
#define TAC_OPT_TLV_TYPE_TAC_COMMAND_LEN      2
#define TAC_OPT_TLV_TYPE_LIST_LOCAL_PORTS_LEN 2
#define TAC_OPT_TLV_TYPE_NOP_LEN              2

typedef enum tac_msg_type {
    TAC_MSG_TYPE_EVENT_SW_HDR_E = 1,
    TAC_MSG_TYPE_OOB_SW_HDR_E   = 2
} tac_msg_type_e;

#define TAC_MSG_SW_HDR_VERSION_MSG_TYPE_BUILD(ver, msg_type) ((ver << 4) | msg_type)

typedef struct sx_tele_tac_msg_opt_tlv {
    uint8_t  opt_type;
    uint8_t  opt_len;
    uint16_t opt_data;
} __attribute__((__packed__)) sx_tele_tac_msg_opt_tlv_t;

typedef struct sx_tele_tac_msg_header {
    uint8_t  dmac[ETHER_ADDR_LENGTH];
    uint8_t  smac[ETHER_ADDR_LENGTH];
    uint16_t eth_type;
    uint16_t reserved;
    uint8_t  version_msg_type;          /* version 4 bits (4-7), msg_type 4 bits (0-3)*/
    uint8_t  msg_total_len;             /* In units of 4B not including the 1st DWORD of this header. In SW_HDR 3, in OOB msg 1-255*/
    uint16_t reserved2;
} __attribute__((__packed__)) sx_tele_tac_msg_header_t;

/* OPT TLV list len for inband TAC SW Header */
#define TAC_MSG_EVENT_SW_HDR_OPT_LIST_LEN 3

/* OPT TLV list len for OOB TAC SW Header may be from 1 to 255 entries */
#define TAC_MSG_OOB_SW_HDR_OPT_LIST_LEN_MIN 1
#define TAC_MSG_OOB_SW_HDR_OPT_LIST_LEN_MAX 255

/*
 * TAC SW Header
 * Predefined header values :
 * tac_msg_hdr.eth_type = TAC_SW_HDR_ETH_TYPE (0x8932)
 * tac_msg_hdr.version_msg_type : version 1 , msg_type SW_HDR 1
 * tac_msg_hdr.msg_total_len = 3 , number of TLVs
 */
typedef struct sx_tele_tac_msg_sw_header {
    sx_tele_tac_msg_header_t  tac_msg_hdr;
    sx_tele_tac_msg_opt_tlv_t opt_tlv_list[TAC_MSG_EVENT_SW_HDR_OPT_LIST_LEN];
} __attribute__((__packed__)) sx_tele_tac_msg_sw_header;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t hwd_tele_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t hwd_tele_init(sx_tele_init_params_t *params_p);

sx_status_t hwd_tele_init_spc2(sx_tele_init_params_t *params_p);

sx_status_t hwd_tele_deinit(boolean_t is_forced);

sx_status_t hwd_tele_assign_ops_spc(hwi_tele_ops_t* valid_operations_p);

sx_status_t hwd_tele_assign_ops_spc2(hwi_tele_ops_t* valid_operations_p);

sx_status_t hwd_tele_assign_ops_spc3(hwi_tele_ops_t* valid_operations_p);

sx_status_t hwd_tele_assign_ops_spc4(hwi_tele_ops_t* valid_operations_p);

sx_status_t hwd_tele_histogram_type_validation_spc(const sx_tele_histogram_key_t *key_p);

sx_status_t hwd_tele_histogram_create_spc(const sx_tele_histogram_key_t             key,
                                          const sx_tele_histogram_attributes_data_t data,
                                          const sx_tele_id_t                        tele_id,
                                          uint8_t                                  *num_of_emads);

sx_status_t hwd_tele_histogram_edit_spc(const sx_tele_histogram_key_t             key,
                                        const sx_tele_histogram_attributes_data_t data,
                                        const sx_tele_id_t                        tele_id);

sx_status_t hwd_tele_histogram_destroy_spc(const sx_tele_histogram_key_t key,
                                           const sx_tele_id_t            tele_id);

sx_status_t hwd_tele_histogram_data_get_spc(const sx_tele_histogram_key_t key,
                                            const sx_tele_id_t            tele_id,
                                            const boolean_t               is_clear,
                                            sx_tele_histogram_data_t     *histogram_p);

sx_status_t hwd_tele_histogram_type_validation_spc2(const sx_tele_histogram_key_t *key_p);

sx_status_t hwd_tele_histogram_create_spc2(const sx_tele_histogram_key_t             key,
                                           const sx_tele_histogram_attributes_data_t data,
                                           const sx_tele_id_t                        tele_id,
                                           uint8_t                                  *num_of_emads);

sx_status_t hwd_tele_histogram_edit_spc2(const sx_tele_histogram_key_t             key,
                                         const sx_tele_histogram_attributes_data_t data,
                                         const sx_tele_id_t                        tele_id);

sx_status_t hwd_tele_histogram_destroy_spc2(const sx_tele_histogram_key_t key,
                                            const sx_tele_id_t            tele_id);

sx_status_t hwd_tele_histogram_data_get_spc2(const sx_tele_histogram_key_t key,
                                             const sx_tele_id_t            tele_id,
                                             const boolean_t               is_clear,
                                             sx_tele_histogram_data_t     *histogram_p);

sx_status_t hwd_tele_threshold_default_set(const sx_tele_threshold_key_t key);

sx_status_t hwd_tele_threshold_edit(const sx_port_log_id_t                log_port,
                                    const tele_threshold_direction_type_e direction,
                                    const uint8_t                        *tc_pg_p,
                                    const uint8_t                         tc_pg_cnt,
                                    const sx_tele_threshold_data_t        data);

sx_status_t hwd_tele_threshold_destroy(const sx_port_log_id_t                log_port,
                                       const tele_threshold_direction_type_e direction,
                                       const uint8_t                        *tc_pg_p,
                                       const uint8_t                         tc_pg_cnt);

sx_status_t hwd_tele_threshold_crossed_data_get(sx_tele_threshold_crossed_data_keys_t *data_p,
                                                const uint32_t                         list_cnt);

sx_status_t hwd_tele_threshold_key_validation_spectrum(const sx_tele_threshold_key_t key);

sx_status_t hwd_tele_threshold_key_validation_spectrum2(const sx_tele_threshold_key_t key);

sx_status_t hwd_tele_threshold_data_validation_spectrum(const sx_tele_threshold_key_t  key,
                                                        const sx_tele_threshold_data_t data);

sx_status_t hwd_tele_threshold_data_validation_spectrum2(const sx_tele_threshold_key_t  key,
                                                         const sx_tele_threshold_data_t data);

sx_status_t hwd_tele_threshold_latency_alloc(const uint8_t                  latency_id,
                                             const sx_tele_threshold_data_t data);

sx_status_t hwd_tele_threshold_latency_bind(const uint8_t                 latency_id,
                                            const sx_tele_threshold_key_t key);

sx_status_t hwd_tele_global_configuration_init(const sx_dev_id_t dev_id);

sx_status_t hwd_tele_attr_set_spc2(const sx_tele_attrib_t attr,
                                   sx_port_id_t          *port,
                                   const sx_swid_id_t     swid);

sx_status_t hwd_tele_hash_sig_prof_set(const uint8_t                             prof_idx,
                                       const sx_tele_hash_sig_classifier_attr_t *hash_sig_classifier_attr_p,
                                       const sx_tele_hash_sig_params_t          *hash_params_p,
                                       const sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                       const uint32_t                            hash_field_enable_list_cnt,
                                       const sx_tele_hash_sig_field_t           *hash_field_list_p,
                                       const uint32_t                            hash_field_list_cnt);

/*
 * TAC related function
 */


sx_status_t hwd_tele_tac_attr_set_spc4(const sx_tele_tac_attr_t *tac_attr_p);
sx_status_t hwd_tele_tac_sw_header_set_spc4(const sx_tele_tac_sw_header_info_t *tac_event_sw_header_p);
sx_status_t hwd_tele_tac_set_spc4(sx_access_cmd_t cmd, sx_trap_group_t trap_group, uint8_t hw_span_session_id);
sx_status_t hwd_tele_tac_action_set_spc4(sx_access_cmd_t              cmd,
                                         /*hwd_tele_tac_action_filter_t   *tac_action_filter_p, */
                                         sx_tele_tac_action_filter_t *tac_action_filter_p,
                                         sx_tele_tac_action_info_t   *tac_action_info_p,
                                         sx_tele_tac_action_status_e *tac_action_status_p);
sx_status_t hwd_tele_tac_action_get_spc4(sx_tele_tac_action_status_e *tac_action_status_p);
sx_status_t hwd_tele_tac_statistics_get_spc4(sx_tele_tac_statistics_t *tele_tac_statistics_p,
                                             boolean_t                 is_read_clear);
sx_status_t hwd_tele_counter_histogram_type_validation_spectrum2(const sx_tele_histogram_attributes_data_t* data_p);

sx_status_t hwd_tele_counter_histogram_type_validation_spectrum3(const sx_tele_histogram_attributes_data_t* data_p);

sx_status_t hwd_tele_counter_histogram_type_validation_spectrum4(const sx_tele_histogram_attributes_data_t* data_p);

sx_status_t hwd_tele_port_bw_gauge_set(sx_tele_gauge_config_t *gauge_config_p);

sx_status_t hwd_tele_port_bw_gauge_data_get(sx_tele_gauge_key_t  *gauge_key_p,
                                            sx_tele_gauge_data_t *gauge_data_p);

void uint64_to_bytes_array(uint64_t value, uint8_t* bytes_array_p, uint8_t bytes_array_len);

#endif /* __HWD_TELE_H__ */
