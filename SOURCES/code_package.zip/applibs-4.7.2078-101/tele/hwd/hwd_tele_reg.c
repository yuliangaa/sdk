/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "hwd_tele_reg.h"

#include <sx/utils/sx_utils_status.h>
#include "sx/sdk/sx_status.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/sx_mem.h"
#include <complib/cl_mem.h>
#include "complib/sx_log.h"
#include <sx/sdk/sx_types.h>

#include "sx/sdk/sx_status_convertor.h"
#include "resource_manager/resource_manager_sdk_table.h"
#include "include/resource_manager/resource_manager.h"

#include <ethl2/fdb_common.h>
#include <ethl2/port_db.h>
#include <sx/sxd/sxd_access_register.h>
#include <hwi/tele_impl.h>
#include <hwd/hwd_tele.h>


#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ TELE

/*
 * PBWR size:
 *  1. the size of struct (all fields without dynamic array)
 *  2. the size of dynamic array * the max number of ports
 */
#define PBWR_MAX_SIZE (sizeof(struct ku_pbwr_reg) + sizeof(uint32_t) * MAX_PHYPORT_NUM)


static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

sx_status_t hwd_tele_reg_log_verbosity_level_set(sx_verbosity_level_t verbosity)
{
    SX_LOG_ENTER();

    LOG_VAR_NAME(__MODULE__) = verbosity;

    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}


sx_status_t access_reg_SBHBR(boolean_t                           is_delete,
                             sx_tele_histogram_key_t             key,
                             sx_tele_histogram_attributes_data_t data,
                             sx_tele_id_t                        tele_id)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t           meta[SX_DEVICE_ID_COUNT];
    struct ku_sbhbr_reg      reg[SX_DEVICE_ID_COUNT];
    sxd_status_t             sxd_st = SXD_STATUS_SUCCESS;
    sx_status_t              st = SX_STATUS_SUCCESS;
    sx_tele_histogram_data_t histogram_data;

    st = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(st)) {
        SX_LOG_ERR("Cannot retrieve device list or there is no leaf devices [%s]\n",
                   sx_status_str(st));
        return SX_STATUS_ERROR;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(meta[dev_idx]);
    meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    meta[dev_idx].access_cmd = SXD_ACCESS_CMD_SET;
    meta[dev_idx].swid = 0;

    SX_MEM_CLR(reg[dev_idx]);

    reg[dev_idx].opcode = (is_delete) ? 1 /*unbind*/ : 0 /*bind*/;
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg[dev_idx].local_port, reg[dev_idx].lp_msb,
                                        SX_PORT_PHY_ID_GET(key.key.port_tc.log_port));
    reg[dev_idx].hist_id = tele_id;
    reg[dev_idx].hist_type = key.type;
    reg[dev_idx].hist_parameters = key.key.port_tc.tc;
    reg[dev_idx].hist_min = data.data.queue_depth.min_boundary;
    reg[dev_idx].hist_max = reg[dev_idx].hist_min + (8 * (1 << data.data.queue_depth.bin_size_resolution));
    reg[dev_idx].sample_time = data.data.queue_depth.sample_time_resolution;

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SBHBR_E, reg, meta, dev_info_arr_size, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing SBHBR register (sxd_st=%d)\n", sxd_st);
        st = SX_STATUS_ERROR;
    }

    /* Clear histogram data */
    if (!is_delete) {
        st = access_reg_SBHRR(TRUE, tele_id, &histogram_data);
        if (st != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed accessing SBHRR register (st=%d)\n", st);
        }
    }

    return st;
}

sx_status_t access_reg_SBHRR(boolean_t is_clear, sx_tele_id_t tele_id, sx_tele_histogram_data_t *histogram_p)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t      meta[SX_DEVICE_ID_COUNT];
    struct ku_sbhrr_reg reg[SX_DEVICE_ID_COUNT];
    sxd_status_t        sxd_st = SXD_STATUS_SUCCESS;
    sx_status_t         st = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(st = utils_check_pointer(histogram_p, "histogram_data"))) {
        return SX_STATUS_ERROR;
    }

    st = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(st)) {
        SX_LOG_ERR("Cannot retrieve device list or there is no leaf devices [%s]\n",
                   sx_status_str(st));
        return SX_STATUS_ERROR;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(meta[dev_idx]);
    meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    meta[dev_idx].access_cmd = SXD_ACCESS_CMD_GET;
    meta[dev_idx].swid = 0;

    SX_MEM_CLR(reg[dev_idx]);
    reg[dev_idx].clr = is_clear;
    reg[dev_idx].hist_id = tele_id;

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SBHRR_E, reg, meta, dev_info_arr_size, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing SBHRR register (sxd_st=%d)\n", sxd_st);
        st = SX_STATUS_ERROR;
    }

    /* assign histogram only in case any leaf device exists */
    if (!SX_FDB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        SX_MEM_CPY(histogram_p->bins, reg[0].bin);
        histogram_p->bins_cnt = SX_TELE_HIST_MAX_BINS;
    }

    return st;
}

sx_status_t access_reg_SBHBR_v2(sx_tele_histogram_key_t             key,
                                sx_tele_histogram_attributes_data_t data,
                                boolean_t                           is_enable)
{
    sx_status_t            st = SX_STATUS_SUCCESS;
    sxd_status_t           sxd_st = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t         meta;
    struct ku_sbhbr_v2_reg reg;

    SX_MEM_CLR(reg);
    SX_MEM_CLR(meta);

    meta.dev_id = SXD_DEV_ID_MIN;
    meta.access_cmd = SXD_ACCESS_CMD_SET;
    meta.swid = 0;
    reg.hist_type = SX_TELE_HISTOGRAM_TYPE_ID_PREFIX;

    switch (key.type) {
    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E:
        reg.hist_type += SX_TELE_HISTOGRAM_TYPE_ID_QUEUE_DEPTH;
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb, SX_PORT_PHY_ID_GET(key.key.port_tc.log_port));
        reg.pg_buff = key.key.port_tc.tc;
        reg.dir = SX_TELE_HISTOGRAM_DIRECTION_EGRESS;
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E:
        reg.hist_type += SX_TELE_HISTOGRAM_TYPE_ID_QUEUE_DEPTH;
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb, SX_PORT_PHY_ID_GET(key.key.port_pg.log_port));
        reg.pg_buff = key.key.port_pg.pg;
        reg.dir = SX_TELE_HISTOGRAM_DIRECTION_INGRESS;
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E:
        reg.hist_type += SX_TELE_HISTOGRAM_TYPE_ID_LATENCY;
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb, SX_PORT_PHY_ID_GET(key.key.port_tc.log_port));
        reg.pg_buff = key.key.port_tc.tc;
        reg.dir = SX_TELE_HISTOGRAM_DIRECTION_EGRESS;
        break;

    default:
        st = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid histogram type [%s].\n", sx_tele_histogram_type_str(key.type));
        goto out;
    }

    reg.en = is_enable;
    reg.hist_min_value = data.data.queue_depth.min_boundary;

    if (data.data.queue_depth.mode == SX_TELE_HISTOGRAM_MODE_LINEAR_E) {
        reg.hist_max_value = reg.hist_min_value + 8 * (1 << data.data.queue_depth.bin_size_resolution);
    } else { /* (data.data.queue_depth.mode == SX_TELE_HISTOGRAM_MODE_EXPONENT_E) */
        reg.hist_max_value = reg.hist_min_value + 255 * (1 << data.data.queue_depth.bin_size_resolution);
    }

    reg.mode = data.data.queue_depth.mode;
    reg.sample_time = data.data.queue_depth.sample_time_resolution;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SBHBR_V2_E, &reg, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing SBHBR_V2 register (sxd_st=%d)\n", sxd_st);
        st = SX_STATUS_ERROR;
    }

out:
    return st;
}

sx_status_t access_reg_PHBR(const sx_tele_histogram_key_t *key_p, const sx_tele_histogram_attributes_data_t *data_p)
{
    sx_status_t        st = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_st = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     meta;
    struct ku_phbr_reg reg;

    if (utils_check_pointer(key_p, "key_p")) {
        st = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(data_p, "data_p")) {
        st = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(reg);
    SX_MEM_CLR(meta);

    meta.dev_id = SXD_DEV_ID_MIN;
    meta.access_cmd = SXD_ACCESS_CMD_SET;
    meta.swid = 0;

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb,
                                        SX_PORT_PHY_ID_GET(key_p->key.port_counter.log_port));
    reg.hist_id = key_p->key.port_counter.histogram_id;
    reg.hist_type = data_p->data.port_counter.port_counter_type;
    reg.mode = data_p->data.port_counter.mode ==
               SX_TELE_HISTOGRAM_MODE_LINEAR_E ? SXD_PHBR_MODE_LINEAR_E : SXD_PHBR_MODE_EXPONENTIAL_E;
    reg.first_bin_thr = data_p->data.port_counter.min_boundary;
    reg.bin_size = data_p->data.port_counter.bin_size_resolution;
    reg.sample_time = data_p->data.port_counter.sample_time_resolution;

    switch (data_p->data.port_counter.control) {
    case SX_TELE_HISTOGRAM_PORT_COUNTER_CTL_START_REP_E:
        reg.hist_repeat_num = data_p->data.port_counter.repetition.number_of_repetitions;
        break;

    case SX_TELE_HISTOGRAM_PORT_COUNTER_CTL_START_E:
        reg.hist_repeat_num = 0xffffff;
        break;

    case SX_TELE_HISTOGRAM_PORT_COUNTER_CTL_STOP_E:
        reg.hist_repeat_num = 0;
        break;

    default:
        st = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid histogram type [%s].\n", sx_tele_histogram_type_str(key_p->type));
        goto out;
    }

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PHBR_E, &reg, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing PHBR register (sxd_st=%d)\n", sxd_st);
        st = SX_STATUS_ERROR;
    }


out:
    return st;
}

sx_status_t access_reg_PHRR(const sx_tele_histogram_key_t *key_p,
                            boolean_t                      is_clear,
                            sx_tele_histogram_data_t      *histogram_p)
{
    sx_status_t        st = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_st = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     meta;
    struct ku_phrr_reg reg;
    uint32_t           i = 0;

    if (utils_check_pointer(key_p, "key_p")) {
        st = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(reg);
    SX_MEM_CLR(meta);

    meta.dev_id = SXD_DEV_ID_MIN;
    meta.access_cmd = SXD_ACCESS_CMD_GET;
    meta.swid = 0;

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb,
                                        SX_PORT_PHY_ID_GET(key_p->key.port_counter.log_port));
    reg.clr = is_clear;
    reg.hist_id = key_p->key.port_counter.histogram_id;


    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PHRR_E, &reg, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing PHRR register (sxd_st=%d)\n", sxd_st);
        st = SX_STATUS_ERROR;
        goto out;
    }

    if (histogram_p == NULL) {
        if (is_clear == TRUE) {
            st = SX_STATUS_SUCCESS;
        }
        goto out;
    }

    for (i = 0; i < SXD_PHRR_BIN_NUM; i++) {
        histogram_p->bins[i] = reg.bin[i];
    }

    histogram_p->bins_cnt = SX_TELE_HIST_MAX_BINS;
    histogram_p->max_sampled = 0;
    histogram_p->watermark_valid = 1;
    histogram_p->max_watermark = reg.max_watermark;
    histogram_p->min_watermark = reg.min_watermark;


out:
    return st;


    return 0;
}

sx_status_t access_reg_SBHRR_v2(sx_tele_histogram_key_t key, boolean_t is_clear, sx_tele_histogram_data_t *histogram_p)
{
    sx_status_t            st = SX_STATUS_SUCCESS;
    sxd_status_t           sxd_st = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t         meta;
    struct ku_sbhrr_v2_reg reg;
    uint32_t               i = 0;

    SX_MEM_CLR(reg);
    SX_MEM_CLR(meta);

    meta.dev_id = SXD_DEV_ID_MIN;
    meta.access_cmd = SXD_ACCESS_CMD_GET;
    meta.swid = 0;
    reg.hist_type = SX_TELE_HISTOGRAM_TYPE_ID_PREFIX;

    switch (key.type) {
    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E:
        reg.hist_type += SX_TELE_HISTOGRAM_TYPE_ID_QUEUE_DEPTH;
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb, SX_PORT_PHY_ID_GET(key.key.port_tc.log_port));
        reg.pg_buff = key.key.port_tc.tc;
        reg.dir = SX_TELE_HISTOGRAM_DIRECTION_EGRESS;
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E:
        reg.hist_type += SX_TELE_HISTOGRAM_TYPE_ID_QUEUE_DEPTH;
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb, SX_PORT_PHY_ID_GET(key.key.port_pg.log_port));
        reg.pg_buff = key.key.port_pg.pg;
        reg.dir = SX_TELE_HISTOGRAM_DIRECTION_INGRESS;
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E:
        reg.hist_type += SX_TELE_HISTOGRAM_TYPE_ID_LATENCY;
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb, SX_PORT_PHY_ID_GET(key.key.port_tc.log_port));
        reg.pg_buff = key.key.port_tc.tc;
        reg.dir = SX_TELE_HISTOGRAM_DIRECTION_EGRESS;
        break;

    default:
        st = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid histogram type [%s].\n", sx_tele_histogram_type_str(key.type));
        goto out;
    }

    reg.clr = is_clear;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SBHRR_V2_E, &reg, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing SBHRR_V2 register (sxd_st=%d)\n", sxd_st);
        st = SX_STATUS_ERROR;
        goto out;
    }

    if (histogram_p == NULL) {
        if (is_clear == TRUE) {
            st = SX_STATUS_SUCCESS;
        }
        goto out;
    }

    for (i = 0; i < SXD_SBHRR_V2_BIN_NUM; i++) {
        histogram_p->bins[i] = reg.bin[i];
    }

    histogram_p->bins_cnt = SX_TELE_HIST_MAX_BINS;

    if (key.type == SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E) {
        histogram_p->max_sampled = ((uint64_t)reg.max_sampled_high << 32) | reg.max_sampled_low;
    } else {
        histogram_p->max_sampled = 0;
    }
    histogram_p->watermark_valid = 0;

out:
    return st;
}

sx_status_t access_reg_SBCTC(sxd_access_cmd_t          cmd,
                             sx_port_log_id_t          log_port,
                             uint8_t                   direction,
                             const uint8_t            *tc_pg_p,
                             uint32_t                  tc_pg_cnt,
                             sx_tele_threshold_data_t *data_p)
{
    sxd_reg_meta_t      meta;
    struct ku_sbctc_reg reg;
    sxd_status_t        sxd_st = SXD_STATUS_SUCCESS;
    sx_status_t         st = SX_STATUS_SUCCESS;
    uint64_t            tc_pg_bitmap = 0;
    uint32_t            i = 0;

    SX_MEM_CLR(reg);
    SX_MEM_CLR(meta);

    /* Parameter validation */
    if ((cmd != SXD_ACCESS_CMD_SET) && (cmd != SXD_ACCESS_CMD_GET)) {
        st = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Access register SBCTC: wrong value for cmd parameter "
                   "[%d, %s], only SET and GET commands are supported.\n",
                   cmd, SXD_ACCESS_CMD_STR(cmd));
        goto out;
    }
    if (tc_pg_cnt > 0) {
        if ((tc_pg_p == NULL) && (cmd == SXD_ACCESS_CMD_SET)) {
            st = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Access register SBCTC: tc_pg_p can not be NULL when access "
                       "command is SET.\n");
            goto out;
        }
        if (data_p == NULL) {
            st = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Access register SBCTC: data_p can not be NULL.\n");
            goto out;
        }
    }

    /* Register access */
    if (cmd == SXD_ACCESS_CMD_SET) {
        /* convert TC/PG list into bitmap */
        for (i = 0; i < tc_pg_cnt; i++) {
            if (tc_pg_p[i] > sizeof(tc_pg_bitmap) * 8) {
                st = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Access register SBCTC: invalid TC/PG %d\n", tc_pg_p[i]);
                goto out;
            } else {
                tc_pg_bitmap |= (((uint64_t)1) << tc_pg_p[i]);
            }
        }
        reg.en_config = 1;
        reg.event = tc_pg_cnt > 0 ? 1 : 0;
        reg.tclass_en = tc_pg_bitmap;
        if (tc_pg_bitmap > 0) {
            if (data_p->threshold_data_type == SX_TELE_THRESHOLD_DATA_TYPE_INVALID_E) {
                reg.thr_max = data_p->data.port_tc_threshold;
                reg.thr_min = 0;
                reg.mode = 0;
            } else if (data_p->threshold_data_type == SX_TELE_THRESHOLD_DATA_TYPE_STATIC_E) {
                reg.thr_max = data_p->threshold_data.threshold_high;
                reg.thr_min = data_p->threshold_data.threshold_low;
                reg.mode = 0;
            } else if (data_p->threshold_data_type == SX_TELE_THRESHOLD_DATA_TYPE_PERCENTAGE_E) {
                reg.thr_max = data_p->threshold_data.threshold_high;
                reg.thr_min = data_p->threshold_data.threshold_low;
                reg.mode = 1;
            } else {
                st = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Access register SBCTC: threshold_data_type invalid.\n");
                goto out;
            }
        } else {
            reg.thr_max = TELE_THRESHOLD_STATIC_MAX_VALUE;
            reg.thr_min = 0;
            reg.mode = 0;
        }
    }

    meta.dev_id = SX_PORT_DEV_ID_GET(log_port);
    meta.access_cmd = cmd;
    meta.swid = 0;
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb, SX_PORT_PHY_ID_GET(log_port));
    reg.dir_ing = direction;
    reg.is_port_profile = (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_PROFILE) ? TRUE : FALSE;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SBCTC_E, &reg, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing SBCTC register (sxd_st=%d)\n", sxd_st);
        st = SXD_STATUS_TO_SX_STATUS(sxd_st);
    }

    if (cmd == SXD_ACCESS_CMD_GET) {
        data_p->threshold_data.threshold_high = reg.thr_max;
        data_p->threshold_data.threshold_low = reg.thr_min;
        data_p->threshold_data_type =
            (reg.mode == 0) ? SX_TELE_THRESHOLD_DATA_TYPE_STATIC_E : SX_TELE_THRESHOLD_DATA_TYPE_PERCENTAGE_E;
    }

out:
    return st;
}

sx_status_t access_reg_SBCTR(sx_port_log_id_t log_port,
                             uint8_t          direction,
                             uint8_t          ievent,
                             uint64_t        *crossed_data_p,
                             uint8_t         *entity,
                             uint8_t         *fp)
{
    sxd_reg_meta_t      meta;
    struct ku_sbctr_reg reg;
    sxd_status_t        sxd_st = SXD_STATUS_SUCCESS;
    sx_status_t         st = SX_STATUS_SUCCESS;

    SX_MEM_CLR(reg);
    SX_MEM_CLR(meta);

    meta.dev_id = SX_PORT_DEV_ID_GET(log_port);
    meta.access_cmd = SXD_ACCESS_CMD_GET;
    meta.swid = 0;

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb, SX_PORT_PHY_ID_GET(log_port));
    reg.ievent = ievent;
    reg.dir_ing = direction;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SBCTR_E, &reg, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing SBCTR register (sxd_st=%d)\n", sxd_st);
        st = SXD_STATUS_TO_SX_STATUS(sxd_st);
    } else {
        *crossed_data_p = ((uint64_t)reg.tclass_vector_high << 32) + reg.tclass_vector_low;
        *entity = reg.entity;
        *fp = reg.fp;
    }

    return st;
}

sx_status_t access_reg_SBGCR(sx_tele_threshold_entity_e tele_entity, sx_tele_threshold_congestion_fp_e cong_fp)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t      meta[SX_DEVICE_ID_COUNT];
    struct ku_sbgcr_reg reg[SX_DEVICE_ID_COUNT];
    sxd_status_t        sxd_st = SXD_STATUS_SUCCESS;
    sx_status_t         st = SX_STATUS_SUCCESS;

    st = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(st)) {
        SX_LOG_ERR("Cannot retrieve device list or there is no leaf devices [%s]\n",
                   sx_status_str(st));
        return SX_STATUS_ERROR;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(meta[dev_idx]);
    meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    meta[dev_idx].access_cmd = SXD_ACCESS_CMD_SET;
    meta[dev_idx].swid = 0;

    SX_MEM_CLR(reg[dev_idx]);
    reg[dev_idx].cong_fp = cong_fp;
    reg[dev_idx].tele_entity = tele_entity;
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SBGCR_E, reg, meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing SBGCR register (sxd_st=%d)\n", sxd_st);
        st = SXD_STATUS_TO_SX_STATUS(sxd_st);
    }
    return st;
}

sx_status_t access_reg_CHLTR(uint8_t threshold_id, sx_tele_threshold_t threshold)
{
    sxd_reg_meta_t      meta;
    struct ku_chltr_reg reg;
    sxd_status_t        sxd_st = SXD_STATUS_SUCCESS;
    sx_status_t         st = SX_STATUS_SUCCESS;

    memset(&reg, 0, sizeof(reg));
    memset(&meta, 0, sizeof(meta));

    meta.dev_id = 1;
    meta.access_cmd = SXD_ACCESS_CMD_SET;
    meta.swid = 0;

    reg.high_latency_thr = threshold;
    reg.hlt_table_index = threshold_id;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_CHLTR_E, &reg, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("failed accessing CHLTR register (sxd_st=%d)\n", sxd_st);
        st = SXD_STATUS_TO_SX_STATUS(sxd_st);
    }
    return st;
}

sx_status_t access_reg_CHLTM(uint8_t threshold_id, sx_port_log_id_t log_port, sx_cos_traffic_class_t tc)
{
    sxd_reg_meta_t      meta;
    struct ku_chltm_reg reg;
    sxd_status_t        sxd_st = SXD_STATUS_SUCCESS;
    sx_status_t         st = SX_STATUS_SUCCESS;

    memset(&reg, 0, sizeof(reg));
    memset(&meta, 0, sizeof(meta));

    meta.dev_id = SX_PORT_DEV_ID_GET(log_port);
    meta.access_cmd = SXD_ACCESS_CMD_SET;
    meta.swid = 0;

    reg.hlt_table_pointer = threshold_id;
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port,
                                        reg.lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));
    reg.traffic_class = tc;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_CHLTM_E, &reg, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("failed accessing CHLTM register (sxd_st=%d)\n", sxd_st);
        st = SXD_STATUS_TO_SX_STATUS(sxd_st);
    }
    return st;
}

sx_status_t access_reg_CHLMM(uint8_t threshold_id, sx_cos_priority_t sp)
{
    sxd_reg_meta_t      meta;
    struct ku_chlmm_reg reg;
    sxd_status_t        sxd_st = SXD_STATUS_SUCCESS;
    sx_status_t         st = SX_STATUS_SUCCESS;

    memset(&reg, 0, sizeof(reg));
    memset(&meta, 0, sizeof(meta));

    meta.dev_id = 1;
    meta.access_cmd = SXD_ACCESS_CMD_SET;
    meta.swid = 0;

    reg.hlt_table_pointer = threshold_id;
    reg.switch_prio = sp;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_CHLMM_E, &reg, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("failed accessing CHLMM register (sxd_st=%d)\n", sxd_st);
        st = SXD_STATUS_TO_SX_STATUS(sxd_st);
    }
    return st;
}

sx_status_t access_reg_MOGCR(const sx_dev_id_t dev_id, const mogcr_set_config_t *set_config)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_mogcr_reg data;
    sxd_reg_meta_t      meta;
    sxd_status_t        sxd_st = SXD_STATUS_SUCCESS;

    SX_MEM_CLR(data);
    SX_MEM_CLR(meta);

    meta.dev_id = dev_id;
    meta.access_cmd = SXD_ACCESS_CMD_GET;

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOGCR_E, &data, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to read global monitoring configuration register (err=%u)\n", sxd_st);
        err = SXD_STATUS_TO_SX_STATUS(sxd_st);
        goto out;
    }

    meta.access_cmd = SXD_ACCESS_CMD_SET;

    if (set_config->config_bitmask & MOGCR_SET_CONFIG_F_POLICER_ID_BASE) {
        data.mirroring_pid_base = set_config->pid_base;
    }

    if (set_config->config_bitmask & MOGCR_SET_CONFIG_F_TOC_FMT) {
        data.toc_fmt = set_config->toc_fmt;
    }

    sxd_st = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOGCR_E, &data, &meta, 1, NULL, NULL);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set monitor global configuration (err=%u)\n", sxd_st);
        err = SXD_STATUS_TO_SX_STATUS(sxd_st);
        goto out;
    }

out:
    return err;
}

sx_status_t access_reg_PCMR(sx_port_log_id_t log_port, sx_ts_over_crc_ingress_mode_e ts_over_crc_ingress_mode)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    struct ku_pcmr_reg reg;
    sxd_reg_meta_t     meta;
    sxd_status_t       sxd_rc = SXD_STATUS_SUCCESS;

    SX_MEM_CLR(reg);
    SX_MEM_CLR(meta);

    meta.dev_id = 1;
    meta.access_cmd = SXD_ACCESS_CMD_GET;

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port, reg.lp_msb, SX_PORT_PHY_ID_GET(log_port));

    sxd_rc = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PCMR_E, &reg, &meta, 1, NULL, NULL);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to read port ethernet check register (rc=%u)\n", sxd_rc);
        rc = SXD_STATUS_TO_SX_STATUS(sxd_rc);
        goto out;
    }

    if (reg.rx_ts_over_crc != ts_over_crc_ingress_mode) {
        reg.rx_ts_over_crc = ts_over_crc_ingress_mode;
        if (!reg.rx_ts_over_crc_cap) {
            SX_LOG_ERR("Port [0x%08X] timestamp over CRC capability not supported\n", log_port);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        meta.access_cmd = SXD_ACCESS_CMD_SET;
        sxd_rc = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PCMR_E, &reg, &meta, 1, NULL, NULL);
        if (sxd_rc != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to set port ethernet check register (rc=%u)\n", sxd_rc);
            rc = SXD_STATUS_TO_SX_STATUS(sxd_rc);
            goto out;
        }
        rc = port_db_pcmr_config_set(SX_PORT_PHY_ID_GET(log_port), &reg);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set timestamp over CRC mode in port db (rc=%u)\n", rc);
            goto out;
        }
    }

out:
    return rc;
}

sx_status_t access_reg_PBWC(sx_tele_gauge_config_t *gauge_config_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     pbwc_reg_meta;
    struct ku_pbwc_reg pbwc_reg_data;


    SX_LOG_ENTER();

    if (utils_check_pointer(gauge_config_p, "gauge_config_p")) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }


    SX_MEM_CLR(pbwc_reg_meta);
    SX_MEM_CLR(pbwc_reg_data);


    pbwc_reg_meta.dev_id = SXD_DEV_ID_MIN;
    pbwc_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pbwc_reg_meta.swid = 0;

    pbwc_reg_data.alpha_factor = gauge_config_p->alpha_factor;
    pbwc_reg_data.log_time_interval = gauge_config_p->log_time_interval;


    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PBWC_E, &pbwc_reg_data, &pbwc_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing PBWC register (sxd_st=%d)\n", sxd_status);
        rc = SX_STATUS_ERROR;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t access_reg_PBWR(sx_tele_gauge_key_t *gauge_key_p, sx_tele_gauge_data_t *gauge_data_p)
{
    sx_status_t         rc = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t      pbwr_reg_meta;
    sx_port_log_id_t    local_port;
    sx_port_log_id_t    max_local_port = 0;
    uint32_t            index = 0;
    uint32_t            bit = 0;
    uint32_t            i = 0;
    uint8_t             reg_data[PBWR_MAX_SIZE];
    struct ku_pbwr_reg *pbwr_reg_data_p = (struct ku_pbwr_reg *)reg_data;

    SX_LOG_ENTER();

    if (utils_check_pointer(gauge_key_p, "gauge_key_p")) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(gauge_data_p, "gauge_data_p")) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }


    SX_MEM_CLR(pbwr_reg_meta);

    /*
     * In PBWR, only control fields (like "local port bitmap") that
     * select what and how many ports to query are cleared.
     * While the dynamic array (data fields) is not cleared; only
     * relevant entries will be cleared during filling the register query.
     */
    SX_MEM_CLR_P(pbwr_reg_data_p);

    pbwr_reg_meta.dev_id = SXD_DEV_ID_MIN;
    pbwr_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    pbwr_reg_meta.swid = 0;

    for (i = 0; i < gauge_key_p->port_cnt; i++) {
        local_port = SX_PORT_PHY_ID_GET(gauge_key_p->port_list[i]);
        index = SXD_PBWR_LOCAL_PORT_BITMAP_NUM - (local_port / SXD_PBWR_LOCAL_PORT_BITMAP_NUM) - 1;
        bit = 1 << (local_port % SXD_PBWR_LOCAL_PORT_BITMAP_NUM);
        pbwr_reg_data_p->local_port_bitmap[index] |= bit;
        pbwr_reg_data_p->bw_record[local_port] = 0;
        if (local_port > max_local_port) {
            max_local_port = local_port;
        }
    }

    /*get RX BW */
    pbwr_reg_data_p->dir = SXD_PBWR_DIR_INGRESS_E;
    pbwr_reg_data_p->num_rec = max_local_port + 1;
    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PBWR_E, pbwr_reg_data_p, &pbwr_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing PBWR register to get RX BW (sxd_st=%d)\n", sxd_status);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    gauge_data_p->port_cnt = gauge_key_p->port_cnt;
    for (i = 0; i < gauge_key_p->port_cnt; i++) {
        gauge_data_p->port_data_list[i].port_id = gauge_key_p->port_list[i];
        local_port = SX_PORT_PHY_ID_GET(gauge_key_p->port_list[i]);
        gauge_data_p->port_data_list[i].rx_bw = pbwr_reg_data_p->bw_record[local_port];
    }

    /*get TX BW */
    pbwr_reg_data_p->dir = SXD_PBWR_DIR_EGRESS_E;
    pbwr_reg_data_p->num_rec = max_local_port + 1;
    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PBWR_E, pbwr_reg_data_p, &pbwr_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed accessing PBWR register to get TX BW (sxd_st=%d)\n", sxd_status);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    for (i = 0; i < gauge_key_p->port_cnt; i++) {
        local_port = SX_PORT_PHY_ID_GET(gauge_key_p->port_list[i]);
        gauge_data_p->port_data_list[i].tx_bw = pbwr_reg_data_p->bw_record[local_port];
    }


out:
    SX_LOG_EXIT();
    return rc;
}
