/*
 * SPDX-FileCopyrightText: Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#include <tele/hwi/tele_db.h>
#include <tele/hwi/tele_impl.h>
#include <tele/hwd/hwd_tele.h>

#include "ethl2/brg.h"
#include "ethl2/port.h"
#include "issu/issu.h"
#include "ethl2/port_profile.h"
#include <ethl2/port_db.h>
#include <utils/utils.h>
#include <utils/port_type_validate.h>
#include <sx/utils/debug_cmd.h>
#include <sx/sdk/sx_types.h>
#include <sx_api/sx_api_internal.h>
#include <ethl2/lag.h>
#include <ethl2/brg.h>
#include <complib/cl_byteswap.h>
#include "complib/cl_fcntl.h"


#undef  __MODULE__
#define __MODULE__ TELE

/************************************************
 *  Global variables
 ***********************************************/
extern rm_resources_t   rm_resource_global;
extern sx_brg_context_t brg_context;

/************************************************
 *  Defines
 ***********************************************/

#define TELE_IMPL_MAX_PG_TC_COUNT                        \
    (rm_resource_global.cos_port_ets_traffic_class_max + \
     rm_resource_global.shared_buff_num_port_ingress_buff)

#define TELE_TRESHOLD_LATENCY_DISABLE_THRESHOLD (rm_resource_global.tele_threshold_latency_thr_max)
#define TELE_TRESHOLD_LATENCY_DISABLE_ID        (rm_resource_global.tele_threshold_latency_table_size)

typedef struct {
    sx_span_session_id_t     span_session_id;
    sx_span_session_id_int_t old_index;
    sx_span_session_id_int_t new_index;
} span_relocate_data_t;


/*
 * TAC OOB related defines
 */
typedef struct tlv_oob_remote_cmd_t {
    uint16_t remote_cmd;
} tlv_oob_remote_cmd_t;

typedef struct oob_port_label_mapping {
    uint16_t local_port;
    uint16_t port_label;
} oob_port_label_mapping_t;

/*
 * Unit of 4B not including the 1st DWORD of this header
 * For Msg Type = 1 this is a fixed size 3
 * For Msg Type = 2 this can be 1-255
 */
#define TELE_TAC_MSG_DATA_MAX_LEN_DWORD 255
#define TELE_TAC_MSG_DATA_MAX_LEN_BYTES (TELE_TAC_MSG_DATA_MAX_LEN_DWORD * sizeof(uint32_t))

#define TELE_TLV_DATA_MAX_LEN_BYTES 255         /* 8 bit MAX */


/* in case we will have only 1 TLV , them the space for port label mapping will be max data length minus 2 for TLV type and length:
 * TELE_TLV_DATA_MAX_LEN_BYTES - 2
 * */
#define TELE_TLV_DATA_MAX_PORT_LABEL_MAPPING_COUNT (TELE_TLV_DATA_MAX_LEN_BYTES / sizeof(oob_port_label_mapping_t))

typedef struct tlv_oob_port_label_mapping {
    uint16_t                 reserved;
    oob_port_label_mapping_t port_label_mapping[TELE_TLV_DATA_MAX_PORT_LABEL_MAPPING_COUNT];
} tlv_oob_port_label_mapping_t;

typedef struct tlv_oob_user_defined {
    uint8_t data[TELE_TLV_DATA_MAX_LEN_BYTES];
} tlv_oob_user_defined_t;

typedef struct __attribute__((packed)) tele_tlv_info {
    uint8_t type;
    uint8_t len;
    uint8_t data[TELE_TLV_DATA_MAX_LEN_BYTES];
} tele_tlv_info_t;

typedef struct __attribute__((packed)) tele_tac_oob_packet_format {
    sx_tele_tac_msg_header_t tac_msg_header;
    uint8_t                  opt_tlv_data[TELE_TAC_MSG_DATA_MAX_LEN_BYTES];             /* TAC OOB msg can have multiple OPT_TLVs */
} tele_tac_oob_packet_format_t;


/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t             g_is_tele_initialized = FALSE;
static boolean_t             g_is_tele_terminated = FALSE;
static boolean_t             g_is_advisor_registered = FALSE;
static boolean_t             g_is_port_profile_apply_advisor_registered = FALSE;
static boolean_t             g_is_port_profile_delete_advisor_registered = FALSE;
static hwi_tele_ops_t        g_ops;
static boolean_t             g_ops_init = FALSE;
static sx_tele_init_params_t g_tele_init_params;
static boolean_t             g_tele_pre_init = FALSE;
static sx_tele_attrib_t      g_tele_attrib = {.internal_ts_enable = TRUE,
                                              .tac_attr_valid = FALSE};
static span_client_handle_t  g_tac_span_user_handle = NULL;
/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __histogram_key_port_get(IN const sx_tele_histogram_key_t *key,
                                            OUT sx_port_log_id_t             *key_port);
static sx_status_t __tele_lag_global_update(IN sx_port_id_t          lag_port_log_id,
                                            IN lag_sink_event_type_e event_type,
                                            IN void                 *context_p);
static sx_status_t __tele_lag_port_update(IN sx_port_id_t          lag_port_log_id,
                                          IN lag_sink_event_type_e event_type,
                                          IN sx_port_id_t          port_log_id,
                                          IN void                 *context_p);
static sx_status_t __congestion_threshold_set(const sx_access_cmd_t          cmd,
                                              const sx_tele_threshold_key_t  key,
                                              const sx_tele_threshold_data_t data);
static sx_status_t __align_thresholds(const sx_port_log_id_t lag_port,
                                      const sx_port_log_id_t network_port);
static sx_status_t __remove_thresholds(const sx_port_log_id_t port);
static sx_status_t __align_latency_thresholds(const sx_port_log_id_t lag_port,
                                              const sx_port_log_id_t network_port);
static sx_status_t __remove_latency_thresholds(const sx_port_log_id_t port);
static sx_status_t __convert_adjusted_key(sx_tele_threshold_key_t  in_key,
                                          sx_tele_threshold_key_t *out_key_p);
static sx_status_t __congestion_thresholds_port_add_to_lag_validation(const sx_port_log_id_t lag_port_log_id,
                                                                      const sx_port_log_id_t port_log_id);
static sx_status_t __latency_thresholds_port_add_to_lag_validation(const sx_port_log_id_t lag_port_log_id,
                                                                   const sx_port_log_id_t port_log_id);
static sx_status_t __sdk_tele_impl_threshold_congestion_issu_set();
static sx_status_t __sdk_tele_impl_threshold_latency_issu_set();
static sx_status_t __congestion_threshold_issu_set(const sx_port_threshold_type_e port_type,
                                                   const sx_port_log_id_t        *port_list_p,
                                                   const uint32_t                 port_cnt,
                                                   const sx_tele_threshold_key_t *port_key_list_p,
                                                   const uint8_t                  key_cnt,
                                                   uint8_t                       *tc_pg_list_p);
static sx_status_t __tele_impl_hash_sig_params_set(const sx_tele_hash_sig_prof_idx_int_t     hash_sig_prof_idx,
                                                   const sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_class_p,
                                                   const sx_tele_hash_sig_params_t          *hash_params_p,
                                                   const sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                                   const uint32_t                            hash_field_enable_list_cnt,
                                                   const sx_tele_hash_sig_field_t           *hash_field_list_p,
                                                   const uint32_t                            hash_field_list_cnt);
static sx_status_t __tele_impl_hash_sig_init(void);
static sx_status_t __tele_impl_tac_attr_set(sx_tele_tac_attr_t *tac_attr_p);
static sx_status_t __tele_impl_tac_sw_header_set(sx_tele_tac_sw_header_info_t *tac_sw_header_info_p);
static boolean_t __is_tac_attr_changed(sx_tele_attrib_t *attr_p);
static sx_status_t tele_impl_tac_sw_header_set(sx_tele_tac_attr_t *tac_attr_p);
static sx_status_t __tele_impl_tac_statistics_get(sx_tele_tac_statistics_t *tele_tac_statistics_p,
                                                  boolean_t                 is_read_clear);

static sx_status_t __tele_impl_tac_init(void);
static sx_status_t __tele_impl_tac_deinit(boolean_t is_forced);
static sx_status_t __tele_impl_update_refcnt(sx_access_cmd_t    cmd,
                                             sx_trap_group_t    trap_group,
                                             sx_tele_tac_cfg_t *tac_cfg_p);

static sx_status_t __tele_port_profile_apply_cb(adviser_event_e event_type, void *param_p);
static sx_status_t __tele_port_profile_delete_cb(adviser_event_e event_type, void *param);
static sx_status_t __tele_impl_int_span_session_id_get(sx_span_session_id_t tac_to_net_span_id,
                                                       uint8_t             *hw_span_session_id_p);
static sx_status_t __tele_impl_align_packet_data_to_4_bytes(tele_tac_oob_packet_format_t *tac_oob_packet_p,
                                                            uint16_t                      packet_data_len,
                                                            uint16_t                     *aligned_packet_data_len_p);
static sx_status_t __tele_impl_fill_tac_oob_msg_header(sx_tele_tac_msg_header_t *tac_msg_hdr_p,
                                                       uint16_t                  total_tlvs_len);


/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sdk_tele_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    sdk_tele_db_log_verbosity_level_set(verbosity_level);
    hwd_tele_log_verbosity_level_set(verbosity_level);
    return status;
}

static void __debug_cmd_threshold_dump_cb(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params = {
        .stream = stream,
        .thread_idx = 0,
        .thread_num = 1,
        .hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    };

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    SX_MEM_CLR(printer_params);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI:  failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    sdk_tele_db_threshold_debug_dump(&dbg_dump_params);

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}

static void __debug_cmd_last_congestion_threshold_dump_cb(FILE       *stream,
                                                          int         argc,
                                                          const char *argv[],
                                                          void       *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params = {
        .stream = stream,
        .thread_idx = 0,
        .thread_num = 1,
        .hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    };

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    SX_MEM_CLR(printer_params);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI:  failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    sdk_tele_db_last_congestion_threshold_debug_dump(&dbg_dump_params);

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}

static void __debug_cmd_threshold_latency_key_dump_cb(FILE *stream, int argc, const char *argv[],
                                                      void *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params = {
        .stream = stream,
        .thread_idx = 0,
        .thread_num = 1,
        .hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    };

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    SX_MEM_CLR(printer_params);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI:  failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    sdk_tele_db_threshold_latency_key_debug_dump(&dbg_dump_params);

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}

static void __debug_cmd_threshold_latency_data_dump_cb(FILE       *stream,
                                                       int         argc,
                                                       const char *argv[],
                                                       void       *handler_context)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    dbg_utils_pprinter_params_t printer_params;
    FILE                       *key_fp = NULL;
    dbg_dump_params_t           dbg_dump_params = {
        .stream = stream,
        .thread_idx = 0,
        .thread_num = 1,
        .hw_dump_method = SX_DBG_HW_DUMP_METHOD_BASIC_E
    };

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    UNUSED_PARAM(handler_context);

    SX_MEM_CLR(printer_params);

    key_fp = cl_fopen("/dev/null", "w");
    if (key_fp == NULL) {
        SX_LOG_ERR("DEBUG CMD CLI:  failed (%s) - failed to open file /dev/null.\n",
                   strerror(errno));
        goto out;
    }

    printer_params.txt_fp = stream;
    utils_rc = dbg_utils_pprinter_add(key_fp, &printer_params);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to create a printer.\n");
        goto out;
    }

    dbg_dump_params.stream = key_fp;

    sdk_tele_db_threshold_latency_data_debug_dump(&dbg_dump_params);

    utils_rc = dbg_utils_pprinter_remove(key_fp);
    if (utils_rc != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("DEBUG CMD CLI: failed to destroy a printer.\n");
        goto out;
    }

out:
    if (key_fp != NULL) {
        if (cl_fclose(key_fp) != CL_SUCCESS) {
            SX_LOG_ERR("DEBUG CMD CLI: failed to close file /dev/null.\n");
        }
    }
}

static void __tele_debug_cmd_register(void)
{
    sx_utils_debug_cmd_register_path("tele threshold congestion all", __debug_cmd_threshold_dump_cb, NULL);
    sx_utils_debug_cmd_register_path("tele threshold last congestion all",
                                     __debug_cmd_last_congestion_threshold_dump_cb,
                                     NULL);
    sx_utils_debug_cmd_register_path("tele threshold latency key all", __debug_cmd_threshold_latency_key_dump_cb,
                                     NULL);
    sx_utils_debug_cmd_register_path("tele threshold latency data all",
                                     __debug_cmd_threshold_latency_data_dump_cb,
                                     NULL);
}

sx_status_t sdk_tele_impl_params_get(boolean_t *is_tele_init_done_p)
{
    if (is_tele_init_done_p) {
        *is_tele_init_done_p = g_is_tele_initialized;
    }
    return SX_STATUS_SUCCESS;
}

sx_status_t sdk_tele_assign_ops_wrapper(hwi_tele_ops_t* valid_operations_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.hwd_tele_assign_ops_cb != NULL) {
        rc = brg_context.spec_cb_g.hwd_tele_assign_ops_cb(valid_operations_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("tele_assign_ops_cb failed, for chip type %s, err = %s\n",
                       sx_chip_type_str((int)brg_context.spec_cb_g.dev_type), sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("hwd_tele_assign_ops_cb is not supported for this chip type (%s), err = %s.\n",
                   sx_chip_type_str((int)brg_context.spec_cb_g.dev_type), sx_status_str(rc));
        goto out;
    }

out:
    return rc;
}

sx_status_t sdk_tele_impl_init(const sx_tele_init_params_t * params_p)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_status_t    rollback_err = SX_STATUS_SUCCESS;
    boolean_t      rollback_db_init = FALSE, hwd_initialized = FALSE;
    hwi_tele_ops_t hwi_tele_ops;
    uint32_t       thr_num_max =
        (rm_resource_global.port_ext_num_max +
         rm_resource_global.lag_num_max) * TELE_IMPL_MAX_PG_TC_COUNT;
    uint32_t latency_threshold_key_num_max =
        (rm_resource_global.port_ext_num_max +
         rm_resource_global.lag_num_max) * rm_resource_global.cos_port_ets_traffic_class_max;
    uint32_t latency_threshold_data_num_max = rm_resource_global.tele_threshold_latency_table_size;

    SX_MEM_CLR(hwi_tele_ops);

    SX_LOG_ENTER();

    if (TRUE == g_is_tele_initialized) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("Tele impl module is already initialized\n");
        goto out;
    }

    if (utils_check_pointer(params_p, "params_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sdk_tele_assign_ops_wrapper(&hwi_tele_ops);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to assign HWD ops error, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_tele_impl_register_hwd_ops(&hwi_tele_ops);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to init tele, err = %s\n", sx_status_str(err));
        goto out;
    }

    err = sdk_tele_db_init(rm_resource_global.tele_histogram_num_max, thr_num_max,
                           latency_threshold_key_num_max, latency_threshold_data_num_max);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to init tele HWI DB, err = %s\n", sx_status_str(err));
        goto out;
    }
    rollback_db_init = TRUE;
    /*coverity[unsigned_compare]*/
    SX_MEM_CPY(g_tele_init_params, *params_p);

    if (g_ops.hwd_tele_init_pfn != NULL) {
        err = g_ops.hwd_tele_init_pfn(&g_tele_init_params);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to init tele HWD module, err = %s\n", sx_status_str(err));
            goto out;
        }
        hwd_initialized = TRUE;
    }

    /* Init telemetry attributes status: */
    g_tele_attrib.internal_ts_enable = TRUE;
    g_tele_attrib.tac_attr_valid = FALSE;
    SX_MEM_CLR(g_tele_attrib.tac_attr);

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_PRE_DEVICE_DEL_E,
                                 sdk_tele_impl_device_del_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
        goto out;
    }

    g_is_advisor_registered = TRUE;

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_PORT_PROFILE_APPLY_E,
                                 __tele_port_profile_apply_cb);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set port profile apply adviser, sx_status = %s\n", sx_status_str(err));
        goto out;
    }

    g_is_port_profile_apply_advisor_registered = TRUE;

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_PORT_PROFILE_DELETE_E,
                                 __tele_port_profile_delete_cb);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set port profile delete adviser, sx_status = %s\n", sx_status_str(err));
        goto out;
    }

    g_is_port_profile_delete_advisor_registered = TRUE;


    /*advise create/destroy of new LAG ids*/
    err = lag_sink_global_advise(__tele_lag_global_update, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in lag_sink_global_advise, error: %s \n", sx_status_str(err));
        goto out;
    }

    err = lag_sink_existent_lag_adviser_register(SX_ACCESS_CMD_ADD,
                                                 __tele_lag_port_update,
                                                 NULL,
                                                 0);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("err in lag_sink_existent_lag_adviser_register, error: %s \n",
                   sx_status_str(err));
        goto out;
    }

    __tele_debug_cmd_register();

    /* init hash sig */
    err = __tele_impl_hash_sig_init();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("err in __tele_impl_hash_sig_init, error: %s \n",
                   sx_status_str(err));
        goto out;
    }

    /* init TAC */
    err = __tele_impl_tac_init();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("err in __tele_impl_tac_init, error: %s \n",
                   sx_status_str(err));
        goto out;
    }

    g_is_tele_initialized = TRUE;

out:
    if (SX_CHECK_FAIL(err)) {
        if (rollback_db_init == TRUE) {
            rollback_err = sdk_tele_db_deinit(FALSE);
            if (SX_CHECK_FAIL(rollback_err)) {
                SX_LOG_ERR(
                    "Failed to rollback, Tele HWI DB deinit failed, err = %s\n",
                    sx_status_str(rollback_err));
            }
        }

        if (hwd_initialized == TRUE) {
            rollback_err = g_ops.hwd_tele_deinit_pfn(FALSE);
            if (SX_CHECK_FAIL(rollback_err)) {
                SX_LOG_ERR("Failed to deinit Tele hwd, err = %s\n",
                           sx_status_str(rollback_err));
                goto out;
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_deinit(boolean_t is_forced)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_is_tele_initialized) {
        if (FALSE == is_forced) {
            err = SX_STATUS_MODULE_UNINITIALIZED;
            SX_LOG_ERR("Tele module is not initialized.\n");
        }
        /* return success on force deinit if not initialized */
        goto out;
    }

    if ((TRUE == g_is_tele_initialized) && (TRUE == is_forced)) {
        g_is_tele_terminated = TRUE;
    }

    /* deinit TAC */
    err = __tele_impl_tac_deinit(is_forced);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("err in __tele_impl_tac_deinit, error: %s \n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_tele_db_deinit(is_forced);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinit Tele HWI DB, err = %s\n",
                   sx_status_str(err));
        goto out;
    }


    err = lag_sink_existent_lag_adviser_register(SX_ACCESS_CMD_DELETE,
                                                 __tele_lag_port_update,
                                                 NULL,
                                                 0);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in lag_sink_existent_lag_adviser_register, error: %s \n",
                   sx_status_str(err));
        goto out;
    }

    err = lag_sink_global_unadvise(__tele_lag_global_update);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in lag_sink_global_unadvise, error: %s \n", sx_status_str(err));
        goto out;
    }

    if (TRUE == g_is_advisor_registered) {
        err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PRE_DEVICE_DEL_E,
                                     sdk_tele_impl_device_del_callback);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
            goto out;
        }
    }

    g_is_advisor_registered = FALSE;

    if (TRUE == g_is_port_profile_apply_advisor_registered) {
        err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PORT_PROFILE_APPLY_E,
                                     __tele_port_profile_apply_cb);

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in ADVISER_EVENT_PORT_PROFILE_APPLY_E - advise, err: %s \n", sx_status_str(err));
            goto out;
        }
    }
    g_is_port_profile_apply_advisor_registered = FALSE;


    if (TRUE == g_is_port_profile_delete_advisor_registered) {
        err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_PORT_PROFILE_DELETE_E,
                                     __tele_port_profile_delete_cb);

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in ADVISER_EVENT_POST_PORT_PROFILE_DELETE_E - advise, err: %s \n", sx_status_str(err));
            goto out;
        }
    }
    g_is_port_profile_delete_advisor_registered = FALSE;


    err = g_ops.hwd_tele_deinit_pfn(is_forced);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinit Tele hwd, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    g_is_tele_initialized = FALSE;

    err = sdk_tele_impl_unregister_hwd_ops();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to unregister HWD ops, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_register_hwd_ops(hwi_tele_ops_t *ops_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(ops_p, "ops_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_tele_deinit_pfn,
                            "hwd_tele_deinit_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_tele_histogram_type_validation_pfn,
                            "hwd_tele_histogram_type_validation_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_tele_histogram_create_pfn,
                            "hwd_tele_create_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_tele_histogram_edit_pfn,
                            "hwd_tele_edit_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ops_p->hwd_tele_histogram_destroy_pfn,
                            "hwd_tele_destroy_pfn")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    g_ops = *ops_p;
    g_ops_init = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_unregister_hwd_ops(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE == g_is_tele_initialized) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("Failed to unregister HWD ops\n");
        goto out;
    }
    SX_MEM_CLR(g_ops);
    g_ops_init = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

void sdk_tele_impl_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }

    dbg_utils_pprinter_module_header_print(dbg_dump_params_p->stream, "Telemetry");

    dbg_utils_pprinter_field_print(dbg_dump_params_p->stream, "Module initialized", &g_is_tele_initialized,
                                   PARAM_BOOL_E);

    if (FALSE == g_is_tele_initialized) {
        /* error stays success */
        goto out;
    }

    sdk_tele_impl_attr_debug_dump(dbg_dump_params_p);
    sdk_tele_db_bw_gauge_attributes_debug_dump(dbg_dump_params_p);
    sdk_tele_db_histogram_debug_dump(dbg_dump_params_p);
    sdk_tele_db_latency_histogram_debug_dump(dbg_dump_params_p);
    sdk_tele_impl_histogram_data_debug_dump(dbg_dump_params_p);
    sdk_tele_db_threshold_debug_dump(dbg_dump_params_p);
    sdk_tele_db_last_congestion_threshold_debug_dump(dbg_dump_params_p);
    sdk_tele_db_threshold_latency_key_debug_dump(dbg_dump_params_p);
    sdk_tele_db_threshold_latency_data_debug_dump(dbg_dump_params_p);
    sdk_tele_db_hash_sig_debug_dump(dbg_dump_params_p);
    sdk_tele_db_tac_debug_dump(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
}

sx_status_t sdk_tele_check_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (FALSE == g_is_tele_initialized) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("Tele module is not initialized\n");
    }
    return err;
}

static sx_status_t __sdk_tele_impl_post_device_ready_callback(adviser_event_e event_type, void *param)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_tele_threshold_data_t disable_data;
    sx_tele_threshold_key_t  key;
    uint32_t                 sp = 0;
    sx_boot_mode_e           issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    const sx_dev_info_t     *dev_info = (sx_dev_info_t*)param;

    SX_LOG_ENTER();

    SX_MEM_CLR(disable_data);
    SX_MEM_CLR(key);

    if (event_type != ADVISER_EVENT_POST_DEVICE_READY_E) {
        SX_LOG_ERR("Wrong event type - expected event type is %s, "
                   "received event type : [%s]\n",
                   ADVISER_EVENT_STR(ADVISER_EVENT_POST_DEVICE_READY_E),
                   ADVISER_EVENT_STR(event_type));
        err = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    if (g_ops.hwd_tele_global_configuration_init_pfn != NULL) {
        err = g_ops.hwd_tele_global_configuration_init_pfn(dev_info->dev_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Fail to init global monitor configuration. [%s] \n", sx_status_str(err));
            goto out;
        }
    }

    if (g_ops.hwd_tele_threshold_latency_alloc_pfn != NULL) {
        disable_data.threshold_data_type = SX_TELE_THRESHOLD_DATA_TYPE_LATENCY_E;
        disable_data.threshold_data.threshold_high = TELE_TRESHOLD_LATENCY_DISABLE_THRESHOLD;
        err = g_ops.hwd_tele_threshold_latency_alloc_pfn(TELE_TRESHOLD_LATENCY_DISABLE_ID,
                                                         disable_data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Fail to init disable latency threshold. [%s] \n", sx_status_str(err));
            goto out;
        }
    }
    err = issu_boot_mode_get(&issu_boot_mode);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get boot mode. [%s] \n",
                   sx_status_str(err));
        goto out;
    }
    if (issu_boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        SX_LOG_DBG("ISSU_STARTED, skip latency mc sp threshold init, return success.\n");
        goto out;
    }

    if (g_ops.hwd_tele_threshold_latency_bind_pfn != NULL) {
        key.key_type = SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E;
        for (sp = 0; sp <= rm_resource_global.cos_port_prio_max; sp++) {
            key.key.mc_sp.sp = sp;
            err = g_ops.hwd_tele_threshold_latency_bind_pfn(TELE_TRESHOLD_LATENCY_DISABLE_ID,
                                                            key);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Fail to init disable latency threshold. [%s] \n", sx_status_str(err));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();

    return err;
}

static sx_status_t __sdk_tele_impl_post_port_add_into_swid_callback(adviser_event_e event_type, void *param)
{
    sx_port_info_t         *port_info_p = (sx_port_info_t*)param;
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_tele_threshold_key_t key;
    uint32_t                tc = 0;
    sx_boot_mode_e          issu_boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_LOG_ENTER();

    SX_MEM_CLR(key);

    if (event_type != ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E) {
        SX_LOG_ERR("Wrong event type - expected event type is %s, "
                   "received event type : [%s]\n",
                   ADVISER_EVENT_STR(ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E),
                   ADVISER_EVENT_STR(event_type));
        err = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    err = issu_boot_mode_get(&issu_boot_mode);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get boot mode. [%s] \n",
                   sx_status_str(err));
        goto out;
    }
    if (issu_boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        SX_LOG_DBG("ISSU_STARTED, skip latency port tc threshold init, return success.\n");
        goto out;
    }

    err = sdk_tele_impl_attributes_set(g_tele_attrib, &port_info_p->id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set telemetry attributes for port %d, err: %s \n",
                   port_info_p->id, sx_status_str(err));
        goto out;
    }

    if ((SX_PORT_TYPE_NETWORK != SX_PORT_TYPE_ID_GET(port_info_p->id)) &&
        (SX_PORT_TYPE_PROFILE != SX_PORT_TYPE_ID_GET(port_info_p->id))) {
        SX_LOG_DBG("Added non network port, return success.\n");
        err = SX_STATUS_SUCCESS;
        goto out;
    }


    if (g_ops.hwd_tele_threshold_default_set_pfn != NULL) {
        key.key_type = SX_TELE_THRESHOLD_TYPE_PORT_TC_E;
        key.key.port_tc.log_port = port_info_p->id;

        err = g_ops.hwd_tele_threshold_default_set_pfn(key);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set default egress congestion threshold: [%s].\n", sx_status_str(err));
            goto out;
        }

        key.key_type = SX_TELE_THRESHOLD_TYPE_PORT_PG_E;
        key.key.port_pg.log_port = port_info_p->id;

        err = g_ops.hwd_tele_threshold_default_set_pfn(key);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set default ingress congestion threshold: [%s].\n", sx_status_str(err));
            goto out;
        }
    }

    if (g_ops.hwd_tele_threshold_latency_bind_pfn != NULL) {
        key.key_type = SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E;
        key.key.port_tc.log_port = port_info_p->id;
        for (tc = 0; tc <= rm_resource_global.cos_port_ets_traffic_class_max; tc++) {
            key.key.port_tc.tc = tc;
            err = g_ops.hwd_tele_threshold_latency_bind_pfn(TELE_TRESHOLD_LATENCY_DISABLE_ID, key);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Fail to init disable latency threshold. [%s] \n", sx_status_str(err));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_pre_init()
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    hwi_tele_ops_t hwi_tele_ops;

    SX_MEM_CLR(hwi_tele_ops);

    err = sdk_tele_assign_ops_wrapper(&hwi_tele_ops);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to assign HWD ops error, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_tele_impl_register_hwd_ops(&hwi_tele_ops);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to init tele, err = %s\n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 __sdk_tele_impl_post_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E,
                                 __sdk_tele_impl_post_port_add_into_swid_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
        goto out;
    }

    g_tele_pre_init = TRUE;

out:
    return err;
}

sx_status_t sdk_tele_impl_pre_deinit()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (g_tele_pre_init == TRUE) {
        err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                                     __sdk_tele_impl_post_device_ready_callback);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
            goto out;
        }

        err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E,
                                     __sdk_tele_impl_post_port_add_into_swid_callback);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
            goto out;
        }

        g_tele_pre_init = FALSE;
    }

out:
    return err;
}

sx_status_t sdk_tele_impl_histogram_set(const sx_access_cmd_t                     cmd,
                                        const sx_tele_histogram_key_t             key,
                                        const sx_tele_histogram_attributes_data_t data)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    uint32_t                       tele_id = 0;
    sx_port_log_id_t               key_port = 0;
    const sx_tele_histogram_key_t *iter_key_p = NULL;
    const sx_tele_histogram_key_t *tmp_key_p = NULL;
    uint8_t                        num_of_emads = 0;

    /* Validate Port */
    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        err = __histogram_key_port_get(&key, &key_port);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve port from histogram key. err = %s\n", sx_status_str(err));
            goto out;
        }
        VALIDATE_PORT(sdk_tele_impl_histogram_set, key_port);
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = sdk_tele_db_histogram_get(key, NULL, NULL);
        if (SX_STATUS_ENTRY_NOT_FOUND != err) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Tele entry already exist in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        err = sdk_tele_db_histogram_add(key, data, &tele_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR_RESOURCE_COND(err, "Failed to add tele entry to HWI DB, err= %s.\n",
                                     sx_status_str(err));
            goto out;
        }

        err = g_ops.hwd_tele_histogram_create_pfn(key, data, tele_id, &num_of_emads);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to add tele histogram HWD entry, err = %s\n", sx_status_str(err));
            goto out;
        }

        if (SX_PORT_TYPE_PROFILE == SX_PORT_TYPE_ID_GET(key_port)) {
            err = port_profile_api_list_add(key_port, SX_API_INT_CMD_TELE_HISTOGRAM_SET_E, num_of_emads,
                                            PORT_PROFILE_PARAM_DB_BITS_TELE_HISTOGRAM_SET_E);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR(
                    "Failed to add histogram set API opcode (%x) to port profile (%d) API list, error (%s)",
                    SX_API_INT_CMD_TELE_HISTOGRAM_SET_E,
                    key_port,
                    sx_status_str(err));
            }
        }

        break;

    case SX_ACCESS_CMD_EDIT:
        err = sdk_tele_db_histogram_get(key, NULL, NULL);
        if (SX_CHECK_FAIL(err)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Tele entry not exist in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        err = sdk_tele_db_histogram_modify(key, data, &tele_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to modify telemetry entry in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        err = g_ops.hwd_tele_histogram_edit_pfn(key, data, tele_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to edit tele histogram HWD entry, err = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        err = sdk_tele_db_histogram_get(key, NULL, NULL);
        if (SX_CHECK_FAIL(err)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Tele entry not exist in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
        err = sdk_tele_db_histogram_delete(key, &tele_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to delete telemetry entry in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        err = g_ops.hwd_tele_histogram_destroy_pfn(key, tele_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to delete tele HWD entry, err = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        err = sdk_tele_db_histogram_key_iter_p_get(SX_ACCESS_CMD_GET_FIRST, &iter_key_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get histogram first key iter_p, err = %s\n", sx_status_str(err));
            goto out;
        }
        while (iter_key_p != NULL) {
            tmp_key_p = iter_key_p;
            err = sdk_tele_db_histogram_key_iter_p_get(SX_ACCESS_CMD_GETNEXT, &iter_key_p);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to get histogram next key iter_p, err = %s\n", sx_status_str(err));
                goto out;
            }
            err = g_ops.hwd_tele_histogram_destroy_pfn(*tmp_key_p, tele_id);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to delete tele HWD entry, err = %s\n", sx_status_str(err));
                goto out;
            }

            err = sdk_tele_db_histogram_delete(*tmp_key_p, &tele_id);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to delete telemetry entry in HWI DB, err= %s.\n",
                           sx_status_str(err));
                goto out;
            }
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is invalid. err = %s\n",
                   sx_access_cmd_str(cmd),
                   sx_status_str(err));
        goto out;
    }


out:
    return err;
}

sx_status_t sdk_tele_impl_histogram_get(const sx_access_cmd_t                cmd,
                                        const sx_tele_histogram_key_t        key,
                                        sx_tele_histogram_attributes_data_t *data_p)
{
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_tele_histogram_attributes_data_t tele_data;
    sx_port_log_id_t                    key_port = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(tele_data);

    /* Validate Port */
    err = __histogram_key_port_get(&key, &key_port);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve port from histogram key. err = %s\n", sx_status_str(err));
        goto out;
    }

    VALIDATE_PORT(sdk_tele_impl_histogram_get, key_port);

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        err = sdk_tele_db_histogram_get(key, &tele_data, NULL);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Histogram entry not exist in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is invalid. err = %s\n",
                   sx_access_cmd_str(cmd),
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(data_p, &tele_data);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_histogram_iter_get(const sx_access_cmd_t      cmd,
                                             sx_tele_histogram_key_t    hist_key,
                                             sx_tele_histogram_filter_t hist_filter,
                                             sx_tele_histogram_key_t   *hist_list_p,
                                             uint32_t                  *hist_cnt_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    sx_port_log_id_t key_port = 0;

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        /* Validate Port */
        if (hist_key.type != SX_TELE_HISTOGRAM_TYPE_INVALID) {
            err = __histogram_key_port_get(&hist_key, &key_port);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to retrieve port from histogram key. err = %s\n", sx_status_str(err));
                goto out;
            }

            VALIDATE_PORT(sdk_tele_impl_histogram_iter_get, key_port);
        }

        err = sdk_tele_db_histogram_iter_get(&hist_filter, &hist_key, hist_list_p, NULL, hist_cnt_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Tele entry not exist in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        err = sdk_tele_db_histogram_iter_get_first(&hist_filter, hist_list_p, NULL, hist_cnt_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Tele HWD DB is empty, err= %s.\n", sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
        /* Validate Port */
        if (hist_key.type != SX_TELE_HISTOGRAM_TYPE_INVALID) {
            err = __histogram_key_port_get(&hist_key, &key_port);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to retrieve port from histogram key. err = %s\n", sx_status_str(err));
                goto out;
            }

            VALIDATE_PORT(sdk_tele_impl_histogram_iter_get, key_port);
        }

        err = sdk_tele_db_histogram_iter_get_next(&hist_filter, hist_key, hist_list_p, NULL, hist_cnt_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Tele entry not exist in HWI DB, err= %s.\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is invalid. err = %s\n",
                   sx_access_cmd_str(cmd),
                   sx_status_str(err));
        goto out;
    }

out:
    return err;
}

sx_status_t sdk_tele_impl_histogram_data_get(const sx_access_cmd_t         cmd,
                                             const sx_tele_histogram_key_t key,
                                             sx_tele_histogram_data_t     *histogram_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    sx_tele_id_t     tele_id = 0;
    boolean_t        is_clear = FALSE;
    sx_port_log_id_t key_port = 0;

    SX_LOG_ENTER();

    /* Validate Port */
    err = __histogram_key_port_get(&key, &key_port);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve port from histogram key. err = %s\n", sx_status_str(err));
        goto out;
    }

    VALIDATE_PORT(sdk_tele_impl_histogram_data_get, key_port);

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }
    is_clear = (cmd == SX_ACCESS_CMD_READ_CLEAR ? TRUE : FALSE);

    err = sdk_tele_db_histogram_get(key, NULL, &tele_id);
    if (SX_CHECK_FAIL(err)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Tele entry not exist in HWI DB, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    err = g_ops.hwd_tele_histogram_data_get_pfn(key, tele_id, is_clear, histogram_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get histogram data, err = %s\n", sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_histogram_type_validation(const sx_tele_histogram_key_t *key_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = g_ops.hwd_tele_histogram_type_validation_pfn(key_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to validate histogram key type, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_counter_histogram_type_validation(const sx_tele_histogram_attributes_data_t *data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    err = g_ops.hwd_tele_counter_histogram_type_validation_pfn(data_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to validate counter histogram key type, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_latency_histogram_port_tc_validate(const sx_tele_histogram_key_t             *key,
                                                             const sx_tele_histogram_attributes_data_t *data,
                                                             boolean_t                                 *is_valid_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    sx_port_log_id_t log_port = 0;

    SX_LOG_ENTER();

    err = __histogram_key_port_get(key, &log_port);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve port from histogram key. err = %s\n", sx_status_str(err));
        goto out;
    }

    err = sdk_tele_db_latency_histogram_port_tc_validate(log_port, data, is_valid_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Invalid latency histogram configuration , err= %s.\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __congestion_threshold_set(const sx_access_cmd_t          cmd,
                                              const sx_tele_threshold_key_t  key,
                                              const sx_tele_threshold_data_t data)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    uint32_t                        i = 0;
    uint8_t                        *tc_pg_list_p = NULL;
    sx_tele_threshold_key_t        *port_key_list_p = NULL;
    sx_port_id_t                   *port_list_p = NULL;
    length_t                        port_cnt = 0;
    sx_tele_threshold_filter_t      filter;
    uint32_t                        total_tc_pg_cnt = 0;
    uint32_t                        tc_pg_cnt = 0;
    sx_port_log_id_t                log_port = 0;
    tele_threshold_direction_type_e direction = 0;
    sx_boot_mode_e                  issu_boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_MEM_CLR(filter);

    err = utils_memory_get((void**)&port_list_p,
                           rm_resource_global.lag_port_members_max * sizeof(sx_port_id_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_list , err = %s\n", sx_status_str(err));
        goto out;
    }

    err = utils_memory_get((void**)&port_key_list_p,
                           TELE_IMPL_MAX_PG_TC_COUNT * sizeof(sx_tele_threshold_key_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_key_list , err = %s\n", sx_status_str(err));
        goto out;
    }

    err = utils_memory_get((void**)&tc_pg_list_p,
                           TELE_IMPL_MAX_PG_TC_COUNT * sizeof(uint8_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for tc_list , err = %s\n", sx_status_str(err));
        goto out;
    }

    err = sdk_tele_db_threshold_get(key, NULL);
    if (cmd == SX_ACCESS_CMD_SET) {
        if (SX_STATUS_ENTRY_NOT_FOUND != err) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Tele threshold entry already exists in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
    } else { /* CMD = EDIT or DESTROY */
        if (SX_CHECK_FAIL(err)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Tele threshold entry not exist in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
    }

    sdk_tele_impl_threshold_key_log_port_get(key, &log_port);

    if (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_LAG) {
        port_cnt = rm_resource_global.lag_port_members_max;
        err = sx_lag_port_group_get(log_port, port_list_p, &port_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in sx_lag_port_group_get(), error: %s\n", sx_status_str(err));
            goto out;
        }
    } else if ((SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_NETWORK)) {
        port_cnt = 1;
        port_list_p[0] = log_port;
    } else {
        SX_LOG_ERR("port type [%u] is not NETWORK nor LAG.\n", SX_PORT_TYPE_ID_GET(log_port));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Update last congestion DB */
    err = sdk_tele_db_last_congestion_threshold_entry_update(cmd, &key, &data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to update last congestion threshold entry, err: %s.\n", sx_status_str(err));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = sdk_tele_db_threshold_add(key, data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR_RESOURCE_COND(err, "Failed to add tele entry to HWI DB, err= %s.\n",
                                     sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        err = sdk_tele_db_threshold_modify(key, data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to modify threshold entry in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        err = sdk_tele_db_threshold_delete(key);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR_RESOURCE_COND(err, "Failed to destroy tele entry in HWI DB, err= %s.\n",
                                     sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is invalid. err: %s\n",
                   sx_access_cmd_str(cmd),
                   sx_status_str(err));
        goto out;
    }

    /* In spectrum/2, the threshold is applied to a port and all TC/PG's in it,
     * thus we need to iter_ger all the TC/PG's and re-apply the threshold */
    filter.port_filter_valid = SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E;
    filter.port_filter = log_port;
    total_tc_pg_cnt = TELE_IMPL_MAX_PG_TC_COUNT;
    err = sdk_tele_db_threshold_iter_get_first(&filter, port_key_list_p, NULL, &total_tc_pg_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get thresholds entries in HWI DB, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    if (key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
        for (i = 0; i < total_tc_pg_cnt; i++) {
            if (port_key_list_p[i].key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
                tc_pg_list_p[tc_pg_cnt] = port_key_list_p[i].key.port_tc.tc;
                tc_pg_cnt++;
            }
        }
        direction = TELE_THRESHOLD_DIRECTION_EGRESS_E;
    } else if (key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
        for (i = 0; i < total_tc_pg_cnt; i++) {
            if (port_key_list_p[i].key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
                tc_pg_list_p[tc_pg_cnt] = port_key_list_p[i].key.port_pg.pg;
                tc_pg_cnt++;
            }
        }
        direction = TELE_THRESHOLD_DIRECTION_INGRESS_E;
    }

    err = issu_boot_mode_get(&issu_boot_mode);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get boot mode. err = %s\n",
                   sx_status_str(err));
        goto out;
    }
    if (issu_boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
        for (i = 0; i < port_cnt; i++) {
            if ((cmd == SX_ACCESS_CMD_SET) || (cmd == SX_ACCESS_CMD_EDIT)) {
                err = g_ops.hwd_tele_threshold_edit_pfn(port_list_p[i],
                                                        direction,
                                                        tc_pg_list_p,
                                                        tc_pg_cnt,
                                                        data);
            } else { /* cmd == DESTROY */
                err = g_ops.hwd_tele_threshold_destroy_pfn(port_list_p[i],
                                                           direction,
                                                           tc_pg_list_p,
                                                           tc_pg_cnt);
            }
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to configure HW, err = %s\n", sx_status_str(err));
                goto out;
            }
        }
    }

out:
    if (port_key_list_p) {
        utils_memory_put(port_key_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    if (tc_pg_list_p) {
        utils_memory_put(tc_pg_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    if (port_list_p) {
        utils_memory_put(port_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    SX_LOG_EXIT();
    return err;
}

void sdk_tele_impl_threshold_key_log_port_get(const sx_tele_threshold_key_t key, sx_port_log_id_t *log_port_p)
{
    if (log_port_p != NULL) {
        if ((key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) ||
            (key.key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E)) {
            *log_port_p = key.key.port_tc.log_port;
        } else if (key.key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
            *log_port_p = key.key.port_pg.log_port;
        } else {
            *log_port_p = SX_INVALID_PORT;
        }
    }
}

void sdk_tele_impl_threshold_key_log_port_set(sx_tele_threshold_key_t *key_p, const sx_port_log_id_t log_port)
{
    if (key_p != NULL) {
        if ((key_p->key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) ||
            (key_p->key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E)) {
            key_p->key.port_tc.log_port = log_port;
        } else if (key_p->key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
            key_p->key.port_pg.log_port = log_port;
        }
    }
}

sx_status_t sdk_tele_impl_threshold_set(const sx_access_cmd_t          cmd,
                                        const sx_tele_threshold_key_t  key,
                                        const sx_tele_threshold_data_t data)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    uint8_t          lag_member = 0;
    sx_port_log_id_t log_port = 0;

    /* Validate access command */
    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_EDIT) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is invalid. err: %s\n",
                   sx_access_cmd_str(cmd),
                   sx_status_str(err));
        goto out;
    }

    /* Validate congestion threshold type */
    if ((key.key_type != SX_TELE_THRESHOLD_TYPE_PORT_TC_E) &&
        (key.key_type != SX_TELE_THRESHOLD_TYPE_PORT_PG_E)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold key type [%s] is invalid. err: %s\n",
                   sx_tele_threshold_type_str(key.key_type),
                   sx_status_str(err));
        goto out;
    }

    sdk_tele_impl_threshold_key_log_port_get(key, &log_port);

    /* Validate Port */
    VALIDATE_PORT(sdk_tele_impl_threshold_set, log_port);

    /* exit if port is lag member */
    err = port_lag_member_state_get(SX_ACCESS_CMD_GET, log_port, &lag_member);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve if port (0x%x) is lag member (%s)\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    if (lag_member) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failure - port (0x%x) is LAG member (%s)\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    err = __congestion_threshold_set(cmd, key, data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set congestion threshold, err: %s.\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_threshold_get(const sx_access_cmd_t         cmd,
                                        const sx_tele_threshold_key_t key,
                                        sx_tele_threshold_data_t     *data_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_tele_threshold_data_t tele_data;
    sx_tele_threshold_key_t  converted_key;
    sx_port_log_id_t         log_port = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(tele_data);
    SX_MEM_CLR(converted_key);

    sdk_tele_impl_threshold_key_log_port_get(key, &log_port);

    /* Validate Port */
    VALIDATE_PORT(sdk_tele_impl_threshold_get, log_port);

    err = __convert_adjusted_key(key, &converted_key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("failed adjusting threshold key\n");
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        err = sdk_tele_db_threshold_get(converted_key, &tele_data);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Tele entry not exist in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is invalid. err = %s\n",
                   sx_access_cmd_str(cmd),
                   sx_status_str(err));
        goto out;
    }

    SX_MEM_CPY_P(data_p, &tele_data);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_threshold_iter_get(const sx_access_cmd_t      cmd,
                                             sx_tele_threshold_key_t    key,
                                             sx_tele_threshold_filter_t filter,
                                             sx_tele_threshold_key_t   *key_list_p,
                                             uint32_t                  *key_cnt_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_tele_threshold_key_t converted_key;

    SX_MEM_CLR(converted_key);

    if ((*key_cnt_p > 0) && (cmd != SX_ACCESS_CMD_GET_FIRST)) {
        err = __convert_adjusted_key(key, &converted_key);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("failed adjusting threshold key\n");
            goto out;
        }
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        err = sdk_tele_db_threshold_iter_get(&filter, &converted_key, key_list_p, NULL, key_cnt_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Tele entry not exist in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        err = sdk_tele_db_threshold_iter_get_first(&filter, key_list_p, NULL, key_cnt_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Tele HWD DB is empty, err= %s.\n", sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
        err = sdk_tele_db_threshold_iter_get_next(&filter, converted_key, key_list_p, NULL, key_cnt_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Tele entry not exist in HWI DB, err= %s.\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is invalid. err = %s\n",
                   sx_access_cmd_str(cmd),
                   sx_status_str(err));
        goto out;
    }

out:
    return err;
}

static sx_status_t __latency_threshold_data_db_set(const sx_access_cmd_t          cmd,
                                                   const sx_tele_threshold_key_t  key,
                                                   const sx_tele_threshold_data_t data,
                                                   uint8_t                       *latency_id_p,
                                                   boolean_t                     *is_new_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_tele_threshold_data_t old_data;

    SX_MEM_CLR(old_data);

    /* Verify key exist (edit or destroy) or not exist (set) */
    err = sdk_tele_db_latency_threshold_key_get(key, &old_data);
    if (cmd == SX_ACCESS_CMD_SET) {
        if (SX_STATUS_ENTRY_NOT_FOUND != err) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Latency threshold entry already exists in DB. [%s]\n",
                       sx_status_str(err));
            goto out;
        }
    } else { /* CMD = EDIT or DESTROY */
        if (SX_CHECK_FAIL(err)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Latency threshold entry not exist in DB. [%s]\n",
                       sx_status_str(err));
            goto out;
        }
    }

    /* Allocate new latency threshold */
    if ((cmd == SX_ACCESS_CMD_SET) || (cmd == SX_ACCESS_CMD_EDIT)) {
        err = sdk_tele_db_latency_threshold_data_alloc(data, latency_id_p, is_new_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("No more resources: Latency threshold. [%s]\n",
                       sx_status_str(err));
            goto out;
        }
    } else { /* CMD = DESTROY */
        *latency_id_p = TELE_TRESHOLD_LATENCY_DISABLE_ID;
        *is_new_p = FALSE;
    }

    /* Remove old latency threshold */
    if ((cmd == SX_ACCESS_CMD_DESTROY) || (cmd == SX_ACCESS_CMD_EDIT)) {
        err = sdk_tele_db_latency_threshold_data_free(old_data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Fail to free Latency threshold data. [%s]\n",
                       sx_status_str(err));
            goto out;
        }
    }
out:

    return err;
}

static sx_status_t __latency_threshold_key_db_set(const sx_access_cmd_t          cmd,
                                                  const sx_tele_threshold_key_t  key,
                                                  const sx_tele_threshold_data_t data)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = sdk_tele_db_latency_threshold_key_add(key, data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR_RESOURCE_COND(err, "Failed to add latency key entry to DB. [%s]\n",
                                     sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        err = sdk_tele_db_latency_threshold_key_modify(key, data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to modify latency threshold key entry in DB. [%s]\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        err = sdk_tele_db_latency_threshold_key_delete(key);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR_RESOURCE_COND(err, "Failed to destroy latency key entry in DB. [%s]\n",
                                     sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is invalid. err: %s\n",
                   sx_access_cmd_str(cmd),
                   sx_status_str(err));
        goto out;
    }
out:

    return err;
}

static sx_status_t __latency_threshold_mc_hw_set(const sx_tele_threshold_key_t key, const uint8_t latency_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = g_ops.hwd_tele_threshold_latency_bind_pfn(latency_id, key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to configure HW, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    return err;
}

static sx_status_t __latency_threshold_port_tc_hw_set(const sx_tele_threshold_key_t key, const uint8_t latency_id)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    uint32_t                i = 0;
    sx_port_id_t           *port_list_p = NULL;
    length_t                port_cnt = 0;
    sx_tele_threshold_key_t log_port_key;
    sx_port_log_id_t        log_port = 0;

    SX_MEM_CLR(log_port_key);

    err = utils_memory_get((void**)&port_list_p,
                           rm_resource_global.lag_port_members_max * sizeof(sx_port_id_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_list , err = %s\n", sx_status_str(err));
        goto out;
    }

    log_port = key.key.port_tc.log_port;

    if (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_LAG) {
        port_cnt = rm_resource_global.lag_port_members_max;
        err = sx_lag_port_group_get(log_port, port_list_p, &port_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in sx_lag_port_group_get(), error: %s\n", sx_status_str(err));
            goto out;
        }
    } else if ((SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_NETWORK)) {
        port_cnt = 1;
        port_list_p[0] = log_port;
    } else {
        SX_LOG_ERR("port type [%u] is not NETWORK nor LAG.\n", SX_PORT_TYPE_ID_GET(log_port));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    log_port_key.key_type = key.key_type;
    log_port_key.key.port_tc.tc = key.key.port_tc.tc;
    for (i = 0; i < port_cnt; i++) {
        log_port_key.key.port_tc.log_port = port_list_p[i];
        err = g_ops.hwd_tele_threshold_latency_bind_pfn(latency_id,
                                                        log_port_key);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to configure HW, err = %s\n", sx_status_str(err));
            goto out;
        }
    }

out:
    if (port_list_p) {
        utils_memory_put(port_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }

    return err;
}

static sx_status_t __latency_threshold_set(const sx_access_cmd_t          cmd,
                                           const sx_tele_threshold_key_t  key,
                                           const sx_tele_threshold_data_t data)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint8_t     latency_id = 0;
    boolean_t   is_new = FALSE;

    /* Update data DB */
    err = __latency_threshold_data_db_set(cmd, key, data, &latency_id, &is_new);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    /* Update key DB */
    err = __latency_threshold_key_db_set(cmd, key, data);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    /* HW configuration */
    if (is_new) {
        err = g_ops.hwd_tele_threshold_latency_alloc_pfn(latency_id, data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to configure HW, err = %s\n", sx_status_str(err));
            goto out;
        }
    }

    if (key.key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E) {
        err = __latency_threshold_port_tc_hw_set(key, latency_id);
    } else if (key.key_type == SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E) {
        err = __latency_threshold_mc_hw_set(key, latency_id);
    } else {
        SX_LOG_ERR("Invalid key type (%s).\n", sx_tele_threshold_type_str(key.key_type));
        err = SX_STATUS_PARAM_ERROR;
    }
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    return err;
}

static sx_status_t __latency_threshold_port_validation(const sx_tele_threshold_key_t key)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    uint8_t          lag_member = 0;
    sx_port_log_id_t log_port = key.key.port_tc.log_port;

    /* Validate Port */
    VALIDATE_PORT(sdk_tele_impl_threshold_set, log_port);

    /* exit if port is lag member */
    err = port_lag_member_state_get(SX_ACCESS_CMD_GET, log_port, &lag_member);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve port (0x%x) lag membership. [%s]\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    if (lag_member) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Port (0x%x) is LAG member. [%s]\n",
                   log_port, sx_status_str(err));
        goto out;
    }

out:
    return err;
}

sx_status_t sdk_tele_impl_latency_threshold_set(const sx_access_cmd_t          cmd,
                                                const sx_tele_threshold_key_t  key,
                                                const sx_tele_threshold_data_t data)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    /* Validate access command */
    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_EDIT) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is invalid. err: %s\n",
                   sx_access_cmd_str(cmd),
                   sx_status_str(err));
        goto out;
    }

    switch (key.key_type) {
    case SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E:
        err = __latency_threshold_port_validation(key);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to validate port. [%s]\n", sx_status_str(err));
            goto out;
        }

    /* fallthrough */

    case SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E:
        err = __latency_threshold_set(cmd, key, data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set latency threshold. [%s]\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Threshold key type [%s] is invalid. [%s]\n",
                   sx_tele_threshold_type_str(key.key_type),
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_latency_threshold_get(const sx_tele_threshold_key_t key,
                                                sx_tele_threshold_data_t     *data_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_tele_threshold_key_t converted_key;
    sx_port_log_id_t        log_port = SX_INVALID_PORT;

    SX_LOG_ENTER();

    SX_MEM_CLR(converted_key);

    sdk_tele_impl_threshold_key_log_port_get(key, &log_port);

    if (log_port != SX_INVALID_PORT) {
        /* Validate Port */
        VALIDATE_PORT(sdk_tele_impl_threshold_get, log_port);
    }

    err = __convert_adjusted_key(key, &converted_key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("failed adjusting threshold key\n");
        goto out;
    }

    err = sdk_tele_db_latency_threshold_key_get(converted_key, data_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_threshold_crossed_data_get(const sx_access_cmd_t                  cmd,
                                                     sx_tele_threshold_crossed_data_keys_t *data_p,
                                                     const uint32_t                         list_cnt)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    uint32_t                i = 0;
    sx_tele_threshold_key_t key;
    sx_port_log_id_t        log_port = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(key);

    /* Validate Port */
    for (i = 0; i < list_cnt; i++) {
        sdk_tele_impl_threshold_key_log_port_get(data_p[i].key, &log_port);
        VALIDATE_PORT(sdk_tele_impl_threshold_crossed_data_get, log_port);

        err = __convert_adjusted_key(data_p[i].key, &key);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("failed adjusting threshold key\n");
            goto out;
        }

        err = sdk_tele_db_threshold_get(key, NULL);
        if (SX_CHECK_FAIL(err)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Tele threshold entry not exist in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }
    }
    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        err = g_ops.hwd_tele_threshold_crossed_data_get_pfn(data_p, list_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to add tele threshold HWD entry, err = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Command [%s] is invalid. err = %s\n",
                   sx_access_cmd_str(cmd),
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_device_del_callback(adviser_event_e event_type, void *param_p)
{
    sx_tele_histogram_key_t             hist_list_arr[SX_TELE_HISTOGRAM_MAX_GET_ENTRIES];
    sx_tele_threshold_key_t            *thr_list_arr_p = NULL;
    sx_port_attributes_t               *port_attributes_p = NULL;
    sx_dev_info_t                      *dev_info_p = (sx_dev_info_t*)param_p;
    sx_status_t                         err = SX_STATUS_SUCCESS;
    sx_tele_histogram_key_t             hist_key;
    sx_tele_threshold_key_t             thr_key;
    sx_tele_histogram_filter_t          hist_filter;
    sx_tele_threshold_filter_t          thr_filter;
    sx_tele_histogram_attributes_data_t data;
    sx_tele_threshold_data_t            thr_data;
    uint32_t                            i = 0, j = 0, port_cnt = 0, hist_cnt = 0, thr_cnt = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(hist_key);
    SX_MEM_CLR(hist_filter);
    SX_MEM_CLR(hist_list_arr);
    SX_MEM_CLR(data);
    SX_MEM_CLR(thr_data);
    SX_MEM_CLR(thr_filter);
    SX_MEM_CLR(thr_key);


    /* This function should handle only pre device delete events */
    if (event_type != ADVISER_EVENT_PRE_DEVICE_DEL_E) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("got event [%s], only [%s] events are valid for this function, err: %s\n",
                   ADVISER_EVENT_STR(event_type),
                   ADVISER_EVENT_STR(ADVISER_EVENT_PRE_DEVICE_DEL_E),
                   sx_status_str(err));
        goto out;
    }

    /* params variable should be a valid pointer to the device info */
    if (utils_check_pointer(param_p, "params_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* if Tele module is not initialized return success - no histograms on the device ports */
    if (g_is_tele_initialized == FALSE) {
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    /* get the device ports count */
    err = port_db_device_cnt(dev_info_p->dev_id, SX_SWID_ID_DONTCARE, &port_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get ports count for device [%u], err: %s\n",
                   dev_info_p->dev_id, sx_status_str(err));
        goto out;
    }

    /* allocate memory for the ports attributes */
    port_attributes_p = (sx_port_attributes_t*)cl_malloc(sizeof(sx_port_attributes_t) * port_cnt);
    if (port_attributes_p == NULL) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for port attributes list, err: %s\n",
                   sx_status_str(err));
        goto out;
    }
    SX_MEM_CLR_ARRAY(port_attributes_p, port_cnt, sx_port_attributes_t);

    /* get the ports attributes */
    err = port_db_device_get(dev_info_p->dev_id, SX_SWID_ID_DONTCARE, port_attributes_p, &port_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get ports attributes for device [%u], err: %s\n",
                   dev_info_p->dev_id, sx_status_str(err));
        goto out;
    }

    /* allocate memory for the threshold key list */
    thr_list_arr_p =
        (sx_tele_threshold_key_t*)cl_malloc(sizeof(sx_tele_threshold_key_t) *
                                            TELE_IMPL_MAX_PG_TC_COUNT);
    if (thr_list_arr_p == NULL) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for the threshold key list, err: %s\n",
                   sx_status_str(err));
        goto out;
    }
    SX_MEM_CLR_ARRAY(thr_list_arr_p, TELE_IMPL_MAX_PG_TC_COUNT, sx_tele_threshold_key_t);

    hist_filter.filter_port_valid = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_VALID_E;
    hist_filter.filter_tc_valid = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_NOT_VALID_E;
    thr_filter.port_filter_valid = SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E;
    thr_filter.tc_filter_valid = SX_TELE_THRESHOLD_KEY_TC_FILTER_NOT_VALID_E;
    for (i = 0; i < port_cnt; i++) {
        hist_filter.port_filter = port_attributes_p[i].log_port;
        hist_cnt = SX_TELE_HISTOGRAM_MAX_GET_ENTRIES;
        /* get all the histograms on that port. GET_FIRST will return all histograms on one port */
        err =
            sdk_tele_impl_histogram_iter_get(SX_ACCESS_CMD_GET_FIRST, hist_key, hist_filter, hist_list_arr, &hist_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get histograms for port [0x%08X], err: %s\n",
                       hist_filter.port_filter, sx_status_str(err));
            goto out;
        }

        /* delete all histograms on the port */
        for (j = 0; j < hist_cnt; j++) {
            err = sdk_tele_impl_histogram_set(SX_ACCESS_CMD_DESTROY, hist_list_arr[j], data);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to destroy histograms for port [0x%08X], err: %s\n",
                           hist_filter.port_filter, sx_status_str(err));
                goto out;
            }
        }

        thr_filter.port_filter = port_attributes_p[i].log_port;
        thr_cnt = TELE_IMPL_MAX_PG_TC_COUNT;

        /* get all the thresholds on the port */
        err = sdk_tele_impl_threshold_iter_get(SX_ACCESS_CMD_GET_FIRST, thr_key, thr_filter, thr_list_arr_p, &thr_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get threshold keys for port [0x%08X], err: %s\n",
                       thr_filter.port_filter, sx_status_str(err));
            goto out;
        }

        /* disable all TC thresholds on the port */
        for (j = 0; j < thr_cnt; j++) {
            err = sdk_tele_impl_threshold_set(SX_ACCESS_CMD_DESTROY, thr_list_arr_p[j], thr_data);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to destroy threshold for port [0x%08X], err: %s\n",
                           thr_filter.port_filter, sx_status_str(err));
                goto out;
            }
        }
    }

out:
    if (port_attributes_p != NULL) {
        CL_FREE_N_NULL(port_attributes_p);
    }
    if (thr_list_arr_p != NULL) {
        CL_FREE_N_NULL(thr_list_arr_p);
    }
    SX_LOG_EXIT();
    return err;
}

void sdk_tele_impl_histogram_data_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    uint32_t                  hist_count = rm_resource_global.tele_histogram_num_max;
    uint32_t                  tele_id = 0, i = 0;
    sx_tele_histogram_key_t   hist_key_list[hist_count];
    sx_tele_histogram_data_t  hist_data;
    dbg_utils_table_columns_t tele_entry_table[] = {
        {"Hist ID", 10, PARAM_UINT32_E, &tele_id},
        {"Bin 0", 10, PARAM_UINT64_E, &hist_data.bins[0]},
        {"Bin 1", 10, PARAM_UINT64_E, &hist_data.bins[1]},
        {"Bin 2", 10, PARAM_UINT64_E, &hist_data.bins[2]},
        {"Bin 3", 10, PARAM_UINT64_E, &hist_data.bins[3]},
        {"Bin 4", 10, PARAM_UINT64_E, &hist_data.bins[4]},
        {"Bin 5", 10, PARAM_UINT64_E, &hist_data.bins[5]},
        {"Bin 6", 10, PARAM_UINT64_E, &hist_data.bins[6]},
        {"Bin 7", 10, PARAM_UINT64_E, &hist_data.bins[7]},
        {"Bin 8", 10, PARAM_UINT64_E, &hist_data.bins[8]},
        {"Bin 9", 10, PARAM_UINT64_E, &hist_data.bins[9]},
        {"Max Sampled", 15, PARAM_UINT64_E, &hist_data.max_sampled},
        {"Valid Watermark", 15, PARAM_BOOL_E, &hist_data.watermark_valid},
        {"Max Watermark", 15, PARAM_UINT64_E, &hist_data.max_watermark},
        {"Min Watermark", 15, PARAM_UINT64_E, &hist_data.min_watermark},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                     *stream = NULL;
    sx_port_log_id_t          key_port = 0;


    SX_LOG_ENTER();

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "TELE HISTOGRAMS DATA");

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = sdk_tele_db_histogram_iter_get_first(NULL, hist_key_list, NULL, &hist_count);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get histograms from db\n");
        goto out;
    }

    dbg_utils_pprinter_print(stream, "\n");

    dbg_utils_pprinter_table_headline_print(stream, tele_entry_table);

    for (i = 0; i < hist_count; i++) {
        err = sdk_tele_db_histogram_get(hist_key_list[i], NULL, &tele_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to find histogram in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        err = __histogram_key_port_get(&hist_key_list[i], &key_port);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve port from histogram key. err = %s\n", sx_status_str(err));
            goto out;
        }

        if (SX_PORT_TYPE_ID_GET(key_port) == SX_PORT_TYPE_PROFILE) {
            continue;
        }

        SX_MEM_CLR(hist_data);

        err = sdk_tele_impl_histogram_data_get(SX_ACCESS_CMD_READ, hist_key_list[i], &hist_data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get histogram from HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        dbg_utils_pprinter_table_data_line_print(stream, tele_entry_table);
    }

out:
    SX_LOG_EXIT();
    return;
}

void sdk_tele_impl_attr_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    dbg_utils_table_columns_t tele_attr_entry_table[] = {
        {"Internal timestamp mode", 24, PARAM_UINT16_E, &g_tele_attrib.internal_ts_enable},
        {"TAC attr valid", 10, PARAM_BOOL_E, &g_tele_attrib.tac_attr_valid},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    char                      tac_mode_s[20];
    char                      tac_periodic_action_s[20];
    dbg_utils_table_columns_t tele_attr_tac_attr_table[] = {
        {"tac_mode", 24, PARAM_STRING_E, tac_mode_s},
        {"periodic_action_en", 24, PARAM_UINT16_E, &g_tele_attrib.tac_attr.tac_periodic_action_enabled},
        {"periodic_action", 24, PARAM_STRING_E, tac_periodic_action_s},
        {"periodic_action_interval", 24, PARAM_UINT16_E, &g_tele_attrib.tac_attr.tac_periodic_action_interval},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                     *stream = NULL;

    SX_LOG_ENTER();

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "TELEMETRY MODULE ATTRIBUTES");

    if ((err = sdk_tele_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    dbg_utils_pprinter_print(stream, "\n");
    dbg_utils_pprinter_table_headline_print(stream, tele_attr_entry_table);
    dbg_utils_pprinter_table_data_line_print(stream, tele_attr_entry_table);

    if (g_tele_attrib.tac_attr_valid) {
        strncpy(tac_mode_s,  sx_tele_tac_mode_str(g_tele_attrib.tac_attr.tac_mode), sizeof(tac_mode_s) - 1);
        strncpy(tac_periodic_action_s, sx_tele_tac_action_str(g_tele_attrib.tac_attr.tac_periodic_action),
                sizeof(tac_periodic_action_s) - 1);
        dbg_utils_pprinter_print(stream, "\n");
        dbg_utils_pprinter_table_headline_print(stream, tele_attr_tac_attr_table);
        dbg_utils_pprinter_table_data_line_print(stream, tele_attr_tac_attr_table);
    }

out:
    SX_LOG_EXIT();
    return;
}


static sx_status_t __histogram_key_port_get(IN const sx_tele_histogram_key_t *key,
                                            OUT sx_port_log_id_t             *key_port)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (key->type) {
    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E:
    case SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E:
        *key_port = key->key.port_tc.log_port;
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E:
        *key_port = key->key.port_pg.log_port;
        break;

    case SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:
        *key_port = key->key.port_counter.log_port;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        *key_port = 0;
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t __tele_lag_global_update(IN sx_port_id_t          lag_port_log_id,
                                     IN lag_sink_event_type_e event_type,
                                     IN void                 *context_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(context_p);

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_CREATED_E:
        /* advise for the new lag */
        rc = lag_sink_lag_advise(lag_port_log_id, __tele_lag_port_update,
                                 NULL, 0);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("lag_sink_lag_advise has failed, error: %s\n", sx_status_str(rc));
            goto out;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        break;

    default:
        SX_LOG_ERR(
            "Unsupported event type , event type: (%d)\n",
            event_type);
        rc = SX_STATUS_CMD_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __tele_lag_port_update(IN sx_port_id_t          lag_port_log_id,
                                   IN lag_sink_event_type_e event_type,
                                   IN sx_port_id_t          port_log_id,
                                   IN void                 *context_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(context_p);

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_PRE_PORT_ADDED_VALIDATIONS_E:

        rc = __congestion_thresholds_port_add_to_lag_validation(lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }
        rc = __latency_thresholds_port_add_to_lag_validation(lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }
        break;


    case LAG_SINK_EVENT_TYPE_LAG_POST_PORT_ADDED_E:
        rc = __remove_thresholds(port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("failed removed from DB log port thresholds. err = %s\n",
                       sx_status_str(rc));
            goto out;
        }
        rc = __remove_latency_thresholds(port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to remove latency threshold from DB for log port 0x%x. [%s]\n",
                       port_log_id, sx_status_str(rc));
            goto out;
        }

        break;

    case LAG_SINK_EVENT_TYPE_LAG_PORT_REMOVED_E:
        rc = __align_thresholds(lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("failed aligning log port thresholds to lag in DB. err = %s\n",
                       sx_status_str(rc));
            goto out;
        }
        rc = __align_latency_thresholds(lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("failed aligning log port latency thresholds from lag in DB. err = %s\n",
                       sx_status_str(rc));
            goto out;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        rc = __remove_thresholds(lag_port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to remove lag port thresholds from the DB. err = %s\n",
                       sx_status_str(rc));
            goto out;
        }
        rc = __remove_latency_thresholds(lag_port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to remove lag port latency thresholds from the DB. err = %s\n",
                       sx_status_str(rc));
            goto out;
        }
        /* unadvised destroyed lag id */
        rc = lag_sink_lag_unadvise(lag_port_log_id, __tele_lag_port_update);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in lag_sink_lag_unadvise , error: %s\n", sx_status_str(rc));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR(
            "Wrong event type , event type: (%d)\n",
            event_type);
        rc = SX_STATUS_CMD_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __congestion_thresholds_port_add_to_lag_validation(const sx_port_log_id_t lag_port_log_id,
                                                                      const sx_port_log_id_t port_log_id)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_tele_threshold_filter_t filter;
    uint32_t                   key_cnt_lag = 0;
    uint32_t                   key_cnt_port = 0;
    sx_tele_threshold_key_t   *key_list_lag_p = NULL;
    sx_tele_threshold_key_t   *key_list_port_p = NULL;
    sx_tele_threshold_data_t   data_port;
    sx_tele_threshold_data_t   data_lag;
    sx_tele_threshold_key_t    key;
    uint32_t                   i = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(filter);
    SX_MEM_CLR(data_port);
    SX_MEM_CLR(data_lag);
    SX_MEM_CLR(key);

    /* allocate memory for the PORT threshold key list */
    key_list_lag_p =
        (sx_tele_threshold_key_t*)cl_malloc(sizeof(key_list_lag_p[0]) *
                                            (TELE_IMPL_MAX_PG_TC_COUNT + 1));
    if (key_list_lag_p == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for the port threshold key list, err: %s\n",
                   sx_status_str(rc));
        goto out;
    }
    SX_MEM_CLR_ARRAY(key_list_lag_p, TELE_IMPL_MAX_PG_TC_COUNT + 1, sx_tele_threshold_key_t);

    /* allocate memory for the LAG threshold key list */
    key_list_port_p =
        (sx_tele_threshold_key_t*)cl_malloc(sizeof(key_list_port_p[0]) *
                                            (TELE_IMPL_MAX_PG_TC_COUNT + 1));
    if (key_list_port_p == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for the lag threshold key list, err: %s\n",
                   sx_status_str(rc));
        goto out;
    }
    SX_MEM_CLR_ARRAY(key_list_port_p, TELE_IMPL_MAX_PG_TC_COUNT + 1, sx_tele_threshold_key_t);

    filter.port_filter = port_log_id;
    filter.port_filter_valid = SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E;

    rc = sdk_tele_impl_threshold_iter_get(SX_ACCESS_CMD_GET_FIRST,
                                          key,
                                          filter,
                                          key_list_port_p,
                                          &key_cnt_port);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("sdk_tele_impl_threshold_iter_get failed. err = %s\n", sx_status_str(rc));
        goto out;
    }
    filter.port_filter = lag_port_log_id;
    rc = sdk_tele_impl_threshold_iter_get(SX_ACCESS_CMD_GET_FIRST,
                                          key,
                                          filter,
                                          key_list_lag_p,
                                          &key_cnt_lag);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("sdk_tele_impl_threshold_iter_get failed. err = %s\n", sx_status_str(rc));
        goto out;
    }
    if (key_cnt_lag != key_cnt_port) {
        SX_LOG_ERR(
            "port [0x%x] attributes does not comply with lag [0x%x] - different amount of enabled TC|PG's. port: %d, lag: %d",
            port_log_id,
            lag_port_log_id,
            key_cnt_port,
            key_cnt_lag);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    for (i = 0; i < key_cnt_lag; i++) {
        if (key_list_lag_p[i].key_type != key_list_port_p[i].key_type) {
            SX_LOG_ERR(
                "threshold key types for port [0x%x] and lag [0x%x] do not match. port key type: %u, lag key type: %u\n",
                port_log_id,
                lag_port_log_id,
                key_list_lag_p[i].key_type,
                key_list_port_p[i].key_type);
        }
        switch (key_list_lag_p[i].key_type) {
        case SX_TELE_THRESHOLD_TYPE_PORT_TC_E:
            if (key_list_lag_p[i].key.port_tc.tc != key_list_port_p[i].key.port_tc.tc) {
                SX_LOG_ERR(
                    "port [0x%x] threshold attributes does not comply with lag [0x%x] - different threshold TC's enabled. lag TC: %u, port TC: %u\n",
                    port_log_id,
                    lag_port_log_id,
                    key_list_lag_p[i].key.port_tc.tc,
                    key_list_port_p[i].key.port_tc.tc);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            break;

        case SX_TELE_THRESHOLD_TYPE_PORT_PG_E:
            if (key_list_lag_p[i].key.port_pg.pg != key_list_port_p[i].key.port_pg.pg) {
                SX_LOG_ERR(
                    "port [0x%x] threshold attributes does not comply with lag [0x%x] - different threshold PG's enabled. lag PG: %u, port PG: %u\n",
                    port_log_id,
                    lag_port_log_id,
                    key_list_lag_p[i].key.port_pg.pg,
                    key_list_port_p[i].key.port_pg.pg);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            break;

        default:
            SX_LOG_ERR("key type %u not supported\n",
                       key_list_lag_p[i].key_type);
            goto out;
        }
        /* get port data */
        key = key_list_port_p[i];
        rc = sdk_tele_impl_threshold_get(SX_ACCESS_CMD_GET,
                                         key,
                                         &data_port);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("sdk_tele_impl_threshold_get failed. rc = %s\n", sx_status_str(rc));
            goto out;
        }
        /* get lag data */
        key = key_list_lag_p[i];
        rc = sdk_tele_impl_threshold_get(SX_ACCESS_CMD_GET,
                                         key,
                                         &data_lag);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("sdk_tele_impl_threshold_get failed. rc = %s\n", sx_status_str(rc));
            goto out;
        }

        if (data_lag.threshold_data_type != data_port.threshold_data_type) {
            SX_LOG_ERR(
                "threshold data types for port [0x%x] and lag [0x%x] do not match. port data type: %u, lag data type: %u\n",
                port_log_id,
                lag_port_log_id,
                data_port.threshold_data_type,
                data_lag.threshold_data_type);
        }
        switch (data_lag.data_type) {
        case SX_TELE_THRESHOLD_DATA_TYPE_INVALID_E:
            if (data_lag.data.port_tc_threshold != data_port.data.port_tc_threshold) {
                SX_LOG_ERR(
                    "port attributes does not comply with lag - different threshold values or types. "
                    "port threshold: %d, port threshold type: %d, lag threshold: %d, lag threshold type: %d\n",
                    data_port.data.port_tc_threshold,
                    data_port.data_type,
                    data_lag.data.port_tc_threshold,
                    data_lag.data_type);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            break;

        case SX_TELE_THRESHOLD_DATA_TYPE_STATIC_E:
        case SX_TELE_THRESHOLD_DATA_TYPE_PERCENTAGE_E:
            if ((data_lag.threshold_data.threshold_high != data_port.threshold_data.threshold_high) ||
                (data_lag.threshold_data.threshold_low != data_port.threshold_data.threshold_low)) {
                SX_LOG_ERR(
                    "port attributes does not comply with lag - different threshold values or types. "
                    "port threshold (high, low): (%d, %d), port threshold type: %d, lag threshold (high, low): (%d, %d), lag threshold type: %d\n",
                    data_port.threshold_data.threshold_high,
                    data_port.threshold_data.threshold_low,
                    data_port.threshold_data_type,
                    data_lag.threshold_data.threshold_high,
                    data_lag.threshold_data.threshold_low,
                    data_lag.threshold_data_type);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            break;

        default:
            SX_LOG_ERR("data type %u not supported\n", data_lag.data_type);
            goto out;
        }
    }

out:
    if (key_list_lag_p != NULL) {
        CL_FREE_N_NULL(key_list_lag_p);
    }
    if (key_list_port_p != NULL) {
        CL_FREE_N_NULL(key_list_port_p);
    }
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __latency_thresholds_port_add_to_lag_validation(const sx_port_log_id_t lag_port_log_id,
                                                                   const sx_port_log_id_t port_log_id)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_tele_threshold_key_t           *port_key_list_p = NULL;
    sx_tele_threshold_data_t          *port_data_list_p = NULL;
    sx_tele_threshold_key_t           *lag_key_list_p = NULL;
    sx_tele_threshold_data_t          *lag_data_list_p = NULL;
    uint32_t                           i = 0;
    uint32_t                           port_total_cnt = rm_resource_global.cos_port_ets_traffic_class_max;
    uint32_t                           lag_total_cnt = rm_resource_global.cos_port_ets_traffic_class_max;
    sx_tele_latency_threshold_filter_t filter;

    SX_LOG_ENTER();

    SX_MEM_CLR(filter);

    err = utils_memory_get((void**)&port_key_list_p,
                           port_total_cnt * sizeof(sx_tele_threshold_key_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_key_list_p , err = %s\n", sx_status_str(err));
        goto out;
    }

    err = utils_memory_get((void**)&port_data_list_p,
                           port_total_cnt * sizeof(sx_tele_threshold_data_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_data_list_p , err = %s\n", sx_status_str(err));
        goto out;
    }

    err = utils_memory_get((void**)&lag_key_list_p,
                           lag_total_cnt * sizeof(sx_tele_threshold_key_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for lag_key_list_p , err = %s\n", sx_status_str(err));
        goto out;
    }

    err = utils_memory_get((void**)&lag_data_list_p,
                           lag_total_cnt * sizeof(sx_tele_threshold_data_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for lag_data_list_p , err = %s\n", sx_status_str(err));
        goto out;
    }

    filter.port_filter_valid = TRUE;
    filter.port_filter = port_log_id;

    err =
        sdk_tele_db_latency_threshold_key_iter_get_first(&filter, port_key_list_p, port_data_list_p, &port_total_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get latency thresholds entries from DB, [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    filter.port_filter = lag_port_log_id;
    err = sdk_tele_db_latency_threshold_key_iter_get_first(&filter, lag_key_list_p, lag_data_list_p, &lag_total_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get latency thresholds entries from DB, [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    if (lag_total_cnt != port_total_cnt) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Fail to validate latency threshold: lag 0x%x has %d thresholds, port 0x%x has %d thresholds\n",
                   lag_port_log_id, lag_total_cnt, port_log_id, port_total_cnt);
        goto out;
    }

    for (i = 0; i < lag_total_cnt; i++) {
        if (lag_key_list_p[i].key.port_tc.tc != port_key_list_p[i].key.port_tc.tc) {
            SX_LOG_ERR(
                "port [0x%x] latency threshold attributes does not comply with lag [0x%x] - "
                "different threshold TC's enabled. lag TC: %u, port TC: %u\n",
                port_log_id,
                lag_port_log_id,
                lag_key_list_p[i].key.port_tc.tc,
                port_key_list_p[i].key.port_tc.tc);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (lag_data_list_p[i].threshold_data.threshold_high != port_data_list_p[i].threshold_data.threshold_high) {
            SX_LOG_ERR(
                "port 0x%x attributes does not comply with lag 0x%x - different threshold values. "
                "port: threshold (%d) threshold type (%d), lag: threshold (%d), threshold type (%d)\n",
                port_log_id, lag_port_log_id,
                port_data_list_p[i].threshold_data.threshold_high,
                port_data_list_p[i].threshold_data_type,
                lag_data_list_p[i].threshold_data.threshold_high,
                lag_data_list_p[i].threshold_data_type);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    if (port_key_list_p) {
        utils_memory_put(port_key_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    if (port_data_list_p) {
        utils_memory_put(port_data_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    if (lag_key_list_p) {
        utils_memory_put(lag_key_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    if (lag_data_list_p) {
        utils_memory_put(lag_data_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __align_thresholds(const sx_port_log_id_t lag_port, const sx_port_log_id_t network_port)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_tele_threshold_key_t    key, *port_key_list_p = NULL;
    sx_tele_threshold_data_t   data;
    sx_tele_threshold_filter_t filter;
    uint32_t                   i = 0, key_cnt = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(key);
    SX_MEM_CLR(data);
    SX_MEM_CLR(filter);

    err = utils_memory_get((void**)&port_key_list_p,
                           TELE_IMPL_MAX_PG_TC_COUNT * sizeof(sx_tele_threshold_key_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_key_list , err = %s\n", sx_status_str(err));
        goto out;
    }

    filter.port_filter_valid = SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E;
    filter.port_filter = lag_port;

    key_cnt = TELE_IMPL_MAX_PG_TC_COUNT;
    err = sdk_tele_db_threshold_iter_get_first(&filter, port_key_list_p, NULL, &key_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get thresholds entries in HWI DB, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    for (i = 0; i < key_cnt; i++) {
        key = port_key_list_p[i];
        err = sdk_tele_db_threshold_get(key, &data);
        if (err == SX_STATUS_SUCCESS) {
            sdk_tele_impl_threshold_key_log_port_set(&key, network_port);
            err = sdk_tele_db_threshold_add(key, data);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to add threshold , error: %s\n", sx_status_str(err));
                goto out;
            }
        } else if (err != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("Failed to retrieve threshold , error: %s\n", sx_status_str(err));
            goto out;
        }
        err = SX_STATUS_SUCCESS;
    }

out:
    if (port_key_list_p) {
        utils_memory_put(port_key_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __align_latency_thresholds(const sx_port_log_id_t lag_port, const sx_port_log_id_t log_port)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_tele_threshold_key_t            key, *port_key_list_p = NULL;
    sx_tele_threshold_data_t          *port_data_list_p = NULL;
    sx_tele_latency_threshold_filter_t filter;
    uint32_t                           i = 0, total_cnt = rm_resource_global.cos_port_ets_traffic_class_max;
    uint8_t                            latency_id = 0;
    boolean_t                          is_new = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(key);
    SX_MEM_CLR(filter);

    err = utils_memory_get((void**)&port_key_list_p,
                           total_cnt * sizeof(sx_tele_threshold_key_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_key_list, err = %s\n", sx_status_str(err));
        goto out;
    }
    err = utils_memory_get((void**)&port_data_list_p,
                           total_cnt * sizeof(sx_tele_threshold_data_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_data_list, err = %s\n", sx_status_str(err));
        goto out;
    }

    filter.port_filter_valid = TRUE;
    filter.port_filter = lag_port;

    err = sdk_tele_db_latency_threshold_key_iter_get_first(&filter, port_key_list_p, port_data_list_p, &total_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get latency thresholds entries from DB. [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    for (i = 0; i < total_cnt; i++) {
        err = sdk_tele_db_latency_threshold_data_alloc(port_data_list_p[i], &latency_id, &is_new);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to update latency data entry in DB. [%s]\n",
                       sx_status_str(err));
            goto out;
        }
        key = port_key_list_p[i];
        sdk_tele_impl_threshold_key_log_port_set(&key, log_port);
        err = sdk_tele_db_latency_threshold_key_add(key, port_data_list_p[i]);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to add latency key entry to DB. [%s]\n",
                       sx_status_str(err));
            goto out;
        }
    }

out:
    if (port_key_list_p) {
        utils_memory_put(port_key_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    if (port_data_list_p) {
        utils_memory_put(port_data_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __remove_thresholds(const sx_port_log_id_t port)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_tele_threshold_key_t    key, *port_key_list_p = NULL;
    sx_tele_threshold_data_t   data;
    uint32_t                   i = 0, key_cnt = 0;
    sx_tele_threshold_filter_t filter;

    SX_LOG_ENTER();
    SX_MEM_CLR(key);
    SX_MEM_CLR(data);
    SX_MEM_CLR(filter);

    err = utils_memory_get((void**)&port_key_list_p,
                           TELE_IMPL_MAX_PG_TC_COUNT * sizeof(sx_tele_threshold_key_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_key_list , err = %s\n", sx_status_str(err));
        goto out;
    }

    filter.port_filter_valid = SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E;
    filter.port_filter = port;

    key_cnt = TELE_IMPL_MAX_PG_TC_COUNT;
    err = sdk_tele_db_threshold_iter_get_first(&filter, port_key_list_p, NULL, &key_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get thresholds entries in HWI DB, err= %s.\n",
                   sx_status_str(err));
        goto out;
    }

    for (i = 0; i < key_cnt; i++) {
        err = sdk_tele_db_threshold_delete(port_key_list_p[i]);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to add threshold , error: %s\n", sx_status_str(err));
            goto out;
        }
    }

out:
    if (port_key_list_p) {
        utils_memory_put(port_key_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __remove_latency_thresholds(const sx_port_log_id_t log_port)
{
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_tele_threshold_key_t           *port_key_list_p = NULL;
    sx_tele_threshold_data_t          *port_data_list_p = NULL;
    uint32_t                           i = 0, total_cnt = rm_resource_global.cos_port_ets_traffic_class_max;
    sx_tele_latency_threshold_filter_t filter;

    SX_LOG_ENTER();

    SX_MEM_CLR(filter);

    err = utils_memory_get((void**)&port_key_list_p,
                           total_cnt * sizeof(sx_tele_threshold_key_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_key_list , err = %s\n", sx_status_str(err));
        goto out;
    }

    err = utils_memory_get((void**)&port_data_list_p,
                           total_cnt * sizeof(sx_tele_threshold_data_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_key_list , err = %s\n", sx_status_str(err));
        goto out;
    }

    filter.port_filter_valid = TRUE;
    filter.port_filter = log_port;

    err = sdk_tele_db_latency_threshold_key_iter_get_first(&filter, port_key_list_p, port_data_list_p, &total_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get latency thresholds entries from DB, [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    for (i = 0; i < total_cnt; i++) {
        err = sdk_tele_db_latency_threshold_data_free(port_data_list_p[i]);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Fail to free latency threshold data. [%s]\n",
                       sx_status_str(err));
            goto out;
        }
        err = sdk_tele_db_latency_threshold_key_delete(port_key_list_p[i]);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to delete latency threshold. [%s]\n", sx_status_str(err));
            goto out;
        }
    }

out:
    if (port_key_list_p) {
        utils_memory_put(port_key_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    if (port_data_list_p) {
        utils_memory_put(port_data_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __convert_adjusted_key(sx_tele_threshold_key_t in_key, sx_tele_threshold_key_t *out_key_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    uint8_t          lag_member = 0;
    sx_port_id_t     lag_port = 0;
    sx_port_log_id_t log_port = 0;

    SX_LOG_ENTER();

    SX_MEM_CPY_P(out_key_p, &in_key);

    if ((in_key.key_type != SX_TELE_THRESHOLD_TYPE_PORT_TC_E) &&
        (in_key.key_type != SX_TELE_THRESHOLD_TYPE_PORT_PG_E) &&
        (in_key.key_type != SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E)) {
        goto out;
    }

    sdk_tele_impl_threshold_key_log_port_get(in_key, &log_port);

    err = port_lag_member_state_get(SX_ACCESS_CMD_GET, log_port, &lag_member);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve if port (0x%x) is lag member (%s)\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    if (lag_member) {
        err = port_lag_log_port_get(SX_ACCESS_CMD_GET, log_port, &lag_port);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("failed in port_lag_log_port_get. error %s.\n", sx_status_str(err));
            goto out;
        }
        sdk_tele_impl_threshold_key_log_port_set(out_key_p, lag_port);
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t tele_impl_threshold_key_validation(const sx_tele_threshold_key_t key)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = g_ops.hwd_tele_threshold_key_validation_pfn(key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("threshold key validation failed, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t tele_impl_threshold_data_validation(const sx_tele_threshold_key_t key, const sx_tele_threshold_data_t data)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = g_ops.hwd_tele_threshold_data_validation_pfn(key, data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("threshold data validation failed, err = %s.\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}
sx_status_t sdk_tele_impl_threshold_issu_set()
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_status_t           deinit_err = SX_STATUS_SUCCESS;
    sx_tele_init_params_t tele_init_params;
    boolean_t             tele_deinit = FALSE;
    boolean_t             tele_initialised = FALSE;

    SX_LOG_ENTER();

    /* coverity[bad_memset] */
    SX_MEM_CLR(tele_init_params);

    err = sdk_tele_impl_params_get(&tele_initialised);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get tele params, err = %s\n", sx_status_str(err));
        goto out;
    }
    if (!tele_initialised) {
        err = sdk_tele_init_wrapper(&tele_init_params);
        if (err == SX_STATUS_CMD_UNSUPPORTED) {
            SX_LOG_INF("NO need to handle Tele on this setup\n");
            err = SX_STATUS_SUCCESS;
            goto out;
        }

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to init tele module, err = %s\n", sx_status_str(err));
            goto out;
        }
        tele_deinit = TRUE;
    }

    err = __sdk_tele_impl_threshold_congestion_issu_set();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to implement congestion threshold issu set, err = %s\n", sx_status_str(err));
        goto out;
    }

    err = __sdk_tele_impl_threshold_latency_issu_set();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to implement latency threshold issu set, err = %s\n", sx_status_str(err));
        goto out;
    }
out:
    if (tele_deinit) {
        deinit_err = sdk_tele_deinit_wrapper(FALSE);
        if (SX_CHECK_FAIL(deinit_err)) {
            SX_LOG_ERR("Failed to deinit tele module, err = %s\n", sx_status_str(err));
            err = deinit_err;
        }
    }

    return err;
}

static sx_status_t __sdk_tele_impl_threshold_latency_issu_set()
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    uint8_t                   lag_member = 0;
    uint32_t                  port_list_cnt = 0;
    sx_port_log_id_t         *log_port_list = NULL;
    uint32_t                  j = 0;
    sx_tele_threshold_key_t   key;
    uint32_t                  tc = 0;
    sx_tele_threshold_data_t  disable_data;
    sx_tele_threshold_data_t *data_p = NULL;
    uint32_t                  sp = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(key);
    SX_MEM_CLR(disable_data);

    if (g_ops.hwd_tele_threshold_latency_bind_pfn == NULL) {
        err = SX_STATUS_SUCCESS;
        SX_LOG_DBG("hwd_tele_threshold_latency configuration ops not supported for this chip type %s.\n",
                   sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
        goto out;
    }

    /* Get ports count to allocate log_port_list */
    err = port_swid_get(SX_ACCESS_CMD_COUNT, 0, NULL, &port_list_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get port list count, err: %s\n", sx_status_str(err));
        goto out;
    }
    err = utils_memory_get((void**)&log_port_list,
                           port_list_cnt * sizeof(sx_port_log_id_t),
                           UTILS_MEM_TYPE_ID_PORT_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_list , err = %s\n", sx_status_str(err));
        goto out;
    }

    /* Get ports */
    err = port_swid_get(SX_ACCESS_CMD_GET, 0, log_port_list, &port_list_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get port list, err: %s\n", sx_status_str(err));
        goto out;
    }

    key.key_type = SX_TELE_THRESHOLD_TYPE_LATENCY_PORT_TC_E;
    for (j = 0; j < port_list_cnt; j++) {
        /* lag members updated when iterating on their lag port */
        err = port_lag_member_state_get(SX_ACCESS_CMD_GET, log_port_list[j], &lag_member);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve if port (0x%x) is lag member (%s)\n",
                       log_port_list[j], sx_status_str(err));
            goto out;
        }
        if (lag_member) {
            continue;
        }

        key.key.port_tc.log_port = log_port_list[j];
        for (tc = 0; tc <= rm_resource_global.cos_port_ets_traffic_class_max; tc++) {
            key.key.port_tc.tc = tc;
            err = sdk_tele_db_latency_threshold_key_get(key, data_p);
            if (SX_CHECK_FAIL(err) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
                SX_LOG_ERR("Failed to lookup threshold key. [%s] \n", sx_status_str(err));
                goto out;
            }
            if (err == SX_STATUS_ENTRY_NOT_FOUND) {
                err = __latency_threshold_port_tc_hw_set(key, TELE_TRESHOLD_LATENCY_DISABLE_ID);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to disable latency threshold. [%s] \n", sx_status_str(err));
                    goto out;
                }
            }
        }
    }

    key.key_type = SX_TELE_THRESHOLD_TYPE_LATENCY_MC_SP_E;
    for (sp = 0; sp <= rm_resource_global.cos_port_prio_max; sp++) {
        key.key.mc_sp.sp = sp;
        err = sdk_tele_db_latency_threshold_key_get(key, data_p);
        if (SX_CHECK_FAIL(err) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
            SX_LOG_ERR("Failed to lookup threshold key. [%s] \n", sx_status_str(err));
            goto out;
        }
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            err = __latency_threshold_mc_hw_set(key, TELE_TRESHOLD_LATENCY_DISABLE_ID);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to disable latency threshold. [%s] \n", sx_status_str(err));
                goto out;
            }
        }
    }


out:
    if (log_port_list) {
        utils_memory_put(log_port_list, UTILS_MEM_TYPE_ID_PORT_E);
    }
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __sdk_tele_impl_threshold_congestion_issu_set()
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_tele_threshold_filter_t filter;
    uint32_t                   total_tc_pg_cnt = 0;
    uint32_t                   j = 0;
    uint8_t                   *tc_pg_list_p = NULL;
    sx_tele_threshold_key_t   *port_key_list_p = NULL;
    uint32_t                   port_list_cnt = 0;
    sx_port_log_id_t          *log_port_list = NULL;
    sx_port_log_id_t          *port_list_p = NULL;
    length_t                   port_cnt = 0;
    uint8_t                    lag_member = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(filter);

    /* Allocate memory */
    err = utils_memory_get((void**)&port_key_list_p,
                           TELE_IMPL_MAX_PG_TC_COUNT * sizeof(sx_tele_threshold_key_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_list , err = %s\n", sx_status_str(err));
        goto out;
    }
    err = utils_memory_get((void**)&tc_pg_list_p,
                           TELE_IMPL_MAX_PG_TC_COUNT * sizeof(uint8_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for tc_list , err = %s\n", sx_status_str(err));
        goto out;
    }
    err = utils_memory_get((void**)&port_list_p,
                           rm_resource_global.lag_port_members_max * sizeof(sx_port_log_id_t),
                           UTILS_MEM_TYPE_ID_TELEMETRY_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_list , err = %s\n", sx_status_str(err));
        goto out;
    }
    /* Get ports count to allocate log_port_list */
    err = port_swid_get(SX_ACCESS_CMD_COUNT, 0, NULL, &port_list_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get port list count, err: %s\n", sx_status_str(err));
        goto out;
    }
    err = utils_memory_get((void**)&log_port_list,
                           port_list_cnt * sizeof(sx_port_log_id_t),
                           UTILS_MEM_TYPE_ID_PORT_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate memory for port_list , err = %s\n", sx_status_str(err));
        goto out;
    }

    /* Get ports */
    err = port_swid_get(SX_ACCESS_CMD_GET, 0, log_port_list, &port_list_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get port list, err: %s\n", sx_status_str(err));
        goto out;
    }

    /* Get threshold for each log_port in the DB and then set HW for each port */
    filter.port_filter_valid = SX_TELE_THRESHOLD_KEY_PORT_FILTER_VALID_E;

    for (j = 0; j < port_list_cnt; j++) {
        /* Lag members updated when iterating on their lag port */
        err = port_lag_member_state_get(SX_ACCESS_CMD_GET, log_port_list[j], &lag_member);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve if port (0x%x) is lag member (%s)\n",
                       log_port_list[j], sx_status_str(err));
            goto out;
        }
        if (lag_member) {
            continue;
        }

        /* Get log port's threshold keys */
        total_tc_pg_cnt = TELE_IMPL_MAX_PG_TC_COUNT;
        filter.port_filter = log_port_list[j];
        err = sdk_tele_db_threshold_iter_get_first(&filter, port_key_list_p, NULL, &total_tc_pg_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get thresholds entries in HWI DB, err= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        port_cnt = rm_resource_global.lag_port_members_max;
        err = port_list_from_log_port_get(log_port_list[j], port_list_p, &port_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("port_list_from_log_port_get failed , err = %s\n", sx_status_str(err));
            goto out;
        }

        err = __congestion_threshold_issu_set(SX_TELE_THRESHOLD_TYPE_PORT_TC_E,
                                              port_list_p,
                                              port_cnt,
                                              port_key_list_p,
                                              total_tc_pg_cnt,
                                              tc_pg_list_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set congestion issu on TC, err = %s\n", sx_status_str(err));
            goto out;
        }

        err = sdk_tele_impl_threshold_port_pg_issu_set_wrapper(port_list_p,
                                                               port_cnt,
                                                               port_key_list_p,
                                                               total_tc_pg_cnt,
                                                               tc_pg_list_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("tele_threshold_on_pg_issu_set_wrapper failed, err = %s\n", sx_status_str(err));
            goto out;
        }
    }
out:
    if (port_key_list_p) {
        utils_memory_put(port_key_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    if (tc_pg_list_p) {
        utils_memory_put(tc_pg_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    if (log_port_list) {
        utils_memory_put(log_port_list, UTILS_MEM_TYPE_ID_PORT_E);
    }
    if (port_list_p) {
        utils_memory_put(port_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __congestion_threshold_issu_set(const sx_port_threshold_type_e port_type,
                                                   const sx_port_log_id_t        *port_list_p,
                                                   const uint32_t                 port_cnt,
                                                   const sx_tele_threshold_key_t *port_key_list_p,
                                                   const uint8_t                  key_cnt,
                                                   sx_cos_traffic_class_t        *tc_pg_list_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_tele_threshold_data_t        data;
    uint32_t                        tc_pg_cnt = 0;
    uint32_t                        k = 0;
    uint32_t                        i = 0;
    tele_threshold_direction_type_e dir = TELE_THRESHOLD_DIRECTION_EGRESS_E;
    sx_tele_threshold_key_t         key;

    SX_LOG_ENTER();

    SX_MEM_CLR(data);
    SX_MEM_CLR(key);

    if (!port_cnt) {
        SX_LOG_INF("Setting congestion threshold on empty LAG\n");
        goto out;
    }
    key.key_type = port_type;
    switch (port_type) {
    case SX_TELE_THRESHOLD_TYPE_PORT_TC_E:
        for (i = 0; i < key_cnt; i++) {
            if (port_key_list_p[i].key_type == SX_TELE_THRESHOLD_TYPE_PORT_TC_E) {
                tc_pg_list_p[tc_pg_cnt] = port_key_list_p[i].key.port_tc.tc;
                tc_pg_cnt++;
            }
        }
        key.key.port_tc.log_port = port_list_p[0];

        break;

    case SX_TELE_THRESHOLD_TYPE_PORT_PG_E:
        for (i = 0; i < key_cnt; i++) {
            if (port_key_list_p[i].key_type == SX_TELE_THRESHOLD_TYPE_PORT_PG_E) {
                tc_pg_list_p[tc_pg_cnt] = port_key_list_p[i].key.port_pg.pg;
                tc_pg_cnt++;
            }
        }
        dir = TELE_THRESHOLD_DIRECTION_INGRESS_E;
        key.key.port_pg.log_port = port_list_p[0];
        break;

    default:
        break;
    }

    if (tc_pg_cnt) {
        err = sdk_tele_db_last_congestion_threshold_data_get(&key, &data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get issu congestion data, err: %s\n", sx_status_str(err));
            goto out;
        }
    }

    for (k = 0; k < port_cnt; k++) {
        err = g_ops.hwd_tele_threshold_edit_pfn(port_list_p[k],
                                                dir,
                                                tc_pg_list_p,
                                                tc_pg_cnt,
                                                data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to configure HW, err = %s\n", sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_threshold_port_pg_issu_set_wrapper(const sx_port_log_id_t        *port_list_p,
                                                             const uint32_t                 port_cnt,
                                                             const sx_tele_threshold_key_t *port_key_list_p,
                                                             const uint8_t                  key_cnt,
                                                             sx_cos_traffic_class_t        *pg_list_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.tele_threshold_port_pg_issu_set_cb != NULL) {
        err = brg_context.spec_cb_g.tele_threshold_port_pg_issu_set_cb(port_list_p,
                                                                       port_cnt,
                                                                       port_key_list_p,
                                                                       key_cnt,
                                                                       pg_list_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("tele threshold set port PG callback failed, err = %s\n", sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}
sx_status_t sdk_tele_impl_threshold_port_pg_issu_set(const sx_port_log_id_t        *port_list_p,
                                                     const uint32_t                 port_cnt,
                                                     const sx_tele_threshold_key_t *port_key_list_p,
                                                     const uint8_t                  key_cnt,
                                                     uint8_t                       *pg_list_p)
{
    return __congestion_threshold_issu_set(SX_TELE_THRESHOLD_TYPE_PORT_PG_E,
                                           port_list_p,
                                           port_cnt,
                                           port_key_list_p,
                                           key_cnt,
                                           pg_list_p);
}

sx_status_t sdk_tele_init_wrapper(const sx_tele_init_params_t *params_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.tele_init_cb != NULL) {
        rc = brg_context.spec_cb_g.tele_init_cb(params_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("sdk_tele_init failed, for chip type %s, err = %s\n",
                       sx_chip_type_str((int)brg_context.spec_cb_g.dev_type), sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_INF("sdk_tele_init is not supported for this chip type (%s), err = %s.\n",
                   sx_chip_type_str((int)brg_context.spec_cb_g.dev_type), sx_status_str(rc));
        goto out;
    }

out:
    return rc;
}

sx_status_t sdk_tele_deinit_wrapper(boolean_t is_forced)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.tele_deinit_cb != NULL) {
        rc = brg_context.spec_cb_g.tele_deinit_cb(is_forced);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("sdk_tele_deinit failed, for chip type %s, err = %s\n",
                       sx_chip_type_str((int)brg_context.spec_cb_g.dev_type), sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_INF("sdk_tele_deinit is not supported for this chip type (%s), err = %s.\n",
                   sx_chip_type_str((int)brg_context.spec_cb_g.dev_type), sx_status_str(rc));
        goto out;
    }

out:
    return rc;
}

sx_status_t sdk_tele_impl_histogram_delete_all(boolean_t is_forced)
{
    sx_status_t                         sx_status = SX_STATUS_SUCCESS;
    sx_tele_histogram_key_t             tele_key;
    sx_tele_histogram_attributes_data_t tele_data;
    boolean_t                           tele_initialised = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(tele_key);
    SX_MEM_CLR(tele_data);

    sx_status = sdk_tele_impl_params_get(&tele_initialised);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to get tele params, err = %s\n", sx_status_str(sx_status));
        goto out;
    }
    if (!tele_initialised) {
        if (!is_forced) {
            sx_status = SX_STATUS_MODULE_UNINITIALIZED;
            SX_LOG_ERR("failed to delete all histograms, err = %s\n", sx_status_str(sx_status));
            goto out;
        }
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    } else {
        sx_status = sdk_tele_impl_histogram_set(SX_ACCESS_CMD_DELETE_ALL, tele_key, tele_data);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("failed to delete histograms, err = %s\n", sx_status_str(sx_status));
            goto out;
        }

        if (g_ops.hwd_tele_port_bw_gauge_set_pfn != NULL) {
            /* return port bw gauge to default values*/
            sx_status = sdk_tele_impl_port_bw_gauge_set(SX_ACCESS_CMD_DESTROY, NULL);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("failed to return port bw gauge to default values, err = %s\n", sx_status_str(sx_status));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tele_impl_attributes_set(sx_tele_attrib_t attr, sx_port_id_t *port)
{
    sx_status_t  sx_status = SX_STATUS_SUCCESS;
    sx_swid_id_t swid = 0;

    SX_LOG_ENTER();

    if (FALSE == g_is_tele_initialized) {
        goto out;
    }
    if ((attr.internal_ts_enable != g_tele_attrib.internal_ts_enable) || (port != NULL)) {
        if (brg_context.spec_cb_g.tele_set_attr_port_validation_cb != NULL) {
            sx_status = brg_context.spec_cb_g.tele_set_attr_port_validation_cb(&attr, swid);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("hwd_tele_attr_set_port_validation_cb failed.\n");
                goto out;
            }
        }

        if (g_ops.hwd_tele_attr_set_pfn != NULL) {
            sx_status = g_ops.hwd_tele_attr_set_pfn(attr, port, swid);
            if (SX_CHECK_FAIL(sx_status)) {
                SX_LOG_ERR("Failed to set telemetry attributes, err: %s \n", sx_status_str(sx_status));
                goto out;
            }
            g_tele_attrib.internal_ts_enable = attr.internal_ts_enable;
        } else {
            SX_LOG_INF("Telemetry attributes are not supported, err: %s \n", sx_status_str(sx_status));
        }
    }

    /* set tac_attr only for global configuration (port == NULL) */
    if ((attr.tac_attr_valid == TRUE) && __is_tac_attr_changed(&attr)) {
        sx_status = __tele_impl_tac_attr_set(&attr.tac_attr);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to set telemetry tac attributes, err: %s \n", sx_status_str(sx_status));
            goto out;
        }
        g_tele_attrib.tac_attr_valid = attr.tac_attr_valid;
        g_tele_attrib.tac_attr = attr.tac_attr;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_tele_impl_attributes_get(sx_tele_attrib_t *attr_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(*attr_p, g_tele_attrib);

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t tele_set_attr_port_validation_spectrum4(const sx_tele_attrib_t *attr, const sx_swid_id_t swid)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint16_t    num_ports_logical_lb = 0;

    /* internal_ts_enable cannot be enabled on port when configured phys LOGICAL (LLU) loopback
     * Before we enable ts_over_crc we need to validate no ports in swid are configured LOGICAL loopback*/
    if (SX_TS_OVER_CRC_INGRESS_MODE_ENABLE_E == attr->internal_ts_enable) {
        sx_status = port_phys_logical_lb_cntr_get(swid, &num_ports_logical_lb);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to retrieve swid[%d] num_ports_logical_lb counter  \n", swid);
            goto out;
        }

        if (num_ports_logical_lb) {
            sx_status = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Can't enable internal_ts_enable. SWID #%d has %d ports that enabled phys LOGICAL loopback\n",
                       swid,
                       num_ports_logical_lb);
            goto out;
        }
    }

out:
    return sx_status;
}

sx_status_t sdk_tele_impl_is_hash_sig_supported(boolean_t *is_hash_sig_supported)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (is_hash_sig_supported == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *is_hash_sig_supported = FALSE;

    /* check if hash signature is supported */
    if (g_ops.hwd_tele_hash_sig_prof_set_pfn != NULL) {
        *is_hash_sig_supported = TRUE;
    }

out:
    return err;
}

static sx_status_t __tele_impl_hash_sig_init(void)
{
    sx_status_t                        err = SX_STATUS_SUCCESS, err2;
    sx_tele_hash_sig_field_enable_t   *enables_list_p = NULL;
    uint32_t                           enables_list_cnt;
    sx_tele_hash_sig_params_t          hash_params;
    sx_tele_hash_sig_classifier_attr_t hash_sig_prof_classifier;
    sx_tele_hash_sig_prof_idx_int_t    hash_sig_prof_idx;
    uint32_t                           fields_list_cnt, i;
    sx_tele_hash_sig_field_t           fields_list[] = {
        SX_TELE_HASH_SIG_OUTER_SMAC,
        SX_TELE_HASH_SIG_OUTER_DMAC,
        SX_TELE_HASH_SIG_OUTER_ETHERTYPE,
        SX_TELE_HASH_SIG_OUTER_OVID
    };

    /* check if hash signature is supported */
    if (g_ops.hwd_tele_hash_sig_prof_set_pfn == NULL) {
        /* if not , return success */
        goto out;
    }

    hash_params.symmetric_hash_outer = FALSE;
    hash_params.symmetric_hash_inner = FALSE;
    hash_params.symmetric_hash_gp_reg = FALSE;

    memset(&hash_sig_prof_classifier, 0, sizeof(hash_sig_prof_classifier));
    hash_sig_prof_classifier.inner_l2_type_classifiers = SX_TELE_HASH_SIG_CLASSIFIER_L2_TYPE_ANY_E;
    hash_sig_prof_classifier.l3_type_classifiers = SX_TELE_HASH_SIG_CLASSIFIER_L3_TYPE_ANY_E;
    hash_sig_prof_classifier.inner_l3_type_classifiers = SX_TELE_HASH_SIG_CLASSIFIER_L3_TYPE_ANY_E;
    hash_sig_prof_classifier.ip_fragment_classifiers = SX_TELE_HASH_SIG_CLASSIFIER_IP_FRAGMENT_ANY_E;
    hash_sig_prof_classifier.inner_ip_fragment_classifiers = SX_TELE_HASH_SIG_CLASSIFIER_IP_FRAGMENT_ANY_E;
    hash_sig_prof_classifier.l4_type_classifiers = SX_TELE_HASH_SIG_CLASSIFIER_L4_TYPE_ANY_E;
    hash_sig_prof_classifier.inner_l4_type_classifiers = SX_TELE_HASH_SIG_CLASSIFIER_L4_TYPE_ANY_E;
    hash_sig_prof_classifier.tunnel_type_classifiers = SX_TELE_HASH_SIG_CLASSIFIER_TUNNEL_TYPE_ANY_E;
    hash_sig_prof_classifier.fpp_classifiers = SX_TELE_HASH_SIG_CLASSIFIER_FPP_ANY_E;
    hash_sig_prof_classifier.inner_fpp_classifiers = SX_TELE_HASH_SIG_CLASSIFIER_FPP_ANY_E;

    enables_list_cnt = SX_TELE_HASH_SIG_OUTER_FIELDS_ENABLE_NUM +
                       SX_TELE_HASH_SIG_INNER_FIELDS_ENABLE_NUM;
    M_UTILS_CLR_MEM_GET(&enables_list_p, 1,
                        (sizeof(sx_tele_hash_sig_field_enable_t) * enables_list_cnt),
                        UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to allocate memory for hash sig fields enables.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    for (i = 0; i < SX_TELE_HASH_SIG_OUTER_FIELDS_ENABLE_NUM; i++) {
        enables_list_p[i] = SX_TELE_HASH_SIG_OUTER_ENABLES_OFFSET + i;
    }

    for (i = 0; i < SX_TELE_HASH_SIG_INNER_FIELDS_ENABLE_NUM; i++) {
        enables_list_p[SX_TELE_HASH_SIG_OUTER_FIELDS_ENABLE_NUM + i] =
            SX_TELE_HASH_SIG_INNER_ENABLES_OFFSET + i;
    }

    fields_list_cnt = sizeof(fields_list) / sizeof(fields_list[0]);

    for (hash_sig_prof_idx = SX_TELE_HASH_SIG_PROF_INTERNAL_MIN;
         hash_sig_prof_idx <= SX_TELE_HASH_SIG_PROF_INTERNAL_MAX;
         hash_sig_prof_idx++) {
        err = __tele_impl_hash_sig_params_set(hash_sig_prof_idx,
                                              &hash_sig_prof_classifier,
                                              &hash_params,
                                              enables_list_p,
                                              enables_list_cnt,
                                              fields_list,
                                              fields_list_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR,
                   "Failed to set hash sig params of profile [%d]."
                   " hash_sig_prof_idx failed. err: [%s]\n",
                   hash_sig_prof_idx, sx_status_str(err));
            goto out;
        }
    }

out:
    if (NULL != enables_list_p) {
        M_UTILS_MEM_PUT(enables_list_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free enables arr", err2);
    }

    return err;
}

sx_status_t __tele_impl_hwd_hash_sig_params_set(const sx_tele_hash_sig_prof_idx_int_t     hash_sig_prof_idx,
                                                const sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_class_p,
                                                const sx_tele_hash_sig_params_t          *hash_params_p,
                                                const sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                                const uint32_t                            hash_field_enable_list_cnt,
                                                const sx_tele_hash_sig_field_t           *hash_field_list_p,
                                                const uint32_t                            hash_field_list_cnt)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_ops.hwd_tele_hash_sig_prof_set_pfn != NULL) {
        sx_status = g_ops.hwd_tele_hash_sig_prof_set_pfn(hash_sig_prof_idx, hash_sig_prof_class_p, hash_params_p,
                                                         hash_field_enable_list_p, hash_field_enable_list_cnt,
                                                         hash_field_list_p, hash_field_list_cnt);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to set telemetry hash signature attributes, err: %s \n", sx_status_str(sx_status));
            goto out;
        }
    } else {
        SX_LOG_INF("Telemetry hash signature are not supported, err: %s \n", sx_status_str(sx_status));
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __tele_impl_hash_sig_params_set(const sx_tele_hash_sig_prof_idx_int_t     hash_sig_prof_idx,
                                                   const sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_class_p,
                                                   const sx_tele_hash_sig_params_t          *hash_params_p,
                                                   const sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                                   const uint32_t                            hash_field_enable_list_cnt,
                                                   const sx_tele_hash_sig_field_t           *hash_field_list_p,
                                                   const uint32_t                            hash_field_list_cnt)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG("Set Hash Signature Params \n");

    err = __tele_impl_hwd_hash_sig_params_set(hash_sig_prof_idx,
                                              hash_sig_prof_class_p,
                                              hash_params_p,
                                              hash_field_enable_list_p,
                                              hash_field_enable_list_cnt,
                                              hash_field_list_p, hash_field_list_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "HWD hash sig params set failed: %s\n",
               sx_status_str(err));
        goto out;
    }

    err = sdk_tele_db_hash_sig_params_set(hash_sig_prof_idx,
                                          hash_sig_prof_class_p,
                                          hash_params_p,
                                          hash_field_enable_list_p,
                                          hash_field_enable_list_cnt,
                                          hash_field_list_p,
                                          hash_field_list_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "sdk_tele_db_hash_sig_params_set failed: %s\n",
               sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static int __hash_sig_field_cmp(const void* const left, const void* const right)
{
    return (*(sx_tele_hash_sig_field_t*)left - *(sx_tele_hash_sig_field_t*)right);
}

static int __hash_sig_field_enable_cmp(const void* const left, const void* const right)
{
    return (*(sx_tele_hash_sig_field_enable_t*)left - *(sx_tele_hash_sig_field_enable_t*)right);
}


static sx_status_t __tele_impl_hash_sig_params_add(const sx_tele_hash_sig_prof_idx_int_t  hash_sig_prof_idx,
                                                   const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                                   const uint32_t                         hash_field_enable_list_cnt,
                                                   const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                                   const uint32_t                         hash_field_list_cnt)
{
    sx_tele_hash_sig_field_enable_t   *curr_enables_p = NULL;
    sx_tele_hash_sig_field_enable_t   *merged_enables_p = NULL;
    sx_tele_hash_sig_field_enable_t   *new_enables_p = NULL;
    sx_tele_hash_sig_field_t          *curr_fields_p = NULL;
    sx_tele_hash_sig_field_t          *merged_fields_p = NULL;
    sx_tele_hash_sig_field_t          *new_fields_p = NULL;
    sx_tele_hash_sig_params_t          curr_hash_params;
    sx_tele_hash_sig_classifier_attr_t hash_sig_prof_classifier;
    uint32_t                           curr_enables_cnt = 0;
    uint32_t                           curr_fields_cnt = 0;
    uint32_t                           merged_enables_cnt = 0;
    uint32_t                           merged_fields_cnt = 0;
    uint32_t                           curr_field_idx = 0;
    uint32_t                           merged_field_idx = 0;
    uint32_t                           new_field_idx = 0;
    sx_status_t                        err = SX_STATUS_SUCCESS;
    sx_status_t                        out_err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    memset(&curr_hash_params, 0, sizeof(curr_hash_params));

    err = sdk_tele_db_hash_sig_params_get(hash_sig_prof_idx,
                                          &hash_sig_prof_classifier,
                                          &curr_hash_params,
                                          NULL,
                                          &curr_enables_cnt,
                                          NULL,
                                          &curr_fields_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Failed to get hash sig params of profile [%d]."
               " sdk_tele_db_hash_sig_params_get failed. err: [%s]\n",
               hash_sig_prof_idx, sx_status_str(err));
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&curr_enables_p, 1,
                        (sizeof(sx_tele_hash_sig_field_enable_t) * curr_enables_cnt),
                        UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to allocate memory for hash sig fields enables.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    M_UTILS_CLR_MEM_GET(&curr_fields_p, 1,
                        (sizeof(sx_tele_hash_sig_field_t) * curr_fields_cnt),
                        UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to allocate memory for hash sig fields.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = sdk_tele_db_hash_sig_params_get(hash_sig_prof_idx, &hash_sig_prof_classifier, &curr_hash_params,
                                          curr_enables_p, &curr_enables_cnt,
                                          curr_fields_p, &curr_fields_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Failed to get hash params of profile [%d]."
               " sdk_tele_db_hash_sig_params_get failed. err: [%s]\n",
               hash_sig_prof_idx, sx_status_str(err));
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&merged_enables_p, 1,
                        (sizeof(sx_tele_hash_sig_field_enable_t) *
                         (curr_enables_cnt + hash_field_enable_list_cnt)),
                        UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to allocate memory for hash sig fields enables.\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    M_UTILS_CLR_MEM_GET(&merged_fields_p, 1,
                        (sizeof(sx_tele_hash_sig_field_t) *
                         (curr_fields_cnt + hash_field_list_cnt)),
                        UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to allocate memory for hash sig fields.\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&new_enables_p, 1,
                        (sizeof(sx_tele_hash_sig_field_enable_t) * hash_field_enable_list_cnt),
                        UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to allocate memory for hash sig fields enables.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    SX_MEM_CPY_ARRAY(new_enables_p, hash_field_enable_list_p,
                     hash_field_enable_list_cnt, sx_tele_hash_sig_field_enable_t);

    M_UTILS_CLR_MEM_GET(&new_fields_p, 1,
                        (sizeof(sx_tele_hash_sig_field_t) * hash_field_list_cnt),
                        UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to allocate memory for hash sig fields.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    SX_MEM_CPY_ARRAY(new_fields_p, hash_field_list_p, hash_field_list_cnt,
                     sx_tele_hash_sig_field_t);

    /* merge fields enables list */
    qsort(new_enables_p, hash_field_enable_list_cnt,
          sizeof(sx_tele_hash_sig_field_enable_t), __hash_sig_field_enable_cmp);
    qsort(curr_enables_p, curr_enables_cnt,
          sizeof(sx_tele_hash_sig_field_enable_t), __hash_sig_field_enable_cmp);

    while ((curr_field_idx < curr_enables_cnt) ||
           (new_field_idx < hash_field_enable_list_cnt)) {
        if (new_field_idx >= hash_field_enable_list_cnt) {
            merged_enables_p[merged_field_idx] = curr_enables_p[curr_field_idx];
            curr_field_idx++;
        } else if (curr_field_idx >= curr_enables_cnt) {
            merged_enables_p[merged_field_idx] = new_enables_p[new_field_idx];
            new_field_idx++;
        } else if (new_enables_p[new_field_idx] < curr_enables_p[curr_field_idx]) {
            merged_enables_p[merged_field_idx] = new_enables_p[new_field_idx];
            new_field_idx++;
        } else if (new_enables_p[new_field_idx] > curr_enables_p[curr_field_idx]) {
            merged_enables_p[merged_field_idx] = curr_enables_p[curr_field_idx];
            curr_field_idx++;
        } else if (new_enables_p[new_field_idx] == curr_enables_p[curr_field_idx]) {
            merged_enables_p[merged_field_idx] = new_enables_p[new_field_idx];
            new_field_idx++;
            curr_field_idx++;
        } else {
            CL_ASSERT(FALSE);
        }
        merged_field_idx++;
        merged_enables_cnt++;
    }
    /* merge fields list */
    qsort(new_fields_p, hash_field_list_cnt, sizeof(sx_tele_hash_sig_field_t),
          __hash_sig_field_cmp);
    qsort(curr_fields_p, curr_fields_cnt, sizeof(sx_tele_hash_sig_field_t),
          __hash_sig_field_cmp);
    curr_field_idx = 0;
    new_field_idx = 0;
    merged_field_idx = 0;

    while ((curr_field_idx < curr_fields_cnt) ||
           (new_field_idx < hash_field_list_cnt)) {
        if (new_field_idx >= hash_field_list_cnt) {
            merged_fields_p[merged_field_idx] = curr_fields_p[curr_field_idx];
            curr_field_idx++;
        } else if (curr_field_idx >= curr_fields_cnt) {
            merged_fields_p[merged_field_idx] = new_fields_p[new_field_idx];
            new_field_idx++;
        } else if (new_fields_p[new_field_idx] < curr_fields_p[curr_field_idx]) {
            merged_fields_p[merged_field_idx] = new_fields_p[new_field_idx];
            new_field_idx++;
        } else if (new_fields_p[new_field_idx] > curr_fields_p[curr_field_idx]) {
            merged_fields_p[merged_field_idx] = curr_fields_p[curr_field_idx];
            curr_field_idx++;
        } else if (new_fields_p[new_field_idx] == curr_fields_p[curr_field_idx]) {
            merged_fields_p[merged_field_idx] = new_fields_p[new_field_idx];
            new_field_idx++;
            curr_field_idx++;
        } else {
            CL_ASSERT(FALSE);
        }
        merged_field_idx++;
        merged_fields_cnt++;
    }

    err = __tele_impl_hash_sig_params_set(hash_sig_prof_idx,
                                          &hash_sig_prof_classifier,
                                          &curr_hash_params,
                                          merged_enables_p,
                                          merged_enables_cnt,
                                          merged_fields_p,
                                          merged_fields_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Failed to set hash sig params of profile [%d]."
               " hash_sig_prof_idx failed. err: [%s]\n",
               hash_sig_prof_idx, sx_status_str(err));
        goto out;
    }

out:
    if (NULL != curr_enables_p) {
        M_UTILS_MEM_PUT(curr_enables_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free enables arr", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    if (NULL != curr_fields_p) {
        M_UTILS_MEM_PUT(curr_fields_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free fields arr", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    if (NULL != new_enables_p) {
        M_UTILS_MEM_PUT(new_enables_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free enables arr", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    if (NULL != new_fields_p) {
        M_UTILS_MEM_PUT(new_fields_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free fields arr", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    if (NULL != merged_enables_p) {
        M_UTILS_MEM_PUT(merged_enables_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free enables arr", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    if (NULL != merged_fields_p) {
        M_UTILS_MEM_PUT(merged_fields_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free fields arr", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tele_impl_hash_sig_params_delete(const sx_tele_hash_sig_prof_idx_int_t  hash_sig_prof_idx,
                                                      const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                                      const uint32_t                         hash_field_enable_list_cnt,
                                                      const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                                      const uint32_t                         hash_field_list_cnt)
{
    sx_tele_hash_sig_field_enable_t   *curr_enables_p = NULL;
    sx_tele_hash_sig_field_t          *curr_fields_p = NULL;
    sx_tele_hash_sig_field_enable_t   *new_disables_p = NULL;
    sx_tele_hash_sig_field_t          *new_disable_fields_p = NULL;
    sx_tele_hash_sig_params_t          curr_hash_params;
    sx_tele_hash_sig_classifier_attr_t hash_sig_prof_classifier;
    uint32_t                           curr_enables_cnt = 0;
    uint32_t                           curr_fields_cnt = 0;
    uint32_t                           curr_field_idx = 0;
    uint32_t                           curr_disable_field_idx = 0;
    sx_status_t                        out_err = SX_STATUS_SUCCESS;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    memset(&curr_hash_params, 0, sizeof(curr_hash_params));

    err = sdk_tele_db_hash_sig_params_get(hash_sig_prof_idx,
                                          &hash_sig_prof_classifier,
                                          &curr_hash_params,
                                          NULL,
                                          &curr_enables_cnt,
                                          NULL,
                                          &curr_fields_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Failed to get hash sig params of profile [%d]."
               " sdk_tele_db_hash_sig_params_get failed. err: [%s]\n",
               hash_sig_prof_idx, sx_status_str(err));
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&curr_enables_p, 1,
                        (sizeof(sx_tele_hash_sig_field_enable_t) * curr_enables_cnt),
                        UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to allocate memory for hash sig fields enables.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    M_UTILS_CLR_MEM_GET(&curr_fields_p, 1,
                        (sizeof(sx_tele_hash_sig_field_t) * curr_fields_cnt),
                        UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to allocate memory for hash sig fields.\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = sdk_tele_db_hash_sig_params_get(hash_sig_prof_idx,
                                          &hash_sig_prof_classifier,
                                          &curr_hash_params,
                                          curr_enables_p, &curr_enables_cnt,
                                          curr_fields_p, &curr_fields_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Failed to get hash sig params of profile [%d]."
               " sdk_tele_db_hash_sig_params_get failed. err: [%s]\n",
               hash_sig_prof_idx, sx_status_str(err));
        goto out;
    }

    if (hash_field_enable_list_cnt > 0) {
        M_UTILS_CLR_MEM_GET(&new_disables_p, 1,
                            (sizeof(sx_tele_hash_sig_field_enable_t) * hash_field_enable_list_cnt),
                            UTILS_MEM_TYPE_ID_TELEMETRY_E,
                            "Failed to allocate memory for hash sig fields enables.\n", err);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
        SX_MEM_CPY_ARRAY(new_disables_p, hash_field_enable_list_p,
                         hash_field_enable_list_cnt,
                         sx_tele_hash_sig_field_enable_t);
        qsort(new_disables_p, hash_field_enable_list_cnt,
              sizeof(sx_tele_hash_sig_field_enable_t),
              __hash_sig_field_enable_cmp);
        qsort(curr_enables_p, curr_enables_cnt,
              sizeof(sx_tele_hash_sig_field_enable_t),
              __hash_sig_field_enable_cmp);
        /* delete fields enables from list */
        curr_disable_field_idx = 0;
        curr_field_idx = 0;
        while (curr_field_idx < curr_enables_cnt &&
               curr_disable_field_idx < hash_field_enable_list_cnt) {
            if (curr_enables_p[curr_field_idx] == new_disables_p[curr_disable_field_idx]) {
                if (curr_field_idx < (curr_enables_cnt - 1)) {
                    SX_MEM_MOVE_BUF(&curr_enables_p[curr_field_idx],
                                    &curr_enables_p[curr_field_idx + 1],
                                    sizeof(sx_router_ecmp_hash_field_enable_t) *
                                    (curr_enables_cnt - curr_field_idx - 1));
                }
                curr_disable_field_idx++;
                --curr_enables_cnt;
            } else if (curr_enables_p[curr_field_idx]
                       > new_disables_p[curr_disable_field_idx]) {
                curr_disable_field_idx++;
            } else if (curr_enables_p[curr_field_idx]
                       < new_disables_p[curr_disable_field_idx]) {
                curr_field_idx++;
            }
        }
    }

    if (hash_field_list_cnt > 0) {
        M_UTILS_CLR_MEM_GET(&new_disable_fields_p, 1,
                            (sizeof(sx_tele_hash_sig_field_t) * hash_field_list_cnt),
                            UTILS_MEM_TYPE_ID_TELEMETRY_E,
                            "Failed to allocate memory for hash sig fields.\n", err);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
        SX_MEM_CPY_ARRAY(new_disable_fields_p, hash_field_list_p,
                         hash_field_list_cnt, sx_tele_hash_sig_field_t);
        qsort(new_disable_fields_p, hash_field_list_cnt,
              sizeof(sx_lag_hash_field_t), __hash_sig_field_cmp);
        qsort(curr_fields_p, curr_fields_cnt, sizeof(sx_tele_hash_sig_field_t),
              __hash_sig_field_cmp);
        curr_disable_field_idx = 0;
        curr_field_idx = 0;
        while (curr_field_idx < curr_fields_cnt && curr_disable_field_idx
               < hash_field_list_cnt) {
            if (curr_fields_p[curr_field_idx] == new_disable_fields_p[curr_disable_field_idx]) {
                if (curr_field_idx < (curr_fields_cnt - 1)) {
                    SX_MEM_MOVE_BUF(
                        &curr_fields_p[curr_field_idx],
                        &curr_fields_p[curr_field_idx + 1],
                        sizeof(sx_tele_hash_sig_field_t) * (curr_fields_cnt
                                                            - curr_field_idx - 1));
                }
                curr_disable_field_idx++;
                --curr_fields_cnt;
            } else if (curr_fields_p[curr_field_idx]
                       > new_disable_fields_p[curr_disable_field_idx]) {
                curr_disable_field_idx++;
            } else if (curr_fields_p[curr_field_idx]
                       < new_disable_fields_p[curr_disable_field_idx]) {
                curr_field_idx++;
            }
        }
    }

    err = __tele_impl_hash_sig_params_set(hash_sig_prof_idx, &hash_sig_prof_classifier,
                                          &curr_hash_params, curr_enables_p,
                                          curr_enables_cnt, curr_fields_p,
                                          curr_fields_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Failed to set hash sig params of profile [%d]."
               " __tele_impl_hash_sig_params_set failed. err: [%s]\n",
               hash_sig_prof_idx, sx_status_str(err));
        goto out;
    }

out:
    if (NULL != curr_enables_p) {
        M_UTILS_MEM_PUT(curr_enables_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free enables arr", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    if (NULL != curr_fields_p) {
        M_UTILS_MEM_PUT(curr_fields_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free fields arr", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    if (NULL != new_disables_p) {
        M_UTILS_MEM_PUT(new_disables_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free enables arr", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    if (NULL != new_disable_fields_p) {
        M_UTILS_MEM_PUT(new_disable_fields_p, UTILS_MEM_TYPE_ID_TELEMETRY_E,
                        "Failed to free fields arr", out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tele_port_profile_apply_cb(adviser_event_e event_type, void *param_p)
{
    sx_status_t                          sx_status = SX_STATUS_SUCCESS;
    sx_utils_status_t                    sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    port_profile_apply_adviser_params_t *apply_params_p = NULL;
    boolean_t                            is_param_set = FALSE;
    sx_tele_histogram_key_t              hist_key_list_arr[SX_TELE_HISTOGRAM_MAX_GET_ENTRIES];
    sx_tele_histogram_key_t              key;
    sx_tele_histogram_attributes_data_t  hist_data_list_arr[SX_TELE_HISTOGRAM_MAX_GET_ENTRIES];
    sx_tele_histogram_attributes_data_t  data;
    sx_tele_histogram_filter_t           hist_filter;
    sx_tele_histogram_key_t              hist_key;
    uint32_t                             i = 0, j = 0, hist_cnt = 0, tele_id = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(hist_filter);
    SX_MEM_CLR(hist_key);
    SX_MEM_CLR(data);
    SX_MEM_CLR(key);

    if (ADVISER_EVENT_PORT_PROFILE_APPLY_E != event_type) {
        SX_LOG(SX_LOG_ERROR, "function called with wrong event type \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(param_p, "param_p"))) {
        goto out;
    }

    apply_params_p = ((port_profile_apply_adviser_params_t *)param_p);

    sx_utils_status = bit_vector_get(apply_params_p->db_params_bits,
                                     PORT_PROFILE_PARAM_DB_BITS_TELE_HISTOGRAM_SET_E, &is_param_set);

    if (sx_utils_status != SX_UTILS_STATUS_SUCCESS) {
        sx_status = sx_utils_status_to_sx_status(sx_utils_status);
        SX_LOG_ERR("Retrieve value of port hash parameter from bit vector failed, status = %s.",
                   SX_UTILS_STATUS_MSG(sx_utils_status));
        goto out;
    }

    if (is_param_set == FALSE) {
        goto out;
    }

    /* Get all the  histograms of the profile port */

    hist_filter.filter_port_valid = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_VALID_E;
    hist_filter.filter_tc_valid = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_NOT_VALID_E;
    hist_filter.port_filter = apply_params_p->port_profile_id;
    hist_cnt = SX_TELE_HISTOGRAM_MAX_GET_ENTRIES;

    sx_status = sdk_tele_db_histogram_iter_get_first(&hist_filter, hist_key_list_arr, hist_data_list_arr, &hist_cnt);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get all the histograms for port profile [0x%08X], err: %s\n",
                   hist_filter.port_filter, sx_status_str(sx_status));
        goto out;
    }

    /* Apply to all network ports */
    for (i = 0; i < apply_params_p->port_count; i++) {
        if (SX_PORT_TYPE_ID_GET(apply_params_p->port_list_p[i]) != SX_PORT_TYPE_NETWORK) {
            continue;
        }

        for (j = 0; j < hist_cnt; j++) {
            key = hist_key_list_arr[j];
            data = hist_data_list_arr[j];
            switch (key.type) {
            case SX_TELE_HISTOGRAM_TYPE_PORT_TC_QUEUE_DEPTH_E:
            case SX_TELE_HISTOGRAM_TYPE_PORT_TC_LATENCY_E:
                key.key.port_tc.log_port = apply_params_p->port_list_p[i];
                break;

            case SX_TELE_HISTOGRAM_TYPE_PORT_PG_QUEUE_DEPTH_E:
                key.key.port_pg.log_port = apply_params_p->port_list_p[i];
                break;

            case SX_TELE_HISTOGRAM_TYPE_PORT_COUNTER_E:
                key.key.port_counter.log_port = apply_params_p->port_list_p[i];
                break;

            default:
                sx_status = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            sx_status = sdk_tele_db_histogram_get(key, NULL, NULL);
            if (SX_STATUS_ENTRY_NOT_FOUND != sx_status) {
                sx_status = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("histogram entry already exist in HWI DB on port [0x%08X] , err= %s.\n",
                           apply_params_p->port_list_p[i],
                           sx_status_str(sx_status));
                goto out;
            }

            sx_status = sdk_tele_db_histogram_add(key, data, &tele_id);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set the histogram from profile [0x%08X], to port [0x%08X], err %s",
                           apply_params_p->port_profile_id, apply_params_p->port_list_p[i], sx_status_str(sx_status));
                goto out;
            }
        }
    }

out:

    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __tele_port_profile_delete_cb(adviser_event_e event_type, void *param_p)
{
    sx_status_t                         sx_status = SX_STATUS_SUCCESS;
    sx_port_log_id_t                    log_port = 0;
    sx_tele_histogram_key_t             hist_key_list_arr[SX_TELE_HISTOGRAM_MAX_GET_ENTRIES];
    sx_tele_histogram_attributes_data_t hist_data_list_arr[SX_TELE_HISTOGRAM_MAX_GET_ENTRIES];
    sx_tele_histogram_filter_t          hist_filter;
    sx_tele_histogram_key_t             hist_key;
    uint32_t                            j = 0, hist_cnt = 0, tele_id = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(hist_filter);
    SX_MEM_CLR(hist_key);


    if (ADVISER_EVENT_POST_PORT_PROFILE_DELETE_E != event_type) {
        SX_LOG(SX_LOG_ERROR, "function called with wrong event type \n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status = utils_check_pointer(param_p, "param_p"))) {
        goto out;
    }

    log_port = ((port_profile_set_params_t*)param_p)->port_profile_id;

    if (SX_PORT_TYPE_ID_GET(log_port) != SX_PORT_TYPE_PROFILE) {
        sx_status = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Incorrect port type received: [%d] [%s].\n",
                   SX_PORT_TYPE_ID_GET(log_port), sx_status_str(sx_status));
        goto out;
    }

    /* Get all the histograms of the profile port */

    hist_filter.filter_port_valid = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_VALID_E;
    hist_filter.filter_tc_valid = SX_TELE_HISTOGRAM_KEY_FILTER_FIELD_NOT_VALID_E;
    hist_filter.port_filter = log_port;

    hist_cnt = SX_TELE_HISTOGRAM_MAX_GET_ENTRIES;
    sx_status = sdk_tele_db_histogram_iter_get_first(&hist_filter, hist_key_list_arr, hist_data_list_arr, &hist_cnt);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get all the histograms for port profile [0x%08X], err: %s\n",
                   hist_filter.port_filter, sx_status_str(sx_status));
        goto out;
    }

    /* Delete all port profile histograms from database */
    for (j = 0; j < hist_cnt; j++) {
        sx_status = sdk_tele_db_histogram_delete(hist_key_list_arr[j], &tele_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to delete the histogram from profile [0x%08X], err %s",
                       log_port, sx_status_str(sx_status));
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t sdk_tele_impl_hash_sig_prof_set(const sx_access_cmd_t                  cmd,
                                            sx_tele_hash_sig_prof_idx_int_t        hash_sig_prof_idx,
                                            sx_tele_hash_sig_classifier_attr_t    *hash_sig_prof_class_p,
                                            const sx_tele_hash_sig_params_t       *hash_params_p,
                                            const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                            const uint32_t                         hash_field_enable_list_cnt,
                                            const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                            const uint32_t                         hash_field_list_cnt)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_SET:

        err = __tele_impl_hash_sig_params_set(hash_sig_prof_idx,
                                              hash_sig_prof_class_p,
                                              hash_params_p,
                                              hash_field_enable_list_p,
                                              hash_field_enable_list_cnt,
                                              hash_field_list_p,
                                              hash_field_list_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR,
                   "Failed to set hash sig params for profile [%d]."
                   " __tele_impl_hash_sig_params_set failed. err: [%s]\n",
                   hash_sig_prof_idx, sx_status_str(err));
            goto out;
        }

        break;

    case SX_ACCESS_CMD_ADD:
        err = __tele_impl_hash_sig_params_add(hash_sig_prof_idx,
                                              hash_field_enable_list_p,
                                              hash_field_enable_list_cnt,
                                              hash_field_list_p,
                                              hash_field_list_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR,
                   "Failed to add hash sig params for profile [%d]."
                   " __tele_impl_hash_sig_params_add failed. err: [%s]\n",
                   hash_sig_prof_idx, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        err = __tele_impl_hash_sig_params_delete(hash_sig_prof_idx,
                                                 hash_field_enable_list_p,
                                                 hash_field_enable_list_cnt,
                                                 hash_field_list_p,
                                                 hash_field_list_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR,
                   "Failed to delete hash sig params of profile [%d]."
                   " __tele_impl_hash_sig_params_delete failed. err: [%s]\n",
                   hash_sig_prof_idx, sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "Failed to set LAG hash params, CMD not supported\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __tele_imlp_tac_attr_validation(sx_tele_tac_attr_t *tac_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    tac_connected_trap_group_count = 0;

    SX_LOG_ENTER();

    if ((tac_attr_p->tac_mode != SX_TELE_TAC_MODE_TO_NETWORK_E) &&
        (tac_attr_p->tac_mode != SX_TELE_TAC_MODE_DISABLE_E)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "TAC attr validation failed: wrong tac_mode %d: [%s].\n",
               tac_attr_p->tac_mode, SX_STATUS_MSG(err));
        goto out;
    }

    if (tac_attr_p->tac_mode == SX_TELE_TAC_MODE_DISABLE_E) {
        /* validation that DISABLE allowed when no TAC trap groups exists */
        err = sdk_tele_db_tac_connected_trap_group_count_get(&tac_connected_trap_group_count);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("sdk_tele_db_tac_trap_group_count_get failed, err %s\n",
                       sx_status_str(err));
            goto out;
        }

        if (tac_connected_trap_group_count > 0) {
            err = SX_STATUS_ERROR;
            SX_LOG_ERR("TAC can't be disabled because %d Trap Groups connected to TAC, err %s\n",
                       tac_connected_trap_group_count, sx_status_str(err));
            goto out;
        }

        goto out;
    }

    if ((tac_attr_p->tac_periodic_action_enabled == TRUE) &&
        (SX_TELE_TAC_ACTION_CHECK_RANGE(tac_attr_p->tac_periodic_action) != TRUE)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "TAC attr validation failed: wrong tac_periodic_action %d: [%s]. \n",
               tac_attr_p->tac_periodic_action, SX_STATUS_MSG(err));
        goto out;
    }

    if ((tac_attr_p->tac_periodic_action_enabled == TRUE) &&
        (SX_TELE_TAC_PERIODIC_INTERVAL_CHECK_RANGE(tac_attr_p->tac_periodic_action_interval) != TRUE)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR,
               "TAC attr validation failed: wrong tac_periodic_action_interval %d: [%s]. (valid range: %d - %d)\n",
               tac_attr_p->tac_periodic_action,
               SX_STATUS_MSG(err),
               SX_TELE_TAC_PERIODIC_INTERVAL_MIN,
               SX_TELE_TAC_PERIODIC_INTERVAL_MAX);
        goto out;
    }

    if (tac_attr_p->tac_truncation_size != 0) {
        SX_LOG(SX_LOG_WARNING,
               "Tac_truncation_size is deprecated, please use sx_api_host_ifc_trap_truncate_profile_set() to set profile size\n");
    }

out:
    SX_LOG_EXIT();
    return err;
}

static boolean_t __is_tac_attr_changed(sx_tele_attrib_t *attr_p)
{
    if (g_tele_attrib.tac_attr_valid != attr_p->tac_attr_valid) {
        return TRUE;
    }

    if (memcmp(&(g_tele_attrib.tac_attr), &(attr_p->tac_attr), sizeof(g_tele_attrib.tac_attr))) {
        return TRUE;
    }

    return FALSE;
}

static sx_status_t __tele_impl_tac_attr_set(sx_tele_tac_attr_t *tac_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_ops.hwd_tele_tac_attr_set_pfn != NULL) {
        /* validate parameters */
        err = __tele_imlp_tac_attr_validation(tac_attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to set telemetry TAC attributes, parameters validation failed: [%s].\n",
                   SX_STATUS_MSG(err));
            goto out;
        }

        err = g_ops.hwd_tele_tac_attr_set_pfn(tac_attr_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set telemetry TAC attributes, err: %s \n", sx_status_str(err));
            goto out;
        }

        err = tele_impl_tac_sw_header_set(tac_attr_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set telemetry TAC sw header, err: %s \n", sx_status_str(err));
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Failed to set telemetry TAC attributes (TAC supported on Spectrum 4+ only), err: %s \n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tele_impl_tac_sw_header_set(sx_tele_tac_sw_header_info_t *tac_sw_header_info_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* set TAC SW header */
    if (g_ops.hwd_tele_tac_sw_header_set_pfn != NULL) {
        err = g_ops.hwd_tele_tac_sw_header_set_pfn(tac_sw_header_info_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set telemetry TAC attributes, err: %s \n", sx_status_str(err));
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Failed to set telemetry TAC attributes (TAC supported on Spectrum 4+ only), err: %s \n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t tele_impl_tac_sw_header_set(sx_tele_tac_attr_t *tac_attr_p)
{
    sx_tele_tac_sw_header_info_t tac_sw_header_info;
    sx_status_t                  err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* get sw_header info */
    err = sdk_tele_db_tac_sw_header_get(&tac_sw_header_info);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set telemetry TAC attributes, err: %s \n", sx_status_str(err));
        goto out;
    }

    if (tac_attr_p->tac_periodic_action_enabled) {
        tac_sw_header_info.max_lifetime = tac_attr_p->tac_periodic_action_interval;
    }

    err = __tele_impl_tac_sw_header_set(&tac_sw_header_info);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set telemetry TAC attributes, err: %s \n", sx_status_str(err));
        goto out;
    }

    /* set sw_header info with new max_lifetime*/
    err = sdk_tele_db_tac_sw_header_set(&tac_sw_header_info);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set telemetry TAC attributes, err: %s \n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_impl_is_tac_supported(boolean_t *is_tac_supported)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (is_tac_supported == NULL) {
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    *is_tac_supported = FALSE;

    /* check if hash signature is supported */
    if (g_ops.hwd_tele_tac_attr_set_pfn != NULL) {
        *is_tac_supported = TRUE;
    }

out:
    return err;
}

sx_status_t sdk_tele_impl_tac_is_enabled(boolean_t *tac_is_enabled_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    sx_tele_attrib_t tele_attr;

    SX_LOG_ENTER();

    *tac_is_enabled_p = FALSE;

    /* validate TAC mode is enabled in tele module */
    err = sdk_tele_impl_attributes_get(&tele_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get telemetry TAC attributes, err: %s \n", sx_status_str(err));
        goto out;
    }

    if (tele_attr.tac_attr_valid == FALSE) {
        SX_LOG_DBG("Telemetry module TAC mode is disabled, err: %s \n", sx_status_str(err));
        goto out;
    }

    if (tele_attr.tac_attr.tac_mode == SX_TELE_TAC_MODE_DISABLE_E) {
        SX_LOG_DBG("Validation error telemetry module TAC mode isn't TO_NETWORK, err: %s \n", sx_status_str(err));
        goto out;
    }

    *tac_is_enabled_p = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_tac_is_trap_bind_allowed(sx_trap_group_t trap_group,
                                                   boolean_t      *tac_is_trap_bind_allowed)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    tele_db_tac_trap_group_data_t data;

    SX_LOG_ENTER();

    *tac_is_trap_bind_allowed = FALSE;

    err = sdk_tele_db_tac_trap_group_map_get(trap_group, &data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_db_tac_trap_group_map_get failed, err: %s \n", sx_status_str(err));
        goto out;
    }

    /* SDK won't allow bind Trap ID to TAC capable Trap group before this trap group will be connected to TAC */
    if (data.tac_trap_group_info.tac_connected == FALSE) {
        SX_LOG_DBG("TAC isn't enabled on TAC capable trap group %d, err: %s \n", trap_group, sx_status_str(err));
        goto out;
    }

    *tac_is_trap_bind_allowed = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_impl_tac_trap_group_db_update(sx_access_cmd_t                cmd,
                                                   sx_trap_group_t                trap_group,
                                                   tele_db_tac_trap_group_info_t *trap_group_info_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_tele_attrib_t              tele_attr;
    tele_db_tac_trap_group_data_t data;

    SX_LOG_ENTER();

    /* validate TAC mode is enabled in tele module */
    err = sdk_tele_impl_attributes_get(&tele_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set telemetry TAC attributes, err: %s \n", sx_status_str(err));
        goto out;
    }

    if (tele_attr.tac_attr_valid == FALSE) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Telemetry module TAC mode is disabled, err: %s \n", sx_status_str(err));
        goto out;
    }

    if (tele_attr.tac_attr.tac_mode == SX_TELE_TAC_MODE_DISABLE_E) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Validation error telemetry module TAC mode isn't TO_NETWORK, err: %s \n", sx_status_str(err));
        goto out;
    }

    /* add/delete trap group from TAC trap group map */
    if (cmd == SX_ACCESS_CMD_ADD) {
        err = sdk_tele_db_tac_trap_group_map_add(trap_group, trap_group_info_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("sdk_tele_db_tac_db_trap_group_add failed, err: %s \n", sx_status_str(err));
            goto out;
        }
    } else {
        /* validation that SPAN is disconnected from TAC trap group */
        err = sdk_tele_db_tac_trap_group_map_get(trap_group, &data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("sdk_tele_db_tac_trap_group_map_get failed, err: %s \n", sx_status_str(err));
            goto out;
        }

        if (data.tac_trap_group_info.tac_connected == TRUE) {
            err = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("TAC trap group %d is still in use, err: %s \n", trap_group, sx_status_str(err));
            goto out;
        }

        err = sdk_tele_db_tac_trap_group_map_delete(trap_group);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("sdk_tele_db_tac_db_trap_group_delete failed, err: %s \n", sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_utils_status_t __tac_trap_group_gc_delete_cb(const void *gc_context)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_trap_group_t               trap_group = (sx_trap_group_t)(uintptr_t)gc_context;
    sx_tele_tac_cfg_t             tac_cfg;
    tele_db_tac_trap_group_data_t curr_tac_trap_group_data, new_tac_trap_group_data, rb_tac_trap_group_data;
    uint8_t                       hw_span_session_id;
    boolean_t                     span_session_locked = FALSE;
    boolean_t                     hwd_tele_tac_unset_done = FALSE;
    boolean_t                     sdk_tele_db_tac_trap_group_map_unset = FALSE;

    SX_LOG_ENTER();

    SX_LOG_DBG("TAC trap group GC delete callback called for Trap Group %u\n",
               trap_group);

    /* validation that SPAN is disconnected from TAC trap group */
    err = sdk_tele_db_tac_trap_group_map_get(trap_group, &curr_tac_trap_group_data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_db_tac_trap_group_map_get failed, err: %s \n", sx_status_str(err));
        goto out;
    }

    /* get hw span session id*/
    err = span_session_lock(g_tac_span_user_handle,
                            curr_tac_trap_group_data.tac_trap_group_info.span_session_id,
                            &hw_span_session_id);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("TAC set failed span_session_lock failed, span_session_id: %u\n",
                   curr_tac_trap_group_data.tac_trap_group_info.span_session_id);
        goto out;
    }
    span_session_locked = TRUE;

    err = g_ops.hwd_tele_tac_set_pfn(SX_ACCESS_CMD_UNSET, trap_group, hw_span_session_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set telemetry TAC group configuration, err: %s \n", sx_status_str(err));
        goto out;
    }
    hwd_tele_tac_unset_done = TRUE;

    /* add the new configuration to DB */
    SX_MEM_CLR(new_tac_trap_group_data);
    new_tac_trap_group_data.tac_trap_group_info.span_session_id_valid = FALSE;
    err = sdk_tele_db_tac_trap_group_map_set(TELE_DB_TAC_TRAP_GROUP_INFO_MASK_SPAN_SESSION_ID,
                                             trap_group, &new_tac_trap_group_data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_db_tac_trap_group_map_update_data failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }
    sdk_tele_db_tac_trap_group_map_unset = TRUE;

    /* TAC ref cnt update.
     * Note: refcnt of SPAN should happen under span user handle lock */
    tac_cfg.tac_to_net_span_id = curr_tac_trap_group_data.tac_trap_group_info.span_session_id;
    err = __tele_impl_update_refcnt(SX_ACCESS_CMD_UNSET, trap_group, &tac_cfg);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_impl_update_refcnt failed for trap group %d and span session id %d , err: %s \n",
                   trap_group, tac_cfg.tac_to_net_span_id, sx_status_str(err));
        goto out;
    }

out:

    if (err != SX_STATUS_SUCCESS) {
        if (sdk_tele_db_tac_trap_group_map_unset) {
            SX_MEM_CLR(rb_tac_trap_group_data);
            rb_tac_trap_group_data.tac_trap_group_info.span_session_id_valid = TRUE;
            rb_tac_trap_group_data.tac_trap_group_info.span_session_id =
                curr_tac_trap_group_data.tac_trap_group_info.span_session_id;
            err = sdk_tele_db_tac_trap_group_map_set(TELE_DB_TAC_TRAP_GROUP_INFO_MASK_SPAN_SESSION_ID,
                                                     trap_group, &rb_tac_trap_group_data);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("sdk_tele_db_tac_trap_group_map_update_data failed with err: %s .\n",
                           sx_status_str(err));
            }
        }

        if (hwd_tele_tac_unset_done) {
            err = g_ops.hwd_tele_tac_set_pfn(SX_ACCESS_CMD_SET, trap_group, hw_span_session_id);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set telemetry TAC group configuration, err: %s \n", sx_status_str(err));
            }
        }
    }

    if (span_session_locked == TRUE) {
        span_session_unlock(g_tac_span_user_handle,
                            curr_tac_trap_group_data.tac_trap_group_info.span_session_id);
        span_session_locked = FALSE;
    }

    SX_LOG_EXIT();
    return sx_status_to_sx_utils_status(err);
}


sx_status_t __tele_tac_trap_group_gc_object_init()
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_utils_status_t           utils_err = SX_UTILS_STATUS_SUCCESS;
    gc_object_type_attributes_t object_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(object_attr);

    object_attr.free_objects_threshold = SX_TRAP_GROUP_MAX / 4;
    object_attr.per_object_threshold = SX_TRAP_GROUP_MAX / 2;
    object_attr.fence_type = GC_FENCE_TYPE_SLOW;
    object_attr.hw_operation_needed = TRUE;
    object_attr.immediate_fence_needed = TRUE;
    object_attr.max_object_count = SX_TRAP_GROUP_MAX + 1;
    utils_err = gc_object_init(GC_OBJECT_TYPE_TRAP_GROUP, &object_attr, __tac_trap_group_gc_delete_cb, NULL);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to initialize %s object type in GC, utils_err = [%s]\n",
                   GC_OBJECT_TYPE_STR(GC_OBJECT_TYPE_TRAP_GROUP), SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __tele_gc_tac_trap_group_object_deinit()
{
    sx_utils_status_t sx_utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_status_t       err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_utils_err = gc_object_deinit(GC_OBJECT_TYPE_TRAP_GROUP);
    if (SX_UTILS_CHECK_FAIL(sx_utils_err)) {
        SX_LOG_ERR("Failed to deinitialize GC object type %s, utils_err = [%s]\n",
                   GC_OBJECT_TYPE_STR(GC_OBJECT_TYPE_TRAP_GROUP),
                   SX_UTILS_STATUS_MSG(sx_utils_err));
        err = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t tele_db_tac_trap_group_db_update_span_id(uint16_t trap_group, void *param_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    span_relocate_data_t         *span_relocate_data_p = (span_relocate_data_t*)param_p;
    tele_db_tac_trap_group_data_t tac_trap_group_data;

    SX_LOG_ENTER();

    SX_LOG_DBG(" Span relocate per trap group:%d, span_id:%d, old_span_id_int:%d, new_span_id_int %d \n",
               (int)trap_group, span_relocate_data_p->span_session_id,
               span_relocate_data_p->old_index, span_relocate_data_p->new_index);

    /* validation that SPAN is disconnected from TAC trap group */
    err = sdk_tele_db_tac_trap_group_map_get(trap_group, &tac_trap_group_data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_db_tac_trap_group_map_get failed, err: %s \n", sx_status_str(err));
        goto out;
    }

    if ((tac_trap_group_data.tac_trap_group_info.span_session_id_valid != TRUE) ||
        tac_trap_group_data.tac_trap_group_info.gc_handle_valid) {
        /* some of the groups in DB can be with TAC disabled */
        goto out;
    }

    if (tac_trap_group_data.tac_trap_group_info.span_session_id != span_relocate_data_p->span_session_id) {
        /* if TAC trap group configured with another SPAN session id , do nothing */
        goto out;
    }

    /* update HW with new HW span session id */
    err = g_ops.hwd_tele_tac_set_pfn(SX_ACCESS_CMD_SET,
                                     trap_group,
                                     span_relocate_data_p->new_index);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set telemetry TAC group configuration, err: %s \n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __tele_tac_hw_span_relocate(sx_span_session_id_t     span_session_id,
                                        sx_span_session_id_int_t old_span_session_id_int,
                                        sx_span_session_id_int_t new_span_session_id_int)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    span_relocate_data_t span_relocate_data;

    SX_LOG_ENTER();

    SX_LOG_DBG(" Span relocate new:%d \n", (int)new_span_session_id_int);

    memset(&span_relocate_data, 0, sizeof(span_relocate_data));

    span_relocate_data.old_index = old_span_session_id_int;
    span_relocate_data.new_index = new_span_session_id_int;
    span_relocate_data.span_session_id = span_session_id;

    /* SPAN relocate handling  */
    err = sdk_tele_db_tac_trap_group_foreach(tele_db_tac_trap_group_db_update_span_id,
                                             &span_relocate_data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_db_tac_trap_group_foreach failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __tele_impl_tac_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS, rb_err;
    boolean_t   gc_obj_inited = FALSE, tac_db_initialized = FALSE;

    SX_LOG_ENTER();

    err = sdk_tele_db_tac_init();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("tele_db_tac_init() failed. err: %s \n", sx_status_str(err));
        goto out;
    }
    tac_db_initialized = TRUE;

    /* init GC for trap group unset */
    err = __tele_tac_trap_group_gc_object_init();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_gc_tac_trap_group_object_init failed, err: %s \n", sx_status_str(err));
        goto out;
    }
    gc_obj_inited = TRUE;

    err = span_user_init(__tele_tac_hw_span_relocate, &g_tac_span_user_handle);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("span_user_init failed.\n");
        goto out;
    }

out:
    if (err != SX_STATUS_SUCCESS) {
        if (gc_obj_inited == TRUE) {
            rb_err = __tele_gc_tac_trap_group_object_deinit();
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("__tele_gc_tac_trap_group_object_deinit failed, err: %s \n", sx_status_str(rb_err));
            }
        }

        if (tac_db_initialized) {
            rb_err = sdk_tele_db_tac_deinit(FALSE);
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("sdk_tele_db_tac_deinit failed, err: %s \n", sx_status_str(rb_err));
            }
        }
    }
    SX_LOG_EXIT();
    return err;
}


sx_status_t __tele_impl_tac_trap_group_unset_on_deinit(uint16_t trap_group, void *param_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    tele_db_tac_trap_group_data_t tac_trap_group_data;

    UNUSED_PARAM(param_p);

    SX_LOG_ENTER();

    SX_LOG_DBG("Deinit Trap group %d unset from TAC. \n", trap_group);

    /* validation that SPAN is disconnected from TAC trap group */
    err = sdk_tele_db_tac_trap_group_map_get(trap_group, &tac_trap_group_data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_db_tac_trap_group_map_get failed, err: %s \n", sx_status_str(err));
        goto out;
    }

    if ((tac_trap_group_data.tac_trap_group_info.tac_connected != TRUE) ||
        tac_trap_group_data.tac_trap_group_info.gc_handle_valid) {
        /* skip the trap groups in DB which are TAC disabled */
        goto out;
    }

    err = sdk_tele_impl_tac_set(SX_ACCESS_CMD_UNSET, trap_group, NULL);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_impl_tac_set failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tele_impl_tac_deinit(boolean_t is_forced)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint32_t                 tac_connected_trap_group_count = 0;
    sx_tele_tac_statistics_t tele_tac_statistics;
    boolean_t                tac_is_enabled = FALSE;

    UNUSED_PARAM(is_forced);

    SX_LOG_ENTER();

    /* TAC force deinit of all TAC trap groups */
    if (is_forced == TRUE) {
        /* Unset TAC on all trap groups */
        err = sdk_tele_db_tac_trap_group_foreach(__tele_impl_tac_trap_group_unset_on_deinit,
                                                 NULL);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("tac deinit: sdk_tele_db_tac_trap_group_foreach failed with err: %s .\n",
                       sx_status_str(err));
            goto out;
        }
    }

    err = sdk_tele_db_tac_connected_trap_group_count_get(&tac_connected_trap_group_count);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_db_tac_trap_group_count_get failed, err %s\n",
                   sx_status_str(err));
        goto out;
    }

    if ((is_forced == FALSE) && (tac_connected_trap_group_count > 0)) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("tele tac deinit failed, there are still %d trap groups connected to TAC, err %s\n",
                   tac_connected_trap_group_count, sx_status_str(err));
        goto out;
    }

    if (g_tac_span_user_handle != NULL) {
        err = span_user_deinit(g_tac_span_user_handle);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to deinit span manager.\n");
        }
    }

    /* deinit GC for trap group */
    err = __tele_gc_tac_trap_group_object_deinit();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_gc_tac_trap_group_object_deinit failed, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = sdk_tele_impl_tac_is_enabled(&tac_is_enabled);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_impl_tac_statistics_get failed, err: %s \n", sx_status_str(err));
        goto out;
    }

    /* clear the TAC statistics on TAC deinit only if TAC is enabled */
    if (tac_is_enabled) {
        err = sdk_tele_impl_tac_statistics_get(SX_ACCESS_CMD_READ_CLEAR, &tele_tac_statistics);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__tele_impl_tac_statistics_get failed, err: %s \n", sx_status_str(err));
            goto out;
        }
    }

    err = sdk_tele_db_tac_deinit(is_forced);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_db_tac_deinit failed, err: %s \n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


/*
 * This function check requirements before SET and UNSET TAC command.
 * Both command requirements:
 * - command is SET or UNSET only
 * - check that provided Trap group is TAC capable (exists in tac trap group db)
 *
 * SET command requirements:
 * - TAC wasn't already configured for this trap group
 * - SPAN session id is valid
 * - SPAN session type is Remote ETH
 * - SPAN session analyzer port isn't CPU port
 * - check Trap group is valid
 *
 * UNSET command requirements:
 * - TAC is already configured for this trap group
 * - All Trap IDs were unbound from this trap group
 */
static sx_status_t __tele_impl_tac_set_validation(sx_access_cmd_t    cmd,
                                                  sx_trap_group_t    trap_group,
                                                  sx_tele_tac_cfg_t *tac_cfg_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    tele_db_tac_trap_group_data_t tac_trap_group_data;
    sx_span_session_params_t      span_session_params;
    sx_port_log_id_t              analyzer_port;
    uint32_t                      analyzer_port_type;
    sx_trap_group_attributes_t    trap_group_attributes;
    sx_swid_t                     swid = 0;
    boolean_t                     is_trap_group_associated;

    SX_LOG_ENTER();

    /* command is SET or UNSET only */
    if ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_UNSET)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("TAC action validation: unsupported cmd %s , err: %s\n",
                   SX_ACCESS_CMD_STR(cmd), sx_status_str(err));
        goto out;
    }

    /* check that provided Trap group is TAC capable (exists in tac trap group db) */
    err = sdk_tele_db_tac_trap_group_map_get(trap_group, &tac_trap_group_data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_db_tac_trap_group_map_get failed for trap group %d with err: %s .\n",
                   trap_group, sx_status_str(err));
        goto out;
    }

    /* check all Trap IDs were unbound from this trap group for both SET/UNSET operation */
    err = host_ifc_spectrum_trap_group_used(swid, trap_group,
                                            &is_trap_group_associated);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("host_ifc_spectrum_trap_group_used failed for TAC trap group %d , err: %s \n",
                   trap_group, sx_status_str(err));
        goto out;
    }

    if (is_trap_group_associated == TRUE) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR(
            "Trap group (%u) is associated with one or more Trap ID, please unset all trap IDs first.\n",
            trap_group);
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        if (tac_cfg_p == NULL) {
            err = SX_STATUS_ERROR;
            SX_LOG_ERR("TAC cfg is NULL for for trap group %d, err: %s .\n",
                       trap_group,  sx_status_str(err));
            goto out;
        }

        /* tac wasn't already configured for this trap group */
        if (tac_trap_group_data.tac_trap_group_info.tac_connected == TRUE) {
            err = SX_STATUS_ERROR;
            SX_LOG_ERR("TAC is already configured for trap group %d, err: %s .\n",
                       trap_group,  sx_status_str(err));
            goto out;
        }

        /* span session id is valid */
        err = span_session_get(tac_cfg_p->tac_to_net_span_id, &span_session_params);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("TAC set validation: session id %d does not exist\n",
                       tac_cfg_p->tac_to_net_span_id);
            goto out;
        }

        /* span session type is remote ETH */
        if ((span_session_params.span_type != SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1) &&
            (span_session_params.span_type != SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1) &&
            (span_session_params.span_type != SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1)) {
            err = SX_STATUS_ERROR;
            SX_LOG_ERR("TAC set validation: SPAN session id %d type %s isn't Remote ETH, err: %s .\n",
                       tac_cfg_p->tac_to_net_span_id,
                       SX_SPAN_TYPE_STR(span_session_params.span_type),
                       sx_status_str(err));
            goto out;
        }

        /* span session analyzer port isn't CPU port */
        err = span_session_analyzer_get(tac_cfg_p->tac_to_net_span_id,
                                        &analyzer_port);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("TAC set validation: span_session_analyzer_get failed for pan session id %d, err: %s\n",
                       tac_cfg_p->tac_to_net_span_id, sx_status_str(err));
            goto out;
        }

        analyzer_port_type = SX_PORT_TYPE_ID_GET(analyzer_port);
        if (analyzer_port_type == SX_PORT_TYPE_CPU) {
            err = SX_STATUS_ERROR;
            SX_LOG_ERR("TAC set validation: SPAN session id %d , analyzer port 0x%x type is CPU PORT, err: %s .\n",
                       tac_cfg_p->tac_to_net_span_id,
                       analyzer_port_type,
                       sx_status_str(err));
            goto out;
        }

        /* check trap group is valid */
        err = host_ifc_trap_group_get(trap_group, swid,  &trap_group_attributes);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get trap group %d ,rc [%s].\n",
                       trap_group, SX_STATUS_MSG(err));
            goto out;
        }
    } else { /* cmd is UNSET */
        /* tac is already configured for this trap group */
        if (tac_trap_group_data.tac_trap_group_info.tac_connected == FALSE) {
            err = SX_STATUS_ERROR;
            SX_LOG_ERR("TAC wasn't configured for trap group %d, err: %s .\n",
                       trap_group,  sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

/*
 * This function check that all requirements for TAC action set API are valid :
 * - currently only SET command is supported
 * - if some filter is enabled then check the the value is valid
 * - check that TAC action is in range
 */
static sx_status_t __tele_impl_tac_action_set_validation(sx_access_cmd_t              cmd,
                                                         sx_tele_tac_action_filter_t *tac_action_filter_p,
                                                         sx_tele_tac_action_info_t   *tac_action_info_p)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_swid_t                  swid = 0;
    sx_trap_group_attributes_t trap_group_attributes;


    UNUSED_PARAM(tac_action_info_p);

    SX_LOG_ENTER();

    /* command is SET only */
    if (cmd != SX_ACCESS_CMD_SET) {
        err = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("TAC action validation: unsupported cmd %s , err: %s\n",
                   SX_ACCESS_CMD_STR(cmd), sx_status_str(err));
        goto out;
    }

    if (tac_action_filter_p->filter_by_trap_group == TRUE) {
        /* check trap group is valid */
        err = host_ifc_trap_group_get(tac_action_filter_p->trap_group, swid, &trap_group_attributes);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get trap group %d ,rc [%s].\n",
                       tac_action_filter_p->trap_group, SX_STATUS_MSG(err));
            goto out;
        }
    }

    if ((tac_action_filter_p->filter_by_trap_id == TRUE) &&
        (!SX_TRAP_ID_CHECK_RANGE(tac_action_filter_p->trap_id))) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("TAC action validation: trap id %d is out of range, err: %s\n",
                   tac_action_filter_p->trap_id, sx_status_str(err));
        goto out;
    }

    if (!SX_TELE_TAC_ACTION_CHECK_RANGE(tac_action_info_p->tac_action)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("TAC action validation: TAC action %d is out of range, err: %s\n",
                   tac_action_info_p->tac_action, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __tele_impl_tac_set(sx_access_cmd_t cmd, sx_trap_group_t trap_group, sx_tele_tac_cfg_t *tac_cfg_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS, rb_err;
    uint8_t                       hw_span_session_id;
    tele_db_tac_trap_group_data_t tac_trap_group_data;
    sx_utils_status_t             utils_err;
    gc_handle_t                   gc_handle;
    boolean_t                     span_session_locked = FALSE;
    boolean_t                     hwd_tele_tac_set_done = FALSE;
    boolean_t                     sdk_tele_db_tac_trap_group_map_set_done = TRUE;
    boolean_t                     gc_object_push_done = TRUE;

    SX_LOG_ENTER();

    SX_MEM_CLR(tac_trap_group_data);

    if (g_ops.hwd_tele_tac_set_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_INF("Telemetry TAC set is not supported, err: %s \n", sx_status_str(err));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        /* get hw span session id*/
        err = span_session_lock(g_tac_span_user_handle, tac_cfg_p->tac_to_net_span_id, &hw_span_session_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("TAC set failed span_session_lock failed, span_session_id: %u\n",
                       tac_cfg_p->tac_to_net_span_id);
            goto out;
        }
        span_session_locked = TRUE;

        err = g_ops.hwd_tele_tac_set_pfn(cmd, trap_group, hw_span_session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set telemetry TAC group configuration, err: %s \n", sx_status_str(err));
            goto out;
        }
        hwd_tele_tac_set_done = TRUE;

        /* add the new configuration to DB */
        SX_MEM_CLR(tac_trap_group_data);
        tac_trap_group_data.tac_trap_group_info.span_session_id_valid = TRUE;
        tac_trap_group_data.tac_trap_group_info.span_session_id = tac_cfg_p->tac_to_net_span_id;
        err = sdk_tele_db_tac_trap_group_map_set(TELE_DB_TAC_TRAP_GROUP_INFO_MASK_SPAN_SESSION_ID,
                                                 trap_group, &tac_trap_group_data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("sdk_tele_db_tac_trap_group_map_update_data failed with err: %s .\n",
                       sx_status_str(err));
            goto out;
        }
        sdk_tele_db_tac_trap_group_map_set_done = TRUE;

        /* TAC ref cnt update.
         * Note: refcnt of SPAN should happen under span user handle lock */
        err = __tele_impl_update_refcnt(cmd, trap_group, tac_cfg_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("__tele_impl_update_refcnt failed for trap group %d and span session id %d , err: %s \n",
                       trap_group, tac_cfg_p->tac_to_net_span_id, sx_status_str(err));
            goto out;
        }
    } else { /* UNSET */
        /* Push the Trap group to the GC queue.
         * It will be deleted asynchronously after a fence is performed. */
        utils_err = gc_object_push(GC_OBJECT_TYPE_TRAP_GROUP, (void*)(uintptr_t)trap_group,
                                   GC_STATE_PENDING_FENCE, 1,
                                   GC_OBJECT_SUBTYPE_NONE, 0,
                                   &gc_handle);
        if (SX_UTILS_CHECK_FAIL(utils_err)) {
            err = (utils_err == SX_UTILS_STATUS_PARTIALLY_COMPLETE) ?
                  SX_STATUS_ERROR : sx_utils_status_to_sx_status(utils_err);
            SX_LOG_ERR("Failed to push TAC Trap Group %u to GC queue, utils_err = [%s]\n",
                       trap_group, SX_UTILS_STATUS_MSG(utils_err));
            goto out;
        }
        gc_object_push_done = TRUE;

        /* add the new configuration to DB */
        SX_MEM_CLR(tac_trap_group_data);
        tac_trap_group_data.tac_trap_group_info.gc_handle_valid = TRUE;
        tac_trap_group_data.tac_trap_group_info.gc_handle = gc_handle;
        err = sdk_tele_db_tac_trap_group_map_set(TELE_DB_TAC_TRAP_GROUP_INFO_MASK_GC_HANDLE,
                                                 trap_group, &tac_trap_group_data);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("sdk_tele_db_tac_trap_group_map_update_data failed with err: %s .\n",
                       sx_status_str(err));
            goto out;
        }

        /* Reference will be decreased in GC callback */
    }

out:

    /* if err isn't SUCCESS than rollback is required */
    if (err != SX_STATUS_SUCCESS) {
        if (sdk_tele_db_tac_trap_group_map_set_done) {
            SX_MEM_CLR(tac_trap_group_data);
            tac_trap_group_data.tac_trap_group_info.span_session_id_valid = FALSE;
            rb_err = sdk_tele_db_tac_trap_group_map_set(TELE_DB_TAC_TRAP_GROUP_INFO_MASK_SPAN_SESSION_ID,
                                                        trap_group, &tac_trap_group_data);
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("rb: sdk_tele_db_tac_trap_group_map_update_data failed with err: %s .\n",
                           sx_status_str(rb_err));
            }
        }

        if (hwd_tele_tac_set_done) {
            rb_err = g_ops.hwd_tele_tac_set_pfn(SX_ACCESS_CMD_UNSET, trap_group, hw_span_session_id);
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("rb: Failed to set telemetry TAC group configuration, err: %s \n", sx_status_str(rb_err));
            }
        }

        if (gc_object_push_done) {
            utils_err = gc_object_remove(gc_handle);
            if (SX_UTILS_CHECK_FAIL(utils_err)) {
                SX_LOG_ERR("rb: Failed to remove trap group %d from gc queue , utils_err = [%s]\n",
                           trap_group, SX_UTILS_STATUS_MSG(utils_err));
            }
        }
    }

    if ((cmd == SX_ACCESS_CMD_SET) && (span_session_locked == TRUE)) {
        span_session_unlock(g_tac_span_user_handle, tac_cfg_p->tac_to_net_span_id);
        span_session_locked = FALSE;
    }

    SX_LOG_EXIT();

    return err;
}


static sx_status_t __tele_impl_tac_get(sx_trap_group_t trap_group, sx_tele_tac_cfg_t *tac_cfg_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    tele_db_tac_trap_group_data_t tac_trap_group_data;

    SX_LOG_ENTER();

    SX_MEM_CLR(tac_trap_group_data);

    /* validation that SPAN is disconnected from TAC trap group */
    err = sdk_tele_db_tac_trap_group_map_get(trap_group, &tac_trap_group_data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_INF("sdk_tele_db_tac_trap_group_map_get failed, err: %s \n", sx_status_str(err));
        goto out;
    }

    if ((tac_trap_group_data.tac_trap_group_info.span_session_id_valid == FALSE) ||
        (tac_trap_group_data.tac_trap_group_info.gc_handle_valid == TRUE)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_INF("__tele_impl_tac_get failed. trap group:%d, span_id_valid:%d, gc_handle_valid:%d, err: %s \n",
                   trap_group,
                   tac_trap_group_data.tac_trap_group_info.span_session_id_valid,
                   tac_trap_group_data.tac_trap_group_info.gc_handle_valid,
                   sx_status_str(err));
        goto out;
    }

    tac_cfg_p->tac_to_net_span_id = tac_trap_group_data.tac_trap_group_info.span_session_id;

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __tele_impl_tac_action_set(sx_access_cmd_t              cmd,
                                              sx_tele_tac_action_filter_t *tac_action_filter_p,
                                              sx_tele_tac_action_info_t   *tac_action_info_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_tele_tac_action_status_e tac_action_status;

    SX_LOG_ENTER();

    if (g_ops.hwd_tele_tac_action_set_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_INF("Telemetry TAC action set is not supported, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = g_ops.hwd_tele_tac_action_set_pfn(cmd, tac_action_filter_p,
                                            tac_action_info_p, &tac_action_status);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set telemetry TAC action, err: %s \n", sx_status_str(err));
        goto out;
    }

    if (tac_action_status == SX_TELE_TAC_ACTION_STATUS_BUSY_E) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_DBG("TAC action set return BUSY, rc: %s \n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tele_impl_tac_action_get(sx_tele_tac_action_status_e *tac_action_status_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_ops.hwd_tele_tac_action_get_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_INF("Telemetry TAC action set is not supported, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = g_ops.hwd_tele_tac_action_get_pfn(tac_action_status_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get telemetry TAC action status, err: %s \n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tele_impl_tac_statistics_get(sx_tele_tac_statistics_t *tele_tac_statistics_p,
                                                  boolean_t                 is_read_clear)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_ops.hwd_tele_tac_statistics_get_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_INF("Telemetry TAC action set is not supported, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = g_ops.hwd_tele_tac_statistics_get_pfn(tele_tac_statistics_p, is_read_clear);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get telemetry TAC action status, err: %s \n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __tele_impl_tac_oob_msg_cfg_validate(sx_access_cmd_t cmd, sx_tele_tac_oob_send_cfg_t *tac_msg_cfg_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint8_t     hw_span_session_id;

    SX_LOG_ENTER();

    /* cmd is needed to make the API future proof.
     * In API description this function supports only SET command
     * so error will be returned for other commands */
    if (cmd != SX_ACCESS_CMD_SET) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("__tele_impl_tac_oob_msg_cfg_validate with cmd %s failed with err: %s .\n",
                   SX_ACCESS_CMD_STR(cmd), sx_status_str(err));
        goto out;
    }

    /* Look up internal session */
    err = __tele_impl_int_span_session_id_get(tac_msg_cfg_p->tac_to_net_span_id, &hw_span_session_id);
    if (err) {
        SX_LOG_ERR("__tele_impl_int_span_session_id_get failed with err: %s for span_session id %d \n",
                   sx_status_str(err), tac_msg_cfg_p->tac_to_net_span_id);
        goto out;
    }

    if (tac_msg_cfg_p->tac_oob_msg_list_cnt > SX_TELE_TAC_OOB_MSG_LIST_LEN_MAX) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR(
            "__tele_impl_tac_oob_msg_cfg_validate failed with err: %s . (tac_oob_msg_list_cnt %d > MAX LIST LEN %d )\n",
            sx_status_str(err),
            tac_msg_cfg_p->tac_oob_msg_list_cnt,
            SX_TELE_TAC_OOB_MSG_LIST_LEN_MAX);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __tele_impl_int_span_session_id_get(sx_span_session_id_t tac_to_net_span_id,
                                                       uint8_t             *hw_span_session_id_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint8_t                  hw_span_session_id;
    sx_span_session_params_t span_session_params;

    /* span session id is valid */
    err = span_session_get(tac_to_net_span_id, &span_session_params);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("TAC set validation: session id %d does not exist\n",
                   tac_to_net_span_id);
        goto out;
    }

    /* Look up internal session */
    err = span_db_session_ext_to_int(tac_to_net_span_id, &hw_span_session_id);
    if (err) {
        goto out;
    }

    *hw_span_session_id_p = hw_span_session_id;

out:
    return err;
}

static sx_status_t __tele_impl_send_oob_msg_to_span(sx_span_session_id_t          tac_to_net_span_id,
                                                    tele_tac_oob_packet_format_t *tac_oob_packet_p,
                                                    uint16_t                      packet_hdr_total_tlvs_len)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint8_t     hw_span_session_id;
    uint32_t    packet_buffer_size;
    uint16_t    aligned_packet_hdr_total_tlvs_len;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(tac_oob_packet_p, "tac_oob_packet_p pointer"))) {
        SX_LOG_ERR("tac_oob_packet_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* align packet header total len to 4 if it isn't aligned */
    if (packet_hdr_total_tlvs_len % 4 != 0) {
        err = __tele_impl_align_packet_data_to_4_bytes(tac_oob_packet_p,
                                                       packet_hdr_total_tlvs_len,
                                                       &aligned_packet_hdr_total_tlvs_len);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to align packet data, orig len %d , err: %s \n",
                       packet_hdr_total_tlvs_len, sx_status_str(err));
            goto out;
        }
        packet_hdr_total_tlvs_len = aligned_packet_hdr_total_tlvs_len;
    }

    /* fill sx_tele_tac_msg_header_t */
    err = __tele_impl_fill_tac_oob_msg_header(&tac_oob_packet_p->tac_msg_header, packet_hdr_total_tlvs_len);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to fill oob msg header, err: %s \n", sx_status_str(err));
        goto out;
    }

    /* Look up internal session */
    err = __tele_impl_int_span_session_id_get(tac_to_net_span_id, &hw_span_session_id);
    if (err) {
        goto out;
    }

    packet_buffer_size = tac_oob_packet_p->tac_msg_header.msg_total_len * TAC_MSG_SW_HDR_TOTAL_LEN_UNITS +
                         sizeof(tac_oob_packet_p->tac_msg_header);
    err = host_ifc_send_to_span(hw_span_session_id, tac_oob_packet_p,
                                packet_buffer_size);
    if (err) {
        SX_LOG_ERR("host_ifc_send_to_span (span_id:%d, hw_span_id:%d) failed , err:%s \n",
                   tac_to_net_span_id, hw_span_session_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __tele_impl_fill_tac_oob_msg_header(sx_tele_tac_msg_header_t *tac_msg_hdr_p,
                                                       uint16_t                  total_tlvs_len)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(*tac_msg_hdr_p);

    if (total_tlvs_len > TELE_TAC_MSG_DATA_MAX_LEN_BYTES) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("total_tlvs_len %d is bigger than max allowed SX_TELE_TAC_OOB_MSG_LEN_MAX %d , err:%s \n",
                   total_tlvs_len, SX_TELE_TAC_OOB_MSG_LEN_MAX, sx_status_str(err));
        goto out;
    }

    uint64_to_bytes_array(TAC_MSG_SW_HDR_DMAC, tac_msg_hdr_p->dmac, ETHER_ADDR_LENGTH);
    uint64_to_bytes_array(TAC_MSG_SW_HDR_SMAC, tac_msg_hdr_p->smac, ETHER_ADDR_LENGTH);
    tac_msg_hdr_p->eth_type = cl_hton16(TAC_MSG_SW_HDR_ETH_TYPE);
    tac_msg_hdr_p->version_msg_type =
        TAC_MSG_SW_HDR_VERSION_MSG_TYPE_BUILD(TAC_MSG_SW_HDR_VERSION, TAC_MSG_TYPE_OOB_SW_HDR_E);

    tac_msg_hdr_p->msg_total_len = total_tlvs_len / 4; /* msg_total_len in 4B units */

out:
    return err;
}


sx_status_t __tele_impl_get_current_port_label_mapping(const sx_access_cmd_t     cmd,
                                                       oob_port_label_mapping_t *port_label_mapping_p,
                                                       uint16_t                 *port_label_mapping_count_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    uint32_t              i = 0;
    uint32_t              port_num = 0;
    uint32_t              port_id = 0;
    sx_port_type_t        port_type = 0;
    sx_port_attributes_t *port_attributes_p = NULL;
    sx_port_info_t        port_info;
    uint32_t              network_ports_cnt = 0;
    sx_swid_id_t          swid = 0;
    sx_device_id_t        device_id = 1;   /* TODO: check if user need to provide dev_id */

    SX_LOG_ENTER();

    /*get device's number of ports*/
    err = port_device_get(SX_ACCESS_CMD_COUNT, device_id, swid, NULL, &port_num);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __port_db_dump - Failed to retrieve number of ports on device (%u)"
                   "and swid (%u)  (%s).\n",
                   device_id, swid, sx_status_str(err));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_COUNT) {
        *port_label_mapping_count_p = port_num;
        goto out;
    }

    if (port_num == 0) {
        SX_LOG_WRN(" number of ports is 0\n");
        *port_label_mapping_count_p = 0;
        goto out;
    }

    port_attributes_p = (sx_port_attributes_t*)cl_malloc(port_num * sizeof(sx_port_attributes_t));
    if (port_attributes_p == NULL) {
        err = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("__port_db_dump - Failed in memory allocation (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    /*get device logical ports list*/
    err = port_device_get(SX_ACCESS_CMD_GET, device_id, swid, port_attributes_p, &port_num);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" __port_db_dump - Failed to retrieve ports info on device (%u)"
                   "and swid (%u)  (%s).\n",
                   device_id, swid, sx_status_str(err));
        goto out;
    }

    for (i = 0; i < port_num; i++) {
        port_id = port_attributes_p[i].log_port;
        port_type = SX_PORT_TYPE_ID_GET(port_id);

        if ((port_attributes_p[i].port_mode == SX_PORT_MODE_TCA_CONNECTOR) ||
            (port_type == SX_PORT_TYPE_TUNNEL) ||
            (port_type == SX_PORT_TYPE_CPU) ||
            (port_type == SX_PORT_TYPE_VPORT)) {
            continue;
        }

        /* Get port info from DB */
        err = port_db_info_get(port_id, &port_info);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("port_db_info_get() Failed for port (0x%08X) err = %s .\n",
                       port_id, sx_status_str(err));
            break;
        }

        if (port_info.mapping.mapping_mode == SX_PORT_MAPPING_MODE_DISABLE) {
            continue;
        }

        /*panel_port_id = (port_info.mapping.mapping_mode == SX_PORT_MAPPING_MODE_DISABLE) ? 0 : port_info.mapping.module_port + 1; / * PANEL PORT - ID begins with 1 * / */
        port_label_mapping_p[network_ports_cnt].local_port = cl_hton16(port_info.mapping.local_port);
        port_label_mapping_p[network_ports_cnt].port_label = cl_hton16(port_info.sdk_port_label_info.port_label);
        network_ports_cnt++;
    }

    *port_label_mapping_count_p = network_ports_cnt;

out:

    if (port_attributes_p) {
        cl_free(port_attributes_p);
    }

    return err;
}


sx_status_t __tele_impl_tac_oob_msg_validate_remote_cmd(sx_tele_tac_oob_msg_t *tac_oob_msg_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (tac_oob_msg_p->oob_msg_data.oob_cmd_msg.remote_cmd) {
    case SX_TELE_TAC_OOB_CMD_FLUSH_ALL_E:
        break;

    case SX_TELE_TAC_OOB_CMD_USER_DEF_E:
        if (!SX_CHECK_MIN(SX_TELE_TAC_OOB_CMD_USER_DEF_CMD_MIN,
                          tac_oob_msg_p->oob_msg_data.oob_cmd_msg.remote_cmd_info.user_def_cmd_info.user_def_cmd)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("user defined remote cmd 0x%x is out of range (0x%x - 0x%x).\n",
                       tac_oob_msg_p->oob_msg_data.oob_cmd_msg.remote_cmd_info.user_def_cmd_info.user_def_cmd,
                       SX_TELE_TAC_OOB_CMD_USER_DEF_CMD_MIN, SX_TELE_TAC_OOB_CMD_USER_DEF_CMD_MAX);
            goto out;
        }
        break;

    default:
        err = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("remote_cmd %d is unsupported.\n",
                   tac_oob_msg_p->oob_msg_data.oob_cmd_msg.remote_cmd);
        goto out;
    }

out:
    return err;
}


sx_status_t __tele_impl_tac_oob_msg_fill_remote_cmd_tlv(sx_tele_tac_oob_msg_t *tac_oob_msg_p,
                                                        uint8_t               *packet_data,
                                                        uint16_t               packet_data_len,
                                                        uint16_t              *total_tlv_size_p,
                                                        boolean_t             *no_space_left_in_buff_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    tlv_oob_remote_cmd_t *remote_cmd_tlv_data_p = NULL;
    tele_tlv_info_t      *tlv_p = NULL;

    err = __tele_impl_tac_oob_msg_validate_remote_cmd(tac_oob_msg_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_impl_tac_oob_msg_validate_remote_cmd failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

    /* if TLV data can't hold even 1 mapping (TLV len + data + 1 mapping) return no resources */
    if (packet_data_len < (sizeof(tlv_p->type) + sizeof(tlv_p->len) + sizeof(tlv_oob_remote_cmd_t))) {
        *no_space_left_in_buff_p = TRUE;
        goto out;
    }

    /* fill TLV part of the packet */
    tlv_p = (tele_tlv_info_t*)packet_data;
    tlv_p->type = TAC_OPT_TLV_TYPE_TAC_COMMAND_E;

    remote_cmd_tlv_data_p = (tlv_oob_remote_cmd_t*)tlv_p->data;
    tlv_p->len = sizeof(remote_cmd_tlv_data_p->remote_cmd);
    if (tac_oob_msg_p->oob_msg_data.oob_cmd_msg.remote_cmd == SX_TELE_TAC_OOB_CMD_USER_DEF_E) {
        remote_cmd_tlv_data_p->remote_cmd = cl_hton16(
            (uint16_t)tac_oob_msg_p->oob_msg_data.oob_cmd_msg.remote_cmd_info.user_def_cmd_info.user_def_cmd);
    } else {
        remote_cmd_tlv_data_p->remote_cmd = cl_hton16((uint16_t)tac_oob_msg_p->oob_msg_data.oob_cmd_msg.remote_cmd);
    }

    *total_tlv_size_p = sizeof(tlv_p->type) + sizeof(tlv_p->len) + tlv_p->len;

out:
    return err;
}


static sx_status_t __tele_impl_tac_oob_msg_fill_port_label_mapping_tlv(oob_port_label_mapping_t *port_label_mapping_p,
                                                                       uint16_t                  port_label_mapping_count,
                                                                       uint16_t                 *port_label_mapping_handled_count_p,
                                                                       uint8_t                  *packet_data,
                                                                       uint16_t                  packet_data_len_max,
                                                                       uint16_t                 *tlv_len_p,
                                                                       boolean_t                *no_space_left_in_buff_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    oob_port_label_mapping_t *port_label_mapping_list_p = NULL;
    uint16_t                  i;
    tele_tlv_info_t          *tlv_p = NULL;
    uint16_t                  packet_tlv_data_len;
    uint8_t                   calculated_mapping_count;

    /* if TLV data can't hold even 1 mapping (TLV len + data + 1 mapping) return no resources */
    if (packet_data_len_max < (sizeof(tlv_p->type) + sizeof(tlv_p->len) + sizeof(port_label_mapping_list_p[0]))) {
        *no_space_left_in_buff_p = TRUE;
        *port_label_mapping_handled_count_p = 0;
        *tlv_len_p = 0;
        goto out;
    }

    if (packet_data_len_max > sizeof(tele_tlv_info_t)) {
        packet_tlv_data_len = sizeof(tele_tlv_info_t);
    } else {
        /* else packet_tlv_data_len_max <= sizeof(tele_tlv_info_t) */
        packet_tlv_data_len = packet_data_len_max;
    }

    /* check number of mapping that will fit this buffer */
    calculated_mapping_count = (packet_tlv_data_len - sizeof(tlv_p->type) - sizeof(tlv_p->len)) /
                               sizeof(port_label_mapping_list_p[0]);

    /* even that we have enough buffer for calculated_mapping_count ,
     * if port_label_mapping_count < calculated_mapping_count ,
     * we need to send only port_label_mapping_count */
    if (port_label_mapping_count < calculated_mapping_count) {
        calculated_mapping_count = port_label_mapping_count;
    }


    tlv_p = (tele_tlv_info_t*)packet_data;
    tlv_p->type = TAC_OPT_TLV_TYPE_LIST_LOCAL_PORTS_E;
    tlv_p->len = (sizeof(port_label_mapping_list_p[0]) * calculated_mapping_count) + sizeof(uint16_t); /* port mapping start with offset 2 bytes */
    port_label_mapping_list_p = (oob_port_label_mapping_t*)((uint8_t*)tlv_p->data + sizeof(uint16_t)); /* mapping starts with offset 2 */

    for (i = 0; i < calculated_mapping_count; i++) {
        memcpy(&port_label_mapping_list_p[i],
               &port_label_mapping_p[i],
               sizeof(port_label_mapping_p[0]));
    }

    *port_label_mapping_handled_count_p = calculated_mapping_count;
    *tlv_len_p = tlv_p->len + sizeof(tlv_p->type) + sizeof(tlv_p->len);

out:
    return err;
}


sx_status_t __tele_impl_tac_oob_msg_validate_user_defined_tlv(sx_tele_tac_oob_msg_t *tac_oob_msg_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (!SX_CHECK_RANGE(SX_TELE_TAC_OOB_MSG_USER_TLV_TYPE_MIN,
                        tac_oob_msg_p->oob_msg_data.oob_user_def_msg.user_tlv_type,
                        SX_TELE_TAC_OOB_MSG_USER_TLV_TYPE_MAX)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("user defined tlv type 0x%x is out of range (0x%x - 0x%x).\n",
                   tac_oob_msg_p->oob_msg_data.oob_user_def_msg.user_tlv_type,
                   SX_TELE_TAC_OOB_MSG_USER_TLV_TYPE_MIN, SX_TELE_TAC_OOB_MSG_USER_TLV_TYPE_MAX);
        goto out;
    }

out:
    return err;
}


static sx_status_t __tele_impl_tac_oob_msg_fill_user_defined_tlv(sx_tele_tac_oob_msg_t *tac_oob_msg_p,
                                                                 uint8_t               *packet_data,
                                                                 uint16_t               packet_data_len,
                                                                 uint16_t              *tlv_len_p,
                                                                 boolean_t             *no_space_left_in_buff_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    tele_tlv_info_t *tlv_p = NULL;

    err = __tele_impl_tac_oob_msg_validate_user_defined_tlv(tac_oob_msg_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_impl_tac_oob_msg_validate_user_defined_tlv failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

    /* if TLV data can't hold even 1 mapping (TLV len + data + 1 mapping) return no resources */
    if (packet_data_len <
        (sizeof(tlv_p->type) + sizeof(tlv_p->len) + tac_oob_msg_p->oob_msg_data.oob_user_def_msg.user_tlv_len)) {
        *no_space_left_in_buff_p = TRUE;
        goto out;
    }

    /* fill OPT TLV part of the packet */
    tlv_p = (tele_tlv_info_t*)packet_data;
    tlv_p->type = tac_oob_msg_p->oob_msg_data.oob_user_def_msg.user_tlv_type;
    tlv_p->len = tac_oob_msg_p->oob_msg_data.oob_user_def_msg.user_tlv_len;
    memcpy(tlv_p->data,
           tac_oob_msg_p->oob_msg_data.oob_user_def_msg.user_tlv_data,
           tlv_p->len);


    *tlv_len_p = sizeof(tlv_p->type) + sizeof(tlv_p->len) + tlv_p->len;

out:
    return err;
}


static sx_status_t __tele_impl_align_packet_data_to_4_bytes(tele_tac_oob_packet_format_t *tac_oob_packet_p,
                                                            uint16_t                      packet_data_len,
                                                            uint16_t                     *aligned_packet_data_len_p)
{
    uint16_t padding_len = 0;

    /* to align the packet it will be enough to add padding */
    padding_len = 4 - (packet_data_len % 4);
    memset(tac_oob_packet_p->opt_tlv_data + packet_data_len, TAC_OPT_TLV_TYPE_NOP_E, padding_len); /* fill the padding with NOP tlv type */
    *aligned_packet_data_len_p = packet_data_len + padding_len;

    return SX_STATUS_SUCCESS;
}

static sx_status_t __tele_impl_update_refcnt(sx_access_cmd_t    cmd,
                                             sx_trap_group_t    trap_group,
                                             sx_tele_tac_cfg_t *tac_cfg_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(trap_group);

    SX_LOG_ENTER();

    if (cmd == SX_ACCESS_CMD_SET) {
        err = span_session_ref_cnt_inc(g_tac_span_user_handle, tac_cfg_p->tac_to_net_span_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("TAC span_session_ref_cnt_inc failed handle:%pid:%d \n",
                       g_tac_span_user_handle, tac_cfg_p->tac_to_net_span_id);
            goto out;
        }
    } else {
        err = span_session_ref_cnt_dec(g_tac_span_user_handle, tac_cfg_p->tac_to_net_span_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("TAC span_session_ref_cnt_dec failed handle:%pid:%d \n",
                       g_tac_span_user_handle, tac_cfg_p->tac_to_net_span_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_impl_tac_set(sx_access_cmd_t cmd, sx_trap_group_t trap_group, sx_tele_tac_cfg_t *tac_cfg_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = __tele_impl_tac_set_validation(cmd, trap_group, tac_cfg_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_impl_tac_set_validation failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

    err = __tele_impl_tac_set(cmd, trap_group, tac_cfg_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_impl_tac_set %s for tg:%d span:%d failed with err: %s .\n",
                   SX_ACCESS_CMD_STR(cmd), trap_group,
                   tac_cfg_p->tac_to_net_span_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_tac_get(sx_trap_group_t trap_group, sx_tele_tac_cfg_t *tac_cfg_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = __tele_impl_tac_get(trap_group, tac_cfg_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_INF("__tele_impl_tac_get for trap group:%d failed with err: %s .\n",
                   trap_group, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_impl_tac_action_set(sx_access_cmd_t              cmd,
                                         sx_tele_tac_action_filter_t *tac_action_filter_p,
                                         sx_tele_tac_action_info_t   *tac_action_info_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = __tele_impl_tac_action_set_validation(cmd, tac_action_filter_p, tac_action_info_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sdk_tele_impl_tac_action_set_validation failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

    err = __tele_impl_tac_action_set(cmd, tac_action_filter_p, tac_action_info_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_impl_tac_action_set cmd:%s , tac action %s failed with err: %s .\n",
                   SX_ACCESS_CMD_STR(cmd), sx_tele_tac_action_str(tac_action_info_p->tac_action),
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_tac_action_get(sx_tele_tac_action_status_e *tac_action_status_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = __tele_impl_tac_action_get(tac_action_status_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_impl_tac_action_get failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tele_impl_tac_statistics_get(sx_access_cmd_t cmd, sx_tele_tac_statistics_t *tac_stat_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_read_clear = FALSE;

    SX_LOG_ENTER();

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        is_read_clear = TRUE;
    }

    /* this function will populate tac_stats with TAC enabled trap group in per group section */
    err = sdk_tele_db_fill_stats_with_tac_trap_groups(tac_stat_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_impl_fill_stats_trap_groups failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

    /* this function will populate the per trap group counters and global counters */
    err = __tele_impl_tac_statistics_get(tac_stat_p, is_read_clear);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_impl_tac_action_get with cmd %s failed with err: %s .\n",
                   SX_ACCESS_CMD_STR(cmd), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


/*
 * TAC OOB message can contain multiple TLVs from same or from different types :
 *  ---------------------------------------------------------------------------------------
 | Ver 4b     | Msg type 4b | Total Msg Len 8b | Reserved 16b                           |
 *   ---------------------------------------------------------------------------------------
 | TLV type 8b              | TLV len 8b       | Data (up to 255b)                       |
 |------------------------------------------------------------------------------------------
 | TLV type 8b              | TLV len 8b       | Data (up to 255b)                       |
 |------------------------------------------------------------------------------------------
 |   ...
 |------------------------------------------------------------------------------------------
 | TLV type 8b              | TLV len 8b       | Data (up to 255b)                       |
 |------------------------------------------------------------------------------------------
 *
 * TAC OOB size should be aligned to 4 bytes .
 */
sx_status_t sdk_tele_impl_tac_oob_msg_send(sx_access_cmd_t cmd, sx_tele_tac_oob_send_cfg_t *tac_msg_cfg_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    uint32_t                     i = 0;
    tele_tac_oob_packet_format_t tac_oob_packet;
    uint8_t                     *tlv_buff_start = NULL;
    uint16_t                     tlv_buff_len_max;
    uint16_t                     tlv_len;
    uint16_t                     packet_hdr_total_tlvs_len;
    oob_port_label_mapping_t    *port_label_mapping_p = NULL, *port_label_mapping_to_send_p = NULL;
    uint16_t                     port_label_mapping_count = 0, port_label_mapping_count_to_send = 0;
    uint16_t                     port_label_mapping_handled_count = 0, total_handled_mappings_count = 0;
    boolean_t                    no_space_left_in_buff = FALSE;

    SX_LOG_ENTER();

    /* this function will populate tac_stats with TAC enabled trap group in per group section */
    err = __tele_impl_tac_oob_msg_cfg_validate(cmd, tac_msg_cfg_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__tele_impl_tac_oob_msg_cfg_validate failed with err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

    tlv_buff_start = tac_oob_packet.opt_tlv_data;
    tlv_buff_len_max = sizeof(tac_oob_packet.opt_tlv_data);
    packet_hdr_total_tlvs_len = 0;
    while (i < tac_msg_cfg_p->tac_oob_msg_list_cnt) {
        switch (tac_msg_cfg_p->tac_oob_msg_list[i].oob_msg_type) {
        case SX_TELE_TAC_OOB_MSG_TYPE_CMD_E:
            /* prepare TAC OOB command TLV */
            err = __tele_impl_tac_oob_msg_fill_remote_cmd_tlv(&tac_msg_cfg_p->tac_oob_msg_list[i],
                                                              tlv_buff_start,
                                                              tlv_buff_len_max,
                                                              &tlv_len,
                                                              &no_space_left_in_buff);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("__tele_impl_tac_oob_msg_send_remote_cmd failed for msg idx %d with err: %s .\n",
                           i, sx_status_str(err));
                goto out;
            }
            i++;
            break;

        case SX_TELE_TAC_OOB_MSG_TYPE_PORT_LABEL_MAPPING_E:
            /* prepare PORT LABEL MAPPING TLV */

            /* SDK need to take the mapping one time */
            if (port_label_mapping_p == NULL) {
                err = __tele_impl_get_current_port_label_mapping(SX_ACCESS_CMD_COUNT, NULL,
                                                                 &port_label_mapping_count);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR(" __tele_impl_get_current_port_label_mapping failed, err: %s",
                               sx_status_str(err));
                    goto out;
                }

                port_label_mapping_p =
                    (oob_port_label_mapping_t*)cl_malloc(port_label_mapping_count * sizeof(oob_port_label_mapping_t));
                if (port_label_mapping_p == NULL) {
                    err = SX_STATUS_NO_MEMORY;
                    SX_LOG_ERR("Failed in memory allocation (%s).\n",
                               sx_status_str(err));
                    goto out;
                }

                err = __tele_impl_get_current_port_label_mapping(SX_ACCESS_CMD_GET, port_label_mapping_p,
                                                                 &port_label_mapping_count);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR(" __tele_impl_get_current_port_label_mapping failed, err: %s",
                               sx_status_str(err));
                    goto out;
                }
            }

            port_label_mapping_to_send_p = port_label_mapping_p + total_handled_mappings_count;
            port_label_mapping_count_to_send = port_label_mapping_count - total_handled_mappings_count;
            /**< Prepare TAC OOB port mapping (local port to label port) TLV,
             * user may define the label ports using sx_api_span_port_attr_set() API */
            err = __tele_impl_tac_oob_msg_fill_port_label_mapping_tlv(port_label_mapping_to_send_p,
                                                                      port_label_mapping_count_to_send,
                                                                      &port_label_mapping_handled_count,
                                                                      tlv_buff_start,
                                                                      tlv_buff_len_max,
                                                                      &tlv_len,
                                                                      &no_space_left_in_buff);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("__tele_impl_tac_oob_msg_send_remote_cmd failed for msg idx %d with err: %s .\n",
                           i, sx_status_str(err));
                goto out;
            }
            total_handled_mappings_count += port_label_mapping_handled_count;

            /* port mapping can use multiple TLVs inside single packet :
             *      every TLV can have up to 255 bytes , every mapping use 4 bytes , so MAX mappings per TLV is 63
             * but also can require multiple packets :
             *      in case system have 256 ports , 5 packets will be required to send all mapping data
             *
             * We will pass to next TAC message from tac_msg_cfg_p->tac_oob_msg_list only when we will finish
             * to send all mapping
             */
            if ((port_label_mapping_count - total_handled_mappings_count) == 0) {
                i++;
            }

            break;

        case SX_TELE_TAC_OOB_MSG_TYPE_USER_DEF_E:
            /* prepare TAC USER DEFINED TLV */

            err = __tele_impl_tac_oob_msg_fill_user_defined_tlv(&tac_msg_cfg_p->tac_oob_msg_list[i],
                                                                tlv_buff_start,
                                                                tlv_buff_len_max,
                                                                &tlv_len,
                                                                &no_space_left_in_buff);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("__tele_impl_tac_oob_msg_fill_user_defined_tlv failed for msg idx %d with err: %s .\n",
                           i, sx_status_str(err));
                goto out;
            }

            i++;

            break;

        default:
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("oob msg type %d is unsupported.\n", tac_msg_cfg_p->tac_oob_msg_list[i].oob_msg_type);
            goto out;
        }


        /* if no space left in packet buffer then send the packet and prepare packet buffer for next TLVs */
        if (no_space_left_in_buff) {
            /* send the packet */
            err = __tele_impl_send_oob_msg_to_span(tac_msg_cfg_p->tac_to_net_span_id,
                                                   &tac_oob_packet,
                                                   packet_hdr_total_tlvs_len);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to send oob msg to span id %d , err: %s \n",
                           tac_msg_cfg_p->tac_to_net_span_id, sx_status_str(err));
                goto out;
            }

            /* prepare buffer to be used for other packets */
            tlv_buff_start = tac_oob_packet.opt_tlv_data;
            tlv_buff_len_max = sizeof(tac_oob_packet.opt_tlv_data);
            packet_hdr_total_tlvs_len = 0;
            no_space_left_in_buff = FALSE;
        } else {
            packet_hdr_total_tlvs_len += tlv_len;
            tlv_buff_start += tlv_len;
            tlv_buff_len_max -= tlv_len;
        }
    }

    /* send packet if we have some data in the buffer */
    if (packet_hdr_total_tlvs_len > 0) {
        /* send the packet */
        err = __tele_impl_send_oob_msg_to_span(tac_msg_cfg_p->tac_to_net_span_id,
                                               &tac_oob_packet,
                                               packet_hdr_total_tlvs_len);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to send oob msg to span id %d , err: %s \n",
                       tac_msg_cfg_p->tac_to_net_span_id, sx_status_str(err));
            goto out;
        }
    }

out:
    if (port_label_mapping_p) {
        cl_free(port_label_mapping_p);
    }

    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_tele_impl_port_bw_gauge_set(const sx_access_cmd_t cmd, sx_tele_gauge_config_t *gauge_config_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_tele_gauge_config_t  gauge_config;
    sx_tele_gauge_config_t *gauge_config_pointer = gauge_config_p;


    if (g_ops.hwd_tele_port_bw_gauge_set_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_DBG("bw gauge is not supported for this chip type %s.\n",
                   sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
        goto out;
    }

    /*when cmd=DESTROY need to return to default values. */
    if (cmd == SX_ACCESS_CMD_DESTROY) {
        if (gauge_config_p == NULL) {
            gauge_config_pointer = &gauge_config;
        }
        gauge_config_pointer->log_time_interval = DEFAULT_LOG_TIME_ITNERVAL;
        gauge_config_pointer->alpha_factor = DEFAULT_ALPHA_FACTOR;
    } else {
        if (utils_check_pointer(gauge_config_p, "gauge_config_p")) {
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    err = sdk_tele_db_port_bw_gauge_set(gauge_config_pointer);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set port BW gauge DB, err = %s\n", sx_status_str(err));
        goto out;
    }

    err = g_ops.hwd_tele_port_bw_gauge_set_pfn(gauge_config_pointer);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set port BW gauge, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    return err;
}

sx_status_t sdk_tele_impl_port_bw_gauge_get(sx_tele_gauge_config_t *gauge_config_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (g_ops.hwd_tele_port_bw_gauge_set_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_DBG("bw gauge is not supported for this chip type %s.\n",
                   sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
        goto out;
    }

    if (utils_check_pointer(gauge_config_p, "gauge_config_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sdk_tele_db_port_bw_gauge_get(gauge_config_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get port BW gauge from DB, err = %s\n", sx_status_str(err));
    }
out:
    return err;
}

sx_status_t sdk_tele_impl_port_bw_gauge_data_get(sx_tele_gauge_key_t *gauge_key_p, sx_tele_gauge_data_t *gauge_data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (g_ops.hwd_tele_port_bw_gauge_data_get_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_DBG("bw gauge is not supported for this chip type %s.\n",
                   sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
        goto out;
    }

    if (utils_check_pointer(gauge_key_p, "gauge_key_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(gauge_data_p, "gauge_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = g_ops.hwd_tele_port_bw_gauge_data_get_pfn(gauge_key_p, gauge_data_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get port BW gauge data, err = %s\n", sx_status_str(err));
    }
out:
    return err;
}
