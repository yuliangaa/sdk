/*
 * Copyright (C) 2011-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __HWI_TELE_DB_H__
#define __HWI_TELE_DB_H__

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_tele.h>
#include "sx/utils/sdk_refcount.h"
#include <complib/cl_fleximap.h>
#include <utils/utils.h>
#include "sx/utils/gc.h"

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Defines
 ***********************************************/
#define PORT_BIT                  0
#define TC_BIT                    1
#define PG_BIT                    2
#define DEFAULT_ALPHA_FACTOR      2
#define DEFAULT_LOG_TIME_ITNERVAL 7

typedef enum sx_tele_hash_sig_prof_idx_internal {
    SX_TELE_HASH_SIG_PROF_INTERNAL_IDX_0_E,
    SX_TELE_HASH_SIG_PROF_INTERNAL_IDX_1_E,
    SX_TELE_HASH_SIG_PROF_INTERNAL_MIN = SX_TELE_HASH_SIG_PROF_INTERNAL_IDX_0_E,
    SX_TELE_HASH_SIG_PROF_INTERNAL_MAX = SX_TELE_HASH_SIG_PROF_INTERNAL_IDX_1_E,
} sx_tele_hash_sig_prof_idx_int_t;

#define SX_TELE_HASH_SIG_PROF_DEFAULT SX_TELE_HASH_SIG_PROF_INTERNAL_IDX_1_E

#define SX_TELE_HASH_SIG_FIELD_ENABLE_CHECK_RANGE(field) \
    (SX_CHECK_RANGE(SX_TELE_HASH_SIG_FIELD_ENABLE_MIN,   \
                    field, SX_TELE_HASH_SIG_FIELD_ENABLE_MAX))

#define SX_TELE_HASH_SIG_FIELD_CHECK_RANGE(field)              \
    (SX_CHECK_RANGE(SX_TELE_HASH_SIG_FIELDS_MIN,               \
                    field,                                     \
                    SX_TELE_HASH_SIG_OUTER_IPV6_FLOW_LABEL) || \
     SX_CHECK_RANGE(SX_TELE_HASH_SIG_OUTER_MPLS_LABEL_0,       \
                    field,                                     \
                    SX_TELE_HASH_SIG_OUTER_LAST) ||            \
     SX_CHECK_RANGE(SX_TELE_HASH_SIG_INNER_SMAC,               \
                    field,                                     \
                    SX_TELE_HASH_SIG_INNER_LAST) ||            \
     SX_CHECK_RANGE(SX_TELE_HASH_SIG_GENERAL_FIELDS_FIRST,     \
                    field,                                     \
                    SX_TELE_HASH_SIG_GENERAL_FIELDS_LAST))

#define SX_TELE_HASH_SIG_OUTER_FIELD_OFFSET_1 32
#define SX_TELE_HASH_SIG_OUTER_FIELD_OFFSET_2 64
#define SX_TELE_HASH_SIG_OUTER_FIELD_OFFSET_3 96

#define SX_TELE_HASH_SIG_IS_FIELD_ENABLE_OUTER(field)   \
    ((SX_TELE_HASH_SIG_INNER_ENABLES_OFFSET > field) && \
     (SX_TELE_HASH_SIG_OUTER_ENABLES_OFFSET <= field))
#define SX_TELE_HASH_SIG_IS_FIELD_ENABLE_INNER(field)          \
    ((SX_TELE_HASH_SIG_FIELD_ENABLE_INNER_L4_IPV6 >= field) && \
     (SX_TELE_HASH_SIG_INNER_ENABLES_OFFSET <= field))
#define SX_TELE_HASH_SIG_IS_FIELD_OUTER(field) \
    ((SX_TELE_HASH_SIG_OUTER_LAST >= field) && \
     (SX_TELE_HASH_SIG_OUTER_FIELDS_OFFSET <= field))
#define SX_TELE_HASH_SIG_IS_FIELD_INNER(field) \
    ((SX_TELE_HASH_SIG_INNER_LAST >= field) && \
     (SX_TELE_HASH_SIG_INNER_FIELDS_OFFSET <= field))
#define SX_TELE_HASH_SIG_IS_FIELD_GENERAL(field)          \
    ((SX_TELE_HASH_SIG_GENERAL_FIELDS_OFFSET <= field) && \
     (SX_TELE_HASH_SIG_GENERAL_FIELDS_LAST >= field))
#define SX_TELE_HASH_SIG_GP_REGISTER_TO_OFFSET(field) \
    (field - SX_TELE_HASH_SIG_GENERAL_FIELDS_GP_REGISTER_OFFSET + 2)

#define SX_TELE_HASH_SIG_IS_FIELD_CUSTOM_BYTE(field)             \
    ((SX_TELE_HASH_SIG_GENERAL_FIELDS_CUSTOM_BYTE_0 <= field) && \
     (SX_TELE_HASH_SIG_GENERAL_FIELDS_CUSTOM_BYTE_LAST >= field))
#define SX_TELE_HASH_SIG_IS_FIELD_GP_REGISTER(field)                  \
    ((SX_TELE_HASH_SIG_GENERAL_FIELDS_GP_REGISTER_OFFSET <= field) && \
     (SX_TELE_HASH_SIG_GENERAL_FIELDS_GP_REGISTER_LAST >= field))
#define SX_TELE_HASH_SIG_FIELD_GP_REGISTER_GET(field) \
    ((field - SX_TELE_HASH_SIG_GENERAL_FIELDS_GP_REGISTER_OFFSET) / 2)


#define SX_TELE_HASH_SIG_ENABLE_BITS_SIZE                                      \
    ((SX_TELE_HASH_SIG_FIELD_ENABLE_MAX - SX_TELE_HASH_SIG_FIELD_ENABLE_MIN) / \
     8 + 1)
#define SX_TELE_HASH_SIG_FIELD_BITS_SIZE ((SX_TELE_HASH_SIG_FIELDS_MAX - SX_TELE_HASH_SIG_FIELDS_MIN) / 8 + 1)

#define SX_TELE_HASH_SIG_FIELD_GP_REGISTER_INDEX_GET(field) \
    (field - SX_TELE_HASH_SIG_GENERAL_FIELDS_GP_REGISTER_OFFSET)
#define SX_TELE_HASH_SIG_GP_REGISTER_FIELDS_NUM         \
    (SX_TELE_HASH_SIG_GENERAL_FIELDS_GP_REGISTER_LAST - \
     SX_TELE_HASH_SIG_GENERAL_FIELDS_GP_REGISTER_OFFSET + 1)

#define SX_TELE_DBG_DUMP_PORT_LIST_BUF_SIZE 100
/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/* Histogram key structure
 *************************************************************************************************
 * +--------------------------------+---------------+--------------+------------------+----------+
 * | Log Port [63:32]               | Unused [31:20]| Type [19:16] | Direction [15:8] | TC [7:0] |
 * +--------------------------------+---------------+--------------+------------------+----------+
 *************************************************************************************************
 */
#define BUILD_HISTOGRAM_KEY(log_port, traffic_class, direction, hist_type) \
    ((uint64_t)log_port << 32 |                                            \
        (uint64_t)(hist_type & 0xF) << 16 |                                \
        (uint64_t)direction << 8 |                                         \
        (uint64_t)traffic_class)

#define BUILD_LAST_CONGESTION_THRESHOLD_KEY(log_port, direction) ((uint64_t)log_port << 32 | (uint64_t)direction)

#define GET_HISTOGRAM_PORT(histogram_id)      ((uint64_t)histogram_id & 0xFFFFFFFF00000000)
#define GET_HISTOGRAM_TYPE(histogram_id)      ((uint64_t)histogram_id & 0x00000000000F0000)
#define GET_HISTOGRAM_DIRECTION(histogram_id) ((uint64_t)histogram_id & 0X000000000000FF00)
#define GET_HISTOGRAM_TC(histogram_id)        ((uint64_t)histogram_id & 0x00000000000000FF)

#define BUILD_CONGGESTION_THRESHOLD_KEY(log_port, direction, tc_pg) \
    ((((uint64_t)log_port << 32) | ((uint64_t)(direction & 0x3) << 30) | ((uint64_t)tc_pg)))

#define BUILD_LATENCY_THRESHOLD_KEY(log_port, tc_sp) \
    (((uint64_t)log_port << 32) | (uint64_t)tc_sp)


typedef struct tele_db_last_congestion_threshold_entry {
    cl_map_item_t            map_item;
    sx_port_threshold_type_e key_type;
    sx_port_log_id_t         log_port;
    sx_tele_threshold_data_t congestion_data;
    uint8_t                  cnt;
} tele_db_last_congestion_threshold_entry_t;

typedef struct tele_id_item {
    cl_list_item_t list_item;
    uint32_t       tele_id;
} tele_id_item_t;

typedef struct tele_db_histogram_data {
    sx_tele_histogram_key_t             tele_key;
    sx_tele_histogram_attributes_data_t tele_attr;
    cl_list_item_t                     *list_item;
} tele_db_histogram_data_t;

typedef struct tele_db_histogram_entry {
    cl_pool_item_t           pool_item;
    cl_map_item_t            map_item;
    tele_db_histogram_data_t data;
} tele_db_histogram_entry_t;


typedef struct tele_db_histogram_port_latency_config_data {
    uint32_t                                        num_of_configured_tcs;
    sx_tele_histogram_queue_depth_attributes_data_t data;
} tele_db_histogram_port_latency_config_data_t;

typedef struct tele_db_threshold_data {
    sx_tele_threshold_key_t  key;
    sx_tele_threshold_data_t data;
} tele_db_threshold_data_t;

typedef struct tele_db_threshold_entry {
    cl_pool_item_t           pool_item;
    cl_map_item_t            map_item;
    tele_db_threshold_data_t data;
} tele_db_threshold_entry_t;

typedef struct tele_db_latency_threshold_key_entry {
    cl_pool_item_t           pool_item;
    cl_map_item_t            map_item;
    sx_tele_threshold_key_t  key;
    sx_tele_threshold_data_t data;
} tele_db_latency_threshold_key_entry_t;

typedef struct tele_db_latency_threshold_data_entry {
    cl_pool_item_t           pool_item;
    cl_map_item_t            map_item;
    sx_tele_threshold_data_t data; /* Key: threshold_high */
    uint8_t                  latency_id; /* Data */
    uint32_t                 ref_count; /* Data */
} tele_db_latency_threshold_data_entry_t;

typedef struct sx_tele_latency_threshold_filter {
    boolean_t              port_filter_valid;
    sx_port_log_id_t       port_filter;
    boolean_t              tc_filter_valid;
    sx_cos_traffic_class_t tc_filter;
} sx_tele_latency_threshold_filter_t;

typedef struct tele_db_gauge_config {
    uint8_t log_time_interval;
    uint8_t alpha_factor;
} tele_db_gauge_config_t;


typedef enum dbg_hist_attr {
    DBG_HIST_ID_E,
    DBG_HIST_PORT_E,
    DBG_HIST_TYPE_E,
    DBG_HIST_MODE_E,
    DBG_HIST_SAMPLE_TIME_E,
    DBG_HIST_TIME_E,
    DBG_HIST_RESOLUTION_E,
    DBG_HIST_MIN_BOUNDERY_E,
    DBG_HIST_MAX_BOUNDERY_E,
    DBG_HIST_TC_PG_E,
    DBG_HIST_COUNTER_TYPE_E,
    DBG_HIST_CONTROL_E,
    DBG_HIST_REPETITION_E
} dbg_hist_attr_e;

typedef enum dbg_latency_hist_attr {
    DBG_LATENCY_HIST_PORT_E,
    DBG_LATENCY_HIST_TC_NUM_E,
    DBG_LATENCY_HIST_MIN_BOUNDERY_E,
    DBG_LATENCY_HIST_MODE_E,
    DBG_LATENCY_HIST_RESOLUTION_E
} dbg_latency_hist_attr_e;

typedef enum dbg_thr {
    DBG_THR_PORT_E,
    DBG_THR_DIRECTION_E,
    DBG_THR_TC_PG_E,
    DBG_THR_MODE_E,
    DBG_THR_THRESHOLD_E,
    DBG_THR_THRESHOLD_LOW_E,
} dbg_thr_e;

typedef enum dbg_hash_sig_attr {
    DBG_HASH_SIG_PROFILE_ID_E,
    DBG_HASH_SIG_GSH_OUTER_E,
    DBG_HASH_SIG_GSH_INNER_E,
    DBG_HASH_SIG_GSH_CBSET_E,
    DBG_HASH_SIG_IS_DEFAULT,
} dbg_hash_sig_attr_e;

/* TAC SW Header params */
typedef struct sx_tele_tac_sw_header_info {
    uint32_t uid_device_id;
    uint16_t max_lifetime;
} sx_tele_tac_sw_header_info_t;

typedef struct sx_tac_trap_group_info {
    boolean_t            tac_connected;
    boolean_t            span_session_id_valid;
    sx_span_session_id_t span_session_id;
    boolean_t            hw_trap_group_valid;
    uint32_t             hw_trap_group;
    boolean_t            gc_handle_valid;
    gc_handle_t          gc_handle;
} tele_db_tac_trap_group_info_t;

typedef enum {
    TELE_DB_TAC_TRAP_GROUP_INFO_MASK_SPAN_SESSION_ID = (1 << 0),
    TELE_DB_TAC_TRAP_GROUP_INFO_MASK_HW_TRAP_GROUP   = (1 << 1),
    TELE_DB_TAC_TRAP_GROUP_INFO_MASK_GC_STATE        = (1 << 2),
    TELE_DB_TAC_TRAP_GROUP_INFO_MASK_GC_HANDLE       = (1 << 3),
} tele_db_tac_trap_group_info_mask_e;

typedef struct tele_db_tac_trap_group_data {
    uint16_t                      trap_group;
    tele_db_tac_trap_group_info_t tac_trap_group_info;
} tele_db_tac_trap_group_data_t;

typedef struct tele_db_tac_trap_group_entry {
    cl_pool_item_t                pool_item;
    cl_map_item_t                 map_item;
    tele_db_tac_trap_group_data_t data;
} tele_db_tac_trap_group_entry_t;

typedef sx_status_t (*tele_db_tac_trap_group_db_update_pfn_t)(uint16_t trap_group, void *param_p);

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t sdk_tele_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t sdk_tele_db_init(const uint32_t histogram_max_count,
                             const uint32_t threshold_max_count,
                             const uint32_t latency_threshold_key_count,
                             const uint32_t latency_threshold_data_count);

sx_status_t sdk_tele_db_deinit(boolean_t is_forced);

sx_status_t sdk_tele_db_histogram_add(const sx_tele_histogram_key_t             key,
                                      const sx_tele_histogram_attributes_data_t data,
                                      uint32_t                                 *tele_id_p);

sx_status_t sdk_tele_db_histogram_modify(const sx_tele_histogram_key_t             key,
                                         const sx_tele_histogram_attributes_data_t data,
                                         uint32_t                                 *tele_id_p);

sx_status_t sdk_tele_db_histogram_delete(const sx_tele_histogram_key_t key,
                                         uint32_t                     *tele_id_p);

sx_status_t sdk_tele_db_histogram_get(const sx_tele_histogram_key_t        tele_key,
                                      sx_tele_histogram_attributes_data_t *data_p,
                                      uint32_t                            *tele_id);

sx_status_t sdk_tele_db_histogram_iter_get_first(const sx_tele_histogram_filter_t    *filter_p,
                                                 sx_tele_histogram_key_t             *key_list_p,
                                                 sx_tele_histogram_attributes_data_t *data_list_p,
                                                 uint32_t                            *hist_cnt_p);

sx_status_t sdk_tele_db_histogram_iter_get_next(const sx_tele_histogram_filter_t    *filter_p,
                                                sx_tele_histogram_key_t              key,
                                                sx_tele_histogram_key_t             *key_list_p,
                                                sx_tele_histogram_attributes_data_t *data_list_p,
                                                uint32_t                            *hist_cnt_p);

sx_status_t sdk_tele_db_histogram_iter_get(const sx_tele_histogram_filter_t    *filter_p,
                                           sx_tele_histogram_key_t             *key_p,
                                           sx_tele_histogram_key_t             *key_list_p,
                                           sx_tele_histogram_attributes_data_t *data_list_p,
                                           uint32_t                            *hist_cnt_p);

sx_status_t sdk_tele_db_latency_histogram_port_tc_validate(const sx_port_log_id_t                     log_port,
                                                           const sx_tele_histogram_attributes_data_t *data,
                                                           boolean_t                                 *is_valid_p);

sx_status_t sdk_tele_db_threshold_add(const sx_tele_threshold_key_t  key,
                                      const sx_tele_threshold_data_t data);

sx_status_t sdk_tele_db_threshold_modify(const sx_tele_threshold_key_t  key,
                                         const sx_tele_threshold_data_t data);

sx_status_t sdk_tele_db_threshold_delete(const sx_tele_threshold_key_t key);

sx_status_t sdk_tele_db_threshold_get(const sx_tele_threshold_key_t tele_key,
                                      sx_tele_threshold_data_t     *data_p);

sx_status_t sdk_tele_db_threshold_iter_get_first(const sx_tele_threshold_filter_t *filter_p,
                                                 sx_tele_threshold_key_t          *key_list_p,
                                                 sx_tele_threshold_data_t         *data_list_p,
                                                 uint32_t                         *thr_cnt_p);

sx_status_t sdk_tele_db_threshold_iter_get_next(const sx_tele_threshold_filter_t *filter_p,
                                                sx_tele_threshold_key_t           key,
                                                sx_tele_threshold_key_t          *key_list_p,
                                                sx_tele_threshold_data_t         *data_list_p,
                                                uint32_t                         *thr_cnt_p);

sx_status_t sdk_tele_db_threshold_iter_get(const sx_tele_threshold_filter_t *filter_p,
                                           sx_tele_threshold_key_t          *key_p,
                                           sx_tele_threshold_key_t          *key_list_p,
                                           sx_tele_threshold_data_t         *data_list_p,
                                           uint32_t                         *thr_cnt_p);

sx_status_t sdk_tele_db_latency_threshold_key_add(const sx_tele_threshold_key_t  key,
                                                  const sx_tele_threshold_data_t data);

sx_status_t sdk_tele_db_latency_threshold_key_modify(const sx_tele_threshold_key_t  key,
                                                     const sx_tele_threshold_data_t data);

sx_status_t sdk_tele_db_latency_threshold_key_delete(const sx_tele_threshold_key_t key);

sx_status_t sdk_tele_db_latency_threshold_key_get(const sx_tele_threshold_key_t key,
                                                  sx_tele_threshold_data_t     *data_p);

sx_status_t sdk_tele_db_latency_threshold_key_iter_get_first(sx_tele_latency_threshold_filter_t *filter_p,
                                                             sx_tele_threshold_key_t            *key_list_p,
                                                             sx_tele_threshold_data_t           *data_list_p,
                                                             uint32_t                           *data_cnt_p);

sx_status_t sdk_tele_db_latency_threshold_data_alloc(const sx_tele_threshold_data_t data,
                                                     uint8_t                       *letancy_id_p,
                                                     boolean_t                     *is_new_p);

sx_status_t sdk_tele_db_latency_threshold_data_free(const sx_tele_threshold_data_t data);

sx_status_t sdk_tele_db_histogram_key_iter_p_get(sx_access_cmd_t                 cmd,
                                                 const sx_tele_histogram_key_t **key_pp);

sx_status_t sdk_tele_db_last_congestion_threshold_entry_update(const sx_access_cmd_t           cmd,
                                                               const sx_tele_threshold_key_t  *key_p,
                                                               const sx_tele_threshold_data_t *data_p);

sx_status_t sdk_tele_db_last_congestion_threshold_data_get(const sx_tele_threshold_key_t *key_p,
                                                           sx_tele_threshold_data_t      *data_p);

void sdk_tele_db_histogram_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
void sdk_tele_db_bw_gauge_attributes_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
void sdk_tele_db_last_congestion_threshold_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
void sdk_tele_db_latency_histogram_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
void sdk_tele_db_threshold_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
void sdk_tele_db_threshold_latency_key_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
void sdk_tele_db_threshold_latency_data_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

sx_status_t sdk_tele_db_hash_sig_params_set(const sx_tele_hash_sig_prof_idx_int_t     hash_sig_prof_idx,
                                            const sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_classifier_p,
                                            const sx_tele_hash_sig_params_t          *hash_params_p,
                                            const sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                            const uint32_t                            hash_field_enable_list_cnt,
                                            const sx_tele_hash_sig_field_t           *hash_field_list_p,
                                            const uint32_t                            hash_field_list_cnt);

sx_status_t sdk_tele_db_hash_sig_params_get(sx_tele_hash_sig_prof_idx_int_t     hash_sig_prof_idx,
                                            sx_tele_hash_sig_classifier_attr_t *hash_sig_prof_classifier_p,
                                            sx_tele_hash_sig_params_t          *hash_params_p,
                                            sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                            uint32_t                           *hash_field_enable_list_cnt_p,
                                            sx_tele_hash_sig_field_t           *hash_field_list_p,
                                            uint32_t                           *hash_field_list_cnt_p);

void sdk_tele_db_hash_sig_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

/*
 * TAC DB related functions
 */
sx_status_t sdk_tele_db_tac_init();
sx_status_t sdk_tele_db_tac_deinit(boolean_t is_forced);
sx_status_t sdk_tele_db_tac_sw_header_set(sx_tele_tac_sw_header_info_t *tac_sw_header_info_p);
sx_status_t sdk_tele_db_tac_sw_header_get(sx_tele_tac_sw_header_info_t *tac_sw_header_info_p);
void sdk_tele_db_tac_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
sx_status_t sdk_tele_db_tac_trap_group_map_add(sx_trap_group_t                trap_group,
                                               tele_db_tac_trap_group_info_t *tac_trap_group_info_p);
sx_status_t sdk_tele_db_tac_trap_group_map_delete(sx_trap_group_t trap_group);
sx_status_t sdk_tele_db_tac_trap_group_map_get(sx_trap_group_t trap_group, tele_db_tac_trap_group_data_t *data_p);
sx_status_t sdk_tele_db_tac_trap_group_map_set(tele_db_tac_trap_group_info_mask_e mask,
                                               sx_trap_group_t trap_group, tele_db_tac_trap_group_data_t *data_p);
sx_status_t sdk_tele_db_tac_trap_group_foreach(tele_db_tac_trap_group_db_update_pfn_t func, void *param_p);
sx_status_t sdk_tele_db_fill_stats_with_tac_trap_groups(sx_tele_tac_statistics_t *tac_stat_p);
sx_status_t sdk_tele_db_tac_connected_trap_group_count_get(uint32_t *tac_trap_group_count_p);
sx_status_t sdk_tele_db_port_bw_gauge_set(const sx_tele_gauge_config_t *gauge_config_p);

sx_status_t sdk_tele_db_port_bw_gauge_get(sx_tele_gauge_config_t *gauge_config_p);


#endif    /* __HWI_TELE_DB_H__ */
