/*
 * Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWI_TELE_IMPL_H__
#define __HWI_TELE_IMPL_H__

#include <sx/sdk/sx_types.h>
#include "tele_db.h"
#include "utils/sx_adviser.h"
#include <ethl2/lag_sink.h>
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/
#define SX_TELE_HISTOGRAM_DIRECTION_INGRESS 0
#define SX_TELE_HISTOGRAM_DIRECTION_EGRESS  1

#define SX_TELE_HISTOGRAM_TYPE_ID_PREFIX      0x1000
#define SX_TELE_HISTOGRAM_TYPE_ID_QUEUE_DEPTH 0
#define SX_TELE_HISTOGRAM_TYPE_ID_LATENCY     2
#define SX_TELE_HISTOGRAM_TYPE_ID_COUNTER     3

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define SX_TELE_TAC_ACTION_CHECK_RANGE(TAC_ACTION) \
    SX_CHECK_MAX(TAC_ACTION, SX_TELE_TAC_ACTION_MAX_E)

#define SX_TELE_TAC_PERIODIC_INTERVAL_MIN 0
#define SX_TELE_TAC_PERIODIC_INTERVAL_MAX 13
#define SX_TELE_TAC_PERIODIC_INTERVAL_CHECK_RANGE(INTERVAL) \
    SX_CHECK_MAX(INTERVAL, SX_TELE_TAC_PERIODIC_INTERVAL_MAX)

#define SX_TELE_TAC_TRUNCATION_SIZE_MIN 64
#define SX_TELE_TAC_TRUNCATION_SIZE_MAX 8000      /* according to TAC Arch specification */
#define SX_TELE_TAC_TRUNCATION_SIZE_CHECK_RANGE(TAC_TRUNC_SIZE) \
    SX_CHECK_RANGE(SX_TELE_TAC_TRUNCATION_SIZE_MIN, TAC_TRUNC_SIZE, SX_TELE_TAC_TRUNCATION_SIZE_MAX)

/* default TAC SW header values */
#define TAC_MSG_SW_HDR_DMAC            0x0002C900CAFEUL
#define TAC_MSG_SW_HDR_SMAC            0x0002C901CAFEUL
#define TAC_MSG_SW_HDR_ETH_TYPE        0x8932
#define TAC_MSG_SW_HDR_VERSION         1
#define TAC_MSG_SW_HDR_DEFAULT_DEV_ID  0x0002C900
#define TAC_MSG_SW_HDR_TOTAL_LEN_UNITS 4

#define SX_TELE_TAC_ACTION_CHECK_RANGE(TAC_ACTION) \
    SX_CHECK_MAX(TAC_ACTION, SX_TELE_TAC_ACTION_MAX_E)

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum tele_threshold_direction_type {
    TELE_THRESHOLD_DIRECTION_EGRESS_E  = 0,
    TELE_THRESHOLD_DIRECTION_INGRESS_E = 1,
} tele_threshold_direction_type_e;

typedef uint32_t sx_tele_id_t;

/* function pointers for HWD APIs */
typedef struct hwi_tele_ops {
    sx_status_t (*hwd_tele_init_pfn)(sx_tele_init_params_t *params_p);
    sx_status_t (*hwd_tele_deinit_pfn)(boolean_t is_forced);
    sx_status_t (*hwd_tele_histogram_type_validation_pfn)(const sx_tele_histogram_key_t *key_p);
    sx_status_t (*hwd_tele_histogram_create_pfn)(const sx_tele_histogram_key_t             key,
                                                 const sx_tele_histogram_attributes_data_t data,
                                                 const sx_tele_id_t                        tele_id,
                                                 uint8_t                                  *num_of_emads);
    sx_status_t (*hwd_tele_histogram_edit_pfn)(const sx_tele_histogram_key_t             key,
                                               const sx_tele_histogram_attributes_data_t data,
                                               const sx_tele_id_t                        tele_id);
    sx_status_t (*hwd_tele_histogram_destroy_pfn)(const sx_tele_histogram_key_t key,
                                                  const sx_tele_id_t            tele_id);
    sx_status_t (*hwd_tele_histogram_data_get_pfn)(const sx_tele_histogram_key_t key,
                                                   const sx_tele_id_t            tele_id,
                                                   boolean_t                     is_clear,
                                                   sx_tele_histogram_data_t     *histogram_p);
    sx_status_t (*hwd_tele_threshold_default_set_pfn)(const sx_tele_threshold_key_t key);
    sx_status_t (*hwd_tele_threshold_edit_pfn)(const sx_port_log_id_t                log_port,
                                               const tele_threshold_direction_type_e direction,
                                               const uint8_t                        *tc_pg_p,
                                               const uint8_t                         tc_pg_cnt,
                                               const sx_tele_threshold_data_t        data);
    sx_status_t (*hwd_tele_threshold_destroy_pfn)(const sx_port_log_id_t                log_port,
                                                  const tele_threshold_direction_type_e direction,
                                                  const uint8_t                        *tc_pg_p,
                                                  const uint8_t                         tc_pg_cnt);
    sx_status_t (*hwd_tele_threshold_crossed_data_get_pfn)(sx_tele_threshold_crossed_data_keys_t *data_p,
                                                           const uint32_t                         list_cnt);
    sx_status_t (*hwd_tele_threshold_key_validation_pfn)(const sx_tele_threshold_key_t key);
    sx_status_t (*hwd_tele_threshold_data_validation_pfn)(const sx_tele_threshold_key_t  key,
                                                          const sx_tele_threshold_data_t data);
    sx_status_t (*hwd_tele_threshold_latency_alloc_pfn)(const uint8_t                  latency_id,
                                                        const sx_tele_threshold_data_t data);
    sx_status_t (*hwd_tele_threshold_latency_bind_pfn)(const uint8_t                 latency_id,
                                                       const sx_tele_threshold_key_t key);
    sx_status_t (*hwd_tele_global_configuration_init_pfn)(const sx_dev_id_t dev_id);

    sx_status_t (*hwd_tele_attr_set_pfn)(const sx_tele_attrib_t attr,
                                         sx_port_id_t          *port,
                                         const sx_swid_id_t     swid);
    sx_status_t (*hwd_tele_hash_sig_prof_set_pfn)(const uint8_t                             prof_idx,
                                                  const sx_tele_hash_sig_classifier_attr_t *hash_classifier_p,
                                                  const sx_tele_hash_sig_params_t          *hash_params_p,
                                                  const sx_tele_hash_sig_field_enable_t    *hash_field_enable_list_p,
                                                  const uint32_t                            hash_field_enable_list_cnt,
                                                  const sx_tele_hash_sig_field_t           *hash_field_list_p,
                                                  const uint32_t                            hash_field_list_cnt);
    sx_status_t (*hwd_tele_tac_attr_set_pfn)(const sx_tele_tac_attr_t *tac_attr_p);
    sx_status_t (*hwd_tele_tac_sw_header_set_pfn)(const sx_tele_tac_sw_header_info_t *event_sw_header_p);
    sx_status_t (*hwd_tele_tac_set_pfn)(sx_access_cmd_t cmd, sx_trap_group_t trap_group, uint8_t hw_span_session_id);
    sx_status_t (*hwd_tele_tac_action_set_pfn)(sx_access_cmd_t              cmd,
                                               sx_tele_tac_action_filter_t *tac_action_filter_p,
                                               sx_tele_tac_action_info_t   *tac_action_info_p,
                                               sx_tele_tac_action_status_e *tac_action_status_p);
    sx_status_t (*hwd_tele_tac_action_get_pfn)(sx_tele_tac_action_status_e *tac_action_status_p);
    sx_status_t (*hwd_tele_tac_statistics_get_pfn)(sx_tele_tac_statistics_t *tele_tac_statistics_p,
                                                   boolean_t                 is_read_clear);

    sx_status_t (*hwd_tele_counter_histogram_type_validation_pfn)(const sx_tele_histogram_attributes_data_t *data);

    sx_status_t (*hwd_tele_port_bw_gauge_set_pfn)(sx_tele_gauge_config_t *gauge_config_p);
    sx_status_t (*hwd_tele_port_bw_gauge_data_get_pfn)(sx_tele_gauge_key_t  *gauge_key_p,
                                                       sx_tele_gauge_data_t *gauge_data_p);
} hwi_tele_ops_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t sdk_tele_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t sdk_tele_impl_params_get(boolean_t *is_tele_init_done_p);

sx_status_t sdk_tele_impl_init(const sx_tele_init_params_t * params_p);

sx_status_t sdk_tele_check_init(void);

sx_status_t sdk_tele_impl_deinit(boolean_t is_forced);

sx_status_t sdk_tele_impl_pre_init(void);

sx_status_t sdk_tele_impl_pre_deinit(void);

sx_status_t sdk_tele_impl_unregister_hwd_ops(void);

sx_status_t sdk_tele_impl_register_hwd_ops(hwi_tele_ops_t *ops_p);

sx_status_t sdk_tele_impl_histogram_set(const sx_access_cmd_t                     cmd,
                                        const sx_tele_histogram_key_t             key,
                                        const sx_tele_histogram_attributes_data_t data);

sx_status_t sdk_tele_impl_histogram_get(const sx_access_cmd_t                cmd,
                                        const sx_tele_histogram_key_t        key,
                                        sx_tele_histogram_attributes_data_t *data_p);

sx_status_t sdk_tele_impl_histogram_iter_get(const sx_access_cmd_t      cmd,
                                             sx_tele_histogram_key_t    hist_key,
                                             sx_tele_histogram_filter_t hist_filter,
                                             sx_tele_histogram_key_t   *hist_list_p,
                                             uint32_t                  *hist_cnt_p);

sx_status_t sdk_tele_impl_histogram_data_get(const sx_access_cmd_t         cmd,
                                             const sx_tele_histogram_key_t key,
                                             sx_tele_histogram_data_t     *histogram_p);

sx_status_t sdk_tele_impl_histogram_type_validation(const sx_tele_histogram_key_t *key_p);

sx_status_t sdk_tele_impl_counter_histogram_type_validation(const sx_tele_histogram_attributes_data_t *data_p);

sx_status_t sdk_tele_impl_latency_histogram_port_tc_validate(const sx_tele_histogram_key_t             *key,
                                                             const sx_tele_histogram_attributes_data_t *data,
                                                             boolean_t                                 *is_valid_p);

sx_status_t sdk_tele_impl_threshold_set(const sx_access_cmd_t          cmd,
                                        const sx_tele_threshold_key_t  key,
                                        const sx_tele_threshold_data_t data);

sx_status_t sdk_tele_impl_threshold_get(const sx_access_cmd_t         cmd,
                                        const sx_tele_threshold_key_t key,
                                        sx_tele_threshold_data_t     *data_p);

sx_status_t sdk_tele_impl_threshold_iter_get(const sx_access_cmd_t      cmd,
                                             sx_tele_threshold_key_t    key,
                                             sx_tele_threshold_filter_t filter,
                                             sx_tele_threshold_key_t   *key_list_p,
                                             uint32_t                  *key_cnt_p);

sx_status_t sdk_tele_impl_threshold_crossed_data_get(const sx_access_cmd_t                  cmd,
                                                     sx_tele_threshold_crossed_data_keys_t *data_p,
                                                     uint32_t                               list_cnt);

sx_status_t sdk_tele_impl_latency_threshold_set(const sx_access_cmd_t          cmd,
                                                const sx_tele_threshold_key_t  key,
                                                const sx_tele_threshold_data_t data);

sx_status_t sdk_tele_impl_latency_threshold_get(const sx_tele_threshold_key_t key,
                                                sx_tele_threshold_data_t     *data_p);


void sdk_tele_impl_threshold_key_log_port_set(sx_tele_threshold_key_t *key_p,
                                              const sx_port_log_id_t   log_port);

void sdk_tele_impl_threshold_key_log_port_get(const sx_tele_threshold_key_t key,
                                              sx_port_log_id_t             *log_port_p);

sx_status_t tele_impl_threshold_key_validation(const sx_tele_threshold_key_t key);

sx_status_t tele_impl_threshold_data_validation(const sx_tele_threshold_key_t  key,
                                                const sx_tele_threshold_data_t data);

void sdk_tele_impl_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

void sdk_tele_impl_histogram_data_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

void sdk_tele_impl_attr_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

sx_status_t sdk_tele_impl_device_del_callback(adviser_event_e event_type,
                                              void           *param_p);

sx_status_t sdk_tele_impl_threshold_issu_set();


sx_status_t sdk_tele_impl_threshold_port_pg_issu_set_wrapper(const sx_port_log_id_t        *port_list_p,
                                                             const uint32_t                 port_cnt,
                                                             const sx_tele_threshold_key_t *port_key_list_p,
                                                             const uint8_t                  key_cnt,
                                                             uint8_t                       *pg_list_p);
sx_status_t sdk_tele_impl_threshold_port_pg_issu_set(const sx_port_log_id_t        *port_list_p,
                                                     const uint32_t                 port_cnt,
                                                     const sx_tele_threshold_key_t *port_key_list_p,
                                                     const uint8_t                  key_cnt,
                                                     uint8_t                       *pg_list_p);

sx_status_t tele_set_attr_port_validation_spectrum4(const sx_tele_attrib_t *attr, const sx_swid_id_t swid);

sx_status_t sdk_tele_init_wrapper(const sx_tele_init_params_t *params_p);

sx_status_t sdk_tele_deinit_wrapper(boolean_t is_forced);

sx_status_t sdk_tele_impl_histogram_delete_all(boolean_t is_forced);

sx_status_t sdk_tele_impl_attributes_set(sx_tele_attrib_t attr, sx_port_id_t *port);

sx_status_t sdk_tele_impl_attributes_get(sx_tele_attrib_t *attr_p);

sx_status_t sdk_tele_impl_hash_sig_prof_set(const sx_access_cmd_t                  cmd,
                                            sx_tele_hash_sig_prof_idx_int_t        hash_sig_prof_idx,
                                            sx_tele_hash_sig_classifier_attr_t    *hash_sig_prof_class_p,
                                            const sx_tele_hash_sig_params_t       *hash_params_p,
                                            const sx_tele_hash_sig_field_enable_t *hash_field_enable_list_p,
                                            const uint32_t                         hash_field_enable_list_cnt,
                                            const sx_tele_hash_sig_field_t        *hash_field_list_p,
                                            const uint32_t                         hash_field_list_cnt);

sx_status_t sdk_tele_impl_is_hash_sig_supported(boolean_t *is_hash_sig_supported);
sx_status_t sdk_tele_impl_is_tac_supported(boolean_t *is_tac_supported);
sx_status_t sdk_tele_impl_tac_is_enabled(boolean_t *tac_is_enabled_p);
sx_status_t sdk_tele_impl_tac_is_trap_bind_allowed(sx_trap_group_t trap_group,
                                                   boolean_t      *tac_is_trap_bind_allowed);
sx_status_t sdk_tele_impl_tac_trap_group_db_update(sx_access_cmd_t                cmd,
                                                   sx_trap_group_t                trap_group,
                                                   tele_db_tac_trap_group_info_t *trap_group_info_p);
sx_status_t sdk_tele_impl_tac_set(sx_access_cmd_t cmd, sx_trap_group_t trap_group, sx_tele_tac_cfg_t *tac_cfg_p);
sx_status_t sdk_tele_impl_tac_get(sx_trap_group_t trap_group, sx_tele_tac_cfg_t *tac_cfg_p);
sx_status_t sdk_tele_impl_tac_action_set(sx_access_cmd_t              cmd,
                                         sx_tele_tac_action_filter_t *tac_action_filter_p,
                                         sx_tele_tac_action_info_t   *tac_action_info_p);
sx_status_t sdk_tele_impl_tac_action_get(sx_tele_tac_action_status_e *tac_action_status_p);
sx_status_t sdk_tele_impl_tac_statistics_get(sx_access_cmd_t cmd, sx_tele_tac_statistics_t *tac_stat_p);

sx_status_t sdk_tele_impl_tac_oob_msg_send(sx_access_cmd_t cmd, sx_tele_tac_oob_send_cfg_t *tac_msg_cfg_p);

sx_status_t sdk_tele_impl_port_bw_gauge_set(const sx_access_cmd_t   cmd,
                                            sx_tele_gauge_config_t *gauge_config_p);

sx_status_t sdk_tele_impl_port_bw_gauge_get(sx_tele_gauge_config_t *gauge_config_p);

sx_status_t sdk_tele_impl_port_bw_gauge_data_get(sx_tele_gauge_key_t  *gauge_key_p,
                                                 sx_tele_gauge_data_t *gauge_data_p);

#endif         /* __HWI_TELE_IMPL_H__ */
