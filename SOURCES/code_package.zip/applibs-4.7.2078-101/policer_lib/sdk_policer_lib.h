/*
 * Copyright (c) 2013-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SDK_POLICER_LIB_H
#define __SDK_POLICER_LIB_H

#include <sx/sdk/sx_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/******************************************************************************************/
/**** init functions **********************************************************************/
/******************************************************************************************/

int sdk_policer_lib_init(sx_verbosity_level_t default_verbosity,  sxd_chip_types_t asic_type);
int sdk_policer_lib_init_spectrum2(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type);
int sdk_policer_lib_init_spectrum4(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type);


#endif
