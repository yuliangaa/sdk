/*
 * SPDX-FileCopyrightText: Copyright (c) 2011-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <errno.h>
#include <dlfcn.h>

#include "policer_lib/policer_common.h"
#include "complib/sx_log.h"
#include "sx_core/sx_core_cmd_db.h"
#include "sx_api/sx_api_internal.h"
#include "include/resource_manager/resource_manager.h"
#include "sdk_policer_lib.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "dbg_dump_modules/dbg_dump_modules.h"

#undef  __MODULE__
#define __MODULE__ POLICER_COM

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
/************************************************
 *  Local Defines
 ***********************************************/
#define SX_POLICER_LIB_PATH            "libsxpolicerlib.so"
#define SX_POLICER_LIB_INIT            "sx_policer_lib_init"
#define SDK_POLICER_LIB_PATH           "libsdkpolicerlib.so"
#define SDK_POLICER_LIB_INIT           "sdk_policer_lib_init"
#define SDK_POLICER_LIB_INIT_SPECTRUM2 "sdk_policer_lib_init_spectrum2"
#define SDK_POLICER_LIB_INIT_SPECTRUM4 "sdk_policer_lib_init_spectrum4"

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/
/************************************************
 *  Global variables
 ***********************************************/
/************************************************
 *  Local variables
 ***********************************************/
static boolean_t             policer_load_library_done = FALSE;
static policer_specific_cb_t policer_cb_api = {
    NULL,       /* policer_device_ready_callback */
    NULL,       /* policer_lag_port_update */
    NULL,       /* policer_lag_global_update */
    NULL,       /* policer_log_verbosity_level_set */
    NULL,       /* policer_log_verbosity_level_get */
    NULL,       /* policer_init */
    NULL,       /* policer_deinit */
    NULL,       /* policer_set */
    NULL,       /* policer_get */
    NULL,       /* policer_counters_get */
    NULL,       /* policer_counters_clear_set */
    NULL,       /* policer_validate_attributes */
    NULL,       /* policer_db_create */
    NULL,       /* policer_storm_control_bind_validations */
    NULL,       /* port_storm_control_set */
    NULL,       /* port_storm_control_get */
};


/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __dump_module_policer_wrapper(dbg_dump_params_t *dbg_dump_params_p);

/************************************************
 *  Function implementations
 ***********************************************/

/*  sx policer loader */
sx_status_t sx_policer_load_library(void              ** policer_lib_handle,
                                    sx_verbosity_level_t default_verbosity,
                                    sxd_chip_types_t     asic_type)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    void       *lib_handle = NULL;

    sx_status_t (*lib_init_fn)(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type);
    char       *dlerr = NULL;

    if (policer_load_library_done) {
        SX_LOG(SX_LOG_ERROR, "policer_load_library already done\n");
        err = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    lib_handle = dlopen(SX_POLICER_LIB_PATH, RTLD_NOW | RTLD_GLOBAL);
    if (!lib_handle) {
        SX_LOG(SX_LOG_ERROR, "dlopen (%s) failed: (%s)\n", SX_POLICER_LIB_PATH, dlerror());
        err = SX_STATUS_ERROR;
        goto out;
    }

    *policer_lib_handle = lib_handle;

    SX_LOG(SX_LOG_INFO, "%s is loaded\n", SX_POLICER_LIB_PATH);

    lib_init_fn = dlsym(lib_handle, SX_POLICER_LIB_INIT);
    dlerr = dlerror();
    if (dlerr != NULL) {
        dlclose(lib_handle);
        SX_LOG(SX_LOG_ERROR, "dlsym (%s) failed: (%s)\n", SX_POLICER_LIB_INIT, dlerr);
        err = SX_STATUS_ERROR;
        goto out;
    }

    err = (*lib_init_fn)(default_verbosity, asic_type);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "policer_init failed\n");
        err = SX_STATUS_ERROR;
        dlclose(lib_handle);
        goto out;
    }

    policer_load_library_done = TRUE;

out:
    return err;
}

static sx_status_t __sdk_policer_load_library_common(void               **policer_lib_handle,
                                                     const char          *lib_init_str,
                                                     sx_verbosity_level_t default_verbosity,
                                                     sxd_chip_types_t     asic_type)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    void       *lib_handle = NULL;

    sx_status_t (*lib_init_fn)(sx_verbosity_level_t default_verbosity, sxd_chip_types_t asic_type);
    char       *dlerr = NULL;

    if (policer_load_library_done) {
        SX_LOG(SX_LOG_ERROR, "policer_load_library already done\n");
        err = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    lib_handle = dlopen(SDK_POLICER_LIB_PATH, RTLD_NOW | RTLD_GLOBAL);
    if (!lib_handle) {
        SX_LOG(SX_LOG_ERROR, "dlopen (%s) failed: (%s)\n", SDK_POLICER_LIB_PATH, dlerror());
        err = SX_STATUS_ERROR;
        goto out;
    }

    *policer_lib_handle = lib_handle;

    SX_LOG(SX_LOG_INFO, "%s is loaded\n", SDK_POLICER_LIB_PATH);

    lib_init_fn = dlsym(lib_handle, lib_init_str);
    dlerr = dlerror();
    if (dlerr != NULL) {
        dlclose(lib_handle);
        SX_LOG(SX_LOG_ERROR, "dlsym (%s) failed: (%s)\n", lib_init_str, dlerr);
        err = SX_STATUS_ERROR;
        goto out;
    }

    err = (*lib_init_fn)(default_verbosity, asic_type);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "policer_init failed\n");
        err = SX_STATUS_ERROR;
        dlclose(lib_handle);
        goto out;
    }

    policer_load_library_done = TRUE;

out:
    return err;
}


/* sdk policer loader - spectrum1*/
sx_status_t sdk_policer_load_library(void              ** policer_lib_handle,
                                     sx_verbosity_level_t default_verbosity,
                                     sxd_chip_types_t     asic_type)
{
    return __sdk_policer_load_library_common(policer_lib_handle, SDK_POLICER_LIB_INIT, default_verbosity, asic_type);
}

/* sdk policer loader - spectrum2*/
sx_status_t sdk_policer_load_library_spectrum2(void              ** policer_lib_handle,
                                               sx_verbosity_level_t default_verbosity,
                                               sxd_chip_types_t     asic_type)
{
    return __sdk_policer_load_library_common(policer_lib_handle,
                                             SDK_POLICER_LIB_INIT_SPECTRUM2,
                                             default_verbosity,
                                             asic_type);
}

/* sdk policer loader - spectrum4*/
sx_status_t sdk_policer_load_library_spectrum4(void              ** policer_lib_handle,
                                               sx_verbosity_level_t default_verbosity,
                                               sxd_chip_types_t     asic_type)
{
    return __sdk_policer_load_library_common(policer_lib_handle,
                                             SDK_POLICER_LIB_INIT_SPECTRUM4,
                                             default_verbosity,
                                             asic_type);
}


sx_status_t policer_common_cb_table_get(policer_specific_cb_t** policer_cb_api_p)
{
    if (NULL == policer_cb_api_p) {
        SX_LOG(SX_LOG_ERROR, "policer_cb_api_p is NULL\n");
        return SX_STATUS_ERROR;
    }

    *policer_cb_api_p = &policer_cb_api;

    return SX_STATUS_SUCCESS;
}

sx_status_t policer_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    if (NULL == policer_cb_api.policer_log_verbosity_level_set) {
        SX_LOG(SX_LOG_INFO, "policer_log_verbosity_level_set callback not initialized\n");
        return SX_STATUS_SUCCESS;
    }
    return policer_cb_api.policer_log_verbosity_level_set(verbosity_level);
}

sx_status_t policer_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    if (NULL == policer_cb_api.policer_log_verbosity_level_get) {
        SX_LOG(SX_LOG_ERROR, "policer_log_verbosity_level_get callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_log_verbosity_level_get(verbosity_level_p);
}

sx_status_t policer_init(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (NULL == policer_cb_api.policer_init) {
        SX_LOG(SX_LOG_ERROR, "policer_init callback not initialized\n");
        return SX_STATUS_ERROR;
    }

    DBG_DUMP_MODULES_REGISTER(err, POLICER, POLICER, policer, FALSE, TRUE, FALSE);

    err = policer_cb_api.policer_init();

out:
    return err;
}

sx_status_t policer_deinit(void)
{
    if (NULL == policer_cb_api.policer_deinit) {
        SX_LOG(SX_LOG_ERROR, "policer_deinit callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_deinit();
}

sx_status_t policer_set(const sx_access_cmd_t   cmd,
                        const sx_policer_mode_e mode,
                        sx_policer_id_t       * policer_id_p,
                        sx_policer_info_t     * policer_info)
{
    if (NULL == policer_cb_api.policer_set) {
        SX_LOG(SX_LOG_ERROR, "policer_set callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_set(cmd, mode, policer_id_p, policer_info);
}

sx_status_t policer_get(const sx_policer_id_t policer_id, sx_policer_attributes_t *policer_attr_p)
{
    if (NULL == policer_cb_api.policer_get) {
        SX_LOG(SX_LOG_ERROR, "policer_get callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_get(policer_id, policer_attr_p);
}

sx_status_t policer_counters_clear_set(const sx_policer_id_t              policer_id,
                                       const sx_policer_counters_clear_t *clear_counters_p)
{
    if (NULL == policer_cb_api.policer_counters_clear_set) {
        SX_LOG(SX_LOG_ERROR, "policer_counters_clear_set callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_counters_clear_set(policer_id, clear_counters_p);
}

sx_status_t policer_counters_get(const sx_policer_id_t policer_id, sx_policer_counters_t *policer_counters_p)
{
    if (NULL == policer_cb_api.policer_counters_get) {
        SX_LOG(SX_LOG_ERROR, "policer_counters_get callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_counters_get(policer_id, policer_counters_p);
}

sx_status_t policer_device_ready_callback(adviser_event_e event, void           *param)
{
    if (NULL == policer_cb_api.policer_device_ready_callback) {
        SX_LOG(SX_LOG_ERROR, "policer_device_ready_callback callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_device_ready_callback(event, param);
}

sx_status_t policer_lag_port_update(IN sx_port_id_t          lag_port_log_id,
                                    IN lag_sink_event_type_e event_type,
                                    IN sx_port_id_t          port_log_id,
                                    IN void                 *context_p)
{
    if (NULL == policer_cb_api.policer_lag_port_update) {
        SX_LOG(SX_LOG_ERROR, "policer_lag_port_update callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_lag_port_update(lag_port_log_id, event_type, port_log_id, context_p);
}

sx_status_t policer_lag_global_update(IN sx_port_id_t          lag_port_log_id,
                                      IN lag_sink_event_type_e event_type,
                                      IN void                 *context_p)
{
    if (NULL == policer_cb_api.policer_lag_global_update) {
        SX_LOG(SX_LOG_ERROR, "policer_lag_global_update callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_lag_global_update(lag_port_log_id, event_type, context_p);
}

sx_status_t policer_validate_attrib(sx_policer_mode_e       mode,
                                    sx_policer_info_t      *policer_info_p,
                                    sx_policer_db_attrib_t *policer_db_attrib_p)
{
    if (NULL == policer_cb_api.policer_validate_attrib) {
        SX_LOG(SX_LOG_ERROR, "policer_validate_attrib callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_validate_attrib(mode, policer_info_p, policer_db_attrib_p);
}

sx_status_t policer_db_create(const sx_policer_db_attrib_t *policer_attr, sx_policer_id_t *policer_id_p)
{
    if (NULL == policer_cb_api.policer_db_create) {
        SX_LOG(SX_LOG_ERROR, "policer_db_create callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_db_create(policer_attr, policer_id_p);
}


sx_status_t policer_storm_control_bind_validations(const sx_access_cmd_t        cmd,
                                                   const sx_port_log_id_t       log_port,
                                                   const sx_policer_id_t        policer_id,
                                                   const sx_port_packet_types_t port_packet_types,
                                                   const sx_policer_mode_e      mode,
                                                   boolean_t                   *is_update_packet_type_p)
{
    if (NULL == policer_cb_api.policer_storm_control_bind_validations) {
        SX_LOG(SX_LOG_ERROR, "policer_storm_control_bind_validation callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_storm_control_bind_validations(cmd, log_port, policer_id,
                                                                 port_packet_types, mode,
                                                                 is_update_packet_type_p);
}

sx_status_t policer_storm_control_set(const sx_access_cmd_t                 cmd,
                                      const sx_port_log_id_t                log_port,
                                      const sx_port_storm_control_id_t      storm_control_id,
                                      const sx_port_storm_control_params_t *storm_control_params)
{
    if (NULL == policer_cb_api.policer_storm_control_set) {
        SX_LOG(SX_LOG_ERROR, "policer_storm_control_set callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_storm_control_set(cmd, log_port, storm_control_id,
                                                    storm_control_params);
}

sx_status_t policer_storm_control_get(const sx_port_log_id_t           log_port,
                                      const sx_port_storm_control_id_t storm_control_id,
                                      sx_port_storm_control_params_t  *storm_control_params_p)
{
    if (NULL == policer_cb_api.policer_storm_control_get) {
        SX_LOG(SX_LOG_ERROR, "policer_storm_control_get callback not initialized\n");
        return SX_STATUS_ERROR;
    }
    return policer_cb_api.policer_storm_control_get(log_port, storm_control_id,
                                                    storm_control_params_p);
}

sx_status_t policer_validate_packet_type(const sx_port_packet_types_t port_packet_types)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (FALSE == SX_PORT_PACKET_TYPE_CHECK_RANGE(port_packet_types.uc)) {
        SX_LOG_ERR("flow metering - unicast (%d) exceeds range (%d...%d)\n",
                   port_packet_types.uc,
                   SX_PORT_PACKET_TYPE_MIN_MAX);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
    }
    if (FALSE == SX_PORT_PACKET_TYPE_CHECK_RANGE(port_packet_types.mc)) {
        SX_LOG_ERR("flow metering - multicast (%d) exceeds range (%d...%d)\n",
                   port_packet_types.mc,
                   SX_PORT_PACKET_TYPE_MIN_MAX);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
    }
    if (FALSE == SX_PORT_PACKET_TYPE_CHECK_RANGE(port_packet_types.bc)) {
        SX_LOG_ERR("flow metering - broadcast (%d) exceeds range (%d...%d)\n",
                   port_packet_types.bc,
                   SX_PORT_PACKET_TYPE_MIN_MAX);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
    }
    if (FALSE == SX_PORT_PACKET_TYPE_CHECK_RANGE(port_packet_types.uuc)) {
        SX_LOG_ERR("flow metering - unknown unicast (%d) exceeds range (%d...%d)\n",
                   port_packet_types.uuc,
                   SX_PORT_PACKET_TYPE_MIN_MAX);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
    }
    if (FALSE == SX_PORT_PACKET_TYPE_CHECK_RANGE(port_packet_types.umc)) {
        SX_LOG_ERR("flow metering - unregistered multicast (%d) exceeds range (%d...%d)\n",
                   port_packet_types.umc,
                   SX_PORT_PACKET_TYPE_MIN_MAX);
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_EXCEEDS_RANGE);
    }

    if (FALSE ==
        (port_packet_types.uc || port_packet_types.mc || port_packet_types.bc || port_packet_types.uuc ||
         port_packet_types.umc)) {
        SX_LOG_ERR("At least one flow metering must be enabled\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_PARAM_ERROR);
    }

    return rc;
}

void policer_dbg_generate_dump_self(dbg_dump_params_t *dbg_dump_params_p)
{
    policer_dbg_generate_dump(dbg_dump_params_p);
    return;
}

static sx_status_t __dump_module_policer_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = policer_dbg_generate_dump(dbg_dump_params_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("dbg_dump failed to generate Policer module dump.\n");
    }

    return err;
}


sx_status_t policer_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    FILE       *stream = NULL;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_module_header_print(stream, "Policer Module");

    sx_status = policer_db_dbg_generate_dump(dbg_dump_params_p);
    /* if the DB was not initialized we should not print an error */
    if (sx_status == SX_STATUS_DB_NOT_INITIALIZED) {
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    }
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed in policer_db_dbg_generate_dump , error: %s\n",
                   sx_status_str(sx_status));
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    }

out:
    return M_UTILS_SX_LOG_EXIT(sx_status);
}
