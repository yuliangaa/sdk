/*
 * Copyright (C) 2015-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <utils/utils.h>
#include "counter_manager.h"
#include "counter_internal.h"
#include "af_counter_manager.h"
#include <include/resource_manager/resource_manager.h>

#undef  __MODULE__
#define __MODULE__ COUNTER_MANAGER

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t   init_done_s = FALSE;
static cmi_user_t  users_s[CM_MAX_USERS];
static ba_handle_t handle_s = NULL;
static cmi_group_t groups_s;

/************************************************
 *  Local variables
 ***********************************************/
static const char * const sx_counter_manager_type_str_s[] = {
    FOREACH_COUNTER_MANAGER_TYPE(SX_GENERATE_STRING)
};

/************************************************
 *  Local function declarations
 ***********************************************/
const char * cm_type_str(cm_type_e type)
{
    return (SX_CHECK_MAX(type, CM_TYPE_NUM_E - 1) ?
            sx_counter_manager_type_str_s[type] : "Unknown");
}

sx_status_t cm_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

sx_status_t cm_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

    return err;
}

/*
 * For best performance ingress and egress RIF counters
 * should be allocated on different HW banks.
 * Counter Manager will manage counter indexes aligned to HW bank size
 * The allocation will be done by using Bin Allocator but after that
 * block index will be aligned according HW bank size.
 * The function below will do the alignment :
 * 1. SW_BANK_SIZE is number of lines in counter bank which is exposed to user:
 *    rm_resource_global.cntr_lines_per_bank
 * 2. HW_BANK_SIZE is number of lines in counter bank as appears in PRM
 *     rm_resource_global.cntr_lines_per_hw_bank
 * 3. Bin allocator is initialized with SW_BANK_SIZE.
 *    So it will allocate block with start index between 0 .. SW_BANK_SIZE-1
 * 4. So bank_id and offset will be :
 *    counter_bank_id = ba_index / SW_BANK_SIZE
 *    counter_offset = ba_index % SW_BANK_SIZE
 * 5. aligned_index  = counter_bank_id * HW_BANK_SIZE + counter_offset
 *
 * Example:
 * SW_BANK_SIZE = 4000
 * HW_BANK_SIZE = 4096
 *
 * ba_index | aligned_index
 * -----------------------------------------------
 * 4000     | (4000 / 4000) * 4096 + (4000 % 4000) = 4096 + 0 = 4096
 * 4001     | (4001 / 4000) * 4096 + (4001 % 4000) = 4096 + 1 = 4097
 * 4096     | (4096 / 4000) * 4096 + (4096 % 4000) = 4096 + 96 = 4182
 * 5000     | (5000 / 4000) * 4096 + (5000 % 4000) = 4096 + 1000 = 5096
 *
 * RIF counters calculation:
 * OLD : ingress rif counter = ba_index , egress rif counter = ba_index + SW_BANK_SIZE
 * NEW : ingress rif counter = aligned_ba_index , egress rif counter = aligned_ba_index + HW_BANK_SIZE
 *
 * Banks [0..4095][4096..8191][8192..
 *
 * Calc |  ba_index | Ingress    | Egress
 * OLD  |  1        | 1          | 4001     # both indexes in the same HW bank [0..4095]
 * OLD  |  4096     | 4096       | 8096     # both indexes in the same HW bank [4096..8191]
 * NEW  |  1        | 1          | 4097     # indexes in different HW banks
 * NEW  |  4096     | 4182       | 8288     # indexes in different HW banks
 */
void __cm_ba_index_get_aligned(cm_index_t ba_index, cm_index_t  *aligned_index_p)
{
    uint16_t        bank_id;
    ba_logical_id_t offset;

    /* if sw_bank == hw_bank than int_ba_lid equal to external */
    if (rm_resource_global.cntr_lines_per_bank ==
        rm_resource_global.cntr_lines_per_hw_bank) {
        *aligned_index_p = ba_index;
        return;
    }

    /* if sw_bank or hw_bank is 0 than int_ba_lid equal to external */
    if ((rm_resource_global.cntr_lines_per_bank == 0) ||
        (rm_resource_global.cntr_lines_per_hw_bank == 0)) {
        *aligned_index_p = ba_index;
        return;
    }

    bank_id = ba_index / rm_resource_global.cntr_lines_per_bank;
    offset = ba_index % rm_resource_global.cntr_lines_per_bank;

    *aligned_index_p = bank_id * rm_resource_global.cntr_lines_per_hw_bank + offset;
}


/*
 * For Spectrum, rm_resource_global.cntr_lines_per_bank is 4094, so supported
 * flow counter block size are: 1, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048.
 * For Spectrum2 and up, rm_resource_global.cntr_lines_per_bank is 10000, so supported
 * flow counter block size are: 1, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192.
 * */
static void __cmi_generate_flow_sizes(uint16_t *sizes_p, uint16_t max_size)
{
    uint16_t i = 0, len = 0, next_size = 0;
    uint16_t cntr_lines_flow_max =
        MAX(MAX(rm_resource_global.cntr_lines_flow_pkt, rm_resource_global.cntr_lines_flow_byte),
            rm_resource_global.cntr_lines_flow_both);
    uint16_t valid_block_sizes[BIN_ALLOC_MAX_ALLOC_SIZES] = {0};

    /* generate valid block sizes */
    valid_block_sizes[0] = 1;
    next_size = 4;
    if ((cntr_lines_flow_max * next_size) <= max_size) {
        valid_block_sizes[++i] = next_size;
    }
    next_size = 8;
    if ((cntr_lines_flow_max * next_size) <= max_size) {
        valid_block_sizes[++i] = next_size;
    }
    next_size = 16;
    while ((cntr_lines_flow_max * next_size) <= max_size && (i >= 1)) {
        valid_block_sizes[++i] = next_size;
        next_size = 16 * (1 << (i - 2));
    }
    len = i + 1;

    for (i = 0; i < len; i++) {
        sizes_p[3 * i] = valid_block_sizes[i] * rm_resource_global.cntr_lines_flow_pkt;
        sizes_p[3 * i + 1] = valid_block_sizes[i] * rm_resource_global.cntr_lines_flow_byte;
        sizes_p[3 * i + 2] = valid_block_sizes[i] * rm_resource_global.cntr_lines_flow_both;
    }
    sizes_p[3 * i] = 0;
}

/**
 * compare function needed by qsort
 *
 * @param[in] p1 - pointer to a uint16 value
 * @param[in] p2 - Pointer to a uint16 value
 *
 * return:
 *   -1: *p1 < *p2
 *    0: *p1 == *p2
 *    1: *p1 > *p2
 */
static int __smi_cmp_uint16(const void *p1, const void *p2)
{
    uint16_t ui1, ui2;

    ui1 = *(uint16_t*)p1;
    ui2 = *(uint16_t*)p2;

    if (ui1 == ui2) {
        return 0;
    } else if (ui1 < ui2) {
        return -1;
    } else {
        return 1;
    }
}

/**
 * Sort and compress sizes into a template
 *
 * @param[in] in - Pointer to zero terminated array of sizes
 * @param[out] out - Pointer to output array of unique sorted sizes
 *
 * @return SX_STATUS_SUCCESS - It worked
 * @return SX_STATUS_PARAM_NULL - At least one parameter is NULL
 * @return SX_STATUS_ERROR - Internal SDK error
 */
static sx_status_t __cmi_update_templates(uint16_t *in, uint16_t *out)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0, cnt = 0, i_out = 0, old = 0;
    boolean_t   found = FALSE;

    if ((in == NULL) || (out == NULL)) {
        SX_LOG_ERR("Internal error - NULL pointer(s) in=%p out=%p!\n", in, out);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Must have at least one input element */
    if (in[0] == 0) {
        SX_LOG_ERR("Template has no sizes!\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    /* Make sure input list is terminated and smaller then template list */
    for (i = cnt = 0; i < BIN_ALLOC_MAX_ALLOC_SIZES; i++) {
        if (in[i] == 0) {
            found = TRUE;
            break;
        }

        cnt++;
    }

    /* Input has too many sizes to fit in a template */
    if (!found) {
        SX_LOG_ERR("Internal error - Input has more sizes than fit (%u)!\n",
                   BIN_ALLOC_MAX_ALLOC_SIZES);
        err = SX_STATUS_ERROR;
        goto out;
    }

    /* Sort the input array as template requires sorted data */
    qsort(in, cnt, sizeof(uint16_t), __smi_cmp_uint16);

    /* Squish out duplicates and move into template */
    for (i = i_out = old = 0; i < cnt; i++) {
        if (old != in[i]) {
            out[i_out++] = in[i];
            old = in[i];
        }
    }
    out[i_out] = 0;

    SX_LOG_INF("Input %u sizes saved as %u template sizes\n", cnt, i_out);

out:
    return err;
}

/**
 * Verify that lid and user context are valid
 *
 * @return SX_STATUS_SUCCESS - Operation completed successfully
 * @return SX_STATUS_PARAM_ERROR - LID is invalid
 * @return SX_STATUS_MODULE_UNINITIALIZED - Module not initialized
 * @return SX_STATUS_ERROR - Handle is invalid
 */
static sx_status_t __verify_lid(cm_logical_id_t lid)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    /* Make sure subsystem has been initialized */
    if (!init_done_s) {
        SX_LOG_ERR("Counter manager not initialized!\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (lid == INVALID_LID) {
        SX_LOG_ERR("LID is not allocated!\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (handle_s == NULL) {
        SX_LOG_ERR("Block Allocator handle is NULL!\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}

/**
 * Clear a register
 *   Calls all registered clear entry points to zero the contents of a register
 * that is the target of relocation.  Once any client has serviced the clear request,
 * we stop looking for somebody else to do it.
 *
 * @param[in] lid - The lid being moved
 * @param[in] type - The generic register type being moved
 * @param[in] hw_type - The PRM specified hw_type value for 'type'
 * @param[in] index - The index of the first line of the register to clear
 *
 * @return SX_STATUS_SUCCESS - Operation completed successfully
 * @return SX_STATUS_CMD_UNSUPPORTED - lid not supported by callback
 * @return SX_STATUS_PARAM_ERROR - At least one parameter was invalid
 * @return SX_STATUS_ERROR - Callback was unable to update HW
 */
static sx_status_t __cm_clear(cm_logical_id_t lid, cm_type_e type, cm_hw_type_t hw_type, cm_index_t index)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    cmi_user_t *p_user = NULL;

    for (i = 0; i < CM_MAX_USERS; i++) {
        p_user = &users_s[i];

        if (!p_user->allocated) {
            continue;
        }

        if (!p_user->clear) {
            continue;
        }

        err = p_user->clear(lid, type, hw_type, index);
        if (err == SX_STATUS_SUCCESS) {
            goto out;
        }

        if (err == SX_STATUS_CMD_UNSUPPORTED) {
            err = SX_STATUS_SUCCESS;
            continue;
        }

        /* Any other error is reported back right away */
        goto out;
    }

    /* Nobody claimed the clear request? */
    err = SX_STATUS_CMD_UNSUPPORTED;

out:
    return err;
}

/**
 * Add the contents of one register to another
 *   Once all clients have relocated a register, we need to add the contents
 * of the original register to those of the new register.  Once any client
 * has serviced the add request, we stop looking for somebody else to do it.
 *
 * @param[in] lid - The lid being moved
 * @param[in] type - The generic register type being moved
 * @param[in] hw_type - The PRM specified hw_type value for 'type'
 * @param[in] old_index - First line of counter to add contents from
 * @param[in] new_index - First line of counter to add contents to
 *
 * @return SX_STATUS_SUCCESS - Operation completed successfully
 * @return SX_STATUS_CMD_UNSUPPORTED - lid not supported by callback
 * @return SX_STATUS_PARAM_ERROR - At least one parameter was invalid
 * @return SX_STATUS_ERROR - Callback was unable to update HW
 */
static sx_status_t __cm_add(cm_logical_id_t lid,
                            cm_type_e       type,
                            cm_hw_type_t    hw_type,
                            cm_index_t      old_index,
                            cm_index_t      new_index)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    cmi_user_t *p_user = NULL;

    for (i = 0; i < CM_MAX_USERS; i++) {
        p_user = &users_s[i];

        if (!p_user->allocated) {
            continue;
        }

        if (!p_user->add) {
            continue;
        }

        err = p_user->add(lid, type, hw_type, old_index, new_index);
        if (err == SX_STATUS_SUCCESS) {
            goto out;
        }

        if (err == SX_STATUS_CMD_UNSUPPORTED) {
            err = SX_STATUS_SUCCESS;
            continue;
        }

        /* Any other error is reported back right away */
        goto out;
    }

    /* Nobody claimed the clear request? */
    err = SX_STATUS_CMD_UNSUPPORTED;

out:
    return err;
}

/**
 * Call CM relocate callbacks
 *   All relocate requests must succeed, or those that succeed must be
 * walked back.  When this function returns, it indicates one of 3
 * possible states:
 *
 *    1) All relocates succeeded and LID should point to new_id
 *       This is the normal case.  Block at old_id needs to be freed.
 *
 *    2) Something failed and LID should point to old_id
 *       This is the case where HW is update a register to use the new_id
 *       index.  If any relocation handlers were updated to new_id, they
 *       successfully re-updated to old_id.  Block at new_id needs to be
 *       freed.
 *
 *    3) Something failed and LID should point to old_lid
 *       Some HW using old_id and some using new_id.  At least 2 failures
 *       seen.  Some relocate handler updated to new_id, one failed to
 *       update to new_id, and when cleanup tried to move one from new_id
 *       back to old_id, that failed.  Both blocks need to be kept.
 *
 * @param[in] lid  - The logical ID of the counter being relocated
 * @param[in] type - HW independent counter type value
 * @param[in] hw_type - Hardware dependent type value (8 bits)
 * @param[in] old_id  - The old PRM counter ID associated with lid
 * @param[in] new_id  - The new relocated PRM counter id
 *
 * @return SX_UTILS_STATUS_SUCCESS - (1) Operation completed successfully
 * @return SX_UTILS_STATUS_ERROR - (2) Callback was unable to update HW
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - (3) Cleanup failed; keep both
 */
static sx_utils_status_t __cm_atomic_relocate(ba_logical_id_t lid,
                                              uint32_t        offset,
                                              cm_type_e       type,
                                              cm_hw_type_t    hw_type,
                                              ba_index_t      old_id,
                                              ba_index_t      new_id)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i = 0;
    uint32_t          cnt, replay[CM_MAX_USERS];
    cmi_user_t       *p_user = NULL;
    boolean_t         replay_fails = FALSE;

    /* Call all clients to move mapping from old_id to new_id */
    for (cnt = i = 0; i < CM_MAX_USERS; i++) {
        p_user = &users_s[i];

        if (!p_user->allocated) {
            continue;
        }

        if (!p_user->relocate) {
            continue;
        }

        err = sx_status_to_sx_utils_status(p_user->relocate(lid, offset, type, hw_type, old_id, new_id));
        if (err == SX_UTILS_STATUS_SUCCESS) {
            replay[cnt++] = i;
            continue;
        }

        /* Any error might need cleanup */
        break;
    }

    /* If all callback functions succeeded, done */
    if (err == SX_UTILS_STATUS_SUCCESS) {
        goto out;
    }

    /* If no relocation succeeded before failure, simple failure */
    if (cnt == 0) {
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Try to relocate back (new_id to old_id) those that succeeded before */
    for (i = 0; i < cnt; i++) {
        p_user = &users_s[replay[i]];

        if (!p_user->allocated) {
            SX_LOG_WRN("Internal error - User closed!\n");
            replay_fails = TRUE;
            continue;
        }

        if (!p_user->relocate) {
            SX_LOG_WRN("Internal error - Relocate removed!\n");
            replay_fails = TRUE;
            continue;
        }

        err = sx_status_to_sx_utils_status(p_user->relocate(lid, offset, type, hw_type, new_id, old_id));
        if (err == SX_UTILS_STATUS_SUCCESS) {
            continue;
        }

        SX_LOG_WRN("Internal error - Relocate recovery fails!\n");

        replay_fails = TRUE;
    }

    /* If we had any failures returning mapping, that is bad */
    err = (replay_fails) ? SX_UTILS_STATUS_PARTIALLY_COMPLETE :
          SX_UTILS_STATUS_ERROR;

out:
    return err;
}

/**
 * Make relocation request
 *
 * @param[in] handle - The client handle that owns the lid
 * @param[in] lid  - The logical ID of the counter being relocated
 * @param[in] cntx - Current value of user context associated with this lid
 * @param[in] old_id  - The old PRM counter ID associated with lid
 * @param[in] new_id  - The new relocated PRM counter id
 *
 * @return SX_UTILS_STATUS_SUCCESS - Operation completed successfully
 * @return SX_UTILS_STATUS_PARAM_ERROR - At least one parameter was invalid
 * @return SX_UTILS_STATUS_ERROR - Callback was unable to update HW; keep old
 * @return SX_UTILS_STATUS_PARTIALLY_COMPLETE - Cleanup failed; keep both
 */
static sx_utils_status_t __cm_relocate(ba_handle_t     handle,
                                       ba_logical_id_t lid,
                                       uint32_t        cntx,
                                       ba_index_t      int_old_id,
                                       ba_index_t      int_new_id,
                                       void          * relocate_cntx)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    sx_status_t       err2 = SX_STATUS_SUCCESS;
    cm_type_e         type = CM_TYPE_PACKET_COUNTER_E;
    cm_hw_type_t      hw_type = rm_resource_global.cntr_type_flow_pkt;
    uint32_t          hw_len = 0, size = 0, i = 0, index_offset = 0;
    ba_index_t        old_id;
    ba_index_t        new_id;

    UNUSED_PARAM(relocate_cntx);

    SX_LOG_ENTER();

    /* Make sure handle matches */
    if (handle != handle_s) {
        SX_LOG_ERR("Handle mismatch!\n");
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Make sure the LID is known and subsystem initialized */
    err2 = __verify_lid(lid);
    if (err2) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Generic type is low order byte of context */
    type = CM_CNTX_TYPE_GET(cntx);

    /* Get block size */
    size = CM_CNTX_SIZE_GET(cntx);

    err2 = cm_hal_hw_type(type, &hw_type, &hw_len, NULL);
    if (err2) {
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* this function align index to hw bank size
     * please see the full explanation in function description */
    __cm_ba_index_get_aligned(int_old_id, &old_id);
    __cm_ba_index_get_aligned(int_new_id, &new_id);

    for (i = 0; i < size; i++) {
        index_offset = i * hw_len;
        /* Attempt to clear the new counter contents */
        err2 = __cm_clear(lid, type, hw_type, new_id + index_offset);
        if (err2) {
            SX_LOG_ERR("Unable to clear new counter contents!\n");
            err = SX_UTILS_STATUS_ERROR;
            goto out;
        }

        /* Try to relocate - This is the error code we will return */
        err = __cm_atomic_relocate(lid, i, type, hw_type, old_id + index_offset, new_id + index_offset);
        if (err) {
            /* If relocation failed tell caller how much we cleaned up */
            goto out;
        }

        /* Now add the contents of old to new - Return relocate error though */
        err2 = __cm_add(lid, type, hw_type, old_id + index_offset, new_id + index_offset);
        if (err2) {
            /* If relocation worked, the only problem is counter values wrong */
            SX_LOG_WRN("LID=%u counter values did not all move - continuing!\n",
                       lid);
        }

        SX_LOG_DBG("LID=%u offset=%u type=%u hw_type=%u moves from %u to %u\n",
                   lid, i, type, hw_type, old_id + index_offset, new_id + index_offset);
    }

out:
    SX_LOG_EXIT();
    return err;
}

/**
 * Handle group free requests
 *
 * @param[in] handle - The client handle
 * @param[out] group - Pointer to the group that is not empty.
 *
 * @return SX_STATUS_SUCCESS - Operation completed successfully
 * @return SX_STATUS_PARAM_ERROR - Bad group info or handle
 * @return SX_STATUS_PARAM_NULL - group_p is NULL
 * @return SX_STATUS_ERROR - Internal SDK logic error
 */
static sx_utils_status_t __cm_free_cb(ba_handle_t handle, ba_group_t *group_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (handle_s != handle) {
        SX_LOG_ERR("Internal error - handle(%p) does not match cache(%p)!\n",
                   handle, handle_s);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!group_p) {
        SX_LOG_ERR("Internal error - group_p is NULL!\n");
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    /* Make sure group index is valid */
    if (group_p->grp_index >= groups_s.group_cnt) {
        SX_LOG_ERR("Group index %u exceeds max %u!\n", group_p->grp_index,
                   groups_s.group_cnt - 1);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Can't free any group if all groups are already free */
    if (groups_s.free_cnt == groups_s.group_cnt) {
        SX_LOG_ERR("All groups already free!\n");
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (group_p->type) {
    case CM_TYPE_RIF:
    case CM_TYPE_FLOW:
        break;

    default:
        SX_LOG_ERR("Internal error - type=%u not supported!\n",
                   group_p->type);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Make sure this type has at least one allocated group */
    if (groups_s.type_counts[group_p->type] == 0) {
        SX_LOG_ERR("Type %u free count is zero\n", group_p->type);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Make sure the group is allocated to the requested type */
    if (group_p->type != groups_s.groups[group_p->grp_index].type) {
        SX_LOG_ERR("Group type mismatch %u != group[%u].type=%u!\n",
                   group_p->type, groups_s.groups[group_p->grp_index].type,
                   groups_s.groups[group_p->grp_index].type);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Make it so */
    groups_s.free_cnt++;
    groups_s.groups[group_p->grp_index].type = CM_TYPE_FREE;
    groups_s.type_counts[group_p->type]--;

    SX_LOG_DBG("group=%u type=%u was freed \n", group_p->grp_index, group_p->type);

out:
    SX_LOG_EXIT();
    return err;
}

/**
 * Handle group allocation requests
 *
 * @param[in] handle - Must match handle returned by client open request
 * @param[in] type - CM_TYPE_FLOW or CM_TYPE_RIF
 * @param[in] group_p - Pointer to where to return group info
 *
 * @return SX_STATUS_SUCCESS - Operation completed successfully
 * @return SX_STATUS_PARAM_ERROR - Unsupported type or bad handle
 * @return SX_STATUS_PARAM_NULL - group_p is NULL
 * @return SX_STATUS_ERROR - Internal SDK logic error
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE - No group available
 */
static sx_utils_status_t __cm_alloc_cb(ba_handle_t handle, uint32_t type, const ba_group_t **group_p)
{
    sx_utils_status_t err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          i = 0;
    ba_group_t       *grp = NULL;

    SX_LOG_ENTER();

    if (handle_s != handle) {
        SX_LOG_ERR("Internal error - handle(%p) does not match cache(%p)!\n",
                   handle, handle_s);
        err = SX_UTILS_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!group_p) {
        SX_LOG_ERR("Internal error - group_p is NULL!\n");
        err = SX_UTILS_STATUS_PARAM_NULL;
        goto out;
    }

    /* No point in looking now */
    if (groups_s.free_cnt == 0) {
        err = SX_UTILS_STATUS_NO_RESOURCES;
        goto out;
    }

    for (i = 0; i < groups_s.group_cnt; i++) {
        grp = &groups_s.groups[i];

        if (grp->type == CM_TYPE_FREE) {
            grp->type = type;
            grp->grp_index = i;
            break;
        }

        grp = NULL;
    }

    /* Internal DB inconsistent */
    if (!grp) {
        SX_LOG_ERR("Internal error - free=%u but allocation fails!\n",
                   groups_s.free_cnt);
        err = SX_UTILS_STATUS_ERROR;
        goto out;
    }

    /* Book keeping */
    groups_s.free_cnt--;
    groups_s.type_counts[type]++;

    SX_LOG_DBG("group=%u type=%u was allocated \n", grp->grp_index, grp->type);

    *group_p = grp;

out:
    SX_LOG_EXIT();
    return err;
}


/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t cm_hal_hw_type(cm_type_e type, cm_hw_type_t *hw_type_p, uint32_t *hw_len_p, uint32_t *ba_type_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    ba_type = 0, hw_len = 0;
    uint8_t     hw_type = 0;

    if ((hw_type_p == NULL) && (hw_len_p == NULL) && (ba_type_p == NULL)) {
        SX_LOG_ERR("All return parameters pointers are NULL!\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (type) {
    case CM_TYPE_PACKET_COUNTER_E:
        ba_type = CM_TYPE_FLOW;
        hw_type = rm_resource_global.cntr_type_flow_pkt;
        hw_len = rm_resource_global.cntr_lines_flow_pkt;
        break;

    case CM_TYPE_BYTE_COUNTER_E:
        ba_type = CM_TYPE_FLOW;
        hw_type = rm_resource_global.cntr_type_flow_byte;
        hw_len = rm_resource_global.cntr_lines_flow_byte;
        break;

    case CM_TYPE_PACKET_AND_BYTE_E:
        ba_type = CM_TYPE_FLOW;
        hw_type = rm_resource_global.cntr_type_flow_both;
        hw_len = rm_resource_global.cntr_lines_flow_both;
        break;

    case CM_TYPE_ESTIMATOR_E:
        ba_type = CM_TYPE_FLOW;
        hw_type = rm_resource_global.cntr_type_flow_estimator; /* same as normal flow counter type */
        hw_len = rm_resource_global.cntr_lines_flow_estimator;
        break;

    case CM_TYPE_RIF_BASIC_E:
        ba_type = CM_TYPE_RIF;
        hw_type = rm_resource_global.cntr_type_rif_basic;
        hw_len = rm_resource_global.cntr_lines_rif_basic;
        break;

    case CM_TYPE_RIF_ENHANCED_E:
        ba_type = CM_TYPE_RIF;
        hw_type = rm_resource_global.cntr_type_rif_enhanced;
        hw_len = rm_resource_global.cntr_lines_rif_enhanced;
        break;

    case CM_TYPE_RIF_MIXED_1_E:
        ba_type = CM_TYPE_RIF;
        hw_type = rm_resource_global.cntr_type_rif_mixed_1;
        hw_len = rm_resource_global.cntr_lines_rif_mixed_1;
        break;

    case CM_TYPE_RIF_MIXED_2_E:
        ba_type = CM_TYPE_RIF;
        hw_type = rm_resource_global.cntr_type_rif_mixed_2;
        hw_len = rm_resource_global.cntr_lines_rif_mixed_2;
        break;

    case CM_TYPE_RIF_BASIC_REDUCED_E:
        ba_type = CM_TYPE_RIF;
        hw_type = rm_resource_global.cntr_type_rif_basic_reduced;
        hw_len = rm_resource_global.cntr_lines_rif_basic_reduced;
        break;

    case CM_TYPE_RIF_ENHANCED_REDUCED_E:
        ba_type = CM_TYPE_RIF;
        hw_type = rm_resource_global.cntr_type_rif_enhanced_reduced;
        hw_len = rm_resource_global.cntr_lines_rif_enhanced_reduced;
        break;

    case CM_TYPE_RIF_MIXED_1_REDUCED_E:
        ba_type = CM_TYPE_RIF;
        hw_type = rm_resource_global.cntr_type_rif_mixed_1_reduced;
        hw_len = rm_resource_global.cntr_lines_rif_mixed_1_reduced;
        break;

    case CM_TYPE_RIF_MIXED_2_REDUCED_E:
        ba_type = CM_TYPE_RIF;
        hw_type = rm_resource_global.cntr_type_rif_mixed_2_reduced;
        hw_len = rm_resource_global.cntr_lines_rif_mixed_2_reduced;
        break;

    default:
        SX_LOG_ERR("type=%u is unknown!\n", type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (hw_type_p) {
        *hw_type_p = hw_type;
    }

    if (hw_len_p) {
        *hw_len_p = hw_len;
    }

    if (ba_type_p) {
        *ba_type_p = ba_type;
    }

out:
    return err;
}

sx_status_t cm_init(sx_flow_counter_params_t *init_params_p)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    sx_utils_status_t rollback_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          array_size = 0, group_cnt = 0, group_size = 0, i = 0, mem_used = 0;
    uint16_t          sizes[BIN_ALLOC_MAX_ALLOC_SIZES];
    ba_param_t        param;
    ba_phys_init_t    phys_init;
    boolean_t         ba_client_init_done = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(param);
    SX_MEM_CLR(phys_init);

    if (init_done_s) {
        SX_LOG_ERR("Already initialized!\n");
        err = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    /*
     * Only initialize CM if HW supports SW managed counters
     * Do not set the init_done_s flag so callers of SW counter allocation
     * receive the "not initialized" error.
     */
    if (rm_resource_global.cntr_bank_pairs == 0) {
        goto out;
    }

    /* Initialize the users and groups structures */
    handle_s = NULL;
    SX_MEM_CLR_BUF(users_s, sizeof(users_s));
    mem_used += sizeof(users_s);

    /* Initialize the Bin Allocator connection */
    SX_MEM_CLR(param);

    /* Calculate the constants and check */
    group_cnt = rm_resource_global.cntr_bank_pairs;
    group_size = rm_resource_global.cntr_lines_per_bank * 2;
    array_size = group_cnt * group_size;

    if ((group_cnt == 0) || (group_cnt > CM_MAX_GROUPS)) {
        SX_LOG_ERR("Internal error - Group %u not in range [1..%u]\n",
                   group_cnt, CM_MAX_GROUPS);
        err = SX_STATUS_ERROR;
        goto out;
    }

    /* Initialize the global group tracking structure */
    SX_MEM_CLR(groups_s);
    mem_used += sizeof(groups_s);
    for (i = 0; i < group_cnt; i++) {
        groups_s.groups[i].grp_index = i;
    }
    groups_s.group_cnt = group_cnt;
    groups_s.free_cnt = group_cnt;

    SX_LOG_INF("Initialize counter array of %u lines into %u/%u groups/lines\n",
               array_size, group_cnt, group_size);

    param.version = BIN_ALLOC_VERSION;
    param.array_size = array_size;
    param.group_cnt = group_cnt;
    param.alignment = group_size;
    param.options = RELOC_SYNC_E | RELOC_ASYNC_E;
    param.r_thresh = CM_THRESHOLD;
    param.r_count = CM_COUNT;
    param.gc_object_type = GC_OBJECT_TYPE_COUNTERS;
    param.gc_subtype = GC_OBJECT_SUBTYPE_NONE;
    param.gc_attr.fence_type = GC_FENCE_TYPE_SLOW;
    param.gc_attr.free_objects_threshold = 500;
    param.gc_attr.per_object_threshold = 1000;
    param.gc_attr.hw_operation_needed = FALSE;
    param.gc_attr.immediate_fence_needed = FALSE;
    param.gc_attr.max_object_count = (group_cnt * group_size);
    param.gc_post_completion_cb = NULL;
    param.free_object_cb = NULL;

    phys_init.phys_mem_size = param.array_size;
    strncpy(phys_init.phys_mem_name, "COUNTER_MANAGER", sizeof(phys_init.phys_mem_name));
    param.phys_init = &phys_init;

    /* Flow template */
    param.templates[0].type = CM_TYPE_FLOW;
    param.templates[0].length = param.alignment;
    param.templates[0].align = ALIGN_NONE_E;
    param.templates[0].cb_relocate = __cm_relocate;
    param.templates[0].cb_alloc = __cm_alloc_cb;
    param.templates[0].cb_free = __cm_free_cb;

    __cmi_generate_flow_sizes(sizes, param.templates[0].length);
    err = __cmi_update_templates(sizes, param.templates[0].alloc_sizes);
    if (err) {
        goto out;
    }

    /* RIF template */
    param.templates[1].type = CM_TYPE_RIF;
    param.templates[1].length = param.alignment / 2;
    param.templates[1].align = ALIGN_NONE_E;
    param.templates[1].cb_relocate = __cm_relocate;
    param.templates[1].cb_alloc = __cm_alloc_cb;
    param.templates[1].cb_free = __cm_free_cb;

    SX_MEM_CLR(sizes);

    sizes[0] = rm_resource_global.cntr_lines_rif_basic;
    sizes[1] = rm_resource_global.cntr_lines_rif_mixed_1;
    sizes[2] = rm_resource_global.cntr_lines_rif_mixed_2;
    sizes[3] = rm_resource_global.cntr_lines_rif_enhanced;
    sizes[4] = rm_resource_global.cntr_lines_rif_basic_reduced; /* for reduced RIF counters */
    sizes[5] = rm_resource_global.cntr_lines_rif_mixed_1_reduced;
    sizes[6] = rm_resource_global.cntr_lines_rif_mixed_2_reduced;
    sizes[7] = rm_resource_global.cntr_lines_rif_enhanced_reduced;
    sizes[8] = 0;

    err = __cmi_update_templates(sizes, param.templates[1].alloc_sizes);
    if (err) {
        goto out;
    }

    utils_err = ba_client_init(&handle_s, &param);
    if (utils_err) {
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }
    mem_used += sizeof(handle_s);
    ba_client_init_done = TRUE;

    SX_LOG_DBG("Memory used: %u bytes\n", mem_used);

    err = afcm_init(init_params_p, __cm_atomic_relocate);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Accumulated Counters Manager init failed (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    init_done_s = TRUE;

out:
    if (err != SX_STATUS_SUCCESS) {
        if (ba_client_init_done == TRUE) {
            rollback_err = ba_client_deinit(handle_s);
            if (rollback_err != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to rollback, BA client deinit failed, err = %s\n",
                           SX_UTILS_STATUS_MSG(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_deinit(void)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    uint32_t          i = 0;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* If SW counter allocation not active, nothing to do */
    if (rm_resource_global.cntr_bank_pairs == 0) {
        goto out;
    }

    if (!init_done_s) {
        SX_LOG_ERR("Internal error - deinit called without init!\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Make sure all our clients are disconnected */
    for (i = 0; i < CM_MAX_USERS; i++) {
        if (users_s[i].allocated) {
            SX_LOG_WRN("Can't deinit when any users are active\n");
            err = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
    }

    utils_err = gc_object_process_queue(GC_OBJECT_TYPE_COUNTERS);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to process GC queue for object type COUNTERS\n");
        goto out;
    }

    /* Make sure internal DB is consistent */
    if (groups_s.free_cnt != groups_s.group_cnt) {
        SX_LOG_ERR("Internal error - Free count(%u) mismatch %u!\n",
                   groups_s.free_cnt, groups_s.group_cnt);
        err = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* Check for active groups */
    for (i = 0; i < CM_MAX_GROUPS; i++) {
        if (groups_s.groups[i].type == CM_TYPE_FREE) {
            continue;
        }

        SX_LOG_ERR("Internal error - Group %u active as type=%u!\n", i,
                   groups_s.groups[i].type);
        err = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* Check for types with non-zero group counts */
    for (i = 0; i < CM_MAX_TYPES; i++) {
        if (groups_s.type_counts[i] == 0) {
            continue;
        }

        SX_LOG_ERR("Internal error - type %u has invalid count %u!\n", i,
                   groups_s.type_counts[i]);
        err = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    err = afcm_deinit();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Accumulated Counters Manager deinit failed, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

    /* We have no clients, and are not using any BA resource, cleanup */
    utils_err = ba_client_deinit(handle_s);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

    init_done_s = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_user_init(hal_cb_relocate_t     relocate,
                         hal_cb_clear_t        clear,
                         hal_cb_add_t          add,
                         cntr_client_handle_t *user_handle_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    cmi_user_t *p_user = NULL;

    SX_LOG_ENTER();

    /* Make sure subsystem has been initialized */
    if (!init_done_s) {
        SX_LOG_ERR("Counter manager not initialized!\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Make sure they provided a location for the handle */
    if (!user_handle_p) {
        SX_LOG_ERR("Pointer to return handle is NULL!\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Search for a free user context */
    for (i = 0; i < CM_MAX_USERS; i++) {
        p_user = &users_s[i];

        if (!p_user->allocated) {
            SX_MEM_CLR_BUF(p_user, sizeof(cmi_user_t));

            p_user->allocated = TRUE;
            p_user->relocate = relocate;
            p_user->clear = clear;
            p_user->add = add;

            break;
        }

        p_user = NULL;
    }

    /* If we did not find an available user structure, too bad */
    if (!p_user) {
        SX_LOG_ERR("No more users allowed!\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    SX_LOG_DBG("User %p(%u): relocate=%p clear=%p add=%p\n", p_user,
               (uint32_t)(p_user - users_s), relocate, clear, add);

    *user_handle_p = (cntr_client_handle_t*)p_user;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_user_deinit(cntr_client_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx = 0;
    cmi_user_t *p_user = (cmi_user_t*)handle;

    SX_LOG_ENTER();

    if (!init_done_s) {
        SX_LOG_ERR("Counter allocation module not initialized!\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (!handle) {
        SX_LOG_ERR("Handle NULL!\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((p_user < &users_s[0]) || (p_user >= &users_s[CM_MAX_USERS])) {
        SX_LOG_ERR("Handle %p not in valid range!\n", handle);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    idx = p_user - users_s;

    if (p_user != &users_s[idx]) {
        SX_LOG_ERR("Handle %p is not aligned!\n", handle);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!p_user->allocated) {
        SX_LOG_ERR("Handle %p not active\n", handle);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Make it so - Don't clear associated data for debug */
    p_user->allocated = FALSE;

    /* De-reference the handle */
    handle = NULL;

    SX_LOG_DBG("deinit user=%p(%u)\n", p_user, idx);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_bulk_block_add(cm_type_e type, uint32_t size, cm_logical_id_t *lid_p)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_lid = INVALID_LID;
    uint32_t          ba_type = 0;
    uint32_t          len = 0;
    uint32_t          cntx = 0;

    SX_LOG_ENTER();

    /* Make sure subsystem has been initialized */
    if (!init_done_s) {
        SX_LOG_ERR("Counter manager not initialized!\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Range checks - type gets stored in 1 byte of context */
    if (type > UINT8_MAX) {
        SX_LOG_ERR("Internal error - SW type %u too big!\n", type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (size > CM_BLOCK_SIZE_MASK) {
        SX_LOG_ERR("Internal error - bulk size %u too big!\n", size);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Make sure they provided a return pointer */
    if (!lid_p) {
        SX_LOG_ERR("Return lid pointer is NULL!\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (type) {
    case CM_TYPE_ACCUFLOW_PACKET_AND_BYTE_E:
        err = afcm_bulk_counter_add(type, size, lid_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Accumulated counter add failed, rc = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case CM_TYPE_PACKET_COUNTER_E:
    case CM_TYPE_BYTE_COUNTER_E:
    case CM_TYPE_PACKET_AND_BYTE_E:
    case CM_TYPE_RIF_BASIC_E:
    case CM_TYPE_RIF_ENHANCED_E:
    case CM_TYPE_RIF_MIXED_1_E:
    case CM_TYPE_RIF_MIXED_2_E:
    case CM_TYPE_RIF_BASIC_REDUCED_E:
    case CM_TYPE_RIF_ENHANCED_REDUCED_E:
    case CM_TYPE_RIF_MIXED_1_REDUCED_E:
    case CM_TYPE_RIF_MIXED_2_REDUCED_E:
    case CM_TYPE_ESTIMATOR_E:
        /* Get the HW specific details on the requested HW independent type */
        err = cm_hal_hw_type(type, NULL, &len, &ba_type);
        if (err) {
            goto out;
        }

        /* Put the interesting bits into context */
        cntx = CM_CNTX_SET(type, size);

        /* Ask Bin Allocator for a block */
        utils_err = ba_allocate(handle_s, ba_type, len * size, cntx, &ba_lid);
        if (utils_err) {
            err = sx_utils_status_to_sx_status(utils_err);
            SX_LOG_ERR_RESOURCE_COND(err, "Unable to allocate block \n");
            goto out;
        }

        /* convert bin allocator LID to counter manager LID */
        *lid_p = CM_LID_BANK_TYPE_SET(ba_lid, CM_SHARED_COUNTERS_BANKS_E);

        SX_LOG_DBG("Allocated LID=%u cntx=0x%8.8X\n", *lid_p, cntx);
        break;

    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_block_add(cm_type_e type, cm_logical_id_t *lid_p)
{
    return cm_bulk_block_add(type, 1, lid_p);
}

sx_status_t cm_block_delete(cm_logical_id_t lid)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_lid = INVALID_LID;

    SX_LOG_ENTER();

    err = __verify_lid(lid);
    if (err) {
        goto out;
    }

    switch (cm_counter_bank_type_get(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_delete(lid);
        if (err) {
            SX_LOG_ERR("Accumulated counter delete failed, rc = %s\n",
                       sx_status_str(err));
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
        /* Convert counter manager LID to Bin Allocator LID */
        ba_lid = CM_LID_BANK_TYPE_CLR(lid);

        /* Pass directly to Bin Allocator to free */
        utils_err = ba_free(handle_s, ba_lid);
        if (utils_err) {
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }

        SX_LOG_DBG("Deleted LID=%u.\n", lid);
        break;

    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_ref_inc(cm_logical_id_t lid)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_lid = INVALID_LID;

    SX_LOG_ENTER();

    err = __verify_lid(lid);
    if (err) {
        goto out;
    }

    switch (cm_counter_bank_type_get(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_ref_inc(lid);
        if (err) {
            SX_LOG_ERR("Add a reference to a previously allocated "
                       "Accumulated counter failed, rc = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
        /* Convert counter manager LID to bin allocator LID */
        ba_lid = CM_LID_BANK_TYPE_CLR(lid);

        /* Pass through to Bin Allocator */
        utils_err = ba_ref_inc(handle_s, ba_lid);
        if (utils_err) {
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_ref_dec(cm_logical_id_t lid)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_lid = INVALID_LID;

    SX_LOG_ENTER();

    err = __verify_lid(lid);
    if (err) {
        goto out;
    }

    switch (cm_counter_bank_type_get(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_ref_dec(lid);
        if (err) {
            SX_LOG_ERR("Delete a reference to a previously allocated "
                       "Accumulated counter failed, rc = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
        /* Convert counter manager LID to bin allocator LID */
        ba_lid = CM_LID_BANK_TYPE_CLR(lid);

        /* Pass through to Bin Allocator */
        utils_err = ba_ref_dec(handle_s, ba_lid);
        if (utils_err) {
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_lock(cm_logical_id_t lid, cm_type_e *type_p, cm_hw_type_t *hw_type_p, cm_index_t *index_p)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    cm_type_e         type = CM_TYPE_PACKET_COUNTER_E;
    cm_hw_type_t      hw_type = rm_resource_global.cntr_type_flow_pkt;
    ba_logical_id_t   ba_lid = INVALID_LID;
    uint32_t          cntx = 0;
    cm_index_t        ba_index;

    SX_LOG_ENTER();

    err = __verify_lid(lid);
    if (err) {
        goto out;
    }

    if (index_p == NULL) {
        SX_LOG_ERR("Index pointer is NULL!\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cm_counter_bank_type_get(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_lock(lid, type_p, hw_type_p, index_p);
        if (err) {
            SX_LOG_ERR("Accumulated counter lock failed, rc = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
        /* Convert counter manager LID to bin allocator LID */
        ba_lid = CM_LID_BANK_TYPE_CLR(lid);

        /* Pass through to Bin Allocator */
        utils_err = ba_lock(handle_s, ba_lid, &ba_index, &cntx);
        if (utils_err) {
            err = sx_utils_status_to_sx_status(utils_err);
            SX_LOG_NTC("Shared counters lock failed, rc = %s\n", sx_status_str(err));
            goto out;
        }

        /* this function align index to hw bank size
         * please see the full explanation in function description */
        __cm_ba_index_get_aligned(ba_index, index_p);

        /* Type is the lower 8 bits of context */
        type = CM_CNTX_TYPE_GET(cntx);

        if (type_p) {
            *type_p = type;
        }

        /* If not needed save the cycles in performance path */
        if (hw_type_p) {
            /* Calculate the hw_type based on HW independent type */
            err = cm_hal_hw_type(type, &hw_type, NULL, NULL);
            if (err) {
                SX_LOG_NTC("Failed to calculate hw_type.\n");
                goto out;
            }

            *hw_type_p = hw_type;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_unlock(cm_logical_id_t lid)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_lid = INVALID_LID;

    SX_LOG_ENTER();

    err = __verify_lid(lid);
    if (err) {
        goto out;
    }

    switch (cm_counter_bank_type_get(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_unlock(lid);
        if (err) {
            SX_LOG_ERR("Accumulated counter unlock failed, rc = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
        /* Convert counter manager LID to bin allocator LID */
        ba_lid = CM_LID_BANK_TYPE_CLR(lid);

        /* Pass through to Bin Allocator */
        utils_err = ba_unlock(handle_s, ba_lid);
        if (utils_err) {
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_lid_attr_get(cm_logical_id_t lid, cm_attr_t *attr_p)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t          cntx = 0;
    ba_logical_id_t   ba_lid = INVALID_LID;
    uint32_t          ref = 0;

    SX_LOG_ENTER();

    err = __verify_lid(lid);
    if (err) {
        goto out;
    }

    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL!\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cm_counter_bank_type_get(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_attr_get(lid, attr_p);
        if (err) {
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
        /* Convert counter manager LID to bin allocator LID */
        ba_lid = CM_LID_BANK_TYPE_CLR(lid);

        /* Get BA context that holds our stuff */
        utils_err = ba_client_cntx_get(handle_s, ba_lid, &cntx, &ref);
        if (utils_err) {
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }

        /* Extract the counter type from the context where we put it */
        attr_p->type = CM_CNTX_TYPE_GET(cntx);
        attr_p->size = CM_CNTX_SIZE_GET(cntx);
        attr_p->ref = ref;

        err = cm_hal_hw_type(attr_p->type, &attr_p->hw_type, &attr_p->hw_len, NULL);
        if (err) {
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_ref_modify(cm_logical_id_t lid, int32_t val)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_lid = INVALID_LID;

    SX_LOG_ENTER();

    err = __verify_lid(lid);
    if (err) {
        goto out;
    }

    switch (cm_counter_bank_type_get(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_ref_modify(lid, val);
        if (err) {
            SX_LOG_ERR("Modify the reference count associated with an allocated "
                       "Accumulated counter failed, rc = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
        /* Convert counter manager LID to bin allocator LID */
        ba_lid = CM_LID_BANK_TYPE_CLR(lid);

        /* Pass directly to Bin Allocator to free */
        utils_err = ba_ref_modify(handle_s, ba_lid, val);
        if (utils_err) {
            err = sx_utils_status_to_sx_status(utils_err);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_block_clear(cm_logical_id_t lid, uint32_t offset)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (!init_done_s) {
        SX_LOG_ERR("Counter manager is not initialized!\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    switch (CM_LID_BANK_TYPE_GET(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_clear(lid, offset);
        if (err) {
            SX_LOG_ERR("afcm_counter_clear failed, rc = %s\n", sx_status_str(err));
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    return err;
}

sx_status_t cm_block_get(cm_logical_id_t lid, uint32_t offset, sx_flow_counter_set_t *counter_set_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (!init_done_s) {
        SX_LOG_ERR("Counter manager is not initialized!\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    switch (cm_counter_bank_type_get(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_get(lid, offset, counter_set_p);
        if (err) {
            SX_LOG_ERR("afcm_counter_get failed, rc = %s\n", sx_status_str(err));
            goto out;
        }

        break;

    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    return err;
}

cm_banks_type_e cm_counter_bank_type_get(cm_logical_id_t lid)
{
    return CM_LID_BANK_TYPE_GET(lid);
}

sx_status_t cm_counter_relocate_force(cm_logical_id_t lid)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = __verify_lid(lid);
    if (err) {
        goto out;
    }

    switch (cm_counter_bank_type_get(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_relocate_force(lid);
        if (err) {
            SX_LOG_ERR("Accumulated counter force relocation failed, rc = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t cm_counter_relocate_undo(cm_logical_id_t lid)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = __verify_lid(lid);
    if (err) {
        goto out;
    }

    switch (cm_counter_bank_type_get(lid)) {
    case CM_ACCUFLOW_COUNTERS_BANKS_E:
        err = afcm_counter_relocate_undo(lid);
        if (err) {
            SX_LOG_ERR("Accumulated counter relocation canceling failed, rc = %s\n", sx_status_str(err));
            goto out;
        }
        break;

    case CM_SHARED_COUNTERS_BANKS_E:
    default:
        SX_LOG_ERR("Unsupported type of counter: %u\n", CM_LID_BANK_TYPE_GET(lid));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}
