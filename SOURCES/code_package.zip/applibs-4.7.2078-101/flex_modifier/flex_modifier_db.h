/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLEX_MODIFIER_DB_H_INCL__
#define __FLEX_MODIFIER_DB_H_INCL__

#include <sx/sdk/sx_types.h>
#include "sx/sdk/sx_strings.h"
#include <sx/utils/sdk_refcount.h>
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

typedef struct emt_db_entry {
    boolean_t                   valid;           /* EMT was allocated by the create command */
    boolean_t                   configured;      /* EMT was configured by the set command */
    boolean_t                   fence_needed;    /* Indicate that a fence is needed before reusing an entry */
    sx_flex_modifier_emt_id_e   emt_id;
    sdk_refcount_t              refcount;        /* Used to count the number of user of this EMT */
    sx_flex_modifier_emt_cfg_t  emt_cfg;
    boolean_t                   is_tunnel;       /* Indicate this is an EMT to be used by tunnel */
    sx_tunnel_flex_header_cfg_t tunnel_cfg;      /* Configuration that is derived from the tunnel config */
    sx_router_interface_t       uirif;           /* Underlay irif to be used by the tunnel */
    sdk_ref_t                   gp_reg_ref;      /* Used to reference registers when using dynamic sizing */
} emt_db_entry_t;

typedef struct {
    cl_pool_item_t               pool_item;
    cl_map_item_t                map_item;
    sx_flex_modifier_port_attr_t port_attributes;   /* The flex modifier attributes to be used by the port */
} sx_flex_modifier_db_port_attr_item_t;

/* Callback function to be used by DB iterators during a device ready callback */
typedef sx_status_t (*flex_modifier_emt_db_pfn_t)(emt_db_entry_t *fixed_transition_entry,
                                                  void           *param_p);


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t flex_modifier_db_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

sx_status_t flex_modifier_db_init();

sx_status_t flex_modifier_db_deinit(boolean_t is_forced);

/* Get the EMT information from the DB. */
sx_status_t flex_modifierr_db_emt_get(const sx_flex_modifier_emt_id_e emt_id,
                                      emt_db_entry_t                **emt_entry_pp);

/* Find an EMT that is currently not used by anyone */
sx_status_t flex_modifier_db_find_free_emt(sx_flex_modifier_emt_id_e *free_emt_id_p);

/* Iterate over all the entries in the DB and call the callback function */
sx_status_t flex_modifier_db_emt_foreach(flex_modifier_emt_db_pfn_t func, void *param_p);

/*Get flex modifier port attribute from the DB*/
sx_status_t flex_modifier_db_port_attr_get(const sx_port_log_id_t                 log_port,
                                           sx_flex_modifier_db_port_attr_item_t **port_attr_item_pp);

/*Get flex modifier next port attribute from the DB*/
sx_status_t flex_modifier_db_port_attr_get_next(const sx_port_log_id_t                 log_port,
                                                sx_flex_modifier_db_port_attr_item_t **port_attr_item_pp);

/*Adds Payload_offset_mov attribute to the DB for an existing / new port entry*/
sx_status_t flex_modifier_db_port_attr_add(const sx_port_log_id_t                 log_port,
                                           sx_flex_modifier_db_port_attr_item_t **port_attr_item_pp);

/*Deletes current port payload_offset_move binding from the DB*/
sx_status_t flex_modifier_db_port_attr_delete(const sx_port_log_id_t log_port);

/* Get the number of entries in the port attribute DB */
sx_status_t flex_modifier_db_port_attr_count(uint32_t *att_cfg_cnt_p);

/*returns allocated memory to the pool*/
sx_status_t flex_modifier_db_port_attr_free(void);

/* Dump the EMT database */
void flex_modifier_db_emt_dump(dbg_dump_params_t *dbg_dump_params_p);

/* Dump the port modifier attribute database */
void flex_modifier_port_attr_dump(dbg_dump_params_t *dbg_dump_params_p);

#endif /*__FLEX_MODIFIER_DB_H_INCL__ */
