/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include "flex_modifier_db.h"
#include "flex_modifier.h"
#include "ethl2/fdb_common.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "ethl3/hwd/hwd_rif/hwd_rif.h"
#include "issu/issu.h"

#undef __MODULE__
#define __MODULE__ FLEX_MODIFIER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;


static sxd_emt_command_e hwd_flex_modifier_sxd_emt_command[] = {
    [SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E] = SXD_EMT_COMMAND_IMMEDIATE_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_SPAN_MIRROR_INGRESS_PORT_LABEL_E] = SXD_EMT_COMMAND_SPAN_MIRROR_INGRESS_PORT_LABEL_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_SPAN_MIRROR_EGRESS_PORT_LABEL_E] = SXD_EMT_COMMAND_SPAN_MIRROR_EGRESS_PORT_LABEL_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_INGRESS_TIMESTAMP_SEC_MSB_E] = SXD_EMT_COMMAND_INGRESS_TIMESTAMP_SEC_MSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_INGRESS_TIMESTAMP_SEC_LSB_E] = SXD_EMT_COMMAND_INGRESS_TIMESTAMP_SEC_LSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_INGRESS_TIMESTAMP_NSEC_MSB_E] = SXD_EMT_COMMAND_INGRESS_TIMESTAMP_NSEC_MSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_INGRESS_TIMESTAMP_NSEC_LSB_E] = SXD_EMT_COMMAND_INGRESS_TIMESTAMP_NSEC_LSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_SEC_MSB_E] = SXD_EMT_COMMAND_EGRESS_TIMESTAMP_SEC_MSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_SEC_LSB_E] = SXD_EMT_COMMAND_EGRESS_TIMESTAMP_SEC_LSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_NSEC_MSB_E] = SXD_EMT_COMMAND_EGRESS_TIMESTAMP_NSEC_MSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_TIMESTAMP_NSEC_LSB_E] = SXD_EMT_COMMAND_EGRESS_TIMESTAMP_NSEC_LSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_TCLASS_E] = SXD_EMT_COMMAND_TCLASS_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_BUFFER_FILL_LEVEL_MSB_E] = SXD_EMT_COMMAND_EGRESS_BUFFER_FILL_LEVEL_MSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_EGRESS_BUFFER_FILL_LEVEL_LSB_E] = SXD_EMT_COMMAND_EGRESS_BUFFER_FILL_LEVEL_LSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_LATENCY_MSB_E] = SXD_EMT_COMMAND_LATENCY_MSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_LATENCY_LSB_E] = SXD_EMT_COMMAND_LATENCY_LSB_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_0_E] = SXD_EMT_COMMAND_GP_REGISTER_0_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_1_E] = SXD_EMT_COMMAND_GP_REGISTER_1_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_2_E] = SXD_EMT_COMMAND_GP_REGISTER_2_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_3_E] = SXD_EMT_COMMAND_GP_REGISTER_3_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_4_E] = SXD_EMT_COMMAND_GP_REGISTER_4_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_5_E] = SXD_EMT_COMMAND_GP_REGISTER_5_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_6_E] = SXD_EMT_COMMAND_GP_REGISTER_6_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_GP_REGISTER_7_E] = SXD_EMT_COMMAND_GP_REGISTER_7_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_RAM0_WORD_0_E] = SXD_EMT_COMMAND_SRAM_0_D0_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_RAM0_WORD_1_E] = SXD_EMT_COMMAND_SRAM_0_D1_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_RAM0_WORD_2_E] = SXD_EMT_COMMAND_SRAM_0_D2_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_RAM0_WORD_3_E] = SXD_EMT_COMMAND_SRAM_0_D3_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_RAM1_WORD_0_E] = SXD_EMT_COMMAND_SRAM_1_D0_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_RAM1_WORD_1_E] = SXD_EMT_COMMAND_SRAM_1_D1_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_RAM1_WORD_2_E] = SXD_EMT_COMMAND_SRAM_1_D2_E,
    [SX_FLEX_MODIFIER_EMT_COMMAND_RAM1_WORD_3_E] = SXD_EMT_COMMAND_SRAM_1_D3_E,
};


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t hwd_flex_modifier_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    SX_LOG_EXIT();

    return rc;
}

sx_status_t hwd_flex_modifier_reg_fmtc_set(const sx_flex_modifier_emt_id_e    emt_id,
                                           const sx_flex_modifier_emt_cfg_t  *emt_cfg_p,
                                           const sx_tunnel_flex_header_cfg_t *tunnel_cfg,
                                           const sx_router_interface_t        uirif,
                                           const ram_offset_t                 sram_offset)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_fmtc_reg fmtc_reg_data;
    sxd_reg_meta_t     fmtc_reg_meta;
    uint32_t           i = 0;
    sx_boot_mode_e     boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    rc = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get ISSU boot mode for FMTC register, err = %s\n", sx_status_str(rc));
        goto out;
    }

    /* When in ISSU process we don't want to write the register yet since
     * it might later be updated with tunnel information. We'll write the register as a whole when all
     * configuration is complete.
     */
    if (boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        goto out;
    }

    SX_MEM_CLR(fmtc_reg_meta);
    SX_MEM_CLR(fmtc_reg_data);

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for fmtc, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    fmtc_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    fmtc_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    fmtc_reg_data.emt_index = emt_id;
    if (emt_cfg_p->emt_data_length_type == SX_FLEX_MODIFIER_DATA_LENGTH_TYPE_DYNAMIC_E) {
        fmtc_reg_data.length_cb = emt_cfg_p->emt_data_dynamic_length.gp_register.key.gp_reg.reg_id * 2;
        fmtc_reg_data.length_cb += emt_cfg_p->emt_data_dynamic_length.gp_register_byte;
        fmtc_reg_data.length_cb_mask = emt_cfg_p->emt_data_dynamic_length.mask;
        fmtc_reg_data.length_math_bitmap = (emt_cfg_p->emt_data_dynamic_length.is_bitmap) ? 1 : 0;
        if (emt_cfg_p->emt_data_dynamic_length.shift < 0) {
            fmtc_reg_data.length_math_shift = (uint8_t)(emt_cfg_p->emt_data_dynamic_length.shift * (-1));
            fmtc_reg_data.length_math_shift_left = 1;
        } else {
            fmtc_reg_data.length_math_shift = (uint8_t)(emt_cfg_p->emt_data_dynamic_length.shift);
            fmtc_reg_data.length_math_shift_left = 0;
        }
        fmtc_reg_data.length = emt_cfg_p->emt_data_dynamic_length.constant >> 1;
    } else {
        fmtc_reg_data.length = emt_cfg_p->emt_data_cnt;
    }

    fmtc_reg_data.buffer_fill_level_invalid_value = 0xffffffff;
    fmtc_reg_data.latency_invalid_value = 0x80000000;
    fmtc_reg_data.max_latency = 255;

    fmtc_reg_data.s0_offset = sram_offset;
    fmtc_reg_data.s1_offset = sram_offset;

    for (i = 0; i < emt_cfg_p->emt_update_cnt; i++) {
        switch (emt_cfg_p->emt_update_list[i]) {
        case SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_IPV4_LENGTH_E:
            fmtc_reg_data.update_ipv4_length = 1;
            break;

        case SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_IPV6_LENGTH_E:
            fmtc_reg_data.update_ipv6_length = 1;
            break;

        case SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_UDP_TCP_LENGTH_E:
            fmtc_reg_data.update_udp_tcp_length = 1;
            break;

        case SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_GENEVE_LENGTH_E:
            fmtc_reg_data.update_geneve_length = 1;
            break;

        case SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_HBH_LENGTH_E:
            fmtc_reg_data.update_hbh_length = 1;
            break;

        case SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_UDP_TCP_CHECKSUM_E:
            fmtc_reg_data.update_udp_tcp_cs = 1;
            break;

        case SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_CLEAR_UDP_CHECKSUM_E:
            fmtc_reg_data.clear_udp_cs = 1;
            break;

        case SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_IPV4_IHL_E:
            fmtc_reg_data.update_ipv4_ihl = 1;
            break;

        case SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_IPV4_CHECKSUM_E:
            fmtc_reg_data.update_ipv4_cs = 1;
            break;


        case SX_FLEX_MODIFIER_EMT_UPDATE_FIELD_LAST_E:
            break;
        }
    }

    /* If this EMT is used for a tunnel we need to configure some special things */
    if (tunnel_cfg != NULL) {
        rc = hwd_rif_hw_id_get(uirif, &fmtc_reg_data.enc_l2_uirif);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Cannot get hw rif id for EMT tunnel [%u], RIF [%u], error: [%s].\n",
                       emt_id,
                       uirif,
                       sx_status_str(rc));
            goto out;
        }

        fmtc_reg_data.enc_next_header = tunnel_cfg->enc_ip_next_header;
        if (tunnel_cfg->ip_version == SX_IP_VERSION_IPV6) {
            fmtc_reg_data.enc_flc = (tunnel_cfg->underlay_ip_enc.uipv6.use_overlay_fl) ? 1 : 0;
            fmtc_reg_data.enc_flh = (tunnel_cfg->underlay_ip_enc.uipv6.use_hash) ? 1 : 0;
            fmtc_reg_data.enc_fl_prefix = tunnel_cfg->underlay_ip_enc.uipv6.fl_12msb;
            fmtc_reg_data.enc_fl_suffix = tunnel_cfg->underlay_ip_enc.uipv6.fl_8lsb;
        } else if (tunnel_cfg->ip_version == SX_IP_VERSION_IPV4) {
            /* Set the ID + flags section of the IP header - fragment id set to zero*/
            fmtc_reg_data.enc_ipv4_id = tunnel_cfg->underlay_ip_enc.uipv4.id;
            fmtc_reg_data.enc_ipv4_flag = tunnel_cfg->underlay_ip_enc.uipv4.flags;
        }
    }

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FMTC_E, &fmtc_reg_data, &fmtc_reg_meta, 1, NULL, NULL);

    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure FMTC flex modifier EMT [%u]\n", emt_id);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}

sx_status_t hwd_flex_modifier_reg_fmte_set(const sx_flex_modifier_emt_id_e   emt_id,
                                           const sx_flex_modifier_emt_cfg_t *emt_cfg_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_fmte_reg fmte_reg_data;
    sxd_reg_meta_t     fmte_reg_meta;
    uint32_t           entry_index = 0;
    sx_boot_mode_e     boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    rc = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get ISSU boot mode for FMTC register, err = %s\n", sx_status_str(rc));
        goto out;
    }

    /* When in ISSU process we don't want to write the register yet since
     * it might later be updated with tunnel information. We'll write the register as a whole when all
     * configuration is complete.
     */
    if (boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        goto out;
    }

    SX_MEM_CLR(fmte_reg_meta);

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for fmte, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    fmte_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    fmte_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    for (entry_index = 0; entry_index < emt_cfg_p->emt_data_cnt; entry_index++) {
        SX_MEM_CLR(fmte_reg_data);
        fmte_reg_data.emt_index = emt_id;
        fmte_reg_data.entry_index = entry_index;
        if (!emt_cfg_p->emt_data_list[entry_index].skip) {
            fmte_reg_data.edit_en = 1;
            fmte_reg_data.cmd_id = hwd_flex_modifier_sxd_emt_command[emt_cfg_p->emt_data_list[entry_index].cmd_id];
            if (emt_cfg_p->emt_data_list[entry_index].cmd_id == SX_FLEX_MODIFIER_EMT_COMMAND_IMMEDIATE_E) {
                fmte_reg_data.imm = emt_cfg_p->emt_data_list[entry_index].immediate_value;
            } else if (emt_cfg_p->emt_data_list[entry_index].immediate_is_mask == TRUE) {
                fmte_reg_data.iim = 1;
                fmte_reg_data.imm = emt_cfg_p->emt_data_list[entry_index].immediate_value;
            }
        }
        sxd_status =
            sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FMTE_E, &fmte_reg_data, &fmte_reg_meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to configure FMTE flex modifier EMT [%u]\n", emt_id);
            rc = sxd_status_to_sx_status(sxd_status);
            goto out;
        }
    }


    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}

sx_status_t hwd_flex_modifier_reg_fmtm_set(const sx_flex_modifier_emt_id_e from_emt_id,
                                           const sx_flex_modifier_emt_id_e to_emt_id)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_fmtm_reg fmtm_reg_data;
    sxd_reg_meta_t     fmtm_reg_meta;
    sx_boot_mode_e     boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    rc = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get ISSU boot mode for FMTC register, err = %s\n", sx_status_str(rc));
        goto out;
    }

    /* When in ISSU process we don't want to write the register yet since
     * it might later be updated with tunnel information. We'll write the register as a whole when all
     * configuration is complete.
     */
    if (boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        goto out;
    }

    SX_MEM_CLR(fmtm_reg_meta);
    SX_MEM_CLR(fmtm_reg_data);

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for fmtm, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    fmtm_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    fmtm_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    fmtm_reg_data.emt_index_in = from_emt_id;
    fmtm_reg_data.emt_index_out = to_emt_id;

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FMTM_E, &fmtm_reg_data, &fmtm_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure FMTM flex modifier from EMT [%u] to EMT [%u]\n", from_emt_id, to_emt_id);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}

sx_status_t hwd_flex_modifier_reg_fmep_set(const sx_access_cmd_t  cmd,
                                           const sx_port_log_id_t log_port,
                                           const uint16_t         payload_offset_shift)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_fmep_reg fmep_reg_data;
    sxd_reg_meta_t     fmep_reg_meta;
    sx_port_phy_id_t   local_port = 0;

    SX_LOG_ENTER();

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(fmep_reg_meta);
    SX_MEM_CLR(fmep_reg_data);

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for fmep, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    fmep_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    fmep_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    /*in case of global fw will configure all ports with port 1 configuration*/
    local_port = SX_PORT_PHY_ID_GET(log_port);
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(fmep_reg_data.local_port,
                                        fmep_reg_data.lp_msb,
                                        local_port);

    fmep_reg_data.global = FALSE;
    if (cmd == SX_ACCESS_CMD_ADD) {
        fmep_reg_data.ext_mod_parsing = payload_offset_shift;
    }

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FMEP_E, &fmep_reg_data, &fmep_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure fmep for log_port [0x%X]\n", log_port);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t hwd_flex_modifier_reg_fgcr_set(const ram_offset_t sram_secondary_offset)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_fgcr_reg fgcr_reg_data;
    sxd_reg_meta_t     fgcr_reg_meta;


    SX_LOG_ENTER();

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(fgcr_reg_meta);
    SX_MEM_CLR(fgcr_reg_data);

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for fgcr, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    fgcr_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    fgcr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    fgcr_reg_data.flat_sec_offset = sram_secondary_offset;

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FGCR_E, &fgcr_reg_data, &fgcr_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure fgcr for secondary offset [%u]\n", sram_secondary_offset);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return rc;
}
