/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/sx_log.h>
#include <complib/cl_dbg.h>
#include "flex_modifier_db.h"

#undef __MODULE__
#define __MODULE__ FLEX_MODIFIER

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local definitions
 ***********************************************/

#define PORT_MODIFIER_ATTR_DB_POOL_MIN_SIZE  0
#define PORT_MODIFIER_ATTR_DB_POOL_MAX_SIZE  0
#define PORT_MODIFIER_ATTR_DB_POOL_GROW_SIZE 4

/************************************************
 *  Local Type definitions
 ***********************************************/
/* The following structures are used to map between the log_port and the
 * configured flex modifier attributes (i.e payload_offset_mov)
 */

typedef struct {
    cl_qpool_t port_attr_pool;
    cl_qmap_t  port_attr_map;
} flex_modifier_db_port_attr_db_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

static emt_db_entry_t emt_db[SX_FLEX_MODIFIER_EMT_LAST_E] = {
    [SX_FLEX_MODIFIER_EMT0_E] =
    {.valid = FALSE, .configured = FALSE, .is_tunnel = FALSE, .emt_id = SX_FLEX_MODIFIER_EMT0_E},
    [SX_FLEX_MODIFIER_EMT1_E] =
    {.valid = FALSE, .configured = FALSE, .is_tunnel = FALSE, .emt_id = SX_FLEX_MODIFIER_EMT1_E},
    [SX_FLEX_MODIFIER_EMT2_E] =
    {.valid = FALSE, .configured = FALSE, .is_tunnel = FALSE, .emt_id = SX_FLEX_MODIFIER_EMT2_E},
    [SX_FLEX_MODIFIER_EMT3_E] =
    {.valid = FALSE, .configured = FALSE, .is_tunnel = FALSE, .emt_id = SX_FLEX_MODIFIER_EMT3_E},
    [SX_FLEX_MODIFIER_EMT4_E] =
    {.valid = FALSE, .configured = FALSE, .is_tunnel = FALSE, .emt_id = SX_FLEX_MODIFIER_EMT4_E},
    [SX_FLEX_MODIFIER_EMT5_E] =
    {.valid = FALSE, .configured = FALSE, .is_tunnel = FALSE, .emt_id = SX_FLEX_MODIFIER_EMT5_E},
    [SX_FLEX_MODIFIER_EMT6_E] =
    {.valid = FALSE, .configured = FALSE, .is_tunnel = FALSE, .emt_id = SX_FLEX_MODIFIER_EMT6_E},
    [SX_FLEX_MODIFIER_EMT7_E] =
    {.valid = FALSE, .configured = FALSE, .is_tunnel = FALSE, .emt_id = SX_FLEX_MODIFIER_EMT7_E},
};

/* This DB is used to store the mapping of ports to their modifier attributes configuration */
static flex_modifier_db_port_attr_db_t port_attr_db;
/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t flex_modifier_db_log_verbosity_level_set(sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    SX_LOG_EXIT();

    return rc;
}

static const char* __get_emt_ref_name(char* name_buf, size_t name_size, void *emt_id_p)
{
    snprintf(name_buf, name_size, "EMT %u", *((sx_flex_modifier_emt_id_e*)emt_id_p));

    return name_buf;
}


sx_status_t flex_modifier_db_init()
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_emt_id_e emt_id = 0;
    cl_status_t               cl_rc = CL_SUCCESS;
    ref_name_data_t           emt_ref_name_data = {.print_func_p = __get_emt_ref_name,
                                                   .ref_data_p = &emt_id,
                                                   .data_size = sizeof(emt_id)};

    SX_LOG_ENTER();

    /* Initialize the reference count of the EMT */
    for (emt_id = 0; emt_id < SX_FLEX_MODIFIER_EMT_LAST_E; emt_id++) {
        sdk_refcount_init(&emt_db[emt_id].refcount, &emt_ref_name_data, NULL);
        SX_MEM_CLR(emt_db[emt_id].emt_cfg);
    }

    /* Initialize the DB used to map ports to their modifier attributes*/
    cl_rc = CL_QPOOL_INIT(&(port_attr_db.port_attr_pool),
                          PORT_MODIFIER_ATTR_DB_POOL_MIN_SIZE,
                          PORT_MODIFIER_ATTR_DB_POOL_MAX_SIZE,
                          PORT_MODIFIER_ATTR_DB_POOL_GROW_SIZE,
                          sizeof(sx_flex_modifier_db_port_attr_item_t),
                          NULL, NULL, NULL);

    if (cl_rc != CL_SUCCESS) {
        SX_LOG_ERR("Failed to init flex modifier port attributes DB. Error: (%s).\n", CL_STATUS_MSG(cl_rc));
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cl_qmap_init(&(port_attr_db.port_attr_map));

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_db_deinit(boolean_t is_forced)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_emt_id_e             emt_id = 0;
    cl_map_item_t                        *port_attr_item_p = NULL;
    sx_flex_modifier_db_port_attr_item_t *port_attr_entry_p = NULL;

    SX_LOG_ENTER();

    /* Do validation that no EMT is defined when not forced */
    if (is_forced == FALSE) {
        for (emt_id = 0; emt_id < SX_FLEX_MODIFIER_EMT_LAST_E; emt_id++) {
            if (emt_db[emt_id].valid == TRUE) {
                rc = SX_STATUS_RESOURCE_IN_USE;
                SX_LOG_ERR("Failed to deinit flex modifier DB: EMT [%u] is used.\n", emt_id);
                goto out;
            }
        }
    }

    /* De-Initialize the reference count */
    for (emt_id = 0; emt_id < SX_FLEX_MODIFIER_EMT_LAST_E; emt_id++) {
        sdk_refcount_deinit(&emt_db[emt_id].refcount, is_forced);
    }
    /* Remove all items in rules ref list and put them back to pool */
    port_attr_item_p = cl_qmap_head(&(port_attr_db.port_attr_map));
    while (port_attr_item_p != cl_qmap_end(&(port_attr_db.port_attr_map))) {
        port_attr_entry_p = PARENT_STRUCT(port_attr_item_p, sx_flex_modifier_db_port_attr_item_t, map_item);
        port_attr_item_p = cl_qmap_next(port_attr_item_p);
        cl_qmap_remove_item(&(port_attr_db.port_attr_map), &(port_attr_entry_p->map_item));
        cl_qpool_put(&(port_attr_db.port_attr_pool), &(port_attr_entry_p->pool_item));
    }
    /* Destroy the map from the port to the flex attributes */
    CL_QPOOL_DESTROY(&(port_attr_db.port_attr_pool));

out:
    SX_LOG_EXIT();

    return rc;
}


/* Get the EMT information from the DB. */
sx_status_t flex_modifierr_db_emt_get(const sx_flex_modifier_emt_id_e emt_id,
                                      emt_db_entry_t                **emt_entry_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Do a validation on the EMT id */
    if (emt_id >= SX_FLEX_MODIFIER_EMT_LAST_E) {
        SX_LOG_ERR("Invalid value for EMT [%u] get.\n", emt_id);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (emt_entry_pp != NULL) {
        *emt_entry_pp = &emt_db[emt_id];
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_db_find_free_emt(sx_flex_modifier_emt_id_e *free_emt_id_p)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_emt_id_e emt_id = 0;

    SX_LOG_ENTER();

    for (emt_id = SX_FLEX_MODIFIER_EMT0_E; emt_id < SX_FLEX_MODIFIER_EMT_LAST_E; emt_id++) {
        if (emt_db[emt_id].valid != TRUE) {
            *free_emt_id_p = emt_id;
            goto out;
        }
    }

    rc = SX_STATUS_NO_RESOURCES;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_db_emt_foreach(flex_modifier_emt_db_pfn_t func, void *param_p)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_emt_id_e emt_id = 0;

    SX_LOG_ENTER();

    for (emt_id = SX_FLEX_MODIFIER_EMT0_E; emt_id < SX_FLEX_MODIFIER_EMT_LAST_E; emt_id++) {
        if (emt_db[emt_id].valid) {
            rc = func(&emt_db[emt_id], param_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed EMT foreach callback.\n");
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_db_port_attr_get(const sx_port_log_id_t                 log_port,
                                           sx_flex_modifier_db_port_attr_item_t **port_attr_item_pp)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    cl_map_item_t       *map_item_p = NULL;
    const cl_map_item_t *map_end_p = NULL;

    SX_LOG_ENTER();

    /* Find out if this port is already mapped */
    map_item_p = cl_qmap_get(&(port_attr_db.port_attr_map), log_port);
    map_end_p = cl_qmap_end(&(port_attr_db.port_attr_map));

    if (map_item_p == map_end_p) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *port_attr_item_pp = PARENT_STRUCT(map_item_p, sx_flex_modifier_db_port_attr_item_t, map_item);


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_db_port_attr_get_next(const sx_port_log_id_t                 log_port,
                                                sx_flex_modifier_db_port_attr_item_t **port_attr_item_pp)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    cl_map_item_t       *map_item_p = NULL;
    const cl_map_item_t *map_end_p = NULL;

    SX_LOG_ENTER();

    /* Find out if this port is already mapped */
    map_item_p = cl_qmap_get_next(&(port_attr_db.port_attr_map), log_port);
    map_end_p = cl_qmap_end(&(port_attr_db.port_attr_map));

    if (map_item_p == map_end_p) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *port_attr_item_pp = PARENT_STRUCT(map_item_p, sx_flex_modifier_db_port_attr_item_t, map_item);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_db_port_attr_add(const sx_port_log_id_t                 log_port,
                                           sx_flex_modifier_db_port_attr_item_t **port_attr_item_pp)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    cl_map_item_t       *map_item_p = NULL;
    const cl_map_item_t *map_end_p = NULL;
    cl_pool_item_t      *pool_item_p = NULL;

    SX_LOG_ENTER();

    /* Find out if this port is already mapped */
    map_item_p = cl_qmap_get(&(port_attr_db.port_attr_map), log_port);
    map_end_p = cl_qmap_end(&(port_attr_db.port_attr_map));

    if (map_item_p != map_end_p) {  /* Entry already exists */
        /* Return the item */
        *port_attr_item_pp = PARENT_STRUCT(map_item_p, sx_flex_modifier_db_port_attr_item_t, map_item);
    } else {  /* Entry does'nt exists */
        pool_item_p = cl_qpool_get(&(port_attr_db.port_attr_pool));
        if (pool_item_p == NULL) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed to add flex modifier attribute DB entry to port [0x%08X] rc=[%s]\n",
                       log_port,
                       sx_status_str(rc));
            goto out;
        }
        *port_attr_item_pp = PARENT_STRUCT(pool_item_p, sx_flex_modifier_db_port_attr_item_t, pool_item);
        cl_qmap_insert(&(port_attr_db.port_attr_map), log_port, &((*port_attr_item_pp)->map_item));
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_db_port_attr_delete(const sx_port_log_id_t log_port)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_db_port_attr_item_t *port_attr_item_p = NULL;

    SX_LOG_ENTER();

    rc = flex_modifier_db_port_attr_get(log_port, &port_attr_item_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex modifier payload_offset_shift is not configure for logical port [0x%x].\n", log_port);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    cl_qmap_remove_item(&(port_attr_db.port_attr_map), &(port_attr_item_p->map_item));
    cl_qpool_put(&(port_attr_db.port_attr_pool), &(port_attr_item_p->pool_item));

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_db_port_attr_count(uint32_t *att_cfg_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    *att_cfg_cnt_p = cl_qmap_count(&(port_attr_db.port_attr_map));

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_modifier_db_port_attr_free(void)
{
    sx_status_t                           rc = SX_STATUS_SUCCESS;
    sx_flex_modifier_db_port_attr_item_t *port_attr_item_p;
    cl_map_item_t                        *map_item_p = NULL;
    const cl_map_item_t                  *map_end_p = NULL;

    SX_LOG_ENTER();

    map_item_p = cl_qmap_head(&(port_attr_db.port_attr_map));
    map_end_p = cl_qmap_end(&(port_attr_db.port_attr_map));

    while (map_item_p != map_end_p) {
        port_attr_item_p = PARENT_STRUCT(map_item_p, sx_flex_modifier_db_port_attr_item_t, map_item);
        map_item_p = cl_qmap_get_next(&(port_attr_db.port_attr_map), port_attr_item_p->port_attributes.log_port);
        cl_qmap_remove(&(port_attr_db.port_attr_map), port_attr_item_p->port_attributes.log_port);
        cl_qpool_put(&(port_attr_db.port_attr_pool), &(port_attr_item_p->pool_item));
    }

    SX_LOG_EXIT();
    return rc;
}

void flex_modifier_db_emt_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    int                       ref_count = 0;
    sx_utils_status_t         utils_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t                  i = 0, j = 0;
    boolean_t                 is_first = TRUE;
    FILE                     *stream = NULL;
    dbg_utils_table_columns_t flex_modifier_emt_table_dump_clmns[] = {
        { "EMT",              6,    PARAM_UINT32_E,     NULL},          /* 0 */
        { "Configured",       12,   PARAM_BOOL_E,       NULL},          /* 1 */
        { "Ref Cnt",          8,    PARAM_INT_E,       &ref_count},     /* 2 */
        { "Data Cnt",         9,    PARAM_UINT32_E,     NULL},          /* 3 */
        { "Update Cnt",       12,   PARAM_UINT32_E,     NULL},          /* 4 */
        { "Is Tunnel",        10,   PARAM_BOOL_E,       NULL},          /* 5 */
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t flex_modifier_command_table_dump_clmns[] = {
        { "Index",            6,    PARAM_UINT32_E,     NULL},          /* 0 */
        { "Command",          40,   PARAM_STRING_E,     NULL},          /* 1 */
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t flex_modifier_update_table_dump_clmns[] = {
        { "Index",           6,    PARAM_UINT32_E,     NULL},          /* 0 */
        { "Update",          40,   PARAM_STRING_E,     NULL},          /* 1 */
        {NULL, 0, 0, NULL}
    };


    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Flex Modifier EMT");

    is_first = TRUE;
    for (i = 0; i < SX_FLEX_MODIFIER_EMT_LAST_E; i++) {
        if (emt_db[i].valid) {
            if (is_first) {
                dbg_utils_pprinter_secondary_header_print(stream, "Flex Modifier EMT overview");
                dbg_utils_pprinter_table_headline_print(stream, flex_modifier_emt_table_dump_clmns);
                is_first = FALSE;
            }

            flex_modifier_emt_table_dump_clmns[0].data = &emt_db[i].emt_id;                  /* 0 */
            flex_modifier_emt_table_dump_clmns[1].data = &emt_db[i].configured;              /* 1 */
            utils_err = sdk_refcount_get(&emt_db[i].refcount, &ref_count);                         /* 2 */
            if (utils_err != SX_UTILS_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed get ref_cnt (err: %s)\n", SX_UTILS_STATUS_MSG(utils_err));
                goto out;
            }
            flex_modifier_emt_table_dump_clmns[3].data = &emt_db[i].emt_cfg.emt_data_cnt;    /* 3 */
            flex_modifier_emt_table_dump_clmns[4].data = &emt_db[i].emt_cfg.emt_update_cnt;  /* 4 */
            flex_modifier_emt_table_dump_clmns[5].data = &emt_db[i].is_tunnel;               /* 5 */

            dbg_utils_pprinter_table_data_line_print(stream, flex_modifier_emt_table_dump_clmns);
        }
    }

    for (i = 0; i < SX_FLEX_MODIFIER_EMT_LAST_E; i++) {
        if (emt_db[i].configured) {
            dbg_utils_pprinter_secondary_header_print(stream, "Flex Modifier EMT %u", i);

            dbg_utils_pprinter_table_headline_print(stream, flex_modifier_command_table_dump_clmns);
            for (j = 0; j < emt_db[i].emt_cfg.emt_data_cnt; j++) {
                flex_modifier_command_table_dump_clmns[0].data = &j;
                flex_modifier_command_table_dump_clmns[1].data = sx_flex_modifier_emt_command_str(
                    emt_db[i].emt_cfg.emt_data_list[j].cmd_id);
                dbg_utils_pprinter_table_data_line_print(stream, flex_modifier_command_table_dump_clmns);
            }

            dbg_utils_pprinter_table_headline_print(stream, flex_modifier_update_table_dump_clmns);
            for (j = 0; j < emt_db[i].emt_cfg.emt_update_cnt; j++) {
                flex_modifier_update_table_dump_clmns[0].data = &j;
                flex_modifier_update_table_dump_clmns[1].data = sx_flex_modifier_emt_update_field_str(
                    emt_db[i].emt_cfg.emt_update_list[j]);
                dbg_utils_pprinter_table_data_line_print(stream, flex_modifier_update_table_dump_clmns);
            }
        }
    }

out:
    SX_LOG_EXIT();
    return;
}

void flex_modifier_port_attr_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    cl_map_item_t                        *map_item_p = NULL;
    const cl_map_item_t                  *map_end_p = NULL;
    sx_flex_modifier_db_port_attr_item_t *port_attr_item_p = NULL;
    static dbg_utils_table_columns_t      port_attr_cfg_dump_columns[] = {
        { "PORT",    14,  PARAM_PORT_ID_E,     NULL }, /* 0 */
        { "PAYLOAD_OFFSET_SHIFT",  14, PARAM_UINT16_E,      NULL },  /* 1 */
        {NULL, 0, 0, NULL}
    };
    FILE                                 *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        return;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "Flex modifier port  attributes");

    /* Find out if this port is already mapped */
    map_item_p = cl_qmap_head(&(port_attr_db.port_attr_map));
    map_end_p = cl_qmap_end(&(port_attr_db.port_attr_map));

    dbg_utils_pprinter_table_headline_print(stream, port_attr_cfg_dump_columns);

    while (map_item_p != map_end_p) {
        port_attr_item_p = PARENT_STRUCT(map_item_p, sx_flex_modifier_db_port_attr_item_t, map_item);
        port_attr_cfg_dump_columns[0].data = &port_attr_item_p->port_attributes.log_port;
        port_attr_cfg_dump_columns[1].data = &port_attr_item_p->port_attributes.payload_offset_shift;
        map_item_p = cl_qmap_next(map_item_p);

        dbg_utils_pprinter_table_data_line_print(stream, port_attr_cfg_dump_columns);
    }

    SX_LOG_EXIT();
    return;
}
