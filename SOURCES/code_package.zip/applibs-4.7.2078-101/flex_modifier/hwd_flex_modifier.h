/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWD_FLEX_MODIFIER_H_INCL__
#define __HWD_FLEX_MODIFIER_H_INCL__

#include <sx/sdk/sx_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t hwd_flex_modifier_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

sx_status_t hwd_flex_modifier_reg_fmtc_set(const sx_flex_modifier_emt_id_e    emt_id,
                                           const sx_flex_modifier_emt_cfg_t  *emt_cfg_p,
                                           const sx_tunnel_flex_header_cfg_t *tunnel_cfg,
                                           const sx_router_interface_t        uirif,
                                           const ram_offset_t                 sram_offset);

sx_status_t hwd_flex_modifier_reg_fmte_set(const sx_flex_modifier_emt_id_e   emt_id,
                                           const sx_flex_modifier_emt_cfg_t *emt_cfg_p);

sx_status_t hwd_flex_modifier_reg_fmtm_set(const sx_flex_modifier_emt_id_e from_emt_id,
                                           const sx_flex_modifier_emt_id_e to_emt_id);

sx_status_t hwd_flex_modifier_reg_fmep_set(const sx_access_cmd_t  cmd,
                                           const sx_port_log_id_t log_port,
                                           const uint16_t         payload_offset_shift);

sx_status_t hwd_flex_modifier_reg_fgcr_set(const ram_offset_t sram_secondary_offset);

#endif /*__HWD_FLEX_MODIFIER_H_INCL__ */
