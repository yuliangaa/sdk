/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLEX_MODIFIER_H_INCL__
#define __FLEX_MODIFIER_H_INCL__

#include <sx/sdk/sx_types.h>
#include "sx/utils/sdk_refcount.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef uint16_t ram_offset_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


sx_status_t flex_modifier_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

sx_status_t flex_modifier_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

sx_status_t flex_modifier_init();

sx_status_t flex_modifier_init_spc4();

sx_status_t flex_modifier_deinit(boolean_t is_forced);

sx_status_t flex_modifier_set(const sx_access_cmd_t             cmd,
                              const sx_flex_modifier_emt_id_e   emt_id,
                              const sx_flex_modifier_emt_cfg_t *emt_cfg_p);

sx_status_t flex_modifier_get(const sx_access_cmd_t           cmd,
                              const sx_flex_modifier_emt_id_e emt_id,
                              sx_flex_modifier_emt_cfg_t     *emt_cfg_p);

sx_status_t flex_modifier_attr_set(const sx_access_cmd_t                cmd,
                                   const uint32_t                       att_cfg_cnt,
                                   const sx_flex_modifier_attributes_t *att_cfg_list_p);

sx_status_t flex_modifier_port_attr_set_handler(const sx_access_cmd_t               cmd,
                                                const sx_flex_modifier_type_attr_u *sx_flex_modifier_attr);

sx_status_t flex_modifier_attr_get(const sx_access_cmd_t          cmd,
                                   uint32_t                      *attr_cfg_cnt_p,
                                   sx_flex_modifier_attributes_t *attr_cfg_list_p);

sx_status_t flex_modifier_validate_emt_bind(const sx_flex_modifier_emt_id_e  emt_id,
                                            sx_flex_modifier_emt_bind_type_e bind_type);

sx_status_t flex_modifier_emt_ref_inc(const sx_flex_modifier_emt_id_e emt_id,
                                      const ref_name_data_t          *ref_name_data_p,
                                      sdk_ref_t                      *ref_p);

sx_status_t flex_modifier_emt_ref_dec(const sx_flex_modifier_emt_id_e emt_id, sdk_ref_t *ref_p);

sx_status_t flex_modifier_emt_ref_get(const sx_flex_modifier_emt_id_e emt_id, int* count_p);

/* Write the complete flex modifier registers after ISSU is complete*/
sx_status_t flex_modifier_issu_set();

/* Set the secondary RAM offset */
sx_status_t flex_modifier_secondary_ram_offset_set_internal(const ram_offset_t ram_secondary_offset);

/* This function must be called by any user wishing to use the secondary ram */
sx_status_t flex_modifier_secondary_ram_lock();

/* This function should be called when the use doesn't need to use the secondary ram anymore */
sx_status_t flex_modifier_secondary_ram_unlock();

void flex_modifier_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

/* Functions related to the use of EMT by flex tunnel */

/* Change an existing EMT to with tunnel configuration */
sx_status_t flex_modifier_tunnel_set(const sx_tunnel_flex_header_cfg_t *tunnel_header_cfg_p,
                                     const sx_router_interface_t        uirif);

/* Remove tunnel configuration from an EMT */
sx_status_t flex_modifier_tunnel_unset(const sx_flex_modifier_emt_id_e emt_id);


#endif /*__FLEX_MODIFIER_H_INCL__ */
