/*
 * SPDX-FileCopyrightText: Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "hwd_ar.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "sx/utils/sx_utils_status.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "ethl2/fdb.h"
#include <complib/cl_byteswap.h>


#undef  __MODULE__
#define __MODULE__ ADAPTIVE_ROUTING

/************************************************
 *  Global variables
 ***********************************************/
hwd_ar_ops_t          g_hwd_ar_ops;
extern rm_resources_t rm_resource_global;

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __hwd_ar_profile_set_spc2(const sx_access_cmd_t       cmd,
                                             const sx_ar_profile_key_t  *profile_key_p,
                                             const sx_ar_profile_attr_t *profile_attr_p);
static sx_status_t __hwd_ar_arn_profile_set_spc2(const sx_access_cmd_t        cmd,
                                                 const sx_ar_profile_key_t   *profile_key_p,
                                                 const sx_arn_profile_attr_t *profile_attr_p);
static sx_status_t __hwd_ar_classification_set_common(const sx_access_cmd_t            cmd,
                                                      struct ku_rarpc_reg             *reg,
                                                      const sx_ar_classifier_type_e    classifier_type,
                                                      const sx_ar_classifier_id_e      classifier_id,
                                                      const sx_ar_classifier_action_t *classifier_action,
                                                      const sx_ar_classifier_attr_t   *attr_p);
static sx_status_t __hwd_ar_classification_attr_validate_spc2(const sx_ar_classifier_attr_t *attr_p);
static sx_status_t __hwd_ar_classification_set_spc2(const sx_access_cmd_t            cmd,
                                                    const sx_ar_classifier_type_e    classifier_type,
                                                    const sx_ar_classifier_id_e      classifier_id,
                                                    const sx_ar_classifier_action_t *classifier_action,
                                                    const sx_ar_classifier_attr_t   *attr_p);
static sx_status_t __hwd_ar_classification_set_spc4(const sx_access_cmd_t            cmd,
                                                    const sx_ar_classifier_type_e    classifier_type,
                                                    const sx_ar_classifier_id_e      classifier_id,
                                                    const sx_ar_classifier_action_t *classifier_action,
                                                    const sx_ar_classifier_attr_t   *attr_p);
static sx_status_t __hwd_ar_congestion_threshold_set_spc2(const sx_access_cmd_t                    cmd,
                                                          const sx_ar_congestion_threshold_attr_t *congestion_thresh);
static sx_status_t __hwd_ar_shaper_rate_set_spc2(const sx_access_cmd_t      cmd,
                                                 const sx_ar_shaper_attr_t *shaper_attr_p);
static sx_status_t __hwd_ar_shaper_rate_get_spc2(const sx_access_cmd_t cmd, sx_ar_shaper_attr_t *shaper_attr_p);
static sx_status_t __hwd_ar_link_utilization_threshold_set_spc2(const sx_access_cmd_t                cmd,
                                                                const sx_port_log_id_t               log_port,
                                                                const sx_ar_link_utilization_attr_t *link_util_attr_p);
static sx_status_t __hwd_ar_counters_get_spc2(const sx_access_cmd_t    cmd,
                                              sx_ar_global_counters_t *ar_counters_p);
static sx_status_t __hwd_ar_arn_params_set_rarns(sx_arn_default_params_t *arn_default_params_p);
static sx_status_t __hwd_ar_arn_params_set_spc2(sx_arn_default_params_t   *arn_default_params_p,
                                                sx_arn_general_params_t   *arn_general_params_p,
                                                sx_arn_counters_indices_t *arn_counters_indices_p);
static sx_status_t __hwd_ar_arn_router_gen_set_spc2(const sx_access_cmd_t             cmd,
                                                    const sx_arn_router_key_t        *router_key_p,
                                                    const sx_arn_router_attributes_t *router_attr_p);
static sx_status_t __hwd_ar_arn_port_params_set_spc2(const sx_access_cmd_t             cmd,
                                                     const sx_port_log_id_t            log_port,
                                                     const sx_mac_addr_t               mac_addr,
                                                     const hwd_ar_arn_port_conf_type_e config_type);
static sx_status_t __hwd_ar_arn_port_counters_get_spc2(const sx_access_cmd_t   cmd,
                                                       const sx_port_log_id_t  log_port,
                                                       sx_arn_port_counters_t *port_counters_p);
static sx_status_t __hwd_ar_arn_system_port_param_set_spc2(const sx_access_cmd_t  cmd,
                                                           const sx_port_log_id_t log_port);
static sx_status_t __hwd_ar_tc_mapping_init_spc2(cos_ar_tc_mapping_t *mapping_p);
static sx_status_t __hwd_ar_tc_mapping_init_spc5(cos_ar_tc_mapping_t *mapping_p);

static sx_status_t __rarpr_regdata_write(struct ku_rarpr_reg *rarpr, sx_dev_id_t dev_id);
static sx_status_t __rarnpr_regdata_write(struct ku_rarnpr_reg *rarpr, sx_dev_id_t dev_id);
static sx_status_t __rarnpc_regdata_read(struct ku_rarnpc_reg *rarnpc, sx_dev_id_t dev_id);
static sx_status_t __rarpc_regdata_write(struct ku_rarpc_reg *rarpc);
static sx_status_t __rarcl_regdata_write(struct ku_rarcl_reg *rarcl);
static sx_status_t __rarsr_regdata_write(struct ku_rarsr_reg *rarsr);
static sx_status_t __rarsr_regdata_read(struct ku_rarsr_reg *rarsr, sx_dev_id_t dev_id);
static sx_status_t __rarlu_regdata_write(struct ku_rarlu_reg *rarlu);
static sx_status_t __rarcc_regdata_read(struct ku_rarcc_reg *rarcc, sx_dev_id_t dev_id);
static sx_status_t __rarngc_regdata_write(struct ku_rarngc_reg *rarngc);
static sx_status_t __rarns_regdata_write(struct ku_rarns_reg *rarns);
static sx_status_t __rarncg_regdata_write(struct ku_rarncg_reg *rarncg);
static sx_status_t __rarftbr_data_read(sx_arn_flow_entry_status_t *flow_status_list_p,
                                       uint32_t                    arft_index,
                                       uint16_t                    num_rec,
                                       uint16_t                   *actual_rec_p,
                                       sx_dev_id_t                 dev_id);
static sx_status_t __rartm_regdata_write(struct ku_rartm_reg *rartm, sx_dev_id_t dev_id);
static sx_status_t __hwd_arn_counter_relocate_cb(const cm_logical_id_t lid,
                                                 const uint32_t        offset,
                                                 const cm_type_e       type,
                                                 const cm_hw_type_t    hw_type,
                                                 const cm_index_t      old_index,
                                                 const cm_index_t      new_index);
/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t hwd_ar_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    return err;
}

sx_status_t hwd_ar_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

    return sx_status;
}

void hwd_router_ar_set_impl_ops_spc2()
{
    /* Implementation specific to Spectrum2 & 3 */
    g_hwd_ar_ops.hwd_ar_profile_set_pfn = __hwd_ar_profile_set_spc2;
    g_hwd_ar_ops.hwd_ar_classification_set_pfn = __hwd_ar_classification_set_spc2;
    g_hwd_ar_ops.hwd_ar_congestion_threshold_set_pfn = __hwd_ar_congestion_threshold_set_spc2;
    g_hwd_ar_ops.hwd_ar_shaper_rate_set_pfn = __hwd_ar_shaper_rate_set_spc2;
    g_hwd_ar_ops.hwd_ar_shaper_rate_get_pfn = __hwd_ar_shaper_rate_get_spc2;
    g_hwd_ar_ops.hwd_ar_link_utilization_threshold_set_pfn = __hwd_ar_link_utilization_threshold_set_spc2;
    g_hwd_ar_ops.hwd_ar_counters_get_pfn = __hwd_ar_counters_get_spc2;
    g_hwd_ar_ops.hwd_ar_classification_attr_validate_pfn = __hwd_ar_classification_attr_validate_spc2;
    g_hwd_ar_ops.hwd_arn_params_set_pfn = __hwd_ar_arn_params_set_spc2;
    g_hwd_ar_ops.hwd_arn_router_gen_set_pfn = __hwd_ar_arn_router_gen_set_spc2;
    g_hwd_ar_ops.hwd_arn_ar_port_params_set_pfn = __hwd_ar_arn_port_params_set_spc2;
    g_hwd_ar_ops.hwd_arn_profile_set_pfn = __hwd_ar_arn_profile_set_spc2;
    g_hwd_ar_ops.hwd_arn_port_counters_get_pfn = __hwd_ar_arn_port_counters_get_spc2;
    g_hwd_ar_ops.hwd_arn_system_port_param_set_pfn = __hwd_ar_arn_system_port_param_set_spc2;
    g_hwd_ar_ops.hwd_arn_counter_relocate_pfn = __hwd_arn_counter_relocate_cb;
    g_hwd_ar_ops.hwd_ar_tc_mapping_init_pfn = __hwd_ar_tc_mapping_init_spc2;
}

void hwd_router_ar_set_impl_ops_spc4()
{
    /* Implementation specific to Spectrum4 */
    g_hwd_ar_ops.hwd_ar_profile_set_pfn = __hwd_ar_profile_set_spc2;
    g_hwd_ar_ops.hwd_ar_classification_set_pfn = __hwd_ar_classification_set_spc4;
    g_hwd_ar_ops.hwd_ar_congestion_threshold_set_pfn = __hwd_ar_congestion_threshold_set_spc2;
    g_hwd_ar_ops.hwd_ar_shaper_rate_set_pfn = __hwd_ar_shaper_rate_set_spc2;
    g_hwd_ar_ops.hwd_ar_shaper_rate_get_pfn = __hwd_ar_shaper_rate_get_spc2;
    g_hwd_ar_ops.hwd_ar_link_utilization_threshold_set_pfn = __hwd_ar_link_utilization_threshold_set_spc2;
    g_hwd_ar_ops.hwd_ar_counters_get_pfn = __hwd_ar_counters_get_spc2;
    g_hwd_ar_ops.hwd_ar_classification_attr_validate_pfn = NULL;
    g_hwd_ar_ops.hwd_arn_params_set_pfn = __hwd_ar_arn_params_set_spc2;
    g_hwd_ar_ops.hwd_arn_router_gen_set_pfn = __hwd_ar_arn_router_gen_set_spc2;
    g_hwd_ar_ops.hwd_arn_ar_port_params_set_pfn = __hwd_ar_arn_port_params_set_spc2;
    g_hwd_ar_ops.hwd_arn_profile_set_pfn = __hwd_ar_arn_profile_set_spc2;
    g_hwd_ar_ops.hwd_arn_port_counters_get_pfn = __hwd_ar_arn_port_counters_get_spc2;
    g_hwd_ar_ops.hwd_arn_system_port_param_set_pfn = __hwd_ar_arn_system_port_param_set_spc2;
    g_hwd_ar_ops.hwd_arn_counter_relocate_pfn = __hwd_arn_counter_relocate_cb;
    g_hwd_ar_ops.hwd_ar_tc_mapping_init_pfn = __hwd_ar_tc_mapping_init_spc2;
}

void hwd_router_ar_set_impl_ops_spc5()
{
    /* Implementation specific to Spectrum5 */
    g_hwd_ar_ops.hwd_ar_profile_set_pfn = __hwd_ar_profile_set_spc2;
    g_hwd_ar_ops.hwd_ar_classification_set_pfn = __hwd_ar_classification_set_spc4;
    g_hwd_ar_ops.hwd_ar_congestion_threshold_set_pfn = __hwd_ar_congestion_threshold_set_spc2;
    g_hwd_ar_ops.hwd_ar_shaper_rate_set_pfn = __hwd_ar_shaper_rate_set_spc2;
    g_hwd_ar_ops.hwd_ar_shaper_rate_get_pfn = __hwd_ar_shaper_rate_get_spc2;
    g_hwd_ar_ops.hwd_ar_link_utilization_threshold_set_pfn = __hwd_ar_link_utilization_threshold_set_spc2;
    g_hwd_ar_ops.hwd_ar_counters_get_pfn = __hwd_ar_counters_get_spc2;
    g_hwd_ar_ops.hwd_ar_classification_attr_validate_pfn = NULL;
    g_hwd_ar_ops.hwd_arn_params_set_pfn = __hwd_ar_arn_params_set_spc2;
    g_hwd_ar_ops.hwd_arn_router_gen_set_pfn = __hwd_ar_arn_router_gen_set_spc2;
    g_hwd_ar_ops.hwd_arn_ar_port_params_set_pfn = __hwd_ar_arn_port_params_set_spc2;
    g_hwd_ar_ops.hwd_arn_profile_set_pfn = __hwd_ar_arn_profile_set_spc2;
    g_hwd_ar_ops.hwd_arn_port_counters_get_pfn = __hwd_ar_arn_port_counters_get_spc2;
    g_hwd_ar_ops.hwd_arn_system_port_param_set_pfn = __hwd_ar_arn_system_port_param_set_spc2;
    g_hwd_ar_ops.hwd_arn_counter_relocate_pfn = __hwd_arn_counter_relocate_cb;
    g_hwd_ar_ops.hwd_ar_tc_mapping_init_pfn = __hwd_ar_tc_mapping_init_spc5;
}

static sx_status_t __hwd_ar_arn_profile_set_spc2(const sx_access_cmd_t        cmd,
                                                 const sx_ar_profile_key_t   *profile_key_p,
                                                 const sx_arn_profile_attr_t *profile_attr_p)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    struct ku_rarnpr_reg reg;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg);

    reg.profile_index = profile_key_p->profile;
    reg.arn_aging_time = profile_attr_p->arn_aging_time;
    reg.hold_time_after_change = profile_attr_p->arn_hold_time;
    reg.arn_gen_en = profile_attr_p->arn_enable;
    reg.elph = profile_attr_p->only_elephant_enable;
    reg.penalty_grade = profile_attr_p->arn_penalty;


    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __rarnpr_regdata_write(&reg, SXD_DEV_ID_MIN);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to update RARNPR register (rc=%d)\n", err);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_profile_set_spc2(const sx_access_cmd_t       cmd,
                                             const sx_ar_profile_key_t  *profile_key_p,
                                             const sx_ar_profile_attr_t *profile_attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_rarpr_reg reg;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg);

    reg.ar_prof_id = profile_key_p->profile;
    reg.prof_mode = (sxd_rarpr_prof_mode_t)profile_attr_p->mode;
    if (profile_attr_p->mode != SX_AR_PROFILE_MODE_FREE_E) {
        reg.elph = profile_attr_p->only_elephant_en;
    }
    if (profile_attr_p->mode != SX_AR_PROFILE_MODE_RANDOM_E) {
        reg.grade_thr_free = profile_attr_p->profile_threshold.free_threshold;
        reg.grade_thr_busy = profile_attr_p->profile_threshold.busy_threshold;

        reg.srf = profile_attr_p->shaper_attr_filter.from_shaper_is_enable;
        reg.srt = profile_attr_p->shaper_attr_filter.to_shaper_is_enable;
    }
    if (profile_attr_p->mode == SX_AR_PROFILE_MODE_TIME_BOUND_E) {
        reg.time_bound_time = profile_attr_p->bind_time;
    }


    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __rarpr_regdata_write(&reg, SXD_DEV_ID_MIN);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to update RARPR register (rc=%d)\n", err);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_classification_set_common(const sx_access_cmd_t            cmd,
                                                      struct ku_rarpc_reg             *reg,
                                                      const sx_ar_classifier_type_e    classifier_type,
                                                      const sx_ar_classifier_id_e      classifier_id,
                                                      const sx_ar_classifier_action_t *classifier_action,
                                                      const sx_ar_classifier_attr_t   *attr_p)
{
    uint32_t         i = 0;
    sx_port_id_t     local_port = 0;
    sx_port_log_id_t log_port = 0;
    sx_status_t      err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (classifier_type == SX_AR_CLASSIFIER_TYPE_DEFAULT_E) {
        reg->pc_default = TRUE;
    } else {
        reg->pc_default = FALSE;
        reg->pc_entry = classifier_id;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        if (classifier_type == SX_AR_CLASSIFIER_TYPE_USER_DEFINED_E) {
            reg->inner_must = attr_p->key.is_tunnel_exist;

            if (attr_p->key.switch_priorities_cnt == 0) {
                reg->switch_prio = 0xFFFF;
            } else {
                for (i = 0; i < attr_p->key.switch_priorities_cnt; i++) {
                    reg->switch_prio |= 1 << attr_p->key.switch_priorities[i];
                }
            }

            if (attr_p->key.l3 == SX_AR_CLASSIFIER_L3_ANY_E) {
                reg->l3_type = 0xFF;
            } else {
                reg->l3_type = attr_p->key.l3;
            }

            if (attr_p->key.inner_l3 == SX_AR_CLASSIFIER_L3_ANY_E) {
                reg->inner_l3_type = 0xFF;
            } else {
                reg->inner_l3_type = attr_p->key.inner_l3;
            }

            if (attr_p->key.l4 == SX_AR_CLASSIFIER_L4_ANY_E) {
                reg->l4_type = 0xFF;
            } else {
                reg->l4_type = attr_p->key.l4;
            }

            if (attr_p->key.inner_l4 == SX_AR_CLASSIFIER_L4_ANY_E) {
                reg->inner_l4_type = 0xFF;
            } else {
                reg->inner_l4_type = attr_p->key.inner_l4;
            }

            if (attr_p->key.bth_ar == SX_AR_IN_BTH_HEADER_ANY_E) {
                reg->bth_ar = 0xF;
            } else {
                reg->bth_ar = attr_p->key.bth_ar;
            }

            if (attr_p->key.inner_bth_ar == SX_AR_IN_BTH_HEADER_ANY_E) {
                reg->inner_bth_ar = 0xF;
            } else {
                reg->inner_bth_ar = attr_p->key.inner_bth_ar;
            }

            if (attr_p->key.log_ports_cnt == 0) {
                for (i = 0; i < SXD_RARPC_INGRESS_PORT_NUM; i++) {
                    reg->ingress_port[i] = 0xFFFFFFFF;
                }
            } else {
                for (i = 0; i < attr_p->key.log_ports_cnt; i++) {
                    log_port = attr_p->key.log_ports[i];
                    local_port = SX_PORT_PHY_ID_GET(log_port);
                    SXD_BITMAP_REVERSE_SET(reg->ingress_port,
                                           SXD_RARPC_INGRESS_PORT_NUM,
                                           sizeof(reg->ingress_port[0]) * 8,
                                           local_port);
                }
            }

            if (attr_p->key.bth_opcodes.bth_opcode_4_0_cnt == 0) {
                reg->bth_opcode_lsb = 0xFFFFFFFF;
            } else {
                for (i = 0; i < attr_p->key.bth_opcodes.bth_opcode_4_0_cnt; i++) {
                    reg->bth_opcode_lsb |= (1 << attr_p->key.bth_opcodes.bth_opcode_4_0[i]);
                }
            }

            if (attr_p->key.bth_opcodes.bth_opcode_7_5_cnt == 0) {
                reg->bth_opcode_msb = 0xFF;
            } else {
                for (i = 0; i < attr_p->key.bth_opcodes.bth_opcode_7_5_cnt; i++) {
                    reg->bth_opcode_msb |= (1 << attr_p->key.bth_opcodes.bth_opcode_7_5[i]);
                }
            }

            if (attr_p->key.inner_bth_opcodes.bth_opcode_4_0_cnt == 0) {
                reg->inner_bth_opcode_lsb = 0xFFFFFFFF;
            } else {
                for (i = 0; i < attr_p->key.inner_bth_opcodes.bth_opcode_4_0_cnt; i++) {
                    reg->inner_bth_opcode_lsb |= (1 << attr_p->key.inner_bth_opcodes.bth_opcode_4_0[i]);
                }
            }

            if (attr_p->key.inner_bth_opcodes.bth_opcode_7_5_cnt == 0) {
                reg->inner_bth_opcode_msb = 0xFF;
            } else {
                for (i = 0; i < attr_p->key.inner_bth_opcodes.bth_opcode_7_5_cnt; i++) {
                    reg->inner_bth_opcode_msb |= (1 << attr_p->key.inner_bth_opcodes.bth_opcode_7_5[i]);
                }
            }

            for (i = 0; i < attr_p->key.port_ranges_cnt; i++) {
                reg->l4port_cmp[i].port_src = attr_p->key.port_ranges[i].port;
                reg->l4port_cmp[i].comp_field = attr_p->key.port_ranges[i].protocol;
                reg->l4port_cmp[i].port_range_min = attr_p->key.port_ranges[i].port_low;
                reg->l4port_cmp[i].port_range_max = attr_p->key.port_ranges[i].port_high;
            }
        }

        reg->ar_packet_prof_id = classifier_action->ar_flow_classification;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
    case SX_ACCESS_CMD_UNSET:
        err = __rarpc_regdata_write(reg);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to update RARPC register error: [%s])\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_classification_attr_validate_spc2(const sx_ar_classifier_attr_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (attr_p->key.port_ranges_mode != SX_AR_CLASSIFIER_L4_PORT_RANGE_INNER_OR_OUTER_E) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("AR port_ranges_mode: %u is not supported\n", attr_p->key.port_ranges_mode);
        goto out;
    }


out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __hwd_ar_classification_set_spc2(const sx_access_cmd_t            cmd,
                                                    const sx_ar_classifier_type_e    classifier_type,
                                                    const sx_ar_classifier_id_e      classifier_id,
                                                    const sx_ar_classifier_action_t *classifier_action,
                                                    const sx_ar_classifier_attr_t   *attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_rarpc_reg reg;

    SX_LOG_ENTER();
    SX_MEM_CLR(reg);

    err = __hwd_ar_classification_set_common(cmd, &reg, classifier_type, classifier_id, classifier_action, attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to update RARPC register error: [%s])\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_classification_set_spc4(const sx_access_cmd_t            cmd,
                                                    const sx_ar_classifier_type_e    classifier_type,
                                                    const sx_ar_classifier_id_e      classifier_id,
                                                    const sx_ar_classifier_action_t *classifier_action,
                                                    const sx_ar_classifier_attr_t   *attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_rarpc_reg reg;

    SX_LOG_ENTER();
    SX_MEM_CLR(reg);

    /*Supported from Spectrum-4*/
    if ((classifier_type != SX_AR_CLASSIFIER_TYPE_DEFAULT_E) && (cmd == SX_ACCESS_CMD_SET)) {
        reg.l4_inner = attr_p->key.port_ranges_mode;
    }

    err = __hwd_ar_classification_set_common(cmd, &reg, classifier_type, classifier_id, classifier_action, attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to update RARPC register error: [%s])\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_congestion_threshold_set_spc2(const sx_access_cmd_t                    cmd,
                                                          const sx_ar_congestion_threshold_attr_t *congestion_thresh)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_rarcl_reg reg;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg);

    reg.eport_cong_level0 = congestion_thresh->port_threshold.congestion_thresh_lo;
    reg.eport_cong_level1 = congestion_thresh->port_threshold.congestion_thresh_med;
    reg.eport_cong_level2 = congestion_thresh->port_threshold.congestion_thresh_hi;
    reg.tc_cong_level0 = AR_TRAFFIC_CLASS_CONGESTION_THRESHOLD_DEFAULT;
    reg.tc_cong_level1 = AR_TRAFFIC_CLASS_CONGESTION_THRESHOLD_DEFAULT;
    reg.tc_cong_level2 = AR_TRAFFIC_CLASS_CONGESTION_THRESHOLD_DEFAULT;

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __rarcl_regdata_write(&reg);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to update RARCL register (rc=%d)\n", err);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_link_utilization_threshold_set_spc2(const sx_access_cmd_t                cmd,
                                                                const sx_port_log_id_t               log_port,
                                                                const sx_ar_link_utilization_attr_t *link_util_attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_rarlu_reg reg;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg);

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port,
                                        reg.lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        reg.lut_en = SXD_RARLU_LUT_EN_ENABLE_E;
        reg.link_utilization_thr = link_util_attr_p->link_utilization_threshold;
        break;

    case SX_ACCESS_CMD_UNSET:
        reg.lut_en = SXD_RARLU_LUT_EN_DISABLE_E;
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = __rarlu_regdata_write(&reg);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to update RARLU register (rc=%d)\n", err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rarpr_regdata_write(struct ku_rarpr_reg *rarpr, sx_dev_id_t dev_id)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_LOG_ENTER();

    if ((utils_check_pointer(rarpr, "rarpr"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARPR_E, rarpr, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARPR to device %u: %s\n", dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __rarnpr_regdata_write(struct ku_rarnpr_reg *rarnpr, sx_dev_id_t dev_id)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_LOG_ENTER();

    if ((utils_check_pointer(rarnpr, "rarnpr"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARNPR_E, rarnpr, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARNPR to device %u: %s\n", dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rarcl_regdata_write(struct ku_rarcl_reg *rarcl)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    if ((utils_check_pointer(rarcl, "rarcl"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    SX_CHECK_RC_OUT_ERR(err, "Cannot retrieve device list.");

    SX_MEM_CLR(reg_meta);
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARCL_E, rarcl, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARCL to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rarpc_regdata_write(struct ku_rarpc_reg *rarpc)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    if ((utils_check_pointer(rarpc, "rarpc"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    SX_CHECK_RC_OUT_ERR(err, "Cannot retrieve device list.");

    SX_MEM_CLR(reg_meta);
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARPC_E, rarpc, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARPC to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rarsr_regdata_write(struct ku_rarsr_reg *rarsr)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    SX_CHECK_RC_OUT_ERR(err, "Cannot retrieve device list.");

    SX_MEM_CLR(reg_meta);
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARSR_E, rarsr, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARSR to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __rarlu_regdata_write(struct ku_rarlu_reg *rarlu)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    if ((utils_check_pointer(rarlu, "rarlu"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    SX_CHECK_RC_OUT_ERR(err, "Cannot retrieve device list.");

    SX_MEM_CLR(reg_meta);
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARLU_E, rarlu, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARLU to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rarcc_regdata_read(struct ku_rarcc_reg *rarcc, sx_dev_id_t dev_id)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_LOG_ENTER();

    if ((utils_check_pointer(rarcc, "rarcc"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARCC_E, rarcc, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get RARCC from device %u: %s\n", dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rarsr_regdata_read(struct ku_rarsr_reg *rarsr, sx_dev_id_t dev_id)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_LOG_ENTER();

    if ((utils_check_pointer(rarsr, "rarsr"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARSR_E, rarsr, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get RARSR from device %u: %s\n", dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rartm_regdata_write(struct ku_rartm_reg *rartm, sx_dev_id_t dev_id)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_MEM_CLR(reg_meta);
    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARTM_E, rartm, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARTM to device %u: %s\n", dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

out:
    return err;
}

static sx_status_t __hwd_ar_shaper_rate_set_spc2(const sx_access_cmd_t cmd, const sx_ar_shaper_attr_t *shaper_attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_rarsr_reg reg;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg);

    reg.ar_srf = shaper_attr_p->shaper_rate_from;
    reg.ar_srt = shaper_attr_p->shaper_rate_to;

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = __rarsr_regdata_write(&reg);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to update RARSR register (rc=%d)\n", err);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_shaper_rate_get_spc2(const sx_access_cmd_t cmd, sx_ar_shaper_attr_t *shaper_attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_rarsr_reg reg;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg);

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        err = __rarsr_regdata_read(&reg, SXD_DEV_ID_MIN);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to update RARSR register (rc=%d)\n", err);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    shaper_attr_p->shaper_rate_from = reg.ar_srf;
    shaper_attr_p->shaper_rate_to = reg.ar_srt;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_arn_port_counters_get_spc2(const sx_access_cmd_t   cmd,
                                                       const sx_port_log_id_t  log_port,
                                                       sx_arn_port_counters_t *port_counters_p)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    struct ku_rarnpc_reg reg;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg);

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        reg.clr_cnt = 1;
    }

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(reg.local_port,
                                        reg.lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));

    err = __rarnpc_regdata_read(&reg, SX_DEV_ID_MIN);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get RARNPC register (rc=%d)\n", err);
        goto out;
    }

    port_counters_p->arn_port_tx = reg.arn_transmit_cnt;

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __hwd_ar_counters_get_spc2(const sx_access_cmd_t cmd, sx_ar_global_counters_t *ar_counters_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_rarcc_reg reg;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg);

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        reg.clr = 1;
    }

    err = __rarcc_regdata_read(&reg, SX_DEV_ID_MIN);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get RARCC register (rc=%d)\n", err);
        goto out;
    }

    ar_counters_p->ar_congestion_changes = reg.ar_changes_congestion_high;
    ar_counters_p->ar_congestion_changes =
        (ar_counters_p->ar_congestion_changes << 32) | reg.ar_changes_congestion_low;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_arn_params_set_rarns(sx_arn_default_params_t *arn_default_params_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_rarns_reg rarns;


    SX_LOG_ENTER();

    SX_MEM_CLR(rarns);


    rarns.arn_gen_min_time = arn_default_params_p->gen_shaper_min_time;
    err = __rarns_regdata_write(&rarns);
    SX_CHECK_RC_OUT_ERR(err, "Failed to set RARNS register.");
out:
    SX_LOG_EXIT();
    return err;
}

/* This function can be called in 2 cases :
 *  1. From relocation callback. In this case the hw index is provided, and counter is locked
 *  2. During configuration as part of arn_set.  The counter index should be translated to hw index before calling the emad. This operation is done using lock/unlock .
 *  Unlock should be done after writing to register, to make sure that index is not changed by others
 *  Note that each counter will be relocated by a separate call to relocation call back.
 *  While one counter is relocated, other can be accessed with lock/unlock
 *  */

sx_status_t hwd_ar_arn_params_set_rarngc(sx_arn_default_params_t   *arn_default_params_p,
                                         sx_arn_general_params_t   *arn_general_params_p,
                                         sx_arn_counters_indices_t *arn_counters_indices_p,
                                         sx_arn_counter_type_e      relocation_counter_type,
                                         cm_hw_type_t               new_counter_hw_type,
                                         cm_index_t                 new_counter_hw_idx)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_status_t          unlock_err = SX_STATUS_SUCCESS;
    struct ku_rarngc_reg rarngc;
    cm_hw_type_t         counter_hw_type;
    cm_index_t           counter_hw_idx;
    boolean_t            drop_ip_miss_is_locked = FALSE;
    boolean_t            no_nexthop_is_locked = FALSE;

    SX_LOG_ENTER();
    SX_MEM_CLR(rarngc);

    rarngc.udp_dst_port = arn_default_params_p->udp_dest_port;
    rarngc.udp_src_port = arn_default_params_p->udp_src_port;
    rarngc.version = arn_default_params_p->arn_version;
    rarngc.prefix_match_type = (sxd_rarngc_prefix_match_type_t)arn_default_params_p->sip_prefix_match_type;
    rarngc.tr_en = arn_default_params_p->truncate;
    rarngc.truncation_size = arn_default_params_p->truncate_size;
    rarngc.switch_id = arn_general_params_p->switch_id;
    rarngc.arn_gen_th_grade = arn_general_params_p->grade_threshold;
    rarngc.ip_df = TRUE;

    /* if relocation operation is done, the hw index is provided */
    if (relocation_counter_type == SX_ARN_COUNTER_TYPE_DROP_IP_MISS) {
        rarngc.arn_bad_sip_cnt = new_counter_hw_idx;
        rarngc.bad_sip_cnt_type = new_counter_hw_type;
    } else {
        /* o/w - get hw index */
        err =
            flow_counter_lock(arn_counters_indices_p->gen_drop_ip_miss_index, NULL, &counter_hw_type, &counter_hw_idx);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to lock counter ID %u for ARN drop ip miss [%s]\n",
                       arn_counters_indices_p->gen_drop_ip_miss_index, sx_status_str(err));
            goto out;
        }
        drop_ip_miss_is_locked = TRUE;
        rarngc.arn_bad_sip_cnt = counter_hw_idx;
        rarngc.bad_sip_cnt_type = counter_hw_type;
    }

    /* if relocation operation is done, the hw index is provided */
    if (relocation_counter_type == SX_ARN_COUNTER_TYPE_NO_NEXTHOP) {
        rarngc.arn_ptr_not_vld_cnt = new_counter_hw_idx;
        rarngc.not_vld_set_type = new_counter_hw_type;
    } else {
        /* o/w - get hw index */
        err = flow_counter_lock(arn_counters_indices_p->gen_drop_no_nexthop_index,
                                NULL,
                                &counter_hw_type,
                                &counter_hw_idx);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to lock counter ID %u for ARN drop no next hop [%s]\n",
                       arn_counters_indices_p->gen_drop_no_nexthop_index, sx_status_str(err));
            goto out;
        }
        no_nexthop_is_locked = TRUE;
        rarngc.arn_ptr_not_vld_cnt = counter_hw_idx;
        rarngc.not_vld_set_type = counter_hw_type;
    }

    err = __rarngc_regdata_write(&rarngc);
    SX_CHECK_RC_OUT_ERR(err, "Failed to set RARNGC register.");
out:
    /* Release the locked counters. Use unlock_err because we don't want SUCCESS in unlock to overwrite the err status.*/
    if (drop_ip_miss_is_locked) {
        unlock_err = flow_counter_unlock(arn_counters_indices_p->gen_drop_ip_miss_index);
        if (unlock_err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to unlock counter ID %u [%s]\n",
                       flow_counter_unlock(arn_counters_indices_p->gen_drop_ip_miss_index), sx_status_str(unlock_err));
        }
    }

    if (no_nexthop_is_locked) {
        unlock_err = flow_counter_unlock(arn_counters_indices_p->gen_drop_no_nexthop_index);
        if (unlock_err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to unlock counter ID %u for ARN drop no next hop[%s]\n",
                       flow_counter_unlock(arn_counters_indices_p->gen_drop_no_nexthop_index),
                       sx_status_str(unlock_err));
        }
    }

    if (err == SX_STATUS_SUCCESS) {
        err = unlock_err;
    }

    SX_LOG_EXIT();
    return err;
}


/* This function can be called in 2 cases :
 *  1. From relocation callback. In this case the hw index is provided, counter is locked
 *  2. During configuration as part of arn_set.  The counter index should be translated to hw index before calling the emad. This operation is done using lock/unlock .
 *  Unlock should be done after writing to register, to make sure that index is not changed by others
 *  Note that each counter will be relocated by a separate call to relocation call back.
 *  While one counter is relocated, other can be accessed with lock/unlock
 */

sx_status_t hwd_ar_arn_params_set_rarncg(sx_arn_default_params_t   *arn_default_params_p,
                                         sx_arn_counters_indices_t *arn_counters_indices_p,
                                         sx_arn_counter_type_e      relocation_counter_type,
                                         cm_hw_type_t               new_counter_hw_type,
                                         cm_index_t                 new_counter_hw_idx)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_status_t          unlock_err = SX_STATUS_SUCCESS;
    struct ku_rarncg_reg rarncg;
    boolean_t            arn_rcv_drop_is_locked = FALSE;
    boolean_t            arn_rcv_ok_is_locked = FALSE;
    cm_hw_type_t         counter_hw_type;
    cm_index_t           counter_hw_idx;

    /* if relocation operation is done, the hw index is provided */
    if (relocation_counter_type == SX_ARN_COUNTER_TYPE_RCV_DROP) {
        rarncg.arn_rcv_bad_cnt = new_counter_hw_idx;
        rarncg.rcv_bad_cnt_type = new_counter_hw_type;
        /* o/w - get hw index */
    } else {
        err = flow_counter_lock(arn_counters_indices_p->arn_rcv_drop_index, NULL, &counter_hw_type, &counter_hw_idx);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to lock counter ID %u for ARN receive drop [%s]\n",
                       arn_counters_indices_p->arn_rcv_drop_index, sx_status_str(err));
            goto out;
        }
        arn_rcv_drop_is_locked = TRUE;

        rarncg.arn_rcv_bad_cnt = counter_hw_idx;
        rarncg.rcv_bad_cnt_type = counter_hw_type;
    }

    /* if relocation operation is done, the hw index is provided */
    if (relocation_counter_type == SX_ARN_COUNTER_TYPE_RCV_OK) {
        rarncg.arn_rcv_ok_cnt = new_counter_hw_idx;
        rarncg.rcv_ok_cnt_type = new_counter_hw_type;
        /* o/w - get hw index */
    } else {
        err = flow_counter_lock(arn_counters_indices_p->arn_rcv_ok_index, NULL, &counter_hw_type, &counter_hw_idx);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to lock counter ID %u for ARN receive OK[%s]\n",
                       arn_counters_indices_p->arn_rcv_ok_index, sx_status_str(err));
            goto out;
        }
        arn_rcv_ok_is_locked = TRUE;
        rarncg.arn_rcv_ok_cnt = counter_hw_idx;
        rarncg.rcv_ok_cnt_type = counter_hw_type;
    }
    rarncg.arn_udp_dport = arn_default_params_p->udp_dest_port;

    err = __rarncg_regdata_write(&rarncg);
    SX_CHECK_RC_OUT_ERR(err, "Failed to set RARNCG register.");

out:
    /* Release the locks on counters. Use unlock_err because we don't want SUCCESS in unlock to overwrite the err status.*/
    if (arn_rcv_drop_is_locked) {
        unlock_err = flow_counter_unlock(arn_counters_indices_p->arn_rcv_drop_index);
        if (unlock_err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to unlock counter ID %u [%s]\n",
                       flow_counter_unlock(arn_counters_indices_p->arn_rcv_drop_index), sx_status_str(unlock_err));
        }
    }

    if (arn_rcv_ok_is_locked) {
        unlock_err = flow_counter_unlock(arn_counters_indices_p->arn_rcv_ok_index);
        if (unlock_err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to unlock counter ID %u [%s]\n",
                       flow_counter_unlock(arn_counters_indices_p->arn_rcv_ok_index), sx_status_str(unlock_err));
        }
    }

    if (err == SX_STATUS_SUCCESS) {
        err = unlock_err;
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_arn_params_set_spc2(sx_arn_default_params_t   *arn_default_params_p,
                                                sx_arn_general_params_t   *arn_general_params_p,
                                                sx_arn_counters_indices_t *arn_counters_indices_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;


    SX_LOG_ENTER();

    err = __hwd_ar_arn_params_set_rarns(arn_default_params_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to updated the RARNS related params: [%s]\n",
                   sx_status_str(err));
        goto out;
    }


    /*translate counter id to hw counter id */
    err = hwd_ar_arn_params_set_rarngc(arn_default_params_p,
                                       arn_general_params_p,
                                       arn_counters_indices_p,
                                       0x0, 0, 0);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to updated the RARNGC related params: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    err = hwd_ar_arn_params_set_rarncg(arn_default_params_p,
                                       arn_counters_indices_p,
                                       0, 0, 0);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to updated the RARNCG related params: [%s]\n",
                   sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rarngc_regdata_write(struct ku_rarngc_reg *rarngc)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    SX_CHECK_RC_OUT_ERR(err, "Cannot retrieve device list.");

    SX_MEM_CLR(reg_meta);
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARNGC_E, rarngc, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARNGC to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __rarns_regdata_write(struct ku_rarns_reg *rarns)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    SX_CHECK_RC_OUT_ERR(err, "Cannot retrieve device list.");

    SX_MEM_CLR(reg_meta);
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARNS_E, rarns, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARNS to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rarnpc_regdata_read(struct ku_rarnpc_reg *rarnpc, sx_dev_id_t dev_id)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;


    SX_LOG_ENTER();


    SX_MEM_CLR(reg_meta);


    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARNPC_E, rarnpc, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get RARNPC from device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }


out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __rarnpc_regdata_write(struct ku_rarnpc_reg *rarnpc)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    SX_CHECK_RC_OUT_ERR(err, "Cannot retrieve device list.");

    SX_MEM_CLR(reg_meta);
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARNPC_E, rarnpc, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARNPC to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __rarncp_regdata_write(struct ku_rarncp_reg *rarncp)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    SX_CHECK_RC_OUT_ERR(err, "Cannot retrieve device list.");

    SX_MEM_CLR(reg_meta);
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARNCP_E, rarncp, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARNCP to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __hwd_ar_arn_router_gen_set_spc2(const sx_access_cmd_t             cmd,
                                                    const sx_arn_router_key_t        *router_key_p,
                                                    const sx_arn_router_attributes_t *router_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(cmd);
    UNUSED_PARAM(router_key_p);
    UNUSED_PARAM(router_attr_p);

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_arn_port_params_set_spc2(const sx_access_cmd_t             cmd,
                                                     const sx_port_log_id_t            log_port,
                                                     const sx_mac_addr_t               mac_addr,
                                                     const hwd_ar_arn_port_conf_type_e config_type)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    struct ku_rarnpc_reg rarnpc;
    struct ku_rarncp_reg rarncp;

    SX_LOG_ENTER();

    SX_MEM_CLR(rarnpc);
    SX_MEM_CLR(rarncp);

    if ((config_type == HWD_ARN_PORT_CONF_TYPE_GENERATION_E) || (config_type == HWD_ARN_PORT_CONF_TYPE_BOTH_E)) {
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(rarnpc.local_port,
                                            rarnpc.lp_msb,
                                            SX_PORT_PHY_ID_GET(log_port));

        switch (cmd) {
        case SX_ACCESS_CMD_SET:
            rarnpc.egress_en = TRUE;
            rarnpc.shaper_en = TRUE;

        /* fallthrough*/
        case SX_ACCESS_CMD_UNSET:
            rarnpc.ingress_en = TRUE;
            break;

        default:
            SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
            err = SX_STATUS_CMD_UNSUPPORTED;
            goto out;
        }

        err = __rarnpc_regdata_write(&rarnpc);
        SX_CHECK_RC_OUT_ERR(err, "Failed to set RARNPC register.");
    }

    if ((config_type == HWD_ARN_PORT_CONF_TYPE_CONSUMPTION_E) || (config_type == HWD_ARN_PORT_CONF_TYPE_BOTH_E)) {
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(rarncp.local_port,
                                            rarncp.lp_msb,
                                            SX_PORT_PHY_ID_GET(log_port));

        switch (cmd) {
        case SX_ACCESS_CMD_SET:
            rarncp.arn_en = TRUE;
            rarncp.arn_dmac_en = TRUE;
            SX_MEM_CPY_ARRAY(&rarncp.arn_dmac_47_32, mac_addr.ether_addr_octet, 2, uint8_t);
            SX_MEM_CPY_ARRAY(&rarncp.arn_dmac_31_0, mac_addr.ether_addr_octet + 2, 4, uint8_t);
            rarncp.arn_dmac_47_32 = cl_hton16(rarncp.arn_dmac_47_32);
            rarncp.arn_dmac_31_0 = cl_hton32(rarncp.arn_dmac_31_0);
            break;

        case SX_ACCESS_CMD_UNSET:
            break;

        default:
            SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
            err = SX_STATUS_CMD_UNSUPPORTED;
            goto out;
        }

        err = __rarncp_regdata_write(&rarncp);
        SX_CHECK_RC_OUT_ERR(err, "Failed to set RARNCP register.");
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rarncg_regdata_write(struct ku_rarncg_reg *rarncg)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sxd_status_t   sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    SX_CHECK_RC_OUT_ERR(err, "Cannot retrieve device list.");

    SX_MEM_CLR(reg_meta);
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARNCG_E, rarncg, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to write RARNCG to device %u: %s\n", reg_meta.dev_id, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwd_ar_arn_system_port_param_set_spc2(const sx_access_cmd_t cmd, const sx_port_log_id_t log_port)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    struct ku_rarnpc_reg rarnpc;

    SX_LOG_ENTER();

    SX_MEM_CLR(rarnpc);

    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(rarnpc.local_port,
                                        rarnpc.lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));
    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        rarnpc.ingress_en = TRUE;
        break;

    case SX_ACCESS_CMD_UNSET:
        rarnpc.ingress_en = FALSE;
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = __rarnpc_regdata_write(&rarnpc);
    SX_CHECK_RC_OUT_ERR(err, "Failed to set RARNPC register.");

out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __hwd_arn_counter_relocate_cb(const cm_logical_id_t lid,
                                                 const uint32_t        offset,
                                                 const cm_type_e       type,
                                                 const cm_hw_type_t    hw_type,
                                                 const cm_index_t      old_index,
                                                 const cm_index_t      new_index)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_flow_counter_id_t      counter_id = LID_OFFSET_TO_FLOW_CNTR_ID(lid, offset);
    sx_arn_counters_indices_t counters_indices;
    sx_arn_default_params_t   arn_default_params;
    sx_arn_general_params_t   arn_general_params;
    sx_arn_counter_type_e     update_counter_index = SX_ARN_COUNTER_TYPE_INVALID;


    SX_LOG_ENTER();

    UNUSED_PARAM(offset);
    UNUSED_PARAM(type);
    UNUSED_PARAM(old_index);

    SX_LOG(SX_LOG_DEBUG, "Relocate ARN counter with lid: %u from index: %u to index: %u.\n",
           lid, old_index, new_index);


    SX_MEM_CLR(counters_indices);
    SX_MEM_CLR(arn_default_params);

    err = sdk_ar_db_arn_counters_indices_get(&counters_indices);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN counters indices");


    if (counter_id == counters_indices.gen_drop_ip_miss_index) {
        update_counter_index = SX_ARN_COUNTER_TYPE_DROP_IP_MISS;
    } else if (counter_id == counters_indices.gen_drop_no_nexthop_index) {
        update_counter_index = SX_ARN_COUNTER_TYPE_NO_NEXTHOP;
    } else if (counter_id == counters_indices.arn_rcv_drop_index) {
        update_counter_index = SX_ARN_COUNTER_TYPE_RCV_DROP;
    } else if (counter_id == counters_indices.arn_rcv_ok_index) {
        update_counter_index = SX_ARN_COUNTER_TYPE_RCV_OK;
    } else {
        /*(counter_id == SX_ARN_COUNTER_TYPE_INVALID) */
        SX_LOG(SX_LOG_DEBUG, "No need to relocate  any ARN counter.\n");
        goto out;
    }

    err = sdk_ar_db_arn_default_params_get(&arn_default_params);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN default params");

    err = sdk_ar_db_arn_general_params_get(&arn_general_params);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN general params");

    if ((update_counter_index == SX_ARN_COUNTER_TYPE_DROP_IP_MISS) ||
        (update_counter_index == SX_ARN_COUNTER_TYPE_NO_NEXTHOP)) {
        err = hwd_ar_arn_params_set_rarngc(&arn_default_params,
                                           &arn_general_params,
                                           &counters_indices,
                                           update_counter_index, hw_type, new_index);
        SX_CHECK_RC_OUT_ERR(err, "Failed to relocate ip miss/ no next hop counters");
    }

    if ((update_counter_index == SX_ARN_COUNTER_TYPE_RCV_OK) ||
        (update_counter_index == SX_ARN_COUNTER_TYPE_RCV_DROP)) {
        err = hwd_ar_arn_params_set_rarncg(&arn_default_params,
                                           &counters_indices,
                                           update_counter_index, hw_type, new_index);
        SX_CHECK_RC_OUT_ERR(err, "Failed to relocate rcv ok/ drop counters");
    }


out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __rarftbr_data_read(sx_arn_flow_entry_status_t *flow_status_list_p,
                                       uint32_t                    arft_index,
                                       uint16_t                    num_rec,
                                       uint16_t                   *actual_rec_p,
                                       sx_dev_id_t                 dev_id)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sxd_status_t           sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t         reg_meta;
    struct ku_rarftbr_reg *rarftbr_p = NULL;
    sx_port_phy_id_t       phy_port_id = 0;
    uint16_t               i = 0;


    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);

    rarftbr_p = cl_malloc(
        sizeof(struct ku_rarftbr_reg) + sizeof(sxd_rarftbr_flow_table_records_t) * num_rec);
    if (rarftbr_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for RARFTBR register.\n");
        err = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    SX_MEM_CLR_P(rarftbr_p);


    rarftbr_p->arft_index = arft_index;
    rarftbr_p->num_rec = num_rec;

    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RARFTBR_E,
                                                     rarftbr_p,
                                                     &reg_meta,
                                                     1,
                                                     NULL,
                                                     NULL);

    if (sxd_status != SXD_STATUS_SUCCESS) {
        err = sxd_status_to_sx_status(sxd_status);
        SX_LOG_ERR("Failed RARFTBR call: arft index [%u] err [%s]", arft_index, sx_status_str(err));
        goto out;
    }
    SX_LOG_INF("Successful RARFTBR call: arft index [%u] ", arft_index);

    *actual_rec_p = rarftbr_p->num_rec;
    for (i = 0; i < *actual_rec_p; i++) {
        flow_status_list_p[i].current_arn_state = (sx_arn_state_e)rarftbr_p->flow_table_records[i].arn_state;
        flow_status_list_p[i].profile_id = (sx_ar_profile_handle_e)rarftbr_p->flow_table_records[i].ar_prof_id;
        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(phy_port_id, rarftbr_p->flow_table_records[i].local_port,
                                          rarftbr_p->flow_table_records[i].lp_msb);
        SX_PORT_DEV_ID_SET(flow_status_list_p[i].current_egress_log_port, dev_id);
        SX_PORT_TYPE_ID_SET(flow_status_list_p[i].current_egress_log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_PHY_ID_SET(flow_status_list_p[i].current_egress_log_port, phy_port_id);
    }
out:
    if (rarftbr_p != NULL) {
        cl_free(rarftbr_p);
    }
    SX_LOG_EXIT();
    return err;
}


sx_status_t hwd_ar_flow_table_read(sx_arn_flow_entry_status_t *flow_status_list_p,
                                   uint32_t                    arft_index,
                                   uint16_t                    total_records,
                                   uint16_t                   *actual_total_records_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint16_t    total_read = 0;
    uint16_t    records_to_read = 0;
    uint16_t    actual_records = 0;

    SX_LOG_ENTER();


    while (total_read < total_records) {
        if ((total_records - total_read) > rm_resource_global.arft_num_rec_max) {
            records_to_read = rm_resource_global.arft_num_rec_max;
        } else {
            records_to_read = total_records - total_read;
        }


        err = __rarftbr_data_read(&flow_status_list_p[total_read], arft_index,
                                  records_to_read, &actual_records, SXD_DEV_ID_MIN);

        /* Check for errors in the read operation */
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to read RARFTBR . ARFT index [%u].\n",
                       arft_index);
            goto out;
        }

        if (actual_records < records_to_read) {
            SX_LOG_INF("Read less entries than requested . ARFT index [%u].\n",
                       arft_index);
            *actual_total_records_p = total_read + actual_records;
            goto out;
        }

        total_read += records_to_read;  /* Update the total number of records read */
        arft_index += records_to_read;  /* Increment the starting index for the next read */
    }

    *actual_total_records_p = total_read;

out:
    SX_LOG_EXIT();
    return err;
}
/*
 * Generate TC -> AR TC mapping:
 * Up to maximum number of AR TCs, mapping is 1:1.
 * Rest of AR TCs are disabled.
 */
static void __hwd_ar_tc_mapping_init(cos_ar_tc_mapping_t *mapping_p)
{
    sx_cos_traffic_class_t tc = 0;

    for (tc = 0; tc < rm_resource_global.adaptive_routing_tclass_max; tc++) {
        mapping_p[tc].ar_tc = tc;
        mapping_p[tc].is_disabled = 0;
    }

    for (; tc < RM_API_COS_TRAFFIC_CLASS_NUM; tc++) {
        mapping_p[tc].ar_tc = 0;
        mapping_p[tc].is_disabled = 1;
    }
}

static sx_status_t __hwd_ar_tc_mapping_init_spc2(cos_ar_tc_mapping_t *mapping_p)
{
    __hwd_ar_tc_mapping_init(mapping_p);
    return SX_STATUS_SUCCESS;
}

static sx_status_t __hwd_ar_tc_mapping_init_spc5(cos_ar_tc_mapping_t *mapping_p)
{
    uint8_t             tc;
    struct ku_rartm_reg rartm;

    SX_MEM_CLR(rartm);

    __hwd_ar_tc_mapping_init(mapping_p);

    for (tc = 0; tc < SXD_RARTM_MAPPING_NUM; tc++) {
        rartm.mapping[tc].ar_tclass = mapping_p[tc].ar_tc;
        rartm.mapping[tc].en = mapping_p[tc].is_disabled ? 0 : 1;
    }

    return __rartm_regdata_write(&rartm, SXD_DEV_ID_MIN);
}
