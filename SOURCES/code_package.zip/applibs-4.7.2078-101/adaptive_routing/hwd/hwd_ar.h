/*
 * SPDX-FileCopyrightText: Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef HWD_AR_H_
#define HWD_AR_H_

#include "sx/sdk/sx_ar.h"
#include "adaptive_routing/hwi/hwi_ar_impl.h"
#include "counters/counter_manager/counter_manager.h"

/************************************************
 *  Defines
 ***********************************************/
#define NUM_AR_PROFILES 2

/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t hwd_ar_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t hwd_ar_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);
void hwd_router_ar_set_impl_ops_spc2();
void hwd_router_ar_set_impl_ops_spc4();
void hwd_router_ar_set_impl_ops_spc5();
sx_status_t hwd_ar_arn_params_set_rarngc(sx_arn_default_params_t   *arn_default_params_p,
                                         sx_arn_general_params_t   *arn_general_params_p,
                                         sx_arn_counters_indices_t *arn_counters_indices_p,
                                         sx_arn_counter_type_e      relocation,
                                         cm_hw_type_t               new_counter_hw_type,
                                         cm_index_t                 new_counter_hw_idx);

sx_status_t hwd_ar_arn_params_set_rarncg(sx_arn_default_params_t   *arn_default_params_p,
                                         sx_arn_counters_indices_t *arn_counters_indices_p,
                                         sx_arn_counter_type_e      relocation,
                                         cm_hw_type_t               new_counter_hw_type,
                                         cm_index_t                 new_counter_hw_idx);

sx_status_t hwd_ar_flow_table_read(sx_arn_flow_entry_status_t *flow_status_list_p,
                                   uint32_t arft_index, uint16_t total_records, uint16_t *actual_total_records_p);
#endif /* HWD_AR_H_ */
