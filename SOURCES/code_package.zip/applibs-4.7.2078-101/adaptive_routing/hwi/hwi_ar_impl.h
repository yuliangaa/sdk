/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __SDK_AR_IMPL_H__
#define __SDK_AR_IMPL_H__

#include "sx/sdk/sx_status.h"
#include "sx/sdk/sx_ar.h"
#include "utils/sx_mem.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "complib/sx_log.h"
#include "hwi_ar_db.h"
#include "ethl2/cos.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "counters/counter_manager/counter_manager.h"

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/
#define SPECTRUM2_AR_NUM_PROFILES       2
#define SPECTRUM2_AR_DEFAULT_CLASSIFIER 255

#define AR_GRADE_MIN 0
#define AR_GRADE_MAX 4

#define AR_BIND_TIME_MIN 5
#define AR_BIND_TIME_MAX 1000

#define AR_CLASSIFIER_L3_MAX 0XF /* Maximum possible value when all l3 type bits are enabled */
#define AR_CLASSIFIER_L4_MAX 0XF /* Maximum possible value when all l4 type bits are enabled */

#define ARN_PROFILE_HOLD_TIME_MIN (12)
#define ARN_PROFILE_HOLD_TIME_MAX (255)

#define ARN_PROFILE_AGING_TIME_MIN (12)
#define ARN_PROFILE_AGING_TIME_MAX (255)

#define ARN_PROFILE_PANELTY_MIN (0)
#define ARN_PROFILE_PANELTY_MAX (4)


typedef enum sx_arn_counter_type {
    SX_ARN_COUNTER_TYPE_INVALID,
    SX_ARN_COUNTER_TYPE_DROP_IP_MISS,
    SX_ARN_COUNTER_TYPE_NO_NEXTHOP,
    SX_ARN_COUNTER_TYPE_RCV_DROP,
    SX_ARN_COUNTER_TYPE_RCV_OK,
} sx_arn_counter_type_e;
/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

typedef enum hwd_arn_port_conf_type {
    HWD_ARN_PORT_CONF_TYPE_CONSUMPTION_E,
    HWD_ARN_PORT_CONF_TYPE_GENERATION_E,
    HWD_ARN_PORT_CONF_TYPE_BOTH_E,
} hwd_ar_arn_port_conf_type_e;

/* function pointers for HWD APIs */
typedef struct hwd_ar_ops {
    sx_status_t (*hwd_ar_profile_set_pfn)(const sx_access_cmd_t       cmd,
                                          const sx_ar_profile_key_t  *profile_key_p,
                                          const sx_ar_profile_attr_t *profile_attr_p);
    sx_status_t (*hwd_ar_classification_set_pfn)(const sx_access_cmd_t            cmd,
                                                 const sx_ar_classifier_type_e    classifier_type,
                                                 const sx_ar_classifier_id_e      classifier_id,
                                                 const sx_ar_classifier_action_t *classifier_action,
                                                 const sx_ar_classifier_attr_t   *attr_p);
    sx_status_t (*hwd_ar_congestion_threshold_set_pfn)(const sx_access_cmd_t                    cmd,
                                                       const sx_ar_congestion_threshold_attr_t *congestion_thresh);
    sx_status_t (*hwd_ar_shaper_rate_set_pfn)(const sx_access_cmd_t      cmd,
                                              const sx_ar_shaper_attr_t *shaper_attr_p);
    sx_status_t (*hwd_ar_shaper_rate_get_pfn)(const sx_access_cmd_t cmd,
                                              sx_ar_shaper_attr_t  *shaper_attr_p);
    sx_status_t (*hwd_ar_link_utilization_threshold_set_pfn)(const sx_access_cmd_t                cmd,
                                                             const sx_port_log_id_t               log_port,
                                                             const sx_ar_link_utilization_attr_t *link_util_attr_p);
    sx_status_t (*hwd_ar_counters_get_pfn)(const sx_access_cmd_t    cmd,
                                           sx_ar_global_counters_t *ar_counters_p);

    sx_status_t (*hwd_ar_classification_attr_validate_pfn)(const sx_ar_classifier_attr_t *attr_p);
    sx_status_t (*hwd_arn_params_set_pfn)(sx_arn_default_params_t   *arn_default_params_p,
                                          sx_arn_general_params_t   *arn_general_params_p,
                                          sx_arn_counters_indices_t *arn_counters_indices_p);
    sx_status_t (*hwd_arn_router_gen_set_pfn)(const sx_access_cmd_t             cmd,
                                              const sx_arn_router_key_t        *router_key_p,
                                              const sx_arn_router_attributes_t *router_attr_p);
    sx_status_t (*hwd_arn_ar_port_params_set_pfn)(const sx_access_cmd_t             cmd,
                                                  const sx_port_log_id_t            log_port,
                                                  const sx_mac_addr_t               mac_addr,
                                                  const hwd_ar_arn_port_conf_type_e config_type);
    sx_status_t (*hwd_arn_profile_set_pfn)(const sx_access_cmd_t        cmd,
                                           const sx_ar_profile_key_t   *profile_key_p,
                                           const sx_arn_profile_attr_t *profile_attr_p);
    sx_status_t (*hwd_arn_port_counters_get_pfn)(const sx_access_cmd_t   cmd,
                                                 const sx_port_log_id_t  log_port,
                                                 sx_arn_port_counters_t *port_counters_p);
    sx_status_t (*hwd_arn_system_port_param_set_pfn)(const sx_access_cmd_t  cmd,
                                                     const sx_port_log_id_t log_port);
    sx_status_t (*hwd_arn_counter_relocate_pfn)(const cm_logical_id_t lid,
                                                const uint32_t        offset,
                                                const cm_type_e       type,
                                                const cm_hw_type_t    hw_type,
                                                const cm_index_t      old_index,
                                                const cm_index_t      new_index);
    sx_status_t (*hwd_ar_tc_mapping_init_pfn)(cos_ar_tc_mapping_t *mapping_p);
} hwd_ar_ops_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t sdk_ar_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t sdk_ar_init(const sx_ar_init_params_t *init_params_p);
sx_status_t sdk_ar_deinit(boolean_t is_forced);
sx_status_t sdk_ar_impl_arn_init();
sx_status_t sdk_ar_impl_arn_deinit();
boolean_t sdk_ar_impl_is_module_initialized(void);
boolean_t sdk_arn_impl_is_module_initialized(void);
boolean_t sdk_arn_impl_is_arn_generation_enabled(sx_router_id_t vrid);
sx_status_t sdk_ar_init_ops_spc2(void);
sx_status_t sdk_ar_init_ops_spc4(void);
sx_status_t sdk_ar_init_ops_spc5(void);
sx_status_t sdk_ar_impl_profile_set(const sx_access_cmd_t       cmd,
                                    const sx_ar_profile_key_t  *profile_key_p,
                                    const sx_ar_profile_attr_t *profile_attr_p);
sx_status_t sdk_ar_impl_arn_profile_set(const sx_access_cmd_t        cmd,
                                        const sx_ar_profile_key_t   *profile_key_p,
                                        const sx_arn_profile_attr_t *profile_attr_p);
sx_status_t sdk_ar_impl_profile_get(const sx_ar_profile_key_t *profile_key_p,
                                    sx_ar_profile_attr_t      *profile_attr_p);
sx_status_t sdk_ar_impl_arn_profile_get(const sx_ar_profile_key_t *profile_key_p,
                                        sx_arn_profile_attr_t     *profile_attr_p);
sx_status_t sdk_ar_impl_default_classification_get(sx_ar_classifier_action_t *classifier_action_p);
sx_status_t sdk_ar_impl_default_classification_set(const sx_access_cmd_t            cmd,
                                                   const sx_ar_classifier_action_t *classifier_action_p);
sx_status_t sdk_ar_impl_congestion_threshold_set(const sx_access_cmd_t                    cmd,
                                                 const sx_ar_congestion_threshold_attr_t *congestion_thresh);
sx_status_t sdk_ar_impl_congestion_threshold_get(sx_ar_congestion_threshold_attr_t *congestion_thresh);
sx_status_t sdk_ar_impl_classification_set(const sx_access_cmd_t            cmd,
                                           const sx_ar_classifier_id_e      classifier_id,
                                           const sx_ar_classifier_attr_t   *attr_p,
                                           const sx_ar_classifier_action_t *action_p);
sx_status_t sdk_ar_impl_classification_get(const sx_ar_classifier_id_e classifier_id,
                                           sx_ar_classifier_attr_t    *attr_p,
                                           sx_ar_classifier_action_t  *action_p);
sx_status_t sdk_ar_impl_shaper_rate_set(const sx_access_cmd_t      cmd,
                                        const sx_ar_shaper_attr_t *shaper_attr_p);
sx_status_t sdk_ar_impl_shaper_rate_get(sx_ar_shaper_attr_t *shaper_attr_p);
sx_status_t sdk_ar_impl_link_utilization_threshold_set(const sx_access_cmd_t                cmd,
                                                       const sx_port_log_id_t               log_port,
                                                       const sx_ar_link_utilization_attr_t *link_util_attr_p);
sx_status_t sdk_ar_impl_link_utilization_threshold_get(const sx_port_log_id_t         log_port,
                                                       sx_ar_link_utilization_attr_t *link_util_attr_p);
sx_status_t sdk_ar_impl_counters_get(const sx_access_cmd_t    cmd,
                                     sx_ar_global_counters_t *ar_counters_p);
sx_status_t sdk_ar_impl_arn_counters_get(const sx_access_cmd_t cmd,
                                         sx_arn_counters_t    *arn_counters);
sx_status_t sdk_ar_impl_arn_port_counters_get(const sx_access_cmd_t   cmd,
                                              const sx_port_log_id_t  log_port,
                                              sx_arn_port_counters_t *port_counters_p);
sx_status_t sdk_ar_impl_arn_flow_status_get(sx_arn_flow_status_key_t  *flow_status_key_p,
                                            sx_arn_flow_status_data_t *flow_status_data_p);
void sdk_ar_impl_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
sx_status_t sdk_ar_impl_port_buffer_mode_get(sx_ar_buffer_mode_e *port_buffer_mode_p);
sx_status_t sdk_ar_impl_arn_general_params_get(sx_arn_general_params_t *arn_general_params_p);
sx_status_t sdk_ar_impl_arn_router_attr_get(sx_arn_router_key_t        *arn_router_key_p,
                                            sx_arn_router_attributes_t *arn_router_attributes_p);
sx_status_t sdk_ar_impl_arn_defaults_set(const sx_access_cmd_t          cmd,
                                         const sx_arn_default_params_t *default_params_p);
sx_status_t sdk_ar_impl_arn_params_hwd_set(void);
sx_status_t sdk_ar_impl_issu_end(void);
sx_status_t sdk_ar_impl_arn_defaults_get(sx_arn_default_params_t *default_params_p);
sx_status_t sdk_ar_impl_arn_ar_port_consume_params_set(const sx_access_cmd_t  cmd,
                                                       const sx_port_log_id_t log_port,
                                                       const sx_mac_addr_t    mac_addr);
sx_status_t sdk_ar_impl_arn_ar_port_gen_params_set(const sx_access_cmd_t  cmd,
                                                   const sx_port_log_id_t log_port);
/*
 * This function sets \ unsets ARN generation mechanism on a given VRID.
 * This operation can be done only when no UC routes are configured on the given VRID.
 * ARN generation configuration is consisted from:
 * 1. AR RIF's port configuration (ARN generation enable and shaper enable) - done during ARN module set API
 * 2. ARN list per ECMP.
 *
 * ARN list will be created only when a first route is being set on this VRID.
 * Therefore, during set flow only ARN DB will be configured.
 *
 * During unset flow, there are no UC routes configured on the given VRID.
 * Therefore no ARN list configuration exists.
 */
sx_status_t sdk_ar_impl_arn_router_gen_set(const sx_access_cmd_t             cmd,
                                           const sx_arn_router_key_t        *router_key_p,
                                           const sx_arn_router_attributes_t *router_attr_p);
sx_status_t sdk_ar_impl_arn_router_gen_get(const sx_arn_router_key_t  *router_key_p,
                                           sx_arn_router_attributes_t *router_attr_p);
sx_status_t sdk_ar_impl_arn_get(sx_arn_general_params_t *general_params_p);
sx_status_t sdk_ar_impl_arn_set(const sx_access_cmd_t          cmd,
                                const sx_arn_general_params_t *general_params_p);
#endif /* __SDK_AR_IMPL_H__ */
