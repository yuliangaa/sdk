/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#ifndef __SDK_AR_DB_H__
#define __SDK_AR_DB_H__

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "sx/utils/sdk_refcount.h"

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/
/**
 * ARN counters indices.
 */
typedef struct sx_arn_db_counters_indices {
    sx_flow_counter_id_t gen_drop_no_nexthop_index; /**< Number of ARN packets that were dropped because of lack of the next hops to send ARN. */
    sx_flow_counter_id_t gen_drop_ip_miss_index;    /**< Number of ARN packets that were dropped because of IP address lookup failure. */
    sx_flow_counter_id_t arn_rcv_ok_index;          /**< Number of ARN packets that were received and processed. */
    sx_flow_counter_id_t arn_rcv_drop_index;        /**< Number of ARN packets that were received and not processed. Possible reasons: packet was dropped, routing failed, route doesn't enable AR, ARN consumption disabled. */
} sx_arn_counters_indices_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t sdk_ar_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t sdk_ar_db_init();
sx_status_t sdk_ar_db_profile_get(const sx_ar_profile_key_t *profile_key_p,
                                  sx_ar_profile_attr_t      *profile_attr_p);
sx_status_t sdk_ar_db_profile_set(const sx_ar_profile_key_t  *profile_key_p,
                                  const sx_ar_profile_attr_t *profile_attr_p);
sx_status_t sdk_ar_db_arn_profile_get(const sx_ar_profile_key_t *profile_key_p,
                                      sx_arn_profile_attr_t     *profile_attr_p);
sx_status_t sdk_ar_db_arn_profile_set(const sx_ar_profile_key_t   *profile_key_p,
                                      const sx_arn_profile_attr_t *profile_attr_p);
sx_status_t sdk_ar_db_classification_set(const sx_access_cmd_t            cmd,
                                         const uint8_t                    classifier_id,
                                         const sx_ar_classifier_action_t *classifier_action_p,
                                         const sx_ar_classifier_attr_t   *attr_p);
sx_status_t sdk_ar_db_classification_get(const uint8_t              classifier_id,
                                         sx_ar_classifier_action_t *classifier_action_p,
                                         sx_ar_classifier_attr_t   *attr_p);
sx_status_t sdk_ar_db_congestion_threshold_set(const sx_ar_congestion_threshold_attr_t *congestion_thresh_p);
sx_status_t sdk_ar_db_congestion_threshold_get(sx_ar_congestion_threshold_attr_t *congestion_thresh_p);
sx_status_t sdk_ar_db_shaper_rate_set(const sx_ar_shaper_attr_t *shaper_attr_p);
sx_status_t sdk_ar_db_shaper_rate_get(sx_ar_shaper_attr_t *shaper_attr_p);
sx_status_t sdk_ar_db_init_params_set(const sx_ar_init_params_t *init_params_p);
sx_status_t sdk_ar_db_init_params_get(sx_ar_init_params_t *init_params_p);
sx_status_t sdk_ar_db_dump(dbg_dump_params_t *dbg_dump_params_p);
sx_status_t sdk_ar_db_arn_init();
sx_status_t sdk_ar_db_arn_deinit();
sx_status_t sdk_ar_db_init_params_set(const sx_ar_init_params_t *init_params_p);
sx_status_t sdk_ar_db_init_params_get(sx_ar_init_params_t *init_params_p);
sx_status_t sdk_ar_db_arn_counters_indices_get(sx_arn_counters_indices_t *counters_indices_p);
sx_status_t sdk_ar_db_arn_counters_indices_set(const sx_arn_counters_indices_t *counters_indices_p);
sx_status_t sdk_ar_db_arn_general_params_get(sx_arn_general_params_t *arn_general_params_p);
sx_status_t sdk_ar_db_arn_general_params_set(const sx_arn_general_params_t *arn_general_params_p);
sx_status_t sdk_ar_db_arn_profile_attr_get(const sx_ar_profile_key_t *profile_key_p,
                                           sx_arn_profile_attr_t     *profile_attr_p);
sx_status_t sdk_ar_db_arn_default_params_get(sx_arn_default_params_t *arn_default_params_p);
sx_status_t sdk_ar_db_arn_default_params_set(const sx_arn_default_params_t *arn_default_params_p);
sx_status_t sdk_ar_db_arn_router_attr_set(const sx_arn_router_key_t        *arn_router_key_p,
                                          const sx_arn_router_attributes_t *arn_router_attributes_p);
sx_status_t sdk_ar_db_arn_router_attr_get(const sx_arn_router_key_t  *arn_router_key_p,
                                          sx_arn_router_attributes_t *arn_router_attributes_p);
sx_status_t sdk_ar_db_arn_router_attr_delete(const sx_arn_router_key_t *arn_router_key_p);
sx_status_t sdk_ar_db_arn_default_params_reset(void);
boolean_t sdk_ar_db_check_arn_router_attr_map_empty(void);
uint32_t sdk_ar_db_arn_router_attr_map_count(void);
sx_status_t sdk_ar_arn_db_dump(dbg_dump_params_t *dbg_dump_params_p);
sx_status_t sdk_ar_db_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

#endif /* __SDK_AR_DB_H__ */
