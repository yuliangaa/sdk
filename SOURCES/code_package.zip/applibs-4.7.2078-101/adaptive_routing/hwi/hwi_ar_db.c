/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include "sx/sdk/sx_status.h"
#include "complib/sx_log.h"
#include "sx/sdk/sx_ar.h"
#include "hwi_ar_be.h"
#include "hwi_ar_db.h"
#include "hwi_ar_impl.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "resource_manager/resource_manager.h"
#include "complib/cl_qpool.h"
#include "complib/cl_qmap.h"
#include <complib/cl_dbg.h>
#include "sx/sdk/sx_status_convertor.h"
#include "ethl2/port_db.h"

#undef  __MODULE__
#define __MODULE__ ADAPTIVE_ROUTING

/************************************************
 *  Defines
 ***********************************************/
#define AR_LOG_PORT_LEN                         (8)
#define AR_SWITCH_PRIO_LEN                      (3)
#define AR_PORT_RANGES_LINE_LEN                 (150)
#define AR_OPCODES_LINE_LEN                     (50)
#define AR_MODE_LEN                             (20)
#define AR_PROFILE_LEN                          (10)
#define AR_CLASSIFIER_HEADER_TYPE_STR_LEN       (5)
#define ARN_PARAM_DEFAULT_UDP_SRC_PORT          (1234)
#define ARN_PARAM_DEFAULT_UDP_DST_PORT          (43987)
#define ARN_PARAM_DEFAULT_ARN_VERSION           (0)
#define ARN_PARAM_DEFAULT_SIP_PREFIX_MATCH_TYPE (SX_ARN_SIP_PREFIX_MATCH_FULL_AND_SUBNET_E)
#define ARN_PARAM_DEFAULT_GEN_SHAPER_MIN_TIME   (20)
#define ARN_PARAM_DEFAULT_TRUNCATE              (TRUE)
#define ARN_PARAM_DEFAULT_TRUNCATE_SIZE         (512)
#define ARN_SIP_PREFIX_LEN                      (36)

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Structs
 ***********************************************/
typedef struct sx_ar_db_classifier {
    sx_ar_classifier_action_t action;
    sx_ar_classifier_attr_t   attr;
    boolean_t                 valid;
} sx_ar_db_classifier_t;

typedef struct sx_arn_router_attr_entry {
    cl_pool_item_t             pool_item;
    cl_map_item_t              map_item;
    sx_arn_router_attributes_t router_attr_data;
} sx_arn_router_attr_entry_t;

typedef struct sx_arn_db_router_attributes {
    cl_qpool_t arn_router_attr_pool;
    cl_qmap_t  arn_router_attr_map;
} sx_arn_db_router_attributes_t;

typedef struct sx_arn_db_default_params {
    sx_arn_default_params_t default_params;
} sx_arn_db_default_params_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static sx_ar_profile_attr_t              ar_profile_db[SPECTRUM2_AR_NUM_PROFILES];
static sx_ar_db_classifier_t             ar_classifier_db[SX_AR_CLASSIFIER_MAX_NUM_OF_INDEXES_E]; /*Number of user classifiers + default classifier*/
static sx_ar_congestion_threshold_attr_t ar_cong_thresholds_db;
static sx_ar_shaper_attr_t               ar_shaper_rate_db;
static sx_arn_general_params_t           arn_gen_params_db;
static sx_ar_init_params_t               ar_init_params_db;
static sx_arn_profile_attr_t             arn_profile_attr_db[SPECTRUM2_AR_NUM_PROFILES];
static sx_arn_db_default_params_t        arn_default_params_db;
static sx_arn_counters_indices_t         arn_counters_indices_db;
static sx_arn_db_router_attributes_t     arn_router_attributes_db;

/************************************************
 *  Local function declarations
 ***********************************************/
static void __sdk_ar_db_classifier_l3_type_print(uint8_t value,
                                                 char   *ret_str);
static void __sdk_ar_db_classifier_l4_type_print(uint8_t value,
                                                 char   *ret_str);
/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t sdk_ar_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

sx_status_t sdk_ar_db_init()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CLR_ARRAY(ar_profile_db, SPECTRUM2_AR_NUM_PROFILES, sx_ar_profile_attr_t);
    SX_MEM_CLR_ARRAY(ar_classifier_db, SX_AR_CLASSIFIER_MAX_NUM_OF_INDEXES_E, sx_ar_db_classifier_t);
    SX_MEM_CLR(ar_shaper_rate_db);
    SX_MEM_CLR(ar_cong_thresholds_db);
    SX_MEM_CLR(ar_init_params_db);

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_init()
{
    sx_status_t err = SX_STATUS_SUCCESS;
    cl_status_t cl_status = CL_SUCCESS;
    boolean_t   router_attr_qpool_init = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(arn_gen_params_db);
    SX_MEM_CLR(arn_default_params_db);
    SX_MEM_CLR(arn_counters_indices_db);
    SX_MEM_CLR_ARRAY(arn_profile_attr_db, SPECTRUM2_AR_NUM_PROFILES, sx_arn_profile_attr_t);

    cl_status = CL_QPOOL_INIT(&arn_router_attributes_db.arn_router_attr_pool,
                              rm_resource_global.router_rifs_max, rm_resource_global.router_rifs_max, 0,
                              sizeof(sx_arn_router_attr_entry_t), NULL, NULL, NULL);
    if (CL_SUCCESS != cl_status) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("No resources to allocate new ARN router attributes.\n");
        goto out;
    }
    router_attr_qpool_init = TRUE;

    cl_qmap_init(&arn_router_attributes_db.arn_router_attr_map);

out:
    if ((err != SX_STATUS_SUCCESS) && (router_attr_qpool_init == TRUE)) {
        CL_QPOOL_DESTROY(&arn_router_attributes_db.arn_router_attr_pool);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_deinit()
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    cl_map_item_t              *map_item = NULL;
    const cl_map_item_t        *map_end = NULL;
    sx_arn_router_attr_entry_t *arn_router_attr_entry_p = NULL;

    SX_LOG_ENTER();

    map_item = cl_qmap_head(&(arn_router_attributes_db.arn_router_attr_map));
    map_end = cl_qmap_end(&(arn_router_attributes_db.arn_router_attr_map));

    while (map_item != map_end) {
        arn_router_attr_entry_p = PARENT_STRUCT(map_item, sx_arn_router_attr_entry_t, map_item);
        map_item = cl_qmap_next(map_item);
        cl_qmap_remove_item(&(arn_router_attributes_db.arn_router_attr_map),
                            &(arn_router_attr_entry_p->map_item));
        cl_qpool_put(&(arn_router_attributes_db.arn_router_attr_pool),
                     &(arn_router_attr_entry_p->pool_item));
    }

    CL_QPOOL_DESTROY(&(arn_router_attributes_db.arn_router_attr_pool));

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_profile_get(const sx_ar_profile_key_t *profile_key_p, sx_ar_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((profile_key_p->profile != SX_AR_PROFILE_0_E) &&
        (profile_key_p->profile != SX_AR_PROFILE_1_E)) {
        SX_LOG_ERR("AR DB profile set failed, invalid profile handle %u\n", profile_key_p->profile);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    SX_MEM_CPY_BUF(profile_attr_p, (void*)&ar_profile_db[profile_key_p->profile - 1], sizeof(sx_ar_profile_attr_t));

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_ar_db_profile_set(const sx_ar_profile_key_t *profile_key_p, const sx_ar_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((profile_key_p->profile != SX_AR_PROFILE_0_E) &&
        (profile_key_p->profile != SX_AR_PROFILE_1_E)) {
        SX_LOG_ERR("AR DB profile set failed, invalid profile handle %u\n",
                   profile_key_p->profile);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    SX_MEM_CPY_BUF((void*)&ar_profile_db[profile_key_p->profile - 1],
                   profile_attr_p, sizeof(sx_ar_profile_attr_t));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_profile_get(const sx_ar_profile_key_t *profile_key_p, sx_arn_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((profile_key_p->profile != SX_AR_PROFILE_0_E) &&
        (profile_key_p->profile != SX_AR_PROFILE_1_E)) {
        SX_LOG_ERR("AR DB profile get failed, invalid profile handle %u\n", profile_key_p->profile);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    SX_MEM_CPY_BUF(profile_attr_p,
                   (void*)&arn_profile_attr_db[profile_key_p->profile - 1],
                   sizeof(sx_arn_profile_attr_t));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_profile_set(const sx_ar_profile_key_t   *profile_key_p,
                                      const sx_arn_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((profile_key_p->profile != SX_AR_PROFILE_0_E) &&
        (profile_key_p->profile != SX_AR_PROFILE_1_E)) {
        SX_LOG_ERR("AR ARN DB profile get failed, invalid profile handle %u\n",
                   profile_key_p->profile);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    SX_MEM_CPY_BUF((void*)&arn_profile_attr_db[profile_key_p->profile - 1],
                   profile_attr_p, sizeof(sx_arn_profile_attr_t));

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_ar_db_classification_set(const sx_access_cmd_t            cmd,
                                         const uint8_t                    classifier_id,
                                         const sx_ar_classifier_action_t *classifier_action_p,
                                         const sx_ar_classifier_attr_t   *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* SX_AR_CLASSIFIER_INDEX_DEFAULT_E = SX_AR_CLASSIFIER_INDEX_MAX_E+1 */
    if (classifier_id >= SX_AR_CLASSIFIER_MAX_NUM_OF_INDEXES_E) {
        SX_LOG_ERR("AR DB classification set failed, invalid classifier id %u\n", classifier_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_SET) {
        SX_MEM_CPY_BUF((void*)&ar_classifier_db[classifier_id].action,
                       classifier_action_p, sizeof(sx_ar_classifier_action_t));
        if (attr_p) {
            SX_MEM_CPY_BUF((void*)&ar_classifier_db[classifier_id].attr, attr_p,
                           sizeof(sx_ar_classifier_attr_t));
        }
        ar_classifier_db[classifier_id].valid = TRUE;
    } else {
        SX_MEM_CLR_BUF((void*)&ar_classifier_db[classifier_id], sizeof(sx_ar_db_classifier_t));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_classification_get(const uint8_t              classifier_id,
                                         sx_ar_classifier_action_t *classifier_action_p,
                                         sx_ar_classifier_attr_t   *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* SX_AR_CLASSIFIER_MAX_NUM_OF_INDEXES_E = SX_AR_CLASSIFIER_INDEX_DEFAULT_E + 1 */
    if (classifier_id >= SX_AR_CLASSIFIER_MAX_NUM_OF_INDEXES_E) {
        SX_LOG_ERR("AR DB classification get failed, invalid classifier id %u\n", classifier_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((classifier_id != SX_AR_CLASSIFIER_INDEX_DEFAULT_E) && !ar_classifier_db[classifier_id].valid) {
        SX_LOG_ERR("AR DB classification get failed, classifier id %u has not been set yet.\n",
                   classifier_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CPY_BUF(classifier_action_p, (void*)&ar_classifier_db[classifier_id].action,
                   sizeof(sx_ar_classifier_action_t));
    if (attr_p) {
        SX_MEM_CPY_BUF(attr_p, (void*)&ar_classifier_db[classifier_id].attr,
                       sizeof(sx_ar_classifier_attr_t));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_congestion_threshold_set(const sx_ar_congestion_threshold_attr_t *congestion_thresh_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(ar_cong_thresholds_db, *congestion_thresh_p);

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_congestion_threshold_get(sx_ar_congestion_threshold_attr_t *congestion_thresh_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(*congestion_thresh_p, ar_cong_thresholds_db);

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_shaper_rate_set(const sx_ar_shaper_attr_t *shaper_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(ar_shaper_rate_db, *shaper_attr_p);

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_shaper_rate_get(sx_ar_shaper_attr_t *shaper_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(*shaper_attr_p, ar_shaper_rate_db);

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_init_params_set(const sx_ar_init_params_t *init_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(ar_init_params_db, *init_params_p);

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_init_params_get(sx_ar_init_params_t *init_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(*init_params_p, ar_init_params_db);

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint64_t    ar_changes;
    uint32_t    j, bind_time, port_hi, port_med, port_low;
    uint8_t     i, busy_thresh, free_thresh, action,
                classifier_id, l3, l4, l3_inner, l4_inner, bth_ar, bth_ar_inner;
    boolean_t                 elephant_en, rate_from_enable, rate_to_enable, is_tunnel_exist, is_init;
    uint16_t                  shaper_rate_from, shaper_rate_to;
    char                      log_ports[MAX_PHYPORT_NUM * AR_LOG_PORT_LEN] = {0};
    char                      switch_prio[AR_SWITCH_PRIO_LEN * RM_API_COS_PORT_PRIO_MAX] = {0};
    const char               *port_range_str = "low: %u, high: %u, protocol: %s, port: %s. ";
    char                      buf[AR_PORT_RANGES_LINE_LEN] = {0};
    char                      port_ranges[AR_PORT_RANGES_MAX][AR_PORT_RANGES_LINE_LEN];
    char                      opcodes_4_0[AR_OPCODES_LINE_LEN] = {0};
    char                      inner_opcodes_4_0[AR_OPCODES_LINE_LEN] = {0};
    char                      opcodes_7_5[AR_OPCODES_LINE_LEN] = {0};
    char                      inner_opcodes_7_5[AR_OPCODES_LINE_LEN] = {0};
    char                      mode[AR_MODE_LEN] = {0};
    char                      profile[AR_PROFILE_LEN] = {0};
    char                      ret_str[AR_PORT_RANGES_LINE_LEN] = {0};
    char                      buffer_mode[AR_MODE_LEN] = {0};
    sx_ar_global_counters_t   ar_counters;
    dbg_utils_table_columns_t ar_dump_profile_clmns[] = {
        { "Profile",                10,    PARAM_STRING_E,    &profile},
        { "Route Mode",             20,    PARAM_STRING_E,    &mode},
        { "Busy Threshold",         14,    PARAM_UINT8_E,    &busy_thresh},
        { "Free Threshold",         14,    PARAM_UINT8_E,    &free_thresh},
        { "Elephant Enable",        16,    PARAM_BOOL_E,     &elephant_en},
        { "Shaper RateTo En",       18,    PARAM_BOOL_E,     &rate_to_enable},
        { "Shaper RateFrom En",     18,    PARAM_BOOL_E,     &rate_from_enable},
        { "Bind Time",              10,    PARAM_UINT32_E,   &bind_time},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t ar_dump_cong_thresh_clmns[] = {
        { "Port Th Hi",             12,    PARAM_UINT32_E,   &port_hi},
        { "Port Th Med",            12,    PARAM_UINT32_E,   &port_med},
        { "Port Th Low",            12,    PARAM_UINT32_E,   &port_low},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t ar_dump_shaper_rate_clmns[] = {
        { "Shaper rate from",          16,    PARAM_UINT16_E,   &shaper_rate_from},
        { "Shaper rate to",            16,    PARAM_UINT16_E,   &shaper_rate_to},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t ar_dump_init_params_clmns[] = {
        { "Is initiated",       12,    PARAM_BOOL_E,   &is_init},
        { "Port Buffer Mode",   16,    PARAM_STRING_E, &buffer_mode},
        {NULL, 0, 0, NULL}
    };
    FILE                     *dump_file = NULL;

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_MEM_CLR(ar_counters);

    dump_file = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(dump_file, "HWI General Adaptive Routing DB");
    dbg_utils_pprinter_secondary_header_print(dump_file, "AR Init Params");
    dbg_utils_pprinter_table_headline_print(dump_file, ar_dump_init_params_clmns);
    is_init = sdk_ar_impl_is_module_initialized();
    strncpy(buffer_mode, sx_ar_buffer_mode_str(ar_init_params_db.buffer_mode), AR_MODE_LEN);
    dbg_utils_pprinter_table_data_line_print(dump_file, ar_dump_init_params_clmns);

    dbg_utils_pprinter_secondary_header_print(dump_file, "AR Profiles table");
    dbg_utils_pprinter_table_headline_print(dump_file, ar_dump_profile_clmns);

    for (i = 0; i < SPECTRUM2_AR_NUM_PROFILES; i++) {
        strncpy(profile, sx_ar_profile_handle_str(i + 1), AR_PROFILE_LEN);  /*Profile0 enum value is 1 and Profile1 enum value is 2. */
        /* coverity[buffer_size_warning] */
        strncpy(mode, sx_ar_profile_mode_str(ar_profile_db[i].mode), AR_MODE_LEN);
        busy_thresh = ar_profile_db[i].profile_threshold.busy_threshold;
        free_thresh = ar_profile_db[i].profile_threshold.free_threshold;
        elephant_en = ar_profile_db[i].only_elephant_en;
        rate_from_enable = ar_profile_db[i].shaper_attr_filter.from_shaper_is_enable;
        rate_to_enable = ar_profile_db[i].shaper_attr_filter.to_shaper_is_enable;
        bind_time = ar_profile_db[i].bind_time;

        dbg_utils_pprinter_table_data_line_print(dump_file, ar_dump_profile_clmns);
    }
    dbg_utils_pprinter_secondary_header_print(dump_file, "AR Classifiers");
    for (i = 0; i < SX_AR_CLASSIFIER_INDEX_MAX_E; i++) {
        if (ar_classifier_db[i].valid) {
            for (j = 0; j < AR_PORT_RANGES_MAX; j++) {
                SX_MEM_CLR_ARRAY(port_ranges[j], AR_PORT_RANGES_LINE_LEN, char);
            }
            classifier_id = i;
            action = ar_classifier_db[i].action.ar_flow_classification;
            l3 = ar_classifier_db[i].attr.key.l3;
            l3_inner = ar_classifier_db[i].attr.key.inner_l3;
            l4 = ar_classifier_db[i].attr.key.l4;
            l4_inner = ar_classifier_db[i].attr.key.inner_l4;
            bth_ar = ar_classifier_db[i].attr.key.bth_ar;
            bth_ar_inner = ar_classifier_db[i].attr.key.inner_bth_ar;
            is_tunnel_exist = ar_classifier_db[i].attr.key.is_tunnel_exist;

            log_ports[0] = '\0';
            for (j = 0; j < ar_classifier_db[i].attr.key.log_ports_cnt; j++) {
                snprintf(&log_ports[j * AR_LOG_PORT_LEN], AR_LOG_PORT_LEN + 1, "0x%x ",
                         ar_classifier_db[i].attr.key.log_ports[j]);
            }

            buf[0] = '\0';
            switch_prio[0] = '\0';
            for (j = 0; j < ar_classifier_db[i].attr.key.switch_priorities_cnt; j++) {
                snprintf(buf, AR_SWITCH_PRIO_LEN + 1, "%u ",
                         ar_classifier_db[i].attr.key.switch_priorities[j]);
                strcat(switch_prio, buf);
            }

            buf[0] = '\0';
            opcodes_4_0[0] = '\0';
            for (j = 0; j < ar_classifier_db[i].attr.key.bth_opcodes.bth_opcode_4_0_cnt; j++) {
                snprintf(buf, 5, "%u ",
                         ar_classifier_db[i].attr.key.bth_opcodes.bth_opcode_4_0[j]);
                strcat(opcodes_4_0, buf);
            }

            buf[0] = '\0';
            inner_opcodes_4_0[0] = '\0';
            for (j = 0; j < ar_classifier_db[i].attr.key.inner_bth_opcodes.bth_opcode_4_0_cnt; j++) {
                snprintf(buf, 5, "%u ",
                         ar_classifier_db[i].attr.key.inner_bth_opcodes.bth_opcode_4_0[j]);
                strcat(inner_opcodes_4_0, buf);
            }

            buf[0] = '\0';
            opcodes_7_5[0] = '\0';
            for (j = 0; j < ar_classifier_db[i].attr.key.bth_opcodes.bth_opcode_7_5_cnt; j++) {
                snprintf(buf, 5, "%u ",
                         ar_classifier_db[i].attr.key.bth_opcodes.bth_opcode_7_5[j]);
                strcat(opcodes_7_5, buf);
            }

            buf[0] = '\0';
            inner_opcodes_7_5[0] = '\0';
            for (j = 0; j < ar_classifier_db[i].attr.key.inner_bth_opcodes.bth_opcode_7_5_cnt; j++) {
                snprintf(opcodes_7_5, 5, "%u ",
                         ar_classifier_db[i].attr.key.inner_bth_opcodes.bth_opcode_7_5[j]);
                strcat(inner_opcodes_7_5, buf);
            }

            for (j = 0; j < ar_classifier_db[i].attr.key.port_ranges_cnt; j++) {
                snprintf(port_ranges[j], AR_PORT_RANGES_LINE_LEN, port_range_str,
                         ar_classifier_db[i].attr.key.port_ranges[j].port_low,
                         ar_classifier_db[i].attr.key.port_ranges[j].port_high,
                         sx_ar_classifier_l4_proto_str(ar_classifier_db[i].attr.key.port_ranges[j].protocol),
                         sx_ar_classifier_l4_port_str(ar_classifier_db[i].attr.key.port_ranges[j].port));
            }

            dbg_utils_pprinter_field_print(dump_file, "Classifier ID", &classifier_id, PARAM_UINT8_E);
            dbg_utils_pprinter_field_print(dump_file,
                                           "Action Type",
                                           sx_ar_classifier_action_type_str(action),
                                           PARAM_STRING_E);
            dbg_utils_pprinter_field_print(dump_file, "Ingress log ports", log_ports, PARAM_STRING_E);
            dbg_utils_pprinter_field_print(dump_file, "Switch priorities", switch_prio, PARAM_STRING_E);
            dbg_utils_pprinter_field_print(dump_file, "BTH opcodes_4_0", opcodes_4_0, PARAM_STRING_E);
            dbg_utils_pprinter_field_print(dump_file, "BTH inner opcodes_4_0", inner_opcodes_4_0, PARAM_STRING_E);
            dbg_utils_pprinter_field_print(dump_file, "BTH opcodes_7_5", opcodes_7_5, PARAM_STRING_E);
            dbg_utils_pprinter_field_print(dump_file, "BTH inner opcodes_7_5", inner_opcodes_7_5, PARAM_STRING_E);
            __sdk_ar_db_classifier_l3_type_print(l3, ret_str);
            dbg_utils_pprinter_field_print(dump_file, "L3", ret_str, PARAM_STRING_E);
            __sdk_ar_db_classifier_l3_type_print(l3_inner, ret_str);
            dbg_utils_pprinter_field_print(dump_file, "L3 inner", ret_str, PARAM_STRING_E);
            __sdk_ar_db_classifier_l4_type_print(l4, ret_str);
            dbg_utils_pprinter_field_print(dump_file, "L4", ret_str, PARAM_STRING_E);
            __sdk_ar_db_classifier_l4_type_print(l4_inner, ret_str);
            dbg_utils_pprinter_field_print(dump_file, "L4 inner", ret_str, PARAM_STRING_E);
            dbg_utils_pprinter_field_print(dump_file, "BTH AR", &bth_ar, PARAM_UINT8_E);
            dbg_utils_pprinter_field_print(dump_file, "BTH AR inner", &bth_ar_inner, PARAM_UINT8_E);
            dbg_utils_pprinter_field_print(dump_file, "Tunnel exists", &is_tunnel_exist, PARAM_BOOL_E);
            for (j = 0; j < ar_classifier_db[i].attr.key.port_ranges_cnt; j++) {
                buf[0] = '\0';
                snprintf(buf, 14, "Port ranges %u", j);
                dbg_utils_pprinter_field_print(dump_file, buf, port_ranges[j], PARAM_STRING_E);
            }
            dbg_utils_pprinter_separator_line_print(dump_file, AR_PORT_RANGES_LINE_LEN, '-');
        }
    }

    dbg_utils_pprinter_secondary_header_print(dump_file, "AR Default Classifier");
    classifier_id = SX_AR_CLASSIFIER_INDEX_DEFAULT_E;
    action = ar_classifier_db[SX_AR_CLASSIFIER_INDEX_DEFAULT_E].action.ar_flow_classification;

    dbg_utils_pprinter_field_print(dump_file, "Classifier ID", &classifier_id, PARAM_UINT8_E);
    dbg_utils_pprinter_field_print(dump_file, "Action Type", sx_ar_classifier_action_type_str(action), PARAM_STRING_E);

    dbg_utils_pprinter_secondary_header_print(dump_file, "AR Congestion Thresholds table");
    dbg_utils_pprinter_table_headline_print(dump_file, ar_dump_cong_thresh_clmns);

    port_hi = ar_cong_thresholds_db.port_threshold.congestion_thresh_hi;
    port_med = ar_cong_thresholds_db.port_threshold.congestion_thresh_med;
    port_low = ar_cong_thresholds_db.port_threshold.congestion_thresh_lo;

    dbg_utils_pprinter_table_data_line_print(dump_file, ar_dump_cong_thresh_clmns);

    dbg_utils_pprinter_secondary_header_print(dump_file, "AR Shaper rate table");
    dbg_utils_pprinter_table_headline_print(dump_file, ar_dump_shaper_rate_clmns);

    shaper_rate_from = ar_shaper_rate_db.shaper_rate_from;
    shaper_rate_to = ar_shaper_rate_db.shaper_rate_to;

    dbg_utils_pprinter_table_data_line_print(dump_file, ar_dump_shaper_rate_clmns);

    /* Print AR global counter */
    dbg_utils_pprinter_secondary_header_print(dump_file, "AR Global Counter");
    err = sdk_ar_impl_counters_get(SX_ACCESS_CMD_READ, &ar_counters);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve AR global counter, Error: (%s).\n",
                   sx_status_str(err));
        goto out;
    }
    ar_changes = ar_counters.ar_congestion_changes;
    dbg_utils_pprinter_field_print(dump_file, "Number of AR changes", &ar_changes, PARAM_UINT64_E);

out:
    return err;
}

sx_status_t sdk_ar_arn_db_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint64_t    gen_drop_no_nexthop = 0, gen_drop_ip_miss = 0, arn_rcv_ok = 0,
                arn_rcv_drop = 0, arn_port_tx = 0;
    uint32_t i = 0, gen_shaper_min_time = 0, device_index = 0, dev_num = 0,
             port_index = 0, port_num = 0;
    uint16_t switch_id = 0, arn_aging_time = 0, arn_hold_time = 0,
             udp_src_port = 0, udp_dest_port = 0, truncate_size = 0, vrid = 0,
             irif = 0, erif = 0;
    uint8_t                     grade_threshold = 0, arn_penalty = 0, arn_version = 0;
    boolean_t                   arn_enable = FALSE, only_elephant_enable = FALSE, truncate = FALSE;
    sx_arn_counters_t           arn_counters;
    sx_port_log_id_t            log_port;
    sx_arn_port_counters_t      port_counters;
    sx_device_info_t           *device_info_list_p = NULL;
    sx_device_id_t              device_id = 1;
    sx_swid_id_t                swid = 0;
    sx_port_attributes_t       *port_attributes_p = NULL;
    sx_swid_type_t              swid_type = SX_SWID_TYPE_DISABLED;
    char                        profile_id_str[AR_PROFILE_LEN + 1] = {0}, sip_prefix_str[ARN_SIP_PREFIX_LEN + 1] = {0};
    cl_map_item_t              *map_item = NULL;
    const cl_map_item_t        *map_end = NULL;
    sx_arn_router_attr_entry_t *arn_router_attr_entry_p = NULL;
    dbg_utils_table_columns_t   arn_dump_general_params_clmns[] = {
        { "Switch ID",          10,                 PARAM_UINT16_E,  &switch_id},
        { "Grade threshold",    16,                 PARAM_UINT8_E,   &grade_threshold},
        { "Source IP",          40,                 PARAM_IPV4_E,    NULL},
        { "Profile ID",         AR_PROFILE_LEN,     PARAM_STRING_E,  &profile_id_str},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t   arn_dump_profile_attr_clmns[] = {
        { "Profile",                10,     PARAM_STRING_E, &profile_id_str},
        { "ARN Generation enable",  21,     PARAM_BOOL_E,   &arn_enable},
        { "Only elephant enable",   20,     PARAM_BOOL_E,   &only_elephant_enable},
        { "ARN Penalty",            11,     PARAM_UINT8_E,  &arn_penalty},
        { "ARN Aging time",         14,     PARAM_UINT16_E, &arn_aging_time},
        { "ARN Hold time",          13,     PARAM_UINT16_E, &arn_hold_time},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t   arn_dump_default_params_clmns[] = {
        { "ARN Version",                    11,                 PARAM_UINT8_E,  &arn_version},
        { "UDP Source port",                15,                 PARAM_UINT16_E, &udp_src_port},
        { "UDP Dest port",                  13,                 PARAM_UINT16_E, &udp_dest_port},
        { "Source IP prefix match type",    ARN_SIP_PREFIX_LEN, PARAM_STRING_E, &sip_prefix_str},
        { "Generation shaper min time",     26,                 PARAM_UINT32_E, &gen_shaper_min_time},
        { "Is truncate enable",             18,                 PARAM_BOOL_E,   &truncate},
        { "Truncate size",                  13,                 PARAM_UINT16_E, &truncate_size},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t   arn_dump_counters_clmns[] = {
        { "Generation drop no nexthop", 26,     PARAM_UINT64_E,  &gen_drop_no_nexthop},
        { "Generation drop IP miss",    23,     PARAM_UINT64_E,  &gen_drop_ip_miss},
        { "ARN Receive OK",             14,     PARAM_UINT64_E,  &arn_rcv_ok},
        { "ARN Receive drop",           16,     PARAM_UINT64_E,  &arn_rcv_drop},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t   arn_dump_port_counters_clmns[] = {
        { "Log port",               8,     PARAM_HEX_E,     &log_port},
        { "ARN port transmitted",   20,    PARAM_UINT64_E,  &arn_port_tx},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t   arn_dump_router_attr_clmns[] = {
        { "Virtual router ID",   17,    PARAM_UINT16_E,  &vrid},
        { "Ingress RIF",         11,    PARAM_UINT16_E,  &irif},
        { "Egress RIF",          10,    PARAM_UINT16_E,  &erif},
        {NULL, 0, 0, NULL}
    };
    FILE                       *dump_file = NULL;

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    dump_file = dbg_dump_params_p->stream;

    dbg_utils_pprinter_module_header_print(dump_file, "HWI Router Adaptive Routing Notification DB");
    dbg_utils_pprinter_secondary_header_print(dump_file, "ARN General Parameters");
    dbg_utils_pprinter_table_headline_print(dump_file, arn_dump_general_params_clmns);

    strncpy(profile_id_str, sx_cos_tq_profile_id_str(arn_gen_params_db.profile_id), AR_PROFILE_LEN);
    switch_id = arn_gen_params_db.switch_id;
    grade_threshold = arn_gen_params_db.grade_threshold;
    if (arn_gen_params_db.source_ip.version == SX_IP_VERSION_IPV4) {
        arn_dump_general_params_clmns[2].type = PARAM_IPV4_E;
        arn_dump_general_params_clmns[2].data = &arn_gen_params_db.source_ip.addr.ipv4;
    } else {
        arn_dump_general_params_clmns[2].type = PARAM_IPV6_E;
        arn_dump_general_params_clmns[2].data = &arn_gen_params_db.source_ip.addr.ipv6;
    }
    dbg_utils_pprinter_table_data_line_print(dump_file, arn_dump_general_params_clmns);

    dbg_utils_pprinter_secondary_header_print(dump_file, "ARN Profile Attributes");
    dbg_utils_pprinter_table_headline_print(dump_file, arn_dump_profile_attr_clmns);

    for (i = 0; i < SPECTRUM2_AR_NUM_PROFILES; i++) {
        strncpy(profile_id_str, sx_ar_profile_handle_str(i + 1), AR_PROFILE_LEN);
        arn_aging_time = arn_profile_attr_db[i].arn_aging_time;
        arn_enable = arn_profile_attr_db[i].arn_enable;
        arn_hold_time = arn_profile_attr_db[i].arn_hold_time;
        arn_penalty = arn_profile_attr_db[i].arn_penalty;
        only_elephant_enable = arn_profile_attr_db[i].only_elephant_enable;
        dbg_utils_pprinter_table_data_line_print(dump_file, arn_dump_profile_attr_clmns);
    }

    dbg_utils_pprinter_secondary_header_print(dump_file, "ARN Default Parameters");
    dbg_utils_pprinter_table_headline_print(dump_file, arn_dump_default_params_clmns);
    arn_version = arn_default_params_db.default_params.arn_version;
    gen_shaper_min_time = arn_default_params_db.default_params.gen_shaper_min_time;
    strncpy(sip_prefix_str,
            sx_arn_sip_prefix_match_type_str(arn_default_params_db.default_params.sip_prefix_match_type),
            ARN_SIP_PREFIX_LEN);
    truncate = arn_default_params_db.default_params.truncate;
    truncate_size = arn_default_params_db.default_params.truncate_size;
    udp_dest_port = arn_default_params_db.default_params.udp_dest_port;
    udp_src_port = arn_default_params_db.default_params.udp_src_port;
    dbg_utils_pprinter_table_data_line_print(dump_file, arn_dump_default_params_clmns);

    dbg_utils_pprinter_secondary_header_print(dump_file, "ARN Flow Counters");
    dbg_utils_pprinter_table_headline_print(dump_file, arn_dump_counters_clmns);
    if (dbg_dump_params_p->hw_dump_method != SX_DBG_HW_DUMP_METHOD_NONE_E) {
        err = sdk_ar_impl_arn_counters_get(SX_ACCESS_CMD_GET, &arn_counters);
        SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN flow counters");

        gen_drop_no_nexthop = arn_counters.gen_drop_no_nexthop;
        gen_drop_ip_miss = arn_counters.gen_drop_ip_miss;
        arn_rcv_ok = arn_counters.arn_rcv_ok;
        arn_rcv_drop = arn_counters.arn_rcv_drop;

        dbg_utils_pprinter_table_data_line_print(dump_file, arn_dump_counters_clmns);


        dbg_utils_pprinter_secondary_header_print(dump_file, "ARN Port Counters");
        dbg_utils_pprinter_table_headline_print(dump_file, arn_dump_port_counters_clmns);

        err = port_device_list_get(SX_ACCESS_CMD_GET, device_info_list_p, &dev_num);
        SX_CHECK_RC_OUT_ERR(err, "Failed to retrieve device info");

        for (device_index = 0; device_index < dev_num; device_index++) {
            device_id = device_info_list_p[device_index].dev_id;

            /*get device's number of ports*/
            err = port_device_get(SX_ACCESS_CMD_COUNT, device_id, swid, NULL, &port_num);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to retrieve number of ports on device: (%u)"
                           "and swid: (%u). Error: (%s).\n",
                           device_id, swid, sx_status_str(err));
                goto out;
            }

            if (port_num == 0) {
                continue;
            }

            port_attributes_p = (sx_port_attributes_t*)cl_malloc(port_num * sizeof(sx_port_attributes_t));
            if (port_attributes_p == NULL) {
                err = SX_STATUS_NO_MEMORY;
                SX_LOG_ERR("Failed in memory allocation (%s).\n", sx_status_str(err));
                goto out;
            }

            /*Get device logical ports list*/
            err = port_device_get(SX_ACCESS_CMD_GET, device_id, swid, port_attributes_p, &port_num);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to retrieve ports info on device (%u) and swid (%u). Error: (%s).\n",
                           device_id, swid, sx_status_str(err));
                goto out;
            }

            err = port_swid_type_get(swid, &swid_type);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to retrieve SWID (%u) type, Error: (%s).\n",
                           swid, sx_status_str(err));
                goto out;
            }

            if (swid_type != SX_SWID_TYPE_ETHERNET) {
                CL_FREE_N_NULL(port_attributes_p);
                continue;
            }

            for (port_index = 0; port_index < port_num; port_index++) {
                if (IS_PORT_TYPE_NETWORK(port_attributes_p[port_index].log_port) == FALSE) {
                    continue;
                }

                err = sdk_ar_impl_arn_port_counters_get(SX_ACCESS_CMD_GET,
                                                        port_attributes_p[port_index].log_port,
                                                        &port_counters);
                SX_CHECK_RC_OUT_ERR(err, "Failed to get port counters");

                log_port = port_attributes_p[port_index].log_port;
                arn_port_tx = port_counters.arn_port_tx;

                dbg_utils_pprinter_table_data_line_print(dump_file, arn_dump_port_counters_clmns);
            }
            CL_FREE_N_NULL(port_attributes_p);
        }
    }

    dbg_utils_pprinter_secondary_header_print(dump_file, "ARN Router Attributes");
    dbg_utils_pprinter_table_headline_print(dump_file, arn_dump_router_attr_clmns);

    map_item = cl_qmap_head(&(arn_router_attributes_db.arn_router_attr_map));
    map_end = cl_qmap_end(&(arn_router_attributes_db.arn_router_attr_map));

    while (map_item != map_end) {
        arn_router_attr_entry_p = PARENT_STRUCT(map_item, sx_arn_router_attr_entry_t, map_item);
        map_item = cl_qmap_next(map_item);

        vrid = cl_qmap_key(&(arn_router_attr_entry_p->map_item));
        erif = arn_router_attr_entry_p->router_attr_data.erif;
        irif = arn_router_attr_entry_p->router_attr_data.irif;
        dbg_utils_pprinter_table_data_line_print(dump_file, arn_dump_router_attr_clmns);
    }

out:
    if (port_attributes_p) {
        CL_FREE_N_NULL(port_attributes_p);
    }
    return err;
}

static void __sdk_ar_db_classifier_l3_type_print(uint8_t value, char *ret_str)
{
    uint8_t     i = 0, mask = 0;
    const char *l3_str;
    boolean_t   is_found = FALSE;
    char        buff[AR_PORT_RANGES_LINE_LEN] = {0};
    uint32_t    buff_size = AR_PORT_RANGES_LINE_LEN - 1;
    uint32_t    buff_len = 0;


    SX_MEM_CLR_BUF(ret_str, AR_PORT_RANGES_LINE_LEN);

    if (value == SX_AR_CLASSIFIER_L3_ANY_E) {
        strncpy(ret_str, sx_ar_classifier_header_type_l3_str(value), AR_PORT_RANGES_LINE_LEN);
        return;
    }

    for (i = 0; i < AR_CLASSIFIER_HEADER_TYPE_STR_LEN; i++) {
        mask = 1 << i;
        if (value & mask) {
            l3_str = sx_ar_classifier_header_type_l3_str(value & mask);
            if (strcmp(l3_str, "Unknown")) {
                if (buff_size == 0) {
                    SX_LOG_WRN("Couldn't dump AR Classifier type %s no more space in the buffer\n", l3_str);
                    break;
                }
                is_found = TRUE;
                buff[0] = '\0';
                buff_len = snprintf(buff, AR_PORT_RANGES_LINE_LEN, "%s,", l3_str);
                strncat(ret_str, buff, buff_size);
                buff_size = (buff_size > buff_len) ? (buff_size - buff_len) : 0;
            }
        }
    }
    if (!is_found) {
        strncpy(ret_str, "Unknown", AR_PORT_RANGES_LINE_LEN);
    } else {
        ret_str[strlen(ret_str) - 1] = '\0';
    }

    return;
}

static void __sdk_ar_db_classifier_l4_type_print(uint8_t value, char *ret_str)
{
    uint8_t     i = 0, mask = 0;
    const char *l4_str;
    boolean_t   is_found = FALSE;
    char        buff[AR_PORT_RANGES_LINE_LEN] = {0};
    uint32_t    buff_size = AR_PORT_RANGES_LINE_LEN - 1;
    uint32_t    buff_len = 0;


    SX_MEM_CLR_BUF(ret_str, AR_PORT_RANGES_LINE_LEN);

    if (value == SX_AR_CLASSIFIER_L4_ANY_E) {
        strncpy(ret_str, sx_ar_classifier_header_type_l4_str(value), AR_PORT_RANGES_LINE_LEN);
        return;
    }

    for (i = 0; i < AR_CLASSIFIER_HEADER_TYPE_STR_LEN; i++) {
        mask = 1 << i;
        if (value & mask) {
            l4_str = sx_ar_classifier_header_type_l4_str(value & mask);
            if (strcmp(l4_str, "Unknown")) {
                if (buff_size == 0) {
                    SX_LOG_WRN("Couldn't dump AR Classifier type %s no more space in the buffer\n", l4_str);
                    break;
                }
                is_found = TRUE;
                buff[0] = '\0';
                buff_len = snprintf(buff, AR_PORT_RANGES_LINE_LEN, "%s,", l4_str);
                strncat(ret_str, buff, buff_size);
                buff_size = (buff_size > buff_len) ? (buff_size - buff_len) : 0;
            }
        }
    }
    if (!is_found) {
        strncpy(ret_str, "Unknown", AR_PORT_RANGES_LINE_LEN);
    } else {
        ret_str[strlen(ret_str) - 1] = '\0';
    }

    return;
}

sx_status_t sdk_ar_db_arn_counters_indices_get(sx_arn_counters_indices_t *counters_indices_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(*counters_indices_p, arn_counters_indices_db);

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_counters_indices_set(const sx_arn_counters_indices_t *counters_indices_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(arn_counters_indices_db, *counters_indices_p);

    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_ar_db_arn_general_params_get(sx_arn_general_params_t *arn_general_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(*arn_general_params_p, arn_gen_params_db);

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_general_params_set(const sx_arn_general_params_t *arn_general_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(arn_gen_params_db, *arn_general_params_p);

    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_ar_db_arn_profile_attr_get(const sx_ar_profile_key_t *profile_key_p,
                                           sx_arn_profile_attr_t     *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((profile_key_p->profile != SX_AR_PROFILE_0_E) &&
        (profile_key_p->profile != SX_AR_PROFILE_1_E)) {
        SX_LOG_ERR("ARN DB profile attr get failed, invalid profile handle %u\n", profile_key_p->profile);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    SX_MEM_CPY(*profile_attr_p, arn_profile_attr_db[profile_key_p->profile - 1]);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_default_params_get(sx_arn_default_params_t *arn_default_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_MEM_CPY(*arn_default_params_p, arn_default_params_db.default_params);

    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_router_attr_set(const sx_arn_router_key_t        *arn_router_key_p,
                                          const sx_arn_router_attributes_t *arn_router_attributes_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    const cl_map_item_t        *end_p = NULL;
    cl_map_item_t              *item_p = NULL;
    sx_arn_router_attr_entry_t *arn_router_attr_entry_p = NULL;

    SX_LOG_ENTER();

    /* Verify the entry is not already in the DB */
    item_p = cl_qmap_get(&arn_router_attributes_db.arn_router_attr_map, arn_router_key_p->vrid);
    end_p = cl_qmap_end(&arn_router_attributes_db.arn_router_attr_map);
    if (end_p != item_p) {
        SX_LOG_ERR("ARN router key: 0x%u, already exists in router attributes ARN DB.\n",
                   arn_router_key_p->vrid);
        err = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    /* Retrieve allocated memory for the new entry */
    arn_router_attr_entry_p =
        (sx_arn_router_attr_entry_t*)cl_qpool_get(&arn_router_attributes_db.arn_router_attr_pool);
    if (utils_check_pointer(arn_router_attr_entry_p, "arn_router_attr_entry_p")) {
        SX_LOG_ERR("No more resources in ARN router attributes pool.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    /* Insert item*/
    SX_MEM_CPY(arn_router_attr_entry_p->router_attr_data, *arn_router_attributes_p);
    cl_qmap_insert(&arn_router_attributes_db.arn_router_attr_map,
                   arn_router_key_p->vrid,
                   &arn_router_attr_entry_p->map_item);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_router_attr_get(const sx_arn_router_key_t  *arn_router_key_p,
                                          sx_arn_router_attributes_t *arn_router_attributes_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    const cl_map_item_t        *end_p = NULL;
    cl_map_item_t              *item_p = NULL;
    sx_arn_router_attr_entry_t *arn_router_attr_entry_p = NULL;

    SX_LOG_ENTER();

    /* Find entry in router attributes ARN map */
    item_p = cl_qmap_get(&arn_router_attributes_db.arn_router_attr_map, arn_router_key_p->vrid);
    end_p = cl_qmap_end(&arn_router_attributes_db.arn_router_attr_map);
    if (end_p == item_p) {
        SX_LOG_INF("ARN router attr not found. key: 0x%u\n",
                   arn_router_key_p->vrid);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /*Return data*/
    arn_router_attr_entry_p = PARENT_STRUCT(item_p, sx_arn_router_attr_entry_t, map_item);
    SX_MEM_CPY(*arn_router_attributes_p, arn_router_attr_entry_p->router_attr_data);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_router_attr_delete(const sx_arn_router_key_t *arn_router_key_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    cl_map_item_t              *item_p = NULL;
    sx_arn_router_attr_entry_t *arn_router_attr_entry_p = NULL;

    SX_LOG_ENTER();

    item_p = cl_qmap_remove(&arn_router_attributes_db.arn_router_attr_map, arn_router_key_p->vrid);
    if (cl_qmap_end(&arn_router_attributes_db.arn_router_attr_map) == item_p) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Router attribute key: 0x%u doesn't exist in ARN DB.\n", arn_router_key_p->vrid);
        goto out;
    }
    arn_router_attr_entry_p = PARENT_STRUCT(item_p, sx_arn_router_attr_entry_t, map_item);
    cl_qpool_put((&arn_router_attributes_db.arn_router_attr_pool), &(arn_router_attr_entry_p->pool_item));

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_db_arn_default_params_set(const sx_arn_default_params_t *arn_default_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_MEM_CPY(arn_default_params_db.default_params, *arn_default_params_p);

    return err;
}

sx_status_t sdk_ar_db_arn_default_params_reset()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    arn_default_params_db.default_params.arn_version = ARN_PARAM_DEFAULT_ARN_VERSION;
    arn_default_params_db.default_params.gen_shaper_min_time = ARN_PARAM_DEFAULT_GEN_SHAPER_MIN_TIME;
    arn_default_params_db.default_params.sip_prefix_match_type = ARN_PARAM_DEFAULT_SIP_PREFIX_MATCH_TYPE;
    arn_default_params_db.default_params.truncate = ARN_PARAM_DEFAULT_TRUNCATE;
    arn_default_params_db.default_params.truncate_size = ARN_PARAM_DEFAULT_TRUNCATE_SIZE;
    arn_default_params_db.default_params.udp_dest_port = ARN_PARAM_DEFAULT_UDP_DST_PORT;
    arn_default_params_db.default_params.udp_src_port = ARN_PARAM_DEFAULT_UDP_SRC_PORT;

    return err;
}

boolean_t sdk_ar_db_check_arn_router_attr_map_empty(void)
{
    return cl_is_qmap_empty(&(arn_router_attributes_db.arn_router_attr_map));
}

uint32_t sdk_ar_db_arn_router_attr_map_count(void)
{
    return cl_qmap_count(&(arn_router_attributes_db.arn_router_attr_map));
}

sx_status_t sdk_ar_db_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}
