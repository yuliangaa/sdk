/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __SDK_AR_BE_H__
#define __SDK_AR_BE_H__

#include "sx/sdk/sx_router.h"
/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/
#define LINK_UTILIZATION_GRANULARITY 200000
#define LINK_UTILIZATION_MAX         0x7FFFFFFF
#define INVALID_SHAPER_RATE_CONF     0x0

/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t sdk_ar_be_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t sdk_ar_be_init_set(const sx_ar_init_params_t *init_params_p);
sx_status_t sdk_ar_be_deinit_set();
sx_status_t sdk_ar_be_profile_set(const sx_access_cmd_t       cmd,
                                  const sx_ar_profile_key_t  *profile_key_p,
                                  const sx_ar_profile_attr_t *profile_attr_p);
sx_status_t sdk_ar_be_profile_get(const sx_ar_profile_key_t *profile_key_p,
                                  sx_ar_profile_attr_t      *profile_attr_p);
sx_status_t sdk_ar_be_arn_profile_set(const sx_access_cmd_t        cmd,
                                      const sx_ar_profile_key_t   *profile_key_p,
                                      const sx_arn_profile_attr_t *profile_attr_p);
sx_status_t sdk_ar_be_arn_profile_get(const sx_ar_profile_key_t *profile_key_p,
                                      sx_arn_profile_attr_t     *profile_attr_p);
sx_status_t sdk_ar_be_default_classification_get(sx_ar_classifier_action_t *classifier_action_p);
sx_status_t sdk_ar_be_default_classification_set(const sx_access_cmd_t            cmd,
                                                 const sx_ar_classifier_action_t *classifier_action_p);
sx_status_t sdk_ar_be_congestion_threshold_set(const sx_access_cmd_t                    cmd,
                                               const sx_ar_congestion_threshold_attr_t *congestion_thresh);
sx_status_t sdk_ar_be_congestion_threshold_get(sx_ar_congestion_threshold_attr_t *congestion_thresh);
sx_status_t sdk_ar_be_classification_set(const sx_access_cmd_t            cmd,
                                         const sx_ar_classifier_id_e      classifier_id,
                                         const sx_ar_classifier_attr_t   *attr_p,
                                         const sx_ar_classifier_action_t *action_p);
sx_status_t sdk_ar_be_classification_get(const sx_ar_classifier_id_e classifier_id,
                                         sx_ar_classifier_attr_t    *attr_p,
                                         sx_ar_classifier_action_t  *action_p);
sx_status_t sdk_ar_be_shaper_rate_set(const sx_access_cmd_t      cmd,
                                      const sx_ar_shaper_attr_t *shaper_attr_p);
sx_status_t sdk_ar_be_shaper_rate_get(sx_ar_shaper_attr_t *shaper_attr_p);
sx_status_t sdk_ar_be_link_utilization_threshold_set(const sx_access_cmd_t                cmd,
                                                     const sx_port_log_id_t               log_port,
                                                     const sx_ar_link_utilization_attr_t *link_util_attr_p);
sx_status_t sdk_ar_be_link_utilization_threshold_get(const sx_port_log_id_t         log_port,
                                                     sx_ar_link_utilization_attr_t *link_util_attr_p);
sx_status_t sdk_ar_be_counters_get(const sx_access_cmd_t    cmd,
                                   sx_ar_global_counters_t *ar_counters_p);
sx_status_t sdk_ar_be_arn_port_counters_get(const sx_access_cmd_t   cmd,
                                            const sx_port_log_id_t  log_port,
                                            sx_arn_port_counters_t *arn_port_counters_p);
sx_status_t sdk_ar_be_arn_counters_get(const sx_access_cmd_t cmd,
                                       sx_arn_counters_t    *arn_counters_p);
sx_status_t sdk_ar_be_arn_flow_status_get(const sx_access_cmd_t      cmd,
                                          sx_arn_flow_status_key_t  *flow_status_key_p,
                                          sx_arn_flow_status_data_t *flow_status_data_p);

sx_status_t sdk_ar_be_arn_defaults_set(const sx_access_cmd_t          cmd,
                                       const sx_arn_default_params_t *default_params_p);
sx_status_t sdk_ar_be_arn_defaults_get(const sx_access_cmd_t    cmd,
                                       sx_arn_default_params_t *default_params_p);
sx_status_t sdk_ar_be_arn_router_gen_set(const sx_access_cmd_t             cmd,
                                         const sx_arn_router_key_t        *router_key_p,
                                         const sx_arn_router_attributes_t *router_attr_p);
sx_status_t sdk_ar_be_arn_router_gen_get(const sx_arn_router_key_t  *router_key_p,
                                         sx_arn_router_attributes_t *router_attr_p);
sx_status_t sdk_ar_be_arn_get(const sx_access_cmd_t    cmd,
                              sx_arn_general_params_t *general_params_p);
sx_status_t sdk_ar_be_arn_set(const sx_access_cmd_t          cmd,
                              const sx_arn_general_params_t *general_params_p);
sx_status_t sdk_ar_be_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

#endif /* __SDK_AR_BE_H__ */
