/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef IB_ROUTER_MC_H_
#define IB_ROUTER_MC_H_


#include <sx/ib/sx_api_ib_router.h>
#include <sx/ib/sx_ib_router.h>
#include "ethl3/sx/router.h"

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/

typedef enum {
    INVALID_IB_TABLE_KEY_E = 0,
    IB_MC_TABLE_KEY_E      = 1,
} ib_route_table_key_type_e;

/**
 * ib_mc_route_table_key_t structure is used to store the key
 * for the mc_routes_map.
 */
typedef struct ib_mc_route_table_key {
    ib_route_table_key_type_e type;
    sx_ip_addr_t              s_addr;
    uint8_t                   s_addr_mask;
    sx_ip_addr_t              group_addr;
    uint8_t                   group_addr_mask;
} ib_mc_route_table_key_t;

/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/


/**
 * This function adds IB MC adjacency entries to a MC route
 * identified by [source_addr, mc_group_addr].
 */
sx_status_t ib_router_mc_egress_set(const sx_access_cmd_t       cmd,
                                    const sx_router_id_t        vrid,
                                    const sx_ip_prefix_t       *source_addr,
                                    const sx_ip_prefix_t       *mc_group_addr,
                                    const sx_router_interface_t ingress_rif,
                                    const uint32_t              neigh_param_num,
                                    const sx_mc_ipoib_adj_t    *mc_ipoib_egress_neigh_param_arr);

/**
 *  For a given route (identified by [source_addr,
 *  mc_group_addr]), This function returns the IPoIB MC adjacency
 *  entries attached as egress rif's.
 */
sx_status_t ib_router_mc_egress_get(const sx_router_id_t        vrid,
                                    const sx_ip_prefix_t       *source_addr,
                                    const sx_ip_prefix_t       *mc_group_addr,
                                    const sx_router_interface_t ingress_rif,
                                    uint32_t                   *neigh_param_num,
                                    sx_mc_ipoib_adj_t          *mc_ipoib_egress_neigh_param_arr);

sx_status_t ib_router_mc_init(router_db_neigh_params_t              *init_param,
                              const sx_vpi_router_resources_param_t *resources_param_p);

sx_status_t ib_router_mc_deinit();

sx_status_t ib_router_db_mc_entry_egress_neigh_move(routing_table_entry_t *dst_entry,
                                                    routing_table_entry_t *src_entry);

sx_status_t ib_router_mc_egress_neigh_count(const sx_router_id_t  vrid,
                                            const sx_ip_prefix_t *source_addr,
                                            const sx_ip_prefix_t *mc_group_addr,
                                            uint32_t             *egress_num);

sx_status_t ib_router_mc_egress_neigh_delete_all(const sx_router_id_t        vrid,
                                                 const sx_ip_prefix_t       *source_addr,
                                                 const sx_ip_prefix_t       *mc_group_addr,
                                                 const sx_router_interface_t ingress_rif);

sx_status_t ib_router_mc_verify_neigh_exist_on_rif(const sx_router_id_t        vrid,
                                                   const neigh_data_types_e    version,
                                                   const sx_router_interface_t rif);

sx_status_t ib_router_mc_verify_neigh_exist(const sx_router_id_t     vrid,
                                            const neigh_data_types_e neigh_type);

sx_utils_status_t ib_router_mc_adjacency_moved(bin_block_t* old_block, bin_block_t* new_block);
uint32_t ib_router_mc_adjacency_move_cost(bin_block_t* block);

#endif /* IB_ROUTER_MC_H_ */
