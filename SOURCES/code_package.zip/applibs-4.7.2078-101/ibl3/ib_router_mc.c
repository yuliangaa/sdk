/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/sx_log.h>
#include <complib/cl_dbg.h>
#include "ib_router_mc.h"
#include "sx_api/sx_api_internal.h"
#include <sx/utils/bin_allocator.h>
#include "ethl3/sx/router_db.h"
#include "ethl3/sx/router_mc.h"
#include "ethl3/common/router_utils.h"
#include "ib_router.h"
#include "ethl2/fdb_common.h"
#include "host_ifc/host_ifc.h"
#include "resource_manager/resource_manager_sdk_table.h"
#include <sx/sdk/sx_status_convertor.h>
#include "utils/sx_ip_utils.h"
#include "sx_reg_bulk/sx_reg_bulk.h"

#undef  __MODULE__
#define __MODULE__ ROUTER

/************************************************
 *  Global variables
 ***********************************************/

typedef struct ib_mc_adjacency_entry {
    cl_map_item_t              map_item;
    neigh_table_entry_common_t common;
    sx_mc_ipoib_adj_t          adj_param;
    neigh_data_types_e         neigh_type;
} ib_mc_adjacency_entry_t;

typedef struct ib_mc_route_entry {
    cl_pool_item_t          pool_item;
    cl_fmap_item_t          map_item;
    sx_ip_prefix_t          source_addr;
    sx_ip_prefix_t          mc_group_addr;
    sx_router_interface_t   ingress_rif;
    uint16_t                mlid_list[SXD_RIF_MAX];
    boolean_t               mlid_used[SXD_RIF_MAX];
    uint32_t                mlid_count;
    ib_mc_route_table_key_t ib_mc_route_table_key;
} ib_mc_route_entry_t;

typedef struct ib_mc_adjacency_data {
    cl_qpool_t *adjacency_pool;
    cl_qmap_t  *adjacency_map;
    cl_qpool_t  mc_routes_pool;
    cl_fmap_t  *mc_routes_map;
} ib_mc_adjacency_data_t;

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
extern uint8_t                 router_module_enabled;
extern ib_neigh_data_t        *ib_neigh_data[NUM_OF_NEIGH_DATA_TYPES_E];
static ib_mc_adjacency_data_t *ib_mc_adjacency_data[NUM_OF_NEIGH_DATA_TYPES_E] = {0};
static uint32_t                ib_mc_adjacency_size_s;
#define IB_MC_ADJACENCY_SIZE 2
/************************************************
 *  Local function declarations
 ***********************************************/
static cl_status_t __ib_router_db_mc_neigh_init(void *const             p_object,
                                                void                   *context,
                                                cl_pool_item_t ** const pp_pool_item);
static cl_status_t __ib_router_db_mc_route_init(void *const             p_object,
                                                void                   *context,
                                                cl_pool_item_t ** const pp_pool_item);
static sx_status_t __ib_router_db_mc_adjacency_find(sx_router_id_t            vrid,
                                                    sx_lid_t                  neigh_mlid,
                                                    neigh_data_types_e        neigh_type,
                                                    ib_mc_adjacency_entry_t **adj_entries);

sx_status_t __ib_router_db_mc_adjacency_add(sx_router_id_t            vrid,
                                            sx_mc_ipoib_adj_t         egress_neigh,
                                            neigh_data_types_e        neigh_type,
                                            ib_mc_adjacency_entry_t **adj_entries);

sx_status_t __ib_router_mc_adjacency_get(sx_router_id_t            vrid,
                                         const sx_ip_prefix_t     *mc_group_addr,
                                         const sx_mc_ipoib_adj_t  *egress_neigh_arr,
                                         neigh_data_types_e        neigh_type,
                                         uint32_t                  egress_neigh_num,
                                         ib_mc_adjacency_entry_t **adj_entries);

static sx_status_t __ib_router_mc_verify_adjacency_mc_route_unique(sx_router_id_t           vrid,
                                                                   const sx_ip_prefix_t    *source_addr,
                                                                   const sx_ip_prefix_t    *mc_group_addr,
                                                                   uint32_t                 egress_neigh_num,
                                                                   const sx_mc_ipoib_adj_t *egress_neigh_arr,
                                                                   neigh_data_types_e       neigh_type);
static sx_status_t __ib_router_mc_adjacency_remove(sx_router_id_t            vrid,
                                                   neigh_data_types_e        neigh_type,
                                                   uint32_t                  egress_neigh_num,
                                                   ib_mc_adjacency_entry_t **adj_entries);
static sx_status_t __ib_router_set_mc_neigh(sx_access_cmd_t           cmd,
                                            uint32_t                  adj_entries_num,
                                            ib_mc_adjacency_entry_t **adj_entries,
                                            neigh_data_types_e        neigh_type);
static sx_status_t __ib_router_mc_entry_egress_neigh_set(sx_access_cmd_t           cmd,
                                                         routing_table_entry_t    *entry,
                                                         ib_mc_adjacency_entry_t **adjacency_entries,
                                                         uint32_t                  adjacency_entries_num,
                                                         neigh_data_types_e        neigh_type);
static sx_status_t __ib_router_db_mc_route_add(sx_router_id_t           vrid,
                                               const sx_ip_prefix_t    *source_addr,
                                               const sx_ip_prefix_t    *mc_group_addr,
                                               sx_router_interface_t    ingress_rif,
                                               uint32_t                 egress_neigh_num,
                                               const sx_mc_ipoib_adj_t *egress_neigh_arr,
                                               neigh_data_types_e       neigh_type);
static sx_status_t __ib_router_db_mc_route_remove(sx_router_id_t        vrid,
                                                  const sx_ip_prefix_t *source_addr,
                                                  const sx_ip_prefix_t *mc_group_addr,
                                                  uint32_t              egress_neigh_num,
                                                  sx_lid_t             *mlid_list,
                                                  neigh_data_types_e    neigh_type);
static sx_status_t __ib_router_db_mc_neigh_get(sx_router_id_t        vrid,
                                               const sx_ip_prefix_t *source_addr,
                                               const sx_ip_prefix_t *mc_group_addr,
                                               uint32_t             *mlid_list_num,
                                               sx_lid_t             *mlid_list);
static sx_status_t __ib_router_mc_egress_neigh_set(sx_router_id_t           vrid,
                                                   const sx_ip_prefix_t    *source_addr,
                                                   const sx_ip_prefix_t    *mc_group_addr,
                                                   sx_router_interface_t    ingress_rif,
                                                   uint32_t                 egress_neigh_num,
                                                   const sx_mc_ipoib_adj_t *egress_neigh_arr);
static sx_status_t __ib_router_mc_egress_neigh_delete(sx_access_cmd_t       cmd,
                                                      sx_router_id_t        vrid,
                                                      const sx_ip_prefix_t *source_addr,
                                                      const sx_ip_prefix_t *mc_group_addr,
                                                      sx_router_interface_t ingress_rif,
                                                      sx_lid_t             *mlid_list,
                                                      uint32_t              egress_neigh_num);

sx_status_t __ib_router_db_mc_egress_neigh_get(const sx_router_id_t  vrid,
                                               const sx_ip_prefix_t *source_addr,
                                               const sx_ip_prefix_t *mc_group_addr,
                                               sx_router_interface_t ingress_rif,
                                               uint32_t             *neigh_param_num,
                                               sx_mc_ipoib_adj_t    *mc_ipoib_egress_neigh_param_arr);

static sx_status_t __ib_router_mc_free_resources(neigh_data_types_e neigh_type);

sx_status_t __router_ib_mc_device_ready_callback(adviser_event_e event_type,
                                                 void           *param);

static sx_status_t __ib_router_set_mc_neigh_sync_to_dev(sx_dev_id_t dev_id);
static sx_status_t __ib_router_mc_entry_egress_neigh_sync_to_dev(sxd_dev_id_t dev_id);

/************************************************
 *  Function implementations
 ***********************************************/
void build_ib_mc_router_table_key(const sx_ip_prefix_t    *source_addr,
                                  const sx_ip_prefix_t    *mc_group_addr,
                                  ib_mc_route_table_key_t *ib_mc_route_table_key)
{
    uint32_t s_addr_index, group_addr_index;

    if (source_addr) {
        __router_db_get_region_index(source_addr, &s_addr_index);
    } else {
        s_addr_index = 0;
    }

    if (mc_group_addr) {
        __router_db_get_region_index(mc_group_addr, &group_addr_index);
    } else {
        group_addr_index = 0;
    }

    ib_mc_route_table_key->type = IB_MC_TABLE_KEY_E;
    if ((source_addr == NULL) || (source_addr->version == SX_IP_VERSION_IPV4)) {
        ib_mc_route_table_key->s_addr.version = SX_IP_VERSION_IPV4;
        ib_mc_route_table_key->s_addr.addr.ipv4.s_addr = source_addr ? source_addr->prefix.ipv4.addr.s_addr : 0;
        ib_mc_route_table_key->s_addr_mask = (uint8_t)s_addr_index;

        ib_mc_route_table_key->group_addr.version = SX_IP_VERSION_IPV4;
        ib_mc_route_table_key->group_addr.addr.ipv4.s_addr =
            mc_group_addr ? mc_group_addr->prefix.ipv4.addr.s_addr : 0;
        ib_mc_route_table_key->group_addr_mask = (uint8_t)group_addr_index;
    } else { /*IPV6*/
        ib_mc_route_table_key->s_addr.version = SX_IP_VERSION_IPV6;
        ib_mc_route_table_key->s_addr.addr.ipv6.s6_addr32[0] =
            source_addr->prefix.ipv6.addr.s6_addr32[0];
        ib_mc_route_table_key->s_addr.addr.ipv6.s6_addr32[1] =
            source_addr->prefix.ipv6.addr.s6_addr32[1];
        ib_mc_route_table_key->s_addr.addr.ipv6.s6_addr32[2] =
            source_addr->prefix.ipv6.addr.s6_addr32[2];
        ib_mc_route_table_key->s_addr.addr.ipv6.s6_addr32[3] =
            source_addr->prefix.ipv6.addr.s6_addr32[3];
        ib_mc_route_table_key->s_addr_mask = (uint8_t)s_addr_index;

        ib_mc_route_table_key->group_addr.version = SX_IP_VERSION_IPV6;
        ib_mc_route_table_key->group_addr.addr.ipv6.s6_addr32[0] =
            mc_group_addr ? mc_group_addr->prefix.ipv6.addr.s6_addr32[0] : 0;
        ib_mc_route_table_key->group_addr.addr.ipv6.s6_addr32[1] =
            mc_group_addr ? mc_group_addr->prefix.ipv6.addr.s6_addr32[1] : 0;
        ib_mc_route_table_key->group_addr.addr.ipv6.s6_addr32[2] =
            mc_group_addr ? mc_group_addr->prefix.ipv6.addr.s6_addr32[2] : 0;
        ib_mc_route_table_key->group_addr.addr.ipv6.s6_addr32[3] =
            mc_group_addr ? mc_group_addr->prefix.ipv6.addr.s6_addr32[3] : 0;
        ib_mc_route_table_key->group_addr_mask = (uint8_t)group_addr_index;
    }
}

static cl_status_t __ib_router_db_mc_neigh_init(void *const             p_object,
                                                void                   *context,
                                                cl_pool_item_t ** const pp_pool_item)
{
    ib_mc_adjacency_entry_t *ib_mc_neigh = (ib_mc_adjacency_entry_t*)p_object;

    UNUSED_PARAM(context);
    SX_LOG_ENTER();

    bin_block_init(&ib_mc_neigh->common.adjacency_block);

    *pp_pool_item = &(ib_mc_neigh->common.pool_item);

    return SX_STATUS_SUCCESS;
}

static cl_status_t __ib_router_db_mc_route_init(void *const             p_object,
                                                void                   *context,
                                                cl_pool_item_t ** const pp_pool_item)
{
    ib_mc_route_entry_t *ib_mc_route = (ib_mc_route_entry_t*)p_object;

    UNUSED_PARAM(context);
    SX_LOG_ENTER();

    *pp_pool_item = &(ib_mc_route->pool_item);

    return SX_STATUS_SUCCESS;
}

int __ib_mc_table_key_compare(const void *const p_key1, const void *const p_key2)
{
    ib_mc_route_table_key_t ib_mc_route_table_key1, ib_mc_route_table_key2;
    int                     res1, res2, res3, res4 = 0;

    memcpy(&ib_mc_route_table_key1, p_key1, sizeof(ib_mc_route_table_key_t));
    memcpy(&ib_mc_route_table_key2, p_key2, sizeof(ib_mc_route_table_key_t));

    assert(ib_mc_route_table_key1.type == IB_MC_TABLE_KEY_E && ib_mc_route_table_key2.type == IB_MC_TABLE_KEY_E);

    res1 = __ip_addr_compare(&(ib_mc_route_table_key1.s_addr), &(ib_mc_route_table_key2.s_addr));
    res3 = __ip_addr_compare(&(ib_mc_route_table_key1.group_addr), &(ib_mc_route_table_key2.group_addr));

    res2 = mask_equal(ib_mc_route_table_key1.s_addr_mask, ib_mc_route_table_key2.s_addr_mask);
    res4 = mask_equal(ib_mc_route_table_key1.group_addr_mask, ib_mc_route_table_key2.group_addr_mask);

    if (res1 != 0) {
        return res1;
    } else if (res2 != 0) {
        return res2;
    } else if (res3 != 0) {
        return res3;
    } else if (res4 != 0) {
        return res4;
    }
    return 0;
}

sx_status_t ib_router_mc_version_init(neigh_data_types_e neigh_type,
                                      uint32_t           ib_mc_neigh_db_size,
                                      uint32_t           mc_routes_num)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_router_id_t vrid = 0;
    const uint32_t adjacency_data_arrays_size = rm_resource_global.router_vrid_max -
                                                ROUTER_VRID_MIN + 1;
    cl_status_t cl_st = CL_SUCCESS;

    SX_LOG_ENTER();

    err = utils_clr_memory_get((void**)(&ib_mc_adjacency_data[neigh_type]), 1, sizeof(ib_mc_adjacency_data_t),
                               UTILS_MEM_TYPE_ID_ROUTER_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for the ib MC neigh table DB.\n");
        goto out;
    }

    /* Allocate all the adjacency data arrays for the current neighbor type */
    ib_mc_adjacency_data[neigh_type]->adjacency_pool =
        (cl_qpool_t*)cl_malloc(sizeof(cl_qpool_t) * adjacency_data_arrays_size);
    if (!ib_mc_adjacency_data[neigh_type]->adjacency_pool) {
        SX_LOG_ERR("Failed to allocate memory for the IB adjacency pool array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    memset(ib_mc_adjacency_data[neigh_type]->adjacency_pool, 0,
           sizeof(cl_qpool_t) * adjacency_data_arrays_size);
    ib_mc_adjacency_data[neigh_type]->adjacency_map =
        (cl_qmap_t*)cl_malloc(sizeof(cl_qmap_t) * adjacency_data_arrays_size);
    if (!ib_mc_adjacency_data[neigh_type]->adjacency_map) {
        SX_LOG_ERR("Failed to allocate memory for the IB adjacency map array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    memset(ib_mc_adjacency_data[neigh_type]->adjacency_map, 0,
           sizeof(cl_qmap_t) * adjacency_data_arrays_size);
    ib_mc_adjacency_data[neigh_type]->mc_routes_map =
        (cl_fmap_t*)cl_malloc(sizeof(cl_fmap_t) * adjacency_data_arrays_size);
    if (!ib_mc_adjacency_data[neigh_type]->mc_routes_map) {
        SX_LOG_ERR("Failed to allocate memory for the IB MC routes map array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    memset(ib_mc_adjacency_data[neigh_type]->mc_routes_map, 0,
           sizeof(cl_fmap_t) * adjacency_data_arrays_size);

    for (vrid = ROUTER_VRID_MIN; vrid < router_init_params_s.virtual_routers_num; ++vrid) {
        cl_qmap_init(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]));

        /* the neigh pool size isn't limited */
        cl_st = CL_QPOOL_INIT(&(ib_mc_adjacency_data[neigh_type]->adjacency_pool[vrid]),
                              ib_mc_neigh_db_size, 0, ib_mc_neigh_db_size, sizeof(ib_mc_adjacency_entry_t),
                              __ib_router_db_mc_neigh_init, NULL, NULL);
        if (cl_st != CL_SUCCESS) {
            SX_LOG_ERR("Failed to initialize neighbors pool.\n");
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }

        cl_fmap_init(&(ib_mc_adjacency_data[neigh_type]->mc_routes_map[vrid]), __ib_mc_table_key_compare);
    }
    cl_st = CL_QPOOL_INIT(&(ib_mc_adjacency_data[neigh_type]->mc_routes_pool),
                          mc_routes_num, mc_routes_num, 0, sizeof(ib_mc_route_entry_t),
                          __ib_router_db_mc_route_init, NULL, NULL);
    if (cl_st != CL_SUCCESS) {
        SX_LOG_ERR("Failed to initialize MC routes pool.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t ib_router_mc_init(router_db_neigh_params_t              *ib_neigh_params,
                              const sx_vpi_router_resources_param_t *resources_param_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    ib_mc_adjacency_size_s = 0;
    if (router_init_params_s.mc_version & SX_IP_VERSION_IPV4) {
        ib_mc_adjacency_size_s += resources_param_p->max_ipv4_mc_route_entries;
    }
    if (router_init_params_s.mc_version & SX_IP_VERSION_IPV6) {
        ib_mc_adjacency_size_s += resources_param_p->max_ipv6_mc_route_entries;
    }
    ALIGN_UP(ib_mc_adjacency_size_s, NUM_OF_ENTRIES_PER_PAGE);

    if (router_init_params_s.mc_version & SX_IP_VERSION_IPV4) {
        err = ib_router_mc_version_init(IPV4_NEIGH_E,
                                        ib_neigh_params->ipv4_max_neigh_num,
                                        rm_resource_global.router_ipv4_mc_max);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to initiate IB MC IPv4 DB.\n");
            goto out;
        }
    }

    if (router_init_params_s.mc_version & SX_IP_VERSION_IPV6) {
        err = ib_router_mc_version_init(IPV6_NEIGH_E,
                                        ib_neigh_params->ipv6_max_neigh_num,
                                        rm_resource_global.router_ipv6_mc_max);

        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to initiate IB MC IPv6 DB.\n");
            goto out;
        }
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 __router_ib_mc_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise , error: %s \n", sx_status_str(err));
        return err;
    }
    router_set_verify_mc_neigh_exist_func((void*)ib_router_mc_verify_neigh_exist);

out:
    SX_LOG_EXIT();
    return err;
}
sx_status_t ib_router_mc_verify_neigh_exist(const sx_router_id_t vrid, const neigh_data_types_e neigh_type)
{
    uint32_t    num_of_entries = 0;
    sx_status_t err = SX_STATUS_ENTRY_NOT_FOUND;

    SX_LOG_ENTER();

    if (ib_mc_adjacency_data[neigh_type]) {
        num_of_entries = cl_qmap_count(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]));

        if (num_of_entries != 0) {
            err = SX_STATUS_SUCCESS;
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t ib_router_mc_verify_neigh_exist_on_rif(const sx_router_id_t        vrid,
                                                   const neigh_data_types_e    version,
                                                   const sx_router_interface_t rif)
{
    cl_map_item_t           *map_item = NULL;
    const cl_map_item_t     *map_end = NULL;
    ib_mc_adjacency_entry_t *neigh = NULL;
    sx_status_t              err = SX_STATUS_ENTRY_NOT_FOUND;

    SX_LOG_ENTER();

    map_item = cl_qmap_head(&(ib_mc_adjacency_data[version]->adjacency_map[vrid]));
    map_end = cl_qmap_end(&(ib_mc_adjacency_data[version]->adjacency_map[vrid]));

    while (map_item != map_end) {
        neigh = PARENT_STRUCT(map_item, ib_mc_adjacency_entry_t, map_item);
        map_item = cl_qmap_next(map_item);

        if (neigh->adj_param.rif == rif) {
            err = SX_STATUS_SUCCESS;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_mc_free_resources(neigh_data_types_e neigh_type)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_router_id_t           vrid;
    ib_mc_adjacency_entry_t *adj_entry;
    cl_map_item_t           *map_item = NULL;
    const cl_map_item_t     *map_end = NULL;

    SX_LOG_ENTER();

    for (vrid = ROUTER_VRID_MIN; vrid < router_init_params_s.virtual_routers_num; ++vrid) {
        map_item = cl_qmap_head(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]));
        map_end = cl_qmap_end(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]));

        while (map_item != map_end) {
            adj_entry = PARENT_STRUCT(map_item, ib_mc_adjacency_entry_t, map_item);

            err = __ib_router_set_mc_neigh(SX_ACCESS_CMD_DELETE, 1, &adj_entry, neigh_type);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Could not remove MC neighbor.\n");
                goto out;
            }

            map_item = cl_qmap_next(map_item);

            err = __ib_router_mc_adjacency_remove(vrid, neigh_type, 1, &adj_entry);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Could not remove MC neighbors from DB.\n");
                goto out;
            }
        }
    }
out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t ib_router_mc_deinit()
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_router_id_t vrid;

    SX_LOG_ENTER();

    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 __router_ib_mc_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise , error: %s \n", sx_status_str(err));
    }

    if (router_init_params_s.mc_version & SX_IP_VERSION_IPV4) {
        err = __ib_router_mc_free_resources(IPV4_NEIGH_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to free all IPv4 IB mc router DB.\n");
            goto out;
        }
        for (vrid = ROUTER_VRID_MIN; vrid < router_init_params_s.virtual_routers_num; ++vrid) {
            CL_QPOOL_DESTROY(&(ib_mc_adjacency_data[IPV4_NEIGH_E]->adjacency_pool[vrid]));
        }
        CL_QPOOL_DESTROY(&(ib_mc_adjacency_data[IPV4_NEIGH_E]->mc_routes_pool));

        /* Free all the IPV4 adjacency data arrays */
        CL_FREE_N_NULL(ib_mc_adjacency_data[IPV4_NEIGH_E]->adjacency_pool);
        CL_FREE_N_NULL(ib_mc_adjacency_data[IPV4_NEIGH_E]->adjacency_map);
        CL_FREE_N_NULL(ib_mc_adjacency_data[IPV4_NEIGH_E]->mc_routes_map);

        err = utils_memory_put((void*)(ib_mc_adjacency_data[IPV4_NEIGH_E]), UTILS_MEM_TYPE_ID_ROUTER_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to free memory for the IPv4 ib MC neigh table DB.\n");
            goto out;
        }
    }
    if (router_init_params_s.mc_version & SX_IP_VERSION_IPV6) {
        err = __ib_router_mc_free_resources(IPV6_NEIGH_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to free all IPv6 IB mc router DB.\n");
            goto out;
        }
        for (vrid = ROUTER_VRID_MIN; vrid < router_init_params_s.virtual_routers_num; ++vrid) {
            CL_QPOOL_DESTROY(&(ib_mc_adjacency_data[IPV6_NEIGH_E]->adjacency_pool[vrid]));
        }
        CL_QPOOL_DESTROY(&(ib_mc_adjacency_data[IPV6_NEIGH_E]->mc_routes_pool));

        /* Free all the IPV6 adjacency data arrays */
        CL_FREE_N_NULL(ib_mc_adjacency_data[IPV6_NEIGH_E]->adjacency_pool);
        CL_FREE_N_NULL(ib_mc_adjacency_data[IPV6_NEIGH_E]->adjacency_map);
        CL_FREE_N_NULL(ib_mc_adjacency_data[IPV6_NEIGH_E]->mc_routes_map);

        err = utils_memory_put((void*)(ib_mc_adjacency_data[IPV6_NEIGH_E]), UTILS_MEM_TYPE_ID_ROUTER_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to free memory for the IPv6 ib MC neigh table DB.\n");
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_db_mc_adjacency_find(sx_router_id_t            vrid,
                                                    sx_lid_t                  neigh_mlid,
                                                    neigh_data_types_e        neigh_type,
                                                    ib_mc_adjacency_entry_t **adj_entries)
{
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;
    sx_status_t          err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    map_item = cl_qmap_get(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]),
                           neigh_mlid);
    map_end = cl_qmap_end(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]));

    if (map_item == map_end) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_DEBUG, "Could not find MC neigh [mlid %u] in lookup map\n", neigh_mlid);
        goto out;
    }

    *adj_entries = PARENT_STRUCT(map_item, ib_mc_adjacency_entry_t, map_item);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __ib_router_db_mc_adjacency_add(sx_router_id_t            vrid,
                                            sx_mc_ipoib_adj_t         egress_neigh,
                                            neigh_data_types_e        neigh_type,
                                            ib_mc_adjacency_entry_t **adj_entries)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    cl_pool_item_t * pool_item = NULL;

    SX_LOG_ENTER();

    /* prepare a item for lookup table  */
    pool_item = cl_qpool_get(&(ib_mc_adjacency_data[neigh_type]->adjacency_pool[vrid]));
    if (pool_item == NULL) {
        SX_LOG(SX_LOG_DEBUG, "Could not find free IB mc neighbor entry at the MC routing DB.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    *adj_entries = PARENT_STRUCT(pool_item, ib_mc_adjacency_entry_t, common.pool_item);
    (*adj_entries)->neigh_type = neigh_type;
    (*adj_entries)->common.vrid = vrid;
    (*adj_entries)->common.remove_neigh_cb = NULL;
    (*adj_entries)->common.state = SX_NEIGH_STATE_ALLOC_BY_SDK_E;
    bin_block_init(&((*adj_entries)->common.adjacency_block));
    (*adj_entries)->common.offset = SX_NEIGH_OFFSET_INVALID;
    (*adj_entries)->common.routes_use = 0;

    cl_qmap_insert(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]),
                   egress_neigh.mlid, &((*adj_entries)->map_item));

out:

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_mc_verify_adjacency_mc_route_unique(sx_router_id_t           vrid,
                                                                   const sx_ip_prefix_t    *source_addr,
                                                                   const sx_ip_prefix_t    *mc_group_addr,
                                                                   uint32_t                 egress_neigh_num,
                                                                   const sx_mc_ipoib_adj_t *egress_neigh_arr,
                                                                   neigh_data_types_e       neigh_type)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_status_t               mem_err = SX_STATUS_SUCCESS;
    sx_lid_t                 *mlid_list = NULL;
    ib_mc_adjacency_entry_t** adj_list = NULL;
    uint32_t                  mlid_list_num = 0;
    uint32_t                  i = 0, j = 0;
    char                      ip_prefix_str[FORMAT_BUFFER_SIZE] = {0};
    char                      ip_prefix_str2[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    M_UTILS_CLR_MEM_GET(&adj_list,
                        rm_resource_global.router_rifs_max,
                        sizeof(ib_mc_adjacency_entry_t*),
                        UTILS_MEM_TYPE_ID_ROUTER_E,
                        "Neighbor information",
                        err);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot allocate local stack memory\n");
        goto out;
    }

    /* Allocate the mlid list array */
    mlid_list = (sx_lid_t*)cl_malloc(sizeof(sx_lid_t) *
                                     rm_resource_global.router_rifs_max);
    if (!mlid_list) {
        SX_LOG(SX_LOG_ERROR, "Failed to allocate memory for the mlid list array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    err = __ib_router_db_mc_neigh_get(vrid, source_addr, mc_group_addr, &mlid_list_num, mlid_list);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not retrieve all ipoib mc neighbors belonging to MC route.\n");
        goto out;
    }

    for (i = 0; i < mlid_list_num; i++) {
        err = __ib_router_db_mc_adjacency_find(vrid, mlid_list[i], neigh_type, &(adj_list[i]));
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not retrieve all ipoib mc neighbors.\n");
            goto out;
        }
    }

    for (i = 0; i < mlid_list_num; i++) {
        for (j = 0; j < egress_neigh_num; j++) {
            if (adj_list[i]->adj_param.rif == egress_neigh_arr[j].rif) {
                SX_LOG(SX_LOG_ERROR, "Adjacency entry with rif %u, is already associated to MC route [%s:%s].\n",
                       egress_neigh_arr[j].rif,
                       format_prefix(source_addr, ip_prefix_str),
                       format_prefix(mc_group_addr, ip_prefix_str2));
                err = SX_STATUS_ENTRY_ALREADY_EXISTS;
                goto out;
            }
            if (adj_list[i]->adj_param.mlid == egress_neigh_arr[j].mlid) {
                SX_LOG(SX_LOG_ERROR, "Adjacency entry with Mlid %u, is already associated to MC route [%s:%s].\n",
                       egress_neigh_arr[j].mlid,
                       format_prefix(source_addr, ip_prefix_str),
                       format_prefix(mc_group_addr, ip_prefix_str2));
                err = SX_STATUS_ENTRY_ALREADY_EXISTS;
                goto out;
            }
        }
    }
out:
    if (adj_list != NULL) {
        M_UTILS_MEM_PUT(adj_list, UTILS_MEM_TYPE_ID_ROUTER_E, "Neighbor information", mem_err);
        if (mem_err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Error deallocating local stack memory\n");
        }
    }
    if (mlid_list != NULL) {
        CL_FREE_N_NULL(mlid_list);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t __ib_router_mc_adjacency_get(sx_router_id_t            vrid,
                                         const sx_ip_prefix_t     *mc_group_addr,
                                         const sx_mc_ipoib_adj_t  *egress_neigh_arr,
                                         neigh_data_types_e        neigh_type,
                                         uint32_t                  egress_neigh_num,
                                         ib_mc_adjacency_entry_t **adj_entries)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_status_t              rollback_err = SX_STATUS_SUCCESS;
    sx_utils_status_t        utils_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t                 i = 0;
    adjacency_table_entry_t* entry = NULL;
    uint32_t                 adj_index = 0;
    uint32_t                 mc_adj_add = FALSE;

    SX_LOG_ENTER();

    for (i = 0; i < egress_neigh_num; i++) {
        err = __ib_router_db_mc_adjacency_find(vrid, egress_neigh_arr[i].mlid, neigh_type, &(adj_entries[i]));
        if (err == SX_STATUS_SUCCESS) {
            continue;
        }
        mc_adj_add = FALSE;
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            err = __ib_router_db_mc_adjacency_add(vrid, egress_neigh_arr[i], neigh_type, &(adj_entries[i]));
            mc_adj_add = TRUE;
        }
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not add MC neighbor to DB.\n");
            mc_adj_add = FALSE;
            goto out;
        }
        adj_entries[i]->adj_param.rif = egress_neigh_arr[i].rif;
        adj_entries[i]->common.vrid = vrid;
        adj_entries[i]->common.rif = egress_neigh_arr[i].rif;
        adj_entries[i]->common.ip_addr.version = mc_group_addr->version;
        adj_entries[i]->adj_param.mlid = egress_neigh_arr[i].mlid;
        adj_entries[i]->adj_param.sl = egress_neigh_arr[i].sl;
        adj_entries[i]->adj_param.hoplimit = egress_neigh_arr[i].hoplimit;
        adj_entries[i]->adj_param.tclass = egress_neigh_arr[i].tclass;

        CL_ASSERT(!bin_is_block_valid(&adj_entries[i]->common.adjacency_block));

        /*Allocate an adjacency block*/
        adj_entries[i]->common.adjacency_block.size = IB_MC_ADJACENCY_SIZE;

        err = router_db_allocate_adjacency(&adj_entries[i]->common.adjacency_block);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_NOTICE, "Could not find free MC IB adjacency entry.\n");
            err = SX_STATUS_NO_RESOURCES;
            /* Rollback adjacency add */
            if (mc_adj_add == TRUE) {
                cl_qmap_remove(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]),
                               adj_entries[i]->adj_param.mlid);
                cl_qpool_put(&(ib_mc_adjacency_data[neigh_type]->adjacency_pool[vrid]),
                             &(adj_entries[i]->common.pool_item));
            }
            bin_block_init(&adj_entries[i]->common.adjacency_block);
            goto out;
        }

        /* Mark this entry in the array */
        utils_err = bin_get_slot_index(
            router_db_adjacency_allocator_get(), &adj_entries[i]->common.adjacency_block, &adj_index);
        if (utils_err != SX_UTILS_STATUS_SUCCESS) {
            rollback_err = router_db_deallocate_adjacency(&adj_entries[i]->common.adjacency_block);
            if (rollback_err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Could not remove IB MC adjacency entry after failure.\n");
            }
            err = SX_UTILS_STATUS_TO_SX_STATUS(utils_err);
            SX_LOG(SX_LOG_ERROR, "Cannot determine block index. IB MC Neigh add failed.\n");
            goto out;
        }

        entry = router_db_adjacency_entry_get(adj_index);

        CL_ASSERT(!entry->used);
        entry->used = TRUE;
        entry->type = (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_MULTICAST_E;
        entry->block_size = adj_entries[i]->common.adjacency_block.size;
        entry->content.other = adj_entries[i];

        /*Mark this entry as a reserved entry*/
        adj_index++;
        entry = router_db_adjacency_entry_get(adj_index);
        CL_ASSERT(!entry->used);
        entry->used = TRUE;
        entry->type = (adjacency_entry_type_e)ADJACENCY_ENTRY_RESERVED_E;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_mc_adjacency_remove(sx_router_id_t            vrid,
                                                   neigh_data_types_e        neigh_type,
                                                   uint32_t                  egress_neigh_num,
                                                   ib_mc_adjacency_entry_t **adj_entries)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint32_t                 i = 0;
    cl_map_item_t           *map_item_p = NULL;
    const cl_map_item_t     *map_end = NULL;
    adjacency_table_entry_t* entry = NULL;
    sx_utils_status_t        utils_err;
    uint32_t                 adj_index = 0;

    SX_LOG_ENTER();
    for (i = 0; i < egress_neigh_num; i++) {
        if (adj_entries[i]->common.routes_use) {
            continue;
        }

        map_item_p = cl_qmap_remove(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]),
                                    adj_entries[i]->adj_param.mlid);
        map_end = cl_qmap_end(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]));
        if (map_item_p == map_end) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG(SX_LOG_ERROR, "IB MC neighbor entry delete failed.\n");
            goto  out;
        }

        adj_entries[i]->adj_param.rif = 0;
        adj_entries[i]->common.rif = 0;
        memset(&adj_entries[i]->adj_param, 0, sizeof(adj_entries[i]->adj_param));
        adj_entries[i]->common.routes_use = 0;

        utils_err = bin_get_slot_index(
            router_db_adjacency_allocator_get(), &adj_entries[i]->common.adjacency_block, &adj_index);
        if (utils_err != SX_UTILS_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Cannot determine block index. IB MC Neigh entry delete failed.\n");
            err = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        /* Mark this entry in the adjacency array */
        entry = router_db_adjacency_entry_get(adj_index);
        CL_ASSERT(entry->used);
        CL_ASSERT(entry->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_MULTICAST_E);
        CL_ASSERT(entry->content.other == adj_entries[i]);
        entry->used = FALSE;
        entry->content.other = NULL;

        /*Mark this entry as a reserved entry*/
        adj_index++;
        entry = router_db_adjacency_entry_get(adj_index);
        CL_ASSERT(entry->used);
        CL_ASSERT(entry->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_RESERVED_E);
        entry->used = FALSE;

        if (bin_is_block_valid(&adj_entries[i]->common.adjacency_block)) {
            bin_free(router_db_adjacency_allocator_get(), &adj_entries[i]->common.adjacency_block);
            bin_block_init(&adj_entries[i]->common.adjacency_block);
        }

        cl_qpool_put(&(ib_mc_adjacency_data[neigh_type]->adjacency_pool[vrid]), &(adj_entries[i]->common.pool_item));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_utils_status_t ib_router_mc_adjacency_moved(bin_block_t* old_block, bin_block_t* new_block)
{
    uint32_t                 old_index, new_index;
    sx_utils_status_t        utils_err;
    sx_status_t              err = SX_STATUS_SUCCESS;
    adjacency_table_entry_t *old_adj = NULL, *new_adj = NULL;
    ib_mc_adjacency_entry_t* entry;
    cl_fmap_item_t          *map_item = NULL;
    const cl_fmap_item_t    *map_end = NULL;
    ib_mc_route_entry_t    * ib_mc_route_entry;
    sx_lid_t                *mlid_list = NULL;
    uint32_t                 mlid_list_num = 0;
    uint32_t                 i;
    routing_table_entry_t  * route_entry;
    char                     ip_prefix_str[FORMAT_BUFFER_SIZE] = {0};
    char                     ip_prefix_str2[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    /* Allocate the mlid list array */
    mlid_list = (sx_lid_t*)cl_malloc(sizeof(sx_lid_t) *
                                     rm_resource_global.router_rifs_max);
    if (!mlid_list) {
        SX_LOG(SX_LOG_ERROR, "Failed to allocate memory for the mlid list array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    utils_err = bin_get_slot_index(router_db_adjacency_allocator_get(), old_block, &old_index);
    CL_ASSERT(utils_err == SX_UTILS_STATUS_SUCCESS);
    if (utils_err != SX_UTILS_STATUS_SUCCESS) {
        err = SX_UTILS_STATUS_TO_SX_STATUS(utils_err);
        SX_LOG(SX_LOG_ERROR, "Cannot relocate IB MC adjacency. cannot get old block index\n");
        goto out;
    }
    old_adj = router_db_adjacency_entry_get(old_index);
    CL_ASSERT(old_adj->used);
    CL_ASSERT(old_adj->block_size == old_block->size);
    CL_ASSERT(old_adj->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_MULTICAST_E);
    CL_ASSERT(old_block->size == IB_MC_ADJACENCY_SIZE); /*IB_MULTICAST consumes two spaces in the Tcam table*/

    utils_err = bin_get_slot_index(router_db_adjacency_allocator_get(), new_block, &new_index);
    CL_ASSERT(utils_err == SX_UTILS_STATUS_SUCCESS);
    if (utils_err != SX_UTILS_STATUS_SUCCESS) {
        err = SX_UTILS_STATUS_TO_SX_STATUS(utils_err);
        SX_LOG(SX_LOG_ERROR, "Cannot relocate. cannot get new block index\n");
        goto out;
    }
    new_adj = router_db_adjacency_entry_get(new_index);
    CL_ASSERT(!new_adj->used);
    if (new_adj->used) {
        SX_LOG(SX_LOG_ERROR, "Cannot relocate IB MC adjacency. New index %u is already taken\n", new_index);
        err = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    CL_ASSERT(old_index != new_index);

    /* Note: At this point, the hardware has only the old RATR. */

    entry = (ib_mc_adjacency_entry_t*)old_adj->content.other;
    if (bin_block_compare(old_block, &entry->common.adjacency_block) != 0) {
        goto out;
    }
    CL_ASSERT(entry->common.routes_use > 0);

    /* Write the new RATR -- Only if the old one was already written */
    if (entry->common.routes_use > 0) {
        entry->common.adjacency_block = *new_block;
        err = __ib_router_set_mc_neigh(SX_ACCESS_CMD_CREATE, 1, &entry, entry->neigh_type);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to move IB MC RATR entry to new index %u\n", new_index);
            entry->common.adjacency_block = *old_block;
            goto out;
        }
        entry->common.adjacency_block = *old_block;

        /* Find all those MC routes which use this adjacency, and update their RIGRs */
        map_item = cl_fmap_head(&(ib_mc_adjacency_data[entry->neigh_type]->mc_routes_map[entry->common.vrid]));
        map_end = cl_fmap_end(&(ib_mc_adjacency_data[entry->neigh_type]->mc_routes_map[entry->common.vrid]));

        while (map_item != map_end) {
            ib_mc_route_entry = PARENT_STRUCT(map_item, ib_mc_route_entry_t, map_item);
            map_item = cl_fmap_next(map_item);

            err = router_db_mc_rt_lookup_map_find(entry->common.vrid,
                                                  &ib_mc_route_entry->source_addr,
                                                  &ib_mc_route_entry->mc_group_addr,
                                                  ib_mc_route_entry->ingress_rif,
                                                  &route_entry);
            if (route_entry == NULL) {
                SX_LOG(SX_LOG_ERROR, "Could not find entry [%s:%s:%u] in MC RT DB: %s \n",
                       format_prefix(&ib_mc_route_entry->source_addr, ip_prefix_str),
                       format_prefix(&ib_mc_route_entry->mc_group_addr, ip_prefix_str2),
                       ib_mc_route_entry->ingress_rif, sx_status_str(err));
                continue;
            }

            err = __ib_router_db_mc_neigh_get(entry->common.vrid,
                                              &ib_mc_route_entry->source_addr,
                                              &ib_mc_route_entry->mc_group_addr,
                                              &mlid_list_num,
                                              mlid_list);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Could not retrieve ipoib mc neighbors belonging to MC route.\n");
                continue;
            }

            for (i = 0; i < mlid_list_num; i++) {
                /* Skip any other entries */
                if (mlid_list[i] != entry->adj_param.mlid) {
                    continue;
                }

                /* Found this entry in the IB MC route's neighbors. Update the RIGR */
                entry->common.adjacency_block = *new_block;
                err = __ib_router_mc_entry_egress_neigh_set(SX_ACCESS_CMD_EDIT,
                                                            route_entry,
                                                            &entry,
                                                            1,
                                                            entry->neigh_type);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG(SX_LOG_ERROR, "Could not add IB MC route neighbor for adjacency move.\n");
                    entry->common.adjacency_block = *old_block;
                    goto out;
                }

                /* No need to look at other neighbors of this same MC route */
                break;
            }
        }

        /* Delete the old RATR -- Only if it was written in FW*/
        entry->common.adjacency_block = *old_block;
        err = __ib_router_set_mc_neigh(SX_ACCESS_CMD_DESTROY, 1, &entry, entry->neigh_type);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to move IB MC RATR entry to new index %u\n", new_index);
            goto out;
        }
    }
    entry->common.adjacency_block = *new_block;

    /* Update the array */
    new_adj->used = TRUE;
    new_adj->type = (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_MULTICAST_E;
    new_adj->block_size = new_block->size;
    new_adj->content.neigh_object = old_adj->content.neigh_object;
    new_adj->content.other = old_adj->content.other;

    /*Update the new reserved entry*/
    new_index++;
    new_adj = router_db_adjacency_entry_get(new_index);
    CL_ASSERT(!new_adj->used);
    new_adj->used = TRUE;
    new_adj->type = (adjacency_entry_type_e)ADJACENCY_ENTRY_RESERVED_E;

    old_adj->used = FALSE;

    /*Update the old reserved entry*/
    old_index++;
    old_adj = router_db_adjacency_entry_get(old_index);
    CL_ASSERT(old_adj->used);
    old_adj->used = FALSE;

    err = SX_STATUS_SUCCESS;
out:
    if (mlid_list != NULL) {
        CL_FREE_N_NULL(mlid_list);
    }
    return SX_STATUS_TO_SX_UTILS_STATUS(err);
}

uint32_t ib_router_mc_adjacency_move_cost(bin_block_t* block)
{
    uint32_t                 old_index;
    sx_utils_status_t        utils_err;
    adjacency_table_entry_t *adj = NULL;
    ib_mc_adjacency_entry_t* entry;

    utils_err = bin_get_slot_index(router_db_adjacency_allocator_get(), block, &old_index);
    CL_ASSERT(utils_err == SX_UTILS_STATUS_SUCCESS);
    if (utils_err != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot calculate IB MC adjacency cost. cannot get old block index\n");
        return 0;
    }
    adj = router_db_adjacency_entry_get(old_index);
    CL_ASSERT(adj->used);
    CL_ASSERT(adj->block_size == block->size);
    CL_ASSERT(adj->type == (adjacency_entry_type_e)ADJACENCY_ENTRY_IB_MULTICAST_E);
    CL_ASSERT(block->size == IB_MC_ADJACENCY_SIZE); /*IB_MULTICAST consumes two spaces in the Tcam table*/

    entry = (ib_mc_adjacency_entry_t*)adj->content.other;
    /* The cost is an update of one RATR, plus this many MC routes */
    return 1 + entry->common.routes_use;
}

/**
 * This function writes or deletes RATR for IB multicast adjacency entry
 * Supported commands:
 * SX_ACCESS_CMD_SET - Add a reference from a MC route to this adjacency
 * SX_ACCESS_CMD_DELETE - Remove a reference from a MC route to this adjacency
 * SX_ACCESS_CMD_CREATE - Forcefully write the RATR entry, disregarding the reference count
 * SX_ACCESS_CMD_DESTROY - Forcefully delete the RATR entry, disregarding the reference count
 */
static sx_status_t __ib_router_set_mc_neigh(sx_access_cmd_t           cmd,
                                            uint32_t                  adj_entries_num,
                                            ib_mc_adjacency_entry_t **adj_entries,
                                            neigh_data_types_e        neigh_type)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t      reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_ratr_reg  ratr_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    uint32_t            i = 0, index;
    sx_access_cmd_t     rm_cmd = SX_ACCESS_CMD_NONE;
    rm_sdk_table_type_e resource;

    UNUSED_PARAM(neigh_type);

    SX_LOG_ENTER();

    for (i = 0; i < adj_entries_num; i++) {
        if ((adj_entries[i]->common.routes_use == 0) && (cmd == SX_ACCESS_CMD_DELETE)) {
            SX_LOG(SX_LOG_ERROR, "Trying to remove a neighbor which is not in the DB.\n");
            err = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        if (((adj_entries[i]->common.routes_use == 0) && (cmd == SX_ACCESS_CMD_SET)) ||
            ((adj_entries[i]->common.routes_use == 1) && (cmd == SX_ACCESS_CMD_DELETE)) ||
            ((cmd != SX_ACCESS_CMD_SET) && (cmd != SX_ACCESS_CMD_DELETE))) {
            /* Get list of LEAF devices */
            err = SX_FDB_GET_LIST_OF_LEAF_DEV;

            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
                       sx_status_str(err));
                err = SX_STATUS_ERROR;
                goto out;
            }

            /* For each LEAF device */
            SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
            SX_MEM_CLR(reg_meta[dev_idx]);
            reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
            reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_ADD;
            reg_meta[dev_idx].mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

            SX_MEM_CLR(ratr_reg_data[dev_idx]);

            ratr_reg_data[dev_idx].operation = SXD_ROUTER_ARP_OPERATION_WRITE;
            switch (cmd) {
            case SX_ACCESS_CMD_SET:
            case SX_ACCESS_CMD_CREATE:
                ratr_reg_data[dev_idx].valid = SXD_ROUTE_ADJECENCY_WRITE;
                rm_cmd = SX_ACCESS_CMD_ADD;
                break;

            case SX_ACCESS_CMD_DELETE:
            case SX_ACCESS_CMD_DESTROY:
                ratr_reg_data[dev_idx].valid = SXD_ROUTE_ADJECENCY_DELETE;
                rm_cmd = SX_ACCESS_CMD_DELETE;
                break;

            default:
                err = SX_STATUS_CMD_UNSUPPORTED;
                goto out;
            }

            bin_get_slot_index(router_db_adjacency_allocator_get(), &adj_entries[i]->common.adjacency_block, &index);

            ratr_reg_data[dev_idx].type = PKEY_MULTI;
            ratr_reg_data[dev_idx].table = ETHERNET_UNICAST_ADJACENCY;
            ratr_reg_data[dev_idx].adjacency_index = index;
            ratr_reg_data[dev_idx].egress_rif = adj_entries[i]->adj_param.rif;
            ratr_reg_data[dev_idx].adj_parameters.pkey_multi_parameters.sl = adj_entries[i]->adj_param.sl;
            ratr_reg_data[dev_idx].adj_parameters.pkey_multi_parameters.dlid = adj_entries[i]->adj_param.mlid;
            ratr_reg_data[dev_idx].adj_parameters.pkey_multi_parameters.tclass = adj_entries[i]->adj_param.tclass;

            SX_FDB_FOR_EACH_LEAF_DEV_END;
            resource = RM_SDK_TABLE_TYPE_ADJACENCY_E;
            err = rm_entries_set(resource, rm_cmd, 1, NULL);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed to set entries in RM for %s\n",
                       SX_RESOURCE_MSG(resource));
                goto out;
            }

            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RATR_E,
                                                             ratr_reg_data,
                                                             reg_meta,
                                                             dev_info_arr_size,
                                                             NULL,
                                                             NULL);
            if (sxd_status != SXD_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed RATR allocate set: id [%u], err [%s].\n",
                       adj_entries[i]->common.adjacency_block.index, SXD_STATUS_MSG(sxd_status));
                rm_cmd = (rm_cmd == SX_ACCESS_CMD_ADD) ? SX_ACCESS_CMD_DELETE : SX_ACCESS_CMD_ADD;
                rm_entries_set(resource, rm_cmd, 1, NULL);
                err = sxd_status_to_sx_status(sxd_status);
                goto out;
            }
        }

        switch (cmd) {
        case SX_ACCESS_CMD_SET:
            adj_entries[i]->common.routes_use++;
            break;

        case SX_ACCESS_CMD_DELETE:
            if (adj_entries[i]->common.routes_use > 0) {
                adj_entries[i]->common.routes_use--;
            }
            break;

        case SX_ACCESS_CMD_CREATE:
        case SX_ACCESS_CMD_DESTROY:
            break;

        default:
            err = SX_STATUS_CMD_UNSUPPORTED;
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_set_mc_neigh_sync_to_dev_by_type(sx_dev_id_t dev_id, neigh_data_types_e neigh_type)
{
    sxd_reg_meta_t           reg_meta;
    struct ku_ratr_reg       ratr_reg_data;
    sxd_status_t             sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t              err = SX_STATUS_SUCCESS;
    ib_mc_adjacency_entry_t *adj_entry = NULL;
    cl_map_item_t           *map_item = NULL;
    const cl_map_item_t     *map_end = NULL;
    sx_router_id_t           vrid;
    uint32_t                 index;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(ratr_reg_data);

    for (vrid = 0; vrid < router_init_params_s.virtual_routers_num; vrid++) {
        map_item = cl_qmap_head(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]));
        map_end = cl_qmap_end(&(ib_mc_adjacency_data[neigh_type]->adjacency_map[vrid]));

        while (map_item != map_end) {
            adj_entry = PARENT_STRUCT(map_item, ib_mc_adjacency_entry_t, map_item);
            map_item = cl_qmap_next(map_item);

            bin_get_slot_index(router_db_adjacency_allocator_get(), &adj_entry->common.adjacency_block, &index);

            reg_meta.dev_id = dev_id;
            reg_meta.access_cmd = SXD_ACCESS_CMD_ADD;
            reg_meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

            ratr_reg_data.operation = SXD_ROUTER_ARP_OPERATION_WRITE;
            ratr_reg_data.valid = SXD_ROUTE_ADJECENCY_WRITE;

            ratr_reg_data.type = PKEY_MULTI;
            ratr_reg_data.table = ETHERNET_UNICAST_ADJACENCY;
            ratr_reg_data.egress_rif = adj_entry->adj_param.rif;
            ratr_reg_data.adjacency_index = index;
            ratr_reg_data.adj_parameters.pkey_multi_parameters.sl = adj_entry->adj_param.sl;
            ratr_reg_data.adj_parameters.pkey_multi_parameters.dlid = adj_entry->adj_param.mlid;
            ratr_reg_data.adj_parameters.pkey_multi_parameters.tclass = adj_entry->adj_param.tclass;

            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RATR_E,
                                                             &ratr_reg_data,
                                                             &reg_meta,
                                                             1,
                                                             NULL,
                                                             NULL);
            if (sxd_status != SXD_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed RATR allocate set: index [%u], err [%s].\n",
                       index, SXD_STATUS_MSG(sxd_status));
                err = sxd_status_to_sx_status(sxd_status);
                goto out;
            }
        } /* while (map_item != map_end) {*/
    } /* for (vrid=0; vrid < SX_VRID_COUNT; vrid++) { */

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __ib_router_set_mc_neigh_sync_to_dev(sxd_dev_id_t dev_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (router_init_params_s.mc_version & SX_IP_VERSION_IPV4) {
        err = __ib_router_set_mc_neigh_sync_to_dev_by_type(dev_id, IPV4_NEIGH_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Unable to add all IPv4 IB MC neighbor entries to device: %d\n", dev_id);
            goto out;
        }
    }
    if (router_init_params_s.mc_version & SX_IP_VERSION_IPV6) {
        err = __ib_router_set_mc_neigh_sync_to_dev_by_type(dev_id, IPV6_NEIGH_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Unable to add all IPv6 IB MC neighbor entries to device: %d\n", dev_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_mc_entry_egress_neigh_set(sx_access_cmd_t           cmd,
                                                         routing_table_entry_t    *entry,
                                                         ib_mc_adjacency_entry_t **adjacency_entries,
                                                         uint32_t                  adjacency_entries_num,
                                                         neigh_data_types_e        neigh_type)
{
    SX_LOG_ENTER();

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sxd_reg_meta_t     reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_rigr_reg rigr_reg_data[SX_DEVICE_ID_COUNT];
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        err = SX_STATUS_SUCCESS;
    uint32_t           i = 0, index;

    SX_LOG_ENTER();

    /* Get list of LEAF devices */
    err = SX_FDB_GET_LIST_OF_LEAF_DEV;

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot retrieve device list [%s].\n",
               sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    /* For each LEAF device */
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = SXD_ACCESS_CMD_ADD;

    SX_MEM_CLR(rigr_reg_data[dev_idx]);

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        rigr_reg_data[dev_idx].op = RIGR_OP_ADD_RIF;
        break;

    case SX_ACCESS_CMD_EDIT:
        rigr_reg_data[dev_idx].op = RIGR_OP_UPDATE_RIF;
        break;

    case SX_ACCESS_CMD_DELETE:
        rigr_reg_data[dev_idx].op = RIGR_OP_REMOVE_RIF;
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        rigr_reg_data[dev_idx].op = RIGR_OP_REMOVE_ALL_RIFS;
        adjacency_entries_num = 0;
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    rigr_reg_data[dev_idx].types =
        (neigh_type == IPV4_NEIGH_E ? SXD_ROUTER_ROUTE_TYPE_IPV4 : SXD_ROUTER_ROUTE_TYPE_IPV6);
    rigr_reg_data[dev_idx].enc = ETH_AND_PKEY;
    rigr_reg_data[dev_idx].offset = entry->index;
    rigr_reg_data[dev_idx].rif_list.eth_pkey_rif_list.size = adjacency_entries_num;
    for (i = 0; i < adjacency_entries_num; i++) {
        bin_get_slot_index(router_db_adjacency_allocator_get(), &adjacency_entries[i]->common.adjacency_block, &index);

        rigr_reg_data[dev_idx].rif_list.eth_pkey_rif_list.adj_list[i].rif_table =
            (((adjacency_entries[i]->adj_param.rif & 0xFFF) << 4) | ETHERNET_UNICAST_ADJACENCY);
        rigr_reg_data[dev_idx].rif_list.eth_pkey_rif_list.adj_list[i].adjacency_index = index;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RIGR_E,
                                                     rigr_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed RIGR set: [%s].\n",
               SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_mc_entry_egress_neigh_sync_to_dev_by_type(sxd_dev_id_t       dev_id,
                                                                         neigh_data_types_e neigh_type)
{
    sxd_reg_meta_t           reg_meta;
    struct ku_rigr_reg       rigr_reg_data;
    sxd_status_t             sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint32_t                 i = 0, index = 0;
    routing_table_entry_t   *entry = NULL;
    ib_mc_adjacency_entry_t *adj_entry = NULL;
    cl_fmap_item_t          *map_item = NULL;
    const cl_fmap_item_t    *map_end = NULL;
    sx_router_id_t           vrid;
    sx_lid_t                *mlid_list = NULL;
    uint32_t                 mlid_list_num = 0;
    ib_mc_route_entry_t     *ib_mc_route_entry = NULL;
    char                     ip_prefix_str[FORMAT_BUFFER_SIZE] = {0};
    char                     ip_prefix_str2[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(rigr_reg_data);

    /* Allocate the mlid list array */
    mlid_list = (sx_lid_t*)cl_malloc(sizeof(sx_lid_t) *
                                     rm_resource_global.router_rifs_max);
    if (!mlid_list) {
        SX_LOG(SX_LOG_ERROR, "Failed to allocate memory for the mlid list array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    for (vrid = 0; vrid < router_init_params_s.virtual_routers_num; vrid++) {
        map_item = cl_fmap_head(&(ib_mc_adjacency_data[neigh_type]->mc_routes_map[vrid]));
        map_end = cl_fmap_end(&(ib_mc_adjacency_data[neigh_type]->mc_routes_map[vrid]));

        while (map_item != map_end) {
            ib_mc_route_entry = PARENT_STRUCT(map_item, ib_mc_route_entry_t, map_item);
            map_item = cl_fmap_next(map_item);

            err = router_db_mc_rt_lookup_map_find(vrid,
                                                  &ib_mc_route_entry->source_addr,
                                                  &ib_mc_route_entry->mc_group_addr,
                                                  ib_mc_route_entry->ingress_rif,
                                                  &entry);
            if (entry == NULL) {
                err = SX_STATUS_ENTRY_NOT_FOUND;
                SX_LOG(SX_LOG_ERROR, "Could not find entries [%s:%s] in MC RT DB: %s \n",
                       format_prefix(&ib_mc_route_entry->source_addr, ip_prefix_str),
                       format_prefix(&ib_mc_route_entry->mc_group_addr, ip_prefix_str2),
                       sx_status_str(err));
                goto out;
            }

            reg_meta.dev_id = dev_id;
            reg_meta.access_cmd = SXD_ACCESS_CMD_ADD;
            rigr_reg_data.op = RIGR_OP_ADD_RIF;

            rigr_reg_data.enc = ETH_AND_PKEY;
            rigr_reg_data.offset = entry->index;
            rigr_reg_data.types =
                (neigh_type == IPV4_NEIGH_E ? SXD_ROUTER_ROUTE_TYPE_IPV4 : SXD_ROUTER_ROUTE_TYPE_IPV6);

            err = __ib_router_db_mc_neigh_get(entry->mc.vrid, &entry->mc.source_addr,
                                              &entry->mc.mc_group_addr, &mlid_list_num, mlid_list);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Could not retrieve all ipoib mc neighbors belonging to MC route.\n");
                goto out;
            }

            rigr_reg_data.rif_list.eth_pkey_rif_list.size = mlid_list_num;

            for (i = 0; i < mlid_list_num; i++) {
                err = __ib_router_db_mc_adjacency_find(vrid, mlid_list[i], neigh_type, &adj_entry);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG(SX_LOG_ERROR, "Could not retrieve all ipoib mc neighbors.\n");
                    goto out;
                }
                bin_get_slot_index(router_db_adjacency_allocator_get(), &adj_entry->common.adjacency_block, &index);

                rigr_reg_data.rif_list.eth_pkey_rif_list.adj_list[i].rif_table =
                    (((adj_entry->adj_param.rif & 0xFFF) << 4) | ETHERNET_UNICAST_ADJACENCY);
                rigr_reg_data.rif_list.eth_pkey_rif_list.adj_list[i].adjacency_index = index;
            }

            sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RIGR_E,
                                                             &rigr_reg_data,
                                                             &reg_meta,
                                                             1,
                                                             NULL,
                                                             NULL);
            if (sxd_status != SXD_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed RIGR set: [%s].\n",
                       SXD_STATUS_MSG(sxd_status));

                err = sxd_status_to_sx_status(sxd_status);
                goto out;
            }
        }
    } /* for (vrid=0; vrid<SX_VRID_COUNT; vrid++) { */

out:
    if (mlid_list != NULL) {
        CL_FREE_N_NULL(mlid_list);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t __ib_router_mc_entry_egress_neigh_sync_to_dev(sxd_dev_id_t dev_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (router_init_params_s.mc_version & SX_IP_VERSION_IPV4) {
        err = __ib_router_mc_entry_egress_neigh_sync_to_dev_by_type(dev_id, IPV4_NEIGH_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Unable to add all IPv4 IB neighbor entries to device: %d, err: %s.\n",
                   dev_id,
                   sx_status_str(err));
            goto out;
        }
    }
    if (router_init_params_s.mc_version & SX_IP_VERSION_IPV6) {
        err = __ib_router_mc_entry_egress_neigh_sync_to_dev_by_type(dev_id, IPV6_NEIGH_E);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR,
                   "Unable to add all IPv6 IB neighbor entries to device: %d, err: %s.\n",
                   dev_id,
                   sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_db_mc_route_add(sx_router_id_t           vrid,
                                               const sx_ip_prefix_t    *source_addr,
                                               const sx_ip_prefix_t    *mc_group_addr,
                                               sx_router_interface_t    ingress_rif,
                                               uint32_t                 egress_neigh_num,
                                               const sx_mc_ipoib_adj_t *egress_neigh_arr,
                                               neigh_data_types_e       neigh_type)
{
    cl_fmap_item_t         *map_item = NULL;
    const cl_fmap_item_t   *map_end = NULL;
    sx_status_t             err = SX_STATUS_SUCCESS;
    ib_mc_route_table_key_t ib_mc_route_table_key;
    ib_mc_route_entry_t    *ib_mc_route_entry = NULL;
    cl_pool_item_t        * pool_item = NULL;
    uint32_t                i = 0, j = 0;

    SX_LOG_ENTER();

    build_ib_mc_router_table_key(source_addr, mc_group_addr, &ib_mc_route_table_key);

    map_item = cl_fmap_get(&(ib_mc_adjacency_data[neigh_type]->mc_routes_map[vrid]),
                           (const void*)&ib_mc_route_table_key);
    map_end = cl_fmap_end(&(ib_mc_adjacency_data[neigh_type]->mc_routes_map[vrid]));

    if (map_item == map_end) { /*map is empty*/
        /* prepare an item for lookup table  */
        pool_item = cl_qpool_get(&(ib_mc_adjacency_data[neigh_type]->mc_routes_pool));
        if (pool_item == NULL) {
            SX_LOG(SX_LOG_DEBUG, "Could not find free IB mc route entry at the IB MC routing DB.\n");
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }

        ib_mc_route_entry = PARENT_STRUCT(pool_item, ib_mc_route_entry_t, pool_item);
        memcpy(&(ib_mc_route_entry->ib_mc_route_table_key), &(ib_mc_route_table_key), sizeof(ib_mc_route_table_key_t));
        memcpy(&(ib_mc_route_entry->source_addr), source_addr, sizeof(*source_addr));
        memcpy(&(ib_mc_route_entry->mc_group_addr), mc_group_addr, sizeof(*mc_group_addr));
        cl_fmap_insert(&(ib_mc_adjacency_data[neigh_type]->mc_routes_map[vrid]),
                       (const void*)&(ib_mc_route_entry->ib_mc_route_table_key), &(ib_mc_route_entry->map_item));
    } else {
        ib_mc_route_entry = PARENT_STRUCT(map_item, ib_mc_route_entry_t, map_item);
    }

    for (i = 0; i < egress_neigh_num; i++) {
        for (j = 0; j < rm_resource_global.router_rifs_max; j++) {
            if (ib_mc_route_entry->mlid_used[j] == FALSE) {
                ib_mc_route_entry->mlid_used[j] = TRUE;
                ib_mc_route_entry->mlid_list[j] = egress_neigh_arr[i].mlid;
                ib_mc_route_entry->mlid_count++;
                ib_mc_route_entry->ingress_rif = ingress_rif;
                break;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_db_mc_route_remove(sx_router_id_t        vrid,
                                                  const sx_ip_prefix_t *source_addr,
                                                  const sx_ip_prefix_t *mc_group_addr,
                                                  uint32_t              egress_neigh_num,
                                                  sx_lid_t             *mlid_list,
                                                  neigh_data_types_e    neigh_type)
{
    cl_fmap_item_t         *map_item = NULL;
    const cl_fmap_item_t   *map_end = NULL;
    sx_status_t             err = SX_STATUS_SUCCESS;
    ib_mc_route_table_key_t ib_mc_route_table_key;
    ib_mc_route_entry_t    *ib_mc_route_entry = NULL;
    uint32_t                i = 0, j = 0;

    SX_LOG_ENTER();

    build_ib_mc_router_table_key(source_addr, mc_group_addr, &ib_mc_route_table_key);

    map_item = cl_fmap_get(&(ib_mc_adjacency_data[neigh_type]->mc_routes_map[vrid]),
                           (const void*)&ib_mc_route_table_key);
    map_end = cl_fmap_end(&(ib_mc_adjacency_data[neigh_type]->mc_routes_map[vrid]));

    if (map_item == map_end) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_ERROR, "IB MC route DB update failed.\n");
        goto  out;
    }

    ib_mc_route_entry = PARENT_STRUCT(map_item, ib_mc_route_entry_t, map_item);

    for (i = 0; i < egress_neigh_num; i++) {
        for (j = 0; j < SXD_RIF_MAX; j++) {
            if ((ib_mc_route_entry->mlid_used[j] == TRUE) && (ib_mc_route_entry->mlid_list[j] == mlid_list[i])) {
                ib_mc_route_entry->mlid_used[j] = FALSE;
                ib_mc_route_entry->mlid_list[j] = 0;
                ib_mc_route_entry->mlid_count--;
                break;
            }
        }
    }

    if (ib_mc_route_entry->mlid_count == 0) {
        map_item = cl_fmap_remove(&(ib_mc_adjacency_data[neigh_type]->mc_routes_map[vrid]),
                                  (const void*)&ib_mc_route_table_key);
        cl_qpool_put(&(ib_mc_adjacency_data[neigh_type]->mc_routes_pool), &(ib_mc_route_entry->pool_item));
    }

out:
    SX_LOG_EXIT();
    return err;
}

/* mlid_list should have the size of SX_RIF_MAX (at least)  */
static sx_status_t __ib_router_db_mc_neigh_get(sx_router_id_t        vrid,
                                               const sx_ip_prefix_t *source_addr,
                                               const sx_ip_prefix_t *mc_group_addr,
                                               uint32_t             *mlid_list_num,
                                               sx_lid_t             *mlid_list)
{
    cl_fmap_item_t         *map_item = NULL;
    const cl_fmap_item_t   *map_end = NULL;
    sx_status_t             err = SX_STATUS_SUCCESS;
    ib_mc_route_table_key_t ib_mc_route_table_key;
    ib_mc_route_entry_t    *ib_mc_route_entry = NULL;
    uint32_t                i = 0, index = 0;

    SX_LOG_ENTER();

    build_ib_mc_router_table_key(source_addr, mc_group_addr, &ib_mc_route_table_key);

    map_item =
        cl_fmap_get(&(ib_mc_adjacency_data[VERSION_TO_NEIGH_TYPE(
                                               source_addr->version)]->mc_routes_map[vrid]),
                    (const void*)&ib_mc_route_table_key);
    map_end = cl_fmap_end(&(ib_mc_adjacency_data[VERSION_TO_NEIGH_TYPE(source_addr->version)]->mc_routes_map[vrid]));

    if (map_item == map_end) {
        SX_LOG(SX_LOG_DEBUG, "IB MC route DB get failed.\n");
        goto  out;
    }

    ib_mc_route_entry = PARENT_STRUCT(map_item, ib_mc_route_entry_t, map_item);

    for (i = 0; i < SXD_RIF_MAX; i++) {
        if (ib_mc_route_entry->mlid_used[i] == TRUE) {
            mlid_list[index] = ib_mc_route_entry->mlid_list[i];
            index++;
        }
    }

out:
    *mlid_list_num = index;
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_mc_egress_neigh_set(sx_router_id_t           vrid,
                                                   const sx_ip_prefix_t    *source_addr,
                                                   const sx_ip_prefix_t    *mc_group_addr,
                                                   sx_router_interface_t    ingress_rif,
                                                   uint32_t                 egress_neigh_num,
                                                   const sx_mc_ipoib_adj_t *egress_neigh_arr)
{
    routing_table_entry_t    *mc_entry = NULL;
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_status_t               mem_err = SX_STATUS_SUCCESS;
    ib_mc_adjacency_entry_t **adj_entries = NULL;
    char                      ip_prefix_str[FORMAT_BUFFER_SIZE] = {0};
    char                      ip_prefix_str2[FORMAT_BUFFER_SIZE] = {0};
    neigh_data_types_e        neigh_type;

    SX_LOG_ENTER();

    M_UTILS_CLR_MEM_GET(&adj_entries,
                        egress_neigh_num,
                        sizeof(ib_mc_adjacency_entry_t*),
                        UTILS_MEM_TYPE_ID_ROUTER_E,
                        "Neighbor information",
                        mem_err);
    if (mem_err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot allocate local stack memory\n");
        err = mem_err;
        goto out;
    }
    neigh_type = VERSION_TO_NEIGH_TYPE(source_addr->version);

    /* lookup for matching route */
    err = router_db_mc_rt_lookup_map_find(vrid, source_addr, mc_group_addr, ingress_rif,
                                          &mc_entry);
    if (mc_entry == NULL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_ERROR, "Could not find entry [%s:%s] in MC RT DB: %s \n",
               format_prefix(source_addr, ip_prefix_str),
               format_prefix(mc_group_addr, ip_prefix_str2),
               sx_status_str(err));
        goto out;
    }

    /* Get DB record */
    err =
        __ib_router_mc_adjacency_get(vrid, mc_group_addr, egress_neigh_arr, neigh_type, egress_neigh_num, adj_entries);
    if (err != SX_STATUS_SUCCESS) {
        if (err != SX_STATUS_NO_RESOURCES) {
            SX_LOG(SX_LOG_ERROR, "Could not retrieve/allocate all ipoib mc neighbors.\n");
        }
        goto out;
    }

    err = __ib_router_mc_verify_adjacency_mc_route_unique(vrid,
                                                          source_addr,
                                                          mc_group_addr,
                                                          egress_neigh_num,
                                                          egress_neigh_arr,
                                                          neigh_type);
    if (err != SX_STATUS_SUCCESS) {
        __ib_router_mc_adjacency_remove(vrid, neigh_type, egress_neigh_num, adj_entries);
        SX_LOG(SX_LOG_ERROR, "Invalid mc route adjacency parameters.\n");
        goto out;
    }

    /* write MC neigh in HW (RATR) */
    err = __ib_router_set_mc_neigh(SX_ACCESS_CMD_SET, egress_neigh_num, adj_entries, neigh_type);
    if (err != SX_STATUS_SUCCESS) {
        __ib_router_mc_adjacency_remove(vrid, neigh_type, egress_neigh_num, adj_entries);
        SX_LOG(SX_LOG_ERROR, "Could not set MC neighbor in HW.\n");
        goto out;
    }
    /* RIGR */
    err = __ib_router_mc_entry_egress_neigh_set(SX_ACCESS_CMD_SET, mc_entry,
                                                adj_entries, egress_neigh_num, neigh_type);
    if (err != SX_STATUS_SUCCESS) {
        __ib_router_set_mc_neigh(SX_ACCESS_CMD_DELETE, egress_neigh_num, adj_entries, neigh_type);
        __ib_router_mc_adjacency_remove(vrid, neigh_type, egress_neigh_num, adj_entries);
        SX_LOG(SX_LOG_ERROR, "Could not update MC route egress set.\n");
        goto out;
    }

    err = __ib_router_db_mc_route_add(vrid,
                                      source_addr,
                                      mc_group_addr,
                                      ingress_rif,
                                      egress_neigh_num,
                                      egress_neigh_arr,
                                      neigh_type);
    if (err != SX_STATUS_SUCCESS) {
        __ib_router_mc_entry_egress_neigh_set(SX_ACCESS_CMD_DELETE, mc_entry,
                                              adj_entries, egress_neigh_num, neigh_type);
        __ib_router_set_mc_neigh(SX_ACCESS_CMD_DELETE, egress_neigh_num, adj_entries, neigh_type);
        __ib_router_mc_adjacency_remove(vrid, neigh_type, egress_neigh_num, adj_entries);
        SX_LOG(SX_LOG_ERROR, "Could not update MC route DB.\n");
        goto out;
    }

    mc_entry->mc.delete_all_func_ptr = ib_router_mc_egress_neigh_delete_all;
    mc_entry->mc.get_egress_neigh_num_func_ptr = ib_router_mc_egress_neigh_count;

out:
    if (adj_entries != NULL) {
        M_UTILS_MEM_PUT(adj_entries, UTILS_MEM_TYPE_ID_ROUTER_E, "Neighbor information", mem_err);
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __ib_router_mc_egress_neigh_delete(sx_access_cmd_t       cmd,
                                                      sx_router_id_t        vrid,
                                                      const sx_ip_prefix_t *source_addr,
                                                      const sx_ip_prefix_t *mc_group_addr,
                                                      sx_router_interface_t ingress_rif,
                                                      sx_lid_t             *mlid_list,
                                                      uint32_t              egress_neigh_num)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    routing_table_entry_t    *mc_entry = NULL;
    ib_mc_adjacency_entry_t **adj_entries;
    uint32_t                  i = 0;
    char                      ip_prefix_str[FORMAT_BUFFER_SIZE] = {0};
    char                      ip_prefix_str2[FORMAT_BUFFER_SIZE] = {0};
    neigh_data_types_e        neigh_type;

    SX_LOG_ENTER();

    M_UTILS_CLR_MEM_GET(&adj_entries,
                        egress_neigh_num,
                        sizeof(ib_mc_adjacency_entry_t*),
                        UTILS_MEM_TYPE_ID_ROUTER_E,
                        "Neighbor information",
                        err);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot allocate local stack memory\n");
        goto out;
    }

    neigh_type = VERSION_TO_NEIGH_TYPE(source_addr->version);

    err = router_db_mc_rt_lookup_map_find(vrid, source_addr, mc_group_addr, ingress_rif,
                                          &mc_entry);
    if (mc_entry == NULL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_ERROR, "Could not find entry [%s:%s] in MC RT DB: %s \n",
               format_prefix(source_addr, ip_prefix_str),
               format_prefix(mc_group_addr, ip_prefix_str2),
               sx_status_str(err));
        goto out;
    }

    for (i = 0; i < egress_neigh_num; i++) {
        err = __ib_router_db_mc_adjacency_find(vrid, mlid_list[i], neigh_type, &(adj_entries[i]));
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not retrieve all ipoib mc neighbors.\n");
            goto out;
        }
    }

    /* RATR - remove from HW */
    err = __ib_router_set_mc_neigh(SX_ACCESS_CMD_DELETE, egress_neigh_num, adj_entries, neigh_type);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not remove MC neighbor.\n");
        goto out;
    }

    /* RIGR */
    err = __ib_router_mc_entry_egress_neigh_set(cmd, mc_entry,
                                                adj_entries, egress_neigh_num, neigh_type);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not update MC route egress set.\n");
        goto out;
    }

    err = __ib_router_mc_adjacency_remove(vrid, neigh_type, egress_neigh_num, adj_entries);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not remove MC neighbors from DB.\n");
        goto out;
    }

    err = __ib_router_db_mc_route_remove(vrid, source_addr, mc_group_addr, egress_neigh_num, mlid_list, neigh_type);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not update MC route DB.\n");
        goto out;
    }

out:
    if (adj_entries != NULL) {
        M_UTILS_MEM_PUT(adj_entries, UTILS_MEM_TYPE_ID_ROUTER_E, "Neighbor information", err);
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t ib_router_mc_egress_neigh_count(const sx_router_id_t  vrid,
                                            const sx_ip_prefix_t *source_addr,
                                            const sx_ip_prefix_t *mc_group_addr,
                                            uint32_t             *egress_num)
{
    sx_lid_t   *mlid_list = NULL;
    uint32_t    mlid_list_num = 0;
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Allocate the mlid list array */
    mlid_list = (sx_lid_t*)cl_malloc(sizeof(sx_lid_t) *
                                     rm_resource_global.router_rifs_max);
    if (!mlid_list) {
        SX_LOG(SX_LOG_ERROR, "Failed to allocate memory for the mlid list array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    err = __ib_router_db_mc_neigh_get(vrid, source_addr, mc_group_addr, &mlid_list_num, mlid_list);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not retrieve all ipoib mc neighbors belonging to MC route.\n");
        goto out;
    }
    *egress_num = mlid_list_num;

out:
    if (mlid_list != NULL) {
        CL_FREE_N_NULL(mlid_list);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t ib_router_mc_egress_neigh_delete_all(const sx_router_id_t        vrid,
                                                 const sx_ip_prefix_t       *source_addr,
                                                 const sx_ip_prefix_t       *mc_group_addr,
                                                 const sx_router_interface_t ingress_rif)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_lid_t   *mlid_list = NULL;
    uint32_t    mlid_list_num = 0;

    SX_LOG_ENTER();

    /* Allocate the mlid list array */
    mlid_list = (sx_lid_t*)cl_malloc(sizeof(sx_lid_t) *
                                     rm_resource_global.router_rifs_max);
    if (!mlid_list) {
        SX_LOG(SX_LOG_ERROR, "Failed to allocate memory for the mlid list array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    err = __ib_router_db_mc_neigh_get(vrid, source_addr, mc_group_addr, &mlid_list_num, mlid_list);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not retrieve all ipoib mc neighbors belonging to MC route.\n");
        goto out;
    }

    if (mlid_list_num != 0) {
        err = __ib_router_mc_egress_neigh_delete(SX_ACCESS_CMD_DELETE_ALL,
                                                 vrid,
                                                 source_addr,
                                                 mc_group_addr,
                                                 ingress_rif,
                                                 mlid_list,
                                                 mlid_list_num);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not remove all ipoib mc neighbors belonging to MC route.\n");
            goto out;
        }
    }

out:
    if (mlid_list != NULL) {
        CL_FREE_N_NULL(mlid_list);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t __ib_router_db_mc_egress_neigh_get(const sx_router_id_t  vrid,
                                               const sx_ip_prefix_t *source_addr,
                                               const sx_ip_prefix_t *mc_group_addr,
                                               sx_router_interface_t ingress_rif,
                                               uint32_t             *neigh_param_num,
                                               sx_mc_ipoib_adj_t    *mc_ipoib_egress_neigh_param_arr)
{
    routing_table_entry_t   *mc_entry = NULL;
    sx_lid_t                *mlid_list = NULL;
    uint32_t                 mlid_list_num = 0, i = 0;
    ib_mc_adjacency_entry_t *adj_entries;
    sx_status_t              err = SX_STATUS_SUCCESS;
    char                     ip_prefix_str[FORMAT_BUFFER_SIZE] = {0};
    char                     ip_prefix_str2[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    if (*neigh_param_num > rm_resource_global.router_rifs_max) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG(SX_LOG_ERROR, "Invalid params neigh_param_num %d > SXD_RIF_MAX %d \n",
               *neigh_param_num, SXD_RIF_MAX);
        goto out;
    }

    router_db_mc_rt_lookup_map_find(vrid, source_addr, mc_group_addr, ingress_rif, &mc_entry);
    if (mc_entry == NULL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_ERROR, "Could not find entries [%s:%s] in MC RT DB: %s \n",
               format_prefix(source_addr, ip_prefix_str),
               format_prefix(mc_group_addr, ip_prefix_str2),
               sx_status_str(err));
        goto out;
    }

    /* Allocate the mlid list array */
    mlid_list = (sx_lid_t*)cl_malloc(sizeof(sx_lid_t) *
                                     rm_resource_global.router_rifs_max);
    if (!mlid_list) {
        SX_LOG(SX_LOG_ERROR, "Failed to allocate memory for the mlid list array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    err = __ib_router_db_mc_neigh_get(vrid, source_addr, mc_group_addr, &mlid_list_num, mlid_list);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not retrieve all ipoib mc neighbors belonging to MC route.\n");
        goto out;
    }

    if (*neigh_param_num == 0) {
        /* return count only */
        *neigh_param_num = mlid_list_num;
    } else {
        *neigh_param_num = MIN(*neigh_param_num, mlid_list_num);

        for (i = 0; i < (*neigh_param_num); i++) {
            err = __ib_router_db_mc_adjacency_find(vrid, mlid_list[i], VERSION_TO_NEIGH_TYPE(
                                                       source_addr->version), &adj_entries);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Could not retrieve all ipoib mc neighbors from DB.\n");
                goto out;
            }
            mc_ipoib_egress_neigh_param_arr[i].rif = adj_entries->adj_param.rif;
            mc_ipoib_egress_neigh_param_arr[i].mlid = adj_entries->adj_param.mlid;
            mc_ipoib_egress_neigh_param_arr[i].sl = adj_entries->adj_param.sl;
            mc_ipoib_egress_neigh_param_arr[i].hoplimit = adj_entries->adj_param.hoplimit;
            mc_ipoib_egress_neigh_param_arr[i].tclass = adj_entries->adj_param.tclass;
        }
    }

out:
    if (mlid_list != NULL) {
        CL_FREE_N_NULL(mlid_list);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t ib_router_mc_egress_set(const sx_access_cmd_t       cmd,
                                    const sx_router_id_t        vrid,
                                    const sx_ip_prefix_t       *source_addr,
                                    const sx_ip_prefix_t       *mc_group_addr,
                                    const sx_router_interface_t ingress_rif,
                                    const uint32_t              neigh_param_num,
                                    const sx_mc_ipoib_adj_t    *mc_ipoib_egress_neigh_param_arr)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_status_t            mem_err = SX_STATUS_SUCCESS;
    sx_router_interface_t* rif_list;
    sx_lid_t              *mlid_list = NULL;
    uint32_t               i = 0;

    SX_LOG_ENTER();

    M_UTILS_CLR_MEM_GET(&rif_list,
                        neigh_param_num,
                        sizeof(sx_router_interface_t),
                        UTILS_MEM_TYPE_ID_ROUTER_E,
                        "Neighbor information",
                        err);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Cannot allocate local stack memory\n");
        goto out;
    }

    /* Allocate the mlid list array */
    mlid_list = (sx_lid_t*)cl_malloc(sizeof(sx_lid_t) *
                                     rm_resource_global.router_rifs_max);
    if (!mlid_list) {
        SX_LOG(SX_LOG_ERROR, "Failed to allocate memory for the mlid list array.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    for (i = 0; i < neigh_param_num; i++) {
        rif_list[i] = mc_ipoib_egress_neigh_param_arr[i].rif;
        mlid_list[i] = mc_ipoib_egress_neigh_param_arr[i].mlid;
    }
    err = router_mc_egress_rif_params_validation(cmd,   vrid,
                                                 source_addr, mc_group_addr, rif_list, neigh_param_num);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("VRID (%d) params validation failed. err: %d.\n", vrid, err);
        goto out;
    }

    for (i = 0; i < neigh_param_num; i++) {
        if (((sx_l2_ib_router_interface_t*)(router_interfaces[rif_list[i]].l2_att))->type !=
            SX_L2_INTERFACE_TYPE_PKEY) {
            SX_LOG(SX_LOG_ERROR, "Router Interface [%u] type is not supported.\n",
                   ((sx_l2_ib_router_interface_t*)(router_interfaces[rif_list[i]].l2_att))->type);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        err = __ib_router_mc_egress_neigh_set(vrid,
                                              source_addr,
                                              mc_group_addr,
                                              ingress_rif,
                                              neigh_param_num,
                                              mc_ipoib_egress_neigh_param_arr);
        break;

    /* case SX_ACCESS_CMD_EDIT: */
    case SX_ACCESS_CMD_DELETE:
        err = __ib_router_mc_egress_neigh_delete(SX_ACCESS_CMD_DELETE,
                                                 vrid,
                                                 source_addr,
                                                 mc_group_addr,
                                                 ingress_rif,
                                                 mlid_list,
                                                 neigh_param_num);
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        err = router_db_mc_egress_rifs_set(SX_ACCESS_CMD_DELETE_ALL,
                                           vrid,
                                           source_addr,
                                           mc_group_addr,
                                           ingress_rif,
                                           NULL,
                                           0);
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

out:
    if (mlid_list != NULL) {
        CL_FREE_N_NULL(mlid_list);
    }
    if (rif_list != NULL) {
        M_UTILS_MEM_PUT(rif_list, UTILS_MEM_TYPE_ID_ROUTER_E, "Neighbor information", mem_err);
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t ib_router_mc_egress_get(const sx_router_id_t        vrid,
                                    const sx_ip_prefix_t       *source_addr,
                                    const sx_ip_prefix_t       *mc_group_addr,
                                    const sx_router_interface_t ingress_rif,
                                    uint32_t                   *neigh_param_num,
                                    sx_mc_ipoib_adj_t          *mc_ipoib_egress_neigh_param_arr)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = router_mc_egress_rif_params_validation(SX_ACCESS_CMD_GET, vrid,
                                                 source_addr, mc_group_addr, NULL, *neigh_param_num);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("VRID (%d) param validation is failed. err: %d.\n", vrid, err);
        goto out;
    }

    err = __ib_router_db_mc_egress_neigh_get(vrid, source_addr, mc_group_addr, ingress_rif,
                                             neigh_param_num, mc_ipoib_egress_neigh_param_arr);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("router_db_mc_get for vrid %d failed, err: %s.\n",
                   vrid, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __router_ib_mc_device_ready_callback(adviser_event_e event_type, void *param)
{
    sx_dev_info_t *dev_info_p = NULL;
    sx_status_t    sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG(SX_LOG_DEBUG, "Device add callback: %s called.\n", __func__);

    if (event_type != ADVISER_EVENT_POST_DEVICE_READY_E) {
        SX_LOG(SX_LOG_ERROR, "Wrong event type, expected event type is"
               " ADVISER_EVENT_POST_DEVICE_READY, received event type: [%s].\n",
               ADVISER_EVENT_STR(event_type));

        sx_status = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    dev_info_p = (sx_dev_info_t*)(param);
    if ((dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE) ||
        (dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE_LOCAL)) {
        goto out;
    }

    if (router_module_enabled == 0) {
        SX_LOG(SX_LOG_ERROR, "Called before router_init_params_s. Failed to initialize device [%u]"
               "router resources.\n", dev_info_p->dev_id);
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    sx_status = __ib_router_set_mc_neigh_sync_to_dev(dev_info_p->dev_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to sync mc_egress_neigh  to device [%u] \n",
               dev_info_p->dev_id);
        goto out;
    }

    sx_status = __ib_router_mc_entry_egress_neigh_sync_to_dev(dev_info_p->dev_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to sync mc_egress_neigh  to device [%u] \n",
               dev_info_p->dev_id);
        goto out;
    }

    SX_LOG_EXIT();

out:
    return sx_status;
}
