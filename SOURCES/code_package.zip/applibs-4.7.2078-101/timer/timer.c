/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#define __FDB_UC_IMPL_C_FILE__

#include <complib/sx_log.h>
#include <complib/cl_dbg.h>

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "utils/sx_internal.h"
#include "timer.h"
#include <complib/cl_thread.h>
#include <sx_core/sx_core_api.h>
#include <sx_core/sx_core_cmd_db.h>
#include <sx/sxd/sxd_access_register.h>
#include <unistd.h>

#undef  __MODULE__
#define __MODULE__ TIMER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static sx_add_intern_job_cb __add_internal_job_cb = NULL;

typedef struct timer_background_api_job_info {
    uint32_t api_opcode;
    uint32_t interval_in_cycles;        /* this background job will run every "interval" timer cycles */
} timer_background_api_job_info_t;

static timer_background_api_job_info_t permanent_bg_api_jobs_list[] = {
    {SX_API_INT_CMD_PSORT_BACKGROUND_SET_E,            1},
    {SX_API_INT_CMD_ECMP_BACKGROUND_SET_E,             1},
    {SX_API_INT_CMD_BA_BACKGROUND_SET_E,               1},
    {SX_API_INT_CMD_MC_CONTAINER_BACKGROUND_SET_E,     1},
    {SX_API_INT_CMD_ATCAM_ERP_OPTIMIZE_E,              16},  /* Execute the ATCAM ERP Optimize BG task only every 16 seconds */
#ifndef IB_PRESENT_FLAG
    {SX_API_INT_CMD_ROUTER_UC_ROUTE_BACKGROUND_SET_E,  16},  /* Execute the UC Route BG task only every 16 seconds */
    {SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_IPV4_E, SX_TIMER_OPT_INTERVAL_INVALID},  /* Initially opt time is invalid (0) this mean this jobs won't run */
    {SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_IPV6_E, SX_TIMER_OPT_INTERVAL_INVALID},  /* Initially opt time is invalid (0) this mean this jobs won't run */
#endif
#ifdef ATCAM_POLLING_COUNTER
    {SX_API_INT_CMD_ATCAM_COUNTERS_SAMPLING_E,         1},
#endif
};

#define TIMER_PERMANENT_BG_API_JOBS_LIST_LEN \
    (sizeof(permanent_bg_api_jobs_list) /    \
     sizeof(permanent_bg_api_jobs_list[0]))
#define TIMER_DYNAMIC_BG_API_JOBS_NUM 4
#define TIMER_BG_API_JOBS_NUM_MAX     (TIMER_PERMANENT_BG_API_JOBS_LIST_LEN + TIMER_DYNAMIC_BG_API_JOBS_NUM)

typedef struct timer_background_api_job {
    cl_list_item_t                  list_item;
    cl_pool_item_t                  pool_item;
    timer_background_api_job_info_t api_job;
} timer_background_api_job_t;

/* fdb_polling_data moved to H file and became public */
typedef struct timer_info {
    cl_thread_t         polling_timer_thread;
    boolean_t           polling_exit_signal_issued;
    boolean_t           polling_enabled;
    sx_timer_interval_t polling_interval;
    cl_spinlock_t       polling_lock;
    uint8_t             data;
    boolean_t           polling_exited;
    uint32_t            opt_tree_polling_time;
    cl_qpool_t          timer_bg_jobs_pool;
    boolean_t           timer_bg_jobs_pool_init_done;
    cl_qlist_t          timer_bg_jobs_list; /* list which contains background API jobs */
    boolean_t           timer_bg_jobs_list_init_done;
} timer_info_t;

/************************************************
 *  Local function declarations
 ***********************************************/

static void __timer_thread(void *context);
static timer_info_t timer_data;

/************************************************
 *  Function implementations
 ***********************************************/

/**********************************************
 *  Public functions
 ***********************************************/

sx_status_t timer_log_verbosity_level(IN sx_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SX_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}


pthread_t sx_timer_get_thread_tid()
{
    return (timer_data.polling_timer_thread.osd.id);
}

cl_thread_t* sx_timer_get_thread_obj()
{
    return &(timer_data.polling_timer_thread);
}

void sx_timer_set_exit_signal_issued(boolean_t signal_issued)
{
    timer_data.polling_exit_signal_issued = signal_issued;
}

void sx_timer_clear_thread_tid()
{
    if (timer_data.polling_exited == TRUE) {
        timer_data.polling_timer_thread.osd.id = (pthread_t)NULL;
    } else {
        SX_LOG(SX_LOG_NOTICE, "Could not clear timer thread ID, thread is still alive\n");
    }
}


/**
 *  See description of fdb_polling_interval_set function.
 *
 *
 */
sx_status_t sx_timer_interval_set(sx_timer_interval_t polling_interval)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!SX_TIMER_INTERVAL_CHECK_RANGE(polling_interval)) {
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("The timer interval (%d) is assigned with a value out of the allowed range.\n",
                   polling_interval);
        goto out;
    }
    timer_data.polling_interval = polling_interval;

out:
    SX_LOG_EXIT();
    return status;
}

/**
 *  See description of fdb_polling_interval_set function.
 *
 *
 */
sx_status_t sx_timer_opt_tree_polling_time_set(sx_timer_interval_t polling_interval)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    timer_data.opt_tree_polling_time = polling_interval;

    /* LPM optimization polling time is called on router deinit to set invalid value (disable polling)
     * and router deinit can also be called from deinit flow when timer thread is stopped and
     * background jobs list is deinitialized */
    if (timer_data.timer_bg_jobs_list_init_done == TRUE) {
        sx_timer_add_api_to_bg_jobs_list(SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_IPV4_E,
                                         polling_interval);
        sx_timer_add_api_to_bg_jobs_list(SX_API_INT_CMD_ROUTER_LPM_TREE_OPTIMIZE_TRIGGER_IPV6_E,
                                         polling_interval);
    }

    SX_LOG_EXIT();
    return status;
}


void sx_timer_register_cb(sx_add_intern_job_cb cb)
{
    __add_internal_job_cb = cb;
}

/* Comparison function */
cl_status_t __sx_timer_bg_jobs_list_cmp(const cl_list_item_t * const list_item_p, void *context)
{
    timer_background_api_job_t *bg_job_list_entry_p =
        PARENT_STRUCT(list_item_p, timer_background_api_job_t, list_item);

    if (bg_job_list_entry_p->api_job.api_opcode == *((uint32_t*)context)) {
        return CL_SUCCESS;
    } else {
        return CL_NOT_FOUND;
    }
}

sx_status_t validate_api_opcode(uint32_t api_opcode)
{
    sx_status_t rc = SX_STATUS_ERROR;
    uint32_t    i;

    for (i = 0; i < TIMER_PERMANENT_BG_API_JOBS_LIST_LEN; i++) {
        /* populate list with permanents background api jobs */
        if (api_opcode == permanent_bg_api_jobs_list[i].api_opcode) {
            rc = SX_STATUS_SUCCESS;
            break;
        }
    }

    return rc;
}

sx_status_t sx_timer_add_api_to_bg_jobs_list(uint32_t api_opcode, uint32_t interval_in_cycles)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    cl_pool_item_t             *pool_item_p = NULL;
    timer_background_api_job_t *bg_api_job_list_entry_p = NULL;
    cl_list_item_t             *list_item_p = NULL;

    SX_LOG_ENTER();

    cl_spinlock_acquire(&timer_data.polling_lock);

    if (timer_data.timer_bg_jobs_list_init_done == FALSE) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("BG jobs list isn't initialized. Error: (%s).\n", sx_status_str(rc));
        goto out;
    }

    rc = validate_api_opcode(api_opcode);
    if (rc) {
        SX_LOG_ERR("API opcode %d isn't supported.\n", api_opcode);
        goto out;
    }

    list_item_p = cl_qlist_find_from_head(&timer_data.timer_bg_jobs_list,
                                          __sx_timer_bg_jobs_list_cmp,
                                          &api_opcode);
    if (list_item_p != cl_qlist_end(&timer_data.timer_bg_jobs_list)) {
        /* API is already in the BG jobs list */
        bg_api_job_list_entry_p = PARENT_STRUCT(list_item_p, timer_background_api_job_t, list_item);
        bg_api_job_list_entry_p->api_job.interval_in_cycles = interval_in_cycles;
    } else {
        /* get item from the pool */
        pool_item_p = cl_qpool_get(&timer_data.timer_bg_jobs_pool);
        if (!pool_item_p) {
            rc = SX_STATUS_NO_RESOURCES;
            SX_LOG_ERR("No resources in BG jobs pool.\n");
            goto out;
        }

        bg_api_job_list_entry_p = PARENT_STRUCT(pool_item_p, timer_background_api_job_t, pool_item);
        cl_qlist_insert_tail(&timer_data.timer_bg_jobs_list, &(bg_api_job_list_entry_p->list_item));

        bg_api_job_list_entry_p->api_job.api_opcode = api_opcode;
        bg_api_job_list_entry_p->api_job.interval_in_cycles = interval_in_cycles;
    }

out:
    cl_spinlock_release(&timer_data.polling_lock);
    SX_LOG_EXIT();
    return rc;
}

sx_status_t sx_timer_del_api_from_bg_job_list(uint32_t api_opcode)
{
    timer_background_api_job_t *bg_job_list_entry_p = NULL;
    cl_list_item_t             *list_item_p = NULL;
    sx_status_t                 rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    cl_spinlock_acquire(&timer_data.polling_lock);

    if (timer_data.timer_bg_jobs_list_init_done == FALSE) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("BG jobs list isn't initialized. Error: (%s).\n", sx_status_str(rc));
        goto out;
    }

    list_item_p = cl_qlist_find_from_head(&timer_data.timer_bg_jobs_list,
                                          __sx_timer_bg_jobs_list_cmp,
                                          &api_opcode);
    if (list_item_p == cl_qlist_end(&timer_data.timer_bg_jobs_list)) {
        SX_LOG_DBG("Error not found API opcode %d in bg jobs list.\n", api_opcode);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    bg_job_list_entry_p = PARENT_STRUCT(list_item_p, timer_background_api_job_t, list_item);
    cl_qlist_remove_item(&timer_data.timer_bg_jobs_list, list_item_p);
    cl_qpool_put(&timer_data.timer_bg_jobs_pool,
                 &bg_job_list_entry_p->pool_item);

out:
    cl_spinlock_release(&timer_data.polling_lock);
    SX_LOG_EXIT();
    return rc;
}


/* no lock is needed because lock is done in upper layer */
sx_status_t sx_timer_bg_jobs_list_delete_all_apis()
{
    timer_background_api_job_t *bg_job_list_entry_p = NULL;
    cl_list_item_t             *list_item_p = NULL;
    sx_status_t                 rc = SX_STATUS_SUCCESS;

    if (timer_data.timer_bg_jobs_list_init_done == FALSE) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("BG jobs list isn't initialized. Error: (%s).\n", sx_status_str(rc));
        goto out;
    }

    list_item_p = cl_qlist_head(&timer_data.timer_bg_jobs_list);
    while (list_item_p != cl_qlist_end(&timer_data.timer_bg_jobs_list)) {
        bg_job_list_entry_p = PARENT_STRUCT(list_item_p, timer_background_api_job_t, list_item);
        SX_LOG_DBG("Delete API opcode %d from bg jobs list.\n", bg_job_list_entry_p->api_job.api_opcode);
        list_item_p = cl_qlist_next(list_item_p);
        cl_qlist_remove_item(&timer_data.timer_bg_jobs_list, &bg_job_list_entry_p->list_item);
        cl_qpool_put(&timer_data.timer_bg_jobs_pool, &bg_job_list_entry_p->pool_item);
    }

out:
    return rc;
}

sx_status_t __sx_timer_bg_job_list_api_dump(FILE* stream, boolean_t is_debug_dump_flow)
{
    timer_background_api_job_t *bg_job_list_entry_p = NULL;
    cl_list_item_t             *list_item_p = NULL;
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    const char                * cmd_name = NULL;
    uint32_t                    api_opcode, interval;
    dbg_utils_table_columns_t   bg_job_apis_clmns[] = {
        { "API name",    50,        PARAM_EXT_STRING_E,  cmd_name},
        { "Interval (cycles)", 20,  PARAM_UINT32_E,      &interval},
        {NULL, 0, 0, NULL}
    };

    cl_spinlock_acquire(&timer_data.polling_lock);

    /* this is a dump function, so it will silently exit without an error when timer_bg_jobs_list_init_done is FALSE*/
    if (timer_data.timer_bg_jobs_list_init_done == FALSE) {
        SX_LOG_DBG("api dump: exit because BG jobs list isn't initialized.\n");
        goto out;
    }

    if (is_debug_dump_flow == FALSE) {
        dbg_utils_print(stream, "Background jobs API list (interval 0 means disabled):\n");
    } else {
        dbg_utils_pprinter_general_header_print(stream, "Background jobs API list:");
        dbg_utils_pprinter_table_headline_print(stream, bg_job_apis_clmns);
    }

    list_item_p = cl_qlist_head(&timer_data.timer_bg_jobs_list);
    while (list_item_p != cl_qlist_end(&timer_data.timer_bg_jobs_list)) {
        bg_job_list_entry_p = PARENT_STRUCT(list_item_p, timer_background_api_job_t, list_item);
        SX_LOG_DBG("Delete API opcode %d from bg jobs list.\n", bg_job_list_entry_p->api_job.api_opcode);
        list_item_p = cl_qlist_next(list_item_p);

        rc = sx_core_get_api_command_name(bg_job_list_entry_p->api_job.api_opcode, &cmd_name);
        if (rc) {
            SX_LOG_ERR("Failed to API command name. Error: (%s).\n", sx_status_str(rc));
            goto out;
        }

        api_opcode = bg_job_list_entry_p->api_job.api_opcode;
        interval = bg_job_list_entry_p->api_job.interval_in_cycles;

        if (is_debug_dump_flow == FALSE) {
            fprintf(stream, "%s, API opcode:%d, interval_in_cycles:%d \n", cmd_name, api_opcode, interval);
        } else {
            /* to reduce the string size and to hide the full name */
            bg_job_apis_clmns[0].data = cmd_name + strlen("SX_API_INT_CMD_");
            dbg_utils_pprinter_table_data_line_print(stream, bg_job_apis_clmns);
        }
    }

out:
    cl_spinlock_release(&timer_data.polling_lock);
    return rc;
}

/* This function is called from debug cli */
sx_status_t sx_timer_bg_job_list_api_dump(FILE* stream)
{
    return __sx_timer_bg_job_list_api_dump(stream, FALSE);
}

/* This function is called from debug dump flow */
void sdk_timer_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    __sx_timer_bg_job_list_api_dump(dbg_dump_params_p->stream, TRUE);
}


sx_status_t sx_timer_init_background_jobs()
{
    cl_status_t cl_err = CL_SUCCESS;
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    api_opcode;
    uint32_t    interval_in_cycles;
    uint32_t    i;

    /* init pool for BG API jobs */
    cl_err = CL_QPOOL_INIT(&(timer_data.timer_bg_jobs_pool),
                           TIMER_BG_API_JOBS_NUM_MAX,
                           TIMER_BG_API_JOBS_NUM_MAX, 0,
                           sizeof(timer_background_api_job_t),
                           NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Failed to init timer BG API jobs pool. Error: (%s).\n",
                   CL_STATUS_MSG(cl_err));
        rc = SX_STATUS_ERROR;
        goto out;
    }
    timer_data.timer_bg_jobs_pool_init_done = TRUE;

    /* init BG API jobs DB */
    cl_qlist_init(&(timer_data.timer_bg_jobs_list));
    timer_data.timer_bg_jobs_list_init_done = TRUE;

    for (i = 0; i < TIMER_PERMANENT_BG_API_JOBS_LIST_LEN; i++) {
        /* populate list with permanents background api jobs */
        api_opcode = permanent_bg_api_jobs_list[i].api_opcode;
        interval_in_cycles = permanent_bg_api_jobs_list[i].interval_in_cycles;
        rc = sx_timer_add_api_to_bg_jobs_list(api_opcode, interval_in_cycles);
        if (rc) {
            SX_LOG_ERR("Failed to add api opcode %d to timer BG API jobs list. Error: (%s).\n",
                       api_opcode, sx_status_str(rc));
            goto out;
        }
    }

out:
    if (rc) {
        if (timer_data.timer_bg_jobs_pool_init_done) {
            CL_QPOOL_DESTROY(&(timer_data.timer_bg_jobs_pool));
        }
    }
    SX_LOG_EXIT();
    return rc;
}

/* deinit background jobs list */
void sx_timer_deinit_background_jobs()
{
    cl_spinlock_acquire(&timer_data.polling_lock);

    /* delete all entries from the list */
    if (timer_data.timer_bg_jobs_list_init_done) {
        sx_timer_bg_jobs_list_delete_all_apis();
        timer_data.timer_bg_jobs_list_init_done = FALSE;
    }

    /* pool destroy */
    if (timer_data.timer_bg_jobs_pool_init_done) {
        CL_QPOOL_DESTROY(&(timer_data.timer_bg_jobs_pool));
        timer_data.timer_bg_jobs_pool_init_done = FALSE;
    }

    cl_spinlock_release(&timer_data.polling_lock);
}

sx_status_t sx_timer_init()
{
    cl_status_t cl_err = CL_SUCCESS;
    sx_status_t rc = SX_STATUS_SUCCESS;

    timer_data.polling_enabled = FALSE;
    timer_data.polling_timer_thread.osd.id = 0;
    timer_data.polling_exit_signal_issued = FALSE;
    timer_data.data = 0;
    timer_data.polling_exited = FALSE;
    cl_spinlock_init(&timer_data.polling_lock);

    rc = sx_timer_init_background_jobs();
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not init background jobs\n");
        goto out;
    }

    cl_err = cl_thread_init(&(timer_data.polling_timer_thread),
                            __timer_thread,
                            NULL,
                            "timers",
                            THREAD_MAX_ALLOWED_TIME_DEFAULT);
    if (cl_err != CL_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not create timer thread\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    cl_spinlock_acquire(&timer_data.polling_lock);
    timer_data.polling_enabled = TRUE;
    cl_spinlock_release(&timer_data.polling_lock);

out:
    if (rc) {
        sx_timer_deinit_background_jobs();
    }

    return rc;
}

static void __timer_thread(void *context)
{
    sx_timer_interval_t interval;
    uint32_t            icount;
    uint64_t            job_count = 0;
    /** Caching the bp_ctl DB entry for this thread.
     *  This variable is used due to performance concerns.
     *  It allows accessing the Process Background DB entry of the current thread
     *  without requesting the entry each time from the DB. One more point:
     *  that in such a way, we omit the continuous need to acquire the spinlock.*/
    cl_dbg_bp_ctl_db_entry_t *bp_ctl_db_entry_p = NULL;
    struct timeval            timeout;
    int                       hc_fd = -1;
    fd_set                    read_fds;
    int                       rc = 0;

#ifndef IB_PRESENT_FLAG
    sx_api_router_lpm_tree_optimize_trigger_params_t cmd_body;
    SX_MEM_CLR(cmd_body);
#endif

    UNUSED_PARAM(context);
    memset(&timeout, 0, sizeof(timeout));
    timer_data.polling_exited = FALSE;
    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, TRUE);
    cl_dbg_bp_ctl_thread_period_register(&bp_ctl_db_entry_p, &timer_data.polling_interval,
                                         SX_CORE_POLLING_SLEEPING_INTERVAL_uS);

    if (bp_ctl_db_entry_p != NULL) {
        hc_fd = bp_ctl_db_entry_p->health_check_fd;
    }
    while (TRUE) {
        FD_ZERO(&read_fds);
        interval = cl_dbg_bp_ctl_thread_period_get(bp_ctl_db_entry_p, timer_data.polling_interval);

        /*  Sleep base unit [SX_CORE_POLLING_SLEEPING_INTERVAL_uS] * number of intervals
         *   Sleeping originally was done for all period continuously. Now, we break the sleep into the smallest unit,
         *   so we can check if external event like CTRL-C needs this thread to quickly finish.
         *   Working this way introduce a small overhead (recall usleep every SX_CORE_POLLING_SLEEPING_INTERVAL_uS)
         *   but it is anyway the default. Make sure to farther break it if SX_CORE_POLLING_SLEEPING_INTERVAL_uS is changed
         *   to an higher value than 100 mili seconds.
         *   We can consider other (more complicated) ways to wake the thread from long sleep:
         *       a. Changing to pthread_cond_timedwait() which can be interrupted
         *       b. Changing to sleep-interruptible and sending Signal to this thread using pthread_kill(thread,signal),
         *          to abort the sleep - need to write signal handler. */
        for (icount = 0; icount <= interval; icount++) {
            if (hc_fd < 0) {
                usleep(SX_CORE_POLLING_SLEEPING_INTERVAL_uS);
            } else {
                timeout.tv_usec = SX_CORE_POLLING_SLEEPING_INTERVAL_uS;
                FD_ZERO(&read_fds);
                FD_SET(hc_fd, &read_fds);
                cl_fd_wait_on(hc_fd, &read_fds, NULL, &timeout, &rc);
                if (rc < 0) {
                    SX_LOG_ERR("timer thread: select() failed [err=%d]\n", rc);
                }
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, FALSE);
            }

            /* check if it is time to die in thread sleep time */
            if (timer_data.polling_exit_signal_issued == TRUE) {
                SX_LOG_NTC("Thread __timer_thread is gracefully ending.\n");
                timer_data.polling_exited = TRUE;

                /* background jobs will be deinitialized at timer thread end */
                sx_timer_deinit_background_jobs();
                return;  /* thread ends */
            }
        }  /* for intervals */
        usleep(cl_dbg_bp_ctl_thread_period_mod_get(bp_ctl_db_entry_p));
        /* The job_count will be used for jobs that do not need to be executed every time */
        job_count++;

        /* check if it is time to die (in case interval is 0 it is not checked in loop...) */
        if (timer_data.polling_exit_signal_issued == TRUE) {
            SX_LOG_NTC("Thread __timer_thread is gracefully ending..\n");
            timer_data.polling_exited = TRUE;
            /* background jobs will be deinitialized at timer thread end */
            sx_timer_deinit_background_jobs();
            return;  /* thread ends */
        }
        cl_dbg_bp_ctl_thread_sync(&bp_ctl_db_entry_p);

        if (__add_internal_job_cb) {
            cl_spinlock_acquire(&timer_data.polling_lock);
            if (timer_data.polling_enabled) {
                if (timer_data.timer_bg_jobs_list_init_done) {
                    timer_background_api_job_t *bg_job_list_entry_p = NULL;
                    cl_list_item_t             *list_item_p = NULL;

                    list_item_p = cl_qlist_head(&timer_data.timer_bg_jobs_list);
                    while (list_item_p != cl_qlist_end(&timer_data.timer_bg_jobs_list)) {
                        /*bg_job_list_entry_p = CL_QLIST_PARENT_STRUCT(timer_background_api_job_t); */
                        bg_job_list_entry_p = PARENT_STRUCT(list_item_p, timer_background_api_job_t, list_item);
                        list_item_p = cl_qlist_next(list_item_p);

                        if ((bg_job_list_entry_p->api_job.interval_in_cycles == SX_TIMER_OPT_INTERVAL_INVALID) ||
                            ((job_count % bg_job_list_entry_p->api_job.interval_in_cycles) != 0)) {
                            continue;
                        }

                        __add_internal_job_cb(bg_job_list_entry_p->api_job.api_opcode, (uint8_t*)&(timer_data.data),
                                              sizeof(timer_data.data), SX_CORE_LOW_PRIO_BUF_E);
                    }
                }
            }
            cl_spinlock_release(&timer_data.polling_lock);
        } else {
            SX_LOG_ERR("Add internal job callback is null \n");
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        }
    }

    timer_data.polling_exited = TRUE;
}
