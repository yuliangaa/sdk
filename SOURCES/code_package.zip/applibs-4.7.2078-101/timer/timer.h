/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __TIMER_H_INCL__
#define __TIMER_H_INCL__

#include <complib/cl_thread.h>
#include <sx/sxd/sxd_swid.h>
#include "dbg/dbg_dump/dbg_dump_common.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#if defined(PD_BU)
#define SX_CORE_POLLING_SLEEPING_INTERVAL_uS 30000000
#else
#define SX_CORE_POLLING_SLEEPING_INTERVAL_uS 100000
#endif

#define SX_TIMER_OPT_INTERVAL_INVALID 0
/**
 * FDB maximum/minimum poll interval time values.
 */
#define SX_TIMER_INTERVAL_DECISEC_MIN 1
#define SX_TIMER_INTERVAL_DECISEC_MAX (10 * 60 * 60)

/************************************************
 *  Macros
 ***********************************************/

#define SX_TIMER_INTERVAL_CHECK_RANGE(INTERVAL) \
    SX_CHECK_RANGE(SX_TIMER_INTERVAL_DECISEC_MIN, INTERVAL, SX_TIMER_INTERVAL_DECISEC_MAX)

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * Timer rate.
 */
typedef uint32_t sx_timer_interval_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  Public functions
 ***********************************************/

pthread_t sx_timer_get_thread_tid();
cl_thread_t* sx_timer_get_thread_obj();

void sx_timer_set_exit_signal_issued(boolean_t signal_issued);

void sx_timer_clear_thread_tid();

/************************************************
 *  API functions
 ***********************************************/

/**
 * This function sets the log verbosity level of TIMER MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *  @return SX_STATUS_ERROR   general error
 */
sx_status_t timer_log_verbosity_level(IN sx_access_cmd_t       cmd,
                                      IN sx_verbosity_level_t *verbosity_level_p);


/**
 * Timer initialization command of DB
 *
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 * @return SX_STATUS_ERROR if any input parameter is invalid
 *
 */
sx_status_t sx_timer_init();


/**
 *  This function sets the Timer polling interval time in seconds.
 *  Polling interval determines the time interval to trigger a job
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameter is
 *         invalid
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if parameter exceed its
 *         range
 * @return SX_STATUS_ERROR if unexpected behavior occurs
 *
 */
sx_status_t sx_timer_interval_set(sx_timer_interval_t polling_interval);


/**
 *  This function registers on an add internal job callback
 *
 * @param[in] )cb - registration callback
 *
 * @return void
 */
void sx_timer_register_cb(sx_add_intern_job_cb cb);

/**
 *  This function set routing tree optimization background job interval
 *
 * @param[in] )cb - registration callback
 *
 * @return void
 */
sx_status_t sx_timer_opt_tree_polling_time_set(sx_timer_interval_t polling_interval);

/**
 *  This function dump all background jobs to debug cli output
 */
sx_status_t sx_timer_bg_job_list_api_dump(FILE* stream);


/**
 *  This function add/set_interval to background job list
 */
sx_status_t sx_timer_add_api_to_bg_jobs_list(uint32_t api_opcode,
                                             uint32_t interval_in_cycles);

/**
 *  This function delete API from background job list
 */
sx_status_t sx_timer_del_api_from_bg_job_list(uint32_t api_opcode);

/**
 *  This function dump all background jobs to debug dump file
 */
void sdk_timer_debug_dump(dbg_dump_params_t *dbg_dump_params_p);


#endif /* __TIMER_H_INCL__ */
