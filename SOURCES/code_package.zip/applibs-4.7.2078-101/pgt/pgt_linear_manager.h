/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef APPLIBS_PGT_PGT_LINEAR_MANAGER_H_
#define APPLIBS_PGT_PGT_LINEAR_MANAGER_H_

#include <sx/sdk/sx_types.h>
#include <sx/utils/linear_manager.h>
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef enum {
    PGT_LINEAR_MANAGER_USER_ID_RMID_MANAGER_E    = 0,
    PGT_LINEAR_MANAGER_USER_ID_FINE_GRAIN_LAG_E  = 1,
    PGT_LINEAR_MANAGER_USER_ID_FDB_E             = 2,
    PGT_LINEAR_MANAGER_USER_ID_SMID_MANAGER_E    = 3,
    PGT_LINEAR_MANAGER_USER_ID_LAG_TABLE_E       = 4,
    PGT_LINEAR_MANAGER_USER_ID_ADAPTIVE_ROUTER_E = 5,
    PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_FID_E  = 6,
    PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_RFID_E = 7,
    PGT_LINEAR_MANAGER_USER_ID_DEFAULT_E         = 0xFF,
    PGT_LINEAR_MANAGER_USER_ID_MIN_E             = PGT_LINEAR_MANAGER_USER_ID_RMID_MANAGER_E,
    PGT_LINEAR_MANAGER_USER_ID_MAX_E             = PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_RFID_E,
    PGT_LINEAR_MANAGER_USER_ID_MAX_NOT_CFF_E     = PGT_LINEAR_MANAGER_USER_ID_ADAPTIVE_ROUTER_E,   /* if added other client it has to be after AR and modify this define accordingly */
    PGT_LINEAR_MANAGER_USER_ID_NUM_E             = PGT_LINEAR_MANAGER_USER_ID_MAX_E + 1
} pgt_linear_manager_user_id_e;

static __attribute__((__used__)) const char* pgt_linear_manager_user_id_str[] = {
    "RMID MANAGER",
    "FGL",
    "FDB",
    "SMID MANAGER",
    "LAG TABLE",
    "ADAPTIVE ROUTER",
    "COMPRESSED FID",
    "COMPRESSED RFID"
};


#define PGT_LINEAR_MANAGER_USER_ID_STR_SIZE (sizeof(pgt_linear_manager_user_id_str) / sizeof(char*))

#define PGT_LINEAR_MANAGER_USER_ID_STR(index)                       \
    (SX_CHECK_MAX(index, PGT_LINEAR_MANAGER_USER_ID_STR_SIZE - 1) ? \
     pgt_linear_manager_user_id_str[index] : "UNKNOWN")             \

#define PGT_LINEAR_MANAGER_USER_ID_RANGE(user)           \
    SX_CHECK_MAX(user, PGT_LINEAR_MANAGER_USER_ID_MAX_E) \

#define PGT_LINEAR_MANAGER_MAX_ALLOC_SIZES LINEAR_MANAGER_MAX_ALLOC_SIZES
typedef linear_manager_handle_t pgt_linear_manager_handle_t;

typedef linear_manager_index_t pgt_linear_manager_index_t;

typedef linear_manager_block_length_t pgt_linear_manager_block_length_t;
/**
 * Callback function.
 * Relocates block from old index to new index and changes all
 * the references to the block.
 * This callback is called when bin allocator relocates a block
 * @param handle                [in] Handle to the relocated block
 * @param size                  [in] Block size
 * @param old_index             [in] Index to relocate from
 * @param new_index             [in] New index to relocate to
 * In case data is contiguous block offset will be 0. Size is the
 * block size, the contents from old_phy_id_p until old_phy_id_p+size
 * should be copied.
 */
typedef sx_status_t (*pgt_linear_manager_block_relocate_t) (pgt_linear_manager_handle_t       handle,
                                                            pgt_linear_manager_block_length_t size,
                                                            pgt_linear_manager_index_t        old_index,
                                                            pgt_linear_manager_index_t        new_index);

typedef struct pgt_linear_manager_relocate_data {
    char                          timestamp[20];
    pgt_linear_manager_user_id_e  user_id;
    linear_manager_handle_t       handle;
    linear_manager_block_length_t size;
    uint32_t                      old_index;
    uint32_t                      new_index;
} pgt_linear_manager_relocate_data_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/
/**
 * Initialize the PGT linear manager module
 *
 * @param start_index     [in]  First index in the PGT table
 * @param req_size        [in]  Requested size for PGT table
 * @param *supported_size [out] Supported size fot PGT table (aligned to pgt max allowed block size)
 *
 * @return SX_STATUS_SUCCESS if initialization completes successfully.
 * @return SX_STATUS_ALREADY_INITIALIZED if module was already initialized
 * @return SX_STATUS_PARAM_ERROR if given indexes are out of range
 * @return SX_STATUS_MEMORY_ERROR if no space for allocation
 */
sx_status_t pgt_linear_manager_init(uint32_t  start_index,
                                    uint32_t  req_size,
                                    uint32_t *aligned_size);

/**
 * Deinitialize PGT linear manager module
 *
 * @return SX_STATUS_SUCCESS if initialization completes successfully.
 * @return SX_STATUS_MODULE_UNINITIALIZED if module wasn't initialized.
 * @return SX_STATUS_ERROR if there are still users which didn't do deinit.
 */
sx_status_t pgt_linear_manager_deinit();

/**
 *  Initialize new user of th PGT linear manager.
 *
 * @param[in] user        - PGT user
 * @param[in] relocate_cb - relocate_cb
 *
 * @return SX_STATUS_SUCCESS if initialization completes successfully.
 * @return SX_STATUS_PARAM_ERROR if there is error in input parameters.
 * @return SX_STATUS_ALREADY_INITIALIZED if user was already initialized.
 */

sx_status_t pgt_linear_manager_user_init(pgt_linear_manager_user_id_e        user,
                                         pgt_linear_manager_block_relocate_t relocate_cb);

/**
 *  Deinitialize PGT linear manager user.
 *
 * @param[in] user        - PGT user
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_ERROR if there is error in input parameters.
 * @return SX_STATUS_MODULE_UNINITIALIZED if module wasn't initialized.
 */
sx_status_t pgt_linear_manager_user_deinit(pgt_linear_manager_user_id_e user);

/**
 *  Add PGT linear manager block for the given user.
 *  According to the reuse_handle parameter, allocates a new handle or reuse the given handle.
 *  If reuse_handle is TRUE, handle should be specified by the caller.
 *
 * @param[in] user              - PGT user
 * @param[in] size              - Block size
 * @param[in] reuse_handle      - if enabled, reuse the given handle and don't allocate a new handle.
 * @param[in,out] handle_p      - Handle to the new block
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_ERROR if there is error in input parameters.
 * @return SX_STATUS_MODULE_UNINITIALIZED if module wasn't initialized.
 */
sx_status_t pgt_linear_manager_block_add(pgt_linear_manager_user_id_e      user,
                                         pgt_linear_manager_block_length_t size,
                                         boolean_t                         reuse_handle,
                                         pgt_linear_manager_handle_t      *handle_p);

/**
 *  Delete PGT linear manager block for the given user.
 *
 * @param[in] handle_p      - Block handle
 * @param[in] reuse_handle  - if enabled, release the block and keep handle for future use.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_ERROR if there is error in input parameters.
 * @return SX_STATUS_ENTRY_NOT_FOUND if there is no block with the given handle.
 * @return SX_STATUS_MODULE_UNINITIALIZED if module wasn't initialized.
 */
sx_status_t pgt_linear_manager_block_delete(pgt_linear_manager_handle_t handle,
                                            boolean_t                   reuse_handle);

/**
 *  Locks the block which is represented by the given handle.
 *  Returns the HW index of this block.
 *
 * @param[in] handle      - Block handle
 * @param[out] index_p     - The HW indices of the locked block
 * @param[out] size_p      - The size of the locked block
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_ERROR if there is error in input parameters.
 * @return SX_STATUS_ENTRY_NOT_FOUND if there is no block with the given handle.
 * @return SX_STATUS_MODULE_UNINITIALIZED if module wasn't initialized.
 */
sx_status_t pgt_linear_manager_handle_lock(pgt_linear_manager_handle_t        handle,
                                           pgt_linear_manager_index_t        *index_p,
                                           pgt_linear_manager_block_length_t *size_p);

/**
 *  Add PGT linear manager block for the given user.
 *
 * @param[in] handle    - Block handle
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_ERROR if there is error in input parameters.
 * @return SX_STATUS_ENTRY_NOT_FOUND if there is no block with the given handle.
 * @return SX_STATUS_MODULE_UNINITIALIZED if module wasn't initialized.
 */
sx_status_t pgt_linear_manager_handle_release(pgt_linear_manager_handle_t handle);

/**
 *  returns a list of user id handles.
 *
 * @param[in]   user        - pgt_linear_manager_user_id_e.
 * @param[out] *handle_list - an array of user block handles.
 *                            if NULL input the handle_cnt will be returned.
 * @param[out] *handle_cnt  - the handle array size.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_ERROR if there is error in input parameters.
 * @return SX_STATUS_ENTRY_NOT_FOUND if there is no block with the given handle.
 * @return SX_STATUS_MODULE_UNINITIALIZED if module wasn't initialized.
 */
sx_status_t pgt_linear_manager_user_handle_get(pgt_linear_manager_user_id_e user,
                                               pgt_linear_manager_handle_t *handle_list,
                                               uint32_t                    *handle_cnt);
/**
 *  Add reference to PGT linear manager block with the given handle.
 *
 * @param[in] handle    - Block handle
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_ERROR if there is error in input parameters.
 * @return SX_STATUS_ENTRY_NOT_FOUND if there is no block with the given handle.
 * @return SX_STATUS_MODULE_UNINITIALIZED if module wasn't initialized.
 */
sx_status_t pgt_linear_manager_ref_add(pgt_linear_manager_handle_t handle);

/**
 *  Delete reference to PGT linear manager block with the given handle.
 *
 * @param[in] handle    - Block handle
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_ERROR if there is error in input parameters.
 * @return SX_STATUS_ENTRY_NOT_FOUND if there is no block with the given handle.
 * @return SX_STATUS_MODULE_UNINITIALIZED if module wasn't initialized.
 */
sx_status_t pgt_linear_manager_ref_delete(pgt_linear_manager_handle_t handle);


/**
 *  Set module's verbosity level.
 *
 * @param[in] verbosity_level    - verbosity level
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sx_status_t pgt_linear_manager_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

/**
 *  Print module's debug dump.
 *
 * @param[in] stream    - a stream for dump output
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sx_status_t pgt_linear_manager_dump(dbg_dump_params_t *dbg_dump_params_p);

/**
 * Set valid allocation size list for user in the global pgt
 * multiple size block list
 *
 * @param[in]      user                           pgt_linear_manager_user_id_e
 * @param[in]     *size_list                      requested allocation sizes list
 * @param[in]      size_list_cnt                  requested allocation sizes list count
 *
 * Note:
 * - in case of size_list NULL entry the
 *   remaining entries in the global list will be returned
 * - API to be invoked by users prior to pgt init.
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_MODULE_UNINITIALIZED if module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if list size is invalid.
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if requested size values exceed expected range.
 * @return SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT in case of insufficient space in global array.
 */
sx_status_t pgt_multiple_block_alloc_size_set(pgt_linear_manager_user_id_e user,
                                              uint32_t                    *size_list,
                                              uint32_t                     size_list_cnt);

/**
 * Swap between block indexes of 2 handles, blocks must be from the same type
 * and created by same user
 *
 * @param first_handle         [in] A handle to a block
 * @param second_handle        [in] A handle to a block
 *
 * @return SX_STATUS_PARAM_ERROR if handle s invalid
 */
sx_status_t pgt_linear_manager_swap_handles(pgt_linear_manager_handle_t first_handle,
                                            pgt_linear_manager_handle_t second_handle);


/**
 * API for other modules to verify if PGT is already initialized.
 * @return TRUE/FALSE;
 */
boolean_t pgt_linear_manager_is_initialized(void);

/**
 *
 * Set a flush routine in hw for the provided handle and size
 * @param[in]      handle                    A handle to a block
 * @param[in]      size                      size of the block
 *
 * Note:
 * Utilize IPFR EMAD which is supported from SPC2 in FW.
 *
 * @return SX_STATUS_SUCCESS   if operation completes successfully.
 * @return SX_STATUS_NO_MEMORY if memory allocation failed
 * @return SX_STATUS_ERROR     if EMAD transaction failed.
 *
 */
sx_status_t pgt_linear_manager_block_hw_flush_spc2(pgt_linear_manager_handle_t       handle,
                                                   pgt_linear_manager_block_length_t size);

#endif /* APPLIBS_PGT_PGT_LINEAR_MANAGER_H_ */
