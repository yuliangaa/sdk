/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#define PGT_C_

#undef  __MODULE__
#define __MODULE__ PGT

#include "sx/sdk/sx_status.h"
#include "resource_manager/resource_manager_hw_table.h"
#include "ethl2/fdb_flood.h"
#include "ethl2/fdb_compressed_flood_manager.h"
#include "ethl2/vlan.h"
#include "pgt/pgt_linear_manager.h"

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/

static boolean_t g_pgt_initialized = FALSE;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t pgt_init(sx_api_sx_sdk_init_t *sx_sdk_params)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_status_t    rb_err = SX_STATUS_SUCCESS;
    uint32_t       start_idx = 0, req_hw_table_size = 0, aligned_hw_table_size = 0, fctr = 1, fid_table_size = 0;
    boolean_t      pgt_linear_initialized = FALSE;
    sx_boot_mode_e issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    sx_issu_bank_e issu_bank = SX_ISSU_BANK_1_E;

    SX_LOG_ENTER();

    if (g_pgt_initialized) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("PGT module is already initialized\n");
        goto out;
    }

    if (rm_resource_global.pgt_size == 0) {
        SX_LOG_DBG("PGT size is 0 - no need to initialize PGT on this system\n");
        goto out;
    }

    if (utils_check_pointer(sx_sdk_params, "sx_sdk_params")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = issu_boot_mode_get(&issu_boot_mode);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to issu_boot_mode_get sx_status = %s\n",
                   sx_status_str(err));
        goto out;
    }
    if (issu_boot_mode != SX_BOOT_MODE_DISABLED_E) {
        err = issu_bank_get(&issu_bank);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to issu bank sx_status = %s\n",
                       sx_status_str(err));
            goto out;
        }

        fctr = 2;
    }

    if (rm_resource_global.flood_control_mode != FLOOD_MODE_CFF) {
        err = fdb_flood_tables_size_get(&fid_table_size);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get the size of flooding tables, err = [%s]\n", sx_status_str(err));
            goto out;
        }
    }
    req_hw_table_size = ((rm_resource_global.pgt_size - 1) / fctr) - fid_table_size;
    if (issu_bank == SX_ISSU_BANK_2_E) {
        /* Move start index after fid table */
        start_idx = ((rm_resource_global.pgt_size - 1) / fctr) + fid_table_size;
    } else {
        start_idx = fid_table_size;
    }

    err = pgt_linear_manager_init(start_idx, req_hw_table_size, &aligned_hw_table_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to initialize PGT linear manager with start index %u and size %u, err = [%s]\n",
                   start_idx,
                   req_hw_table_size,
                   sx_status_str(err));
        goto out;
    }

    pgt_linear_initialized = TRUE;

    rm_resource_global.rm_hw_tables_attrb[RM_HW_TABLE_TYPE_PGT_E].rm_hw_table_size = aligned_hw_table_size;
    rm_resource_global.rm_hw_tables_attrb[RM_HW_TABLE_TYPE_PGT_E].rm_hw_table_supported = TRUE;
    err = rm_hw_table_init_resource(RM_HW_TABLE_TYPE_PGT_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to initialize PGT in resource manager with size %u, err = [%s]\n",
                   rm_resource_global.rm_hw_tables_attrb[RM_HW_TABLE_TYPE_PGT_E].rm_hw_table_size,
                   sx_status_str(err));
        goto out;
    }

    SX_LOG_NTC("PGT module is initialized. Start index: %u\n", start_idx);
    g_pgt_initialized = TRUE;

out:
    if (SX_CHECK_FAIL(err)) {
        if (pgt_linear_initialized) {
            rb_err = pgt_linear_manager_deinit();
            if (SX_CHECK_FAIL(rb_err)) {
                SX_LOG_ERR("Failed to deinitialize PGT linear manager, err = [%s]\n",
                           sx_status_str(rb_err));
            }
        }
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t pgt_deinit(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_pgt_initialized) {
        SX_LOG_DBG("PGT is not initialized\n");
        goto out;
    }

    err = pgt_linear_manager_deinit();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinitialize PGT linear manager, err = [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    err = rm_hw_table_deinit_resource(RM_HW_TABLE_TYPE_PGT_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinitialize PGT in resource manager, err = [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    g_pgt_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t pgt_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return rc;
}
