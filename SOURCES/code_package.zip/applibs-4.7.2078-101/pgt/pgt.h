/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef PGT_H_
#define PGT_H_

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initialize the PGT module
 *
 * @param[in] sx_sdk_params - SDK init params
 *
 * @return SX_STATUS_SUCCESS if initialization completes successfully.
 * @return SX_STATUS_ALREADY_INITIALIZED if module was already initialized
 * @return SX_STATUS_PARAM_NULL if NULL parameter is given
 * @return SX_STATUS_ERROR if general error occurs
 */
sx_status_t pgt_init(sx_api_sx_sdk_init_t *sx_sdk_params);

/**
 * Deinitialize the PGT module
 *
 * @return SX_STATUS_SUCCESS if initialization completes successfully.
 * @return SX_STATUS_ERROR if general error occurs
 */
sx_status_t pgt_deinit(void);

sx_status_t pgt_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

#endif /* PGT_H_ */
