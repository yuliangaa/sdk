/*
 * SPDX-FileCopyrightText: Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#undef  __MODULE__
#define __MODULE__ PGT_LINEAR_MANAGER

#include "pgt_linear_manager.h"
#include <utils/utils.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <sx/sdk/sx_status_convertor.h>
#include <complib/cl_dbg.h>
#include <complib/cl_circular_buffer.h>
#include <sx/sxd/sxd_access_register.h>
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "ethl2/topo_db.h"
#include "ethl2/brg.h"
#include "dbg_dump_modules/dbg_dump_modules.h"

/************************************************
 *  Global variables
 ***********************************************/
static sx_circ_buff_t   g_pgt_circular_buff;
extern sx_brg_context_t brg_context;
/************************************************
 *  Local variables
 ***********************************************/

typedef enum dbg_column {
    DBG_BLOCK_HANDLE_E,
    DBG_USER_ID_E,
    DBG_BLOCK_SIZE_E,
    DBG_BLOCK_TYPE_E,
    DBG_START_INDEX_E,
} dbg_column_e;

typedef enum block_alloc_type {
    BLOCK_ALLOC_TYPE_MULTIPLE_SIZES = 1,
    BLOCK_ALLOC_TYPE_MAX            = BLOCK_ALLOC_TYPE_MULTIPLE_SIZES,
    BLOCK_ALLOC_TYPE_NUM            = BLOCK_ALLOC_TYPE_MAX,
} block_alloc_type_e;

static __attribute__((__used__)) const char* block_alloc_type[] = {
    "Unknown",
    "Single Line",
    "Multiple Lines"
};

#define BLOCK_ALLOC_TYPE_STR_SIZE (sizeof(block_alloc_type) / sizeof(char*))

#define BLOCK_ALLOC_TYPE_STR(type)                         \
    (SX_CHECK_MAX(type, (BLOCK_ALLOC_TYPE_STR_SIZE - 1)) ? \
     block_alloc_type[type] : "Unknown")                   \

typedef struct user_params {
    pgt_linear_manager_user_id_e        id;
    block_alloc_type_e                  alloc_type;
    pgt_linear_manager_block_relocate_t block_relocate;
    uint32_t                            handles_num;
    boolean_t                           is_initialized;
} user_params_t;

typedef struct handle_to_user_obj {
    cl_pool_item_t pool_item;
    cl_map_item_t  map_item;
    user_params_t *params;
} handle_to_user_obj_t;

typedef struct group_params {
    cl_pool_item_t pool_item;
    cl_map_item_t  map_item;
    ba_group_t     group;
} group_params_t;

typedef struct groups_pool_init_context {
    uint32_t index;
    uint32_t num;
} groups_pool_init_context_t;

typedef struct db_params {
    boolean_t           is_initialized;
    linear_manager_db_t linear_manager_db;
    user_params_t       user_params[PGT_LINEAR_MANAGER_USER_ID_NUM_E];
    cl_qpool_t          free_groups_pool;
    cl_qmap_t           groups_map;
    cl_qpool_t          handle_to_user_obj_pool;
    cl_qmap_t           handle_to_user;
    uint32_t            table_size;
    uint32_t            start_index;
    uint32_t            group_num;
} db_params_t;

static uint32_t pgt_multiple_block_alloc_size[PGT_LINEAR_MANAGER_MAX_ALLOC_SIZES] = {0};
static uint32_t pgt_block_alloc_size_list_cnt = 0;

#define GROUP_SIZE                rm_resource_global.pgt_max_block_size
#define RELOCATION_THRESH         80
#define RELOCATION_COUNT_SPECTRUM 30
#define ISPOW2(x)              ((x) > 0 && !((x) & (x - 1)))
#define ALIGN_NEXT_POW2_U32(x) (1UL << (1 + (31 - __builtin_clz(x - 1))))

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
db_params_t pgt_params;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __dump_module_pgt_linear_wrapper(dbg_dump_params_t *dbg_dump_params_p);

static sx_utils_status_t block_relocate(linear_manager_handle_t       handle,
                                        linear_manager_block_length_t size,
                                        linear_manager_block_length_t offset,
                                        linear_manager_context_t      context,
                                        linear_manager_index_t      * old_index_p,
                                        linear_manager_index_t        new_index);
static sx_utils_status_t alloc_group(ba_handle_t        handle,
                                     uint32_t           type,
                                     const ba_group_t **group_p);
static sx_utils_status_t free_group(ba_handle_t handle, ba_group_t *group);
static inline sx_status_t verify_user_id(pgt_linear_manager_user_id_e user);
static inline int cmpfunc(const void * a, const void * b);
static sx_status_t multiple_block_alloc_size_init_defaults(uint32_t size);
static sx_status_t verify_user_block_size(pgt_linear_manager_user_id_e user,
                                          uint32_t                     size);
static cl_status_t free_groups_pool_init(void            *const p_object,
                                         void                  *context,
                                         cl_pool_item_t **const pp_pool_item);
static sx_status_t get_user_id(pgt_linear_manager_handle_t   handle,
                               pgt_linear_manager_user_id_e *user_id);
static sx_status_t pgt_linear_manager_logging_relocate(pgt_linear_manager_user_id_e  user_id,
                                                       linear_manager_handle_t       handle,
                                                       linear_manager_block_length_t size,
                                                       uint32_t                      old_index,
                                                       uint32_t                      new_index);
static sx_status_t handle_ipfr(pgt_linear_manager_index_t        index,
                               pgt_linear_manager_block_length_t size);
static void __pgt_linear_manager_shift_indices(pgt_linear_manager_index_t       *indices_p,
                                               pgt_linear_manager_block_length_t size);
/************************************************
 *  Function implementations
 ***********************************************/
inline boolean_t pgt_linear_manager_is_initialized(void)
{
    return (pgt_params.is_initialized);
}

sx_status_t pgt_linear_manager_init(uint32_t start_index, uint32_t req_size, uint32_t *aligned_size)
{
    linear_manager_params_t    linear_manager_params;
    groups_pool_init_context_t groups_pool_init_context;
    uint32_t                   size_idx;
    boolean_t                  free_group_rollback = FALSE;
    boolean_t                  user_rollback = FALSE;
    sx_utils_status_t          utils_rc = SX_UTILS_STATUS_SUCCESS;
    cl_status_t                cl_rc = CL_SUCCESS;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    linear_manager_phys_init_t phys_init;

    SX_LOG_ENTER();

    SX_MEM_CLR(phys_init);

    if (TRUE == pgt_params.is_initialized) {
        SX_LOG_ERR("Failed to initialize PGT linear manager, "
                   "module already initialized\n");
        rc = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    if (start_index >= rm_resource_global.pgt_size) {
        SX_LOG_ERR("Failed to initialize PGT linear manager, "
                   "start index %u exceeds range %u.\n", start_index, rm_resource_global.pgt_size);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((req_size > rm_resource_global.pgt_size) || (req_size < GROUP_SIZE)) {
        SX_LOG_ERR("Failed to initialize PGT linear manager, "
                   "requested size %u exceeds range %u.\n", req_size, rm_resource_global.pgt_size);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((start_index + req_size) > rm_resource_global.pgt_size) {
        SX_LOG_ERR("Failed to initialize PGT linear manager, "
                   "start_index + size %u exceeds range %u.\n", (start_index + req_size), rm_resource_global.pgt_size);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    DBG_DUMP_MODULES_REGISTER(rc, PGT_LINEAR, PGT_LINEAR, pgt_linear, FALSE, FALSE, FALSE);

    SX_MEM_CLR(pgt_params);

    pgt_params.start_index = start_index;
    pgt_params.group_num = req_size / GROUP_SIZE;
    pgt_params.table_size = pgt_params.group_num * GROUP_SIZE;
    if (NULL != aligned_size) {
        *aligned_size = pgt_params.table_size;
    }

    groups_pool_init_context.index = 0;
    groups_pool_init_context.num = pgt_params.group_num;
    cl_rc = CL_QPOOL_INIT(&pgt_params.free_groups_pool,
                          pgt_params.group_num,
                          pgt_params.group_num,
                          0,
                          sizeof(group_params_t),
                          free_groups_pool_init,
                          NULL,
                          &groups_pool_init_context);
    if (CL_SUCCESS != cl_rc) {
        SX_LOG_ERR("Failed to initialize free_groups pool. "
                   "CL_QPOOL_INIT failed."
                   "err: %s.\n", CL_STATUS_MSG(cl_rc));
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    free_group_rollback = TRUE;
    cl_rc = CL_QPOOL_INIT(&pgt_params.handle_to_user_obj_pool,
                          pgt_params.table_size,
                          pgt_params.table_size,
                          0,
                          sizeof(handle_to_user_obj_t),
                          NULL,
                          NULL,
                          NULL);
    if (CL_SUCCESS != cl_rc) {
        SX_LOG_ERR("Failed to initialize user_map_items pool. "
                   "CL_QPOOL_INIT failed."
                   "err: %s.\n", CL_STATUS_MSG(cl_rc));
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    cl_qmap_init(&pgt_params.handle_to_user);
    cl_qmap_init(&pgt_params.groups_map);

    user_rollback = TRUE;
    SX_MEM_CLR(linear_manager_params);
    linear_manager_params.array_size = pgt_params.table_size;
    linear_manager_params.allocation_types_num = BLOCK_ALLOC_TYPE_NUM;

    rc = multiple_block_alloc_size_init_defaults(GROUP_SIZE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to register pgt default multiple block allocation sizes"
                   "error: %s\n", sx_status_str(rc));
        goto out;
    }
    for (size_idx = 0; size_idx < pgt_block_alloc_size_list_cnt; size_idx++) {
        linear_manager_params.allocation_types_params[BLOCK_ALLOC_TYPE_MULTIPLE_SIZES - 1].alloc_sizes[size_idx] =
            pgt_multiple_block_alloc_size[size_idx];
    }

    phys_init.phys_mem_size = pgt_params.table_size;
    strncpy(phys_init.phys_mem_name, "PGT_LINEAR", sizeof(phys_init.phys_mem_name));

    linear_manager_params.alignment = GROUP_SIZE;
    linear_manager_params.relocate_cb = block_relocate;
    linear_manager_params.alloc_group_cb = alloc_group;
    linear_manager_params.free_group_cb = free_group;
    linear_manager_params.relocation_threshold = RELOCATION_THRESH;
    linear_manager_params.relocation_count = RELOCATION_COUNT_SPECTRUM;
    linear_manager_params.gc_object_type = GC_OBJECT_TYPE_PGT;
    linear_manager_params.gc_subtype = GC_OBJECT_SUBTYPE_NONE;
    linear_manager_params.gc_attr.fence_type = GC_FENCE_TYPE_FAST;
    linear_manager_params.gc_attr.free_objects_threshold = 1000;
    linear_manager_params.gc_attr.per_object_threshold = 2000;
    linear_manager_params.gc_attr.hw_operation_needed = FALSE;
    linear_manager_params.gc_attr.immediate_fence_needed = FALSE;
    linear_manager_params.gc_attr.max_object_count = rm_resource_global.pgt_size;
    linear_manager_params.gc_post_completion_cb = NULL;
    linear_manager_params.p_phys_init = &phys_init;

    utils_rc = linear_manager_init(&pgt_params.linear_manager_db, &linear_manager_params);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to initialize linear manager , "
                   "error: %s\n", SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

    if (cl_circ_buff_allocate(sizeof(pgt_linear_manager_relocate_data_t),
                              1000,
                              &g_pgt_circular_buff)) {
        rc = SX_STATUS_NO_RESOURCES;
        SX_CHECK_RC_OUT_ERR(rc, "cl_circ_buff_allocate");
    }

    pgt_params.is_initialized = TRUE;

out:
    if (SX_CHECK_FAIL(rc)) {
        if (TRUE == free_group_rollback) {
            CL_QPOOL_DESTROY(&pgt_params.free_groups_pool);
        }
        if (TRUE == user_rollback) {
            CL_QPOOL_DESTROY(&pgt_params.handle_to_user_obj_pool);
        }
    }
    SX_LOG_EXIT();
    return rc;
}


sx_status_t pgt_linear_manager_deinit()
{
    uint32_t          user_idx;
    uint32_t          pool_cnt;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;
    sx_status_t       rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("Can't deinitialize PGT linear manager, PGT linear manager is not initialized\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    pool_cnt = cl_qpool_count(&pgt_params.handle_to_user_obj_pool);
    if (pool_cnt < pgt_params.table_size) {
        SX_LOG_ERR("Can't deinitialize PGT linear manager, there are still %u blocks allocated\n",
                   pool_cnt);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    for (user_idx = PGT_LINEAR_MANAGER_USER_ID_MIN_E; user_idx < PGT_LINEAR_MANAGER_USER_ID_MAX_E; user_idx++) {
        if (TRUE == pgt_params.user_params[user_idx].is_initialized) {
            SX_LOG_ERR("Can't deinitialize PGT linear manager, user %s is still initialized\n",
                       PGT_LINEAR_MANAGER_USER_ID_STR(user_idx));
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
    }

    utils_rc = linear_manager_deinit(pgt_params.linear_manager_db);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to deinit linear manager , "
                   "error: %s\n", SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

    CL_QPOOL_DESTROY(&pgt_params.handle_to_user_obj_pool);
    CL_QPOOL_DESTROY(&pgt_params.free_groups_pool);

    if (g_pgt_circular_buff) {
        if (cl_circ_buff_free(g_pgt_circular_buff, TRUE)) {
            rc = SX_STATUS_ERROR;
            SX_CHECK_RC_OUT_ERR(rc, "cl_circ_buff_free");
        }
    }

    SX_MEM_CLR(pgt_multiple_block_alloc_size);
    pgt_block_alloc_size_list_cnt = 0;
    pgt_params.is_initialized = FALSE;
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t pgt_linear_manager_user_init(pgt_linear_manager_user_id_e        user,
                                         pgt_linear_manager_block_relocate_t relocate_cb)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("PGT linear manager is not initialized\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = verify_user_id(user);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Can't initialize user %u of PGT linear manager, user doesn't exist\n", user);
        goto out;
    }

    if (TRUE == pgt_params.user_params[user].is_initialized) {
        SX_LOG_ERR("Can't initialize user %s of PGT linear manager, user is already initialized\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user));
        rc = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    if (utils_check_pointer(relocate_cb, "relocate_cb")) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    SX_MEM_CLR(pgt_params.user_params[user]);
    pgt_params.user_params[user].id = user;
    pgt_params.user_params[user].block_relocate = relocate_cb;
    pgt_params.user_params[user].alloc_type = BLOCK_ALLOC_TYPE_MULTIPLE_SIZES;
    pgt_params.user_params[user].is_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t pgt_linear_manager_user_deinit(pgt_linear_manager_user_id_e user)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!PGT_LINEAR_MANAGER_USER_ID_RANGE(user)) {
        SX_LOG_ERR("Can't deinitialize user id %u is out of range\n", user);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("Can't deinitialize user %s of PGT linear manager, "
                   "PGT linear manager is not initialized\n", PGT_LINEAR_MANAGER_USER_ID_STR(user));
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }
    if (TRUE != pgt_params.user_params[user].is_initialized) {
        goto out;
    }
    if (0 < pgt_params.user_params[user].handles_num) {
        SX_LOG_ERR("Can't deinitialize user %s of PGT linear manager, "
                   "this user still has %u blocks allocated\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user), pgt_params.user_params[user].handles_num);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }
    pgt_params.user_params[user].is_initialized = FALSE;
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t pgt_linear_manager_block_add(pgt_linear_manager_user_id_e      user,
                                         pgt_linear_manager_block_length_t size,
                                         boolean_t                         reuse_handle,
                                         pgt_linear_manager_handle_t      *handle_p)
{
    handle_to_user_obj_t *user_map_entry_p = NULL;
    cl_pool_item_t       *pool_item_p = NULL;
    sx_utils_status_t     utils_rc = SX_UTILS_STATUS_SUCCESS;
    sx_status_t           rc = SX_STATUS_SUCCESS;
    boolean_t             block_added = FALSE;

    SX_LOG_ENTER();

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("PGT linear manager is not initialized\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = verify_user_id(user);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Can't add PGT linear manager block, user %u doesn't exist\n", user);
        goto out;
    }

    if (TRUE != pgt_params.user_params[user].is_initialized) {
        SX_LOG_ERR("Can't add block for user %s of PGT linear manager, user is not initialized\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user));
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (NULL == handle_p) {
        SX_LOG_ERR("Can't add block for user %s of PGT linear manager, handle is NULL\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    rc = verify_user_block_size(user, size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Can't add block for user %s of PGT linear manager, block size %u is invalid\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user), size);
        goto out;
    }

    utils_rc = linear_manager_block_add(pgt_params.linear_manager_db,
                                        BLOCK_ALLOC_TYPE_MULTIPLE_SIZES,
                                        LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E,
                                        size,
                                        0,
                                        reuse_handle, handle_p);
    if (SX_UTILS_STATUS_NO_RESOURCES == utils_rc) {
        SX_LOG_ERR("Can't add block for user %s of PGT linear manager, "
                   "linear_manager_block_add failed, err: %s\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user), SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    } else if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Can't add block for user %s of PGT linear manager, "
                   "linear_manager_block_add failed, err: %s\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user), SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }
    block_added = TRUE;

    /*initiate (flush) block in hw for the below users*/
    if (((user == PGT_LINEAR_MANAGER_USER_ID_LAG_TABLE_E) &&
         (rm_resource_global.lag_table_mngr == RM_SDK_LAG_TABLE_SDK_MNGR)) ||
        (((user == PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_FID_E) ||
          (user == PGT_LINEAR_MANAGER_USER_ID_FDB_E) ||
          (user == PGT_LINEAR_MANAGER_USER_ID_SMID_MANAGER_E) ||
          (user == PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_RFID_E)) &&
         (rm_resource_global.flood_control_mode == 5) /* FLOOD_MODE_CFF */)) {
        if (brg_context.spec_cb_g.pgt_linear_manager_block_hw_flush_cb) {
            rc = brg_context.spec_cb_g.pgt_linear_manager_block_hw_flush_cb(*handle_p, size);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Can't initiate/flush block for user %s of PGT linear manager, "
                           "linear_manager_block_add failed, err: %s\n",
                           PGT_LINEAR_MANAGER_USER_ID_STR(user), sx_status_str(rc));
                goto out;
            }
        }
    }

    pool_item_p = cl_qpool_get(&pgt_params.handle_to_user_obj_pool);

    if (NULL == pool_item_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("No resources to allocate new user map pool entry.\n");
        goto out;
    }
    user_map_entry_p = PARENT_STRUCT(pool_item_p, handle_to_user_obj_t, pool_item);
    user_map_entry_p->params = &pgt_params.user_params[user];
    cl_qmap_insert(&pgt_params.handle_to_user, *handle_p, &user_map_entry_p->map_item);
    ++pgt_params.user_params[user].handles_num;

out:
    if ((block_added) && (SX_CHECK_FAIL(rc))) {
        utils_rc = linear_manager_block_delete(pgt_params.linear_manager_db, *handle_p, reuse_handle);
        if (SX_UTILS_CHECK_FAIL(utils_rc)) {
            SX_LOG_NTC("Can't delete block for user %s of PGT linear manager, "
                       "linear_manager_block_add rollback failure, err: %s\n",
                       PGT_LINEAR_MANAGER_USER_ID_STR(user), SX_UTILS_STATUS_MSG(utils_rc));
        }
    }
    SX_LOG_EXIT();
    return rc;
}


sx_status_t pgt_linear_manager_block_delete(pgt_linear_manager_handle_t handle, boolean_t reuse_handle)
{
    handle_to_user_obj_t *user_map_entry_p = NULL;
    cl_map_item_t        *map_item_p = NULL;
    sx_utils_status_t     utils_rc = SX_UTILS_STATUS_SUCCESS;
    sx_status_t           rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("PGT linear manager is not initialized\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    map_item_p = cl_qmap_get(&pgt_params.handle_to_user, handle);
    if (cl_qmap_end(&pgt_params.handle_to_user) == map_item_p) {
        SX_LOG_ERR("Can't delete block with handle %u, handle doesn't exist\n", handle);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    user_map_entry_p = PARENT_STRUCT(map_item_p, handle_to_user_obj_t, map_item);

    utils_rc = linear_manager_block_delete(pgt_params.linear_manager_db, handle, reuse_handle);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Can't delete block with handle %u from PGT linear manager, "
                   "pgt_linear_manager_block_delete failed, err: %s\n",
                   handle, SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }
    cl_qmap_remove_item(&pgt_params.handle_to_user, map_item_p);
    cl_qpool_put(&pgt_params.handle_to_user_obj_pool, &user_map_entry_p->pool_item);
    --pgt_params.user_params[user_map_entry_p->params->id].handles_num;

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t pgt_linear_manager_handle_lock(pgt_linear_manager_handle_t        handle,
                                           pgt_linear_manager_index_t        *index_p,
                                           pgt_linear_manager_block_length_t *size_p)
{
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;
    sx_status_t       rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("PGT linear manager is not initialized\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (cl_qmap_end(&pgt_params.handle_to_user) ==
        cl_qmap_get(&pgt_params.handle_to_user, handle)) {
        SX_LOG_ERR("Can't lock block with handle %u, handle doesn't exist\n", handle);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(index_p, "index_p")) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (utils_check_pointer(size_p, "size_p")) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    utils_rc = linear_manager_handle_lock(pgt_params.linear_manager_db,
                                          handle,
                                          index_p,
                                          size_p);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_NTC("Can't lock block with handle %u, "
                   "linear_manager_handle_lock failed, err: %s\n",
                   handle, SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

    __pgt_linear_manager_shift_indices(index_p, *size_p);

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t pgt_linear_manager_handle_release(pgt_linear_manager_handle_t handle)
{
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;
    sx_status_t       rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("PGT linear manager is not initialized\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (cl_qmap_end(&pgt_params.handle_to_user) ==
        cl_qmap_get(&pgt_params.handle_to_user, handle)) {
        SX_LOG_ERR("Can't lock block with handle %u, handle doesn't exist\n", handle);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    utils_rc = linear_manager_handle_release(pgt_params.linear_manager_db,
                                             handle);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_NTC("Can't release block with handle %u, "
                   "linear_manager_handle_release failed, err: %s\n",
                   handle, SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t pgt_linear_manager_user_handle_get(pgt_linear_manager_user_id_e user,
                                               pgt_linear_manager_handle_t *handle_list,
                                               uint32_t                    *handle_cnt_p)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    cl_map_item_t        *map_item_p = NULL;
    const cl_map_item_t  *map_end_p = NULL;
    handle_to_user_obj_t *user_map_entry_p = NULL;
    uint32_t              cnt_idx = 0;

    SX_LOG_ENTER();

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("PGT linear manager is not initialized\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = verify_user_id(user);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get PGT linear manager handles, user %d doesn't exist\n", user);
        goto out;
    }

    if (TRUE != pgt_params.user_params[user].is_initialized) {
        SX_LOG_ERR("Failed to get handle info for user %s of PGT linear manager, user is not initialized\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user));
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* return number of user handles and out*/
    if (NULL == handle_list) {
        *handle_cnt_p = pgt_params.user_params[user].handles_num;
        goto out;
    }

    /* Find out if this user is  mapped */
    map_item_p = cl_qmap_head(&pgt_params.handle_to_user);
    map_end_p = cl_qmap_end(&pgt_params.handle_to_user);

    while (map_item_p != map_end_p) {
        user_map_entry_p = PARENT_STRUCT(map_item_p, handle_to_user_obj_t, map_item);
        if (user_map_entry_p->params->id == user) {
            /*list handle address if user exist*/
            handle_list[cnt_idx++] = (pgt_linear_manager_handle_t)(map_item_p->key);
        }
        map_item_p = cl_qmap_next(map_item_p);
    }
    /*return handle count for validation*/
    *handle_cnt_p = cnt_idx;
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t pgt_linear_manager_ref_add(pgt_linear_manager_handle_t handle)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("PGT linear manager is not initialized\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (cl_qmap_end(&pgt_params.handle_to_user) ==
        cl_qmap_get(&pgt_params.handle_to_user, handle)) {
        SX_LOG_ERR("Can't add ref to block with handle %u, handle doesn't exist\n", handle);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    utils_rc = linear_manager_ref_add(pgt_params.linear_manager_db,
                                      handle);

    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to add reference to block in linear manager , "
                   "error: %s\n", SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t pgt_linear_manager_ref_delete(pgt_linear_manager_handle_t handle)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_rc = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("PGT linear manager is not initialized\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (cl_qmap_end(&pgt_params.handle_to_user) ==
        cl_qmap_get(&pgt_params.handle_to_user, handle)) {
        SX_LOG_ERR("Can't delete reference to block with handle %u, handle doesn't exist\n", handle);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    utils_rc = linear_manager_ref_delete(pgt_params.linear_manager_db,
                                         handle);

    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Failed to delete reference to block in linear manager , "
                   "error: %s handle - %u\n", SX_UTILS_STATUS_MSG(utils_rc), handle);
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t multiple_block_alloc_size_init_defaults(uint32_t size)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    type_idx = 0;
    uint32_t    size_pow2 = 0;
    uint32_t    def_sizes_list[31];
    uint32_t    def_sizes_cnt = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(def_sizes_list);

    if (!size) {
        SX_LOG_ERR("PGT linear manager failed to init default block alloc sizes\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /*if not power of 2 align to the next power of 2*/
    size_pow2 = (!ISPOW2(size)) ? ALIGN_NEXT_POW2_U32(size) : size;

    while (size_pow2 >> type_idx) {
        def_sizes_list[type_idx] = (size_pow2 >> type_idx);
        type_idx++;
    }
    /* update array count */
    def_sizes_cnt += type_idx;

    /* first size is capped by group size in case not pow2*/
    def_sizes_list[0] = size;

    rc = pgt_multiple_block_alloc_size_set(PGT_LINEAR_MANAGER_USER_ID_DEFAULT_E,
                                           def_sizes_list,
                                           def_sizes_cnt);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init multiple block allocation sizes for user %s, "
                   "error: %s\n", PGT_LINEAR_MANAGER_USER_ID_STR(PGT_LINEAR_MANAGER_USER_ID_DEFAULT_E),
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t pgt_linear_manager_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return rc;
}

static sx_status_t __dump_module_pgt_linear_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = pgt_linear_manager_dump(dbg_dump_params_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("dbg_dump failed to generate PGT linear manager dump\n");
    }

    return err;
}

sx_status_t pgt_linear_manager_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    handle_to_user_obj_t              *user_map_entry_p = NULL;
    cl_map_item_t                     *map_item_p = NULL;
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    pgt_linear_manager_handle_t        handle;
    pgt_linear_manager_user_id_e       user;
    pgt_linear_manager_index_t         index[GROUP_SIZE];
    pgt_linear_manager_block_length_t  size = GROUP_SIZE;
    pgt_linear_manager_relocate_data_t relocate_data;
    char                               username[16] = {'\0'};
    char                               relocate_username[16] = {'\0'};
    dbg_utils_table_columns_t          blocks_db_dump_clmns[] = {
        { "Block handle",  12,    PARAM_UINT32_E,     NULL},
        { "Username",       16,    PARAM_STRING_E,     username},
        { "Block size",    12,    PARAM_UINT32_E,     NULL},
        { "Block type",    16,    PARAM_STRING_E,     NULL},
        { "Start index",   12,    PARAM_UINT32_E,     NULL},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t          relocate_db_dump_clmns[] = {
        { "Timestamp",  20,    PARAM_STRING_E,     relocate_data.timestamp},
        { "Username",       16,    PARAM_STRING_E,     relocate_username},
        { "Block handle",  12,    PARAM_UINT32_E,     &relocate_data.handle},
        { "Block size",    12,    PARAM_UINT32_E,     &relocate_data.size},
        { "Old index",    12,    PARAM_UINT32_E,     &relocate_data.old_index},
        { "New index",   12,    PARAM_UINT32_E,     &relocate_data.new_index},
        {NULL, 0, 0, NULL}
    };
    FILE                              *stream = NULL;

    rc = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    stream = dbg_dump_params_p->stream;
    dbg_utils_pprinter_module_header_print(stream, "PGT Linear Manager");
    dbg_utils_pprinter_field_print(stream, "PGT Linear Manager is initialized", &pgt_params.is_initialized,
                                   PARAM_BOOL_E);

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_DBG("PGT linear manager is not initialized\n");
        goto out;
    }
    dbg_utils_pprinter_field_print(stream, "PGT Linear Manager Table Size", &pgt_params.table_size, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "PGT Linear Manager Start Index", &pgt_params.start_index, PARAM_UINT32_E);

    dbg_utils_pprinter_general_header_print(stream, "PGT linear manager blocks DB Dump");
    dbg_utils_pprinter_table_headline_print(stream, blocks_db_dump_clmns);

    map_item_p = cl_qmap_head(&pgt_params.handle_to_user);
    while (cl_qmap_end(&pgt_params.handle_to_user) != map_item_p) {
        user_map_entry_p = PARENT_STRUCT(map_item_p, handle_to_user_obj_t, map_item);
        handle = cl_qmap_key(map_item_p);
        user = user_map_entry_p->params->id;
        if (PGT_LINEAR_MANAGER_USER_ID_RANGE(user)) {
            blocks_db_dump_clmns[DBG_BLOCK_HANDLE_E].data = &handle;
            strncpy(username, PGT_LINEAR_MANAGER_USER_ID_STR(user), (sizeof(username) - 1));
            blocks_db_dump_clmns[DBG_BLOCK_TYPE_E].data =
                BLOCK_ALLOC_TYPE_STR(pgt_params.user_params[user].alloc_type);
        } else {
            SX_LOG_ERR("PGT user id %u is out of range\n", user);
            map_item_p = cl_qmap_next(map_item_p);
            continue;
        }

        size = GROUP_SIZE;
        rc = pgt_linear_manager_handle_lock(handle, index, &size);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Can't print PGT debug dump, failed to lock "
                       "handle %u.\n", handle);
            goto out;
        }

        blocks_db_dump_clmns[DBG_BLOCK_SIZE_E].data = &size;
        blocks_db_dump_clmns[DBG_START_INDEX_E].data = index;

        dbg_utils_pprinter_table_data_line_print(stream, blocks_db_dump_clmns);

        rc = pgt_linear_manager_handle_release(handle);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Can't print PGT debug dump, failed to release "
                       "handle %u.\n", handle);
            goto out;
        }
        map_item_p = cl_qmap_next(map_item_p);
    }

    dbg_utils_pprinter_module_header_print(stream, "PGT Linear Manager Relocate History");
    dbg_utils_pprinter_table_headline_print(stream, relocate_db_dump_clmns);
    while (!cl_circ_buff_empty(g_pgt_circular_buff)) {
        if (cl_circ_buff_read(g_pgt_circular_buff,
                              (pgt_linear_manager_relocate_data_t*)&relocate_data)) {
            rc = SX_STATUS_ERROR;
            SX_CHECK_RC_OUT_ERR(rc, "cl_circ_buff_read");
        }
        strncpy(relocate_username,
                PGT_LINEAR_MANAGER_USER_ID_STR(relocate_data.user_id),
                (sizeof(relocate_username) - 1));
        dbg_utils_pprinter_table_data_line_print(stream, relocate_db_dump_clmns);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static inline int cmpfunc(const void * a, const void * b)
{
    return (*(uint32_t*)a - *(uint32_t*)b);
}

static inline sx_status_t verify_user_id(pgt_linear_manager_user_id_e user)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    switch (user) {
    case PGT_LINEAR_MANAGER_USER_ID_DEFAULT_E:
    case PGT_LINEAR_MANAGER_USER_ID_RMID_MANAGER_E:
    case PGT_LINEAR_MANAGER_USER_ID_FINE_GRAIN_LAG_E:
    case PGT_LINEAR_MANAGER_USER_ID_FDB_E:
    case PGT_LINEAR_MANAGER_USER_ID_SMID_MANAGER_E:
    case PGT_LINEAR_MANAGER_USER_ID_ADAPTIVE_ROUTER_E:
    case PGT_LINEAR_MANAGER_USER_ID_LAG_TABLE_E:
    case PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_FID_E:
    case PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_RFID_E:
        break;

    default:
        SX_LOG_ERR("can't find user ID %u\n", user);
        rc = SX_STATUS_PARAM_ERROR;
    }

    return rc;
}
static sx_status_t verify_user_block_size(pgt_linear_manager_user_id_e user, uint32_t size)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    size_idx;

    switch (user) {
    case PGT_LINEAR_MANAGER_USER_ID_RMID_MANAGER_E:
    case PGT_LINEAR_MANAGER_USER_ID_FDB_E:
    case PGT_LINEAR_MANAGER_USER_ID_SMID_MANAGER_E:
        if (1 != size) {
            SX_LOG_ERR("block size %u doesn't match user %s block type.\n",
                       size, PGT_LINEAR_MANAGER_USER_ID_STR(user));
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case PGT_LINEAR_MANAGER_USER_ID_DEFAULT_E:
    case PGT_LINEAR_MANAGER_USER_ID_FINE_GRAIN_LAG_E:
    case PGT_LINEAR_MANAGER_USER_ID_ADAPTIVE_ROUTER_E:
    case PGT_LINEAR_MANAGER_USER_ID_LAG_TABLE_E:
    case PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_FID_E:
    case PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_RFID_E:
        for (size_idx = 0; size_idx < pgt_block_alloc_size_list_cnt; size_idx++) {
            if (pgt_multiple_block_alloc_size[size_idx] == size) {
                goto out;
            }
        }
        rc = SX_STATUS_PARAM_ERROR;
        break;

    default:
        SX_LOG_ERR("can't verify block size. Invalid user ID %s\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user));
        rc = SX_STATUS_PARAM_ERROR;
    }

out:
    return rc;
}

static sx_utils_status_t block_relocate(linear_manager_handle_t       handle,
                                        linear_manager_block_length_t size,
                                        linear_manager_block_length_t offset,
                                        linear_manager_context_t      context,
                                        linear_manager_index_t      * old_index_p,
                                        linear_manager_index_t        new_index)
{
    cl_map_item_t         *map_item_p = NULL;
    handle_to_user_obj_t  *user_map_entry_p = NULL;
    sx_status_t            rc = SX_STATUS_SUCCESS;
    linear_manager_index_t old_index = *old_index_p;

    SX_LOG_ENTER();

    UNUSED_PARAM(offset);
    UNUSED_PARAM(context);

    map_item_p = cl_qmap_get(&pgt_params.handle_to_user, handle);
    if (cl_qmap_end(&pgt_params.handle_to_user) == map_item_p) {
        SX_LOG_ERR("Can't relocate block with handle %u, handle doesn't exist\n", handle);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    __pgt_linear_manager_shift_indices(&old_index, 1);
    __pgt_linear_manager_shift_indices(&new_index, 1);

    user_map_entry_p = PARENT_STRUCT(map_item_p, handle_to_user_obj_t, map_item);
    rc = pgt_linear_manager_logging_relocate(user_map_entry_p->params->id,
                                             handle,
                                             size,
                                             old_index,
                                             new_index);
    SX_CHECK_RC_OUT_ERR(rc, "pgt_linear_manager_logging_relocate");

    /*initiate (flush) block in hw for the below users */
    if (((user_map_entry_p->params->id == PGT_LINEAR_MANAGER_USER_ID_LAG_TABLE_E) &&
         (rm_resource_global.lag_table_mngr == RM_SDK_LAG_TABLE_SDK_MNGR)) ||
        (((user_map_entry_p->params->id == PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_FID_E) ||
          (user_map_entry_p->params->id == PGT_LINEAR_MANAGER_USER_ID_COMPRESSED_RFID_E)) &&
         (rm_resource_global.flood_control_mode == 5) /* FLOOD_MODE_CFF */)) {
        if (brg_context.spec_cb_g.pgt_linear_manager_block_hw_flush_cb) {
            rc = handle_ipfr(new_index, size);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Set IPFR register failure [%s] \n", SX_STATUS_MSG(rc));
                goto out;
            }
        }
    }

    rc = user_map_entry_p->params->block_relocate(handle,
                                                  size,
                                                  old_index,
                                                  new_index);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Can't relocate block with handle %u, relocate CB of user %s failed,"
                   " err: %s\n",
                   handle,
                   PGT_LINEAR_MANAGER_USER_ID_STR(user_map_entry_p->params->id),
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status_to_sx_utils_status(rc);
}

static sx_utils_status_t alloc_group(linear_manager_db_t database, uint32_t type, const ba_group_t **group_p)
{
    cl_pool_item_t *pool_item_p = NULL;
    group_params_t *group_params_entry_p = NULL;
    sx_status_t     rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(database);

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("Can't allocate new group, PGT linear manager is not initialized\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (utils_check_pointer(group_p, "group_p")) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    pool_item_p = cl_qpool_get(&pgt_params.free_groups_pool);
    if (NULL == pool_item_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Can't allocate new group, no resources to allocate new group.\n");
        goto out;
    }

    group_params_entry_p = PARENT_STRUCT(pool_item_p, group_params_t, pool_item);
    group_params_entry_p->group.type = type;
    *group_p = &(group_params_entry_p->group);

    cl_qmap_insert(&pgt_params.groups_map,
                   group_params_entry_p->group.grp_index,
                   &group_params_entry_p->map_item);

out:
    SX_LOG_EXIT();
    return sx_status_to_sx_utils_status(rc);
}

static sx_utils_status_t free_group(linear_manager_db_t database, ba_group_t *group)
{
    cl_map_item_t  *map_item_p = NULL;
    group_params_t *group_params_entry_p = NULL;
    sx_status_t     rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(database);

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_ERR("Can't free group with index %u, PGT linear manager is not initialized\n",
                   group->grp_index);
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (utils_check_pointer(group, "group")) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    map_item_p = cl_qmap_get(&pgt_params.groups_map, group->grp_index);
    if (cl_qmap_end(&pgt_params.groups_map) == map_item_p) {
        SX_LOG_ERR("Can't free group with index %u, entry not found\n",
                   group->grp_index);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    group_params_entry_p = PARENT_STRUCT(map_item_p, group_params_t, map_item);
    cl_qmap_remove_item(&pgt_params.groups_map, &group_params_entry_p->map_item);
    cl_qpool_put(&pgt_params.free_groups_pool, &group_params_entry_p->pool_item);

out:
    SX_LOG_EXIT();
    return sx_status_to_sx_utils_status(rc);
}
static cl_status_t free_groups_pool_init(void            *const p_object,
                                         void                  *context,
                                         cl_pool_item_t **const pp_pool_item)
{
    group_params_t             *group_params_entry_p = (group_params_t*)p_object;
    groups_pool_init_context_t* groups_pool_init_context = (groups_pool_init_context_t*)context;
    cl_status_t                 rc = CL_SUCCESS;

    if (groups_pool_init_context->index >= groups_pool_init_context->num) {
        SX_LOG_ERR("Failed to initialize free group pool entry, group index "
                   "exceeds PGT size %u\n", groups_pool_init_context->num);
        rc = CL_ERROR;
        goto out;
    }
    group_params_entry_p->group.grp_index = groups_pool_init_context->index++;
    *pp_pool_item = &group_params_entry_p->pool_item;
out:
    return rc;
}

static sx_status_t get_user_id(pgt_linear_manager_handle_t handle, pgt_linear_manager_user_id_e *user_id)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    cl_map_item_t        *map_item_p = NULL;
    handle_to_user_obj_t *user_map_entry_p = NULL;

    if ((utils_check_pointer(user_id, "user_id"))) {
        rc = SX_STATUS_ERROR;
        goto out;
    }

    map_item_p = cl_qmap_get(&pgt_params.handle_to_user, handle);
    if (cl_qmap_end(&pgt_params.handle_to_user) == map_item_p) {
        SX_LOG_ERR("Can't get block with handle %u, handle doesn't exist\n", handle);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    user_map_entry_p = PARENT_STRUCT(map_item_p, handle_to_user_obj_t, map_item);
    *user_id = user_map_entry_p->params->id;

out:
    return rc;
}

sx_status_t pgt_multiple_block_alloc_size_set(pgt_linear_manager_user_id_e user,
                                              uint32_t                    *size_list,
                                              uint32_t                     size_list_cnt)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    index = 0;
    uint32_t   *g_size_arr = &pgt_multiple_block_alloc_size[0];
    uint32_t   *g_arr_cnt = &pgt_block_alloc_size_list_cnt;
    uint8_t     j_run = 0;

    SX_LOG_ENTER();

    rc = verify_user_id(user);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get block allocation valid sizes of PGT linear manager block, user %u doesn't exist \n",
                   user);
        goto out;
    }

    if (NULL == size_list) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Failed to set multiple block size for user : [%s] size_list is NULL\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user));
        goto out;
    }

    if (0 == size_list_cnt) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to set  multiple block size for user : [%s] size_list_cnt = [%d],  err: %s\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user), size_list_cnt, sx_status_str(rc));
        goto out;
    }

    /* verify sizes align with group size limitation */
    for (; index < size_list_cnt; index++) {
        if (size_list[index] > GROUP_SIZE) {
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Failed to set  multiple block size for user : [%s] size_list[%d] = [%d] exceeds"
                       "group size [%d],  err: %s\n",
                       PGT_LINEAR_MANAGER_USER_ID_STR(user), index, size_list[index], GROUP_SIZE, sx_status_str(rc));
            goto out;
        }
    }

    /* verify available space on list */
    if ((PGT_LINEAR_MANAGER_MAX_ALLOC_SIZES - *g_arr_cnt) < size_list_cnt) {
        rc = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        SX_LOG_ERR("Failed to set  multiple block size for user : [%s] size_list_cnt [%d] exceeds"
                   " available resource limit:[%d],  err: %s\n",
                   PGT_LINEAR_MANAGER_USER_ID_STR(user),
                   size_list_cnt,
                   PGT_LINEAR_MANAGER_MAX_ALLOC_SIZES - *g_arr_cnt
                   ,
                   sx_status_str(rc));
        goto out;
    }

    SX_MEM_CPY_ARRAY(&g_size_arr[*g_arr_cnt], size_list, size_list_cnt, size_list[0]);
    *g_arr_cnt += size_list_cnt;

    /* default user is the pgt init process. for any other user just list its values
     * at the end of the array and out. once pgt will init its default values it will sort and remove
     * duplicates as restricted in the bin allocator.
     */
    if (user != PGT_LINEAR_MANAGER_USER_ID_DEFAULT_E) {
        goto out;
    }

    /* Sizes must be monotonically increasing  - re sort*/
    qsort(g_size_arr, *g_arr_cnt, sizeof(uint32_t), cmpfunc);

    /*remove duplications - bin allocator restriction*/
    index = 0;
    for (j_run = index + 1; j_run < *g_arr_cnt; j_run++) {
        if (g_size_arr[j_run] != g_size_arr[index]) {
            index++;
            g_size_arr[index] = g_size_arr[j_run];
        }
    }
    *g_arr_cnt = index + 1;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t pgt_linear_manager_swap_handles(pgt_linear_manager_handle_t first_handle,
                                            pgt_linear_manager_handle_t second_handle)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    sx_utils_status_t            utils_err = SX_UTILS_STATUS_SUCCESS;
    pgt_linear_manager_user_id_e first_user = 0, second_user = 0;

    SX_LOG_ENTER();

    if (TRUE != pgt_params.is_initialized) {
        SX_LOG_DBG("PGT linear manager is not initialized\n");
        goto out;
    }

    if (first_handle == second_handle) {
        SX_LOG_ERR("2 handles given are the same, can't swap between them\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = get_user_id(first_handle, &first_user);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get handle's user id [0x%" PRIx32 "], err = [%s] (%d)\n",
                   first_handle, sx_status_str(rc), rc);
        goto out;
    }

    rc = get_user_id(second_handle, &second_user);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get handle's user id [0x%" PRIx32 "], err = [%s] (%d)\n",
                   second_handle, sx_status_str(rc), rc);
        goto out;
    }

    if (first_user != second_user) {
        SX_LOG_ERR("Can't swap handles of two different users\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    utils_err = linear_manager_swap_handles(pgt_params.linear_manager_db,
                                            first_handle,
                                            second_handle);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG_ERR("Failed to swap handles in linear manager , "
                   "error: %s\n", SX_UTILS_STATUS_MSG(utils_err));
        rc = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t pgt_linear_manager_logging_relocate(pgt_linear_manager_user_id_e  user_id,
                                                       linear_manager_handle_t       handle,
                                                       linear_manager_block_length_t size,
                                                       uint32_t                      old_index,
                                                       uint32_t                      new_index)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    struct timeval                     tv;
    struct tm                         *nowtm = NULL;
    pgt_linear_manager_relocate_data_t relocate_data;

    SX_MEM_CLR(relocate_data);

    tv.tv_sec = (time_t)0;
    tv.tv_usec = 0L;

    gettimeofday(&tv, NULL);
    nowtm = localtime(&tv.tv_sec);
    strftime(relocate_data.timestamp,
             sizeof(relocate_data.timestamp),
             "%d-%m-%Y %H:%M:%S",
             nowtm);

    relocate_data.handle = handle;
    relocate_data.new_index = new_index;
    relocate_data.old_index = old_index;
    relocate_data.size = size;
    relocate_data.user_id = user_id;

    cl_circ_buff_overwrite(g_pgt_circular_buff,
                           (pgt_linear_manager_relocate_data_t *)&relocate_data);

    return rc;
}

static sx_status_t handle_ipfr(pgt_linear_manager_index_t index, pgt_linear_manager_block_length_t size)
{
    struct ku_ipfr_reg ipfr_reg_data;
    sxd_reg_meta_t     ipfr_reg_meta;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    length_t           dev_info_arr_size = SX_DEV_ID_MAX;
    sx_dev_info_t      dev_info_arr[SX_DEV_ID_MAX];
    length_t           dev_idx = 0;

    SX_LOG_ENTER();

    SX_LOG_DBG("Flush index: %u size: %u \n", index, size);

    SX_MEM_CLR(ipfr_reg_meta);
    SX_MEM_CLR(ipfr_reg_data);

    ipfr_reg_meta.swid = 0;
    ipfr_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    ipfr_reg_data.pgt_base_ptr = index;
    ipfr_reg_data.size = size;


    /* Get list of LEAF devices */
    sx_status = topo_device_tbl_bulk_get(SX_ACCESS_CMD_GET,
                                         &leaf_filter,
                                         dev_info_arr,
                                         &dev_info_arr_size);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("[__handle_ipfr] cannot retrieve "
                   "device list or there is no leaf devices [%s]\n",
                   sx_status_str(sx_status));
        goto out;
    }

    /* For each LEAF device */
    for (dev_idx = 0; dev_idx < dev_info_arr_size; dev_idx++) {
        ipfr_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_IPFR_E,
                                                         &ipfr_reg_data,
                                                         &ipfr_reg_meta, 1,
                                                         NULL, NULL);

        if (SXD_CHECK_FAIL(sxd_status)) {
            SX_LOG_ERR("Set IPFR register failure [%s]\n", SXD_STATUS_MSG(sxd_status));
            sx_status = SXD_STATUS_TO_SX_STATUS(sxd_status);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t pgt_linear_manager_block_hw_flush_spc2(pgt_linear_manager_handle_t       handle,
                                                   pgt_linear_manager_block_length_t size)
{
    sx_utils_status_t           utils_rc = SX_UTILS_STATUS_SUCCESS;
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    pgt_linear_manager_index_t *indices_p = NULL;
    boolean_t                   handle_locked = FALSE;

    SX_LOG_ENTER();


    indices_p = (pgt_linear_manager_index_t *)cl_calloc(size, sizeof(indices_p[0]));
    if (indices_p == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Can't flush pgt block - indices_p allocation failure err: %s\n", SX_STATUS_MSG(rc));
        goto out;
    }

    utils_rc = linear_manager_handle_lock(pgt_params.linear_manager_db,
                                          handle,
                                          indices_p,
                                          &size);
    if (SX_UTILS_CHECK_FAIL(utils_rc)) {
        SX_LOG_ERR("Can't lock block with handle %u, "
                   "linear_manager_handle_lock failed, err: %s\n",
                   handle, SX_UTILS_STATUS_MSG(utils_rc));
        rc = sx_utils_status_to_sx_status(utils_rc);
        goto out;
    }
    handle_locked = TRUE;
    __pgt_linear_manager_shift_indices(indices_p, size);

    SX_LOG_DBG("Flush block with handle %u size: %u mid: %u\n", handle, size, indices_p[0]);

    rc = handle_ipfr(indices_p[0], size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Set IPFR register failure [%s] \n", SX_STATUS_MSG(rc));
        goto out;
    }

out:
    if (handle_locked) {
        utils_rc = linear_manager_handle_release(pgt_params.linear_manager_db,
                                                 handle);
        if (SX_UTILS_CHECK_FAIL(utils_rc)) {
            SX_LOG_ERR("Can't release block with handle %u, "
                       "linear_manager_handle_release failed, err: %s\n",
                       handle, SX_UTILS_STATUS_MSG(utils_rc));
            if (rc == SX_STATUS_SUCCESS) {
                rc = sx_utils_status_to_sx_status(utils_rc);
            }
            goto out;
        }
    }
    if (indices_p != NULL) {
        CL_FREE_N_NULL(indices_p);
    }
    SX_LOG_EXIT();
    return rc;
}

static void __pgt_linear_manager_shift_indices(pgt_linear_manager_index_t       *indices_p,
                                               pgt_linear_manager_block_length_t size)
{
    pgt_linear_manager_block_length_t i = 0;

    for (i = 0; i < size; i++) {
        indices_p[i] += pgt_params.start_index;
    }
}
