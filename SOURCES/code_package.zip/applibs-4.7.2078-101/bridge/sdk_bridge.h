/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SDK_BRIDGE_H__
#define __SDK_BRIDGE_H__

#include <complib/sx_log.h>

#include <complib/cl_types.h>
#include <complib/cl_qmap.h>
#include <complib/cl_qpool.h>

#include <sx/sdk/sx_types.h>
#include "bridge_lib/bridge_common.h"
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  DB definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  API functions
 ***********************************************/
sx_status_t sdk_bridge_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t sdk_bridge_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

/* Initialize bridge module and DB */
sx_status_t sdk_bridge_init(sx_bridge_params_t *bridge_init_param);

/* Free all initialized resources used by the bridge module */
sx_status_t sdk_bridge_deinit();

/* This function creates a new bridge or deletes an existing one.
 * The bridge must be clear before deletion. */
sx_status_t sdk_bridge_set(sx_access_cmd_t cmd, sx_bridge_id_t *bridge_id);

/* This function retrieves a list of one or more Bridge IDs. */
sx_status_t sdk_bridge_iter_get(const sx_access_cmd_t     cmd,
                                const sx_bridge_id_t      bridge_id,
                                const sx_bridge_filter_t *filter_p,
                                sx_bridge_id_t           *bridge_id_list_p,
                                uint32_t                 *bridge_id_cnt_p);

/* This function adds/removes a virtual port from a bridge.
 * Only one virtual port from each physical port is allowed per bridge.
 * A virtual port cannot be added to one bridge only. */
sx_status_t sdk_bridge_vport_set(sx_access_cmd_t cmd, sx_bridge_id_t bridge_id, sx_port_log_id_t log_port,
                                 boolean_t part_of_multi_vlans_set);
sx_status_t sdk_bridge_vport_pending_push_set(void);

/* This function returns the list of virtual port of a specific bridge.
 * In case bridge_vport_cnt==0 it returns the number of virtual ports on the bridge.*/
sx_status_t sdk_bridge_vport_get(sx_bridge_id_t    bridge_id,
                                 sx_port_log_id_t *bridge_vport_list,
                                 uint32_t         *bridge_vport_cnt);

/* This function is used to bind/un-bind a flow counter to a bridge. */
sx_status_t sdk_bridge_counter_bind_set(sx_access_cmd_t      cmd,
                                        sx_bridge_id_t       bridge_id,
                                        sx_flow_counter_id_t flow_counter_id);

/* This function returns the flow counter id that is bound to the bridge (if any) */
sx_status_t sdk_bridge_counter_bind_get(sx_bridge_id_t bridge_id, sx_flow_counter_id_t *flow_counter_id_p);

/* This function is used to bind/unbind a flow counter to a fid/tunnel. */
sx_status_t sdk_bridge_tunnel_counter_bind_set(const sx_access_cmd_t                  cmd,
                                               const sx_fid_t                         fid,
                                               const sx_bridge_tunnel_counter_attr_t *attr_p,
                                               const sx_flow_counter_id_t             counter_id);

/* This function returns the flow counter id that is bound to the fid/tunnel (if any) */
sx_status_t sdk_bridge_tunnel_counter_bind_get(const sx_fid_t                         fid,
                                               const sx_bridge_tunnel_counter_attr_t *attr_p,
                                               sx_flow_counter_id_t                  *counter_id_p);

/* Any module that uses a bridge can this function to indicate a it is in use (preventing deletion) */
sx_status_t sdk_bridge_ref_cnt_increase(sx_bridge_id_t bridge_id);

/* This function releases the use of a bridge */
sx_status_t sdk_bridge_ref_cnt_decrease(sx_bridge_id_t bridge_id);

/* This function returns the fid (if any) associated with a specific virtual port */
sx_status_t sdk_bridge_vport_fid_get(sx_port_log_id_t log_port, sx_fid_t *fid);

/* This function is used to determine if a virtual port belongs to a specific bridge along with with the bridge_id. */
sx_status_t sdk_bridge_is_vport_in_bridge(sx_bridge_id_t *bridge_id, sx_port_log_id_t log_port);

/* This function is used to determine if a virtual port belongs to a specific bridge along with with the bridge_id
 * and if a sync fence needed. */
sx_status_t sdk_bridge_is_sync_fence_needed(sx_bridge_id_t  *bridge_id,
                                            sx_port_log_id_t log_port,
                                            boolean_t       *is_sync_fence_needed);

/* This function returns a virtual port from a specific physical port and a bridge.
 * A specific bridge supports only one virtual port from the same physical port. */
sx_status_t sdk_bridge_port_vport_get(sx_bridge_id_t bridge_id, sx_port_log_id_t port, sx_port_log_id_t *vport);

sx_status_t sdk_bridge_remove_vport_from_gc_queue(sx_port_log_id_t log_port);

sx_status_t sdk_bridge_mode_get(sx_bridge_mode_t *bridge_mode);

sx_status_t sdk_bridge_clear_port(sx_port_id_t port_id, boolean_t remove_port_from_db);

sx_status_t sdk_bridge_redirect_lag_validate(sx_port_log_id_t lag_port_log_id,
                                             sx_port_log_id_t redirect_lag_port_log_id);

sx_status_t sdk_bridge_redirect_lag_set(sx_access_cmd_t  access_cmd,
                                        sx_port_log_id_t lag_port);

sx_status_t sdk_bridge_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);

sx_status_t sdk_bridge_port_delete_validate_igmpv3_state(sx_bridge_id_t   bridge_id,
                                                         sx_port_log_id_t vport,
                                                         boolean_t       *approve_delete_flag);

sx_status_t sx_bridge_vport_count_get(sx_bridge_id_t bridge_id, uint32_t *vport_count);

sx_status_t sdk_bridge_is_homogeneous(sx_bridge_id_t bridge_id, boolean_t *is_homogeneous);


#endif /* __SDK_BRIDGE_H__ */
