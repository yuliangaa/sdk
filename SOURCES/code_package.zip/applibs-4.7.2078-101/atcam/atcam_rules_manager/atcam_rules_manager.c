/*
 * Copyright (c) 2017-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "complib/sx_log.h"
#include "atcam/common/atcam_types.h"
#include "atcam/common/atcam_ipc.h"

#include "atcam_rules_manager.h"

#include "atcam/atcam_sxd_wrapper/atcam_rules_manager_sxd_wrapper.h"

#include "atcam/atcam_regions_manager/atcam_global_mask.h"
#include "atcam/atcam_regions_manager/atcam_regions_manager.h"
#include "atcam/atcam_erps_manager/atcam_erps_manager.h"
#include "atcam_rules_ctcam_prio_db.h"

#include "sx_reg_bulk/sx_reg_bulk.h"
#include "resource_manager/resource_manager_sdk_table.h"


/************************************************
 *  Global variables
 ***********************************************/
/************************************************
 *  Local definitions
 ***********************************************/
/************************************************
 *  Local Defines
 ***********************************************/

#define MAX_PEAPS_BUSY_CHECKS             100
#define MAX_SLEEP_BEFORE_PEAPS_BUSY_CHECK 400

/************************************************
 *  Local variables
 ***********************************************/

#undef  __MODULE__
#define __MODULE__ ATCAM_RULES_MGR

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t g_initialized = FALSE;

#if !ASYNC_INFRA_SUPPORTED
extern sx_status_t atcam_erp_manager_recv_msg(atcam_ipc_msg_t *msg);
#endif


/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __send_msg_to_erp_mgr(atcam_ipc_msg_t *msg_p);
static void __init_erp_msg_common_info(atcam_ipc_msg_t       *msg_p,
                                       atcam_ipc_events_e     event,
                                       sx_atcam_rule_id_t     rule_id,
                                       atcam_rules_db_rule_t *rule_ptr,
                                       uint64_t               transaction_id,
                                       boolean_t              predetermined,
                                       sx_atcam_erp_id_t      predetermined_erp_id);
static sx_status_t __update_erp_m_with_new_rule(sx_atcam_rule_id_t     rule_id,
                                                atcam_rules_db_rule_t *rule_ptr,
                                                uint32_t               transaction_id,
                                                boolean_t              predetermined,
                                                sx_atcam_erp_id_t      predetermined_erp_id);
static sx_status_t __update_erp_m_with_rule_deletion(sx_atcam_rule_id_t     rule_id,
                                                     atcam_rules_db_rule_t *rule_ptr,
                                                     uint32_t               transaction_id,
                                                     boolean_t              predetermined);
static sx_status_t __insert_rule_to_hw(atcam_rules_db_rule_t        *new_rule,
                                       boolean_t                     is_single,
                                       sx_atcam_large_entry_key_id_t large_key_id,
                                       sx_atcam_key_blocks_size_t    key_blocks_size);
static sx_status_t __update_rule_to_hw(atcam_rules_db_rule_t *rule_p, sx_atcam_key_blocks_size_t key_blocks_size);
static sx_status_t __delete_rule_from_hw(atcam_rules_db_rule_t        *rule,
                                         boolean_t                     is_single,
                                         sx_atcam_large_entry_key_id_t large_key_id,
                                         sx_atcam_key_blocks_size_t    key_blocks_size);
static sx_status_t __update_global_mask(sx_acl_region_id_t region_id);
static sx_status_t __update_ctcam_offset_by_rule_prio(sx_atcam_region_id_t region_id,
                                                      uint16_t             size,
                                                      uint16_t             dest_offset,
                                                      uint16_t             source_offset);
static sx_status_t __insert_rule_to_ctcam(atcam_rules_db_rule_t *rule_p);
static sx_status_t __update_erp_m_with_prio_change(sx_atcam_rule_id_t rule_id,
                                                   atcam_rules_db_rule_t *rule_ptr, uint32_t old_prio,
                                                   uint32_t transaction_id);
static sx_status_t __update_atcam_rules_prio(sx_acl_region_id_t          region_id,
                                             sx_flex_acl_rule_priority_t min_priority,
                                             sx_flex_acl_rule_priority_t max_priority,
                                             int32_t                     prio_change,
                                             uint32_t                    transaction_id);
static sx_status_t __update_atomic_prio_shift(sx_acl_region_id_t          region_id,
                                              sx_flex_acl_rule_priority_t min_priority,
                                              sx_flex_acl_rule_priority_t max_priority,
                                              int32_t                     prio_change,
                                              uint32_t                    ct_offset,
                                              uint32_t                    ct_size);
static sx_status_t __update_rm_with_rules(sx_acl_region_id_t region_id,
                                          uint32_t           rules_count,
                                          boolean_t          is_atcam,
                                          boolean_t          is_add);
static sx_status_t __initialize_rm_sdk_table(rm_sdk_table_type_e resource,
                                             uint32_t            table_size_min,
                                             uint32_t            table_size_max);
static sx_status_t __init_tcam_resources();
static sx_status_t __deinit_tcam_resources();

static sx_status_t __atcam_rules_duplication_delete(const sx_acl_region_id_t     region_id,
                                                    const atcam_rules_db_rule_t *p_rule,
                                                    uint32_t                     transaction_id);
static sx_status_t __atcam_rules_duplication_insert(const sx_acl_region_id_t    region_id,
                                                    const sx_acl_rule_offset_t  offset,
                                                    const sx_atcam_key_t       *key,
                                                    kvd_linear_manager_index_t  action_set,
                                                    sx_flex_acl_rule_priority_t priority,
                                                    uint32_t                    transaction_id);

/************************************************
 *  Function implementations
 ***********************************************/


sx_status_t atcam_rules_manager_init(const uint32_t num_of_atcam_regions)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    sx_status_t rollback_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_initialized) {
        SX_LOG_ERR("atcam_rules_manager_init: module was already initialized\n");
        sx_status = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    sx_status = __init_tcam_resources();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialize resource managers for atcam rules manager.\n");
        goto out;
    }

    sx_status = atcam_rules_ctcam_prio_db_init(num_of_atcam_regions, __update_ctcam_offset_by_rule_prio);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_rules_ctcam_rules_db_init: Failed to init ctcam rules-db. [%s]\n", sx_status_str(sx_status));
        goto rm_rb;
    }

    sx_status = atcam_rules_db_init(num_of_atcam_regions);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_rules_manager_init: Failed to init rules-db. [%s]\n", sx_status_str(sx_status));
        goto ctcam_rules_db_rb;
    }

    sx_status = atcam_large_key_db_init(NUM_OF_LARGE_KEY_IDS);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_large_key_db_init: Failed to init large_key-db. [%s]\n", sx_status_str(sx_status));
        goto rules_db_init_rb;
    }


    g_initialized = TRUE;
    goto out;

rules_db_init_rb:
    rollback_status = atcam_rules_db_deinit(FALSE);
    if (rollback_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_rules_db_deinit: Fatal error at rollback. [%s]\n", sx_status_str(rollback_status));
    }

ctcam_rules_db_rb:
    rollback_status = atcam_rules_ctcam_prio_db_deinit(FALSE);
    if (rollback_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_rules_ctcam_rules_db_deinit: Fatal error at rollback. [%s]\n",
                   sx_status_str(rollback_status));
    }

rm_rb:
    rollback_status = __deinit_tcam_resources();
    if (SX_CHECK_FAIL(rollback_status)) {
        SX_LOG_ERR("Failed to rollback deinit rm for atcam rules manager\n");
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


void atcam_rules_manager_deinit(const boolean_t forced_deinit)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_initialized) {
        SX_LOG_ERR("atcam_rules_manager_deinit: Module is not initialized\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    sx_status = atcam_large_key_db_deinit(forced_deinit);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_large_key_db_deinit: Failed to de-init large-key. [%s]\n", sx_status_str(sx_status));
    }

    sx_status = atcam_rules_db_deinit(forced_deinit);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_rules_manager_deinit: Failed to de-init rules-db. [%s]\n", sx_status_str(sx_status));
    }

    sx_status = atcam_rules_ctcam_prio_db_deinit(forced_deinit);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("atcam_rules_ctcam_rules_db_deinit: Failed to de-init ctcam rules-db. [%s]\n",
                   sx_status_str(sx_status));
    }

    sx_status = __deinit_tcam_resources();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to deinit resource manager for atcam rules manager\n");
    }

    g_initialized = FALSE;

out:
    SX_LOG_EXIT();
}

sx_status_t atcam_rules_manager_delete_region(const sx_atcam_region_id_t region_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = atcam_rules_ctcam_prio_db_del_region(region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to delete region %d ctcam allocation (%s)\n", region_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_rules_manager_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    FILE       *stream = NULL;

    status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(status)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "SDK ATCAM (SpACE) rules manager Module");
    dbg_utils_pprinter_field_print(stream, "Module Initialized :",  &g_initialized, PARAM_BOOL_E);

    if (g_initialized) {
        status = atcam_rules_db_dump(dbg_dump_params_p);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to generate debug dump for rules db\n");
            goto out;
        }

        status = atcam_rules_ctcam_prio_db_dump(dbg_dump_params_p);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to generate debug dump for ctcam priority db\n");
            goto out;
        }

        /* Large key DB dump */
        status = atcam_large_key_db_generate_dump(dbg_dump_params_p);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Failed to generate debug dump for large key db.\n");
            return status;
        }
    }

out:
    return status;
}


/************************************************
 *  Local Functions implementations
 ***********************************************/

sx_status_t atcam_rules_manager_insert_rule(const sx_acl_region_id_t    region_id,
                                            const sx_acl_rule_offset_t  offset,
                                            const sx_atcam_key_t       *key,
                                            kvd_linear_manager_index_t  action_set_p,
                                            sx_flex_acl_rule_priority_t priority,
                                            uint32_t                    transaction_id,
                                            sx_dev_id_t                 dev_id,
                                            boolean_t                   predetermined,
                                            sx_atcam_erp_id_t           predetermined_erp_id)
{
    sx_status_t                       sx_status = SX_STATUS_SUCCESS;
    sx_status_t                       rollback_status = SX_STATUS_SUCCESS;
    atcam_rules_db_rule_t            *new_rule = NULL;
    sx_atcam_key_value_t              rule_key_values;
    sx_atcam_key_blocks_size_t        key_blocks_size = 0;
    ctcam_rules_db_region_info_t      ctcam_db_region_info;
    sx_atcam_large_entry_key_handle_t large_key_handle = LARGE_KEY_HANDLE_INVALID;
    boolean_t                         should_update_gm = FALSE;
    sx_atcam_large_entry_key_id_t     large_key_id = LARGE_KEY_HANDLE_INVALID;
    boolean_t                         is_single = FALSE;
    uint32_t                          ctcam_num_of_rules = 0, atcam_num_of_rules = 0;


    SX_LOG_ENTER();

    UNUSED_PARAM(dev_id);
    SX_MEM_CLR(rule_key_values);
    SX_MEM_CLR(ctcam_db_region_info);

    /* Handle ATCAM rule insertion in case of duplicated rules found.
     * Duplicated rules are rules in ATCAM with the same key but not configured in HW, only in SW DB.
     *
     * Otherwise, if not found an ATCAM rule with the same key, return "ENTRY_NOT_FOUND" and handle the "normal case" i.e. rule that has no duplications. */
    sx_status = __atcam_rules_duplication_insert(region_id, offset, key, action_set_p, priority, transaction_id);
    if (sx_status != SX_STATUS_ENTRY_NOT_FOUND) {
        goto out;
    }

    if (!predetermined) {
        sx_status = atcam_global_mask_rule_set(SX_ACCESS_CMD_ADD, region_id,
                                               (sx_atcam_mask_byte_t*)key->flex_mask_blocks,
                                               &should_update_gm);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update global mask for rule offset %d, region %d\n", offset, region_id);
            goto out;
        }
        /* If the rule is predetermined there is no need to update the global mask in hw*/
        if (should_update_gm) {
            sx_status = __update_global_mask(region_id);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to update global mask in HW for rule offset %d, region %d\n",
                    offset,
                    region_id);
                goto gm_rollback;
            }
        }
    }

    sx_status = atcam_rules_db_rule_allocate(region_id, offset, priority, action_set_p, key, FALSE, &new_rule);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed when allocating new rule, offset %d, region %d\n", offset, region_id);
        goto db_rollback;
    }

    sx_status = __update_erp_m_with_new_rule(new_rule->rule_id,
                                             new_rule,
                                             transaction_id,
                                             predetermined,
                                             predetermined_erp_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update ERP manager for rule offset %d, region %d\n", offset, region_id);
        goto erp_db_rollback;
    }

    /* if this rule is CTCAM rule, we need to add it to sorted db and calculate the CTCAM offset */
    if (!new_rule->is_atcam) {
        /* Try to insert the rule into the ctcam. This operation may fail due to resource limits */
        sx_status = __insert_rule_to_ctcam(new_rule);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to insert rule to ctcam rule offset %d, region %d\n", offset, region_id);
            goto erp_m_rollback;
        }
        sx_status = atcam_regions_db_ctcam_rules_num_get(region_id, &ctcam_num_of_rules);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to get ctcam num of rules for rule offset %d, region %d DB\n",
                offset,
                region_id);
            goto erp_m_rollback;
        }
        sx_status = atcam_regions_db_ctcam_rules_num_set(region_id, ctcam_num_of_rules + 1);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to update ctcam num  of rules for rule offset %d, region %d DB\n",
                offset,
                region_id);
            goto erp_m_rollback;
        }
    } else {
        /* Check if we have resources for inserting this rule into the ATCAM */
        sx_status = __update_rm_with_rules(region_id, 1, new_rule->is_atcam, TRUE);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed on RM update for atcam insert rule. Region [%u].\n", region_id);
            goto erp_m_rollback;
        }
        /* Check large-key flow */
        sx_status = atcam_regions_db_key_blocks_size_get(region_id, &key_blocks_size);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get region block size for region %d\n", region_id);
            goto erp_m_rollback;
        }

        sx_status = atcam_regions_db_atcam_rules_num_get(region_id, &atcam_num_of_rules);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get atcam num of rules for rule in region %d DB\n", region_id);
            goto erp_m_rollback;
        }
        sx_status = atcam_regions_db_atcam_rules_num_set(region_id, atcam_num_of_rules + 1);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update atcam num of rules for rule in region %d DB\n", region_id);
            goto erp_m_rollback;
        }

        if (key_blocks_size == SX_ATCAM_SIX_KEY_BLOCKS) {
            /* Large key flow */
            sx_status = atcam_large_key_db_rule_insert(region_id,
                                                       new_rule->erp_id,
                                                       key,
                                                       &new_rule->delta,
                                                       &large_key_handle);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to insert rule offset %d to DB in region %d\n", offset, region_id);
                goto erp_m_rollback;
            }

            sx_status = atcam_rules_db_rule_large_key_update(region_id,
                                                             new_rule->rule_id,
                                                             large_key_handle);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to update rule id 0x%" PRIx64 ", offset %d DB in region %d with large_key_handle\n",
                    new_rule->rule_id,
                    new_rule->offset,
                    region_id);
                goto large_key_rollback;
            }

            sx_status = atcam_large_key_id_get(large_key_handle,
                                               &large_key_id,
                                               &is_single);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get large_key_id\n");
                goto large_key_rollback;
            }
        }
    }

    sx_status = __insert_rule_to_hw(new_rule, is_single, large_key_id, key_blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to insert rule to HW\n");
        goto large_key_rollback;
    }

    goto out;

large_key_rollback:
    if (key_blocks_size == SX_ATCAM_SIX_KEY_BLOCKS) {
        rollback_status = atcam_large_key_db_rule_del(large_key_handle, &is_single);
        if (rollback_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to rollback rule from Large key for rule offset %d, region %d\n",
                offset,
                region_id);
        }
    }
erp_m_rollback:
    rollback_status = __update_erp_m_with_rule_deletion(new_rule->rule_id, new_rule, transaction_id, FALSE);
    if (rollback_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to rollback rule from ERP M for rule offset %d, region %d\n", offset, region_id);
    }
erp_db_rollback:
    rollback_status = atcam_rules_db_rule_deallocate(region_id, offset);
    if (rollback_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to rollback rule from DB for rule offset %d, region %d\n", offset, region_id);
    }


db_rollback:
gm_rollback:
    if (!predetermined) {
        rollback_status = atcam_global_mask_rule_set(SX_ACCESS_CMD_DELETE, region_id,
                                                     (sx_atcam_mask_byte_t*)key->flex_mask_blocks,
                                                     &should_update_gm);
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __update_ctcam_offset_by_rule_prio(sx_atcam_region_id_t region_id,
                                                      uint16_t             size,
                                                      uint16_t             dest_offset,
                                                      uint16_t             source_offset)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    struct ku_prcr_reg prcr_reg_data;
    sxd_reg_meta_t     reg_meta;

    SX_MEM_CLR(prcr_reg_data);
    SX_MEM_CLR(reg_meta);

    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.dev_id = DEFAULT_DEV_ID;
    reg_meta.swid = 0;

    prcr_reg_data.op = SXD_PRCR_OP_RULES_MOVE;
    prcr_reg_data.size = size;
    prcr_reg_data.dest_offset = dest_offset;
    prcr_reg_data.offset = source_offset;

    sx_status = atcam_regions_db_tcam_region_info_get(region_id, prcr_reg_data.tcam_region_info);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to get region info, "
                   "error: %s\n", sx_status_str(sx_status));
        goto out;
    }
    memcpy(&(prcr_reg_data.dest_tcam_region_info), &(prcr_reg_data.tcam_region_info),
           sizeof(prcr_reg_data.dest_tcam_region_info));


    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PRCR_E, &prcr_reg_data, &reg_meta, 1, NULL, NULL);
    sx_status = SXD_STATUS_TO_SX_STATUS(sxd_status);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set PRCR (%s)\n", sx_status_str(sx_status));
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __delete_rule_from_ctcam(atcam_rules_db_rule_t *rule_p)
{
    sx_status_t                  status = SX_STATUS_SUCCESS;
    uint32_t                     ctcam_region_size = 0;
    ctcam_rules_db_region_info_t region_info;
    sx_atcam_key_blocks_size_t   key_blocks_size = 0;

    SX_MEM_CLR(region_info);

    status = atcam_rules_ctcam_prio_db_del_rule(rule_p->region_id, rule_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "Failed to delete rule id 0x%" PRIx64 ", offset %d, from ctcam db\n",
            rule_p->rule_id,
            rule_p->offset);
        goto out;
    }

    status = atcam_rules_ctcam_prio_db_get_region_info(rule_p->region_id, &region_info);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region %d info from ctcam db\n", rule_p->region_id);
        goto out;
    }

    /* Return the rule to the resource manager */
    status = __update_rm_with_rules(rule_p->region_id, 1, FALSE, FALSE);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed on RM update for ctcam delete rule. Region [%u].\n", rule_p->region_id);
        goto out;
    }

    if (region_info.ctcam_num_of_rules + CTCAM_CHANGE_INTERVAL < region_info.region_ctcam_size) {
        ctcam_region_size = region_info.region_ctcam_size - CTCAM_CHANGE_INTERVAL;

        status = atcam_regions_db_key_blocks_size_get(rule_p->region_id, &key_blocks_size);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to get key block size for region %d when deleting rule from ctcam\n",
                rule_p->region_id);
            goto out;
        }
        /* Update the RM with the new size of the CTCAM */
        status = atcam_rules_manager_update_rm_ctcam_size(key_blocks_size,
                                                          ctcam_region_size,
                                                          ctcam_region_size + CTCAM_CHANGE_INTERVAL);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to deallocate ctcam size for region %d when deleting rule. New size=[%u], old size=[%u]\n",
                rule_p->region_id,
                ctcam_region_size,
                ctcam_region_size + CTCAM_CHANGE_INTERVAL);
            goto out;
        }
        if (ctcam_region_size) {
            status = atcam_rules_ctcam_prio_db_resize_region(rule_p->region_id, ctcam_region_size);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to resize region %d\n", rule_p->region_id);
                goto out;
            }
        } else {
            status = atcam_rules_ctcam_prio_db_del_region(rule_p->region_id);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to delete region %d ctcam db\n", rule_p->region_id);
                goto out;
            }
        }
        status = atcam_regions_manager_region_resize_ctcam(rule_p->region_id, ctcam_region_size);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to resize region %d\n", rule_p->region_id);
            goto out;
        }
    }

out:
    return status;
}

static sx_status_t __insert_rule_to_ctcam(atcam_rules_db_rule_t *rule_p)
{
    sx_status_t                  status = SX_STATUS_SUCCESS;
    ctcam_rules_db_region_info_t region_info;
    uint32_t                     new_ctcam_region_size = 0;
    sx_atcam_key_blocks_size_t   key_blocks_size = 0;

    SX_MEM_CLR(region_info);

    /* Due to optimization we do not create a prio_db when there are no rules even though
     * the hw resource is already allocated. We create the db here when we add the first rule.
     */
    status = atcam_rules_ctcam_prio_db_get_region_info(rule_p->region_id, &region_info);
    if (status != SX_STATUS_SUCCESS) {
        if (status == SX_STATUS_ENTRY_NOT_FOUND) {
            new_ctcam_region_size = INITIAL_CTCAM_REGION_SIZE; /*In this case, we know we'll have at least one CTCAM rule - so we allocate the minimum size */

            status = atcam_rules_ctcam_prio_db_add_region(rule_p->region_id,
                                                          new_ctcam_region_size,
                                                          FLEX_ACL_RULE_PRIORITY_MAX,
                                                          FLEX_ACL_RULE_PRIORITY_MIN);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "atcam_rules_ctcam_rules_db_add_region failed to region %d, rule id 0x%" PRIx64 ", offset %d\n",
                    rule_p->region_id,
                    rule_p->rule_id,
                    rule_p->offset);
                goto out;
            }
            /* Get the region info again after the update */
            status = atcam_rules_ctcam_prio_db_get_region_info(rule_p->region_id, &region_info);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("atcam_rules_ctcam_rules_db_get_region_info failed for region %d\n",
                           rule_p->region_id);
                goto out;
            }
        } else {
            SX_LOG_ERR("atcam_rules_ctcam_rules_db_get_region_info failed for region %d\n",
                       rule_p->region_id);
            goto out;
        }
    }
    if (region_info.ctcam_num_of_rules == region_info.region_ctcam_size) {
        /* Increase the CTCAM size with an additional size */
        new_ctcam_region_size = region_info.region_ctcam_size + CTCAM_CHANGE_INTERVAL;

        status = atcam_regions_db_key_blocks_size_get(rule_p->region_id, &key_blocks_size);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to get key block size for region %d when deleting rule from ctcam\n",
                rule_p->region_id);
            goto out;
        }
        /* Update the RM with the new size of the CTCAM */
        status = atcam_rules_manager_update_rm_ctcam_size(key_blocks_size,
                                                          new_ctcam_region_size,
                                                          region_info.region_ctcam_size);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR_RESOURCE_COND(status,
                                     "Failed to allocate ctcam size for region %d when adding rule. New size=[%u] old size=[%u]\n",
                                     rule_p->region_id,
                                     new_ctcam_region_size,
                                     region_info.region_ctcam_size);
            goto out;
        }

        status = atcam_rules_ctcam_prio_db_resize_region(rule_p->region_id, new_ctcam_region_size);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to resize region %d\n", rule_p->region_id);
            goto out;
        }
        status = atcam_regions_manager_region_resize_ctcam(rule_p->region_id, new_ctcam_region_size);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to resize region %d\n", rule_p->region_id);
            goto out;
        }
    }
    /* Add this rule to the CTCAM resource manager. This should always succeed
     * due to the rm allocation functions we've called in the previous lines.
     */
    status = __update_rm_with_rules(rule_p->region_id, 1, FALSE, TRUE);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update ctcam rm for rule id 0x%" PRIx64 ", offset %d to region %d\n",
                   rule_p->rule_id, rule_p->region_id, rule_p->offset);
        goto out;
    }

    /* num_of_psort_regions counts the regions we should move in CTCAM in order to insert new rule */
    status = atcam_rules_ctcam_prio_db_add_rule(rule_p->region_id, rule_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed add to ctcam db: rule id 0x%" PRIx64 ", offset %d to region %d\n",
                   rule_p->rule_id, rule_p->region_id, rule_p->offset);
        goto out;
    }

out:
    return status;
}

sx_status_t atcam_rules_manager_delete_rule(const sx_acl_region_id_t   region_id,
                                            const sx_acl_rule_offset_t offset,
                                            uint32_t                   transaction_id,
                                            boolean_t                  predetermined)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_status_t                   last_failure_status = SX_STATUS_SUCCESS;
    atcam_rules_db_rule_t        *rule_p = NULL;
    boolean_t                     should_update_gm = FALSE;
    sx_atcam_large_entry_key_id_t large_key_id = LARGE_KEY_HANDLE_INVALID;
    boolean_t                     is_single = FALSE;
    sx_atcam_key_value_t          rule_key_values;
    uint32_t                      atcam_num_of_rules = 0, ctcam_num_of_rules = 0;


    SX_LOG_ENTER();
    SX_MEM_CLR(rule_key_values);

    sx_status = atcam_rules_db_rule_get_by_offset(region_id, offset, &rule_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find rule offset %d, region %d\n", offset, region_id);
        goto out;
    }

    /* Handle rule delete in case of duplicated rules are exists - replace the deleted rule with the next highest priority duplicated rule.
     * Duplicated rules are rules with the same key but not configured in HW, only in SW DB.
     *
     * If a rule with the same key exists, we handle rule deletion within this function and go out.
     * Otherwise, we didn't find rule a duplicated rule (key with the same key but with lower priority) return with "ENTRY_NOT_FOUND", and handle the "normal case" i.e. rule that have no duplication. */
    sx_status = __atcam_rules_duplication_delete(region_id, rule_p, transaction_id);
    if (sx_status != SX_STATUS_ENTRY_NOT_FOUND) {
        goto out;
    }

    if (!predetermined) {
        sx_status = atcam_global_mask_rule_set(SX_ACCESS_CMD_DELETE, region_id,
                                               rule_p->key_value_blocks.flex_mask_blocks,
                                               &should_update_gm);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update global mask for rule offset %d, region %d\n", offset, region_id);
            goto out;
        }
        /* If the rule is predetermined there is no need to update the global mask in hw */
        if (should_update_gm) {
            sx_status = __update_global_mask(region_id);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed to update global mask in HW for rule offset %d, region %d\n",
                    offset,
                    region_id);
                last_failure_status = sx_status;
            }
        }
    }

    if (rule_p->is_atcam) {
        /* Check large-key flow */
        if (rule_p->large_key_handle != LARGE_KEY_HANDLE_INVALID) {
            sx_status = atcam_large_key_id_get(rule_p->large_key_handle,
                                               &large_key_id,
                                               &is_single);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get large_key_id\n");
                goto out;
            }

            sx_status = atcam_large_key_db_rule_del(rule_p->large_key_handle, &is_single);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to delete rule offset %d from region %d\n", offset, region_id);
                last_failure_status = sx_status;
            }
        }

        sx_status = __delete_rule_from_hw(rule_p, is_single, large_key_id, 0 /*key block size is not relevant*/);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to delete rule from HW\n");
            last_failure_status = sx_status;
        }

        /* Return the rule to the resource manager */
        sx_status = __update_rm_with_rules(region_id, 1, rule_p->is_atcam, FALSE);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed on RM update for atcam delete rule. Region [%u].\n", region_id);
            last_failure_status = sx_status;
        }

        sx_status = atcam_regions_db_atcam_rules_num_get(region_id, &atcam_num_of_rules);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get atcam num of rules for rule in region %d DB\n", region_id);
            last_failure_status = sx_status;
        }
        sx_status = atcam_regions_db_atcam_rules_num_set(region_id, atcam_num_of_rules - 1);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update atcam num of rules for rule in region %d DB\n", region_id);
            last_failure_status = sx_status;
        }
    } else {
        /* In this case - we first delete from HW - because moves might occur */
        sx_status =
            __delete_rule_from_hw(rule_p, FALSE, LARGE_KEY_HANDLE_INVALID, 0 /*key block size is not relevant*/);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to delete rule from HW\n");
            last_failure_status = sx_status;
        }
        /* Delete rule and return it to the rm */
        sx_status = __delete_rule_from_ctcam(rule_p);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to delete rule from CTCAM DB\n");
            last_failure_status = sx_status;
        }

        sx_status = atcam_regions_db_ctcam_rules_num_get(region_id, &ctcam_num_of_rules);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get ctcam num of rules  for rule in region %d DB\n", region_id);
            last_failure_status = sx_status;
        }
        sx_status = atcam_regions_db_ctcam_rules_num_set(region_id, ctcam_num_of_rules - 1);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update ctcam of rules  num for rule in region %d DB\n", region_id);
            last_failure_status = sx_status;
        }
    }

    sx_status = __update_erp_m_with_rule_deletion(rule_p->rule_id, rule_p, transaction_id, predetermined);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update ERP manager for rule offset %d, region %d\n", offset, region_id);
        last_failure_status = sx_status;
    }

    sx_status = atcam_rules_db_rule_deallocate(region_id, offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("When deallocate rule, offset %d, region %d\n", offset, region_id);
        last_failure_status = sx_status;
    }


out:
    SX_LOG_EXIT();
    if (last_failure_status != SX_STATUS_SUCCESS) {
        return last_failure_status;
    }
    return sx_status;
}

static sx_status_t __update_action(const sx_acl_region_id_t   region_id,
                                   const sx_acl_rule_offset_t rule_id,
                                   kvd_linear_manager_index_t action_set,
                                   uint32_t                   transaction_id)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    atcam_rules_db_rule_t     *rule_p = NULL;
    sx_atcam_key_blocks_size_t key_blocks_size = 0;

    UNUSED_PARAM(transaction_id);

    SX_LOG_ENTER();

    sx_status = atcam_rules_db_rule_get_by_offset(region_id, rule_id, &rule_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find rule %d, region %d\n", rule_id, region_id);
        goto out;
    }

    sx_status = atcam_regions_db_key_blocks_size_get(region_id, &key_blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region block size for region %d\n", region_id);
        goto out;
    }

    rule_p->action = action_set;

    /* There is no need to update HW if the rule is a duplication.
     * Duplicated rules are rules in ATCAM with the same key but not configured in HW, only in SW DB. */
    if (rule_p->is_duplicated == FALSE) {
        sx_status = __update_rule_to_hw(rule_p, key_blocks_size);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed update rule [%d], region [%d] in HW \n", rule_id, region_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __ctcam_rule_prio_update(atcam_rules_db_rule_t      *rule_p,
                                            sx_flex_acl_rule_priority_t old_priority,
                                            sx_flex_acl_rule_priority_t new_priority)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS, rb_status = SX_STATUS_SUCCESS;
    atcam_rules_db_rule_t     *new_rule_p = NULL;
    const sx_acl_rule_offset_t preserve_offset = rule_p->offset;

    SX_LOG_ENTER();

    /* Allocate new rule and try to insert the rule into the CTCAM. This operation may fail due to resource limits.
     * The rule's offset is a dummy and changed when the old rule is removed. */
    sx_status = atcam_rules_db_rule_allocate(rule_p->region_id,
                                             ATCAM_INVALID_RULE_OFFSET,
                                             new_priority,
                                             rule_p->action,
                                             &rule_p->key_value_blocks,
                                             FALSE,
                                             &new_rule_p);
    if (SX_CHECK_FAIL(sx_status)) {
        if (sx_status == SX_STATUS_MEMORY_ERROR) {
            sx_status = SX_STATUS_NO_RESOURCES;
        } else {
            SX_LOG_ERR("Failed when allocating new rule, offset %d, region %d\n",
                       ATCAM_INVALID_RULE_OFFSET,
                       rule_p->region_id);
        }
        goto out;
    }

    sx_status = __update_erp_m_with_new_rule(new_rule_p->rule_id,
                                             new_rule_p,
                                             0,
                                             TRUE,
                                             ATCAM_INVALID_ERP_ID);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to update ERP manager for rule offset %d, region %d\n",
                   new_rule_p->offset,
                   new_rule_p->region_id);
        goto rollback_alloc;
    }

    sx_status = __insert_rule_to_ctcam(new_rule_p);
    if (SX_CHECK_FAIL(sx_status)) {
        if (sx_status != SX_STATUS_NO_RESOURCES) {
            SX_LOG_ERR("Failed to add rule id 0x%" PRIx64 " to ctcam \n", new_rule_p->rule_id);
        }
        goto rollback_alloc2;
    }

    sx_status = __insert_rule_to_hw(new_rule_p, FALSE, LARGE_KEY_HANDLE_INVALID, 0);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to add rule id 0x%" PRIx64 " to ctcam hw when updating priority\n", new_rule_p->rule_id);
        goto rollback_ctcam;
    }

    rule_p->priority = old_priority;
    sx_status = __delete_rule_from_hw(rule_p, FALSE, LARGE_KEY_HANDLE_INVALID, 0);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to delete  rule id 0x%" PRIx64 " from ctcam hw when updating priority\n",
                   rule_p->rule_id);
        goto rollback_hw;
    }

    sx_status = __delete_rule_from_ctcam(rule_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to delete rule id 0x%" PRIx64 " from ctcam \n", rule_p->rule_id);
        goto out;
    }

    sx_status = __update_erp_m_with_rule_deletion(rule_p->rule_id, rule_p, 0, TRUE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update ERP manager for rule offset %d, region %d\n", rule_p->offset, rule_p->region_id);
        goto out;
    }
    /* The calling function already changed the main DB with the new priority */
    rule_p->priority = new_priority;
    sx_status = atcam_rules_db_rule_deallocate(rule_p->region_id, rule_p->offset);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("When deallocate rule, offset %d, region %d\n", rule_p->offset, rule_p->region_id);
        goto out;
    }

    /* After removing the old prio rule - change the offset */
    sx_status = atcam_rules_db_change_rule_offset(new_rule_p->region_id,
                                                  ATCAM_INVALID_RULE_OFFSET,
                                                  preserve_offset);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed changing offsets [%u]->[%u], region [%u] CTCAM rule prio update.\n",
                   ATCAM_INVALID_RULE_OFFSET,
                   preserve_offset,
                   new_rule_p->region_id);
        goto out;
    }

    goto out;

rollback_hw:
    rb_status = __delete_rule_from_hw(new_rule_p, FALSE, LARGE_KEY_HANDLE_INVALID, 0);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to rollback new rule id 0x%" PRIx64 " from HW for rule offset %d, region %d\n",
                   new_rule_p->rule_id,
                   new_rule_p->offset,
                   new_rule_p->region_id);
    }

rollback_ctcam:
    rb_status = __delete_rule_from_ctcam(new_rule_p);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to rollback new rule id 0x%" PRIx64 " from CTCAM for rule offset %d, region %d\n",
                   new_rule_p->rule_id,
                   new_rule_p->offset,
                   new_rule_p->region_id);
    }


rollback_alloc2:
    rb_status = __update_erp_m_with_rule_deletion(new_rule_p->rule_id, new_rule_p, 0, TRUE);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to rollback update ERP manager for rule offset %d, region %d\n",
                   rule_p->offset,
                   rule_p->region_id);
        goto out;
    }

rollback_alloc:
    rb_status = atcam_rules_db_rule_deallocate(new_rule_p->region_id, ATCAM_INVALID_RULE_OFFSET);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to rollback rule from DB for rule offset %d, region %d\n",
                   ATCAM_INVALID_RULE_OFFSET,
                   new_rule_p->region_id);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t __update_rule_prio(sx_acl_region_id_t          region_id,
                               const sx_acl_rule_offset_t  offset,
                               sx_flex_acl_rule_priority_t new_priority,
                               kvd_linear_manager_index_t  action_set,
                               uint32_t                    transaction_id)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    atcam_rules_db_rule_t        *rule_p = NULL;
    sx_atcam_large_entry_key_id_t large_key_id = 0;
    boolean_t                     is_single = FALSE;
    sx_atcam_key_blocks_size_t    key_blocks_size = 0;
    sx_flex_acl_rule_priority_t   old_priority = 0;
    boolean_t                     is_insufficient_resources = FALSE;

    SX_LOG_ENTER();

    sx_status = atcam_rules_db_rule_get_by_offset(region_id, offset, &rule_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find rule %d, region %d\n", offset, region_id);
        goto out;
    }

    old_priority = rule_p->priority;

    sx_status = atcam_regions_db_key_blocks_size_get(region_id, &key_blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get key blocks size for region %d\n", region_id);
        goto out;
    }

    large_key_id = LARGE_KEY_HANDLE_INVALID;
    if (rule_p->large_key_handle != LARGE_KEY_HANDLE_INVALID) {
        sx_status = atcam_large_key_id_get(rule_p->large_key_handle,
                                           &large_key_id,
                                           &is_single);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR(
                "Failed to get large_key_id for offset %d  rule id 0x%" PRIx64 "\n",
                offset,
                rule_p->rule_id);
            goto out;
        }
    }

    sx_status = atcam_rules_db_rule_priority_change(region_id, rule_p->offset, new_priority);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to change in DB the priority of rule offset [%d] to priority [%d], error: %s\n",
                   rule_p->offset,
                   new_priority,
                   sx_status_str(sx_status));
        goto out;
    }
    /* No HW update for a duplicated rule */
    if (rule_p->is_duplicated == TRUE) {
        goto out;
    }

    rule_p->action = action_set; /* It is possible that an action was also edited while updating this rules prio */

    if (rule_p->is_atcam) {
        /* Decrease rule priority before we update all other prune vectors */
        if (new_priority < old_priority) {
            /* we mark to the rule to look at CTCAM and other erps till erp manager will update everything */
            rule_p->prune_vector = 0;
            rule_p->prune_ctcam_cnt = 1;

            sx_status = atcam_sxd_wrapper_set_rule_to_hw(rule_p,
                                                         DEFAULT_DEV_ID,
                                                         (rule_op_e)SXD_PTCE_OP_UPDATE,
                                                         TRUE, large_key_id, key_blocks_size);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set prune all to rule id 0x%" PRIx64  "\n", rule_p->rule_id);
                goto out;
            }
        }
    }

    sx_status = __update_erp_m_with_prio_change(rule_p->rule_id, rule_p, old_priority, transaction_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update rule prio for offset %d, region %d\n", offset, region_id);
        goto out;
    }

    if (rule_p->is_atcam) {
        /* Update rule with updated prune vector */
        sx_status = atcam_sxd_wrapper_set_rule_to_hw(rule_p,
                                                     DEFAULT_DEV_ID,
                                                     (rule_op_e)SXD_PTCE_OP_UPDATE,
                                                     TRUE, large_key_id, key_blocks_size);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set prune all to rule id 0x%" PRIx64 " \n", rule_p->rule_id);
            goto out;
        }
    } else {
        /* In CTCAM, rules are stored by priority. When updating a rule's priority, we need first to delete it from the old priority,
         * move other rules, and then add it again. The move is done automatically by CTCAM infrastructure.
         *
         * However, if we delete the old priority rule first, there will be a moment when there is no rule to hit except the default rule.
         * To avoid this, we try to add a rule with the new priority to CTCAM. But this operation may fail due to resource limits.
         * If it fails, we delete the old priority rule and then add the new priority rule.
         */
        sx_status = __ctcam_rule_prio_update(rule_p, old_priority, new_priority);
        if (SX_CHECK_FAIL(sx_status)) {
            if (sx_status == SX_STATUS_NO_RESOURCES) {
                is_insufficient_resources = TRUE;
            } else {
                SX_LOG_ERR(
                    "Failed to change in HW CTCAM the priority of rule id 0x%" PRIx64 " to priority [%d], error: %s\n",
                    rule_p->rule_id,
                    new_priority,
                    sx_status_str(sx_status));
                goto out;
            }
        }

        if (is_insufficient_resources == TRUE) {
            /* We must first delete it from old prio, move other rules and than add it again */
            /* the move is done automatically from CTCAM infra */
            rule_p->priority = old_priority;
            sx_status = __delete_rule_from_hw(rule_p, FALSE, LARGE_KEY_HANDLE_INVALID, 0);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to delete  rule id 0x%" PRIx64 " from ctcam hw when updating priority\n",
                           rule_p->rule_id);
                goto out;
            }
            sx_status = __delete_rule_from_ctcam(rule_p);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to delete rule id 0x%" PRIx64 " from ctcam \n", rule_p->rule_id);
                goto out;
            }
            rule_p->priority = new_priority;
            sx_status = __insert_rule_to_ctcam(rule_p);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to add rule id 0x%" PRIx64 " to ctcam \n", rule_p->rule_id);
                goto out;
            }
            sx_status = __insert_rule_to_hw(rule_p, FALSE, LARGE_KEY_HANDLE_INVALID, 0);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to add rule id 0x%" PRIx64 " to ctcam hw when updating priority\n",
                           rule_p->rule_id);
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __update_atcam_rules_prio(sx_acl_region_id_t          region_id,
                                             sx_flex_acl_rule_priority_t min_priority,
                                             sx_flex_acl_rule_priority_t max_priority,
                                             int32_t                     prio_change,
                                             uint32_t                    transaction_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    ct_offset = 0, ct_size = 0;

    SX_LOG_ENTER();

    UNUSED_PARAM(transaction_id);

    sx_status = atcam_rules_db_priorities_change(region_id,
                                                 min_priority,
                                                 max_priority,
                                                 prio_change,
                                                 &ct_offset,
                                                 &ct_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update atcam rules, region %d\n", region_id);
        goto out;
    }

    sx_status = atcam_rules_ctcam_prio_db_change_prio(region_id,
                                                      min_priority,
                                                      max_priority,
                                                      prio_change);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to change psort priority, region %d\n", region_id);
        goto out;
    }

    sx_status = __update_atomic_prio_shift(region_id,
                                           min_priority,
                                           max_priority,
                                           prio_change,
                                           ct_offset,
                                           ct_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set PEAPS reg, region %d\n", region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __update_atomic_prio_shift(sx_acl_region_id_t          region_id,
                                              sx_flex_acl_rule_priority_t min_priority,
                                              sx_flex_acl_rule_priority_t max_priority,
                                              int32_t                     prio_change,
                                              uint32_t                    ct_offset,
                                              uint32_t                    ct_size)
{
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_status = SXD_STATUS_SUCCESS;
    struct ku_peaps_reg peaps_reg_data;
    sxd_reg_meta_t      peaps_reg_meta;
    sx_dev_id_t         dev_id = 1;
    uint8_t             i = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(peaps_reg_data);
    SX_MEM_CLR(peaps_reg_meta);

    peaps_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    peaps_reg_meta.dev_id = dev_id;

    sx_status = atcam_regions_db_tcam_region_info_get(region_id, peaps_reg_data.tcam_region_info);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Failed to get region info, "
                   "error: %s\n", sx_status_str(sx_status));
        goto out;
    }

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PEAPS_E, &peaps_reg_data, &peaps_reg_meta, 1, NULL, NULL);
    sx_status = sxd_status_to_sx_status(sxd_status);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("ACL : Failed to get peaps data. dev_idx [%u]\n", dev_id);
        goto out;
    }

    if (peaps_reg_data.busy) {
        sxd_status = SXD_STATUS_FW_BUSY;
        sx_status = sxd_status_to_sx_status(sxd_status);
        SX_LOG_ERR("ACL : Failed to configure peaps to dev_idx [%u] FW is busy\n", dev_id);
        goto out;
    }

    peaps_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    peaps_reg_data.priority_start = min_priority;
    peaps_reg_data.priority_end = max_priority;
    peaps_reg_data.priority_inc = prio_change;
    peaps_reg_data.ct_offset = ct_offset;
    peaps_reg_data.ct_size = ct_size;

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PEAPS_E, &peaps_reg_data, &peaps_reg_meta, 1, NULL, NULL);
    sx_status = sxd_status_to_sx_status(sxd_status);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("ACL : Failed to configure peaps to dev_idx [%u]\n", 1);
        goto out;
    }

    /* Check if the FW busy before we free the SDK */
    peaps_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    for (i = 0; i < MAX_PEAPS_BUSY_CHECKS; i++) {
        sxd_status =
            sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PEAPS_E, &peaps_reg_data, &peaps_reg_meta, 1, NULL, NULL);
        sx_status = sxd_status_to_sx_status(sxd_status);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("ACL : Failed to get peaps data. dev_idx [%u]\n", dev_id);
            goto out;
        }

        if (peaps_reg_data.busy) {
            usleep(MAX_SLEEP_BEFORE_PEAPS_BUSY_CHECK);
        } else {
            break;
        }
    }

    if (peaps_reg_data.busy) {
        sxd_status = SXD_STATUS_FW_BUSY;
        sx_status = sxd_status_to_sx_status(sxd_status);
        SX_LOG_ERR("ACL : After trying to set peaps - failed to configure peaps to dev_idx [%u] FW is busy\n", dev_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __atcam_rules_duplication_insert(const sx_acl_region_id_t    region_id,
                                                    const sx_acl_rule_offset_t  offset,
                                                    const sx_atcam_key_t       *key,
                                                    kvd_linear_manager_index_t  action_set,
                                                    sx_flex_acl_rule_priority_t priority,
                                                    uint32_t                    transaction_id)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    atcam_rules_db_rule_t        *old_rule = NULL;
    atcam_api_rule_add_req_info_t old_rule_info;
    uint32_t                      num_of_dup_rules;

    SX_LOG_ENTER();

    /* Check if we have a rule with the same key in our DB */
    sx_status = atcam_rules_db_highest_prio_rules_get_by_key(region_id, key, &old_rule, NULL);
    if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
        /* Not found rule with the same rule key.
         * Go out and handle as a "normal case" of rule insertion. */
        goto out;
    }

    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get a rule with the highest prio, error: %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* Rule Duplication optimization is supported in ATCAM only */
    if (old_rule->is_atcam == FALSE) {
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Get the number of current duplicated rules to increment the counter after insertion. */
    sx_status = atcam_regions_db_atcam_dup_rules_num_get(region_id, &num_of_dup_rules);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get ATCAM num of duplicated rules in region %d DB\n", region_id);
        goto out;
    }

    /* If the new rule has a higher priority:
     * Replace the current HW rule with this new highest priority rule and store in DB the previous HW rule.
     *
     * The "replace" operation is done by editing the current HW rule with rule info (priority, action set, offset).*/
    if (priority > old_rule->priority) {
        /* Preserve old rule info, used to set in DB only after HW update. */
        SX_MEM_CLR(old_rule_info);
        old_rule_info.action_set = old_rule->action;
        old_rule_info.offset = old_rule->offset;
        old_rule_info.priority = old_rule->priority;

        /* Update DB and HW: Edit the current rule in HW and DB with the info (priority & action set) from a new rule. */
        sx_status = __update_rule_prio(region_id,
                                       old_rule->offset,
                                       priority,
                                       action_set,
                                       transaction_id);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update rule priority and action_set, err: %s\n", sx_status_str(sx_status));
            goto out;
        }

        sx_status = atcam_rules_db_change_rule_offset(region_id, old_rule->offset, offset);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed changing offsets [%u]->[%u], region [%u]",
                       old_rule->offset,
                       offset,
                       region_id);
            goto out;
        }

        /* Add the old HW rule to DB as ‘duplicated’ (DB only) */
        sx_status = atcam_rules_db_rule_allocate(region_id,
                                                 old_rule_info.offset,
                                                 old_rule_info.priority,
                                                 old_rule_info.action_set,
                                                 key,
                                                 TRUE,
                                                 &old_rule);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed when allocating new duplicated rule, offset %d, region %d\n", offset, region_id);
            goto out;
        }
    } else { /* Add the new rule to DB as a 'duplicated' rule */
        sx_status = atcam_rules_db_rule_allocate(region_id, offset, priority, action_set, key, TRUE, NULL);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed when allocating new duplicated rule, offset %d, region %d\n", offset, region_id);
            goto out;
        }
    }

    sx_status = atcam_regions_db_atcam_dup_rules_num_set(region_id, num_of_dup_rules + 1);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update ATCAM num of duplicated rules in region %d DB\n", region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __atcam_rules_duplication_delete(const sx_acl_region_id_t     region_id,
                                                    const atcam_rules_db_rule_t *p_rule,
                                                    uint32_t                     transaction_id)
{
    sx_status_t            sx_status = SX_STATUS_SUCCESS;
    atcam_rules_db_rule_t *p_rule_1 = NULL, *p_rule_2 = NULL;
    uint32_t               num_of_dup_rules;
    sx_acl_rule_offset_t   preserved_offset;

    SX_LOG_ENTER();

    /* 1. Case: Rule is the duplication (SW DB only) - remove and return SUCCESS */
    if (p_rule->is_duplicated == TRUE) {
        sx_status = atcam_rules_db_rule_deallocate(region_id, p_rule->offset);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to remove a duplicated rule with offset %d, error: %s\n", p_rule->offset,
                       sx_status_str(sx_status));
        }

        sx_status = atcam_regions_db_atcam_dup_rules_num_get(region_id, &num_of_dup_rules);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get ATCAM num of duplicated rules in region %d DB\n", region_id);
            goto out;
        }

        sx_status = atcam_regions_db_atcam_dup_rules_num_set(region_id, num_of_dup_rules - 1);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update ATCAM num of duplicated rules in region %d DB\n", region_id);
            goto out;
        }

        goto out;
    }

    /* 2. Case: Rule in CTCAM - Go out and handle as a "normal case" of rule deletion.
     *    Rule Duplication optimization is supported in ATCAM only */
    if (p_rule->is_atcam == FALSE) {
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* 3. Case: The rule is ATCAM. */
    sx_status = atcam_rules_db_highest_prio_rules_get_by_key(region_id,
                                                             &(p_rule->key_value_blocks),
                                                             &p_rule_1,
                                                             &p_rule_2);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to get a rule with the highest prio, error: %s\n", sx_status_str(sx_status));
        goto out;
    }

    /* 3.1.  Case: ATCAM and Found a duplicated rule.
     *       Replace the deleted HW rule with the next highest priority duplicated rule:
     *           - Edit the HW rule info(priority, action set) with the next highest priority duplicated rule.
     *           - Preserve the offset of the duplicated rule and remove it from DB.
     *           - Update the offset of the HW rule with the preserved duplicated rule's offset */
    if (p_rule_2 != NULL) {
        preserved_offset = p_rule_2->offset;

        sx_status = atcam_regions_db_atcam_dup_rules_num_get(region_id, &num_of_dup_rules);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get ATCAM num of duplicated rules in region %d DB\n", region_id);
            goto out;
        }

        /* Update HW: Edit current rule in HW with the info from a new higher priority rule */
        sx_status = __update_rule_prio(region_id,
                                       p_rule->offset,
                                       p_rule_2->priority,
                                       p_rule_2->action,
                                       transaction_id);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update rule priority and action_set, err: %s\n", sx_status_str(sx_status));
            goto out;
        }

        /* Delete the duplicated rule with the next highest priority from DB */
        sx_status = atcam_rules_db_rule_deallocate(region_id, preserved_offset);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed deallocating duplicated rule, offset %d, region %d\n", preserved_offset, region_id);
            goto out;
        }

        sx_status = atcam_rules_db_change_rule_offset(region_id, p_rule->offset, preserved_offset);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed changing offsets [%u]->[%u], region [%u]",
                       p_rule->offset,
                       preserved_offset,
                       region_id);
            goto out;
        }

        sx_status = atcam_regions_db_atcam_dup_rules_num_set(region_id, num_of_dup_rules - 1);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update ATCAM num of duplicated rules in region %d DB\n", region_id);
            goto out;
        }
    } else { /* 3.2. Case: ATCAM without duplication
              *       Go out and handle as a "normal case" of rule deletion */
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t __atcam_rules_prio_change(sx_acl_region_id_t          region_id,
                                      const sx_acl_rule_offset_t  offset,
                                      sx_flex_acl_rule_priority_t new_priority,
                                      kvd_linear_manager_index_t  action_set,
                                      uint32_t                    transaction_id)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    atcam_rules_db_rule_t        *p_rule = NULL, *p_rule_hw = NULL, *p_rule_next = NULL;
    atcam_api_rule_add_req_info_t preserved_rule_info, new_hw_rule_info;
    boolean_t                     is_replace_hw_rule = FALSE; /* Indicate whether need to replace between the HW and the duplicated rule */

    SX_LOG_ENTER();

    /* Get the rule that we want to update his priority */
    sx_status = atcam_rules_db_rule_get_by_offset(region_id, offset, &p_rule);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find rule %d, region %d\n", offset, region_id);
        goto out;
    }

    /* Whether ATCAM rule, check if a duplicated rule exists (SW DB only rule with the same key).
     * If a duplicated rule exists, make sure that the rule with the highest priority among all rules with the same key is configured in HW. */
    if (p_rule->is_atcam == TRUE) {
        /* Get the highest priority rules with the same key */
        sx_status = atcam_rules_db_highest_prio_rules_get_by_key(region_id,
                                                                 &p_rule->key_value_blocks,
                                                                 &p_rule_hw,
                                                                 &p_rule_next);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to get a rule with the highest prio, error: %s\n", sx_status_str(sx_status));
            goto out;
        }

        if (p_rule_hw == NULL) {
            sx_status = SX_STATUS_ERROR;
            SX_LOG_ERR("Failed to get a rule with the highest priority, error: %s\n", sx_status_str(sx_status));
            goto out;
        }

        /* Check if need to replace the current HW rule and the rule that we change his priority.
         * If need to replace the HW rule - preserve the HW rule info that we replace. This preserved rule will be added as a duplicated rule. */
        is_replace_hw_rule = FALSE;
        SX_MEM_CLR(preserved_rule_info);
        SX_MEM_CLR(new_hw_rule_info);

        if (p_rule_next != NULL) {
            /* If the rule is configured in HW and his new priority is no longer the highest
             * Replace between the current HW rule and the next rule (that now has higher priority) */
            if ((p_rule == p_rule_hw) && (new_priority < p_rule_next->priority)) {
                is_replace_hw_rule = TRUE;
                preserved_rule_info.offset = p_rule_hw->offset;
                preserved_rule_info.priority = new_priority;
                preserved_rule_info.action_set = action_set;

                new_hw_rule_info.priority = p_rule_next->priority;
                new_hw_rule_info.action_set = p_rule_next->action;
                new_hw_rule_info.offset = p_rule_next->offset;
            }
            /* If the rule is duplicated (not in HW) and his new priority is higher than the current HW rule
             * Replace between the current duplicated rule to configured in HW rule*/
            else if ((p_rule->is_duplicated) && (p_rule != p_rule_hw) && (new_priority > p_rule_hw->priority)) {
                is_replace_hw_rule = TRUE;
                preserved_rule_info.offset = p_rule_hw->offset;
                preserved_rule_info.priority = p_rule_hw->priority;
                preserved_rule_info.action_set = p_rule_hw->action;

                new_hw_rule_info.priority = new_priority;
                new_hw_rule_info.action_set = action_set;
                new_hw_rule_info.offset = p_rule->offset;
            }
        }
    }

    /* If the highest priority rule is duplicated - Replace the duplicated and the next higher priority in HW */
    if (is_replace_hw_rule) {
        /* Update rule info in HW with the info of new the highest priority rule */
        sx_status = __update_rule_prio(region_id,
                                       p_rule_hw->offset,
                                       new_hw_rule_info.priority,
                                       new_hw_rule_info.action_set,
                                       transaction_id);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update rule priority and action_set, err: %s\n", sx_status_str(sx_status));
            goto out;
        }

        /* Remove the prev duplicated rule from the DB (we need this offset ID for the HW rule) */
        sx_status = atcam_rules_db_rule_deallocate(region_id, new_hw_rule_info.offset);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to remove a duplicated rule with offset %d, error: %s\n", new_hw_rule_info.offset,
                       sx_status_str(sx_status));
        }

        sx_status = atcam_rules_db_change_rule_offset(region_id, p_rule_hw->offset, new_hw_rule_info.offset);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed changing offsets [%u]->[%u], region [%u]",
                       p_rule_hw->offset,
                       new_hw_rule_info.offset,
                       region_id);
            goto out;
        }

        /* Add the preserved HW rule to DB as a ‘duplicated’ */
        SX_MEM_CPY(preserved_rule_info.key, p_rule_hw->key_value_blocks);
        sx_status = atcam_rules_db_rule_allocate(region_id,
                                                 preserved_rule_info.offset,
                                                 preserved_rule_info.priority,
                                                 preserved_rule_info.action_set,
                                                 &preserved_rule_info.key,
                                                 TRUE,
                                                 &p_rule);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed when allocating new duplicated rule, offset %d, region %d\n",
                       preserved_rule_info.offset,
                       region_id);
            goto out;
        }
    } else {
        sx_status = __update_rule_prio(region_id,
                                       p_rule->offset,
                                       new_priority,
                                       action_set,
                                       transaction_id);
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Failed to update rule priority and action_set, err: %s\n", sx_status_str(sx_status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __handle_msg(atcam_api_rule_req_msgs_bulk_t *msgs_bulk)
{
    uint32_t                               msgs_iter = 0;
    sx_status_t                            status = SX_STATUS_SUCCESS;
    atcam_api_rule_add_req_info_t         *add_info_p = NULL;
    atcam_api_rule_delete_req_info_t      *delete_info_p = NULL;
    atcam_api_rule_update_action_info_t   *action_info_p = NULL;
    atcam_api_rule_move_req_info_t        *move_info_p = NULL;
    atcam_api_rule_update_priority_info_t *prio_info_p = NULL;
    atcam_api_rule_update_prio_info_t     *bulk_of_rules_prio_info_p = NULL;
    atcam_rules_db_rule_t                 *rule_p = NULL;
    kvd_linear_manager_index_t             action_set_idx = 0;
    sx_atcam_key_t                         key;

    SX_LOG_INF("Rule manager: handing transaction %d. region %d\n", msgs_bulk->transaction_id, msgs_bulk->region_id);
    switch (msgs_bulk->req_type) {
    case ATCAM_API_REQ_ADD_RULE_E:

        for (msgs_iter = 0; msgs_iter < msgs_bulk->num_of_msgs; msgs_iter++) {
            add_info_p = &msgs_bulk->msgs[msgs_iter].req_info.add_info;
            status = atcam_rules_manager_insert_rule(msgs_bulk->region_id,
                                                     add_info_p->offset,
                                                     &add_info_p->key,
                                                     add_info_p->action_set,
                                                     add_info_p->priority,
                                                     msgs_bulk->transaction_id,
                                                     msgs_bulk->dev_id,
                                                     FALSE,
                                                     ATCAM_INVALID_ERP_ID);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to add rule, "
                           "error: %s\n", sx_status_str(status));
                goto out;
            }
        }
        break;

    case ATCAM_API_REQ_DEL_RULE_E:
        for (msgs_iter = 0; msgs_iter < msgs_bulk->num_of_msgs; msgs_iter++) {
            delete_info_p = &msgs_bulk->msgs[msgs_iter].req_info.delete_info;
            status = atcam_rules_manager_delete_rule(msgs_bulk->region_id, delete_info_p->offset,
                                                     msgs_bulk->transaction_id, FALSE);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to delete rule, "
                           "error: %s\n", sx_status_str(status));
                goto out;
            }
        }
        break;

    case ATCAM_API_REQ_UPDATE_PRIO_E:
        for (msgs_iter = 0; msgs_iter < msgs_bulk->num_of_msgs; msgs_iter++) {
            prio_info_p = &msgs_bulk->msgs[msgs_iter].req_info.prio_info;

            status = __atcam_rules_prio_change(msgs_bulk->region_id,
                                               msgs_bulk->msgs[msgs_iter].req_info.prio_info.offset,
                                               prio_info_p->priority,
                                               msgs_bulk->msgs[msgs_iter].req_info.prio_info.action_set,
                                               msgs_bulk->transaction_id);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to update rule priority, "
                           "error: %s\n", sx_status_str(status));
                goto out;
            }
        }

        break;

    case ATCAM_API_REQ_UPDATE_RULES_PRIO_E:
        for (msgs_iter = 0; msgs_iter < msgs_bulk->num_of_msgs; msgs_iter++) {
            bulk_of_rules_prio_info_p = &msgs_bulk->msgs[msgs_iter].req_info.update_prio_info;
            status = __update_atcam_rules_prio(msgs_bulk->region_id,
                                               bulk_of_rules_prio_info_p->min_priority,
                                               bulk_of_rules_prio_info_p->max_priority,
                                               bulk_of_rules_prio_info_p->prio_change,
                                               msgs_bulk->transaction_id);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to update rule priority, "
                           "error: %s\n", sx_status_str(status));
                goto out;
            }
        }
        break;

    case ATCAM_API_REQ_UPDATE_ACTION_E:
        for (msgs_iter = 0; msgs_iter < msgs_bulk->num_of_msgs; msgs_iter++) {
            action_info_p = &msgs_bulk->msgs[msgs_iter].req_info.action_info;
            status = __update_action(msgs_bulk->region_id,
                                     action_info_p->offset,
                                     action_info_p->action_set,
                                     msgs_bulk->transaction_id);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to add rule, "
                           "error: %s\n", sx_status_str(status));
                goto out;
            }
        }
        break;

    case ATCAM_API_REQ_EDIT_RULE_E:
        for (msgs_iter = 0; msgs_iter < msgs_bulk->num_of_msgs; msgs_iter++) {
            add_info_p = &msgs_bulk->msgs[msgs_iter].req_info.add_info;
            /* To implement the edit functionality we:
             *  1. Insert the new rule with an invalid offset.
             *  2. Delete the old rule.
             *  3. Change the offset of the new rule to the correct offset (db operation only).
             */
            status = atcam_rules_manager_insert_rule(msgs_bulk->region_id,
                                                     ATCAM_INVALID_RULE_OFFSET,
                                                     &add_info_p->key,
                                                     add_info_p->action_set,
                                                     add_info_p->priority,
                                                     msgs_bulk->transaction_id,
                                                     msgs_bulk->dev_id,
                                                     FALSE,
                                                     ATCAM_INVALID_ERP_ID);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to add rule for rule edit offset [%u], error: %s\n",
                           add_info_p->offset, sx_status_str(status));
                goto out;
            }
            status = atcam_rules_manager_delete_rule(msgs_bulk->region_id, add_info_p->offset,
                                                     msgs_bulk->transaction_id, FALSE);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to delete rule for rule edit offset [%u], error: %s\n",
                           add_info_p->offset, sx_status_str(status));
                goto out;
            }
            status = atcam_rules_db_change_rule_offset(msgs_bulk->region_id,
                                                       ATCAM_INVALID_RULE_OFFSET,
                                                       add_info_p->offset);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed changing offsets for rule edit [%u]->[%u], region [%u].\n",
                           ATCAM_INVALID_RULE_OFFSET,
                           add_info_p->offset,
                           msgs_bulk->region_id);
                goto out;
            }
        }
        break;

    case ATCAM_API_REQ_MOVE_RULE_E:
        for (msgs_iter = 0; msgs_iter < msgs_bulk->num_of_msgs; msgs_iter++) {
            move_info_p = &msgs_bulk->msgs[msgs_iter].req_info.move_info;

            if (move_info_p->src_rule_exists) {
                status = atcam_rules_db_rule_get_by_offset(msgs_bulk->region_id, move_info_p->src_offset, &rule_p);
                if (status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to find rule %d, region %d for move rule\n",
                               move_info_p->src_offset, msgs_bulk->region_id);
                    goto out;
                }
                /* Preserve the old key and action index */
                action_set_idx = rule_p->action;
                memcpy(&key, &(rule_p->key_value_blocks), sizeof(key));
            }
            /* Delete the rule that currently exists in the destination offset (if needed) */
            if (move_info_p->overwrite_dst) {
                status = atcam_rules_manager_delete_rule(msgs_bulk->region_id, move_info_p->dst_offset,
                                                         msgs_bulk->transaction_id, FALSE);
                if (SX_CHECK_FAIL(status)) {
                    SX_LOG_ERR("Failed to delete rule, "
                               "error: %s\n", sx_status_str(status));
                    goto out;
                }
            }
            if (move_info_p->src_rule_exists) {
                /* If there is a need to actually change the priority of the rule*/
                if (move_info_p->change_priority) {
                    /* Delete the rule from the old location */
                    status = atcam_rules_manager_delete_rule(msgs_bulk->region_id, move_info_p->src_offset,
                                                             msgs_bulk->transaction_id, FALSE);
                    if (SX_CHECK_FAIL(status)) {
                        SX_LOG_ERR("Failed to delete rule, "
                                   "error: %s\n", sx_status_str(status));
                        goto out;
                    }
                    /* Insert the rule to the new offset */
                    status = atcam_rules_manager_insert_rule(msgs_bulk->region_id,
                                                             move_info_p->dst_offset,
                                                             &key,
                                                             action_set_idx,
                                                             move_info_p->dst_rule_priority,
                                                             msgs_bulk->transaction_id,
                                                             msgs_bulk->dev_id,
                                                             FALSE,
                                                             ATCAM_INVALID_ERP_ID);
                    if (SX_CHECK_FAIL(status)) {
                        SX_LOG_ERR("Failed to insert rule, "
                                   "error: %s\n", sx_status_str(status));
                        goto out;
                    }
                } else {
                    /* If we're here we're changing the offset only in the db records without
                     * changing the priority in the db or the hw.
                     */
                    status = atcam_rules_db_change_rule_offset(msgs_bulk->region_id,
                                                               move_info_p->src_offset,
                                                               move_info_p->dst_offset);
                    if (SX_CHECK_FAIL(status)) {
                        SX_LOG_ERR("Failed to change rule offset in db, region_id %d, offset %d, error: %s\n",
                                   msgs_bulk->region_id, move_info_p->src_offset, sx_status_str(status));
                        goto out;
                    }
                }
            }
        }
        break;

    default:
        SX_LOG_ERR("Invalid request\n");
        break;
    }

out:
    return status;
}


#ifdef ATSYNC_MODE
static
#else
sx_status_t atcam_rules_manager_handle_msg(atcam_api_rule_req_msgs_bulk_t *msgs_bulk)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    status = __handle_msg(msgs_bulk);
    return status;
}
#endif


static sx_status_t __update_erp_m_with_new_rule(sx_atcam_rule_id_t     rule_id,
                                                atcam_rules_db_rule_t *rule_ptr,
                                                uint32_t               transaction_id,
                                                boolean_t              predetermined,
                                                sx_atcam_erp_id_t      predetermined_erp_id)
{
    sx_status_t     status = SX_STATUS_SUCCESS;
    atcam_ipc_msg_t msg;

    __init_erp_msg_common_info(&msg,
                               ATCAM_REQ_ADD_RULE_E,
                               rule_id,
                               rule_ptr,
                               transaction_id,
                               predetermined,
                               predetermined_erp_id);
    status = __send_msg_to_erp_mgr(&msg);
    return status;
}

static sx_status_t __update_erp_m_with_rule_deletion(sx_atcam_rule_id_t     rule_id,
                                                     atcam_rules_db_rule_t *rule_ptr,
                                                     uint32_t               transaction_id,
                                                     boolean_t              predetermined)
{
    sx_status_t     status = SX_STATUS_SUCCESS;
    atcam_ipc_msg_t msg;

    __init_erp_msg_common_info(&msg,
                               ATCAM_REQ_DELETE_RULE_E,
                               rule_id,
                               rule_ptr,
                               transaction_id,
                               predetermined,
                               ATCAM_INVALID_ERP_ID);
    status = __send_msg_to_erp_mgr(&msg);
    return status;
}

static sx_status_t __update_erp_m_with_prio_change(sx_atcam_rule_id_t     rule_id,
                                                   atcam_rules_db_rule_t *rule_ptr,
                                                   uint32_t               old_prio,
                                                   uint32_t               transaction_id)
{
    sx_status_t     status = SX_STATUS_SUCCESS;
    atcam_ipc_msg_t msg;

    __init_erp_msg_common_info(&msg,
                               ATCAM_REQ_PRIO_CHANGE_E,
                               rule_id,
                               rule_ptr,
                               transaction_id,
                               FALSE,
                               ATCAM_INVALID_ERP_ID);
    msg.msg.command_extra_info.prio_change.old_prio = old_prio;
    status = __send_msg_to_erp_mgr(&msg);
    return status;
}

static sx_status_t __insert_rule_to_hw(atcam_rules_db_rule_t        *new_rule,
                                       boolean_t                     is_single,
                                       sx_atcam_large_entry_key_id_t large_key_id,
                                       sx_atcam_key_blocks_size_t    key_blocks_size)
{
    return atcam_sxd_wrapper_set_rule_to_hw(new_rule,
                                            DEFAULT_DEV_ID,
                                            RULE_CREATE_E,
                                            is_single,
                                            large_key_id,
                                            key_blocks_size);
}

static sx_status_t __update_rule_to_hw(atcam_rules_db_rule_t *rule_p, sx_atcam_key_blocks_size_t key_blocks_size)
{
    sx_status_t                   sx_status = SX_STATUS_SUCCESS;
    sx_atcam_large_entry_key_id_t large_key_id = LARGE_KEY_HANDLE_INVALID;
    boolean_t                     is_single = FALSE;

    if (rule_p->large_key_handle != LARGE_KEY_HANDLE_INVALID) {
        sx_status = atcam_large_key_id_get(rule_p->large_key_handle,
                                           &large_key_id,
                                           &is_single);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to get large_key_id for offset %d  rule id 0x%" PRIx64 "\n",
                rule_p->offset,
                rule_p->rule_id);
            return sx_status;
        }
    }

    return atcam_sxd_wrapper_set_rule_to_hw(rule_p,
                                            DEFAULT_DEV_ID,
                                            RULE_UPDATE_E,
                                            is_single,
                                            large_key_id,
                                            key_blocks_size);
}

static sx_status_t __delete_rule_from_hw(atcam_rules_db_rule_t        *rule,
                                         boolean_t                     is_single,
                                         sx_atcam_large_entry_key_id_t large_key_id,
                                         sx_atcam_key_blocks_size_t    key_blocks_size)
{
    return atcam_sxd_wrapper_set_rule_to_hw(rule,
                                            DEFAULT_DEV_ID,
                                            RULE_DELETE_E,
                                            is_single,
                                            large_key_id,
                                            key_blocks_size);
}

static sx_status_t __update_global_mask(sx_acl_region_id_t region_id)
{
    sx_status_t          status = SX_STATUS_SUCCESS;
    sx_atcam_mask_byte_t global_mask[ATCAM_MAX_KEY_SIZE] = {0};
    uint32_t             mask_size = ATCAM_MAX_KEY_SIZE;

    status = atcam_global_mask_get(region_id, &mask_size, global_mask);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get global mask, region %d\n", region_id);
        goto out;
    }

    status = atcam_regions_manager_region_mask_update(region_id, global_mask);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update region global mask, region %d\n", region_id);
        goto out;
    }

    SX_LOG_INF("Updated global mask for region %d\n", region_id);

out:
    SX_LOG_EXIT();
    return status;
}


static void __init_erp_msg_common_info(atcam_ipc_msg_t       *msg_p,
                                       atcam_ipc_events_e     event,
                                       sx_atcam_rule_id_t     rule_id,
                                       atcam_rules_db_rule_t *rule_ptr,
                                       uint64_t               transaction_id,
                                       boolean_t              predetermined,
                                       sx_atcam_erp_id_t      predetermined_erp_id)
{
    static uint64_t __msg_id = 0;


    memset(msg_p, 0, sizeof(*msg_p));
    msg_p->event = event;
    msg_p->transaction_id = transaction_id;
    msg_p->msg_id = __msg_id;
    msg_p->msg.rule_id = rule_id;
    msg_p->msg.rule_ptr = rule_ptr;
    msg_p->msg.command_extra_info.erp_extra_info.predetermined = predetermined;
    msg_p->msg.command_extra_info.erp_extra_info.predetermined_erp_id = predetermined_erp_id;
}

static sx_status_t __send_msg_to_erp_mgr(atcam_ipc_msg_t *msg_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;

#if ASYNC_INFRA_SUPPORTED
    /* send message */
#else
    status = atcam_erp_manager_recv_msg(msg_p);

#endif

    return status;
}

sx_status_t atcam_rules_manager_update_rm_ctcam_size(sx_atcam_key_blocks_size_t key_blocks_size,
                                                     uint32_t                   new_size,
                                                     uint32_t                   old_size)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    rm_sdk_table_type_e   resource = RM_SDK_TABLE_TYPE_INVALID_E;
    sx_access_cmd_t       rm_cmd = SX_ACCESS_CMD_NONE;
    uint32_t              rm_cnt = 0;
    rm_sdk_table_params_t params;


    SX_LOG_ENTER();

    SX_MEM_CLR(params);
    /* Get the key block size so we'll know which resource to account */
    status = get_region_rule_resource(key_blocks_size, FALSE, &resource);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ATCAM: Failed to get rule resource type for key block size %u\n", key_blocks_size);
        goto out;
    }
    if (new_size > old_size) {
        rm_cmd = SX_ACCESS_CMD_ADD;
        rm_cnt = new_size - old_size;
    } else if (new_size < old_size) {
        rm_cmd = SX_ACCESS_CMD_DELETE;
        rm_cnt = old_size - new_size;
    } else {
        goto out; /* if equal return success */
    }

    params.attrs.acl_attr.is_ctcam = TRUE;
    /* Makes sure RM allows the allocation */
    status = rm_allocate_entries_check(resource, rm_cmd, rm_cnt, &params);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(status, "ATCAM : RM Denied check to %s %u ctcam rules with size %u\n",
                                 (rm_cmd == SX_ACCESS_CMD_ADD) ? "Allocate" : "Free", rm_cnt, key_blocks_size);
        goto out;
    }

    status = rm_allocate_entries_update(resource, rm_cmd, rm_cnt,  &params);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ATCAM : RM Denied update to %s %u ctcam rules with key blocks size %u\n",
                   (rm_cmd == SX_ACCESS_CMD_ADD) ? "Allocate" : "Free", rm_cnt, key_blocks_size);
    }

out:
    SX_LOG_EXIT();
    return status;
}


static sx_status_t __update_rm_with_rules(sx_acl_region_id_t region_id,
                                          uint32_t           rules_count,
                                          boolean_t          is_atcam,
                                          boolean_t          is_add)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    rm_sdk_table_type_e        resource = RM_SDK_TABLE_TYPE_INVALID_E;
    sx_atcam_key_blocks_size_t key_blocks_size = 0;


    SX_LOG_ENTER();

    /* Get the key block size so we'll know which resource to account */
    status = atcam_regions_db_key_blocks_size_get(region_id, &key_blocks_size);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "Failed to get region block size for region %d when updating rules resource manager\n",
            region_id);
        goto out;
    }

    /* Get the resource to account */
    status = get_region_rule_resource(key_blocks_size, is_atcam, &resource);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ATCAM: Failed to get region's rule resource type for region id [%u]\n", region_id);
        goto out;
    }

    /* Now it's time to update the resource in the rm */
    status = rm_entries_set(resource, (is_add) ? SX_ACCESS_CMD_ADD : SX_ACCESS_CMD_DELETE, rules_count, NULL);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ATCAM: RM Failed to %s %u rules to resource %s for region [%u]\n",
                   (is_add) ? "add" : "remove", rules_count, SX_RESOURCE_MSG(resource), region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}


static sx_status_t __initialize_rm_sdk_table(rm_sdk_table_type_e resource,
                                             uint32_t            table_size_min,
                                             uint32_t            table_size_max)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    rm_resource_global.rm_sdk_tables_db[resource].is_initialized = TRUE;
    rm_resource_global.rm_sdk_tables_db[resource].table_size_min = table_size_min;
    rm_resource_global.rm_sdk_tables_db[resource].table_size_max = table_size_max;
    status = rm_sdk_table_init_resource(resource);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to init RM for %s\n", SX_RESOURCE_MSG(resource));
    }
    return status;
}

static sx_status_t __init_tcam_resources()
{
    sx_status_t status = SX_STATUS_SUCCESS;
    sx_status_t rb_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    status = __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_A_TCAM_ONE_KEY_BLOCK_E, 0, 0);
    if (SX_CHECK_FAIL(status)) {
        goto out;
    }
    status = __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_A_TCAM_TWO_KEYS_BLOCK_E, 0, 0);
    if (SX_CHECK_FAIL(status)) {
        goto rm_one_atcam_key_block_rb;
    }
    status = __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_A_TCAM_FOUR_KEYS_BLOCK_E, 0, 0);
    if (SX_CHECK_FAIL(status)) {
        goto rm_two_atcam_keys_block_rb;
    }
    status = __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_A_TCAM_SIX_KEYS_BLOCK_E, 0, 0);
    if (SX_CHECK_FAIL(status)) {
        goto rm_four_atcam_keys_block_rb;
    }
    status = __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_C_TCAM_TWO_KEYS_BLOCK_E, 0, 0);
    if (SX_CHECK_FAIL(status)) {
        goto rm_six_atcam_keys_block_rb;
    }
    status = __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_C_TCAM_FOUR_KEYS_BLOCK_E, 0, 0);
    if (SX_CHECK_FAIL(status)) {
        goto rm_two_ctcam_keys_block_rb;
    }
    status = __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_C_TCAM_SIX_KEYS_BLOCK_E, 0, 0);
    if (SX_CHECK_FAIL(status)) {
        goto rm_four_ctcam_keys_block_rb;
    }
    goto out;

rm_four_ctcam_keys_block_rb:
    rb_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_C_TCAM_FOUR_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to rollback deinit c-tcam four key blocks acl rules in rm\n");
    }
rm_two_ctcam_keys_block_rb:
    rb_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_C_TCAM_TWO_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to rollback deinit c-tcam two key blocks acl rules in rm\n");
    }
rm_six_atcam_keys_block_rb:
    rb_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_A_TCAM_SIX_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to rollback deinit a-tcam six key blocks acl rules in rm\n");
    }
rm_four_atcam_keys_block_rb:
    rb_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_A_TCAM_FOUR_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to rollback deinit a-tcam four key blocks acl rules in rm\n");
    }
rm_two_atcam_keys_block_rb:
    rb_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_A_TCAM_TWO_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to rollback deinit a-tcam two key blocks acl rules in rm\n");
    }
rm_one_atcam_key_block_rb:
    rb_status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_A_TCAM_ONE_KEY_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG_ERR("Failed to rollback deinit a-tcam one key block acl rules in rm\n");
    }
out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __deinit_tcam_resources()
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_C_TCAM_SIX_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to deinit c-tcam six key blocks acl rules in rm\n");
    }
    status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_C_TCAM_FOUR_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to deinit c-tcam four key blocks acl rules in rm\n");
    }
    status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_C_TCAM_TWO_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to deinit c-tcam two key blocks acl rules in rm\n");
    }
    status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_A_TCAM_SIX_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to deinit a-tcam six key blocks acl rules in rm\n");
    }
    status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_A_TCAM_FOUR_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to deinit a-tcam four key blocks acl rules in rm\n");
    }
    status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_A_TCAM_TWO_KEYS_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to deinit a-tcam two key blocks acl rules in rm\n");
    }
    status = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_A_TCAM_ONE_KEY_BLOCK_E, TRUE);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to deinit a-tcam one key block acl rules in rm\n");
    }

    SX_LOG_EXIT();
    return status;
}
