/*
 * Copyright (c) 2017-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "sx/sdk/sx_status_convertor.h"
#include "atcam_erps_recalc.h"
#include "complib/sx_log.h"
#include "complib/cl_map.h"
#include "complib/cl_qpool.h"
#include <complib/cl_dbg.h>
#include "complib/cl_fleximap.h"
#include "atcam/atcam_rules_manager/atcam_rules_db.h"
#include "atcam/atcam_rules_manager/atcam_rules_manager.h"
#include "atcam/atcam_regions_manager/atcam_regions_db.h"
#include "atcam/atcam_erps_manager/atcam_erps_selector.h"
#include "atcam/atcam_erps_manager/atcam_erps_manager.h"
#include "atcam/atcam_erps_manager/atcam_erps_memory_manager.h"
#include "atcam/atcam_regions_manager/atcam_regions_manager.h"
#include "resource_manager/resource_manager_hw_table.h"
#include "sx/utils/fib_hash.h"
#include "sx/utils/debug_cmd.h"
#include "resource_manager/resource_manager_sdk_table.h"

/************************************************
 *  Global variables
 ***********************************************/
/************************************************
 *  Local definitions
 ***********************************************/

#define REGION_MASKS_POOL_MIN_SIZE  (16)
#define REGION_MASKS_POOL_GROW_SIZE (16)
#define REGION_MASKS_POOL_MAX_SIZE  (16384)
#define REGIONS_POOL_GROW_SIZE      (4)
/* These limits are used to decide what is the step size of the optimization algorithm when adding alternative masks.
 * Step size determines how we iterate over each mask while creating alternative masks. step sizes are 1 bit, 4 bit and byte.
 * As we decrease the step size we increase the amount of possible alternative masks we can create.
 * The numbers defined below are a calculation of the amount original masks squared times the amount of relevant bits
 * We adjust the step size to make sure the algorithm runs in reasonable time.
 * The higher the result of the above calculation the bigger the step size.
 */
#define STEP_SIZE_UPPER_LIMIT     (50000)
#define STEP_SIZE_MID_RANGE_LIMIT (25000)
/* We'll consider doing an optimization only if the number of erps in a region is above this value. */
#define MIN_ERPS_NEEDED_FOR_RECALC (5)
/* The maximum number of rules to move during a single optimization step */
#define MAX_RULES_PER_ITERATION (500)
/* if the ERP count reached this threshold as a result of rule insertion we trigger a full optimization for that region */
#define ERP_THRESHOLD_TO_TRIGGER (12)
/* enough time to perform a complete cache wipe before deleting rules - 200 usec */
#define TIME_FOR_CACHE_WIPE (200)
/* Thresholds for setting how many rules are moved from the old region to the optimized region at a time
 * If more than 90% of the KVD is utilized we move one rule at a time
 * If 60% - 90% is utilized we move 100 rules at a time
 * If less than 60% is utilized we move 500 rules at a time
 * The values are in 0.01 percent
 */
#define RULES_PER_ITERATION_THRESHOLD_MAX (900)
#define RULES_PER_ITERATION_THRESHOLD_MIN (600)

#define REGION_STATE_INITIAL_OR_DONE(state)              \
    ((state == RECALC_REGION_STATE_INITIAL) ||           \
     (state == RECALC_REGION_STATE_OPTIMIZATION_DONE) || \
     (state == RECALC_REGION_STATE_OPTIMIZATION_ERROR))

typedef enum {
    RECALC_REGION_STATE_INITIAL                     = 0,
    RECALC_REGION_STATE_OPTIMIZATION_NEEDED         = 1,
    RECALC_REGION_STATE_SHADOW_REGION_CREATED       = 2,
    RECALC_REGION_STATE_ATCAM_TO_SHADOW_IN_PROGRESS = 3,
    RECALC_REGION_STATE_ATCAM_TO_SHADOW_DONE        = 4,
    RECALC_REGION_STATE_ATCAM_TO_CTCAM_IN_PROGRESS  = 5,
    RECALC_REGION_STATE_ATCAM_TO_CTCAM_DONE         = 6,
    RECALC_REGION_STATE_NEW_ERPS_CREATED            = 7,
    RECALC_REGION_STATE_SHADOW_TO_ATCAM_IN_PROGRESS = 8,
    RECALC_REGION_STATE_SHADOW_TO_ATCAM_DONE        = 9,
    RECALC_REGION_STATE_SHADOW_REGION_REMOVED       = 10,
    RECALC_REGION_STATE_OPTIMIZATION_DONE           = 11,
    RECALC_REGION_STATE_OPTIMIZATION_ERROR          = 12,
} atcam_erps_recalc_region_state_e;


/* This structure is used to store the information about the state of a specific region as it iterates through the
 * operations needed to complete the erp recalculation.
 */
typedef struct {
    sx_atcam_region_id_t             region_id;     /* The region id this context */
    atcam_erps_recalc_region_state_e state;         /* The state of optimization this region is currently in */
    cl_list_item_t                  *list_iter;     /* Stores the current rule iterator in a list */
    cl_fmap_item_t                  *map_iter;      /* Stores the current mask iterator in a map */
    uint32_t                         erp_idx;       /* Stores the current erp_id iterator */
    uint32_t                         iter_count;    /* The number of iteration performed so far */
    uint32_t                         iter_max;      /* The maximum number of iteration to perform */
    boolean_t                        step_done;     /* Indicates if the current step (going over all the rules) is done */
} atcam_erps_recalc_region_context_t;

/* Used to store a mask along with the rules that are delta compatible the with this mask.
 */
typedef struct {
    cl_pool_item_t      cl_pool_item;
    cl_fmap_item_t      fmap_item;
    cl_fmap_item_t      fmap_temp_item;
    uint32_t            rule_count;
    uint32_t            delta_comp_count;
    sx_atcam_key_mask_t mask;
    cl_qlist_t          rules_list;
} atcam_erps_recalc_mask_entry_t;

typedef struct {
    cl_pool_item_t         cl_pool_item;
    cl_list_item_t         cl_list_item;
    atcam_rules_db_rule_t *rule;
} atcam_erps_recalc_rule_entry_t;

/* NOTE: The masks_fmap will map all the masks that exists in the region and will not be changed after it's created.
 * masks_temp_fmap will be initially identical to masks_fmap, however, during the processing the masks with the most
 * rules will be removed from this map one by one.
 */
typedef struct {
    boolean_t                       valid;
    sx_atcam_region_id_t            region_id;
    sx_atcam_region_id_t            shadow_region_id;
    cl_qpool_t                      masks_pool;
    cl_fmap_t                       masks_fmap;
    cl_fmap_t                       masks_temp_fmap; /* Used to store masks temporarily in the optimization process */
    cl_qpool_t                      rules_pool;
    uint32_t                        erp_num;
    sx_atcam_erp_id_t               erp_ids[SX_ATCAM_ERPS_PER_REGION];
    atcam_erps_recalc_mask_entry_t *erp_entries[SX_ATCAM_ERPS_PER_REGION];
} atcam_erps_recalc_masks_db_t;

/* This struct will be used to store info about the region only for iteration purposes - if it needs to be optimized,
 * the last time it was optimized etc.
 */
typedef struct {
    sx_atcam_region_id_t             region_id;
    boolean_t                        allocated;            /* Indicate if the current region is allocated */
    cl_list_item_t                   cl_list_item;         /* Used to go over the list of regions */
    atcam_erps_recalc_region_state_e state;                /* The current state of processing this region */
    boolean_t                        rules_changed;        /* Indicator if the rules in the region have changed */
    uint64_t                         rules_changed_cycle;  /* Indicator on which cycle there was a change in a region's rule */
} atcam_erps_recalc_region_list_entry_t;

/* This is the db struct that will be used to store info about all the region for iteration purposes only.*/
typedef struct {
    atcam_erps_recalc_region_list_entry_t *regions_array;  /* Will hold the actual memory for the region iteration */
    uint32_t                               regions_num;    /* The actual size of regions array (both allocated and unallocated regions)*/
    cl_qlist_t                             regions_list;   /* Region list of the *allocated regions*/
} atcam_erps_recalc_regions_iter_db_t;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static boolean_t g_initialized = FALSE;
/* Global parameter controlling if the optimization is enabled */
static boolean_t                     g_optimization_enabled = TRUE;
static atcam_shadow_region_create_cb shadow_create_cb = NULL;
static atcam_shadow_region_remove_cb shadow_remove_cb = NULL;
/* The following counter counts the number of times we're examined all the regions for optimization. */
static uint64_t completed_cycles_count = 0;
/* The following will be used to iterate over the regions and examine if the need to be optimized */
static atcam_erps_recalc_regions_iter_db_t regions_iter_db;
/* The following keeps information about the current region we're processing */
static atcam_erps_recalc_region_list_entry_t *current_region_p;
static atcam_erps_recalc_masks_db_t           current_region_mask_db;
static atcam_erps_recalc_region_context_t     current_region_context;
/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/
static cl_status_t __atcam_erps_recalc_mask_pool_item_init(void *const             p_object,
                                                           void                   *context,
                                                           cl_pool_item_t ** const pp_pool_item)
{
    UNUSED_PARAM(context);
    atcam_erps_recalc_mask_entry_t *entry = (atcam_erps_recalc_mask_entry_t*)p_object;

    entry->rule_count = 0;
    entry->delta_comp_count = 0;
    SX_MEM_CLR(entry->mask);
    cl_qlist_init(&entry->rules_list);
    *pp_pool_item = &(entry->cl_pool_item);
    return CL_SUCCESS;
}

static int __atcam_erps_recalc_mask_cmpr(const void *const p_key1, const void *const p_key2)
{
    const sx_atcam_mask_byte_t *mask1 = p_key1;
    const sx_atcam_mask_byte_t *mask2 = p_key2;

    CL_ASSERT(NULL != mask1);
    CL_ASSERT(NULL != mask2);

    return memcmp(mask1, mask2, ATCAM_MAX_KEY_SIZE);
}

static sx_status_t __atcam_erps_recalc_init_masks_db(const sx_atcam_region_id_t    region_id,
                                                     atcam_erps_recalc_masks_db_t *masks_db)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    cl_status_t cl_status = CL_SUCCESS;
    uint32_t    ctcam_rules_num = 0, atcam_rules_num = 0, atcam_duplicated_rules_num = 0, rules_count = 0;


    SX_LOG_ENTER();

    /* Clear the db entry before using it */
    SX_MEM_CLR_P(masks_db);

    sx_status = atcam_regions_db_ctcam_rules_num_get(region_id, &ctcam_rules_num);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while getting ctcam rules count for region's [%u] erp recalculation\n", region_id);
        goto out;
    }
    sx_status = atcam_regions_db_atcam_rules_num_get(region_id, &atcam_rules_num);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while getting atcam rules count for region's [%u] erp recalculation\n", region_id);
        goto out;
    }

    sx_status = atcam_regions_db_atcam_dup_rules_num_get(region_id, &atcam_duplicated_rules_num);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while getting ATCAM duplicated rules count for region's [%u] erp recalculation\n",
                   region_id);
        goto out;
    }

    rules_count = ctcam_rules_num + atcam_rules_num + atcam_duplicated_rules_num;

    /* Initialize the pool the will be used to store all the masks we have in the region */
    cl_status = CL_QPOOL_INIT(&masks_db->masks_pool,
                              REGION_MASKS_POOL_MIN_SIZE,
                              REGION_MASKS_POOL_MAX_SIZE,
                              REGION_MASKS_POOL_GROW_SIZE,
                              sizeof(atcam_erps_recalc_mask_entry_t),
                              __atcam_erps_recalc_mask_pool_item_init,
                              NULL,
                              NULL);
    if (SX_UTILS_CHECK_FAIL(cl_status)) {
        SX_LOG_ERR("Failed to init region [%u] pool for erp calculation. err: %s.\n", region_id,
                   CL_STATUS_MSG(cl_status));
        sx_status = cl_status_to_sx_status(cl_status);
        goto out;
    }
    cl_status = CL_QPOOL_INIT(&masks_db->rules_pool,
                              rules_count,
                              rules_count,
                              rules_count,
                              sizeof(atcam_erps_recalc_rule_entry_t),
                              NULL,
                              NULL,
                              NULL);
    if (SX_UTILS_CHECK_FAIL(cl_status)) {
        CL_QPOOL_DESTROY(&masks_db->masks_pool);
        SX_LOG_ERR("Failed to init rule [%u] pool for erp calculation. err: %s.\n", region_id,
                   CL_STATUS_MSG(cl_status));
        sx_status = cl_status_to_sx_status(cl_status);
        goto out;
    }
    /* Initialize the map used to find a mask */
    cl_fmap_init(&(masks_db->masks_fmap), __atcam_erps_recalc_mask_cmpr);
    /* Create an additional map that it a working map that will be used to calculate optimized erps.
     * Masks will be removed by the algorithm as it's going along. */
    cl_fmap_init(&(masks_db->masks_temp_fmap), __atcam_erps_recalc_mask_cmpr);

    masks_db->region_id = region_id;
    masks_db->shadow_region_id = SX_ATCAM_INVALID_REGION_ID;
    masks_db->valid = TRUE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __atcam_erps_recalc_deinit_masks_db(atcam_erps_recalc_masks_db_t* masks_db)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    const cl_fmap_item_t           *map_item = NULL, *map_end = NULL;
    const cl_list_item_t           *list_item = NULL, *list_end = NULL;
    atcam_erps_recalc_mask_entry_t *mask_entry = NULL;
    atcam_erps_recalc_rule_entry_t *rule_entry = NULL;

    SX_LOG_ENTER();

    map_item = cl_fmap_head(&masks_db->masks_fmap);
    map_end = cl_fmap_end(&masks_db->masks_fmap);

    /* Destroy all the entries in the mask pool */
    while (map_item != map_end) {
        mask_entry = PARENT_STRUCT(map_item, atcam_erps_recalc_mask_entry_t, fmap_item);
        /* Go to the next entry */
        map_item = cl_fmap_next(map_item);
        /* For each map destroy the rules that are a part of it */
        list_item = cl_qlist_head(&mask_entry->rules_list);
        list_end = cl_qlist_end(&mask_entry->rules_list);
        while (list_item != list_end) {
            rule_entry = PARENT_STRUCT(list_item, atcam_erps_recalc_rule_entry_t, cl_list_item);
            list_item = cl_qlist_next(list_item);
            cl_qpool_put(&masks_db->rules_pool, &rule_entry->cl_pool_item);
        }
        cl_fmap_remove_item(&masks_db->masks_fmap, &mask_entry->fmap_item);
        cl_qpool_put(&masks_db->masks_pool, &mask_entry->cl_pool_item);
    }

    CL_QPOOL_DESTROY(&masks_db->masks_pool);
    CL_QPOOL_DESTROY(&masks_db->rules_pool);

    masks_db->region_id = SX_ATCAM_INVALID_REGION_ID;
    masks_db->shadow_region_id = SX_ATCAM_INVALID_REGION_ID;
    masks_db->valid = FALSE;

    SX_LOG_EXIT();
    return sx_status;
}


static sx_status_t __atcam_erps_recalc_insert_rule_mask(atcam_erps_recalc_masks_db_t *masks_db,
                                                        const sx_atcam_mask_byte_t   *mask,
                                                        atcam_rules_db_rule_t        *rule)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    cl_fmap_item_t                 *map_item = NULL;
    atcam_erps_recalc_mask_entry_t *mask_entry = NULL;
    atcam_erps_recalc_rule_entry_t *rule_entry = NULL;

    SX_LOG_ENTER();

    /* Check if the mask already exists in the DB */
    map_item = cl_fmap_get(&(masks_db->masks_fmap), mask);
    if (map_item == cl_fmap_end(&(masks_db->masks_fmap))) {
        /* If the mask does not exist in the fmap create it from the pool */
        mask_entry = (atcam_erps_recalc_mask_entry_t*)cl_qpool_get(&(masks_db->masks_pool));
        if (mask_entry == NULL) {
            SX_LOG_ERR("Error when allocating new mask from pool for erp recalculation\n");
            sx_status = SX_STATUS_MEMORY_ERROR;
            goto out;
        }
        /* Copy the mask into the entry */
        SX_MEM_CPY_BUF(mask_entry->mask.flex_mask_blocks, mask, ATCAM_MAX_KEY_SIZE);
        /* Insert the mask into the fmap */
        cl_fmap_insert(&(masks_db->masks_fmap), mask_entry->mask.flex_mask_blocks, &mask_entry->fmap_item);
        /* Also add the mask to the temporary map that will be used to process the optimal mask selection */
        cl_fmap_insert(&(masks_db->masks_temp_fmap), mask_entry->mask.flex_mask_blocks, &mask_entry->fmap_temp_item);
    } else {
        mask_entry = PARENT_STRUCT(map_item, atcam_erps_recalc_mask_entry_t, fmap_item);
    }
    /* Check if the rule was added as a result of rule insertion
     * or as part of the optimization process as an alternative mask for which a rule is NULL */
    if (rule != NULL) {
        /* Increase the counter on this item */
        mask_entry->rule_count++;

        /* Get a pool entry for the rule */
        rule_entry = (atcam_erps_recalc_rule_entry_t*)cl_qpool_get(&(masks_db->rules_pool));
        if (rule_entry == NULL) {
            SX_LOG_ERR("Error when allocating new rule from pool for erp recalculation\n");
            sx_status = SX_STATUS_MEMORY_ERROR;
            goto out;
            /* No rollback */
        }
        /* Insert the rule to the list of rules for this mask */
        rule_entry->rule = rule;
        cl_qlist_insert_tail(&mask_entry->rules_list, &rule_entry->cl_list_item);
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __atcam_erps_recalc_calculate_delta_compatible(const uint32_t                      blocks_cnt,
                                                                  const atcam_erps_recalc_masks_db_t *masks_db,
                                                                  atcam_erps_recalc_mask_entry_t    **max_count_entry)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    const cl_fmap_item_t           *erp_iter = NULL, *erp_end = NULL;
    atcam_erps_recalc_mask_entry_t *erp_mask_entry = NULL;
    const cl_fmap_item_t           *rule_iter = NULL, *rule_end = NULL;
    atcam_erps_recalc_mask_entry_t *rule_mask_entry = NULL;
    uint32_t                        max_count = 0;

    *max_count_entry = NULL;

    SX_LOG_ENTER();

    if (!cl_is_fmap_empty(&masks_db->masks_temp_fmap)) {
        erp_iter = cl_fmap_head(&masks_db->masks_temp_fmap);
        erp_end = cl_fmap_end(&masks_db->masks_temp_fmap);

        while (erp_iter != erp_end) {
            erp_mask_entry = PARENT_STRUCT(erp_iter, atcam_erps_recalc_mask_entry_t, fmap_temp_item);
            rule_iter = cl_fmap_head(&masks_db->masks_temp_fmap);
            rule_end = cl_fmap_end(&masks_db->masks_temp_fmap);

            erp_mask_entry->delta_comp_count = 0;

            while (rule_iter != rule_end) {
                rule_mask_entry = PARENT_STRUCT(rule_iter, atcam_erps_recalc_mask_entry_t, fmap_temp_item);
                /* Check if the masks are delta compatible. If so add to the count */
                if ((rule_mask_entry->rule_count > 0)
                    && atcam_erps_selector_are_masks_delta_eq(blocks_cnt,
                                                              erp_mask_entry->mask.flex_mask_blocks,
                                                              rule_mask_entry->mask.flex_mask_blocks,
                                                              NULL, NULL)) {
                    erp_mask_entry->delta_comp_count += rule_mask_entry->rule_count;
                }
                rule_iter = cl_fmap_next(rule_iter);
            }
            /* Return the entry that has the maximum number of delta compatible rules */
            if (erp_mask_entry->delta_comp_count >= max_count) {
                max_count = erp_mask_entry->delta_comp_count;
                *max_count_entry = erp_mask_entry;
            }
            erp_iter = cl_fmap_next(erp_iter);
        }
    }

    SX_LOG_EXIT();
    return sx_status;
}

static void __atcam_erps_recalc_remove_mask_and_compatible(atcam_erps_recalc_masks_db_t   *masks_db,
                                                           atcam_erps_recalc_mask_entry_t *erp_mask_entry)
{
    uint32_t                        blocks_cnt = 0;
    const cl_fmap_item_t           *rule_iter = NULL, *rule_end = NULL;
    atcam_erps_recalc_mask_entry_t *rule_mask_entry = NULL;

    rule_iter = cl_fmap_head(&masks_db->masks_temp_fmap);
    rule_end = cl_fmap_end(&masks_db->masks_temp_fmap);

    /* Go over all the masks and remove the given mask and its rules.
     * For compatible masks, just remove the rules from the mask but don't remove the mask itself.
     * The compatible mask can still be a good ERP candidate for other masks.
     * Note: It is assumed here that the given mask will be removed by this loop as well.
     */
    while (rule_iter != rule_end) {
        rule_mask_entry = PARENT_STRUCT(rule_iter, atcam_erps_recalc_mask_entry_t, fmap_temp_item);
        /* Go to the next entry */
        rule_iter = cl_fmap_next(rule_iter);
        /* Check if the masks are delta compatible.*/
        if (atcam_erps_selector_are_masks_delta_eq(blocks_cnt,
                                                   erp_mask_entry->mask.flex_mask_blocks,
                                                   rule_mask_entry->mask.flex_mask_blocks,
                                                   NULL, NULL)) {
            if (erp_mask_entry != rule_mask_entry) {
                /* Add to the list the rules of the compatible mask.*/
                cl_qlist_insert_list_tail(&erp_mask_entry->rules_list, &rule_mask_entry->rules_list);
                rule_mask_entry->rule_count = 0;
            } else {
                /* Remove the given mask from the list of available masks */
                cl_fmap_remove_item(&masks_db->masks_temp_fmap, &rule_mask_entry->fmap_temp_item);
            }
        }
    }

    SX_LOG_EXIT();
    return;
}


static sx_status_t __atcam_erps_recalc_check_bad_collision(atcam_erps_recalc_mask_entry_t **erp_entries,
                                                           const uint32_t                   erp_num)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    const cl_list_item_t           *list_iter = NULL, *list_end = NULL;
    cl_map_t                        collision_map;
    cl_status_t                     cl_status = CL_SUCCESS;
    atcam_rules_db_rule_t          *rule = NULL;
    atcam_erps_recalc_rule_entry_t *rule_entry = NULL;
    sx_atcam_key_value_t            res_key_value;
    uint32_t                        i = 0;
    uint64_t                        hash_value = 0;

    SX_MEM_CLR(res_key_value);

    for (i = 0; i < erp_num; i++) {
        /* Create a new collision map for each erp */
        SX_MEM_CLR(collision_map);
        cl_status = cl_map_init(&collision_map, cl_qlist_count(&erp_entries[i]->rules_list));
        if (SX_UTILS_CHECK_FAIL(cl_status)) {
            SX_LOG_ERR("Failed to create collision map for erp recalculation. err: %s.\n", CL_STATUS_MSG(cl_status));
            sx_status = cl_status_to_sx_status(cl_status);
            goto out;
        }
        /* Go over all the rules and add their erp masked hash to the collision DB */
        list_iter = cl_qlist_head(&(erp_entries[i]->rules_list));
        list_end = cl_qlist_end(&(erp_entries[i]->rules_list));
        while (list_iter != list_end) {
            rule_entry = PARENT_STRUCT(list_iter, atcam_erps_recalc_rule_entry_t, cl_list_item);
            rule = rule_entry->rule;

            /* Get the rule after the erp's mask */
            sx_status = atcam_utils_intersect_val_n_mask(
                (const sx_atcam_key_value_t*)rule->key_value_blocks.flex_value_blocks,
                &erp_entries[i]->mask,
                &res_key_value);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to intersect value for erp recalculation\n");
                goto clear_map;
            }
            hash_value = fib_hash_add64(0, &res_key_value, sizeof(res_key_value), 64);
            /* If this rule already exists (after the erp mask) we have a bad collision */
            if (cl_map_get(&collision_map, hash_value) != cl_map_end(&collision_map)) {
                sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
                goto clear_map;
            }
            if (cl_map_insert(&collision_map, hash_value, rule) == NULL) {
                SX_LOG_ERR("Out of memory for erp recalculation\n");
                sx_status = SX_STATUS_NO_MEMORY;
                goto clear_map;
            }
            list_iter = cl_qlist_next(list_iter);
        }
        cl_map_remove_all(&collision_map);
        cl_map_destroy(&collision_map);
    }
    goto out;

clear_map:
    cl_map_remove_all(&collision_map);
    cl_map_destroy(&collision_map);
out:
    return sx_status;
}

sx_status_t __atcam_erps_recalc_add_alternative_masks(atcam_erps_recalc_masks_db_t *masks_db, uint32_t blocks_cnt)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    atcam_erps_recalc_mask_entry_t *erp_mask_entry = NULL;
    sx_atcam_mask_byte_t            temp_byte1 = 0;
    sx_atcam_mask_byte_t            temp_byte2 = 0;
    const cl_fmap_item_t           *masks_iter = NULL, *masks_iter_end = NULL;
    sx_atcam_key_mask_t             masks_intersection;
    sx_atcam_key_mask_t             masks_union;
    sx_atcam_key_mask_t             mask_entry;
    sx_atcam_key_mask_t             curr_relevant_bits;
    sx_atcam_key_mask_t             relevant_bits_mask;
    uint64_t                        difficulty_factor = 0;
    uint32_t                        relevant_bits_count = 0;
    uint8_t                         byte = 0;
    uint8_t                         i = 0;
    uint8_t                         step_size = 1;
    uint8_t                         mask_start = 0, mask_size = 1;

    SX_LOG_ENTER();

    SX_MEM_SET(masks_intersection, 0xFF);
    SX_MEM_CLR(curr_relevant_bits);
    SX_MEM_CLR(masks_union);
    SX_MEM_CLR(mask_entry);


    /* mask pool iterators */
    masks_iter = cl_fmap_head(&masks_db->masks_fmap);
    masks_iter_end = cl_fmap_end(&masks_db->masks_fmap);
    atcam_utils_blocks_location_get(blocks_cnt, &mask_start, &mask_size);

    /* we iterate over all original masks to create the relevant bits mask,
     * the relevant bits mask is constructed using a series of binary operations, as follows:
     * an intersection of all masks creates a mask containing only bits that are on in every mask, therefore are irrelevant
     * a union of all the masks creates a mask containing all the bits that are on even once in some mask
     * a XOR of the above mentioned masks weeds out only the bits that are on in some masks but not all
     * that way we know that zeroing out those bits might create a mask that is delta compatible with more masks
     */
    while (masks_iter != masks_iter_end) {
        erp_mask_entry = PARENT_STRUCT(masks_iter, atcam_erps_recalc_mask_entry_t, fmap_item);
        atcam_utils_intersect_masks(&erp_mask_entry->mask, &masks_intersection, &masks_intersection);
        atcam_utils_unite_masks(&erp_mask_entry->mask, &masks_union);
        masks_iter = cl_fmap_next(masks_iter);
    }

    /* calculate the relevant bits mask using the intersection and union of all masks */
    atcam_utils_xor_masks(&masks_intersection, &masks_union, &relevant_bits_mask);

    /* counts the amount of '1' bits in the relevant mask in order to decide the algorithm step size
     * the algorithm's step size dictates how big are the jumps we take when iterating over each mask while creating alternative masks
     * the step size can be: 1 bit, 4 bits or 8 bits (1 byte)
     * step size is based on the amount of relevant bits because more relevant bits lead to more alternative masks and longer run-time
     */
    for (byte = mask_start; byte < mask_start + mask_size; byte++) {
        relevant_bits_count += __builtin_popcount(relevant_bits_mask.flex_mask_blocks[byte]);
    }

    /* Make a decision about the step size based on the relevant bits count and original masks.
     * The difficulty factor predicts how long the runtime of the algorithm will be based
     * on the amount of original masks and the amount of relevant bits
     * As those numbers get higher, the algorithm runs exponentially slower. So, adjusting the step
     * size will balance out the number of alternative masks added and adjust the algorithm
     * to the anticipated load.
     * default step size is 1 bit
     */
    difficulty_factor = relevant_bits_count * cl_fmap_count(&masks_db->masks_fmap) * cl_fmap_count(
        &masks_db->masks_fmap);
    if (difficulty_factor > STEP_SIZE_UPPER_LIMIT) {
        step_size = 8;
    } else if (difficulty_factor > STEP_SIZE_MID_RANGE_LIMIT) {
        step_size = 4;
    }

    /* reset the mask pool iterator */
    masks_iter = cl_fmap_head(&masks_db->masks_fmap);

    /* iterate over the masks and create alternative masks based on them */
    while (masks_iter != masks_iter_end) {
        erp_mask_entry = PARENT_STRUCT(masks_iter, atcam_erps_recalc_mask_entry_t, fmap_item);
        /* makes sure we iterate only over original masks, because we add alternative masks into the pool
         * we check if the mask has rules associated with it because otherwise,
         * if the rule_count is zero it means that the mask is an alternative mask and there's no need to check it
         *  */
        if (erp_mask_entry->rule_count == 0) {
            masks_iter = cl_fmap_next(masks_iter);
            continue;
        }
        /* create a mask containing only relevant bits in the current mask
         * that is we intersect the relevant bits mask with the current mask
         * the result of this operation is a mask containing only relevant bits that are present in the current mask
         * we use this mask to indicate which bits we should zero out
         * this way we create alternative masks that have a chance to be chosen by the recalculation algorithm later on
         */
        atcam_utils_intersect_masks(&relevant_bits_mask, &(erp_mask_entry->mask), &curr_relevant_bits);

        /* copying the mask to a temporary buffer so we can manipulate the mask without affecting the database */
        SX_MEM_CPY(mask_entry, erp_mask_entry->mask);

        /* iterate over the masks' bytes creating alternative masks by zeroing out bits */
        for (byte = mask_start; byte < mask_start + mask_size - 1; byte++) {
            if (curr_relevant_bits.flex_mask_blocks[byte] > 0) {
                for (i = 0; i < 8; i += step_size) {
                    /* preserving the current and following byte because we're manipulating them in order to create alternative masks */
                    temp_byte1 = mask_entry.flex_mask_blocks[byte];
                    temp_byte2 = mask_entry.flex_mask_blocks[byte + 1];
                    /*
                     * zeroing out up to 8 consecutive relevant bits starting at bit i by:
                     * zeroing out the (8 - i) least significant relevant bits of the first byte
                     * zeroing out the i most significant relevant bits of the following byte
                     */
                    mask_entry.flex_mask_blocks[byte] &=
                        ~((curr_relevant_bits.flex_mask_blocks[byte]) & (0xFF >> i));
                    mask_entry.flex_mask_blocks[byte + 1] &=
                        ~((curr_relevant_bits.flex_mask_blocks[byte + 1]) & (0xFF << (8 - i)));
                    /* inserting the alternative mask into the mask pool */
                    sx_status = __atcam_erps_recalc_insert_rule_mask(masks_db,
                                                                     mask_entry.flex_mask_blocks,
                                                                     NULL);
                    if (sx_status != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("alternative mask insertion failed\n");
                        goto out;
                    }
                    /* restoring the original value for both bytes */
                    mask_entry.flex_mask_blocks[byte] = temp_byte1;
                    mask_entry.flex_mask_blocks[byte + 1] = temp_byte2;
                }
            }
        }
        /* zeroing out the last mask byte not covered by the above for loop */
        if (curr_relevant_bits.flex_mask_blocks[mask_size + mask_start - 1] > 0) {
            mask_entry.flex_mask_blocks[byte] &=
                ~curr_relevant_bits.flex_mask_blocks[mask_size + mask_start - 1];
            sx_status = __atcam_erps_recalc_insert_rule_mask(masks_db, mask_entry.flex_mask_blocks, NULL);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("alternative mask insertion failed\n");
                goto out;
            }
        }
        /* moving on to the next mask */
        masks_iter = cl_fmap_next(masks_iter);
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t __atcam_erps_recalc_get_erp_masks(atcam_erps_recalc_masks_db_t *masks_db,
                                              uint32_t                      max_erp_count,
                                              uint32_t                     *masks_total,
                                              boolean_t                     next_gen)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    atcam_rules_db_rule_t          *rule = NULL;
    atcam_erps_recalc_mask_entry_t *max_mask_count_entry = NULL;
    uint32_t                        erp_count = 0;
    uint32_t                        blocks_cnt = 0;
    sx_atcam_region_id_t            region_id = 0;

    SX_LOG_ENTER();

    if (utils_check_pointer(masks_db, "masks_db")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    region_id = masks_db->region_id;

    sx_status = atcam_regions_db_key_blocks_cnt_get(region_id, &blocks_cnt);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while getting key blocks count for region's [%u] erp recalculation\n", region_id);
        goto out;
    }

    /* Go over all the rules in the region and add them to the mask DB */
    sx_status = atcam_rules_db_iterate_rules(SX_ACCESS_CMD_GET_FIRST, region_id, 0, &rule);
    while (sx_status == SX_STATUS_SUCCESS) {
        /* Insert to our DB the rule's mask */
        __atcam_erps_recalc_insert_rule_mask(masks_db, rule->key_value_blocks.flex_mask_blocks, rule);
        sx_status = atcam_rules_db_iterate_rules(SX_ACCESS_CMD_GETNEXT, region_id, rule->rule_id, &rule);
    }
    if (sx_status != SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_ERR("Failed iterating rules for region [%u] erp recalculation. Error [%s]\n", region_id,
                   sx_status_str(sx_status));
        goto out;
    }
    sx_status = SX_STATUS_SUCCESS;

    if (next_gen == TRUE) {
        /* adding optional masks to the masks_db*/
        sx_status = __atcam_erps_recalc_add_alternative_masks(masks_db, blocks_cnt);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("erp recalculation for region [%u] failed at adding alternative masks.\n", region_id);
        }
    }

    /* return the number of total masks for testing purposes */
    if (masks_total != NULL) {
        *masks_total = cl_fmap_count(&masks_db->masks_fmap);
    }

    /* Go over the masks_db and find the masks that have the most compatible rules */
    while (cl_fmap_count(&masks_db->masks_temp_fmap) > 0 && erp_count < max_erp_count) {
        /* Calculate the delta compatible rules for each of the masks we've encountered */
        __atcam_erps_recalc_calculate_delta_compatible(blocks_cnt, masks_db, &max_mask_count_entry);
        if (max_mask_count_entry != NULL) {
            /* if the max mask entry has 0 delta compatible rules
             * it means we're left with alternative masks only and the optimizations is done
             */
            if (max_mask_count_entry->delta_comp_count == 0) {
                break;
            }
            /* Copy the erp with the most rules to the output */
            masks_db->erp_entries[erp_count] = max_mask_count_entry;
            /* Remove the mask that has the most rules along with all its delta compatible masks */
            __atcam_erps_recalc_remove_mask_and_compatible(masks_db, max_mask_count_entry);
        }
        erp_count++;
    }
    masks_db->erp_num = erp_count;
    sx_status = __atcam_erps_recalc_check_bad_collision(masks_db->erp_entries, erp_count);
    if (sx_status == SX_STATUS_ENTRY_ALREADY_EXISTS) {
        SX_LOG_INF("erp recalculation for region [%u] found a bad collision.\n", region_id);
    } else if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("erp recalculation bad collision check failed for region [%u].\n", region_id);
    }


out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_recalc_test_erp_calculation(const sx_acl_region_id_t region_id,
                                                   boolean_t                next_gen,
                                                   uint32_t                *erp_count,
                                                   uint32_t                *mask_count)
{
    atcam_erps_recalc_masks_db_t masks_db;
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;

    if (!g_initialized) {
        SX_LOG_ERR("Erp recalculation module is not initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Initialize the DB needed to store all the masks of this region */
    sx_status = __atcam_erps_recalc_init_masks_db(region_id, &masks_db);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed creating database entry for region [%u] erp recalculation. Error [%s]\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    /* Get the new erps to create */
    sx_status = __atcam_erps_recalc_get_erp_masks(&masks_db, *erp_count, mask_count, next_gen);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to recalculate erps for region [%u]\n", region_id);
        goto out;
    }
    *erp_count = masks_db.erp_num;

    /* Destroy the DB and release the memory */
    sx_status = __atcam_erps_recalc_deinit_masks_db(&masks_db);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed deinit region [%u] erp recalculation\n", region_id);
        goto out;
    }

out:
    return sx_status;
}

static sx_status_t __atcam_erps_recalc_check_optimization_needed(const sx_acl_region_id_t      region_id,
                                                                 atcam_erps_recalc_masks_db_t *masks_db)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     old_erp_num = 0;
    uint32_t    old_ctcam_rules_num = 0, new_ctcam_rules_num = 0;
    uint32_t    num_of_rules = 0;

    SX_LOG_ENTER();

    /* The next section examines if there is a need to do erp optimization */

    /* Duplicated rules (SW DB rules that have the same key) are certain to cause bad collisions and not supported by the the optimizer. */
    sx_status = atcam_regions_db_atcam_dup_rules_num_get(region_id, &num_of_rules);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while getting ATCAM duplicated rules count for region [%u]\n",
                   region_id);
        goto out;
    }
    if (num_of_rules > 0) {
        SX_LOG_INF("Region [%u] has [%u] duplicated rules and therefore will not be optimized.\n",
                   region_id, num_of_rules);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    /* Get the old number of erps so we can compare with the number we get after the optimization. */
    sx_status = atcam_erps_memory_manager_array_get(region_id, NULL, &old_erp_num, NULL);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region [%u] erp number for erp recalculation\n", region_id);
        goto out;
    }
    /* Get the number of the entries in the ctcam */
    sx_status = atcam_regions_db_ctcam_rules_num_get(region_id, &old_ctcam_rules_num);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed while getting ctcam rules count for region's [%u] erp recalculation\n", region_id);
        goto out;
    }

    /* If the number of erps is already very small and there are no entries in the ctcam
     * there is no need for optimization for this region.
     */
    if ((old_erp_num < MIN_ERPS_NEEDED_FOR_RECALC) && (old_ctcam_rules_num == 0)) {
        SX_LOG_INF("Region [%u] has only [%u] erps and therefore will not be optimized.\n",
                   region_id, old_erp_num);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    /* Initialize the DB needed to store all the masks of this region */
    sx_status = __atcam_erps_recalc_init_masks_db(region_id, masks_db);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed creating database entry for region [%u] erp recalculation. Error [%s]\n",
                   region_id,
                   sx_status_str(sx_status));
        goto out;
    }

    /* Get the new erps to create */
    sx_status = __atcam_erps_recalc_get_erp_masks(masks_db, SX_ATCAM_ERPS_PER_REGION, NULL, TRUE);
    if (sx_status == SX_STATUS_ENTRY_ALREADY_EXISTS) {
        SX_LOG_INF("erp recalculation for region [%u] found a bad collision.\n", region_id);
        goto db_destroy;
    } else if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to recalculate erps for region [%u]\n", region_id);
        goto db_destroy;
    }

    /* The rules that were not moved to the erps maps are the rules that are going to the ctcam */
    new_ctcam_rules_num = cl_fmap_count(&(masks_db->masks_temp_fmap));

    /* We decide to do the optimization in two cases:
     * 1. The number of erps has decreased due to the optimization.
     * 2. The number of erps stayed the same but the rules in the ctcam decreased by at least CTCAM_CHANGE_INTERVAL (16)
     */
    if ((masks_db->erp_num > old_erp_num) ||
        ((masks_db->erp_num == old_erp_num) &&
         ((new_ctcam_rules_num + CTCAM_CHANGE_INTERVAL) >= old_ctcam_rules_num))) {
        SX_LOG_INF(
            "Region [%u] optimization calculated [%u] erps to the original [%u] erps and therefore will not be optimized.\n",
            region_id,
            masks_db->erp_num,
            old_erp_num);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto db_destroy;
    }

    goto out;

db_destroy:
    /* Destroy the DB and release the memory */
    if (__atcam_erps_recalc_deinit_masks_db(masks_db) != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed deinit masks db for region [%u] erp recalculation\n", region_id);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __atcam_erps_recalc_create_shadow_region(atcam_erps_recalc_masks_db_t *masks_db)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    sx_status_t                rb_status = SX_STATUS_SUCCESS;
    atcam_regions_db_region_t *db_region_p = NULL;
    sx_acl_region_id_t         shadow_region_id = SX_ATCAM_INVALID_REGION_ID;
    sx_acl_id_t                shadow_acl_id = 0;
    uint32_t                   i = 0;

    SX_LOG_ENTER();

    if (utils_check_pointer(masks_db, "masks_db")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (!masks_db->valid) {
        SX_LOG_ERR("Trying to create shadow region for an uninitialized erp recalc db\n");
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }
    if ((shadow_create_cb == NULL) || (shadow_remove_cb == NULL)) {
        SX_LOG_ERR("Erp recalculation shadow region create/remove callbacks are un-initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Create a shadow region in which we'll create the new erps and transfer the rules */
    sx_status = shadow_create_cb(masks_db->region_id, &shadow_region_id, &shadow_acl_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        /* It is likely that it won't be possible to create a shadow region. We don't treat it as error. */
        SX_LOG_INF("Failed creating shadow region for region [%u] erp recalculation\n", masks_db->region_id);
        goto out;
    }
    ATCAM_CLR_REGION_BIT(shadow_region_id);
    SX_LOG_INF("Shadow region [%u] was created for region [%u] for erp recalculation\n",
               shadow_region_id,
               masks_db->region_id);
    /* Indicate in the db the shadow region */
    masks_db->shadow_region_id = shadow_region_id;

    /* Get a pointer to region's db */
    sx_status = atcam_regions_db_region_get(masks_db->region_id, &db_region_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Invalid region to get [%u] for erp recalculation\n", masks_db->region_id);
        goto destroy_region_rb;
    }

    /* Set the global mask of the new region be the same as the old one since we'll have the same rules */
    sx_status = atcam_regions_manager_region_mask_update(shadow_region_id, db_region_p->params.global_mask);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set global mask for shadow region [%u]\n", shadow_region_id);
        goto destroy_region_rb;
    }

    /* Create the required erps in the new region. We can fail due to lack of erp resources. */
    for (i = 0; i < masks_db->erp_num; i++) {
        sx_status =
            atcam_erps_manager_erp_create(shadow_region_id,
                                          masks_db->erp_entries[i]->mask.flex_mask_blocks,
                                          &masks_db->erp_ids[i]);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_INF("Failed to create erp for shadow region [%u]\n", shadow_region_id);
            goto destroy_region_rb;
        }
    }
    goto out;

destroy_region_rb:
    rb_status = shadow_remove_cb(masks_db->region_id, masks_db->shadow_region_id);
    if (rb_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to destroy shadow region [%u] for rollback region [%u]\n",
                   shadow_region_id,
                   masks_db->region_id);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __atcam_erps_recalc_move_atcam_region_rules(atcam_erps_recalc_masks_db_t       *masks_db,
                                                               atcam_erps_recalc_region_context_t *context,
                                                               const sx_acl_region_id_t            from_region_id,
                                                               const sx_acl_region_id_t            to_region_id)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    const cl_list_item_t           *list_end = NULL;
    atcam_rules_db_rule_t          *rule = NULL;
    atcam_erps_recalc_rule_entry_t *rule_entry = NULL;
    sx_acl_rule_offset_t            offset = 0;
    sx_acl_rule_offset_t            offsets[context->iter_max]; /* save the offsets of all moved rules to remove them later */
    uint32_t                        rules_per_iteration = 1;    /* rules to move per one loop iteration, default value is 1 */
    uint32_t                        utilization_count = 0;      /* used when determining rules per iteration */
    uint32_t                        rules_moved = 0;            /* rules inserted to the new region */
    uint32_t                        rules_removed = 0;          /* rules removed from the old region */


    SX_LOG_ENTER();
    SX_MEM_CLR(offsets);

    /* Indicate in the context that we are starting this operation */
    context->step_done = FALSE;

    /* determine the amount of rules per loop iteration based on the KVD utilization
     * The default value of 1 is set at initialization
     * If less than 60 percent is utilized we set the maximum amount of rules per iteration
     * If less than 90 percent is utilized we set it to a 100 rules at a time
     */
    sx_status = rm_hw_table_utilization_get_cb_wrapper(RM_HW_TABLE_TYPE_KVD_HASH_E, &utilization_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Couldn't get KVD utilization [%d]\n", from_region_id);
        goto out;
    }
    if (utilization_count <= RULES_PER_ITERATION_THRESHOLD_MAX) {
        rules_per_iteration = 100;
    }
    if (utilization_count <= RULES_PER_ITERATION_THRESHOLD_MIN) {
        rules_per_iteration = context->iter_max;
    }

    /* Go over the erp and add their rules' to the destination region */
    for (; context->erp_idx < masks_db->erp_num; context->erp_idx++) {
        /* If the list iterator is NULL in the context we need to take the head from the erp's rule list */
        if (context->list_iter == NULL) {
            context->list_iter = cl_qlist_head(&(masks_db->erp_entries[context->erp_idx]->rules_list));
        }
        list_end = cl_qlist_end(&(masks_db->erp_entries[context->erp_idx]->rules_list));
        while (context->list_iter != list_end && context->iter_count < context->iter_max) {
            rules_moved = 0;
            rules_removed = 0;
            /* This loop inserts a bulk of rules into the new region */
            while (rules_moved < rules_per_iteration) {
                if (context->list_iter == list_end) {
                    break;
                }
                rule_entry = PARENT_STRUCT(context->list_iter, atcam_erps_recalc_rule_entry_t, cl_list_item);
                rule = rule_entry->rule;
                offset = rule->offset;
                /* Add the rule to the region */
                sx_status = atcam_rules_manager_insert_rule(to_region_id,
                                                            rule->offset,
                                                            &rule->key_value_blocks,
                                                            rule->action,
                                                            rule->priority,
                                                            0,
                                                            DEFAULT_DEV_ID,
                                                            TRUE,
                                                            masks_db->erp_ids[context->erp_idx]);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed inserting rule in erp [%u] for region [%u] erp recalculation.\n",
                               masks_db->erp_ids[context->erp_idx],
                               to_region_id);
                    goto out;
                }
                /* Since the pointer to the rule is now pointing to a non-existing rule move the pointer to the new region */
                sx_status = atcam_rules_db_rule_get_by_offset(to_region_id, offset, &rule);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed getting rule offset [%u] for shadow region [%u] after move.\n",
                               offset,
                               to_region_id);
                    goto out;
                }
                /* we save the offset of each moved rule */
                offsets[rules_moved++] = offset;
                rule_entry->rule = rule;
                context->list_iter = cl_qlist_next(context->list_iter);
                context->iter_count++;
                /* If we ran out of iterations to perform we end the processing in this function */
                if (context->iter_count >= context->iter_max) {
                    break;
                }
            }

            /* we wait until the cache is wiped before removing rules to avoid packet loss */
            usleep(TIME_FOR_CACHE_WIPE);

            /* this loop removes the rules inserted into the new region from the old region */
            while (rules_removed < rules_moved) {
                /* Delete the rule from the old region */
                sx_status = atcam_rules_manager_delete_rule(from_region_id, offsets[rules_removed], 0, TRUE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed deleting rule from region [%u] erp recalculation.\n", from_region_id);
                    goto out;
                }
                rules_removed++;
            }
            /* If we ran out of iterations to perform we end the processing in this function */
            if (context->iter_count >= context->iter_max) {
                goto out;
            }
        }
        /* It's important to NULL the list iterator so it will be initialized again in the next erp */
        context->list_iter = NULL;
    }
    /* If we have reached this point in the code it means we went over all the rules
     * to be moved and therefore we are done with this operation and can clear the context.
     */
    context->step_done = TRUE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __atcam_erps_recalc_move_ctcam_region_rules(atcam_erps_recalc_masks_db_t       *masks_db,
                                                               atcam_erps_recalc_region_context_t *context)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    sx_acl_rule_offset_t            offset = 0, old_offset = 0;
    atcam_rules_db_rule_t          *rule = NULL;
    atcam_erps_recalc_rule_entry_t *rule_entry = NULL;
    atcam_erps_recalc_mask_entry_t *mask_entry = NULL;
    const cl_list_item_t           *temp_list_iter = NULL, *list_end = NULL;
    const cl_fmap_item_t           *map_end = NULL;

    SX_LOG_ENTER();

    /* Indicate in the context that we are starting this operation */
    context->step_done = FALSE;

    /* Note: We do a nasty trick here: we add the atcam rule to the ctcam with an offset
     * cleared by another rule (which was moved to the shadow region). After deleting
     * the rule from the atcam we set the correct offset to the rule in the ctcam.
     */
    temp_list_iter = cl_qlist_head(&(masks_db->erp_entries[0]->rules_list));
    list_end = cl_qlist_end(&(masks_db->erp_entries[0]->rules_list));
    if (temp_list_iter == list_end) {
        SX_LOG_ERR("Unexpected empty erp for region [%u] for erp recalculation.\n", masks_db->region_id);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    /* Preserve the offset of the rule that no longer exists in the original region */
    rule_entry = PARENT_STRUCT(temp_list_iter, atcam_erps_recalc_rule_entry_t, cl_list_item);
    offset = rule_entry->rule->offset;

    /* Add the rest of the rules to the ctcam */
    if (context->map_iter == NULL) {
        context->map_iter = cl_fmap_head(&(masks_db->masks_temp_fmap));
    }
    map_end = cl_fmap_end(&(masks_db->masks_temp_fmap));
    while (context->map_iter != map_end) {
        mask_entry = PARENT_STRUCT(context->map_iter, atcam_erps_recalc_mask_entry_t, fmap_temp_item);
        /* Go over this mask's entries and add them to the CTCAM */
        if (context->list_iter == NULL) {
            context->list_iter = cl_qlist_head(&(mask_entry->rules_list));
        }
        list_end = cl_qlist_end(&(mask_entry->rules_list));
        while (context->list_iter != list_end) {
            rule_entry = PARENT_STRUCT(context->list_iter, atcam_erps_recalc_rule_entry_t, cl_list_item);
            rule = rule_entry->rule;
            /* There is a point in moving the rule only if we're moving it from atcam to ctcam */
            if (rule->is_atcam) {
                old_offset = rule->offset;
                sx_status = atcam_rules_manager_insert_rule(masks_db->region_id,
                                                            offset,
                                                            &rule->key_value_blocks,
                                                            rule->action,
                                                            rule->priority,
                                                            0,
                                                            DEFAULT_DEV_ID,
                                                            TRUE,
                                                            ATCAM_INVALID_ERP_ID);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed inserting rule to ctcam for region [%u] erp recalculation.\n",
                               masks_db->region_id);
                    goto out;
                }
                /* Delete the "old" rule from the atcam */
                sx_status = atcam_rules_manager_delete_rule(masks_db->region_id, old_offset, 0, TRUE);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed deleting rule from region [%u] erp recalculation.\n", masks_db->region_id);
                    goto out;
                }
                /* Now we set the correct offset to the rule we've moved to the ctcam */
                sx_status = atcam_rules_db_change_rule_offset(masks_db->region_id, offset, old_offset);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed changing offsets [%u]->[%u], region [%u] erp recalculation.\n",
                               offset,
                               old_offset,
                               masks_db->region_id);
                    goto out;
                }
            }
            context->list_iter = cl_qlist_next(context->list_iter);
            context->iter_count++;
            /* If we ran out of iterations to perform we end the processing in this function */
            if (context->iter_count >= context->iter_max) {
                goto out;
            }
        }
        /* It's important to NULL the list iterator so it will be initialized again in the next erp */
        context->list_iter = NULL;
        /* Go to the next entry */
        context->map_iter = cl_fmap_next(context->map_iter);
    }
    /* If we have reached this point in the code it means we went over all the rules
     * to be moved and therefore we are done with this operation and can clear the context.
     */
    context->step_done = TRUE;


out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __atcam_erps_recalc_remove_shadow_region(atcam_erps_recalc_masks_db_t *masks_db)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(masks_db, "masks_db")) {
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (!masks_db->valid) {
        SX_LOG_ERR("Trying to remove shadow region for an uninitialized erp recalc db\n");
        sx_status = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }
    if ((shadow_create_cb == NULL) || (shadow_remove_cb == NULL)) {
        SX_LOG_ERR("Erp recalculation shadow region create/remove callbacks are un-initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }
    /* Remove the shadow region after all the rules were moved */
    sx_status = shadow_remove_cb(masks_db->region_id, masks_db->shadow_region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed removing shadow region for region [%u] erp recalculation\n", masks_db->region_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

inline static void __clear_iteration_context(atcam_erps_recalc_region_context_t *context)
{
    context->erp_idx = 0;
    context->iter_count = 0;
    context->iter_max = MAX_RULES_PER_ITERATION;
    context->list_iter = NULL;
    context->map_iter = NULL;
    context->step_done = FALSE;
    return;
}

static sx_status_t __atcam_erps_recalc_region_state_machine(atcam_erps_recalc_region_context_t *context,
                                                            atcam_erps_recalc_masks_db_t       *masks_db)
{
    sx_status_t        sx_status = SX_STATUS_SUCCESS;
    sx_acl_region_id_t region_id = context->region_id;
    uint32_t           i = 0;

    SX_LOG_ENTER();

    if (!g_initialized) {
        SX_LOG_ERR("Erp recalculation module is not initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }
    /* For each iteration we clear the iteration's count */
    context->iter_count = 0;

    switch (context->state) {
    /* 1. Check if optimization is needed. If so, create a db with the new erps to create and the rules within them. */
    case RECALC_REGION_STATE_INITIAL:
        /* Check if the erp region needs optimization and if so calculates the erps that need to be created */
        sx_status = __atcam_erps_recalc_check_optimization_needed(region_id, masks_db);
        if (sx_status != SX_STATUS_SUCCESS) {
            if (sx_status == SX_STATUS_ENTRY_ALREADY_EXISTS) {
                /* Erp recalculation may not be needed or some failure happened. In any case we cancel the optimization. */
                SX_LOG_INF("Region [%u] doesn't need erp recalculation\n", region_id);
                sx_status = SX_STATUS_SUCCESS;
            } else {
                SX_LOG_INF("Region [%u] failed erp recalculation\n", region_id);
            }
            /* Indicate the erp optimization is done here. The reason doesn't really matter. */
            context->state = RECALC_REGION_STATE_OPTIMIZATION_DONE;
        } else {
            /* If we're here it means we need optimization */
            if (masks_db->erp_num > 0) {
                context->state = RECALC_REGION_STATE_OPTIMIZATION_NEEDED;
            } else {
                /* There are no erps to be created - no more rules in the region.
                 * Clear all the erps and finish the optimization.
                 */
                sx_status = atcam_erps_manager_clear_region_erps(region_id);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed clearing erps from region [%u] erp recalculation with no rules.\n", region_id);
                    goto err_db_destroy;
                }
                context->state = RECALC_REGION_STATE_OPTIMIZATION_DONE;
                /* Destroy the DB and release the memory */
                sx_status = __atcam_erps_recalc_deinit_masks_db(masks_db);
                if (sx_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed deinit region [%u] erp recalculation with no rules\n", region_id);
                }
            }
        }
        break;

    /* 2. If we're here it means that an optimization is needed and we better start doing it. */
    case RECALC_REGION_STATE_OPTIMIZATION_NEEDED:
        /* Create the new region in which to create the optimized erps + the new erps we need */
        sx_status = __atcam_erps_recalc_create_shadow_region(masks_db);
        if (sx_status != SX_STATUS_SUCCESS) {
            /* If creating a shadow region failed we just get out without any fuss */
            context->state = RECALC_REGION_STATE_OPTIMIZATION_ERROR;
            SX_LOG_INF("Failed creating shadow region for region [%u] erp recalculation.\n", region_id);
            sx_status = SX_STATUS_SUCCESS;
            goto err_db_destroy;
        }
        context->state = RECALC_REGION_STATE_SHADOW_REGION_CREATED;
    /* fall through */

    /* 3. Shadow region was created. Start moving the rules intended to go to the ATCAM */
    case RECALC_REGION_STATE_SHADOW_REGION_CREATED:
        /* Clear the context for the following iteration. */
        __clear_iteration_context(context);
        context->state = RECALC_REGION_STATE_ATCAM_TO_SHADOW_IN_PROGRESS;
    /* fall through */

    case RECALC_REGION_STATE_ATCAM_TO_SHADOW_IN_PROGRESS:
        /* Move the rules from the region to its shadow region */
        sx_status = __atcam_erps_recalc_move_atcam_region_rules(masks_db,
                                                                context,
                                                                region_id,
                                                                masks_db->shadow_region_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed moving rules from region [%u] to shadow region [%u] erp recalculation.\n",
                       region_id,
                       masks_db->shadow_region_id);
            goto err_db_destroy;
        }
        if (context->step_done) {
            context->state = RECALC_REGION_STATE_ATCAM_TO_SHADOW_DONE;
        }
        break;

    /* 4. Move all the rules that are moving from the atcam to the ctcam. */
    case RECALC_REGION_STATE_ATCAM_TO_SHADOW_DONE:
        /* Clear the context for the following iteration. */
        __clear_iteration_context(context);
        context->state = RECALC_REGION_STATE_ATCAM_TO_CTCAM_IN_PROGRESS;
    /* fall through */

    case RECALC_REGION_STATE_ATCAM_TO_CTCAM_IN_PROGRESS:
        /* Move the rules that are moving from the atcam to the ctcam */
        sx_status = __atcam_erps_recalc_move_ctcam_region_rules(masks_db, context);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed moving rules from atcam to ctcam for region [%u] erp recalculation.\n", region_id);
            goto err_db_destroy;
        }
        if (context->step_done) {
            context->state = RECALC_REGION_STATE_ATCAM_TO_CTCAM_DONE;
        }
        break;

    /* 5. All the ATCAM rules were moved to the shadow region or ctcam.
     *      Destroy the old erps and create new erps in the original region. */
    case RECALC_REGION_STATE_ATCAM_TO_CTCAM_DONE:
        /* Clear the erps from the old region */
        sx_status = atcam_erps_manager_clear_region_erps(region_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed clearing erps from region [%u] erp recalculation.\n", region_id);
            goto err_db_destroy;
        }
        /* Create the new erps in the old region */
        for (i = 0; i < masks_db->erp_num; i++) {
            sx_status = atcam_erps_manager_erp_create(region_id,
                                                      masks_db->erp_entries[i]->mask.flex_mask_blocks,
                                                      &masks_db->erp_ids[i]);
            if (sx_status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to create erp for shadow region [%u]\n", masks_db->shadow_region_id);
                goto err_db_destroy;
            }
        }
        context->state = RECALC_REGION_STATE_NEW_ERPS_CREATED;

    /* fall through */
    case RECALC_REGION_STATE_NEW_ERPS_CREATED:
        /* Clear the context for the following iteration. */
        __clear_iteration_context(context);
        context->state = RECALC_REGION_STATE_SHADOW_TO_ATCAM_IN_PROGRESS;
    /* fall through */

    /* 6. Move back all the atcam rules from the shadow region to the original region */
    case RECALC_REGION_STATE_SHADOW_TO_ATCAM_IN_PROGRESS:
        sx_status = __atcam_erps_recalc_move_atcam_region_rules(masks_db,
                                                                context,
                                                                masks_db->shadow_region_id,
                                                                region_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed moving rules from shadow region [%u] to region [%u] erp recalculation.\n",
                       masks_db->shadow_region_id,
                       region_id);
            goto err_db_destroy;
        }
        if (context->step_done) {
            context->state = RECALC_REGION_STATE_SHADOW_TO_ATCAM_DONE;
        }
        break;

    /* 7. We're done moving the rules. Destroy the shadow region. */
    case RECALC_REGION_STATE_SHADOW_TO_ATCAM_DONE:
        sx_status = __atcam_erps_recalc_remove_shadow_region(masks_db);
        /* Remove the shadow region */
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed removing shadow region for region [%u] erp recalculation\n", region_id);
            goto err_db_destroy;
        }
        context->state = RECALC_REGION_STATE_SHADOW_REGION_REMOVED;
    /* fall through */

    /* 8. Clean the DB for the region. */
    case RECALC_REGION_STATE_SHADOW_REGION_REMOVED:
        context->state = RECALC_REGION_STATE_OPTIMIZATION_DONE;
        /* Destroy the DB and release the memory */
        sx_status = __atcam_erps_recalc_deinit_masks_db(masks_db);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed deinit region [%u] erp recalculation\n", region_id);
        }
        break;

    /* 9. If for some reason we get an already optimized region we don't do anything. */
    case RECALC_REGION_STATE_OPTIMIZATION_DONE:
        break;

    default:
        SX_LOG_ERR("Unknown erp recalculation state [%u] for region [%u] \n", context->state, region_id);
        sx_status = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    goto out;

err_db_destroy:
    /* Destroy the DB and release the memory */
    if (__atcam_erps_recalc_deinit_masks_db(masks_db) != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed deinit region [%u] erp recalculation\n", region_id);
    }
    /* Indicate that we have encountered an error */
    context->state = RECALC_REGION_STATE_OPTIMIZATION_ERROR;

out:
    SX_LOG_EXIT();
    return sx_status;
}

static void __atcam_erp_recalc_enable(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    UNUSED_PARAM(stream);
    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    atcam_erps_recalc_enable_set((boolean_t)(intptr_t)handler_context);
}

static void __atcam_erps_recalc_timer_execute(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);
    boolean_t is_complete = FALSE;

    atcam_erps_recalc_timer_execute((boolean_t)(intptr_t)handler_context, &is_complete);
    if (is_complete) {
        fprintf(stream, "all regions were optimized\n");
    } else {
        fprintf(stream, "not all regions were optimized yet\n");
    }
}

sx_status_t atcam_erps_recalc_init(const uint32_t                num_of_regions,
                                   atcam_shadow_region_create_cb shadow_region_create_cb,
                                   atcam_shadow_region_remove_cb shadow_region_remove_cb)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    if (g_initialized) {
        SX_LOG_ERR("atcam_erps_recalc_init: module is already initialized\n");
        sx_status = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }
    shadow_create_cb = shadow_region_create_cb;
    shadow_remove_cb = shadow_region_remove_cb;

    /* Initialize the pool that will be used to store the regions we'll iterate on */
    sx_status = utils_clr_memory_get((void**)(&(regions_iter_db.regions_array)),
                                     num_of_regions,
                                     sizeof(atcam_erps_recalc_region_list_entry_t),
                                     UTILS_MEM_TYPE_ID_ACL_E);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate erp optimization memory\n");
        goto out;
    }

    regions_iter_db.regions_num = num_of_regions;
    for (i = 0; i < num_of_regions; i++) {
        regions_iter_db.regions_array[i].region_id = i;
        regions_iter_db.regions_array[i].allocated = FALSE;
    }
    /* Initialize the list used to iterate over the regions */
    cl_qlist_init(&(regions_iter_db.regions_list));

    sx_utils_debug_cmd_register_path("atcam region erp optimize enable", __atcam_erp_recalc_enable, (void*)TRUE);
    sx_utils_debug_cmd_register_path("atcam region erp optimize disable", __atcam_erp_recalc_enable, (void*)FALSE);
    sx_utils_debug_cmd_register_path("atcam region erp optimize whole region",
                                     __atcam_erps_recalc_timer_execute,
                                     (void*)TRUE);
    sx_utils_debug_cmd_register_path("atcam region erp optimize once",
                                     __atcam_erps_recalc_timer_execute,
                                     (void*)FALSE);

    g_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_recalc_deinit(const boolean_t forced_deinit)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(forced_deinit);

    if (!g_initialized) {
        SX_LOG_ERR("atcam_erps_recalc_deinit: module is not initialized\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }
    shadow_create_cb = NULL;
    shadow_remove_cb = NULL;

    sx_status = utils_memory_put((void*)(regions_iter_db.regions_array), UTILS_MEM_TYPE_ID_ACL_E);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed deallocating erp recalculation memory\n");
    }

    g_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_recalc_enable_set(const boolean_t enable)
{
    g_optimization_enabled = enable;
    return SX_STATUS_SUCCESS;
}

sx_status_t atcam_erps_recalc_enable_get(boolean_t *enable)
{
    if (utils_check_pointer(enable, "enable")) {
        return SX_STATUS_PARAM_NULL;
    } else {
        *enable = g_optimization_enabled;
        return SX_STATUS_SUCCESS;
    }
}

sx_status_t atcam_erps_recalc_region_allocate(const sx_atcam_region_id_t region_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!g_initialized) {
        SX_LOG_ERR("Erp recalculation module is not initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (region_id >= regions_iter_db.regions_num) {
        SX_LOG_ERR("Region id [%u] is out of bounds for erp recalculation.\n", region_id);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Check if the region id doesn't exist already */
    if (regions_iter_db.regions_array[region_id].allocated) {
        SX_LOG_ERR("Region id [%u] already exists in the erp recalculation module.\n", region_id);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }
    /* Insert this region to the list of allocated regions we can iterate on */
    cl_qlist_insert_tail(&(regions_iter_db.regions_list), &(regions_iter_db.regions_array[region_id].cl_list_item));
    /* Initialize the region's entry */
    regions_iter_db.regions_array[region_id].allocated = TRUE;
    regions_iter_db.regions_array[region_id].rules_changed = FALSE;
    regions_iter_db.regions_array[region_id].rules_changed_cycle = completed_cycles_count;
    regions_iter_db.regions_array[region_id].state = RECALC_REGION_STATE_INITIAL;
out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_recalc_region_destroy(const sx_atcam_region_id_t region_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    boolean_t   is_complete = FALSE;

    SX_LOG_ENTER();

    if (!g_initialized) {
        SX_LOG_ERR("Erp recalculation module is not initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (region_id >= regions_iter_db.regions_num) {
        SX_LOG_ERR("Region id [%u] is out of bounds for erp recalculation.\n", region_id);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Check if the region id exist */
    if (!regions_iter_db.regions_array[region_id].allocated) {
        SX_LOG_ERR("Region id [%u] does not exist in the erp recalc module.\n", region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    /* Check if the current region we're handling is the region whose rule is changed */
    if ((current_region_p != NULL) && (current_region_p->region_id == region_id)) {
        /* Force the completion of the current region so we can set the new rule.*/
        sx_status = atcam_erps_recalc_timer_execute(TRUE, &is_complete);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to complete region [%u] erp optimization for rule modification.\n", region_id);
            goto out;
        }
    }
    /* Remove the region from the allocated list */
    cl_qlist_remove_item(&(regions_iter_db.regions_list), &(regions_iter_db.regions_array[region_id].cl_list_item));
    /* Clear the entry */
    regions_iter_db.regions_array[region_id].allocated = FALSE;
    regions_iter_db.regions_array[region_id].rules_changed = FALSE;
    regions_iter_db.regions_array[region_id].rules_changed_cycle = 0;
    regions_iter_db.regions_array[region_id].state = RECALC_REGION_STATE_INITIAL;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_recalc_rule_change_notify(const sx_atcam_region_id_t region_id)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    boolean_t   is_complete = FALSE;

    SX_LOG_ENTER();

    /* If the module was not initialize yet just go out quietly */
    if (!g_initialized || !g_optimization_enabled) {
        goto out;
    }
    /* Check if the region id is not out of bounds */
    if (region_id >= regions_iter_db.regions_num) {
        SX_LOG_ERR("Region id [%u] does not exist in the erp recalc module.\n", region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    /* Check if the current region we're handling is the region whose rule is changed */
    if ((current_region_p != NULL) && (current_region_p->region_id == region_id)) {
        /* Force the completion of the current region so we can set the new rule.*/
        sx_status = atcam_erps_recalc_timer_execute(TRUE, &is_complete);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to complete region [%u] erp optimization for rule modification.\n", region_id);
            goto out;
        }
    }
    /* In any case indicate that this region's rules has changed and on what cycle this happened.*/
    regions_iter_db.regions_array[region_id].rules_changed = TRUE;
    regions_iter_db.regions_array[region_id].rules_changed_cycle = completed_cycles_count;

out:
    SX_LOG_EXIT();
    return sx_status;
}

/*
 * The following function is used by:
 * - the regular timer execution.
 * - optimization triggered as a result of ERP count crossing a predefined threshold.
 */
sx_status_t __atcam_erps_recalc_current_region(atcam_erps_recalc_region_list_entry_t *region_p,
                                               const boolean_t                        complete_whole_region)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* initialize the region's data if needed */
    if (region_p->state == RECALC_REGION_STATE_INITIAL) {
        SX_MEM_CLR(current_region_mask_db);
        SX_MEM_CLR(current_region_context);
    }
    /* The context might be a leftover from the previous region
     * so in some cases we need to set correctly the region_id and state.
     */
    current_region_context.region_id = region_p->region_id;
    current_region_context.state = region_p->state;

    do {
        sx_status = __atcam_erps_recalc_region_state_machine(&current_region_context, &current_region_mask_db);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to run state machine for region [%u] erp optimization.\n",
                       region_p->region_id);
            goto out;
        }
    } while (complete_whole_region &&
             current_region_context.state != RECALC_REGION_STATE_OPTIMIZATION_DONE &&
             current_region_context.state != RECALC_REGION_STATE_OPTIMIZATION_ERROR);
    /* Store the state of the region in the iterator as well */
    region_p->state = current_region_context.state;

out:
    SX_LOG_EXIT();
    return sx_status;
}


/*
 * The following function is called whenever a rule insertion causes a new ERP creation.
 * The function checks if the new ERP created have caused the ERP count to reach a predefined threshold,
 * for which it was decided to trigger the optimization process immediately in order to shrink the amount of ERP's
 * and prevent rules from going into the CTCAM
 */
sx_status_t atcam_erps_recalc_trigger_region_optimization(const sx_atcam_region_id_t region_id, uint32_t erp_count)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    boolean_t   is_complete = TRUE;

    SX_LOG_ENTER();

    /* erp count is under the set threshold and optimization is not needed */
    if (erp_count < ERP_THRESHOLD_TO_TRIGGER) {
        goto out;
    }

    /* If the module was not initialized yet or optimization is disabled just go out quietly */
    if (!g_initialized || !g_optimization_enabled) {
        goto out;
    }

    if (region_id >= regions_iter_db.regions_num) {
        SX_LOG_ERR("Region id [%u] is out of bounds for erp recalculation.\n", region_id);
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Check if the region id exists */
    if (!regions_iter_db.regions_array[region_id].allocated) {
        SX_LOG_ERR("Region id [%u] does not exist in the erp recalc module.\n", region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* check if this or any other region is undergoing an optimization at the moment,
     * if so, force the optimization of the whole region to be over before optimizing the region we want.
     */
    if ((current_region_p != NULL) &&
        REGION_STATE_INITIAL_OR_DONE(current_region_p->state)) {
        atcam_erps_recalc_timer_execute(TRUE, &is_complete);
    }
    /* IMPORTANT!
     * At this point we assume there is no region undergoing timer triggered optimization,
     * because if any optimization was underway we just forced its completion.
     * In addition, check that the region is in an expected state to run the optimization */
    if (REGION_STATE_INITIAL_OR_DONE(regions_iter_db.regions_array[region_id].state)) {
        regions_iter_db.regions_array[region_id].state = RECALC_REGION_STATE_INITIAL;
    } else {
        SX_LOG_ERR("Failed to set \"initial\" state for region id [%u]. Error [%s]\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }
    /* Perform the optimization for the whole region */
    sx_status = __atcam_erps_recalc_current_region(&regions_iter_db.regions_array[region_id], TRUE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to force ERP recalculation for region id [%u]. Error [%s]\n",
                   region_id, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_recalc_timer_execute(const boolean_t complete_whole_region, boolean_t *is_complete)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    const cl_list_item_t *list_item = NULL;
    boolean_t             execute_state_machine = TRUE;

    SX_LOG_ENTER();

    *is_complete = TRUE;
    /* If the module was not initialize yet just go out quietly */
    if (!g_initialized || !g_optimization_enabled) {
        goto out;
    }

    /* If we don't have a current region to handle get the first one from the list */
    if (current_region_p == NULL) {
        list_item = cl_qlist_head(&regions_iter_db.regions_list);
        /* If there are no entries in the list we just get out */
        if (list_item == cl_qlist_end(&regions_iter_db.regions_list)) {
            goto out;
        }
        current_region_p = PARENT_STRUCT(list_item, atcam_erps_recalc_region_list_entry_t, cl_list_item);
    } else {
        list_item = &current_region_p->cl_list_item;
    }

    /* If the processing of the current region has not begun - initialize the region's data */
    if (current_region_p->state == RECALC_REGION_STATE_INITIAL) {
        SX_MEM_CLR(current_region_mask_db);
        SX_MEM_CLR(current_region_context);
        /* If this region is the initial state don't start the optimization state machine
         *  unless a certain amount of quiet cycles have passed.
         *  This is to prevent optimization of very active regions.
         */
        if (completed_cycles_count - regions_iter_db.regions_array[current_region_p->region_id].rules_changed_cycle <
            MIN_QUIET_CYCLES) {
            execute_state_machine = FALSE;
        }
    }

    /* The context might be a leftover from the previous region
     * so in some cases we need to set correctly the region_id and state.
     */
    current_region_context.region_id = current_region_p->region_id;
    current_region_context.state = current_region_p->state;

    if (execute_state_machine) {
        /* Run the state machine on the current context and see where it leads us. */
        sx_status = __atcam_erps_recalc_current_region(current_region_p, complete_whole_region);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to optimize region [%u] while executing state machine.\n", current_region_p->region_id);
            goto out;
        }
    }
    /* If we're done with the current region - goto to the next */
    if (REGION_STATE_INITIAL_OR_DONE(current_region_context.state)) {
        /* If the rules changed for the region we need to revert it to initial state so it can be optimized again. */
        /* If the optimization failed for some reason (probably lack of resources) try it again the next round. */
        if (current_region_p->rules_changed ||
            (current_region_context.state == RECALC_REGION_STATE_OPTIMIZATION_ERROR)) {
            current_region_p->state = RECALC_REGION_STATE_INITIAL;
            current_region_p->rules_changed = FALSE;
        }

        list_item = cl_qlist_next(list_item);
        if (list_item == cl_qlist_end(&regions_iter_db.regions_list)) {
            current_region_p = NULL;
        } else {
            current_region_p = PARENT_STRUCT(list_item, atcam_erps_recalc_region_list_entry_t, cl_list_item);
        }
    }
    /* If we did not complete the optimization of all the regions signal that to the caller */
    if (current_region_p != NULL) {
        *is_complete = FALSE;
    } else {
        completed_cycles_count++;   /* Count the number of cycles we've done so far. */
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}
