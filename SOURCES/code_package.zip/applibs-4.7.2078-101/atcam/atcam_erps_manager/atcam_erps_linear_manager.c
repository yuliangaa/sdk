/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include "atcam_erps_linear_manager.h"

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "sx/sdk/sx_status_convertor.h"
#include "sx/utils/dbg_utils.h"
#include "sx/utils/dbg_utils_pretty_printer.h"
#include "resource_manager/resource_manager.h"
#include "complib/sx_log.h"
#include "sx/utils/gc.h"
#include "issu/issu.h"

#undef  __MODULE__
#define __MODULE__ ERP_LINEAR_MANAGER


/************************************************
 *  Local Type definitions
 ***********************************************/

#define ERP_MEM_SIZE                   128
#define RELOCATION_THRESHOLD_SPECTRUM2 50
#define RELOCATION_COUNT_SPECTRUM2     ERP_MEM_SIZE
#define ERP_ALLOCATION_TYPE            1
#define MAX_NUM_OF_ROWS                4
#define MAX_SIZE_OF_ROW                3
#define MAX_BLOCK_SIZE                 (MAX_SIZE_OF_ROW * MAX_NUM_OF_ROWS)
#define ERP_INVALID_ID                 0xFF

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static linear_manager_db_t                        g_erp_linear_manager_db;
static boolean_t                                  g_erp_group_initialized = FALSE;
static atcam_erps_linear_manager_block_relocate_t g_relocate_cb;
static atcam_erps_linear_manager_index_t          g_erps_linear_base_index = 0;
static uint16_t                                   g_alloc_sizes[BLOCK_SIZE_NUM] = {BLOCK_SIZE_ONE,
                                                                                   BLOCK_SIZE_TWO,
                                                                                   BLOCK_SIZE_THREE,
                                                                                   BLOCK_SIZE_FOUR,
                                                                                   BLOCK_SIZE_SIX,
                                                                                   BLOCK_SIZE_EIGHT,
                                                                                   BLOCK_SIZE_NINE,
                                                                                   BLOCK_SIZE_TWELVE};

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __check_block_size(atcam_erps_linear_manager_block_length_t size);
static sx_utils_status_t __group_free(linear_manager_db_t database, ba_group_t *group);
static sx_utils_status_t __group_alloc(linear_manager_db_t database, uint32_t type, const ba_group_t **group_p);
static sx_utils_status_t __block_relocate(linear_manager_handle_t       handle,
                                          linear_manager_block_length_t size,
                                          linear_manager_block_length_t offset,
                                          linear_manager_context_t      context,
                                          linear_manager_index_t      * old_index_p,
                                          linear_manager_index_t        new_index);
/************************************************
 *  Function implementations
 ***********************************************/
static sx_utils_status_t __block_relocate(linear_manager_handle_t       handle,
                                          linear_manager_block_length_t size,
                                          linear_manager_block_length_t offset,
                                          linear_manager_context_t      context,
                                          linear_manager_index_t      * old_index_p,
                                          linear_manager_index_t        new_index)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(offset);

    if (!old_index_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("param NULL from linear manager callback  err = [%s]\n", sx_status_str(err));
        goto out;
    }
    err = g_relocate_cb(handle,
                        size,
                        (sx_acl_region_id_t)context,
                        new_index,
                        ERP_INVALID_ID);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to call given callback  err = [%s]\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status_to_sx_utils_status(err);
}
static sx_utils_status_t __group_free(linear_manager_db_t database, ba_group_t *group)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(database);
    UNUSED_PARAM(group);

    if (g_erp_group_initialized) {
        g_erp_group_initialized = FALSE;
    } else {
        SX_LOG_ERR("erp group is already free\n");
        err = SX_STATUS_DB_NOT_INITIALIZED;
    }

    return sx_status_to_sx_utils_status(err);
}

static sx_utils_status_t __group_alloc(linear_manager_db_t database, uint32_t type, const ba_group_t **group_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(database);
    UNUSED_PARAM(type);

    static ba_group_t ba_group = {0};

    if (!g_erp_group_initialized) {
        g_erp_group_initialized = TRUE;
    } else {
        SX_LOG_ERR("erp group is already initialized\n");
        err = SX_STATUS_DB_ALREADY_INITIALIZED;
        goto out;
    }

    ba_group.type = ERP_ALLOCATION_TYPE;
    ba_group.grp_index = 0;
    *group_p = &ba_group;

out:
    return sx_status_to_sx_utils_status(err);
}
static sx_status_t __check_block_size(atcam_erps_linear_manager_block_length_t size)
{
    uint8_t i;

    for (i = 0; i < BLOCK_SIZE_NUM; i++) {
        if (size == g_alloc_sizes[i]) {
            return SX_STATUS_SUCCESS;
        }
    }

    return SX_STATUS_PARAM_ERROR;
}


sx_status_t atcam_erps_linear_manager_init(atcam_erps_linear_manager_params_t *user_params)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_utils_status_t          utils_err = SX_UTILS_STATUS_SUCCESS;
    linear_manager_params_t    params;
    linear_manager_phys_init_t phys_init;
    uint32_t                   erp_mem_size = ERP_MEM_SIZE;
    uint8_t                    relocation_count_spectrum2 = RELOCATION_COUNT_SPECTRUM2;
    sx_boot_mode_e             issu_boot_mode;
    sx_issu_bank_e             issu_bank;

    SX_LOG_ENTER();

    SX_MEM_CLR(params);
    SX_MEM_CLR(phys_init);

    SX_MEM_CPY_ARRAY(params.allocation_types_params[ERP_ALLOCATION_TYPE - 1].alloc_sizes,
                     g_alloc_sizes, BLOCK_SIZE_NUM, uint16_t);

    g_relocate_cb = user_params->relocate_cb;

    err = issu_boot_mode_get(&issu_boot_mode);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to issu_boot_mode_get err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    if (issu_boot_mode != SX_BOOT_MODE_DISABLED_E) {
        erp_mem_size = ERP_MEM_SIZE / 2;
        relocation_count_spectrum2 = RELOCATION_COUNT_SPECTRUM2 / 2;
        err = issu_bank_get(&issu_bank);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to issu_bank_get sx_status = %s\n",
                       sx_status_str(err));
            goto out;
        }
        /*If we use the first ISSU bank , the linear table starts from the first entry,
         * Otherwise it starts from the first entry + (SX_ATCAM_ERPS_HW_INDEX_MAX / 2)
         */
        g_erps_linear_base_index = (ERP_MEM_SIZE / 2) * issu_bank;
    }

    phys_init.phys_mem_size = erp_mem_size;

    strncpy(phys_init.phys_mem_name, "ERP_LINEAR",
            sizeof(phys_init.phys_mem_name));

    params.alignment = erp_mem_size;
    params.alloc_group_cb = __group_alloc;
    params.allocation_types_num = 1;
    params.array_size = erp_mem_size;
    params.free_group_cb = __group_free;
    params.p_phys_init = &phys_init;
    params.relocate_cb = __block_relocate;
    params.relocation_count = relocation_count_spectrum2;
    params.relocation_threshold = RELOCATION_THRESHOLD_SPECTRUM2;
    params.gc_attr.fence_type = GC_FENCE_TYPE_FAST;
    params.gc_attr.free_objects_threshold = erp_mem_size;
    params.gc_attr.per_object_threshold = 2;
    params.gc_attr.hw_operation_needed = FALSE;
    params.gc_attr.immediate_fence_needed = FALSE;
    params.gc_object_type = GC_OBJECT_TYPE_ERP;
    params.gc_subtype = GC_OBJECT_SUBTYPE_NONE;
    params.gc_post_completion_cb = NULL;
    params.gc_attr.max_object_count = erp_mem_size;


    utils_err = linear_manager_init(&g_erp_linear_manager_db, &params);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("linear_manager_init - Failed to initialize erp linear manager DB  err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t atcam_erps_linear_manager_deinit(const boolean_t forced_deinit)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    utils_err = linear_manager_deinit(g_erp_linear_manager_db);
    if ((!forced_deinit) && (SX_UTILS_CHECK_FAIL(utils_err))) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to deinitialize erp linear manager utils_err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t atcam_erps_linear_manager_block_add(sx_acl_region_id_t                       region_id,
                                                atcam_erps_linear_manager_block_length_t size,
                                                atcam_erps_linear_manager_handle_t     * handle)
{
    sx_status_t                                  err = SX_STATUS_SUCCESS;
    sx_utils_status_t                            utils_err = SX_UTILS_STATUS_SUCCESS;
    atcam_erps_linear_manager_allocation_types_t allocation_type;
    linear_manager_handle_t                      linear_handle = 0;

    SX_LOG_ENTER();

    if (handle == NULL) {
        SX_LOG(SX_LOG_ERROR, "handle param invalid\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __check_block_size(size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "size param invalid\n");
        goto out;
    }

    allocation_type = ERP_ALLOCATION_TYPE;
    utils_err = linear_manager_block_add(g_erp_linear_manager_db, allocation_type,
                                         LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E,
                                         size, (linear_manager_context_t)region_id,
                                         FALSE, &linear_handle);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        if (utils_err == SX_UTILS_STATUS_NO_RESOURCES) {
            SX_LOG(SX_LOG_DEBUG, "No resources available to add block to linear manager\n");
        } else {
            SX_LOG(SX_LOG_ERROR, "Failed to add block to linear manager, "
                   "error: %s\n", SX_UTILS_STATUS_MSG(utils_err));
        }
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

    *handle = linear_handle;

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t atcam_erps_linear_manager_block_delete(atcam_erps_linear_manager_handle_t handle)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();
    utils_err = linear_manager_block_delete(g_erp_linear_manager_db,
                                            handle, FALSE);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to delete block from erp linear manager , "
               "error: %s\n", SX_UTILS_STATUS_MSG(utils_err));
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t atcam_erps_linear_manager_handle_lock(atcam_erps_linear_manager_handle_t        handle,
                                                  atcam_erps_linear_manager_index_t        *index_p,
                                                  atcam_erps_linear_manager_block_length_t *size_p)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_utils_status_t                        utils_err = SX_UTILS_STATUS_SUCCESS;
    atcam_erps_linear_manager_block_length_t array_size = MAX_BLOCK_SIZE;
    atcam_erps_linear_manager_index_t        index_array[MAX_BLOCK_SIZE];

    SX_LOG_ENTER();

    utils_err = linear_manager_handle_lock(g_erp_linear_manager_db,
                                           handle, index_array, &array_size);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to lock handle in linear manager , "
               "error: %s\n", SX_UTILS_STATUS_MSG(utils_err));
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }
    if (size_p) {
        *size_p = array_size;
    }


    if (index_array[0] >= ERP_MEM_SIZE) {
        SX_LOG(SX_LOG_ERROR, "index %u given by linear manager is out of range %u\n", index_array[0], ERP_MEM_SIZE);
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (index_p) {
        /* Get the index according to the ISSU mode*/
        *index_p = index_array[0] + g_erps_linear_base_index;
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t atcam_erps_linear_manager_handle_release(atcam_erps_linear_manager_handle_t handle)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    utils_err = linear_manager_handle_release(g_erp_linear_manager_db, handle);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to release lock handle in linear manager , "
               "error: %s\n", SX_UTILS_STATUS_MSG(utils_err));
        err = sx_utils_status_to_sx_status(utils_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}
