/*
 * Copyright (C) 2017-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_ERPS_RECALC_H__
#define __ATCAM_ERPS_RECALC_H__

#include "sx/sdk/sx_types.h"
#include "atcam/common/atcam_utils.h"
#include "atcam/common/atcam_types.h"

/* The number of cycles (iterating over all regions) we'll wait
 * until we optimized a region what was recently modified.
 */
#define MIN_QUIET_CYCLES (2)

typedef sx_status_t (*atcam_erps_recalc_shadow_region_cb)(const sx_acl_region_id_t region_id,
                                                          sx_acl_region_id_t      *shadow_region_id);

/**
 * Initializes Erps recalculation Module.
 *
 * @param[in]  num_of_regions          - The total number of regions that should be supported.
 * @param[in]  shadow_region_create_cb - Function to be called when a shadow region needs to be created.
 * @param[in]  shadow_region_remove_cb - Function to be called to destroy the shadow region.
 *
 * @return
 *    SX_STATUS_NO_MEMORY - if there's not enough memory to allocate the requested number of regions
 *    SX_STATUS_SUCCESS        - if operation has finished successfully.
 */
sx_status_t atcam_erps_recalc_init(const uint32_t                num_of_regions,
                                   atcam_shadow_region_create_cb shadow_region_create_cb,
                                   atcam_shadow_region_remove_cb shadow_region_remove_cb);

/**
 * De-Initializes Erps recalculation Module.
 *
 * @param[in]  forced_deinit - If TRUE, deinitialize the module even if some resources are in use, otherwise function will fail.
 *
 * @return
 *    SX_STATUS_RESOURCE_IN_USE - If some regions are still not deleted (and not forced_deinit)
 *    SX_STATUS_SUCCESS         - if operation has finished successfully.
 */
sx_status_t atcam_erps_recalc_deinit(const boolean_t forced_deinit);

/**
 * Allocates a new region. This function should be called whenever a new region is allocated in the system.
 * It will allow the region to be examined if a better erp allocation is possible.
 *
 * @param[in]  region_id - The id of the region.
 *
 * @return
 *    SX_STATUS_PARAM_EXCEEDS_RANGE  - If region id exceeds range (more than the number of regions)
 *    SX_STATUS_ENTRY_ALREADY_EXISTS - If region was previously allocated
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_recalc_region_allocate(const sx_atcam_region_id_t region_id);

/**
 * Destroys an existing region. This function should be called whenever a region is destroyed
 * in order to remove it from the list of regions to consider for erp optimization.
 *
 * @param[in]  region_id - The id of the region.
 *
 * @return
 *    SX_STATUS_PARAM_EXCEEDS_RANGE  - If region id exceeds range (more than the number of regions)
 *    SX_STATUS_ENTRY_NOT_FOUND      - If region wasn't previously allocated
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_recalc_region_destroy(const sx_atcam_region_id_t region_id);

/**
 * Notify this module that a rule in the specified region is going to be changed.
 * NOTE: Must be called before the rule actually changes.
 * Important in to complete the in progress optimization before the rule actually changes
 * and to mark the region as needing optimization.
 *
 * @param[in]  region_id - The id of the region.
 *
 * @return
 *    SX_STATUS_PARAM_EXCEEDS_RANGE  - If region id exceeds range (more than the number of regions)
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_recalc_rule_change_notify(const sx_atcam_region_id_t region_id);

/**
 * This function is called after a rule is inserted if:
 * 1. a new ERP created as a result of the insertion
 * 2. the rule was inserted to the CTCAM
 * the optimization runs if the new ERP created crossed a predefined threshold or if the CTCAM is overloaded.
 *
 * @param[in]  region_id - the id of the region.
 *
 * @param[in]  erp_count - the number of ERPs in the region.
 *
 * @return
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_recalc_trigger_region_optimization(const sx_atcam_region_id_t region_id, uint32_t erp_count);

/**
 * This function should be called by a timer to advance the erp optimization state machine.
 *
 * @param[in]  complete_whole_region - Whether to complete a whole region's optimization in this call (TRUE)
 *                                     or allow the optimization to be performed over several calls (FALSE).
 * @param[out] is_complete -           Return if the optimization of all regions was done for this round (TRUE)
 *                                     or there is a need for more calls to this function (FALSE).
 *
 * @return
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_recalc_timer_execute(const boolean_t complete_whole_region, boolean_t *is_complete);


/**
 * This function should be used to enable/disable the erp recalculation module.
 *
 * @param[in]  enable - Whether to enable (TRUE) or disable (FALSE) the erp recalculation.
 *
 * @return
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_recalc_enable_set(const boolean_t enable);

/**
 * This function should be used to get the current enable/disable state of the erp recalculation module.
 *
 * @param[out]  enable - Enabled (TRUE) or Disabled (FALSE).
 *
 * @return
 *    SX_STATUS_SUCCESS              - if operation has finished successfully.
 */
sx_status_t atcam_erps_recalc_enable_get(boolean_t *enable);

/**
 * NOTE: Debug Only! - Executes optimization algorithm on a region and return the number of new erps.
 *
 * @param[in]  region_id        - The region for which to optimize the erps.
 * @param[in]  next_gen         - if 0 then run basic algorithm without adding alternative masks,
 *                                otherwise run the next-gen recalculation.
 * @param[out] erp_count        - The number of erps this region can be optimized to.
 * @param[out] mask_count       - The total number of masks in this region after adding alternative masks.
 *
 * @return
 *             SX_STATUS_SUCCESS - if operation was successful
 */
sx_status_t atcam_erps_recalc_test_erp_calculation(const sx_acl_region_id_t region_id,
                                                   boolean_t                next_gen,
                                                   uint32_t                *erp_count,
                                                   uint32_t                *mask_count);


#endif /* __ATCAM_ERPS_RECALC_H__ */
