/*
 * Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "sx/utils/sx_utils_status.h"
#include "sx/utils/fib_hash.h"
#include "sx/sdk/sx_status_convertor.h"
#include "complib/cl_map.h"
#include "atcam/atcam_erps_manager/atcam_erps_db.h"
#include "atcam/atcam_rules_manager/atcam_rules_db.h"
#include "atcam/atcam_regions_manager/atcam_regions_db.h"
#include "atcam/common/atcam_utils.h"
#include "sx/utils/hashtable.h"
#include <complib/cl_dbg.h>

/************************************************
 *  Global variables
 ***********************************************/
/************************************************
 *  Local definitions
 ***********************************************/
#define ERPS_POOL_MIN_SIZE  0
#define ERPS_POOL_GROW_SIZE 32

#define CTCAMS_POOL_MIN_SIZE  0
#define CTCAMS_POOL_GROW_SIZE 8

#define ERPS_PV_POOL_MIN_SIZE  0
#define ERPS_PV_POOL_MAX_SIZE  0    /* Unlimited */
#define ERPS_PV_POOL_GROW_SIZE 64

/* Note if the hash size is increased there is a need to increase the polynomial. */
#define ERP_BAD_COLLISION_HASH_BITS (13)
#define ERP_BAD_COLLISION_HASH_SIZE (1 << ERP_BAD_COLLISION_HASH_BITS) /* 8192 */

typedef struct atcam_erps_db_ctcam_entry {
    cl_pool_item_t        pool_item;
    cl_map_item_t         map_item;
    atcam_erps_db_ctcam_t data;
} atcam_erps_db_ctcam_entry_t;

typedef struct atcam_erps_db_erp_entry {
    cl_pool_item_t      pool_item;
    cl_map_item_t       map_item;
    atcam_erps_db_erp_t data;
} atcam_erps_db_erp_entry_t;

typedef struct atcam_bad_collision_hash_key {
    sx_atcam_region_id_t region_id;
    uint16_t             erp_id;
    sx_atcam_key_value_t erp_key_value;           /* The key value after the erp mask is set */
} atcam_bad_collision_hash_key_t;

/************************************************
 *  Local function declarations
 ***********************************************/

/**
 * This function is used as the initialization of the ctcam_pool entry
 */
static cl_status_t __erps_db_ctcam_pool_init(void *const             p_object,
                                             void                   *context,
                                             cl_pool_item_t ** const pp_pool_item);

/**
 * This function is used as the initialization of the erps_pool entry
 */
static cl_status_t __erps_db_erps_pool_init(void *const             p_object,
                                            void                   *context,
                                            cl_pool_item_t ** const pp_pool_item);

/**
 * This function is used as the initialization of the erps_prune db entry
 */
static cl_status_t __erps_db_erps_pdb_pool_init(void *const             p_object,
                                                void                   *context,
                                                cl_pool_item_t ** const pp_pool_item);


/*
 * Compares between 2 flex-map keys. Used to determine prune calculations.
 */
static int __atcam_erps_db_masked_rules_compare_func(IN const void *const p_key1,
                                                     IN const void *const p_key2);

/**
 * Sets the params for a new region.
 */
static sx_status_t __atcam_erps_db_erp_params_set(const atcam_erps_db_erp_params_t *params,
                                                  atcam_erps_db_erp_t              *erp);

/**
 * See atcam_erps_db_check_erps_ids.
 * The additional erp_to_ignore param lets us use the same function when allocating a new eRP
 */
static sx_status_t __atcam_erps_db_check_erps_ids(const sx_atcam_region_id_t region_id,
                                                  const sx_atcam_erp_id_t   *erps_ids,
                                                  const uint8_t              valid_erps_num,
                                                  const sx_atcam_erp_id_t    erp_to_ignore);

/**
 * Initializes prune db for a given eRP with regards to another eRP of that region
 */
static sx_status_t __atcam_erps_db_erp_init_single_prune_db(atcam_erps_db_erp_t *erp,
                                                            sx_atcam_erp_id_t    other_erp_id);

/**
 * De-Initializes prune db for a given eRP with regards to another eRP of that region
 */
static sx_status_t __atcam_erps_db_erp_deinit_single_prune_db(atcam_erps_db_erp_t *const erp,
                                                              sx_atcam_erp_id_t          other_erp_id);

/**
 * Checks for a bad collision in a specific bucket
 */
static sx_status_t __atcam_erps_db_bad_collision_bucket_check(const atcam_rules_db_rule_entry_t *rule,
                                                              const cl_qlist_t                  *bucket,
                                                              uint32_t                          *bad_collision_count_p,
                                                              uint32_t                          *exact_match_count_p);

/**
 * The following functions are used in the hash table use to detect bad collision entries
 */
static uint32_t ____erps_db_bad_collision_hash_func(cl_list_item_t* entry);
static void ____erps_db_bad_collision_free_func(cl_list_item_t* entry);
static cl_status_t ____erps_db_bad_collision_cmp_func(cl_list_item_t* entry1, cl_list_item_t* entry2);

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static cl_qpool_t                             ctcams_pool; /* Physically, there is one c-tcam, but logically, it's separated per region */
static cl_qpool_t                             erps_pool;
static cl_qpool_t                             erps_pv_entries_pool;
static cl_qmap_t                              erps_db;
static cl_qmap_t                              ctcams_db;
static hashtable_t                           *bad_collision_ht; /* A hash table used to detect bad collision between rules in the same erp */
static hashtable_ops_t                        erp_bad_collision_hashtable_ops = {
    ERP_BAD_COLLISION_HASH_SIZE,            /* num_of_buckets */
    ____erps_db_bad_collision_hash_func,    /* hash_func */
    ____erps_db_bad_collision_free_func,    /* free_func - not used */
    ____erps_db_bad_collision_cmp_func,     /* cmp_func - not used */
};
static atcam_erps_db_bad_collision_counters_t bad_collision_counters;
/************************************************
 *  Functions implementations
 ***********************************************/

sx_status_t atcam_erps_db_init(const uint32_t num_of_regions, const uint32_t num_of_erps)
{
    cl_status_t cl_status = CL_SUCCESS;
    boolean_t   is_ctcam_pool_inited = FALSE, is_erps_pool_inited = FALSE, is_erps_pv_pool_inited = FALSE;

    SX_LOG_ENTER();


    cl_status = CL_QPOOL_INIT(&ctcams_pool, CTCAMS_POOL_MIN_SIZE, num_of_regions, CTCAMS_POOL_GROW_SIZE,
                              sizeof(atcam_erps_db_ctcam_entry_t), __erps_db_ctcam_pool_init, NULL, NULL);
    if (SX_UTILS_CHECK_FAIL(cl_status)) {
        SX_LOG_ERR("Failed to init the ctcams pool. err: %s.\n", CL_STATUS_MSG(cl_status));
        goto mem_error;
    }
    is_ctcam_pool_inited = TRUE;

    cl_status = CL_QPOOL_INIT(&erps_pool, ERPS_POOL_MIN_SIZE, num_of_erps, ERPS_POOL_GROW_SIZE,
                              sizeof(atcam_erps_db_erp_entry_t), __erps_db_erps_pool_init, NULL, NULL);
    if (SX_UTILS_CHECK_FAIL(cl_status)) {
        SX_LOG_ERR("Failed to init the erps pool. err: %s.\n", CL_STATUS_MSG(cl_status));
        goto mem_error;
    }
    is_erps_pool_inited = TRUE;

    cl_status = CL_QPOOL_INIT(&erps_pv_entries_pool,
                              ERPS_PV_POOL_MIN_SIZE, ERPS_PV_POOL_MAX_SIZE, ERPS_PV_POOL_GROW_SIZE,
                              sizeof(atcam_erps_db_prune_db_entry_t), __erps_db_erps_pdb_pool_init, NULL, NULL);
    if (SX_UTILS_CHECK_FAIL(cl_status)) {
        SX_LOG_ERR("Failed to init the erps prune db entries pool. err: %s.\n", CL_STATUS_MSG(cl_status));
        goto mem_error;
    }
    is_erps_pv_pool_inited = TRUE;

    bad_collision_ht = hashtable_alloc(&erp_bad_collision_hashtable_ops);
    if (bad_collision_ht == NULL) {
        SX_LOG_ERR("Failed to init the bad collision hash table.\n");
        goto mem_error;
    }
    SX_MEM_CLR(bad_collision_counters);

    cl_qmap_init(&ctcams_db);
    cl_qmap_init(&erps_db);

    goto out;

mem_error:
    if (is_ctcam_pool_inited) {
        CL_QPOOL_DESTROY(&ctcams_pool);
    }
    if (is_erps_pool_inited) {
        CL_QPOOL_DESTROY(&erps_pool);
    }
    if (is_erps_pv_pool_inited) {
        CL_QPOOL_DESTROY(&erps_pv_entries_pool);
    }
out:
    SX_LOG_EXIT();
    return cl_status_to_sx_status(cl_status);
}

sx_status_t atcam_erps_db_deinit(const boolean_t forced_deinit)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t               *it = NULL;
    atcam_erps_db_erp_entry_t   *erp_entry = NULL;
    atcam_erps_db_ctcam_entry_t *ctcam_entry = NULL;

    SX_LOG_ENTER();

    if (!forced_deinit) {
        if (!cl_is_qmap_empty(&erps_db)) {
            sx_status = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("Not all eRPs were explicitly freed before.\n");
            goto out;
        }

        if (!cl_is_qmap_empty(&ctcams_db)) {
            sx_status = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("Not all rules were explicitly freed from ctcam before.\n");
            goto out;
        }
    }

    it = cl_qmap_head(&ctcams_db);
    while (it != cl_qmap_end(&ctcams_db)) {
        ctcam_entry = PARENT_STRUCT(it, atcam_erps_db_ctcam_entry_t, map_item);
        it = cl_qmap_next(it);
        cl_qpool_put(&ctcams_pool, &ctcam_entry->pool_item);
    }

    CL_QPOOL_DESTROY(&ctcams_pool);


    /* In order to destroy the pool, we first return all elements to it (eRPS) */
    /* We will only to that if we are forced to deinit, in which case, it is ok the eRP weren't freed explicitly. */
    it = cl_qmap_head(&erps_db);
    while (it != cl_qmap_end(&erps_db)) {
        erp_entry = PARENT_STRUCT(it, atcam_erps_db_erp_entry_t, map_item);
        it = cl_qmap_next(it);
        cl_qpool_put(&erps_pool, &erp_entry->pool_item);
    }

    hashtable_free(bad_collision_ht);
    bad_collision_ht = NULL;

    CL_QPOOL_DESTROY(&erps_pool);
    CL_QPOOL_DESTROY(&erps_pv_entries_pool);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_erp_allocate(const sx_atcam_region_id_t        region_id,
                                       const sx_atcam_erp_id_t           erp_id,
                                       const atcam_erps_db_erp_params_t *params,
                                       atcam_erps_db_erp_t             **erp)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_entry_t *new_erp_entry = NULL;
    uint64_t                   new_erp_key;

    SX_LOG_ENTER();

    if (erp_id >= SX_ATCAM_ERPS_PER_REGION) {
        SX_LOG_ERR("erp_id out of range.\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* If a similar eRP was already requested to be allocated, this is an error */
    new_erp_key = atcam_utils_build_erp_key_from_id(region_id, erp_id);
    if (cl_qmap_contains(&erps_db, new_erp_key)) {
        SX_LOG_ERR("erp_id %d was already allocated for region %d\n", erp_id, region_id);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    /* we allocate new rule from pool */
    new_erp_entry = (atcam_erps_db_erp_entry_t*)cl_qpool_get(&erps_pool);
    if (!new_erp_entry) {
        SX_LOG_DBG("Error when allocating new erp from pool\n");
        sx_status = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    new_erp_entry->data.region_id = region_id;
    new_erp_entry->data.erp_id = erp_id;
    sx_status = __atcam_erps_db_erp_params_set(params, &new_erp_entry->data);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("When setting params of new eRP %d in region %d\n", erp_id, region_id);
        goto error;
    }

    /* If got here - all params for new region are set properly, and we can store it safely */
    new_erp_entry->data.allocated = TRUE;
    cl_qmap_insert(&erps_db, new_erp_key, &new_erp_entry->map_item);

    if (erp) {
        *erp = &(new_erp_entry->data);
    }

    goto out;

error:
    /* return to pool */
    cl_qpool_put(&erps_pool, &new_erp_entry->pool_item);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_erp_deallocate(const sx_atcam_region_id_t region_id, const sx_atcam_erp_id_t erp_id)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t       *erp = NULL;
    atcam_erps_db_erp_entry_t *erp_entry = NULL;
    uint64_t                   erp_key;
    uint32_t                   i = 0;

    SX_LOG_ENTER();

    sx_status = atcam_erps_db_erp_get(region_id, erp_id, &erp);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Error when getting erp with id %d\n", erp_id);
        goto out;
    }

    /* If this eRP still has some rules not deleted - we don't allow its deletion. */
    if (!cl_is_qmap_empty(&erp->rules)) {
        SX_LOG_ERR("When deleting eRP %d, not all rules were deleted from that eRP.\n", erp_id);
        sx_status = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* We delete the prune map of this erp.
     * Note that prune maps actually store references to actual rules in DB;
     * so we DON'T free those rules */
    for (i = 0; i < SX_ATCAM_ERPS_PER_REGION; ++i) {
        if (erp->prune_maps[i].allocated) {
            sx_status = __atcam_erps_db_erp_deinit_single_prune_db(erp, i);
            if (SX_STATUS_SUCCESS != sx_status) {
                SX_LOG_ERR("When de-initializing prune map %d for erp %d if region %d\n", i, erp_id, region_id);
                sx_status = SX_STATUS_ERROR;
                goto out;
            }
        }
    }

    /* Delete this erp mask */
    memset(&(erp->mask), 0, sizeof(sx_atcam_key_mask_t));
    erp->allocated = FALSE;

    /* Remove from map */
    erp_key = atcam_utils_build_erp_key_from_id(region_id, erp_id);
    cl_qmap_remove(&erps_db, erp_key);

    /* return to pool */
    erp_entry = PARENT_STRUCT(erp, atcam_erps_db_erp_entry_t, data);
    cl_qpool_put(&erps_pool, &erp_entry->pool_item);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_erp_get(const sx_atcam_region_id_t region_id,
                                  const sx_atcam_erp_id_t    erp_id,
                                  atcam_erps_db_erp_t      **erp)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t             *erp_map_item = NULL;
    atcam_erps_db_erp_entry_t *erp_entry = NULL;
    uint64_t                   erp_key;

    SX_LOG_ENTER();

    if (erp_id >= SX_ATCAM_ERPS_PER_REGION) {
        SX_LOG_ERR("erp_id out of range.\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    erp_key = atcam_utils_build_erp_key_from_id(region_id, erp_id);
    erp_map_item = cl_qmap_get(&erps_db, erp_key);
    if (erp_map_item == cl_qmap_end(&erps_db)) {
        SX_LOG_DBG("eRP %d for region %d does not exist.\n", erp_id, region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    erp_entry = PARENT_STRUCT(erp_map_item, atcam_erps_db_erp_entry_t, map_item);
    /* If, for some reason, entry exists, but wasn't properly allocated, this is considered an error */
    if (!erp_entry->data.allocated) {
        SX_LOG_ERR("trying to get non-allocated eRP %d\n", erp_entry->data.erp_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    /* Resolve the entry only if requested */
    if (erp) {
        *erp = &(erp_entry->data);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_erp_add_rule(const sx_atcam_region_id_t   region_id,
                                       const sx_atcam_erp_id_t      erp_id,
                                       const atcam_rules_db_rule_t *rule)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t         *erp = NULL;
    atcam_rules_db_rule_entry_t *rule_entry = NULL;

    SX_LOG_ENTER();

    if (!rule) {
        SX_LOG_ERR("When adding rule to eRP %d of region %d - NULL pointer was given\n", erp_id, region_id);
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    sx_status = atcam_erps_db_erp_get(region_id, erp_id, &erp);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Error when getting erp with id %d, of region %d\n", erp_id, region_id);
        goto out;
    }

    if (cl_qmap_contains(&erp->rules, rule->rule_id)) {
        SX_LOG_ERR("Rule id 0x%" PRIx64 ", offset %d, was already inserted to erp %d of region %d\n",
                   rule->rule_id,
                   rule->offset,
                   erp_id,
                   region_id);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    rule_entry = PARENT_STRUCT(rule, atcam_rules_db_rule_entry_t, data);
    if (cl_qmap_insert(&erp->rules, rule->rule_id, &(rule_entry->per_erp_ctcam_mi)) == NULL) {
        SX_LOG_ERR("When inserting rule id 0x%" PRIx64 ", offset %d, to erp %d of region %d - no more memory.\n",
                   rule->rule_id,
                   rule->offset,
                   erp_id,
                   region_id);
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_erp_delete_rule(const sx_atcam_region_id_t region_id,
                                          const sx_atcam_erp_id_t    erp_id,
                                          const sx_atcam_rule_id_t   rule_id)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t *erp = NULL;

    SX_LOG_ENTER();

    sx_status = atcam_erps_db_erp_get(region_id, erp_id, &erp);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Error when getting erp with id %d for region %d\n", erp_id, region_id);
        goto out;
    }

    if (cl_qmap_remove(&erp->rules, rule_id) == cl_qmap_end(&erp->rules)) {
        SX_LOG_ERR("while deleting rule id 0x%" PRIx64 " from erp %d of region %d - entry not found\n",
                   rule_id,
                   erp_id,
                   region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_is_erp_empty(const sx_atcam_region_id_t region_id,
                                       const sx_atcam_erp_id_t    erp_id,
                                       boolean_t                 *is_empty)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t *erp = NULL;

    SX_LOG_ENTER();

    if (!is_empty) {
        SX_LOG_ERR("Null param was given\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    sx_status = atcam_erps_db_erp_get(region_id, erp_id, &erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get erp %d for region %d\n", erp_id, region_id);
        goto out;
    }

    *is_empty = cl_is_qmap_empty(&erp->rules);

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_db_ctcam_allocate(const sx_atcam_region_id_t region_id, atcam_erps_db_ctcam_t **ctcam)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_ctcam_entry_t *new_ctcam_entry = NULL;
    uint64_t                     new_ctcam_key;

    SX_LOG_ENTER();

    /* If a similar ctcam was already requested to be allocated, this is an error */
    new_ctcam_key = region_id;
    if (cl_qmap_contains(&ctcams_db, new_ctcam_key)) {
        SX_LOG_ERR("ctcam-db was already allocated for region %d\n", region_id);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    /* we allocate ctcam object from pool */
    new_ctcam_entry = (atcam_erps_db_ctcam_entry_t*)cl_qpool_get(&ctcams_pool);
    if (!new_ctcam_entry) {
        /* Unlike erp entry - there's no turning back from this - thus an error */
        SX_LOG_ERR("Error when allocating new ctcam entry from pool\n");
        sx_status = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    new_ctcam_entry->data.region_id = region_id;
    cl_qmap_init(&(new_ctcam_entry->data.rules));
    new_ctcam_entry->data.allocated = TRUE;
    cl_qmap_insert(&ctcams_db, new_ctcam_key, &new_ctcam_entry->map_item);

    if (ctcam) {
        *ctcam = &(new_ctcam_entry->data);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_ctcam_deallocate(const sx_atcam_region_id_t region_id)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_ctcam_t       *ctcam = NULL;
    atcam_erps_db_ctcam_entry_t *ctcam_entry = NULL;
    uint64_t                     ctcam_key;

    SX_LOG_ENTER();

    sx_status = atcam_erps_db_ctcam_get(region_id, &ctcam);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when getting ctcam object for region %d\n", region_id);
        goto out;
    }

    /* If this region still has some rules on its ctcam - we don't allow its deletion. */
    if (!cl_is_qmap_empty(&ctcam->rules)) {
        SX_LOG_ERR("When deleting ctcam from region  %d, not all rules were deleted before\n", region_id);
        sx_status = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    ctcam->allocated = FALSE;
    /* Remove from map */
    ctcam_key = region_id;
    cl_qmap_remove(&ctcams_db, ctcam_key);

    /* return to pool */
    ctcam_entry = PARENT_STRUCT(ctcam, atcam_erps_db_ctcam_entry_t, data);
    cl_qpool_put(&ctcams_pool, &ctcam_entry->pool_item);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_ctcam_get(const sx_atcam_region_id_t region_id, atcam_erps_db_ctcam_t **ctcam)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    cl_map_item_t               *ctcam_map_item = NULL;
    atcam_erps_db_ctcam_entry_t *ctcam_entry = NULL;
    uint64_t                     ctcam_key;

    SX_LOG_ENTER();
    ctcam_key = region_id;
    ctcam_map_item = cl_qmap_get(&ctcams_db, ctcam_key);
    if (ctcam_map_item == cl_qmap_end(&ctcams_db)) {
        SX_LOG_DBG("ctcam for region %d does not exist.\n", region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    ctcam_entry = PARENT_STRUCT(ctcam_map_item, atcam_erps_db_ctcam_entry_t, map_item);
    /* If, for some reason, entry exists, but wasn't properly allocated, this is considered an error */
    if (!ctcam_entry->data.allocated) {
        SX_LOG_ERR("trying to get non-allocated ctcam for region %d\n", region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    /* Resolve the entry only if requested */
    if (ctcam) {
        *ctcam = &(ctcam_entry->data);
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_is_ctcam_empty(const sx_atcam_region_id_t region_id, boolean_t *is_empty)
{
    sx_status_t            sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_ctcam_t *ctcam = NULL;

    SX_LOG_ENTER();

    sx_status = atcam_erps_db_ctcam_get(region_id, &ctcam);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get ctcam for region %d\n", region_id);
        goto out;
    }

    *is_empty = cl_is_qmap_empty(&ctcam->rules);

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_db_has_ctcam(const sx_atcam_region_id_t region_id, boolean_t *has_ctcam)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();


    *has_ctcam = cl_qmap_get(&ctcams_db, region_id) != cl_qmap_end(&ctcams_db);

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_ctcam_add_rule(const sx_atcam_region_id_t region_id, const atcam_rules_db_rule_t *rule)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_ctcam_t       *ctcam = NULL;
    atcam_rules_db_rule_entry_t *rule_entry = NULL;

    SX_LOG_ENTER();
    sx_status = atcam_erps_db_ctcam_get(region_id, &ctcam);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when getting ctcam object of region %d\n", region_id);
        goto out;
    }

    if (cl_qmap_contains(&ctcam->rules, rule->rule_id)) {
        SX_LOG_ERR("Rule id 0x%" PRIx64 " was already inserted to ctcam of region %d\n", rule->rule_id, region_id);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    rule_entry = PARENT_STRUCT(rule, atcam_rules_db_rule_entry_t, data);
    if (cl_qmap_insert(&ctcam->rules, rule->rule_id, &(rule_entry->per_erp_ctcam_mi)) == NULL) {
        SX_LOG_ERR("When inserting rule id 0x%" PRIx64 ", offset %d, to ctcam of region %d - no more memory.\n",
                   rule->rule_id,
                   rule->offset,
                   region_id);
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_ctcam_delete_rule(const sx_atcam_region_id_t region_id, const sx_atcam_rule_id_t rule_id)
{
    sx_status_t            sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_ctcam_t *ctcam = NULL;

    SX_LOG_ENTER();

    sx_status = atcam_erps_db_ctcam_get(region_id, &ctcam);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when getting ctcam object of region %d\n", region_id);
        goto out;
    }

    if (cl_qmap_remove(&ctcam->rules, rule_id) == cl_qmap_end(&ctcam->rules)) {
        SX_LOG_ERR("while deleting rule id 0x%" PRIx64 " from ctcam of region %d - entry not found\n",
                   rule_id,
                   region_id);
        sx_status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_erp_add_prune_map(const sx_atcam_region_id_t region_id,
                                            const sx_atcam_erp_id_t    erp_id,
                                            const sx_atcam_erp_id_t    other_erp_id)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t *erp = NULL;

    SX_LOG_ENTER();

    sx_status = atcam_erps_db_erp_get(region_id, erp_id, &erp);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Error when getting erp with id %d of region %d\n", erp_id, region_id);
        goto out;
    }


    /* All validations and checks are done next */
    sx_status = __atcam_erps_db_erp_init_single_prune_db(erp, other_erp_id);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Erp When initializing prune map of indices (%d, %d)\n", erp->erp_id, other_erp_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_erp_remove_prune_map(const sx_atcam_region_id_t region_id,
                                               const sx_atcam_erp_id_t    erp_id,
                                               const sx_atcam_erp_id_t    other_erp_id)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t *erp = NULL;

    SX_LOG_ENTER();

    sx_status = atcam_erps_db_erp_get(region_id, erp_id, &erp);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Error when getting erp with id %d of region %d\n", erp_id, region_id);
        goto out;
    }

    sx_status = __atcam_erps_db_erp_deinit_single_prune_db(erp, other_erp_id);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Erp When de-initializing prune map of indices (%d, %d)\n", erp->erp_id, other_erp_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_db_check_erps_ids(const sx_atcam_region_id_t region_id,
                                         const sx_atcam_erp_id_t   *erps_ids,
                                         const uint8_t              valid_erps_num)
{
    /* If called from an outside module - then it should only be used for allocated set of eRPS */
    return __atcam_erps_db_check_erps_ids(region_id, erps_ids, valid_erps_num, ATCAM_INVALID_ERP_ID);
}


sx_status_t atcam_erps_db_prune_entry_allocate(atcam_erps_db_prune_db_t        *prune_map,
                                               const sx_atcam_key_value_t      *intersected_value,
                                               atcam_erps_db_prune_db_entry_t **prune_db_entry)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_prune_db_entry_t *new_prune_db_entry = NULL;

    SX_LOG_ENTER();


    if (!prune_map->allocated) {
        SX_LOG_ERR("Prune db of erps (m: %d,s: %d) wasn't properly allocated before\n",
                   prune_map->main_id,
                   prune_map->sec_id);
        goto out;
    }

    /* we allocate new rule from pool */
    new_prune_db_entry = (atcam_erps_db_prune_db_entry_t*)cl_qpool_get(&erps_pv_entries_pool);
    if (!new_prune_db_entry) {
        SX_LOG_ERR("Error when allocating new prune db entry from pool\n");
        sx_status = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    memcpy(&new_prune_db_entry->key, intersected_value, sizeof(new_prune_db_entry->key));

    /* Lists are already initialized in init-func */
    cl_fmap_insert(&prune_map->rules_refs, (void*)&new_prune_db_entry->key, &new_prune_db_entry->fmap_item);

    if (prune_db_entry) {
        *prune_db_entry = new_prune_db_entry;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_db_prune_entry_deallocate(atcam_erps_db_prune_db_t       *prune_map,
                                                 atcam_erps_db_prune_db_entry_t *prune_db_entry)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!prune_map->allocated) {
        SX_LOG_ERR("Prune db of erps (m: %d,s: %d) wasn't properly allocated before\n",
                   prune_map->main_id,
                   prune_map->sec_id);
        goto out;
    }

    if (!cl_is_qmap_empty(&(prune_db_entry->current_erp_rules))) {
        SX_LOG_ERR(
            "When deleting prune_db entry of erps: (m: %d, s: %d) not all rules from erp %d were deleted before\n",
            prune_map->main_id,
            prune_map->sec_id,
            prune_map->main_id);
        sx_status = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    if (!cl_is_qmap_empty(&(prune_db_entry->other_erp_rules))) {
        SX_LOG_ERR(
            "When deleting prune_db entry of erps: (m: %d, s: %d) not all rules from erp %d were deleted before\n",
            prune_map->main_id,
            prune_map->sec_id,
            prune_map->sec_id);
        sx_status = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    cl_fmap_remove_item(&prune_map->rules_refs, &prune_db_entry->fmap_item);
    /* return to pool */
    cl_qpool_put(&erps_pv_entries_pool, &prune_db_entry->pool_item);

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_bad_collision_check(atcam_rules_db_rule_t *rule,
                                              uint32_t              *bad_collision_count_p,
                                              uint32_t              *exact_match_count_p)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    cl_status_t                  cl_status = CL_SUCCESS;
    cl_qlist_t                  *bucket = NULL;
    atcam_rules_db_rule_entry_t *rule_entry = NULL;
    sx_atcam_key_blocks_size_t   key_blocks_size = SX_ATCAM_ONE_KEY_BLOCK;

    SX_LOG_ENTER();

    sx_status = atcam_regions_db_key_blocks_size_get(rule->region_id, &key_blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get key block size for region [%u].\n", rule->region_id);
        goto out;
    }

    rule_entry = PARENT_STRUCT(rule, atcam_rules_db_rule_entry_t, data);
    cl_status = hashtable_bucket_lookup(bad_collision_ht, &(rule_entry->bad_collision_li), &bucket);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Failed to get hash bucket for rule add. Region id %u, Erp id %u.\n", rule->region_id,
                   rule->erp_id);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sx_status = __atcam_erps_db_bad_collision_bucket_check(rule_entry,
                                                           bucket,
                                                           bad_collision_count_p,
                                                           exact_match_count_p);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when checking bad collision bucket. Region id %u, Erp id %u.\n",
                   rule->region_id,
                   rule->erp_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_bad_collision_add_rule(atcam_rules_db_rule_t *rule)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    cl_status_t                  cl_status = CL_SUCCESS;
    cl_qlist_t                  *bucket = NULL;
    atcam_rules_db_rule_entry_t *rule_entry = NULL;
    sx_atcam_key_blocks_size_t   key_blocks_size = SX_ATCAM_ONE_KEY_BLOCK;
    uint32_t                     bad_collision_count = 0;
    uint32_t                     exact_match_count = 0;
    uint32_t                    *counters_p = NULL;

    SX_LOG_ENTER();


    sx_status = atcam_regions_db_key_blocks_size_get(rule->region_id, &key_blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get key block size for region [%u].\n", rule->region_id);
        goto out;
    }

    rule_entry = PARENT_STRUCT(rule, atcam_rules_db_rule_entry_t, data);
    cl_status = hashtable_bucket_lookup(bad_collision_ht, &(rule_entry->bad_collision_li), &bucket);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Failed to get hash bucket for rule add. Region id %u, Erp id %u.\n", rule->region_id,
                   rule->erp_id);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    /* Check how many collisions it creates so to determine which collision we have created */
    sx_status = __atcam_erps_db_bad_collision_bucket_check(rule_entry,
                                                           bucket,
                                                           &bad_collision_count,
                                                           &exact_match_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when checking bad collision bucket. Region id %u, Erp id %u.\n",
                   rule->region_id,
                   rule->erp_id);
        goto out;
    }
    /* Add the new rule to the bucket's list */
    cl_qlist_insert_tail(bucket, &rule_entry->bad_collision_li);

    /* Update collision db */
    counters_p = (key_blocks_size == SX_ATCAM_ONE_KEY_BLOCK) ? \
                 bad_collision_counters.single_bad_collision_count : bad_collision_counters.double_bad_collision_count;
    /* We have counter for 0 to 3 collisions and counter for more than 3 collisions single & double */
    if (bad_collision_count == 0) {
        counters_p[0]++;
    } else if (bad_collision_count < BAD_COLLISION_COUNTERS_NUM) {
        counters_p[bad_collision_count] += bad_collision_count + 1;
        counters_p[bad_collision_count - 1] -= bad_collision_count;
    } else {
        counters_p[BAD_COLLISION_COUNTERS_NUM - 1]++;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


sx_status_t atcam_erps_db_bad_collision_remove_rule(atcam_rules_db_rule_t* rule)
{
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    cl_status_t                  cl_status = CL_SUCCESS;
    cl_qlist_t                  *bucket = NULL;
    atcam_rules_db_rule_entry_t *rule_entry = NULL;
    sx_atcam_key_blocks_size_t   key_blocks_size = SX_ATCAM_ONE_KEY_BLOCK;
    uint32_t                     bad_collision_count = 0;
    uint32_t                     exact_match_count = 0;
    uint32_t                    *counters_p = NULL;

    SX_LOG_ENTER();


    sx_status = atcam_regions_db_key_blocks_size_get(rule->region_id, &key_blocks_size);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get key block size for region [%u].\n", rule->region_id);
        goto out;
    }

    rule_entry = PARENT_STRUCT(rule, atcam_rules_db_rule_entry_t, data);
    cl_status = hashtable_bucket_lookup(bad_collision_ht, &(rule_entry->bad_collision_li), &bucket);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Failed to get hash bucket for rule remove. Region id %u, Erp id %u.\n",
                   rule->region_id,
                   rule->erp_id);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    /* Unlink this node */
    cl_qlist_remove_item(bucket, &(rule_entry->bad_collision_li));

    /* Check how many collisions it creates so to determine which collision we have created */
    sx_status = __atcam_erps_db_bad_collision_bucket_check(rule_entry,
                                                           bucket,
                                                           &bad_collision_count,
                                                           &exact_match_count);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when checking bad collision bucket. Region id %u, Erp id %u.\n",
                   rule->region_id,
                   rule->erp_id);
        goto out;
    }

    /* Update collision db */
    counters_p = (key_blocks_size == SX_ATCAM_ONE_KEY_BLOCK) ? \
                 bad_collision_counters.single_bad_collision_count : bad_collision_counters.double_bad_collision_count;
    /* We have counter for 0 to 3 collisions and counter for more than 3 collisions single & double */
    if (bad_collision_count == 0) {
        counters_p[0]--;
    } else if (bad_collision_count < BAD_COLLISION_COUNTERS_NUM) {
        counters_p[bad_collision_count] -= bad_collision_count + 1;
        counters_p[bad_collision_count - 1] += bad_collision_count;
    } else {
        counters_p[BAD_COLLISION_COUNTERS_NUM - 1]--;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_bad_collision_counters_get(atcam_erps_db_bad_collision_counters_t *counters_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();


    SX_MEM_CPY_P(counters_p, &bad_collision_counters);

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t atcam_erps_db_update_bf_enable(const sx_acl_region_id_t region_id,
                                           const sx_atcam_erp_id_t  erp_id,
                                           const boolean_t          bf_enabled)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t *erp_p = NULL;


    SX_LOG_ENTER();

    sx_status = atcam_erps_db_erp_get(region_id, erp_id, &erp_p);
    if (SX_STATUS_SUCCESS != sx_status) {
        SX_LOG_ERR("Error when getting erp with id %d, of region %d\n", erp_id, region_id);
        goto out;
    }

    erp_p->bf_enabled = bf_enabled;

out:
    SX_LOG_EXIT();
    return sx_status;
}
/*****************************************************************
 *                     Local Functions implementations
 ******************************************************************/

static cl_status_t __erps_db_ctcam_pool_init(void *const p_object, void *context, cl_pool_item_t ** const pp_pool_item)
{
    UNUSED_PARAM(context);
    atcam_erps_db_ctcam_entry_t *entry = (atcam_erps_db_ctcam_entry_t*)p_object;

    SX_MEM_CLR(entry->data);
    *pp_pool_item = &(entry->pool_item);
    return CL_SUCCESS;
}

static cl_status_t __erps_db_erps_pool_init(void *const p_object, void *context, cl_pool_item_t ** const pp_pool_item)
{
    UNUSED_PARAM(context);
    atcam_erps_db_erp_entry_t *entry = (atcam_erps_db_erp_entry_t*)p_object;

    SX_MEM_CLR(entry->data);
    *pp_pool_item = &(entry->pool_item);
    return CL_SUCCESS;
}

static cl_status_t __erps_db_erps_pdb_pool_init(void *const             p_object,
                                                void                   *context,
                                                cl_pool_item_t ** const pp_pool_item)
{
    UNUSED_PARAM(context);
    atcam_erps_db_prune_db_entry_t *entry = (atcam_erps_db_prune_db_entry_t*)p_object;

    cl_qmap_init(&entry->current_erp_rules);
    cl_qmap_init(&entry->other_erp_rules);
    *pp_pool_item = &(entry->pool_item);
    return CL_SUCCESS;
}


static sx_status_t __atcam_erps_db_check_erps_ids(const sx_atcam_region_id_t region_id,
                                                  const sx_atcam_erp_id_t   *erps_ids,
                                                  const uint8_t              valid_erps_num,
                                                  const sx_atcam_erp_id_t    erp_to_ignore)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint8_t     id_checker_arr[SX_ATCAM_ERPS_PER_REGION] = {};
    uint8_t     i = 0;


    if (valid_erps_num > SX_ATCAM_ERPS_PER_REGION) {
        SX_LOG_ERR("Valid erp num given exceeds range.\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* quick check to make sure the same erp_id doesn't appear more than once within the erps list, and that id's are in range */
    for (i = 0; i < valid_erps_num; ++i) {
        if (erps_ids[i] >= SX_ATCAM_ERPS_PER_REGION) {
            SX_LOG_ERR("eRP_id %d is out of erps range\n", erps_ids[i]);
            sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
        if ((++id_checker_arr[erps_ids[i]]) > 1) {
            SX_LOG_ERR("eRP_id %d appears more than once within eRP id's list\n", erps_ids[i]);
            sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
            goto out;
        }

        /*
         * we use this function to verify a set of eRPs, and also when adding new
         * eRP (for other) - in which case we need to skip the eRP been created
         */
        if (erps_ids[i] == erp_to_ignore) {
            continue;
        }

        /* If we won't fail, then this is a valid erp */
        sx_status = atcam_erps_db_erp_get(region_id, erps_ids[i], NULL);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("Error when getting eRP %d for region %d\n", erps_ids[i], region_id);
            goto out;
        }
    }

out:
    return sx_status;
}

static sx_status_t __atcam_erps_db_erp_params_set(const atcam_erps_db_erp_params_t *params, atcam_erps_db_erp_t *erp)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    uint32_t    i = 0, j = 0;

    SX_LOG_ENTER();

    sx_status = __atcam_erps_db_check_erps_ids(erp->region_id,
                                               params->region_erps,
                                               params->region_erps_num,
                                               erp->erp_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("While setting new eRP %d for region %d - other eRP weren't valid\n", erp->erp_id, erp->region_id);
        goto out;
    }

    /* if got here - params are validated */
    memcpy(&(erp->mask), &(params->mask), sizeof(sx_atcam_key_mask_t));
    erp->bf_enabled = params->bf_enabled;
    erp->bf_bank = params->bf_bank;

    /* We init the map that will hold the rules associated with this erp. Initially, empty */
    cl_qmap_init(&(erp->rules));

    for (i = 0; i < params->region_erps_num; ++i) {
        /* We skip the eRP id that is the id of this eRP */
        if (params->region_erps[i] == erp->erp_id) {
            continue;
        }

        sx_status = __atcam_erps_db_erp_init_single_prune_db(erp, params->region_erps[i]);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Erp When initializing prune map of indices (%d, %d)\n",
                       erp->erp_id, params->region_erps[i]);
            goto roll_back;
        }
    }

    goto out;

roll_back:

    for (j = 0; j < i; ++j) {
        /* We skip the eRP id that is the id of this eRP */
        if (params->region_erps[j] == erp->erp_id) {
            continue;
        }

        sx_status = __atcam_erps_db_erp_deinit_single_prune_db(erp, params->region_erps[j]);
        if (SX_STATUS_SUCCESS != sx_status) {
            SX_LOG_ERR("Error When de-initializing prune map of indices (%d, %d)\n",
                       erp->erp_id,
                       params->region_erps[j]);
        }
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


static int __atcam_erps_db_masked_rules_compare_func(IN const void *const p_key1, IN const void *const p_key2)
{
    return memcmp(p_key1, p_key2, sizeof(sx_atcam_key_mask_t));
}


/* We only update eRP, so we only need the other_erp_index */
static sx_status_t __atcam_erps_db_erp_init_single_prune_db(atcam_erps_db_erp_t    *erp,
                                                            const sx_atcam_erp_id_t other_erp_id)
{
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_erp_t *other_erp = NULL;

    SX_LOG_ENTER();

    if (erp->erp_id == other_erp_id) {
        SX_LOG_ERR("Prune-map indices cannot be the same as the erp's id\n");
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    sx_status = atcam_erps_db_erp_get(erp->region_id, other_erp_id, &other_erp);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("While getting other eRP\n");
        goto out;
    }

    /* Make sure that this new-prune intersection wasn't previously added */
    if (erp->prune_maps[other_erp_id].allocated == TRUE) {
        SX_LOG_ERR("Prune intersection for eRPs [(m)%d, (s)%d] at region %d already exists\n",
                   erp->erp_id,
                   other_erp_id,
                   erp->region_id);
        sx_status = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    /* The new mask is the intersection of our current eRP (erp), and the secondary (other_erp_id).
     * This is stored in prune_maps array on main erp (eRP), at other_erp_index
     */
    sx_status = atcam_utils_intersection_mask(&(erp->mask),
                                              &(other_erp->mask),
                                              &(erp->prune_maps[other_erp_id].mask));
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed when intersection masks of erps (%d, %d).\n", erp->erp_id, other_erp_id);
        goto out;
    }

    /* Entries will be inserted to this map according to rules being inserted */
    cl_fmap_init(&(erp->prune_maps[other_erp_id].rules_refs), __atcam_erps_db_masked_rules_compare_func);
    /* We set the ID as index to the array, although not necessary, but would make things easier */
    erp->prune_maps[other_erp_id].main_id = erp->erp_id;
    erp->prune_maps[other_erp_id].sec_id = other_erp_id;
    erp->prune_maps[other_erp_id].allocated = TRUE;

out:
    return sx_status;
}


static sx_status_t __atcam_erps_db_erp_deinit_single_prune_db(atcam_erps_db_erp_t *const erp,
                                                              const sx_atcam_erp_id_t    other_erp_id)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    atcam_erps_db_prune_db_t       *pm_p = NULL;
    atcam_erps_db_prune_db_entry_t *pm_entry_p = NULL;
    const cl_fmap_item_t           *it = NULL, *end = NULL;

    pm_p = &(erp->prune_maps[other_erp_id]);

    if (!pm_p->allocated) {
        /* nothing to do */
        goto out;
    }

    if (!cl_is_fmap_empty(&pm_p->rules_refs)) {
        it = cl_fmap_head(&pm_p->rules_refs);
        end = cl_fmap_end(&pm_p->rules_refs);

        /*
         * This acts as a 'forced-deinit' in some way. One can call atcam_erps_db_prune_db_entry_deallocate on
         * each entry, but if we are requested to remove all entries (by deleting erp for instance - background process,
         * then this function will be called, and will delete all entries, regardless if they were deleted explicitly.
         */
        while (it != end) {
            /* We extract the entry of our map - and we destroy both lists -
             * we DON'T remove the actual rules stored there - since they reference
             * to the same rules in DB - so we must not corrupt our DB.
             */
            pm_entry_p = PARENT_STRUCT(it, atcam_erps_db_prune_db_entry_t, fmap_item);

            if (!cl_is_qmap_empty(&pm_entry_p->current_erp_rules)) {
                cl_qmap_remove_all(&pm_entry_p->current_erp_rules);
            }
            if (!cl_is_qmap_empty(&pm_entry_p->other_erp_rules)) {
                cl_qmap_remove_all(&pm_entry_p->other_erp_rules);
            }

            /* return to pool */
            cl_qpool_put(&erps_pv_entries_pool, &pm_entry_p->pool_item);
            it = cl_fmap_next(it);
        }
    }

    memset(&(pm_p->mask), 0, sizeof(sx_atcam_key_mask_t));
    pm_p->allocated = FALSE;

out:
    return sx_status;
}

static sx_status_t __atcam_erps_db_bad_collision_bucket_check(const atcam_rules_db_rule_entry_t *rule,
                                                              const cl_qlist_t                  *bucket,
                                                              uint32_t                          *bad_collision_count_p,
                                                              uint32_t                          *exact_match_count_p)
{
    cl_list_item_t              *list_item = NULL;
    uint32_t                     bad_collision_count = 0, exact_match_count = 0;
    atcam_rules_db_rule_entry_t *list_rule = NULL;
    sx_atcam_key_value_t         rule_key_value, list_rule_value;
    const sx_atcam_key_byte_t   *rule_value_p = rule->data.key_value_blocks.flex_value_blocks;
    boolean_t                    rule_key_set = FALSE;
    int                          cmp_result = 0;

    list_item = cl_qlist_head(bucket);

    while (list_item != cl_qlist_end(bucket)) {
        list_rule = PARENT_STRUCT(list_item, atcam_rules_db_rule_entry_t, bad_collision_li);

        /* Check if the rule in the bucket has the same region & erp as the provided rule. */
        if ((rule->data.region_id == list_rule->data.region_id) && (rule->data.erp_id == list_rule->data.erp_id)) {
            if (!rule_key_set) {
                /* If there is a delta we need to remove it for the comparison */
                if (rule->data.delta.delta_mask) {
                    /* Clear the delta of the rule we supposed to add in order to compare with other rules */
                    SX_MEM_CPY_BUF(rule_key_value.flex_value_blocks,
                                   rule->data.key_value_blocks.flex_value_blocks,
                                   sizeof(rule_key_value.flex_value_blocks));
                    /* The delta is not part of the bad collision and should be removed */
                    atcam_utils_clear_delta_mask(rule_key_value.flex_value_blocks,
                                                 rule->data.delta.delta_start,
                                                 rule->data.delta.delta_mask);
                    rule_value_p = rule_key_value.flex_value_blocks;
                }
                rule_key_set = TRUE;
            }

            if (list_rule->data.delta.delta_mask) {
                /* Clear the delta of the rule we supposed to add in order to compare with other rules */
                SX_MEM_CPY_BUF(list_rule_value.flex_value_blocks,
                               list_rule->data.key_value_blocks.flex_value_blocks,
                               sizeof(list_rule_value.flex_value_blocks));
                /* The delta is not part of the bad collision and should be removed */
                atcam_utils_clear_delta_mask(list_rule_value.flex_value_blocks,
                                             list_rule->data.delta.delta_start,
                                             list_rule->data.delta.delta_mask);
                cmp_result = memcmp(list_rule_value.flex_value_blocks,
                                    rule_value_p,
                                    sizeof(list_rule_value.flex_value_blocks));
            } else {
                /* No delta. Compare the original key value */
                cmp_result = memcmp(list_rule->data.key_value_blocks.flex_value_blocks,
                                    rule_value_p,
                                    sizeof(list_rule->data.key_value_blocks.flex_value_blocks));
            }
            /* If we found a match we have a bad collision here */
            if (cmp_result == 0) {
                bad_collision_count++;
                /* now we check if we have an exact match */
                if ((list_rule->data.delta.delta_mask == rule->data.delta.delta_mask) &&
                    (list_rule->data.delta.delta_start == rule->data.delta.delta_start) &&
                    (list_rule->data.delta.delta_value == rule->data.delta.delta_value)) {
                    exact_match_count++;
                }
            }
        }
        list_item = cl_qlist_next(list_item);
    }

    *bad_collision_count_p = bad_collision_count;
    *exact_match_count_p = exact_match_count;

    return SX_STATUS_SUCCESS;
}

static uint32_t ____erps_db_bad_collision_hash_func(cl_list_item_t* entry)
{
    atcam_bad_collision_hash_key_t hash_key;
    atcam_rules_db_rule_entry_t  * rule_p = PARENT_STRUCT(entry, atcam_rules_db_rule_entry_t, bad_collision_li);

    SX_MEM_CLR(hash_key);

    hash_key.region_id = rule_p->data.region_id;
    hash_key.erp_id = rule_p->data.erp_id;
    SX_MEM_CPY_BUF(hash_key.erp_key_value.flex_value_blocks,
                   rule_p->data.key_value_blocks.flex_value_blocks,
                   sizeof(hash_key.erp_key_value.flex_value_blocks));
    /* The delta is not part of the hash calculation and therefore should be removed */
    if (rule_p->data.delta.delta_mask) {
        atcam_utils_clear_delta_mask(hash_key.erp_key_value.flex_value_blocks,
                                     rule_p->data.delta.delta_start,
                                     rule_p->data.delta.delta_mask);
    }

    return fib_hash_add(0, (uint8_t*)&hash_key, sizeof(hash_key), ERP_BAD_COLLISION_HASH_BITS);
}

static void ____erps_db_bad_collision_free_func(cl_list_item_t* entry)
{
    UNUSED_PARAM(entry);
    /* Do nothing */
    return;
}

static cl_status_t ____erps_db_bad_collision_cmp_func(cl_list_item_t* entry1, cl_list_item_t* entry2)
{
    UNUSED_PARAM(entry1);
    UNUSED_PARAM(entry2);
    /* This function is irrelevant here since the comparison is done in each bucket individually. */
    return CL_SUCCESS;
}
