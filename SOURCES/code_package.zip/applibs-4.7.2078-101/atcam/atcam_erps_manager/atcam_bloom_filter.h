/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_BLOOMFILTER_H__
#define __ATCAM_BLOOMFILTER_H__

#include "sx/sdk/sx_types.h"
#include "sx/utils/bloom_filter.h"
#include "atcam/common/atcam_types.h"
#include "atcam_erps_db.h"


/************************************************
 *  Global definitions
 ***********************************************/

/*
 *
 */
typedef struct atcam_bloom_filter_params {
    bf_hash_func atcam_bf_hash_func;
    uint32_t     size; /* Of each bank */
} atcam_bloom_filter_params_t;


/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initializes atcam bloom_filter module
 *
 * @param[in]  params - Parameters by which this module will be set
 */
sx_status_t atcam_bloom_filter_init(const atcam_bloom_filter_params_t* params);


/**
 * De-initializes atcam bloom_filter module
 *
 */
sx_status_t atcam_bloom_filter_deinit();


/**
 * Assign the operations unique for each type of flex bloom filter calculation
 *
 */
sx_status_t atcam_bloom_filter_assign_ops_flex2(atcam_bloom_filter_params_t *bloom_filter_params_p);
sx_status_t atcam_bloom_filter_assign_ops_flex3(atcam_bloom_filter_params_t *bloom_filter_params_p);
sx_status_t atcam_bloom_filter_assign_ops_flex4(atcam_bloom_filter_params_t *bloom_filter_params_p);

/**
 * Increments the bloom filter at bank 'bf_bank', at the index determined by the given key
 *
 * @param[in]  dev_id  - The device id used for the operation
 * @param[in]  bf_bank - The bank (out of ATCAM_BF_NUMBER_OF_BANKS) to which we apply the hash function
 * @param[in]  region_id - region id of the rule
 * @param[in]  erp_id - erp id of the rule
 * @param[in]  key - The masked value of the rule, along with the key size in HW blocks
 * @param[out] res_index - the index of the hash is returned to caller
 * Note: Region_id MUST be stripped of ACL added info
 */
sx_status_t atcam_bloom_filter_insert_rule(const sx_dev_id_t           dev_id,
                                           const uint8_t               bf_bank,
                                           const sx_atcam_region_id_t  region_id,
                                           const sx_atcam_erp_id_t     erp_id,
                                           const sx_atcam_key_value_t *key,
                                           uint32_t                   *res_index);

/**
 * Decrements the bloom filter at bank 'bf_bank', at the index determined by the given key
 *
 * @param[in]  dev_id  - The device id used for the operation
 * @param[in]  bf_bank - The bank (out of ATCAM_BF_NUMBER_OF_BANKS) to which we apply the hash function
 * @param[in]  region_id - region id of the rule
 * @param[in]  erp_id - erp id of the rule
 * @param[in]  key - The masked value of the rule, along with the key size in HW blocks
 * @param[out] res_index - the index of the hash is returned to caller
 *
 * Note: Region_id MUST be stripped of ACL added info
 */
sx_status_t atcam_bloom_filter_delete_rule(const sx_dev_id_t           dev_id,
                                           const uint8_t               bf_bank,
                                           const sx_atcam_region_id_t  region_id,
                                           const sx_atcam_erp_id_t     erp_id,
                                           const sx_atcam_key_value_t *key,
                                           uint32_t                   *res_index);

/**
 * Calculate the res_index according to the key
 *
 * @param[in] bf_bank - The bank (out of ATCAM_BF_NUMBER_OF_BANKS) to which we apply the hash function
 * @param[in] region_id - region id of the rule
 * @param[in] erp_id - erp id of the rule
 * @param[in] key - The masked value of the rule, along with the key size in HW blocks
 * @param[out] res_index - the index of the hash is returned to caller
 *
 * Note: Region_id MUST be stripped of ACL added info
 *
 */
sx_status_t atcam_bloom_filter_calculate_res_index(const uint8_t               bf_bank,
                                                   const sx_atcam_region_id_t  region_id,
                                                   const sx_atcam_erp_id_t     erp_id,
                                                   const sx_atcam_key_value_t *key,
                                                   uint32_t                   *res_index);

/**
 * Update the bloom filter for erp in one bulk
 *
 * @param[in] erp - the erp we want to update
 * @param[in] is_increase - TRUE if we want to update with added rules, FALSE otherwise
 * @return
 */
sx_status_t atcam_bloom_filter_update_erp_in_bulk(const atcam_erps_db_erp_t *erp,
                                                  boolean_t                  is_increase);

/**
 * FOR DEBUG PURPOSES ONLY. DO NOT USE AS IS
 *
 * Returns the value of the bloom filter at bank 'bf_bank', at the index determined by the given key
 *
 * @param[in]  bf_bank - The bank (out of ATCAM_BF_NUMBER_OF_BANKS) to which we apply the hash function
 * @param[in]  region_id - region id of the rule
 * @param[in]  erp_id - erp id of the rule
 * @param[in]  key - The masked value of the rule, along with the key size in HW blocks
 * @param[out] res_index - The index of the hash result.
 * @param[out] res_value - The value at 'res_index'
 *
 * Note: Region_id MUST be stripped of ACL added info
 */
sx_status_t atcam_bloom_filter_get_by_key(const uint8_t               bf_bank,
                                          const sx_atcam_region_id_t  region_id,
                                          const sx_atcam_erp_id_t     erp_id,
                                          const sx_atcam_key_value_t *key,
                                          uint32_t                   *res_index,
                                          uint32_t                   *res_value);

/**
 * When ISSU is enabled: The function will be called from issu_end_set and
 * will update the BF with state = 0 if needed
 * .
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *         other return codes are not provided
 */
sx_status_t atcam_bloom_filter_issu_set();


#endif /* __ATCAM_BLOOMFILTER_H__ */
