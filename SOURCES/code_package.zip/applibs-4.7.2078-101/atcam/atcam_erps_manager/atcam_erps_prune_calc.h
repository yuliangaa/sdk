/*
 * Copyright (C) 2017-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


/**
 * IMPORTANT NOTE:
 *  To fully understand the code below, please refer to the prune db and atcam documentation and
 *  spec.
 *  Notice the inline comments on of to use multi-threads in the calculations below, to be inserted
 *  once async-infra is prepared.
 */


#ifndef __ATCAM_ERPS_PRUNE_CALC_H__
#define __ATCAM_ERPS_PRUNE_CALC_H__

#include "sx/sdk/sx_types.h"
#include "atcam/common/atcam_utils.h"
#include "atcam/common/atcam_types.h"
#include "atcam/atcam_rules_manager/atcam_rules_db.h"

#include "atcam/atcam_erps_manager/atcam_erps_db.h"


/**
 * Updates Prune vectors of All rules of a specific region, caused by an insertion of a single
 * rule to atcam DB's. That is, both the prune vector of the inserted rule 'rule', and the prune-vectors
 * of other rules is updated as a result.
 *
 * @param[in]  rule - The rule that was inserted to atcam
 *
 * @return
 *    SX_STATUS_SUCCESS - if operation was successful
 *    SX_STATUS_ERROR - (or types) in case of other errors
 */
sx_status_t atcam_erps_prune_calc_atcam_insertion(atcam_rules_db_rule_t *rule);


/**
 * Updates Prune vectors of All rules of a specific region, caused by a deletion of a single
 * rule from atcam DB's. That is, the prune-vectors of other rules is updated as a result of the deletion.
 *
 * @param[in]  rule - The rule that was deleted from atcam
 *
 * @return
 *    SX_STATUS_SUCCESS - if operation was successful
 *    SX_STATUS_ERROR - (or types) in case of other errors
 */
sx_status_t atcam_erps_prune_calc_atcam_deletion(atcam_rules_db_rule_t *rule);


/**
 * Updates Prune ctcam-bits of All rules of a specific region, caused by an insertion of a single
 * rule to ctcam DB's. That is, the prune-ctcam bit of other rules is updated as a result of the deletion.
 *
 * @param[in]  rule - The rule that was inserted to ctcam
 *
 * @return
 *    SX_STATUS_SUCCESS - if operation was successful
 *    SX_STATUS_ERROR - (or types) in case of other errors
 */
sx_status_t atcam_erps_prune_calc_ctcam_insertion(const atcam_rules_db_rule_t *rule);

/**
 * Updates Prune ctcam-bit of All rules of a specific region, caused by a deletion of a single
 * rule from ctcam DB's. That is, the prune-vectors of other rules is updated as a result of the deletion.
 *
 * @param[in]  rule - The rule that was deleted from ctcam
 *
 * @return
 *    SX_STATUS_SUCCESS - if operation was successful
 *    SX_STATUS_ERROR - (or types) in case of other errors
 */
sx_status_t atcam_erps_prune_calc_ctcam_deletion(const atcam_rules_db_rule_t *rule);


/**
 * Updates Prune-DB to handle newly allocated erp. In order to compute future insertion and deletions, this function
 * must be called prior to insertion of any rule to the new erp. This function will update all the relevant-db with the
 * needed information, so when request to update prune-vectors will be made - it will be done quickly.
 *
 * @param[in]  region_id  - The id of the region a new erp was created in
 * @param[in]  new_erp_id - The id of the new erp
 * @param[in]  erp_params - The params needed for the creation of the new erp.
 *
 * @return
 *    SX_STATUS_SUCCESS - if operation was successful
 *    SX_STATUS_ERROR - (or types) in case of other errors
 */
sx_status_t atcam_erps_prune_calc_new_erp(const sx_atcam_region_id_t        region_id,
                                          const sx_atcam_erp_id_t           new_erp_id,
                                          const atcam_erps_db_erp_params_t *erp_params);


/**
 * Updates the prune vector of given rule as well as other rules in atcam due to change of priority of the rule in atcam.
 *
 * Notes:
 *     - This function updates the HW for changes in other rules (in atcam) as a result of this change.
 *       The changed rule (in atcam) HW update is NOT done via this function.
 *     - It is the caller responsibility to sync the order in which updates should be done.
 *     - It is assumed the 'rule' contains the new priority already.
 *     - It is also assumed the that old_priority != rule->priority
 *
 * @param[in]  rule  - The rule, with the new priority set
 * @param[in]  old_priority - The priority of the rule before the change
 *
 * @return
 *    SX_STATUS_SUCCESS - if operation was successful
 *    SX_STATUS_ERROR - (or types) in case of other errors
 */
sx_status_t atcam_erps_prune_calc_atcam_priority_update(atcam_rules_db_rule_t            *rule,
                                                        const sx_flex_acl_rule_priority_t old_priority);


/**
 * Updates the prune vector of other rules in atcam due to change of priority of the rule in ctcam.
 *
 * Notes:
 *    - This function updates the HW for changes in other rules (in atcam) as a result of this change.
 *      The changed rule (in ctcam) HW update is NOT done via this function.
 *    - It is the caller responsibility to sync the order in which updates should be done.
 *    - It is assumed the 'rule' contains the new priority already.
 *    - It is also assumed the old_priority != rule->priority
 *
 * @param[in]  rule  - The rule, with the new priority set
 * @param[in]  old_priority - The priority of the rule before the change
 *
 * @return
 *    SX_STATUS_SUCCESS - if operation was successful
 *    SX_STATUS_ERROR - (or types) in case of other errors
 */
sx_status_t atcam_erps_prune_calc_ctcam_priority_update(const atcam_rules_db_rule_t      *rule,
                                                        const sx_flex_acl_rule_priority_t old_priority);


#endif /* __ATCAM_ERPS_PRUNE_CALC_H__ */
