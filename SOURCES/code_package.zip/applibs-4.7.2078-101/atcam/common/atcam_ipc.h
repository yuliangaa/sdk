/*
 * Copyright (C) 2008-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef __ATCAM_IPC_H__
#define __ATCAM_IPC_H__

#include "sx/sdk/sx_types.h"
#include "kvd/kvd_linear_manager.h"
#include "resource_manager/resource_manager.h"
#include "atcam/atcam_rules_manager/atcam_rules_db.h"

#define ASYNC_INFRA_SUPPORTED 0
/* ***************************************************************************** */
/*                        ERP MGR <-> RULE MGR */
/* ***************************************************************************** */

typedef enum atcam_ipc_events {
    ATCAM_REQ_ADD_RULE_E,
    ATCAM_REQ_DELETE_RULE_E,
    ATCAM_REQ_PRIO_CHANGE_E,
    ATCAM_RESP_ADD_PRE_ERP_COMPLETED_E,
    ATCAM_RESP_ADD_POST_ERP_COMPLETED_E,
    ATCAM_RESP_DELETE_PRE_ERP_COMPLETED_E,
    ATCAM_RESP_DELETE_POST_ERP_COMPLETED_E,
    ATCAM_RESP_PRIO_CHANGE_COMPLETED_E
} atcam_ipc_events_e;

typedef struct prio_change_info {
    sx_flex_acl_rule_priority_t old_prio;
} prio_change_info_t;

typedef struct erp_extra_info {
    boolean_t         predetermined;
    sx_atcam_erp_id_t predetermined_erp_id;
} erp_extra_info_t;

typedef struct atcam_ipc_msg_payload {
    sx_dev_id_t            dev;
    sx_atcam_rule_id_t     rule_id; /* For DEBUG purposes */
    atcam_rules_db_rule_t *rule_ptr;
    union {
        prio_change_info_t prio_change;
        erp_extra_info_t   erp_extra_info;
    } command_extra_info;
} atcam_ipc_msg_payload_t;

typedef struct atcam_ipc_msg {
    atcam_ipc_events_e      event;
    uint64_t                transaction_id; /* ASYNC infra transaction id */
    uint64_t                msg_id; /* internal message id, mostly for debug */
    atcam_ipc_msg_payload_t msg;
} atcam_ipc_msg_t;


/* ***************************************************************************** */
/*                        ATCAM_API(ACL calls) <-> ATCAM - START */
/* ***************************************************************************** */

typedef struct {
    sx_acl_rule_offset_t        offset;
    sx_atcam_key_t              key;
    kvd_linear_manager_index_t  action_set;
    sx_flex_acl_rule_priority_t priority;
} atcam_api_rule_add_req_info_t;

typedef struct {
    sx_acl_rule_offset_t offset;
} atcam_api_rule_delete_req_info_t;

typedef struct {
    sx_acl_rule_offset_t        offset;
    sx_flex_acl_rule_priority_t priority;
    kvd_linear_manager_index_t  action_set;
} atcam_api_rule_update_priority_info_t;

typedef struct {
    int32_t                     prio_change;
    sx_flex_acl_rule_priority_t min_priority;
    sx_flex_acl_rule_priority_t max_priority;
} atcam_api_rule_update_prio_info_t;

typedef struct {
    sx_acl_rule_offset_t       offset;
    kvd_linear_manager_index_t action_set;
} atcam_api_rule_update_action_info_t;

typedef struct {
    sx_acl_rule_offset_t        src_offset;
    sx_acl_rule_offset_t        dst_offset;
    sx_flex_acl_rule_priority_t src_rule_priority;
    sx_flex_acl_rule_priority_t dst_rule_priority;
    boolean_t                   src_rule_exists;
    boolean_t                   overwrite_dst;
    boolean_t                   change_priority;
} atcam_api_rule_move_req_info_t;

typedef enum {
    ATCAM_API_REQ_ADD_RULE_E,
    ATCAM_API_REQ_DEL_RULE_E,
    ATCAM_API_REQ_EDIT_RULE_E,
    ATCAM_API_REQ_UPDATE_PRIO_E,
    ATCAM_API_REQ_UPDATE_RULES_PRIO_E,
    ATCAM_API_REQ_UPDATE_ACTION_E,
    ATCAM_API_REQ_MOVE_RULE_E,
} atcam_api_req_enum_t;

typedef struct {
    union {
        atcam_api_rule_add_req_info_t         add_info;
        atcam_api_rule_delete_req_info_t      delete_info;
        atcam_api_rule_update_priority_info_t prio_info;
        atcam_api_rule_update_action_info_t   action_info;
        atcam_api_rule_move_req_info_t        move_info;
        atcam_api_rule_update_prio_info_t     update_prio_info;
    } req_info;
} atcam_api_rule_req_msg_t;

typedef struct {
    atcam_api_req_enum_t     req_type;
    uint32_t                 transaction_id;
    boolean_t                is_sync;
    sx_acl_region_id_t       region_id;
    uint32_t                 num_of_msgs;
    sx_dev_id_t              dev_id;
    atcam_api_rule_req_msg_t msgs[RM_API_ACL_FLEX_RULES_BLOCK_MAX];
} atcam_api_rule_req_msgs_bulk_t;


/* ***************************************************************************** */
/*                        ATCAM_API(ACL calls) <-> ATCAM - END */
/* ***************************************************************************** */


#endif /*__ATCAM_IPC_H__ */
