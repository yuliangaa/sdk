/*
 * Copyright (c) 2017-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ATCAM_UTILS_H__
#define __ATCAM_UTILS_H__

#include "sx/sdk/sx_types.h"
#include "atcam_types.h"

/**
 * Converts a regions key block size into resource manager table type resource.
 *
 * @param[in]  region_id       - The region in question
 * @param[in]  is_atcam        - ctcam and atcam have different types.
 * @param[out] resource        - The resulting resource type
 *
 * @return
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 *      SX_STATUS_PARAM_ERROR - if unsupported key block size provided.
 */
sx_status_t get_region_rule_resource(sx_atcam_key_blocks_size_t key_blocks_size,
                                     boolean_t                  is_atcam,
                                     rm_sdk_table_type_e       *resource);
/**
 * Intersects two masks (= Logical and) and returns the result.
 *
 * @param[in]  mask1        - The first mask
 * @param[in]  mask2        - The second mask
 * @param[out] res          - The result mask
 *
 * @return
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 *      SX_STATUS_PARAM_NULL  - if at least one of input params is null
 *      SX_STATUS_PARAM_ERROR - if the blocks_count is illegal
 */
sx_status_t atcam_utils_intersection_mask(const sx_atcam_key_mask_t *const mask1,
                                          const sx_atcam_key_mask_t *const mask2,
                                          sx_atcam_key_mask_t             *res);

/**
 * Tests for compatibility of two keys.
 * A key k1 is compatible to k2 iff. all the values on unmasked bits are equal.
 *
 * @param[in]  key1           - The first key
 * @param[in]  key2           - The second key
 * @param[out] are_compatible - TRUE if keys are compatible, FALSE otherwise.
 *
 * @return
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 *      SX_STATUS_PARAM_NULL  - if at least one of input params is null
 *      SX_STATUS_PARAM_ERROR - if the blocks_count is illegal
 */
sx_status_t atcam_utils_are_keys_compatible(const sx_atcam_key_t *const key1,
                                            const sx_atcam_key_t *const key2,
                                            boolean_t                  *are_compatible);

/**
 * Intersects a key with a given mask, and returns the result.
 *
 * @param[in]     mask              - Given mask
 * @param[inout]  rule_key_val      - Rule key values after intersection with mask
 *
 * @return
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 *      SX_STATUS_PARAM_NULL  - if at least one of input params is null
 *      SX_STATUS_PARAM_ERROR - if the blocks_count is illegal
 */
sx_status_t atcam_utils_intersect_rule_n_mask(const sx_atcam_mask_byte_t *mask,
                                              sx_atcam_key_byte_t        *rule_key_val);

/**
 * Performs an intersection (Bitwise AND) of two masks, and puts the result in mask2.
 *
 * @param[in]     mask1    - first mask
 * @param[in]     mask2    - second mask
 * @param[out]  mask2    - the result of the intersection
 *
 * @return
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 *      SX_STATUS_PARAM_NULL  - if at least one of input params is null
 *      SX_STATUS_PARAM_ERROR - if the blocks_count is illegal
 */
sx_status_t atcam_utils_intersect_masks(const sx_atcam_key_mask_t *mask1,
                                        const sx_atcam_key_mask_t *mask2,
                                        sx_atcam_key_mask_t       *res);

/**
 * Intersects a key with a given mask, and returns the result.
 *
 * @param[in]  key            - The key
 * @param[in]  mask           - The mask
 * @param[out] res            - The result of the intersection.
 *
 * @return
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 *      SX_STATUS_PARAM_NULL  - if at least one of input params is null
 *      SX_STATUS_PARAM_ERROR - if the blocks_count is illegal
 */
sx_status_t atcam_utils_intersect_val_n_mask(const sx_atcam_key_value_t *const value,
                                             const sx_atcam_key_mask_t  *const mask,
                                             sx_atcam_key_value_t             *res);

/**
 * Performs a union (Bitwise OR) of two masks, and puts the result in mask2.
 *
 * @param[in]     mask1    - first mask
 * @param[inout]  mask2    - second mask, and the result of the union
 *
 * @return
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 *      SX_STATUS_PARAM_NULL  - if at least one of input params is null
 *      SX_STATUS_PARAM_ERROR - if the blocks_count is illegal
 */
sx_status_t atcam_utils_unite_masks(const sx_atcam_key_mask_t *mask1,
                                    sx_atcam_key_mask_t       *mask2);

/**
 * performs an exclusive OR between two masks, and returns the result.
 *
 * @param[in]     mask1, mask2  - given masks
 * @param[out]    res           - the result of the XOR operation
 *
 * @return
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 *      SX_STATUS_PARAM_NULL  - if at least one of input params is null
 *      SX_STATUS_PARAM_ERROR - if the blocks_count is illegal
 */
sx_status_t atcam_utils_xor_masks(const sx_atcam_key_mask_t *const mask1,
                                  const sx_atcam_key_mask_t *const mask2,
                                  sx_atcam_key_mask_t             *res);

/**
 * Get the location and size of the valid key blocks within the entire key.
 *
 * @param[in]  blocks_count  - Number of valid blocks both the key and mask have (must be the same)
 * @param[out] blocks_start  - Offset within the key were the valid blocks start
 * @param[out] blocks_size   - Size of the valid blocks
 *
 * @return
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 *      SX_STATUS_PARAM_NULL  - if at least one of input params is null
 *      SX_STATUS_PARAM_ERROR - if the blocks_count is illegal
 */
sx_status_t atcam_utils_blocks_location_get(const uint32_t blocks_count,
                                            uint8_t       *blocks_start,
                                            uint8_t       *blocks_size);

/**
 * Returns update_bf = TRUE if we need to update the  BF
 * Usually, If we don't update the BF we will update the res_index
 *
 * @param[in] num_of_erps - num of erps
 * @param[out] update_bf -  Returns TRUE if we need to update BF
 * @return
 *      SX_STATUS_PARAM_NULL - if update_res_index is null.
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 */
sx_status_t atcam_utils_need_to_update_bf(const uint16_t num_of_erps,
                                          boolean_t     *update_bf);

/**
 * Returns if we need to update all the erp.bf_bypass or not and in which value
 *  to update it
 * If we add erp (or enable):
 * 1.  new_num_of_erps < MIN_ERPS_FOR_BF:
 *     update_all = FALSE, bf_bypass = TRUE
 * 2.  old_num_of_erps < MIN_ERPS_FOR_BF && new_num_of_erps >= MIN_ERPS_FOR_BF:
 *     update_all = TRUE, bf_bypass = FALSE
 * 3.  old_num_of_erps >= MIN_ERPS_FOR_BF:
 *     update_all = FALSE, bf_bypass = FALSE
 * If we delete erp (or disable):
 * 1. old_num_of_erps < MIN_ERPS_FOR_BF:
 *     update_all = FALSE, bf_bypass = TRUE
 * 2. old_num_of_erps >= MIN_ERPS_FOR_BF && new_num_of_erps < MIN_ERPS_FOR_BF:
 *     update_all = TRUE, bf_bypass = TRUE
 * 3. new_num_of_erps >= MIN_ERPS_FOR_BF:
 *     update_all = FALSE, bf_bypass = FALSE
 * @param[in] old_num_of_erps - num of erps before insert/delete rule
 * @param[in] new_num_of_erps - num of erps after insert/delete rule
 * @param[in] is_add - TRUE if we are adding or setting, FALSE if we are deleting
 * @param[out] update_all_p - TRUE if we need to update all the  eRPs bf_bypass
 * @param[out] bf_bypass_p - bf_bypass value
 * @return
 *      SX_STATUS_PARAM_NULL - if update_res_index is null.
 *      SX_STATUS_SUCCESS     - if operation has ended successfully.
 */
sx_status_t atcam_utils_need_to_update_all_erps_bf(const uint16_t  old_num_of_erps,
                                                   const uint16_t  new_num_of_erps,
                                                   const boolean_t is_add,
                                                   boolean_t      *update_all_p,
                                                   boolean_t      *bf_bypass_p);

/**
 * This function returns the relevant byte out of the byte array given HW bit-offset of a key-value
 * mapping.
 *
 * Note - function assumes bit_offset is within valid range within byte_arr
 *
 * @param[in]  byte_arr    - The array of data to look within.
 * @param[in]  bit_offset  - Offset (given in bits) where the relevant byte started.
 *
 * @return
 *      uint8_t     - A byte of data starting the given bit_offset
 */
__inline static uint8_t atcam_utils_get_delta_byte(const uint8_t *byte_arr, const uint16_t bit_offset)
{
    uint8_t res = 0;

    /* First part */
    res = byte_arr[ATCAM_MAX_KEY_SIZE - 1 - (bit_offset / BYTE_SIZE)] >> (bit_offset % BYTE_SIZE);

    /* If mid-bytes: */
    if (bit_offset % BYTE_SIZE) {
        res |= byte_arr[ATCAM_MAX_KEY_SIZE - 2 - (bit_offset / BYTE_SIZE)] << (BYTE_SIZE - (bit_offset % BYTE_SIZE));
    }

    return res;
}

/**
 * This function clears the relevant mask byte out of the byte array given HW bit-offset of a key-value
 * mapping.
 *
 * Note - function assumes bit_offset is within valid range within byte_arr
 *
 * @param[in]  byte_arr    - The array of data to clear the mask within.
 * @param[in]  bit_offset  - Offset (given in bits) where the relevant byte started.
 * @param[in]  delta_mask  - The delta mask. Bits set to one will be cleared in the byte_arr.
 *
 * @return
 *      uint8_t     - A byte of data starting the given bit_offset
 */
__inline static void atcam_utils_clear_delta_mask(uint8_t       *byte_arr,
                                                  const uint16_t bit_offset,
                                                  const uint8_t  delta_mask)
{
    /* First part */
    byte_arr[ATCAM_MAX_KEY_SIZE - 1 - (bit_offset / BYTE_SIZE)] &= ~(delta_mask << (bit_offset % BYTE_SIZE));

    /* If mid-bytes: */
    if (bit_offset % BYTE_SIZE) {
        byte_arr[ATCAM_MAX_KEY_SIZE - 2 -
                 (bit_offset / BYTE_SIZE)] &= ~(delta_mask >> (BYTE_SIZE - (bit_offset % BYTE_SIZE)));
    }

    return;
}

__inline static uint64_t atcam_utils_build_erp_key_from_id(const sx_atcam_region_id_t region_id, const uint8_t erp_id)
{
    uint64_t key = 0;

    key = region_id;
    return (key << 32) | (erp_id);
}


__inline static uint32_t atcam_utils_round_up(uint32_t num, uint32_t multiple)
{
    if (multiple == 0) {
        return num;
    }

    uint32_t remainder = num % multiple;

    if (remainder == 0) {
        return num;
    }

    return num + multiple - remainder;
}

__inline static uint32_t atcam_utils_key_compare(const sx_atcam_key_t *key_value_blocks_1,
                                                 const sx_atcam_key_t *key_value_blocks_2)
{
    const uint64_t *flex_mask_blocks_1 = (uint64_t*)(key_value_blocks_1->flex_mask_blocks);
    const uint64_t *flex_value_blocks_1 = (uint64_t*)(key_value_blocks_1->flex_value_blocks);
    const uint64_t *flex_mask_blocks_2 = (uint64_t*)(key_value_blocks_2->flex_mask_blocks);
    const uint64_t *flex_value_blocks_2 = (uint64_t*)(key_value_blocks_2->flex_value_blocks);

    if (flex_mask_blocks_1[6] != flex_mask_blocks_2[6]) {
        if (flex_mask_blocks_1[6] > flex_mask_blocks_2[6]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_value_blocks_1[6] != flex_value_blocks_2[6]) {
        if (flex_value_blocks_1[6] > flex_value_blocks_2[6]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_mask_blocks_1[5] != flex_mask_blocks_2[5]) {
        if (flex_mask_blocks_1[5] > flex_mask_blocks_2[5]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_value_blocks_1[5] != flex_value_blocks_2[5]) {
        if (flex_value_blocks_1[5] > flex_value_blocks_2[5]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_mask_blocks_1[4] != flex_mask_blocks_2[4]) {
        if (flex_mask_blocks_1[4] > flex_mask_blocks_2[4]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_value_blocks_1[4] != flex_value_blocks_2[4]) {
        if (flex_value_blocks_1[4] > flex_value_blocks_2[4]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_mask_blocks_1[3] != flex_mask_blocks_2[3]) {
        if (flex_mask_blocks_1[3] > flex_mask_blocks_2[3]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_value_blocks_1[3] != flex_value_blocks_2[3]) {
        if (flex_value_blocks_1[3] > flex_value_blocks_2[3]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_mask_blocks_1[2] != flex_mask_blocks_2[2]) {
        if (flex_mask_blocks_1[2] > flex_mask_blocks_2[2]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_value_blocks_1[2] != flex_value_blocks_2[2]) {
        if (flex_value_blocks_1[2] > flex_value_blocks_2[2]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_mask_blocks_1[1] != flex_mask_blocks_2[1]) {
        if (flex_mask_blocks_1[1] > flex_mask_blocks_2[1]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_value_blocks_1[1] != flex_value_blocks_2[1]) {
        if (flex_value_blocks_1[1] > flex_value_blocks_2[1]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_mask_blocks_1[0] != flex_mask_blocks_2[0]) {
        if (flex_mask_blocks_1[0] > flex_mask_blocks_2[0]) {
            return 1;
        } else {
            return -1;
        }
    } else if (flex_value_blocks_1[0] != flex_value_blocks_2[0]) {
        if (flex_value_blocks_1[0] > flex_value_blocks_2[0]) {
            return 1;
        } else {
            return -1;
        }
    }
    return 0;
}

#endif /* __ATCAM_UTILS_H__ */
