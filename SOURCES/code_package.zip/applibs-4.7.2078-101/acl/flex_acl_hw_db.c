/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "sx/utils/dbg_utils.h"
#include "sx/utils/dbg_utils_pretty_printer.h"
#include "flex_acl_db.h"
#include "flex_acl_hw.h"
#include "flex_acl_hw_db.h"
#include <fcntl.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_shared_memory.h>
#include <complib/cl_dbg.h>

#undef  __MODULE__
#define __MODULE__ ACL

/************************************************
 *  Local variables
 ***********************************************/
#define HANDLER_DB_POOL_MIN_SIZE  2
#define HANDLER_DB_POOL_MAX_SIZE  CL_POOL_UNLIMITED_MAX_SIZE  /* not bounded pool*/
#define HANDLER_DB_POOL_GROW_SIZE 5
#define FLEX_ACL_DB_FREE          0
#define FLEX_ACL_DB_ALLOCATED     1

/* NOTE: If you change the defines below,
 *        make sure to align the WJH library with your changes. */

#define ACL_DROP_DIRECTION_OFFSET     18         /* an ACL direction; starts at offeset 18 and takes 2 msb.
                                                  *  Due to limited number of bits available only the following
                                                  *  directions are supported: */
#define ACL_DROP_DIRECTION_INGRESS    0          /* Used to represent: ingress port, ingress rif, ingress tport, ingress cpu port */
#define ACL_DROP_DIRECTION_EGRESS     1          /* Used to represent: egress port, egress rif, egress tport, egress cpu port */
#define ACL_DROP_DIRECTION_MULTIPOINT 2          /* Used to represent: multipoint binding */

#define ACL_DROP_RULES_MAX_MASK   0x3FFFF        /* 18 bits - used to identify an ACL rule that dropped a packet */
#define ACL_DPOP_USR_DEF_VAL_MASK 0xFFFFF        /* 20 bits - the size of the user defined value in the PRM
                                                  *            that can be reported with a dropped packet to SW by HW */

#define ACL_DROP_USR_DEF_VAL_SET(usr_def_val, direction) \
    ((((usr_def_val) & ACL_DROP_RULES_MAX_MASK) |        \
      ((direction) << ACL_DROP_DIRECTION_OFFSET)) & ACL_DPOP_USR_DEF_VAL_MASK)

#define ACL_DROP_DB_POOL_MIN_SIZE  400
#define ACL_DROP_DB_POOL_MAX_SIZE  ((1 << ACL_DROP_DIRECTION_OFFSET) - 1)
#define ACL_DROP_DB_POOL_GROW_SIZE ACL_DROP_DB_POOL_MIN_SIZE

typedef struct hw_action_dump_descr {
    dbg_utils_table_columns_t * columns_p;
    const char                * title;
    int                         count;
    boolean_t                   exist;
} hw_action_dump_descr_t;

char * hw_action_short[SXD_ACTION_TYPE_LAST_E + 1] = {
    [SXD_ACTION_TYPE_NULL_E] = "",
    [SXD_ACTION_TYPE_VLAN_E] = "VLAN",
    [SXD_ACTION_TYPE_MAC_E] = "MAC",
    [SXD_ACTION_TYPE_QOS_E] = "QOS",
    [SXD_ACTION_TYPE_TRAP_E] = "TRAP",
    [SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E] = "TRAP_UDF",
    [SXD_ACTION_TYPE_FORWARD_E] = "FWDG",
    [SXD_ACTION_TYPE_POLICING_COUNTING_E] = "P&C",
    [SXD_ACTION_TYPE_POLICING_COUNTING_BY_REF_E] = "P&C_REF",
    [SXD_ACTION_TYPE_META_DATA_E] = "META",
    [SXD_ACTION_TYPE_VIRTUAL_FORWARDING_E] = "VFWD",
    [SXD_ACTION_TYPE_IGNORE_E] = "IGN",
    [SXD_ACTION_TYPE_MC_E] = "MCRT",
    [SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E] = "UCRT",
    [SXD_ACTION_TYPE_PORT_FILTER_E] = "PFLT",
    [SXD_ACTION_TYPE_MPLS_E] = "MPLS",
    [SXD_ACTION_TYPE_HASH_E] = "HASH",
    [SXD_ACTION_TYPE_VXLAN_E] = "VXLAN",
    [SXD_ACTION_TYPE_SIP_DIP_E] = "SIPDIP",
    [SXD_ACTION_TYPE_L4_PORT_E] = "L4PORT",
    [SXD_ACTION_TYPE_MIRROR_SAMPLER_E] = "SAMPLER",
    [SXD_ACTION_TYPE_UNDEFINDED_E] = "UNDEFINED",
    [SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_IMM_E] = "ALUIMM",
    [SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_REG_E] = "ALUREG",
    [SXD_ACTION_TYPE_CUSTOM_BYTES_ALU_FIELD_E] = "ALUFIELD",
    [SXD_ACTION_TYPE_CUSTOM_BYTES_MOVE_E] = "BYTEMOVE",
    [SXD_ACTION_TYPE_FLOW_ESTIMATOR_E] = "ESTIMATOR",
};
char * vlan_tag_cmd_2str[SXD_FLEX_VLAN_TAG_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_VLAN_TAG_CMD_TYPE_DO_NOTHING_E] = "DONT",
    [SXD_FLEX_VLAN_TAG_CMD_TYPE_PUSH_OUTER_E] = "PUSH OUTER",
    [SXD_FLEX_VLAN_TAG_CMD_TYPE_POP_OUTER_E] = "POP OUTER",
    [SXD_FLEX_VLAN_TAG_CMD_TYPE_LAST_E] = "***",
};
#define ACT_VLAN_TAG_CMD_2STR(cmd) ((cmd) < SXD_FLEX_VLAN_TAG_CMD_TYPE_LAST_E) ? vlan_tag_cmd_2str[(cmd)] : "###"


char * vlan_vid_cmd_2str[SXD_FLEX_VID_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_VID_CMD_TYPE_DO_NOTHING_E] = "DONT",
    [SXD_FLEX_VID_CMD_TYPE_SET_OUTER_E] = "SET OUTER",
    [SXD_FLEX_VID_CMD_TYPE_SET_INNER_E] = "SET INNER",
    [SXD_FLEX_VID_CMD_TYPE_COPY_FROM_OUTER_TO_INNER_E] = "CP OUT2INN",
    [SXD_FLEX_VID_CMD_TYPE_COPY_FROM_INNER_TO_OUTER_E] = "CP INN2OUT",
    [SXD_FLEX_VID_CMD_TYPE_SWAP_INNER_OUTER_E] = "SWP INNOUT",
    [SXD_FLEX_VID_CMD_TYPE_LAST_E] = "***"
};
#define ACT_VLAN_VID_CMD_2STR(cmd) ((cmd) < SXD_FLEX_VID_CMD_TYPE_LAST_E) ? vlan_vid_cmd_2str[(cmd)] : "###"

char * vlan_ethertype_cmd_2str[SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_DO_NOTHING_E] = "DONT",
    [SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_SET_OUTER_E] = "SET OUTER",
    [SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_SET_INNER_E] = "SET INNER",
    [SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_COPY_FROM_OUTER_TO_INNER_E] = "CP OUT2INN",
    [SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_COPY_FROM_INNER_TO_OUTER_E] = "CP INN2OUT",
    [SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_SWAP_INNER_OUTER_E] = "SWP INNOUT",
    [SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_LAST_E] = "***"
};
#define ACT_VLAN_ETHERTYPED_CMD_2STR(cmd)                                        \
    ((cmd) <                                                                     \
     SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_LAST_E) ? vlan_ethertype_cmd_2str[(cmd)] : \
    "###"

char * vlan_pcp_cmd_2str[SXD_FLEX_VLAN_PRIO_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_VLAN_PRIO_CMD_TYPE_DO_NOTHING_E] = "DONT",
    [SXD_FLEX_VLAN_PRIO_CMD_TYPE_SET_OUTER_E] = "SET OUTER",
    [SXD_FLEX_VLAN_PRIO_CMD_TYPE_SET_INNER_E] = "SET INNER",
    [SXD_FLEX_VLAN_PRIO_CMD_TYPE_COPY_FROM_OUTER_TO_INNER_E] = "CP OUT2INN",
    [SXD_FLEX_VLAN_PRIO_CMD_TYPE_COPY_FROM_INNER_TO_OUTER_E] = "CP INN2OUT",
    [SXD_FLEX_VLAN_ETHERTYPE_CMD_TYPE_SWAP_INNER_OUTER_E] = "SWP INNOUT",
    [SXD_FLEX_VLAN_PRIO_CMD_TYPE_LAST_E] = "***"
};
#define ACT_VLAN_PCP_CMD_2STR(cmd) ((cmd) < SXD_FLEX_VLAN_PRIO_CMD_TYPE_LAST_E) ? vlan_pcp_cmd_2str[(cmd)] : "###"

char * vlan_dei_cmd_2str[SXD_FLEX_DEI_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_DEI_CMD_TYPE_DO_NOTHING_E] = "DO NOTHING",
    [SXD_FLEX_DEI_CMD_TYPE_SET_OUTER_E] = "SET OUTER",
    [SXD_FLEX_DEI_CMD_TYPE_SET_INNER_E] = "SET INNER",
    [SXD_FLEX_DEI_CMD_TYPE_COPY_FROM_OUTER_TO_INNER_E] = "CP OUT2INN",
    [SXD_FLEX_DEI_CMD_TYPE_COPY_FROM_INNER_TO_OUTER_E] = "CP INN2OUT",
    [SXD_FLEX_DEI_CMD_TYPE_SWAP_INNER_OUTER_E] = "SWP INNOUT",
    [SXD_FLEX_DEI_CMD_TYPE_LAST_E] = "***"
};
#define ACT_VLAN_DEI_CMD_2STR(cmd) ((cmd) < SXD_FLEX_DEI_CMD_TYPE_LAST_E) ? vlan_dei_cmd_2str[(cmd)] : "invalid"

char * mac_ttl_cmd_2str[SXD_FLEX_TTL_CMD_LAST_E + 1] = {
    [SXD_FLEX_TTL_CMD_DO_NOTHING_E] = "DO NOTHING",
    [SXD_FLEX_TTL_CMD_SET_TTL_VALUE_E] = "SET TTL",
    [SXD_FLEX_TTL_CMD_DECREMENT_E] = "DEC TTL",
    [SXD_FLEX_TTL_CMD_LAST_E] = "INVALID"
};
#define ACT_MAC_TTL_CMD_2STR(cmd) ((cmd) < SXD_FLEX_TTL_CMD_LAST_E) ? mac_ttl_cmd_2str[(cmd)] : "invalid"

char * mac_cmd_2str[SXD_FLEX_MAC_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_MAC_CMD_TYPE_DO_NOTHING_E] = "DO NOTHING",
    [SXD_FLEX_MAC_CMD_TYPE_SET_SMAC_E] = "SET SMAC",
    [SXD_FLEX_MAC_CMD_TYPE_SET_DMAC_E] = "DEC DMAC",
    [SXD_FLEX_MAC_CMD_TYPE_LAST_E] = "INVALID"
};
#define ACT_MAC_CMD_2STR(cmd) ((cmd) < SXD_FLEX_MAC_CMD_TYPE_LAST_E) ? mac_cmd_2str[(cmd)] : "invalid"

char * qos_ecn_cmd_2str[SXD_FLEX_ECN_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_ECN_CMD_TYPE_DO_NOTHING_E] = "DONT",
    [SXD_FLEX_ECN_CMD_TYPE_SET_OUTER_ECN_E] = "SET OUTER",
    [SXD_FLEX_ECN_CMD_TYPE_SET_INNER_ECN_E] = "SET INNER",
    [SXD_FLEX_ECN_CMD_TYPE_COPY_ENC_OUTER_TO_INNER_E] = "CP OUT2INN",
    [SXD_FLEX_ECN_CMD_TYPE_COPY_ENC_INNER_TO_OUTER_E] = "CP INN2OUT",
    [SXD_FLEX_ECN_CMD_TYPE_SWAP_INNER_AND_OUTER_E] = "SWP INNOUT",
    [SXD_FLEX_ECN_CMD_TYPE_LAST_E] = "***",
};
#define ACT_QOS_ECN_CMD_2STR(cmd) ((cmd) < SXD_FLEX_ECN_CMD_TYPE_LAST_E) ? qos_ecn_cmd_2str[(cmd)] : "###"

char * qos_color_cmd_2str[SXD_FLEX_COLOR_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_COLOR_CMD_TYPE_DO_NOTHING_E] = "DONT",
    [SXD_FLEX_COLOR_CMD_TYPE_SET_COLOR_E] = "SET",
    [SXD_FLEX_COLOR_CMD_TYPE_LAST_E] = "***",
};
#define ACT_QOS_COLOR_CMD_2STR(cmd) ((cmd) < SXD_FLEX_COLOR_CMD_TYPE_LAST_E) ? qos_color_cmd_2str[(cmd)] : "###"

char * qos_dscp_cmd_2str[SXD_FLEX_DSCP_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_DSCP_CMD_TYPE_DO_NOTHING_E] = "DONT",
    [SXD_FLEX_DSCP_CMD_TYPE_SET_3_LSB_BITS_E] = "SET 3 LSB",
    [SXD_FLEX_DSCP_CMD_TYPE_SET_3_MSB_BITS_E] = "SET 3 MSB",
    [SXD_FLEX_DSCP_CMD_TYPE_SET_DSCP_6_BITS_E] = "SET 6 BIT",
    [SXD_FLEX_DSCP_CMD_TYPE_LAST_E] = "***",
};
#define ACT_QOS_DSCP_CMD_2STR(cmd) ((cmd) < SXD_FLEX_DSCP_CMD_TYPE_LAST_E) ? qos_dscp_cmd_2str[(cmd)] : "###"

char * qos_switch_prio_cmd_2str[SXD_FLEX_SWITCH_PRIO_CMD_TYPE_LAST + 1] = {
    [SXD_FLEX_SWITCH_PRIO_CMD_TYPE_DO_NOTHING_E] = "DONT",
    [SXD_FLEX_SWITCH_PRIO_CMD_TYPE_SET_SWITCH_PRIORITY_E] = "SET",
    [SXD_FLEX_SWITCH_PRIO_CMD_TYPE_LAST] = "***",
};
#define ACT_QOS_SWITCH_PRIO_CMD_2STR(cmd)                                    \
    ((cmd) <                                                                 \
     SXD_FLEX_SWITCH_PRIO_CMD_TYPE_LAST) ? qos_switch_prio_cmd_2str[(cmd)] : \
    "###"

char * qos_color_type_2str[SXD_FLEX_COLOR_TYPE_LAST_E + 1] = {
    [SXD_FLEX_COLOR_CMD_TYPE_GREEN_E] = "G",
    [SXD_FLEX_COLOR_CMD_TYPE_YELLOW_E] = "Y",
    [SXD_FLEX_COLOR_CMD_TYPE_RED_E] = "R",
    [SXD_FLEX_COLOR_TYPE_LAST_E] = "*",
};
#define ACT_QOS_COLOR_TYPE_2STR(type) ((type) < SXD_FLEX_COLOR_TYPE_LAST_E) ? qos_color_type_2str[(type)] : "invalid"

char * qos_rewrite_cmd_2str[SXD_FLEX_REWRITE_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_REWRITE_CMD_TYPE_PRESERVE_VALUE_REWRITE_ENABLE_BIT_E] = "PRESRV",
    [SXD_FLEX_REWRITE_CMD_TYPE_SET_VALUE_REWRITE_ENABLE_BIT_E] = "SET",
    [SXD_FLEX_REWRITE_CMD_TYPE_CLEAR_VALUE_REWRITE_ENABLE_BIT_E] = "CLR",
    [SXD_FLEX_REWRITE_CMD_TYPE_LAST_E] = "***",
};
#define ACT_QOS_REWRITE_CMD_2STR(cmd) \
    ((cmd) <                          \
     SXD_FLEX_REWRITE_CMD_TYPE_LAST_E) ? qos_rewrite_cmd_2str[(cmd)] : "###"

char * qos_tc_cmd_2str[SXD_FLEX_TRAFFIC_CLASS_CMD_TYPE_LAST_E + 1] = {
    [SXD_FLEX_TRAFFIC_CLASS_CMD_TYPE_DO_NOTHING_E] = "DONT",
    [SXD_FLEX_TRAFFIC_CLASS_CMD_TYPE_SET_TRAFFIC_CLASS_E] = "SET",
    [SXD_FLEX_TRAFFIC_CLASS_CMD_TYPE_LAST_E] = "***",
};
#define ACT_QOS_TC_CMD_2STR(cmd) ((cmd) < SXD_FLEX_TRAFFIC_CLASS_CMD_TYPE_LAST_E) ? qos_tc_cmd_2str[(cmd)] : "###"

char * trap_fw_action_2str[SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_LAST_E + 1] = {
    [SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DO_NOTHING_E] = "DO NOTHING",
    [SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_FORWARD_DO_NOTHING_CLEAR_SOFT_DROP_E] = "CLEAR SOFT DISCARD",
    [SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_SOFT_DROP_ERROR_E] = "SOFT DISCARD ERROR",
    [SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_E] = "HARD DISCARD",
    [SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_DISCARD_HARD_DROP_ERROR_E] = "HARD DISCARD ERROR",
    [SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_LAST_E] = "INVALID",
};
#define ACT_TRAP_FW_ACTION_2STR(action)                                          \
    ((action) <                                                                  \
     SXD_FLEX_TRAP_FORWARD_ACTION_TYPE_LAST_E) ? trap_fw_action_2str[(action)] : \
    "invalid"

char * trap_action_2str[SXD_FLEX_TRAP_ACTION_TYPE_LAST_E + 1] = {
    [SXD_FLEX_TRAP_ACTION_TYPE_DO_NOTHING_E] = "DO NOTHING",
    [SXD_FLEX_TRAP_ACTION_TYPE_SOFT_DISCARD_CLEAR_TRAP_E] = "CLEAR SOFT DISCARD",
    [SXD_FLEX_TRAP_ACTION_TYPE_TRAP_E] = "TRAP",
    [SXD_FLEX_TRAP_ACTION_TYPE_DISCARD_NO_TRAP_E] = "DISCARD",
    [SXD_FLEX_TRAP_ACTION_TYPE_LAST_E] = "INVALID",
};
#define ACT_TRAP_ACTION_2STR(action) \
    ((action) <                      \
     SXD_FLEX_TRAP_ACTION_TYPE_LAST_E) ? trap_action_2str[(action)] : "invalid"

char * forward_type_2str[SXD_FORWARD_FLEX_ACTION_TYPE_LAST_E + 1] = {
    [SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E] = "PBS",
    [SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E] = "OUTPUT",
    [SXD_FORWARD_FLEX_ACTION_TYPE_LAST_E] = "INVALID",
};
#define ACT_FORWARD_TYPE_2STR(type) \
    ((type) <                       \
     SXD_FORWARD_FLEX_ACTION_TYPE_LAST_E) ? forward_type_2str[(type)] : "invalid"

char * pc_type_2str[SXD_POLIICING_MONITORING_FLEX_ACTION_LAST_E + 1] = {
    [SXD_POLIICING_MONITORING_FLEX_ACTION_COUNTER_E] = "COUNTER",
    [SXD_POLIICING_MONITORING_FLEX_ACTION_POLICER_E] = "POLICER",
    [SXD_POLIICING_MONITORING_FLEX_ACTION_LAST_E] = "INVALID",
};
#define ACT_PC_TYPE_2STR(type) \
    ((type) <                  \
     SXD_POLIICING_MONITORING_FLEX_ACTION_LAST_E) ? pc_type_2str[(type)] : "invalid"

char * vf_cmd_2str[SXD_VIRTUAL_FORWARD_FLEX_ACTION_VR_CMD_TYPE_LAST + 1] = {
    [SXD_VIRTUAL_FORWARD_FLEX_ACTION_VR_CMD_TYPE_DO_NOTING_E] = "DO NOTHING",
    [SXD_VIRTUAL_FORWARD_FLEX_ACTION_VR_CMD_TYPE_SET_VR_TO_PACKET_E] = "SET VR TO PACKET",
    [SXD_VIRTUAL_FORWARD_FLEX_ACTION_VR_CMD_TYPE_LAST] = "INVALID",
};
#define ACT_VF_CMD_2STR(cmd) \
    ((cmd) <                 \
     SXD_VIRTUAL_FORWARD_FLEX_ACTION_VR_CMD_TYPE_LAST) ? vf_cmd_2str[(cmd)] : "invalid"

char * fid_cmd_2str[SXD_VIRTUAL_FORWARD_FLEX_ACTION_FID_CMD_TYPE_LAST + 1] = {
    [SXD_VIRTUAL_FORWARD_FLEX_ACTION_FID_CMD_TYPE_DO_NOTING_E] = "DO NOTHING",
    [SXD_VIRTUAL_FORWARD_FLEX_ACTION_FID_CMD_TYPE_SET_FID_TO_PACKET_E] = "SET FID TO PACKET",
    [SXD_VIRTUAL_FORWARD_FLEX_ACTION_FID_CMD_TYPE_LAST] = "INVALID",
};
#define ACT_FID_CMD_2STR(cmd) \
    ((cmd) <                  \
     SXD_VIRTUAL_FORWARD_FLEX_ACTION_FID_CMD_TYPE_LAST) ? fid_cmd_2str[(cmd)] : "invalid"

char * ignore_stp_type_2str[SXD_IGNORE_FLEX_ACTION_IGNORE_STP_TYPE_LAST_E + 1] = {
    [SXD_IGNORE_FLEX_ACTION_IGNORE_STP_TYPE_REGULAR_FLOW_E] = "REGULAR FLOW",
    [SXD_IGNORE_FLEX_ACTION_IGNORE_STP_TYPE_IGNORE_STP_E] = "IGNORE STP",
    [SXD_IGNORE_FLEX_ACTION_IGNORE_STP_TYPE_LAST_E] = "INVALID",
};
#define ACT_IGNORE_STP_TYPE_2STR(type)                                             \
    ((type) <                                                                      \
     SXD_IGNORE_FLEX_ACTION_IGNORE_STP_TYPE_IGNORE_STP_E) ? ignore_stp_type_2str[( \
                                                                                     type)] : "invalid"

char * ignore_vl_filter_type_2str[SXD_IGNORE_FLEX_ACTION_IGNORE_VL_TYPE_LAST_E + 1] = {
    [SXD_IGNORE_FLEX_ACTION_IGNORE_STP_TYPE_REGULAR_FLOW_E] = "REGULAR FLOW",
    [SXD_IGNORE_FLEX_ACTION_IGNORE_STP_TYPE_IGNORE_STP_E] = "IGNORE VLAN",
    [SXD_IGNORE_FLEX_ACTION_IGNORE_VL_TYPE_LAST_E] = "INVALID",
};
#define ACT_IGNORE_VL_FILER_2STR(type)                                            \
    ((type) <                                                                     \
     SXD_IGNORE_FLEX_ACTION_IGNORE_VL_TYPE_LAST_E) ? ignore_vl_filter_type_2str[( \
                                                                                    type)] : "invalid"

char * ignore_disable_leraning_type_2str[SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_LEARNING_TYPE_LAST_E + 1] = {
    [SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_LEARNING_TYPE_REGULAR_FLOW_E] = "REGULAR FLOW",
    [SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_LEARNING_TYPE_DISABLE_LEARNING_E] = "DISABLE LEARNING",
    [SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_LEARNING_TYPE_LAST_E] = "INVALID",
};
#define ACT_IGNORE_DISABLE_LEARNING_2STR(type)                     \
    ((type) <                                                      \
     SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_LEARNING_TYPE_LAST_E) ? \
    ignore_disable_leraning_type_2str[(type)] : "invalid"

char * ignore_disable_ovl_leraning_type_2str[SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_OVL_LEARNING_TYPE_LAST_E + 1] = {
    [SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_OVL_LEARNING_TYPE_REGULAR_FLOW_E] = "OVL REGULAR FLOW",
    [SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_OVL_LEARNING_TYPE_DISABLE_LEARNING_E] = "OVL DISABLE LEARNING",
    [SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_OVL_LEARNING_TYPE_LAST_E] = "INVALID",
};
#define ACT_IGNORE_DISABLE_OVL_LEARNING_2STR(type)                     \
    ((type) <                                                          \
     SXD_IGNORE_FLEX_ACTION_IGNORE_DISABLE_OVL_LEARNING_TYPE_LAST_E) ? \
    ignore_disable_ovl_leraning_type_2str[(type)] :                    \
    "invalid"

char * mc_rpf_action_2str[SXD_MC_FLEX_ACTION_RPF_ACTION_LAST_E + 1] = {
    [SXD_MC_FLEX_ACTION_RPF_ACTION_NOP_E] = "NOP",
    [SXD_MC_FLEX_ACTION_RPF_ACTION_RPF_TRAP_E] = "TRAP",
    [SXD_MC_FLEX_ACTION_RPF_ACTION_RPF_DISCARD_ERR_E] = "DISCARD ERROR",
    [SXD_MC_FLEX_ACTION_RPF_ACTION_ASSERT_TRAP_E] = "ASSERT TRAP",
    [SXD_MC_FLEX_ACTION_RPF_ACTION_LAST_E] = "INVALID",
};

#define ACT_IMC_RPF_ACTION_2STR(action)                                                 \
    (((action) < SXD_MC_FLEX_ACTION_RPF_ACTION_LAST_E) && mc_rpf_action_2str[(action)]) \
    ? mc_rpf_action_2str[(action)] : "invalid"

char * uc_route_action_type_2str[SXD_UC_ROUTER_FLEX_ACTION_TYPE_LAST_E + 1] = {
    [SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E] = "IP REMOTE",
    [SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_LOCAL_E] = "IP LOCAL",
    [SXD_UC_ROUTER_FLEX_ACTION_TYPE_TUNNL_TERMINIATION_E] = "TUNNEL TERMINATION",
    [SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_ILM_E] = "MPLS ILM",
    [SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_NHLFE_E] = "MPLS NHLFE",
    [SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E] = "AR",
    [SXD_UC_ROUTER_FLEX_ACTION_TYPE_LAST_E] = "INVALID",
};

#define ACT_UC_ROUTE_2STR(action)                                                               \
    (((action) < SXD_UC_ROUTER_FLEX_ACTION_TYPE_LAST_E) && uc_route_action_type_2str[(action)]) \
    ? uc_route_action_type_2str[(action)] : "invalid"

char * mc_air_type_2str[SXD_MC_FLEX_ACTION_EIR_TYPE_LAST_E + 1] = {
    [SXD_MC_FLEX_ACTION_EIR_TYPE_IRIF_E] = "IRIF",
    [SXD_MC_FLEX_ACTION_EIR_TYPE_IRIF_LIST_E] = "IRIF LIST",
    [SXD_MC_FLEX_ACTION_EIR_TYPE_LAST_E] = "INVALID",
};
#define ACT_MC_AIR_TYPE_2STR(type)                                                                   \
    (((type) < SXD_MC_FLEX_ACTION_EIR_TYPE_LAST_E) && ignore_disable_ovl_leraning_type_2str[(type)]) \
    ? mc_air_type_2str[(type)] : "invalid"

static char * api_action_short[SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST + 1] = {
    [SX_FLEX_ACL_ACTION_FORWARD] = "FWD",
    [SX_FLEX_ACL_ACTION_TRAP] = "TRAP",
    [SX_FLEX_ACL_ACTION_COUNTER] = "CNTR",
    [SX_FLEX_ACL_ACTION_COUNTER_BY_REF] = "CNTR_REF",
    [SX_FLEX_ACL_ACTION_MIRROR] = "MIRR",
    [SX_FLEX_ACL_ACTION_EGRESS_MIRROR] = "EGMIRR",
    [SX_FLEX_ACL_ACTION_POLICER] = "POLCR",
    [SX_FLEX_ACL_ACTION_SET_PRIO] = "PRIO",
    [SX_FLEX_ACL_ACTION_SET_VLAN] = "VLAN",
    [SX_FLEX_ACL_ACTION_SET_INNER_VLAN_PRI] = "INNPRI",
    [SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_PRI] = "OUTPRI",
    [SX_FLEX_ACL_ACTION_SET_INNER_VLAN_ID] = "INNVID",
    [SX_FLEX_ACL_ACTION_SET_OUTER_VLAN_ID] = "OUTVID",
    [SX_FLEX_ACL_ACTION_SET_SRC_MAC] = "SMAC",
    [SX_FLEX_ACL_ACTION_SET_DST_MAC] = "DMAC",
    [SX_FLEX_ACL_ACTION_SET_DSCP] = "DSCP",
    [SX_FLEX_ACL_ACTION_SET_BRIDGE] = "BRDG",
    [SX_FLEX_ACL_ACTION_PBS] = "PBS",
    [SX_FLEX_ACL_ACTION_SET_TC] = "TC",
    [SX_FLEX_ACL_ACTION_DEC_TTL] = "DECTTL",
    [SX_FLEX_ACL_ACTION_SET_TTL] = "TTL",
    [SX_FLEX_ACL_ACTION_SET_COLOR] = "CLR",
    [SX_FLEX_ACL_ACTION_SET_ECN] = "ECN",
    [SX_FLEX_ACL_ACTION_SET_USER_TOKEN] = "USRTKN",
    [SX_FLEX_ACL_ACTION_DONT_LEARN] = "DNTLRN",
    [SX_FLEX_ACL_ACTION_TUNNEL_DECAP] = "TUNDCP",
    [SX_FLEX_ACL_ACTION_GOTO] = "GOTO",
    [SX_FLEX_ACL_ACTION_RPF] = "RPF",
    [SX_FLEX_ACL_ACTION_MC_ROUTE] = "MCROUT",
    [SX_FLEX_ACL_ACTION_SET_ROUTER] = "ROUTER",
    [SX_FLEX_ACL_ACTION_MC] = "MCPBS",
    [SX_FLEX_ACL_ACTION_UC_ROUTE] = "UCROUT",
    [SX_FLEX_ACL_ACTION_AR_UC_ROUTE] = "ARUCROUT",
    [SX_FLEX_ACL_ACTION_SET_DSCP_REWRITE] = "DSCPRW",
    [SX_FLEX_ACL_ACTION_SET_PCP_REWRITE] = "PCPRW",
    [SX_FLEX_ACL_ACTION_IGNORE_EGRESS_VLAN_FILTER] = "IGEVFL",
    [SX_FLEX_ACL_ACTION_IGNORE_EGRESS_STP_FILTER] = "IGESTP",
    [SX_FLEX_ACL_ACTION_DISABLE_OVERLAY_LEARNING] = "DISOVLN",
    [SX_FLEX_ACL_ACTION_PORT_FILTER] = "PRTFLT",
    [SX_FLEX_ACL_ACTION_SET_MPLS_TTL] = "SMPLSTTL",
    [SX_FLEX_ACL_ACTION_DEC_MPLS_TTL] = "DMPLSTTL",
    [SX_FLEX_ACL_ACTION_SET_EXP] = "SETEXP",
    [SX_FLEX_ACL_ACTION_SET_EXP_REWRITE] = "EXP_RW",
    [SX_FLEX_ACL_ACTION_PBILM] = "PBILM",
    [SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP] = "NVENCAP",
    [SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP] = "NVENCPMC",
    [SX_FLEX_ACL_ACTION_TRAP_W_USER_ID] = "TRAP_UID",
    [SX_FLEX_ACL_ACTION_HASH] = "HASH",
    [SX_FLEX_ACL_ACTION_SWAP_INNER_OUTER_VLAN] = "VLANSWAP",
    [SX_FLEX_ACL_ACTION_SET_VNI] = "SETVNI",
    [SX_FLEX_ACL_ACTION_SET_SIP_ADDR] = "SETSIP",
    [SX_FLEX_ACL_ACTION_SET_DIP_ADDR] = "SETDIP",
    [SX_FLEX_ACL_ACTION_SET_SIPV6_ADDR] = "SETSIP6",
    [SX_FLEX_ACL_ACTION_SET_DIPV6_ADDR] = "SETDIP6",
    [SX_FLEX_ACL_ACTION_SET_L4_SRC_PORT] = "SETL4SRC",
    [SX_FLEX_ACL_ACTION_SET_L4_DST_PORT] = "SETL4DST",
    [SX_FLEX_ACL_ACTION_ALU_IMM] = "ALUIMM",
    [SX_FLEX_ACL_ACTION_ALU_REG] = "ALUREG",
    [SX_FLEX_ACL_ACTION_ALU_FIELD] = "ALUFIELD",
    [SX_FLEX_ACL_ACTION_REGISTER_ACCESS] = "REGACCS",
    [SX_FLEX_ACL_ACTION_ELEPHANT_SET] = "ELEPHANT",
    [SX_FLEX_ACL_ACTION_SET_AR_PACKET_PROFILE] = "AR_PACKET_PROFILE",
    [SX_FLEX_ACL_ACTION_MIRROR_SAMPLER] = "MIRR_SMPL",
    [SX_FLEX_ACL_ACTION_FIELD_IMM] = "FIELDIMM",
    [SX_FLEX_ACL_ACTION_FIELD_COPY] = "FIELDCOPY",
    [SX_FLEX_ACL_ACTION_SET_EMT] = "SETEMT",
    [SX_FLEX_ACL_ACTION_SET_BUFFER_SNAP] = "SETSNAP",
    [SX_FLEX_ACL_ACTION_TRUNCATION] = "TRUNC",
    [SX_FLEX_ACL_ACTION_SET_VLAN_ETHERTYPE] = "SET_ET",
    [SX_FLEX_ACL_ACTION_FLOW_ESTIMATOR] = "FLOW_EST",
    [SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST] = "LAST",
};
#define API_ACT_2SHORT(act_type)                                \
    (((act_type) > SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST) ? "***" : \
     (api_action_short[act_type] ? : "###"))

static char * hw_action_pos_2short[FLEX_ACL_HW_ACTION_POSITION_LAST_E + 1] = {
    [FLEX_ACL_HW_ACTION_POSITION_INVALID_E] = "***",
    [FLEX_ACL_HW_ACTION_POSITION_IN_TRANS_E] = "INT",
    [FLEX_ACL_HW_ACTION_POSITION_TRANS_TERMINATE_E] = "TRT",
    [FLEX_ACL_HW_ACTION_POSITION_OFF_TRANS_E] = "OFF",
    [FLEX_ACL_HW_ACTION_POSITION_END_E] = "END"
};
#define HW_ACTION_POSITION_2STR(pos)                         \
    (((pos) >= FLEX_ACL_HW_ACTION_POSITION_LAST_E) ? "***" : \
     (hw_action_pos_2short[pos] ? : "###"))

static char * hw_act_hash_type_2str[SXD_HASH_FLEX_ACTION_TYPE_LAST + 1] = {
    [SXD_HASH_FLEX_ACTION_TYPE_LAG] = "LAG",
    [SXD_HASH_FLEX_ACTION_TYPE_ECMP] = "ECMP",
    [SXD_HASH_FLEX_ACTION_TYPE_LAST] = "INVALID"
};
#define HW_ACT_HASH_TYPE_2STR(type)                                    \
    ((type) <                                                          \
     SXD_HASH_FLEX_ACTION_TYPE_LAST) ? hw_act_hash_type_2str[(type)] : \
    "invalid"

static char * hw_act_hash_cmd_2str[SXD_HASH_FLEX_ACTION_CMD_LAST_E + 1] = {
    [SXD_HASH_FLEX_ACTION_CMD_NONE_E] = "NONE",
    [SXD_HASH_FLEX_ACTION_CMD_SET_E] = "SET",
    [SXD_HASH_FLEX_ACTION_CMD_XOR_E] = "XOR",
    [SXD_HASH_FLEX_ACTION_CMD_RANDOM_E] = "RANDOM",
    [SXD_HASH_FLEX_ACTION_CMD_COPY_E] = "COPY",
    [SXD_HASH_FLEX_ACTION_CMD_SWAP_E] = "SWAP",
    [SXD_HASH_FLEX_ACTION_CMD_CRC_E] = "CRC",
    [SXD_HASH_FLEX_ACTION_CMD_LAST_E] = "INVALID",
};
#define HW_ACT_HASH_CMD_2STR(cmd)                                     \
    ((cmd) <                                                          \
     SXD_HASH_FLEX_ACTION_CMD_LAST_E) ? hw_act_hash_cmd_2str[(cmd)] : \
    "invalid"

/************************************************
 *  Global variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
extern boolean_t                            g_flex_acl_initialized;
static flex_acl_pool_map_t                  flex_acl_hw_db_trap_id_db;
static flex_acl_pool_map_t                  flex_acl_hw_db_counter_db;
static flex_acl_pool_map_t                  flex_acl_hw_db_policer_db;
static flex_acl_pool_map_t                  flex_acl_hw_db_mirror_db;
static flex_acl_pool_map_t                  flex_acl_hw_db_tunnel_decap_db;
static flex_acl_pool_map_t                  flex_acl_hw_db_pbs_db;
static flex_acl_pool_map_t                  flex_acl_hw_db_pbilm_db;
static flex_acl_pool_map_t                  flex_acl_hw_db_kvd_db;
static flex_acl_hw_db_region_attribs_pool_t flex_acl_hw_db_region_attribs_db;
static flex_acl_hw_db_key_block_pool_t      flex_acl_hw_db_key_blocks_db;
static flex_acl_pool_map_t                  flex_acl_hw_db_mc_container_db;
static flex_acl_pool_map_t                  flex_acl_hw_db_ecmp_container_db;
static flex_acl_pool_map_t                  flex_acl_hw_db_port_filter_mc_container_db;
static cl_qpool_t                           flex_acl_hw_action_list_qpool_g;
static boolean_t                            flex_acl_hw_db_init_done_g = FALSE;
static boolean_t                            flex_acl_hw_action_list_init_done_g = FALSE;
static flex_acl_hw_db_binding_t             flex_acl_hw_db_late_binding_db_s;
static flex_acl_hw_db_acl_drop_data_fmap_t  flex_acl_hw_db_acl_drop_trap_data_db_s; /* save acl attr like id/region/rule/usr-def-val etc */
static flex_acl_pool_map_t                  flex_acl_hw_db_acl_drop_relocate_db;    /* save index to access entry in above db faster */
static sx_acl_drop_wjh_trap_index_t        *wjh_acl_drp_shm_ptr;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __manager_handlers_db_init();
static void __manager_handlers_db_deinit(boolean_t kvd,
                                         boolean_t mirror,
                                         boolean_t policer,
                                         boolean_t counter,
                                         boolean_t pbs,
                                         boolean_t mc_container,
                                         boolean_t tunnerl_decap,
                                         boolean_t ecmp_container,
                                         boolean_t port_filter_mc_container,
                                         boolean_t pbilm,
                                         boolean_t acl_drop_action,
                                         boolean_t trap_id);
static sx_status_t __flex_acl_hw_db_region_attribs_db_init(uint32_t num_of_regions);
static sx_status_t __flex_acl_hw_db_region_attribs_db_deinit();
static sx_status_t __flex_acl_hw_db_key_blocks_db_init(uint32_t num_of_regions);
static sx_status_t __flex_acl_hw_db_key_blocks_db_deinit();
static sx_status_t __flex_acl_hw_db_acl_drop_trap_db_init();
static sx_status_t __flex_acl_hw_db_acl_drop_trap_db_deinit();
static sx_status_t __acl_drop_trap_usr_def_free_idx_put(cl_list_item_t **usr_idx_list_item_p);
static sx_status_t __acl_drop_trap_usr_def_free_idx_get(cl_list_item_t **usr_idx_list_item_p);
static boolean_t __flex_acl_hw_db_acl_drop_trap_data_fmap_get(sx_acl_pkt_drop_attributes_t *data_p,
                                                              cl_fmap_item_t              **fmap_item_p);
/************************************************
 *  Function implementations
 ***********************************************/

/* helper function */
void __kvd_pool_map_object_destroy_func(void *const p_object, void *context)
{
    sx_status_t rc;

    UNUSED_PARAM(context);
    rc = utils_memory_put(p_object, UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear handles memory: [%u]\n", rc);
    }
}

/* This is a helper function to combine the acl drop user index with the ACL direction
 * into one 20 bits value to be used in the user_def_val of TRAP_W_USERDEF_ACTION action.*/
static uint32_t __acl_drop_user_defined_value_compose(uint32_t acl_drop_usridx, sx_acl_direction_t direction)
{
    uint32_t acl_drop_direction = 0;

    /* Due to limited number of bits available we combine multiple direction into one value */
    switch (direction) {
    case SX_ACL_DIRECTION_INGRESS:
    case SX_ACL_DIRECTION_RIF_INGRESS:
    case SX_ACL_DIRECTION_TPORT_INGRESS:
    case SX_ACL_DIRECTION_CPU_INGRESS:
        acl_drop_direction = ACL_DROP_DIRECTION_INGRESS;
        break;

    case SX_ACL_DIRECTION_EGRESS:
    case SX_ACL_DIRECTION_RIF_EGRESS:
    case SX_ACL_DIRECTION_TPORT_EGRESS:
    case SX_ACL_DIRECTION_CPU_EGRESS:
        acl_drop_direction = ACL_DROP_DIRECTION_EGRESS;
        break;

    case SX_ACL_DIRECTION_MULTI_POINTS_E:
        acl_drop_direction = ACL_DROP_DIRECTION_MULTIPOINT;
        break;

    default:
        SX_LOG_ERR("ACL: Invalid drop direction [%u]\n", acl_drop_direction);
        break;
    }

    return ACL_DROP_USR_DEF_VAL_SET(acl_drop_usridx, acl_drop_direction);
}

/* function to create user defined object. Should be provided with init function */
sx_status_t __kvd_pool_map_object_create_func(void ** p_object, void *param)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t** store_container = NULL;
    flex_acl_hw_db_action_set_t * store_obj = NULL;

    SX_LOG_ENTER();
    if (SX_CHECK_FAIL(rc = utils_check_pointer(p_object, "p_object"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(param, "param"))) {
        goto out;
    }

    store_container = (flex_acl_hw_db_action_set_t**)param;
    store_obj = *store_container;

    rc = utils_clr_memory_get((void**)(p_object), 1, sizeof(flex_acl_hw_db_action_set_t*),
                              UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear handles memory: [%u]\n", rc);
        goto out;
    }
    store_container = (flex_acl_hw_db_action_set_t**)*p_object;
    *store_container = store_obj;
out:
    SX_LOG_EXIT();
    return rc;
}
boolean_t __kvd_compare_func(void* obj, void* other_obj)
{
    flex_acl_hw_db_action_set_t **set = (flex_acl_hw_db_action_set_t**)obj;
    flex_acl_hw_db_action_set_t **other_set = (flex_acl_hw_db_action_set_t**)other_obj;

    return (*set == *other_set);
}

uint64_t __kvd_hash_func(void* obj, uint64_t handle)
{
    UNUSED_PARAM(handle);
    return (uint64_t)((intptr_t)(*(flex_acl_hw_db_action_set_t**)obj));
}

sx_status_t flex_acl_hw_db_kvd_add_entry(kvd_linear_manager_handle_t  handle,
                                         flex_acl_hw_db_action_set_t *hw_action_set)
{
    return flex_acl_pool_map_add_entry(&flex_acl_hw_db_kvd_db, handle, (void*)&hw_action_set);
}

sx_status_t flex_acl_hw_db_kvd_remove_entry(kvd_linear_manager_handle_t  handle,
                                            flex_acl_hw_db_action_set_t *hw_action_set)
{
    return flex_acl_pool_map_remove_entry(&flex_acl_hw_db_kvd_db, handle, (void*)&hw_action_set);
}

sx_status_t flex_acl_hw_db_kvd_action_ref_get(kvd_linear_manager_handle_t   handle,
                                              flex_acl_hw_db_action_set_t **hw_action_set)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    cl_list_t         *obj_list_p;
    cl_list_iterator_t iter;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(hw_action_set, "hw_action_set"))) {
        goto out;
    }

    rc = flex_acl_pool_map_object_list_get(&flex_acl_hw_db_kvd_db, handle, &obj_list_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to get object from pool map, handle: %" PRIu64 "\n", handle);
        goto out;
    }
    iter = cl_list_head(obj_list_p);
    if (iter == cl_list_end(obj_list_p)) {
        SX_LOG_ERR("Failed to get object from list\n");
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *hw_action_set = *((flex_acl_hw_db_action_set_t**)cl_list_obj(iter));
out:
    SX_LOG_EXIT();
    return rc;
}

/* destroy function that good for counter, policer and mirror db */
void __pool_map_object_destroy_func(void *const p_object, void *context)
{
    sx_status_t rc;

    UNUSED_PARAM(context);
    rc = utils_memory_put(p_object, UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear handles memory: [%u]\n", rc);
    }
}
/* create function that good for counter, policer and mirror db */
sx_status_t __pool_map_object_create_func(void ** p_object, void *param)
{
    sx_status_t                   rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_kvd_index_ref  store_obj = {.kvd_index_ptr = 0};
    flex_acl_hw_db_kvd_index_ref *store_container = (flex_acl_hw_db_kvd_index_ref*)param;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(p_object, "p_object"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(param, "param"))) {
        goto out;
    }
    store_obj = *store_container;

    rc = utils_clr_memory_get((void**)(p_object), 1, sizeof(flex_acl_hw_db_kvd_index_ref),
                              UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get memory for index reference: [%u]\n", rc);
        goto out;
    }

    store_container = (flex_acl_hw_db_kvd_index_ref*)*p_object;
    store_container->kvd_index_ptr = store_obj.kvd_index_ptr;
    store_container->is_head = store_obj.is_head;
out:
    SX_LOG_EXIT();
    return rc;
}
/* help function that compare two objects stored in list of pool map item.*/
boolean_t __object_compare_func(void* obj, void* other_obj)
{
    flex_acl_hw_db_kvd_index_ref *ref = (flex_acl_hw_db_kvd_index_ref*)obj;
    flex_acl_hw_db_kvd_index_ref *other_ref = (flex_acl_hw_db_kvd_index_ref*)other_obj;

    return (ref->kvd_index_ptr == other_ref->kvd_index_ptr);
}

uint64_t __object_hash_func(void* obj, uint64_t handle)
{
    UNUSED_PARAM(handle);
    return (uint64_t)((intptr_t)(((flex_acl_hw_db_kvd_index_ref*)obj)->kvd_index_ptr));
}

/* help function for mirror, kvd and policer handles db*/
sx_status_t __flex_acl_hw_db_pool_map_add_entry(flex_acl_pool_map_t* pool_map,
                                                uint64_t             handle,
                                                boolean_t            is_head,
                                                uint32_t            *kvd_index_ptr)
{
    flex_acl_hw_db_kvd_index_ref index_ref = {.kvd_index_ptr = 0};

    index_ref.kvd_index_ptr = kvd_index_ptr;
    index_ref.is_head = is_head;

    return flex_acl_pool_map_add_entry(pool_map, handle, (void*)&index_ref);
}
/* help function for mirror, kvd and policer handles db*/
sx_status_t __flex_acl_hw_db_pool_map_remove_entry(flex_acl_pool_map_t* pool_map,
                                                   uint64_t             handle,
                                                   uint32_t            *kvd_index_ptr)
{
    flex_acl_hw_db_kvd_index_ref index_ref = {.kvd_index_ptr = 0};

    if (NULL == kvd_index_ptr) {
        SX_LOG_ERR("kvd index pointer are null\n");
        return SX_STATUS_PARAM_NULL;
    }

    index_ref.kvd_index_ptr = kvd_index_ptr;

    return flex_acl_pool_map_remove_entry(pool_map, handle, (void*)&index_ref);
}

/* Mirror handle */
sx_status_t flex_acl_hw_db_mirror_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_add_entry(&flex_acl_hw_db_mirror_db, handle, is_head, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_mirror_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_remove_entry(&flex_acl_hw_db_mirror_db, handle, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_mirror_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list)
{
    return flex_acl_pool_map_object_list_get(&flex_acl_hw_db_mirror_db, handle, kvd_index_ref_list);
}

/* Policer handler */
sx_status_t flex_acl_hw_db_policer_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_add_entry(&flex_acl_hw_db_policer_db, handle, is_head, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_policer_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_remove_entry(&flex_acl_hw_db_policer_db, handle, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_policer_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list)
{
    return flex_acl_pool_map_object_list_get(&flex_acl_hw_db_policer_db, handle, kvd_index_ref_list);
}

/* Tunnel decap handle */
sx_status_t flex_acl_hw_db_tunnel_decap_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_add_entry(&flex_acl_hw_db_tunnel_decap_db, handle, is_head, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_tunnel_decap_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_remove_entry(&flex_acl_hw_db_tunnel_decap_db, handle, kvd_index_ptr);
}
sx_status_t flex_acl_hw_db_tunnel_decap_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list)
{
    return flex_acl_pool_map_object_list_get(&flex_acl_hw_db_tunnel_decap_db, handle, kvd_index_ref_list);
}

/* Trap ID handler */
sx_status_t flex_acl_hw_db_trap_id_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_add_entry(&flex_acl_hw_db_trap_id_db, handle, is_head, kvd_index_ptr);
}
sx_status_t flex_acl_hw_db_trap_id_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_remove_entry(&flex_acl_hw_db_trap_id_db, handle, kvd_index_ptr);
}
sx_status_t flex_acl_hw_db_trap_id_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list)
{
    return flex_acl_pool_map_object_list_get(&flex_acl_hw_db_trap_id_db, handle, kvd_index_ref_list);
}

/* Counter handler */
sx_status_t flex_acl_hw_db_counter_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_add_entry(&flex_acl_hw_db_counter_db, handle, is_head, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_counter_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_remove_entry(&flex_acl_hw_db_counter_db, handle, kvd_index_ptr);
}
sx_status_t flex_acl_hw_db_counter_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list)
{
    return flex_acl_pool_map_object_list_get(&flex_acl_hw_db_counter_db, handle, kvd_index_ref_list);
}

/* PBS handler */
sx_status_t flex_acl_hw_db_pbs_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_add_entry(&flex_acl_hw_db_pbs_db, handle, is_head, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_pbs_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_remove_entry(&flex_acl_hw_db_pbs_db, handle, kvd_index_ptr);
}
sx_status_t flex_acl_hw_db_pbs_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list)
{
    return flex_acl_pool_map_object_list_get(&flex_acl_hw_db_pbs_db, handle, kvd_index_ref_list);
}

/* PBILM handler */
sx_status_t flex_acl_hw_db_pbilm_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_add_entry(&flex_acl_hw_db_pbilm_db, handle, is_head, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_pbilm_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_remove_entry(&flex_acl_hw_db_pbilm_db, handle, kvd_index_ptr);
}
sx_status_t flex_acl_hw_db_pbilm_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list)
{
    return flex_acl_pool_map_object_list_get(&flex_acl_hw_db_pbilm_db, handle, kvd_index_ref_list);
}

/* Mc container handle */
sx_status_t flex_acl_hw_db_mc_container_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_add_entry(&flex_acl_hw_db_mc_container_db, handle, is_head, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_mc_container_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_remove_entry(&flex_acl_hw_db_mc_container_db, handle, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_mc_container_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list)
{
    return flex_acl_pool_map_object_list_get(&flex_acl_hw_db_mc_container_db, handle, kvd_index_ref_list);
}

/* ECMP container handle */
sx_status_t flex_acl_hw_db_ecmp_container_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_add_entry(&flex_acl_hw_db_ecmp_container_db, handle, is_head, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_ecmp_container_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr)
{
    return __flex_acl_hw_db_pool_map_remove_entry(&flex_acl_hw_db_ecmp_container_db, handle, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_ecmp_container_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list)
{
    return flex_acl_pool_map_object_list_get(&flex_acl_hw_db_ecmp_container_db, handle, kvd_index_ref_list);
}

/* ACL Drop Action handle */
sx_status_t flex_acl_hw_db_acl_drop_relocate_db_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr)
{
    SX_LOG_DBG("Insert to Reloc db handle= 0x%" PRIx64 " kvd_index_ptr = %p, *kvd_index_ptr =%x\n",
               handle, (void*)kvd_index_ptr, *kvd_index_ptr);
    return __flex_acl_hw_db_pool_map_add_entry(&flex_acl_hw_db_acl_drop_relocate_db, handle, is_head, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_acl_drop_relocate_db_del_entry(uint64_t handle, uint32_t *kvd_index_ptr)
{
    SX_LOG_DBG("Remove from Reloc db handle= 0x%" PRIx64 " kvd_index_ptr = %p, *kvd_index_ptr =%x\n",
               handle, (void*)kvd_index_ptr, *kvd_index_ptr);
    return __flex_acl_hw_db_pool_map_remove_entry(&flex_acl_hw_db_acl_drop_relocate_db, handle, kvd_index_ptr);
}

sx_status_t flex_acl_hw_db_acl_drop_relocate_db_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list)
{
    return flex_acl_pool_map_object_list_get(&flex_acl_hw_db_acl_drop_relocate_db, handle, kvd_index_ref_list);
}

uint32_t flex_acl_hw_db_acl_drop_relocate_db_size_get(void)
{
    return flex_acl_pool_map_size(&flex_acl_hw_db_acl_drop_relocate_db);
}
/* deinit all pool map entities */
static void __manager_handlers_db_deinit(boolean_t kvd,
                                         boolean_t mirror,
                                         boolean_t policer,
                                         boolean_t counter,
                                         boolean_t pbs,
                                         boolean_t mc_container,
                                         boolean_t tunnel_decap,
                                         boolean_t ecmp_container,
                                         boolean_t port_filter_mc_container,
                                         boolean_t pbilm,
                                         boolean_t acl_drop_action,
                                         boolean_t trap_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (kvd) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_kvd_db))) {
            SX_LOG_ERR("Error at deinit kvd db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (mirror) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_mirror_db))) {
            SX_LOG_ERR("Error at deinit mirror db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (mc_container) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_mc_container_db))) {
            SX_LOG_ERR("Error at deinit mirror db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (policer) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_policer_db))) {
            SX_LOG_ERR("Error at deinit policer db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (counter) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_counter_db))) {
            SX_LOG_ERR("Error at deinit counter db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (pbs) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_pbs_db))) {
            SX_LOG_ERR("Error at deinit pbs db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (tunnel_decap) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_tunnel_decap_db))) {
            SX_LOG_ERR("Error at deinit tunnel decap db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (ecmp_container) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_ecmp_container_db))) {
            SX_LOG_ERR("Error at deinit ecmp container db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (port_filter_mc_container) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_port_filter_mc_container_db))) {
            SX_LOG_ERR("Error at deinit port filter mc container db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (pbilm) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_pbilm_db))) {
            SX_LOG_ERR("Error at deinit pbilm db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (acl_drop_action) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_acl_drop_relocate_db))) {
            SX_LOG_ERR("Error at deinit acl drop action db\n, err [%s]\n", sx_status_str(rc));
        }
    }
    if (trap_id) {
        if (SX_CHECK_FAIL(rc = flex_acl_pool_map_deinit(&flex_acl_hw_db_trap_id_db))) {
            SX_LOG_ERR("Error at deinit trap IDs db\n, err [%s]\n", sx_status_str(rc));
        }
    }
}

/* Init function for all kvd, mirror, counter and policer handlers */
static sx_status_t __manager_handlers_db_init()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    /* init kvd handlers db */
    rc = flex_acl_pool_map_init(&flex_acl_hw_db_kvd_db,
                                __kvd_pool_map_object_create_func,
                                __kvd_pool_map_object_destroy_func,
                                __kvd_compare_func,
                                __kvd_hash_func,
                                HANDLER_DB_POOL_MIN_SIZE, HANDLER_DB_POOL_MAX_SIZE, HANDLER_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        goto out;
    }

    rc = flex_acl_pool_map_init(&flex_acl_hw_db_mirror_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                HANDLER_DB_POOL_MIN_SIZE, HANDLER_DB_POOL_MAX_SIZE, HANDLER_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE,
                                     FALSE);
        goto out;
    }

    rc = flex_acl_pool_map_init(&flex_acl_hw_db_policer_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                HANDLER_DB_POOL_MIN_SIZE, HANDLER_DB_POOL_MAX_SIZE, HANDLER_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE);
        goto out;
    }
    rc = flex_acl_pool_map_init(&flex_acl_hw_db_counter_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                HANDLER_DB_POOL_MIN_SIZE, HANDLER_DB_POOL_MAX_SIZE, HANDLER_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE);
        goto out;
    }

    rc = flex_acl_pool_map_init(&flex_acl_hw_db_pbs_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                HANDLER_DB_POOL_MIN_SIZE, HANDLER_DB_POOL_MAX_SIZE, HANDLER_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE);
        goto out;
    }

    rc = flex_acl_pool_map_init(&flex_acl_hw_db_mc_container_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                HANDLER_DB_POOL_MIN_SIZE, HANDLER_DB_POOL_MAX_SIZE, HANDLER_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE);
        goto out;
    }

    rc = flex_acl_pool_map_init(&flex_acl_hw_db_tunnel_decap_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                HANDLER_DB_POOL_MIN_SIZE, HANDLER_DB_POOL_MAX_SIZE, HANDLER_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE);
        goto out;
    }

    rc = flex_acl_pool_map_init(&flex_acl_hw_db_ecmp_container_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                HANDLER_DB_POOL_MIN_SIZE, HANDLER_DB_POOL_MAX_SIZE, HANDLER_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE, FALSE);
        goto out;
    }

    rc = flex_acl_pool_map_init(&flex_acl_hw_db_port_filter_mc_container_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                HANDLER_DB_POOL_MIN_SIZE, HANDLER_DB_POOL_MAX_SIZE, HANDLER_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE, FALSE, FALSE);
        goto out;
    }

    rc = flex_acl_pool_map_init(&flex_acl_hw_db_pbilm_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                HANDLER_DB_POOL_MIN_SIZE, HANDLER_DB_POOL_MAX_SIZE, HANDLER_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE, FALSE);
        goto out;
    }

    rc = flex_acl_pool_map_init(&flex_acl_hw_db_acl_drop_relocate_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                ACL_DROP_DB_POOL_MIN_SIZE, ACL_DROP_DB_POOL_MAX_SIZE, ACL_DROP_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE, FALSE);
        goto out;
    }

    rc = flex_acl_pool_map_init(&flex_acl_hw_db_trap_id_db,
                                __pool_map_object_create_func,
                                __pool_map_object_destroy_func,
                                __object_compare_func,
                                __object_hash_func,
                                ACL_DROP_DB_POOL_MIN_SIZE, ACL_DROP_DB_POOL_MAX_SIZE, ACL_DROP_DB_POOL_GROW_SIZE);
    if (SX_STATUS_SUCCESS != rc) {
        __manager_handlers_db_deinit(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, FALSE);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_db_init(uint32_t num_of_regions)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_status_t rb_rc = SX_STATUS_SUCCESS;
    cl_status_t cl_status = CL_SUCCESS;

    SX_LOG_ENTER();

    /* Init the ACL Drop Trap Attribute Db */
    rc = __flex_acl_hw_db_acl_drop_trap_db_init();
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to init ACL Drop db: [%u]\n", rc);
        goto out;
    }
    /* init handlers db*/
    rc = __manager_handlers_db_init();
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to init handlers db: [%u]\n", rc);
        goto dealloc_acldrop;
    }

    rc = __flex_acl_hw_db_region_attribs_db_init(num_of_regions);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to init region attributes db: [%u]\n", rc);
        goto dealloc_handlers;
    }

    rc = __flex_acl_hw_db_key_blocks_db_init(num_of_regions);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to init key blocks db: [%u]\n", rc);
        goto dealloc_attribs;
    }

    cl_status = CL_QPOOL_INIT(&flex_acl_hw_action_list_qpool_g, FLEX_ACL_HW_ACTIONS_PER_RULE_MIN,
                              FLEX_ACL_HW_ACTIONS_PER_RULE_MAX, 10, sizeof(hw_action_list_entry_t), NULL, NULL, NULL);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("CL_QPOOL_INIT failed [%s]\n", CL_STATUS_MSG(cl_status));
        rc = SX_STATUS_ERROR;
        goto dealloc_blocks;
    }

    cl_status = CL_QPOOL_INIT(&flex_acl_hw_db_late_binding_db_s.entry_pool, FLEX_ACL_HW_BINDING_POINT_MIN,
                              FLEX_ACL_HW_BINDING_POINT_MAX, 10, sizeof(flex_acl_hw_db_binding_entry_t),
                              NULL, NULL, NULL);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("CL_QPOOL_INIT failed [%s]\n", CL_STATUS_MSG(cl_status));
        rc = SX_STATUS_ERROR;
        goto dealloc_blocks;
    }
    cl_qmap_init(&flex_acl_hw_db_late_binding_db_s.port_map);
    cl_qmap_init(&flex_acl_hw_db_late_binding_db_s.vlan_map);
    cl_qmap_init(&flex_acl_hw_db_late_binding_db_s.rif_map);

    flex_acl_hw_db_init_done_g = TRUE;
    return SX_STATUS_SUCCESS;

dealloc_blocks:
    if (SX_CHECK_FAIL(rb_rc = __flex_acl_hw_db_key_blocks_db_deinit())) {
        SX_LOG_ERR("Fatal error at rollback\n, err [%s]\n", sx_status_str(rb_rc));
    }
dealloc_attribs:
    if (SX_CHECK_FAIL(rb_rc = __flex_acl_hw_db_region_attribs_db_deinit())) {
        SX_LOG_ERR("Fatal error at rollback\n, err [%s]\n", sx_status_str(rb_rc));
    }
dealloc_handlers:
    __manager_handlers_db_deinit(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE);

dealloc_acldrop:
    if (SX_CHECK_FAIL(rb_rc = __flex_acl_hw_db_acl_drop_trap_db_deinit())) {
        SX_LOG_ERR("Fatal error at acl drop rollback\n, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_db_deinit()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!flex_acl_hw_db_init_done_g) {
        SX_LOG_INF("ACL HW DB was not initialized - deinit success.\n");
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    CL_QPOOL_DESTROY(&flex_acl_hw_action_list_qpool_g);
    CL_QPOOL_DESTROY(&flex_acl_hw_db_late_binding_db_s.entry_pool);

    /* init handlers db*/
    __manager_handlers_db_deinit(TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE, TRUE);

    rc = __flex_acl_hw_db_region_attribs_db_deinit();
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to deinit region attributes db: [%u]\n", rc);
    }

    rc = __flex_acl_hw_db_key_blocks_db_deinit();
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to deinit region attributes db: [%u]\n", rc);
    }

    rc = __flex_acl_hw_db_acl_drop_trap_db_deinit();
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to deinit ACL Drop db: [%u]\n", rc);
    }

    flex_acl_hw_db_init_done_g = FALSE;

out:
    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}
/* The HW action set db is helps to handle actions manipulations. The structures describe HW layout
 * the action should be created by user and added to a SW rule as handle. At rule destruction, user should destroy action set also*/
sx_status_t flex_acl_hw_db_action_set_create(flex_acl_hw_db_register_action_set_t *register_action_set,
                                             flex_acl_db_flex_rule_t              *rule_ptr,
                                             void                               ** handle)
{
    flex_acl_hw_db_action_set_t *new_action_set = NULL;
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    sx_status_t                  rb_rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(rule_ptr, "rule_ptr"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(handle, "handle"))) {
        goto out;
    }


    rc = utils_clr_memory_get((void**)(&new_action_set),
                              1,
                              sizeof(flex_acl_hw_db_action_set_t),
                              UTILS_MEM_TYPE_ID_ACL_E);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG(SX_LOG_ERROR, "Failed allocate hw db action set memory\n");
        goto out;
    }


    rc = cl_list_init(&new_action_set->kvd_action_set_list, 1);
    if (CL_SUCCESS != rc) {
        SX_LOG(SX_LOG_ERROR, "action set create with cl_list_init failed\n");
        goto error;
    }

    new_action_set->kvd_handle = FLEX_ACL_INVALID_HANDLE;

    new_action_set->kvd_action_set_count = 0;
    new_action_set->related_rule = rule_ptr;
    new_action_set->action_set = *register_action_set;
    new_action_set->sum_of_actions += register_action_set->actions_count;

    *handle = (void*)new_action_set;

    goto out;

error:
    if (SX_CHECK_FAIL(rb_rc = utils_memory_put(new_action_set, UTILS_MEM_TYPE_ID_ACL_E))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
    *handle = NULL;
out:
    SX_LOG_EXIT();
    return rc;
}

/* help function that destroy kvd action set stored in actions set list */
void __kvd_action_list_destroy_func(void *const p_object, void *context)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    UNUSED_PARAM(context);
    rc = utils_memory_put(p_object, UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear action list memory: [%u]\n", rc);
    }
    SX_LOG_EXIT();
}

/* Destroy the referenced by handle hw action set and all inner structures.*/
sx_status_t flex_acl_hw_db_action_set_destroy(void* handle)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t *hw_action_set = (flex_acl_hw_db_action_set_t*)handle;

    SX_LOG_ENTER();
    SX_LOG_DBG("FLOWDC destroyed action set %p\n", handle);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(handle, "handle"))) {
        goto out;
    }

    cl_list_apply_func(&hw_action_set->kvd_action_set_list, __kvd_action_list_destroy_func, NULL);
    cl_list_remove_all(&hw_action_set->kvd_action_set_list);
    cl_list_destroy(&hw_action_set->kvd_action_set_list);

    rc = utils_memory_put(hw_action_set, UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to clear hw action set memory : [%u]\n", rc);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* Return the reference to inner buffer that holds register's action set. Modifying the buffer is actually
 * modifying the actions in action set*/
sx_status_t flex_acl_hw_db_get_register_action_set(void* handle, flex_acl_hw_db_register_action_set_t **action_set_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    flex_acl_hw_db_action_set_t *hw_action_set = (flex_acl_hw_db_action_set_t*)handle;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(handle, "handle"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(action_set_p, "action_set_p"))) {
        goto out;
    }

    *action_set_p = &hw_action_set->action_set;

out:
    SX_LOG_EXIT();
    return rc;
}
/* Add action set to list of kvd action sets. The function adds the action set to tail of list, so last added action set
 * is last set in hw register action set structure*/
sx_status_t flex_acl_hw_db_tail_add_kvd_action_set(void* handle, flex_acl_hw_db_kvd_action_set_t *kvd_action_set)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t     *hw_action_set = (flex_acl_hw_db_action_set_t*)handle;
    flex_acl_hw_db_kvd_action_set_t* new_kvd_action_set = NULL;

    SX_LOG_ENTER();
    if (SX_CHECK_FAIL(rc = utils_check_pointer(handle, "handle"))) {
        goto out;
    }

    rc = utils_clr_memory_get((void**)(&new_kvd_action_set),
                              1,
                              sizeof(flex_acl_hw_db_kvd_action_set_t),
                              UTILS_MEM_TYPE_ID_ACL_E);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG(SX_LOG_ERROR, "Allocate hw db kvd action set memory\n");
        goto out;
    }
    *new_kvd_action_set = *kvd_action_set;

    /* insert created object to list */
    rc = cl_list_insert_tail(&hw_action_set->kvd_action_set_list, new_kvd_action_set);
    if (CL_SUCCESS != rc) {
        SX_LOG_ERR("Failed to insert item to list of kvd action sets\n");
        __kvd_action_list_destroy_func(new_kvd_action_set, NULL);
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    /* update counters */
    hw_action_set->sum_of_actions += kvd_action_set->actions_count;
    hw_action_set->kvd_action_set_count++;

out:
    SX_LOG_EXIT();
    return rc;
}
/* Return reference to inner kvd action set structure, pointed by index. The index starts from 0, where 0 is first kvd action set
 * Modifying returned buffer is modifying kvd action set structure */
sx_status_t flex_acl_hw_db_get_kvd_action_set(void                            * handle,
                                              uint32_t                          action_set_idx,
                                              flex_acl_hw_db_kvd_action_set_t** kvd_action_set)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t *hw_action_set = (flex_acl_hw_db_action_set_t*)handle;
    cl_list_iterator_t           iter = NULL;
    cl_list_iterator_t           list_end = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(handle, "handle"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(kvd_action_set, "kvd_action_set"))) {
        goto out;
    }

    if (hw_action_set->kvd_action_set_count <= action_set_idx) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Go to the desired index in the list*/
    iter = cl_list_head(&hw_action_set->kvd_action_set_list);
    list_end = cl_list_end(&hw_action_set->kvd_action_set_list);
    while (action_set_idx) {
        if (iter == list_end) {
            SX_LOG_ERR("The index exceeds items count in the list\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        iter = cl_list_next(iter);
        action_set_idx--;
    }
    *kvd_action_set = cl_list_obj(iter);
out:
    SX_LOG_EXIT();
    return rc;
}
/* Get reference to kvd action sets list. The list shouldn't to be modified.*/
sx_status_t flex_acl_hw_db_get_kvd_action_set_list(void* handle, const cl_list_t **kvd_action_set_list)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t *hw_action_set = (flex_acl_hw_db_action_set_t*)handle;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(handle, "handle"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(kvd_action_set_list, "kvd_action_set_list"))) {
        goto out;
    }

    *kvd_action_set_list = &hw_action_set->kvd_action_set_list;
out:
    SX_LOG_EXIT();
    return rc;
}

/* Get counter of kvd action sets.*/
sx_status_t flex_acl_hw_db_get_kvd_action_set_count(void* handle, uint32_t *action_set_count)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t *hw_action_set = (flex_acl_hw_db_action_set_t*)handle;


    if (SX_CHECK_FAIL(rc = utils_check_pointer(handle, "handle"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(action_set_count, "action_set_count"))) {
        goto out;
    }

    *action_set_count = hw_action_set->kvd_action_set_count;
out:
    return rc;
}

/* Get total sum of actions within register action set and kvd action set*/
sx_status_t flex_acl_hw_db_get_sum_of_actions(void* handle, uint32_t *sum_of_actions)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t *hw_action_set = (flex_acl_hw_db_action_set_t*)handle;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(handle, "handle"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(sum_of_actions, "sum_of_actions"))) {
        goto out;
    }

    *sum_of_actions = hw_action_set->sum_of_actions;
out:
    return rc;
}


/* init region attributes db */
static sx_status_t __flex_acl_hw_db_region_attribs_db_init(uint32_t num_of_regions)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_status_t rb_rc = SX_STATUS_SUCCESS;
    cl_status_t cl_rc = CL_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    rc = utils_clr_memory_get((void**)(&flex_acl_hw_db_region_attribs_db.entries),
                              num_of_regions,
                              sizeof(flex_acl_hw_db_region_attribs_entry_t),
                              UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate region attributes memory: [%u]\n", rc);
        goto out;
    }
    flex_acl_hw_db_region_attribs_db.count = num_of_regions;

    /* init the pool of free entries*/
    cl_rc = cl_list_init(&flex_acl_hw_db_region_attribs_db.free_pool, num_of_regions);
    if (CL_SUCCESS != cl_rc) {
        SX_LOG(SX_LOG_ERROR, "pool map cl_list_init failed\n");
        goto error;
    }
    /* push the entries to the pool */
    for (i = 0; i < num_of_regions; i++) {
        flex_acl_hw_db_region_attribs_db.entries[i].allocated = FLEX_ACL_DB_FREE;
        flex_acl_hw_db_region_attribs_db.entries[i].idx = i;
        cl_rc = cl_list_insert_tail(&flex_acl_hw_db_region_attribs_db.free_pool,
                                    &flex_acl_hw_db_region_attribs_db.entries[i]);
        if (CL_SUCCESS != cl_rc) {
            SX_LOG(SX_LOG_ERROR, "Failed to return object to free pool\n");
            goto error;
        }
    }
    goto out;

error:
    rc = SX_STATUS_ERROR;
    if (SX_CHECK_FAIL(rb_rc = __flex_acl_hw_db_region_attribs_db_deinit())) {
        SX_LOG_ERR("Fatal error at rollback\n, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_db_region_attribs_db_deinit()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    if (flex_acl_hw_db_region_attribs_db.entries == NULL) {
        goto out;
    }

    if (cl_is_list_inited(&flex_acl_hw_db_region_attribs_db.free_pool)) {
        cl_list_remove_all(&flex_acl_hw_db_region_attribs_db.free_pool);
        cl_list_destroy(&flex_acl_hw_db_region_attribs_db.free_pool);
    }

    rc = utils_memory_put(flex_acl_hw_db_region_attribs_db.entries, UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to free region attributes memory: [%u]\n", rc);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_db_set_region_attributes(flex_acl_hw_db_region_attribs_t* region_attribs, uint32_t* handle)
{
    flex_acl_hw_db_region_attribs_entry_t *entry = NULL;
    sx_status_t                            rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(handle, "handle"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(region_attribs, "region_attribs"))) {
        goto out;
    }

    /* take free item from list */
    entry = (flex_acl_hw_db_region_attribs_entry_t*)cl_list_remove_head(&flex_acl_hw_db_region_attribs_db.free_pool);
    if (entry == NULL) {
        SX_LOG(SX_LOG_ERROR, "No free entries in region attributes pool\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    /* set item allocated and copy attributes */
    entry->allocated = FLEX_ACL_DB_ALLOCATED;
    entry->attribs = *region_attribs;

    *handle = entry->idx;
out:
    SX_LOG_EXIT();
    return rc;
}

/* return the reference to inner structure */
sx_status_t flex_acl_hw_db_get_region_attributes(uint32_t handle, flex_acl_hw_db_region_attribs_t** region_attribs)
{
    uint32_t    index = handle;
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(region_attribs, "region_attribs"))) {
        goto out;
    }

    /* parameters validation */
    if (index >= flex_acl_hw_db_region_attribs_db.count) {
        SX_LOG(SX_LOG_ERROR, "Provided handle are not valid\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (flex_acl_hw_db_region_attribs_db.entries[index].allocated == FLEX_ACL_DB_FREE) {
        SX_LOG(SX_LOG_ERROR, "Provided handle are not valid\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    /* return the reference to inner structure */
    *region_attribs = &flex_acl_hw_db_region_attribs_db.entries[index].attribs;
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_db_remove_region_attributes(uint32_t handle)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    cl_status_t cl_rc = CL_SUCCESS;
    uint32_t    index = handle;

    SX_LOG_ENTER();
    /* parameters validation */
    if (index >= flex_acl_hw_db_region_attribs_db.count) {
        SX_LOG(SX_LOG_ERROR, "Provided handle are not valid\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (flex_acl_hw_db_region_attribs_db.entries[index].allocated == FLEX_ACL_DB_FREE) {
        SX_LOG(SX_LOG_ERROR, "Provided handle are not valid\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* return the object to free pool */
    flex_acl_hw_db_region_attribs_db.entries[index].allocated = FLEX_ACL_DB_FREE;
    cl_rc = cl_list_insert_head(&flex_acl_hw_db_region_attribs_db.free_pool,
                                &flex_acl_hw_db_region_attribs_db.entries[index]);
    if (CL_SUCCESS != cl_rc) {
        SX_LOG(SX_LOG_ERROR, "Failed to return object to free pool\n");
        rc = SX_STATUS_ERROR;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_db_set_region_bulk_write(sx_acl_region_id_t region_id, boolean_t bulk_write)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t *region_attribs = NULL;
    flex_acl_db_acl_region_t        *region = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_region_get(region_id, &region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region id [%u]\n", region_id);
        goto out;
    }

    rc = flex_acl_hw_db_get_region_attributes(region->hw_region_attribs_handle, &region_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Region attributes get error, region_id[%u]\n", region_id);
        goto out;
    }

    region_attribs->bulk_write = bulk_write;

out:
    SX_LOG_EXIT();
    return rc;
}


/* init region attributes db */
static sx_status_t __flex_acl_hw_db_key_blocks_db_init(uint32_t num_of_regions)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_status_t rb_rc = SX_STATUS_SUCCESS;
    cl_status_t cl_rc = CL_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    rc = utils_clr_memory_get((void**)(&flex_acl_hw_db_key_blocks_db.entries),
                              num_of_regions,
                              sizeof(flex_acl_hw_db_key_blocks_entry_t),
                              UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate region attributes memory : [%s]\n", sx_status_str(rc));
        goto out;
    }
    flex_acl_hw_db_key_blocks_db.count = num_of_regions;

    /* init the pool of free entries*/
    cl_rc = cl_list_init(&flex_acl_hw_db_key_blocks_db.free_pool, 1);
    if (CL_SUCCESS != cl_rc) {
        SX_LOG(SX_LOG_ERROR, "pool map cl_list_init failed\n");
        goto error;
    }
    /* push the entries to the pool */
    for (i = 0; i < num_of_regions; i++) {
        flex_acl_hw_db_key_blocks_db.entries[i].allocated = FLEX_ACL_DB_FREE;
        flex_acl_hw_db_key_blocks_db.entries[i].idx = i;
        cl_rc = cl_list_insert_tail(&flex_acl_hw_db_key_blocks_db.free_pool, &flex_acl_hw_db_key_blocks_db.entries[i]);
        if (CL_SUCCESS != cl_rc) {
            SX_LOG(SX_LOG_ERROR, "Failed to return object to free pool\n");
            goto error;
        }
    }
    goto out;

error:
    rc = SX_STATUS_ERROR;
    if (SX_CHECK_FAIL(rb_rc = __flex_acl_hw_db_key_blocks_db_deinit())) {
        SX_LOG_ERR("Fatal error at rollback\n, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_hw_db_key_blocks_db_deinit()
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (flex_acl_hw_db_key_blocks_db.entries == NULL) {
        goto out;
    }

    if (cl_is_list_inited(&flex_acl_hw_db_key_blocks_db.free_pool)) {
        cl_list_remove_all(&flex_acl_hw_db_key_blocks_db.free_pool);
        cl_list_destroy(&flex_acl_hw_db_key_blocks_db.free_pool);
    }

    rc = utils_memory_put(flex_acl_hw_db_key_blocks_db.entries, UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to free region attributes memory: [%u]\n", rc);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_db_set_key_blocks(sx_acl_key_block_e* key_blocks, uint32_t count, uint32_t* handle)
{
    flex_acl_hw_db_key_blocks_entry_t *entry = NULL;
    uint32_t                           i = 0;
    sx_status_t                        rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(handle, "handle"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(key_blocks, "key_blocks"))) {
        goto out;
    }

    /* take free item from list */
    entry = (flex_acl_hw_db_key_blocks_entry_t*)cl_list_remove_head(&flex_acl_hw_db_key_blocks_db.free_pool);
    if (entry == NULL) {
        SX_LOG_ERR("No free entries in region attributes pool\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    /* set item allocated and copy attributes */
    entry->allocated = FLEX_ACL_DB_ALLOCATED;
    for (i = 0; i < count; i++) {
        entry->key_blocks[i] = key_blocks[i];
    }
    entry->count = count;
    *handle = entry->idx;

out:
    SX_LOG_EXIT();
    return rc;
}

/* return the reference to inner structure */
sx_status_t flex_acl_hw_db_get_key_blocks(uint32_t handle, sx_acl_key_block_e** key_blocks, uint32_t* count)
{
    uint32_t    index = handle;
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(key_blocks, "key_blocks"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(count, "count"))) {
        goto out;
    }

    /* parameters validation */
    if (index >= flex_acl_hw_db_key_blocks_db.count) {
        SX_LOG(SX_LOG_ERROR, "Provided handle are not valid\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (flex_acl_hw_db_key_blocks_db.entries[index].allocated == FLEX_ACL_DB_FREE) {
        SX_LOG(SX_LOG_ERROR, "Provided handle are not valid\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    /* return the reference to inner structure */
    *key_blocks = flex_acl_hw_db_key_blocks_db.entries[index].key_blocks;
    *count = flex_acl_hw_db_key_blocks_db.entries[index].count;
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_db_remove_key_blocks(uint32_t handle)
{
    cl_status_t cl_rc = CL_SUCCESS;
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    index = handle;

    SX_LOG_ENTER();

    /* parameters validation */
    if (index >= flex_acl_hw_db_key_blocks_db.count) {
        SX_LOG(SX_LOG_ERROR, "Provided handle are not valid\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (flex_acl_hw_db_key_blocks_db.entries[index].allocated == FLEX_ACL_DB_FREE) {
        SX_LOG(SX_LOG_ERROR, "Provided handle are not valid\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* return the object to free pool */
    flex_acl_hw_db_key_blocks_db.entries[index].allocated = FLEX_ACL_DB_FREE;
    cl_rc = cl_list_insert_head(&flex_acl_hw_db_key_blocks_db.free_pool, &flex_acl_hw_db_key_blocks_db.entries[index]);
    if (CL_SUCCESS != cl_rc) {
        SX_LOG(SX_LOG_ERROR, "Failed to return object to free pool\n");
        rc = SX_STATUS_ERROR;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return rc;
}

static void __flex_acl_hw_db_populate_action(flex_acl_hw_action_t *action, hw_action_dump_descr_t *action_dump_descr)
{
    static uint32_t zero = 0;

    switch (action->slot.type) {
    case SXD_ACTION_TYPE_VLAN_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ACT_VLAN_TAG_CMD_2STR(
            action->slot.fields.action_vlan.v_tag_cmd);
        action_dump_descr[action->slot.type].columns_p[6].data = ACT_VLAN_VID_CMD_2STR(
            action->slot.fields.action_vlan.vid_cmd);
        action_dump_descr[action->slot.type].columns_p[7].data =
            ((uint8_t*)&(action->slot.fields.action_vlan.vid_val));
        action_dump_descr[action->slot.type].columns_p[8].data = ACT_VLAN_ETHERTYPED_CMD_2STR(
            action->slot.fields.action_vlan.ethertype_cmd);
        action_dump_descr[action->slot.type].columns_p[9].data =
            ((uint8_t*)&(action->slot.fields.action_vlan.ethertype_val));
        action_dump_descr[action->slot.type].columns_p[10].data = ACT_VLAN_PCP_CMD_2STR(
            action->slot.fields.action_vlan.pcp_cmd);
        action_dump_descr[action->slot.type].columns_p[11].data =
            ((uint8_t*)&(action->slot.fields.action_vlan.pcp_val));
        action_dump_descr[action->slot.type].columns_p[12].data = ACT_VLAN_DEI_CMD_2STR(
            action->slot.fields.action_vlan.dei_cmd);
        action_dump_descr[action->slot.type].columns_p[13].data =
            ((uint8_t*)&(action->slot.fields.action_vlan.dei_val));
        action_dump_descr[action->slot.type].columns_p[14].data = ((uint8_t*)&(action->slot.fields.action_vlan.defer));
        break;

    case SXD_ACTION_TYPE_MAC_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ACT_MAC_TTL_CMD_2STR(
            action->slot.fields.action_mac.ttl_cmd);
        action_dump_descr[action->slot.type].columns_p[6].data =
            ((uint8_t*)&(action->slot.fields.action_mac.ttl_value));
        action_dump_descr[action->slot.type].columns_p[7].data = ACT_MAC_CMD_2STR(
            action->slot.fields.action_mac.mac_cmd);
        action_dump_descr[action->slot.type].columns_p[8].data = ((uint8_t*)&(action->slot.fields.action_mac.mac));
        action_dump_descr[action->slot.type].columns_p[9].data = ((uint8_t*)&(action->slot.fields.action_mac.defer));
        break;

    case SXD_ACTION_TYPE_QOS_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ACT_QOS_ECN_CMD_2STR(
            action->slot.fields.action_qos.ecn_cmd);
        action_dump_descr[action->slot.type].columns_p[6].data = ((uint8_t*)&(action->slot.fields.action_qos.ecn_val));
        action_dump_descr[action->slot.type].columns_p[7].data = ACT_QOS_COLOR_CMD_2STR(
            action->slot.fields.action_qos.color_cmd);
        action_dump_descr[action->slot.type].columns_p[8].data = ACT_QOS_COLOR_TYPE_2STR(
            action->slot.fields.action_qos.color_val);
        action_dump_descr[action->slot.type].columns_p[9].data = ACT_QOS_DSCP_CMD_2STR(
            action->slot.fields.action_qos.dscp_cmd);
        action_dump_descr[action->slot.type].columns_p[10].data =
            ((uint8_t*)&(action->slot.fields.action_qos.dscp_val));
        action_dump_descr[action->slot.type].columns_p[11].data = ACT_QOS_SWITCH_PRIO_CMD_2STR(
            action->slot.fields.action_qos.switch_prio_cmd);
        action_dump_descr[action->slot.type].columns_p[12].data =
            ((uint8_t*)&(action->slot.fields.action_qos.switch_prio_val));
        action_dump_descr[action->slot.type].columns_p[13].data = ACT_QOS_REWRITE_CMD_2STR(
            action->slot.fields.action_qos.rewrite_dscp_cmd);
        action_dump_descr[action->slot.type].columns_p[14].data = ACT_QOS_REWRITE_CMD_2STR(
            action->slot.fields.action_qos.rewrite_pcp_cmd);
        action_dump_descr[action->slot.type].columns_p[15].data = ACT_QOS_TC_CMD_2STR(
            action->slot.fields.action_qos.traffic_class_cmd);
        action_dump_descr[action->slot.type].columns_p[16].data = ((uint8_t*)&(action->slot.fields.action_qos.tc));
        action_dump_descr[action->slot.type].columns_p[17].data = ((uint8_t*)&(action->slot.fields.action_mac.defer));
        break;

    case SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E:
        action_dump_descr[action->slot.type].columns_p[11].data =
            ((uint8_t*)&(action->slot.fields.action_trap.user_def_val));

    /* fall through */
    case SXD_ACTION_TYPE_TRAP_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ACT_TRAP_ACTION_2STR(
            action->slot.fields.action_trap.trap_action);
        action_dump_descr[action->slot.type].columns_p[6].data = ACT_TRAP_FW_ACTION_2STR(
            action->slot.fields.action_trap.forward_action);
        action_dump_descr[action->slot.type].columns_p[7].data =
            ((uint8_t*)&(action->slot.fields.action_trap.trap_id));
        action_dump_descr[action->slot.type].columns_p[8].data =
            ((uint8_t*)&(action->slot.fields.action_trap.mirror_agent));
        action_dump_descr[action->slot.type].columns_p[9].data =
            ((uint8_t*)&(action->slot.fields.action_trap.mirror_enable));
        action_dump_descr[action->slot.type].columns_p[10].data = ((uint8_t*)&(action->slot.fields.action_trap.defer));
        action_dump_descr[action->slot.type].columns_p[11].data =
            ((uint8_t*)&(action->slot.fields.action_trap.preserve_user_def_val));
        break;

    case SXD_ACTION_TYPE_MIRROR_SAMPLER_E:
        action_dump_descr[action->slot.type].columns_p[5].data =
            ((uint8_t*)&(action->slot.fields.action_mirror_sampler.mirror_agent));
        action_dump_descr[action->slot.type].columns_p[6].data =
            ((uint32_t*)&(action->slot.fields.action_mirror_sampler.mirror_probability_rate));
        break;

    case SXD_ACTION_TYPE_FORWARD_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ACT_FORWARD_TYPE_2STR(
            action->aux_slot.fields.action_forward.type);
        action_dump_descr[action->slot.type].columns_p[6].data = ((uint8_t*)&(action->pbs_id));
        switch (action->aux_slot.fields.action_forward.type) {
        case SXD_FORWARD_FLEX_ACTION_TYPE_PBS_E:
            action_dump_descr[action->slot.type].columns_p[7].data =
                ((uint8_t*)&(action->slot.fields.action_forward.record.pbs_ptr));
            action_dump_descr[action->slot.type].columns_p[8].data = ((uint8_t*)&(zero));
            action_dump_descr[action->slot.type].columns_p[9].data = ((uint8_t*)&(zero));
            break;

        case SXD_FORWARD_FLEX_ACTION_TYPE_OUTPUT_E:
            action_dump_descr[action->slot.type].columns_p[7].data =
                ((uint8_t*)&(action->slot.fields.action_forward.record.output.pbs_ptr));
            action_dump_descr[action->slot.type].columns_p[8].data =
                ((uint8_t*)&(action->slot.fields.action_forward.record.output.in_port));
            action_dump_descr[action->slot.type].columns_p[9].data =
                ((uint8_t*)&(action->slot.fields.action_forward.record.output.defer));
            break;

        default:
            break;
        }
        break;

    case SXD_ACTION_TYPE_POLICING_COUNTING_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ACT_PC_TYPE_2STR(
            action->slot.fields.action_policing_monitoring.c_p);
        action_dump_descr[action->slot.type].columns_p[6].data =
            ((uint8_t*)&(action->slot.fields.action_policing_monitoring.counter_set.type));
        action_dump_descr[action->slot.type].columns_p[7].data =
            ((uint8_t*)&(action->slot.fields.action_policing_monitoring.counter_set.index));
        action_dump_descr[action->slot.type].columns_p[8].data =
            ((uint8_t*)&(action->slot.fields.action_policing_monitoring.pid));
        break;

    case SXD_ACTION_TYPE_FLOW_ESTIMATOR_E:
        action_dump_descr[action->slot.type].columns_p[5].data =
            ((uint8_t*)&(action->slot.fields.action_flow_estimator.profile_key.profile_id));
        action_dump_descr[action->slot.type].columns_p[6].data =
            ((uint8_t*)&(action->slot.fields.action_flow_estimator.bulk_counter.index));
        break;

    case SXD_ACTION_TYPE_META_DATA_E:
        action_dump_descr[action->slot.type].columns_p[5].data =
            ((uint8_t*)&(action->slot.fields.action_metadata.meta_data));
        action_dump_descr[action->slot.type].columns_p[6].data =
            ((uint8_t*)&(action->slot.fields.action_metadata.mask));
        break;

    case SXD_ACTION_TYPE_VIRTUAL_FORWARDING_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ACT_VF_CMD_2STR(
            action->slot.fields.action_virtual_forward.vr_cmd);
        action_dump_descr[action->slot.type].columns_p[6].data =
            ((uint8_t*)&(action->slot.fields.action_virtual_forward.virtual_router));
        action_dump_descr[action->slot.type].columns_p[7].data = ACT_FID_CMD_2STR(
            action->slot.fields.action_virtual_forward.fid_cmd);
        action_dump_descr[action->slot.type].columns_p[8].data =
            ((uint8_t*)&(action->slot.fields.action_virtual_forward.fid));
        break;

    case SXD_ACTION_TYPE_IGNORE_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ACT_IGNORE_STP_TYPE_2STR(
            action->slot.fields.action_ignore.ignore_stp);
        action_dump_descr[action->slot.type].columns_p[6].data = ACT_IGNORE_VL_FILER_2STR(
            action->slot.fields.action_ignore.ignore_vl_filter);
        action_dump_descr[action->slot.type].columns_p[7].data = ACT_IGNORE_DISABLE_LEARNING_2STR(
            action->slot.fields.action_ignore.disable_learning);
        action_dump_descr[action->slot.type].columns_p[8].data = ACT_IGNORE_DISABLE_OVL_LEARNING_2STR(
            action->slot.fields.action_ignore.disable_ovl_learning);
        break;

    case SXD_ACTION_TYPE_MC_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ACT_IMC_RPF_ACTION_2STR(
            action->slot.fields.action_mc.rpf_action);
        action_dump_descr[action->slot.type].columns_p[6].data = ACT_MC_AIR_TYPE_2STR(
            action->slot.fields.action_mc.eir_type);
        action_dump_descr[action->slot.type].columns_p[7].data =
            ((uint8_t*)&(action->slot.fields.action_mc.expected_irif));
        action_dump_descr[action->slot.type].columns_p[8].data =
            ((uint8_t*)&(action->slot.fields.action_mc.expected_irif_list_index));
        action_dump_descr[action->slot.type].columns_p[9].data = ((uint8_t*)&(action->slot.fields.action_mc.vrmid));
        action_dump_descr[action->slot.type].columns_p[10].data =
            ((uint8_t*)&(action->slot.fields.action_mc.rigr_rmid_index));
        break;

    case SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ACT_UC_ROUTE_2STR(
            action->slot.fields.action_uc_router.type);
        switch (action->slot.fields.action_uc_router.type) {
        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_TUNNL_TERMINIATION_E:
            action_dump_descr[action->slot.type].columns_p[6].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.tunnul_termination.tunnul_ptr));
            action_dump_descr[action->slot.type].columns_p[7].data = ((uint8_t*)&(zero));
            break;

        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_LOCAL_E:
            action_dump_descr[action->slot.type].columns_p[6].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.ip_local.local_erif));
            action_dump_descr[action->slot.type].columns_p[7].data = ((uint8_t*)&(zero));
            break;

        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_IP_REMOTE_E:
            action_dump_descr[action->slot.type].columns_p[6].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.ip_remote.adjacency_index));
            action_dump_descr[action->slot.type].columns_p[7].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.ip_remote.ecmp_size));
            break;

        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_NHLFE_E:
            action_dump_descr[action->slot.type].columns_p[6].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.mpls_nhlfe.nhlfe_ptr));
            action_dump_descr[action->slot.type].columns_p[7].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.mpls_nhlfe.ecmp_size));
            break;

        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_MPLS_ILM_E:
            action_dump_descr[action->slot.type].columns_p[6].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.mpls_ilm.ilm_ptr));
            action_dump_descr[action->slot.type].columns_p[7].data = ((uint8_t*)&(zero));
            break;

        case SXD_UC_ROUTER_FLEX_ACTION_TYPE_AR_E:
            action_dump_descr[action->slot.type].columns_p[6].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.ar_uc_route.ar_lookup_prof_id));
            action_dump_descr[action->slot.type].columns_p[7].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.ar_uc_route.ecmp_size));
            action_dump_descr[action->slot.type].columns_p[8].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.ar_uc_route.arlpgt_pointer));
            action_dump_descr[action->slot.type].columns_p[9].data =
                ((uint8_t*)&(action->slot.fields.action_uc_router.structs.ar_uc_route.arft_pointer));
            break;

        default:
            break;
        }
        break;

    case SXD_ACTION_TYPE_PORT_FILTER_E:
        action_dump_descr[action->slot.type].columns_p[5].data = ((uint8_t*)&(action->mc_container));
        action_dump_descr[action->slot.type].columns_p[6].data =
            ((uint8_t*)&(action->slot.fields.action_port_filter.egress_port_list_0_31));
        action_dump_descr[action->slot.type].columns_p[7].data =
            ((uint8_t*)&(action->slot.fields.action_port_filter.egress_port_list_32_63));
        action_dump_descr[action->slot.type].columns_p[8].data =
            ((uint8_t*)&(action->slot.fields.action_port_filter.egress_port_list_64));
        break;

    case SXD_ACTION_TYPE_HASH_E:
        action_dump_descr[action->slot.type].columns_p[5].data = HW_ACT_HASH_TYPE_2STR(
            action->slot.fields.action_hash.type);
        action_dump_descr[action->slot.type].columns_p[6].data = HW_ACT_HASH_CMD_2STR(
            action->slot.fields.action_hash.hash_cmd);
        action_dump_descr[action->slot.type].columns_p[7].data =
            ((uint8_t*)&(action->slot.fields.action_hash.hash_value));
        break;

    default:
        break;
    }
}

void flex_acl_hw_db_debug_dump_actions_detailed(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t     *hw_db_action_set = NULL;
    uint32_t                         i = 0, j = 0, k, action_idx, extension = 0;
    cl_list_iterator_t               iter = NULL;
    cl_list_iterator_t               list_end = NULL;
    cl_list_iterator_t               list_head = NULL;
    sx_acl_region_id_t               region_id = FLEX_ACL_INVALID_REGION_ID;
    flex_acl_db_acl_region_t        *region = NULL;
    sxd_flex_acl_action_type_t       action_type;
    boolean_t                        first;
    static dbg_utils_table_columns_t columns_hw_action_vlan[] = {
        { "Region ID",                       10,   PARAM_HEX_E,     NULL },  /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,  NULL },  /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,  NULL },  /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,  NULL },  /* 3 */
        { "Type",                             6,   PARAM_STRING_E,  NULL },  /* 4 */
        { "Vlan tag cmd",                    12,   PARAM_STRING_E,  NULL },  /* 5 */
        { "VID cmd",                         10,   PARAM_STRING_E,  NULL },  /* 6 */
        { "VID",                              5,   PARAM_HEX_E,     NULL },  /* 7 */
        { "Ether cmd",                       10,   PARAM_STRING_E,  NULL },  /* 8 */
        { "Ether",                            6,   PARAM_HEX_E,     NULL },  /* 9 */
        { "PCP cmd",                         10,   PARAM_STRING_E,  NULL },  /* 10 */
        { "PCP",                              3,   PARAM_UINT8_E,   NULL },  /* 11 */
        { "DEI cmd",                         10,   PARAM_STRING_E,  NULL },  /* 12 */
        { "DEI",                              3,   PARAM_UINT8_E,   NULL },  /* 13 */
        { "Dfr",                              3,   PARAM_UINT8_E,   NULL },  /* 14 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_mac[] = {
        { "Region ID",                        10,   PARAM_HEX_E,     NULL  },  /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },  /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },  /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },  /* 3 */
        { "Type",                             6,   PARAM_STRING_E,     NULL  },  /* 4 */
        { "ttl_cmd",                          13,   PARAM_STRING_E,     NULL  },  /* 5 */
        { "ttl     ",                         8,   PARAM_UINT8_E,     NULL  },  /* 6 */
        { "mac cmd",                          13,   PARAM_STRING_E,     NULL  },  /* 7 */
        { "mac",                              20,   PARAM_MAC_ADDR_E,     NULL  },  /* 8 */
        { "defer",                            6,   PARAM_UINT8_E,     NULL  },  /* 9 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_qos[] = {
        { "Region ID",                       10,   PARAM_HEX_E,         NULL },  /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },  /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },  /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },  /* 3 */
        { "Type",                             6,   PARAM_STRING_E,      NULL },  /* 4 */
        { "ecn cmd",                         10,   PARAM_STRING_E,      NULL },  /* 5 */
        { "ecn",                              3,   PARAM_UINT8_E,       NULL },  /* 6 */
        { "color cmd",                        9,   PARAM_STRING_E,      NULL },  /* 7 */
        { "clr",                              3,   PARAM_STRING_E,      NULL },  /* 8 */
        { "dscp cmd",                         9,   PARAM_STRING_E,      NULL },  /* 9 */
        { "dscp",                             4,   PARAM_UINT8_E,       NULL },  /* 10 */
        { "prio cmd",                         8,   PARAM_STRING_E,      NULL },  /* 11 */
        { "prio",                             4,   PARAM_UINT8_E,       NULL },  /* 12 */
        { "dscp rw",                          7,   PARAM_STRING_E,      NULL },  /* 13 */
        { "pcp rw",                           6,   PARAM_STRING_E,      NULL },  /* 14 */
        { "tc cmd",                           6,   PARAM_STRING_E,      NULL },  /* 15 */
        { "tc",                               3,   PARAM_UINT8_E,       NULL },  /* 16 */
        { "dfr",                              3,   PARAM_UINT8_E,       NULL },  /* 17 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_trap[] = {
        { "Region ID",                        10,   PARAM_HEX_E,     NULL  },  /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },  /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },  /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },  /* 3 */
        { "Type",                             8,   PARAM_STRING_E,      NULL  },  /* 4 */
        { "trap action",                      20,   PARAM_STRING_E,     NULL  },  /* 5 */
        { "forward action",                   20,   PARAM_STRING_E,     NULL  },  /* 6 */
        { "trap id",                           8,   PARAM_UINT16_E,     NULL  },  /* 7 */
        { "mirror agent",                      13,   PARAM_UINT8_E,     NULL  },  /* 8 */
        { "mirror enable",                     13,   PARAM_UINT8_E,     NULL  },  /* 9 */
        { "defer",                            6,   PARAM_UINT8_E,     NULL  },  /* 10 */
        { "presrv_usr_id",                    13,   PARAM_UINT8_E,     NULL  },  /* 11 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_trap_w_udf[] = {
        { "Region ID",                        10,   PARAM_HEX_E,     NULL  },  /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },  /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },  /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },  /* 3 */
        { "Type",                             8,   PARAM_STRING_E,      NULL  },  /* 4 */
        { "trap action",                      20,   PARAM_STRING_E,     NULL  },  /* 5 */
        { "forward action",                   20,   PARAM_STRING_E,     NULL  },  /* 6 */
        { "trap id",                           8,   PARAM_UINT16_E,     NULL  },  /* 7 */
        { "mirror agent",                      13,   PARAM_UINT8_E,     NULL  },  /* 8 */
        { "mirror enable",                     13,   PARAM_UINT8_E,     NULL  },  /* 9 */
        { "defer",                             6,   PARAM_UINT8_E,     NULL  },  /* 10 */
        { "user_def",                          8,   PARAM_UINT16_E,     NULL  },  /* 11 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_mirror_sampler[] = {
        { "Region ID",                        10,  PARAM_HEX_E,         NULL },  /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },  /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },  /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },  /* 3 */
        { "Type",                             8,   PARAM_STRING_E,      NULL },  /* 4 */
        { "span session id",                  15,  PARAM_UINT8_E,       NULL },  /* 5 */
        { "mirror probability rate",          26,  PARAM_UINT32_E,      NULL },  /* 6 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_forward[] = {
        { "Region ID",                       10,   PARAM_HEX_E,     NULL },  /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,  NULL },  /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,  NULL },  /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,  NULL },  /* 3 */
        { "Type",                             6,   PARAM_STRING_E,  NULL },  /* 4 */
        { "Forward type",                    12,   PARAM_STRING_E,  NULL },  /* 5 */
        { "PBS ID",                           6,   PARAM_UINT32_E,  NULL },  /* 6 */
        { "PBS ptr",                          7,   PARAM_UINT32_E,  NULL },  /* 7 */
        { "Output in port",                  14,   PARAM_UINT8_E,   NULL },  /* 8 */
        { "Output defer",                    12,   PARAM_UINT8_E,   NULL },  /* 9 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_pc[] = {
        { "Region ID",                        10,   PARAM_HEX_E,     NULL  },   /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },   /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },   /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },   /* 3 */
        { "Type",                             6,   PARAM_STRING_E,     NULL  },   /* 4 */
        { "C/P",                              20,   PARAM_STRING_E,     NULL  },   /* 5 */
        { "counter set type",                 20,   PARAM_UINT32_E,     NULL  },   /* 6 */
        { "counter set index",                20,   PARAM_UINT32_E,     NULL  },   /* 7 */
        { "policer hw id",                    20,   PARAM_UINT16_E,     NULL  },   /* 8 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_meta[] = {
        { "Region ID",                        10,  PARAM_HEX_E,     NULL  },     /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },     /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },     /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },     /* 3 */
        { "Type",                             6,   PARAM_STRING_E,     NULL  },     /* 4 */
        { "meta data",                        12,  PARAM_HEX16_E,     NULL  },     /* 5 */
        { "meta mask",                        12,  PARAM_HEX16_E,     NULL  },     /* 6 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_vf[] = {
        { "Region ID",                        10,   PARAM_HEX_E,     NULL  },     /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },     /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },     /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },     /* 3 */
        { "Type",                             6,   PARAM_STRING_E,     NULL  },     /* 4 */
        { "vrid cmd",                        20,   PARAM_STRING_E,     NULL  },     /* 5 */
        { "vrid",                            20,   PARAM_UINT16_E,     NULL  },     /* 6 */
        { "fid cmd",                         20,   PARAM_STRING_E,     NULL  },     /* 7 */
        { "fid",                             20,   PARAM_UINT16_E,     NULL  },     /* 8 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_ignore[] = {
        { "Region ID",                        10,   PARAM_HEX_E,     NULL  },     /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },     /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },     /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },     /* 3 */
        { "Type",                             6,   PARAM_STRING_E,     NULL  },     /* 4 */
        { "ignore stp",                       20,   PARAM_STRING_E,     NULL  },     /* 5 */
        { "ignore vl filter",                 20,   PARAM_STRING_E,     NULL  },     /* 6 */
        { "disable learning",                 20,   PARAM_STRING_E,     NULL  },     /* 7 */
        { "OVL disable learning",             20,   PARAM_STRING_E,     NULL  },     /* 8 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_mc[] = {
        { "Region ID",                        10,   PARAM_HEX_E,     NULL  },     /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },     /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },     /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },     /* 3 */
        { "Type",                             6,  PARAM_STRING_E,     NULL  },     /* 4 */
        { "rpf action",                       20,   PARAM_STRING_E,     NULL  },     /* 5 */
        { "eir type",                         20,   PARAM_STRING_E,     NULL  },     /* 6 */
        { "expected irif",                 20,   PARAM_UINT16_E,     NULL  },     /* 7 */
        { "expected irif list index",         30,   PARAM_UINT32_E,     NULL  },     /* 8 */
        { "vrmid",                          20,   PARAM_UINT8_E,     NULL  },     /* 9 */
        { "rigr rmid index",                30,   PARAM_UINT32_E,     NULL  },     /* 10 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_uc[] = {
        { "Region ID",                        10,   PARAM_HEX_E,     NULL  },       /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL },       /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL },       /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL },       /* 3 */
        { "Type",                             6,  PARAM_STRING_E,     NULL  },       /* 4 */
        { "uc route type",                    20,   PARAM_STRING_E,     NULL  },       /* 5 */
        { "tunnel id or RIF or adj_id",       30,   PARAM_UINT32_E,     NULL  },       /* 6 */
        { "ecmp size",                        10,   PARAM_UINT32_E,     NULL  },       /* 7 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_port_filter[] = {
        { "Region ID",                        10,   PARAM_HEX_E,         NULL  },    /* 0 */
        { "Offset",                           7,    PARAM_UINT32_E,      NULL  },    /* 1 */
        { "Idx",                              3,    PARAM_UINT32_E,      NULL  },    /* 2 */
        { "Set",                              3,    PARAM_UINT32_E,      NULL  },    /* 3 */
        { "Type",                             6,    PARAM_STRING_E,      NULL  },    /* 4 */
        { "mc container id",                  20,   PARAM_UINT32_E,      NULL  },    /* 5 */
        { "ports:0-31",                       10,   PARAM_HEX_E,         NULL  },    /* 6 */
        { "32-63",                            10,   PARAM_HEX_E,         NULL  },    /* 7 */
        { "64",                               10,   PARAM_HEX_E,         NULL  },    /* 8 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t columns_hw_action_hash[] = {
        { "Region ID",                        10,   PARAM_HEX_E,        NULL  },     /* 0 */
        { "Offset",                           7,    PARAM_UINT32_E,     NULL  },     /* 1 */
        { "Idx",                              3,    PARAM_UINT32_E,     NULL  },     /* 2 */
        { "Set",                              3,    PARAM_UINT32_E,     NULL  },     /* 3 */
        { "Type",                             6,    PARAM_STRING_E,     NULL  },     /* 4 */
        { "Hash Type",                        10,   PARAM_STRING_E,     NULL  },     /* 5 */
        { "Hash Command",                     12,   PARAM_STRING_E,     NULL  },     /* 6 */
        { "Hash Value",                       10,   PARAM_HEX_E,        NULL  },     /* 7 */
        {NULL, 0, 0, NULL}
    };
    static hw_action_dump_descr_t    action_dump_descr[SXD_ACTION_TYPE_LAST_E] = {
        [SXD_ACTION_TYPE_VLAN_E] = {.columns_p = columns_hw_action_vlan, .title = "HW ACTION VLAN"},
        [SXD_ACTION_TYPE_MAC_E] = {.columns_p = columns_hw_action_mac, .title = "HW ACTION MAC"},
        [SXD_ACTION_TYPE_QOS_E] = {.columns_p = columns_hw_action_qos, .title = "HW ACTION QOS"},
        [SXD_ACTION_TYPE_TRAP_E] = {.columns_p = columns_hw_action_trap, .title = "HW ACTION TRAP"},
        [SXD_ACTION_TYPE_TRAP_W_USER_DEF_VAL_E] =
        {.columns_p = columns_hw_action_trap_w_udf, .title = "HW ACTION TRAP W USER_DEF_VAL"},
        [SXD_ACTION_TYPE_FORWARD_E] = {.columns_p = columns_hw_action_forward, .title = "HW ACTION FORWARD"},
        [SXD_ACTION_TYPE_POLICING_COUNTING_E] =
        {.columns_p = columns_hw_action_pc, .title = "HW ACTION POLICING COUNTING"},
        [SXD_ACTION_TYPE_META_DATA_E] = {.columns_p = columns_hw_action_meta, .title = "HW ACTION METADATA"},
        [SXD_ACTION_TYPE_VIRTUAL_FORWARDING_E] =
        {.columns_p = columns_hw_action_vf, .title = "HW ACTION VIRTUAL FORWARDING"},
        [SXD_ACTION_TYPE_IGNORE_E] = {.columns_p = columns_hw_action_ignore, .title = "HW ACTION IGNORE"},
        [SXD_ACTION_TYPE_MC_E] = {.columns_p = columns_hw_action_mc, .title = "HW ACTION MC ROUTER"},
        [SXD_ACTION_TYPE_UC_ROUTER_AND_MPLS_E] =
        {.columns_p = columns_hw_action_uc, .title = "HW ACTION UC ROUTER AND MPLS"},
        [SXD_ACTION_TYPE_PORT_FILTER_E] =
        {.columns_p = columns_hw_action_port_filter, .title = "HW ACTION PORT FILTER"},
        [SXD_ACTION_TYPE_HASH_E] =
        {.columns_p = columns_hw_action_hash, .title = "HW ACTION HASH"},
        [SXD_ACTION_TYPE_MIRROR_SAMPLER_E] =
        {.columns_p = columns_hw_action_mirror_sampler, .title = "HW ACTION MIRROR SAMPLER"},
    };
    FILE                            *stream = NULL;
    flex_acl_db_flex_rule_t         *db_flex_rule_p = NULL;
    boolean_t                        is_default_action = FALSE;

    rc = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(rc)) {
        return;
    }

    stream = dbg_dump_params_p->stream;

    if (!g_flex_acl_initialized) {
        dbg_utils_pprinter_field_print(stream,
                                       "FLEX ACL Modules are not initialized",
                                       &g_flex_acl_initialized,
                                       PARAM_BOOL_E);
        return;
    }

    for (action_type = 0; action_type < SXD_ACTION_TYPE_LAST_E; action_type++) {
        first = TRUE;

        if (!action_dump_descr[action_type].columns_p) {
            continue;
        }

        for (region_id = flex_acl_db_get_next_region(FLEX_ACL_INVALID_REGION_ID);
             region_id != FLEX_ACL_INVALID_REGION_ID;
             region_id = flex_acl_db_get_next_region(region_id)) {
            /* parameter checking is being done under acl_db_get_region */
            rc = flex_acl_db_region_get(region_id, &region);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("Get acl region failed\n");
                continue;
            }
            for (i = 0; i < region->size + 1; i++) {
                if (i < region->size) {
                    db_flex_rule_p = &region->rules[i];

                    if (region->rules[i].valid == FLEX_ACL_RULE_INVALID) {
                        continue;
                    }
                    is_default_action = FALSE;
                } else {
                    db_flex_rule_p = &region->default_rule;
                    is_default_action = TRUE;
                }
                hw_db_action_set = db_flex_rule_p->hw_action_handle;
                if (!hw_db_action_set) {
                    SX_LOG_DBG("Region %#x offset %d - no action set\n", region_id, db_flex_rule_p->offset);
                    continue;
                }
                extension = 0;
                /* print hw actions */
                for (j = 0; j < hw_db_action_set->action_set.actions_count; j++) {
                    if (hw_db_action_set->action_set.actions[j].slot.type != action_type) {
                        continue;
                    }

                    if (is_default_action == TRUE) {
                        action_dump_descr[action_type].columns_p[1].type = PARAM_STRING_E;
                        action_dump_descr[action_type].columns_p[1].data = "default";
                    } else {
                        action_dump_descr[action_type].columns_p[1].type = PARAM_UINT32_E;
                        action_dump_descr[action_type].columns_p[1].data = &(i);
                    }

                    action_dump_descr[action_type].columns_p[0].data = &(region_id);
                    action_dump_descr[action_type].columns_p[2].data = &(j);
                    action_dump_descr[action_type].columns_p[3].data = &(extension);
                    action_dump_descr[action_type].columns_p[4].data = HW_ACTION_ID_2SHORT(
                        hw_db_action_set->action_set.actions[j].slot.type);
                    __flex_acl_hw_db_populate_action(&(hw_db_action_set->action_set.actions[j]), action_dump_descr);
                    if (first) {
                        dbg_utils_pprinter_secondary_header_print(stream, "%s", action_dump_descr[action_type].title);
                        dbg_utils_pprinter_table_headline_print(stream, action_dump_descr[action_type].columns_p);
                        first = FALSE;
                    }
                    dbg_utils_pprinter_table_data_line_print(stream, action_dump_descr[action_type].columns_p);
                }
                action_idx = j - 1;  /* set j to control total num of actions */
                list_head = cl_list_head(&hw_db_action_set->kvd_action_set_list);
                list_end = cl_list_end(&hw_db_action_set->kvd_action_set_list);
                for (iter = list_head;
                     iter != list_end;
                     iter = cl_list_next(iter)) {
                    flex_acl_hw_db_kvd_action_set_t *kvd_action_set;
                    kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iter);
                    extension++;
                    for (k = 0; k < kvd_action_set->actions_count; k++) {
                        action_idx++;
                        if (kvd_action_set->actions[k].slot.type != action_type) {
                            continue;
                        }

                        if (is_default_action == TRUE) {
                            action_dump_descr[action_type].columns_p[1].type = PARAM_STRING_E;
                            action_dump_descr[action_type].columns_p[1].data = "default";
                        } else {
                            action_dump_descr[action_type].columns_p[1].type = PARAM_UINT32_E;
                            action_dump_descr[action_type].columns_p[1].data = &(i);
                        }

                        action_dump_descr[action_type].columns_p[0].data = &(region_id);
                        action_dump_descr[action_type].columns_p[2].data = &(action_idx);
                        action_dump_descr[action_type].columns_p[3].data = &(extension);
                        action_dump_descr[action_type].columns_p[4].data = HW_ACTION_ID_2SHORT(
                            kvd_action_set->actions[k].slot.type);
                        __flex_acl_hw_db_populate_action(&(kvd_action_set->actions[k]), action_dump_descr);
                        if (first) {
                            dbg_utils_pprinter_secondary_header_print(stream, "%s",
                                                                      action_dump_descr[action_type].title);
                            dbg_utils_pprinter_table_headline_print(stream, action_dump_descr[action_type].columns_p);
                            first = FALSE;
                        }
                        dbg_utils_pprinter_table_data_line_print(stream, action_dump_descr[action_type].columns_p);
                    }
                }
            }
        }
    }
}

void flex_acl_hw_db_debug_dump_action_sets_print_action(dbg_dump_params_t    *dbg_dump_params_p,
                                                        flex_acl_hw_action_t *hw_action_p,
                                                        sx_acl_region_id_t    region_id,
                                                        sx_acl_rule_offset_t  offset,
                                                        uint32_t              index,
                                                        uint32_t              action_set_i,
                                                        boolean_t            *first)
{
    flex_acl_hw_action_details_t    *flex_acl_hw_action_details_p;
    uint8_t                          size = 0;
    static dbg_utils_table_columns_t dump_columns[] = {
        { "Region ID",                        10,   PARAM_HEX_E,        NULL }, /* 0 */
        { "Offset",                           7,   PARAM_UINT32_E,      NULL }, /* 1 */
        { "Idx",                              3,   PARAM_UINT32_E,      NULL }, /* 2 */
        { "Set",                              3,   PARAM_UINT32_E,      NULL }, /* 3 */
        { "Act type",                         9,   PARAM_STRING_E,      NULL }, /* 4 */
        { "Size",                             4,   PARAM_UINT8_E,       NULL }, /* 5 */
        { "Pos",                              3,   PARAM_STRING_E,      NULL }, /* 6 */
        { "Slot type",                        9,   PARAM_STRING_E,      NULL }, /* 7 */
        { "Aux type",                         8,   PARAM_STRING_E,      NULL }, /* 8 */
        { "API act",                          8,   PARAM_STRING_E,      NULL }, /* 9 */
        {NULL, 0, 0, NULL}
    };
    FILE                            *stream = NULL;

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        return;
    }

    stream = dbg_dump_params_p->stream;

    if (flex_acl_hw_action_details_get(hw_action_p->slot.type,
                                       &flex_acl_hw_action_details_p)
        != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_hw_action_details_get failed. Action type: %d\n",
                   hw_action_p->slot.type);
    }
    size = flex_acl_hw_action_details_p ? flex_acl_hw_action_details_p->size : 0;

    dump_columns[0].data = &(region_id);
    if (offset == SX_ACL_DEFAULT_ACTION_OFFSET) {
        dump_columns[1].type = PARAM_STRING_E;
        dump_columns[1].data = "default";
    } else {
        dump_columns[1].type = PARAM_UINT32_E;
        dump_columns[1].data = &(offset);
    }
    dump_columns[2].data = &(index);
    dump_columns[3].data = &(action_set_i);
    dump_columns[4].data = HW_ACTION_ID_2SHORT(hw_action_p->action_type);
    dump_columns[5].data = &(size);
    dump_columns[6].data = HW_ACTION_POSITION_2STR(hw_action_p->position);
    dump_columns[7].data = HW_ACTION_ID_2SHORT(hw_action_p->slot.type);
    dump_columns[8].data = HW_ACTION_ID_2SHORT(hw_action_p->aux_slot.type);
    dump_columns[9].data = API_ACT_2SHORT(hw_action_p->api_action_type);

    if (*first) {
        dbg_utils_pprinter_general_header_print(stream, "HW ACTION SETS");
        dbg_utils_pprinter_field_print(stream, "Position legend:",
                                       "\n\tINT = 'In Transaction'"
                                       "\n\tTRT = 'Transaction Termination'"
                                       "\n\tOFF = 'Off Transaction'"
                                       "\n\tEND = 'End of action list'",
                                       PARAM_STRING_E);
        dbg_utils_pprinter_table_headline_print(stream, dump_columns);
        *first = FALSE;
    }
    dbg_utils_pprinter_table_data_line_print(stream, dump_columns);
}

void flex_acl_hw_db_debug_dump_action_sets(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_action_set_t *hw_db_action_set = NULL;
    sx_acl_region_id_t           region_id = FLEX_ACL_INVALID_REGION_ID;
    flex_acl_db_acl_region_t    *region = NULL;
    uint32_t                     iii, jjj, kkk;
    uint32_t                     action_set_i = 0;
    boolean_t                    first = TRUE;
    uint32_t                     action_idx;
    cl_list_iterator_t           iter = NULL;
    flex_acl_db_flex_rule_t     *db_flex_rule_p = NULL;
    FILE                        *stream = NULL;

    rc = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(rc)) {
        return;
    }
    stream = dbg_dump_params_p->stream;

    if (!g_flex_acl_initialized) {
        dbg_utils_pprinter_field_print(stream,
                                       "FLEX ACL Modules are not initialized",
                                       &g_flex_acl_initialized,
                                       PARAM_BOOL_E);
        return;
    }

    for (region_id = flex_acl_db_get_next_region(FLEX_ACL_INVALID_REGION_ID);
         region_id != FLEX_ACL_INVALID_REGION_ID;
         region_id = flex_acl_db_get_next_region(region_id)) {
        /* parameter checking is being done under acl_db_get_region */
        rc = flex_acl_db_region_get(region_id, &region);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Get acl region %#x failed. rc: %s\n", region_id, sx_status_str(rc));
            continue;
        }
        for (iii = 0; iii < region->size + 1; iii++) {
            if (iii < region->size) {
                db_flex_rule_p = &region->rules[iii];
                if (db_flex_rule_p->valid == FLEX_ACL_RULE_INVALID) {
                    continue;
                }
            } else {
                db_flex_rule_p = &region->default_rule;
            }
            hw_db_action_set = db_flex_rule_p->hw_action_handle;
            if (!hw_db_action_set) {
                SX_LOG_DBG("Region %#x offset %d - no action set\n", region_id, db_flex_rule_p->offset);
                continue;
            }
            action_set_i = 0;
            /* print hw actions */
            for (jjj = 0; jjj < hw_db_action_set->action_set.actions_count; jjj++) {
                flex_acl_hw_db_debug_dump_action_sets_print_action(dbg_dump_params_p,
                                                                   &hw_db_action_set->action_set.actions[jjj],
                                                                   region_id,
                                                                   db_flex_rule_p->offset,
                                                                   jjj,
                                                                   action_set_i,
                                                                   &first);
            }

            action_idx = jjj - 1;  /* set j to control total num of actions */
            for (iter = cl_list_head(&hw_db_action_set->kvd_action_set_list);
                 iter != cl_list_end(&hw_db_action_set->kvd_action_set_list);
                 iter = cl_list_next(iter)) {
                flex_acl_hw_db_kvd_action_set_t *kvd_action_set;
                kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iter);
                action_set_i++;
                for (kkk = 0; kkk < kvd_action_set->actions_count; kkk++) {
                    action_idx++;
                    flex_acl_hw_db_debug_dump_action_sets_print_action(dbg_dump_params_p,
                                                                       &kvd_action_set->actions[kkk],
                                                                       region_id,
                                                                       db_flex_rule_p->offset,
                                                                       action_idx,
                                                                       action_set_i,
                                                                       &first);
                }
            }
        }
    }
}

void flex_acl_hw_db_debug_dump_keys(dbg_dump_params_t *dbg_dump_params_p)
{
    uint32_t                         i = 0, k = 0;
    uint32_t                         invalid = 0xFFFF;
    static dbg_utils_table_columns_t acl_dump_columns[] = {
        { "HW Key Handle ID",          16,   PARAM_UINT32_E,     NULL }, /* 0 */
        { "Blocks Cnt",             10,   PARAM_UINT32_E,      NULL }, /* 1 */
        { "Block1",                    6,   PARAM_HEX_E,      NULL }, /* 2 */
        { "Block2",                    6,   PARAM_HEX_E,      NULL }, /* 3 */
        { "Block3",                    6,   PARAM_HEX_E,      NULL }, /* 4 */
        { "Block4",                    6,   PARAM_HEX_E,      NULL }, /* 5 */
        { "Block5",                    6,   PARAM_HEX_E,      NULL }, /* 6 */
        { "Block6",                    6,   PARAM_HEX_E,      NULL }, /* 7 */
        { "Block7",                    6,   PARAM_HEX_E,      NULL }, /* 8 */
        { "Block8",                    6,   PARAM_HEX_E,      NULL }, /* 9 */
        { "Block9",                    6,   PARAM_HEX_E,      NULL }, /* 10 */
        { "Block10",                    7,   PARAM_HEX_E,      NULL }, /* 11 */
        { "Block11",                    7,   PARAM_HEX_E,      NULL }, /* 12 */
        { "Block12",                    7,   PARAM_HEX_E,      NULL }, /* 13 */
        {NULL, 0, 0, NULL}
    };
    boolean_t                        first = TRUE;
    FILE                            *stream = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    if (!g_flex_acl_initialized) {
        dbg_utils_pprinter_field_print(stream,
                                       "FLEX ACL Modules are not initialized",
                                       &g_flex_acl_initialized,
                                       PARAM_BOOL_E);
        return;
    }

    for (i = 0; i < flex_acl_hw_db_key_blocks_db.count; i++) {
        if (flex_acl_hw_db_key_blocks_db.entries[i].allocated == TRUE) {
            acl_dump_columns[0].data = &(flex_acl_hw_db_key_blocks_db.entries[i].idx);
            acl_dump_columns[1].data = &(flex_acl_hw_db_key_blocks_db.entries[i].count);

            k = 0;
            while (k < flex_acl_hw_db_key_blocks_db.entries[i].count && k < 12) {
                acl_dump_columns[2 +
                                 k].data =
                    &(key_block_data_dictionary[flex_acl_hw_db_key_blocks_db.entries[i].key_blocks[k]]);
                k++;
            }

            while (k < 12) { /* the constant here to avoid core dump */
                acl_dump_columns[2 + k].data = &invalid;
                k++;
            }
            if (first) {
                dbg_utils_pprinter_general_header_print(stream, "ACL HWD Key Blocks DB");
                dbg_utils_pprinter_table_headline_print(stream, acl_dump_columns);
                first = FALSE;
            }
            dbg_utils_pprinter_table_data_line_print(stream, acl_dump_columns);
        }
    }
out:
    SX_LOG_EXIT();
}

void flex_acl_hw_db_debug_late_binding_map(dbg_dump_params_t *dbg_dump_params_p)
{
    cl_qmap_t                       *binding_map_p = NULL;
    cl_map_item_t                   *map_item_p = NULL;
    const cl_map_item_t             *map_end_p = NULL;
    flex_acl_hw_db_binding_entry_t  *binding_entry_p = NULL;
    uint32_t                         type;
    char                             buf[32] = {0};
    static dbg_utils_table_columns_t late_binding_dump_columns[] = {
        { "Binding Type",              30,   PARAM_STRING_E,    NULL },   /* 0 */
        { "Bind",                      10,   PARAM_BOOL_E,      NULL },   /* 1 */
        { "id",                        10,   PARAM_UINT32_E,    NULL },   /* 2 */
        { "Bind to",                   20,   PARAM_UINT32_E,    NULL },   /* 3 */
        {NULL, 0, 0, NULL}
    };
    FILE                            *stream = NULL;

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        return;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "ACL HW late binding DB");

    if (!g_flex_acl_initialized) {
        dbg_utils_pprinter_field_print(stream,
                                       "FLEX ACL Modules are not initialized",
                                       &g_flex_acl_initialized,
                                       PARAM_BOOL_E);
        return;
    }

    for (type = FLEX_ACL_HW_BINDING_MIN_E; type <= FLEX_ACL_HW_BINDING_MAX_E; type++) {
        switch (type) {
        case FLEX_ACL_HW_BINDING_PORT_E:
            late_binding_dump_columns[2].type = PARAM_HEX_E;
            late_binding_dump_columns[2].name = "PORT ID";
            late_binding_dump_columns[3].name = "ACL GROUP ID";
            break;

        case FLEX_ACL_HW_BINDING_VLAN_E:
            late_binding_dump_columns[2].type = PARAM_UINT32_E;
            late_binding_dump_columns[2].name = "VLAN ID";
            late_binding_dump_columns[3].name = "VLAN GROUP ID";
            break;

        case FLEX_ACL_HW_BINDING_RIF_E:
            late_binding_dump_columns[2].type = PARAM_UINT32_E;
            late_binding_dump_columns[2].name = "RIF ID";
            late_binding_dump_columns[3].name = "ACL GROUP ID";
            break;

        /* coverity[dead_error_begin]*/
        default:
            break;
        }
        snprintf(buf, sizeof(buf), "late_binding_dump_columns%d", type);
        dbg_utils_pprinter_json_table_name_set(stream, buf);
        dbg_utils_pprinter_table_headline_print(stream, late_binding_dump_columns);

        flex_acl_hw_db_get_late_binding_map(type, &binding_map_p);

        map_item_p = cl_qmap_head(binding_map_p);
        map_end_p = cl_qmap_end(binding_map_p);
        while (map_item_p != map_end_p) {
            binding_entry_p = PARENT_STRUCT(map_item_p, flex_acl_hw_db_binding_entry_t, map_item);
            late_binding_dump_columns[1].data = &binding_entry_p->binding_data.bind;
            switch (type) {
            case FLEX_ACL_HW_BINDING_PORT_E:
                late_binding_dump_columns[0].data = "PORT BIND to ACL GROUP";
                late_binding_dump_columns[2].data = &binding_entry_p->binding_data.data.port.log_port;
                late_binding_dump_columns[3].data = &binding_entry_p->binding_data.data.port.bind_id;
                break;

            case FLEX_ACL_HW_BINDING_VLAN_E:
                late_binding_dump_columns[0].data = "VLAN BIND to VLAN GROUP";
                late_binding_dump_columns[2].data = &binding_entry_p->binding_data.data.vlan.vlan_id;
                late_binding_dump_columns[3].data = &binding_entry_p->binding_data.data.vlan.vlan_group_id;
                break;

            case FLEX_ACL_HW_BINDING_RIF_E:
                late_binding_dump_columns[0].data = "RIF BIND to ACL GROUP";
                late_binding_dump_columns[2].data = &binding_entry_p->binding_data.data.rif.rif_id;
                late_binding_dump_columns[3].data = &binding_entry_p->binding_data.data.rif.bind_id;
                break;

            /* coverity[dead_error_begin] */
            default:
                break;
            }
            dbg_utils_pprinter_table_data_line_print(stream, late_binding_dump_columns);
            map_item_p = cl_qmap_next(map_item_p);
        }
    }

    SX_LOG_EXIT();
}
void flex_acl_hw_db_debug_dump_acldrop_trap_fmap(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                                  rc = SX_STATUS_SUCCESS;
    cl_fmap_item_t                              *fmap_item_p = NULL;
    const cl_fmap_item_t                        *fmap_end_p = NULL;
    flex_acl_hw_db_acl_drop_data_item_t         *acl_drop_fmap_entry_p = NULL;
    cl_list_item_t                              *free_idx_list_item_p = NULL;
    flex_acl_hw_db_acl_drop_trap_usr_idx_item_t *free_idx_list_entry_p = NULL;
    uint32_t                                     free_count = 0;
    uint32_t                                     total_count = ACL_DROP_DB_POOL_MAX_SIZE;
    cl_list_t                                   *acl_drop_action_relocate_list = NULL;
    uint64_t                                     acl_drop_handle = 0;
    uint32_t                                     reloc_db_count = 1;
    cl_map_item_t                               *map_item = NULL;
    const cl_map_item_t                         *map_end = NULL;
    boolean_t                                    first = TRUE;
    static dbg_utils_table_columns_t             acl_drop_trap_dump_table[] = {
        { "ACL ID", 10, PARAM_HEX_E, NULL },            /* 0 */
        { "Region ID", 10, PARAM_HEX_E, NULL },         /* 1 */
        { "Offset", 10, PARAM_UINT32_E, NULL },         /* 2 */
        { "Idx-Trap val", 12, PARAM_UINT32_E, NULL },   /* 3 */
        { "Valid", 10, PARAM_BOOL_E, NULL },            /* 4 */
        { "Relocate DB", 12, PARAM_STRING_E, NULL },    /* 5 */
        { "ACL Type", 12, PARAM_STRING_E, NULL },       /* 6 */
        { NULL, 0, 0, NULL }
    };
    static dbg_utils_table_columns_t             acldrop_trap_to_index_map_table[] = {
        { "Total Count", 12, PARAM_UINT32_E, NULL },         /* 0 */
        { "Free Count", 12, PARAM_UINT32_E, NULL },          /* 1 */
        { "Next Free Val(head)", 20, PARAM_UINT32_E, NULL }, /* 2 */
        { "Last Free Val(Tail)", 20, PARAM_UINT32_E, NULL }, /* 3 */
        { NULL, 0, 0, NULL }
    };
    static dbg_utils_table_columns_t             acldrop_relocate_db_fmap_table[] = {
        { "Index", 12, PARAM_UINT32_E, NULL },         /* 0 */
        { "Handle", 16, PARAM_HEX64_E, NULL },         /* 1 */
        { NULL, 0, 0, NULL }
    };
    FILE                                        *stream = NULL;

    SX_LOG_ENTER();

    rc = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_general_header_print(stream, "ACL Drop Action Monitoring Trap DB");

    dbg_utils_pprinter_table_headline_print(stream, acl_drop_trap_dump_table);

    if (cl_is_fmap_empty(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap)) {
        dbg_utils_pprinter_print(stream, "DB is Empty\n");
    } else {
        fmap_item_p = cl_fmap_head(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap));
        fmap_end_p = cl_fmap_end(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap));

        while (fmap_item_p != fmap_end_p) {
            acl_drop_fmap_entry_p = PARENT_STRUCT(fmap_item_p, flex_acl_hw_db_acl_drop_data_item_t, fmap_item);

            acl_drop_trap_dump_table[0].data = &(acl_drop_fmap_entry_p->acl_drop_attr.acl_id);
            acl_drop_trap_dump_table[1].data = &(acl_drop_fmap_entry_p->acl_drop_attr.acl_region_id);
            acl_drop_trap_dump_table[2].data = &(acl_drop_fmap_entry_p->acl_drop_attr.acl_rule_offset);
            acl_drop_trap_dump_table[3].data = &(acl_drop_fmap_entry_p->acl_drop_attr.trap_usr_def_val);
            acl_drop_trap_dump_table[4].data = &(acl_drop_fmap_entry_p->acl_drop_attr.valid);

            /* check if this entry is in relocate DB */
            acl_drop_handle = FLEX_ACL_DROP_TRAP_HANDLE(acl_drop_fmap_entry_p->acl_drop_attr.acl_region_id,
                                                        acl_drop_fmap_entry_p->acl_drop_attr.acl_rule_offset);
            rc = flex_acl_pool_map_object_list_get(&flex_acl_hw_db_acl_drop_relocate_db,
                                                   acl_drop_handle, &acl_drop_action_relocate_list);
            if (rc == SX_STATUS_SUCCESS) {
                acl_drop_trap_dump_table[5].data = "YES";
            } else {
                acl_drop_trap_dump_table[5].data = "NO";
            }
            flex_acl_db_acl_region_t *region = NULL;

            rc = flex_acl_db_region_get(acl_drop_fmap_entry_p->acl_drop_attr.acl_region_id, &region);
            if (rc == SX_STATUS_SUCCESS) {
                switch (region->entry_type) {
                case FLEX_ACL_ENTRY_TYPE_USER_E:
                    acl_drop_trap_dump_table[6].data = "USER";
                    break;

                case FLEX_ACL_ENTRY_TYPE_SYSTEM_E:
                    acl_drop_trap_dump_table[6].data = "SYS";
                    break;

                case FLEX_ACL_ENTRY_TYPE_AGGREGATE_E:
                    acl_drop_trap_dump_table[6].data = "AGGR";
                    break;

                default:
                    acl_drop_trap_dump_table[6].data = "OTHER";
                    break;
                }
            } else {
                SX_LOG_WRN("ACL drop trap DB contains non existing rule: offset [%u], region [%u], acl [%u]\n",
                           acl_drop_fmap_entry_p->acl_drop_attr.acl_rule_offset,
                           acl_drop_fmap_entry_p->acl_drop_attr.acl_region_id,
                           acl_drop_fmap_entry_p->acl_drop_attr.acl_id);
                acl_drop_trap_dump_table[6].data = "ERR";
            }
            dbg_utils_pprinter_table_data_line_print(stream, acl_drop_trap_dump_table);

            fmap_item_p = cl_fmap_next(fmap_item_p);
        }
    }

    dbg_utils_pprinter_general_header_print(stream, "ACL Drop Trap Usr Def Val Pool DB");
    dbg_utils_pprinter_table_headline_print(stream, acldrop_trap_to_index_map_table);

    free_count = cl_qlist_count(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list);
    acldrop_trap_to_index_map_table[0].data = &total_count;
    acldrop_trap_to_index_map_table[1].data = &free_count;

    free_idx_list_item_p = cl_qlist_head(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list));
    free_idx_list_entry_p = PARENT_STRUCT(free_idx_list_item_p,
                                          flex_acl_hw_db_acl_drop_trap_usr_idx_item_t,
                                          list_item);
    acldrop_trap_to_index_map_table[2].data = &(free_idx_list_entry_p->acl_drop_usridx);

    free_idx_list_item_p = cl_qlist_tail(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list));
    free_idx_list_entry_p = PARENT_STRUCT(free_idx_list_item_p,
                                          flex_acl_hw_db_acl_drop_trap_usr_idx_item_t,
                                          list_item);
    acldrop_trap_to_index_map_table[3].data = &(free_idx_list_entry_p->acl_drop_usridx);
    dbg_utils_pprinter_table_data_line_print(stream, acldrop_trap_to_index_map_table);
    dbg_utils_pprinter_general_header_print(stream, "ACL Drop Relocate DB");
    total_count = flex_acl_hw_db_acl_drop_relocate_db_size_get();
    dbg_utils_pprinter_field_print(stream, "Total Count", (&total_count), PARAM_UINT32_E);


    map_item = cl_qmap_head(&(flex_acl_hw_db_acl_drop_relocate_db.map));
    map_end = cl_qmap_end(&(flex_acl_hw_db_acl_drop_relocate_db.map));
    while (map_item != map_end) {
        if (first) {
            dbg_utils_pprinter_table_headline_print(stream, acldrop_relocate_db_fmap_table);
            first = FALSE;
        }

        acl_drop_handle = map_item->key;
        acldrop_relocate_db_fmap_table[0].data = &reloc_db_count;
        acldrop_relocate_db_fmap_table[1].data = &acl_drop_handle;
        dbg_utils_pprinter_table_data_line_print(stream, acldrop_relocate_db_fmap_table);
        map_item = cl_qmap_next(map_item);
        reloc_db_count++;
    }
out:
    SX_LOG_EXIT();
}

void flex_acl_hw_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        return;
    }

    dbg_utils_pprinter_general_header_print(dbg_dump_params_p->stream, "Flex Acl HW DB");

    flex_acl_hw_db_debug_dump_actions_detailed(dbg_dump_params_p);
    flex_acl_hw_db_debug_dump_action_sets(dbg_dump_params_p);
    flex_acl_hw_db_debug_dump_keys(dbg_dump_params_p);
    flex_acl_hw_db_debug_late_binding_map(dbg_dump_params_p);
    flex_acl_hw_db_debug_dump_acldrop_trap_fmap(dbg_dump_params_p);
}

static sx_status_t __get_matching_hw_action_from_rule(flex_acl_db_flex_rule_t   *rule,
                                                      sxd_flex_acl_action_type_t action_type,
                                                      boolean_t                  cmp_slot_action_f,
                                                      boolean_t                 *found_p,
                                                      flex_acl_hw_action_t     **action_pp)
{
    uint32_t                         i;
    flex_acl_hw_db_action_set_t     *action_set = NULL;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    cl_list_iterator_t               iter = NULL;
    cl_list_iterator_t               list_head = NULL;
    cl_list_iterator_t               list_end = NULL;
    const cl_list_t                 *kvd_action_set_list = NULL;
    flex_acl_hw_db_kvd_action_set_t *kvd_action_set = NULL;
    sxd_flex_acl_action_type_t       tmp_action;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(rule, "rule"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(found_p, "found_p"))) {
        goto out;
    }

    action_set = (flex_acl_hw_db_action_set_t*)rule->hw_action_handle;

    *found_p = FALSE;
    for (i = 0; (!*found_p) && (i < action_set->action_set.actions_count); i++) {
        if (cmp_slot_action_f) {
            tmp_action = action_set->action_set.actions[i].slot.type;
        } else {
            tmp_action = action_set->action_set.actions[i].action_type;
        }
        if (tmp_action == action_type) {
            *found_p = TRUE;
            if (action_pp != NULL) {
                *action_pp = &action_set->action_set.actions[i];
            }
        }
    }

    if (action_set->kvd_action_set_count == 0) {
        goto out;
    }

    rc = flex_acl_hw_db_get_kvd_action_set_list(action_set, &kvd_action_set_list);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL action : Failed getting action set list.\n");
        goto out;
    }
    list_head = cl_list_head(kvd_action_set_list);
    list_end = cl_list_end(kvd_action_set_list);
    for (iter = list_head; (!*found_p) && (iter != list_end);
         iter = cl_list_next(iter)) {
        kvd_action_set = (flex_acl_hw_db_kvd_action_set_t*)cl_list_obj(iter);
        for (i = 0; (!*found_p) && (i < kvd_action_set->actions_count); i++) {
            if (cmp_slot_action_f) {
                tmp_action = kvd_action_set->actions[i].slot.type;
            } else {
                tmp_action = kvd_action_set->actions[i].action_type;
            }
            if (tmp_action == action_type) {
                *found_p = TRUE;
                if (action_pp != NULL) {
                    *action_pp = &kvd_action_set->actions[i];
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}
/* This function returns the pointer to the hw action where the respective user api
 * mapped SXD action_type matches with the provided action type.
 */
sx_status_t flex_acl_hw_db_get_action_from_rule(flex_acl_db_flex_rule_t   *rule,
                                                sxd_flex_acl_action_type_t action_type,
                                                boolean_t                 *found_p,
                                                flex_acl_hw_action_t     **action_pp)
{
    return __get_matching_hw_action_from_rule(rule, action_type, FALSE,
                                              found_p, action_pp);
}
/* This function returns the pointer to the hw action whose slot.type matches
 * with the provided action type.
 */
sx_status_t flex_acl_hw_db_get_matching_hw_action_from_rule(flex_acl_db_flex_rule_t   *rule,
                                                            sxd_flex_acl_action_type_t action_type,
                                                            boolean_t                 *found_p,
                                                            flex_acl_hw_action_t     **action_pp)
{
    return __get_matching_hw_action_from_rule(rule, action_type, TRUE,
                                              found_p, action_pp);
}

sx_status_t flex_acl_hw_db_hw_action_list_init(hw_action_list_t *hw_action_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (!flex_acl_hw_db_init_done_g) {
        SX_LOG_ERR("ACL HW DB not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (flex_acl_hw_action_list_init_done_g) {
        SX_LOG_ERR("ACL HW DB Action List already initialized.\n");
        rc = SX_STATUS_DB_ALREADY_INITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_p, "hw_action_list_p"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cl_qlist_init(&hw_action_list_p->qlist);

    flex_acl_hw_action_list_init_done_g = TRUE;

out:
    return rc;
}

sx_status_t flex_acl_hw_db_hw_action_list_deinit(hw_action_list_t *hw_action_list_p)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    const cl_list_item_t   *p_end = NULL;
    cl_list_item_t         *p_item = NULL;
    hw_action_list_entry_t *hw_action_list_entry_p;

    if (!flex_acl_hw_action_list_init_done_g) {
        SX_LOG_ERR("ACL HW DB Action List not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_p, "hw_action_list_p"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    p_item = cl_qlist_head(&hw_action_list_p->qlist);
    p_end = cl_qlist_end(&hw_action_list_p->qlist);

    while (p_item != p_end) {
        hw_action_list_entry_p = PARENT_STRUCT(p_item, hw_action_list_entry_t, list_item);
        cl_qpool_put(&flex_acl_hw_action_list_qpool_g, &hw_action_list_entry_p->pool_item);
        cl_qlist_remove_head(&hw_action_list_p->qlist);
        p_item = cl_qlist_head(&hw_action_list_p->qlist);
    }

    flex_acl_hw_action_list_init_done_g = FALSE;

out:
    return rc;
}

sx_status_t flex_acl_hw_db_hw_action_list_insert_tail(hw_action_list_t        *hw_action_list_p,
                                                      flex_acl_hw_action_t    *hw_action_p,
                                                      hw_action_list_entry_t **hw_action_list_entry_pp)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    cl_pool_item_t *pool_item_p = NULL;


    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_p, "hw_action_list_p"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_p, "hw_action_p"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!flex_acl_hw_action_list_init_done_g) {
        SX_LOG_ERR("ACL HW DB Action List not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    pool_item_p = cl_qpool_get(&flex_acl_hw_action_list_qpool_g);
    if (NULL == pool_item_p) {
        rc = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("cl_qpool_get failed for flex_acl_hw_action_list_qpool_g.\n");
        goto out;
    }

    (*hw_action_list_entry_pp) = PARENT_STRUCT(pool_item_p, hw_action_list_entry_t, pool_item);

    (*hw_action_list_entry_pp)->pool_item = *pool_item_p;
    (*hw_action_list_entry_pp)->hw_action = *hw_action_p;
    cl_qlist_insert_tail(&hw_action_list_p->qlist, &(*hw_action_list_entry_pp)->list_item);

out:
    return rc;
}

/* Move given entry to the end of the list */
sx_status_t flex_acl_hw_db_hw_action_list_move_2tail(hw_action_list_t       *hw_action_list_p,
                                                     hw_action_list_entry_t *hw_action_list_entry_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_p, "hw_action_list_p"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_entry_p, "hw_action_list_entry_p"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!flex_acl_hw_action_list_init_done_g) {
        SX_LOG_ERR("ACL HW DB Action List not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    cl_qlist_remove_item(&hw_action_list_p->qlist, &hw_action_list_entry_p->list_item);
    cl_qlist_insert_tail(&hw_action_list_p->qlist, &hw_action_list_entry_p->list_item);

out:
    return rc;
}

boolean_t flex_acl_hw_db_hw_action_list_is_empty(hw_action_list_t *hw_action_list_p)
{
    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_p, "hw_action_list_p"))) {
        return TRUE;
    }

    return cl_is_qlist_empty(&hw_action_list_p->qlist);
}

sx_status_t flex_acl_hw_db_hw_action_list_head(hw_action_list_t        *hw_action_list_p,
                                               hw_action_list_entry_t **hw_action_list_entry_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_p, "hw_action_list_p"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_entry_pp, "hw_action_list_entry_pp"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!flex_acl_hw_action_list_init_done_g) {
        SX_LOG_ERR("ACL HW DB Action List not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    cl_list_item_t       *list_item = cl_qlist_head(&hw_action_list_p->qlist);
    const cl_list_item_t *list_end = cl_qlist_end(&hw_action_list_p->qlist);

    if (list_item == list_end) {
        /* Empty list */
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        *hw_action_list_entry_pp = NULL;
        goto out;
    }

    *hw_action_list_entry_pp = PARENT_STRUCT(list_item, hw_action_list_entry_t, list_item);

out:
    return rc;
}

/**
 * Removes item pointed by hw_action_list_entry_pp and returns next entry
 *
 * @param hw_action_list_p
 * @param hw_action_list_entry_pp
 */
sx_status_t flex_acl_hw_db_hw_action_list_remove_and_next(hw_action_list_t        *hw_action_list_p,
                                                          hw_action_list_entry_t **hw_action_list_entry_pp)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    cl_list_item_t *list_item_next_p;

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_p, "hw_action_list_p"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_entry_pp, "hw_action_list_entry_pp"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!flex_acl_hw_action_list_init_done_g) {
        SX_LOG_ERR("ACL HW DB Action List not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    list_item_next_p = cl_qlist_next(&(*hw_action_list_entry_pp)->list_item);

    cl_qlist_remove_item(&hw_action_list_p->qlist, &(*hw_action_list_entry_pp)->list_item);
    cl_qpool_put(&flex_acl_hw_action_list_qpool_g, &(*hw_action_list_entry_pp)->pool_item);

    if (list_item_next_p == &hw_action_list_p->qlist.end) {
        (*hw_action_list_entry_pp) = NULL;
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *hw_action_list_entry_pp = PARENT_STRUCT(list_item_next_p, hw_action_list_entry_t, list_item);

out:
    return rc;
}

sx_status_t flex_acl_hw_db_hw_action_list_next(hw_action_list_t        *hw_action_list_p,
                                               hw_action_list_entry_t **hw_action_list_entry_pp)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    cl_list_item_t *list_item_next_p;

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_p, "hw_action_list_p"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(hw_action_list_entry_pp, "hw_action_list_entry_pp"))) {
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!flex_acl_hw_action_list_init_done_g) {
        SX_LOG_ERR("ACL HW DB Action List not initialized.\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    list_item_next_p = cl_qlist_next(&(*hw_action_list_entry_pp)->list_item);

    if (list_item_next_p == &hw_action_list_p->qlist.end) {
        (*hw_action_list_entry_pp) = NULL;
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *hw_action_list_entry_pp = PARENT_STRUCT(list_item_next_p, hw_action_list_entry_t, list_item);

out:
    return rc;
}

sx_status_t flex_acl_hw_db_handle_late_binding(uint64_t key, flex_acl_hw_db_binding_data_t *data_p)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    cl_qmap_t                      *binding_map_p = NULL;
    cl_map_item_t                  *map_item_p = NULL;
    cl_pool_item_t                 *pool_item_p = NULL;
    flex_acl_hw_db_binding_entry_t *binding_entry_p = NULL;

    SX_LOG_ENTER();

    if (data_p == NULL) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("data_p is NULL.\n");
        goto out;
    }

    rc = flex_acl_hw_db_get_late_binding_map(data_p->binding_type, &binding_map_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get late binding map for binding type %u.\n", data_p->binding_type);
        goto out;
    }

    map_item_p = cl_qmap_get(binding_map_p, key);
    if (map_item_p != cl_qmap_end(binding_map_p)) {
        binding_entry_p = PARENT_STRUCT(map_item_p, flex_acl_hw_db_binding_entry_t, map_item);
        if ((binding_entry_p->binding_data.bind == TRUE) &&
            (data_p->bind == FALSE)) {
            cl_qmap_remove(binding_map_p, key);
            cl_qpool_put(&flex_acl_hw_db_late_binding_db_s.entry_pool, &binding_entry_p->pool_item);
            goto out;
        }
        binding_entry_p->binding_data = *data_p;
    } else {
        pool_item_p = cl_qpool_get(&flex_acl_hw_db_late_binding_db_s.entry_pool);
        if (pool_item_p == NULL) {
            SX_LOG_ERR("Could not find free entry at the late binding DB.\n");
            rc = SX_STATUS_NO_RESOURCES;
            goto out;
        }
        binding_entry_p = PARENT_STRUCT(pool_item_p, flex_acl_hw_db_binding_entry_t, pool_item);
        binding_entry_p->binding_data = *data_p;
        cl_qmap_insert(binding_map_p, key, &binding_entry_p->map_item);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_db_get_late_binding_map(flex_acl_hw_db_binding_type_e type,
                                                cl_qmap_t                   **binding_map_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (type) {
    case FLEX_ACL_HW_BINDING_PORT_E:
        *binding_map_pp = &flex_acl_hw_db_late_binding_db_s.port_map;
        break;

    case FLEX_ACL_HW_BINDING_VLAN_E:
        *binding_map_pp = &flex_acl_hw_db_late_binding_db_s.vlan_map;
        break;

    case FLEX_ACL_HW_BINDING_RIF_E:
        *binding_map_pp = &flex_acl_hw_db_late_binding_db_s.rif_map;
        break;

    default:
        SX_LOG_ERR("Unsupported binding type: %u\n", type);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

void flex_acl_hw_db_remove_late_binding_entry(flex_acl_hw_db_binding_entry_t *binding_entry_p)
{
    cl_qpool_put(&flex_acl_hw_db_late_binding_db_s.entry_pool, &binding_entry_p->pool_item);
}

/* helper function that searches the ACL Drop Trap FMAP for an entry .
 * If present, return TRUE and the pointer to the fmap item
 * If no, return FALSE, and the pointer to the end of the FMAP
 */
static boolean_t __flex_acl_hw_db_acl_drop_trap_data_fmap_get(sx_acl_pkt_drop_attributes_t *data_p,
                                                              cl_fmap_item_t              **fmap_item_p)
{
    uint32_t num_map_entries = 0;

    num_map_entries = cl_fmap_count(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap));

    if (num_map_entries) {
        /* Map is not empty. Check if it exists .*/
        *fmap_item_p = cl_fmap_get(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap,
                                   data_p);
        /* cl_fmap_get returns the tail if no match found*/
        if (*fmap_item_p != cl_fmap_end(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap)) {
            /* This entry already exists in FMAP. */
            return TRUE;
        }
    }
    return FALSE;
}
static sx_status_t __wjh_acl_shm_db_idx_add(sx_acl_pkt_drop_attributes_t acl_drop_data)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    index = acl_drop_data.trap_usr_def_val;

    SX_LOG_ENTER();

    if (index > SX_ACL_USER_ID_MAX) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("acl drop usr-def-val[%u] is greater than Max [%u] rc = %s\n",
                   acl_drop_data.trap_usr_def_val, SX_ACL_USER_ID_MAX, sx_status_str(rc));
        goto out;
    }
    if (wjh_acl_drp_shm_ptr == NULL) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("WJH ACL SHM not initialized. rc = %s\n", sx_status_str(rc));
        goto out;
    }

#ifndef UNITTESTS
    /* The locking mechanism here in not compatible with multi-process unit test
     *  and therefore disable for all unit tests.
     */
    cl_plock_acquire(&wjh_acl_drp_shm_ptr->p_lock);

    wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[index].acl_id
        = acl_drop_data.acl_id;
    wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[index].acl_region_id
        = acl_drop_data.acl_region_id;
    wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[index].acl_rule_offset
        = acl_drop_data.acl_rule_offset;
    wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[index].acl_direction
        = acl_drop_data.acl_direction;
    wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[index].valid = TRUE;

    cl_plock_release(&wjh_acl_drp_shm_ptr->p_lock);
    SX_LOG_DBG(" Set SHM valid = True at index[%x]=acl(%x)/reg(%x)/off(%u) \n",
               index, acl_drop_data.acl_id, acl_drop_data.acl_region_id, acl_drop_data.acl_rule_offset);
#endif  /* UNITTESTS */

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __wjh_acl_shm_db_idx_del(uint32_t index)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (index > SX_ACL_USER_ID_MAX) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("acl drop usr-def-val[%u] is greater than Max [%u] rc = %s\n",
                   index, SX_ACL_USER_ID_MAX, sx_status_str(rc));
        goto out;
    }
    if (wjh_acl_drp_shm_ptr == NULL) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("WJH ACL SHM not initialized. rc = %s\n", sx_status_str(rc));
        goto out;
    }

#ifndef UNITTESTS
    /* The locking mechanism here in not compatible with multi-process unit test
     *  and therefore disable for all unit tests.
     */
    cl_plock_acquire(&wjh_acl_drp_shm_ptr->p_lock);

    wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[index].acl_id = 0;
    wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[index].acl_region_id = 0;
    wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[index].acl_rule_offset = 0;
    wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[index].valid = FALSE;
    wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[index].acl_direction = 0;

    cl_plock_release(&wjh_acl_drp_shm_ptr->p_lock);

    SX_LOG_DBG(" Set SHM valid = False at index[%x]\n", index);
#endif  /* UNITTESTS */
out:
    SX_LOG_EXIT();
    return rc;
}
/* remove an entry from the ACL Drop FMAP DB */
sx_status_t flex_acl_hw_db_acl_drop_trap_data_db_del(sx_acl_pkt_drop_attributes_t acl_drop_data)
{
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    cl_fmap_item_t                      *fmap_item_p = NULL;
    flex_acl_hw_db_acl_drop_data_item_t *acl_drop_fmap_entry_p = NULL;
    uint32_t                             found_trap_usr_def_val = 0;

    SX_LOG_ENTER();

    if (__flex_acl_hw_db_acl_drop_trap_data_fmap_get(&acl_drop_data, &fmap_item_p)) {
        acl_drop_fmap_entry_p = PARENT_STRUCT(fmap_item_p,
                                              flex_acl_hw_db_acl_drop_data_item_t,
                                              fmap_item);
        /* Put the pointer to the usr def val linked list item back into free list */
        SX_LOG_DBG("First release the usr val [%u] back to free list\n",
                   acl_drop_fmap_entry_p->acl_drop_attr.trap_usr_def_val);
        found_trap_usr_def_val = acl_drop_fmap_entry_p->acl_drop_attr.trap_usr_def_val;
        rc = __acl_drop_trap_usr_def_free_idx_put(&(acl_drop_fmap_entry_p->usr_idx_list_item_p));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_DBG("Failed to release User Index back to Free List\n");
            goto out;
        }
        /* Clear this fmap item's data */
        SX_MEM_CLR(acl_drop_fmap_entry_p->acl_drop_attr);

        cl_fmap_remove_item(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap),
                            (void*)&(acl_drop_fmap_entry_p->fmap_item));

        cl_qpool_put(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_pool),
                     &(acl_drop_fmap_entry_p->pool_item));

        /* SHM Cache Remove */
        __wjh_acl_shm_db_idx_del(found_trap_usr_def_val);
    } else {
        /* Entry not found in FMAP. */
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG(" Entry not found in ACL Drop Fmap DB , err = %s\n", sx_status_str(rc));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}
/* Insert an entry into the ACL Drop FMAP DB */
sx_status_t flex_acl_hw_db_acl_drop_trap_data_db_get(sx_acl_pkt_drop_attributes_t *acl_drop_data_p)
{
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    cl_fmap_item_t                      *fmap_item_p = NULL;
    flex_acl_hw_db_acl_drop_data_item_t *new_acl_drop_fmap_entry_p = NULL;

    SX_LOG_ENTER();
    if (__flex_acl_hw_db_acl_drop_trap_data_fmap_get(acl_drop_data_p, &fmap_item_p)) {
        /* found = TRUE; This entry already exists */
        new_acl_drop_fmap_entry_p = PARENT_STRUCT(fmap_item_p,
                                                  flex_acl_hw_db_acl_drop_data_item_t,
                                                  fmap_item);
        SX_MEM_CPY_P(acl_drop_data_p, &new_acl_drop_fmap_entry_p->acl_drop_attr);

        SX_LOG_DBG("New Valid flag state = %u, usr def val = %u\n",
                   new_acl_drop_fmap_entry_p->acl_drop_attr.valid,
                   new_acl_drop_fmap_entry_p->acl_drop_attr.trap_usr_def_val);
    } else {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
    }

    SX_LOG_EXIT();
    return rc;
}
/* Insert an entry into the ACL Drop FMAP DB */
sx_status_t flex_acl_hw_db_acl_drop_trap_data_db_add(sx_acl_pkt_drop_attributes_t *acl_drop_data_p)
{
    sx_status_t                                  rc = SX_STATUS_SUCCESS;
    cl_fmap_item_t                              *fmap_item_p = NULL;
    flex_acl_hw_db_acl_drop_data_item_t         *new_acl_drop_fmap_entry_p = NULL;
    cl_pool_item_t                              *pool_item_p = NULL;
    flex_acl_hw_db_acl_drop_trap_usr_idx_item_t *list_entry_p = NULL;

    SX_LOG_ENTER();
    if (__flex_acl_hw_db_acl_drop_trap_data_fmap_get(acl_drop_data_p, &fmap_item_p)) {
        /* found = TRUE; This entry already exists */
        new_acl_drop_fmap_entry_p = PARENT_STRUCT(fmap_item_p,
                                                  flex_acl_hw_db_acl_drop_data_item_t,
                                                  fmap_item);
        /* use the valid flag from what was passed.
         * Sometime we only need to update the valid bit to TRUE/FALSE */
        new_acl_drop_fmap_entry_p->acl_drop_attr.valid = acl_drop_data_p->valid;
        acl_drop_data_p->trap_usr_def_val = new_acl_drop_fmap_entry_p->acl_drop_attr.trap_usr_def_val;
        SX_LOG_DBG("New Valid flag state = %u, usr def val = %u\n",
                   new_acl_drop_fmap_entry_p->acl_drop_attr.valid,
                   new_acl_drop_fmap_entry_p->acl_drop_attr.trap_usr_def_val);
    } else {
        /* Entry not found. Need to add it to DB*/
        pool_item_p = cl_qpool_get(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_pool));
        if (NULL == pool_item_p) {
            rc = SX_STATUS_NO_RESOURCES;
            SX_LOG_ERR("NO free pool entries available for ACL Drop Data DB, err = %s\n", sx_status_str(rc));
            goto out;
        }

        new_acl_drop_fmap_entry_p = PARENT_STRUCT(pool_item_p, flex_acl_hw_db_acl_drop_data_item_t, pool_item);
        SX_MEM_CLR(new_acl_drop_fmap_entry_p->acl_drop_attr);

        new_acl_drop_fmap_entry_p->acl_drop_attr.acl_id = acl_drop_data_p->acl_id;
        new_acl_drop_fmap_entry_p->acl_drop_attr.acl_region_id = acl_drop_data_p->acl_region_id;
        new_acl_drop_fmap_entry_p->acl_drop_attr.acl_rule_offset = acl_drop_data_p->acl_rule_offset;

        /* get next Avail Value from the Usr Def Index Free list */
        rc = __acl_drop_trap_usr_def_free_idx_get(&(new_acl_drop_fmap_entry_p->usr_idx_list_item_p));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get Free User Index from List\n");
            goto out;
        }
        list_entry_p = PARENT_STRUCT(new_acl_drop_fmap_entry_p->usr_idx_list_item_p,
                                     flex_acl_hw_db_acl_drop_trap_usr_idx_item_t,
                                     list_item);

        new_acl_drop_fmap_entry_p->acl_drop_attr.trap_usr_def_val =
            acl_drop_data_p->trap_usr_def_val = __acl_drop_user_defined_value_compose(list_entry_p->acl_drop_usridx,
                                                                                      acl_drop_data_p->acl_direction);
        new_acl_drop_fmap_entry_p->acl_drop_attr.valid =
            acl_drop_data_p->valid = TRUE;
        SX_LOG_DBG(" Mapped index value = %u for acl %x region %x, offset %u\n", list_entry_p->acl_drop_usridx,
                   acl_drop_data_p->acl_id, acl_drop_data_p->acl_region_id, acl_drop_data_p->acl_rule_offset);

        cl_fmap_insert(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap),
                       (void*)&(new_acl_drop_fmap_entry_p->acl_drop_attr),
                       &(new_acl_drop_fmap_entry_p->fmap_item));
    }
    /* Update the SHM Cache */
    if (acl_drop_data_p->valid) {
        __wjh_acl_shm_db_idx_add(*acl_drop_data_p);
    } else {
        __wjh_acl_shm_db_idx_del(acl_drop_data_p->trap_usr_def_val);
    }

out:
    SX_LOG_EXIT();

    return rc;
}
/* Edit/Update an existing entry in the ACL Drop FMAP DB.
 * 1. Find if the entry exists,
 * 2. If Yes, Get a ptr to it. If no, Log error and return
 * 3. Remove it from the fmap. This is a must so the the left/right pointers are correct
 * 3. Update the attributes (As of now only the Rule Offset is updated. May be enhanced in the future).
 * 4. Insert it back. */
sx_status_t flex_acl_hw_db_acl_drop_trap_data_db_edit(sx_acl_pkt_drop_attributes_t *old_acl_data_p,
                                                      sx_acl_pkt_drop_attributes_t *new_acl_data_p)
{
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    cl_fmap_item_t                      *fmap_item_p = NULL;
    flex_acl_hw_db_acl_drop_data_item_t *acl_drop_fmap_entry_p = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(old_acl_data_p, "old_acl_data_p"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(new_acl_data_p, "new_acl_data_p"))) {
        goto out;
    }
    if (__flex_acl_hw_db_acl_drop_trap_data_fmap_get(old_acl_data_p, &fmap_item_p)) {
        acl_drop_fmap_entry_p = PARENT_STRUCT(fmap_item_p,
                                              flex_acl_hw_db_acl_drop_data_item_t,
                                              fmap_item);
        /* Put the pointer to the usr def val linked list item back into free list */
        SX_LOG_DBG("First get the item [%u] from the db.\n",
                   acl_drop_fmap_entry_p->acl_drop_attr.trap_usr_def_val);

        /* remove from fmap first */
        cl_fmap_remove_item(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap),
                            (void*)&(acl_drop_fmap_entry_p->fmap_item));

        /* update the necessary data. (As of now only the ACL ID & Rule Offset) */
        acl_drop_fmap_entry_p->acl_drop_attr.acl_id = new_acl_data_p->acl_id;
        acl_drop_fmap_entry_p->acl_drop_attr.acl_rule_offset = new_acl_data_p->acl_rule_offset;
        acl_drop_fmap_entry_p->acl_drop_attr.acl_direction = new_acl_data_p->acl_direction;
        acl_drop_fmap_entry_p->acl_drop_attr.trap_usr_def_val =
            new_acl_data_p->trap_usr_def_val =
                __acl_drop_user_defined_value_compose(acl_drop_fmap_entry_p->acl_drop_attr.trap_usr_def_val,
                                                      new_acl_data_p->acl_direction);

        /* insert into fmap */
        cl_fmap_insert(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap),
                       (void*)&(acl_drop_fmap_entry_p->acl_drop_attr),
                       &(acl_drop_fmap_entry_p->fmap_item));

        /* SHM Cache Update */
        __wjh_acl_shm_db_idx_add(acl_drop_fmap_entry_p->acl_drop_attr);
    } else {
        /* Entry not found in FMAP. */
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR(" Entry not found in ACL Drop Fmap DB , err = %s\n", sx_status_str(rc));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}
sx_status_t flex_acl_hw_db_acl_drop_trap_data_db_size_get(uint32_t *db_size_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(db_size_p, "db_size_p"))) {
        goto out;
    }
    *db_size_p = cl_fmap_count(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap));

out:
    SX_LOG_EXIT();
    return rc;
}
/* Puts the list item pointer back to the User Index Free List. */
static sx_status_t __acl_drop_trap_usr_def_free_idx_put(cl_list_item_t **usr_idx_list_item_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(usr_idx_list_item_p, "usr_idx_list_item_p"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(*usr_idx_list_item_p, "*usr_idx_list_item_p"))) {
        goto out;
    }

    cl_qlist_insert_tail(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list),
                         *usr_idx_list_item_p);

    usr_idx_list_item_p = NULL;
out:
    SX_LOG_EXIT();
    return rc;
}
/*
 * Retrieve the next available index from the Head of The Free List.
 */
static sx_status_t __acl_drop_trap_usr_def_free_idx_get(cl_list_item_t **usr_idx_list_item_p)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    cl_list_item_t *list_item_p = NULL;

    /* flex_acl_hw_db_acl_drop_trap_usr_idx_item_t *acl_drop_usridx_entry_p = NULL; */

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(usr_idx_list_item_p, "usr_idx_list_item_p"))) {
        goto out;
    }

    /* assign a new one from the free list*/
    list_item_p = cl_qlist_remove_head(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list));
    if (cl_qlist_end(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list))
        == list_item_p) {
        /* Shouldn't happen */
        rc = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("no free index avail,Free up some resources. err = %s\n", sx_status_str(rc));
        goto out;
    }
    *usr_idx_list_item_p = list_item_p;

out:
    SX_LOG_EXIT();
    return rc;
}
/* acl_drop attr fmap comparison function*/
static int __flex_acl_hw_db_acl_drop_attr_fmap_cmp_fn(const void *const p_key1, const void *const p_key2)
{
    int                                 res = 0;
    const sx_acl_pkt_drop_attributes_t *acl_drop_attr_1_p = p_key1;
    const sx_acl_pkt_drop_attributes_t *acl_drop_attr_2_p = p_key2;

    CL_ASSERT(NULL != acl_drop_attr_1_p);
    CL_ASSERT(NULL != acl_drop_attr_2_p);

    /* First Compare ACL Id */
    if (acl_drop_attr_1_p->acl_id != acl_drop_attr_2_p->acl_id) {
        res = acl_drop_attr_1_p->acl_id - acl_drop_attr_2_p->acl_id;
        goto out;
    }
    /* Next Compare Region Id */
    if (acl_drop_attr_1_p->acl_region_id != acl_drop_attr_2_p->acl_region_id) {
        res = acl_drop_attr_1_p->acl_region_id - acl_drop_attr_2_p->acl_region_id;
        goto out;
    }
    /* Next Compare Rule Offset */
    if (acl_drop_attr_1_p->acl_rule_offset != acl_drop_attr_2_p->acl_rule_offset) {
        res = acl_drop_attr_1_p->acl_rule_offset - acl_drop_attr_2_p->acl_rule_offset;
        goto out;
    }
    /* If we reach here - both objects are the same. Note: We dont check the usr-def-val */
out:
    return res;
}

static sx_status_t __flex_acl_wjh_acl_drop_trap_shm_db_deinit()
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    int         err = 0;

#ifndef UNITTESTS
    /* The locking mechanism here in not compatible with multi-process unit test
     *  and therefore disable for all unit tests.
     */
    cl_plock_destroy(&wjh_acl_drp_shm_ptr->p_lock);
#endif  /* UNITTESTS */
    err = munmap(wjh_acl_drp_shm_ptr, sizeof(sx_acl_drop_wjh_trap_index_t));
    if (err == -1) {
        SX_LOG_ERR("Failed to unmap the shared memory of the WJH ACL\n");
        rc = SX_STATUS_MEMORY_ERROR;
    }
    /* cl_shm_destroy(WJH_ACL_SHM_PATH);
     * We do not destroy the file as it causes problems during ISSU.
     * We leave the file and re-open it on restart of SDK
     */
    return rc;
}
static sx_status_t __flex_acl_wjh_acl_drop_trap_shm_db_init()
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    int         shmid = 0;
    int         err = 0;
    size_t      size = sizeof(sx_acl_drop_wjh_trap_index_t);

    SX_LOG_ENTER();

    err = cl_shm_create(WJH_ACL_SHM_PATH, &shmid);
    if (err) {
        if (errno == EEXIST) {
            err = cl_shm_open(WJH_ACL_SHM_PATH, &shmid);
            SX_LOG_NTC("Shared memory of the WJH ACL already exists,"
                       "open it\n");
        }

        if (err) {
            SX_LOG_ERR("Failed to create/open the WJH ACL shared memory SHMID = %d err=%s\n",
                       shmid, strerror(errno));
            rc = SX_STATUS_MEMORY_ERROR;
            goto out;
        }
    }

    err = ftruncate(shmid, size);
    if (err == -1) {
        SX_LOG_ERR("truncate error %s\n", strerror(errno));
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    wjh_acl_drp_shm_ptr = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
    close(shmid);

    if (wjh_acl_drp_shm_ptr == MAP_FAILED) {
        SX_LOG_ERR("Failed to map the shared memory of the WJH ACL \n");
        wjh_acl_drp_shm_ptr = NULL;

        cl_shm_destroy(WJH_ACL_SHM_PATH);

        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }

    memset(wjh_acl_drp_shm_ptr, 0, sizeof(sx_acl_drop_wjh_trap_index_t));
#ifndef UNITTESTS
    /* The locking mechanism here in not compatible with multi-process unit test
     *  and therefore disable for all unit tests.
     */
    rc = cl_plock_init_pshared(&wjh_acl_drp_shm_ptr->p_lock);
    if (err) {
        SX_LOG_ERR("Failed to initialize the WJH ACL rwlock\n");
        munmap(wjh_acl_drp_shm_ptr, sizeof(sx_acl_drop_wjh_trap_index_t));
        wjh_acl_drp_shm_ptr = NULL;
        cl_shm_destroy(WJH_ACL_SHM_PATH);
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cl_plock_excl_acquire(&wjh_acl_drp_shm_ptr->p_lock);
    int i = 0;
    for (i = 0; i < SX_ACL_USER_ID_MAX; i++) {
        wjh_acl_drp_shm_ptr->acl_drp_trap_mapping[i].trap_usr_def_val = i;
    }

    msync(wjh_acl_drp_shm_ptr, sizeof(sx_acl_drop_wjh_trap_index_t), MS_SYNC);
    cl_plock_release(&wjh_acl_drp_shm_ptr->p_lock);
#endif  /* UNITTESTS */
out:
    SX_LOG_EXIT();
    return rc;
}
static sx_status_t __flex_acl_hw_db_acl_drop_trap_db_init()
{
    sx_status_t                                  rc = SX_STATUS_SUCCESS;
    cl_status_t                                  cl_status = CL_SUCCESS;
    cl_pool_item_t                              *free_idx_pool_item_p = NULL;
    cl_list_item_t                              *free_idx_list_item_p = NULL;
    flex_acl_hw_db_acl_drop_trap_usr_idx_item_t *free_idx_list_entry_p = NULL;
    boolean_t                                    acl_drop_data_init = FALSE;
    boolean_t                                    acl_free_idx_init = FALSE;
    uint32_t                                     i = 0;

    SX_LOG_ENTER();

    if (TRUE == flex_acl_hw_db_init_done_g) {
        rc = SX_STATUS_DB_ALREADY_INITIALIZED;
        SX_LOG_ERR("ACL HW DB already initialized, err = %s\n", sx_status_str(rc));
        goto out;
    }
    /* init pool for ACL Drop Attributes */
    cl_status = CL_QPOOL_INIT(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_pool,
                              ACL_DROP_DB_POOL_MIN_SIZE,
                              ACL_DROP_DB_POOL_MAX_SIZE,
                              ACL_DROP_DB_POOL_GROW_SIZE,
                              sizeof(flex_acl_hw_db_acl_drop_data_item_t), NULL, NULL, NULL);
    if (CL_SUCCESS != cl_status) {
        rc = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("No resources to allocate for ACL Drop Trap Data pool entry.\n");
        goto out;
    }

    cl_fmap_init(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap),
                 __flex_acl_hw_db_acl_drop_attr_fmap_cmp_fn);
    acl_drop_data_init = TRUE;

    /* Init Pool for ACL user index */
    cl_status = CL_QPOOL_INIT(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_pool,
                              ACL_DROP_DB_POOL_MAX_SIZE,
                              ACL_DROP_DB_POOL_MAX_SIZE,
                              0,
                              sizeof(flex_acl_hw_db_acl_drop_trap_usr_idx_item_t), NULL, NULL, NULL);
    if (CL_SUCCESS != cl_status) {
        rc = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("No resources to allocate for ACL Drop Trap Index pool entry.\n");
        goto out;
    }

    cl_qlist_init(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list);
    for (i = 0; i < ACL_DROP_DB_POOL_MAX_SIZE; i++) {
        /* set the user def indexes into the free list */
        free_idx_pool_item_p =
            cl_qpool_get(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_pool));
        if (NULL == free_idx_pool_item_p) {
            rc = SX_STATUS_NO_RESOURCES;
            SX_LOG_ERR("Unable to get free item from Pool, err = %s\n", sx_status_str(rc));
            goto out;
        }
        free_idx_list_entry_p = PARENT_STRUCT(free_idx_pool_item_p,
                                              flex_acl_hw_db_acl_drop_trap_usr_idx_item_t,
                                              pool_item);
        free_idx_list_entry_p->acl_drop_usridx = i + 1;
        cl_qlist_insert_tail(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list),
                             &(free_idx_list_entry_p->list_item));
    }
    acl_free_idx_init = TRUE;

    /* Now lets init the Shared Memory Array for WJH ACL */
    rc = __flex_acl_wjh_acl_drop_trap_shm_db_init();
    if (rc) {
        SX_LOG_ERR("Failed to init Shared Memory DB for WJH ACL, err = %s\n", sx_status_str(rc));
        goto out;
    }


out:
    if ((SX_STATUS_SUCCESS != rc) && (SX_STATUS_DB_ALREADY_INITIALIZED != rc)) {
        __flex_acl_wjh_acl_drop_trap_shm_db_deinit();

        if (TRUE == acl_drop_data_init) {
            CL_QPOOL_DESTROY(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_pool);
        }
        if (TRUE == acl_free_idx_init) {
            while (TRUE != cl_is_qlist_empty(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list)) {
                free_idx_list_item_p =
                    cl_qlist_remove_head(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list));
                free_idx_list_entry_p = PARENT_STRUCT(free_idx_list_item_p,
                                                      flex_acl_hw_db_acl_drop_trap_usr_idx_item_t,
                                                      list_item);
                cl_qpool_put(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_pool),
                             &(free_idx_list_entry_p->pool_item));
            }

            CL_QPOOL_DESTROY(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_pool));
        }
    }
    SX_LOG_EXIT();
    return rc;
}
static sx_status_t __flex_acl_hw_db_acl_drop_trap_db_deinit()
{
    sx_status_t                                  rc = SX_STATUS_SUCCESS;
    cl_fmap_item_t                              *fmap_item = NULL;
    cl_fmap_item_t                              *tmp_fmap_item = NULL;
    const cl_fmap_item_t                        *fmap_end = NULL;
    flex_acl_hw_db_acl_drop_data_item_t         *acl_drop_fmap_entry_p = NULL;
    flex_acl_hw_db_acl_drop_trap_usr_idx_item_t *acl_drop_usridx_entry_p = NULL;
    cl_list_item_t                              *list_item_p = NULL;

    SX_LOG_ENTER();

    if (FALSE == flex_acl_hw_db_init_done_g) {
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("Failed to deinit ACL Drop Trap Data Db. Module is not initialized.\n");
        goto out;
    }

    /* WJH ACL shared Memory De-Init */
    __flex_acl_wjh_acl_drop_trap_shm_db_deinit();

    /* ACL Drop Trap data FMAP deinitialization */
    fmap_item = cl_fmap_head(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap));
    fmap_end = cl_fmap_end(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap));
    while (fmap_item != fmap_end) {
        acl_drop_fmap_entry_p = PARENT_STRUCT(fmap_item,
                                              flex_acl_hw_db_acl_drop_data_item_t,
                                              fmap_item);
        tmp_fmap_item = fmap_item;
        fmap_item = cl_fmap_next(fmap_item);
        cl_fmap_remove_item(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap,
                            tmp_fmap_item);
        acl_drop_fmap_entry_p = PARENT_STRUCT(tmp_fmap_item,
                                              flex_acl_hw_db_acl_drop_data_item_t,
                                              fmap_item);
        rc = __acl_drop_trap_usr_def_free_idx_put(&(acl_drop_fmap_entry_p->usr_idx_list_item_p));
        cl_qpool_put(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_pool),
                     &(acl_drop_fmap_entry_p->pool_item));
    }
    cl_fmap_remove_all(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_fmap));
    CL_QPOOL_DESTROY(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_data_pool);

    /* Acl Drop Trap User Index Qlist Deinitialization */

    while (TRUE != cl_is_qlist_empty(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list)) {
        list_item_p = cl_qlist_remove_head(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_list));
        acl_drop_usridx_entry_p = PARENT_STRUCT(list_item_p,
                                                flex_acl_hw_db_acl_drop_trap_usr_idx_item_t,
                                                list_item);
        cl_qpool_put(&flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_pool,
                     &(acl_drop_usridx_entry_p->pool_item));
    }
    CL_QPOOL_DESTROY(&(flex_acl_hw_db_acl_drop_trap_data_db_s.acl_drop_usridx_pool));

out:
    SX_LOG_EXIT();
    return rc;
}
