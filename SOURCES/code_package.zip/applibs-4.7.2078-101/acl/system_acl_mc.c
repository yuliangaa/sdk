/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#define SYSTEM_ACL_MC_C_

#include "acl/flex_acl_hw_cb.h"
#include "sx/sxd/kernel_user.h"
#include "acl/system_acl.h"
#include "sx/sxd/sxd_access_register.h"
#include "ethl3/router_common.h"
#include "acl/flex_acl.h"
#include "sx/utils/sx_utils_status.h"
#include "issu/issu.h"
#include "sx/sxd/sxd_emad_acl_reg.h"

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ ACL

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/
static sx_status_t __flex_acl_region_op_to_tcam_allocation_op(acl_region_op_e              region_op,
                                                              sxd_router_tcam_operation_t *tcam_op)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sxd_router_tcam_operation_t ret_op = 0;

    switch (region_op) {
    case ACL_REGION_HW_OP_ALLOCATE_E:
        ret_op = SXD_ROUTER_TCAM_OPERATION_ALLOCATE;
        break;

    case ACL_REGION_HW_OP_RESIZE_E:
        ret_op = SXD_ROUTER_TCAM_OPERATION_RESIZE;
        break;

    case ACL_REGION_HW_OP_DEALLOCATE_E:
        ret_op = SXD_ROUTER_TCAM_OPERATION_DEALLOCATE;
        break;

    case ACL_REGION_HW_OP_TEST_ALLOCATE_E:
        ret_op = SXD_ROUTER_TCAM_OPERATION_TEST;
        break;

    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid region op %u given\n", region_op);
        goto out;
    }

    *tcam_op = ret_op;

out:
    return err;
}

static sx_status_t __client_id_to_tcam_type(system_acl_client_id_e client_id, sxd_router_tcam_type_t *tcam_type)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sxd_router_tcam_type_t ret_type = SXD_ROUTER_TCAM_TYPE_INVALID;
    sx_boot_mode_e         issu_mode = SX_BOOT_MODE_DISABLED_E;
    sx_issu_bank_e         issu_bank = SX_ISSU_BANK_1_E;

    SX_LOG_ENTER();

    err = issu_boot_mode_get(&issu_mode);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get ISSU boot mode\n");
        goto out;
    }

    if (issu_mode != SX_BOOT_MODE_DISABLED_E) {
        err = issu_bank_get(&issu_bank);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get ISSU bank\n");
            goto out;
        }
    }

    if (client_id == SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E) {
        if (issu_bank == SX_ISSU_BANK_1_E) {
            ret_type = SXD_ROUTER_TCAM_TYPE_IPV4_MULTICAST;
        } else {
            ret_type = SXD_ROUTER_TCAM_TYPE_IPV4_MULTICAST_1;
        }
    } else if (client_id == SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E) {
        if (issu_bank == SX_ISSU_BANK_1_E) {
            ret_type = SXD_ROUTER_TCAM_TYPE_IPV6_MULTICAST;
        } else {
            ret_type = SXD_ROUTER_TCAM_TYPE_IPV6_MULTICAST_1;
        }
    } else {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Unsupported client ID %u for mc tcam type\n", client_id);
        goto out;
    }

    *tcam_type = ret_type;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __client_id_to_mc_route_type(system_acl_client_id_e      client_id,
                                                sxd_router_mc_route_type_t *route_type)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sxd_router_mc_route_type_t ret_type = 0;
    sx_boot_mode_e             issu_mode = SX_BOOT_MODE_DISABLED_E;
    sx_issu_bank_e             issu_bank = SX_ISSU_BANK_1_E;

    SX_LOG_ENTER();
    err = issu_boot_mode_get(&issu_mode);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get ISSU mode %s\n", sx_status_str(err));
        goto out;
    }

    if (issu_mode != SX_BOOT_MODE_DISABLED_E) {
        err = issu_bank_get(&issu_bank);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get ISSU mode %s\n", sx_status_str(err));
            goto out;
        }
    }

    if (client_id == SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E) {
        if (issu_bank == SX_ISSU_BANK_1_E) {
            ret_type = SXD_ROUTER_MC_ROUTE_TYPE_IPV4_G0;
        } else {
            ret_type = SXD_ROUTER_MC_ROUTE_TYPE_IPV4_G1;
        }
    } else if (client_id == SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E) {
        if (issu_bank == SX_ISSU_BANK_1_E) {
            ret_type = SXD_ROUTER_MC_ROUTE_TYPE_IPV6_G0;
        } else {
            ret_type = SXD_ROUTER_MC_ROUTE_TYPE_IPV6_G1;
        }
    } else {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Unsupported client ID %u found for mc route type.\n", client_id);
        goto out;
    }

    *route_type = ret_type;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __client_id_to_route_type(system_acl_client_id_e client_id, sxd_router_route_type_t *route_type)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sxd_router_route_type_t ret_type = 0;

    SX_LOG_ENTER();

    if (client_id == SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E) {
        ret_type = SXD_ROUTER_ROUTE_TYPE_IPV4;
    } else if (client_id == SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E) {
        ret_type = SXD_ROUTER_ROUTE_TYPE_IPV6;
    } else {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Unsupported client ID %u found for mc route type.\n", client_id);
        goto out;
    }

    *route_type = ret_type;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __flex_acl_rule_op_to_tcam_rule_op(acl_rule_hw_op_e                   rule_op,
                                                      sxd_router_tcam_write_operation_t *tcam_op,
                                                      boolean_t                         *is_write)
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sxd_router_tcam_write_operation_t ret_op = 0;
    boolean_t                         write = FALSE;

    switch (rule_op) {
    case ACL_RULE_HW_OP_WRITE_E:
    case ACL_RULE_HW_OP_OVERWRITE_E:
        ret_op = SXD_ROUTER_TCAM_WRITE;
        write = TRUE;
        break;

    case ACL_RULE_HW_OP_WRITE_CLEAR_E:
    case ACL_RULE_HW_OP_OVERWRITE_CLEAR_E:
    case ACL_RULE_HW_OP_PRIO_SET_CLEAR_E:
        ret_op = SXD_ROUTER_TCAM_WRITE_CLEAR;
        write = TRUE;
        break;

    case ACL_RULE_HW_OP_READ_E:
        ret_op = SXD_ROUTER_TCAM_READ;
        break;

    case ACL_RULE_HW_OP_CLEAR_ON_READ_E:
        ret_op = SXD_ROUTER_ACTIVITY_CLEAR_ON_READ;
        break;

    case ACL_RULE_HW_OP_UPDATE_E:
    case ACL_RULE_HW_OP_PRIO_SET_E:
        ret_op = SXD_ROUTER_TCAM_UPDATE;
        write = TRUE;
        break;

    case ACL_RULE_HW_OP_CLEAR_ACTIVITY_E:
        ret_op = SXD_ROUTER_TCAM_CLEAR_ACTIVITY;
        write = TRUE;
        break;

    case ACL_RULE_HW_OP_LAST_E:
    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid rule op %u received\n", rule_op);
        goto out;
    }

    *tcam_op = ret_op;
    *is_write = write;

out:
    return err;
}

static sx_status_t __flex_acl_move_op_to_rrcr_op(acl_move_rule_hw_op_e move_op, sxd_rrcr_opcode_t *rrcr_op)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sxd_rrcr_opcode_t ret_op = SXD_RRCR_OPCODE_COPY;

    switch (move_op) {
    case ACL_RULE_MOVE_HW_OP_COPY_E:
        ret_op = SXD_RRCR_OPCODE_COPY;
        break;

    case ACL_RULE_MOVE_HW_OP_MOVE_E:
        ret_op = SXD_RRCR_OPCODE_MOVE;
        break;

    case ACL_RULE_MOVE_HW_OP_LAST_E:
    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Invalid move op %u given\n", move_op);
        goto out;
    }

    *rrcr_op = ret_op;

out:
    return err;
}

sx_status_t system_acl_mc_log_verbosity_level_set(sx_verbosity_level_t verbosity)
{
    LOG_VAR_NAME(__MODULE__) = verbosity;
    return SX_STATUS_SUCCESS;
}

sx_status_t system_acl_mc_router_hw_bind_region_spc(sx_access_cmd_t        cmd,
                                                    system_acl_client_id_e client_id,
                                                    boolean_t              second_group)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sxd_status_t         sxd_err = SXD_STATUS_SUCCESS;
    struct ku_pemrbt_reg pemrbt_reg_data;
    sxd_reg_meta_t       reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();
    SX_MEM_CLR(pemrbt_reg_data);
    SX_MEM_CLR(reg_meta);

    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    if ((cmd != SX_ACCESS_CMD_BIND) && (cmd != SX_ACCESS_CMD_ADD)) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Unsupported CMD %s for mc tcam type\n", sx_access_cmd_str(cmd));
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list, error: %s.\n", sx_status_str(err));
        goto out;
    }

    if (client_id == SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E) {
        pemrbt_reg_data.protocol = 0;
    } else if (client_id == SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E) {
        pemrbt_reg_data.protocol = 1;
    } else {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Unsupported client ID %u for mc tcam type\n", client_id);
        goto out;
    }

    /*SXD_PEMRBT_OP_BIND_E = 0, SXD_PEMRBT_OP_ADD_E = 2*/
    pemrbt_reg_data.op = (cmd == SX_ACCESS_CMD_BIND) ? 0 : 2;
    pemrbt_reg_data.group_id = (second_group == TRUE) ? 1 : 0;
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;
    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PEMRBT_E, &pemrbt_reg_data, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = sxd_status_to_sx_status(sxd_err);
        SX_LOG_ERR("Failed to bind MC router TCAM region of protocol %u in PEMRBT, err = [%s]\n",
                   pemrbt_reg_data.protocol, sx_status_str(err));
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __system_acl_mc_hw_write_region(acl_region_op_e        region_op,
                                                   sx_dev_id_t            dev_id,
                                                   sx_acl_region_id_t     region_id,
                                                   sx_acl_key_type_t      key_handle,
                                                   sx_acl_key_block_e    *key_blocks,
                                                   uint32_t               key_blocks_cnt,
                                                   uint8_t               *tcam_region_info,
                                                   uint32_t               tcam_region_info_size,
                                                   sx_acl_size_t          new_size,
                                                   sx_acl_size_t         *allocated_size_p,
                                                   system_acl_client_id_e client_id)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;
    struct ku_rtar_reg rtar_reg_data;
    sxd_reg_meta_t     reg_meta;
    sx_boot_mode_e     issu_mode = SX_BOOT_MODE_DISABLED_E;
    sx_issu_bank_e     issu_bank = SX_ISSU_BANK_1_E;

    SX_LOG_ENTER();

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(key_handle);
    UNUSED_PARAM(key_blocks);
    UNUSED_PARAM(key_blocks_cnt);
    UNUSED_PARAM(tcam_region_info);
    UNUSED_PARAM(tcam_region_info_size);

    SX_MEM_CLR(rtar_reg_data);
    SX_MEM_CLR(reg_meta);

    err = __flex_acl_region_op_to_tcam_allocation_op(region_op, &rtar_reg_data.operation);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = issu_boot_mode_get(&issu_mode);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get ISSU boot mode\n");
        goto out;
    }

    if ((rtar_reg_data.operation == SXD_ROUTER_TCAM_OPERATION_ALLOCATE) ||
        (rtar_reg_data.operation == SXD_ROUTER_TCAM_OPERATION_RESIZE)) {
        rtar_reg_data.tcam_size = new_size;
    }

    rtar_reg_data.external_bind = TRUE;

    err = __client_id_to_tcam_type(client_id, &rtar_reg_data.type);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.dev_id = dev_id;
    reg_meta.mode = SXD_ACCESS_MODE_SYNC_DEPARSE;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RTAR_E, &rtar_reg_data, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = sxd_status_to_sx_status(sxd_err);
        SX_LOG_ERR_RESOURCE_COND(err,
                                 "Failed to allocate TCAM region of type %u and size %u in RTAR, err = [%s]\n",
                                 rtar_reg_data.type, new_size, sx_status_str(err));
        goto out;
    }

    *allocated_size_p = rtar_reg_data.tcam_size;

    if ((issu_mode == SX_BOOT_MODE_ISSU_STARTED_E) || (region_op == ACL_REGION_HW_OP_DEALLOCATE_E)) {
        goto out;
    } else if (issu_mode == SX_BOOT_MODE_DISABLED_E) {
        err = system_acl_mc_router_hw_bind_region_spc(SX_ACCESS_CMD_BIND, client_id, FALSE);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to bind MC router region, ISSU bank = %u, client = %u\n", issu_bank, client_id);
            goto out;
        }
    } else {
        err = issu_bank_get(&issu_bank);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get ISSU Bank\n");
            goto out;
        }

        err =
            system_acl_mc_router_hw_bind_region_spc(SX_ACCESS_CMD_BIND, client_id,
                                                    (issu_bank == SX_ISSU_BANK_1_E ? FALSE : TRUE));
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to bind MC router region, ISSU bank = %u, client = %u\n", issu_bank, client_id);
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __system_acl_mc_hw_write_rule(acl_rule_hw_op_e        op,
                                                 sx_dev_id_t             dev_id,
                                                 sx_acl_region_id_t      region_id,
                                                 const void             *region_info,
                                                 sx_acl_rule_offset_t    offset,
                                                 boolean_t               is_valid,
                                                 uint32_t                priority,
                                                 sx_flex_acl_key_desc_t *keys,
                                                 uint32_t                keys_cnt,
                                                 sx_acl_key_block_e     *key_blocks,
                                                 uint32_t                key_blocks_cnt,
                                                 sxd_flex_action_set_t  *reg_action_set,
                                                 boolean_t              *activity_value,
                                                 system_acl_client_id_e  client_id)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sxd_status_t          sxd_err = SXD_STATUS_SUCCESS;
    struct ku_rmft_v2_reg rmft_v2_reg_data;
    sxd_reg_meta_t        reg_meta;
    uint32_t              key_idx = 0;
    uint32_t              i = 0;
    boolean_t             sip_added = FALSE;
    boolean_t             dip_added = FALSE;
    boolean_t             vrid_added = FALSE;
    boolean_t             irif_added = FALSE;
    sx_ip_version_t       route_type = SX_IP_VERSION_NONE;
    boolean_t             is_write = FALSE;

    SX_LOG_ENTER();

    UNUSED_PARAM(region_id);
    UNUSED_PARAM(region_info);
    UNUSED_PARAM(key_blocks);
    UNUSED_PARAM(key_blocks_cnt);
    UNUSED_PARAM(priority);

    SX_MEM_CLR(rmft_v2_reg_data);
    SX_MEM_CLR(reg_meta);

    rmft_v2_reg_data.valid = is_valid;
    err = __flex_acl_rule_op_to_tcam_rule_op(op, &rmft_v2_reg_data.operation, &is_write);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = __client_id_to_mc_route_type(client_id, &rmft_v2_reg_data.route_type);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    rmft_v2_reg_data.offset = offset;

    if ((is_valid) && (is_write)) {
        for (key_idx = 0; key_idx < keys_cnt; key_idx++) {
            switch (keys[key_idx].key_id) {
            case FLEX_ACL_KEY_VIRTUAL_ROUTER:
                if (!keys[key_idx].mask.virtual_router) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("VRID field is masked as FALSE\n");
                    goto out;
                }

                if (vrid_added) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("VRID key received twice\n");
                    goto out;
                }

                rmft_v2_reg_data.router = keys[key_idx].key.virtual_router;
                vrid_added = TRUE;
                break;

            case FLEX_ACL_KEY_SIP:
                if (keys[key_idx].key.sip.version != SX_IP_VERSION_IPV4) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("Expected IP version of key %u is IPv4, received %u\n",
                               key_idx, keys[key_idx].key.sip.version);
                    goto out;
                }

                if (sip_added) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("SIP key received twice\n");
                    goto out;
                }

                if (route_type == SX_IP_VERSION_IPV6) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("Inconsistency in route types between source and destination IPs\n");
                    goto out;
                }

                rmft_v2_reg_data.source_ip[0] = keys[key_idx].key.sip.addr.ipv4.s_addr;
                rmft_v2_reg_data.source_ip_mask[0] = keys[key_idx].mask.sip.addr.ipv4.s_addr;
                route_type = SX_IP_VERSION_IPV4;
                sip_added = TRUE;
                break;

            case FLEX_ACL_KEY_SIPV6:
                if (keys[key_idx].key.sipv6.version != SX_IP_VERSION_IPV6) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("Expected IP version of key %u is IPv6, received %u\n",
                               key_idx, keys[key_idx].key.sip.version);
                    goto out;
                }

                if (sip_added) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("SIP key received twice\n");
                    goto out;
                }

                if (route_type == SX_IP_VERSION_IPV4) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("Inconsistency in route types between source and destination IPs\n");
                    goto out;
                }

                for (i = 0; i < 4; i++) {
                    rmft_v2_reg_data.source_ip[i] = keys[key_idx].key.sipv6.addr.ipv6.s6_addr32[i];
                    rmft_v2_reg_data.source_ip_mask[i] = keys[key_idx].mask.sipv6.addr.ipv6.s6_addr32[i];
                }
                route_type = SX_IP_VERSION_IPV6;
                sip_added = TRUE;
                break;

            case FLEX_ACL_KEY_DIP:
                if (keys[key_idx].key.dip.version != SX_IP_VERSION_IPV4) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("Expected IP version of key %u is IPv4, received %u\n",
                               key_idx, keys[key_idx].key.dip.version);
                    goto out;
                }

                if (dip_added) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("DIP key received twice\n");
                    goto out;
                }

                if (route_type == SX_IP_VERSION_IPV6) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("Inconsistency in route types between source and destination IPs\n");
                    goto out;
                }

                rmft_v2_reg_data.destination_ip[0] = keys[key_idx].key.dip.addr.ipv4.s_addr;
                rmft_v2_reg_data.destination_ip_mask[0] = keys[key_idx].mask.dip.addr.ipv4.s_addr;
                route_type = SX_IP_VERSION_IPV4;
                dip_added = TRUE;
                break;

            case FLEX_ACL_KEY_DIPV6:
                if (keys[key_idx].key.dipv6.version != SX_IP_VERSION_IPV6) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("Expected IP version of key %u is IPv6, received %u\n",
                               key_idx, keys[key_idx].key.dipv6.version);
                    goto out;
                }

                if (dip_added) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("DIP key received twice\n");
                    goto out;
                }

                if (route_type == SX_IP_VERSION_IPV4) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("Inconsistency in route types between source and destination IPs\n");
                    goto out;
                }

                for (i = 0; i < 4; i++) {
                    rmft_v2_reg_data.destination_ip[i] = keys[key_idx].key.dipv6.addr.ipv6.s6_addr32[i];
                    rmft_v2_reg_data.destination_ip_mask[i] = keys[key_idx].mask.dipv6.addr.ipv6.s6_addr32[i];
                }
                route_type = SX_IP_VERSION_IPV6;
                dip_added = TRUE;
                break;

            case FLEX_ACL_KEY_IRIF:
                if (irif_added) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("Ingress RIF key received twice\n");
                    goto out;
                }

                if (!keys[key_idx].mask.irif) {
                    err = SX_STATUS_ERROR;
                    SX_LOG_ERR("Ingress RIF field is masked as FALSE\n");
                    goto out;
                }

                err = sdk_router_cmn_rif_hw_id_get(keys[key_idx].key.irif,
                                                   &rmft_v2_reg_data.irif);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed to convert ingress RIF %u to HW RIF ID, err = [%s]\n",
                               keys[key_idx].key.irif, sx_status_str(err));
                    goto out;
                }

                rmft_v2_reg_data.irif_mask = TRUE;
                irif_added = TRUE;
                break;

            default:
                err = SX_STATUS_ERROR;
                SX_LOG_ERR("Unexpected key ID %u received at index %u\n",
                           keys[key_idx].key_id, key_idx);
                goto out;
            }
        }

        if (((!vrid_added) || (!sip_added) || (!dip_added)) &&
            (rmft_v2_reg_data.operation != SXD_ROUTER_TCAM_UPDATE)) {
            err = SX_STATUS_ERROR;
            SX_LOG_ERR("Either VRID, SIP, or DIP weren't given - VRID: %s, SIP: %s, DIP: %s\n",
                       vrid_added ? "TRUE" : "FALSE",
                       sip_added ? "TRUE" : "FALSE",
                       dip_added ? "TRUE" : "FALSE");
            goto out;
        }

        if ((rmft_v2_reg_data.operation == SXD_ROUTER_TCAM_WRITE) ||
            (rmft_v2_reg_data.operation == SXD_ROUTER_TCAM_UPDATE) ||
            (rmft_v2_reg_data.operation == SXD_ROUTER_TCAM_WRITE_CLEAR)) {
            if (utils_check_pointer(reg_action_set, "reg_action_set")) {
                err = SX_STATUS_PARAM_NULL;
                goto out;
            }

            rmft_v2_reg_data.flexible_action_set = *reg_action_set;
        }
    }

    reg_meta.access_cmd = is_write ? SXD_ACCESS_CMD_SET : SXD_ACCESS_CMD_GET;
    reg_meta.dev_id = dev_id;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RMFTV2_E, &rmft_v2_reg_data, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = sxd_status_to_sx_status(sxd_err);
        SX_LOG_ERR("Failed to write rule to RMFTv2, err = [%s]\n", sx_status_str(err));
        goto out;
    }

    if (!is_write) {
        if (utils_check_pointer(activity_value, "activity_value")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }

        *activity_value = rmft_v2_reg_data.activity;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __system_acl_mc_hw_move_rule(acl_move_rule_hw_op_e  op,
                                                sx_dev_id_t            dev_id,
                                                sx_acl_region_id_t     src_region_id,
                                                sx_acl_region_id_t     dst_region_id,
                                                const void            *src_region_info,
                                                const void            *dst_region_info,
                                                sx_acl_rule_offset_t   src_offset,
                                                sx_acl_rule_offset_t   dst_offset,
                                                uint32_t               size,
                                                system_acl_client_id_e client_id)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta;
    struct ku_rrcr_reg rrcr_data;

    SX_LOG_ENTER();

    UNUSED_PARAM(src_region_info);
    UNUSED_PARAM(dst_region_info);

    SX_MEM_CLR(rrcr_data);
    SX_MEM_CLR(reg_meta);

    if (src_region_id != dst_region_id) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Source region ID %u is not equal to destination region ID %u\n",
                   src_region_id, dst_region_id);
        goto out;
    }

    err = __flex_acl_move_op_to_rrcr_op(op, &rrcr_data.op);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    rrcr_data.offset = src_offset;
    rrcr_data.size = size;
    rrcr_data.dest_offset = dst_offset;

    err = __client_id_to_tcam_type(client_id, (sxd_router_tcam_type_t*)&rrcr_data.table_id);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RRCR_E, &rrcr_data, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = sxd_status_to_sx_status(sxd_err);
        SX_LOG_ERR("Failed to move rule from offset %u to offset %u in RRCR, err = [%s]\n",
                   rrcr_data.offset, rrcr_data.dest_offset, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t system_acl_mc_hw_write_region_ipv4(acl_region_op_e     region_op,
                                               sx_dev_id_t         dev_id,
                                               sx_acl_region_id_t  region_id,
                                               sx_acl_key_type_t   key_handle,
                                               sx_acl_key_block_e *key_blocks,
                                               uint32_t            key_blocks_cnt,
                                               uint8_t            *tcam_region_info,
                                               uint32_t            tcam_region_info_size,
                                               sx_acl_size_t       new_size,
                                               sx_acl_size_t      *allocated_size_p,
                                               boolean_t           stateful_db_region)
{
    UNUSED_PARAM(stateful_db_region);

    return __system_acl_mc_hw_write_region(region_op, dev_id, region_id, key_handle, key_blocks,
                                           key_blocks_cnt, tcam_region_info, tcam_region_info_size,
                                           new_size, allocated_size_p, SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E);
}

sx_status_t system_acl_mc_hw_write_rule_ipv4(acl_rule_hw_op_e        op,
                                             sx_dev_id_t             dev_id,
                                             sx_acl_region_id_t      region_id,
                                             const void             *region_info,
                                             sx_acl_rule_offset_t    offset,
                                             boolean_t               is_valid,
                                             uint32_t                priority,
                                             sx_flex_acl_key_desc_t *keys,
                                             uint32_t                keys_cnt,
                                             sx_acl_key_block_e     *key_blocks,
                                             uint32_t                key_blocks_cnt,
                                             sxd_flex_action_set_t  *reg_action_set,
                                             boolean_t              *activity_value,
                                             boolean_t               bulk_write)
{
    UNUSED_PARAM(bulk_write);
    return __system_acl_mc_hw_write_rule(op,
                                         dev_id,
                                         region_id,
                                         region_info,
                                         offset,
                                         is_valid,
                                         priority,
                                         keys,
                                         keys_cnt,
                                         key_blocks,
                                         key_blocks_cnt,
                                         reg_action_set,
                                         activity_value,
                                         SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E);
}

sx_status_t system_acl_mc_hw_move_rule_ipv4(acl_move_rule_hw_op_e op,
                                            sx_dev_id_t           dev_id,
                                            sx_acl_region_id_t    src_region_id,
                                            sx_acl_region_id_t    dst_region_id,
                                            const void           *src_region_info,
                                            const void           *dst_region_info,
                                            sx_acl_rule_offset_t  src_offset,
                                            sx_acl_rule_offset_t  dst_offset,
                                            uint32_t              size,
                                            boolean_t             change_priority)
{
    UNUSED_PARAM(change_priority);
    return __system_acl_mc_hw_move_rule(op, dev_id, src_region_id, dst_region_id, src_region_info, dst_region_info,
                                        src_offset, dst_offset, size, SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E);
}

sx_status_t system_acl_mc_hw_write_region_ipv6(acl_region_op_e     region_op,
                                               sx_dev_id_t         dev_id,
                                               sx_acl_region_id_t  region_id,
                                               sx_acl_key_type_t   key_handle,
                                               sx_acl_key_block_e *key_blocks,
                                               uint32_t            key_blocks_cnt,
                                               uint8_t            *tcam_region_info,
                                               uint32_t            tcam_region_info_size,
                                               sx_acl_size_t       new_size,
                                               sx_acl_size_t      *allocated_size_p,
                                               boolean_t           stateful_db_region)
{
    UNUSED_PARAM(stateful_db_region);

    return __system_acl_mc_hw_write_region(region_op, dev_id, region_id, key_handle, key_blocks,
                                           key_blocks_cnt, tcam_region_info, tcam_region_info_size,
                                           new_size, allocated_size_p, SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E);
}

sx_status_t system_acl_mc_hw_write_rule_ipv6(acl_rule_hw_op_e        op,
                                             sx_dev_id_t             dev_id,
                                             sx_acl_region_id_t      region_id,
                                             const void             *region_info,
                                             sx_acl_rule_offset_t    offset,
                                             boolean_t               is_valid,
                                             uint32_t                priority,
                                             sx_flex_acl_key_desc_t *keys,
                                             uint32_t                keys_cnt,
                                             sx_acl_key_block_e     *key_blocks,
                                             uint32_t                key_blocks_cnt,
                                             sxd_flex_action_set_t  *reg_action_set,
                                             boolean_t              *activity_value,
                                             boolean_t               bulk_write)
{
    UNUSED_PARAM(bulk_write);
    return __system_acl_mc_hw_write_rule(op,
                                         dev_id,
                                         region_id,
                                         region_info,
                                         offset,
                                         is_valid,
                                         priority,
                                         keys,
                                         keys_cnt,
                                         key_blocks,
                                         key_blocks_cnt,
                                         reg_action_set,
                                         activity_value,
                                         SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E);
}

sx_status_t system_acl_mc_hw_move_rule_ipv6(acl_move_rule_hw_op_e op,
                                            sx_dev_id_t           dev_id,
                                            sx_acl_region_id_t    src_region_id,
                                            sx_acl_region_id_t    dst_region_id,
                                            const void           *src_region_info,
                                            const void           *dst_region_info,
                                            sx_acl_rule_offset_t  src_offset,
                                            sx_acl_rule_offset_t  dst_offset,
                                            uint32_t              size,
                                            boolean_t             change_priority)
{
    UNUSED_PARAM(change_priority);
    return __system_acl_mc_hw_move_rule(op, dev_id, src_region_id, dst_region_id, src_region_info, dst_region_info,
                                        src_offset, dst_offset, size, SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E);
}

/* the function do nothing, needed to complete registers callback list */
sx_status_t system_acl_mc_acl_write_hw_cb(sx_acl_id_t        acl_id,
                                          sx_acl_direction_t direction,
                                          uint8_t           *region_info,
                                          uint32_t           region_info_size,
                                          sx_dev_id_t        dev_id,
                                          boolean_t          valid)
{
    SX_LOG_DBG("ACL_REG_CB: acl_id[%u], direction[%u], region_info[%p], region_info_size[%d], dev_id[%u], valid[%u]\n",
               acl_id,
               direction,
               region_info,
               region_info_size,
               dev_id,
               valid);
    return SX_STATUS_SUCCESS;
}

static sx_status_t __system_acl_mc_hw_activity_dump(boolean_t              is_clear,
                                                    sx_dev_id_t            dev_id,
                                                    const void            *region_info,
                                                    sx_acl_rule_offset_t   offset,
                                                    uint32_t               num_entries,
                                                    bit_vector_t          *activities_p,
                                                    system_acl_client_id_e client_id)
{
    sx_status_t          status = SX_STATUS_SUCCESS;
    sxd_status_t         sxd_status = SXD_STATUS_SUCCESS;
    sx_utils_status_t    utils_status = SX_UTILS_STATUS_SUCCESS;
    sxd_reg_meta_t       reg_meta;
    uint8_t              activities_index = 0;
    uint32_t             activities[SXD_RMFTAD_ACTIVITIES_VECTOR_SIZE];
    int                  index = 0;
    struct ku_rmftad_reg rmftad_data;

    UNUSED_PARAM(region_info);

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(rmftad_data);
    SX_MEM_CLR(activities);

    rmftad_data.operation = (is_clear) ? SXD_EMAD_RMFTAD_OPERATION_READ_CLEAR_E : SXD_EMAD_RMFTAD_OPERATION_READ_E;
    rmftad_data.offset = offset;
    rmftad_data.num_entries = num_entries;

    status = __client_id_to_route_type(client_id, (sxd_router_route_type_t*)&rmftad_data.route_type);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to get route type from client_id, client_id = [%d]\n", client_id);
        goto out;
    }

    reg_meta.dev_id = dev_id;
    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;

    sxd_status = sxd_access_reg_rmftad(&rmftad_data, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        status = sxd_status_to_sx_status(sxd_status);
        SX_LOG_ERR("Failed to get activities from RMFTAD, status = [%s]\n",
                   sx_status_str(status));
        goto out;
    }

    /* change order of array elements to get valid offsets */
    for (index = (SXD_RMFTAD_ACTIVITIES_VECTOR_SIZE - 1); index >= 0; index--) {
        activities[activities_index] = rmftad_data.activities[index];
        activities_index++;
    }

    /* copy from array only needed size in words */
    utils_status = bit_vector_assign_array(activities_p, activities, ((num_entries - 1) / 32) + 1);
    if (SX_UTILS_CHECK_FAIL(utils_status)) {
        status = sx_utils_status_to_sx_status(utils_status);
        SX_LOG_ERR("Failed to assign array of bits to bit_vector, err = [%s]\n",
                   sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t system_acl_mc_hw_activity_dump_ipv4(boolean_t            is_clear,
                                                sx_dev_id_t          dev_id,
                                                const void          *region_info,
                                                sx_acl_rule_offset_t offset,
                                                uint32_t             num_entries,
                                                bit_vector_t        *activities_p)
{
    return __system_acl_mc_hw_activity_dump(is_clear,
                                            dev_id,
                                            region_info,
                                            offset,
                                            num_entries,
                                            activities_p,
                                            SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E);
}

sx_status_t system_acl_mc_hw_activity_dump_ipv6(boolean_t            is_clear,
                                                sx_dev_id_t          dev_id,
                                                const void          *region_info,
                                                sx_acl_rule_offset_t offset,
                                                uint32_t             num_entries,
                                                bit_vector_t        *activities_p)
{
    return __system_acl_mc_hw_activity_dump(is_clear,
                                            dev_id,
                                            region_info,
                                            offset,
                                            num_entries,
                                            activities_p,
                                            SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E);
}

sx_status_t system_acl_hw_write_region_dummy(acl_region_op_e     region_op,
                                             sx_dev_id_t         dev_id,
                                             sx_acl_region_id_t  region_id,
                                             sx_acl_key_type_t   key_handle,
                                             sx_acl_key_block_e *key_blocks,
                                             uint32_t            key_blocks_cnt,
                                             uint8_t            *tcam_region_info,
                                             uint32_t            tcam_region_info_size,
                                             sx_acl_size_t       new_size,
                                             sx_acl_size_t      *allocated_size_p,
                                             boolean_t           stateful_db_region)
{
    UNUSED_PARAM(region_op);
    UNUSED_PARAM(dev_id);
    UNUSED_PARAM(region_id);
    UNUSED_PARAM(key_handle);
    UNUSED_PARAM(key_blocks);
    UNUSED_PARAM(key_blocks_cnt);
    UNUSED_PARAM(tcam_region_info);
    UNUSED_PARAM(tcam_region_info_size);
    UNUSED_PARAM(new_size);
    UNUSED_PARAM(allocated_size_p);
    UNUSED_PARAM(stateful_db_region);
    return SX_STATUS_SUCCESS;
}

sx_status_t system_acl_hw_write_acl_dummy(sx_acl_id_t        acl_id,
                                          sx_acl_direction_t direction,
                                          uint8_t           *region_info,
                                          uint32_t           region_info_size,
                                          sx_dev_id_t        dev_id,
                                          boolean_t          valid)
{
    UNUSED_PARAM(acl_id);
    UNUSED_PARAM(direction);
    UNUSED_PARAM(region_info);
    UNUSED_PARAM(region_info_size);
    UNUSED_PARAM(dev_id);
    UNUSED_PARAM(valid);
    return SX_STATUS_SUCCESS;
}

/* Stateful DB callback function intended to write the pointer to the failure actions */
sx_status_t system_acl_hw_write_rule_stateful_db(acl_rule_hw_op_e        op,
                                                 sx_dev_id_t             dev_id,
                                                 sx_acl_region_id_t      region_id,
                                                 const void             *region_info,
                                                 sx_acl_rule_offset_t    offset,
                                                 boolean_t               is_valid,
                                                 uint32_t                priority,
                                                 sx_flex_acl_key_desc_t *keys,
                                                 uint32_t                keys_cnt,
                                                 sx_acl_key_block_e     *key_blocks,
                                                 uint32_t                key_blocks_cnt,
                                                 sxd_flex_action_set_t  *reg_action_set,
                                                 boolean_t              *activity_value,
                                                 boolean_t               bulk_write)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sxd_status_t                    sxd_err = SXD_STATUS_SUCCESS;
    struct ku_fsfh_reg              fsfh_reg_data;
    sxd_reg_meta_t                  fsfh_reg_meta;
    sxd_emad_flex_action_set_reg_t *action_reg_p = NULL;

    SX_LOG_ENTER();


    UNUSED_PARAM(op);
    UNUSED_PARAM(region_id);
    UNUSED_PARAM(region_info);
    UNUSED_PARAM(priority);
    UNUSED_PARAM(keys);
    UNUSED_PARAM(keys_cnt);
    UNUSED_PARAM(key_blocks);
    UNUSED_PARAM(key_blocks_cnt);
    UNUSED_PARAM(activity_value);
    UNUSED_PARAM(bulk_write);

    SX_MEM_CLR(fsfh_reg_meta);
    SX_MEM_CLR(fsfh_reg_data);

    fsfh_reg_meta.dev_id = dev_id;
    fsfh_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    fsfh_reg_data.failure_reason = offset;
    /* Note: The action info is in the format of a regular ACL action set. Since we're writing all the actions
     * in the KVD (to reduce implementation complexity) we only need the pointer to the KVD.
     */
    action_reg_p = (sxd_emad_flex_action_set_reg_t*)&fsfh_reg_data.action_info;
    if (is_valid) {
        action_reg_p->type = SXD_FLEX_NEXT_POINTER_RECORD_E;
        action_reg_p->next_goto_record.next_action_set_ptr = reg_action_set->next_goto_record.next_action_set_ptr;
    } else {  /* Return to nop operation  when deleting */
        action_reg_p->type = SXD_FLEX_GOTO_RECORD_E;
    }

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_FSFH_E, &fsfh_reg_data, &fsfh_reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = sxd_status_to_sx_status(sxd_err);
        SX_LOG_ERR("Failed to configure stateful DB failure action [%u] register, err = [%s]\n",
                   offset, sx_status_str(err));
        goto out;
    }


out:
    return err;
}
