/*
 * SPDX-FileCopyrightText: Copyright (c) 2008-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef FLEX_ACL_HW_H_
#define FLEX_ACL_HW_H_

#include "flex_acl.h"
#include "flex_acl_hw_common.h"
#include <sx/sdk/sx_flex_acl.h>
#include "flex_acl_hw_db.h"
#include <policer/policer_manager.h>
#include <counters/counter_manager/counter_manager.h>
#include <span/span.h>
#include "sx/utils/sdk_refcount.h"
#include <utils/sx_adviser.h>
#include <ethl3/hwi/ecmp/router_ecmp.h>

#ifdef FLEX_ACL_HW_C_

/************************************************
 *  Local Defines
 ***********************************************/
/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#endif

/************************************************
 *  Macros
 ***********************************************/
#define FLEX_ACL_HW_FULL_WRITE              TRUE
#define FLEX_ACL_HW_ALLOW_WRITE_ONLY_ACTION FALSE
#define FLEX_ACL_DROP_TRAP_HANDLE(region, offset) \
    (((uint64_t)(region) << 32) | (uint64_t)offset)
#define FLEX_ACL_DROP_TRAP_HANDLE_TO_REGION(handle) \
    ((uint32_t)(((uint64_t)handle) >> 32))
#define FLEX_ACL_DROP_TRAP_HANDLE_TO_OFFSET(handle) \
    ((uint32_t)(handle & 0xFFFFFFFF))
/************************************************
 *  Type definitions
 ***********************************************/
typedef struct {
    hwi_ecmp_hw_block_handle_t ecmp_block_handle;
    uint32_t                   old_adjacency_index;
    uint32_t                   old_arlpgt_index;
    hwd_ecmp_block_size_t      old_ecmp_size;
    uint32_t                   new_adjacency_index;
    uint32_t                   new_arlpgt_index;
    hwd_ecmp_block_size_t      new_ecmp_size;
} flex_acl_hw_ecmp_container_change_data_t;

typedef struct {
    uint8_t custom_bytes_set_code;
} acl_hw_custom_bytes_set_data_t;

typedef struct {
    uint8_t extraction_point_type_code;
} acl_hw_extraction_point_data_t;

/************************************************
 *  Global variables
 ***********************************************/
extern flex_acl_actions_details_t sx_flex_acl_actions_details[];

/************************************************
 *  Function declarations
 ***********************************************/
/* the function sets registers callbacks in hw region attributes structure */
sx_status_t flex_acl_hw_set_register_cb(sx_acl_region_id_t region_id, flex_acl_hw_reg_cb_t *register_cbs);

sx_status_t flex_acl_hw_free_rule_third_party_resources(flex_acl_db_flex_rule_t* rule);

/* the function below should create region, acl, bind them and add rules */

sx_status_t flex_acl_hw_is_commit_acl(sx_acl_id_t acl_id, boolean_t *is_commit);
sx_status_t flex_acl_hw_commit_acl_set(sx_acl_id_t acl_id, sx_acl_direction_t direction);
sx_status_t flex_acl_hw_commit_acl_get(sx_acl_id_t *acl_id, sx_acl_direction_t direction);
sx_status_t flex_acl_hw_gen_hw_action_sets(flex_acl_db_flex_rule_t *rule_ptr, boolean_t is_defer, /* calls to populate go to action */
                                           flex_acl_hw_db_action_set_t **new_action_set);
sx_status_t flex_acl_hw_write_rule(flex_acl_db_flex_rule_t  *rule,
                                   flex_acl_db_acl_region_t *acl_region,
                                   acl_rule_hw_op_e          hw_op);
sx_status_t flex_acl_hw_write_rollback_move_rules(flex_acl_db_flex_rule_t  *rules,
                                                  uint32_t                  rules_num,
                                                  flex_acl_db_acl_region_t *acl_region,
                                                  uint32_t                  dev);
sx_status_t flex_acl_hw_rules_move_update_db(sx_api_acl_block_move_params_t *params,
                                             flex_acl_db_flex_rule_t        *rules_to_free,
                                             uint32_t                        rules_count,
                                             boolean_t                       change_priority);
sx_status_t flex_acl_hw_rules_move_upd_acl_drop_trap_db(sx_api_acl_block_move_params_t *params);

/* The function writes rules from db to registers without db update */
sx_status_t flex_acl_hw_write_only_rule(flex_acl_db_flex_rule_t  *rule,
                                        flex_acl_db_acl_region_t *region,
                                        uint32_t                  dev_id,
                                        boolean_t                 fill_kvd,
                                        boolean_t                 is_only_action_set,
                                        boolean_t                 is_overwrite);
sx_status_t flex_acl_hw_goto_action_update(flex_acl_db_flex_rule_t *rule_p, boolean_t rebind);
sx_status_t flex_acl_hw_set_key_blocks(sx_acl_key_block_e* key_blocks, uint32_t count, uint32_t* handle);
sx_status_t flex_acl_hw_get_key_blocks(uint32_t handle, sx_acl_key_block_e** key_blocks, uint32_t* count);
sx_status_t flex_acl_hw_remove_flex_key_entry(sx_acl_key_type_t key_handle);

sx_status_t flex_acl_hw_rule_move(sx_api_acl_block_move_params_t *params, uint32_t dev,
                                  flex_acl_db_acl_region_t *region, boolean_t change_priority);

sx_status_t flex_acl_hw_reg_write_group(flex_acl_bind_attribs_id_t new_bind_attribs_id,
                                        acl_id_group_entry_t      *acl_ids_prepared,
                                        uint32_t                   prepared_ids_num);
/* The function invalidates group that referenced by old_bind_attribs id */
sx_status_t flex_acl_hw_reg_invalidate_group(flex_acl_bind_attribs_id_t old_bind_attribs_id);

sx_status_t flex_acl_hw_reg_write_acls(flex_acl_db_acl_table_t *acl_table,
                                       boolean_t                valid);
sx_status_t flex_acl_hw_reg_write_acls_to_dev(flex_acl_db_acl_table_t *acl_table,
                                              sx_dev_id_t             *devs_list,
                                              uint16_t                 devs_count,
                                              boolean_t                valid);

sx_status_t flex_acl_hw_reg_write_region(flex_acl_db_acl_region_t * acl_region,
                                         sx_dev_id_t                dev_id,
                                         acl_region_op_e            op,
                                         uint8_t                  * tcam_region_info,
                                         uint32_t                   tcam_region_info_size,
                                         sx_acl_size_t              new_size,
                                         sx_acl_size_t            * allocated_size);
sx_status_t flex_acl_hw_reg_write_port(sx_port_log_id_t                  log_port,
                                       flex_acl_db_group_bind_attribs_t *bind_attribs,
                                       boolean_t                         bind,
                                       boolean_t                         write_to_reg);
sx_status_t flex_acl_hw_reg_write_vlan_group_add(sx_api_acl_vlan_group_set_params_t *params);
sx_status_t flex_acl_hw_reg_write_vlan_group_bind(sx_acl_vlan_group_t               vlan_group,
                                                  flex_acl_db_group_bind_attribs_t *bind_attribs,
                                                  uint8_t                           bind);
sx_status_t flex_acl_hw_reg_write_rif_bind(sx_rif_id_t                       rif,
                                           flex_acl_db_group_bind_attribs_t *bind_attribs,
                                           boolean_t                         bind);


sx_status_t flex_acl_hw_region_update(flex_acl_db_acl_region_t * acl_region,
                                      acl_region_op_e            op,
                                      sx_acl_size_t              new_size);

sx_status_t flex_acl_hw_should_unbind_acl(sx_acl_id_t acl_id, sx_acl_id_t group_id, boolean_t *unbind);
sx_status_t flex_acl_hw_should_unbind_acl_at_group_update(sx_acl_id_t acl_id, boolean_t *unbind);

sx_status_t flex_acl_hw_prepare_acl_list_from_groups(sx_acl_id_t           group_id,
                                                     acl_id_group_entry_t *acl_ids_prepared,
                                                     uint32_t             *prepared_ids_num,
                                                     sx_acl_direction_t    direction);
sx_status_t flex_acl_hw_prepare_acl_list_from_groups_update(sx_acl_id_t           group_id,
                                                            sx_acl_id_t          *acl_ids,
                                                            uint32_t              acl_ids_num,
                                                            acl_id_group_entry_t *acl_ids_prepared,
                                                            uint32_t             *prepared_ids_num,
                                                            sx_acl_direction_t    direction);
sx_status_t flex_acl_hw_update_acl_list_with_shadows(acl_id_group_entry_t *acl_ids,
                                                     uint32_t              acl_ids_num,
                                                     acl_id_group_entry_t *acl_ids_prepared,
                                                     uint32_t             *prepared_ids_num);

sx_status_t flex_acl_hw_region_hw_size_set(sx_acl_region_id_t region_id, sx_dev_id_t dev_id, sx_acl_size_t hw_size);
sx_status_t flex_acl_hw_region_update_bind(sx_acl_region_id_t region_id,
                                           sx_dev_id_t        dev_id,
                                           uint8_t          * tcam_region_info_arr,
                                           uint32_t           tcam_region_info_size);
sx_status_t flex_acl_hw_region_update_unbind(sx_acl_region_id_t region_id, sx_dev_id_t dev_id);

sx_status_t flex_acl_hw_region_attribs_set(sx_acl_region_id_t region_id, flex_acl_hw_db_region_attribs_t *attribs);
sx_status_t flex_acl_hw_region_attribs_remove(sx_acl_region_id_t               region_id,
                                              flex_acl_hw_db_region_attribs_t *rollback_attribs);
sx_status_t flex_acl_rm_entries_set(uint32_t                  new_cnt,
                                    uint32_t                  old_cnt,
                                    flex_acl_db_acl_region_t *region);
sx_status_t flex_acl_hw_free_action_sets(flex_acl_db_flex_rule_t *rule);

sx_status_t flex_acl_hw_copy_rule_ptr(flex_acl_db_flex_rule_t *rule);

sx_status_t flex_acl_hw_policer_block_relocate(sx_policer_id_t                handle,
                                               policer_manager_block_length_t size,
                                               policer_manager_index_t        old_index,
                                               policer_manager_index_t        new_index);

sx_status_t flex_acl_hw_cm_relocate(cm_logical_id_t lid,
                                    uint32_t        offset,
                                    cm_type_e       type,
                                    cm_hw_type_t    hw_type,
                                    cm_index_t      old_index,
                                    cm_index_t      new_index);

sx_status_t flex_acl_hw_span_relocate(sx_span_session_id_t     span_session_id,
                                      sx_span_session_id_int_t old_span_session_id_int,
                                      sx_span_session_id_int_t new_span_session_id_int);

sx_status_t flex_acl_hw_kvd_block_reloc(kvd_linear_manager_handle_t       handle,
                                        kvd_linear_manager_block_length_t size,
                                        kvd_linear_manager_block_length_t offset,
                                        const kvd_linear_manager_index_t *old_index,
                                        const kvd_linear_manager_index_t  new_index);

sx_status_t flex_acl_hw_kvd_pbs_block_reloc(kvd_linear_manager_handle_t       handle,
                                            kvd_linear_manager_block_length_t size,
                                            kvd_linear_manager_block_length_t offset,
                                            const kvd_linear_manager_index_t *old_index,
                                            const kvd_linear_manager_index_t  new_index);

sx_status_t flex_acl_hw_kvd_pbilm_block_reloc(kvd_linear_manager_handle_t       handle,
                                              kvd_linear_manager_block_length_t size,
                                              kvd_linear_manager_block_length_t offset,
                                              const kvd_linear_manager_index_t *old_index,
                                              const kvd_linear_manager_index_t  new_index);

sx_status_t flex_acl_hw_ftn_change(kvd_linear_manager_handle_t       mpls_adj_block_handle,
                                   kvd_linear_manager_index_t        mpls_adj_old_index,
                                   kvd_linear_manager_index_t        mpls_adj_new_index,
                                   hwi_ecmp_hw_block_handle_t        ecmp_block_handle,
                                   kvd_linear_manager_block_length_t old_ecmp_size,
                                   kvd_linear_manager_block_length_t new_ecmp_size);

sx_status_t flex_acl_hw_continue_lookup_change(kvd_linear_manager_handle_t handle,
                                               kvd_linear_manager_index_t  old_index,
                                               kvd_linear_manager_index_t  new_index);

sx_status_t flex_acl_hw_config_pbs(flex_acl_db_pbs_entry_t *pbs_entry, boolean_t is_vport);

sx_status_t flex_acl_hw_add_pbs(flex_acl_db_pbs_entry_t *pbs_entry, boolean_t is_vport);

sx_status_t flex_acl_hw_del_pbs(flex_acl_db_pbs_entry_t *pbs_entry);

sx_status_t flex_acl_hw_add_pbilm(flex_acl_db_pbilm_entry_t *pbilm_entry, boolean_t is_new);
sx_status_t flex_acl_hw_del_pbilm(flex_acl_db_pbilm_entry_t *pbilm_entry, boolean_t remove_kvdl);
sx_status_t flex_acl_hw_pbilm_update_nhfle_related_rules(sx_acl_pbilm_id_t                         pbilm_id,
                                                         flex_acl_hw_ecmp_container_change_data_t *container_change_data);

sx_status_t flex_acl_hw_free_third_parties(sx_acl_region_id_t region_id, sx_flex_acl_rule_offset_t offset);
sx_status_t flex_acl_hw_free_kvd(sx_acl_region_id_t region_id, sx_flex_acl_rule_offset_t offset);
sx_status_t flex_acl_hw_free_rule_kvd(flex_acl_db_flex_rule_t *rule);

sx_status_t flex_acl_hw_set_range_to_devs(sx_acl_port_range_entry_t* port_range,
                                          sx_acl_port_range_id_t id, sx_dev_id_t *devs_list,
                                          uint16_t dev_info_arr_size);
sx_status_t flex_acl_hw_get_all_devs_list(sx_dev_id_t *devs_list, uint16_t *dev_info_arr_size);
sx_status_t flex_acl_hw_set_range(sx_acl_range_entry_t  *range_entry_p,
                                  sx_acl_port_range_id_t id,
                                  sx_dev_id_t           *devs_list,
                                  uint16_t               dev_info_arr_size);

sx_status_t flex_acl_hw_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t flex_acl_hw_policy_engine_general_conf_device(sx_dev_id_t dev_id);

sx_status_t flex_acl_hw_change_pbs_action(flex_acl_rule_id_t      *rule_id_p,
                                          flex_acl_db_pbs_entry_t *pbs_entry,
                                          boolean_t                to_pbs_action);

sx_status_t flex_acl_hw_read_activity(flex_acl_db_acl_region_t *acl_region,
                                      sx_acl_rule_offset_t      offset,
                                      boolean_t                 is_clear,
                                      boolean_t                *value);

sx_status_t flex_acl_hw_dump_activity(flex_acl_db_acl_region_t *acl_region,
                                      sx_access_cmd_t           cmd,
                                      sx_acl_rule_offset_t      offset,
                                      uint32_t                  num_entries,
                                      bit_vector_t             *activities_p);

sx_status_t flex_acl_hw_trap_id_prio_change(adviser_event_e event_type, void *param);
sx_status_t flex_acl_hw_mc_tunnel_decap_change(adviser_event_e event_type, void *param);
sx_status_t flex_acl_hw_mc_container_change(adviser_event_e event_type, void *param);
sx_status_t flex_acl_hw_ecmp_container_change(hwi_ecmp_hw_block_handle_t ecmp_block_handle,
                                              sx_ecmp_container_type_e   container_type,
                                              uint32_t                   old_adjacency_index,
                                              uint32_t                   old_arlpgt_index,
                                              hwd_ecmp_block_size_t      old_ecmp_size,
                                              uint32_t                   new_adjacency_index,
                                              uint32_t                   new_arlpgt_index,
                                              hwd_ecmp_block_size_t      new_ecmp_size);
sx_status_t flex_acl_hw_init(flex_acl_attributes_t *attribs_p);
sx_status_t flex_acl_hw_deinit(void);

sx_status_t flex_acl_hw_handle_custom_bytes_register(acl_custom_bytes_set_id_e    custom_byte_set_id,
                                                     flex_acl_extraction_point_t *extraction_points_p,
                                                     uint32_t                     extraction_points_count,
                                                     boolean_t                    is_enable);

sx_status_t flex_acl_hw_action_details_get(sxd_flex_acl_action_type_t     sxd_flex_acl_action_type,
                                           flex_acl_hw_action_details_t** flex_acl_hw_action_details_pp);

sx_status_t flex_acl_hw_issu_bind_acl_trigger();
/**
 * Allocate KVD memory for all the regions' default actions. Called at system initialization.
 *
 * @return SX_STATUS_SUCCESS - initialization successful.
 */
sx_status_t flex_acl_hw_init_default_actions();
/**
 * De allocates KVD memory allocated to all the regions. Called at system initialization.
 *
 * @return SX_STATUS_SUCCESS - initialization successful.
 */
sx_status_t flex_acl_hw_deinit_default_actions();

/**
 * Sets in HW the retrieved from DB the first default action set for the specified region id.
 *
 * @param[in,out] rule              - Pointer to retrieved rule from DB
 * @param[in] region_id             - The region id on which we want to set default actions.
 * @param[in,out] hw_action_set     - Holds the HW action sets of the rule.
 * @param[in] next_action_kvd_idx_p - Pointer to KVD index of next action set or NULL if last set
 * @param[in] is_full_write         - Indication whether full activity write
 * @param[in] activity_clear        - Indicate if to clear activity for a new rule
 * @param[in] is_commit             - Indication whether ACL is commit
 * @param[in] add_ref               - Indication whether add new ref entry
 * @return SX_STATUS_SUCCESS        - setting the default action set for a region was successful.
 */
sx_status_t flex_acl_hw_write_first_default_action_set(flex_acl_db_flex_rule_t     *rule,
                                                       sx_acl_region_id_t           region_id,
                                                       flex_acl_hw_db_action_set_t *hw_action_set,
                                                       kvd_linear_manager_index_t  *next_action_kvd_idx_p,
                                                       boolean_t                    is_full_write,
                                                       boolean_t                    activity_clear,
                                                       boolean_t                    is_commit,
                                                       boolean_t                    add_ref);

/**
 * Sets in HW the NOP default action for the specified region id.
 *
 * NOTE: Currently only the SX_FLEX_ACL_ACTION_FORWARD (= NOP) is supported.
 *
 * @param[in] region_id     - The region id on which we want to set default action.
 * @param[in] action_list_p - pointer to array of actions to set as default. Currently only one action is supported.
 * @param[in] action_count  - Number of action in the array pointed by action_list_p. Currently only only one is supported..
 * @param[in] is_defer      - Indicate if the action should be is deferred.
 *
 * @return SX_STATUS_SUCCESS - setting the default action for a region was successful.
 */
sx_status_t flex_acl_hw_write_nop_default_action_set(sx_acl_region_id_t         region_id,
                                                     sx_flex_acl_flex_action_t *action_list_p,
                                                     uint32_t                   action_count,
                                                     boolean_t                  is_defer);

/**
 * Binds in hw the ACL group to be used for IPv4/IPv6 Multicast lookup.
 *
 * NOTE: Not supported for FLEX1. Should be called only from FLEX2.
 *
 * @param[in] cmd             - BIND/UNBIND/ADD.
 * @param[in] ip_version      - The IP version (v4/v6) for which we are setting the group.
 * @param[in] bind_attribs_id - The bind attributes id (ACL group id) that will handle the MC routing.
 *                              FLEX_ACL_INVALID_BIND_ATTRIBS_ID should be used to invalidate the binding.
 *
 * @return SX_STATUS_SUCCESS - Setting the bind attributes for the IP version was successful.
 */
sx_status_t flex_acl_hw_reg_write_mc_bind(sx_access_cmd_t            cmd,
                                          sx_ip_version_t            ip_version,
                                          flex_acl_bind_attribs_id_t bind_attribs_id);

/**
 * Bulk dump activity in hw.
 *
 * NOTE: Not supported for FLEX1. Should be called only from FLEX2.
 *
 * @param[in] region_id             - Region ID.
 * @param[in] clear                 - Clear the dumped activities.
 * @param[in] force_end             - Force end the dump session.
 * @param[in] index_arr             - KVD index array which are activity.
 * @param[in/out] index_num_p       - Number of KVD index.
 *
 * @return SX_STATUS_SUCCESS - Setting the bind attributes for the IP version was successful.
 */
sx_status_t flex_acl_hw_bulk_dump_activity(sx_acl_region_id_t          region_id,
                                           boolean_t                   clear,
                                           boolean_t                   force_end,
                                           kvd_linear_manager_index_t *index_arr,
                                           uint32_t                   *index_num_p);
/**
 * Set the acl register callbacks according to the flex stage.
 *
 * NOTE: This function is exposed for UT & debugging purposes only as it's called internally.
 *
 * @param[in] acl_stage      - The flex acl stage for which to set the default register callbacks.
 * @param[in] is_ut          - Indicate this initialization is for UT purposes.
 *
 * @return SX_STATUS_SUCCESS - Setting the default registers was successful.
 */
sx_status_t flex_acl_hw_set_default_register_cbs(acl_stage_e acl_stage, boolean_t is_ut);
sx_status_t flex_acl_get_hw_opt(sx_acl_region_id_t region_id,
                                uint32_t          *num_of_copies);
/**
 * Set the range between min-max_priority to min-max + priority_change
 *
 * @param[in] region -The region id on which we want to set the rules.
 * @param[in] min_priority - The min priority bound we want to set
 * @param[in] max_priority - The max priority bound we want to set
 * @param[in] priority_change - the change we ant to add to min and max priorities
 * @return
 */
sx_status_t flex_acl_hw_rule_prio_update(sx_acl_region_id_t          region_id,
                                         sx_flex_acl_rule_priority_t min_priority,
                                         sx_flex_acl_rule_priority_t max_priority,
                                         int32_t                     priority_change);

/**
 * For the specified register field select option returns the number of hw actions needed
 *
 * @param[in] field_select - The field we want to translate
 * @param[out] sxd_actions_count - The number of hw actions count
 * @return
 */
sx_status_t flex_acl_hw_field_select_count_get(sx_flex_acl_register_field_select_t field_select,
                                               uint32_t                           *sxd_actions_count);

/**
 * For the hash crc field returns the number of hw actions needed
 *
 * @param[in] field_select - The field we want to translate
 * @param[out] sxd_actions_count - The number of hw actions count
 * @return
 */
sx_status_t flex_acl_hw_hash_crc_count_get(sx_flex_acl_action_hash_crc_field_t field_select,
                                           uint32_t                           *sxd_actions_count);

sx_status_t flex_acl_hw_acl_drop_trap_usr_def_val_disable(flex_acl_rule_id_t rule_id);
sx_status_t flex_acl_hw_acl_drop_trap_usr_def_val_modify(flex_acl_rule_id_t rule_id,
                                                         boolean_t          monitor_en);
sx_status_t flex_acl_hw_acl_drop_trap_usr_def_val_del(flex_acl_rule_id_t rule_id);
sx_status_t flex_acl_hw_acl_drop_trap_usr_def_val_add(flex_acl_rule_id_t rule_id,
                                                      uint32_t          *ret_usr_def_val_p);
sx_status_t flex_acl_hw_acl_drop_trap_usr_def_val_get(flex_acl_rule_id_t rule_id,
                                                      uint32_t          *ret_usr_def_val_p);
sx_status_t flex_acl_hw_acl_drop_action_relocate(sx_acl_id_t acl_id,
                                                 boolean_t   old_state,
                                                 boolean_t   new_state);
sx_status_t flex_acl_hw_acl_drop_trap_action_iter_relocate(boolean_t old_state,
                                                           boolean_t new_state);
sx_status_t flex_acl_hw_rule_upd_is_acl_drop_trap_overwritten(flex_acl_db_flex_rule_t *old_rule_p,
                                                              flex_acl_db_flex_rule_t *new_rule_p,
                                                              boolean_t               *acl_drop_overwritten);
sx_status_t flex_acl_hw_key_generate(flex_acl_db_acl_region_t *acl_region_p,
                                     sx_flex_acl_key_desc_t   *keys,
                                     uint32_t                  keys_cnt,
                                     flex_acl_key_build_mode_e build_mode,
                                     uint8_t                   flex_value_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES],
                                     uint8_t                   flex_mask_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES]);
sx_status_t flex_acl_hw_key_extract(flex_acl_db_acl_region_t *acl_region_p,
                                    uint8_t                   flex_value_blocks[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES],
                                    sx_flex_acl_key_desc_t   *keys_p,
                                    uint32_t                 *keys_cnt_p);

sx_status_t flex_acl_hw_global_mask_set(flex_acl_db_acl_region_t *acl_region_p,
                                        uint8_t                   global_mask[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES]);
sx_status_t flex_acl_hw_lookup_region_id_set(flex_acl_db_acl_region_t *acl_region_p,
                                             const sx_acl_region_id_t  lookup_region_id);
sx_status_t flex_acl_hw_issu_bind_attributes_align(sx_issu_bank_e align_issu_bank, sx_issu_bank_e clear_issu_bank);

#endif /* ifndef FLEX_ACL_HW_H_ */
