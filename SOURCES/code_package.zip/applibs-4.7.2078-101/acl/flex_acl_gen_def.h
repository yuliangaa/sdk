/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

/* flex_acl_db_gen_def.h
 *    GENEREATED CODE created by machine. Do not change.
 */
#ifndef FLEX_ACL_GEN_DEF_H_
#define FLEX_ACL_GEN_DEF_H_

#include <sx/sdk/sx_flex_acl.h>
#ifdef GEN_DF_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/
#endif

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef enum sx_acl_key_block {
    FLEX_ACL_KEY_BLOCK_L2_DMAC_E                 = 0, /**<  */
    FLEX_ACL_KEY_BLOCK_L2_SMAC_E                 = 1, /**<  */
    FLEX_ACL_KEY_BLOCK_L2_SMAC_EX_E              = 2, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_E                    = 3, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_DIP_E                = 4, /**<  */
    FLEX_ACL_KEY_BLOCK_QOS_E                     = 5, /**<  */
    FLEX_ACL_KEY_BLOCK_RPF_E                     = 6, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_SIP_E                = 7, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_EX_E                 = 8, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_EX2_E                = 9, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_EX3_E                = 10, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_5TUPLE_E             = 11, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_12TUPLE_E            = 12, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_12TUPLE_EX_E         = 13, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_CUSTOM_E             = 14, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV4_CUSTOM_EX_E          = 15, /**<  */
    FLEX_ACL_KEY_BLOCK_INNER_IPV4_DIP_E          = 16, /**<  */
    FLEX_ACL_KEY_BLOCK_INNER_IPV4_5TUPLE_E       = 17, /**<  */
    FLEX_ACL_KEY_BLOCK_INNER_IPV4_12TUPLE_E      = 18, /**<  */
    FLEX_ACL_KEY_BLOCK_INNER_IPV4_12TUPLE_EX_E   = 19, /**<  */
    FLEX_ACL_KEY_BLOCK_ETHERNET_ETH_PAYLOAD0_E   = 20, /**<  */
    FLEX_ACL_KEY_BLOCK_CUSTOM_ETH_PAYLOAD1_E     = 21, /**<  */
    FLEX_ACL_KEY_BLOCK_ETHERTYPE_ETH_PAYLOAD2_E  = 22, /**<  */
    FLEX_ACL_KEY_BLOCK_ETHERTYPE_ETH_PAYLOAD3_E  = 23, /**<  */
    FLEX_ACL_KEY_BLOCK_VID_E                     = 24, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV6_DIP_E                = 25, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV6_DIP_EX_E             = 26, /**<  */
    FLEX_ACL_KEY_BLOCK_ROCE_E                    = 27, /**<  */
    FLEX_ACL_KEY_BLOCK_ROCE_EX_E                 = 28, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV6_SIP_E                = 29, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV6_SIP_EX_E             = 30, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV6_E                    = 31, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV6_EX1_E                = 32, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV6_EX2_E                = 33, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV6_EX3_E                = 34, /**<  */
    FLEX_ACL_KEY_BLOCK_IPV6_EX4_E                = 35, /**<  */
    FLEX_ACL_KEY_BLOCK_INNER_IPV6_E              = 36, /**<  */
    FLEX_ACL_KEY_BLOCK_INNER_IPV6_EX1_E          = 37, /**<  */
    FLEX_ACL_KEY_BLOCK_INNER_IPV6_EX2_E          = 38, /**<  */
    FLEX_ACL_KEY_BLOCK_INNER_IPV6_EX3_E          = 39, /**<  */
    FLEX_ACL_KEY_BLOCK_TUNNEL_E                  = 40, /**<  */
    FLEX_ACL_KEY_BLOCK_IPSEC_E                   = 41, /**<  */
    FLEX_ACL_KEY_BLOCK_MPLS_E                    = 42, /**<  */
    FLEX_ACL_KEY_BLOCK_MPLS_EX_E                 = 43, /**<  */
    FLEX_ACL_KEY_BLOCK_LOADBALANCING_EX_E        = 44, /**<  */
    FLEX_ACL_KEY_BLOCK_PACKETTYPE_E              = 45, /**<  */
    FLEX_ACL_KEY_BLOCK_RX_LIST_E                 = 46, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_0_E             = 47, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_1_E             = 48, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_2_E             = 49, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_3_E             = 50, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_4_E             = 51, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_5_E             = 52, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_5B_E            = 53, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_5C_E            = 54, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_6_E             = 55, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_6B_E            = 56, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_6C_E            = 57, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_7_E             = 58, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_8_E             = 59, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_8B_E            = 60, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_8C_E            = 61, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_9_E             = 62, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MAC_9B_E            = 63, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MAC_0_E       = 64, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MAC_1_E       = 65, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MAC_2_E       = 66, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MAC_3_E       = 67, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MAC_4_E       = 68, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IP_0_E              = 69, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_0_E            = 70, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_0_SYMM_E       = 71, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1_E            = 72, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1B_E           = 73, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1B_SYMM_E      = 74, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1C_E           = 75, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1C_SYMM_E      = 76, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1_OPT_E        = 77, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_2_E            = 78, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_3_E            = 79, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_4_E            = 80, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_4B_E           = 81, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_4C_E           = 82, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_5_E            = 83, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_5B_E           = 84, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_5C_E           = 85, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_6B_E           = 86, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_6C_E           = 87, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_0_E            = 88, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_0_SYMM_E       = 89, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_1_E            = 90, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_1_SYMM_E       = 91, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2_E            = 92, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2_SYMM_E       = 93, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2B_E           = 94, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2B_SYMM_E      = 95, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2C_E           = 96, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2C_SYMM_E      = 97, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_3_E            = 98, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_3_SYMM_E       = 99, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_4_E            = 100, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_4_SYMM_E       = 101, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_5_E            = 102, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_5_SYMM_E       = 103, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_6_E            = 104, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_0_E      = 105, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_0_SYMM_E = 106, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_1_E      = 107, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_1_SYMM_E = 108, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_2_E      = 109, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_0_E      = 110, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_0_SYMM_E = 111, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_1_E      = 112, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_1_SYMM_E = 113, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_2_E      = 114, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_2_SYMM_E = 115, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_3_E      = 116, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_3_SYMM_E = 117, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_4_E      = 118, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_4_SYMM_E = 119, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_5_E      = 120, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_5_SYMM_E = 121, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_6_E      = 122, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_0_E            = 123, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_1_E            = 124, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_1B_E           = 125, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_1C_E           = 126, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_2_E            = 127, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_2B_E           = 128, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_2C_E           = 129, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_3_E            = 130, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_3B_E           = 131, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_3C_E           = 132, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_4_E            = 133, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_5_E            = 134, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_6_E            = 135, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_0_E      = 136, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_1_E      = 137, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_2_E      = 138, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_3_E      = 139, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IB_0_E              = 140, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IB_1_E              = 141, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L3_0_E              = 142, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L3_1_E              = 143, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L3_2_E              = 144, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L3_3_E              = 145, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L3_4_E              = 146, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L3_5_E              = 147, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L4_0_E              = 148, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L4_0_OPT_E          = 149, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L4_0_SWAP_E         = 150, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L4_1_E              = 151, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L4_2_E              = 152, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_L4_3_E              = 153, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_IP_L4_0_E           = 154, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_L4_0_E        = 155, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_L4_1_E        = 156, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_INNER_L4_2_E        = 157, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_0_E       = 158, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_1_E       = 159, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_2_E       = 160, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_3_E       = 161, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_4_E       = 162, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_5_E       = 163, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_6_E       = 164, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_7_E       = 165, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_8_E       = 166, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_9_E       = 167, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_10_E      = 168, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_11_E      = 169, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_11B_E     = 170, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_12_E      = 171, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_13_E      = 172, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_14_E      = 173, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_15_E      = 174, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_15B_E     = 175, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_16_E      = 176, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_17_E      = 177, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_18_E      = 178, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_19_E      = 179, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_20_E      = 180, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_21_E      = 181, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_22_E      = 182, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_23_E      = 183, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_24_E      = 184, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_25_E      = 185, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_26_E      = 186, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_27_E      = 187, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_28_E      = 188, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_29_E      = 189, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_30_E      = 190, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_31_E      = 191, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_QOS_0_E             = 192, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_QOS_1_E             = 193, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_TUNNELS_0_E         = 194, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_TUNNELS_1_E         = 195, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_TUNNELS_2_E         = 196, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MISC_0_E            = 197, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MISC_0B_E           = 198, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MISC_1_E            = 199, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MISC_2_E            = 200, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MISC_2B_E           = 201, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MISC_2C_E           = 202, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MISC_3_E            = 203, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MISC_4_E            = 204, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MISC_4B_E           = 205, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_MISC_4C_E           = 206, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_STATEFUL_0_E        = 207, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_STATEFUL_0B_E       = 208, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_STATEFUL_0C_E       = 209, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_STATEFUL_1B_E       = 210, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_STATEFUL_1C_E       = 211, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_0_E          = 212, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_1_E          = 213, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_2_E          = 214, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_3_E          = 215, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_4_E          = 216, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_5_E          = 217, /**<  */
    FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_6_E          = 218, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_MAC_0_E            = 219, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_MAC_1_E            = 220, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_MAC_2_E            = 221, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_ETHERTYPE_0_E      = 222, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_VLAN_0_E           = 223, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_TUNNELS_0_E        = 224, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_MACSEC_0_E         = 225, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_MACSEC_1_E         = 226, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_MACSEC_2_E         = 227, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_MACSEC_3_E         = 228, /**<  */
    FLEX_ACL_KEY_BLOCK_MACSEC_MACSEC_4_E         = 229, /**<  */
    FLEX_ACL_KEY_BLOCK_LAST_E                    = 230,
} sx_acl_key_block_e;

typedef enum {
    FLEX_ACL_HW_KEY_INVALID_E                                     = 0,
    FLEX_ACL_HW_KEY_DIP_E                                         = 1, /**< size:32, IPV4 destination IP address */
    FLEX_ACL_HW_KEY_INNER_DIP_E                                   = 2, /**< size:32, IPV4 destination IP address tunnel */
    FLEX_ACL_HW_KEY_SIP_E                                         = 3, /**< size:32, IPV4 source IP address */
    FLEX_ACL_HW_KEY_INNER_SIP_E                                   = 4, /**< size:32, IPV4 source IP address tunnel */
    FLEX_ACL_HW_KEY_DIPV6_PART1_E                                 = 5, /**< size:32,  destination IP address */
    FLEX_ACL_HW_KEY_INNER_DIPV6_PART1_E                           = 6, /**< size:32, IPV4/IPV6 destination IP address tunnel */
    FLEX_ACL_HW_KEY_DIPV6_PART2_E                                 = 7, /**< size:32, IPV6 destination IP address */
    FLEX_ACL_HW_KEY_INNER_DIPV6_PART2_E                           = 8, /**< size:32, IPV4/IPV6 destination IP address tunnel */
    FLEX_ACL_HW_KEY_DIPV6_PART3_E                                 = 9, /**< size:32, IPV6 destination IP address */
    FLEX_ACL_HW_KEY_INNER_DIPV6_PART3_E                           = 10, /**< size:32, IPV6 destination IP address tunnel */
    FLEX_ACL_HW_KEY_DIPV6_PART4_E                                 = 11, /**< size:32, IPV6 destination IP address */
    FLEX_ACL_HW_KEY_INNER_DIPV6_PART4_E                           = 12, /**< size:32, IPV6 destination IP address tunnel */
    FLEX_ACL_HW_KEY_SIPV6_PART1_E                                 = 13, /**< size:32, IPV4/IPV6 source IP address */
    FLEX_ACL_HW_KEY_INNER_SIPV6_PART1_E                           = 14, /**< size:32, IPV4/IPV6 source IP address tunnel */
    FLEX_ACL_HW_KEY_SIPV6_PART2_E                                 = 15, /**< size:32, IPV6 source IP address */
    FLEX_ACL_HW_KEY_INNER_SIPV6_PART2_E                           = 16, /**< size:32, IPV6 source IP address tunnel */
    FLEX_ACL_HW_KEY_SIPV6_PART3_E                                 = 17, /**< size:32, IPV6 source IP address */
    FLEX_ACL_HW_KEY_INNER_SIPV6_PART3_E                           = 18, /**< size:32, IPV6 source IP address tunnel */
    FLEX_ACL_HW_KEY_SIPV6_PART4_E                                 = 19, /**< size:32, IPV6 source IP address */
    FLEX_ACL_HW_KEY_INNER_SIPV6_PART4_E                           = 20, /**< size:32, IPV6 source IP address tunnel */
    FLEX_ACL_HW_KEY_DSCP_E                                        = 21, /**< size:6, DSCP */
    FLEX_ACL_HW_KEY_DSCP_RANGE_E                                  = 22, /**< size:4, DSCP range */
    FLEX_ACL_HW_KEY_INNER_DSCP_E                                  = 23, /**< size:6, DSCP bit from inner UP header */
    FLEX_ACL_HW_KEY_RW_DSCP_E                                     = 24, /**< size:1,  -0 packet is transmitted with DSCP at end of control pipe 1 - DSCP gets encoded from QoS */
    FLEX_ACL_HW_KEY_ECN_E                                         = 25, /**< size:2, ECN */
    FLEX_ACL_HW_KEY_INNER_ECN_E                                   = 26, /**< size:2, ECN tunnel */
    FLEX_ACL_HW_KEY_IP_FRAGMENTED_E                               = 27, /**< size:1, When set the packet is fragmented. */
    FLEX_ACL_HW_KEY_IP_DONT_FRAGMENT_E                            = 28, /**< size:1, When set means that the packet should not be fragmented. */
    FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E                       = 29, /**< size:1, When set means that the segment is not first segment of fragmented packets. */
    FLEX_ACL_HW_KEY_IP_PACKET_LENGTH_E                            = 30, /**< size:16, IPV4/6 header length */
    FLEX_ACL_HW_KEY_IP_OK_E                                       = 31, /**< size:1, IPV4/6 header validation checked OK */
    FLEX_ACL_HW_KEY_INNER_IP_OK_E                                 = 32, /**< size:1, IPV4/6 header validation checked OK */
    FLEX_ACL_HW_KEY_IP_PROTO_E                                    = 33, /**< size:8, IPV6 header next protocol */
    FLEX_ACL_HW_KEY_INNER_IP_PROTO_E                              = 34, /**< size:8, IPV6 header next protocol - tunnel */
    FLEX_ACL_HW_KEY_IPV6_CUSTOM_EXTENSION_E                       = 35, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_IPV6_CUSTOM_EXTENSION_E                 = 36, /**< size:1, tunnel */
    FLEX_ACL_HW_KEY_IPV6_EXTENSION_EXISTS_E                       = 37, /**< size:1, Extension header exists */
    FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_EXISTS_E                 = 38, /**< size:1, Extension header exists - tunnel */
    FLEX_ACL_HW_KEY_INNER_IPV6_HBH_ROUTER_ALERT_OPTION_E          = 39, /**< size:1, tunnel */
    FLEX_ACL_HW_KEY_IPV6_HBH_EXTENSION_HEADER_E                   = 40, /**< size:1,  */
    FLEX_ACL_HW_KEY_IPV6_EXTENSION_E                              = 41, /**< size:6,  */
    FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_E                        = 42, /**< size:6,  */
    FLEX_ACL_HW_KEY_IS_ARP_E                                      = 43, /**< size:1, According to Ether type - does not include RARP. */
    FLEX_ACL_HW_KEY_IP_OPT_E                                      = 44, /**< size:1, Relevant for IPV4 */
    FLEX_ACL_HW_KEY_IS_IP_V4_E                                    = 45, /**< size:1, Relevant for IPV4    */
    FLEX_ACL_HW_KEY_L3_TYPE_E                                     = 46, /**< size:2, 1 - IPV4 */
    FLEX_ACL_HW_KEY_INNER_L3_TYPE_E                               = 47, /**< size:2, - */
    FLEX_ACL_HW_KEY_TTL_E                                         = 48, /**< size:8,  */
    FLEX_ACL_HW_KEY_INNER_TTL_E                                   = 49, /**< size:8, tunnel */
    FLEX_ACL_HW_KEY_TTL_OK_E                                      = 50, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_TTL_OK_E                                = 51, /**< size:1, tunnel */
    FLEX_ACL_HW_KEY_INNER_IPV6_HBH_CUSTOM_OPTION_E                = 52, /**< size:1, Configure another extension in CR space - tunnel */
    FLEX_ACL_HW_KEY_IS_TCP_OPTION_E                               = 53, /**< size:1,  */
    FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E                         = 54, /**< size:16,  */
    FLEX_ACL_HW_KEY_INNER_L4_DESTINATION_PORT_E                   = 55, /**< size:16, tunnel */
    FLEX_ACL_HW_KEY_L4_OK_E                                       = 56, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_L4_OK_E                                 = 57, /**< size:1,  */
    FLEX_ACL_HW_KEY_L4_PORT_RANGE_E                               = 58, /**< size:16,  */
    FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E                              = 59, /**< size:16,  */
    FLEX_ACL_HW_KEY_INNER_L4_SOURCE_PORT_E                        = 60, /**< size:16, tunnel */
    FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E                            = 61, /**< size:4, 1 - None */
    FLEX_ACL_HW_KEY_L4_TYPE_E                                     = 62, /**< size:4, Bit 0 - TCP */
    FLEX_ACL_HW_KEY_L4_TYPE_ENUM_E                                = 63, /**< size:2,  TCP */
    FLEX_ACL_HW_KEY_INNER_L4_TYPE_ENUM_E                          = 64, /**< size:2,  TCP - UDP */
    FLEX_ACL_HW_KEY_TCP_CONTROL_E                                 = 65, /**< size:6, All the TCP control bits from header */
    FLEX_ACL_HW_KEY_TCP_ECN_E                                     = 66, /**< size:3, TCP ECN bits */
    FLEX_ACL_HW_KEY_DMAC_E                                        = 67, /**< size:48, Destination MAC address */
    FLEX_ACL_HW_KEY_INNER_DMAC_E                                  = 68, /**< size:48, Destination MAC address tunnel */
    FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E                                = 69, /**< size:2, 0 */
    FLEX_ACL_HW_KEY_ETHERTYPE_E                                   = 70, /**< size:16,  */
    FLEX_ACL_HW_KEY_INNER_ETHERTYPE_E                             = 71, /**< size:16, tunnel */
    FLEX_ACL_HW_KEY_ETHERTYPE_VECTOR_E                            = 72, /**< size:8, [0] - IPV44 */
    FLEX_ACL_HW_KEY_RW_PCP_E                                      = 73, /**< size:1, 0 - The packet gets transmitted with VLAN.PCP and VLAN.DEI */
    FLEX_ACL_HW_KEY_SMAC_E                                        = 74, /**< size:48, Source MAC address */
    FLEX_ACL_HW_KEY_INNER_SMAC_E                                  = 75, /**< size:48, Source MAC address */
    FLEX_ACL_HW_KEY_DEI_E                                         = 76, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_DEI_E                                   = 77, /**< size:1, tunnel */
    FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E                             = 78, /**< size:2, 00 -Ethertype 0 */
    FLEX_ACL_HW_KEY_PCP_E                                         = 79, /**< size:3,  */
    FLEX_ACL_HW_KEY_INNER_PCP_E                                   = 80, /**< size:3,  */
    FLEX_ACL_HW_KEY_VLAN_TAGGED_E                                 = 81, /**< size:1, Indicates whether the packet enter the chip with or without VLAN tag */
    FLEX_ACL_HW_KEY_VLAN_VALID_E                                  = 82, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_VLAN_VALID_E                            = 83, /**< size:1, tunnel */
    FLEX_ACL_HW_KEY_VLAN_ID_E                                     = 84, /**< size:12,  */
    FLEX_ACL_HW_KEY_VLAN_ID_11_4_E                                = 85, /**< size:8, bits 4 - 11 in the vlan id field */
    FLEX_ACL_HW_KEY_INNER_VLAN_ETHER_TYPE_E                       = 86, /**< size:2, 00 -Ethertype 0 */
    FLEX_ACL_HW_KEY_INNER_VLAN_ID_E                               = 87, /**< size:12,  */
    FLEX_ACL_HW_KEY_SMPE_E                                        = 88, /**< size:14,  SMPE or VLAN_ID */
    FLEX_ACL_HW_KEY_SMPE_VALID_E                                  = 89, /**< size:1, Indicates whether tag0 is using MC_ID or VLAN_ID */
    FLEX_ACL_HW_KEY_RW_EXP_E                                      = 90, /**< size:1, Indicates whether the packet is transmitted with the same EXP or it gets encoded */
    FLEX_ACL_HW_KEY_EXP_E                                         = 91, /**< size:3,  */
    FLEX_ACL_HW_KEY_IS_MPLS_E                                     = 92, /**< size:1,  */
    FLEX_ACL_HW_KEY_BOS_E                                         = 93, /**< size:1,  */
    FLEX_ACL_HW_KEY_LABEL_ID_0_E                                  = 94, /**< size:20, Outermost label in MPLS label stack */
    FLEX_ACL_HW_KEY_LABEL_ID_1_E                                  = 95, /**< size:20,  */
    FLEX_ACL_HW_KEY_LABEL_ID_2_19_10_E                            = 96, /**< size:10, label id 2 [19:10] */
    FLEX_ACL_HW_KEY_LABEL_ID_2_9_0_E                              = 97, /**< size:10, label id 2 [9:0] */
    FLEX_ACL_HW_KEY_LABEL_ID_2_E                                  = 98, /**< size:20,  */
    FLEX_ACL_HW_KEY_LABEL_ID_3_E                                  = 99, /**< size:20,  */
    FLEX_ACL_HW_KEY_LABEL_ID_4_E                                  = 100, /**< size:20,  */
    FLEX_ACL_HW_KEY_LABEL_ID_5_E                                  = 101, /**< size:20, Innermost label in MPLS label stack */
    FLEX_ACL_HW_KEY_MPLS_ECN_E                                    = 102, /**< size:2, Result of decoding the EXP into ECN */
    FLEX_ACL_HW_KEY_MPLS_LABELS_VALID_E                           = 103, /**< size:6, bit vector for the validity of the labels. */
    FLEX_ACL_HW_KEY_PHP_E                                         = 104, /**< size:1,  */
    FLEX_ACL_HW_KEY_MPLS_TTL_E                                    = 105, /**< size:8, Outermost TTL. */
    FLEX_ACL_HW_KEY_DEST_QP_E                                     = 106, /**< size:24,  */
    FLEX_ACL_HW_KEY_PKEY_E                                        = 107, /**< size:16, Partition key */
    FLEX_ACL_HW_KEY_BTH_OPCODE_E                                  = 108, /**< size:8, IB Packet type */
    FLEX_ACL_HW_KEY_COLOR_E                                       = 109, /**< size:2, Internal color/drop precedence of the packet of the packet */
    FLEX_ACL_HW_KEY_DST_PORT_E                                    = 110, /**< size:16, System destination port */
    FLEX_ACL_HW_KEY_ECMP_HASH_E                                   = 111, /**< size:12, Used when ECMP hash value is used as key. */
    FLEX_ACL_HW_KEY_ERIF_E                                        = 112, /**< size:13, Egress router interface */
    FLEX_ACL_HW_KEY_IRIF_E                                        = 113, /**< size:13, Ingress router interface */
    FLEX_ACL_HW_KEY_SWITCH_PRIO_E                                 = 114, /**< size:4, Key of QOS indicator */
    FLEX_ACL_HW_KEY_SRC_PORT_E                                    = 115, /**< size:32, System source port or LAG */
    FLEX_ACL_HW_KEY_DMAC_IS_UC_E                                  = 116, /**< size:1,  0 - MC 1 - UC */
    FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_E                              = 117, /**< size:8,  */
    FLEX_ACL_HW_KEY_USER_TOKEN_E                                  = 118, /**< size:16, USed for meta data passing between ACLs */
    FLEX_ACL_HW_KEY_DWORD_VALID_0_E                               = 119, /**< size:1, Number of valid DWORDs that the parser was able to take from the packets into payload bits. */
    FLEX_ACL_HW_KEY_DWORD_VALID_1_E                               = 120, /**< size:1, Number of valid DWORDs that the parser was able to take from the packets into payload bits. */
    FLEX_ACL_HW_KEY_DWORD_VALID_2_E                               = 121, /**< size:1, Number of valid DWORDs that the parser was able to take from the packets into payload bits. */
    FLEX_ACL_HW_KEY_DWORD_VALID_3_E                               = 122, /**< size:1, Number of valid DWORDs that the parser was able to take from the packets into payload bits. */
    FLEX_ACL_HW_KEY_DWORD_VALID_4_E                               = 123, /**< size:1, Number of valid DWORDs that the parser was able to take from the packets into payload bits. */
    FLEX_ACL_HW_KEY_DWORD_VALID_5_E                               = 124, /**< size:1, Number of valid DWORDs that the parser was able to take from the packets into payload bits. */
    FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_191_160_E                    = 125, /**< size:32, bytes 0,1 are unknown ethertype and two bytes after unknown Ethertype */
    FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_159_128_E                    = 126, /**< size:32, bytes 2-5 after unknown Ethertype */
    FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_127_120_E                    = 127, /**< size:8, byte 6  after unknown Ethertype */
    FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_119_96_E                     = 128, /**< size:24, bytes 7,8,9 after unknown Ethertype */
    FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_95_80_E                      = 129, /**< size:16, bytes 10,11 after unknown Ethertype */
    FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_79_64_E                      = 130, /**< size:16,  bytes 12,13 after unknown Ethertype */
    FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_63_40_E                      = 131, /**< size:24, bytes 14,15,16 after unknown Ethertype */
    FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_39_32_E                      = 132, /**< size:8, byte 17 after unknown Ethertype */
    FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_31_0_E                       = 133, /**< size:32, bytes 18-21 after unknown Ethertype */
    FLEX_ACL_HW_KEY_DISCARD_STATE_E                               = 134, /**< size:2,  Discard state on the packet header. */
    FLEX_ACL_HW_KEY_BUFF_E                                        = 135, /**< size:4, The priority group of the packet as classified when entered/enqueued the chip */
    FLEX_ACL_HW_KEY_TX_LIST_E                                     = 136, /**< size:72,  TX Port list */
    FLEX_ACL_HW_KEY_TRAP_PRIO_E                                   = 137, /**< size:3,  Trap priority from the header */
    FLEX_ACL_HW_KEY_IS_TRAPPED_E                                  = 138, /**< size:1,  1..6 - the packet is going to trap 0 and 7 - don't trap */
    FLEX_ACL_HW_KEY_TUNNEL_TYPE_E                                 = 139, /**< size:3,  0 - NVGRE 1 - VXLAN/GENEVE/GRE 2 - MPLS 3 - IPinIP 4 - GRE 5 -None */
    FLEX_ACL_HW_KEY_VNI_E                                         = 140, /**< size:24,  */
    FLEX_ACL_HW_KEY_GRE_KEY_E                                     = 141, /**< size:32,  */
    FLEX_ACL_HW_KEY_NVE_TYPE_VECTOR_E                             = 142, /**< size:4,  0 - VXLAN 1 - GENEVE 2 - GRE 3 - NVGRE */
    FLEX_ACL_HW_KEY_GRE_PROTOCOL_E                                = 143, /**< size:16,  */
    FLEX_ACL_HW_KEY_GRE_KEY_EXIST_E                               = 144, /**< size:1,  */
    FLEX_ACL_HW_KEY_SPI_E                                         = 145, /**< size:32,  Security parameters index. */
    FLEX_ACL_HW_KEY_RX_LIST_E                                     = 146, /**< size:72,  */
    FLEX_ACL_HW_KEY_HAS_CONFIGURE_ETHERTYPE_E                     = 147, /**< size:1,  */
    FLEX_ACL_HW_KEY_IS_ROUTED_E                                   = 148, /**< size:1, Packet is Routed */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E                               = 149, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E                               = 150, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E                               = 151, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E                               = 152, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E                               = 153, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E                               = 154, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E                               = 155, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E                               = 156, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E                               = 157, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E                               = 158, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E                              = 159, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E                              = 160, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E                              = 161, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E                              = 162, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E                              = 163, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E                              = 164, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E                         = 165, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E                         = 166, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E                         = 167, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E                         = 168, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E                         = 169, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E                         = 170, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E                         = 171, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E                         = 172, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E                         = 173, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E                         = 174, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E                        = 175, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E                        = 176, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E                        = 177, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E                        = 178, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E                        = 179, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E                        = 180, /**< size:1,  */
    FLEX_ACL_HW_KEY_DMAC_31_0_E                                   = 181, /**< size:32,  DMAC [31:0] */
    FLEX_ACL_HW_KEY_DMAC_47_32_E                                  = 182, /**< size:16,  DMAC [47:32] */
    FLEX_ACL_HW_KEY_SMAC_31_0_E                                   = 183, /**< size:32,  SMAC [31:0] */
    FLEX_ACL_HW_KEY_SMAC_47_32_E                                  = 184, /**< size:16,  SMAC [47:32] */
    FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E                              = 185, /**< size:1,  Packet has a valid L2 */
    FLEX_ACL_HW_KEY_FDB_MISS_E                                    = 186, /**< size:1,  FDB miss or hit */
    FLEX_ACL_HW_KEY_LLC_VALID_E                                   = 187, /**< size:1,  Packet has a valid LLC header */
    FLEX_ACL_HW_KEY_RX_SYS_PORT_E                                 = 188, /**< size:16,  RX ACL system port (including lag bit) */
    FLEX_ACL_HW_KEY_TX_SYS_PORT_E                                 = 189, /**< size:9,  TX ACL system port */
    FLEX_ACL_HW_KEY_RX_SYS_PORT_PHYSICAL_E                        = 190, /**< size:9,  RX ACL system port physical */
    FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E                         = 191, /**< size:4,  Received port list for Tunnel ports */
    FLEX_ACL_HW_KEY_TUNNEL_VLAN_ETHERTYPE_E                       = 192, /**< size:2,  Tunnel VLAN Ethertype */
    FLEX_ACL_HW_KEY_TUNNEL_INNER_VLAN_ETHERTYPE_E                 = 193, /**< size:2,  Tunnel inner VLAN Ethertype */
    FLEX_ACL_HW_KEY_INNER_DMAC_VALID_E                            = 194, /**< size:1,  Inner MAC valid */
    FLEX_ACL_HW_KEY_TAG_VALID_E                                   = 195, /**< size:1,  TAG valid */
    FLEX_ACL_HW_KEY_INNER_TAG_VALID_E                             = 196, /**< size:1,  Inner tag valid */
    FLEX_ACL_HW_KEY_TUNNEL_TAG_VALID_E                            = 197, /**< size:1,  Tunnel tag valid */
    FLEX_ACL_HW_KEY_TUNNEL_INNER_TAG_VALID_E                      = 198, /**< size:1,  Tunnel inner tag valid */
    FLEX_ACL_HW_KEY_INNER_DMAC_31_0_E                             = 199, /**< size:32,  Inner DMAC [31:0] */
    FLEX_ACL_HW_KEY_INNER_DMAC_47_32_E                            = 200, /**< size:16,  Inner DMAC [47:32] */
    FLEX_ACL_HW_KEY_INNER_SMAC_31_0_E                             = 201, /**< size:32,  Inner SMAC [31:0] */
    FLEX_ACL_HW_KEY_INNER_SMAC_47_32_E                            = 202, /**< size:16,  Inner SMAC [47:32] */
    FLEX_ACL_HW_KEY_TUNNEL_INNER_PCP_E                            = 203, /**< size:3,  Tunnel inner PCP */
    FLEX_ACL_HW_KEY_TUNNEL_INNER_DEI_E                            = 204, /**< size:1,  Tunnel inner DEI */
    FLEX_ACL_HW_KEY_TUNNEL_PCP_E                                  = 205, /**< size:3,  Tunnel PCP */
    FLEX_ACL_HW_KEY_TUNNEL_DEI_E                                  = 206, /**< size:1,  Tunnel DEI */
    FLEX_ACL_HW_KEY_TUNNEL_VLAN_ID_E                              = 207, /**< size:12,  Tunnel VLAN ID */
    FLEX_ACL_HW_KEY_TUNNEL_INNER_VLAN_ID_E                        = 208, /**< size:12,  Tunnel inner VLAN ID */
    FLEX_ACL_HW_KEY_IP_MORE_FRAGMENT_E                            = 209, /**< size:1,  Set when the more fragment bit is set */
    FLEX_ACL_HW_KEY_L3_TYPE_EXT_E                                 = 210, /**< size:3, 1 - IPV4/IPV6/GRH/FC/ARP/RAW */
    FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E                           = 211, /**< size:1,  Tunnel DEI */
    FLEX_ACL_HW_KEY_URPF_FAIL_E                                   = 212, /**< size:1,  Tunnel DEI */
    FLEX_ACL_HW_KEY_INNER_IP_OPT_E                                = 213, /**< size:1,  Inner IPv4 Options exists */
    FLEX_ACL_HW_KEY_INNER_L3_TYPE_EXT_E                           = 214, /**< size:3, 1 - IPV4/IPV6/GRH/FC/ARP/RAW */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_16_E                        = 215, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_17_E                        = 216, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_18_E                        = 217, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_19_E                        = 218, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E                              = 219, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E                              = 220, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E                              = 221, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E                              = 222, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_20_E                        = 223, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_21_E                        = 224, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_22_E                        = 225, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_23_E                        = 226, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_20_E                              = 227, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_21_E                              = 228, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_22_E                              = 229, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E                              = 230, /**< size:8,  */
    FLEX_ACL_HW_KEY_ALU_CARRY_FLAG_E                              = 231, /**< size:1,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_0_OFFSET_E                   = 232, /**< size:8,  */
    FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_1_OFFSET_E                   = 233, /**< size:8,  */
    FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E                          = 234, /**< size:4,  */
    FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E                          = 235, /**< size:4,  */
    FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E                         = 236, /**< size:3,  */
    FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_11_E                           = 237, /**< size:1,  */
    FLEX_ACL_HW_KEY_RX_LIST_HW_31_0_E                             = 238, /**< size:32,  RX LIST bits 31-0 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_63_32_E                            = 239, /**< size:32,  RX LIST bits 63-32 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_95_64_E                            = 240, /**< size:32,  RX LIST bits 95-64 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_127_96_E                           = 241, /**< size:32,  RX LIST bits 127-96 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_159_128_E                          = 242, /**< size:32,  RX LIST bits 159-128 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_191_160_E                          = 243, /**< size:32,  RX LIST bits 191-160 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_223_192_E                          = 244, /**< size:32,  RX LIST bits 223-192 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_255_224_E                          = 245, /**< size:32,  RX LIST bits 255-224 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_257_256_E                          = 246, /**< size:32,  RX LIST bits 257-256 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_287_256_E                          = 247, /**< size:32,  RX LIST bits 287-256 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_319_288_E                          = 248, /**< size:32,  RX LIST bits 319-288 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_351_320_E                          = 249, /**< size:32,  RX LIST bits 351-320 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_383_352_E                          = 250, /**< size:32,  RX LIST bits 383-352 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_415_384_E                          = 251, /**< size:32,  RX LIST bits 415-384 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_447_416_E                          = 252, /**< size:32,  RX LIST bits 447-416 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_479_448_E                          = 253, /**< size:32,  RX LIST bits 479-448 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_511_480_E                          = 254, /**< size:32,  RX LIST bits 511-480 */
    FLEX_ACL_HW_KEY_RX_LIST_HW_515_512_E                          = 255, /**< size:32,  RX LIST bits 515-512 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_31_0_E                             = 256, /**< size:32,  TX LIST bits 31-0 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_63_32_E                            = 257, /**< size:32, TX LIST bits 63-32 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_95_64_E                            = 258, /**< size:32,  TX LIST bits 95-64 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_127_96_E                           = 259, /**< size:32,  TX LIST bits 127-96 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_159_128_E                          = 260, /**< size:32,  TX LIST bits 159-128 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_191_160_E                          = 261, /**< size:32,  TX LIST bits 191-160 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_223_192_E                          = 262, /**< size:32,  TX LIST bits 223-192 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_255_224_E                          = 263, /**< size:32,  TX LIST bits 255-224 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_257_256_E                          = 264, /**< size:32,  TX LIST bits 257-256 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_287_256_E                          = 265, /**< size:32,  TX LIST bits 287-256 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_319_288_E                          = 266, /**< size:32,  TX LIST bits 319-288 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_351_320_E                          = 267, /**< size:32,  TX LIST bits 351-320 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_383_352_E                          = 268, /**< size:32,  TX LIST bits 383-352 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_415_384_E                          = 269, /**< size:32,  TX LIST bits 415-384 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_447_416_E                          = 270, /**< size:32,  TX LIST bits 447-416 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_479_448_E                          = 271, /**< size:32,  TX LIST bits 479-448 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_511_480_E                          = 272, /**< size:32,  TX LIST bits 511-480 */
    FLEX_ACL_HW_KEY_TX_LIST_HW_515_512_E                          = 273, /**< size:32,  TX LIST bits 515-512 */
    FLEX_ACL_HW_KEY_INNER_EXP_E                                   = 274, /**< size:3,  */
    FLEX_ACL_HW_KEY_INNER_IS_MPLS_E                               = 275, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_MPLS_ECN_E                              = 276, /**< size:2, Result of decoding the EXP into ECN */
    FLEX_ACL_HW_KEY_IRIF_3_0_E                                    = 277, /**< size:8, Ingress router interface */
    FLEX_ACL_HW_KEY_IRIF_7_4_E                                    = 278, /**< size:8, Ingress router interface */
    FLEX_ACL_HW_KEY_IRIF_11_8_E                                   = 279, /**< size:8, Ingress router interface */
    FLEX_ACL_HW_KEY_IRIF_12_E                                     = 280, /**< size:8, Ingress router interface */
    FLEX_ACL_HW_KEY_RX_CPU_E                                      = 281, /**< size:1, Packet is from CPU */
    FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_E                           = 282, /**< size:32,  MPLS control word */
    FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_VALID_E                     = 283, /**< size:1,  qualifier for MPLS control word */
    FLEX_ACL_HW_KEY_FID_E                                         = 284, /**< size:14, Flow ID */
    FLEX_ACL_HW_KEY_MC_TYPE_VECTOR_E                              = 285, /**< size:8, Multicast type vector */
    FLEX_ACL_HW_KEY_INNER_IS_IPV4_E                               = 286, /**< size:1, Inner is IPV4 */
    FLEX_ACL_HW_KEY_INNER_IP_PACKET_LENGTH_E                      = 287, /**< size:16, Inner IPV4/6 header length */
    FLEX_ACL_HW_KEY_DIP_REVERSED_E                                = 288, /**< size:32, Destination IP address reversed */
    FLEX_ACL_HW_KEY_IPV6_EXTENSION_SHIM6_E                        = 289, /**< size:1, IPV6 Extension shim6 */
    FLEX_ACL_HW_KEY_IPV6_HBH_CUSTOM_OPTION_E                      = 290, /**< size:1, IPV6 Hop-by-hop custom option */
    FLEX_ACL_HW_KEY_IPV6_HBH_ROUTER_ALERT_OPTION_E                = 291, /**< size:1, IPV6 Hop-by-hop router alert option */
    FLEX_ACL_HW_KEY_IPV6_ND_TARGET_VALID_E                        = 292, /**< size:1, IPV6 Neighbor discovery target valid */
    FLEX_ACL_HW_KEY_ND_SLL_OR_TLL_VALID_E                         = 293, /**< size:2, Neighbor discovery SLL/TLL Valid */
    FLEX_ACL_HW_KEY_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E       = 294, /**< size:1, IPV6 extension host identify protocol */
    FLEX_ACL_HW_KEY_INNER_IP_DONT_FRAGMENT_E                      = 295, /**< size:1, When set means that the inner packet should not be fragmented */
    FLEX_ACL_HW_KEY_INNER_IP_MORE_FRAGMENT_E                      = 296, /**< size:1,  Set when the more fragment bit is set in inner packet */
    FLEX_ACL_HW_KEY_INNER_IP_FRAGMENTED_E                         = 297, /**< size:1, When set the inner packet is fragmented */
    FLEX_ACL_HW_KEY_INNER_IP_FRAGMENT_NOT_FIRST_E                 = 298, /**< size:1, When set means that the segment is not first segment of fragmented packets. */
    FLEX_ACL_HW_KEY_INNER_IPV6_ROUTING_EXTENSION_E                = 299, /**< size:1,  Inner IPV6 routing extension */
    FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E             = 300, /**< size:1, Inner IPV6 hop-by-hop extension header */
    FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_SHIM6_E                  = 301, /**< size:1, Inner IPV6 Extension shim6 */
    FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E = 302, /**< size:1, Inner IPV6 extension host identify protocol */
    FLEX_ACL_HW_KEY_INNER_BOS_E                                   = 303, /**< size:1, 1 */
    FLEX_ACL_HW_KEY_INNER_LABEL_ID_0_E                            = 304, /**< size:20, Outermost label in  inner MPLS label stack */
    FLEX_ACL_HW_KEY_INNER_MPLS_TTL_E                              = 305, /**< size:8, Outermost TTL in inner MPLS label stack */
    FLEX_ACL_HW_KEY_INNER_MPLS_LABELS_VALID_E                     = 306, /**< size:6, bit vector for the validity of the inner MPLS label stack . */
    FLEX_ACL_HW_KEY_INNER_LABEL_ID_1_E                            = 307, /**< size:20,  */
    FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_VALID_E               = 308, /**< size:1,  qualifier for inner MPLS control word */
    FLEX_ACL_HW_KEY_INNER_LABEL_ID_2_E                            = 309, /**< size:20,  */
    FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_E                     = 310, /**< size:32,  Inner MPLS control word */
    FLEX_ACL_HW_KEY_OR_TCP_CONTROL_OR_ECN_E                       = 311, /**< size:2,  */
    FLEX_ACL_HW_KEY_INNER_L4_TYPE_EXTENDED_E                      = 312, /**< size:4, 1 */
    FLEX_ACL_HW_KEY_INNER_TCP_CONTROL_E                           = 313, /**< size:6, All the inner TCP control bits from header */
    FLEX_ACL_HW_KEY_INNER_TCP_ECN_E                               = 314, /**< size:3, Inner TCP ECN bits */
    FLEX_ACL_HW_KEY_INNER_IS_TCP_OPTION_E                         = 315, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_SPI_E                                   = 316, /**< size:32, Inner security parameters index. */
    FLEX_ACL_HW_KEY_SYMMETRIC_HASH_MAC_E                          = 317, /**< size:1,  Symmetric hash mac */
    FLEX_ACL_HW_KEY_SYMMETRIC_HASH_L4_PORTS_E                     = 318, /**< size:1,  Symmetric hash L4 ports */
    FLEX_ACL_HW_KEY_SYMMETRIC_HASH_IP_E                           = 319, /**< size:1,  Symmetric hash IP */
    FLEX_ACL_HW_KEY_LAG_HASH_E                                    = 320, /**< size:12, LAG Hash */
    FLEX_ACL_HW_KEY_FREE_RUNNIG_CLOCK_MSB_E                       = 321, /**< size:16,  */
    FLEX_ACL_HW_KEY_TRAP_ID_E                                     = 322, /**< size:10,  */
    FLEX_ACL_HW_KEY_POLICER_STATE_E                               = 323, /**< size:12,  */
    FLEX_ACL_HW_KEY_PORT_USER_MEM_E                               = 324, /**< size:8,  */
    FLEX_ACL_HW_KEY_FPP0_TOUCHED_E                                = 325, /**< size:1,  */
    FLEX_ACL_HW_KEY_FPP1_TOUCHED_E                                = 326, /**< size:1,  */
    FLEX_ACL_HW_KEY_FPP2_TOUCHED_E                                = 327, /**< size:1,  */
    FLEX_ACL_HW_KEY_FPP3_TOUCHED_E                                = 328, /**< size:1,  */
    FLEX_ACL_HW_KEY_FPP4_TOUCHED_E                                = 329, /**< size:1,  */
    FLEX_ACL_HW_KEY_FPP5_TOUCHED_E                                = 330, /**< size:1,  */
    FLEX_ACL_HW_KEY_FPP6_TOUCHED_E                                = 331, /**< size:1,  */
    FLEX_ACL_HW_KEY_FPP7_TOUCHED_E                                = 332, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_FPP0_TOUCHED_E                          = 333, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_FPP1_TOUCHED_E                          = 334, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_FPP2_TOUCHED_E                          = 335, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_FPP3_TOUCHED_E                          = 336, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_FPP4_TOUCHED_E                          = 337, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_FPP5_TOUCHED_E                          = 338, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_FPP6_TOUCHED_E                          = 339, /**< size:1,  */
    FLEX_ACL_HW_KEY_INNER_FPP7_TOUCHED_E                          = 340, /**< size:1,  */
    FLEX_ACL_HW_KEY_IS_ELEPHANT_E                                 = 341, /**< size:1, Packet is elephant. */
    FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E                             = 342, /**< size:2, AR packet classification */
    FLEX_ACL_HW_KEY_IS_ARN_E                                      = 343, /**< size:1, Is ARN */
    FLEX_ACL_HW_KEY_MACSEC_SECTAG_VALID_E                         = 344, /**< size:1, MACSEC SECTAG valid */
    FLEX_ACL_HW_KEY_MACSEC_SECTAG_ES_E                            = 345, /**< size:1, MACSEC SECTAG ES. */
    FLEX_ACL_HW_KEY_MACSEC_SECTAG_SC_E                            = 346, /**< size:1, MACSEC SECTAG SC. */
    FLEX_ACL_HW_KEY_MACSEC_SECTAG_SHORT_LEN_ZERO_E                = 347, /**< size:1, MACSEC SECTAG short len zero. */
    FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_0_31_E                      = 348, /**< size:32, MACSEC SECTAG SCI 0..31. */
    FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_32_63_E                     = 349, /**< size:32, MACSEC SECTAG SCI 32..63. */
    FLEX_ACL_HW_KEY_MACSEC_SECTAG_AN_E                            = 350, /**< size:2, MACSEC SECTAG AN. */
    FLEX_ACL_HW_KEY_MACSEC_SECTAG_SHORT_LEN_E                     = 351, /**< size:8, MACSEC SECTAG SCI 0..31. */
    FLEX_ACL_HW_KEY_MACSEC_SECY_VALID_E                           = 352, /**< size:1, MACSEC SECY valid */
    FLEX_ACL_HW_KEY_MACSEC_SECY_E                                 = 353, /**< size:16, MACSEC SECY */
    FLEX_ACL_HW_KEY_MACSEC_GRE_KEY_0_7_E                          = 354, /**< size:8, MACSEC GRE key bits 0..7 */
    FLEX_ACL_HW_KEY_MACSEC_VNI_GRE_KEY_8_31_E                     = 355, /**< size:24, MACSEC GRE key bits 8..31 */
    FLEX_ACL_HW_KEY_MACSEC_VXLAN_GPE_NEXT_PROTO_E                 = 356, /**< size:8, MACSEC VxLAN next proto */
    FLEX_ACL_HW_KEY_LAST_E                                        = 357,
} sx_acl_hw_key_e;

typedef struct {
    uint8_t   size;
    uint8_t   bit_size;
    uint8_t   flags;
    boolean_t is_endianism;
} flex_acl_key_data_t;

typedef struct {
    sx_acl_hw_key_e key_id;
    uint32_t        block_offset;
    uint32_t        len;
    uint32_t        basic_key_offset;
} flex_acl_key_block_item_t;

typedef struct {
    uint8_t                    key_block_code;
    boolean_t                  is_enabled;
    uint32_t                   hw_key_stages;
    uint32_t                   symmetric_bitmask;
    uint32_t                   key_block_items_count;
    flex_acl_key_block_item_t *key_block_items;
} flex_acl_key_block_data_t;

#ifndef __FLEX_ACL_GEN_INIT__
extern flex_acl_key_data_t       flex_acl_keys_data[];
extern flex_acl_key_block_data_t key_block_data_dictionary[];
#endif

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* FLEX_ACL_DB_GEN_DEF_H_ */
