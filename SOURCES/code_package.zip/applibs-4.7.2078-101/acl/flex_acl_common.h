/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __FLEX_ACL_COMMON_H_INCL__
#define __FLEX_ACL_COMMON_H_INCL__

/******************************************************************************************
* NOTE: This file should NOT have any other include statements. It should be used for    *
* pure definition of structure, macro, enums etc.                                        *
******************************************************************************************/


/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

typedef enum flex_acl_system_key {
    FLEX_ACL_KEY_SYSTEM_START     = (FLEX_ACL_KEY_COMMON_LAST + 1),
    FLEX_ACL_SYSTEM_KEY_DIPV6_LSB = FLEX_ACL_KEY_SYSTEM_START,
    FLEX_ACL_SYSTEM_KEY_DIPV6_MSB,
    FLEX_ACL_KEY_SYSTEM_LAST = FLEX_ACL_SYSTEM_KEY_DIPV6_MSB
} flex_acl_system_key_e;

typedef enum {
    ACL_STAGE_UNKNOWN = 0,
    ACL_STAGE_FLEX    = 1,
    ACL_STAGE_FLEX2   = 1 << 1,
    ACL_STAGE_FLEX3   = 1 << 2,
    ACL_STAGE_FLEX4   = 1 << 3,
    ACL_STAGE_MACSEC  = 1 << 4,
    ACL_STAGES_NUM,
} acl_stage_e;

/************************************************
 *  Macros
 ***********************************************/


#define ACL_STAGE_IS_VALID(acl_stage) \
    ((acl_stage) != ACL_STAGE_MACSEC && (acl_stage) != ACL_STAGE_UNKNOWN)

#define ACL_STAGE_IS_FLEX2_OR_FLEX3(acl_stage) \
    ((acl_stage) == ACL_STAGE_FLEX2 || (acl_stage) == ACL_STAGE_FLEX3)

#define ACL_STAGE_IS_FLEX2_OR_ABOVE(acl_stage) \
    (ACL_STAGE_IS_VALID(acl_stage) && (acl_stage) != ACL_STAGE_FLEX)

#define ACL_STAGE_IS_FLEX3_OR_ABOVE(acl_stage) \
    (ACL_STAGE_IS_FLEX2_OR_ABOVE(acl_stage) && (acl_stage) != ACL_STAGE_FLEX2)

#define ACL_STAGE_IS_FLEX4_OR_ABOVE(acl_stage) \
    (ACL_STAGE_IS_VALID(acl_stage) && (acl_stage == ACL_STAGE_FLEX4))

/************************************************
 *  Function declarations
 ***********************************************/


#endif /* ifndef __FLEX_ACL_COMMON_H_INCL__ */
