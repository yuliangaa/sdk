/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef FLEX_ACL_TCAM_MANAGER_H_
#define FLEX_ACL_TCAM_MANAGER_H_

#include "sx/sdk/sx_status.h"
#include "sx/sdk/sx_types.h"

/************************************************
 *  Defines
 ***********************************************/
#define FLEX_ACL_TCAM_MANAGER_INVALID_HANDLE 0

/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/
/* Callback to free unused TCAM memory allocated by the client */
typedef uint32_t flex_acl_tcam_manager_handle_t;
typedef sx_status_t (*flex_acl_tcam_manager_free_unused_cb_t) (flex_acl_tcam_manager_handle_t handle,
                                                               void                          *context);
typedef struct flex_acl_tcam_manager_client_params {
    flex_acl_tcam_manager_free_unused_cb_t free_unused_cb;
    void                                  *free_unused_cb_context;
} flex_acl_tcam_manager_client_params_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/

/*
 * Initializes the TCAM manager.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_ERROR - general error
 */
sx_status_t flex_acl_tcam_manager_init(void);

/*
 * Registers a client to the TCAM manager.
 *
 * @param[in] client_params - client parameters
 * @param[out] ret_handle - client handle
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_NULL if invalid NULL parameter is given
 * @return SX_STATUS_NO_RESOURCES if there is no room for another client
 * @return SX_STATUS_ERROR - general error
 */
sx_status_t flex_acl_tcam_manager_client_register(flex_acl_tcam_manager_client_params_t *client_params,
                                                  flex_acl_tcam_manager_handle_t        *ret_handle);

/*
 * Unregisters a client to the TCAM manager.
 *
 * @param[in] handle - client handle
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if the handle is invalid
 * @return SX_STATUS_PARAM_ERROR if the handle isn't registered
 * @return SX_STATUS_ERROR - general error
 */
sx_status_t flex_acl_tcam_manager_client_unregister(flex_acl_tcam_manager_handle_t handle);

/*
 * Frees all allocated and unused TCAM entries of all clients that registered to
 * the TCAM manager and gave a free-unused callback.
 * Entries of the client calling this function will not be freed.
 * An unregistered client can call this function by passing an invalid handle
 * as the calling handle.
 * There must not be any resource manager TCAM checks in progress when calling
 * this function.
 *
 * @param[in] calling_handle - handle of calling client.
 *                             Unregistered clients should pass an invalid handle
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_PARAM_EXCEEDS_RANGE if the handle is invalid
 * @return SX_STATUS_ERROR - general error
 */
sx_status_t flex_acl_tcam_manager_free_unused_entries(flex_acl_tcam_manager_handle_t calling_handle);

#endif /* FLEX_ACL_TCAM_MANAGER_H_ */
