/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLEX_ACL_BINDING_H_INCL__
#define __FLEX_ACL_BINDING_H_INCL__


/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/
#define NOT_LAG FALSE
#define IS_LAG  TRUE

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t flex_acl_bind_update_rules_and_bind_points(sx_acl_id_t                group_id,
                                                       flex_acl_bind_attribs_id_t bind_attribs_id,
                                                       sx_acl_direction_t         direction,
                                                       boolean_t                  bind);
sx_status_t flex_acl_update_bind_points_on_group_edit(sx_acl_id_t                group_id,
                                                      flex_acl_bind_attribs_id_t bind_attribs_id,
                                                      sx_acl_direction_t         direction);
sx_status_t flex_acl_post_port_added_to_lag_handle_binding(sx_port_id_t port_log_id, sx_port_id_t lag_port_log_id);
sx_status_t flex_acl_port_removed_from_lag_handle_binding(sx_port_id_t lag_port_log_id, sx_port_id_t log_port);
sx_status_t flex_acl_clear_port_binding(sx_port_id_t log_port);
sx_status_t flex_acl_clear_rif_binding(sx_rif_id_t rif, boolean_t clear_system);
sx_status_t flex_acl_create_bind_attribs(sx_acl_id_t                  group_id,
                                         flex_acl_bind_attribs_id_t * bind_attribs_id);
sx_status_t flex_acl_remove_bind_attribs(sx_acl_id_t group_id);
sx_status_t flex_acl_get_bind_attribs(sx_acl_id_t                 acl_id,
                                      flex_acl_bind_attribs_id_t *bind_attribs_id,
                                      sx_acl_direction_t         *direction,
                                      sx_acl_id_t                *group_id);
sx_status_t flex_acl_group_validate(sx_acl_id_t               group_id,
                                    flex_acl_db_acl_group_t **acl_group_pp,
                                    boolean_t                *write_to_reg_p);
/* the functions used for allocation and deallocation of group that needed to bind acl directly to port */
sx_status_t flex_acl_allocate_adhoc_acl_group(sx_acl_id_t  acl_id,
                                              sx_acl_id_t *group_id);
sx_status_t flex_acl_clean_adhoc_acl_group(sx_acl_id_t acl_id, boolean_t fail_if_bound);

/**
 * This function performs two tasks:
 * 1. Handles the RM of the total number of ACLs in ACL groups.
 * 2. Calls the HW function to actually change a HW ACL group (if the RM allows it).
 *
 * @param[in] bind_attribs_id  - The bind attributes id (HW ACL group) to perform the operations on.
 * @param[in] set_acls         - Boolean operation: setting ACLs in the group (TRUE) or removing all ACLs (FALSE).
 * @param[in] acl_ids_prepared - The array of ACLs to set in the group - when set_acls is TRUE.
 *                             - The array of ACLs for rollback is the group clear operation fails - when set_acls is FALSE.
 * @param[in] prepared_ids_num - The number of ACL ids in the acl_ids_prepared.
 * @param[in] write_to_reg     - Indicator if to actual perform the operation or not (legacy code support).
 *
 *
 * @return SX_STATUS_SUCCESS - keys are valid.
 *         SX_STATUS_PARAM_ERROR - Keys are invalid for the region.
 *         SX_STATUS_INVALID_HANDLE - Internal DB error.
 *         SX_STATUS_PARAM_EXCEEDS_RANGE - Internal DB error.
 */
sx_status_t flex_acl_write_bind_attributes(flex_acl_bind_attribs_id_t bind_attribs_id,
                                           boolean_t                  set_acls,
                                           acl_id_group_entry_t      *acl_ids_prepared,
                                           uint32_t                   prepared_ids_num,
                                           boolean_t                  write_to_reg);

sx_status_t flex_acl_binding_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

#endif /* ifndef __FLEX_ACL_BINDING_H_INCL__ */
