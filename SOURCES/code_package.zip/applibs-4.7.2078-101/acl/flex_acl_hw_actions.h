/*
 * Copyright (C) 2008-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef FLEX_ACL_HW_ACTIONS_H_
#define FLEX_ACL_HW_ACTIONS_H_


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t flex_acl_hw_write_action_register(sx_dev_id_t          dev_id,
                                              sx_acl_region_id_t   region_id,
                                              sx_acl_rule_offset_t offset,
                                              ku_pefa_reg_t       *pefa_reg_data,
                                              boolean_t            bulk_write);
sx_status_t flex2_acl_hw_write_action_register(sx_dev_id_t          dev_id,
                                               sx_acl_region_id_t   region_id,
                                               sx_acl_rule_offset_t offset,
                                               ku_pefa_reg_t       *pefa_reg_data,
                                               boolean_t            bulk_write);

sx_status_t flex_acl_hw_config_uc_tunnel_pbs_write(const flex_acl_db_pbs_entry_t *pbs_entry_p,
                                                   struct ku_ppbs_reg            *ppbs_p);
sx_status_t flex2_acl_hw_config_uc_tunnel_pbs_write(const flex_acl_db_pbs_entry_t *pbs_entry_p,
                                                    struct ku_ppbs_reg            *ppbs_p);

sx_status_t flex_acl_hw_set_action_activity(boolean_t                        is_full_write,
                                            boolean_t                        is_default_action,
                                            boolean_t                        activity_clear,
                                            flex_acl_hw_db_kvd_action_set_t *kvd_action_set,
                                            ku_pefa_reg_t                   *pefa_reg_data);

sx_status_t flex_acl_hw_release_action_locks(flex_acl_hw_action_t *actions, uint32_t actions_count);

sx_status_t flex_acl_hw_write_extended_action_set(flex_acl_db_flex_rule_t     *rule,
                                                  flex_acl_hw_db_action_set_t *hw_action_set,
                                                  kvd_linear_manager_index_t  *kvd_indexes,
                                                  uint32_t                     kvd_block_size,
                                                  boolean_t                    is_commit,
                                                  uint32_t                     dev_id,
                                                  boolean_t                    is_full_write,
                                                  boolean_t                    activity_clear,
                                                  boolean_t                    add_ref);

sx_status_t flex_acl_hw_create_reg_action_set(flex_acl_hw_action_t      *actions,
                                              uint32_t                   actions_count,
                                              sxd_goto_set_action_t      goto_action,
                                              boolean_t                  is_last_set,
                                              kvd_linear_manager_index_t kvd_index,
                                              boolean_t                  is_commit,
                                              flex_acl_relocation_data_t relocation_data,
                                              sxd_flex_action_set_t     *reg_action_set,
                                              boolean_t                  add_ref,
                                              flex_acl_db_flex_rule_t   *rule);

sx_status_t flex_acl_hw_write_pefa_devices(sx_dev_id_t          dev_id,
                                           boolean_t            write_all_devs,
                                           sx_acl_region_id_t   region_id,
                                           sx_acl_rule_offset_t offset,
                                           struct ku_pefa_reg  *pefa_reg_data);

sx_status_t flex_acl_hw_set_rebind_group_pfunc(flex_acl_rebind_group_pfunc_t rebind_group_cb);

sx_status_t flex_acl_hw_get_all_devs_list(sx_dev_id_t *devs_list, uint16_t *devs_count);
#endif /* ifndef FLEX_ACL_HW_ACTIONS_H_ */
