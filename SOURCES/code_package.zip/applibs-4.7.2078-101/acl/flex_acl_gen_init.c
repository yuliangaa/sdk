/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

/* flex_acl_db_gen_init.c
 *   GENERATED CODE created by machine. Do not change.
 */
#define __FLEX_ACL_GEN_INIT__
#include "flex_acl_gen_def.h"
#undef __FLEX_ACL_GEN_INIT__
/***********************************************
*  Local variables
***********************************************/
/************************************************
 *  Global variables
 ***********************************************/

flex_acl_key_data_t       flex_acl_keys_data[FLEX_ACL_HW_KEY_LAST_E] = {
    [FLEX_ACL_HW_KEY_DIP_E] = {4, 32,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                               , TRUE},
    [FLEX_ACL_HW_KEY_INNER_DIP_E] = {4, 32,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , TRUE},
    [FLEX_ACL_HW_KEY_SIP_E] = {4, 32,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                               , TRUE},
    [FLEX_ACL_HW_KEY_INNER_SIP_E] = {4, 32,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , TRUE},
    [FLEX_ACL_HW_KEY_DIPV6_PART1_E] = {4, 32,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_INNER_DIPV6_PART1_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_DIPV6_PART2_E] = {4, 32,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_INNER_DIPV6_PART2_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_DIPV6_PART3_E] = {4, 32,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_INNER_DIPV6_PART3_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_DIPV6_PART4_E] = {4, 32,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_INNER_DIPV6_PART4_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_SIPV6_PART1_E] = {4, 32,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_INNER_SIPV6_PART1_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_SIPV6_PART2_E] = {4, 32,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_INNER_SIPV6_PART2_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_SIPV6_PART3_E] = {4, 32,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_INNER_SIPV6_PART3_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_SIPV6_PART4_E] = {4, 32,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_INNER_SIPV6_PART4_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_DSCP_E] = {1, 6,
                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                , FALSE},
    [FLEX_ACL_HW_KEY_DSCP_RANGE_E] = {1, 4,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_INNER_DSCP_E] = {1, 6,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_RW_DSCP_E] = {1, 1,
                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                   , FALSE},
    [FLEX_ACL_HW_KEY_ECN_E] = {1, 2,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                               , FALSE},
    [FLEX_ACL_HW_KEY_INNER_ECN_E] = {1, 2,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_IP_FRAGMENTED_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_IP_DONT_FRAGMENT_E] = {1, 1,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E] = {1, 1,
                                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                 , FALSE},
    [FLEX_ACL_HW_KEY_IP_PACKET_LENGTH_E] = {2, 16,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , TRUE},
    [FLEX_ACL_HW_KEY_IP_OK_E] = {1, 1,
                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                 , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IP_OK_E] = {1, 1,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , FALSE},
    [FLEX_ACL_HW_KEY_IP_PROTO_E] = {1, 8,
                                    0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                    , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IP_PROTO_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_IPV6_CUSTOM_EXTENSION_E] = {1, 1,
                                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                 , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IPV6_CUSTOM_EXTENSION_E] = {1, 1,
                                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                       , FALSE},
    [FLEX_ACL_HW_KEY_IPV6_EXTENSION_EXISTS_E] = {1, 1,
                                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                 , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_EXISTS_E] = {1, 1,
                                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                       , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IPV6_HBH_ROUTER_ALERT_OPTION_E] = {1, 1,
                                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                              , FALSE},
    [FLEX_ACL_HW_KEY_IPV6_HBH_EXTENSION_HEADER_E] = {1, 1,
                                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                     , FALSE},
    [FLEX_ACL_HW_KEY_IPV6_EXTENSION_E] = {1, 6,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_E] = {1, 6,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_IS_ARP_E] = {1, 1,
                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                  , FALSE},
    [FLEX_ACL_HW_KEY_IP_OPT_E] = {1, 1,
                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                  , FALSE},
    [FLEX_ACL_HW_KEY_IS_IP_V4_E] = {1, 1,
                                    0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                    , FALSE},
    [FLEX_ACL_HW_KEY_L3_TYPE_E] = {1, 2,
                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                   , FALSE},
    [FLEX_ACL_HW_KEY_INNER_L3_TYPE_E] = {1, 2,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_TTL_E] = {1, 8,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                               , FALSE},
    [FLEX_ACL_HW_KEY_INNER_TTL_E] = {1, 8,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_TTL_OK_E] = {1, 1,
                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                  , FALSE},
    [FLEX_ACL_HW_KEY_INNER_TTL_OK_E] = {1, 1,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IPV6_HBH_CUSTOM_OPTION_E] = {1, 1,
                                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                        , FALSE},
    [FLEX_ACL_HW_KEY_IS_TCP_OPTION_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E] = {2, 16,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , TRUE},
    [FLEX_ACL_HW_KEY_INNER_L4_DESTINATION_PORT_E] = {2, 16,
                                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                     , TRUE},
    [FLEX_ACL_HW_KEY_L4_OK_E] = {1, 1,
                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                 , FALSE},
    [FLEX_ACL_HW_KEY_INNER_L4_OK_E] = {1, 1,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , FALSE},
    [FLEX_ACL_HW_KEY_L4_PORT_RANGE_E] = {2, 16,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , TRUE},
    [FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E] = {2, 16,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , TRUE},
    [FLEX_ACL_HW_KEY_INNER_L4_SOURCE_PORT_E] = {2, 16,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , TRUE},
    [FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E] = {1, 4,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_L4_TYPE_E] = {1, 4,
                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                   , FALSE},
    [FLEX_ACL_HW_KEY_L4_TYPE_ENUM_E] = {1, 2,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_INNER_L4_TYPE_ENUM_E] = {1, 2,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_TCP_CONTROL_E] = {1, 6,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , FALSE},
    [FLEX_ACL_HW_KEY_TCP_ECN_E] = {1, 3,
                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                   , FALSE},
    [FLEX_ACL_HW_KEY_DMAC_E] = {6, 48,
                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                , FALSE},
    [FLEX_ACL_HW_KEY_INNER_DMAC_E] = {6, 48,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E] = {1, 2,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_ETHERTYPE_E] = {2, 16,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , TRUE},
    [FLEX_ACL_HW_KEY_INNER_ETHERTYPE_E] = {2, 16,
                                           0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                           , TRUE},
    [FLEX_ACL_HW_KEY_ETHERTYPE_VECTOR_E] = {1, 8,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_RW_PCP_E] = {1, 1,
                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                  , FALSE},
    [FLEX_ACL_HW_KEY_SMAC_E] = {6, 48,
                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                , FALSE},
    [FLEX_ACL_HW_KEY_INNER_SMAC_E] = {6, 48,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_DEI_E] = {1, 1,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               , FALSE},
    [FLEX_ACL_HW_KEY_INNER_DEI_E] = {1, 1,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E] = {1, 2,
                                           0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                           , FALSE},
    [FLEX_ACL_HW_KEY_PCP_E] = {1, 3,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               , FALSE},
    [FLEX_ACL_HW_KEY_INNER_PCP_E] = {1, 3,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_VLAN_TAGGED_E] = {1, 1,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       , FALSE},
    [FLEX_ACL_HW_KEY_VLAN_VALID_E] = {1, 1,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_INNER_VLAN_VALID_E] = {1, 1,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_VLAN_ID_E] = {2, 12,
                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                   , TRUE},
    [FLEX_ACL_HW_KEY_VLAN_ID_11_4_E] = {1, 8,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_INNER_VLAN_ETHER_TYPE_E] = {1, 2,
                                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                 , FALSE},
    [FLEX_ACL_HW_KEY_INNER_VLAN_ID_E] = {2, 12,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         , TRUE},
    [FLEX_ACL_HW_KEY_SMPE_E] = {2, 14,
                                0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                , TRUE},
    [FLEX_ACL_HW_KEY_SMPE_VALID_E] = {1, 1,
                                      0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_RW_EXP_E] = {1, 1,
                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                  , FALSE},
    [FLEX_ACL_HW_KEY_EXP_E] = {1, 3,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                               , FALSE},
    [FLEX_ACL_HW_KEY_IS_MPLS_E] = {1, 1,
                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                   , FALSE},
    [FLEX_ACL_HW_KEY_BOS_E] = {1, 1,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                               , FALSE},
    [FLEX_ACL_HW_KEY_LABEL_ID_0_E] = {4, 20,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , TRUE},
    [FLEX_ACL_HW_KEY_LABEL_ID_1_E] = {4, 20,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , TRUE},
    [FLEX_ACL_HW_KEY_LABEL_ID_2_19_10_E] = {4, 10,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , TRUE},
    [FLEX_ACL_HW_KEY_LABEL_ID_2_9_0_E] = {4, 10,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , TRUE},
    [FLEX_ACL_HW_KEY_LABEL_ID_2_E] = {4, 20,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , TRUE},
    [FLEX_ACL_HW_KEY_LABEL_ID_3_E] = {4, 20,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , TRUE},
    [FLEX_ACL_HW_KEY_LABEL_ID_4_E] = {4, 20,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , TRUE},
    [FLEX_ACL_HW_KEY_LABEL_ID_5_E] = {4, 20,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , TRUE},
    [FLEX_ACL_HW_KEY_MPLS_ECN_E] = {1, 2,
                                    0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                    , FALSE},
    [FLEX_ACL_HW_KEY_MPLS_LABELS_VALID_E] = {1, 6,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , FALSE},
    [FLEX_ACL_HW_KEY_PHP_E] = {1, 1,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                               , FALSE},
    [FLEX_ACL_HW_KEY_MPLS_TTL_E] = {1, 8,
                                    0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                    , FALSE},
    [FLEX_ACL_HW_KEY_DEST_QP_E] = {4, 24,
                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                   , TRUE},
    [FLEX_ACL_HW_KEY_PKEY_E] = {2, 16,
                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                , TRUE},
    [FLEX_ACL_HW_KEY_BTH_OPCODE_E] = {1, 8,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_COLOR_E] = {1, 2,
                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                 | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                 , FALSE},
    [FLEX_ACL_HW_KEY_DST_PORT_E] = {2, 16,
                                    0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                    , TRUE},
    [FLEX_ACL_HW_KEY_ECMP_HASH_E] = {2, 12,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , TRUE},
    [FLEX_ACL_HW_KEY_ERIF_E] = {2, 13,
                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                , TRUE},
    [FLEX_ACL_HW_KEY_IRIF_E] = {2, 13,
                                0 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                , TRUE},
    [FLEX_ACL_HW_KEY_SWITCH_PRIO_E] = {1, 4,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , FALSE},
    [FLEX_ACL_HW_KEY_SRC_PORT_E] = {4, 32,
                                    0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                    , TRUE},
    [FLEX_ACL_HW_KEY_DMAC_IS_UC_E] = {1, 1,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_E] = {2, 8,
                                          0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          , TRUE},
    [FLEX_ACL_HW_KEY_USER_TOKEN_E] = {2, 16,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , TRUE},
    [FLEX_ACL_HW_KEY_DWORD_VALID_0_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_DWORD_VALID_1_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_DWORD_VALID_2_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_DWORD_VALID_3_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_DWORD_VALID_4_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_DWORD_VALID_5_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_191_160_E] = {4, 32,
                                                    0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                    | (1 << SX_ACL_DIRECTION_EGRESS)
                                                    | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                    | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                    , TRUE},
    [FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_159_128_E] = {4, 32,
                                                    0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                    | (1 << SX_ACL_DIRECTION_EGRESS)
                                                    | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                    | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                    , TRUE},
    [FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_127_120_E] = {4, 8,
                                                    0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                    | (1 << SX_ACL_DIRECTION_EGRESS)
                                                    | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                    | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                    , TRUE},
    [FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_119_96_E] = {4, 24,
                                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                   , TRUE},
    [FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_95_80_E] = {4, 16,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                  , TRUE},
    [FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_79_64_E] = {4, 16,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                  , TRUE},
    [FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_63_40_E] = {4, 24,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                  , TRUE},
    [FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_39_32_E] = {4, 8,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                  , TRUE},
    [FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_31_0_E] = {4, 32,
                                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                 , TRUE},
    [FLEX_ACL_HW_KEY_DISCARD_STATE_E] = {1, 2,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_BUFF_E] = {1, 4,
                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                , FALSE},
    [FLEX_ACL_HW_KEY_TX_LIST_E] = {9, 72,
                                   0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                   , TRUE},
    [FLEX_ACL_HW_KEY_TRAP_PRIO_E] = {1, 3,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_IS_TRAPPED_E] = {1, 1,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_TUNNEL_TYPE_E] = {1, 3,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , FALSE},
    [FLEX_ACL_HW_KEY_VNI_E] = {4, 24,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                               , TRUE},
    [FLEX_ACL_HW_KEY_GRE_KEY_E] = {4, 32,
                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                   , TRUE},
    [FLEX_ACL_HW_KEY_NVE_TYPE_VECTOR_E] = {1, 4,
                                           0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                           , FALSE},
    [FLEX_ACL_HW_KEY_GRE_PROTOCOL_E] = {2, 16,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , TRUE},
    [FLEX_ACL_HW_KEY_GRE_KEY_EXIST_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_SPI_E] = {4, 32,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                               , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_E] = {9, 72,
                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                   , TRUE},
    [FLEX_ACL_HW_KEY_HAS_CONFIGURE_ETHERTYPE_E] = {1, 1,
                                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                   , FALSE},
    [FLEX_ACL_HW_KEY_IS_ROUTED_E] = {1, 1,
                                     0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_DMAC_31_0_E] = {4, 32,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_DMAC_47_32_E] = {2, 16,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_SMAC_31_0_E] = {4, 32,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_SMAC_47_32_E] = {2, 16,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E] = {1, 1,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_FDB_MISS_E] = {1, 1,
                                    0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                    , FALSE},
    [FLEX_ACL_HW_KEY_LLC_VALID_E] = {1, 1,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_RX_SYS_PORT_E] = {2, 16,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_TX_SYS_PORT_E] = {2, 9,
                                       0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_RX_SYS_PORT_PHYSICAL_E] = {2, 9,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E] = {1, 4,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_TUNNEL_VLAN_ETHERTYPE_E] = {1, 2,
                                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                 , FALSE},
    [FLEX_ACL_HW_KEY_TUNNEL_INNER_VLAN_ETHERTYPE_E] = {1, 2,
                                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                       , FALSE},
    [FLEX_ACL_HW_KEY_INNER_DMAC_VALID_E] = {1, 1,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_TAG_VALID_E] = {1, 1,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_INNER_TAG_VALID_E] = {1, 1,
                                           0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                           , FALSE},
    [FLEX_ACL_HW_KEY_TUNNEL_TAG_VALID_E] = {1, 1,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_TUNNEL_INNER_TAG_VALID_E] = {1, 1,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                  , FALSE},
    [FLEX_ACL_HW_KEY_INNER_DMAC_31_0_E] = {4, 32,
                                           0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                           , FALSE},
    [FLEX_ACL_HW_KEY_INNER_DMAC_47_32_E] = {2, 16,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_INNER_SMAC_31_0_E] = {4, 32,
                                           0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                           , FALSE},
    [FLEX_ACL_HW_KEY_INNER_SMAC_47_32_E] = {2, 16,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_TUNNEL_INNER_PCP_E] = {1, 3,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_TUNNEL_INNER_DEI_E] = {1, 1,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_TUNNEL_PCP_E] = {1, 3,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_TUNNEL_DEI_E] = {1, 1,
                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                      , FALSE},
    [FLEX_ACL_HW_KEY_TUNNEL_VLAN_ID_E] = {2, 12,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          , TRUE},
    [FLEX_ACL_HW_KEY_TUNNEL_INNER_VLAN_ID_E] = {2, 12,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                , TRUE},
    [FLEX_ACL_HW_KEY_IP_MORE_FRAGMENT_E] = {1, 1,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_L3_TYPE_EXT_E] = {1, 3,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , FALSE},
    [FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E] = {1, 1,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             , FALSE},
    [FLEX_ACL_HW_KEY_URPF_FAIL_E] = {1, 1,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IP_OPT_E] = {1, 1,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_INNER_L3_TYPE_EXT_E] = {1, 3,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_16_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_17_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_18_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_19_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_20_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_21_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_22_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_23_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_20_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_21_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_22_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_ALU_CARRY_FLAG_E] = {1, 1,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_0_OFFSET_E] = {1, 8,
                                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                     , FALSE},
    [FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_1_OFFSET_E] = {1, 8,
                                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                     , FALSE},
    [FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E] = {1, 4,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E] = {1, 4,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E] = {1, 3,
                                               0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_11_E] = {1, 1,
                                             0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             , FALSE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_31_0_E] = {4, 32,
                                           0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                           , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_63_32_E] = {4, 32,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_95_64_E] = {4, 32,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_127_96_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_159_128_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_191_160_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_223_192_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_255_224_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_257_256_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_287_256_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_319_288_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_351_320_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_383_352_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_415_384_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_447_416_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_479_448_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_511_480_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_RX_LIST_HW_515_512_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_31_0_E] = {4, 32,
                                           0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                           , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_63_32_E] = {4, 32,
                                            0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                            , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_95_64_E] = {4, 32,
                                            0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                            , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_127_96_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_159_128_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_191_160_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_223_192_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_255_224_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_257_256_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_287_256_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_319_288_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_351_320_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_383_352_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_415_384_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_447_416_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_479_448_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_511_480_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_TX_LIST_HW_515_512_E] = {4, 32,
                                              0 | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , TRUE},
    [FLEX_ACL_HW_KEY_INNER_EXP_E] = {1, 3,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IS_MPLS_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_INNER_MPLS_ECN_E] = {1, 2,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_IRIF_3_0_E] = {1, 8,
                                    0 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                    , FALSE},
    [FLEX_ACL_HW_KEY_IRIF_7_4_E] = {1, 8,
                                    0 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                    , FALSE},
    [FLEX_ACL_HW_KEY_IRIF_11_8_E] = {1, 8,
                                     0 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_IRIF_12_E] = {1, 8,
                                   0 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                   , FALSE},
    [FLEX_ACL_HW_KEY_RX_CPU_E] = {2, 1,
                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                  , TRUE},
    [FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_E] = {4, 32,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             , TRUE},
    [FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_VALID_E] = {1, 1,
                                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                   , FALSE},
    [FLEX_ACL_HW_KEY_FID_E] = {2, 14,
                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                               | (1 << SX_ACL_DIRECTION_EGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                               , TRUE},
    [FLEX_ACL_HW_KEY_MC_TYPE_VECTOR_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IS_IPV4_E] = {1, 1,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IP_PACKET_LENGTH_E] = {2, 16,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                  , TRUE},
    [FLEX_ACL_HW_KEY_DIP_REVERSED_E] = {4, 32,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        , TRUE},
    [FLEX_ACL_HW_KEY_IPV6_EXTENSION_SHIM6_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_IPV6_HBH_CUSTOM_OPTION_E] = {1, 1,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                  , FALSE},
    [FLEX_ACL_HW_KEY_IPV6_HBH_ROUTER_ALERT_OPTION_E] = {1, 1,
                                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                        , FALSE},
    [FLEX_ACL_HW_KEY_IPV6_ND_TARGET_VALID_E] = {1, 1,
                                                0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                , FALSE},
    [FLEX_ACL_HW_KEY_ND_SLL_OR_TLL_VALID_E] = {1, 2,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E] = {1, 1,
                                                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                                 , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IP_DONT_FRAGMENT_E] = {1, 1,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                  , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IP_MORE_FRAGMENT_E] = {1, 1,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                  , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IP_FRAGMENTED_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IP_FRAGMENT_NOT_FIRST_E] = {1, 1,
                                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                       , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IPV6_ROUTING_EXTENSION_E] = {1, 1,
                                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                        , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E] = {1, 1,
                                                           0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                           | (1 << SX_ACL_DIRECTION_EGRESS)
                                                           | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                           | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                           | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                           | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                           | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                           | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                           , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_SHIM6_E] = {1, 1,
                                                      0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                      | (1 << SX_ACL_DIRECTION_EGRESS)
                                                      | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                      | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                      | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                      | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                      | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                      | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                      , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E] = {1, 1,
                                                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                                       , FALSE},
    [FLEX_ACL_HW_KEY_INNER_BOS_E] = {1, 1,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , FALSE},
    [FLEX_ACL_HW_KEY_INNER_LABEL_ID_0_E] = {4, 20,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , TRUE},
    [FLEX_ACL_HW_KEY_INNER_MPLS_TTL_E] = {1, 8,
                                          0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                          | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                          , FALSE},
    [FLEX_ACL_HW_KEY_INNER_MPLS_LABELS_VALID_E] = {1, 6,
                                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                   , FALSE},
    [FLEX_ACL_HW_KEY_INNER_LABEL_ID_1_E] = {4, 20,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , TRUE},
    [FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_VALID_E] = {1, 1,
                                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                         , FALSE},
    [FLEX_ACL_HW_KEY_INNER_LABEL_ID_2_E] = {4, 20,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                            , TRUE},
    [FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_E] = {4, 32,
                                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                   , TRUE},
    [FLEX_ACL_HW_KEY_OR_TCP_CONTROL_OR_ECN_E] = {1, 2,
                                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                 , FALSE},
    [FLEX_ACL_HW_KEY_INNER_L4_TYPE_EXTENDED_E] = {1, 4,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                  , FALSE},
    [FLEX_ACL_HW_KEY_INNER_TCP_CONTROL_E] = {1, 6,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , FALSE},
    [FLEX_ACL_HW_KEY_INNER_TCP_ECN_E] = {1, 3,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_INNER_IS_TCP_OPTION_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_INNER_SPI_E] = {4, 32,
                                     0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                     | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                     , TRUE},
    [FLEX_ACL_HW_KEY_SYMMETRIC_HASH_MAC_E] = {1, 1,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_SYMMETRIC_HASH_L4_PORTS_E] = {1, 1,
                                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                   , FALSE},
    [FLEX_ACL_HW_KEY_SYMMETRIC_HASH_IP_E] = {1, 1,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                             , FALSE},
    [FLEX_ACL_HW_KEY_LAG_HASH_E] = {2, 12,
                                    0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                    | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                    , TRUE},
    [FLEX_ACL_HW_KEY_FREE_RUNNIG_CLOCK_MSB_E] = {2, 16,
                                                 0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                                 | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                                 , TRUE},
    [FLEX_ACL_HW_KEY_TRAP_ID_E] = {2, 10,
                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                   | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                   , TRUE},
    [FLEX_ACL_HW_KEY_POLICER_STATE_E] = {2, 12,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         , TRUE},
    [FLEX_ACL_HW_KEY_PORT_USER_MEM_E] = {1, 8,
                                         0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                         | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                         , FALSE},
    [FLEX_ACL_HW_KEY_FPP0_TOUCHED_E] = {1, 1,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_FPP1_TOUCHED_E] = {1, 1,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_FPP2_TOUCHED_E] = {1, 1,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_FPP3_TOUCHED_E] = {1, 1,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_FPP4_TOUCHED_E] = {1, 1,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_FPP5_TOUCHED_E] = {1, 1,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_FPP6_TOUCHED_E] = {1, 1,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_FPP7_TOUCHED_E] = {1, 1,
                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                        | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                        , FALSE},
    [FLEX_ACL_HW_KEY_INNER_FPP0_TOUCHED_E] = {1, 1,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_INNER_FPP1_TOUCHED_E] = {1, 1,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_INNER_FPP2_TOUCHED_E] = {1, 1,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_INNER_FPP3_TOUCHED_E] = {1, 1,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_INNER_FPP4_TOUCHED_E] = {1, 1,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_INNER_FPP5_TOUCHED_E] = {1, 1,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_INNER_FPP6_TOUCHED_E] = {1, 1,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_INNER_FPP7_TOUCHED_E] = {1, 1,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_IS_ELEPHANT_E] = {1, 1,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_CPU_EGRESS)
                                       , FALSE},
    [FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E] = {1, 2,
                                           0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_RIF_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_INGRESS)
                                           | (1 << SX_ACL_DIRECTION_TPORT_EGRESS)
                                           | (1 << SX_ACL_DIRECTION_CPU_INGRESS)
                                           , FALSE},
    [FLEX_ACL_HW_KEY_IS_ARN_E] = {1, 1,
                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                  | (1 << SX_ACL_DIRECTION_RIF_INGRESS)
                                  , FALSE},
    [FLEX_ACL_HW_KEY_MACSEC_SECTAG_VALID_E] = {1, 1,
                                               0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                               | (1 << SX_ACL_DIRECTION_EGRESS)
                                               , FALSE},
    [FLEX_ACL_HW_KEY_MACSEC_SECTAG_ES_E] = {1, 1,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_MACSEC_SECTAG_SC_E] = {1, 1,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_MACSEC_SECTAG_SHORT_LEN_ZERO_E] = {1, 1,
                                                        0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                        | (1 << SX_ACL_DIRECTION_EGRESS)
                                                        , FALSE},
    [FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_0_31_E] = {4, 32,
                                                  0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                  | (1 << SX_ACL_DIRECTION_EGRESS)
                                                  , TRUE},
    [FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_32_63_E] = {4, 32,
                                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                                   , TRUE},
    [FLEX_ACL_HW_KEY_MACSEC_SECTAG_AN_E] = {1, 2,
                                            0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                            | (1 << SX_ACL_DIRECTION_EGRESS)
                                            , FALSE},
    [FLEX_ACL_HW_KEY_MACSEC_SECTAG_SHORT_LEN_E] = {1, 8,
                                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                                   , FALSE},
    [FLEX_ACL_HW_KEY_MACSEC_SECY_VALID_E] = {1, 1,
                                             0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                             | (1 << SX_ACL_DIRECTION_EGRESS)
                                             , FALSE},
    [FLEX_ACL_HW_KEY_MACSEC_SECY_E] = {2, 16,
                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                       , TRUE},
    [FLEX_ACL_HW_KEY_MACSEC_GRE_KEY_0_7_E] = {1, 8,
                                              0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                              | (1 << SX_ACL_DIRECTION_EGRESS)
                                              , FALSE},
    [FLEX_ACL_HW_KEY_MACSEC_VNI_GRE_KEY_8_31_E] = {4, 24,
                                                   0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                   | (1 << SX_ACL_DIRECTION_EGRESS)
                                                   , TRUE},
    [FLEX_ACL_HW_KEY_MACSEC_VXLAN_GPE_NEXT_PROTO_E] = {1, 8,
                                                       0 | (1 << SX_ACL_DIRECTION_INGRESS)
                                                       | (1 << SX_ACL_DIRECTION_EGRESS)
                                                       , FALSE},
};
flex_acl_key_block_data_t key_block_data_dictionary[] = {
    [FLEX_ACL_KEY_BLOCK_L2_DMAC_E] =
    {SXD_ACL_KEY_BLOCK_L2_DMAC, 1, 0x1, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_DMAC_E, 0, 32, 16},
         {FLEX_ACL_HW_KEY_DMAC_E, 48, 16, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 64, 12, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 76, 1, 0},
         {FLEX_ACL_HW_KEY_PCP_E, 77, 3, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 125, 1, 16},
     }, },
    [FLEX_ACL_KEY_BLOCK_L2_SMAC_E] =
    {SXD_ACL_KEY_BLOCK_L2_SMAC, 1, 0x1, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_SMAC_E, 0, 32, 16},
         {FLEX_ACL_HW_KEY_SMAC_E, 48, 16, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 64, 12, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 76, 1, 0},
         {FLEX_ACL_HW_KEY_PCP_E, 77, 3, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 125, 1, 16},
     }, },
    [FLEX_ACL_KEY_BLOCK_L2_SMAC_EX_E] =
    {SXD_ACL_KEY_BLOCK_L2_SMAC_EX, 1, 0x1, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_SMAC_E, 0, 16, 32},
         {FLEX_ACL_HW_KEY_SMAC_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 64, 2, 0},
         {FLEX_ACL_HW_KEY_ETHERTYPE_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_IP_OPT_E, 124, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 125, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 126, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 127, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_E] =
    {SXD_ACL_KEY_BLOCK_IPV4, 1, 0x1, 0x3, 12, (flex_acl_key_block_item_t[12]) {
         {FLEX_ACL_HW_KEY_SIP_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_IP_OPT_E, 32, 1, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENTED_E, 33, 1, 0},
         {FLEX_ACL_HW_KEY_IS_ARP_E, 34, 1, 0},
         {FLEX_ACL_HW_KEY_IS_ROUTED_E, 35, 1, 0},
         {FLEX_ACL_HW_KEY_ECN_E, 36, 2, 0},
         {FLEX_ACL_HW_KEY_TTL_E, 56, 8, 0},
         {FLEX_ACL_HW_KEY_DSCP_E, 64, 6, 0},
         {FLEX_ACL_HW_KEY_TCP_CONTROL_E, 72, 6, 0},
         {FLEX_ACL_HW_KEY_TCP_ECN_E, 78, 3, 0},
         {FLEX_ACL_HW_KEY_DST_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_L4_TYPE_E, 120, 4, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_DIP_E] =
    {SXD_ACL_KEY_BLOCK_IPV4_DIP, 1, 0x1, 0x3, 12, (flex_acl_key_block_item_t[12]) {
         {FLEX_ACL_HW_KEY_DIP_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_TTL_OK_E, 32, 1, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E, 33, 1, 0},
         {FLEX_ACL_HW_KEY_L4_OK_E, 34, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 35, 1, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 36, 2, 0},
         {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E, 48, 16, 0},
         {FLEX_ACL_HW_KEY_IP_PROTO_E, 64, 8, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 88, 1, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 89, 1, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 125, 1, 16},
     }, },
    [FLEX_ACL_KEY_BLOCK_QOS_E] =
    {SXD_ACL_KEY_BLOCK_QOS, 1, 0x1, 0x3, 15, (flex_acl_key_block_item_t[15]) {
         {FLEX_ACL_HW_KEY_RW_DSCP_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_RW_PCP_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 7, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 8, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 9, 1, 0},
         {FLEX_ACL_HW_KEY_COLOR_E, 16, 2, 0},
         {FLEX_ACL_HW_KEY_PCP_E, 29, 3, 0},
         {FLEX_ACL_HW_KEY_SWITCH_PRIO_E, 32, 4, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 48, 2, 0},
         {FLEX_ACL_HW_KEY_BUFF_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_DSCP_E, 64, 6, 0},
         {FLEX_ACL_HW_KEY_ECN_E, 80, 2, 0},
         {FLEX_ACL_HW_KEY_IP_PACKET_LENGTH_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_IRIF_E, 112, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_RPF_E] =
    {SXD_ACL_KEY_BLOCK_RPF, 1, 0x1, 0x3, 11, (flex_acl_key_block_item_t[11]) {
         {FLEX_ACL_HW_KEY_SIP_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 32, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 33, 1, 0},
         {FLEX_ACL_HW_KEY_IS_IP_V4_E, 34, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 35, 1, 0},
         {FLEX_ACL_HW_KEY_L4_TYPE_E, 48, 4, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 62, 2, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 64, 12, 0},
         {FLEX_ACL_HW_KEY_IRIF_E, 80, 16, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 125, 1, 16},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_SIP_E] =
    {SXD_ACL_KEY_BLOCK_IPV4_SIP, 1, 0x1, 0x3, 12, (flex_acl_key_block_item_t[12]) {
         {FLEX_ACL_HW_KEY_SIP_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_TTL_OK_E, 32, 1, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E, 33, 1, 0},
         {FLEX_ACL_HW_KEY_L4_OK_E, 34, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 35, 1, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 36, 2, 0},
         {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E, 48, 16, 0},
         {FLEX_ACL_HW_KEY_IP_PROTO_E, 64, 8, 0},
         {FLEX_ACL_HW_KEY_IS_ROUTED_E, 88, 1, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 89, 1, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 125, 1, 16},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_EX_E] =
    {SXD_ACL_KEY_BLOCK_IPV4_EX, 1, 0x1, 0x3, 11, (flex_acl_key_block_item_t[11]) {
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 0, 12, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 16, 2, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 24, 2, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 32, 1, 0},
         {FLEX_ACL_HW_KEY_IP_DONT_FRAGMENT_E, 33, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 34, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 35, 1, 0},
         {FLEX_ACL_HW_KEY_IRIF_E, 48, 16, 0},
         {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E, 64, 16, 0},
         {FLEX_ACL_HW_KEY_PCP_E, 93, 3, 0},
         {FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E, 96, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_EX2_E] =
    {SXD_ACL_KEY_BLOCK_IPV4_EX2, 1, 0x1, 0x3, 13, (flex_acl_key_block_item_t[13]) {
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E, 0, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E, 8, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E, 16, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E, 24, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E, 25, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E, 26, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_VLAN_ID_E, 32, 12, 0},
         {FLEX_ACL_HW_KEY_INNER_PCP_E, 48, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_DEI_E, 51, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_VLAN_VALID_E, 52, 1, 0},
         {FLEX_ACL_HW_KEY_L4_OK_E, 53, 1, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 56, 2, 0},
         {FLEX_ACL_HW_KEY_USER_TOKEN_E, 64, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_EX3_E] =
    {SXD_ACL_KEY_BLOCK_IPV4_EX3, 1, 0x1, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_IRIF_E, 0, 16, 0},
         {FLEX_ACL_HW_KEY_TTL_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_IS_TCP_OPTION_E, 48, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 52, 1, 0},
         {FLEX_ACL_HW_KEY_SMPE_VALID_E, 56, 1, 0},
         {FLEX_ACL_HW_KEY_LAG_HASH_E, 64, 12, 0},
         {FLEX_ACL_HW_KEY_ECMP_HASH_E, 80, 12, 0},
         {FLEX_ACL_HW_KEY_SMPE_E, 96, 14, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_5TUPLE_E] =
    {SXD_ACL_KEY_BLOCK_IPV4_5TUPLE, 1, 0x1, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_SIP_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_DSCP_E, 32, 6, 0},
         {FLEX_ACL_HW_KEY_ECN_E, 62, 2, 0},
         {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E, 64, 16, 0},
         {FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E, 96, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_12TUPLE_E] =
    {SXD_ACL_KEY_BLOCK_IPV4_12TUPLE, 1, 0x1, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_DMAC_E, 0, 16, 32},
         {FLEX_ACL_HW_KEY_DMAC_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_USER_TOKEN_E, 80, 16, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 112, 1, 0},
         {FLEX_ACL_HW_KEY_PCP_E, 124, 3, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_12TUPLE_EX_E] =
    {SXD_ACL_KEY_BLOCK_IPV4_12TUPLE_EX, 1, 0x1, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_SMAC_E, 0, 16, 32},
         {FLEX_ACL_HW_KEY_SMAC_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_11_4_E, 64, 8, 0},
         {FLEX_ACL_HW_KEY_ETHERTYPE_E, 80, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_CUSTOM_E] =
    {SXD_ACL_KEY_BLOCK_IPV4_CUSTOM, 1, 0x1, 0x3, 16, (flex_acl_key_block_item_t[16]) {
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E, 0, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E, 24, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E, 56, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E, 64, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E, 65, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E, 66, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E, 67, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E, 68, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E, 69, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E, 70, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E, 71, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E, 80, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E, 88, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E, 96, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E, 120, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV4_CUSTOM_EX_E] =
    {SXD_ACL_KEY_BLOCK_IPV4_CUSTOM_EX, 1, 0x1, 0x3, 16, (flex_acl_key_block_item_t[16]) {
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E, 0, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E, 24, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E, 56, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E, 64, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E, 65, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E, 66, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E, 67, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E, 68, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E, 69, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E, 70, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E, 71, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E, 80, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E, 88, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E, 96, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E, 120, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_INNER_IPV4_DIP_E] =
    {SXD_ACL_KEY_BLOCK_INNER_IPV4_DIP, 1, 0x1, 0x3, 9, (flex_acl_key_block_item_t[9]) {
         {FLEX_ACL_HW_KEY_INNER_DIP_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_INNER_TTL_OK_E, 32, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_L4_OK_E, 34, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OK_E, 35, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E, 36, 2, 0},
         {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E, 48, 16, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_PROTO_E, 64, 8, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 125, 1, 16},
     }, },
    [FLEX_ACL_KEY_BLOCK_INNER_IPV4_5TUPLE_E] =
    {SXD_ACL_KEY_BLOCK_INNER_IPV4_5TUPLE, 1, 0x1, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_INNER_SIP_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_INNER_DSCP_E, 32, 6, 0},
         {FLEX_ACL_HW_KEY_INNER_ECN_E, 62, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_L4_SOURCE_PORT_E, 64, 16, 0},
         {FLEX_ACL_HW_KEY_INNER_L4_DESTINATION_PORT_E, 96, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_INNER_IPV4_12TUPLE_E] =
    {SXD_ACL_KEY_BLOCK_INNER_IPV4_12TUPLE, 1, 0x1, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_INNER_DMAC_E, 0, 16, 32},
         {FLEX_ACL_HW_KEY_INNER_DMAC_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_USER_TOKEN_E, 80, 16, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 112, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_INNER_IPV4_12TUPLE_EX_E] =
    {SXD_ACL_KEY_BLOCK_INNER_IPV4_12TUPLE_EX, 1, 0x1, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_INNER_SMAC_E, 0, 16, 32},
         {FLEX_ACL_HW_KEY_INNER_SMAC_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_INNER_ETHERTYPE_E, 80, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_ETHERNET_ETH_PAYLOAD0_E] =
    {SXD_ACL_KEY_BLOCK_ETHERNET_ETH_PAYLOAD0, 1, 0x1, 0x3, 11, (flex_acl_key_block_item_t[11]) {
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_39_32_E, 0, 8, 0},
         {FLEX_ACL_HW_KEY_DWORD_VALID_5_E, 30, 1, 0},
         {FLEX_ACL_HW_KEY_DWORD_VALID_4_E, 31, 1, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_31_0_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_ETHERTYPE_VECTOR_E, 64, 8, 0},
         {FLEX_ACL_HW_KEY_DST_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 112, 2, 0},
         {FLEX_ACL_HW_KEY_L4_TYPE_E, 116, 4, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 124, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 125, 1, 0},
         {FLEX_ACL_HW_KEY_IS_ROUTED_E, 126, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_CUSTOM_ETH_PAYLOAD1_E] =
    {SXD_ACL_KEY_BLOCK_CUSTOM_ETH_PAYLOAD1, 1, 0x1, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_79_64_E, 0, 8, 8},
         {FLEX_ACL_HW_KEY_DWORD_VALID_4_E, 30, 1, 0},
         {FLEX_ACL_HW_KEY_DWORD_VALID_3_E, 31, 1, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_63_40_E, 32, 24, 8},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_79_64_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_ETHERTYPE_ETH_PAYLOAD2_E] =
    {SXD_ACL_KEY_BLOCK_ETHERTYPE_ETH_PAYLOAD2, 1, 0x1, 0x3, 9, (flex_acl_key_block_item_t[9]) {
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_119_96_E, 0, 8, 16},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_95_80_E, 32, 16, 16},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_119_96_E, 48, 16, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 65, 1, 0},
         {FLEX_ACL_HW_KEY_DWORD_VALID_3_E, 92, 1, 0},
         {FLEX_ACL_HW_KEY_DWORD_VALID_2_E, 93, 1, 0},
         {FLEX_ACL_HW_KEY_DWORD_VALID_1_E, 94, 1, 0},
         {FLEX_ACL_HW_KEY_DWORD_VALID_0_E, 95, 1, 0},
         {FLEX_ACL_HW_KEY_ETHERTYPE_E, 96, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_ETHERTYPE_ETH_PAYLOAD3_E] =
    {SXD_ACL_KEY_BLOCK_ETHERTYPE_ETH_PAYLOAD3, 1, 0x1, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_191_160_E, 0, 8, 24},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_159_128_E, 32, 8, 24},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_191_160_E, 40, 24, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_127_120_E, 64, 8, 24},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_159_128_E, 72, 24, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_VID_E] =
    {SXD_ACL_KEY_BLOCK_VID, 1, 0x1, 0x3, 11, (flex_acl_key_block_item_t[11]) {
         {FLEX_ACL_HW_KEY_IRIF_E, 0, 16, 0},
         {FLEX_ACL_HW_KEY_ERIF_E, 16, 16, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 32, 1, 0},
         {FLEX_ACL_HW_KEY_SMPE_VALID_E, 34, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 36, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 37, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_VLAN_VALID_E, 38, 1, 0},
         {FLEX_ACL_HW_KEY_SMPE_E, 40, 14, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 61, 2, 0},
         {FLEX_ACL_HW_KEY_IS_ROUTED_E, 63, 1, 0},
         {FLEX_ACL_HW_KEY_PCP_E, 108, 3, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV6_DIP_E] =
    {SXD_ACL_KEY_BLOCK_IPV6_DIP, 1, 0x1, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_DIPV6_PART2_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_DIPV6_PART1_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_DSCP_E, 120, 6, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV6_DIP_EX_E] =
    {SXD_ACL_KEY_BLOCK_IPV6_DIP_EX, 1, 0x1, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_DIPV6_PART4_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_DIPV6_PART3_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_E, 64, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_ROCE_E] =
    {SXD_ACL_KEY_BLOCK_ROCE, 1, 0x1, 0x3, 9, (flex_acl_key_block_item_t[9]) {
         {FLEX_ACL_HW_KEY_DEST_QP_E, 0, 24, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 32, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 35, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 37, 1, 0},
         {FLEX_ACL_HW_KEY_PKEY_E, 48, 16, 0},
         {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E, 64, 4, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 72, 12, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 125, 1, 16},
     }, },
    [FLEX_ACL_KEY_BLOCK_ROCE_EX_E] =
    {SXD_ACL_KEY_BLOCK_ROCE_EX, 1, 0x1, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_DMAC_E, 0, 16, 32},
         {FLEX_ACL_HW_KEY_DMAC_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_ETHERTYPE_E, 64, 16, 0},
         {FLEX_ACL_HW_KEY_BTH_OPCODE_E, 96, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV6_SIP_E] =
    {SXD_ACL_KEY_BLOCK_IPV6_SIP, 1, 0x1, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_SIPV6_PART2_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_SIPV6_PART1_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV6_SIP_EX_E] =
    {SXD_ACL_KEY_BLOCK_IPV6_SIP_EX, 1, 0x1, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_SIPV6_PART4_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_SIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV6_E] =
    {SXD_ACL_KEY_BLOCK_IPV6, 1, 0x1, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_DIPV6_PART2_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_DIPV6_PART1_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_IPV6_EXTENSION_E, 64, 6, 0},
         {FLEX_ACL_HW_KEY_IPV6_HBH_EXTENSION_HEADER_E, 95, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV6_EX1_E] =
    {SXD_ACL_KEY_BLOCK_IPV6_EX1, 1, 0x1, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_DIPV6_PART4_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_DIPV6_PART3_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_IP_PROTO_E, 64, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV6_EX2_E] =
    {SXD_ACL_KEY_BLOCK_IPV6_EX2, 1, 0x1, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_SIPV6_PART2_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_SIPV6_PART1_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 125, 1, 16},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV6_EX3_E] =
    {SXD_ACL_KEY_BLOCK_IPV6_EX3, 1, 0x1, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_SIPV6_PART4_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_SIPV6_PART3_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 66, 2, 0},
         {FLEX_ACL_HW_KEY_IPV6_EXTENSION_EXISTS_E, 124, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 127, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPV6_EX4_E] =
    {SXD_ACL_KEY_BLOCK_IPV6_EX4, 1, 0x1, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_L4_OK_E, 32, 1, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E, 33, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_L4_OK_E, 35, 1, 0},
         {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E, 40, 16, 0},
         {FLEX_ACL_HW_KEY_TTL_E, 56, 8, 0},
         {FLEX_ACL_HW_KEY_TCP_CONTROL_E, 72, 6, 0},
         {FLEX_ACL_HW_KEY_TCP_ECN_E, 78, 3, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_INNER_IPV6_E] =
    {SXD_ACL_KEY_BLOCK_INNER_IPV6, 1, 0x1, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_INNER_DIPV6_PART2_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_INNER_DIPV6_PART1_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_INNER_IPV6_EX1_E] =
    {SXD_ACL_KEY_BLOCK_INNER_IPV6_EX1, 1, 0x1, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_INNER_DIPV6_PART4_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_INNER_DIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_INNER_IPV6_EX2_E] =
    {SXD_ACL_KEY_BLOCK_INNER_IPV6_EX2, 1, 0x1, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_INNER_SIPV6_PART2_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_INNER_SIPV6_PART1_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_INNER_IPV6_EX3_E] =
    {SXD_ACL_KEY_BLOCK_INNER_IPV6_EX3, 1, 0x1, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_INNER_SIPV6_PART4_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_INNER_SIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_TUNNEL_E] =
    {SXD_ACL_KEY_BLOCK_TUNNEL, 1, 0x1, 0x3, 9, (flex_acl_key_block_item_t[9]) {
         {FLEX_ACL_HW_KEY_IP_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OK_E, 6, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E, 16, 2, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 30, 2, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E, 48, 3, 0},
         {FLEX_ACL_HW_KEY_GRE_KEY_E, 64, 32, 0},
         {FLEX_ACL_HW_KEY_VNI_E, 72, 24, 0},
         {FLEX_ACL_HW_KEY_GRE_PROTOCOL_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_NVE_TYPE_VECTOR_E, 124, 4, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_IPSEC_E] =
    {SXD_ACL_KEY_BLOCK_IPSEC, 1, 0x1, 0x3, 13, (flex_acl_key_block_item_t[13]) {
         {FLEX_ACL_HW_KEY_SPI_E, 0, 32, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 32, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 34, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 35, 1, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E, 36, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 37, 1, 0},
         {FLEX_ACL_HW_KEY_L4_OK_E, 38, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 39, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 48, 12, 0},
         {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E, 64, 4, 0},
         {FLEX_ACL_HW_KEY_IP_PROTO_E, 80, 8, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 96, 16, 0},
         {FLEX_ACL_HW_KEY_SRC_PORT_E, 125, 1, 16},
     }, },
    [FLEX_ACL_KEY_BLOCK_MPLS_E] =
    {SXD_ACL_KEY_BLOCK_MPLS, 1, 0x1, 0x3, 10, (flex_acl_key_block_item_t[10]) {
         {FLEX_ACL_HW_KEY_BOS_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_RW_EXP_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_IS_MPLS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_2_9_0_E, 16, 10, 0},
         {FLEX_ACL_HW_KEY_MPLS_ECN_E, 30, 2, 0},
         {FLEX_ACL_HW_KEY_MPLS_TTL_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_EXP_E, 61, 3, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_1_E, 64, 20, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_0_E, 96, 20, 0},
         {FLEX_ACL_HW_KEY_MPLS_LABELS_VALID_E, 122, 6, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MPLS_EX_E] =
    {SXD_ACL_KEY_BLOCK_MPLS_EX, 1, 0x1, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_LABEL_ID_2_19_10_E, 16, 10, 10},
         {FLEX_ACL_HW_KEY_LABEL_ID_3_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_4_E, 64, 20, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_5_E, 96, 20, 0},
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E, 126, 2, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_LOADBALANCING_EX_E] =
    {SXD_ACL_KEY_BLOCK_LOADBALANCING_EX, 1, 0x1, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_TX_LIST_E, 0, 32, 33},
         {FLEX_ACL_HW_KEY_TX_LIST_E, 32, 32, 1},
         {FLEX_ACL_HW_KEY_TX_LIST_E, 95, 1, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 96, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 125, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_PACKETTYPE_E] =
    {SXD_ACL_KEY_BLOCK_PACKETTYPE, 1, 0x1, 0x3, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E, 64, 4, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_RX_LIST_E] =
    {SXD_ACL_KEY_BLOCK_RX_LIST, 1, 0x1, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_RX_LIST_E, 0, 32, 32},
         {FLEX_ACL_HW_KEY_RX_LIST_E, 32, 32, 0},
         {FLEX_ACL_HW_KEY_RX_LIST_E, 95, 1, 64},
         {FLEX_ACL_HW_KEY_DISCARD_STATE_E, 64, 2, 0},
         {FLEX_ACL_HW_KEY_IS_TRAPPED_E, 124, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 127, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_0, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_31_0_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_1, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_LLC_VALID_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_SMAC_31_0_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_2, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_47_32_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_SMAC_47_32_E, 48, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_3, 1, 0xE, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_PCP_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_47_32_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 48, 12, 0},
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_4_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_4, 1, 0xE, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_PCP_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_ETHERTYPE_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 48, 12, 0},
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_5_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_5, 1, 0x2, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 48, 12, 0},
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 63, 1, 15},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_5B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_5B, 1, 0x4, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 1, 1, 15},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 32, 9, 0},
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 41, 9, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 50, 12, 0},
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 62, 2, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_5C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_5C, 1, 0x8, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 3, 1, 15},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 32, 10, 0},
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 42, 10, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 52, 12, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_6_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_6, 1, 0x2, 0x3, 11, (flex_acl_key_block_item_t[11]) {
         {FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_ETHERTYPE_VECTOR_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_HAS_CONFIGURE_ETHERTYPE_E, 40, 1, 0},
         {FLEX_ACL_HW_KEY_LLC_VALID_E, 41, 1, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 42, 2, 0},
         {FLEX_ACL_HW_KEY_RW_PCP_E, 44, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 45, 1, 15},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 47, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_6B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_6B, 1, 0x4, 0x3, 11, (flex_acl_key_block_item_t[11]) {
         {FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_ETHERTYPE_VECTOR_E, 32, 6, 0},
         {FLEX_ACL_HW_KEY_HAS_CONFIGURE_ETHERTYPE_E, 38, 1, 0},
         {FLEX_ACL_HW_KEY_LLC_VALID_E, 39, 1, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 40, 2, 0},
         {FLEX_ACL_HW_KEY_RW_PCP_E, 42, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 43, 1, 15},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 44, 1, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 45, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 46, 9, 0},
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 55, 9, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_6C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_6C, 1, 0x8, 0x3, 12, (flex_acl_key_block_item_t[12]) {
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 0, 2, 8},
         {FLEX_ACL_HW_KEY_TUNNEL_VLAN_ETHERTYPE_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_ETHERTYPE_VECTOR_E, 32, 6, 0},
         {FLEX_ACL_HW_KEY_HAS_CONFIGURE_ETHERTYPE_E, 38, 1, 0},
         {FLEX_ACL_HW_KEY_LLC_VALID_E, 39, 1, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 40, 2, 0},
         {FLEX_ACL_HW_KEY_RW_PCP_E, 42, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 43, 1, 15},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 44, 1, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 45, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 46, 10, 0},
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 55, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_7_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_7, 1, 0xE, 0x3, 10, (flex_acl_key_block_item_t[10]) {
         {FLEX_ACL_HW_KEY_INNER_PCP_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_DEI_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 32, 12, 0},
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 44, 2, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 47, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_VLAN_ID_E, 48, 12, 0},
         {FLEX_ACL_HW_KEY_INNER_VLAN_ETHER_TYPE_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_VLAN_VALID_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_8_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_8, 1, 0x2, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 1, 1, 15},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_FID_E, 32, 14, 0},
         {FLEX_ACL_HW_KEY_RX_CPU_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 47, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_MC_TYPE_VECTOR_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_8B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_8B, 1, 0x4, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 1, 1, 15},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_FID_E, 32, 14, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 47, 9, 0},
         {FLEX_ACL_HW_KEY_MC_TYPE_VECTOR_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_8C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_8C, 1, 0x8, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_MC_TYPE_VECTOR_E, 0, 1, 7},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 2, 1, 15},
         {FLEX_ACL_HW_KEY_FID_E, 32, 14, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 47, 10, 0},
         {FLEX_ACL_HW_KEY_MC_TYPE_VECTOR_E, 57, 7, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_9_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_9, 1, 0x6, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_VLAN_ETHER_TYPE_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_SMPE_E, 32, 14, 0},
         {FLEX_ACL_HW_KEY_SMPE_VALID_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_TAG_VALID_E, 47, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_TAG_VALID_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MAC_9B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MAC_9B, 1, 0x8, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_INNER_VLAN_ETHER_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_VLAN_ETHERTYPE_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_SMPE_E, 32, 13, 0},
         {FLEX_ACL_HW_KEY_SMPE_VALID_E, 45, 1, 0},
         {FLEX_ACL_HW_KEY_TAG_VALID_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_TAG_VALID_E, 61, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 62, 2, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MAC_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_MAC_0, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_TUNNEL_VLAN_ETHERTYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_DMAC_VALID_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_TAG_VALID_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_DMAC_31_0_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MAC_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_MAC_1, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_VLAN_ETHERTYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_DMAC_VALID_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_TAG_VALID_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_SMAC_31_0_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MAC_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_MAC_2, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_DEI_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_PCP_E, 1, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_DMAC_47_32_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_INNER_SMAC_47_32_E, 48, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MAC_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_MAC_3, 1, 0xE, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_TUNNEL_PCP_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_DEI_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_ETHERTYPE_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_VLAN_ID_E, 48, 12, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_VLAN_ETHERTYPE_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_TAG_VALID_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_DMAC_VALID_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MAC_4_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_MAC_4, 1, 0xE, 0x3, 10, (flex_acl_key_block_item_t[10]) {
         {FLEX_ACL_HW_KEY_TUNNEL_PCP_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_DEI_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_VLAN_ID_E, 32, 12, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_VLAN_ETHERTYPE_E, 44, 2, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_TAG_VALID_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_DEI_E, 47, 1, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_VLAN_ID_E, 48, 12, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_VLAN_ETHERTYPE_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_TAG_VALID_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_DMAC_VALID_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IP_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IP_0, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_IS_IPV4_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_IP_PACKET_LENGTH_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_PACKET_LENGTH_E, 48, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_0, 1, 0xE, 0x1, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OPT_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_DIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_0_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_0_SYMM, 1, 0xC, 0x2, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_DIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_1, 1, 0x2, 0x1, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OPT_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_SIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_1B, 1, 0x4, 0x1, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_IRIF_12_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_SIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1B_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_1B_SYMM, 1, 0x4, 0x2, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_SIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_1C, 1, 0x8, 0x1, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_IP_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_SIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1C_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_1C_SYMM, 1, 0x8, 0x2, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_SIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_1_OPT_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_1_OPT, 1, 0xC, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_SIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_2, 1, 0xE, 0x3, 12, (flex_acl_key_block_item_t[12]) {
         {FLEX_ACL_HW_KEY_DSCP_RANGE_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_DSCP_E, 32, 6, 0},
         {FLEX_ACL_HW_KEY_ECN_E, 38, 2, 0},
         {FLEX_ACL_HW_KEY_TTL_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_IP_PROTO_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_IP_DONT_FRAGMENT_E, 56, 1, 0},
         {FLEX_ACL_HW_KEY_IP_MORE_FRAGMENT_E, 57, 1, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENTED_E, 58, 1, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E, 59, 1, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 62, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OPT_E, 63, 2, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_3, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_DIP_REVERSED_E, 0, 4, 28},
         {FLEX_ACL_HW_KEY_DIP_REVERSED_E, 36, 28, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 32, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 34, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OPT_E, 35, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_4_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_4, 1, 0x2, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_TTL_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_IRIF_3_0_E, 32, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_7_4_E, 36, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_11_8_E, 40, 4, 0},
         {FLEX_ACL_HW_KEY_ERIF_E, 44, 12, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 60, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 56, 4, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_4B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_4B, 1, 0x4, 0x3, 11, (flex_acl_key_block_item_t[11]) {
         {FLEX_ACL_HW_KEY_IP_OK_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OPT_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_IRIF_3_0_E, 32, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_7_4_E, 36, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_11_8_E, 40, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_12_E, 44, 1, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 45, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 49, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 53, 3, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_11_E, 56, 1, 0},
         {FLEX_ACL_HW_KEY_TTL_OK_E, 57, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_4C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_4C, 1, 0x8, 0x3, 11, (flex_acl_key_block_item_t[11]) {
         {FLEX_ACL_HW_KEY_IP_OK_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OPT_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_IRIF_3_0_E, 32, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_7_4_E, 36, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_11_8_E, 40, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 44, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 48, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 52, 3, 0},
         {FLEX_ACL_HW_KEY_TTL_OK_E, 55, 1, 0},
         {FLEX_ACL_HW_KEY_ERIF_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_5_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_5, 1, 0x2, 0x3, 13, (flex_acl_key_block_item_t[13]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_EXT_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_IP_OPT_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_IS_IP_V4_E, 44, 1, 0},
         {FLEX_ACL_HW_KEY_IS_ARP_E, 45, 1, 0},
         {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_URPF_FAIL_E, 47, 1, 0},
         {FLEX_ACL_HW_KEY_RW_DSCP_E, 51, 1, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 52, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 60, 3, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 63, 1, 0},
         {FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E, 48, 2, 0},
         {FLEX_ACL_HW_KEY_IS_ARN_E, 50, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_5B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_5B, 1, 0x4, 0x3, 13, (flex_acl_key_block_item_t[13]) {
         {FLEX_ACL_HW_KEY_IP_OK_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_EXT_E, 1, 3, 0},
         {FLEX_ACL_HW_KEY_IS_IP_V4_E, 44, 1, 0},
         {FLEX_ACL_HW_KEY_IS_ARP_E, 45, 1, 0},
         {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_URPF_FAIL_E, 47, 1, 0},
         {FLEX_ACL_HW_KEY_RW_DSCP_E, 51, 1, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 52, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 60, 3, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_11_E, 63, 1, 0},
         {FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E, 48, 2, 0},
         {FLEX_ACL_HW_KEY_IS_ARN_E, 50, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_5C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_5C, 1, 0x8, 0x3, 13, (flex_acl_key_block_item_t[13]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_EXT_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENTED_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_IS_IP_V4_E, 44, 1, 0},
         {FLEX_ACL_HW_KEY_IS_ARP_E, 45, 1, 0},
         {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_URPF_FAIL_E, 47, 1, 0},
         {FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E, 48, 2, 0},
         {FLEX_ACL_HW_KEY_IS_ARN_E, 50, 1, 0},
         {FLEX_ACL_HW_KEY_RW_DSCP_E, 51, 1, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 52, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 60, 3, 0},
         {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_MAC_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_6B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_6B, 1, 0x4, 0x3, 11, (flex_acl_key_block_item_t[11]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_E, 0, 3, 1},
         {FLEX_ACL_HW_KEY_ERIF_E, 32, 13, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 45, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 49, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 53, 3, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_11_E, 56, 1, 0},
         {FLEX_ACL_HW_KEY_TTL_OK_E, 57, 1, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 58, 2, 0},
         {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E, 60, 1, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 61, 2, 0},
         {FLEX_ACL_HW_KEY_L4_TYPE_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV4_6C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV4_6C, 1, 0x8, 0x3, 11, (flex_acl_key_block_item_t[11]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_E, 0, 1, 3},
         {FLEX_ACL_HW_KEY_ND_SLL_OR_TLL_VALID_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_ERIF_E, 32, 12, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 44, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 48, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 52, 3, 0},
         {FLEX_ACL_HW_KEY_TTL_OK_E, 55, 1, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 56, 2, 0},
         {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E, 58, 1, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 59, 2, 0},
         {FLEX_ACL_HW_KEY_L4_TYPE_E, 61, 3, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_0, 1, 0xE, 0x1, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_DIPV6_PART2_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_0_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_0_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_DIPV6_PART2_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_1, 1, 0xE, 0x1, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_DIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_1_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_1_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_DIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_2, 1, 0x2, 0x1, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_DIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_2_SYMM, 1, 0x2, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_DIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_2B, 1, 0x4, 0x1, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_11_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_DIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2B_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_2B_SYMM, 1, 0x4, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_DIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_2C, 1, 0x8, 0x1, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_IPV6_EXTENSION_EXISTS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_DIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_2C_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_2C_SYMM, 1, 0x8, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_DIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_3, 1, 0xE, 0x1, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_IRIF_3_0_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_SIPV6_PART2_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_3_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_3_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_SIPV6_PART2_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_4_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_4, 1, 0xE, 0x1, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_IRIF_7_4_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_SIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_4_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_4_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_SIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_5_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_5, 1, 0xE, 0x1, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_IRIF_11_8_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_SIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_5_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_5_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_SIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IPV6_6_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IPV6_6, 1, 0xE, 0x3, 16, (flex_acl_key_block_item_t[16]) {
         {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_IP_MORE_FRAGMENT_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENTED_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_TTL_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_TTL_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_IP_PROTO_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_IPV6_EXTENSION_E, 48, 6, 0},
         {FLEX_ACL_HW_KEY_IPV6_EXTENSION_SHIM6_E, 54, 1, 0},
         {FLEX_ACL_HW_KEY_IPV6_EXTENSION_EXISTS_E, 55, 1, 0},
         {FLEX_ACL_HW_KEY_IPV6_HBH_CUSTOM_OPTION_E, 56, 1, 0},
         {FLEX_ACL_HW_KEY_IPV6_HBH_ROUTER_ALERT_OPTION_E, 57, 1, 0},
         {FLEX_ACL_HW_KEY_IPV6_HBH_EXTENSION_HEADER_E, 58, 1, 0},
         {FLEX_ACL_HW_KEY_IPV6_ND_TARGET_VALID_E, 59, 1, 0},
         {FLEX_ACL_HW_KEY_ND_SLL_OR_TLL_VALID_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_IPV6_CUSTOM_EXTENSION_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_0, 1, 0xE, 0x1, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OK_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OPT_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_DIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_0_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_0_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_INNER_DIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_1, 1, 0xE, 0x1, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_SIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_1_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_1_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_INNER_SIP_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV4_2, 1, 0xE, 0x3, 13, (flex_acl_key_block_item_t[13]) {
         {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_TTL_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_DSCP_E, 32, 6, 0},
         {FLEX_ACL_HW_KEY_INNER_ECN_E, 38, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_TTL_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_PROTO_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_DONT_FRAGMENT_E, 56, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_MORE_FRAGMENT_E, 57, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENTED_E, 58, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENT_NOT_FIRST_E, 59, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OK_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OPT_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_0, 1, 0xE, 0x1, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_ROUTING_EXTENSION_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_DIPV6_PART2_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_0_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_0_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_INNER_DIPV6_PART2_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_1, 1, 0xE, 0x1, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_INNER_IP_MORE_FRAGMENT_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENTED_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENT_NOT_FIRST_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_CUSTOM_EXTENSION_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_DIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_1_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_1_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_INNER_DIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_2, 1, 0xE, 0x1, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OK_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_TTL_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_DIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_2_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_2_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_INNER_DIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_3, 1, 0xE, 0x1, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_HBH_ROUTER_ALERT_OPTION_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_HBH_CUSTOM_OPTION_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_TTL_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_SIPV6_PART2_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_3_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_3_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_INNER_SIPV6_PART2_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_4_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_4, 1, 0xE, 0x1, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_ROUTING_EXTENSION_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_SIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_4_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_4_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_INNER_SIPV6_PART3_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_5_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_5, 1, 0xE, 0x1, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_EXT_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_SIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_5_SYMM_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_5_SYMM, 1, 0xC, 0x2, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_INNER_SIPV6_PART4_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_6_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_IPV6_6, 1, 0xE, 0x3, 15, (flex_acl_key_block_item_t[15]) {
         {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENT_NOT_FIRST_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_MORE_FRAGMENT_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_FRAGMENTED_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_TTL_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_TTL_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_PROTO_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_E, 48, 6, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_SHIM6_E, 54, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_EXISTS_E, 55, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_HBH_CUSTOM_OPTION_E, 56, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_HBH_ROUTER_ALERT_OPTION_E, 57, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_HBH_EXTENSION_HEADER_E, 58, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OK_E, 59, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_IPV6_EXTENSION_HOST_IDENTIFY_PROTOCOL_E, 62, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_0, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_IS_MPLS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_BOS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_0_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_MPLS_TTL_E, 52, 8, 0},
         {FLEX_ACL_HW_KEY_MPLS_LABELS_VALID_E, 60, 6, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_1, 1, 0x2, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_EXP_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_PHP_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_1_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_IRIF_3_0_E, 52, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_7_4_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_11_8_E, 60, 4, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_1B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_1B, 1, 0x4, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_IRIF_12_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_EXP_E, 1, 3, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_1_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_IRIF_3_0_E, 52, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_7_4_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_11_8_E, 60, 4, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_1C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_1C, 1, 0x8, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_EXP_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_RW_EXP_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_1_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_IRIF_3_0_E, 52, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_7_4_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_IRIF_11_8_E, 60, 4, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_2, 1, 0x2, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_RW_EXP_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_2_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_ERIF_E, 52, 12, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_2B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_2B, 1, 0x4, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_ERIF_E, 0, 1, 12},
         {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E, 1, 3, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_2_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_ERIF_E, 52, 12, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_2C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_2C, 1, 0x8, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_2_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_ERIF_E, 52, 12, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_3, 1, 0x2, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_MPLS_ECN_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_3_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 52, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 60, 3, 0},
         {FLEX_ACL_HW_KEY_EXP_E, 63, 3, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_3B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_3B, 1, 0x4, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_MPLS_ECN_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_PHP_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_BOS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_3_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 52, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 60, 3, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_11_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_3C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_3C, 1, 0x8, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_PHP_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_BOS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_3_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_3_0_E, 52, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_7_4_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_VIRTUAL_ROUTER_10_8_E, 60, 3, 0},
         {FLEX_ACL_HW_KEY_MPLS_ECN_E, 63, 2, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_4_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_4, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_IS_MPLS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_BOS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_4_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_MPLS_LABELS_VALID_E, 52, 6, 0},
         {FLEX_ACL_HW_KEY_MPLS_TTL_E, 58, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_5_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_5, 1, 0xE, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_EXP_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_RW_EXP_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_LABEL_ID_5_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_MPLS_LABELS_VALID_E, 52, 6, 0},
         {FLEX_ACL_HW_KEY_MPLS_ECN_E, 58, 2, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E, 60, 3, 0},
         {FLEX_ACL_HW_KEY_BOS_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MPLS_6_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MPLS_6, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_VALID_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_PHP_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_IS_MPLS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_BOS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_MPLS_CONTROL_WORD_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_0, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_INNER_IS_MPLS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_BOS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_LABEL_ID_0_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_INNER_MPLS_TTL_E, 52, 8, 0},
         {FLEX_ACL_HW_KEY_INNER_MPLS_LABELS_VALID_E, 60, 6, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_1, 1, 0xE, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_INNER_TTL_OK_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IS_MPLS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_BOS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_LABEL_ID_1_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_INNER_EXP_E, 52, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_MPLS_ECN_E, 55, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_MPLS_LABELS_VALID_E, 57, 6, 0},
         {FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_VALID_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_2, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_INNER_IS_MPLS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_BOS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_LABEL_ID_2_E, 32, 20, 0},
         {FLEX_ACL_HW_KEY_INNER_MPLS_TTL_E, 52, 8, 0},
         {FLEX_ACL_HW_KEY_INNER_MPLS_LABELS_VALID_E, 60, 6, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_MPLS_3, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_VALID_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_TTL_OK_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IS_MPLS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_BOS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_MPLS_INNER_CONTROL_WORD_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IB_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IB_0, 1, 0xE, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_DEST_QP_E, 32, 24, 0},
         {FLEX_ACL_HW_KEY_BTH_OPCODE_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IB_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IB_1, 1, 0xE, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_PKEY_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_BTH_OPCODE_E, 48, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L3_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L3_0, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_DWORD_VALID_0_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_31_0_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L3_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L3_1, 1, 0xE, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_DWORD_VALID_1_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_LLC_VALID_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_39_32_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_63_40_E, 40, 24, 8},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L3_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L3_2, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_DWORD_VALID_2_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_79_64_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_95_80_E, 48, 16, 16},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L3_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L3_3, 1, 0xE, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_DWORD_VALID_3_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_SMPE_VALID_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_TAG_VALID_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_119_96_E, 32, 24, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_127_120_E, 56, 8, 24},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L3_4_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L3_4, 1, 0xE, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_DWORD_VALID_4_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_PCP_E, 1, 3, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_159_128_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L3_5_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L3_5, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_DWORD_VALID_5_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_TAG_VALID_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_ETHERNET_PAYLOAD_191_160_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L4_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L4_0, 1, 0xE, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E, 48, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L4_0_OPT_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L4_0_OPT, 1, 0xC, 0x1, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_OR_TCP_CONTROL_OR_ECN_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E, 48, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L4_0_SWAP_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L4_0_SWAP, 1, 0xC, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_L4_DESTINATION_PORT_E, 48, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L4_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L4_1, 1, 0xE, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E, 32, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L4_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L4_2, 1, 0xE, 0x3, 9, (flex_acl_key_block_item_t[9]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_TCP_CONTROL_E, 48, 6, 0},
         {FLEX_ACL_HW_KEY_TCP_ECN_E, 54, 3, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 57, 1, 0},
         {FLEX_ACL_HW_KEY_OR_TCP_CONTROL_OR_ECN_E, 58, 2, 0},
         {FLEX_ACL_HW_KEY_L4_TYPE_ENUM_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_IS_TCP_OPTION_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_L4_OK_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_L4_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_L4_3, 1, 0xE, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_L4_TYPE_EXTENDED_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_SPI_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_IP_L4_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_IP_L4_0, 1, 0xE, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_IP_DONT_FRAGMENT_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_IP_MORE_FRAGMENT_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENTED_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_IP_FRAGMENT_NOT_FIRST_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_IP_PROTO_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_TCP_CONTROL_E, 56, 6, 0},
         {FLEX_ACL_HW_KEY_OR_TCP_CONTROL_OR_ECN_E, 62, 2, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_L4_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_L4_0, 1, 0xE, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_INNER_L4_TYPE_EXTENDED_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_INNER_L4_SOURCE_PORT_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_INNER_L4_DESTINATION_PORT_E, 48, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_L4_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_L4_1, 1, 0xE, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_INNER_TCP_CONTROL_E, 32, 6, 0},
         {FLEX_ACL_HW_KEY_INNER_TCP_ECN_E, 38, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_IS_TCP_OPTION_E, 41, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_L4_OK_E, 42, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OK_E, 43, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_L4_TYPE_ENUM_E, 44, 2, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_INNER_L4_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_INNER_L4_2, 1, 0xE, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_INNER_L4_TYPE_EXTENDED_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_INNER_SPI_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_0, 1, 0xE, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_31_0_E, 32, 32, 1},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_1, 1, 0xE, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_TRAP_PRIO_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_IS_TRAPPED_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_63_32_E, 32, 32, 33},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_2, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_DISCARD_STATE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_IS_TRAPPED_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_95_64_E, 32, 32, 65},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_3, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_RX_CPU_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_127_96_E, 32, 32, 97},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_4_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_4, 1, 0xE, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_31_0_E, 32, 32, 1},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_5_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_5, 1, 0xE, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_TRAP_PRIO_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_IS_TRAPPED_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_63_32_E, 32, 32, 33},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_6_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_6, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_DISCARD_STATE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_IS_TRAPPED_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_95_64_E, 32, 32, 65},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_7_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_7, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_RX_CPU_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_127_96_E, 32, 32, 97},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_8_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_8, 1, 0xC, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_COLOR_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_159_128_E, 32, 32, 129},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_9_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_9, 1, 0xC, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_BUFF_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_191_160_E, 32, 32, 161},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_10_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_10, 1, 0xC, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_SWITCH_PRIO_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_223_192_E, 32, 32, 193},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_11_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_11, 1, 0x4, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_RX_LIST_HW_257_256_E, 0, 2, 257},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_257_256_E, 2, 2, 257},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_255_224_E, 32, 32, 225},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_11B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_11B, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_RX_LIST_HW_515_512_E, 0, 4, 513},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_255_224_E, 32, 32, 225},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_12_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_12, 1, 0xC, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_COLOR_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_159_128_E, 32, 32, 129},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_13_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_13, 1, 0xC, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_SWITCH_PRIO_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_191_160_E, 32, 32, 161},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_14_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_14, 1, 0xC, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_BUFF_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_223_192_E, 32, 32, 193},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_15_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_15, 1, 0x4, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_TX_LIST_HW_257_256_E, 0, 2, 257},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_257_256_E, 2, 2, 257},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_255_224_E, 32, 32, 225},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_15B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_15B, 1, 0x8, 0x3, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_TX_LIST_HW_515_512_E, 0, 4, 513},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_16_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_16, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_ETHERTYPE_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_287_256_E, 32, 32, 257},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_17_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_17, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_ETHERTYPE_E, 0, 4, 4},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_319_288_E, 32, 32, 289},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_18_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_18, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_ETHERTYPE_E, 0, 4, 8},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_351_320_E, 32, 32, 321},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_19_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_19, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_ETHERTYPE_E, 0, 4, 12},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_383_352_E, 32, 32, 353},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_20_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_20, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_415_384_E, 32, 32, 385},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_21_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_21, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 0, 4, 4},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_447_416_E, 32, 32, 417},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_22_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_22, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 0, 4, 8},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_479_448_E, 32, 32, 449},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_23_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_23, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_RX_LIST_HW_515_512_E, 0, 4, 513},
         {FLEX_ACL_HW_KEY_RX_LIST_HW_511_480_E, 32, 32, 481},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_24_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_24, 1, 0x8, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_L3_TYPE_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_287_256_E, 32, 32, 257},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_25_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_25, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_IP_PROTO_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_319_288_E, 32, 32, 289},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_26_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_26, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_IP_PROTO_E, 0, 4, 4},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_351_320_E, 32, 32, 321},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_27_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_27, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_383_352_E, 32, 32, 353},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_28_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_28, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E, 0, 4, 4},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_415_384_E, 32, 32, 385},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_29_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_29, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E, 0, 4, 8},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_447_416_E, 32, 32, 417},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_30_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_30, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_L4_SOURCE_PORT_E, 0, 4, 12},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_479_448_E, 32, 32, 417},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_PORT_LIST_31_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_PORT_LIST_31, 1, 0x8, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_TX_LIST_HW_515_512_E, 32, 32, 513},
         {FLEX_ACL_HW_KEY_TX_LIST_HW_511_480_E, 32, 32, 481},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_QOS_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_QOS_0, 1, 0xE, 0x3, 15, (flex_acl_key_block_item_t[15]) {
         {FLEX_ACL_HW_KEY_COLOR_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_RW_PCP_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_RW_DSCP_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_DSCP_E, 32, 6, 0},
         {FLEX_ACL_HW_KEY_ECN_E, 38, 2, 0},
         {FLEX_ACL_HW_KEY_PCP_E, 40, 3, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 43, 1, 0},
         {FLEX_ACL_HW_KEY_TAG_VALID_E, 44, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_TAG_VALID_E, 45, 1, 0},
         {FLEX_ACL_HW_KEY_VLAN_TAGGED_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 47, 1, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 48, 1, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 49, 1, 0},
         {FLEX_ACL_HW_KEY_BUFF_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_SWITCH_PRIO_E, 60, 4, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_QOS_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_QOS_1, 1, 0xE, 0x3, 18, (flex_acl_key_block_item_t[18]) {
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_PCP_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_DEI_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_DSCP_E, 32, 6, 0},
         {FLEX_ACL_HW_KEY_INNER_ECN_E, 38, 2, 0},
         {FLEX_ACL_HW_KEY_EXP_E, 40, 3, 0},
         {FLEX_ACL_HW_KEY_IS_MPLS_E, 43, 1, 0},
         {FLEX_ACL_HW_KEY_MPLS_ECN_E, 44, 2, 0},
         {FLEX_ACL_HW_KEY_RW_EXP_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_IP_OK_E, 47, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_EXP_E, 48, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_IS_MPLS_E, 51, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_MPLS_ECN_E, 52, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_PCP_E, 54, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_DEI_E, 57, 1, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_TAG_VALID_E, 58, 1, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_PCP_E, 59, 3, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_DEI_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_INNER_TAG_VALID_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_TUNNELS_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_TUNNELS_0, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_GRE_KEY_EXIST_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_GRE_KEY_E, 32, 24, 8},
         {FLEX_ACL_HW_KEY_VNI_E, 32, 24, 0},
         {FLEX_ACL_HW_KEY_GRE_KEY_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_TUNNELS_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_TUNNELS_1, 1, 0xE, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_NVE_TYPE_VECTOR_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_GRE_PROTOCOL_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_IP_PROTO_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E, 56, 3, 0},
         {FLEX_ACL_HW_KEY_GRE_KEY_EXIST_E, 59, 1, 0},
         {FLEX_ACL_HW_KEY_L3_TYPE_E, 60, 2, 0},
         {FLEX_ACL_HW_KEY_IP_OK_E, 62, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_TUNNELS_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_TUNNELS_2, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_IP_OK_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_GRE_KEY_E, 32, 24, 8},
         {FLEX_ACL_HW_KEY_VNI_E, 32, 24, 0},
         {FLEX_ACL_HW_KEY_NVE_TYPE_VECTOR_E, 56, 4, 0},
         {FLEX_ACL_HW_KEY_TUNNEL_TYPE_E, 60, 3, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MISC_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MISC_0, 1, 0x6, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_MAC_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_L4_PORTS_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_IP_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 3, 1, 15},
         {FLEX_ACL_HW_KEY_LAG_HASH_E, 32, 12, 0},
         {FLEX_ACL_HW_KEY_ECMP_HASH_E, 44, 12, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MISC_0B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MISC_0B, 1, 0x8, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 0, 1, 8},
         {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_L4_PORTS_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_SYMMETRIC_HASH_IP_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 3, 1, 15},
         {FLEX_ACL_HW_KEY_LAG_HASH_E, 32, 12, 0},
         {FLEX_ACL_HW_KEY_ECMP_HASH_E, 44, 12, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MISC_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MISC_1, 1, 0xE, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_IS_ELEPHANT_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_L4_PORT_RANGE_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_FREE_RUNNIG_CLOCK_MSB_E, 48, 16, 0},
         {FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_IS_ARN_E, 1, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MISC_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MISC_2, 1, 0x2, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_USER_TOKEN_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_IS_ROUTED_E, 53, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 54, 1, 15},
         {FLEX_ACL_HW_KEY_PACKET_TYPE_L2_E, 55, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MISC_2B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MISC_2B, 1, 0x4, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 0, 1, 8},
         {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_USER_TOKEN_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_IS_ROUTED_E, 54, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 55, 1, 15},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MISC_2C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MISC_2C, 1, 0x8, 0x3, 7, (flex_acl_key_block_item_t[7]) {
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 0, 2, 8},
         {FLEX_ACL_HW_KEY_DEFAULT_ROUTE_HIT_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_FDB_MISS_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_USER_TOKEN_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_IS_ROUTED_E, 54, 1, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 55, 1, 15},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MISC_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MISC_3, 1, 0xE, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_TRAP_PRIO_E, 0, 3, 0},
         {FLEX_ACL_HW_KEY_IS_TRAPPED_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_TRAP_ID_E, 52, 10, 0},
         {FLEX_ACL_HW_KEY_DISCARD_STATE_E, 62, 2, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MISC_4_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MISC_4, 1, 0x2, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_RX_LIST_TUNNEL_PORT_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_USER_TOKEN_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_RX_CPU_E, 55, 1, 0},
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MISC_4B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MISC_4B, 1, 0x4, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 0, 2, 7},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 2, 1, 15},
         {FLEX_ACL_HW_KEY_DMAC_IS_UC_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_USER_TOKEN_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_RX_CPU_E, 56, 1, 0},
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 57, 7, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_MISC_4C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_MISC_4C, 1, 0x8, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 0, 3, 7},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 3, 1, 15},
         {FLEX_ACL_HW_KEY_USER_TOKEN_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_TX_SYS_PORT_E, 57, 7, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_STATEFUL_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_STATEFUL_0, 1, 0x2, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 0, 1, 15},
         {FLEX_ACL_HW_KEY_IS_ELEPHANT_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_POLICER_STATE_E, 32, 12, 0},
         {FLEX_ACL_HW_KEY_PORT_USER_MEM_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 56, 8, 0},
         {FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E, 2, 2, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_STATEFUL_0B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_STATEFUL_0B, 1, 0x4, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 0, 1, 8},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 1, 1, 15},
         {FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_POLICER_STATE_E, 32, 12, 0},
         {FLEX_ACL_HW_KEY_PORT_USER_MEM_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_STATEFUL_0C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_STATEFUL_0C, 1, 0x8, 0x3, 6, (flex_acl_key_block_item_t[6]) {
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 0, 2, 8},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 2, 1, 15},
         {FLEX_ACL_HW_KEY_RX_CPU_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_POLICER_STATE_E, 32, 12, 0},
         {FLEX_ACL_HW_KEY_PORT_USER_MEM_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_STATEFUL_1B_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_STATEFUL_1B, 1, 0x4, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_PORT_USER_MEM_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_PHYSICAL_E, 51, 9, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_STATEFUL_1C_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_STATEFUL_1C, 1, 0x8, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_RX_LIST_HW_515_512_E, 0, 4, 513},
         {FLEX_ACL_HW_KEY_PORT_USER_MEM_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_RX_SYS_PORT_PHYSICAL_E, 51, 10, 0},
         {FLEX_ACL_HW_KEY_AR_PACKET_CLASS_E, 61, 2, 0},
         {FLEX_ACL_HW_KEY_RX_CPU_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_0_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_CUSTOM_0, 1, 0xE, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_0_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_1_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_2_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_3_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_0_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_1_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_2_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_3_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_1_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_CUSTOM_1, 1, 0xE, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_4_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_5_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_6_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_7_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_4_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_5_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_6_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_7_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_2_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_CUSTOM_2, 1, 0xE, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_8_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_9_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_10_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_11_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_8_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_9_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_10_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_11_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_3_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_CUSTOM_3, 1, 0xE, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_12_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_13_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_14_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_15_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_12_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_13_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_14_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_15_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_4_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_CUSTOM_4, 1, 0xE, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_16_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_17_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_18_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_19_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_16_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_17_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_18_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_19_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_5_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_CUSTOM_5, 1, 0xE, 0x3, 19, (flex_acl_key_block_item_t[19]) {
         {FLEX_ACL_HW_KEY_ALU_CARRY_FLAG_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_0_OFFSET_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTES_SET_1_OFFSET_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_FPP0_TOUCHED_E, 48, 1, 0},
         {FLEX_ACL_HW_KEY_FPP1_TOUCHED_E, 49, 1, 0},
         {FLEX_ACL_HW_KEY_FPP2_TOUCHED_E, 50, 1, 0},
         {FLEX_ACL_HW_KEY_FPP3_TOUCHED_E, 51, 1, 0},
         {FLEX_ACL_HW_KEY_FPP4_TOUCHED_E, 52, 1, 0},
         {FLEX_ACL_HW_KEY_FPP5_TOUCHED_E, 53, 1, 0},
         {FLEX_ACL_HW_KEY_FPP6_TOUCHED_E, 54, 1, 0},
         {FLEX_ACL_HW_KEY_FPP7_TOUCHED_E, 55, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_FPP0_TOUCHED_E, 56, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_FPP1_TOUCHED_E, 57, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_FPP2_TOUCHED_E, 58, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_FPP3_TOUCHED_E, 59, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_FPP4_TOUCHED_E, 60, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_FPP5_TOUCHED_E, 61, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_FPP6_TOUCHED_E, 62, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_FPP7_TOUCHED_E, 63, 1, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_FLEX2_CUSTOM_6_E] =
    {SXD_ACL_KEY_BLOCK_FLEX2_CUSTOM_6, 1, 0xC, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_20_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_21_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_22_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_VALID_23_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_20_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_21_E, 40, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_22_E, 48, 8, 0},
         {FLEX_ACL_HW_KEY_CUSTOM_BYTE_23_E, 56, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_MAC_0_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_MAC_0, 1, 0x10, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_DEI_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_31_0_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_MAC_1_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_MAC_1, 1, 0x10, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_L2_DMAC_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_INNER_DEI_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_SMAC_31_0_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_MAC_2_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_MAC_2, 1, 0x10, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_DEI_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_DMAC_47_32_E, 32, 16, 0},
         {FLEX_ACL_HW_KEY_SMAC_47_32_E, 48, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_ETHERTYPE_0_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_ETHERTYPE_0, 1, 0x10, 0x3, 1, (flex_acl_key_block_item_t[1]) {
         {FLEX_ACL_HW_KEY_ETHERTYPE_E, 32, 16, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_VLAN_0_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_VLAN_0, 1, 0x10, 0x3, 8, (flex_acl_key_block_item_t[8]) {
         {FLEX_ACL_HW_KEY_INNER_VLAN_VALID_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_INNER_PCP_E, 1, 3, 0},
         {FLEX_ACL_HW_KEY_VLAN_ID_E, 32, 12, 0},
         {FLEX_ACL_HW_KEY_VLAN_ETHER_TYPE_E, 44, 2, 0},
         {FLEX_ACL_HW_KEY_VLAN_VALID_E, 46, 1, 0},
         {FLEX_ACL_HW_KEY_PCP_E, 47, 3, 0},
         {FLEX_ACL_HW_KEY_INNER_VLAN_ID_E, 50, 12, 0},
         {FLEX_ACL_HW_KEY_INNER_VLAN_ETHER_TYPE_E, 62, 2, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_TUNNELS_0_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_TUNNELS_0, 1, 0x10, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_NVE_TYPE_VECTOR_E, 0, 4, 0},
         {FLEX_ACL_HW_KEY_MACSEC_GRE_KEY_0_7_E, 24, 8, 0},
         {FLEX_ACL_HW_KEY_MACSEC_VXLAN_GPE_NEXT_PROTO_E, 32, 8, 0},
         {FLEX_ACL_HW_KEY_MACSEC_VNI_GRE_KEY_8_31_E, 42, 24, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_MACSEC_0_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_MACSEC_0, 1, 0x10, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_VALID_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_ES_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_SC_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_SHORT_LEN_ZERO_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_0_31_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_MACSEC_1_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_MACSEC_1, 1, 0x10, 0x3, 5, (flex_acl_key_block_item_t[5]) {
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_VALID_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_ES_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_SC_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_SHORT_LEN_ZERO_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_32_63_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_MACSEC_2_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_MACSEC_2, 1, 0x10, 0x3, 3, (flex_acl_key_block_item_t[3]) {
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_AN_E, 0, 2, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_VALID_E, 2, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_SCI_32_63_E, 32, 32, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_MACSEC_3_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_MACSEC_3, 1, 0x10, 0x3, 2, (flex_acl_key_block_item_t[2]) {
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_VALID_E, 3, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_SHORT_LEN_E, 48, 8, 0},
     }, },
    [FLEX_ACL_KEY_BLOCK_MACSEC_MACSEC_4_E] =
    {SXD_ACL_KEY_BLOCK_MACSEC_MACSEC_4, 1, 0x10, 0x3, 4, (flex_acl_key_block_item_t[4]) {
         {FLEX_ACL_HW_KEY_MACSEC_SECY_VALID_E, 0, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_VALID_E, 1, 1, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECTAG_AN_E, 2, 2, 0},
         {FLEX_ACL_HW_KEY_MACSEC_SECY_E, 32, 16, 0},
     }, },
};
/************************************************
 *  Local function declarations
 ***********************************************/
/************************************************
 *  Function implementations
 ***********************************************/
