/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef FLEX_ACL_HW_DB_H_
#define FLEX_ACL_HW_DB_H_


#include "acl/flex_acl_db.h"
#include "acl/flex_acl.h"
#include "acl/flex_acl_hw_common.h"
#include "acl/flex_acl_hw_cb.h"

#include <sx/sxd/sxd_emad_acl.h>


#include <complib/cl_types.h>
#include <complib/cl_list.h>
#include <complib/cl_map.h>
#include "../include/sx/sdk/sx_acl.h"
#include "../include/sx/sdk/sx_flex_acl.h"
#include "flex_acl_hw_common.h"
#include <kvd/kvd_linear_manager.h>
#include "flex_acl_pool_map.h"

/************************************************
 *  Local Defines
 ***********************************************/
#define FLEX_ACL_HW_ACTIONS_PER_RULE_MIN SX_FLEX_ACL_FLEX_ACTION_TYPE_LAST
#define FLEX_ACL_HW_ACTIONS_PER_RULE_MAX 1024
#define FLEX_ACL_MAX_ACTIONS_PER_SET     3

#define FLEX_ACL_HW_BINDING_POINT_MIN 255
#define FLEX_ACL_HW_BINDING_POINT_MAX CL_POOL_UNLIMITED_MAX_SIZE

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/* Used to store the the action set written to extension kvd using PEFA register. */
typedef struct {
    uint32_t                   actions_count;
    flex_acl_hw_action_t       actions[FLEX_ACL_MAX_ACTIONS_PER_SET];
    uint8_t                    commit;
    kvd_linear_manager_index_t kvd_index;
    kvd_linear_manager_index_t kvd_next_index;
    boolean_t                  is_last;
    boolean_t                  is_first;
    sx_acl_region_id_t         region_id;
    sxd_goto_set_action_t      goto_action;
} flex_acl_hw_db_kvd_action_set_t;

/* Used to store the the action set written to the rule itself using PTCE register. */
typedef struct {
    uint32_t                   actions_count;
    flex_acl_hw_action_t       actions[FLEX_ACL_MAX_ACTIONS_PER_SET];
    uint8_t                    commit;
    kvd_linear_manager_index_t kvd_index;
    sxd_goto_set_action_t      goto_action;
} flex_acl_hw_db_register_action_set_t;

/* Stores HW action set that was written to register within the rule. Also stores pointer to related rule. */
typedef struct {
    cl_list_t                            kvd_action_set_list;
    uint32_t                             kvd_action_set_count;
    kvd_linear_manager_handle_t          kvd_handle;
    uint32_t                             sum_of_actions;
    flex_acl_hw_db_register_action_set_t action_set;
    flex_acl_db_flex_rule_t             *related_rule;
} flex_acl_hw_db_action_set_t;

/* The HW action set db is helps to handle actions manipulations. The structures describes HW layout
 * the action should be created by user and added to a SW rule as ptr. At rule destruction, user should destroy action set also*/
sx_status_t flex_acl_hw_db_action_set_create(flex_acl_hw_db_register_action_set_t *action_set,
                                             flex_acl_db_flex_rule_t              *rule_ptr,
                                             void                               ** handle);
/* Destroy the referenced by handle hw action set and all inner structures.*/
sx_status_t flex_acl_hw_db_action_set_destroy(void* handle);
sx_status_t flex_acl_hw_db_get_register_action_set(void* handle, flex_acl_hw_db_register_action_set_t **action_set_p);
sx_status_t flex_acl_hw_db_tail_add_kvd_action_set(void* handle, flex_acl_hw_db_kvd_action_set_t *kvd_action_set);
sx_status_t flex_acl_hw_db_get_kvd_action_set(void                            * handle,
                                              uint32_t                          action_set_idx,
                                              flex_acl_hw_db_kvd_action_set_t** kvd_action_set);
sx_status_t flex_acl_hw_db_get_kvd_action_set_list(void* handle, const cl_list_t **kvd_action_set_list);
sx_status_t flex_acl_hw_db_get_kvd_action_set_count(void* handle, uint32_t *action_sets_count);
sx_status_t flex_acl_hw_db_get_sum_of_actions(void* handle, uint32_t *sum_of_actions);


/* the struct defines entry for storing key blocks array */
typedef struct flex_acl_hw_db_key_block_entry {
    uint32_t           idx;
    sx_acl_key_block_e key_blocks[SPECTRUM2_ACL_KEY_BLOCKS_MAX];
    uint32_t           count;
    boolean_t          allocated;
} flex_acl_hw_db_key_blocks_entry_t;

/* structure defines db of region attributes */
typedef struct flex_acl_hw_db_key_block_pool {
    flex_acl_hw_db_key_blocks_entry_t* entries;
    cl_list_t                          free_pool;
    uint32_t                           count;
} flex_acl_hw_db_key_block_pool_t;

sx_status_t flex_acl_hw_db_set_key_blocks(sx_acl_key_block_e* key_blocks, uint32_t count, uint32_t* handle);
sx_status_t flex_acl_hw_db_get_key_blocks(uint32_t handle, sx_acl_key_block_e** key_blocks, uint32_t *count);
sx_status_t flex_acl_hw_db_remove_key_blocks(uint32_t handle);


typedef struct flex_acl_hw_reg_cb {
    flex_acl_hw_rule_write_hw_cb              rule_hw_cb;
    flex_acl_hw_region_write_hw_cb            region_hw_cb;
    flex_acl_hw_move_rule_write_hw_cb         move_rule_hw_cb;
    flex_acl_hw_acl_write_hw_cb               acl_register_cb;
    flex_acl_hw_activity_read_hw_cb           activity_register_cb;
    flex_acl_hw_dump_activity_cb              activity_dump_hw_cb;
    flex_acl_hw_action_write_hw_cb            action_hw_cb;
    flex_acl_hw_prio_change_hw_cb             prio_change_hw_cb;
    flex_acl_hw_config_uc_tunnel_pbs_write_cb config_uc_tunnel_pbs_write_cb;
    flex_acl_hw_activity_bulk_dump_cb         activity_bulk_dump_hw_cb;
    flex_acl_hw_write_global_mask_cb          global_mask_hw_cb;
    flex_acl_hw_lookup_region_write_hw_cb     lookup_region_hw_cb;
} flex_acl_hw_reg_cb_t;

typedef struct flex_acl_hw_db_region_attribs {
    uint8_t              region_info[SX_DEV_NUM_MAX][SXD_TCAM_REGION_INFO_SIZE_BYTES];
    sx_acl_size_t        hw_size[SX_DEV_NUM_MAX];           /* one hw size for all devices */
    flex_acl_hw_reg_cb_t write_reg_cb;
    boolean_t            free_unused_memory; /* If TRUE, module will attempt to free unused memory
                                              *  from system ACL regions when region allocation fails
                                              *  due to NO_RESOURCES error */
    boolean_t bulk_write;                    /* Used for phoenix to indicate writing the atcam in bulk */
} flex_acl_hw_db_region_attribs_t;

/* structure that defines entry of free pool */
typedef struct flex_acl_hw_db_region_attribs_entry {
    uint32_t                        idx;
    flex_acl_hw_db_region_attribs_t attribs;
    boolean_t                       allocated;
} flex_acl_hw_db_region_attribs_entry_t;

/* structure defines db of region attributes */
typedef struct flex_acl_hw_db_region_attribs_pool {
    flex_acl_hw_db_region_attribs_entry_t *entries;
    cl_list_t                              free_pool;
    uint32_t                               count;
} flex_acl_hw_db_region_attribs_pool_t;

typedef enum flex_acl_hw_db_binding_type {
    FLEX_ACL_HW_BINDING_PORT_E,
    FLEX_ACL_HW_BINDING_VLAN_E,
    FLEX_ACL_HW_BINDING_RIF_E,
    FLEX_ACL_HW_BINDING_MIN_E = FLEX_ACL_HW_BINDING_PORT_E,
    FLEX_ACL_HW_BINDING_MAX_E = FLEX_ACL_HW_BINDING_RIF_E,
} flex_acl_hw_db_binding_type_e;

typedef struct flex_acl_hw_db_binding_port {
    sx_port_log_id_t           log_port;
    sx_acl_direction_t         direction;
    flex_acl_bind_attribs_id_t bind_id;
} flex_acl_hw_db_binding_port_t;

typedef struct flex_acl_hw_db_binding_vlan {
    sx_vlan_id_t        vlan_id;
    sx_acl_vlan_group_t vlan_group_id;
} flex_acl_hw_db_binding_vlan_t;

typedef struct flex_acl_hw_db_binding_rif {
    sx_rif_id_t                rif_id;
    sx_acl_direction_t         direction;
    flex_acl_bind_attribs_id_t bind_id;
} flex_acl_hw_db_binding_rif_t;

typedef struct flex_acl_hw_db_binding_data {
    flex_acl_hw_db_binding_type_e binding_type;
    boolean_t                     bind;
    union {
        flex_acl_hw_db_binding_port_t port;
        flex_acl_hw_db_binding_vlan_t vlan;
        flex_acl_hw_db_binding_rif_t  rif;
    } data;
} flex_acl_hw_db_binding_data_t;

typedef struct flex_acl_hw_db_binding_entry {
    cl_pool_item_t                pool_item;
    cl_map_item_t                 map_item;
    flex_acl_hw_db_binding_data_t binding_data;
} flex_acl_hw_db_binding_entry_t;

typedef struct flex_acl_hw_binding {
    cl_qmap_t  port_map;
    cl_qmap_t  vlan_map;
    cl_qmap_t  rif_map;
    cl_qpool_t entry_pool;
} flex_acl_hw_db_binding_t;

typedef struct flex_acl_hw_acl_drop_data_db_table_entry {
    cl_pool_item_t               pool_item;
    cl_fmap_item_t               fmap_item;
    cl_list_item_t              *usr_idx_list_item_p;            /* pointer to Free Index List Item */
    sx_acl_pkt_drop_attributes_t acl_drop_attr;              /* ACL Attr Item*/
} flex_acl_hw_db_acl_drop_data_item_t;

typedef struct flex_acl_hw_db_acl_drop_trap_usr_idx {
    cl_pool_item_t pool_item;
    cl_list_item_t list_item;
    uint32_t       acl_drop_usridx;
} flex_acl_hw_db_acl_drop_trap_usr_idx_item_t;

typedef struct flex_acl_db_acl_drop_data_db_entry {
    cl_qpool_t acl_drop_data_pool;
    cl_fmap_t  acl_drop_data_fmap;              /* Stores the acl drop rule attributes */
    cl_qpool_t acl_drop_usridx_pool;
    cl_qlist_t acl_drop_usridx_list;            /* Stores the user index to put as the acl drop trap id */
} flex_acl_hw_db_acl_drop_data_fmap_t;
/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t flex_acl_hw_db_set_region_attributes(flex_acl_hw_db_region_attribs_t *region_attributes, uint32_t *handle);
sx_status_t flex_acl_hw_db_get_region_attributes(uint32_t handle, flex_acl_hw_db_region_attribs_t **region_attributes);
sx_status_t flex_acl_hw_db_remove_region_attributes(uint32_t handle);
sx_status_t flex_acl_hw_db_set_region_bulk_write(sx_acl_region_id_t region_id, boolean_t bulk_write);


/* handles db that helps to manage given by managers handles*/
sx_status_t flex_acl_hw_db_kvd_add_entry(kvd_linear_manager_handle_t  handle,
                                         flex_acl_hw_db_action_set_t *hw_action_set);
sx_status_t flex_acl_hw_db_kvd_remove_entry(kvd_linear_manager_handle_t  handle,
                                            flex_acl_hw_db_action_set_t *hw_action_set);
sx_status_t flex_acl_hw_db_kvd_action_ref_get(kvd_linear_manager_handle_t   handle,
                                              flex_acl_hw_db_action_set_t **hw_action_set);

/* Structure that stores kvd index pointer in action set and flag if action set is head
 * uses for get kvd action set structure or register action set structure
 */
typedef struct {
    kvd_linear_manager_index_t* kvd_index_ptr;
    boolean_t                   is_head;
} flex_acl_hw_db_kvd_index_ref;

sx_status_t flex_acl_hw_db_trap_id_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_trap_id_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_trap_id_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list);

sx_status_t flex_acl_hw_db_mirror_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_mirror_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_mirror_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list);

sx_status_t flex_acl_hw_db_tunnel_decap_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_tunnel_decap_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_tunnel_decap_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list);

sx_status_t flex_acl_hw_db_policer_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_policer_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_policer_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list);

sx_status_t flex_acl_hw_db_counter_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_counter_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_counter_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list);

sx_status_t flex_acl_hw_db_pbs_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_pbs_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_pbs_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list);

sx_status_t flex_acl_hw_db_pbilm_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_pbilm_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_pbilm_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list);

sx_status_t flex_acl_hw_db_mc_container_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_mc_container_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_mc_container_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list);

sx_status_t flex_acl_hw_db_ecmp_container_add_entry(uint64_t handle, boolean_t is_head, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_ecmp_container_remove_entry(uint64_t handle, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_ecmp_container_index_ref_list_get(uint64_t handle, cl_list_t** kvd_index_ref_list);

/* Initialization functions for all db*/
sx_status_t flex_acl_hw_db_init(uint32_t num_of_regions);
sx_status_t flex_acl_hw_db_deinit();

sx_status_t flex_acl_hw_db_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t flex_acl_hw_db_get_action_from_rule(flex_acl_db_flex_rule_t *rule, sxd_flex_acl_action_type_t action_type,
                                                boolean_t *found,  flex_acl_hw_action_t **action);
sx_status_t flex_acl_hw_db_get_matching_hw_action_from_rule(flex_acl_db_flex_rule_t   *rule,
                                                            sxd_flex_acl_action_type_t action_type,
                                                            boolean_t                 *found_p,
                                                            flex_acl_hw_action_t     **action_pp);

sx_status_t flex_acl_hw_db_hw_action_list_init(hw_action_list_t *hw_action_list_p);
sx_status_t flex_acl_hw_db_hw_action_list_deinit(hw_action_list_t *hw_action_list_p);
sx_status_t flex_acl_hw_db_hw_action_list_insert_tail(hw_action_list_t        *hw_action_list_p,
                                                      flex_acl_hw_action_t    *hw_action_p,
                                                      hw_action_list_entry_t **hw_action_list_entry_pp);
sx_status_t flex_acl_hw_db_hw_action_list_move_2tail(hw_action_list_t       *hw_action_list_p,
                                                     hw_action_list_entry_t *hw_action_list_entry_p);
boolean_t flex_acl_hw_db_hw_action_list_is_empty(hw_action_list_t *hw_action_list_p);
sx_status_t flex_acl_hw_db_hw_action_list_remove_and_next(hw_action_list_t        *hw_action_list_p,
                                                          hw_action_list_entry_t **hw_action_list_entry_pp);
sx_status_t flex_acl_hw_db_hw_action_list_next(hw_action_list_t        *hw_action_list_p,
                                               hw_action_list_entry_t **hw_action_list_entry_pp);
sx_status_t flex_acl_hw_db_hw_action_list_head(hw_action_list_t        *hw_action_list_p,
                                               hw_action_list_entry_t **hw_action_list_entry_pp);

sx_status_t flex_acl_hw_db_handle_late_binding(uint64_t                       key,
                                               flex_acl_hw_db_binding_data_t *data_p);
sx_status_t flex_acl_hw_db_get_late_binding_map(flex_acl_hw_db_binding_type_e type,
                                                cl_qmap_t                   **binding_map_pp);
void flex_acl_hw_db_remove_late_binding_entry(flex_acl_hw_db_binding_entry_t *binding_entry_p);
sx_status_t flex_acl_hw_db_acl_drop_trap_data_db_size_get(uint32_t *db_size_p);
sx_status_t flex_acl_hw_db_acl_drop_trap_data_db_edit(sx_acl_pkt_drop_attributes_t *old_acl_data,
                                                      sx_acl_pkt_drop_attributes_t *new_acl_data);
sx_status_t flex_acl_hw_db_acl_drop_trap_data_db_add(sx_acl_pkt_drop_attributes_t *acl_drop_data);
sx_status_t flex_acl_hw_db_acl_drop_trap_data_db_del(sx_acl_pkt_drop_attributes_t acl_drop_data);
sx_status_t flex_acl_hw_db_acl_drop_trap_data_db_get(sx_acl_pkt_drop_attributes_t *acl_drop_data);
sx_status_t flex_acl_hw_db_acl_drop_relocate_db_add_entry(uint64_t  handle,
                                                          boolean_t is_head,
                                                          uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_acl_drop_relocate_db_del_entry(uint64_t handle, uint32_t *kvd_index_ptr);
sx_status_t flex_acl_hw_db_acl_drop_relocate_db_ref_list_get(uint64_t    handle,
                                                             cl_list_t** kvd_index_ref_list);
uint32_t flex_acl_hw_db_acl_drop_relocate_db_size_get(void);

void flex_acl_hw_db_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
void flex_acl_hw_db_debug_dump_actions_detailed(dbg_dump_params_t *dbg_dump_params_p);
void flex_acl_hw_db_debug_dump_action_sets(dbg_dump_params_t *dbg_dump_params_p);
void flex_acl_hw_db_debug_dump_keys(dbg_dump_params_t *dbg_dump_params_p);
void flex_acl_hw_db_debug_late_binding_map(dbg_dump_params_t *dbg_dump_params_p);

#endif /* ifndef FLEX_ACL_HW_DB_H_ */
