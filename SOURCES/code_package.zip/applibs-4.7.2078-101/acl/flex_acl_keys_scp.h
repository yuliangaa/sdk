/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLEX_ACL_KEYS_SCP_H_INCL__
#define __FLEX_ACL_KEYS_SCP_H_INCL__

#include "flex_acl_common.h"

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/
#define ACL_STAGE_FLEX_MAX_KEY_BLOCKS   (6)
#define ACL_STAGE_FLEX2_MAX_KEY_BLOCKS  (12)
#define ACL_STAGE_MACSEC_MAX_KEY_BLOCKS (12)

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct {
    uint32_t         hw_keys_cnt;
    sx_acl_hw_key_e *hw_keys;
} flex_acl_key_map_data_t;

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t flex_acl_scp_init(acl_stage_e acl_stage);
sx_status_t flex_acl_scp_calc(acl_stage_e         acl_stage,
                              sx_acl_hw_key_e    *keys,
                              uint32_t            keys_count,
                              sx_acl_key_block_e *key_blocks,
                              uint32_t           *key_blocks_count,
                              boolean_t           is_symmetric,
                              boolean_t           do_static);

sx_status_t flex_acl_get_hw_keys(acl_stage_e     acl_stage,
                                 sx_acl_key_t    keys[],
                                 uint32_t        keys_count,
                                 sx_acl_hw_key_e hw_keys[],
                                 uint32_t       *hw_key_cnt);

sx_status_t flex_acl_scp_calc_greedy(acl_stage_e         acl_stage,
                                     sx_acl_hw_key_e    *keys,
                                     uint32_t            keys_count,
                                     sx_acl_key_block_e *key_blocks,
                                     uint32_t           *key_blocks_count,
                                     boolean_t           is_symmetric);


#endif /* ifndef __FLEX_ACL_KEYS_SCP_H_INCL__ */
