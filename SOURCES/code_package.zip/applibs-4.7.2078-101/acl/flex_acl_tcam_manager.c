/*
 * Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sx/sdk/sx_types.h"
#include "utils/sx_mem.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "acl/flex_acl_tcam_manager.h"

#undef  __MODULE__
#define __MODULE__ ACL

/************************************************
 *  Local Defines
 ***********************************************/
#define TCAM_CLIENTS_MAX 10

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/
typedef struct flex_acl_tcam_manager_client_data {
    boolean_t                              registered;
    flex_acl_tcam_manager_handle_t         handle;
    flex_acl_tcam_manager_free_unused_cb_t free_unused_cb;
    void                                  *free_unused_cb_context;
} flex_acl_tcam_manager_client_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static flex_acl_tcam_manager_client_data_t tcam_clients_db[TCAM_CLIENTS_MAX];

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
static uint32_t __handle_to_index(flex_acl_tcam_manager_handle_t handle)
{
    return handle - 1;
}

static flex_acl_tcam_manager_handle_t __index_to_handle(uint32_t idx)
{
    return idx + 1;
}

sx_status_t flex_acl_tcam_manager_init(void)
{
    SX_MEM_CLR_BUF(tcam_clients_db, sizeof(tcam_clients_db));
    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_tcam_manager_client_register(flex_acl_tcam_manager_client_params_t *client_params,
                                                  flex_acl_tcam_manager_handle_t        *ret_handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    i = 0;
    boolean_t   found = FALSE;

    SX_LOG_ENTER();

    if (utils_check_pointer(client_params, "client_params")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(ret_handle, "ret_handle")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    for (i = 0; i < TCAM_CLIENTS_MAX; i++) {
        if (!tcam_clients_db[i].registered) {
            *ret_handle = i + 1;
            tcam_clients_db[i].registered = TRUE;
            if (client_params->free_unused_cb) {
                tcam_clients_db[i].free_unused_cb = client_params->free_unused_cb;
                tcam_clients_db[i].free_unused_cb_context = client_params->free_unused_cb_context;
            }
            found = TRUE;
            break;
        }
    }

    if (!found) {
        err = SX_STATUS_NO_RESOURCES;
        SX_LOG_ERR("No free handles left in flex-ACL TCAM manager DB\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t flex_acl_tcam_manager_client_unregister(flex_acl_tcam_manager_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    idx = 0;

    SX_LOG_ENTER();

    if ((handle == FLEX_ACL_TCAM_MANAGER_INVALID_HANDLE) || (handle > TCAM_CLIENTS_MAX)) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Invalid handle %u given\n", handle);
        goto out;
    }

    idx = __handle_to_index(handle);
    if (!tcam_clients_db[idx].registered) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Handle %u is not registered\n", handle);
        goto out;
    }

    SX_MEM_CLR(tcam_clients_db[idx]);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t flex_acl_tcam_manager_free_unused_entries(flex_acl_tcam_manager_handle_t calling_handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    calling_idx = 0;
    uint32_t    idx = 0;

    SX_LOG_ENTER();

    if (calling_handle > TCAM_CLIENTS_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Invalid handle %u given\n", calling_handle);
        goto out;
    }

    calling_idx = (calling_handle == FLEX_ACL_TCAM_MANAGER_INVALID_HANDLE) ?
                  TCAM_CLIENTS_MAX : __handle_to_index(calling_handle);

    for (idx = 0; idx < TCAM_CLIENTS_MAX; idx++) {
        if ((calling_idx != idx) &&
            (tcam_clients_db[idx].free_unused_cb)) {
            err = tcam_clients_db[idx].free_unused_cb(__index_to_handle(idx),
                                                      tcam_clients_db[idx].free_unused_cb_context);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Free unused callback failed for index %u, err = [%s]\n",
                           idx, sx_status_str(err));
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}
