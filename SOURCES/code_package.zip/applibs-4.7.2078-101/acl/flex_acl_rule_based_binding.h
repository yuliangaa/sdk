/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLEX_ACL_RULE_BASED_BINDING_H_INCL__
#define __FLEX_ACL_RULE_BASED_BINDING_H_INCL__


/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t flex_acl_rule_based_binding_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t flex_acl_rule_based_binding_init();
sx_status_t flex_acl_rule_based_binding_deinit();
sx_status_t flex_acl_rule_based_binding_rules_set(const sx_access_cmd_t       cmd,
                                                  const sx_acl_rbb_rule_id_t *rules_id_list_p,
                                                  const uint32_t              rules_id_cnt);
sx_status_t flex_acl_rule_based_binding_bind_set(const sx_access_cmd_t               cmd,
                                                 const sx_acl_rbb_rule_id_t          rule_id,
                                                 const sx_acl_rbb_classifier_attr_t *rule_classifier_p,
                                                 const sx_acl_id_t                   group_id);
sx_status_t flex_acl_rule_based_binding_bind_get(const sx_access_cmd_t         cmd,
                                                 const sx_acl_rbb_rule_id_t    rule_id,
                                                 sx_acl_rbb_classifier_attr_t *rule_classifier_p,
                                                 sx_acl_id_t                  *group_id_p);
sx_status_t flex_acl_rule_based_binding_rif_group_set(const sx_access_cmd_t        cmd,
                                                      const sx_rif_id_t           *rif_id_p,
                                                      const uint32_t               rif_count,
                                                      const sx_acl_rbb_direction_e direction,
                                                      const sx_acl_rbb_rif_group_e rif_group);
sx_status_t flex_acl_rule_based_binding_rif_group_get(const sx_access_cmd_t        cmd,
                                                      sx_rif_id_t                 *rif_id_p,
                                                      uint32_t                    *rif_count_p,
                                                      const sx_acl_rbb_direction_e direction,
                                                      const sx_acl_rbb_rif_group_e rif_group);
sx_status_t flex_acl_rule_based_binding_port_group_set(const sx_access_cmd_t         cmd,
                                                       const sx_port_log_id_t       *log_port_p,
                                                       const uint32_t                port_count,
                                                       const sx_acl_rbb_direction_e  direction,
                                                       const sx_acl_rbb_port_group_e port_group);
sx_status_t flex_acl_rule_based_binding_port_group_get(const sx_access_cmd_t         cmd,
                                                       sx_port_log_id_t             *log_port_p,
                                                       uint32_t                     *port_count_p,
                                                       const sx_acl_rbb_direction_e  direction,
                                                       const sx_acl_rbb_port_group_e port_group);
sx_status_t flex_acl_rule_based_binding_group_update(const sx_acl_id_t                group_id,
                                                     const flex_acl_bind_attribs_id_t bind_attribs_id,
                                                     const sx_acl_direction_t         direction,
                                                     const sx_acl_rbb_rule_offset_e   offset);
sx_status_t flex_acl_rule_based_binding_device_ready(boolean_t is_issu);
sx_status_t flex_acl_rule_based_binding_port_delete_update(const sx_port_log_id_t log_port);
sx_status_t flex_acl_rule_based_binding_rif_delete_update(const sx_rif_id_t rif_id);
sx_status_t flex_acl_rule_based_binding_issu_set();
void flex_acl_rule_based_binding_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
#endif /* ifndef __FLEX_ACL_RULE_BASED_BINDING_H_INCL__ */
