/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/cl_mem.h>
#include "acl/acl.h"

/************************************************
*  Global variables
************************************************/
acl_cb_t *g_acl_cb = NULL;


/************************************************
 *  Local variables
 ***********************************************/
/************************************************
 *  Local function declarations
 ***********************************************/
/************************************************
*  Function implementations
************************************************/
acl_cb_t* acl_get_cb(void)
{
    CL_ASSERT(g_acl_cb != NULL);
    return g_acl_cb;
}

void acl_set_cb(acl_cb_t* cb)
{
    CL_ASSERT(cb != NULL);
    g_acl_cb = cb;
}
