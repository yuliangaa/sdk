/*
 * Copyright (C) 2015-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef FLEX_ACL_POOL_MAP_H_
#define FLEX_ACL_POOL_MAP_H_

#include <sx_api/sx_api_internal.h>
#include <complib/cl_types.h>
#include <complib/cl_list.h>
#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <complib/cl_map.h>

#ifdef FLEX_ACL_POOL_MAP_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#endif

/************************************************
 *  Macros
 ***********************************************/
/* Used to determine if a rule object should be saved in an object map in addition to being saved in a list.
 * If the amount of rules with the same object is equal or bigger than the threshold,
 * insert the object into the object map as well */
#define OBJ_LIST_THRESHOLD 20

/************************************************
 *  Type definitions
 ***********************************************/

/* Generic structure that stores handler connected with a user object. The user should provide function for object
 * creation and destroy, INIT_SIZE and GROW_SIZE of the pool.
 * The structure holds pool of allocated entries and can store them in the map with key created from handler.
 * If needed handle allocated, the pool_map stores provided object in list, so many objects can be associated with
 * one handle
 */
/* At initialization should be provided functions for object creation, destruction and user objects
 * compare function to find object in the list
 * */
typedef sx_status_t (*obj_create_fn_t)(void **p_object, void *context);
typedef void (*obj_destroy_fn_t)(void *const p_object, void *context);
typedef boolean_t (*obj_compare_fn_t)(void* obj, void* other_obj);
/* a non-mandatory function.
 * Used to return a hash of the object to be used as a key when inserting the object into an object map. */
typedef uint64_t (*obj_hash_fn_t)(void* obj, uint64_t handle);

typedef struct {
    cl_pool_item_t pool_item;
    cl_map_item_t  map_item;
    uint64_t       handle;
    cl_list_t      obj_list;
    /* Used to store objects when the same object is used in multiple rules.
     * The object map is used when removing objects from a large list to avoid iterating over the whole list for every entry removed.
     * The map stores pointers to the object list */
    cl_map_t *obj_map;
} flex_acl_pool_map_entry_t;

typedef struct {
    cl_qpool_t       pool;
    uint32_t         pool_size;         /* Free entries in the pool */
    cl_qmap_t        map;               /* map storing ALL active entries*/
    uint32_t         map_count;         /* actual count of entries in map */
    obj_create_fn_t  obj_create_func;   /* function to create user object*/
    obj_destroy_fn_t obj_destroy_func;  /* function to destroy user object */
    obj_compare_fn_t obj_compare_func;
    obj_hash_fn_t    obj_hash_func;     /* function that returns a hash of the object to be used as a key in the object map, non-mandatory field */
} flex_acl_pool_map_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t flex_acl_pool_map_init(flex_acl_pool_map_t* self,
                                   obj_create_fn_t obj_crate_func,
                                   obj_destroy_fn_t obj_destroy_func,
                                   obj_compare_fn_t obj_compare_func,
                                   obj_hash_fn_t obj_hash_func,
                                   uint32_t min_size, uint32_t max_size, uint32_t grow_size);
sx_status_t flex_acl_pool_map_deinit(flex_acl_pool_map_t* self);

/* adds entry to the map. If the entry already exist, simply adds user object to list of user objects*/
sx_status_t flex_acl_pool_map_add_entry(flex_acl_pool_map_t *self, uint64_t handle, void* obj_to_store);

/* remove specified by obj object from object list in specified by handle map entry. If list became empty,
 * removes item from map and return it to pool */
sx_status_t flex_acl_pool_map_remove_entry(flex_acl_pool_map_t *self, uint64_t handle, void* obj);
/* get list of stored by user objects */
sx_status_t flex_acl_pool_map_object_list_get(flex_acl_pool_map_t* self, uint64_t handle, cl_list_t** obj_list);
uint32_t flex_acl_pool_map_size(flex_acl_pool_map_t* self);
typedef sx_status_t (*pool_map_apply_on_each_p_fn)(void* list_object, void* context);
sx_status_t flex_acl_pool_map_for_each(flex_acl_pool_map_t *self, pool_map_apply_on_each_p_fn func_p, void* context);


#endif /* POOL_MAP_H_ */
