/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#undef  __MODULE__
#define __MODULE__ ACL

#include <complib/sx_log.h>
#include "ethl2/fdb_common.h"
#include "ethl2/topo.h"
#include "ethl2/port_db.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "flex_acl_db.h"
#include "flex_acl_binding.h"
#include "flex_acl_rule_based_binding.h"
#include "ethl3/router_common.h"
#include "ethl2/port_uc_route.h"

/************************************************
 *  Macros
 ***********************************************/

#define RBB_DIRECTION_NUM (SX_ACL_RBB_DIRECTION_LAST_E)
#define RBB_GROUPS_MAX    (4)              /* Should be the maximum groups in a direction */

#define RBB_DEFAULT_GROUP (0)              /* This group will be used to store all rifs/ports
                                            *  that were not explicitly set to one of the other groups by the user (1-3) */
#define RBB_HW_GROUP(group) ((group) + 1)  /* HW group 0 is reserved for our default/don't care group. The user's
                                            *  group are 1-3 in the HW and 0-2 logically */

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct {
    boolean_t                    valid;
    sx_acl_id_t                  group_id;          /* Will be set to FLEX_ACL_INVALID_ACL_ID when not bound */
    flex_acl_bind_attribs_id_t   bound_attribs_id;  /* Will be set to FLEX_ACL_INVALID_BIND_ATTRIBS_ID when bound to empty group */
    sx_acl_rbb_classifier_attr_t classifier;
} rbb_rule_info_t;

/************************************************
**  Global variables
************************************************/
extern boolean_t   g_flex_acl_initialized;
extern acl_stage_e g_acl_stage;

/***********************************************
*  Local variables
***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

static rbb_rule_info_t g_rules_db[SX_ACL_RBB_DIRECTION_LAST_E][SX_ACL_RBB_RULE_OFFSET_LAST_E];

static boolean_t g_is_initialized = FALSE;

static sxd_perb_pipe_stage_t g_perb_pipe_stage_map[] = {
    [SX_ACL_RBB_DIRECTION_INGRESS_E] = SXD_PERB_PIPE_STAGE_IPORT_E,
    [SX_ACL_RBB_DIRECTION_EGRESS_E] = SXD_PERB_PIPE_STAGE_EPORT_E,
    [SX_ACL_RBB_DIRECTION_RIF_INGRESS_E] = SXD_PERB_PIPE_STAGE_IRIF_E,
    [SX_ACL_RBB_DIRECTION_RIF_EGRESS_E] = SXD_PERB_PIPE_STAGE_ERIF_E,
};

/* For each direction the user can define groups of rifs/ports.
 * This DB keeps track of the rifs/ports in each group.
 * NOTE: For ingress ports this will contains the ports for each **rule**.
 */
static cl_map_t g_rbb_groups_db[RBB_DIRECTION_NUM][RBB_GROUPS_MAX];


/* This will hold a global bitmask for all the ports in the system. Useful when we'll need a catch all
 * port classifier.
 */
static uint32_t g_ingress_local_port_list[SXD_PERB_PERB_CLASSIFIER_IPORT_INGRESS_LOCAL_PORT_LIST_NUM];


/************************************************
 *  Function implementations
 ***********************************************/

static boolean_t __is_issu_started()
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_boot_mode_e issu_boot_mode = SX_BOOT_MODE_DISABLED_E;

    rc = issu_boot_mode_get(&issu_boot_mode);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to issu_boot_mode_get for rule based binding. sx_status = %s\n",
                   sx_status_str(rc));
        return FALSE;
    }

    if (issu_boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        return TRUE;
    } else {
        return FALSE;
    }
}

static inline void __clear_db_rule(rbb_rule_info_t *rbb_rule_p)
{
    SX_MEM_CLR_P(rbb_rule_p);
    rbb_rule_p->group_id = FLEX_ACL_INVALID_ACL_ID;
    rbb_rule_p->bound_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
}

static void __clear_db_all_rules()
{
    sx_acl_rbb_direction_e   rule_direction = 0;
    sx_acl_rbb_rule_offset_e rule_offset = 0;

    for (rule_direction = 0; rule_direction < SX_ACL_RBB_DIRECTION_LAST_E; rule_direction++) {
        for (rule_offset = 0; rule_offset < SX_ACL_RBB_RULE_OFFSET_LAST_E; rule_offset++) {
            __clear_db_rule(&g_rules_db[rule_direction][rule_offset]);
        }
    }
}

static sx_status_t __clear_db_rule_by_id(const sx_acl_rbb_rule_id_t *rules_id_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (rules_id_p->rule_direction >= SX_ACL_RBB_DIRECTION_LAST_E) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported rule direction [%u] for RBB rule set\n", rules_id_p->rule_direction);
        goto out;
    }
    if (rules_id_p->rule_offset >= SX_ACL_RBB_RULE_OFFSET_LAST_E) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported rule offset [%u] for RBB rule set\n", rules_id_p->rule_offset);
        goto out;
    }

    __clear_db_rule(&g_rules_db[rules_id_p->rule_direction][rules_id_p->rule_offset]);
out:
    return rc;
}

static sx_status_t __validate_rule_id(const sx_acl_rbb_rule_id_t *rules_id_p,
                                      const sx_access_cmd_t       cmd,
                                      rbb_rule_info_t           **rbb_rule_pp)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   is_valid = FALSE;
    boolean_t   is_bound = FALSE;

    if (rules_id_p->rule_direction >= SX_ACL_RBB_DIRECTION_LAST_E) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported rule direction [%u] for RBB rule set\n", rules_id_p->rule_direction);
        goto out;
    }
    if (rules_id_p->rule_offset >= SX_ACL_RBB_RULE_OFFSET_LAST_E) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported rule offset [%u] for RBB rule set\n", rules_id_p->rule_offset);
        goto out;
    }
    if (cmd != SX_ACCESS_CMD_NONE) {
        is_valid = g_rules_db[rules_id_p->rule_direction][rules_id_p->rule_offset].valid;
        is_bound =
            (g_rules_db[rules_id_p->rule_direction][rules_id_p->rule_offset].group_id ==
             FLEX_ACL_INVALID_ACL_ID) ? FALSE : TRUE;
        if ((cmd == SX_ACCESS_CMD_CREATE) && (is_valid == TRUE)) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("RBB rule [%s][%u] is already set and cannot be created\n",
                       sx_acl_rbb_direction_str(rules_id_p->rule_direction),
                       rules_id_p->rule_offset);
            goto out;
        }
        if ((cmd == SX_ACCESS_CMD_DESTROY) && (is_valid == FALSE)) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("RBB rule [%s][%u] is not created and cannot be destroyed\n",
                       sx_acl_rbb_direction_str(rules_id_p->rule_direction),
                       rules_id_p->rule_offset);
            goto out;
        }
        if (cmd == SX_ACCESS_CMD_BIND) {
            if (is_valid == FALSE) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("RBB rule [%s][%u] cannot be bound. Rule does not exist.\n",
                           sx_acl_rbb_direction_str(rules_id_p->rule_direction),
                           rules_id_p->rule_offset);
                goto out;
            }
        }
        if (cmd == SX_ACCESS_CMD_UNBIND) {
            if (is_valid == FALSE) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("RBB rule [%s][%u] cannot be unbound. Rule does not exist.\n",
                           sx_acl_rbb_direction_str(rules_id_p->rule_direction),
                           rules_id_p->rule_offset);
                goto out;
            }
            if (is_bound == FALSE) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("RBB rule [%s][%u] cannot be unbound. Rule is not bound.\n",
                           sx_acl_rbb_direction_str(rules_id_p->rule_direction),
                           rules_id_p->rule_offset);
                goto out;
            }
        }
    }

    if (rbb_rule_pp != NULL) {
        *rbb_rule_pp = &g_rules_db[rules_id_p->rule_direction][rules_id_p->rule_offset];
    }

out:
    return rc;
}

static sx_status_t __validate_ports_rifs(const sx_acl_rbb_rule_id_t         *rules_id_p,
                                         const sx_acl_rbb_classifier_attr_t *rule_classifier_p)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS;
    uint32_t                                  i = 0;
    const sx_port_log_id_t                   *rbb_tunnel_port_list_p = NULL;
    uint32_t                                  rbb_tunnel_port_cnt = 0;
    const sx_acl_rbb_classifier_rif_groups_t *rif_group_p = NULL;
    sx_port_type_t                            port_type = SX_PORT_TYPE_NETWORK;


    switch (rules_id_p->rule_direction) {
    case SX_ACL_RBB_DIRECTION_INGRESS_E:
        if (rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_port_cnt > MAX_PHYPORT_NUM) {
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Port num [%u] for ingress RBB rule set is out of bounds\n",
                       rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_port_cnt);
            goto out;
        }

        for (i = 0; i < rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_port_cnt; i++) {
            rc = port_db_info_get(rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_port_list[i],
                                  NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("RBB group failed on port validation: Logical port[0x%08X] not found [%s]\n",
                           rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_port_list[i],
                           sx_status_str(rc));
                goto out;
            }
            /* LAG not supported */
            port_type = SX_PORT_TYPE_ID_GET(
                rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_port_list[i]);
            if (port_type != SX_PORT_TYPE_NETWORK) {
                SX_LOG_ERR("RBB group failed on port validation: Logical port[0x%08X] type:[%s] not supported\n",
                           rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_port_list[i],
                           sx_port_type_str(port_type));
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        rbb_tunnel_port_list_p =
            rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_tunnel_port_list;
        rbb_tunnel_port_cnt = rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_tunnel_port_cnt;
        break;

    case SX_ACL_RBB_DIRECTION_EGRESS_E:
        if (rule_classifier_p->bind_object_classifiers.egress_port_classifiers.rbb_port_group_cnt >
            SX_ACL_RBB_PORT_GROUP_LAST_E) {
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Port group num [%u] for RBB rule set is out of bounds\n",
                       rule_classifier_p->bind_object_classifiers.egress_port_classifiers.rbb_port_group_cnt);
            goto out;
        }

        for (i = 0; i < rule_classifier_p->bind_object_classifiers.egress_port_classifiers.rbb_port_group_cnt; i++) {
            if (rule_classifier_p->bind_object_classifiers.egress_port_classifiers.rbb_port_group_list[i] >=
                SX_ACL_RBB_PORT_GROUP_LAST_E) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Port group [%u] for RBB rule set is invalid\n",
                           rule_classifier_p->bind_object_classifiers.egress_port_classifiers.rbb_port_group_list[i]);
                goto out;
            }
        }

        rbb_tunnel_port_list_p =
            rule_classifier_p->bind_object_classifiers.egress_port_classifiers.rbb_tunnel_port_list;
        rbb_tunnel_port_cnt = rule_classifier_p->bind_object_classifiers.egress_port_classifiers.rbb_tunnel_port_cnt;
        break;

    case SX_ACL_RBB_DIRECTION_RIF_INGRESS_E:
        rif_group_p = &rule_classifier_p->bind_object_classifiers.ingress_rif_classifiers;
        break;

    case SX_ACL_RBB_DIRECTION_RIF_EGRESS_E:
        rif_group_p = &rule_classifier_p->bind_object_classifiers.egress_rif_classifiers;
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported rule direction [%u] for RBB rule set\n", rules_id_p->rule_direction);
        goto out;
        break;
    }

    switch (rules_id_p->rule_direction) {
    case SX_ACL_RBB_DIRECTION_INGRESS_E:
    case SX_ACL_RBB_DIRECTION_EGRESS_E:
        /* Validate the tunnel ports that are common to the ingress and egress ports */
        if (rbb_tunnel_port_cnt > SX_ACL_RBB_TUNNEL_PORT_COUNT_MAX) {
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Tunnel num [%u] for RBB rule set is out of bounds\n", rbb_tunnel_port_cnt);
            goto out;
        }

        for (i = 0; i < rbb_tunnel_port_cnt; i++) {
            if ((rbb_tunnel_port_list_p[i] != (sx_port_log_id_t)SX_TUNNEL_PORT_ID_NVE) &&
                (rbb_tunnel_port_list_p[i] != (sx_port_log_id_t)SX_TUNNEL_PORT_ID_FLEX0) &&
                (rbb_tunnel_port_list_p[i] != (sx_port_log_id_t)SX_TUNNEL_PORT_ID_FLEX1)) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Tunnel port [0x%x] for RBB rule set is invalid\n", rbb_tunnel_port_list_p[i]);
                goto out;
            }
        }
        break;

    case SX_ACL_RBB_DIRECTION_RIF_INGRESS_E:
    case SX_ACL_RBB_DIRECTION_RIF_EGRESS_E:
        if (rif_group_p->rbb_rif_group_cnt > SX_ACL_RBB_RIF_GROUP_LAST_E) {
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            SX_LOG_ERR("Rif group num [%u] for RBB rule set is out of bounds\n", rif_group_p->rbb_rif_group_cnt);
            goto out;
        }

        for (i = 0; i < rif_group_p->rbb_rif_group_cnt; i++) {
            if (rif_group_p->rbb_rif_group_list[i] >= SX_ACL_RBB_RIF_GROUP_LAST_E) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Rif group [%u] for RBB rule set is invalid\n", rif_group_p->rbb_rif_group_list[i]);
                goto out;
            }
        }
        break;

    default:
        break;
    }


out:
    return rc;
}

static uint8_t __create_tunnel_bitmask(const sx_port_log_id_t *rbb_tunnel_port_list_p,
                                       const uint32_t          rbb_tunnel_port_cnt)
{
    uint8_t  tunnel_bitmask = 0;
    uint32_t i = 0;

    if (rbb_tunnel_port_cnt == 0) {
        tunnel_bitmask = 0xff;
    } else {
        tunnel_bitmask = 0;
        for (i = 0; i < rbb_tunnel_port_cnt; i++) {
            tunnel_bitmask |= 1 << SX_PORT_PHY_ID_GET(rbb_tunnel_port_list_p[i]);
        }
    }

    return tunnel_bitmask;
}

static uint8_t __create_port_group_bitmask(const sx_acl_rbb_classifier_port_groups_t *port_groups_p)
{
    uint8_t  port_group_bitmask = 0;
    uint32_t i = 0;

    if (port_groups_p->rbb_port_group_cnt == 0) {
        port_group_bitmask = 0xff;
    } else {
        port_group_bitmask = 0;
        for (i = 0; i < port_groups_p->rbb_port_group_cnt; i++) {
            /* NOTE: Group zero is reserved for default group. User groups start at 1. */
            port_group_bitmask |= 1 << RBB_HW_GROUP(port_groups_p->rbb_port_group_list[i]);
        }
    }

    return port_group_bitmask;
}

static void __create_port_bitmask(const sx_port_log_id_t *log_ports_p,
                                  const uint32_t          port_cnt,
                                  uint32_t               *port_bitmask_p)
{
    uint32_t i = 0;

    if (port_cnt == 0) {
        /* For the catch all ports we copy the array we've prepare beforehand */
        SX_MEM_CPY_ARRAY(port_bitmask_p,
                         g_ingress_local_port_list,
                         SXD_PERB_PERB_CLASSIFIER_IPORT_INGRESS_LOCAL_PORT_LIST_NUM,
                         uint32_t);
    } else {
        SX_MEM_CLR_ARRAY(port_bitmask_p, SXD_PERB_PERB_CLASSIFIER_IPORT_INGRESS_LOCAL_PORT_LIST_NUM, uint32_t);
        /* Get all the ports into the bitmask */
        for (i = 0; i < port_cnt; i++) {
            SXD_BITMAP_REVERSE_SET(port_bitmask_p,
                                   SXD_PERB_PERB_CLASSIFIER_IPORT_INGRESS_LOCAL_PORT_LIST_NUM,
                                   sizeof(port_bitmask_p[0]) * 8,
                                   SX_PORT_PHY_ID_GET(log_ports_p[i]));
        }
    }

    return;
}


static uint8_t __create_rif_group_bitmask(const sx_acl_rbb_classifier_rif_groups_t *rif_groups_p)
{
    uint8_t  rif_group_bitmask = 0;
    uint32_t i = 0;

    if (rif_groups_p->rbb_rif_group_cnt == 0) {
        rif_group_bitmask = 0xff;
    } else {
        rif_group_bitmask = 0;
        for (i = 0; i < rif_groups_p->rbb_rif_group_cnt; i++) {
            /* NOTE: Group zero is reserved for default group. User groups start at 1. */
            rif_group_bitmask |= 1 << RBB_HW_GROUP(rif_groups_p->rbb_rif_group_list[i]);
        }
    }

    return rif_group_bitmask;
}

static sx_status_t __perbrg_register_set(const sx_rif_id_t            rif_id,
                                         const sx_acl_rbb_direction_e direction,
                                         const uint32_t               group)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sxd_status_t         sxd_status = SXD_STATUS_SUCCESS;
    struct ku_perbrg_reg perbrg_reg_data;
    sxd_reg_meta_t       perbrg_reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(perbrg_reg_meta);
    SX_MEM_CLR(perbrg_reg_data);

    /* During ISSU we do not write to registers. We'll do the binding at ISSU end. */
    if (__is_issu_started()) {
        goto out;
    }

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for PERBRG, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    rc = sdk_router_cmn_rif_hw_id_get(rif_id, &perbrg_reg_data.rif);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("RBB rif [%u] failed getting HW rif for PERBRG register.\n", rif_id);
        goto out;
    }
    perbrg_reg_data.rb_rif_group = group;
    perbrg_reg_data.dir = direction & 0x1;
    perbrg_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN

    perbrg_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PERBRG_E, &perbrg_reg_data, &perbrg_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("RBB rif [%u] group [%u] failed PERBRG register.\n", rif_id, group);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}

static sx_status_t __perbeg_register_set(const sx_port_log_id_t log_port, const uint32_t group)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sxd_status_t         sxd_status = SXD_STATUS_SUCCESS;
    struct ku_perbeg_reg perbeg_reg_data;
    sxd_reg_meta_t       perbeg_reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(perbeg_reg_meta);
    SX_MEM_CLR(perbeg_reg_data);

    /* During ISSU we do not write to registers. We'll do the binding at ISSU end. */
    if (__is_issu_started()) {
        goto out;
    }

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for PERBEG, error: [%s].\n", sx_status_str(rc));
        goto out;
    }

    perbeg_reg_data.rb_eport_group = group;
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(perbeg_reg_data.egress_local_port, perbeg_reg_data.egress_lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));

    perbeg_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN
    perbeg_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PERBEG_E, &perbeg_reg_data, &perbeg_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("RBB log port [0x%x] group [%u] failed PERBEG register.\n", log_port, group);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}

static sx_status_t __perb_register_set(const sx_acl_rbb_rule_id_t          rule_id,
                                       const sx_access_cmd_t               cmd,
                                       const flex_acl_bind_attribs_id_t    bind_attribs_id,
                                       const sx_acl_rbb_classifier_attr_t *rule_classifier_p)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sxd_status_t                sxd_status = SXD_STATUS_SUCCESS;
    struct ku_perb_reg          perb_reg_data;
    sxd_reg_meta_t              perb_reg_meta;
    sxd_perb_base_classifier_t *base_classifier_p = NULL;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_MEM_CLR(perb_reg_meta);
    SX_MEM_CLR(perb_reg_data);

    /* During ISSU we do not write to registers. We'll do the binding at ISSU end. */
    if (__is_issu_started()) {
        goto out;
    }

    rc = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Cannot retrieve device list for PERB, error: [%s].\n", sx_status_str(rc));
        goto out;
    }
    perb_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;

    perb_reg_data.pipe_stage = g_perb_pipe_stage_map[rule_id.rule_direction];
    perb_reg_data.rule_profile_index = rule_id.rule_offset;

    if (cmd == SX_ACCESS_CMD_BIND) {
        if (bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
            /* Active classifier but empty group */
            perb_reg_data.op = 1;
        } else {
            /* Active classifier with non-empty group */
            perb_reg_data.op = 0;
        }
        perb_reg_data.group_id = bind_attribs_id;
        switch (rule_id.rule_direction) {
        case SX_ACL_RBB_DIRECTION_INGRESS_E:
            __create_port_bitmask(rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_port_list,
                                  rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_port_cnt,
                                  perb_reg_data.classifier_entry.perb_classifier_iport.ingress_local_port_list);
            perb_reg_data.classifier_entry.perb_classifier_iport.tunnel_port = __create_tunnel_bitmask(
                rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_tunnel_port_list,
                rule_classifier_p->bind_object_classifiers.ingress_port_classifiers.rbb_tunnel_port_cnt);
            base_classifier_p = &perb_reg_data.classifier_entry.perb_classifier_iport.base_classifier;
            break;

        case SX_ACL_RBB_DIRECTION_EGRESS_E:
            perb_reg_data.classifier_entry.perb_classifier_eport.rb_eport_group = __create_port_group_bitmask(
                &rule_classifier_p->bind_object_classifiers.egress_port_classifiers);
            perb_reg_data.classifier_entry.perb_classifier_eport.tunnel_port = __create_tunnel_bitmask(
                rule_classifier_p->bind_object_classifiers.egress_port_classifiers.rbb_tunnel_port_list,
                rule_classifier_p->bind_object_classifiers.egress_port_classifiers.rbb_tunnel_port_cnt);
            base_classifier_p = &perb_reg_data.classifier_entry.perb_classifier_eport.base_classifier;
            break;

        case SX_ACL_RBB_DIRECTION_RIF_INGRESS_E:
            perb_reg_data.classifier_entry.perb_classifier_irif.rb_irif_group = __create_rif_group_bitmask(
                &rule_classifier_p->bind_object_classifiers.ingress_rif_classifiers);
            base_classifier_p = &perb_reg_data.classifier_entry.perb_classifier_irif.base_classifier;
            break;

        case SX_ACL_RBB_DIRECTION_RIF_EGRESS_E:
            perb_reg_data.classifier_entry.perb_classifier_erif.rb_erif_group = __create_rif_group_bitmask(
                &rule_classifier_p->bind_object_classifiers.ingress_rif_classifiers);
            base_classifier_p = &perb_reg_data.classifier_entry.perb_classifier_erif.base_classifier;
            break;

        default:
            SX_LOG_ERR("RBB rule direction [%u] invalid for PERB register.\n", rule_id.rule_direction);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
            break;
        }
        /* We want to set all bits to 1 so we indicate don't care on all fields by default */
        SX_MEM_SET_P(base_classifier_p, 0xFF);
        if (rule_classifier_p->l2_flood_classifiers != SX_ACL_RBB_CLASSIFIER_L2_FLOOD_ANY_E) {
            base_classifier_p->l2_flood = rule_classifier_p->l2_flood_classifiers;
        }
        if (rule_classifier_p->l2_multicast_classifiers != SX_ACL_RBB_CLASSIFIER_L2_MULTICAST_ANY_E) {
            base_classifier_p->l2_mc = rule_classifier_p->l2_multicast_classifiers;
        }
        if (rule_classifier_p->l3_multicast_classifiers != SX_ACL_RBB_CLASSIFIER_L3_MULTICAST_ANY_E) {
            base_classifier_p->l3_mc = rule_classifier_p->l3_multicast_classifiers;
        }
        if (rule_classifier_p->inner_l2_type_classifiers != SX_ACL_RBB_CLASSIFIER_L2_TYPE_ANY_E) {
            base_classifier_p->inner_l2_type = rule_classifier_p->inner_l2_type_classifiers;
        }
        if (rule_classifier_p->l3_type_classifiers != SX_ACL_RBB_CLASSIFIER_L3_TYPE_ANY_E) {
            base_classifier_p->l3_type = rule_classifier_p->l3_type_classifiers;
        }
        if (rule_classifier_p->inner_l3_type_classifiers != SX_ACL_RBB_CLASSIFIER_L3_TYPE_ANY_E) {
            base_classifier_p->inner_l3_type = rule_classifier_p->inner_l3_type_classifiers;
        }
        if (rule_classifier_p->ip_fragment_classifiers != SX_ACL_RBB_CLASSIFIER_IP_FRAGMENT_ANY_E) {
            base_classifier_p->ip_frag = rule_classifier_p->ip_fragment_classifiers;
        }
        if (rule_classifier_p->inner_ip_fragment_classifiers != SX_ACL_RBB_CLASSIFIER_IP_FRAGMENT_ANY_E) {
            base_classifier_p->inner_ip_frag = rule_classifier_p->inner_ip_fragment_classifiers;
        }
        if (rule_classifier_p->l4_type_classifiers != SX_ACL_RBB_CLASSIFIER_L4_TYPE_ANY_E) {
            base_classifier_p->l4_type = rule_classifier_p->l4_type_classifiers;
        }
        if (rule_classifier_p->inner_l4_type_classifiers != SX_ACL_RBB_CLASSIFIER_L4_TYPE_ANY_E) {
            base_classifier_p->inner_l4_type = rule_classifier_p->inner_l4_type_classifiers;
        }
        if (rule_classifier_p->tunnel_type_classifiers != SX_ACL_RBB_CLASSIFIER_TUNNEL_TYPE_ANY_E) {
            base_classifier_p->tunnel_type = rule_classifier_p->tunnel_type_classifiers;
        }
        if (rule_classifier_p->flex_parser_fpp_classifiers != SX_ACL_RBB_CLASSIFIER_FLEX_PARSER_FPP_ANY_E) {
            base_classifier_p->fpp_index = rule_classifier_p->flex_parser_fpp_classifiers;
        }
        if (rule_classifier_p->inner_flex_parser_fpp_classifiers != SX_ACL_RBB_CLASSIFIER_FLEX_PARSER_FPP_ANY_E) {
            base_classifier_p->inner_fpp_index = rule_classifier_p->inner_flex_parser_fpp_classifiers;
        }
    } else {    /* UNBIND */
        /* Remove the entire classifier */
        perb_reg_data.op = 2;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    perb_reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    sxd_status =
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PERB_E, &perb_reg_data, &perb_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("RBB rule [%s][%u] failed PERB register.\n",
                   sx_acl_rbb_direction_str(rule_id.rule_direction),
                   rule_id.rule_offset);

        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    return rc;
}

sx_status_t flex_acl_rule_based_binding_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return rc;
}

sx_status_t flex_acl_rule_based_binding_init()
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    cl_status_t            cl_status = CL_SUCCESS;
    sx_acl_rbb_direction_e direction = 0;
    uint32_t               group = 0;
    uint32_t               port_idx = 0;

    SX_LOG_ENTER();

    if (g_is_initialized) {
        rc = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("ACL rule based binding module has already been initialized.\n");
        goto out;
    }
    __clear_db_all_rules();

    /* Initialize the ports/rif lists' DB */
    for (direction = SX_ACL_RBB_DIRECTION_EGRESS_E; direction < RBB_DIRECTION_NUM; direction++) {
        for (group = 0; group < RBB_GROUPS_MAX; group++) {
            cl_status = cl_map_init(&g_rbb_groups_db[direction][group], 0);
            if (SX_UTILS_CHECK_FAIL(cl_status)) {
                SX_LOG_ERR("RBB Failed to init [%s] DB. err: %s.\n",
                           sx_acl_rbb_direction_str(direction),
                           CL_STATUS_MSG(cl_status));
                rc = cl_status_to_sx_status(cl_status);
                goto out;
            }
        }
    }

    /* Set a global bitmask for all available ports. Will be used for ingress ports only. */
    SX_MEM_CLR(g_ingress_local_port_list);
    for (port_idx = 0; port_idx < rm_resource_global.port_ext_num_max; port_idx++) {
        SXD_BITMAP_REVERSE_SET(g_ingress_local_port_list,
                               SXD_PERB_PERB_CLASSIFIER_IPORT_INGRESS_LOCAL_PORT_LIST_NUM,
                               sizeof(g_ingress_local_port_list[0]) * 8,
                               port_idx);
    }
    /* The CPU port is not supported */
    SXD_BITMAP_REVERSE_CLR(g_ingress_local_port_list,
                           SXD_PERB_PERB_CLASSIFIER_IPORT_INGRESS_LOCAL_PORT_LIST_NUM,
                           sizeof(g_ingress_local_port_list[0]) * 8,
                           CPU_PORT_PHY_ID);

    g_is_initialized = TRUE;


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_based_binding_deinit()
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    uint32_t               group = 0;
    sx_acl_rbb_direction_e direction = 0;
    cl_map_iterator_t      map_iter, map_iter_end;
    uint64_t               key = 0;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ACL rule based binding module was not initialized. Cannot deinit.\n");
        goto out;
    }

    /* De-initialize the ports/rif lists' DB - Move all the ports/rifs to the default group */
    for (direction = SX_ACL_RBB_DIRECTION_EGRESS_E; direction < RBB_DIRECTION_NUM; direction++) {
        for (group = 0; group < RBB_GROUPS_MAX; group++) {
            if (!cl_is_map_empty(&g_rbb_groups_db[direction][group])) {
                map_iter = cl_map_head(&g_rbb_groups_db[direction][group]);
                map_iter_end = cl_map_end(&g_rbb_groups_db[direction][group]);
                while (map_iter != map_iter_end) {
                    key = cl_map_key(map_iter);
                    if (direction == SX_ACL_RBB_DIRECTION_EGRESS_E) {
                        rc = __perbeg_register_set((sx_port_log_id_t)key, RBB_DEFAULT_GROUP);
                        if (SX_CHECK_FAIL(rc)) {
                            SX_LOG_ERR("RBB port [0x%08X] could not be removed from group. Register failure\n",
                                       (sx_port_log_id_t)key);
                            goto out;
                        }
                    } else {
                        rc = __perbrg_register_set((sx_rif_id_t)key, direction, RBB_DEFAULT_GROUP);
                        if (SX_CHECK_FAIL(rc)) {
                            SX_LOG_ERR("RBB rif [%u] could not be removed from group. Register failure\n",
                                       (sx_rif_id_t)key);
                            goto out;
                        }
                    }
                    map_iter = cl_map_next(map_iter);
                }
            }
            cl_map_remove_all(&g_rbb_groups_db[direction][group]);
            cl_map_destroy(&g_rbb_groups_db[direction][group]);
        }
    }

    g_is_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_based_binding_rules_set(const sx_access_cmd_t       cmd,
                                                  const sx_acl_rbb_rule_id_t *rules_id_list_p,
                                                  const uint32_t              rules_id_cnt)
{
    sx_status_t      rc = SX_STATUS_SUCCESS;
    uint32_t         i = 0;
    rbb_rule_info_t *rbb_rule_p = NULL;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ACL rule based binding module was not initialized. Cannot set rules.\n");
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(rules_id_list_p, "rules_id_list_p"))) {
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB rule set\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    /* Do validations before actually do anything*/
    for (i = 0; i < rules_id_cnt; i++) {
        rc = __validate_rule_id(&rules_id_list_p[i], cmd, NULL);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB rule set validation failed\n");
            goto out;
        }
    }

    for (i = 0; i < rules_id_cnt; i++) {
        rc = __validate_rule_id(&rules_id_list_p[i], SX_ACCESS_CMD_NONE, &rbb_rule_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB rule set validation failed\n");
            goto out;
        }

        if (cmd == SX_ACCESS_CMD_CREATE) {
            rbb_rule_p->valid = TRUE;
        } else { /* SX_ACCESS_CMD_DESTROY */
            /* If we have a bound rule we automatically unbind it */
            if (rbb_rule_p->group_id != FLEX_ACL_INVALID_ACL_ID) {
                rc = flex_acl_rule_based_binding_bind_set(SX_ACCESS_CMD_UNBIND,
                                                          rules_id_list_p[i],
                                                          NULL,
                                                          rbb_rule_p->group_id);
            }
            /* Clear the DB entry for this rule */
            __clear_db_rule_by_id(&rules_id_list_p[i]);
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_based_binding_bind_set(const sx_access_cmd_t               cmd,
                                                 const sx_acl_rbb_rule_id_t          rule_id,
                                                 const sx_acl_rbb_classifier_attr_t *rule_classifier_p,
                                                 const sx_acl_id_t                   group_id)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t   *acl_group_p = NULL;
    boolean_t                  non_empty_group;
    rbb_rule_info_t           *rbb_rule_p = NULL;
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ACL rule based binding module was not initialized. Cannot bind.\n");
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_BIND) && (cmd != SX_ACCESS_CMD_UNBIND)) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB bind\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    /* Check if the rule is in a valid state for the command */
    rc = __validate_rule_id(&rule_id, cmd, &rbb_rule_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("RBB rule bind validation failed\n");
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_BIND) {
        rc = __validate_ports_rifs(&rule_id, rule_classifier_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB rule bind validation failed\n");
            goto out;
        }

        rc = flex_acl_group_validate(group_id, &acl_group_p, &non_empty_group);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB bind group [0x%x] is invalid\n", group_id);
            goto out;
        }

        if (rule_id.rule_direction != (sx_acl_rbb_direction_e)acl_group_p->direction) {
            SX_LOG_ERR("RBB rule [%s][%u] cannot be bound to group [0x%x][%s].\n",
                       sx_acl_rbb_direction_str(rule_id.rule_direction),
                       rule_id.rule_offset, group_id,
                       sx_acl_direction_str(acl_group_p->direction));
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        /* No point in rebinding the same group */
        if (rbb_rule_p->group_id == group_id) {
            goto out;
        }
        /* We provide a valid bind attribute only if the group is not empty */
        bind_attribs_id = (non_empty_group) ? acl_group_p->bind_attribs_id : FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

        /* Update HW first */
        rc = __perb_register_set(rule_id, cmd, bind_attribs_id, rule_classifier_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB failed to configure RBB bind register for rule [%s][%u] group [0x%x].\n",
                       sx_acl_rbb_direction_str(rule_id.rule_direction),
                       rule_id.rule_offset, group_id);
            goto out;
        }
        /* Updated the DB about the operation */
        /* Remove the old bind attributes from DB (for overwrite operation)*/
        if (rbb_rule_p->bound_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
            rc = flex_acl_db_attribs_unbind_rbb_rule(rbb_rule_p->bound_attribs_id, rule_id.rule_offset);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("RBB failed to remove old DB bind attribs id [%d] for rule [%s][%u].\n",
                           rbb_rule_p->bound_attribs_id,
                           sx_acl_rbb_direction_str(rule_id.rule_direction),
                           rule_id.rule_offset);
                goto out;
            }
        }
        /* Remove the old group from DB (for overwrite operation)*/
        if (rbb_rule_p->group_id != FLEX_ACL_INVALID_ACL_ID) {
            rc = flex_acl_db_group_unbind_rbb_rule(rule_id.rule_offset, acl_group_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("RBB failed to remove old DB group [0x%x] for rule [%s][%u].\n",
                           rbb_rule_p->group_id,
                           sx_acl_rbb_direction_str(rule_id.rule_direction),
                           rule_id.rule_offset);
                goto out;
            }
        }
        /* Set the new attributes in the DB */
        if (bind_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
            rc = flex_acl_db_attribs_bind_rbb_rule(bind_attribs_id, rule_id.rule_offset);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("RBB failed to add DB bind attribs id [%d] for rule [%s][%u].\n",
                           bind_attribs_id,
                           sx_acl_rbb_direction_str(rule_id.rule_direction),
                           rule_id.rule_offset);
                goto out;
            }
        }
        /* Set the group in the DB */
        rc = flex_acl_db_group_bind_rbb_rule(rule_id.rule_offset, acl_group_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB failed to add DB group [0x%x] for rule [%s][%u].\n",
                       group_id,
                       sx_acl_rbb_direction_str(rule_id.rule_direction),
                       rule_id.rule_offset);
            goto out;
        }
        rbb_rule_p->group_id = group_id;
        rbb_rule_p->bound_attribs_id = bind_attribs_id;
        rbb_rule_p->classifier = *rule_classifier_p;
    } else { /* SX_ACCESS_CMD_UNBIND */
        /* If there is no actual binding (may be caused by port delete) we do nothing */
        if (rbb_rule_p->group_id == FLEX_ACL_INVALID_ACL_ID) {
            goto out;
        }

        rc = flex_acl_group_validate(rbb_rule_p->group_id, &acl_group_p, &non_empty_group);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB bind group [0x%x] is invalid\n", group_id);
            goto out;
        }

        /* Update HW first */
        rc = __perb_register_set(rule_id, cmd, bind_attribs_id, NULL);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB failed to configure RBB unbind register for rule [%s][%u] group [0x%x].\n",
                       sx_acl_rbb_direction_str(rule_id.rule_direction),
                       rule_id.rule_offset, group_id);
            goto out;
        }
        /* Remove the bind attributes from DB (for overwrite operation)*/
        if (rbb_rule_p->bound_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
            rc = flex_acl_db_attribs_unbind_rbb_rule(rbb_rule_p->bound_attribs_id, rule_id.rule_offset);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("RBB failed to remove DB bind attribs id [%d] for rule [%s][%u].\n",
                           rbb_rule_p->bound_attribs_id,
                           sx_acl_rbb_direction_str(rule_id.rule_direction),
                           rule_id.rule_offset);
                goto out;
            }
        }
        /* Remove the group from DB (for overwrite operation)*/
        if (rbb_rule_p->group_id != FLEX_ACL_INVALID_ACL_ID) {
            rc = flex_acl_db_group_unbind_rbb_rule(rule_id.rule_offset, acl_group_p);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("RBB failed to remove DB group [0x%x] for rule [%s][%u].\n",
                           rbb_rule_p->group_id,
                           sx_acl_rbb_direction_str(rule_id.rule_direction),
                           rule_id.rule_offset);
                goto out;
            }
        }
        /* Clear the entries in the DB */
        rbb_rule_p->group_id = FLEX_ACL_INVALID_ACL_ID;
        rbb_rule_p->bound_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
        SX_MEM_CLR(rbb_rule_p->classifier);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_based_binding_bind_get(const sx_access_cmd_t         cmd,
                                                 const sx_acl_rbb_rule_id_t    rule_id,
                                                 sx_acl_rbb_classifier_attr_t *rule_classifier_p,
                                                 sx_acl_id_t                  *group_id_p)
{
    sx_status_t      rc = SX_STATUS_SUCCESS;
    rbb_rule_info_t *rbb_rule_p = NULL;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ACL rule based binding module was not initialized. Cannot bind.\n");
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB bind\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    /* Check if the rule is in a valid state for the command */
    rc = __validate_rule_id(&rule_id, SX_ACCESS_CMD_NONE, &rbb_rule_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("RBB rule bind validation failed for bind get\n");
        goto out;
    }

    /* If a binding exists */
    if (rbb_rule_p->valid && (rbb_rule_p->group_id != FLEX_ACL_INVALID_ACL_ID)) {
        *rule_classifier_p = rbb_rule_p->classifier;
        *group_id_p = rbb_rule_p->group_id;
    } else {
        rc = SX_STATUS_ENTRY_NOT_BOUND;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_based_binding_rif_group_set(const sx_access_cmd_t        cmd,
                                                      const sx_rif_id_t           *rif_id_p,
                                                      const uint32_t               rif_count,
                                                      const sx_acl_rbb_direction_e direction,
                                                      const sx_acl_rbb_rif_group_e rif_group)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    uint32_t               i = 0;
    hwd_rif_id_t           rif_hwd_id = 0;
    sx_acl_rbb_rif_group_e rif_group_iter = 0;
    boolean_t              rif_enabled = FALSE;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ACL rule based binding module was not initialized. Cannot set rif group.\n");
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE)) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB rif group\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (rif_group >= SX_ACL_RBB_RIF_GROUP_LAST_E) {
        SX_LOG_ERR("RBB rif group [%u] is invalid\n", rif_group);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((direction != SX_ACL_RBB_DIRECTION_RIF_INGRESS_E) && (direction != SX_ACL_RBB_DIRECTION_RIF_EGRESS_E)) {
        SX_LOG_ERR("RBB rif direction [%u] is invalid\n", direction);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Validate the rifs */
    for (i = 0; i < rif_count; i++) {
        rc = sdk_router_cmn_rif_impl_is_enabled(rif_id_p[i], &rif_enabled, &rif_hwd_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB rif [%u] is not valid for group.\n", rif_id_p[i]);
            goto out;
        }
    }

    /* Go over all the rifs and move them to the correct group */
    for (i = 0; i < rif_count; i++) {
        /* Find if this rif already exists in one of the groups */
        for (rif_group_iter = 0; rif_group_iter < SX_ACL_RBB_RIF_GROUP_LAST_E; rif_group_iter++) {
            if (cl_map_contains(&g_rbb_groups_db[direction][rif_group_iter], (uint64_t)rif_id_p[i]) == TRUE) {
                break;
            }
        }
        /* If a rif belonged to a group and now we want to remove it and return to default group */
        if ((cmd == SX_ACCESS_CMD_DELETE) && (rif_group_iter < SX_ACL_RBB_RIF_GROUP_LAST_E)) {
            /* Move this rif to the default group */
            rc = __perbrg_register_set(rif_id_p[i], direction, RBB_DEFAULT_GROUP);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("RBB rif [%u] could not be removed from group. Register failure\n", rif_id_p[i]);
                goto out;
            }
            /* Remove the rif group from the group in the DB */
            cl_map_remove(&g_rbb_groups_db[direction][rif_group_iter], (uint64_t)rif_id_p[i]);
        }
        if ((cmd == SX_ACCESS_CMD_ADD) && (rif_group_iter != rif_group)) {
            /* Set the rif in the new group */
            rc = __perbrg_register_set(rif_id_p[i], direction, RBB_HW_GROUP(rif_group));
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("RBB rif [%u] could not be added to group [%u]. Register failure\n", rif_id_p[i],
                           rif_group);
                goto out;
            }
            if (cl_map_insert(&g_rbb_groups_db[direction][rif_group], (uint64_t)rif_id_p[i], (void*)TRUE) == NULL) {
                SX_LOG_ERR("RBB rif [%u] could not be added to group [%u]. DB failure\n", rif_id_p[i], rif_group);
                rc = SX_STATUS_ERROR;
                goto out;
            }
            if (rif_group_iter < SX_ACL_RBB_RIF_GROUP_LAST_E) {
                /* Remove the rif group from the group in the DB */
                cl_map_remove(&g_rbb_groups_db[direction][rif_group_iter], (uint64_t)rif_id_p[i]);
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_based_binding_rif_group_get(const sx_access_cmd_t        cmd,
                                                      sx_rif_id_t                 *rif_id_p,
                                                      uint32_t                    *rif_count_p,
                                                      const sx_acl_rbb_direction_e direction,
                                                      const sx_acl_rbb_rif_group_e rif_group)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    cl_map_iterator_t map_iter, map_iter_end;
    uint32_t          count = 0;


    SX_LOG_ENTER();

    if (!g_is_initialized) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ACL rule based binding module was not initialized. Cannot get rif group.\n");
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB rif group get\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (rif_group >= SX_ACL_RBB_RIF_GROUP_LAST_E) {
        SX_LOG_ERR("RBB rif group [%u] is invalid\n", rif_group);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((direction != SX_ACL_RBB_DIRECTION_RIF_INGRESS_E) && (direction != SX_ACL_RBB_DIRECTION_RIF_EGRESS_E)) {
        SX_LOG_ERR("RBB rif direction [%u] is invalid\n", direction);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (*rif_count_p == 0) {
        *rif_count_p = (uint32_t)cl_map_count(&g_rbb_groups_db[direction][rif_group]);
    } else {
        map_iter = cl_map_head(&g_rbb_groups_db[direction][rif_group]);
        map_iter_end = cl_map_end(&g_rbb_groups_db[direction][rif_group]);

        for (count = 0; count < (*rif_count_p) && map_iter != map_iter_end; count++) {
            rif_id_p[count] = (sx_rif_id_t)cl_map_key(map_iter);
            map_iter = cl_map_next(map_iter);
        }
        *rif_count_p = count;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_rule_based_binding_port_group_set(const sx_access_cmd_t         cmd,
                                                       const sx_port_log_id_t       *log_port_p,
                                                       const uint32_t                port_count,
                                                       const sx_acl_rbb_direction_e  direction,
                                                       const sx_acl_rbb_port_group_e port_group)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    uint32_t                i = 0;
    sx_port_type_t          port_type = SX_PORT_TYPE_NETWORK;
    sx_acl_rbb_port_group_e port_group_iter = 0;

    SX_LOG_ENTER();

    if (!g_is_initialized) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ACL rule based binding module was not initialized. Cannot set port group.\n");
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE)) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB port group\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (port_group >= SX_ACL_RBB_PORT_GROUP_LAST_E) {
        SX_LOG_ERR("RBB port group [%u] is invalid\n", port_group);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (direction != SX_ACL_RBB_DIRECTION_EGRESS_E) {
        SX_LOG_ERR("RBB port direction [%s] is invalid for port group. Only egress port direction supported.\n",
                   sx_acl_rbb_direction_str(direction));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Validate the ports */
    for (i = 0; i < port_count; i++) {
        rc = port_db_info_get(log_port_p[i], NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("RBB group failed on port validation: Logical port[0x%08X] not found [%s]\n",
                       log_port_p[i],
                       sx_status_str(rc));
            goto out;
        }
        /* LAG not supported */
        port_type = SX_PORT_TYPE_ID_GET(log_port_p[i]);
        if (port_type != SX_PORT_TYPE_NETWORK) {
            SX_LOG_ERR("RBB group failed on port validation: Logical port[0x%08X] type:[%s] not supported\n",
                       log_port_p[i], sx_port_type_str(port_type));
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    /* Go over all the ports and move them to the correct group */
    for (i = 0; i < port_count; i++) {
        /* Find if this port already exists in one of the groups */
        for (port_group_iter = 0; port_group_iter < SX_ACL_RBB_PORT_GROUP_LAST_E; port_group_iter++) {
            if (cl_map_contains(&g_rbb_groups_db[direction][port_group_iter], (uint64_t)log_port_p[i]) == TRUE) {
                break;
            }
        }
        /* If a port belonged to a group and now we want to remove it and return to default group */
        if ((cmd == SX_ACCESS_CMD_DELETE) && (port_group_iter < SX_ACL_RBB_PORT_GROUP_LAST_E)) {
            /* Move this port to the default group (only for egress group) */
            rc = __perbeg_register_set(log_port_p[i], RBB_DEFAULT_GROUP);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("RBB port [0x%08X] could not be removed from group. Register failure\n", log_port_p[i]);
                goto out;
            }
            /* Remove the port group from the group in the DB */
            cl_map_remove(&g_rbb_groups_db[direction][port_group_iter], (uint64_t)log_port_p[i]);
        }
        if ((cmd == SX_ACCESS_CMD_ADD) && (port_group_iter != port_group)) {
            /* Set the port in the new group */
            if (direction != SX_ACL_RBB_DIRECTION_INGRESS_E) {
                rc = __perbeg_register_set(log_port_p[i], RBB_HW_GROUP(port_group));
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("RBB port [0x%08X] could not be added to group [%u]. Register failure\n",
                               log_port_p[i],
                               port_group);
                    goto out;
                }
            }
            if (cl_map_insert(&g_rbb_groups_db[direction][port_group], (uint64_t)log_port_p[i], (void*)TRUE) == NULL) {
                SX_LOG_ERR("RBB port [0x%08X] could not be added to group [%u]. DB failure\n",
                           log_port_p[i],
                           port_group);
                rc = SX_STATUS_ERROR;
                goto out;
            }
            if (port_group_iter < SX_ACL_RBB_PORT_GROUP_LAST_E) {
                /* Remove the port group from the group in the DB */
                cl_map_remove(&g_rbb_groups_db[direction][port_group_iter], (uint64_t)log_port_p[i]);
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_rule_based_binding_port_group_get(const sx_access_cmd_t         cmd,
                                                       sx_port_log_id_t             *log_port_p,
                                                       uint32_t                     *port_count_p,
                                                       const sx_acl_rbb_direction_e  direction,
                                                       const sx_acl_rbb_port_group_e port_group)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    cl_map_iterator_t map_iter, map_iter_end;
    uint32_t          count = 0;


    SX_LOG_ENTER();

    if (!g_is_initialized) {
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("ACL rule based binding module was not initialized. Cannot get port group.\n");
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Unsupported command: [%s] for RBB port group get\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (port_group >= SX_ACL_RBB_PORT_GROUP_LAST_E) {
        SX_LOG_ERR("RBB port group [%u] is invalid\n", port_group);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (direction != SX_ACL_RBB_DIRECTION_EGRESS_E) {
        SX_LOG_ERR("RBB port direction [%u] is invalid for get\n", direction);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (*port_count_p == 0) {
        *port_count_p = (uint32_t)cl_map_count(&g_rbb_groups_db[direction][port_group]);
    } else {
        map_iter = cl_map_head(&g_rbb_groups_db[direction][port_group]);
        map_iter_end = cl_map_end(&g_rbb_groups_db[direction][port_group]);

        for (count = 0; count < (*port_count_p) && map_iter != map_iter_end; count++) {
            log_port_p[count] = (sx_port_log_id_t)cl_map_key(map_iter);
            map_iter = cl_map_next(map_iter);
        }
        *port_count_p = count;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


/* This function should be called when an ACL group is changing from being empty to non-empty and vice versa.
 * If bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID it means the group is now empty.
 */
sx_status_t flex_acl_rule_based_binding_group_update(const sx_acl_id_t                group_id,
                                                     const flex_acl_bind_attribs_id_t bind_attribs_id,
                                                     const sx_acl_direction_t         direction,
                                                     const sx_acl_rbb_rule_offset_e   offset)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    rbb_rule_info_t     *rbb_rule_p = NULL;
    sx_acl_rbb_rule_id_t rule_id = {.rule_direction = (sx_acl_rbb_direction_e)direction, .rule_offset = offset};

    /* A notification can be called even if the module was not initialized (for older chips) */
    if (!g_is_initialized) {
        goto out;
    }

    /* Do some validation that we actually receive a logical update to the group */
    rc = __validate_rule_id(&rule_id, SX_ACCESS_CMD_BIND, &rbb_rule_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("RBB group [0x%x] update failed for rule [%u][%u] validation\n",
                   group_id, direction, offset);
        goto out;
    }
    if (group_id != rbb_rule_p->group_id) {
        SX_LOG_ERR("RBB group [0x%x] is not bound to rule [%s][%u] for group update\n",
                   group_id, sx_acl_rbb_direction_str(rule_id.rule_direction), offset);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    if ((rbb_rule_p->bound_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) &&
        (bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID)) {
        SX_LOG_ERR("RBB group [0x%x] is empty for rule [%s][%u] and cannot be empty again for group update\n",
                   group_id, sx_acl_rbb_direction_str(rule_id.rule_direction), offset);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    if ((rbb_rule_p->bound_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) &&
        (bind_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID)) {
        SX_LOG_ERR("RBB group [0x%x] is not empty for rule [%s][%u] and cannot be not empty again for group update\n",
                   group_id, sx_acl_rbb_direction_str(rule_id.rule_direction), offset);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    /* Do the actual update */
    rc = __perb_register_set(rule_id, SX_ACCESS_CMD_BIND, bind_attribs_id, &rbb_rule_p->classifier);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("RBB failed to configure RBB bind register for rule [%s][%u] group [0x%x].\n",
                   sx_acl_rbb_direction_str(rule_id.rule_direction),
                   rule_id.rule_offset, group_id);
        goto out;
    }
    /* The bind attributes DB is updated accordingly if the group is empty or not */
    if (bind_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        rc = flex_acl_db_attribs_bind_rbb_rule(bind_attribs_id, rule_id.rule_offset);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB failed to remove DB bind attribs id [%d] for rule [%s][%u].\n",
                       bind_attribs_id,
                       sx_acl_rbb_direction_str(rule_id.rule_direction),
                       rule_id.rule_offset);
            goto out;
        }
    } else {
        rc = flex_acl_db_attribs_unbind_rbb_rule(rbb_rule_p->bound_attribs_id, rule_id.rule_offset);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("RBB failed to remove DB bind attribs id [%d] for rule [%s][%u].\n",
                       bind_attribs_id,
                       sx_acl_rbb_direction_str(rule_id.rule_direction),
                       rule_id.rule_offset);
            goto out;
        }
    }
    rbb_rule_p->bound_attribs_id = bind_attribs_id;


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_based_binding_device_ready(boolean_t is_issu)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    uint32_t               group = 0;
    sx_acl_rbb_direction_e direction = 0;
    cl_map_iterator_t      map_iter, map_iter_end;
    sx_acl_rbb_rule_id_t   rule_id;
    rbb_rule_info_t       *rbb_rule_p = NULL;
    uint64_t               key = 0;

    SX_LOG_ENTER();

    /* A notification can be called even if the module was not initialized (for older chips) */
    if (!g_is_initialized) {
        goto out;
    }

    /* First write all the groups to the HW */
    for (direction = SX_ACL_RBB_DIRECTION_EGRESS_E; direction < RBB_DIRECTION_NUM; direction++) {
        for (group = 0; group < RBB_GROUPS_MAX; group++) {
            if (!cl_is_map_empty(&g_rbb_groups_db[direction][group])) {
                map_iter = cl_map_head(&g_rbb_groups_db[direction][group]);
                map_iter_end = cl_map_end(&g_rbb_groups_db[direction][group]);
                while (map_iter != map_iter_end) {
                    key = cl_map_key(map_iter);
                    if (direction == SX_ACL_RBB_DIRECTION_EGRESS_E) {
                        rc = __perbeg_register_set((sx_port_log_id_t)key, RBB_HW_GROUP(group));
                        if (SX_CHECK_FAIL(rc)) {
                            SX_LOG_ERR("RBB port [0x%08X] could not be set to group. Register failure\n",
                                       (sx_port_log_id_t)key);
                            goto out;
                        }
                    } else {
                        rc = __perbrg_register_set((sx_rif_id_t)key, direction, RBB_HW_GROUP(group));
                        if (SX_CHECK_FAIL(rc)) {
                            SX_LOG_ERR("RBB rif [%u] could not be set to group. Register failure\n", (sx_rif_id_t)key);
                            goto out;
                        }
                    }
                    map_iter = cl_map_next(map_iter);
                }
            }
        }
    }

    /* Now write all the rules */
    for (rule_id.rule_direction = SX_ACL_RBB_DIRECTION_INGRESS_E;
         rule_id.rule_direction < RBB_DIRECTION_NUM;
         rule_id.rule_direction++) {
        for (rule_id.rule_offset = SX_ACL_RBB_RULE_OFFSET_0_E;
             rule_id.rule_offset < SX_ACL_RBB_RULE_OFFSET_LAST_E;
             rule_id.rule_offset++) {
            rbb_rule_p = &g_rules_db[rule_id.rule_direction][rule_id.rule_offset];

            if (rbb_rule_p->valid) {
                rc = __perb_register_set(rule_id,
                                         SX_ACCESS_CMD_BIND,
                                         rbb_rule_p->bound_attribs_id,
                                         &rbb_rule_p->classifier);
            } else if (is_issu == TRUE) { /* We write all rules even the not configured ones - important for ISSU */
                rc = __perb_register_set(rule_id, SX_ACCESS_CMD_UNBIND, FLEX_ACL_INVALID_BIND_ATTRIBS_ID, NULL);
            }
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("RBB PERB register failure on device ready [%s][%u]\n",
                           sx_acl_rbb_direction_str(rule_id.rule_direction),
                           rule_id.rule_offset);
                goto out;
            }
        }
    }


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_based_binding_rif_delete_update(const sx_rif_id_t rif_id)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_acl_rbb_rif_group_e rif_group_iter = 0;
    sx_acl_rbb_direction_e direction = 0;

    SX_LOG_ENTER();

    /* A notification can be called even if the module was not initialized (for older chips) */
    if (!g_is_initialized) {
        goto out;
    }

    /* If a rif is deleted we move it to the default group */
    for (direction = SX_ACL_RBB_DIRECTION_RIF_INGRESS_E; direction <= SX_ACL_RBB_DIRECTION_RIF_EGRESS_E; direction++) {
        for (rif_group_iter = 0; rif_group_iter < SX_ACL_RBB_RIF_GROUP_LAST_E; rif_group_iter++) {
            if (cl_map_contains(&g_rbb_groups_db[direction][rif_group_iter], rif_id) == TRUE) {
                /* Move this rif to the default group */
                rc = __perbrg_register_set(rif_id, direction, RBB_DEFAULT_GROUP);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("RBB rif [%u] update could not be removed from group. Register failure\n", rif_id);
                    goto out;
                }
                /* Remove the rif group from the group in the DB */
                cl_map_remove(&g_rbb_groups_db[direction][rif_group_iter], rif_id);
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_based_binding_port_delete_update(const sx_port_log_id_t log_port)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    sx_acl_rbb_port_group_e port_group_iter = 0;
    sx_acl_rbb_direction_e  direction = SX_ACL_RBB_DIRECTION_EGRESS_E;
    sx_acl_rbb_rule_id_t    rule_id;
    rbb_rule_info_t        *rbb_rule_p = NULL;
    uint32_t                port_found_cnt = 0;
    uint32_t                i = 0;

    SX_LOG_ENTER();

    /* A notification can be called even if the module was not initialized (for older chips) */
    if (!g_is_initialized) {
        goto out;
    }

    direction = SX_ACL_RBB_DIRECTION_EGRESS_E;
    /* If an egress port is deleted we move it to the default group */
    for (port_group_iter = 0; port_group_iter < SX_ACL_RBB_PORT_GROUP_LAST_E; port_group_iter++) {
        if (cl_map_contains(&g_rbb_groups_db[direction][port_group_iter], log_port) == TRUE) {
            /* Move this port to the default group */
            rc = __perbeg_register_set(log_port, RBB_DEFAULT_GROUP);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("RBB port [0x%x] update could not be removed from group. PERBEG register failure\n",
                           log_port);
                goto out;
            }
            /* Remove the port group from the group in the DB */
            cl_map_remove(&g_rbb_groups_db[direction][port_group_iter], log_port);
        }
    }

    direction = SX_ACL_RBB_DIRECTION_INGRESS_E;
    /* For an ingress ports we need to go over the rules and rewrite them without the deleted port.
     * If it's actually used by one of the groups */
    rule_id.rule_direction = direction;
    for (rule_id.rule_offset = SX_ACL_RBB_RULE_OFFSET_0_E;
         rule_id.rule_offset < SX_ACL_RBB_RULE_OFFSET_LAST_E;
         rule_id.rule_offset++) {
        rbb_rule_p = &g_rules_db[rule_id.rule_direction][rule_id.rule_offset];
        if (rbb_rule_p->group_id != FLEX_ACL_INVALID_ACL_ID) {
            /* This loop will go over the port list of each rule and remove the specific port of the list */
            port_found_cnt = 0;
            for (i = 0; i < rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_cnt;
                 i++) {
                if (rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_list[i] ==
                    log_port) {
                    port_found_cnt++;
                } else if (port_found_cnt != 0) {
                    rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_list[i -
                                                                                                          port_found_cnt
                    ] =
                        rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_list[i];
                    rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_list[i] = 0;
                }
            }
            if (port_found_cnt == 0) {
                continue;
            }

            /* Decrease the port list by the ports found */
            rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_cnt -= port_found_cnt;

            if (rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_cnt != 0) {
                rc = __perb_register_set(rule_id,
                                         SX_ACCESS_CMD_BIND,
                                         rbb_rule_p->bound_attribs_id,
                                         &rbb_rule_p->classifier);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("RBB port [0x%x] update could not update. PERB register failure\n", log_port);
                    goto out;
                }
            } else {
                /* If no more ports we just unbind this rule since it will never be useful to us again */
                rc =
                    flex_acl_rule_based_binding_bind_set(SX_ACCESS_CMD_UNBIND, rule_id, NULL, FLEX_ACL_INVALID_ACL_ID);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("RBB port [0x%x] update could not update rule unbinding. \n", log_port);
                    goto out;
                }
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_based_binding_issu_set()
{
    return flex_acl_rule_based_binding_device_ready(TRUE);
}

void flex_acl_rule_based_binding_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    uint32_t                  group = 0;
    sx_acl_rbb_direction_e    direction = 0;
    cl_map_iterator_t         map_iter, map_iter_end;
    sx_acl_rbb_rule_id_t      rule_id;
    rbb_rule_info_t          *rbb_rule_p = NULL;
    uint32_t                  key = 0, i = 0;
    dbg_utils_table_columns_t groups_dump_columns[] = {
        { "Direction",               15,   PARAM_STRING_E,    NULL       }, /* 0 */
        { "RBB Group Num",           20,   PARAM_UINT32_E,    &group     }, /* 1 */
        { "Port/RIF",                10,   PARAM_HEX_E,       &key       }, /* 2 */
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t rules_dump_columns[] = {
        { "Direction",        15,   PARAM_STRING_E,    NULL     }, /* 0 */
        { "Offset",           8,    PARAM_UINT32_E,    NULL     }, /* 1 */
        { "ACL Group",        14,   PARAM_HEX_E,       NULL     }, /* 2 */
        { "Bind Attrib",      14,   PARAM_HEX_E,       NULL     }, /* 3 */
        { "L2 Flood",         14,   PARAM_HEX_E,       NULL     }, /* 4 */
        { "L2 MC",            14,   PARAM_HEX_E,       NULL     }, /* 5 */
        { "L3 MC",            14,   PARAM_HEX_E,       NULL     }, /* 6 */
        { "Inner L2 Type",    14,   PARAM_HEX_E,       NULL     }, /* 7 */
        { "L3 Type",          14,   PARAM_HEX_E,       NULL     }, /* 8 */
        { "Inner L3 Type",    14,   PARAM_HEX_E,       NULL     }, /* 9 */
        { "IP Fragment",      14,   PARAM_HEX_E,       NULL     }, /* 10 */
        { "Inner IP Frag",    14,   PARAM_HEX_E,       NULL     }, /* 11 */
        { "L4 Type",          14,   PARAM_HEX_E,       NULL     }, /* 12 */
        { "Inner L4 type",    14,   PARAM_HEX_E,       NULL     }, /* 13 */
        { "Tunnel Type",      14,   PARAM_HEX_E,       NULL     }, /* 14 */
        { "FPP",              14,   PARAM_HEX_E,       NULL     }, /* 15 */
        { "Inner FPP",        14,   PARAM_HEX_E,       NULL     }, /* 16 */
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t rules_groups_dump_columns[] = {
        { "Direction",  15,   PARAM_STRING_E,    NULL     }, /* 0 */
        { "Offset",     8,    PARAM_UINT32_E,    NULL     }, /* 1 */
        { "Port/Group", 10,   PARAM_HEX_E,       NULL     }, /* 2 */
        {NULL, 0, 0, NULL}
    };
    boolean_t                 first = TRUE;
    FILE                     *stream = NULL;

    /* Can be called even if the module was not initialized (for older chips) */
    if (!g_is_initialized) {
        return;
    }
    rc = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(rc)) {
        return;
    }
    stream = dbg_dump_params_p->stream;

    for (direction = SX_ACL_RBB_DIRECTION_EGRESS_E; direction < RBB_DIRECTION_NUM; direction++) {
        groups_dump_columns[0].data = sx_acl_rbb_direction_str(direction);
        for (group = 0; group < RBB_GROUPS_MAX; group++) {
            if (!cl_is_map_empty(&g_rbb_groups_db[direction][group])) {
                map_iter = cl_map_head(&g_rbb_groups_db[direction][group]);
                map_iter_end = cl_map_end(&g_rbb_groups_db[direction][group]);
                while (map_iter != map_iter_end) {
                    key = (uint32_t)cl_map_key(map_iter);
                    if (first) {
                        dbg_utils_pprinter_general_header_print(stream, "ACL RULE BASED BINDING GROUPS");
                        dbg_utils_pprinter_table_headline_print(stream, groups_dump_columns);
                        first = FALSE;
                    }
                    dbg_utils_pprinter_table_data_line_print(stream, groups_dump_columns);
                    map_iter = cl_map_next(map_iter);
                }
            }
        }
    }
    first = TRUE;

    for (rule_id.rule_direction = SX_ACL_RBB_DIRECTION_INGRESS_E;
         rule_id.rule_direction < RBB_DIRECTION_NUM;
         rule_id.rule_direction++) {
        for (rule_id.rule_offset = SX_ACL_RBB_RULE_OFFSET_0_E;
             rule_id.rule_offset < SX_ACL_RBB_RULE_OFFSET_LAST_E;
             rule_id.rule_offset++) {
            rbb_rule_p = &g_rules_db[rule_id.rule_direction][rule_id.rule_offset];

            if (rbb_rule_p->valid) {
                if (first) {
                    dbg_utils_pprinter_general_header_print(stream, "ACL RULE BASED BINDING RULES");
                    dbg_utils_pprinter_table_headline_print(stream, rules_dump_columns);
                    first = FALSE;
                }
                rules_dump_columns[0].data = sx_acl_rbb_direction_str(rule_id.rule_direction);
                rules_dump_columns[1].data = &rule_id.rule_offset;
                rules_dump_columns[2].data = &rbb_rule_p->group_id;
                rules_dump_columns[3].data = &rbb_rule_p->bound_attribs_id;
                rules_dump_columns[4].data = &rbb_rule_p->classifier.l2_flood_classifiers;
                rules_dump_columns[5].data = &rbb_rule_p->classifier.l2_multicast_classifiers;
                rules_dump_columns[6].data = &rbb_rule_p->classifier.l3_multicast_classifiers;
                rules_dump_columns[7].data = &rbb_rule_p->classifier.inner_l2_type_classifiers;
                rules_dump_columns[8].data = &rbb_rule_p->classifier.l3_type_classifiers;
                rules_dump_columns[9].data = &rbb_rule_p->classifier.inner_l3_type_classifiers;
                rules_dump_columns[10].data = &rbb_rule_p->classifier.ip_fragment_classifiers;
                rules_dump_columns[11].data = &rbb_rule_p->classifier.inner_ip_fragment_classifiers;
                rules_dump_columns[12].data = &rbb_rule_p->classifier.l4_type_classifiers;
                rules_dump_columns[13].data = &rbb_rule_p->classifier.inner_l4_type_classifiers;
                rules_dump_columns[14].data = &rbb_rule_p->classifier.tunnel_type_classifiers;
                rules_dump_columns[15].data = &rbb_rule_p->classifier.flex_parser_fpp_classifiers;
                rules_dump_columns[16].data = &rbb_rule_p->classifier.inner_flex_parser_fpp_classifiers;

                dbg_utils_pprinter_table_data_line_print(stream, rules_dump_columns);
            }
        }
    }
    first = TRUE;

    for (rule_id.rule_direction = SX_ACL_RBB_DIRECTION_INGRESS_E;
         rule_id.rule_direction < RBB_DIRECTION_NUM;
         rule_id.rule_direction++) {
        for (rule_id.rule_offset = SX_ACL_RBB_RULE_OFFSET_0_E;
             rule_id.rule_offset < SX_ACL_RBB_RULE_OFFSET_LAST_E;
             rule_id.rule_offset++) {
            rbb_rule_p = &g_rules_db[rule_id.rule_direction][rule_id.rule_offset];

            if (rbb_rule_p->valid) {
                if (first) {
                    dbg_utils_pprinter_general_header_print(stream, "ACL RULE BASED BINDING RULES PORTS/GROUPS");
                    dbg_utils_pprinter_table_headline_print(stream, rules_groups_dump_columns);
                    first = FALSE;
                }
                rules_groups_dump_columns[0].data = sx_acl_rbb_direction_str(rule_id.rule_direction);
                rules_groups_dump_columns[1].data = &rule_id.rule_offset;

                switch (rule_id.rule_direction) {
                case SX_ACL_RBB_DIRECTION_INGRESS_E:
                    for (i = 0;
                         i < rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_cnt;
                         i++) {
                        rules_groups_dump_columns[2].data =
                            &rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.rbb_port_list[i];
                        dbg_utils_pprinter_table_data_line_print(stream, rules_groups_dump_columns);
                    }
                    for (i = 0;
                         i <
                         rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.rbb_tunnel_port_cnt;
                         i++) {
                        rules_groups_dump_columns[2].data =
                            &rbb_rule_p->classifier.bind_object_classifiers.ingress_port_classifiers.
                            rbb_tunnel_port_list[i
                            ];
                        dbg_utils_pprinter_table_data_line_print(stream, rules_groups_dump_columns);
                    }
                    break;

                case SX_ACL_RBB_DIRECTION_EGRESS_E:
                    for (i = 0;
                         i < rbb_rule_p->classifier.bind_object_classifiers.egress_port_classifiers.rbb_port_group_cnt;
                         i++) {
                        rules_groups_dump_columns[2].data =
                            &rbb_rule_p->classifier.bind_object_classifiers.egress_port_classifiers.rbb_port_group_list
                            [i];
                        dbg_utils_pprinter_table_data_line_print(stream, rules_groups_dump_columns);
                    }
                    for (i = 0;
                         i <
                         rbb_rule_p->classifier.bind_object_classifiers.egress_port_classifiers.rbb_tunnel_port_cnt;
                         i++) {
                        rules_groups_dump_columns[2].data =
                            &rbb_rule_p->classifier.bind_object_classifiers.egress_port_classifiers.
                            rbb_tunnel_port_list[i];
                        dbg_utils_pprinter_table_data_line_print(stream, rules_groups_dump_columns);
                    }
                    break;

                case SX_ACL_RBB_DIRECTION_RIF_INGRESS_E:
                    for (i = 0;
                         i < rbb_rule_p->classifier.bind_object_classifiers.ingress_rif_classifiers.rbb_rif_group_cnt;
                         i++) {
                        rules_groups_dump_columns[2].data =
                            &rbb_rule_p->classifier.bind_object_classifiers.ingress_rif_classifiers.rbb_rif_group_list[
                                i];
                        dbg_utils_pprinter_table_data_line_print(stream, rules_groups_dump_columns);
                    }
                    break;

                case SX_ACL_RBB_DIRECTION_RIF_EGRESS_E:
                    for (i = 0;
                         i < rbb_rule_p->classifier.bind_object_classifiers.egress_rif_classifiers.rbb_rif_group_cnt;
                         i++) {
                        rules_groups_dump_columns[2].data =
                            &rbb_rule_p->classifier.bind_object_classifiers.egress_rif_classifiers.rbb_rif_group_list[i
                            ];
                        dbg_utils_pprinter_table_data_line_print(stream, rules_groups_dump_columns);
                    }
                    break;


                default:
                    break;
                }
            }
        }
    }
}
