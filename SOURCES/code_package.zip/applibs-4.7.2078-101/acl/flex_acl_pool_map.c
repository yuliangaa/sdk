/*
 * Copyright (C) 2015-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "flex_acl_pool_map.h"


#undef  __MODULE__
#define __MODULE__ ACL

#include <complib/sx_log.h>
#include <complib/cl_dbg.h>

/***********************************************
*  Local variables
***********************************************/


typedef sx_status_t (*pool_map_fn_t)(flex_acl_pool_map_t *self, flex_acl_pool_map_entry_t *entry);

/************************************************
 *  Global variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/
static void __entry_deinit(const cl_pool_item_t * const p_pool_item, void *context);
cl_status_t __entry_init(void *const p_object, void *context __attribute__(
                             (unused)), cl_pool_item_t ** const pp_pool_item);
static sx_status_t __pool_map_push_entry(flex_acl_pool_map_t* self, flex_acl_pool_map_entry_t *entry);

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t flex_acl_pool_map_init(flex_acl_pool_map_t * self,
                                   obj_create_fn_t       obj_create_func,
                                   obj_destroy_fn_t      obj_destroy_func,
                                   obj_compare_fn_t      obj_compare_func,
                                   obj_hash_fn_t         obj_hash_func,
                                   uint32_t              min_size,
                                   uint32_t              max_size,
                                   uint32_t              grow_size)
{
    cl_status_t cl_status = CL_SUCCESS;
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    if (SX_CHECK_FAIL(rc = utils_check_pointer(obj_destroy_func, "obj_destroy_func"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(obj_create_func, "obj_create_func"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(self, "pool map object"))) {
        goto out;
    }

    cl_status = CL_QPOOL_INIT(&(self->pool), min_size, max_size, grow_size, sizeof(flex_acl_pool_map_entry_t),
                              __entry_init, __entry_deinit, self);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Failed to Init pool map structure\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    cl_qmap_init(&(self->map));

    self->map_count = 0;
    self->obj_create_func = obj_create_func;
    self->obj_destroy_func = obj_destroy_func;
    self->obj_compare_func = obj_compare_func;
    self->obj_hash_func = obj_hash_func;
out:
    SX_LOG_EXIT();
    return rc;
}

cl_status_t __entry_init(void *const p_object, void *context __attribute__(
                             (unused)), cl_pool_item_t ** const pp_pool_item)
{
    cl_status_t                err = CL_SUCCESS;
    flex_acl_pool_map_entry_t *entry = (flex_acl_pool_map_entry_t*)p_object;
    flex_acl_pool_map_t       *self = (flex_acl_pool_map_t*)context;

    SX_LOG_ENTER();

    entry->handle = 0;

    err = cl_list_init(&entry->obj_list, 1);
    if (CL_SUCCESS != err) {
        SX_LOG(SX_LOG_ERROR, "pool map cl_list_init failed\n");
        goto out;
    }

    /* Object map is used to store objects in a map in addition to storing them in a list.
     * If an object is used in more than a threshold amount of multiple rules,
     * insert the objects into the map in order to speed up removal of rules, by avoiding iterating over the list. */
    entry->obj_map = NULL;

    self->pool_size++;
    *pp_pool_item = &(entry->pool_item);

out:
    SX_LOG_EXIT();
    return err;
}

static void __entry_deinit(const cl_pool_item_t * const p_pool_item, void *context)
{
    flex_acl_pool_map_entry_t *entry = PARENT_STRUCT(p_pool_item, flex_acl_pool_map_entry_t, pool_item);
    flex_acl_pool_map_t       *self = (flex_acl_pool_map_t*)context;

    SX_LOG_ENTER();

    cl_list_apply_func(&entry->obj_list, self->obj_destroy_func, NULL);
    cl_list_remove_all(&entry->obj_list);
    cl_list_destroy(&entry->obj_list);
    if (entry->obj_map != NULL) {
        cl_map_remove_all(entry->obj_map);
        cl_map_destroy(entry->obj_map);
        utils_memory_put(entry->obj_map, UTILS_MEM_TYPE_ID_ACL_E);
        entry->obj_map = NULL;
    }
    self->pool_size--;

    UNUSED_PARAM(context);

    SX_LOG_EXIT();
}

/* take the item from map, clean item and return it to the pool*/
static sx_status_t __pool_map_push_entry(flex_acl_pool_map_t* self, flex_acl_pool_map_entry_t *entry)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(self, "pool map object"))) {
        goto out;
    }

    if (entry != NULL) {
        /* empty created object list */
        cl_list_apply_func(&entry->obj_list, self->obj_destroy_func, NULL);
        cl_list_remove_all(&entry->obj_list);
        /* empty created object map if initiated*/
        if (entry->obj_map != NULL) {
            cl_map_remove_all(entry->obj_map);
            cl_map_destroy(entry->obj_map);
            utils_memory_put(entry->obj_map, UTILS_MEM_TYPE_ID_ACL_E);
            entry->obj_map = NULL;
        }
        /* reinitialize */
        entry->handle = 0;
        /* remove item from map */
        cl_qmap_remove_item(&self->map, &entry->map_item);
        cl_qpool_put(&self->pool, &entry->pool_item);
        self->pool_size++;
        goto out;
    }
    rc = SX_STATUS_PARAM_NULL;
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __pool_map_entry_deinit(flex_acl_pool_map_t *self, flex_acl_pool_map_entry_t *entry)
{
    return __pool_map_push_entry(self, entry);
}

sx_status_t __pool_map_foreach(flex_acl_pool_map_t* self, pool_map_fn_t func)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    cl_map_item_t             *map_item;
    const cl_map_item_t       *map_end = NULL;
    flex_acl_pool_map_entry_t *entry = NULL;

    SX_LOG_ENTER();
    if (SX_CHECK_FAIL(rc = utils_check_pointer(self, "pool map object"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(func, "pool map apply function"))) {
        goto out;
    }

    map_item = cl_qmap_head(&(self->map));
    map_end = cl_qmap_end(&(self->map));
    while (map_item != map_end) {
        entry = PARENT_STRUCT(map_item, flex_acl_pool_map_entry_t, map_item);
        map_item = cl_qmap_next(map_item);
        /* apply function to entry */
        rc = func(self, entry);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to apply func on map element, rc=[%u]\n", rc);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_pool_map_deinit(flex_acl_pool_map_t* self)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(self, "pool map object"))) {
        goto out;
    }

    if (self->map.state == CL_INITIALIZED) {
        /* return all used elements in map to pool*/
        rc = __pool_map_foreach(self, __pool_map_entry_deinit);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to deinit pool map entries\n");
            goto out;
        }

        cl_qmap_remove_all(&self->map);
    }

    if (cl_is_qpool_inited(&self->pool)) {
        CL_QPOOL_DESTROY(&self->pool);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* adds entry to the map. If the entry already exist, simply adds user object to list of user objects*/
sx_status_t flex_acl_pool_map_add_entry(flex_acl_pool_map_t *self, uint64_t handle, void* obj_to_store)
{
    cl_status_t                cl_rc = CL_SUCCESS;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    cl_pool_item_t            *pool_item = NULL;
    cl_list_iterator_t         iter;
    flex_acl_pool_map_entry_t *entry = NULL;
    void                     * new_obj = NULL;
    cl_map_item_t             *map_item = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(self, "object self"))) {
        goto out;
    }

    /* get free item from the pool */
    pool_item = cl_qpool_get(&self->pool);
    if (pool_item == NULL) {
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }
    entry = PARENT_STRUCT(pool_item, flex_acl_pool_map_entry_t, pool_item);

    /* insert item into map */
    entry->handle = handle;
    map_item = cl_qmap_insert(&self->map, handle, &entry->map_item);
    if (map_item != &entry->map_item) {
        /* the entry already exist in map, return allocated entry to pool*/
        cl_qpool_put(&self->pool, pool_item);
    }

    /* now map item point to real map item*/
    entry = PARENT_STRUCT(map_item, flex_acl_pool_map_entry_t, map_item);

    /* create object to store in a list */
    cl_rc = self->obj_create_func(&new_obj, obj_to_store);
    if (CL_SUCCESS != cl_rc) {
        SX_LOG_ERR("Failed to create object to store in list\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto rollback_map_insert;
    }

    /* insert created object to list */
    cl_rc = cl_list_insert_head(&entry->obj_list, new_obj);
    if (CL_SUCCESS != cl_rc) {
        SX_LOG_ERR("Failed to insert item to list in pool_map\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto rollback_obj_create;
    }

    /* insert object into map if amount of objects is over the threshold */
    if ((cl_list_count(&entry->obj_list) >= OBJ_LIST_THRESHOLD) && (self->obj_hash_func != NULL)) {
        /* if map doesn't exists yet, create it */
        if (entry->obj_map == NULL) {
            rc = utils_clr_memory_get((void**)(&entry->obj_map), 1, sizeof(cl_map_t),
                                      UTILS_MEM_TYPE_ID_ACL_E);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get memory for object map: [%u]\n", rc);
                goto rollback_insert_head;
            }
            cl_rc = cl_map_init(entry->obj_map, 4);
            if (CL_SUCCESS != cl_rc) {
                SX_LOG_ERR("Failed to initialize object map\n");
                rc = SX_STATUS_NO_RESOURCES;
                goto rollback_map_memory_get;
            }
        }
        iter = cl_list_head(&entry->obj_list);
        /* Insert object into the map because the threshold was crossed, so in order to speed up object removal
         * in the future, we add the object to the map to avoid iterating over the object list. */
        if (cl_map_insert(entry->obj_map, self->obj_hash_func(obj_to_store, handle), iter) == NULL) {
            SX_LOG_ERR("Failed to insert object into map\n");
            rc = SX_STATUS_NO_RESOURCES;
            if (cl_is_map_empty(entry->obj_map)) {
                /* if the object map was just created and insertion failed we deinit the map */
                goto rollback_map_init;
            } else {
                /* else the map wasn't created now and we leave it as is and only roll back the insertion to the list */
                goto rollback_insert_head;
            }
        }
    }
    goto out;

rollback_map_init:
    cl_map_remove_all(entry->obj_map);
    cl_map_destroy(entry->obj_map);
rollback_map_memory_get:
    utils_memory_put(entry->obj_map, UTILS_MEM_TYPE_ID_ACL_E);
    entry->obj_map = NULL;
rollback_insert_head:
    cl_list_remove_object(&entry->obj_list, new_obj);
rollback_obj_create:
    self->obj_destroy_func(new_obj, NULL);
rollback_map_insert:
    if (map_item == &entry->map_item) {
        /* the entry already exist in map, return allocated entry to pool*/
        cl_qpool_put(&self->pool, pool_item);
        cl_qmap_remove_item(&self->map, &entry->map_item);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* remove specified by obj object from object list in specified by handle map entry. If list became empty,
 * removes item from map and return it to pool */
sx_status_t flex_acl_pool_map_remove_entry(flex_acl_pool_map_t *self, uint64_t handle, void* obj)
{
    cl_map_item_t             *map_item = NULL;
    const cl_map_item_t       *map_end = NULL;
    cl_list_iterator_t         iter = NULL;
    cl_list_iterator_t         list_end = NULL;
    flex_acl_pool_map_entry_t *entry = NULL;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    boolean_t                  found = FALSE;
    uint64_t                   obj_hash = 0;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(self, "pool map object"))) {
        goto out;
    }

    map_item = cl_qmap_get(&(self->map), handle);
    map_end = cl_qmap_end(&(self->map));
    if (map_item == map_end) {
        /* the entry doesn't exist */
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    entry = PARENT_STRUCT(map_item, flex_acl_pool_map_entry_t, map_item);

    /* make sure the map is initiated and,
     * that the object hash function is not NULL before using it because it is a non-mandatory function */
    if ((entry->obj_map != NULL) && (self->obj_hash_func != NULL)) {
        obj_hash = self->obj_hash_func(obj, handle);
    }
    /* try to find the entry in the map */
    if ((entry->obj_map != NULL) &&
        (cl_map_contains(entry->obj_map, obj_hash) == TRUE) &&
        self->obj_compare_func(cl_list_obj(cl_map_get(entry->obj_map, obj_hash)), obj)) {
        iter = cl_map_get(entry->obj_map, obj_hash);
        cl_map_remove(entry->obj_map, obj_hash);
        found = TRUE;
    } else {
        /* find entry in the list if exist*/
        iter = cl_list_head(&entry->obj_list);
        list_end = cl_list_end(&entry->obj_list);

        while (iter != list_end) {
            if (self->obj_compare_func(cl_list_obj(iter), obj)) {
                found = TRUE;
                break;
            }
            iter = cl_list_next(iter);
        }
    }
    if (found) {
        /* delete object*/
        self->obj_destroy_func(cl_list_obj(iter), NULL);
        cl_list_remove_item(&entry->obj_list, iter);
    } else {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if ((entry->obj_map != NULL) && (cl_list_count(&entry->obj_list) == 0)) {
        cl_map_remove_all(entry->obj_map);
        cl_map_destroy(entry->obj_map);
        utils_memory_put(entry->obj_map, UTILS_MEM_TYPE_ID_ACL_E);
        entry->obj_map = NULL;
    }
    if (cl_list_count(&entry->obj_list) == 0) {
        __pool_map_push_entry(self, entry);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_pool_map_for_each(flex_acl_pool_map_t *self, pool_map_apply_on_each_p_fn func_p, void* context)
{
    cl_map_item_t             *map_item = NULL;
    const cl_map_item_t       *map_end = NULL;
    cl_list_iterator_t         iter = NULL;
    cl_list_iterator_t         list_end = NULL;
    flex_acl_pool_map_entry_t *entry = NULL;
    sx_status_t                rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(self, "pool map object"))) {
        goto out;
    }

    map_item = cl_qmap_head(&(self->map));
    map_end = cl_qmap_end(&(self->map));
    while (map_item != map_end) {
        entry = PARENT_STRUCT(map_item, flex_acl_pool_map_entry_t, map_item);
        map_item = cl_qmap_next(map_item);

        /* find entry in the list if exists */
        iter = cl_list_head(&entry->obj_list);
        list_end = cl_list_end(&entry->obj_list);

        while (iter != list_end) {
            rc = func_p(cl_list_obj(iter), context);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error at apply function on list item: %s\n", sx_status_str(rc));
                goto out;
            }
            iter = cl_list_next(iter);
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_pool_map_object_list_get(flex_acl_pool_map_t* self, uint64_t handle, cl_list_t** obj_list)
{
    cl_map_item_t             *map_item = NULL;
    const cl_map_item_t       *map_end = NULL;
    flex_acl_pool_map_entry_t *entry = NULL;
    sx_status_t                rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(self, "pool map object"))) {
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(obj_list, "obj_list"))) {
        goto out;
    }

    map_item = cl_qmap_get(&(self->map), handle);
    map_end = cl_qmap_end(&(self->map));
    if (map_item == map_end) {
        /* the entry doesn't exist */
        *obj_list = NULL;
        SX_LOG_DBG("Failed resolve entry in map\n");
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    entry = PARENT_STRUCT(map_item, flex_acl_pool_map_entry_t, map_item);
    *obj_list = &entry->obj_list;

out:
    SX_LOG_EXIT();
    return rc;
}

uint32_t flex_acl_pool_map_size(flex_acl_pool_map_t* self)
{
    if (SX_CHECK_FAIL(utils_check_pointer(self, "pool map object"))) {
        return 0;
    }
    return cl_qmap_count(&self->map);
}
