/*
 * Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include "system_acl.h"
#include "acl/flex_acl_db.h"
#include "acl/flex_acl_hw.h"
#include "acl/flex_acl_hw_db.h"
#include "acl/flex_acl_binding.h"
#include "acl/flex_acl_keys.h"
#include "acl/system_acl_mc.h"
#include "sx/utils/dbg_utils.h"
#include "sx/utils/dbg_utils_pretty_printer.h"
#include "ethl3/router_common.h"
#include "ethl2/port.h"
#include "issu/issu.h"

/************************************************
 *  Global variables
 ***********************************************/
extern boolean_t       g_flex_acl_initialized;
extern flex_acl_ops_t *flex_acl_ops_g;
extern acl_stage_e     g_acl_stage;

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local Defines
 ***********************************************/


#define SYSTEM_ACL_REGION_DEFAULT_SIZE 3
#define SYSTEM_ACL_INVALID_ID          0xFFFFFFFF
#define INSTANCE_INFO_INIT(NUM)                                                 \
    ((system_acl_instance_info_t[NUM]) {[0 ... (NUM - 1)] =                     \
                                        {.is_initialized = FALSE,               \
                                         .region_id = SYSTEM_ACL_INVALID_ID,    \
                                         .acl_id = SYSTEM_ACL_INVALID_ID,       \
                                         .acl_group_id = SYSTEM_ACL_INVALID_ID} \
     })
#define MAX_STR_LEN 40
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
system_acl_client_table_entry_t system_acl_clients_table[SYSTEM_ACL_CLIENT_ID_LAST_E] = {
    [SYSTEM_ACL_CLIENT_ID_INVALID_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_INVALID_E,
        .keys = {0},
        .num_of_keys = 0,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_LAST_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_DEFAULT_SIZE,
        .instances_allowed = 0,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_INVALID_ID,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .is_rules_rm_needed = TRUE,
        .instance_info = NULL
    },
    [SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E,
        .keys = {FLEX_ACL_KEY_SIP,
                 FLEX_ACL_KEY_DIP,
                 FLEX_ACL_KEY_VIRTUAL_ROUTER,
                 FLEX_ACL_KEY_IRIF},
        .num_of_keys = 4,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_MC_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_DEFAULT_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E + SX_ACL_KEY_TYPE_LAST,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_NONE_E,
        .is_rules_rm_needed = FALSE,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E,
        .keys = {FLEX_ACL_KEY_SIPV6,
                 FLEX_ACL_KEY_DIPV6,
                 FLEX_ACL_KEY_VIRTUAL_ROUTER,
                 FLEX_ACL_KEY_IRIF},
        .num_of_keys = 4,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_MC_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_DEFAULT_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E + SX_ACL_KEY_TYPE_LAST,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_NONE_E,
        .is_rules_rm_needed = FALSE,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_E,
        .keys = {FLEX_ACL_KEY_VIRTUAL_ROUTER,
                 FLEX_ACL_KEY_DIP,
                 FLEX_ACL_KEY_SIP,
                 FLEX_ACL_KEY_L3_TYPE,
                 FLEX_ACL_KEY_TUNNEL_TYPE,
                 FLEX_ACL_KEY_TUNNEL_NVE_TYPE},
        .num_of_keys = 6,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_INGRESS_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_SPC2_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_SPC2_E,
        .keys = {FLEX_ACL_KEY_VIRTUAL_ROUTER,
                 FLEX_ACL_KEY_DIP,
                 FLEX_ACL_KEY_SIP,
                 FLEX_ACL_KEY_L3_TYPE,
                 FLEX_ACL_KEY_TUNNEL_TYPE,
                 FLEX_ACL_KEY_TUNNEL_NVE_TYPE,
                 FLEX_ACL_KEY_FPP_0_TOUCHED,
                 FLEX_ACL_KEY_FPP_1_TOUCHED,
                 FLEX_ACL_KEY_FPP_2_TOUCHED,
                 FLEX_ACL_KEY_FPP_3_TOUCHED,
                 FLEX_ACL_KEY_FPP_4_TOUCHED,
                 FLEX_ACL_KEY_FPP_5_TOUCHED,
                 FLEX_ACL_KEY_FPP_6_TOUCHED,
                 FLEX_ACL_KEY_FPP_7_TOUCHED},
        .num_of_keys = 14,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_INGRESS_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_SPC2_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_E,
        .keys = {FLEX_ACL_KEY_VIRTUAL_ROUTER,
                 FLEX_ACL_KEY_DIPV6,
                 FLEX_ACL_KEY_SIPV6,
                 FLEX_ACL_KEY_L3_TYPE,
                 FLEX_ACL_KEY_TUNNEL_TYPE,
                 FLEX_ACL_KEY_TUNNEL_NVE_TYPE},
        .num_of_keys = 6,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_INGRESS_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_SPC2_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_SPC2_E,
        .keys = {FLEX_ACL_KEY_VIRTUAL_ROUTER,
                 FLEX_ACL_KEY_DIPV6,
                 FLEX_ACL_KEY_SIPV6,
                 FLEX_ACL_KEY_L3_TYPE,
                 FLEX_ACL_KEY_TUNNEL_TYPE,
                 FLEX_ACL_KEY_TUNNEL_NVE_TYPE,
                 FLEX_ACL_KEY_FPP_0_TOUCHED,
                 FLEX_ACL_KEY_FPP_1_TOUCHED,
                 FLEX_ACL_KEY_FPP_2_TOUCHED,
                 FLEX_ACL_KEY_FPP_3_TOUCHED,
                 FLEX_ACL_KEY_FPP_4_TOUCHED,
                 FLEX_ACL_KEY_FPP_5_TOUCHED,
                 FLEX_ACL_KEY_FPP_6_TOUCHED,
                 FLEX_ACL_KEY_FPP_7_TOUCHED},
        .num_of_keys = 14,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_INGRESS_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_TUNNEL_MIN_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_SPC2_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_METADATA_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_IGMP_V3_METADATA_E,
        .keys = {FLEX_ACL_KEY_L3_TYPE,
                 FLEX_ACL_KEY_USER_TOKEN,
                 FLEX_ACL_KEY_DIP,
                 (sx_acl_key_t)FLEX_ACL_SYSTEM_KEY_DIPV6_MSB,
                 FLEX_ACL_KEY_DMAC},
        .num_of_keys = 5,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_VLAN_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_IGMP_V3_METADATA_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_IGMP_V3_METADATA_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_IPV4_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_IGMP_V3_IPV4_E,
        .keys = {FLEX_ACL_KEY_VLAN_ID,
                 FLEX_ACL_KEY_DIP,
                 FLEX_ACL_KEY_SIP},
        .num_of_keys = 3,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        /* Allocate extra 1 location for the GOTO --> Prune region [+1]*/
        .region_min_size = SYSTEM_ACL_REGION_IGMP_V3_IPV4_MIN_SIZE + 1,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_IGMP_V3_IPV4_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_IPV6_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_IGMP_V3_IPV6_E,
        .keys = {FLEX_ACL_KEY_VLAN_ID,
                 (sx_acl_key_t)FLEX_ACL_SYSTEM_KEY_DIPV6_LSB,
                 FLEX_ACL_KEY_SIPV6},
        .num_of_keys = 3,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        /* Allocate extra 1 location for the GOTO --> Prune region [+1]*/
        .region_min_size = SYSTEM_ACL_REGION_IGMP_V3_IPV6_MIN_SIZE + 1,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_IGMP_V3_IPV6_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_METADATA_ERIF_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_IGMP_V3_METADATA_ERIF_E,
        .keys = {FLEX_ACL_KEY_L3_TYPE,
                 FLEX_ACL_KEY_USER_TOKEN,
                 FLEX_ACL_KEY_DMAC},
        .num_of_keys = 3,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_RIF_EGRESS_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_AFTER_USER,
        .region_min_size = SYSTEM_ACL_REGION_IGMP_V3_METADATA_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_IGMP_V3_METADATA_ERIF_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_PRUNE_IPV4_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_IGMP_V3_PRUNE_IPV4_E,
        .keys = {FLEX_ACL_KEY_VLAN_ID},
        .num_of_keys = 1,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_IGMP_V3_PRUNE_MIN_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_IGMP_V3_PRUNE_IPV4_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_PRUNE_IPV6_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_IGMP_V3_PRUNE_IPV6_E,
        .keys = {FLEX_ACL_KEY_VLAN_ID},
        .num_of_keys = 1,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_IGMP_V3_PRUNE_MIN_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_IGMP_V3_PRUNE_IPV6_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_PORT_ISOLATION_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_PORT_ISOLATION_E,
        .keys = {FLEX_ACL_KEY_SRC_PORT,
                 FLEX_ACL_KEY_IS_ROUTED},
        .num_of_keys = 2,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_EGRESS_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = 15, /* HW granularity - WC rule */
        .instances_allowed = MAX_PHYPORT_NUM + MAX_LAG_NUM,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_PORT_ISOLATION_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(MAX_PHYPORT_NUM + MAX_LAG_NUM),
    },
    [SYSTEM_ACL_CLIENT_ID_L2_TPORT_ISOLATION_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_L2_TPORT_ISOLATION_E,
        .keys = {FLEX_ACL_KEY_SRC_PORT,
                 FLEX_ACL_KEY_IS_ROUTED},
        .num_of_keys = 2,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = 15, /* HW granularity - WC rule */
        .instances_allowed = 4,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_L2_TPORT_ISOLATION_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(4),
    },
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_RESTORE_VLAN_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_IGMP_V3_RESTORE_VLAN_E,
        .keys = {FLEX_ACL_KEY_VNI_KEY},
        .num_of_keys = 1,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_AFTER_USER,
        .region_min_size = SYSTEM_ACL_REGION_IGMP_V3_RESTORE_VLAN_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_IGMP_V3_RESTORE_VLAN_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_NAT_4_TO_6_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_NAT_4_TO_6_E,
        .keys = {FLEX_ACL_KEY_L3_TYPE},
        .num_of_keys = 1,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_RIF_INGRESS_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SYSTEM_ACL_REGION_DEFAULT_SIZE,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_NAT_4_TO_6_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
    [SYSTEM_ACL_CLIENT_ID_STATEFUL_DB_E] = {
        .client_id = SYSTEM_ACL_CLIENT_ID_STATEFUL_DB_E,
        .keys = {FLEX_ACL_KEY_VLAN_ID},
        .num_of_keys = 1,
        .binding_point_type = SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E,
        .system_acl_priority = SYSTEM_ACL_PRIORITY_BEFORE_USER,
        .region_min_size = SXD_FSFH_FAILURE_REASON_MAX + 1,
        .instances_allowed = 1,
        .num_of_instances = 0,
        .key_handle = SYSTEM_ACL_CLIENT_ID_STATEFUL_DB_E + SX_ACL_KEY_TYPE_LAST,
        .is_rules_rm_needed = FALSE,
        .wc_rule_type = SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E,
        .instance_info = INSTANCE_INFO_INIT(1),
    },
};
char                          * client_dictionary[SYSTEM_ACL_CLIENT_ID_LAST_E + 1] = {
    [SYSTEM_ACL_CLIENT_ID_INVALID_E] = "INVALID",
    [SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E] = "MC_ROUTER_IPV4",
    [SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E] = "MC_ROUTER_IPV6",
    [SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_E] = "TUNNEL_IPV4",
    [SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_SPC2_E] = "TUNNEL_IPV4_SPC2",
    [SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_E] = "TUNNEL_IPV6",
    [SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_SPC2_E] = "TUNNEL_IPV6_SPC2",
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_METADATA_E] = "IGMP_V3_METADATA",
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_IPV4_E] = "IGMP_V3_IPV4",
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_IPV6_E] = "IGMP_V3_IPV6",
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_METADATA_ERIF_E] = "IGMP_V3_METADATA_ERIF",
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_PRUNE_IPV4_E] = "IGMP_V3_PRUNE_IPV4",
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_PRUNE_IPV6_E] = "IGMP_V3_PRUNE_IPV6",
    [SYSTEM_ACL_CLIENT_ID_PORT_ISOLATION_E] = "PORT_ISOLATION",
    [SYSTEM_ACL_CLIENT_ID_IGMP_V3_RESTORE_VLAN_E] = "IGMP_V3_RESTORE_VLAN",
    [SYSTEM_ACL_CLIENT_ID_L2_TPORT_ISOLATION_E] = "L2_TPORT_ISOLATION",
    [SYSTEM_ACL_CLIENT_ID_NAT_4_TO_6_E] = "NAT_4_TO_6",
    [SYSTEM_ACL_CLIENT_ID_STATEFUL_DB_E] = "STATEFUL_DB"
};
char                          * binding_point_type_dictionary[SYSTEM_ACL_BINDING_POINT_LAST_E + 1] = {
    [SYSTEM_ACL_BINDING_POINT_TYPE_MC_E] = "MC",
    [SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORTS_ALL_INGRESS_E] = "L2_PORTS_ALL_INGRESS",
    [SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORTS_ALL_EGRESS_E] = "L2_PORTS_ALL_EGRESS",
    [SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_INGRESS_E] = "RIFS_ALL_INGRESS",
    [SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_EGRESS_E] = "RIFS_ALL_EGRESS",
    [SYSTEM_ACL_BINDING_POINT_TYPE_VLAN_E] = "VLANS",
    [SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E] = "NONE",
    [SYSTEM_ACL_BINDING_POINT_TYPE_RIF_INGRESS_E] = "RIF_INGRESS",
    [SYSTEM_ACL_BINDING_POINT_TYPE_RIF_EGRESS_E] = "RIF_EGRESS",
    [SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_INGRESS_E] = "L2_PORT_INGRESS",
    [SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_EGRESS_E] = "L2_PORT_EGRESS",
    [SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E] = "TPORT INGRESS",
    [SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E] = "TPORT EGRESS",
};
char                          * wc_rule_type_dictionary[SYSTEM_ACL_WC_RULE_TYPE_LAST_E + 1] = {
    [SYSTEM_ACL_WC_RULE_TYPE_DEFAULT_E] = "DEFAULT",
    [SYSTEM_ACL_WC_RULE_TYPE_NONE_E] = "NONE",
};


/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __system_acl_client_bind(system_acl_client_id_e client_id, uint32_t instance);
static sx_status_t __system_acl_client_unbind(system_acl_client_id_e client_id, uint32_t instance);
static sx_status_t __system_acl_rif_bind(system_acl_client_id_e client_id, uint32_t instance);
static sx_status_t __system_acl_rif_unbind_client(system_acl_client_id_e client_id, uint32_t instance);
static sx_status_t __system_acl_mc_bind(system_acl_client_id_e client_id, uint32_t instance);
static sx_status_t __system_acl_mc_unbind(system_acl_client_id_e client_id, uint32_t instance);
static sx_status_t __system_acl_client_deinit(system_acl_client_id_e client_id,
                                              uint32_t               instance,
                                              boolean_t              is_rollback);
static sx_status_t __system_acl_create_system_group(system_acl_client_id_e     client_id,
                                                    uint32_t                   instance,
                                                    sx_acl_direction_t         direction,
                                                    sx_api_acl_group_params_t *group_params);
static sx_status_t __system_acl_destroy_system_group(system_acl_client_id_e     client_id,
                                                     uint32_t                   instance,
                                                     sx_acl_direction_t         direction,
                                                     sx_api_acl_group_params_t *group_params);
static sx_status_t __system_acl_add_acl_to_group(system_acl_client_id_e client_id,
                                                 uint32_t               instance,
                                                 sx_acl_id_t            acl_id,
                                                 boolean_t             *group_created);
static sx_status_t __system_acl_remove_acl_from_group(system_acl_client_id_e client_id, uint32_t instance);
static sx_status_t __system_acl_get_rifs_list(uint16_t *rif_list, uint32_t *rif_count);
static sx_status_t __system_acl_get_decap_rifs_list(uint16_t *rif_list, uint32_t *rif_count);
static sx_status_t __system_acl_client_vlan_bind(system_acl_client_id_e client_id);
static sx_status_t __system_acl_client_vlan_unbind(system_acl_client_id_e client_id);
static sx_status_t __system_acl_create_bind_group(system_acl_client_id_e      client_id,
                                                  uint32_t                    instance,
                                                  flex_acl_bind_attribs_id_t *new_bind_attribs_id);
static sx_status_t __system_acl_delete_bind_group(system_acl_client_id_e client_id,
                                                  uint32_t               instance);
static sx_status_t __system_acl_individual_unbind_groups(system_acl_client_id_e client_id,
                                                         uint32_t               instance,
                                                         sx_acl_id_t            group_id);
static sx_status_t __system_acl_individual_client_unbind(system_acl_client_id_e client_id, uint32_t instance);
/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t system_acl_client_get(sx_acl_region_id_t region_id, system_acl_client_table_entry_t **client_table_entry)
{
    uint32_t    i = 0, j = 0;
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(client_table_entry, "client_table_entry"))) {
        goto out;
    }

    *client_table_entry = NULL;

    for (i = SYSTEM_ACL_CLIENT_ID_INVALID_E + 1; i < SYSTEM_ACL_CLIENT_ID_LAST_E; i++) {
        for (j = 0; j < system_acl_clients_table[i].instances_allowed; j++) {
            if (system_acl_clients_table[i].instance_info[j].region_id == region_id) {
                *client_table_entry = &system_acl_clients_table[i];
                break;
            }
        }
        if (*client_table_entry != NULL) {
            break;
        }
    }
    if (i == SYSTEM_ACL_CLIENT_ID_LAST_E) {
        SX_LOG_DBG("Client entry for region_id[%#x] not found in db\n", region_id);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* return not found when id is illegal, return NULL if id is INVALID */
sx_status_t system_acl_client_get_by_id(system_acl_client_id_e            client_id,
                                        system_acl_client_table_entry_t **client_table_entry_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(client_table_entry_p, "client_table_entry_p"))) {
        goto out;
    }
    *client_table_entry_p = NULL;

    if (client_id >= SYSTEM_ACL_CLIENT_ID_LAST_E) {
        SX_LOG_ERR("Provided client id[%u] are illegal\n", client_id);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *client_table_entry_p = &system_acl_clients_table[client_id];
out:
    SX_LOG_EXIT();
    return rc;
}

/* return not found when id or instance is illegal, return NULL if id is INVALID */
sx_status_t system_acl_instance_get_by_id(system_acl_client_id_e       client_id,
                                          uint32_t                     instance_num,
                                          system_acl_instance_info_t **instance_info_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(instance_info_p, "instance_info_p"))) {
        goto out;
    }
    *instance_info_p = NULL;

    if (client_id >= SYSTEM_ACL_CLIENT_ID_LAST_E) {
        SX_LOG_ERR("Provided client id[%u] are illegal\n", client_id);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (instance_num >= system_acl_clients_table[client_id].instances_allowed) {
        SX_LOG_ERR("Provided instance[%u] for client id[%u] is illegal\n", instance_num, client_id);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *instance_info_p = &(system_acl_clients_table[client_id].instance_info[instance_num]);
out:
    SX_LOG_EXIT();
    return rc;
}

/* A small utility function (without validation) to identify binding point type that are automatic (vs. explicit or non binding). */
static inline boolean_t __is_automatic_binding_point(system_acl_binding_point_type_e binding_point_type)
{
    boolean_t is_automatic_binding = TRUE;

    switch (binding_point_type) {
    case SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIF_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIF_EGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_EGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_MC_E:
        is_automatic_binding = FALSE;
        break;

    default:
        break;
    }

    return is_automatic_binding;
}

static sx_status_t __sys_acl_group_prio_set(sx_acl_id_t group_id, system_acl_client_id_e client_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    uint32_t                 priority = 0;
    flex_acl_db_acl_group_t *acl_group = NULL;


    priority = FLEX_ACL_GROUP_PRIORITY_MIN - 1;
    if (system_acl_clients_table[client_id].system_acl_priority == SYSTEM_ACL_PRIORITY_BEFORE_USER) {
        priority = FLEX_ACL_GROUP_PRIORITY_MAX + 2;
        if (__is_automatic_binding_point(system_acl_clients_table[client_id].binding_point_type)) {
            priority = FLEX_ACL_GROUP_PRIORITY_MAX + 1;
        }
    }

    /* Get Group ID from DB */
    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL group id [0x%x]\n", group_id);
        goto out;
    }

    /* Internally set group priority */
    acl_group->group_prio = priority;

out:
    return rc;
}

/* the function creates new acl group and adds it to system_acl_group db by direction(or bind point type)
 * if group added by direction - it will be update all the acl groups with new acls if added to system group*/
static sx_status_t __system_acl_create_system_group(system_acl_client_id_e     client_id,
                                                    uint32_t                   instance,
                                                    sx_acl_direction_t         direction,
                                                    sx_api_acl_group_params_t *group_params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    group_params->acl_direction = direction;
    group_params->cmd = SX_ACCESS_CMD_CREATE;
    rc = flex_acl_group_set_internal(group_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create group for system purposes\n");
        goto out;
    }
    system_acl_clients_table[client_id].instance_info[instance].acl_group_id = group_params->group_id;

    rc = flex_acl_set_acl_entry_type(group_params->group_id, FLEX_ACL_ENTRY_TYPE_SYSTEM_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set entry type for group id[%u]\n", group_params->group_id);
        goto out;
    }
    if ((system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_VLAN_E) &&
        (__is_automatic_binding_point(system_acl_clients_table[client_id].binding_point_type))) {
        rc = flex_acl_db_set_system_acl_group(system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                              direction);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set system group[%u] for direction[%u]\n",
                       system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                       direction);
            goto out;
        }
    }
    group_params->acl_ids_num = 0;

    /* Set the priority of the system ACL in the group */
    rc = __sys_acl_group_prio_set(system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                  client_id);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __system_acl_destroy_system_group(system_acl_client_id_e     client_id,
                                                     uint32_t                   instance,
                                                     sx_acl_direction_t         direction,
                                                     sx_api_acl_group_params_t *group_params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if ((system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_VLAN_E) &&
        (__is_automatic_binding_point(system_acl_clients_table[client_id].binding_point_type))) {
        rc = flex_acl_db_set_system_acl_group(FLEX_ACL_INVALID_ACL_ID, direction);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to set system group[%u] for direction[%u]\n",
                       system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                       direction);
            goto out;
        }
    }
    group_params->group_id = system_acl_clients_table[client_id].instance_info[instance].acl_group_id;
    group_params->acl_direction = direction;
    group_params->cmd = SX_ACCESS_CMD_DESTROY;
    rc = flex_acl_group_set_internal(group_params);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to create group for system purposes\n");
        goto out;
    }
    system_acl_clients_table[client_id].instance_info[instance].acl_group_id = FLEX_ACL_INVALID_ACL_ID;


out:
    SX_LOG_EXIT();
    return rc;
}
/* the function creates system group per direction and adds to it new system acl */
static sx_status_t __system_acl_add_acl_to_group(system_acl_client_id_e client_id,
                                                 uint32_t               instance,
                                                 sx_acl_id_t            acl_id,
                                                 boolean_t             *group_created)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rb_rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t         direction = SX_ACL_DIRECTION_LAST;
    sx_acl_id_t                group_id = FLEX_ACL_INVALID_ACL_ID;
    sx_api_acl_group_params_t *group_params_p = NULL;
    acl_stage_e                acl_stage = ACL_STAGE_UNKNOWN;

    SX_LOG_ENTER();

    *group_created = FALSE;

    rc = flex_acl_ops_g->acl_stage_get_p(&acl_stage);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to retrieve acl stage for adding to system acl group.\n");
        goto out;
    }

    if (((system_acl_clients_table[client_id].binding_point_type == SYSTEM_ACL_BINDING_POINT_TYPE_MC_E) &&
         (acl_stage == ACL_STAGE_FLEX)) ||
        (client_id == SYSTEM_ACL_CLIENT_ID_STATEFUL_DB_E)) {
        /* For stateful DB and for mc bind point (flex1) there is no need for a group. */
        goto out;
    }

    direction = system_acl_get_direction(system_acl_clients_table[client_id].binding_point_type);

    group_params_p = cl_malloc(
        sizeof(sx_api_acl_group_params_t) + sizeof(sx_acl_id_t) * rm_resource_global.acl_groups_size_max);
    if (group_params_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory\n");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    SX_MEM_CLR(*group_params_p);

    /* get system acl group from db, it matters when user make bind/unbind operations */
    if (__is_automatic_binding_point(system_acl_clients_table[client_id].binding_point_type)) {
        rc = flex_acl_db_get_system_acl_group(direction, &group_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to get system group for direction[%u]\n", direction);
            goto out;
        }
    }

    if (group_id == FLEX_ACL_INVALID_ACL_ID) {
        /* create new group and add acl there */
        rc = __system_acl_create_system_group(client_id, instance, direction, group_params_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to set group for system purposes, group_id[%u]\n", group_params_p->group_id);
            goto out;
        }
        group_id = group_params_p->group_id;
        *group_created = TRUE;
    } else {
        group_params_p->group_id = group_id;
        *group_created = FALSE;

        /* get system group content */
        group_params_p->acl_ids_num = rm_resource_global.acl_groups_size_max;
        group_params_p->cmd = SX_ACCESS_CMD_GET;
        rc = flex_acl_group_get_internal(group_params_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to get system group[%u], rc = %s\n", group_id, sx_status_str(rc));
            goto error;
        }
        /* check that acls number in group does not greater than max acls in group */
        if (group_params_p->acl_ids_num >= rm_resource_global.acl_groups_size_max) {
            rc = SX_STATUS_NO_RESOURCES;
            SX_LOG_ERR("the num of acls in system group[%u] are exceeds maximum range[%u], rc = %s\n", group_id,
                       rm_resource_global.acl_groups_size_max, sx_status_str(rc));
            goto error;
        }
        system_acl_clients_table[client_id].instance_info[instance].acl_group_id = group_params_p->group_id;
    }

    /* add the new system acl to group, if already exist acl - it bound and will be called group edit flow */
    group_params_p->acl_ids[group_params_p->acl_ids_num] = acl_id;
    group_params_p->acl_ids_num++;
    group_params_p->cmd = SX_ACCESS_CMD_SET;
    rc = flex_acl_group_set_internal(group_params_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to set group for system purposes, group_id[%u]\n", group_params_p->group_id);
        goto error;
    }

    if (__is_automatic_binding_point(system_acl_clients_table[client_id].binding_point_type)) {
        /* rebind user group after change in system group */
        rc = flex_acl_update_all_groups_with_system_acl(direction);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to update user's groups with system acl, direction[%u]\n", direction);
            goto remove_acl;
        }
    }
    goto out;

remove_acl:
    /* the added acl is last acl in group params */
    group_params_p->acl_ids_num--;
    group_params_p->cmd = SX_ACCESS_CMD_SET;
    if (SX_CHECK_FAIL(rb_rc = flex_acl_group_set_internal(group_params_p))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
error:
    if (*group_created) {
        if (SX_CHECK_FAIL(rb_rc = __system_acl_destroy_system_group(client_id, instance, direction, group_params_p))) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
        *group_created = FALSE;
    }
out:
    if (group_params_p != NULL) {
        cl_free(group_params_p);
    }
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __system_acl_remove_acl_from_group(system_acl_client_id_e client_id, uint32_t instance)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t         direction = SX_ACL_DIRECTION_LAST;
    uint32_t                   i = 0, j = 0;
    sx_api_acl_group_params_t *group_params_p = NULL;
    acl_stage_e                acl_stage = ACL_STAGE_UNKNOWN;

    SX_LOG_ENTER();

    rc = flex_acl_ops_g->acl_stage_get_p(&acl_stage);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to retrieve acl stage for removing from system acl group.\n");
        goto out;
    }

    if (((system_acl_clients_table[client_id].binding_point_type == SYSTEM_ACL_BINDING_POINT_TYPE_MC_E) &&
         (acl_stage == ACL_STAGE_FLEX)) ||
        (client_id == SYSTEM_ACL_CLIENT_ID_STATEFUL_DB_E)) {
        /* For stateful DB and for mc bind point (flex1) there is no need for a group. */
        goto out;
    }

    direction = system_acl_get_direction(system_acl_clients_table[client_id].binding_point_type);
    group_params_p = cl_malloc(sizeof(sx_api_acl_group_params_t) +
                               sizeof(sx_acl_id_t) * rm_resource_global.acl_groups_size_max);
    if (group_params_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory\n");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    SX_MEM_CLR(*group_params_p);
    group_params_p->acl_ids_num = rm_resource_global.acl_groups_size_max;

    group_params_p->group_id = system_acl_clients_table[client_id].instance_info[instance].acl_group_id;
    group_params_p->cmd = SX_ACCESS_CMD_GET;
    rc = flex_acl_group_get_internal(group_params_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get system group[%u], rc = %s\n", group_params_p->group_id, sx_status_str(rc));
        goto out;
    }

    /* Iterate on acls in params and remove client's acl from list */
    for (i = 0; i < group_params_p->acl_ids_num; i++) {
        if (group_params_p->acl_ids[i] == system_acl_clients_table[client_id].instance_info[instance].acl_id) {
            for (j = i; j + 1 < group_params_p->acl_ids_num; j++) { /* if it is not last acl id - remove it */
                group_params_p->acl_ids[j] = group_params_p->acl_ids[j + 1];
            }
        }
    }
    /* remove acl from group */
    group_params_p->acl_ids_num--;
    group_params_p->cmd = SX_ACCESS_CMD_SET;
    rc = flex_acl_group_set_internal(group_params_p);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to set group for system purposes, group_id[%u]\n", group_params_p->group_id);
        goto out;
    }

    /* if group are empty - destroy group */
    if (group_params_p->acl_ids_num == 0) {
        rc = __system_acl_destroy_system_group(client_id, instance, direction, group_params_p);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to destroy system acl group, group_id[%u]\n", group_params_p->group_id);
            goto out;
        }
    } else {
        /* remove group id from client db */
        system_acl_clients_table[client_id].instance_info[instance].acl_group_id = FLEX_ACL_INVALID_ACL_ID;
    }
    if (__is_automatic_binding_point(system_acl_clients_table[client_id].binding_point_type)) {
        /* rebind user groups after change in system group */
        rc = flex_acl_update_all_groups_with_system_acl(direction);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed rebind user's groups for direction[%u]\n", direction);
            goto out;
        }
    }

out:
    if (group_params_p != NULL) {
        cl_free(group_params_p);
    }
    SX_LOG_EXIT();
    return rc;
}
/* the function provides initialization for each bind point type, creates key handle with region, bind region with acl and
 * puts acl into group. Process bind operation per bind point.
 */
sx_status_t system_acl_client_init(system_acl_client_id_e client_id,
                                   uint32_t               instance,
                                   sx_acl_region_id_t    *region_id_p)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_status_t                    rb_rc = SX_STATUS_SUCCESS;
    sx_api_flex_acl_set_params_t   acl_params = {.cmd = 0};
    sx_api_acl_region_set_params_t region_params = {.cmd = 0};
    sx_api_acl_group_params_t     *group_params = 0;
    boolean_t                      sys_group_created = FALSE;

    SX_LOG_ENTER();

    group_params = cl_malloc(sizeof(sx_api_acl_group_params_t) + sizeof(sx_acl_id_t));
    if (group_params == NULL) {
        SX_LOG_ERR("Failed to allocate memory\n");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    if (client_id >= SYSTEM_ACL_CLIENT_ID_LAST_E) {
        SX_LOG_ERR("The client id [%u] is illegal\n", client_id);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (instance >= system_acl_clients_table[client_id].instances_allowed) {
        SX_LOG_ERR("The instance [%u] is illegal for client id [%u]. Max possible = [%u]\n", instance, client_id,
                   system_acl_clients_table[client_id].instances_allowed);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (system_acl_clients_table[client_id].instance_info[instance].is_initialized) {
        SX_LOG_ERR("The client instance [%u] is already initialized for client id [%u]\n", instance, client_id);
        rc = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    /* Create key handle only for the first instance */
    if (system_acl_clients_table[client_id].num_of_instances == 0) {
        system_acl_clients_table[client_id].key_handle = client_id + SX_ACL_KEY_TYPE_LAST;
        rc = flex_acl_create_basic_key(g_acl_stage, system_acl_clients_table[client_id].keys,
                                       system_acl_clients_table[client_id].num_of_keys,
                                       &system_acl_clients_table[client_id].key_handle);
        if (SX_STATUS_SUCCESS != rc) {
            system_acl_clients_table[client_id].key_handle = SYSTEM_ACL_INVALID_ID;
            SX_LOG_ERR("Failed to set basic  key\n");
            goto out;
        }
    }

    /*process region */
    region_params.cmd = SX_ACCESS_CMD_CREATE;
    region_params.region_size = system_acl_clients_table[client_id].region_min_size;
    region_params.key_type = system_acl_clients_table[client_id].key_handle;
    rc = flex_acl_region_set_internal(&region_params, client_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to set region for system purposes, system client_id[%u]\n", client_id);
        goto error;
    }
    system_acl_clients_table[client_id].instance_info[instance].region_id = region_params.region_id;

    rc = flex_acl_set_region_entry_type(region_params.region_id, FLEX_ACL_ENTRY_TYPE_SYSTEM_E);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to set entry type for  region id[%u]\n", region_params.region_id);
        goto error;
    }

    if (system_acl_clients_table[client_id].wc_rule_type != SYSTEM_ACL_WC_RULE_TYPE_NONE_E) {
        rc = flex_acl_region_wc_rule_set(region_params.region_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to set wildcard rule, system client_id[%u]\n", client_id);
            goto error;
        }
    }

    /* process acl */
    acl_params.acl_direction = system_acl_get_direction(system_acl_clients_table[client_id].binding_point_type);
    acl_params.cmd = SX_ACCESS_CMD_CREATE;
    acl_params.region_id = region_params.region_id;
    rc = flex_acl_set_internal(&acl_params);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to set acl table for system purposes, client_id[%u]\n", client_id);
        goto error;
    }
    system_acl_clients_table[client_id].instance_info[instance].acl_id = acl_params.acl_id;

    rc = flex_acl_set_acl_entry_type(acl_params.acl_id, FLEX_ACL_ENTRY_TYPE_SYSTEM_E);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to set entry type for ACL id[%u]\n", acl_params.acl_id);
        goto error;
    }

    rc = __system_acl_add_acl_to_group(client_id, instance, acl_params.acl_id, &sys_group_created);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to add system acl[%u] to system group\n", acl_params.acl_id);
        goto error;
    }

    /* process acl groups */
    if (sys_group_created) {
        rc = __system_acl_client_bind(client_id, instance);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to bind client id[%u]\n", client_id);
            goto error;
        }
    }
    *region_id_p = region_params.region_id;

    system_acl_clients_table[client_id].instance_info[instance].is_initialized = TRUE;
    system_acl_clients_table[client_id].num_of_instances++;

    goto out;
error:
    rb_rc = __system_acl_client_deinit(client_id, instance, TRUE);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    if (group_params != NULL) {
        cl_free(group_params);
    }
    SX_LOG_EXIT();
    return rc;
}

sx_status_t system_acl_client_deinit(system_acl_client_id_e client_id, uint32_t instance)
{
    return __system_acl_client_deinit(client_id, instance, FALSE);
}
/* de-initialize system client, unbind it from hw, remove system objects */
static sx_status_t __system_acl_client_deinit(system_acl_client_id_e client_id,
                                              uint32_t               instance,
                                              boolean_t              is_rollback)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_status_t                    last_error = SX_STATUS_SUCCESS;
    sx_api_flex_acl_set_params_t   acl_params = {.cmd = 0};
    sx_api_acl_region_set_params_t region_params = {.cmd = 0};

    SX_LOG_ENTER();

    if (client_id >= SYSTEM_ACL_CLIENT_ID_LAST_E) {
        SX_LOG_ERR("The client id [%u] is illegal\n", client_id);
        last_error = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (instance >= system_acl_clients_table[client_id].instances_allowed) {
        SX_LOG_ERR("The instance [%u] is illegal for client id [%u]. Max possible = [%u]\n", instance, client_id,
                   system_acl_clients_table[client_id].instances_allowed);
        last_error = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (!is_rollback) {
        if (!system_acl_clients_table[client_id].instance_info[instance].is_initialized) {
            SX_LOG_ERR("Failed to deinitialize  client id[%u], NOT INITIALIZED \n", client_id);
            last_error = SX_STATUS_SDK_NOT_INITIALIZED;
            goto out;
        }
    }
    rc = __system_acl_client_unbind(client_id, instance);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to unbind client id[%u]\n", client_id);
        last_error = rc;
    }

    rc = __system_acl_remove_acl_from_group(client_id, instance);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to remove system acl[%u]\n",
                   system_acl_clients_table[client_id].instance_info[instance].acl_id);
        last_error = rc;
    }

    if (system_acl_clients_table[client_id].instance_info[instance].acl_id != SYSTEM_ACL_INVALID_ID) {
        acl_params.acl_id = system_acl_clients_table[client_id].instance_info[instance].acl_id;
        acl_params.cmd = SX_ACCESS_CMD_DESTROY;
        rc = flex_acl_set_internal(&acl_params);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to destroy system acl id[%u]\n", acl_params.acl_id);
            last_error = rc;
        }
        system_acl_clients_table[client_id].instance_info[instance].acl_id = SYSTEM_ACL_INVALID_ID;
    }

    if (system_acl_clients_table[client_id].instance_info[instance].region_id != SYSTEM_ACL_INVALID_ID) {
        region_params.cmd = SX_ACCESS_CMD_DESTROY;
        region_params.region_id = system_acl_clients_table[client_id].instance_info[instance].region_id;
        rc = flex_acl_region_set_internal(&region_params, client_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to delete region for system purposes, region_id[%#x]\n", region_params.region_id);
            last_error = rc;
        }
        system_acl_clients_table[client_id].instance_info[instance].region_id = SYSTEM_ACL_INVALID_ID;
    }

    /* Release the key handle only for the last instance (can be zero for rollback) */
    if ((system_acl_clients_table[client_id].key_handle != SYSTEM_ACL_INVALID_ID) &&
        (system_acl_clients_table[client_id].num_of_instances <= 1)) {
        rc = flex_acl_remove_basic_key(system_acl_clients_table[client_id].key_handle);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to delete system acl key[%u]\n", system_acl_clients_table[client_id].key_handle);
            last_error = rc;
        }
        system_acl_clients_table[client_id].key_handle = SYSTEM_ACL_INVALID_ID;
    }

    system_acl_clients_table[client_id].instance_info[instance].is_initialized = FALSE;
    if (!is_rollback) {
        system_acl_clients_table[client_id].num_of_instances--;
    }
out:
    SX_LOG_EXIT();
    return last_error;
}

/* the function provides bind operation for each bind point type */
static sx_status_t __system_acl_client_bind(system_acl_client_id_e client_id, uint32_t instance)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    switch (system_acl_clients_table[client_id].binding_point_type) {
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_EGRESS_E:
        rc = __system_acl_rif_bind(client_id, instance);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to bind tunnel client[%d], rc = %s\n", client_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SYSTEM_ACL_BINDING_POINT_TYPE_VLAN_E:
        rc = __system_acl_client_vlan_bind(client_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to bind tunnel client[%d], rc = %s\n", client_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SYSTEM_ACL_BINDING_POINT_TYPE_RIF_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIF_EGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_EGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E:
        rc = __system_acl_create_bind_group(client_id, instance, NULL);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to create bind group for client[%u], rc = %s\n", client_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SYSTEM_ACL_BINDING_POINT_TYPE_MC_E:
        rc = __system_acl_mc_bind(client_id, instance);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to create bind group for MC client[%u], rc = %s\n", client_id, sx_status_str(rc));
            goto out;
        }

        break;

    case SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E:
        break;

    default:
        SX_LOG_ERR("Command is not supported.\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* the function provides unbind operation for each bind point type */
static sx_status_t __system_acl_client_unbind(system_acl_client_id_e client_id, uint32_t instance)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    switch (system_acl_clients_table[client_id].binding_point_type) {
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_EGRESS_E:
        rc = __system_acl_rif_unbind_client(client_id, instance);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to unbind tunnel client[%d]\n", client_id);
            goto out;
        }
        break;

    case SYSTEM_ACL_BINDING_POINT_TYPE_VLAN_E:
        rc = __system_acl_client_vlan_unbind(client_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to unbind client[%d], rc = %s\n", client_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SYSTEM_ACL_BINDING_POINT_TYPE_RIF_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIF_EGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_EGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E:
        rc = __system_acl_individual_client_unbind(client_id, instance);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to unbind group for client[%u], rc = %s\n", client_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SYSTEM_ACL_BINDING_POINT_TYPE_MC_E:
        rc = __system_acl_mc_unbind(client_id, instance);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to unbind group for MC client[%u], rc = %s\n", client_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E:
        break;

    default:
        SX_LOG_ERR("Command is not supported.\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __system_acl_get_rifs_list(uint16_t *rif_list, uint32_t *rif_count)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   router_initialized = FALSE;

    SX_LOG_ENTER();

    rc = sdk_router_cmn_router_impl_is_initialized(&router_initialized);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("error when trying to get if router initialized\n");
        goto out;
    }
    if (!router_initialized) {
        *rif_count = 0;
        SX_LOG_DBG("MSG: router module not initialized at RIF system client unbind\n");
        goto out;
    }

    rc = sdk_router_cmn_rif_impl_get_all_rif_ids(rif_list, rif_count);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Error at get rifs list\n");
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __system_acl_get_decap_rifs_list(uint16_t *rif_list, uint32_t *rif_count)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   router_initialized = FALSE;

    SX_LOG_ENTER();

    rc = sdk_router_cmn_router_impl_is_initialized(&router_initialized);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to check if the router module is initialized, error: %s\n",
                   sx_status_str(rc));
    }
    if (!router_initialized) {
        *rif_count = 0;
        SX_LOG_DBG("The router module is not initialized at RIF system client unbind\n");
        goto out;
    }

    rc = sdk_router_cmn_rif_impl_get_all_decap_rif_ids(rif_list, rif_count);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to get a list of decap RIFs, error: %s\n",
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static boolean_t __is_it_tunnel_decap_client(system_acl_client_id_e client_id)
{
    switch (client_id) {
    case SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_E:
    case SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_SPC2_E:
    case SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_E:
    case SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_SPC2_E:
        return TRUE;

    default:
        return FALSE;
    }
}

/* Binds RIF client to all free rifs in system
 *  1. gets list of all RIFs from RIF db
 *  2. For each RIF call binding function which will calculate the required HW group */
static sx_status_t __system_acl_rif_bind(system_acl_client_id_e client_id, uint32_t instance)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_status_t            rb_st = SX_STATUS_SUCCESS;
    sx_router_interface_t *rif_list_p;
    uint32_t               i = 0;
    uint32_t               rif_count = rm_resource_global.router_rifs_max;
    boolean_t              router_initialized = FALSE;

    SX_LOG_ENTER();

    rif_list_p = cl_malloc(rm_resource_global.router_rifs_max * sizeof(sx_router_interface_t));
    if (rif_list_p == NULL) {
        SX_LOG_ERR("failed memory allocation for rif id's list\n");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    rc = sdk_router_cmn_router_impl_is_initialized(&router_initialized);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("error when trying to get if router initialized\n");
        goto out;
    }
    if (!router_initialized) {
        SX_LOG_ERR("Error: router module not initialized at RIF system client bind, client id[%s]\n",
                   client_dictionary[client_id]);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    /* Get all RIFs from RIF db */
    if (__is_it_tunnel_decap_client(client_id)) {
        rc = __system_acl_get_decap_rifs_list(rif_list_p, &rif_count);
    } else {
        rc = __system_acl_get_rifs_list(rif_list_p, &rif_count);
    }
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("error when trying to get rifs list\n");
        goto out;
    }

    /* Per each RIF, add the system ACL to its bound groups.
     * RIFs that are not bound to user groups will be bound to the
     * global system ACL.
     * RIFs that are bound to user groups will get an aggregated group.
     */
    for (i = 0; i < rif_count; i++) {
        rc = flex_acl_rif_bind_internal(rif_list_p[i],
                                        system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                        TRUE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to bind RIF [%u] to client[%u], group_id[%u], rc = %s\n",
                       rif_list_p[i], client_id,
                       system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                       sx_status_str(rc));
            goto rollback;
        }
    }

    goto out;

rollback:
    rb_st = __system_acl_rif_unbind_client(client_id, instance);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
    }
out:
    if (rif_list_p != NULL) {
        cl_free(rif_list_p);
    }
    SX_LOG_EXIT();
    return rc;
}
/** Binds System ACL client to vlan groups, which are not bound to user ACL groups
 *  Run through all allocated vlan groups and bind them to System ACL group for VLAN binding
 *
 */
static sx_status_t __system_acl_client_vlan_bind(system_acl_client_id_e client_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    /* sx_acl_vlan_group_t vlan_group_id = 0xFF; */

    SX_LOG_ENTER();

    /* the default vlan group will be bound at creation to existing in system client group id */
    rc = system_acl_create_default_vlan_group(client_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to enable default vlan group, client_id: %u, error(%s)\n", client_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* For Flex2 we need to create regular bind attributes for the MC group.
 * We also set the group as the the MC handling group for IPv4/IPv6.
 */
static sx_status_t __system_acl_mc_bind(system_acl_client_id_e client_id, uint32_t instance)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rb_rc = SX_STATUS_SUCCESS;
    acl_stage_e                acl_stage = ACL_STAGE_UNKNOWN;
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_ip_version_t            ip_version = SX_IP_VERSION_NONE;

    SX_LOG_ENTER();

    switch (client_id) {
    case SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E:
        ip_version = SX_IP_VERSION_IPV4;
        break;

    case SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E:
        ip_version = SX_IP_VERSION_IPV6;
        break;

    default:
        SX_LOG_ERR("Unsupported client [%u] for mc bind.\n", client_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_ops_g->acl_stage_get_p(&acl_stage);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to retrieve acl stage for system acl mc bind.\n");
        goto out;
    }
    /* For Flex1 there is no real need for binding as it's done automatically in hw. */
    if (acl_stage == ACL_STAGE_FLEX) {
        goto out;
    }

    /* Create a default bind attributes and write it to hw.*/
    rc = __system_acl_create_bind_group(client_id, instance, &bind_attribs_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to create bind group for client[%u], rc = %s\n", client_id, sx_status_str(rc));
        goto out;
    }
    /* Write the mc bind attribute to the hw.*/
    rc = flex_acl_hw_reg_write_mc_bind(SX_ACCESS_CMD_BIND, ip_version, bind_attribs_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to write mc bind to hw for client[%u], rc = %s\n", client_id, sx_status_str(rc));
        /* Rollback if the hw operation was not successful */
        rb_rc = __system_acl_delete_bind_group(client_id, instance);
        if (SX_STATUS_SUCCESS != rb_rc) {
            SX_LOG_ERR("SYSTEM ACL: Failed to delete MC bind group for client id [%u].\n", client_id);
        }
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* go through default VLAN group DB - check VID per client */
sx_status_t __default_vlan_group_check_belong_to_client(void* list_object, void* context)
{
    flex_acl_db_system_vid_pool_map_entry_t *entry = (flex_acl_db_system_vid_pool_map_entry_t*)list_object;
    system_acl_client_id_e                   client_id = (system_acl_client_id_e)context;

    if (client_id == entry->client_id) {
        return SX_STATUS_RESOURCE_IN_USE;
    }
    return SX_STATUS_SUCCESS;
}


/* binds vlan client to SYSTEM'S vlans
 *  1. run of all allocated vlan groups and bind them to system acl group
 *  */
static sx_status_t __system_acl_client_vlan_unbind(system_acl_client_id_e client_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* go through default VLAN group DB - check VID per client */
    rc = flex_acl_db_for_each_vlan_entry(__default_vlan_group_check_belong_to_client, (void*)client_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: there are VIDs defined for client %d\n", client_id);
        goto out;
    }

    /* if client is last - the vlan group will be unbound from client's group id */
    rc = system_acl_delete_default_vlan_group(client_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to disable default vlan group, client_id: %u, error(%s)\n", client_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


/* This function unbinds client group from RIFs */
/* 1. Gets RIFs list
 * 2. Go over RIFs and call aggregate logic
 */
static sx_status_t __system_acl_rif_unbind_client(system_acl_client_id_e client_id, uint32_t instance)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t         direction = SX_ACL_DIRECTION_LAST;
    flex_acl_bind_attribs_id_t attribs_id_from_rif = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_bind_attribs_id_t system_bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_router_interface_t     *rif_list_p = NULL;
    uint32_t                   i = 0;
    uint32_t                   rif_count = 0;
    sx_api_acl_group_params_t *group_params = NULL;

    SX_LOG_ENTER();

    group_params = cl_malloc(
        sizeof(sx_api_acl_group_params_t) + sizeof(sx_acl_id_t) * rm_resource_global.acl_groups_size_max);
    if (group_params == NULL) {
        SX_LOG_ERR("Failed to allocate memory\n");
        goto out;
    }
    memset(group_params, 0,
           (sizeof(sx_api_acl_group_params_t) + sizeof(sx_acl_id_t) * rm_resource_global.acl_groups_size_max));

    rif_list_p = cl_malloc(rm_resource_global.router_rifs_max * sizeof(sx_router_interface_t));
    if (rif_list_p == NULL) {
        SX_LOG_ERR("failed memory allocation for rif id's list\n");
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    rif_count = rm_resource_global.router_rifs_max;

    direction = system_acl_get_direction(system_acl_clients_table[client_id].binding_point_type);

    group_params->acl_ids_num = 0;
    group_params->group_id = system_acl_clients_table[client_id].instance_info[instance].acl_group_id;
    group_params->cmd = SX_ACCESS_CMD_GET;
    rc = flex_acl_group_get_internal(group_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get system group[%u], rc = %s\n", group_params->group_id, sx_status_str(rc));
        goto out;
    }

    if (group_params->acl_ids_num == 1) {
        /* Get all RIFs from RIF db */
        if (__is_it_tunnel_decap_client(client_id)) {
            rc = __system_acl_get_decap_rifs_list(rif_list_p, &rif_count);
        } else {
            rc = __system_acl_get_rifs_list(rif_list_p, &rif_count);
        }
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error when trying to get RIFs list\n");
            goto out;
        }

        /* Get bind attributes from system */
        rc = flex_acl_get_bind_attribs(system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                       &system_bind_attribs_id, &direction, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error when trying to get bind attributes id for system group id\n");
            goto out;
        }

        /* Iterate on RIFs list and apply ACL aggregation logic */
        for (i = 0; i < rif_count; i++) {
            rc = flex_acl_db_get_rif_bind(rif_list_p[i], direction, &attribs_id_from_rif);
            if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                SX_LOG_ERR("Failed to get bind attributes for RIF %u, error[%s]\n", rif_list_p[i],
                           sx_status_str(rc));
                goto out;
            }
            if (attribs_id_from_rif == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
                attribs_id_from_rif = system_bind_attribs_id;
            }

            rc = flex_acl_rif_unbind_internal(system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                              rif_list_p[i], attribs_id_from_rif);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to unbind RIF [%u] from system ACL client[%u]\n", rif_list_p[i], client_id);
            }
        }
    }

    goto out;

out:
    if (group_params != NULL) {
        cl_free(group_params);
    }
    if (rif_list_p != NULL) {
        cl_free(rif_list_p);
    }
    SX_LOG_EXIT();
    return rc;
}

/* For Flex2 need to unset the pointer to the relevant Ipv4/IPv6 MC group.
 * Bind attributes must also be released.
 */
static sx_status_t __system_acl_mc_unbind(system_acl_client_id_e client_id, uint32_t instance)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    acl_stage_e     acl_stage = ACL_STAGE_UNKNOWN;
    sx_ip_version_t ip_version = SX_IP_VERSION_NONE;

    SX_LOG_ENTER();

    switch (client_id) {
    case SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E:
        ip_version = SX_IP_VERSION_IPV4;
        break;

    case SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E:
        ip_version = SX_IP_VERSION_IPV6;
        break;

    default:
        SX_LOG_ERR("Unsupported client [%u] for mc bind.\n", client_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_ops_g->acl_stage_get_p(&acl_stage);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to retrieve acl stage for system acl mc bind.\n");
        goto out;
    }

    /* For Flex1 there is no real need for binding as it's done automatically in hw. */
    if (acl_stage == ACL_STAGE_FLEX) {
        goto out;
    }

    /* Remove the binding of the group from hw. */
    rc = flex_acl_hw_reg_write_mc_bind(SX_ACCESS_CMD_UNBIND, ip_version, FLEX_ACL_INVALID_BIND_ATTRIBS_ID);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to delete mc bind from hw client id [%u], rc = %s\n", client_id, sx_status_str(rc));
        goto out;
    }

    /* Delete the default created bind attributes */
    rc = __system_acl_delete_bind_group(client_id, instance);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("SYSTEM ACL: Failed to delete default bind group for client id [%u] instance [%u].\n",
                   client_id,
                   instance);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


/* the function sets register call backs depends on bind point type */
sx_status_t system_acl_set_register_callbacks(system_acl_client_id_e client_id, sx_acl_region_id_t region_id)
{
    flex_acl_hw_reg_cb_t flex_acl_reg_cb = {NULL};
    system_acl_hw_cb_t   system_acl_hw_cb = {NULL};
    boolean_t            change_needed = FALSE;
    sx_status_t          rc = SX_STATUS_SUCCESS;

    switch (system_acl_clients_table[client_id].binding_point_type) {
    case SYSTEM_ACL_BINDING_POINT_TYPE_MC_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E:
        rc = flex_acl_ops_g->system_acl_set_mc_register_callbacks_p(client_id, &system_acl_hw_cb, &change_needed);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Failed to get mc client register callbacks, client_id: %u, \n", client_id);
            goto out;
        }
        if (change_needed) {
            flex_acl_reg_cb.acl_register_cb = system_acl_hw_cb.acl_hw_cb;
            flex_acl_reg_cb.move_rule_hw_cb = system_acl_hw_cb.move_rule_hw_cb;
            flex_acl_reg_cb.region_hw_cb = system_acl_hw_cb.region_hw_cb;
            flex_acl_reg_cb.rule_hw_cb = system_acl_hw_cb.rule_hw_cb;
            flex_acl_reg_cb.activity_register_cb = system_acl_hw_cb.activity_read_hw_cb;
            flex_acl_reg_cb.activity_dump_hw_cb = system_acl_hw_cb.activity_dump_hw_cb;
        }
        break;

    case SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_EGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_VLAN_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIF_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_RIF_EGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_EGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E:
    case SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E:
        break;

    default:
        SX_LOG_ERR("Command is not supported.\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    rc = flex_acl_hw_set_register_cb(region_id, &flex_acl_reg_cb);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to set region hw callbacks for region id[%u]\n", region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_acl_direction_t system_acl_get_direction(system_acl_binding_point_type_e binding_point_type)
{
    switch (binding_point_type) {
    case SYSTEM_ACL_BINDING_POINT_TYPE_MC_E:
        return SX_ACL_DIRECTION_INGRESS;      /* For mc bind point direction are not matter, so sets to first legal */

    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORTS_ALL_INGRESS_E:
        return SX_ACL_DIRECTION_INGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_INGRESS_E:
        return SX_ACL_DIRECTION_RIF_INGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORTS_ALL_EGRESS_E:
        return SX_ACL_DIRECTION_EGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_RIFS_ALL_EGRESS_E:
        return SX_ACL_DIRECTION_RIF_EGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_VLAN_E:
        return SX_ACL_DIRECTION_INGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_NONE_E:
        return SX_ACL_DIRECTION_INGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_RIF_INGRESS_E:
        return SX_ACL_DIRECTION_RIF_INGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_RIF_EGRESS_E:
        return SX_ACL_DIRECTION_RIF_EGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_INGRESS_E:
        return SX_ACL_DIRECTION_INGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_EGRESS_E:
        return SX_ACL_DIRECTION_EGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E:
        return SX_ACL_DIRECTION_INGRESS;

    case SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E:
        return SX_ACL_DIRECTION_EGRESS;

    default:
        SX_LOG_ERR("Invalid system ACL binding_point_type [%u]\n", binding_point_type);
        return SX_ACL_DIRECTION_LAST;
    }
}

/* This is a utility function to retrieve the correct tunnel client according to stage and ip version */
system_acl_client_id_e system_acl_tunnel_client_id_get(sx_ip_version_t ip_version)
{
    system_acl_client_id_e client_id = SYSTEM_ACL_CLIENT_ID_INVALID_E;

    if (ACL_STAGE_IS_FLEX2_OR_ABOVE(g_acl_stage)) {
        client_id =
            (ip_version ==
             SX_IP_VERSION_IPV6) ? SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_SPC2_E : SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_SPC2_E;
    } else {
        client_id =
            (ip_version ==
             SX_IP_VERSION_IPV6) ? SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV6_E : SYSTEM_ACL_CLIENT_ID_TUNNEL_IPV4_E;
    }
    return client_id;
}

#define CLIENT_ID_2STR(client_id)                 \
    ((client_id) < SYSTEM_ACL_CLIENT_ID_LAST_E && \
     client_dictionary[(client_id)]) ? client_dictionary[(client_id)] : "invalid"

#define BINDING_POINT_2STR(bp_type)                 \
    ((bp_type) < SYSTEM_ACL_BINDING_POINT_LAST_E && \
     binding_point_type_dictionary[(bp_type)]) ? binding_point_type_dictionary[(bp_type)] : "invalid"

#define WC_RULE_2STR(wc_rule_type)                      \
    ((wc_rule_type) < SYSTEM_ACL_WC_RULE_TYPE_LAST_E && \
     wc_rule_type_dictionary[(wc_rule_type)]) ? wc_rule_type_dictionary[(wc_rule_type)] : "invalid"


void system_acl_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    system_acl_client_id_e           client_id;
    uint32_t                         instance_id = 0;
    static dbg_utils_table_columns_t acl_dump_columns[] = {
        { "Client ID",                           22,    PARAM_STRING_E,     NULL }, /* 0 */
        { "Bind Point Type",                     30,    PARAM_STRING_E,     NULL }, /* 1 */
        { "Priority",                            15,    PARAM_UINT32_E,     NULL }, /* 2 */
        { "Min size",                            8,     PARAM_UINT32_E,     NULL }, /* 3 */
        { "Key Handle",                          10,    PARAM_HEX_E,        NULL }, /* 4 */
        { "Instance allowed",                    17,    PARAM_UINT32_E,     NULL }, /* 5 */
        { "Num of instances",                    17,    PARAM_UINT32_E,     NULL }, /* 6 */
        { "wc rule type",                        13,    PARAM_STRING_E,     NULL }, /* 7 */
        { "Is rules rm needed",                  18,    PARAM_BOOL_E,       NULL }, /* 8 */
        {NULL, 0, 0, NULL}
    };
    static dbg_utils_table_columns_t instance_info_dump_clmns[] = {
        { "Client ID",     22, PARAM_STRING_E, NULL}, /* 0 */
        { "Instance",      9, PARAM_UINT32_E, NULL}, /* 1 */
        { "Region ID",     10, PARAM_HEX_E, NULL},    /* 2 */
        { "ACL ID",        10, PARAM_HEX_E, NULL},    /* 3 */
        { "ACL Group ID",  13, PARAM_HEX_E, NULL},    /* 4 */
        {NULL, 0, 0, NULL}
    };
    FILE                            *stream = NULL;

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        return;
    }
    stream = dbg_dump_params_p->stream;
    if (!g_flex_acl_initialized) {
        dbg_utils_pprinter_field_print(stream,
                                       "FLEX ACL Modules are not initialized",
                                       &g_flex_acl_initialized,
                                       PARAM_BOOL_E);
        return;
    }

    dbg_utils_pprinter_general_header_print(stream, "SYSTEM ACL DB");
    dbg_utils_pprinter_table_headline_print(stream, acl_dump_columns);

    for (client_id = SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E; client_id < SYSTEM_ACL_CLIENT_ID_LAST_E; client_id++) {
        acl_dump_columns[0].data = CLIENT_ID_2STR(system_acl_clients_table[client_id].client_id);
        acl_dump_columns[1].data = BINDING_POINT_2STR(system_acl_clients_table[client_id].binding_point_type);
        acl_dump_columns[2].data = &(system_acl_clients_table[client_id].system_acl_priority);
        acl_dump_columns[3].data = &(system_acl_clients_table[client_id].region_min_size);
        acl_dump_columns[4].data = &(system_acl_clients_table[client_id].key_handle);
        acl_dump_columns[5].data = &(system_acl_clients_table[client_id].instances_allowed);
        acl_dump_columns[6].data = &(system_acl_clients_table[client_id].num_of_instances);
        acl_dump_columns[7].data = WC_RULE_2STR(system_acl_clients_table[client_id].wc_rule_type);
        acl_dump_columns[8].data = &(system_acl_clients_table[client_id].is_rules_rm_needed);

        dbg_utils_pprinter_table_data_line_print(stream, acl_dump_columns);
    }

    dbg_utils_pprinter_table_headline_print(stream, instance_info_dump_clmns);

    for (client_id = SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E; client_id < SYSTEM_ACL_CLIENT_ID_LAST_E; client_id++) {
        for (instance_id = 0; instance_id < system_acl_clients_table[client_id].instances_allowed; instance_id++) {
            if (system_acl_clients_table[client_id].instance_info[instance_id].is_initialized) {
                instance_info_dump_clmns[0].data = CLIENT_ID_2STR(system_acl_clients_table[client_id].client_id);
                instance_info_dump_clmns[1].data = &(instance_id);
                instance_info_dump_clmns[2].data =
                    &(system_acl_clients_table[client_id].instance_info[instance_id].region_id);
                instance_info_dump_clmns[3].data =
                    &(system_acl_clients_table[client_id].instance_info[instance_id].acl_id);
                instance_info_dump_clmns[4].data =
                    &(system_acl_clients_table[client_id].instance_info[instance_id].acl_group_id);

                dbg_utils_pprinter_table_data_line_print(stream, instance_info_dump_clmns);
            }
        }
    }
    SX_LOG_EXIT();
}

sx_status_t system_acl_region_get_hw_size(sx_acl_region_id_t region_id, uint32_t *hw_size)
{
    sx_status_t                            rc = SX_STATUS_SUCCESS;
    sx_api_acl_region_hw_size_get_params_t size_get_params;

    SX_LOG_ENTER();
    SX_MEM_CLR(size_get_params);

    size_get_params.region_id = region_id;
    rc = flex_acl_region_get_hw_size(&size_get_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error on get region hw size, region_id[%#x]\n", region_id);
        goto out;
    }

    *hw_size = size_get_params.hw_size;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t system_acl_vlan_add(system_acl_client_id_e client_id,
                                sx_swid_id_t           swid,
                                sx_vlan_id_t          *vlan_list,
                                uint32_t               vlan_num)
{
    sx_acl_vlan_group_t vlan_group_id = 0xFF;
    sx_status_t         rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_default_vlan_group_id(&vlan_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : failed to get default vlan group id\n");
        goto out;
    }

    rc = system_acl_add_vlan_to_default_vlan_group(client_id, vlan_group_id, swid, vlan_list, vlan_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : failed to add vlans to vlan group[%u]\n", vlan_group_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t system_acl_vlan_remove(system_acl_client_id_e client_id,
                                   sx_swid_id_t           swid,
                                   sx_vlan_id_t          *vlan_list,
                                   uint32_t               vlan_num)
{
    sx_acl_vlan_group_t vlan_group_id = 0xFF;
    sx_status_t         rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_default_vlan_group_id(&vlan_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : failed to get default vlan group id\n");
        goto out;
    }

    rc = system_acl_remove_vlan_from_default_vlan_group(client_id, vlan_group_id, swid, vlan_list, vlan_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : failed to add vlans to vlan group[%u]\n", vlan_group_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __system_acl_create_bind_group(system_acl_client_id_e      client_id,
                                                  uint32_t                    instance,
                                                  flex_acl_bind_attribs_id_t *new_bind_attribs_id)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_acl_id_t                group_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    SX_LOG_EXIT();

    /* Use the client's default group */
    group_id = system_acl_clients_table[client_id].instance_info[instance].acl_group_id;

    rc = flex_acl_get_bind_attribs(group_id, &bind_attribs_id, NULL, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: failed to get bind attributes id for group_id [%u].\n", group_id);
        goto out;
    }

    /* Add to the mapping of groups to client id and instance */
    rc = flex_acl_db_system_acl_group_client_add(group_id, client_id, instance);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("SYSTEM ACL: Failed to to add group [%u] to mapping for client id [%u] instance [%u].\n",
                   group_id,
                   client_id,
                   instance);
        goto out;
    }

    if (new_bind_attribs_id != NULL) {
        *new_bind_attribs_id = bind_attribs_id;
    }

out:

    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __system_acl_delete_bind_group(system_acl_client_id_e client_id, uint32_t instance)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_acl_id_t              group_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_db_acl_group_t *acl_group = NULL;

    SX_LOG_EXIT();

    group_id = system_acl_clients_table[client_id].instance_info[instance].acl_group_id;
    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("SYSTEM ACL: Failed to get group id [%u].\n", group_id);
        goto out;
    }

    rc = flex_acl_db_system_acl_group_client_delete(group_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("SYSTEM ACL: Failed to to remove group [%u] from mapping to client id [%u] instance [%u].\n",
                   group_id,
                   client_id,
                   instance);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t system_acl_rif_bind(system_acl_client_id_e client_id, uint32_t instance, sx_rif_id_t rif)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_status_t              rb_rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t       direction = SX_ACL_DIRECTION_LAST;
    sx_acl_id_t              group_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_bind_point_id   bind_point_id;
    boolean_t                router_initialized = FALSE;
    flex_acl_db_acl_group_t *acl_group = NULL;

    SX_LOG_ENTER();

    SX_MEM_CLR(bind_point_id);

    if (client_id >= SYSTEM_ACL_CLIENT_ID_LAST_E) {
        SX_LOG_ERR("The client id [%u] is illegal\n", client_id);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (instance >= system_acl_clients_table[client_id].instances_allowed) {
        SX_LOG_ERR("The instance [%u] is illegal for client id [%u]\n", instance, client_id);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (!system_acl_clients_table[client_id].instance_info[instance].is_initialized) {
        SX_LOG_ERR("The client instance [%u] is not initialized for client id [%u]\n", instance, client_id);
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if ((system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_RIF_INGRESS_E) &&
        (system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_RIF_EGRESS_E)) {
        SX_LOG_ERR("Client id [%u] cannot be bound to an individual rif.\n", client_id);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    bind_point_id.rif_id = rif;
    direction = system_acl_get_direction(system_acl_clients_table[client_id].binding_point_type);

    /* Check that the router is initialized */
    rc = sdk_router_cmn_router_impl_is_initialized(&router_initialized);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("error when trying to get if router initialized\n");
        goto out;
    }

    if (!router_initialized) {
        SX_LOG_ERR("Error: router module not initialized at RIF system client bind, client id[%s]\n",
                   client_dictionary[client_id]);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    /* Check that the rif is indeed valid */
    rc = sdk_router_cmn_rif_impl_get(rif, NULL, NULL, NULL);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Trying to bind to uninitialized RIF [%u]\n", rif);
        goto out;
    }

    /* Check if the rif is already bound to a user/all rif system ACL group.*/
    rc = flex_acl_db_system_acl_binding_point_get(direction, bind_point_id, &group_id);
    if (rc == SX_STATUS_SUCCESS) {
        SX_LOG_ERR("RIF is already bound to group id [%u]. Multiple binding is not supported.\n", group_id);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    group_id = system_acl_clients_table[client_id].instance_info[instance].acl_group_id;
    rc = flex_acl_db_system_acl_binding_point_add(direction, bind_point_id, group_id, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: Failed to add bind port for RIF [0x%x].\n", bind_point_id.rif_id);
        goto out;
    }

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Get acl group error, group_id: %u\n", group_id);
        goto rollback_binding_point_add;
    }

    rc = flex_acl_db_group_bind_rif(acl_group, rif);
    if (rc != SX_STATUS_SUCCESS) {
        goto rollback_binding_point_add;
    }

    rc = flex_acl_rif_bind_internal(rif, group_id, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in system acl binding RIF [0x%x]\n", bind_point_id.rif_id);
        goto rollback_rif_bind;
    }

    SX_LOG_INF("SYSTEM ACL: Bind client id [%u], instance [%u], to rif [%u]\n", client_id, instance, rif);
    goto out;

rollback_rif_bind:

    rb_rc = flex_acl_db_group_unbind_rif(acl_group, rif);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed system acl rollback DB unbind RIF [0x%x]\n", rif);
    }

rollback_binding_point_add:
    rb_rc = flex_acl_db_system_acl_binding_point_delete(direction, bind_point_id);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed system acl rollback binding point delete for RIF [0x%x]\n", bind_point_id.rif_id);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t system_acl_rif_unbind(system_acl_client_id_e client_id, uint32_t instance, sx_rif_id_t rif)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rb_rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t         direction = SX_ACL_DIRECTION_LAST;
    flex_acl_bind_point_id     bind_point_id = {.rif_id = rif};
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_bind_attribs_id_t system_bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_acl_id_t                group_id = FLEX_ACL_INVALID_ACL_ID;
    system_acl_client_id_e     db_client_id = SYSTEM_ACL_CLIENT_ID_INVALID_E;
    uint32_t                   db_instance = 0;
    flex_acl_db_acl_group_t   *acl_group = NULL;

    SX_LOG_ENTER();

    if (client_id >= SYSTEM_ACL_CLIENT_ID_LAST_E) {
        SX_LOG_ERR("SYSTEM ACL: The client id [%u] is illegal\n", client_id);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (instance >= system_acl_clients_table[client_id].instances_allowed) {
        SX_LOG_ERR("SYSTEM ACL: The instance [%u] is illegal for client id [%u]\n", client_id, instance);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (!system_acl_clients_table[client_id].instance_info[instance].is_initialized) {
        SX_LOG_ERR("SYSTEM ACL: The client instance [%u] is not initialized for client id [%u]\n", instance,
                   client_id);
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if ((system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_RIF_INGRESS_E) &&
        (system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_RIF_EGRESS_E)) {
        SX_LOG_ERR("SYSTEM ACL: Client id [%u] cannot be unbound from an individual RIF.\n", client_id);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    direction = system_acl_get_direction(system_acl_clients_table[client_id].binding_point_type);

    /* Check if the port/rif is bound by this client and get the group id*/
    rc = flex_acl_db_system_acl_binding_point_get(direction, bind_point_id, &group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: RIF [%u] is not bound and therefore cannot be unbound.\n", rif);
        goto out;
    }

    /* Check that we are unbinding from the correct client */
    rc = flex_acl_db_system_acl_group_client_get(group_id, &db_client_id, &db_instance);
    if ((rc != SX_STATUS_SUCCESS) || (db_client_id != client_id) || (db_instance != instance)) {
        SX_LOG_ERR("SYSTEM ACL: RIF [%u] is not bound to client [%u] instance [%u] and cannot be unbound.\n",
                   rif, client_id, instance);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_db_get_rif_bind(rif, direction, &bind_attribs_id);
    if (rc != SX_STATUS_SUCCESS) {
        if (rc != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("Error finding RIF [%u] direction[%u] in db, err[%s]\n",
                       rif, direction, sx_status_str(rc));
        }
    }

    rc = flex_acl_get_bind_attribs(system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                   &system_bind_attribs_id, NULL, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when trying to get bind attributes id for system group\n");
        goto out;
    }

    if (bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        bind_attribs_id = system_bind_attribs_id;
    }

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Get acl group error, group_id: %u\n", group_id);
        goto out;
    }

    rc = flex_acl_db_group_unbind_rif(acl_group, rif);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    rc = flex_acl_db_system_acl_binding_point_delete(direction, bind_point_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: Failed to remove attribute bind db for RIF [0x%x].\n", bind_point_id.rif_id);
        goto rollback_db_unbind_rif;
    }

    rc = flex_acl_rif_unbind_internal(system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                      rif, bind_attribs_id);
    /* System ACL unbind can be called for an unbound entry.
     * This happens when a RIF is deleted - first ACLs are cleared from RIF and then
     * system ACL remove callback is activated. In order to skip errors
     * Allow an ENTRY_NOT_BOUND return code to be skipped.
     */
    if (rc == SX_STATUS_ENTRY_NOT_BOUND) {
        rc = SX_STATUS_SUCCESS;
    }
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in system acl individual unbinding RIF [0x%x]\n", rif);
        goto rollback_bind_point_del;
    }
    SX_LOG_INF("SYSTEM ACL: Unbind client id [%u], instance [%u], from rif [%u].\n", client_id, instance, rif);
    goto out;

rollback_bind_point_del:
    rb_rc = flex_acl_db_system_acl_binding_point_add(direction,
                                                     bind_point_id,
                                                     system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                                     FALSE);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: Failed to remove attribute bind db for RIF [0x%x].\n", bind_point_id.rif_id);
    }
rollback_db_unbind_rif:
    rb_rc = flex_acl_db_group_bind_rif(acl_group, rif);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in rollback DB unbinding RIF [0x%x]\n", rif);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __system_acl_port_bind_internal(system_acl_client_id_e client_id,
                                                   uint32_t               instance,
                                                   sx_port_id_t           port)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_status_t              rb_rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t       direction = SX_ACL_DIRECTION_LAST;
    sx_acl_id_t              group_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_bind_point_id   bind_point_id;
    flex_acl_db_acl_group_t *acl_group = NULL;

    SX_LOG_ENTER();

    SX_MEM_CLR(bind_point_id);

    if (client_id >= SYSTEM_ACL_CLIENT_ID_LAST_E) {
        SX_LOG_ERR("The client id [%u] is illegal\n", client_id);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (instance >= system_acl_clients_table[client_id].instances_allowed) {
        SX_LOG_ERR("The instance [%u] is illegal for client id [%u]\n", instance, client_id);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (!system_acl_clients_table[client_id].instance_info[instance].is_initialized) {
        SX_LOG_ERR("The client instance [%u] is not initialized for client id [%u]\n", instance, client_id);
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if ((system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_INGRESS_E) &&
        (system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_EGRESS_E) &&
        (system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E) &&
        (system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E)) {
        SX_LOG_ERR("Client id [%u] cannot be bound to an individual port.\n", client_id);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if ((SX_PORT_TYPE_ID_GET(port) != SX_PORT_TYPE_TUNNEL) &&
        ((system_acl_clients_table[client_id].binding_point_type == SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E) ||
         (system_acl_clients_table[client_id].binding_point_type == SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E))) {
        SX_LOG_ERR("NVE bind type can not be used with non-NVE port 0x[%x]\n", port);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    bind_point_id.port_id = port;
    direction = system_acl_get_direction(system_acl_clients_table[client_id].binding_point_type);

    /* Check if the port is already bound by another client/instance */
    rc = flex_acl_db_system_acl_binding_point_get(direction, bind_point_id, &group_id);
    if (rc == SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Port is already bound to group id [%u]. Multiple binding is not supported.\n", group_id);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    group_id = system_acl_clients_table[client_id].instance_info[instance].acl_group_id;
    rc = flex_acl_db_system_acl_binding_point_add(direction, bind_point_id, group_id, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: Failed to add attribute bind db for lag port [0x%x].\n", bind_point_id.port_id);
        goto out;
    }

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Get acl group error, group_id: %u\n", group_id);
        goto rollback_binding_point_add;
    }

    rc = flex_acl_db_group_bind_log_port(acl_group, port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Error DB bind system acl group id: %u\n", group_id);
        goto rollback_binding_point_add;
    }

    rc = flex_acl_port_bind_internal(port, group_id, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in system acl binding port [0x%x].\n", bind_point_id.port_id);
        goto rollback_group_bind;
    }

    goto out;

rollback_group_bind:
    rb_rc = flex_acl_db_group_unbind_log_port(acl_group, port);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Error rollback DB unbind system acl group id: %u\n", group_id);
    }

rollback_binding_point_add:
    rb_rc = flex_acl_db_system_acl_binding_point_delete(direction, bind_point_id);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed system acl rollback binding port delete for LAG [0x%x].\n", bind_point_id.port_id);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t system_acl_port_bind(system_acl_client_id_e client_id, uint32_t instance, sx_port_id_t port)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    /* Check that the port is valid for binding */
    rc = flex_acl_validate_port(port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: port [0x%x] is invalid for individual binding.\n", port);
        return rc;
    }
    return __system_acl_port_bind_internal(client_id, instance, port);
}

sx_status_t system_acl_port_unbind(system_acl_client_id_e client_id, uint32_t instance, sx_port_id_t port)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rb_rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t         direction = SX_ACL_DIRECTION_LAST;
    flex_acl_bind_point_id     bind_point_id = {.port_id = port};
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_bind_attribs_id_t system_bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_port_type_t             port_type = SX_PORT_TYPE_NETWORK;
    sx_acl_id_t                group_id = FLEX_ACL_INVALID_ACL_ID;
    system_acl_client_id_e     db_client_id = SYSTEM_ACL_CLIENT_ID_INVALID_E;
    uint32_t                   db_instance = 0;
    flex_acl_db_acl_group_t   *acl_group = NULL;

    SX_LOG_ENTER();

    if (client_id >= SYSTEM_ACL_CLIENT_ID_LAST_E) {
        SX_LOG_ERR("SYSTEM ACL: The client id [%u] is illegal\n", client_id);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (instance >= system_acl_clients_table[client_id].instances_allowed) {
        SX_LOG_ERR("SYSTEM ACL: The instance [%u] is illegal for client id [%u]\n", client_id, instance);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (!system_acl_clients_table[client_id].instance_info[instance].is_initialized) {
        SX_LOG_ERR("SYSTEM ACL:: The client instance [%u] is not initialized for client id [%u]\n", instance,
                   client_id);
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if ((system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_INGRESS_E) &&
        (system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_L2_PORT_EGRESS_E) &&
        (system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E) &&
        (system_acl_clients_table[client_id].binding_point_type != SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E)) {
        SX_LOG_ERR("SYSTEM ACL: Client id [%u] cannot be unbound from an individual port.\n", client_id);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if ((SX_PORT_TYPE_ID_GET(port) != SX_PORT_TYPE_TUNNEL) &&
        ((system_acl_clients_table[client_id].binding_point_type == SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_INGRESS_E) ||
         (system_acl_clients_table[client_id].binding_point_type == SYSTEM_ACL_BINDING_POINT_TYPE_TPORT_EGRESS_E))) {
        SX_LOG_ERR("NVE bind type can not be used when unbinding non-NVE port 0x[%x]\n", port);
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    direction = system_acl_get_direction(system_acl_clients_table[client_id].binding_point_type);

    /* Check if the port is bound by this client and get the group id*/
    rc = flex_acl_db_system_acl_binding_point_get(direction, bind_point_id, &group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: Port [%u] is not bound and therefore cannot be unbound.\n", port);
        goto out;
    }

    /* Check that we are unbinding from the correct client */
    rc = flex_acl_db_system_acl_group_client_get(group_id, &db_client_id, &db_instance);
    if ((rc != SX_STATUS_SUCCESS) || (db_client_id != client_id) || (db_instance != instance)) {
        SX_LOG_ERR("SYSTEM ACL: Port [%u] is not bound to client [%u] instance [%u] and cannot be unbound.\n",
                   port, client_id, instance);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    port_type = SX_PORT_TYPE_ID_GET(port);
    rc = flex_acl_db_get_port_bind(port, direction, &bind_attribs_id, (port_type == SX_PORT_TYPE_LAG));
    if (rc != SX_STATUS_SUCCESS) {
        if (rc != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("Error finding log port [%u] direction[%u] in db, err[%s]\n",
                       port, direction, sx_status_str(rc));
        }
    }

    /* Get bind attributes from system */
    rc = flex_acl_get_bind_attribs(system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                   &system_bind_attribs_id, NULL, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when trying to get bind attributes id for system group id\n");
        goto out;
    }

    if (bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        bind_attribs_id = system_bind_attribs_id;
    }

    bind_point_id.port_id = port;

    rc = flex_acl_db_system_acl_binding_point_delete(direction, bind_point_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: Failed to remove attribute bind db for lag port [0x%x].\n", bind_point_id.port_id);
        goto out;
    }

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Get acl group error, group_id: %u\n", group_id);
        goto rollback_bind_point_del;
    }

    rc = flex_acl_db_group_unbind_log_port(acl_group, port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Error DB unbind system acl group id: %u\n", group_id);
        goto rollback_bind_point_del;
    }

    rc = flex_acl_port_unbind_internal(system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                       port, bind_attribs_id);
    /* System ACL unbind can be called for an unbound entry.
     * This happens when a Port is removed from SWID - first ACLs are cleared and then
     * system ACL remove callback is activated. In order to skip errors
     * Allow an ENTRY_NOT_BOUND return code to be skipped.
     */
    if (rc == SX_STATUS_ENTRY_NOT_BOUND) {
        rc = SX_STATUS_SUCCESS;
    }
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in system acl individual unbinding port [0x%x].\n", port);
        goto rollback_db_unbind;
    }

    goto out;

rollback_db_unbind:
    rb_rc = flex_acl_db_group_bind_log_port(acl_group, port);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Error in rollback - DB bind system acl group id: %u\n", group_id);
    }
rollback_bind_point_del:
    rb_rc = flex_acl_db_system_acl_binding_point_add(direction,
                                                     bind_point_id,
                                                     system_acl_clients_table[client_id].instance_info[instance].acl_group_id,
                                                     FALSE);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: Failed to remove attribute bind db for lag port [0x%x].\n", bind_point_id.port_id);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* This function will be used to unbind all the rifs from a client. This is done for a specified acl group. */
static sx_status_t __system_acl_individual_unbind_groups(system_acl_client_id_e client_id,
                                                         uint32_t               instance,
                                                         sx_acl_id_t            group_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    cl_list_iterator_t       itor = NULL;
    cl_list_iterator_t       list_end = NULL;
    cl_list_t               *list_p = NULL;
    sx_rif_id_t              rif;
    sx_port_id_t             port;
    flex_acl_db_acl_group_t *acl_group = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("SYSTEM ACL: Failed to get group id [%u].\n", group_id);
        goto out;
    }

    list_p = &(acl_group->bound_rifs);
    itor = cl_list_head(list_p);
    list_end = cl_list_end(list_p);

    while (itor != list_end) {
        /* Get the group from the list */
        rif = (sx_rif_id_t)((intptr_t)cl_list_obj(itor));
        /* Go to the next item since the current entry will be deleted by the next lines */
        itor = cl_list_next(itor);
        /* Use the regular unbind function to remove the binding */
        rc = system_acl_rif_unbind(client_id, instance, rif);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SYSTEM ACL: Failed unbind client id [%u] instance [%u] rif [%u].\n",
                       client_id,
                       instance,
                       rif);
            goto out;
        }
    }
    list_p = &(acl_group->bound_log_ports);
    itor = cl_list_head(list_p);
    list_end = cl_list_end(list_p);
    while (itor != list_end) {
        /* Get the group from the list */
        port = (sx_port_id_t)((intptr_t)cl_list_obj(itor));
        /* Go to the next item since the current entry will be deleted by the next lines */
        itor = cl_list_next(itor);
        /* Use the regular unbind function to remove the binding */
        rc = system_acl_port_unbind(client_id, instance, port);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SYSTEM ACL: Failed unbind client id [%u] instance [%u] port [0x%x].\n",
                       client_id,
                       instance,
                       port);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* This function will be used when a client is delete so we need to remove all bound ports/rifs */
static sx_status_t __system_acl_individual_client_unbind(system_acl_client_id_e client_id, uint32_t instance)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Remove the default's group ports */
    rc = __system_acl_individual_unbind_groups(client_id,
                                               instance,
                                               system_acl_clients_table[client_id].instance_info[instance].acl_group_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("SYSTEM ACL: Failed to remove default all bounded ports for client id [%u] instance [%u].\n",
                   client_id,
                   instance);
        goto out;
    }

    /* Delete the default created bind attributes */
    rc = __system_acl_delete_bind_group(client_id, instance);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("SYSTEM ACL: Failed to delete default bind group for client id [%u] instance [%u].\n",
                   client_id,
                   instance);
        goto out;
    }

out:
    /* No rollback here since the DB is destroyed during the unbind */
    SX_LOG_EXIT();
    return rc;
}
sx_status_t system_acl_issu_mc_router_bind_trigger_spc2(sx_access_cmd_t cmd, system_acl_client_id_e client_id)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_acl_id_t                group_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_ip_version_t            ip_version = SX_IP_VERSION_NONE;

    SX_LOG_ENTER();

    /* Use the client's default group */
    group_id = system_acl_clients_table[client_id].instance_info[0].acl_group_id;

    rc = flex_acl_get_bind_attribs(group_id, &bind_attribs_id, NULL, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SYSTEM ACL: failed to get bind attributes id for group_id [%u].\n", group_id);
        goto out;
    }

    switch (client_id) {
    case SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E:
        ip_version = SX_IP_VERSION_IPV4;
        break;

    case SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E:
        ip_version = SX_IP_VERSION_IPV6;
        break;

    default:
        SX_LOG_ERR("Unsupported client [%u] for mc bind.\n", client_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Write the mc bind attribute to the hw.*/
    rc = flex_acl_hw_reg_write_mc_bind(cmd, ip_version, bind_attribs_id);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed to bind client id [%u] in ISSU \n", client_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}
