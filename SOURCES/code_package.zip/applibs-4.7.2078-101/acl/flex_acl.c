/*
 * SPDX-FileCopyrightText: Copyright (c) 2015-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "flex_acl.h"
#include "system_acl.h"
#include "flex_acl_gen_def.h"
#include "flex_acl_db.h"
#include "flex_acl_tcam_manager.h"
#include "flex_acl_keys.h"
#include "flex_acl_actions.h"
#include "flex_acl_binding.h"
#include "flex_acl_rule_based_binding.h"
#include <utils/utils.h>
#include <sx/sdk/sx_event.h>
#include "sx/sdk/sx_lib_flex_acl.h"
#include "bridge_lib/bridge_common.h"
#include "ethl2/brg.h"
#include "ethl2/topo.h"
#include "ethl2/port.h"
#include "ethl2/port_db.h"
#include "ethl2/lag_sink.h"
#include "ethl2/fdb.h"
#include "ethl2/la_db.h"
#include "ethl2/vlan.h"
#include "ethl2/fid_manager.h"
#include "ethl3/router_common.h"
#include "ethl3/hwi/sdk_router_vrid/sdk_router_vrid_impl.h"
#include "ethl3/hwi/ecmp/router_ecmp_impl.h"
#include "sx_core/sx_core_api.h"
#include <acl/flex_acl_db.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sdk/sx_flex_acl.h>
#include "resource_manager/resource_manager_sdk_table.h"
#include <kvd/kvd_linear_manager.h>
#include "flex_acl_hw.h"
#include <counters/counter_manager/counter_manager.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "acl.h"
#include <resource_manager/resource_manager.h>
#include <span/span.h>
#include <sx/sdk/sx_mc_container.h>
#include <mc_container/hwd/erif_list_manager.h>
#include <mc_container/hwd/hwd_mc_container.h>
#include <mc_container/hwi/mc_container_db.h>
#include "acl/system_acl.h"
#include "acl/system_acl_mc.h"
#include <utils/sx_adviser.h>
#include <tunnel/hwi/tunnel_impl.h>
#include "mpls/hwd/hwd_ftn_impl.h"
#include "mpls/hwd/continue_lookup_nhlfe.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "sx/sxd/sxd_dpt.h"
#include "issu/issu.h"
#include "flex_modifier/flex_modifier.h"
#include <tunnel/hwi/ipv6_mgr_impl.h>
#include <tunnel/hwd/hwd_ipv6_mgr.h>
#include <utils/sx_ip_utils.h>
#include "ethl3/hwi/nat_4to6/nat_4to6_impl.h"
#include "truncation_profile/truncation_profile.h"
#include "dbg_dump_modules/dbg_dump_modules.h"

#undef __MODULE__
#define __MODULE__ ACL

/************************************************
 *  Macros
 ***********************************************/

/************************************************
**  Global variables
************************************************/

typedef struct {
    sx_dev_id_t devs[SX_DEV_NUM_MAX];
} flex_acl_enforced_devices_t;

flex_acl_enforced_devices_t g_enforced_devs = {
    {0}
};

typedef struct {
    sx_port_id_t lag_port_log_id;
    sx_port_id_t log_port;
} flex_acl_validate_pbs_lag_params_t;

extern sx_brg_context_t              brg_context;
boolean_t                            g_flex_acl_initialized = FALSE;
flex_acl_db_goto_validation_params_t flex_acl_goto_validation_params;
flex_acl_ops_t                      *flex_acl_ops_g = NULL;
acl_custom_bytes_set_data_t         *custom_bytes_set_data = NULL;
extern acl_stage_e                   g_acl_stage;
boolean_t                            g_flex_acl_manual_unbind = FALSE; /* When enabled user RIF bound ACLs
                                                                        *  are allowed to be unbound by user only,
                                                                        *  to enable RIFs lazy delete functionality */
static boolean_t g_default_action_issu_support = FALSE;  /* [SPC2+] Flag indicates whether defaults actions are supported by ISSU */
static boolean_t g_pagt_v2_issu_support = FALSE;         /* Flag indicating if the previous version already supported PAGT_V2 functionality */
static boolean_t g_pagt_v2_issu_alignment_check = TRUE;  /* Flag indicating if we need to check the need for PAGT_V2 bank alignment after ISSU */

sx_status_t system_acl_set_register_callbacks(system_acl_client_id_e client_id,
                                              sx_acl_region_id_t     region_id);

/***********************************************
*  Local variables
***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static flex_acl_init_flags_t         g_init_flags = {FALSE};
static cntr_client_handle_t          acl_cm_handle;
static policer_manager_user_handle_t acl_policer_manager_handle;
static span_client_handle_t          acl_span_handle;

#define FLEX_ACL_RULES_MIN                     2
#define FLEX_ACL_NUM_OF_RESERVED_REGIONS       1
#define FLEX_ACL_IS_EXTENDED_ACTION            TRUE
#define FLEX_ACL_MIN_LIST_ITEMS_REDIRECTION_DB 10
#define FLEX_ACL_PORT_LIST_MIN_ID              1

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __dump_module_flex_acl_wrapper(dbg_dump_params_t *dbg_dump_params_p);
static sx_status_t __dump_module_flex_acl_main_wrapper(dbg_dump_params_t *dbg_dump_params_p);
static sx_status_t __dump_module_flex_acl_db_wrapper(dbg_dump_params_t *dbg_dump_params_p);
static sx_status_t __dump_module_flex_acl_rbb_wrapper(dbg_dump_params_t *dbg_dump_params_p);
static sx_status_t __dump_module_flex_acl_hw_db_wrapper(dbg_dump_params_t *dbg_dump_params_p);
static sx_status_t __dump_module_flex_acl_system_wrapper(dbg_dump_params_t *dbg_dump_params_p);

static inline sx_status_t __flex_acl_deinit_commit_acls();
static inline sx_status_t __flex_acl_init_commit_acls();
static inline sx_status_t __flex_acl_unset_commit_acl(sx_acl_direction_t egress, sx_acl_key_type_t *key_handle);
static inline sx_status_t __flex_acl_set_commit_acl(sx_acl_direction_t egress, sx_acl_key_type_t key_handle);

/* sx_acl_key_block_t __flex_acl_get_first_available_block( */
/*        sx_acl_key_block_t *blocks, uint32_t key_blocks_count); */
static sx_status_t __flex_acl_device_ready_callback(adviser_event_e event_type, void *param);
static sx_status_t __flex_acl_port_handle_swid_callback(adviser_event_e event_type, void *param);
static sx_status_t __flex_acl_pre_port_del_from_swid_callback(adviser_event_e event_type, void *param);
static sx_status_t __flex_acl_enforce_min_table_size_on_new_dev(sx_dev_id_t dev_id);
/**
 * The function will resize and increase the size of the reserved region.
 * It is used by Resource Manager to make sure minimum requirement will be met.
 *
 * allocate_size -> [in] size to reserve. 0 means deallocate region.
 * */
/* RM table management functions */
static sx_status_t __flex_acl_enforce_min_table_size(uint32_t allocate_size);
static boolean_t __flex_acl_enforce_min_for_devs(flex_acl_db_acl_region_t *acl_region,
                                                 sxd_acl_ptar_op_t op, sxd_acl_ptar_op_t rollback_op,
                                                 boolean_t is_rollback_needed, sx_acl_size_t size,
                                                 sx_acl_size_t rollback_size);
static sx_status_t __flex_acl_enforce_min_per_dev(flex_acl_db_acl_region_t * acl_region, sx_dev_id_t dev_id,
                                                  acl_region_op_e op, acl_region_op_e rollback_op,
                                                  sx_acl_size_t size, sx_acl_size_t rollback_size,
                                                  boolean_t need_rollback);
/* lag management callbacks and functions */
static sx_status_t __flex_acl_lag_port_update(sx_port_id_t lag_port_log_id,
                                              lag_sink_event_type_e event_type, sx_port_id_t port_log_id,
                                              void *context_p);
static sx_status_t __flex_acl_lag_global_update(sx_port_id_t lag_port_log_id,
                                                lag_sink_event_type_e event_type, void *context_p);
static sx_status_t __flex_acl_rules_update(sx_acl_region_id_t        region_id,
                                           flex_acl_db_flex_rule_t  *rules,
                                           uint16_t                  rules_count,
                                           flex_acl_db_acl_region_t *acl_region);
static sx_status_t __flex_acl_rules_validation(sx_api_flex_acl_rules_set_params_t *params,
                                               flex_acl_db_acl_region_t           *acl_region,
                                               boolean_t                           is_flex);
static sx_status_t __flex_acl_rules_delete(sx_api_flex_acl_rules_set_params_t *params,
                                           flex_acl_db_flex_rule_t *rules, flex_acl_db_acl_region_t *acl_region);
static sx_status_t __flex_acl_destroy_acl_region(sx_api_acl_region_set_params_t *params, uint32_t *region_size);
sx_status_t __flex_acl_update_acl_group(sx_acl_id_t group_id, sx_acl_id_t *acl_ids, uint32_t acl_ids_num);
sx_status_t __flex_acl_allocate_group(sx_acl_id_t       *group_id,
                                      sx_acl_direction_t direction);
sx_status_t __flex_acl_free_group(sx_acl_id_t group_id);
sx_status_t __flex_acl_free_group_bind_attributes(sx_acl_id_t group_id);
static sx_status_t __flex_acl_add_acl_to_group(sx_acl_id_t group_id,
                                               uint32_t acl_ids_num, sx_acl_id_t* acl_ids);
sx_status_t __flex_acl_group_edit(sx_acl_id_t group_id, sx_acl_id_t *acl_ids, uint32_t acl_ids_num);
static sx_status_t __flex_acl_group_write(sx_acl_id_t group_id);
static sx_status_t __flex_acl_create_new_region(sx_api_acl_region_set_params_t *params,
                                                uint32_t                        reserved_rules_num,
                                                system_acl_client_id_e          client_id,
                                                boolean_t                       stateful_db_region);
static sx_status_t __flex_acl_destroy_reserved_region(sx_acl_region_id_t region_id);
static sx_status_t __flex_acl_create_reserved_region(sx_api_acl_region_set_params_t *params);
static sx_status_t __flex_acl_group_update_current_and_head(sx_acl_id_t                group_id,
                                                            flex_acl_bind_attribs_id_t attribs_id,
                                                            sx_acl_id_t               *acl_ids,
                                                            uint32_t                   count);
static sx_status_t __flex_acl_update_rules_to_devs(flex_acl_db_acl_region_t *acl_region,
                                                   flex_acl_db_flex_rule_t  *rules,
                                                   uint16_t                  rules_count,
                                                   boolean_t                 is_full_write);
static sx_status_t __flex_acl_is_region_have_valid_rules(sx_acl_region_id_t region_id, boolean_t *valid_rules_exist);
static sx_status_t __flex_acl_validate_groups_bind(sx_acl_id_t group_id, sx_acl_id_t group_id_other);
static sx_status_t __flex_acl_dec_actions_ref(flex_acl_db_flex_rule_t *rule, sx_acl_region_id_t region_id);
static sx_status_t __flex_acl_add_actions_ref(flex_acl_db_flex_rule_t *rule, sx_acl_region_id_t region_id);
static sx_status_t __flex_acl_pre_port_added_to_lag(sx_port_id_t log_port, sx_port_id_t lag_port_log_id);
static sx_status_t __flex_acl_pbs_count_ports(sx_api_acl_pbs_get_params_t *params);
static sx_status_t __flex_acl_pbs_get(sx_api_acl_pbs_get_params_t *param);
static sx_status_t __flex_acl_validate_pbs_ports(uint32_t                ports_count,
                                                 sx_port_id_t            log_ports[],
                                                 sx_swid_id_t            param_swid,
                                                 boolean_t              *is_vport,
                                                 sx_fid_t               *fid,
                                                 sx_acl_pbs_entry_type_t entry_type);
static sx_status_t __flex_acl_change_pbs_actions(flex_acl_db_pbs_entry_t *pbs_entry,
                                                 boolean_t                to_pbs_action,
                                                 boolean_t                full_rewrite);
static boolean_t __flex_acl_is_port_in_pbs(sx_swid_t       swid,
                                           uint32_t        port_num,
                                           sx_port_id_t   *ports_to_add,
                                           sx_acl_pbs_id_t pbs_id,
                                           sx_fid_t        fid,
                                           uint16_t        old_ports_count,
                                           boolean_t       is_vport);
static sx_status_t __flex_acl_rules_set_internal(sx_api_flex_acl_rules_set_params_t *params, boolean_t flex);
static sx_status_t __flex_acl_delete_all_rules_from_region(sx_acl_region_id_t region_id);
static sx_status_t __flex_acl_update_rm(uint32_t               region_new_size,
                                        uint32_t               region_old_size,
                                        system_acl_client_id_e client_id,
                                        sx_acl_key_type_t      key_handle);
static sx_status_t __flex_acl_rules_l4_port_range_ref_count(sx_flex_acl_key_desc_t *key, boolean_t is_inc);
static sx_status_t __flex_acl_rules_keys_ref_update(flex_acl_db_flex_rule_t *rule,
                                                    boolean_t                is_inc,
                                                    sx_acl_region_id_t       region_id);
static sx_status_t __flex_acl_pbs_del_ports_internal(flex_acl_db_pbs_entry_t *pbs_entry,
                                                     sx_swid_id_t             swid,
                                                     sx_port_id_t            *log_ports,
                                                     uint32_t                 port_num);
static sx_status_t __flex_acl_validate_pbs_lag(flex_acl_db_pbs_entry_t *pbs_entry, void *param_p);
static sx_status_t __flex_acl_rif_destroy_adviser_cb(adviser_event_e event_type, void *param);
static sx_status_t __flex_acl_rif_create_adviser_cb(adviser_event_e event_type, void *param);
static sx_status_t __flex_acl_set_ports_bitmap(sx_port_id_t *port_list,
                                               uint32_t      port_count,
                                               boolean_t     is_vport,
                                               uint8_t      *ports_bitmap);
static sx_status_t __flex_acl_vport_bridge_delete_cb(adviser_event_e event_type, void *param);
static sx_status_t __flex_acl_bind_group_on_goto_action_cb(flex_acl_db_flex_rule_t    *rule_p,
                                                           boolean_t                   rebind,
                                                           flex_acl_bind_attribs_id_t *bind_id,
                                                           boolean_t                  *is_empty_group);
static sx_status_t __flex_acl_unbind_group_on_goto_action_cb(sx_acl_id_t group_id, flex_acl_db_flex_rule_t *rule_p);
static sx_status_t __flex_acl_mc_container_ptr_changed(adviser_event_e event_type, void *param);

/* mc container next hop*/
static sx_status_t __flex_acl_mc_container_port_ref_inc(sx_mc_container_id_t mc_container_id);
static sx_status_t __flex_acl_mc_container_port_ref_dec(sx_mc_container_id_t mc_container_id);
static sx_status_t __flex_acl_mc_container_port_add_log_ports(sx_mc_container_id_t port_list_id);
static sx_status_t __flex_acl_rule_key_mc_container_change_cb(flex_acl_rule_id_t *rule_id_p, void *param_p);
static sx_status_t __flex_acl_rule_key_mc_container_change(sx_mc_container_id_t mc_container_id);
static sx_status_t __flex_acl_rule_port_filter_action_container_change_cb(flex_acl_rule_id_t *rule_id_p,
                                                                          void               *param_p);
static sx_status_t __flex_acl_rule_port_filter_action_container_change(sx_mc_container_id_t mc_container_id);
static sx_status_t __flex_acl_mc_container_change_write_to_hw(sx_mc_container_id_t mc_container_id);
static sx_status_t __flex_acl_remove_log_port_from_mc_container_port(sx_port_id_t         log_port_id,
                                                                     sx_mc_container_id_t mc_container_id);
static sx_status_t __flex_acl_add_log_port_to_mc_container_port(sx_port_id_t         log_port_id,
                                                                sx_mc_container_id_t mc_container_id);
static sx_status_t __flex_acl_remove_all_log_ports_from_mc_container_port(sx_mc_container_id_t mc_container_id);
static sx_status_t __flex_acl_mc_container_port_next_hops_change_cb(adviser_event_e event_type, void *param);
static sx_status_t __flex_acl_mc_container_port_rollback_db(sx_mc_container_id_t mc_container_id,
                                                            uint32_t             rollback_db_log_port_count,
                                                            sx_port_id_t        *rollback_db_log_ports_ref_list_p);
static sx_status_t __flex_acl_update_mc_container_port(sx_mc_container_id_t mc_container_id,
                                                       uint32_t old_port_count, sx_port_id_t *old_log_ports_ref_list_p,
                                                       uint32_t new_port_count,
                                                       sx_port_id_t *new_log_ports_ref_list_p);
static sx_status_t __flex_acl_post_port_added_to_lag_mc_container(sx_port_id_t lag_port_log_id);
static sx_status_t __flex_acl_post_port_removed_from_lag_mc_container(sx_port_id_t lag_port_log_id);
static sx_status_t __flex_acl_lag_destroyed_mc_container(sx_port_id_t lag_port_log_id);
static sx_status_t __flex_acl_post_port_del_from_swid_mc_container_port(sx_port_id_t port_log_id);
static sx_status_t __flex_acl_mc_container_post_port_changed(sx_port_id_t log_port_id,
                                                             boolean_t    write_to_hw,
                                                             boolean_t    remove_from_db);
static sx_status_t __flex_acl_write_region_offset_rule(sx_acl_region_id_t region_id, sx_acl_rule_offset_t offset);
static sx_status_t __flex_acl_fdb_mc_mid_changed(adviser_event_e event_type, void *param);
inline static void __flex_acl_pbs_to_mc_key(sx_acl_pbs_id_t pbs_id, sx_fid_t fid, fdb_ext_mc_key_t *key_p);
inline static void __flex_acl_mc_key_to_pbs(fdb_ext_mc_key_t key, sx_acl_pbs_id_t *pbs_id_p, sx_fid_t *fid_p);
static sx_status_t __flex_system_acl_set_mc_register_callbacks(system_acl_client_id_e client_id,
                                                               system_acl_hw_cb_t    *system_acl_hw_cb_p,
                                                               boolean_t             *change_needed);
static const char * acl_tunnel_ref_name(char* name_buf, size_t name_size, void *data);
static const char * acl_vrid_ref_name(char* name_buf, size_t name_size, void *data);
static const char * acl_mc_ref_name(char* name_buf, size_t name_size, void *data);
static const char * acl_rif_ref_name(char* name_buf, size_t name_size, void *data);
static const char * acl_ecmp_ref_name(char* name_buf, size_t name_size, void *data);
static const char * acl_gp_register_ref_name(char* name_buf, size_t name_size, void *data);
static const char * acl_flex_modifier_emt_ref_name(char* name_buf, size_t name_size, void *data);
static const char * acl_nat_ref_name(char* name_buf, size_t name_size, void *data);
static const char * acl_stateful_db_ref_name(char* name_buf, size_t name_size, void *data);
static sx_status_t __flex_acl_drop_trap_hw_db_del(flex_acl_db_flex_rule_t *rule);
static sx_status_t __flex_acl_acl_drop_db_update(flex_acl_db_flex_rule_t *old_rule_p,
                                                 flex_acl_db_flex_rule_t *new_rule_p);
static sx_status_t __flex_acl_tunnel_id_get(sx_tunnel_id_t *tunnel_id_p);
static sx_status_t __flex_acl_pbs_tunnel_map_entry_ref_inc_dec(sx_access_cmd_t          cmd,
                                                               flex_acl_db_pbs_entry_t *pbs_entry_p,
                                                               sx_tunnel_id_t           tunnel_id);
static sx_status_t __flex_acl_ecmp_update_ptr_changed(adviser_event_e event_type, void *param_p);
static sx_status_t __flex_acl_ipv6_reloc_changed(adviser_event_e event_type, void *param_p);
static sx_status_t __flex_acl_ipv6_addr_add(const sx_ip_addr_t   *ip_addr_p,
                                            hwi_ipv6_hw_handle_t *handle_p,
                                            hwi_ipv6_hw_index_t  *hw_index_p,
                                            boolean_t            *ipv6_added_p);
static sx_status_t __flex_acl_ipv6_addr_free(const sx_ip_addr_t *ip_addr_p);
static sx_status_t __flex_acl_delete_rule_refs(sx_acl_region_id_t region_id, flex_acl_db_flex_rule_t *rule);
static sx_status_t __flex_acl_issu_acl_group_alignment_needed();

/************************************************
 *  Local variables
 ***********************************************/
static ref_name_data_t acl_tunnel_name_data =
{.print_func_p = acl_tunnel_ref_name, .ref_data_p = NULL, .data_size = 0};
static ref_name_data_t acl_vrid_name_data = {.print_func_p = acl_vrid_ref_name, .ref_data_p = NULL, .data_size = 0};
static ref_name_data_t acl_mc_name_data = {.print_func_p = acl_mc_ref_name, .ref_data_p = NULL, .data_size = 0};
static ref_name_data_t acl_rif_name_data = {.print_func_p = acl_rif_ref_name, .ref_data_p = NULL, .data_size = 0};
static ref_name_data_t acl_ecmp_name_data = {.print_func_p = acl_ecmp_ref_name, .ref_data_p = NULL, .data_size = 0};
static ref_name_data_t acl_gp_register_name_data =
{.print_func_p = acl_gp_register_ref_name, .ref_data_p = NULL, .data_size = 0};
static ref_name_data_t acl_flex_modifier_emt_name_data =
{.print_func_p = acl_flex_modifier_emt_ref_name, .ref_data_p = NULL, .data_size = 0};
static ref_name_data_t acl_nat_name_data =
{.print_func_p = acl_nat_ref_name, .ref_data_p = NULL, .data_size = 0};
static ref_name_data_t acl_stateful_db_name_data =
{.print_func_p = acl_stateful_db_ref_name, .ref_data_p = NULL, .data_size = 0};


/************************************************
 *  Function implementations
 ***********************************************/
static const char * acl_tunnel_ref_name(char* name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = ACL_TUNNEL_REF;

    return ref_name;
}

static const char * acl_vrid_ref_name(char* name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = ACL_VRID_REF;

    return ref_name;
}

static const char * acl_mc_ref_name(char* name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = ACL_MC_REF;

    return ref_name;
}

static const char * acl_rif_ref_name(char* name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = ACL_RIF_REF;

    return ref_name;
}

static const char * acl_ecmp_ref_name(char* name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = ACL_ECMP_REF;

    return ref_name;
}

static const char * acl_gp_register_ref_name(char* name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = ACL_GP_REGISTER_REF;

    return ref_name;
}

static const char * acl_flex_modifier_emt_ref_name(char* name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = ACL_FLEX_MODIFIER_EMT_REF;

    return ref_name;
}

static const char * acl_nat_ref_name(char* name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = ACL_NAT_REF;

    return ref_name;
}

static const char * acl_stateful_db_ref_name(char* name_buf, size_t name_size, void *data)
{
    UNUSED_PARAM(name_buf);
    UNUSED_PARAM(name_size);
    UNUSED_PARAM(data);
    const char* ref_name = ACL_STATEFUL_DB_REF;

    return ref_name;
}


sx_status_t __flex_acl_enforce_min_per_dev(flex_acl_db_acl_region_t * acl_region,
                                           sx_dev_id_t                dev_id,
                                           acl_region_op_e            op,
                                           acl_region_op_e            rollback_op,
                                           sx_acl_size_t              size,
                                           sx_acl_size_t              rollback_size,
                                           boolean_t                  need_rollback)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_status_t rb_rc = SX_STATUS_SUCCESS;
    uint8_t     tcam_region_info[SXD_TCAM_REGION_INFO_SIZE_BYTES];
    boolean_t   hw_set = FALSE;

    SX_LOG_ENTER();

    memset(tcam_region_info, 0, sizeof(tcam_region_info));

    /* Skip if need to bind and already bound */
    if ((op == ACL_REGION_HW_OP_ALLOCATE_E) && g_enforced_devs.devs[dev_id]) {
        SX_LOG_ERR("Reserved region already enforced to device [%d]\n", dev_id);
        rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    /* Skip if not bound and need to deallocate/edit */
    if (((op == ACL_REGION_HW_OP_DEALLOCATE_E) ||
         (op == ACL_REGION_HW_OP_RESIZE_E)) && (!g_enforced_devs.devs[dev_id])) {
        SX_LOG_ERR("Reserved region not bound to device, editing failed\n");
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Configure the device */
    rc = flex_acl_hw_reg_write_region(acl_region, dev_id, op, tcam_region_info,
                                      sizeof(tcam_region_info), size, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to update HW with reserved region size [%u]\n", size);
        goto out;
    }

    hw_set = TRUE;

    /* Update database (Per device) */
    switch (op) {
    case ACL_REGION_HW_OP_DEALLOCATE_E:

        rc = flex_acl_db_region_unbind_set(acl_region->region_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to update DB, [region_id = %u]\n", acl_region->region_id);
            goto out;
        }
        rc = flex_acl_hw_region_update_unbind(acl_region->region_id, dev_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to update hw DB, [region_id = %u]\n", acl_region->region_id);
            rb_rc = flex_acl_db_region_bind_set(acl_region->region_id);
            if (SX_CHECK_FAIL(rb_rc)) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
            }
            goto out;
        }
        g_enforced_devs.devs[dev_id] = FALSE;

        break;

    case ACL_REGION_HW_OP_ALLOCATE_E:

        rc = flex_acl_db_region_bind_set(acl_region->region_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to update DB, [region_id = %u]\n", acl_region->region_id);
            goto out;
        }
        rc = flex_acl_hw_region_update_bind(acl_region->region_id, dev_id, tcam_region_info, sizeof(tcam_region_info));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to update hw DB, [region_id = %u]\n", acl_region->region_id);
            rb_rc = flex_acl_db_region_unbind_set(acl_region->region_id);
            if (SX_CHECK_FAIL(rb_rc)) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
            }
            goto out;
        }
        g_enforced_devs.devs[dev_id] = TRUE;

        break;

    case ACL_REGION_HW_OP_RESIZE_E:
        /* Nothing to do. */
        break;

    default:
        rc = SX_STATUS_UNSUPPORTED;
        break;
    }

out:
    if ((rc != SX_STATUS_SUCCESS) && (TRUE == hw_set) && (TRUE == need_rollback)) {
        rb_rc = flex_acl_hw_reg_write_region(acl_region,
                                             dev_id,
                                             rollback_op,
                                             tcam_region_info,
                                             sizeof(tcam_region_info),
                                             rollback_size,
                                             NULL);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
    }
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    flex_acl_db_log_verbosity_level_set(verbosity_level);
    flex_acl_hw_log_verbosity_level_set(verbosity_level);
    flex_acl_keys_log_verbosity_level_set(verbosity_level);
    flex_acl_actions_log_verbosity_level_set(verbosity_level);
    flex_acl_binding_log_verbosity_level_set(verbosity_level);
    flex_acl_rule_based_binding_log_verbosity_level_set(verbosity_level);
    system_acl_mc_log_verbosity_level_set(verbosity_level);

    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level)
{
    *verbosity_level = LOG_VAR_NAME(__MODULE__);

    return SX_STATUS_SUCCESS;
}


sx_status_t __flex_acl_vlan_group_check_entry_type(flex_acl_db_vlan_group_element_t *grp_info, void *param_p)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e *entry_type_p = (flex_acl_entry_type_e*)param_p;

    SX_LOG_ENTER();
    if ((grp_info->entry_type != *entry_type_p) && grp_info->allocated) {
        SX_LOG_ERR("Vlan group[%u] entry type[%u] are different from desired[%u] \n",
                   grp_info->group_id,
                   grp_info->entry_type,
                   *entry_type_p);
        rc = SX_STATUS_ERROR;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* no user groups allowed when system acl set */
static sx_status_t __flex_acl_system_vlan_group_allocate(sx_acl_vlan_group_t   *vlan_group_id,
                                                         system_acl_client_id_e client_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
/*    flex_acl_entry_type_e            entry_type = FLEX_ACL_ENTRY_TYPE_SYSTEM_E; */
    system_acl_instance_info_t *client_instance_info = NULL;
    sx_api_acl_bind_params_t    bind_vlan_params;

    SX_LOG_EXIT();

    /* CHECK THAT users vlan groups not exists - temp*/
    /* rc = flex_acl_db_vlan_group_foreach(__flex_acl_vlan_group_check_entry_type, (void*)&entry_type); */
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: could not set up entry type for vlan group [%x]\n", *vlan_group_id);
        goto out;
    }

    /* Allocate new index for group, check that are available groups*/
    rc = flex_acl_db_vlan_group_allocate(vlan_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: could not allocate group [%u]\n", *vlan_group_id);
        goto out;
    }
    rc = flex_acl_db_vlan_group_entry_type_set(*vlan_group_id, FLEX_ACL_ENTRY_TYPE_SYSTEM_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: could not set up entry type for vlan group [%x]\n", *vlan_group_id);
        goto out;
    }
    rc = system_acl_instance_get_by_id(client_id, 0, &client_instance_info);
    if ((rc != SX_STATUS_SUCCESS) || (client_instance_info == NULL)) {
        SX_LOG_ERR("ACL:failed to get system client[%u] instance[%u] entry\n", client_id, 0);
        goto out;
    }
    if (client_instance_info->acl_group_id == FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG_DBG("System group for bind vlan group[%u] operation does not exist\n", *vlan_group_id);
        goto out;
    }

    bind_vlan_params.acl_direction = SX_ACL_DIRECTION_INGRESS;
    bind_vlan_params.vlan_group = *vlan_group_id;
    bind_vlan_params.acl_id = client_instance_info->acl_group_id;
    bind_vlan_params.cmd = SX_ACCESS_CMD_ADD;

    rc = flex_acl_bind_vlan_group_internal(&bind_vlan_params, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed bind VLAN group[%u] to System ACL Group[%x]\n",
                   *vlan_group_id,
                   client_instance_info->acl_group_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_system_vlan_group_destroy(sx_acl_vlan_group_t *vlan_group_id, system_acl_client_id_e client_id)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_status_t                 rb_rc = SX_STATUS_SUCCESS;
    system_acl_instance_info_t *client_instance_info = NULL;
    sx_api_acl_bind_params_t    bind_vlan_params;

    rc = system_acl_instance_get_by_id(client_id, 0, &client_instance_info);
    if ((rc != SX_STATUS_SUCCESS) || (client_instance_info == NULL)) {
        SX_LOG_ERR("ACL:failed to get system client[%u] instance[%u] entry\n", client_id, 0);
        goto out;
    }

    if (client_instance_info->acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
        bind_vlan_params.acl_direction = SX_ACL_DIRECTION_INGRESS;
        bind_vlan_params.vlan_group = *vlan_group_id;
        bind_vlan_params.acl_id = client_instance_info->acl_group_id;
        bind_vlan_params.cmd = SX_ACCESS_CMD_DELETE;

        rc = flex_acl_unbind_vlan_group_internal(&bind_vlan_params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed unbind VLAN group[%u] from System ACL Group[%x]\n",
                       *vlan_group_id,
                       client_instance_info->acl_group_id);
            goto out;
        }
    } else {
        SX_LOG_DBG("System group for unbind vlan group[%u] operation does not exist\n", *vlan_group_id);
    }

    rc = flex_acl_db_vlan_group_validate_destroy(*vlan_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: could not destroy vlan group [%u]\n", *vlan_group_id);
        goto rollback_unbind_system;
    }

    /* This will clear resources, allowed only on empty group*/
    rc = flex_acl_db_vlan_group_destroy(*vlan_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: could not destroy vlan group [%u]\n", *vlan_group_id);
        goto out;
    }
    goto out;

rollback_unbind_system:
    if (client_instance_info->acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
        bind_vlan_params.cmd = SX_ACCESS_CMD_ADD;
        rb_rc = flex_acl_bind_vlan_group_internal(&bind_vlan_params, FALSE);
        if (SX_STATUS_SUCCESS != rb_rc) {
            SX_LOG_ERR("ACL: Failed bind VLAN group[%u] from System ACL Group at rollback operation[%x]\n",
                       *vlan_group_id,
                       client_instance_info->acl_group_id);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_vlan_group_set(sx_api_acl_vlan_group_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    rc = flex_acl_vlan_group_set_internal(params, SYSTEM_ACL_CLIENT_ID_INVALID_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Vlan group set failed. group_id[%x]\n", params->vlan_group_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_vlan_group_set_internal(sx_api_acl_vlan_group_set_params_t *params,
                                             system_acl_client_id_e              client_id)
{
    sx_status_t         rc = SX_STATUS_SUCCESS, rb_st = SX_STATUS_SUCCESS;
    uint32_t            port_num = 0;
    uint32_t            i = 0;
    sx_acl_vlan_group_t default_vlan_group_id = 0xFF;

    SX_LOG_ENTER();

    /**** Check input parameters */
    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if ((params->cmd != SX_ACCESS_CMD_CREATE) && (params->cmd != SX_ACCESS_CMD_DESTROY)) {
        if (!VLAN_NUMS_CHECK_MAX(params->vlan_num)) {
            SX_LOG_ERR("vlan_num param exceeds range %u.\n", params->vlan_num);
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        for (i = 0; i < params->vlan_num; i++) {
            if (!VLAN_ID_CHECK_RANGE(params->vlan_list[i])) {
                SX_LOG_ERR("vlan id exceeds range %u.\n", params->vlan_list[i]);
                rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
        }

        if (!flex_acl_db_swid_in_range(params->swid)) {
            SX_LOG_ERR("ACL: swid has invalid value [%u]\n", params->swid);
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        /* Check SWID exist in DB */
        rc = port_swid_get(SX_ACCESS_CMD_GET, params->swid, NULL, &port_num);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: swid not found [%u]\n", params->swid);
            goto out;
        }
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:

        if (client_id == SYSTEM_ACL_CLIENT_ID_INVALID_E) {
            /* Allocate new index for group, check that are available groups*/
            rc = flex_acl_db_vlan_group_allocate(&params->vlan_group_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not allocate group [%u]\n", params->vlan_group_id);
                goto out;
            }
        } else {
            /* set up vlan group to bee system */
            rc = __flex_acl_system_vlan_group_allocate(&params->vlan_group_id, client_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not allocate group [%u]\n", params->vlan_group_id);
                goto out;
            }
        }
        break;

    case SX_ACCESS_CMD_ADD:
        /* if default group not exist */
        if (!g_init_flags.default_vlan_group_created) {
            /* Validate add swid,vid to vlan group */
            rc = flex_acl_db_vlan_group_validate_add(params->vlan_group_id,
                                                     params->swid,
                                                     params->vlan_list,
                                                     params->vlan_num);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not update vlan group [%u]. validation error\n", params->vlan_group_id);
                goto out;
            }

            rc = flex_acl_db_vlan_group_add(params->vlan_group_id, params->swid, params->vlan_list, params->vlan_num);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not update vlan group [%u] DB\n", params->vlan_group_id);
                goto out;
            }

            rc = flex_acl_hw_reg_write_vlan_group_add(params);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not configure vlan group [%u] in HW\n", params->vlan_group_id);
                /* back roll current db state */
                rb_st = flex_acl_db_vlan_group_remove_from(params->vlan_group_id,
                                                           params->swid,
                                                           params->vlan_list,
                                                           params->vlan_num);
                if (SX_CHECK_FAIL(rb_st)) {
                    SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
                }
                goto out;
            }
        } else {
            rc = flex_acl_db_get_default_vlan_group_id(&default_vlan_group_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to get default vlan group from db \n");
                goto out;
            }
            rc = system_acl_add_vlan_to_user_vlan_group(params->vlan_group_id,
                                                        params->swid,
                                                        params->vlan_list,
                                                        params->vlan_num);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to add vlan to vlan group [%u]\n", params->vlan_group_id);
                goto out;
            }
        }
        break;

    case SX_ACCESS_CMD_DELETE:

        if (!g_init_flags.default_vlan_group_created) {
            /* Validate remove swid,vid from vlan group */
            rc =
                flex_acl_db_vlan_group_validate_remove(params->vlan_group_id, params->swid, params->vlan_list,
                                                       params->vlan_num);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not update vlan group [%u]. validation error\n", params->vlan_group_id);
                goto out;
            }

            rc = flex_acl_db_vlan_group_remove_from(params->vlan_group_id,
                                                    params->swid,
                                                    params->vlan_list,
                                                    params->vlan_num);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not update vlan group [%u] DB\n", params->vlan_group_id);
                goto out;
            }
            rc = flex_acl_hw_reg_write_vlan_group_add(params);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not configure vlan group [%u] in HW\n", params->vlan_group_id);
                rb_st = flex_acl_db_vlan_group_remove_from(params->vlan_group_id,
                                                           params->swid,
                                                           params->vlan_list,
                                                           params->vlan_num);
                if (SX_CHECK_FAIL(rb_st)) {
                    SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
                }
                goto out;
            }
        } else {
            rc = flex_acl_db_get_default_vlan_group_id(&default_vlan_group_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to get default vlan group from db \n");
                goto out;
            }
            rc = system_acl_remove_vlan_from_user_vlan_group(params->vlan_group_id,
                                                             params->swid,
                                                             params->vlan_list,
                                                             params->vlan_num);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to remove vlan from user vlan group[%u]\n", params->vlan_group_id);
                goto out;
            }
        }
        break;

    case SX_ACCESS_CMD_DESTROY:

        if (client_id == SYSTEM_ACL_CLIENT_ID_INVALID_E) {
            rc = flex_acl_db_vlan_group_validate_destroy(params->vlan_group_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not destroy vlan group [%u]\n", params->vlan_group_id);
                goto out;
            }
            /* This will clear resources, allowed only on empty group*/
            rc = flex_acl_db_vlan_group_destroy(params->vlan_group_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not destroy vlan group [%u]\n", params->vlan_group_id);
                goto out;
            }
        } else {
            /* unbind from system client and destroy */
            rc = __flex_acl_system_vlan_group_destroy(&params->vlan_group_id, client_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not allocate group [%u]\n", params->vlan_group_id);
                goto out;
            }
        }

        break;

    default:
        /* cmd not supported */
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t system_acl_add_vlan_to_default_vlan_group(system_acl_client_id_e client_id,
                                                      sx_acl_vlan_group_t    vlan_group_id,
                                                      sx_swid_id_t           swid,
                                                      sx_vlan_id_t          *vlan_list,
                                                      uint32_t               vlan_num)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    uint32_t                            vlan_idx = 0;
    flex_acl_vlan_attribs_t            *vlan_attribs_list = NULL;  /* Arranged according to vlan_list */
    sx_api_acl_vlan_group_set_params_t *vlan_add_params = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(vlan_list, "vlan_list"))) {
        goto out;
    }
    if (!g_init_flags.default_vlan_group_created) {
        SX_LOG_ERR("Failed add vlan - default vlan group not created\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    vlan_attribs_list = (flex_acl_vlan_attribs_t*)cl_malloc(sizeof(flex_acl_vlan_attribs_t) * vlan_num);
    if (!vlan_attribs_list) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(vlan_attribs_list, 0, sizeof(flex_acl_vlan_attribs_t) * vlan_num);

    /* Only 1 VID will be in use */
    vlan_add_params = (sx_api_acl_vlan_group_set_params_t*)cl_malloc(
        sizeof(sx_api_acl_vlan_group_set_params_t) + 1 * sizeof(sx_vlan_id_t));
    if (!vlan_add_params) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(vlan_add_params, 0, sizeof(sx_api_acl_vlan_group_set_params_t) + 1 * sizeof(sx_vlan_id_t));

    /* Check if in user group. if vlan exist in user group the VLAN attributes list will be set at idx of vlan
     * with added information about this vlan*/
    rc = flex_acl_db_get_vlan_attribs(swid,
                                      vlan_list,
                                      vlan_num,
                                      vlan_attribs_list);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: could not get VLAN attributes\n");
        goto out;
    }

    /* If VLAN already defined in System Default VLAN group - error */
    for (vlan_idx = 0; vlan_idx < vlan_num; vlan_idx++) {
        if (vlan_attribs_list[vlan_idx].is_exist && (vlan_attribs_list[vlan_idx].group_id == vlan_group_id)) {
            SX_LOG_ERR("ACL: The  vlan[%u] already defined in System ACL vlan group [%u]\n",
                       vlan_list[vlan_idx],
                       vlan_group_id);
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
        /* Same vlan cannot be used both in user vlan group and in system acl*/
        if (vlan_attribs_list[vlan_idx].is_exist) {
            SX_LOG_ERR("ACL: The  vlan[%u] already defined in user ACL vlan group [%u]\n",
                       vlan_list[vlan_idx], vlan_group_id);
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
    }

    /* For user VLAN groups only */
    for (vlan_idx = 0; vlan_idx < vlan_num; vlan_idx++) {
        /* add vlans to vlan group db of system group */
        rc = flex_acl_db_vlan_group_add(vlan_group_id, swid, &vlan_list[vlan_idx], 1);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: could not update vlan group [%u] DB\n", vlan_group_id);
            goto rollback;
        }

        vlan_add_params->swid = swid;
        vlan_add_params->vlan_group_id = vlan_group_id;
        vlan_add_params->vlan_list[0] = vlan_list[vlan_idx];
        vlan_add_params->vlan_num = 1;
        vlan_add_params->cmd = SX_ACCESS_CMD_ADD;
        rc = flex_acl_hw_reg_write_vlan_group_add(vlan_add_params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: could not configure vlan group [%u] in HW\n", vlan_group_id);
            goto rollback;
        }

        rc = flex_acl_db_system_vlan_group_add_entry(swid, client_id, vlan_list[vlan_idx]);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: could not configure vlan group [%u] in HW\n", vlan_group_id);
            goto rollback;
        }
    }
    goto out;

rollback:
out:
    if (vlan_attribs_list) {
        CL_FREE_N_NULL(vlan_attribs_list);
    }
    if (vlan_add_params) {
        CL_FREE_N_NULL(vlan_add_params);
    }
    SX_LOG_EXIT();
    return rc;
}


sx_status_t system_acl_remove_vlan_from_default_vlan_group(system_acl_client_id_e client_id,
                                                           sx_acl_vlan_group_t    default_vlan_group_id,
                                                           sx_swid_id_t           swid,
                                                           sx_vlan_id_t          *vlan_list,
                                                           uint32_t               vlan_num)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    uint32_t                            vlan_idx = 0;
    flex_acl_vlan_attribs_t            *vlan_attribs_list = NULL;
    sx_api_acl_vlan_group_set_params_t *vlan_add_params = NULL;
    boolean_t                           is_set = FALSE;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(vlan_list, "vlan_list"))) {
        goto out;
    }
    if (!g_init_flags.default_vlan_group_created) {
        SX_LOG_ERR("Failed to remove vlan - default vlan group not created\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    vlan_attribs_list = (flex_acl_vlan_attribs_t*)cl_malloc(sizeof(flex_acl_vlan_attribs_t) * vlan_num);
    if (!vlan_attribs_list) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(vlan_attribs_list, 0, sizeof(flex_acl_vlan_attribs_t) * vlan_num);

    vlan_add_params = (sx_api_acl_vlan_group_set_params_t*)cl_malloc(
        sizeof(sx_api_acl_vlan_group_set_params_t) + 1 * sizeof(sx_vlan_id_t));
    if (!vlan_add_params) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(vlan_add_params, 0, sizeof(sx_api_acl_vlan_group_set_params_t) + 1 * sizeof(sx_vlan_id_t));

    /* check if in user group. if vlan exists in user group the vlan bit arr will be set at idx of vlan*/
    rc = flex_acl_db_get_vlan_attribs(swid,
                                      vlan_list,
                                      vlan_num,
                                      vlan_attribs_list);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: could not get VLAN attributes\n");
        goto out;
    }

    for (vlan_idx = 0; vlan_idx < vlan_num; vlan_idx++) {
        is_set = FALSE;
        rc = flex_acl_db_system_vlan_is_vlan_set(swid, vlan_list[vlan_idx], &is_set);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at check if VLAN[%u] set in system vlan group[%u]\n",
                       vlan_list[vlan_idx],
                       default_vlan_group_id);
            goto out;
        }
        if (!vlan_attribs_list[vlan_idx].is_exist || !is_set) {
            SX_LOG_ERR("ACL:Error, trying to remove vlan[%u] that not added to db\n", vlan_list[vlan_idx]);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    for (vlan_idx = 0; vlan_idx < vlan_num; vlan_idx++) {
        /* check if belong to user */
        if (vlan_attribs_list[vlan_idx].is_exist && (vlan_attribs_list[vlan_idx].group_id != default_vlan_group_id)) {
            /* check if user group bound - sanity check*/
            SX_LOG_ERR("ACL: default vlan [%u] belongs to a user vlan group [%u]\n", vlan_idx, default_vlan_group_id);
            goto rollback;
        } else if (vlan_attribs_list[vlan_idx].is_exist) {
            /* remove vlans from db of system group */

            rc = flex_acl_db_vlan_group_remove_from(default_vlan_group_id, swid, &vlan_list[vlan_idx], 1);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: could not update vlan group [%u] DB\n", default_vlan_group_id);
                goto rollback;
            }
            /* remove from system in reg */
            vlan_add_params->cmd = SX_ACCESS_CMD_DELETE;
            vlan_add_params->vlan_group_id = default_vlan_group_id;
        }

        vlan_add_params->swid = swid;
        vlan_add_params->vlan_list[0] = vlan_list[vlan_idx];
        vlan_add_params->vlan_num = 1;
        rc = flex_acl_hw_reg_write_vlan_group_add(vlan_add_params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: could not configure vlan group [%u] in HW\n", default_vlan_group_id);
            goto rollback;
        }
        rc = flex_acl_db_system_vlan_group_remove_entry(swid, client_id, vlan_list[vlan_idx]);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: could not remove vlan[%u] in HW\n", default_vlan_group_id);
            goto rollback;
        }
    }
    goto out;

rollback:
out:
    if (vlan_attribs_list) {
        CL_FREE_N_NULL(vlan_attribs_list);
    }
    if (vlan_add_params) {
        CL_FREE_N_NULL(vlan_add_params);
    }
    SX_LOG_EXIT();
    return rc;
}


/* adds vlan to user vlan group */
sx_status_t system_acl_add_vlan_to_user_vlan_group(sx_acl_vlan_group_t vlan_group_id,
                                                   sx_swid_id_t        swid,
                                                   sx_vlan_id_t       *vlan_list,
                                                   uint32_t            vlan_num)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    uint32_t                            vlan_idx = 0;
    flex_acl_vlan_attribs_t            *vlan_attribs_list = NULL;
    sx_api_acl_vlan_group_set_params_t *vlan_add_params = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(vlan_list, "vlan_list"))) {
        goto out;
    }
    if (!g_init_flags.default_vlan_group_created) {
        SX_LOG_ERR("Failed add vlan - default vlan group not created\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    vlan_attribs_list = (flex_acl_vlan_attribs_t*)cl_malloc(sizeof(flex_acl_vlan_attribs_t) * vlan_num);
    if (!vlan_attribs_list) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(vlan_attribs_list, 0, sizeof(flex_acl_vlan_attribs_t) * vlan_num);

    vlan_add_params = (sx_api_acl_vlan_group_set_params_t*)cl_malloc(
        sizeof(sx_api_acl_vlan_group_set_params_t) + (vlan_num * sizeof(sx_vlan_id_t)));
    if (!vlan_add_params) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(vlan_add_params, 0, sizeof(sx_api_acl_vlan_group_set_params_t) + (vlan_num * sizeof(sx_vlan_id_t)));

    /* For all vlans get the attributes info */
    rc = flex_acl_db_get_vlan_attribs(swid,
                                      vlan_list,
                                      vlan_num,
                                      vlan_attribs_list);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: could not get VLAN attributes\n");
        goto out;
    }

    /* validate that not used in another user group or system group  */
    for (vlan_idx = 0; vlan_idx < vlan_num; vlan_idx++) {
        if (vlan_attribs_list[vlan_idx].is_exist) {
            SX_LOG_ERR("ACL: The desired vlan[%u] already used in vlan group[%u]\n",
                       vlan_list[vlan_idx],
                       vlan_attribs_list[vlan_idx].group_id);
            rc = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
    }

    /* iterate over vlans and add them to the group */
    for (vlan_idx = 0; vlan_idx < vlan_num; vlan_idx++) {
        /* add vlans to vlan group db of user group */

        rc = flex_acl_db_vlan_group_add(vlan_group_id, swid, &vlan_list[vlan_idx], 1);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: could not update vlan group [%u] DB\n", vlan_group_id);
            goto rollback;
        }
        vlan_add_params->swid = swid;
        vlan_add_params->vlan_group_id = vlan_group_id;
        vlan_add_params->vlan_list[0] = vlan_list[vlan_idx];
        vlan_add_params->vlan_num = 1;
        vlan_add_params->cmd = SX_ACCESS_CMD_ADD;
        rc = flex_acl_hw_reg_write_vlan_group_add(vlan_add_params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: could not configure vlan group [%u] in HW\n", vlan_group_id);
            goto rollback;
        }
    }
    goto out;


rollback:
out:
    if (vlan_attribs_list) {
        CL_FREE_N_NULL(vlan_attribs_list);
    }
    if (vlan_add_params) {
        CL_FREE_N_NULL(vlan_add_params);
    }
    SX_LOG_EXIT();
    return rc;
}


/* removes vlan from user vlan group. */
sx_status_t system_acl_remove_vlan_from_user_vlan_group(sx_acl_vlan_group_t vlan_group_id,
                                                        sx_swid_id_t        swid,
                                                        sx_vlan_id_t       *vlan_list,
                                                        uint32_t            vlan_num)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS;
    uint32_t                            vlan_idx = 0;
    flex_acl_vlan_attribs_t            *vlan_attribs_list = NULL;
    sx_api_acl_vlan_group_set_params_t *vlan_add_params = NULL;
    boolean_t                           is_set = FALSE;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(vlan_list, "vlan_list"))) {
        goto out;
    }
    if (!g_init_flags.default_vlan_group_created) {
        SX_LOG_ERR("Failed to remove vlan - default vlan group not created\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }


    vlan_attribs_list = (flex_acl_vlan_attribs_t*)cl_malloc(sizeof(flex_acl_vlan_attribs_t) * vlan_num);
    if (!vlan_attribs_list) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(vlan_attribs_list, 0, sizeof(flex_acl_vlan_attribs_t) * vlan_num);
    vlan_add_params = (sx_api_acl_vlan_group_set_params_t*)cl_malloc(
        sizeof(sx_api_acl_vlan_group_set_params_t) * sizeof(sx_vlan_id_t));
    if (!vlan_add_params) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(vlan_add_params, 0, sizeof(sx_api_acl_vlan_group_set_params_t) * sizeof(sx_vlan_id_t));
    /* get info about vlans to attributes list */
    rc = flex_acl_db_get_vlan_attribs(swid,
                                      vlan_list,
                                      vlan_num,
                                      vlan_attribs_list);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: could not get VLAN attributes\n");
        goto out;
    }
    /* check if in user group, if not - can't be removed */
    for (vlan_idx = 0; vlan_idx < vlan_num; vlan_idx++) {
        if (!vlan_attribs_list[vlan_idx].is_exist || (vlan_attribs_list[vlan_idx].group_id != vlan_group_id)) {
            SX_LOG_ERR("ACL:Error, trying to remove vlan[%u] that not belong to vlan group[%x]\n",
                       vlan_list[vlan_idx],
                       vlan_list[vlan_idx]);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }
    for (vlan_idx = 0; vlan_idx < vlan_num; vlan_idx++) {
        /* check if vlan belong to system group */
        rc = flex_acl_db_system_vlan_is_vlan_set(swid, vlan_list[vlan_idx], &is_set);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: could not check if vlan set [%u]\n", vlan_list[vlan_idx]);
            goto rollback;
        }
        if (is_set) { /* Sanity check if the vlan belong to system */
            SX_LOG_ERR("ACL: vlan [%u] is in system vlan group instead of user group\n", vlan_list[vlan_idx]);
            rc = SX_STATUS_ERROR;
            goto rollback;
        }

        /* in all the cases vlan in user group db - remove it*/
        rc = flex_acl_db_vlan_group_remove_from(vlan_group_id, swid, &vlan_list[vlan_idx], 1);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: could not update vlan group [%u] DB\n", vlan_group_id);
            goto rollback;
        }
        /* write register */
        vlan_add_params->vlan_group_id = vlan_group_id;
        vlan_add_params->cmd = SX_ACCESS_CMD_DELETE;
        vlan_add_params->swid = swid;
        vlan_add_params->vlan_list[0] = vlan_list[vlan_idx];
        vlan_add_params->vlan_num = 1;
        rc = flex_acl_hw_reg_write_vlan_group_add(vlan_add_params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: could not configure vlan group [%u] in HW\n", vlan_group_id);
            goto rollback;
        }
    }
    goto out;
rollback:
out:
    if (vlan_attribs_list) {
        CL_FREE_N_NULL(vlan_attribs_list);
    }
    if (vlan_add_params) {
        CL_FREE_N_NULL(vlan_add_params);
    }
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_system_acl_set_mc_register_callbacks(system_acl_client_id_e client_id,
                                                        system_acl_hw_cb_t    *system_acl_hw_cb_p,
                                                        boolean_t             *change_needed)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(system_acl_hw_cb_p, "system_acl_hw_cb_p")) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(change_needed, "change_needed")) {
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (client_id == SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E) {
        system_acl_hw_cb_p->move_rule_hw_cb = system_acl_mc_hw_move_rule_ipv4;
        system_acl_hw_cb_p->region_hw_cb = system_acl_mc_hw_write_region_ipv4;
        system_acl_hw_cb_p->rule_hw_cb = system_acl_mc_hw_write_rule_ipv4;
        system_acl_hw_cb_p->activity_read_hw_cb = system_acl_mc_hw_write_rule_ipv4;
        system_acl_hw_cb_p->activity_dump_hw_cb = system_acl_mc_hw_activity_dump_ipv4;
    } else if (client_id == SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E) {
        system_acl_hw_cb_p->move_rule_hw_cb = system_acl_mc_hw_move_rule_ipv6;
        system_acl_hw_cb_p->region_hw_cb = system_acl_mc_hw_write_region_ipv6;
        system_acl_hw_cb_p->rule_hw_cb = system_acl_mc_hw_write_rule_ipv6;
        system_acl_hw_cb_p->activity_read_hw_cb = system_acl_mc_hw_write_rule_ipv6;
        system_acl_hw_cb_p->activity_dump_hw_cb = system_acl_mc_hw_activity_dump_ipv6;
    } else {
        *change_needed = FALSE;
        goto out;
    }
    system_acl_hw_cb_p->acl_hw_cb = system_acl_mc_acl_write_hw_cb;
    /* Indicate that the callbacks were indeed changed for the mc. */
    *change_needed = TRUE;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_vlan_group_get(sx_acl_vlan_group_t group_id,
                                    sx_swid_id_t        swid,
                                    sx_vlan_id_t       *vlan_list,
                                    uint32_t           *vlan_num)
{
    /* This api is not exposed to the user in 802.1D mode */
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    port_num = 0;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /**** Check input parameters */
    if (flex_acl_db_swid_in_range(swid) == FALSE) {
        SX_LOG_ERR("ACL %s : swid has invalid value [%u] max_val:%d \n",
                   __FUNCTION__,
                   swid,
                   rm_resource_global.swid_id_max);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (*vlan_num > VLAN_NUMS_MAX) {
        *vlan_num = VLAN_NUMS_MAX;
    }

    /* Check SWID exist in DB */
    rc = port_swid_get(SX_ACCESS_CMD_GET, swid, NULL, &port_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: swid not found [%u]\n", swid);
        goto out;
    }

    rc = flex_acl_db_vlan_group_get(group_id, swid, vlan_list, vlan_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: failed get of vlan group [%u]\n", group_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_enable_system(boolean_t enable)
{
    UNUSED_PARAM(enable);
    return SX_STATUS_SUCCESS;
}

static acl_cb_t flex_acl_cbs = {
    .acl_enable_system = flex_acl_enable_system,
    .acl_vlan_group_set = flex_acl_vlan_group_set,
    .acl_vlan_group_get = flex_acl_vlan_group_get,
    .acl_region_set = flex_acl_redirect_region_set,
    .acl_region_get = flex_acl_redirect_region_get,
    .acl_set = flex_acl_redirect_acl_set,
    .acl_get = flex_acl_redirect_acl_get,
    .acl_iter_get = flex_acl_iter_get,
    .acl_group_set = flex_acl_group_set,
    .acl_group_get = flex_acl_group_get,
    .acl_group_iter_get = flex_acl_group_iter_get,
    .acl_rule_activity_get = flex_acl_rule_activity_get,
    .acl_rule_activity_dump = flex_acl_rule_activity_dump,
    .acl_rules_move = flex_acl_rules_move,
    .acl_bind_port = flex_acl_bind_port,
    .acl_bind_port_get = flex_acl_bind_port_get,
    .acl_unbind_port = flex_acl_unbind_port,
    .acl_bind_vlan_group = flex_acl_bind_vlan_group,
    .acl_bind_vlan_group_get = flex_acl_bind_vlan_group_get,
    .acl_unbind_vlan_group = flex_acl_unbind_vlan_group,
    .acl_l4_port_range_set = flex_acl_l4_port_range_set,
    .acl_l4_port_range_get = flex_acl_l4_port_range_get,
    .acl_l4_port_range_iter_get = flex_acl_l4_port_range_iter_get,
    .acl_pbs_set = flex_acl_pbs_set,
    .acl_pbs_get = flex_acl_pbs_get,
    .acl_pbs_iter_get = flex_acl_pbs_iter_get,
    .acl_range_set = flex_acl_range_set,
    .acl_range_get = flex_acl_range_get,
    .acl_pbilm_set = flex_acl_pbilm_set,
    .acl_pbilm_get = flex_acl_pbilm_get,
};
static sx_status_t __flex_acl_stage_get(acl_stage_e *acl_stage_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (NULL == acl_stage_p) {
        SX_LOG_ERR("NULL pointer has been got as input parameter.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    *acl_stage_p = ACL_STAGE_FLEX;

out:
    return rc;
}

static boolean_t __flex_acl_wc_rule_needed()
{
    return TRUE;
}

static boolean_t __flex_acl_default_action_needed()
{
    return FALSE;
}

static flex_acl_ops_t flex_acl_ops = {
    .acl_stage_get_p = __flex_acl_stage_get,
    .acl_wc_rule_needed_p = __flex_acl_wc_rule_needed,
    .acl_default_action_needed_p = __flex_acl_default_action_needed,
    .system_acl_set_mc_register_callbacks_p = __flex_system_acl_set_mc_register_callbacks,
};

sx_status_t flex_acl_set_ops(flex_acl_ops_t* ops_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (NULL == ops_p) {
        SX_LOG_ERR("NULL pointer has been got as input parameter.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    flex_acl_ops_g = ops_p;

out:
    return rc;
}

sx_status_t flex_acl_init_ops(void)
{
    return flex_acl_set_ops(&flex_acl_ops);
}

sx_status_t __initialize_rm_sdk_table(rm_sdk_table_type_e resource, uint32_t table_size_min, uint32_t table_size_max)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rm_resource_global.rm_sdk_tables_db[resource].is_initialized = TRUE;
    rm_resource_global.rm_sdk_tables_db[resource].table_size_min = table_size_min;
    rm_resource_global.rm_sdk_tables_db[resource].table_size_max = table_size_max;
    rc = rm_sdk_table_init_resource(resource);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init RM for %s\n", SX_RESOURCE_MSG(resource));
    }
    return rc;
}

sx_status_t flex_acl_init_with_callbacks(sx_api_sx_sdk_init_t *init_params, acl_cb_t *acl_cbs_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_status_t                      rb_rc = SX_STATUS_SUCCESS;
    flex_acl_attributes_t            attribs;
    uint32_t                         i = 0;
    uint32_t                         rm_acl_groups = 0;
    uint32_t                         rm_max_rules = 0;
    uint32_t                         init_max_rules = 0;
    kvd_linear_manager_user_params_t kvd_params;
    sx_api_acl_region_set_params_t   reserved_region_params = {0, 0, 0, 0, 0};
    acl_stage_e                      acl_stage = ACL_STAGE_UNKNOWN;
    sx_boot_mode_e                   issu_boot_mode;
    uint32_t                         acl_groups_max = 0;

    KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_ITERATORS;

    SX_LOG_ENTER();

    memset(&kvd_params, 0, sizeof(kvd_params));

    if (TRUE == g_flex_acl_initialized) {
        rc = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    if (NULL == acl_cbs_p) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "Received acl_cbs_p NULL pointer.\n");
        goto out;
    }

    acl_set_cb(acl_cbs_p);
    rc = brg_context.spec_cb_g.flex_acl_init_ops();
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in acl_init_ops.\n");
        goto error;
    }

    if (flex_acl_ops_g->acl_stage_get_p(&acl_stage) != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get flex acl stage.\n");
        rc = SX_STATUS_ERROR;
        goto error;
    }
    g_acl_stage = acl_stage;

    DBG_DUMP_MODULES_REGISTER(rc, FLEX_ACL, FLEX_ACL, flex_acl, FALSE, FALSE, FALSE);
    DBG_DUMP_MODULES_REGISTER(rc, FLEX_ACL, FLEX_ACL_MAIN, flex_acl_main, FALSE, FALSE, FALSE);
    DBG_DUMP_MODULES_REGISTER(rc, FLEX_ACL, FLEX_ACL_DB, flex_acl_db, FALSE, FALSE, FALSE);
    DBG_DUMP_MODULES_REGISTER(rc, FLEX_ACL, FLEX_ACL_RBB, flex_acl_rbb, FALSE, FALSE, FALSE);
    DBG_DUMP_MODULES_REGISTER(rc, FLEX_ACL, FLEX_ACL_HW_DB, flex_acl_hw_db, FALSE, FALSE, FALSE);
    DBG_DUMP_MODULES_REGISTER(rc, FLEX_ACL, FLEX_ACL_SYSTEM, flex_acl_system, FALSE, FALSE, FALSE);

    rc = issu_boot_mode_get(&issu_boot_mode);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" failed to issu_boot_mode_get sx_status = %s\n",
                   sx_status_str(rc));
        goto out;
    }

    init_max_rules =
        init_params->acl_params.max_acl_rules ? init_params->acl_params.max_acl_rules : UNLIMITED_SDK_TABLE_SIZE;

    if (issu_boot_mode != SX_BOOT_MODE_DISABLED_E) {
        acl_groups_max = rm_resource_global.acl_groups_num_max / 2;
    } else {
        acl_groups_max = rm_resource_global.acl_groups_num_max;
    }
    /* Validate Init params */
    if ((init_params->acl_params.max_acl_ingress_groups + init_params->acl_params.max_acl_egress_groups)
        > acl_groups_max) {
        SX_LOG_ERR("Failed in acl_init - max_acl_groups [%u] > SXD_MAX_ACL_GROUPS [%u]\n",
                   init_params->acl_params.max_acl_ingress_groups + init_params->acl_params.max_acl_egress_groups,
                   acl_groups_max);
        rc = SX_STATUS_PARAM_ERROR;
        goto error;
    }

    if (init_params->acl_params.acl_search_type >= SX_API_ACL_SEARCH_TYPE_LAST) {
        SX_LOG_ERR("Failed in acl_init - Search type is invalid\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto error;
    }

    rm_max_rules = rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ACL_RULES_E].table_size_max;
    if ((rm_max_rules != UNLIMITED_SDK_TABLE_SIZE) && (init_max_rules > rm_max_rules)) {
        SX_LOG(SX_LOG_ERROR, "MAX ACL rules [%u] higher then maximum allowed rules [%u].\n",
               init_params->acl_params.max_acl_rules, rm_max_rules);
        rc = SX_STATUS_PARAM_ERROR;
        goto error;
    }

    if ((init_params->acl_params.min_acl_rules > init_max_rules) && (init_max_rules != UNLIMITED_SDK_TABLE_SIZE)) {
        SX_LOG(SX_LOG_ERROR, "MIN ACL rules [%u] higher than MAX ACL rules [%u].\n",
               init_params->acl_params.min_acl_rules, init_params->acl_params.max_acl_rules);
        rc = SX_STATUS_PARAM_ERROR;
        goto error;
    }
    if (rm_resource_global.acl_regions_max <= FLEX_ACL_NUM_OF_RESERVED_REGIONS) {
        SX_LOG_ERR("Max number of acl regions are less than needed number of reserved groups\n");
        rc = SX_STATUS_ERROR;
        goto error;
    }
    if (!RM_SWID_CHECK_RANGE(init_params->acl_params.max_swid_id)) {
        SX_LOG_ERR("Init parameter's max swid id is exceeds range. Init param max swid=%d, global max swid=%d \n",
                   init_params->acl_params.max_swid_id, rm_resource_global.swid_id_max);
        rc = SX_STATUS_ERROR;
        goto error;
    }
    if (init_params->acl_params.max_vlan_groups == 0) {
        init_params->acl_params.max_vlan_groups = rm_resource_global.acl_vlan_groups_max;
    }

    if (init_params->acl_params.max_vlan_groups > rm_resource_global.acl_vlan_groups_max) {
        SX_LOG_ERR(
            "Init parameter's max_vlan_groups exceeds range. Init param max_vlan_groups=%d, global max max_vlan_groups=%d \n",
            init_params->acl_params.max_vlan_groups,
            rm_resource_global.acl_vlan_groups_max);
        rc = SX_STATUS_ERROR;
        goto error;
    }

    rc = flex_acl_tcam_manager_init();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to initialize flex-ACL TCAM manager, err = [%s]\n",
                   sx_status_str(rc));
        goto error;
    }

    /* Data base initialization */
    memset(&attribs, 0, sizeof(attribs));
    attribs.num_of_acl_ingress_groups = init_params->acl_params.max_acl_ingress_groups; /*backward comp */
    attribs.num_of_acl_egress_groups = init_params->acl_params.max_acl_egress_groups;   /*backward comp */
    attribs.num_of_acl_regions = rm_resource_global.acl_regions_max;
    attribs.num_of_devices = init_params->port_params.max_dev_id + 1;
    attribs.num_of_swid_ids = init_params->acl_params.max_swid_id + 1;
    attribs.num_of_vlan_groups = init_params->acl_params.max_vlan_groups;
    /* Choose the minimum possible, either maximum regions or maximum tables. */
    attribs.num_of_acl = MIN(rm_resource_global.acl_regions_max, rm_resource_global.acl_tables_max);
    attribs.acl_search_type = (sx_flex_acl_search_type_t)(init_params->acl_params.acl_search_type);
    attribs.min_acl_rules = init_params->acl_params.min_acl_rules;
    attribs.max_acl_rules = init_max_rules;
    attribs.num_of_rif = rm_resource_global.router_rifs_max;
    attribs.max_group_size = rm_resource_global.acl_groups_size_max;
    attribs.num_of_key_tables = rm_resource_global.acl_regions_max;
    attribs.num_of_bind_attribs = rm_resource_global.acl_groups_num_max;
    attribs.num_of_logic_groups = rm_resource_global.acl_groups_num_max;

    attribs.free_action_set_cb = flex_acl_hw_free_action_sets;
    attribs.free_pbs_cb = flex_acl_hw_del_pbs;
    attribs.free_pbilm_cb = flex_acl_hw_del_pbilm;
    attribs.tcam_opt_params = init_params->tcam_opt_params;
    attribs.rebind_group_cb.bind_group_cb = __flex_acl_bind_group_on_goto_action_cb;
    attribs.rebind_group_cb.unbind_group_cb = __flex_acl_unbind_group_on_goto_action_cb;
    attribs.acl_stage = acl_stage;

    /* For Spectrum2 and above we only use dynamic CTCAM.
     * Other modes are not exposed to the user.
     */
    if (ACL_STAGE_IS_FLEX2_OR_ABOVE(acl_stage)) {
        if (attribs.tcam_opt_params.tcam_opt_mode != SX_TCAM_OPT_MODE_DYNAMIC) {
            attribs.tcam_opt_params.tcam_opt_mode = SX_TCAM_OPT_MODE_DYNAMIC;
            attribs.tcam_opt_params.tcam_opt_mode_param = SX_TCAM_OPT_MODE_PARAM_NONE;
            SX_LOG_NTC("This chip only supports dynamic CTCAM allocation.\n");
        }
    }

    rc = flex_acl_db_init(&attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init acl db, error: %s \n", sx_status_str(rc));
        goto error;
    }
    g_init_flags.db_inited = TRUE;

    rc = flex_acl_hw_init(&attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init acl hw, error: %s \n", sx_status_str(rc));
        goto rollback_db_init;
    }
    g_init_flags.hw_init_done = TRUE;

    /* acl_stage indicates for which ACL type ,
     *  key block map should be initialized */
    rc = flex_acl_key_block_map_init(acl_stage);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed key map init.\n");
        goto rollback_hw_init;
    }

    g_init_flags.basic_keys_inited = TRUE;

    /* Initialize the rule based binding module */
    if (ACL_STAGE_IS_FLEX2_OR_ABOVE(acl_stage)) {
        rc = flex_acl_rule_based_binding_init();
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL : Failed rule based binding init.\n");
            goto rollback_hw_init;
        }
        g_init_flags.rule_based_biniding_inited = TRUE;
    }

    /* Init Custom Bytes sets configuration array */
    custom_bytes_set_data = (acl_custom_bytes_set_data_t*)cl_malloc(
        sizeof(acl_custom_bytes_set_data_t) * rm_resource_global.acl_custom_bytes_set_max);
    if (custom_bytes_set_data == NULL) {
        SX_LOG_ERR("ACL : Failed to allocate memory for custom byte sets data.\n");
        goto rollback_rule_based_binding;
    }

    for (i = 0; i < rm_resource_global.acl_custom_bytes_set_max; i++) {
        custom_bytes_set_data[i].start_key_id = FLEX_ACL_KEY_CUSTOM_BYTES_START + i *
                                                rm_resource_global.acl_custom_bytes_set_size_max;
        custom_bytes_set_data[i].size = rm_resource_global.acl_custom_bytes_set_size_max;
    }

    reserved_region_params.region_size = FLEX_ACL_RULES_MIN;
    reserved_region_params.key_type = SX_ACL_KEY_TYPE_RESERVED;

    if (init_params->acl_params.min_acl_rules != 0) { /* no need in reserved region */
        rc = __flex_acl_create_reserved_region(&reserved_region_params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to allocate acl reserved region\n");
            goto rollback_custom_bytes_set_data_allocated;
        }
    }
    /* Init RM rules management (regions) :Handling RM Rules */
    /* The RM_SDK_TABLE_TYPE_ACL_RULES_E is the parent RM for all ATCAM and CTCAM resource managers */
    rm_sdk_set_acl_enforce_min_table_size_func(__flex_acl_enforce_min_table_size);
    rm_sdk_set_acl_get_tcam_opts_func(flex_acl_get_hw_opt);
    rm_sdk_set_acl_get_rm_attrs_func(flex_acl_get_rm_attrs);
    rc =
        __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_ACL_RULES_E, init_params->acl_params.min_acl_rules,
                                  init_max_rules);
    if (SX_CHECK_FAIL(rc)) {
        goto rollback_create_reserved_region;
    }

    /* The RM_SDK_TABLE_TYPE_ACL_RULES_*_KEY_BLOCK_E are used to RM the CTCAM rules for Spectrum1.
     * For Spectrum2 and above it's used for rules' accounting only.
     */
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E].is_initialized = TRUE;
    rc = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E);
    if (SX_CHECK_FAIL(rc)) {
        goto rollback_create_reserved_region;
    }
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E].is_initialized = TRUE;
    rc = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E);
    if (SX_CHECK_FAIL(rc)) {
        goto rollback_create_reserved_region;
    }
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E].is_initialized = TRUE;
    rc = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E);
    if (SX_CHECK_FAIL(rc)) {
        goto rollback_create_reserved_region;
    }

    g_init_flags.rm_rules_inited = TRUE;

    /*in RM ACL regions management */
    rc = __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_ACL_E,
                                   FLEX_ACL_NUM_OF_RESERVED_REGIONS,
                                   rm_resource_global.acl_regions_max);
    if (SX_CHECK_FAIL(rc)) {
        goto rollback_init_rules_resource;
    }
    g_init_flags.rm_regions_inited = TRUE;

    /* init RM groups management */
    rc = flex_acl_db_get_max_acl_groups(&rm_acl_groups, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get maximum acl groups from DB\n");
        goto rollback_init_regions_resource;
    }

    rc = __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, 0, rm_acl_groups);
    if (SX_CHECK_FAIL(rc)) {
        goto rollback_init_regions_resource;
    }

    rc = rm_allocate_entries_check(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_ADD, rm_acl_groups, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set acl groups to rm\n");
        goto rollback_init_group_resource;
    }
    rc = rm_allocate_entries_update(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_ADD, rm_acl_groups,  NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set acl groups to rm\n");
        goto rollback_init_group_resource;
    }
    g_init_flags.rm_groups_inited = TRUE;

    /* init RM ACLs in groups */
    rc = __initialize_rm_sdk_table(RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E, 0, rm_resource_global.acl_acls_in_groups_max);
    if (SX_CHECK_FAIL(rc)) {
        goto rollback_rm_groups_update;
    }
    g_init_flags.rm_acls_in_groups_inited = TRUE;

    /* KVD linear registration. */
    memset(&kvd_params, 0, sizeof(kvd_params));

    if (acl_stage == ACL_STAGE_FLEX) {
        kvd_params.block_type = LINEAR_MANAGER_LINK_LIST_BLOCK_TYPE_E;
    } else {
        /* For flex2 we need continuous space for default action and activity dumping */
        kvd_params.block_type = LINEAR_MANAGER_CONTIGUOUS_BLOCK_TYPE_E;
    }
    kvd_params.block_relocate = flex_acl_hw_kvd_block_reloc;
    KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_INIT(kvd_params);

    rc = kvd_linear_manager_init_user(KVD_LINEAR_MANAGER_USER_ACL_RULES_E, kvd_params);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init KVD linear.\n");
        goto rollback_rm_acls_in_groups_update;
    }
    g_init_flags.kvd_rules_inited = TRUE;

    kvd_params.alloc_sizes[0] = 1; /* [SPC] Mandatory for Bin Allocator with block type linked list (allocates by size 1) */
    kvd_params.alloc_sizes[1] = DEFAULT_ACTIONS_MAX_BLOCK_SIZE;
    kvd_params.alloc_sizes_array_size = 2;
    rc = kvd_linear_manager_init_user(KVD_LINEAR_MANAGER_USER_ACL_DEFAULT_ACTIONS_E, kvd_params);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init KVD linear user: ACL default actions.\n");
        goto rollback_kvd_init_rules_resource;
    }
    g_init_flags.kvd_default_actions_inited = TRUE;

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E].is_initialized = TRUE;
    rc = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init RM Table with ACL extended actions resource\n");
        goto rollback_kvd_init_default_actions_resource;
    }
    g_init_flags.rm_extended_actions_inited = TRUE;

    kvd_params.block_type = LINEAR_MANAGER_LINK_LIST_BLOCK_TYPE_E;
    kvd_params.block_relocate = flex_acl_hw_kvd_pbs_block_reloc;
    KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_INIT(kvd_params);

    rc = kvd_linear_manager_init_user(KVD_LINEAR_MANAGER_USER_PBS_E, kvd_params);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init PBS KVD linear.\n");
        goto rollback_init_extended_actions_resource;
    }
    g_init_flags.kvd_pbs_inited = TRUE;

    /* init PBS entry*/
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_ACL_PBS_E].is_initialized = TRUE;
    rc = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_ACL_PBS_E);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init RM Table with ACL PBS resource\n");
        goto rollback_kvd_init_pbs_resource;
    }
    g_init_flags.pbs_inited = TRUE;

    /* PBILM Initialization */
    memset(&kvd_params, 0, sizeof(kvd_params));

    kvd_params.block_type = LINEAR_MANAGER_LINK_LIST_BLOCK_TYPE_E;
    kvd_params.block_relocate = flex_acl_hw_kvd_pbilm_block_reloc;
    KVD_LINEAR_MANAGER_WITH_ONE_BIG_BLOCK_INIT(kvd_params);

    rc = kvd_linear_manager_init_user(KVD_LINEAR_MANAGER_USER_PBILM_E, kvd_params);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init PBILM KVD linear.\n");
        goto rollback_init_pbs_entry_resource;
    }
    g_init_flags.kvd_pbilm_inited = TRUE;

    /* init PBILM entry*/
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E].is_initialized = TRUE;
    rc = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init RM Table with ACL PBILM resource\n");
        goto rollback_kvd_init_pbilm_resource;
    }
    g_init_flags.pbilm_inited = TRUE;

    rc = cm_user_init(flex_acl_hw_cm_relocate, NULL, NULL, &acl_cm_handle);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init CM.\n");
        goto rollback_init_pbilm_entry_resource;
    }
    g_init_flags.cm_user_inited = TRUE;

    rc = policer_manager_user_init(flex_acl_hw_policer_block_relocate, &acl_policer_manager_handle);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init Policer.\n");
        goto rollback_cm_user_init;
    }
    g_init_flags.policer_manager_user_inited = TRUE;

    rc = span_user_init(flex_acl_hw_span_relocate, &acl_span_handle);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init Policer.\n");
        goto rollback_policer_manager_user_init;
    }
    g_init_flags.span_user_inited = TRUE;

    rc =
        adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E, __flex_acl_device_ready_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in adviser register - advise DEVICE_READY , error: %s \n", sx_status_str(rc));
        goto rollback_span_user_init;
    }
    g_init_flags.adviser_regisered_dev_ready = TRUE;


    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_PRE_PORT_DEL_FROM_SWID_E,
                                __flex_acl_pre_port_del_from_swid_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in adviser register - advise DEL_PORT_FROM_SWID , error: %s \n", sx_status_str(rc));
        goto rollback_register_device_ready;
    }
    g_init_flags.adviser_registered_pre_port_del = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_PORT_DEL_FROM_SWID_E,
                                __flex_acl_port_handle_swid_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in adviser register - advise DEL_PORT_FROM_SWID , error: %s \n", sx_status_str(rc));
        goto rollback_register_pre_port_delete;
    }
    g_init_flags.adviser_registered_port_del = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E,
                                __flex_acl_port_handle_swid_callback);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in adviser register - POST_PORT_ADD_INTO_SWID advise  , error: %s \n", sx_status_str(rc));
        goto rollback_register_port_delete;
    }
    g_init_flags.adviser_registered_port_add = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_RIF_ADD_E,
                                __flex_acl_rif_create_adviser_cb);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up rif create adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_register_port_add;
    }
    g_init_flags.rif_create_adviser_set_done = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_PRE_RIF_DEL_E,
                                __flex_acl_rif_destroy_adviser_cb);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up rif destroy adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_adviser_post_rif_add;
    }
    g_init_flags.rif_destroy_adviser_set_done = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_MC_CONTAINER_ERIF_POINTER_CHANGE_E,
                                flex_acl_hw_mc_container_change);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up MC container pointer change adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_register_pre_rif_delete;
    }
    g_init_flags.mc_container_erif_pointer_change_adviser_set_done = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_PRE_VPORT_BRIDGE_DELETE_E,
                                __flex_acl_vport_bridge_delete_cb);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up vport bridge delete adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_register_post_mc_container_erif_pointer_change;
    }
    g_init_flags.vport_bridge_delete_pre_adviser_set_done = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_TUNNEL_DECAP_CHANGE_E,
                                flex_acl_hw_mc_tunnel_decap_change);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up tunnel decap adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_register_vport_bridge_delete;
    }
    g_init_flags.tunnel_decap_change_adviser_set_done = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_MC_CONTAINER_PORT_MC_POINTER_CHANGE_E,
                                __flex_acl_mc_container_ptr_changed);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up MC container port pointer change adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_tunnel_decap_change;
    }
    g_init_flags.mc_container_port_mc_pointer_change_adviser_set_done = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_MC_CONTAINER_NVE_MC_POINTER_CHANGE_E,
                                __flex_acl_mc_container_ptr_changed);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up MC container NVE pointer change adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_register_post_mc_container_port_mc_pointer_change;
    }
    g_init_flags.mc_container_nve_mc_pointer_change_adviser_set_done = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_ECMP_UPDATE_E,
                                __flex_acl_ecmp_update_ptr_changed);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up ECMP pointer change adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_register_post_ecmp_update_pointer_change;
    }
    g_init_flags.ecmp_update_pointer_change_adviser_set_done = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_IPV6_CHANGE_E,
                                __flex_acl_ipv6_reloc_changed);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up IPv6 relocation change adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_register_ipv6_reloc_changed;
    }
    g_init_flags.ipv6_reloc_changed_set_done = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_FDB_MC_MID_CHANGE_E,
                                __flex_acl_fdb_mc_mid_changed);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up fdb mc mid change adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_register_post_mc_container_nve_mc_pointer_change;
    }
    g_init_flags.fdb_mc_mid_change_adviser_set_done = TRUE;

    rc = lag_sink_global_advise(__flex_acl_lag_global_update, NULL, 0);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in lag_sink_global_advise, error: %s \n", sx_status_str(rc));
        goto rollback_fdb_mc_mid_change;
    }

    g_init_flags.lag_sinc_advised = TRUE;

    rc = adviser_register_event(SX_ACCESS_CMD_ADD,
                                ADVISER_EVENT_POST_MC_CONTAINER_NEXT_HOPS_CHANGE_E,
                                __flex_acl_mc_container_port_next_hops_change_cb);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up port filter MC container adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_global_advise;
    }
    g_init_flags.mc_container_next_hops_change_adviser_set_done = TRUE;

    rc = hwd_mpls_ftn_update_adviser_set(SX_ACCESS_CMD_ADD, flex_acl_hw_ftn_change);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up ftn adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_register_port_filter_mc_conatiner_change;
    }
    g_init_flags.ftn_adviser_set_done = TRUE;

    rc = hwd_continue_lookup_update_adviser_set(SX_ACCESS_CMD_ADD, flex_acl_hw_continue_lookup_change);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up continue lookup adviser, rc = %s\n", sx_status_str(rc));
        goto rollback_ftn_adviser;
    }
    g_init_flags.continue_lookup_adviser_set_done = TRUE;

    rc =
        adviser_register_event(SX_ACCESS_CMD_ADD,
                               ADVISER_EVENT_POST_TRAP_ID_PRIO_CHANGE_E,
                               flex_acl_hw_trap_id_prio_change);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in register adviser POST_TRAP_ID_PRIO_CHANGE, error: %s \n", sx_status_str(rc));
        goto rollback_continue_lookup_adviser;
    }
    g_init_flags.trap_id_prio_change_adviser_set_done = TRUE;

    g_flex_acl_initialized = TRUE;

    rc = flex_acl_db_init_redirection_db(FLEX_ACL_MIN_LIST_ITEMS_REDIRECTION_DB);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed at init redirection db\n");
        goto rollback_trap_id_prio_change_adviser;
    }
    g_init_flags.redirection_db_inited = TRUE;

    if (flex_acl_ops_g->acl_default_action_needed_p()) {
        rc = flex_acl_hw_init_default_actions();
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to init default actions\n");
            goto rollback_redirection_db;
        }
        /* For issu we need to write all potential regions' default action on initialization.
         * This is to prevent a situation when issu is executed and new region still have
         * their default action pointed in the previous issu default action location.
         */
        if ((issu_boot_mode != SX_BOOT_MODE_DISABLED_E) && (g_default_action_issu_support == FALSE)) {
            /* Write the default actions for all the regions */
            rc = flex_acl_write_default_action(FLEX_ACL_INVALID_REGION_ID, TRUE);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to init default actions for all regions for flex acl init\n");
                goto rollback_redirection_db;
            }
        }
    }

    /* Init commit ACLs - Have to be the last section in init. Relevant for Spectrum1 only */
    if ((init_params->acl_params.acl_search_type == SX_API_ACL_SEARCH_TYPE_PARALLEL) &&
        (acl_stage == ACL_STAGE_FLEX)) {
        rc = __flex_acl_init_commit_acls();
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to init commit acls\n");
            goto rollback_default_action_init;
        }
    }
    rc = flex_acl_db_goto_validation_init(&flex_acl_goto_validation_params,  rm_acl_groups);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init group list vector\n");
        goto deinit_commit_acls;
    }

    /* Update resource manager about with new set values */
    rm_resource_global.acl_ingress_groups_max = init_params->acl_params.max_acl_ingress_groups;
    rm_resource_global.acl_engress_groups_max = init_params->acl_params.max_acl_egress_groups;
    rm_resource_global.acl_tables_max = attribs.num_of_acl;
    rm_resource_global.acl_vlan_groups_max = init_params->acl_params.max_vlan_groups;

    /* Save state of whether to Trap and monitor System Acl packet Drops */
    if (init_params->acl_params.sys_acl_drop_trap_enable) {
        g_init_flags.sys_acl_drop_trap_enabled = TRUE;
    }

    if (init_params->acl_params.use_soft_drop_for_empty_container) {
        g_init_flags.use_soft_drop_for_empty_container = TRUE;
    }

    /* Init ACL manual unbind flag */
    g_flex_acl_manual_unbind = init_params->acl_params.acl_manual_unbind;
    SX_LOG_INF("ACL manual unbind is set to %s\n", g_flex_acl_manual_unbind ? "TRUE" : "FALSE");

    goto out;
deinit_commit_acls:
    if ((init_params->acl_params.acl_search_type == SX_API_ACL_SEARCH_TYPE_PARALLEL) &&
        (acl_stage == ACL_STAGE_FLEX)) {
        if (SX_CHECK_FAIL(rb_rc = __flex_acl_deinit_commit_acls())) {
            SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
        }
    }
rollback_default_action_init:
    if (flex_acl_ops_g->acl_default_action_needed_p()) {
        flex_acl_hw_deinit_default_actions();
    }
rollback_redirection_db:
    flex_acl_deinit_redirection_db();
rollback_continue_lookup_adviser:
    if (SX_CHECK_FAIL(rb_rc =
                          hwd_continue_lookup_update_adviser_set(SX_ACCESS_CMD_DELETE,
                                                                 flex_acl_hw_continue_lookup_change))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }
rollback_trap_id_prio_change_adviser:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_POST_TRAP_ID_PRIO_CHANGE_E,
                                                     flex_acl_hw_trap_id_prio_change))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }
rollback_ftn_adviser:
    if (SX_CHECK_FAIL(rb_rc = hwd_mpls_ftn_update_adviser_set(SX_ACCESS_CMD_DELETE, flex_acl_hw_ftn_change))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }
rollback_register_port_filter_mc_conatiner_change:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_POST_MC_CONTAINER_NEXT_HOPS_CHANGE_E,
                                                     __flex_acl_mc_container_port_next_hops_change_cb))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }
rollback_global_advise:
    if (SX_CHECK_FAIL(rb_rc = lag_sink_global_unadvise(__flex_acl_lag_global_update))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }

rollback_fdb_mc_mid_change:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_POST_FDB_MC_MID_CHANGE_E,
                                                     __flex_acl_fdb_mc_mid_changed))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }

rollback_register_post_mc_container_port_mc_pointer_change:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_POST_MC_CONTAINER_PORT_MC_POINTER_CHANGE_E,
                                                     __flex_acl_mc_container_ptr_changed))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }

rollback_register_post_mc_container_nve_mc_pointer_change:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_POST_MC_CONTAINER_NVE_MC_POINTER_CHANGE_E,
                                                     __flex_acl_mc_container_ptr_changed))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }

rollback_register_post_ecmp_update_pointer_change:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_POST_ECMP_UPDATE_E,
                                                     __flex_acl_ecmp_update_ptr_changed))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }

rollback_register_ipv6_reloc_changed:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_POST_IPV6_CHANGE_E,
                                                     __flex_acl_ipv6_reloc_changed))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }


rollback_tunnel_decap_change:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_POST_TUNNEL_DECAP_CHANGE_E,
                                                     flex_acl_hw_mc_tunnel_decap_change))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }

rollback_register_vport_bridge_delete:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_PRE_VPORT_BRIDGE_DELETE_E,
                                                     __flex_acl_vport_bridge_delete_cb))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }
rollback_register_post_mc_container_erif_pointer_change:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_POST_MC_CONTAINER_ERIF_POINTER_CHANGE_E,
                                                     flex_acl_hw_mc_container_change))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }
rollback_register_pre_rif_delete:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_PRE_RIF_DEL_E,
                                                     __flex_acl_rif_destroy_adviser_cb))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }
rollback_adviser_post_rif_add:
    if (SX_CHECK_FAIL(rb_rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                                     ADVISER_EVENT_POST_RIF_ADD_E,
                                                     __flex_acl_rif_create_adviser_cb))) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_rc));
    }
rollback_register_port_add:
    if (SX_CHECK_FAIL(rb_rc =
                          adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E,
                                                 __flex_acl_port_handle_swid_callback))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_register_port_delete:
    if (SX_CHECK_FAIL(rb_rc =
                          adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_PORT_DEL_FROM_SWID_E,
                                                 __flex_acl_port_handle_swid_callback))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_register_pre_port_delete:
    if (SX_CHECK_FAIL(rb_rc =
                          adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PRE_PORT_DEL_FROM_SWID_E,
                                                 __flex_acl_pre_port_del_from_swid_callback))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_register_device_ready:
    if (SX_CHECK_FAIL(rb_rc =
                          adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_DEVICE_READY_E,
                                                 __flex_acl_device_ready_callback))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_span_user_init:
    if (SX_CHECK_FAIL(rb_rc = span_user_deinit(acl_span_handle))) {
        SX_LOG_ERR("Fatal error at span_user_deinit rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_policer_manager_user_init:
    if (SX_CHECK_FAIL(rb_rc = policer_manager_user_deinit(acl_policer_manager_handle))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_cm_user_init:
    if (SX_CHECK_FAIL(rb_rc = cm_user_deinit(acl_cm_handle))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_init_pbilm_entry_resource:
    if (SX_CHECK_FAIL(rb_rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E, TRUE))) {
        SX_LOG_ERR("Fatal error at PBILM resource rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_kvd_init_pbilm_resource:
    if (SX_CHECK_FAIL(rb_rc = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_PBILM_E))) {
        SX_LOG_ERR("Fatal error at PBILM KVDL rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_init_pbs_entry_resource:
    if (SX_CHECK_FAIL(rb_rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_PBS_E, TRUE))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_kvd_init_pbs_resource:
    if (SX_CHECK_FAIL(rb_rc = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_PBS_E))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_init_extended_actions_resource:
    if (SX_CHECK_FAIL(rb_rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E, TRUE))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_kvd_init_default_actions_resource:
    if (SX_CHECK_FAIL(rb_rc = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_ACL_DEFAULT_ACTIONS_E))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_kvd_init_rules_resource:
    if (SX_CHECK_FAIL(rb_rc = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_ACL_RULES_E))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_rm_acls_in_groups_update:
    if (SX_CHECK_FAIL(rb_rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E, TRUE))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_rm_groups_update:
    if (SX_CHECK_FAIL(rb_rc =
                          rm_allocate_entries_check(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_DELETE,
                                                    rm_acl_groups, NULL))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
    if (SX_CHECK_FAIL(rb_rc =
                          rm_allocate_entries_update(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_DELETE,
                                                     rm_acl_groups,  NULL))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_init_group_resource:
    if (SX_CHECK_FAIL(rb_rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, TRUE))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }

rollback_init_regions_resource:
    if (SX_CHECK_FAIL(rb_rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_E, TRUE))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_init_rules_resource:
    rm_sdk_set_acl_enforce_min_table_size_func(NULL);
    if (SX_CHECK_FAIL(rb_rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E, TRUE))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
    if (SX_CHECK_FAIL(rb_rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E, TRUE))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
    if (SX_CHECK_FAIL(rb_rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E, TRUE))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
    if (SX_CHECK_FAIL(rb_rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_RULES_E, TRUE))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_create_reserved_region:
    if (init_params->acl_params.min_acl_rules != 0) {
        if (SX_CHECK_FAIL(rb_rc =
                              flex_acl_db_region_destroy(reserved_region_params.region_id,
                                                         &reserved_region_params.region_size))) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
    }
rollback_custom_bytes_set_data_allocated:
    if (NULL != custom_bytes_set_data) {
        CL_FREE_N_NULL(custom_bytes_set_data);
    }
rollback_rule_based_binding:
    if (ACL_STAGE_IS_FLEX2_OR_ABOVE(acl_stage)) {
        if (SX_CHECK_FAIL(rb_rc = flex_acl_rule_based_binding_deinit())) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
    }
rollback_hw_init:
    if (SX_CHECK_FAIL(rb_rc = flex_acl_hw_db_deinit())) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_db_init:
    flex_acl_db_deinit();
error:
    g_flex_acl_initialized = FALSE;
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_init(sx_api_sx_sdk_init_t *init_params)
{
    return flex_acl_init_with_callbacks(init_params, &flex_acl_cbs);
}

sx_status_t __flex_acl_deinit_rules_resources(void)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_acl_region_id_t               region_id;
    sx_acl_rule_offset_t            *offset_list = NULL;
    uint32_t                         list_size, i;
    flex_acl_db_flex_rule_t         *rule = NULL, help_rule;
    flex_acl_db_acl_region_t        *region;
    uint32_t                         old_valid_rules_num = 0;
    system_acl_client_table_entry_t *client_table_entry = NULL;
    system_acl_client_id_e           client_id = SYSTEM_ACL_CLIENT_ID_INVALID_E;

    SX_LOG_DBG("FLOWD review the ACL region in order to clean up the rules resources.\n");
    for (region_id = flex_acl_db_get_next_region(FLEX_ACL_INVALID_REGION_ID);
         region_id != FLEX_ACL_INVALID_REGION_ID; region_id = flex_acl_db_get_next_region(region_id)) {
        SX_LOG_DBG("FLOWD Reviewing region #:%u \n", region_id);
        rc = flex_acl_db_get_valid_rules_offset_list(region_id, &offset_list, &list_size);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Region #%u failed flex_acl_db_get_valid_rules_offset_list.\n", region_id);
        }
        SX_LOG_DBG("region_id %u, offset list ptr %p\n", region_id, offset_list);

        rc = flex_acl_db_region_get(region_id, &region);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL : Failed to get region, region id [%u]\n", region_id);
            continue;
        }
        old_valid_rules_num = region->valid_rules_num;

        SX_LOG_DBG("FLOWD Region #%u has %d valid rules.\n", region_id, list_size);

        for (i = 0; i < list_size; i++) {
            SX_LOG_DBG("FLOWD Deinit rule offset:%d in region\n", offset_list[i]);
            rc = flex_acl_db_get_rule_by_offset(region_id, offset_list[i], &rule);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL : Failed to get rule from db for offset [%u]\n", offset_list[i]);
            }
            memcpy(&help_rule, rule, sizeof(help_rule));
            help_rule.valid = FLEX_ACL_RULE_INVALID;
            rc = __flex_acl_update_rules_to_devs(region, &help_rule, 1, FLEX_ACL_HW_FULL_WRITE);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL : Failed to delete rule from dev\n");
            }

            rc = __flex_acl_rules_keys_ref_update(rule, FALSE, region_id);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL:  failed to delete ref count for keys. region_id:%d offset :%d\n",
                           rule->region_id,
                           rule->offset);
            }
            rc = __flex_acl_dec_actions_ref(rule, region_id);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL : Failed to decrease ref count, region_id: %u\n", region_id);
            }
        }
        if (offset_list != NULL) {
            rc = flex_acl_db_invalidate_rules(region_id, offset_list, list_size);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to invalidate rules in region ID [%u]\n", region_id);
            }

            rc = flex_acl_rm_entries_set(region->valid_rules_num, old_valid_rules_num,
                                         region);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to invalidate rules in region ID [%u]\n", region_id);
            }
        }

        if (region->entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
            rc = system_acl_client_get(region->region_id, &client_table_entry);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL:filed to get client size [%u]\n", region->size);
            }
            if (client_table_entry != NULL) {
                client_id = client_table_entry->client_id;
            }
        }

        rc = __flex_acl_update_rm(0, region->size, client_id, region->key_handle);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR_RESOURCE_COND(rc, "ACL:failed to update rm [%u]\n", region->size);
        }

        if (region->size > 0) {
            rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_E, SX_ACCESS_CMD_DELETE, 1, NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR_RESOURCE_COND(rc, "ACL: Failed to delete region from RM rc = %d\n", rc);
            }
        }

        if (offset_list) {
            flex_acl_db_free_offset_list(offset_list);
            offset_list = NULL;
        }
    }

    return rc;
}

void flex_acl_deinit(void)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    rm_acl_groups = 0;
    uint32_t    rm_valid_rules = 0;
    uint32_t    used_groups = 0;

    SX_LOG_ENTER();

    flex_acl_goto_validation_denit(&flex_acl_goto_validation_params);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deinit goto validation params\n");
    }

    if (g_init_flags.lag_sinc_advised) {
        rc = lag_sink_global_unadvise(__flex_acl_lag_global_update);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in lag_sink_global_unadvise, error: %s \n", sx_status_str(rc));
        }
        g_init_flags.lag_sinc_advised = FALSE;
    }

    if (g_init_flags.adviser_regisered_dev_ready) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_POST_DEVICE_READY_E,
                                    __flex_acl_device_ready_callback);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in adviser register - delete ADVISER_EVENT_POST_DEVICE_READY, error: %s \n",
                       sx_status_str(rc));
        }
        g_init_flags.adviser_regisered_dev_ready = FALSE;
    }
    if (g_init_flags.rif_create_adviser_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_POST_RIF_ADD_E, __flex_acl_rif_create_adviser_cb);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up rif create adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.ecmp_update_pointer_change_adviser_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_POST_ECMP_UPDATE_E,
                                    __flex_acl_ecmp_update_ptr_changed);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up ECMP pointer change adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.ipv6_reloc_changed_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_POST_IPV6_CHANGE_E,
                                    __flex_acl_ipv6_reloc_changed);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up IPv6 relocation change adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.mc_container_port_mc_pointer_change_adviser_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_POST_MC_CONTAINER_PORT_MC_POINTER_CHANGE_E,
                                    __flex_acl_mc_container_ptr_changed);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up tunnel decap destroy adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.mc_container_nve_mc_pointer_change_adviser_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_POST_MC_CONTAINER_NVE_MC_POINTER_CHANGE_E,
                                    __flex_acl_mc_container_ptr_changed);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up tunnel decap destroy adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.fdb_mc_mid_change_adviser_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_POST_FDB_MC_MID_CHANGE_E,
                                    __flex_acl_fdb_mc_mid_changed);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up fdb mc mid destroy adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.continue_lookup_adviser_set_done) {
        rc = hwd_continue_lookup_update_adviser_set(SX_ACCESS_CMD_DELETE, flex_acl_hw_continue_lookup_change);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up continue lookup destroy adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.ftn_adviser_set_done) {
        rc = hwd_mpls_ftn_update_adviser_set(SX_ACCESS_CMD_DELETE, flex_acl_hw_ftn_change);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up ftn destroy adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.tunnel_decap_change_adviser_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_POST_TUNNEL_DECAP_CHANGE_E,
                                    flex_acl_hw_mc_tunnel_decap_change);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up tunnel decap destroy adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.vport_bridge_delete_pre_adviser_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_PRE_VPORT_BRIDGE_DELETE_E,
                                    __flex_acl_vport_bridge_delete_cb);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up bridge delete vport, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.mc_container_erif_pointer_change_adviser_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_POST_MC_CONTAINER_ERIF_POINTER_CHANGE_E,
                                    flex_acl_hw_mc_container_change);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up rif destroy adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.rif_destroy_adviser_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_PRE_RIF_DEL_E,
                                    __flex_acl_rif_destroy_adviser_cb);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up rif destroy adviser, rc = %s\n", sx_status_str(rc));
        }
    }

    if (g_init_flags.adviser_registered_port_add) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E,
                                    __flex_acl_port_handle_swid_callback);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in adviser register - delete DEL_PORT_FROM_SWID, error: %s \n", sx_status_str(rc));
        }
        g_init_flags.adviser_registered_port_add = FALSE;
    }

    if (g_init_flags.adviser_registered_port_del) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_PORT_DEL_FROM_SWID_E,
                                    __flex_acl_port_handle_swid_callback);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in adviser register - delete DEL_PORT_FROM_SWID, error: %s \n", sx_status_str(rc));
        }
        g_init_flags.adviser_registered_port_del = FALSE;
    }

    if (g_init_flags.adviser_registered_pre_port_del) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PRE_PORT_DEL_FROM_SWID_E,
                                    __flex_acl_pre_port_del_from_swid_callback);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in adviser register - delete PRE_DEL_PORT_FROM_SWID, error: %s \n", sx_status_str(
                           rc));
        }
        g_init_flags.adviser_registered_pre_port_del = FALSE;
    }
    if (g_init_flags.mc_container_next_hops_change_adviser_set_done) {
        rc = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_MC_CONTAINER_NEXT_HOPS_CHANGE_E,
                                    __flex_acl_mc_container_port_next_hops_change_cb);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR(
                "Failed in adviser register - delete ADVISER_EVENT_POST_MC_CONTAINER_NEXT_HOPS_CHANGE_E, error: %s \n",
                sx_status_str(
                    rc));
        }
        g_init_flags.mc_container_next_hops_change_adviser_set_done = FALSE;
    }

    /* Deinit Custom Bytes sets configuration array */
    if (NULL != custom_bytes_set_data) {
        CL_FREE_N_NULL(custom_bytes_set_data);
    }

    if (flex_acl_ops_g->acl_default_action_needed_p()) {
        rc = flex_acl_hw_deinit_default_actions();
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit default actions\n");
        }
    }

    rc = __flex_acl_deinit_commit_acls();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deinit commit acls\n");
    }
    rc = __flex_acl_deinit_rules_resources();
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to cleanup rules resources.\n");
    }

    if (g_init_flags.span_user_inited) {
        rc = span_user_deinit(acl_span_handle);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit span manager.\n");
        }
        g_init_flags.span_user_inited = FALSE;
    }

    if (g_init_flags.policer_manager_user_inited) {
        rc = policer_manager_user_deinit(acl_policer_manager_handle);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit policer manager.\n");
        }
        g_init_flags.policer_manager_user_inited = FALSE;
    }

    if (g_init_flags.cm_user_inited) {
        rc = cm_user_deinit(acl_cm_handle);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit CM.\n");
        }
        g_init_flags.cm_user_inited = FALSE;
    }

    if (g_init_flags.rm_extended_actions_inited) {
        rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit extended actions in rm\n");
        }
        g_init_flags.rm_extended_actions_inited = FALSE;
    }

    if (g_init_flags.kvd_rules_inited) {
        rc = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_ACL_RULES_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("KVD linear deinit failed.\n");
        }
        g_init_flags.kvd_rules_inited = FALSE;
    }

    if (g_init_flags.kvd_default_actions_inited) {
        rc = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_ACL_DEFAULT_ACTIONS_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("KVD linear deinit failed.\n");
        }
        g_init_flags.kvd_default_actions_inited = FALSE;
    }

    /* Deinit Resource manager. */
    if (g_init_flags.rm_acls_in_groups_inited) {
        rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit acls in groups in rm\n");
        }
        g_init_flags.rm_acls_in_groups_inited = FALSE;
    }

    if (g_init_flags.rm_groups_inited) {
        rc = flex_acl_db_get_max_acl_groups(&rm_acl_groups, &used_groups);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get maximum acl groups from DB\n");
        } else {
            rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_DELETE, used_groups, NULL);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to delete acl groups entries from rm\n");
            }

            rc = rm_allocate_entries_check(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_DELETE, rm_acl_groups, NULL);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to deallocate (check) acl groups from rm\n");
            }

            rc =
                rm_allocate_entries_update(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_DELETE, rm_acl_groups,  NULL);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to deallocate (update) acl groups from rm\n");
            }
        }

        rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit acl groups in rm\n");
        }
        g_init_flags.rm_groups_inited = FALSE;
    }

    /* Deinit RM only if initialized */
    if ((rm_resource_global.acl_regions_max > 0) && g_init_flags.rm_rules_inited) {
        rc = flex_acl_db_region_valid_rules_sum_get(&rm_valid_rules);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to get valid acl rules from DB\n");
        } else if (rm_valid_rules != 0) {
            rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_RULES_E, SX_ACCESS_CMD_DELETE, rm_valid_rules, NULL);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to delete acl rules entries from rm\n");
            }
        }

        rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit c-tcam two key blocks acl rules in rm\n");
        }
        rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit c-tcam four key blocks acl rules in rm\n");
        }
        rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit c-tcam six key blocks acl rules in rm\n");
        }

        rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_RULES_E, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit acl rules in rm\n");
        }

        rm_sdk_set_acl_enforce_min_table_size_func(NULL);
        g_init_flags.rm_rules_inited = FALSE;
    }

    /* Deinit RM only if initialized */
    if (g_init_flags.rm_regions_inited) {
        rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_E, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit acl rules in rm\n");
        }
        g_init_flags.rm_regions_inited = FALSE;
    }

    g_init_flags.basic_keys_inited = FALSE;

    if (g_init_flags.db_inited) {
        flex_acl_db_deinit();
        g_init_flags.db_inited = FALSE;
    }

    if (g_init_flags.pbs_inited) {
        rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_ACL_PBS_E, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit acl PBS in rm\n");
        }
        g_init_flags.pbs_inited = FALSE;
    }

    if (g_init_flags.pbilm_inited) {
        rc = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_PB_MPLS_ILM_E, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit acl PBILM in rm\n");
        }
        g_init_flags.pbilm_inited = FALSE;
    }

    if (g_init_flags.rule_based_biniding_inited) {
        rc = flex_acl_rule_based_binding_deinit();
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to deinit acl rule based binding\n");
        }
        g_init_flags.rule_based_biniding_inited = FALSE;
    }

    if (g_init_flags.hw_init_done) {
        rc = flex_acl_hw_deinit();
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed deinit hw db resources, error:  %s \n", sx_status_str(rc));
        }
        g_init_flags.hw_init_done = FALSE;
    }

    if (g_init_flags.kvd_pbs_inited) {
        rc = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_PBS_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("KVD linear deinit PBS failed.\n");
        }
        g_init_flags.kvd_pbs_inited = FALSE;
    }

    if (g_init_flags.kvd_pbilm_inited) {
        rc = kvd_linear_manager_deinit_user(KVD_LINEAR_MANAGER_USER_PBILM_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("KVD linear deinit PBILM failed.\n");
        }
        g_init_flags.kvd_pbilm_inited = FALSE;
    }

    if (g_init_flags.redirection_db_inited) {
        flex_acl_deinit_redirection_db();
        g_init_flags.redirection_db_inited = FALSE;
    }

    SX_LOG_NTC("ACL : Terminated\n");

    g_flex_acl_initialized = FALSE;

    SX_LOG_EXIT();
}

sx_status_t flex_acl_egress_mirror_handle_buffer(sx_access_cmd_t cmd, sx_port_log_id_t log_port)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((SX_PORT_TYPE_ID_GET(log_port) != SX_PORT_TYPE_NETWORK)) {
        goto out;
    }
    rc = span_egress_mirror_handle_buffer(cmd, log_port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" Failed span_egress_mirror_alloc_buffer for port :%x, (%s).\n", log_port, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_pre_port_del_from_swid_callback(adviser_event_e event_type, void *param)
{
    sx_port_info_t          *port_info_p = NULL;
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;

    SX_LOG_ENTER();

    UNUSED_PARAM(event_type);

    port_info_p = (sx_port_info_t*)param;

    /* Skip unmapped ports */
    if (SX_SWID_ID_DISABLED == port_info_p->swid_id) {
        SX_LOG_DBG("Skipping Port 0x%08X because it's not mapped\n", port_info_p->id);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = swid_validation_func_ptr(port_info_p->swid_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Swid validation failed\n");
        /* SWID type mismatch, nothing to process */
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    if (port_info_p->port_mode == SX_PORT_MODE_TCA_CONNECTOR) {
        SX_LOG_ERR("Can't update TCA CONNECTOR PORT (0x%08X)  when swid (%d)is not an ETH swid.\n",
                   port_info_p->id,
                   port_info_p->swid_id);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    if (SX_CHECK_PASS(flex_acl_db_pbs_by_log_port(port_info_p->id, &pbs_entry))) {
        SX_LOG_ERR("port 0x%X is in pbs %d - failing\n", port_info_p->id, pbs_entry->pbs_id);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /*Check that port not in use by RX list*/
    rc = flex_acl_db_is_port_in_port_list(port_info_p->id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("port 0x%X is in use in port_list, error: %s \n", port_info_p->id, sx_status_str(rc));
        goto out;
    }

    /* The clear port binding was moved here from the post callback.
     * Since the SWID port delete disables the port in FW (via the PSPA register)
     * we cannot call the PPBT register at the post callback.
     * We remove the binding here after all the pre-validations are done.
     */
    rc = flex_acl_clear_port_binding(port_info_p->id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in __acl_clear_port_binding port [0x%x] , error: %s\n", port_info_p->id,
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_handle_buffers_for_port(flex_acl_db_acl_region_t *region,
                                                      sx_access_cmd_t           cmd,
                                                      sx_port_log_id_t          port)
{
    sx_status_t rc = SX_STATUS_SUCCESS, rb_rc;
    uint32_t    i, count, success = 0;

    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE)) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("__flex_acl_handle_buffers_for_port. Invalid command %u\n", cmd);
        goto out;
    }

    if (!region->bound_to_devs) {
        /* Region is not bound, nothing to do */
        goto out;
    }

    rc = flex_acl_db_egress_mirror_actions_count_get(region->region_id, &count);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("flex_acl_handle_buffers_for_port failed, region_id: %u\n", region->region_id);
    }

    for (i = 0; i < count; i++) {
        rc = flex_acl_egress_mirror_handle_buffer(cmd, port);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("__flex_acl_handle_buffers_for_port failed, port: %#x\n", port);
            goto error;
        }
        success++;
    }

    goto out;

error:
    for (i = 0; i < success; i++) {
        rb_rc = flex_acl_egress_mirror_handle_buffer(
            cmd == SX_ACCESS_CMD_ADD ? SX_ACCESS_CMD_DELETE : SX_ACCESS_CMD_ADD,
            port);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_DBG("flex_acl_egress_mirror_handle_buffer failed. Rollback\n");
            break;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_alloc_buffers_for_port(flex_acl_db_acl_region_t *region, void *param_p)
{
    return __flex_acl_handle_buffers_for_port(region, SX_ACCESS_CMD_ADD, ((sx_port_info_t*)param_p)->id);
}


static sx_status_t __flex_acl_free_buffers_for_port(flex_acl_db_acl_region_t *region, void *param_p)
{
    return __flex_acl_handle_buffers_for_port(region, SX_ACCESS_CMD_DELETE, ((sx_port_info_t*)param_p)->id);
}

static sx_status_t __flex_acl_port_handle_swid_callback(adviser_event_e event_type, void *param)
{
    sx_port_info_t *port_info_p = NULL;
    sx_status_t     rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    port_info_p = (sx_port_info_t*)param;

    rc = swid_validation_func_ptr(port_info_p->swid_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Swid validation failed, swid: %u\n", port_info_p->swid_id);
        /* SWID type mismatch, nothing to process */
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    if (port_info_p->port_mode == SX_PORT_MODE_TCA_CONNECTOR) {
        SX_LOG_ERR("Can't update TCA CONNECTOR PORT (0x%08X)  when swid (%d)is not an ETH swid.\n",
                   port_info_p->id,
                   port_info_p->swid_id);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    switch (event_type) {
    case ADVISER_EVENT_POST_PORT_DEL_FROM_SWID_E:
        rc = flex_acl_rule_based_binding_port_delete_update(port_info_p->id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in flex_acl_rule_based_binding_port_delete_update port [0x%x] , error: %s\n",
                       port_info_p->id,
                       sx_status_str(rc));
            goto out;
        }

        /* Free all the buffers allocated by acl rules */
        rc = flex_acl_db_region_foreach(__flex_acl_free_buffers_for_port, port_info_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in flex_acl_update_region_at_device_ready, error: %s \n", sx_status_str(rc));
            goto out;
        }
        rc = __flex_acl_post_port_del_from_swid_mc_container_port(port_info_p->id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to handle port_filter_post_port_del_from_swid, error: %s \n", sx_status_str(rc));
            goto out;
        }
        break;

    case ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E:
        /* Allocate all the buffers allocated by acl rules */
        rc = flex_acl_db_region_foreach(__flex_acl_alloc_buffers_for_port, port_info_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in flex_acl_update_region_at_device_ready, error: %s \n", sx_status_str(rc));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Invalid event type %d: \n", event_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }


out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t flex_acl_update_rules_at_device_ready(sx_acl_direction_t        direction,
                                                         flex_acl_db_acl_region_t *region,
                                                         sx_dev_id_t               dev_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    UNUSED_PARAM(direction);

    SX_LOG_ENTER();

    for (i = 0; i < region->size; i++) {
        if (region->rules[i].valid) {
            rc = flex_acl_hw_write_only_rule(&region->rules[i],
                                             region,
                                             dev_id,
                                             TRUE,
                                             FLEX_ACL_HW_FULL_WRITE,
                                             FALSE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL Fatal error: Failed writing rules to new added device[%d].\n", dev_id);
                goto out;
            }
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t flex_acl_update_region_at_device_ready(flex_acl_db_acl_region_t *region, void *param_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_acl_size_t                    allocated_size = 0;
    flex_acl_hw_db_region_attribs_t *attribs = NULL;
    flex_acl_db_acl_table_t         *acl_table = NULL;
    sx_dev_id_t                     *dev_id = (sx_dev_id_t*)param_p;

    SX_LOG_ENTER();

    rc = flex_acl_hw_db_get_region_attributes(region->hw_region_attribs_handle, &attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("get region attributes error, handle: %u\n", region->hw_region_attribs_handle);
        goto out;
    }

    rc = flex_acl_db_acl_get(region->bound_acl, &acl_table);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("get acl table error, acl id[%d]\n", region->bound_acl);
        goto out;
    }

    rc = flex_acl_hw_reg_write_region(region,
                                      *dev_id,
                                      ACL_REGION_HW_OP_ALLOCATE_E,
                                      attribs->region_info[*dev_id],
                                      SXD_TCAM_REGION_INFO_SIZE_BYTES,
                                      region->size,
                                      &allocated_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : the register update failed for region id [%d] ,device id [%d].\n",
                   region->region_id,
                   *dev_id);
        goto out;
    }

    attribs->hw_size[*dev_id] = allocated_size;


    rc = flex_acl_update_rules_at_device_ready(acl_table->direction, region, *dev_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL Fatal error: Failed writing roll back of move rules.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t flex_acl_update_acl_at_device_ready(flex_acl_db_acl_table_t *acl_table, void *param_p)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    sx_dev_id_t *dev_id = (sx_dev_id_t*)param_p;

    SX_LOG_ENTER();

    rc = flex_acl_hw_reg_write_acls_to_dev(acl_table, dev_id, 1, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : the register update failed for acl_id[%d] ,region_id[%#x], device id [%d].\n",
                   acl_table->acl_id, acl_table->bound_region, *dev_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_hw_write_group_to_new_dev(flex_acl_bind_attribs_id_t new_bind_attribs_id,
                                               sx_dev_id_t                dev_id,
                                               acl_id_group_entry_t      *acl_ids_prepared,
                                               uint32_t                   prepared_ids_num)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sxd_status_t                      sxd_status = SXD_STATUS_SUCCESS;
    uint32_t                          i = 0;
    struct ku_pagt_reg                pagt_reg_data;
    sxd_reg_meta_t                    pagt_reg_meta;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;


    SX_LOG_ENTER();

    /* simply don't write configuration to register */
    if (prepared_ids_num == 0) {
        goto out;
    }

    SX_MEM_CLR(pagt_reg_meta);
    SX_MEM_CLR(pagt_reg_data);

    rc = flex_acl_db_attribs_get(new_bind_attribs_id, &bind_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get bind attributes with id %d\n", new_bind_attribs_id);
        goto out;
    }

    pagt_reg_meta.dev_id = dev_id;
    pagt_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    pagt_reg_data.acl_group_id = bind_attribs->bind_id;
    pagt_reg_data.egress = bind_attribs->direction;
    pagt_reg_data.size = prepared_ids_num;

    for (i = 0; i < pagt_reg_data.size; i++) {
        pagt_reg_data.acl_ids[i].acl_id = acl_ids_prepared[i].acl_id;
        pagt_reg_data.acl_ids[i].commit = (acl_ids_prepared[i].is_commit) ? 1 : 0;
    }

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PAGT_E, &pagt_reg_data, &pagt_reg_meta, 1, NULL, NULL);
    if (SXD_STATUS_SUCCESS != sxd_status) {
        SX_LOG_ERR("ACL : Failed to configure ACL group [%u] to HW rc [%u] \n", bind_attribs->bind_id, sxd_status);
        rc = sxd_status_to_sx_status(sxd_status);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t flex_acl_update_group_at_device_ready(flex_acl_db_acl_group_t *group, void *param_p)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    acl_id_group_entry_t acl_ids_prepared[SPECTRUM_ACL_GROUPS_SIZE_MAX] = {
        {0}
    };
    uint32_t             prepared_acls_num = rm_resource_global.acl_groups_size_max;
    sx_dev_id_t         *dev_id = (sx_dev_id_t*)param_p;

    SX_LOG_ENTER();

    if (group->bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        goto out;
    }
    rc = flex_acl_hw_prepare_acl_list_from_groups(group->group_id,
                                                  acl_ids_prepared,
                                                  &prepared_acls_num,
                                                  group->direction);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to prepare acl list from group [0x%x] \n", group->group_id);
        goto out;
    }

    /* write group to register, adds system acl  */
    rc = flex_acl_hw_write_group_to_new_dev(group->bind_attribs_id, *dev_id, acl_ids_prepared, prepared_acls_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to write group to register, bind attributes: %u\n", group->bind_attribs_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_hw_reg_write_rif_to_new_dev(flex_acl_db_rif_info_t *rif_info, void *param_p)
{
    sxd_status_t                      sxd_status = SXD_STATUS_SUCCESS;
    struct ku_prbt_reg                prbt_reg_data;
    sxd_reg_meta_t                    prbt_reg_meta;
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    flex_acl_db_group_bind_attribs_t *attribs = NULL;
    sx_dev_id_t                      *dev_id = (sx_dev_id_t*)param_p;

    SX_LOG_ENTER();

    SX_MEM_CLR(prbt_reg_meta);
    SX_MEM_CLR(prbt_reg_data);

    rc = flex_acl_db_attribs_get(rif_info->bound_attribs_id, &attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get bind attributes with id %d\n", rif_info->bound_attribs_id);
        goto out;
    }

    prbt_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    prbt_reg_meta.dev_id = *dev_id;
    prbt_reg_data.egress_indication = attribs->direction % 2; /* direction ingress or egress only */
    prbt_reg_data.group_binding = SXD_GROUP_OR_ACL_BINDING_TYPE_GROUP_E;
    prbt_reg_data.acl_id_grp_id = attribs->bind_id;
    rc = sdk_router_cmn_rif_hw_id_get(rif_info->rif_id, &prbt_reg_data.rif);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "sdk_router_cmn_rif_hw_id_get failed, rif: %u, err %s\n", rif_info->rif_id,
               sx_status_str(rc));
        goto out;
    }

    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PRBT_E, &prbt_reg_data, &prbt_reg_meta, 1, NULL, NULL);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to bind port SXD err [%u]\n", sxd_status);
        rc = sxd_status_to_sx_status(sxd_status);
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t __flex_acl_set_vlan_group_to_dev(flex_acl_db_vlan_group_element_t *grp_info, void *param_p)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sxd_status_t         sxd_status;
    uint32_t             vid_idx, swid_idx, swid_max;
    sx_dev_id_t         *dev_id = (sx_dev_id_t*)param_p;
    struct ku_pvgt_reg   pvgt;
    struct ku_pvbt_reg   pvbt;
    sxd_reg_meta_t       meta;
    static sx_vlan_id_t* vlans_list = NULL; /* Why static??????? */
    uint32_t             vid_num;

    SX_LOG_ENTER();

    SX_MEM_CLR(meta);
    SX_MEM_CLR(pvgt);

    vlans_list = (sx_vlan_id_t*)cl_malloc(sizeof(sx_vlan_id_t) * (VLAN_ID_MAX + 1));
    if (vlans_list == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }
    memset(vlans_list, 0, sizeof(sx_vlan_id_t) * (VLAN_ID_MAX + 1));

    meta.access_cmd = SXD_ACCESS_CMD_SET;
    meta.dev_id = *dev_id;

    pvgt.vlan_group = grp_info->group_id;
    pvgt.op = SXD_PVGT_OP_ADD_VLAN_E;

    /* Update Vlan group to device */
    vid_num = VLAN_ID_MAX + 1;
    swid_max = flex_acl_db_get_max_swid();

    for (swid_idx = SX_SWID_ID_MIN; swid_idx < swid_max; swid_idx++) {
        rc = flex_acl_db_vlan_group_get(grp_info->group_id, swid_idx, vlans_list, &vid_num);
        if (rc == SX_STATUS_SUCCESS) {
            pvgt.swid = swid_idx;
            meta.swid = swid_idx;
            for (vid_idx = 0; vid_idx < vid_num; vid_idx++) {
                pvgt.vid = vlans_list[vid_idx];

                sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PVGT_E, &pvgt, &meta, 1, NULL, NULL);
                if (sxd_status != SXD_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL : Failed to set vlan group entry SXD err [%s]\n",
                               SXD_STATUS_MSG(sxd_status));
                    rc = SXD_STATUS_TO_SX_STATUS(sxd_status);
                    goto out;
                }
            }
        }
    }
    /* Update Bound tables to device */

    /* Bind ACL to VLAN group */
    if (grp_info->bound_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        SX_MEM_CLR(meta);
        SX_MEM_CLR(pvbt);

        meta.access_cmd = SXD_ACCESS_CMD_SET;
        meta.dev_id = *dev_id;

        pvbt.op = SXD_PVBT_OP_BIND_E;
        pvbt.vlan_group = grp_info->group_id;
        pvbt.g = TRUE;
        pvbt.acl_id_group_id = grp_info->bound_attribs_id;
        pvbt.swid = 0;

        sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PVBT_E, &pvbt, &meta, 1, NULL, NULL);
        if (sxd_status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to bind VLAN group [%u] SXD err [%s]\n",
                       grp_info->group_id, SXD_STATUS_MSG(sxd_status));
            rc = SXD_STATUS_TO_SX_STATUS(sxd_status);
            goto out;
        }
    }

out:
    if (vlans_list) {
        CL_FREE_N_NULL(vlans_list);
    }
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_acl_device_ready_callback(adviser_event_e event_type, void *param)
{
    sx_dev_info_t *dev_info_p = NULL;
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_boot_mode_e issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    acl_stage_e    acl_stage = ACL_STAGE_UNKNOWN;


    SX_LOG_ENTER();

    UNUSED_PARAM(event_type);

    dev_info_p = (sx_dev_info_t*)(param);

    if ((dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE) ||
        (dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE_LOCAL)) {
        rc = SX_STATUS_SUCCESS;
    }

    rc = issu_boot_mode_get(&issu_boot_mode);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get issu boot mode, error: %s\n", sx_status_str(rc));
        goto out;
    }

    if (issu_boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        /* When SDK is being booted in ISSU_STARTED mode, the DPT is set to READ-ONLY before all SDK
         * modules initialize. Here we temporarily set DPT to READ-WRITE to allow the commit regions/acls
         * to be actually written to HW registers. The DPT is set back to READ-ONLY after that.
         */
        rc = issu_dpt_access_control_set(READ_WRITE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set dpt access control, error: %s\n", sx_status_str(rc));
            goto out;
        }
    }

    if (flex_acl_ops_g->acl_stage_get_p(&acl_stage) != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get flex acl stage.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /*Policy engine general register conf*/
    if (ACL_STAGE_IS_FLEX2_OR_ABOVE(acl_stage)) {
        if ((issu_boot_mode != SX_BOOT_MODE_DISABLED_E) && (g_default_action_issu_support == FALSE)) {
            /* For Spectrum versions of these flex acl stages we need to write the
             * default action for all regions in case we might have an issu executed.
             */
            rc = flex_acl_write_default_action(FLEX_ACL_INVALID_REGION_ID, TRUE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to init default actions for all regions for device ready execution\n");
                goto out;
            }
        }
        rc = flex_acl_hw_policy_engine_general_conf_device(dev_info_p->dev_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Policy engine general register conf failed.\n");
            goto out;
        }
    }

    /* Makes sure the new device will reserve the right space like the others */
    rc = __flex_acl_enforce_min_table_size_on_new_dev(dev_info_p->dev_id);
    if (SX_CHECK_FAIL(rc)) {
        if (SX_STATUS_ENTRY_NOT_FOUND != rc) {
            SX_LOG_ERR("Failed in __acl_enforce_min_table_size_on_new_dev, error: %s \n", sx_status_str(rc));
            goto out;
        }
    }

    rc = flex_acl_db_region_foreach(flex_acl_update_region_at_device_ready, &dev_info_p->dev_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in flex_acl_update_region_at_device_ready, error: %s \n", sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_db_acl_bind_foreach(flex_acl_update_acl_at_device_ready, &dev_info_p->dev_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in flex_acl_update_new_dev_macro, error: %s \n", sx_status_str(rc));
        goto out;
    }
    rc = flex_acl_db_group_bind_foreach(flex_acl_update_group_at_device_ready, &dev_info_p->dev_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in flex_acl_update_acl_at_device_ready, error: %s \n", sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_db_rif_bind_foreach(flex_acl_hw_reg_write_rif_to_new_dev, &dev_info_p->dev_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in flex_acl_hw_reg_write_rif_to_new_dev, error: %s \n", sx_status_str(rc));
        goto out;
    }

    /* Set All Vlan groups to Device */
    rc = flex_acl_db_vlan_group_foreach(__flex_acl_set_vlan_group_to_dev, &dev_info_p->dev_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in __flex_acl_set_vlan_group_to_dev, error: %s \n", sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_rule_based_binding_device_ready(FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed in flex_acl_rule_based_binding_device_ready, error: %s \n", sx_status_str(rc));
        goto out;
    }

out:
    if (issu_boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        rc = issu_dpt_access_control_set(READ_ONLY);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set dpt access control, error: %s\n", sx_status_str(rc));
        }
    }

    SX_LOG_EXIT();

    return rc;
}

static sx_status_t __flex_acl_set_commit_acl(sx_acl_direction_t egress, sx_acl_key_type_t key_handle)
{
    sx_api_flex_acl_set_params_t       acl_params = {.cmd = 0};
    sx_api_acl_region_set_params_t     region_params = {.cmd = 0};
    sx_api_flex_acl_rules_set_params_t rules_params = {.cmd = 0};
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_status_t                        rb_st = SX_STATUS_SUCCESS;
    sx_flex_acl_flex_rule_t            rule;
    sx_acl_rule_offset_t               offset;

    SX_LOG_ENTER();
    SX_MEM_CLR(rule);
    SX_MEM_CLR(offset);

    rules_params.rules = &rule;
    rules_params.offsets_list_p = &offset;


    region_params.cmd = SX_ACCESS_CMD_CREATE;
    region_params.region_size = FLEX_ACL_RULES_MIN;
    region_params.key_type = key_handle;
    rc = flex_acl_region_set(&region_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set region for system purposes\n");
        goto out;
    }

    acl_params.acl_direction = egress;
    acl_params.cmd = SX_ACCESS_CMD_CREATE;
    acl_params.region_id = region_params.region_id;

    rc = flex_acl_set(&acl_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set region for system purposes\n");
        goto rollback_region_set;
    }

    /* Note: it is important to mark the acl as commit ACL before writing the rules. */
    rc = flex_acl_hw_commit_acl_set(acl_params.acl_id, egress);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update commit acl id purposes, acl_id: %u\n", acl_params.acl_id);
        goto rollback_acl_set;
    }

    rc = sx_lib_flex_acl_rule_init(key_handle, 1, &rules_params.rules[0]);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init rule for commit acl, key_handle: %u\n", key_handle);
        goto rollback_commit_acl_set;
    }
    rules_params.cmd = SX_ACCESS_CMD_SET;
    rules_params.region_id = region_params.region_id;
    rules_params.rules[0].action_count = 0;
    rules_params.rules_count = 1;
    rules_params.offsets_list_p[0] = 0;
    rules_params.rules[0].valid = 1;
    rules_params.rules[0].key_desc_count = 1;
    rules_params.rules[0].key_desc_list_p[0].key_id = FLEX_ACL_KEY_DIP;
    rules_params.rules[0].key_desc_list_p[0].key.dip.version = SX_IP_VERSION_IPV4;
    rules_params.rules[0].key_desc_list_p[0].mask.dip.version = SX_IP_VERSION_IPV4;
    rules_params.rules[0].key_desc_list_p[0].key.dip.addr.ipv4.s_addr = 0;
    rules_params.rules[0].key_desc_list_p[0].mask.dip.addr.ipv4.s_addr = 0;

    rc = flex_acl_rules_set(&rules_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set rules for system purposes\n");
        goto rollback_commit_acl_set;
    }

    /* free allocated resources */
    goto out;

rollback_commit_acl_set:
    rb_st = flex_acl_hw_commit_acl_set(FLEX_ACL_INVALID_ACL_ID, egress);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_st));
    }
rollback_acl_set:
    acl_params.cmd = SX_ACCESS_CMD_DESTROY;
    rb_st = flex_acl_set(&acl_params);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_st));
    }
rollback_region_set:
    region_params.cmd = SX_ACCESS_CMD_DESTROY;
    rb_st = flex_acl_region_set(&region_params);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err[%s]\n", sx_status_str(rb_st));
    }
out:
    rb_st = sx_lib_flex_acl_rule_deinit(&rules_params.rules[0]);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Failed deinit rules structure \n");
    }
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_acl_unset_commit_acl(sx_acl_direction_t egress, sx_acl_key_type_t *key_handle)
{
    sx_api_flex_acl_set_params_t   acl_params = {.cmd = 0};
    sx_api_acl_region_set_params_t region_params = {.cmd = 0};
    flex_acl_db_acl_table_t       *acl_table = NULL;
    flex_acl_db_acl_region_t      *region = NULL;
    sx_acl_id_t                    acl_id = FLEX_ACL_INVALID_ACL_ID;
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_status_t                    rb_st = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_hw_commit_acl_get(&acl_id, egress);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get commit acl id\n");
        goto out;
    }
    if (acl_id == FLEX_ACL_INVALID_ACL_ID) {
        *key_handle = FLEX_ACL_INVALID_HANDLE;
        goto out;
    }

    rc = flex_acl_db_acl_get(acl_id, &acl_table);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get acl, acl_id: %u\n", acl_id);
        goto out;
    }

    rc = flex_acl_db_region_get(acl_table->bound_region, &region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region, region_id: %u\n", acl_table->bound_region);
        goto out;
    }
    *key_handle = region->key_handle;

    /* invalidate acl */
    acl_params.acl_direction = egress;
    acl_params.region_id = acl_table->bound_region;
    acl_params.cmd = SX_ACCESS_CMD_DESTROY;
    acl_params.acl_id = acl_id;
    rc = flex_acl_set(&acl_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to unset commit acl\n");
        goto out;
    }

    /* invalidate region */
    region_params.region_id = acl_params.region_id;
    region_params.cmd = SX_ACCESS_CMD_DESTROY;
    region_params.region_size = region->size;
    region_params.key_type = region->key_handle;
    rc = flex_acl_region_set(&region_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set region for system purposes\n");
        goto rollback_acl_set;
    }

    rc = flex_acl_hw_commit_acl_set(FLEX_ACL_INVALID_ACL_ID, egress);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update commit acl id purposes\n");
        goto rollback_region_set;
    }

    goto out;

rollback_region_set:
    region_params.cmd = SX_ACCESS_CMD_CREATE;
    rb_st = flex_acl_region_set(&region_params);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
    }
rollback_acl_set:
    acl_params.region_id = region_params.region_id;
    acl_params.cmd = SX_ACCESS_CMD_CREATE;
    rb_st = flex_acl_set(&acl_params);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_init_commit_acls()
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_status_t                      rb_st = SX_STATUS_SUCCESS;
    sx_api_flex_acl_key_set_params_t key_params = { .cmd = 0};
    uint32_t                         i = 0;
    uint32_t                         j = 0;

    SX_LOG_ENTER();

    key_params.keys[0] = FLEX_ACL_KEY_DIP;
    key_params.keys_count = 1;
    key_params.cmd = SX_ACCESS_CMD_CREATE;

    rc = flex_acl_key_set(&key_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set acl key for system purposes\n");
        goto out;
    }

    for (i = 0; i <= SX_ACL_DIRECTION_MAX_SPECTRUM; i++) {
        rc = __flex_acl_set_commit_acl(i, key_params.key_handle);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set commit ACL for system purposes, egress: %u, key_handle: %u\n",
                       i, key_params.key_handle);
            goto error;
        }
    }
    goto out;

error:
    for (j = 0; j < i; j++) {
        rb_st = __flex_acl_unset_commit_acl(j, &(key_params.key_handle));
        if (SX_CHECK_FAIL(rb_st)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
        }
    }
    key_params.cmd = SX_ACCESS_CMD_DELETE;
    rb_st = flex_acl_key_set(&key_params);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_deinit_commit_acls()
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_status_t                      rb_rc = SX_STATUS_SUCCESS;
    sx_api_flex_acl_key_set_params_t key_params = {.cmd = 0};
    uint32_t                         i = 0;
    uint32_t                         j = 0;

    SX_LOG_ENTER();

    for (i = 0; i <= SX_ACL_DIRECTION_MAX_SPECTRUM; i++) {
        rc = __flex_acl_unset_commit_acl(i, &(key_params.key_handle));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to unset commit acl for system purposes, egress: %u\n", i);
            goto error;
        }
    }

    if (key_params.key_handle != FLEX_ACL_INVALID_HANDLE) {
        key_params.cmd = SX_ACCESS_CMD_DELETE;
        rc = flex_acl_key_set(&key_params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to destroy acl key for system purposes\n");
            goto error;
        }
    }
    goto out;

error:
    for (j = 0; j < i; j++) {
        if (SX_CHECK_FAIL(rb_rc = __flex_acl_set_commit_acl(j, key_params.key_handle))) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/**
 * This function is a callback for the lag sink port change event
 *
 * @param[in]  lag_port_log_id  - notify on this lag log port
 * @param[in]  event_type    - new event type (CREATE/DESTROY)
 * @param[in]  port_log_id   - notify on this logical port id
 * @param[in]  context_p     - adviser context to be called from callback
 *
 * @return sx_status_t
 */
static sx_status_t __flex_acl_lag_port_update(sx_port_id_t          lag_port_log_id,
                                              lag_sink_event_type_e event_type,
                                              sx_port_id_t          port_log_id,
                                              void                 *context_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    SX_LOG_DBG(" lag_port_log_id[%d], event_type[%d], port_log_id[%d]\n", lag_port_log_id, event_type, port_log_id);

    UNUSED_PARAM(context_p);

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_POST_PORT_ADDED_E:
        /* Should bind the port to LAG ACLs if such exist */
        rc = flex_acl_post_port_added_to_lag_handle_binding(port_log_id, lag_port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("failed handling adding port [%#x] to lag [%#x], error: %s\n",
                       port_log_id,
                       lag_port_log_id,
                       sx_status_str(rc));
            goto out;
        }
        rc = __flex_acl_post_port_added_to_lag_mc_container(lag_port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("failed handling port filter adding port to lag [%#x], error: %s\n",
                       lag_port_log_id,
                       sx_status_str(rc));
            goto out;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_PORT_REMOVED_E:
        /* Should Unbind port from LAG related ACLs  */
        rc = flex_acl_port_removed_from_lag_handle_binding(lag_port_log_id, port_log_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to clear port [0x%x] bind\n", port_log_id);
            goto out;
        }
        rc = __flex_acl_post_port_removed_from_lag_mc_container(lag_port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("failed handling port filter removing port from lag [%#x], error: %s\n",
                       lag_port_log_id,
                       sx_status_str(rc));
            goto out;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        /* unregister destroyed lag id */
        rc = lag_sink_lag_unadvise(lag_port_log_id, __flex_acl_lag_port_update);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in lag_sink_lag_unadvise, lag: %#x, error: %s\n", lag_port_log_id, sx_status_str(rc));
            goto out;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_PRE_PORT_ADDED_VALIDATIONS_E:

        /* Check that there is no duplicate network ports or LAG ports */
        rc = __flex_acl_pre_port_added_to_lag(port_log_id, lag_port_log_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed add port:0x%X to lag:0x%X, rc=[%s]\n", port_log_id, lag_port_log_id, sx_status_str(rc));
            goto out;
        }
        rc = SX_STATUS_SUCCESS;
        break;


    default:
        SX_LOG_ERR("Wrong event type , event type: (%d)\n", event_type);
        rc = SX_STATUS_CMD_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_acl_pre_port_added_to_lag(sx_port_id_t log_port, sx_port_id_t lag_port_log_id)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    flex_acl_validate_pbs_lag_params_t add_port_to_lag;

    SX_LOG_ENTER();

    add_port_to_lag.lag_port_log_id = lag_port_log_id;
    add_port_to_lag.log_port = log_port;

    rc = flex_acl_db_pbs_foreach(__flex_acl_validate_pbs_lag, (void*)&add_port_to_lag);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't add port:[%#x] to LAG:[%#x], port and LAG in use by same PBS rc=[%s]\n",
                   log_port,
                   lag_port_log_id,
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_lag_global_update(sx_port_id_t          lag_port_log_id,
                                                lag_sink_event_type_e event_type,
                                                void                 *context_p)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;

    SX_LOG_ENTER();

    UNUSED_PARAM(context_p);

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_CREATED_E:
        /* advise for the new lag */
        rc = lag_sink_lag_advise(lag_port_log_id, __flex_acl_lag_port_update, NULL, 0);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in lag_sink_lag_advise (CREATE), lag: %#x, error: %s\n", lag_port_log_id,
                       sx_status_str(rc));
            goto out;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        rc = flex_acl_db_pbs_by_log_port(lag_port_log_id, &pbs_entry);
        if (rc == SX_STATUS_SUCCESS) {
            SX_LOG_DBG("lag port 0x%X is also a pbs port - dropping it\n", lag_port_log_id);
            rc = __flex_acl_pbs_del_ports_internal(pbs_entry, pbs_entry->swid, &lag_port_log_id, 1);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed in lag_sink_lag_advise __flex_acl_pbs_del_ports_internal, error: %s\n",
                           sx_status_str(rc));
                goto out;
            }
        }
        rc = __flex_acl_lag_destroyed_mc_container(lag_port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("failed handling port filter lag destroyed, lag: %#x, error: %s\n",
                       lag_port_log_id,
                       sx_status_str(rc));
            goto out;
        }
        rc = flex_acl_clear_port_binding(lag_port_log_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to clear lag bind for lag[%d] , error: %s\n", lag_port_log_id, sx_status_str(rc));
        }
        break;

    default:
        SX_LOG_ERR("Wrong event type , event type: (%d)\n", event_type);
        rc = SX_STATUS_CMD_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_enforce_min_table_size_on_new_dev(sx_dev_id_t dev_id)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    sx_acl_region_id_t         region_id = FLEX_ACL_INVALID_REGION_ID;
    flex_acl_db_acl_region_t * acl_region = NULL;

    SX_LOG_ENTER();

    /* Get the reserved region */
    sx_status = flex_acl_db_region_reserved_get(&region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at get reserved region \n");
        goto out;
    }
    if (region_id == FLEX_ACL_INVALID_REGION_ID) {
        goto out;
    }

    sx_status = flex_acl_db_region_get(region_id, &acl_region);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at get reserved region, region_id: %u\n", region_id);
        goto out;
    }

    /* Bind the acl to device */
    sx_status = __flex_acl_enforce_min_per_dev(acl_region,
                                               dev_id,
                                               ACL_REGION_HW_OP_ALLOCATE_E,
                                               ACL_REGION_HW_OP_DEALLOCATE_E,
                                               acl_region->size,
                                               0,
                                               TRUE);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to update HW with reserved region size %u\n", acl_region->size);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}
/* more need in this function */
sx_status_t __flex_acl_enforce_min_table_size(uint32_t allocate_size)
{
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    sx_acl_region_id_t         region_id = FLEX_ACL_INVALID_REGION_ID;
    flex_acl_db_acl_region_t * acl_region = NULL;
    sx_dev_id_t                devs_list[SX_DEV_NUM_MAX];
    sxd_acl_ptar_op_t          op = (sxd_acl_ptar_op_t)ACL_REGION_HW_OP_ALLOCATE_E;
    sxd_acl_ptar_op_t          rollback_op = (sxd_acl_ptar_op_t)ACL_REGION_HW_OP_DEALLOCATE_E;
    sx_acl_size_t              size = 0;
    sx_acl_size_t              rollback_size = 0;
    boolean_t                  hw_set = FALSE;
    uint32_t                   reserved_rules_num = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(devs_list);

    /* Get the reserved region */
    sx_status = flex_acl_db_region_reserved_get(&region_id);
    if (sx_status != SX_STATUS_SUCCESS) {
        goto out;
    }

    sx_status = flex_acl_db_region_get(region_id, &acl_region);
    if (sx_status != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (allocate_size) {
        /* Alloc or resize */
        size = allocate_size;
        if (size == acl_region->size) {
            sx_status = SX_STATUS_SUCCESS;
            goto out;
        }
        op =
            (sxd_acl_ptar_op_t)((acl_region->size !=
                                 FLEX_ACL_RULES_MIN) ? ACL_REGION_HW_OP_RESIZE_E : ACL_REGION_HW_OP_ALLOCATE_E);
        rollback_op =
            (sxd_acl_ptar_op_t)((acl_region->size !=
                                 FLEX_ACL_RULES_MIN) ? ACL_REGION_HW_OP_RESIZE_E : ACL_REGION_HW_OP_DEALLOCATE_E);
        rollback_size = (acl_region->size != FLEX_ACL_RULES_MIN) ? acl_region->size : 0;
    } else {
        size = 0;
        op = (sxd_acl_ptar_op_t)ACL_REGION_HW_OP_DEALLOCATE_E;
        rollback_op = (sxd_acl_ptar_op_t)ACL_REGION_HW_OP_ALLOCATE_E;
        rollback_size = acl_region->size;
    }

    /* Get all possible devices */
    hw_set = __flex_acl_enforce_min_for_devs(acl_region, op, rollback_op, TRUE, size, rollback_size);

    /* Update database (region size)*/
    switch (op) {
    case ACL_REGION_HW_OP_RESIZE_E:
        sx_status = flex_acl_db_region_resize_set(acl_region->region_id, size,
                                                  reserved_rules_num,
                                                  flex_acl_hw_copy_rule_ptr);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to update reserved region info in DB, region_id: %u\n", acl_region->region_id);
            goto out;
        }
        break;

    case ACL_REGION_HW_OP_DEALLOCATE_E:
        sx_status = __flex_acl_destroy_reserved_region(acl_region->region_id);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to update reserved region info in DB, region_id: %u\n", acl_region->region_id);
            goto out;
        }
        break;

    case ACL_REGION_HW_OP_ALLOCATE_E:
        sx_status = flex_acl_db_region_resize_set(acl_region->region_id, size,
                                                  reserved_rules_num,
                                                  NULL);
        if (sx_status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to update reserved region info in DB, region_id: %u\n", acl_region->region_id);
            goto out;
        }
        break;

    /* coverity[dead_error_begin] */
    default:
        sx_status = SX_STATUS_UNSUPPORTED;
        break;
    }

out: if (sx_status != SX_STATUS_SUCCESS) {
        if (hw_set) {
            __flex_acl_enforce_min_for_devs(acl_region, rollback_op, op, FALSE, rollback_size, size);
            hw_set = FALSE;
        }
    }
    SX_LOG_EXIT();
    return sx_status;
}


boolean_t __flex_acl_enforce_min_for_devs(flex_acl_db_acl_region_t *acl_region,
                                          sxd_acl_ptar_op_t         op,
                                          sxd_acl_ptar_op_t         rollback_op,
                                          boolean_t                 is_rollback_needed,
                                          sx_acl_size_t             size,
                                          sx_acl_size_t             rollback_size)
{
    uint8_t     dev_idx = 0;
    boolean_t   hw_set = FALSE;
    sx_dev_id_t devs_list[SX_DEV_NUM_MAX];
    uint16_t    dev_info_arr_size = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(devs_list);

    if (SX_STATUS_SUCCESS != flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size)) {
        SX_LOG_ERR("failed to get all devices list\n");
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    if (SX_STATUS_SUCCESS != __flex_acl_enforce_min_per_dev(acl_region, devs_list[dev_idx], (acl_region_op_e)op,
                                                            (acl_region_op_e)rollback_op, size, rollback_size,
                                                            is_rollback_needed)) {
        /* We cannot work on that device, which means we didn't get there yet. so no rollback needed */
        break;
    }

    hw_set = TRUE;
    SX_FDB_FOR_EACH_LEAF_DEV_END;
out:
    SX_LOG_EXIT();
    return hw_set;
}

/**
 *  This function is used to set:
 *  [SPC2+] Default actions rule that doesn't have keys and with fixed offset that used for DB reference only.
 *  [SPC1] Wildcard rule at the end of the region. region size is pre-allocated with num for reserved rules. *
 **/
static sx_status_t __flex_acl_region_default_actions_rule_set(sx_acl_region_id_t           region_id,
                                                              sx_acl_default_action_cfg_t *default_action_cfg_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_status_t                        rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t          *acl_region = NULL;
    flex_acl_db_flex_rule_t           *db_rule = 0;
    sx_api_flex_acl_rules_set_params_t rules_params = {.cmd = 0};
    sx_flex_acl_flex_rule_t            rule;
    sx_acl_rule_offset_t               offset = 0;
    sx_acl_key_t                      *user_keys = NULL;
    uint8_t                            user_keys_count = 0;
    uint32_t                           hw_key_handle = 0;
    system_acl_client_table_entry_t   *client_table_entry_p;

    SX_LOG_ENTER();

    if (default_action_cfg_p->action_count == 0) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    if (default_action_cfg_p->action_count > SX_ACL_DEFAULT_ACTION_CNT_MAX) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("ACL : Default actions count [%d] exceeds the max [%d]\n",
                   default_action_cfg_p->action_count,
                   SX_ACL_DEFAULT_ACTION_CNT_MAX);
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL region id [%u]\n", region_id);
        goto out;
    }

    /* Check system ACL */
    if (acl_region->entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
        rc = system_acl_client_get(acl_region->region_id, &client_table_entry_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : cannot find system ACL region id [%u] in client table\n", acl_region->region_id);
            goto out;
        }
        if (client_table_entry_p->wc_rule_type == SYSTEM_ACL_WC_RULE_TYPE_NONE_E) {
            /* No need in WC rule */
            rc = SX_STATUS_SUCCESS;
            goto out;
        }
    }

    rc = flex_acl_db_get_flex_key_entry(acl_region->key_handle, &user_keys, &user_keys_count, &hw_key_handle);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("get flex_key_entry error, key_handle: %u\n", acl_region->key_handle);
        goto out;
    }

    memset(&rules_params, 0, sizeof(sx_api_flex_acl_rules_set_params_t));
    memset(&rule, 0, sizeof(rule));
    rc = sx_lib_flex_acl_rule_init(acl_region->key_handle, default_action_cfg_p->action_count, &rule);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("sx_lib_flex_acl_rule_init error, key_handle: %u\n", acl_region->key_handle);
        goto out;
    }

    /* Create rule params for rules update function */
    if (ACL_STAGE_IS_FLEX2_OR_ABOVE(g_acl_stage)) {
        offset = SX_ACL_DEFAULT_ACTION_OFFSET;
        rule.key_desc_count = 0; /* Default actions rule doesn't have keys */
        rule.priority = 0;
    } else {
        offset = acl_region->size - 1;
        rule.key_desc_count = 1;
        rule.key_desc_list_p[0].key_id = user_keys[0];
    }

    rules_params.cmd = SX_ACCESS_CMD_SET;
    rules_params.region_id = region_id;
    rules_params.rules_count = 1;
    rules_params.offsets_list_p = &offset;
    rules_params.rules = &rule;
    rules_params.rules[0].valid = TRUE;
    SX_MEM_CPY_ARRAY(rules_params.rules[0].action_list_p,
                     default_action_cfg_p->action_list,
                     default_action_cfg_p->action_count,
                     sx_flex_acl_flex_action_t);

    /* Action fields validation. Skip the validation if only a NOP action */
    if ((default_action_cfg_p->action_count > 1) ||
        (default_action_cfg_p->action_list[0].type != SX_FLEX_ACL_ACTION_FORWARD)) {
        rc = flex_acl_actions_validate(&(rules_params.rules[0]), acl_region, TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL : Failed default actions validation for region id %u.\n",
                       acl_region->region_id);
            goto out;
        }
    }

    /* create db rule structure from regular rule */
    rc = flex_acl_db_allocate_and_fill_rules(rules_params.rules,
                                             rules_params.offsets_list_p,
                                             rules_params.rules_count,
                                             &db_rule);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Error in allocating rules memory.\n");
        goto rule_deinit;
    }
    /* add rule to the region */
    rc = __flex_acl_rules_update(region_id, db_rule, rules_params.rules_count, acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc, "__flex_acl_rules_update failed, region:%#x rc:%s\n",
                                 acl_region->region_id, sx_status_str(rc));
        goto free_rules;
    }

free_rules:
    rb_rc = flex_acl_db_free_rules(db_rule, rules_params.rules_count);
    if (SX_STATUS_SUCCESS != rb_rc) {
        SX_LOG_ERR("ACL : Failed free rules\n");
    }
rule_deinit:
    sx_lib_flex_acl_rule_deinit(&rule);
out:
    SX_LOG_EXIT();
    return rc;
}

/* This function should be called whenever there is a need to re-write the action list on a rule.
 * A new kvd action list will be allocated filled with the correct values and connected to the rule -
 * replacing by thus the old actions list. This function is usually needed when an external resource has changed
 * (such as: PBS container) that alters the actions list. The DB of the actions should be updated before calling
 * this function. NOTE: This function temporarily allocates additional kvd resources for the new actions.
 */
sx_status_t __flex_acl_rewrite_rule_actions(sx_acl_region_id_t region_id, sx_acl_rule_offset_t offset)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_status_t               rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_flex_rule_t  *original_rule = NULL;
    flex_acl_db_flex_rule_t  *db_rule = NULL;
    flex_acl_db_acl_region_t *acl_region = NULL;
    sx_flex_acl_flex_rule_t   rule;

    SX_LOG_ENTER();

    memset(&rule, 0, sizeof(rule));

    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get region [%u] for rewrite rule actions\n", region_id);
        goto out;
    }

    rc = flex_acl_db_get_rule_by_offset(region_id, offset, &original_rule);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get region [%u] offset [%u] for rewrite rule actions\n", region_id, offset);
        goto out;
    }

    rule.valid = original_rule->valid;
    rule.key_desc_count = original_rule->key_desc_count;
    rule.key_desc_list_p = original_rule->key_desc_list;
    rule.action_count = original_rule->action_count;
    rule.action_list_p = original_rule->actions;
    rule.priority = original_rule->priority;

    /* create db rule structure from regular rule */
    rc = flex_acl_db_allocate_and_fill_rules(&rule, &offset, 1, &db_rule);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error in allocating rules memory.\n");
        goto out;
    }
    /* add rule to the region */
    rc = __flex_acl_rules_update(region_id, db_rule, 1, acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc, "__flex_acl_rules_update failed, region:%#x rc:%s\n",
                                 acl_region->region_id, sx_status_str(rc));
        goto free_rules;
    }

free_rules:
    rb_rc = flex_acl_db_free_rules(db_rule, 1);
    if (SX_STATUS_SUCCESS != rb_rc) {
        SX_LOG_ERR("ACL : Failed free rules\n");
    }
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_region_wc_rule_set(sx_acl_region_id_t region_id)
{
    sx_acl_default_action_cfg_t default_action_cfg;
    sx_status_t                 rc = SX_STATUS_SUCCESS;

    if (!flex_acl_ops_g->acl_wc_rule_needed_p()) {
        /* No need in WC rule */
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    SX_MEM_CLR(default_action_cfg);

    default_action_cfg.action_list[0].type = SX_FLEX_ACL_ACTION_FORWARD;
    default_action_cfg.action_list[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT;
    default_action_cfg.action_count = 1;

    rc = __flex_acl_region_default_actions_rule_set(region_id, &default_action_cfg);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL action : Failed set rule in region id [%d] for default actions.\n", region_id);
        goto out;
    }

out:
    return rc;
}

/* The function free inner references of wild card rule */
static sx_status_t __flex_acl_invalidate_wild_card_rule(sx_acl_region_id_t region_id)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t        *acl_region = NULL;
    sx_flex_acl_rule_offset_t        offset = 0;
    uint32_t                         valid_rules_num_old = 0;
    system_acl_client_table_entry_t *client_table_entry_p;
    flex_acl_db_flex_rule_t         *rule = NULL, help_rule;

    SX_LOG_ENTER();

    if (!flex_acl_ops_g->acl_wc_rule_needed_p()) {
        /* No need in WC rule */
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to find ACL id [%u]\n", region_id);
        goto out;
    }

    /* Check system ACL */
    if (acl_region->entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
        rc = system_acl_client_get(acl_region->region_id, &client_table_entry_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL : cannot find system ACL region id [%u] in client table\n", acl_region->region_id);
            goto out;
        }
        if (client_table_entry_p->wc_rule_type == SYSTEM_ACL_WC_RULE_TYPE_NONE_E) {
            /* No need in WC rule */
            rc = SX_STATUS_SUCCESS;
            goto out;
        }
    }

    offset = acl_region->size - 1;

    /* Now delete the rule from the hw */
    rc = flex_acl_db_get_rule_by_offset(region_id, offset, &rule);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to get rule from db for offset [%u]\n", offset);
        goto out;
    }

    /* Temporarily set the rule as invalid so to delete it from hw */
    help_rule = *rule;
    help_rule.valid = FLEX_ACL_RULE_INVALID;
    /* Remove the rule from the hw */
    rc = __flex_acl_update_rules_to_devs(acl_region,
                                         &help_rule,
                                         1,
                                         FLEX_ACL_HW_FULL_WRITE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to write rules to dev \n");
        goto out;
    }

    SX_LOG_DBG("Region:%u delete wild card rule:%d \n", region_id, offset);
    rc = __flex_acl_rules_keys_ref_update(rule, FALSE, region_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL:  failed to delete ref count for keys. region:%d offset :%d\n",
                   rule->region_id,
                   rule->offset);
        goto out;
    }
    rc = __flex_acl_dec_actions_ref(rule, region_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to decrease ref count, region_id: %u\n", region_id);
        goto out;
    }

    valid_rules_num_old = acl_region->valid_rules_num;

    rc = flex_acl_db_invalidate_rules(region_id, &offset, 1);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to invalidate rules for region id [%u]\n", region_id);
        goto out;
    }

    rc = flex_acl_rm_entries_set(acl_region->valid_rules_num, valid_rules_num_old,
                                 acl_region);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("failed set entries in resource manager\n");
    }
out:
    SX_LOG_EXIT();
    return rc;
}


/* [SPC2+] The function free inner references of default action rule */
static sx_status_t __flex_acl_invalidate_default_action(sx_acl_region_id_t region_id)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *acl_region = NULL;
    sx_flex_acl_rule_offset_t offset = 0;
    flex_acl_db_flex_rule_t  *rule = NULL;

    SX_LOG_ENTER();

    if (!flex_acl_ops_g->acl_default_action_needed_p()) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to find ACL region id [%u]\n", region_id);
        goto out;
    }

    offset = SX_ACL_DEFAULT_ACTION_OFFSET;

    rc = flex_acl_db_get_rule_by_offset(region_id, offset, &rule);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to get rule from db for offset [%u]\n", offset);
        goto out;
    }

    SX_LOG_DBG("Region:%u Delete unbind rule:%d \n", region_id, offset);
    rc = __flex_acl_delete_rule_refs(region_id, rule);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL:  failed to delete refs for delete default rules. region:%d offset :%d\n",
                   region_id,
                   rule->offset);
        goto out;
    }

    /* HW Free of KVD entries that used for the extended default actions */
    rc = flex_acl_hw_free_kvd(region_id, offset);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: Failed to free kvd, region_id: %u, offset: %u\n", region_id, offset);
        goto out;
    }

    /* Delete From DB all inner default actions references.*/
    rc = flex_acl_db_invalidate_rules(region_id, &offset, 1);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to invalidate default actions rule for region id [%u]\n", region_id);
        goto out;
    }

    /* HW write a NOP action to pre-allocated KVD block */
    rc = flex_acl_write_default_action(region_id, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to init HW default action for region id [%u]\n", region_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* the reserved region are created without wild card rule */
static sx_status_t __flex_acl_create_reserved_region(sx_api_acl_region_set_params_t *params)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    sx_status_t                     rb_rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t attribs;
    uint32_t                        reserved_rules_num = 0;
    sx_acl_key_t                    keys[RM_API_ACL_MAX_FIELDS_IN_KEY] = {0};
    sx_acl_key_type_t               key_type = SX_ACL_KEY_TYPE_RESERVED;


    SX_LOG_ENTER();

    SX_MEM_CLR(attribs);
    SX_MEM_CLR(keys);

    keys[0] = FLEX_ACL_KEY_DIP;
    keys[1] = FLEX_ACL_KEY_SIP;
    keys[2] = FLEX_ACL_KEY_L4_SOURCE_PORT;
    keys[3] = FLEX_ACL_KEY_L4_DESTINATION_PORT;
    keys[4] = FLEX_ACL_KEY_TTL;
    keys[5] = FLEX_ACL_KEY_IP_PROTO;
    keys[6] = FLEX_ACL_KEY_IP_OK;
    keys[7] = FLEX_ACL_KEY_L4_OK;
    keys[8] = FLEX_ACL_KEY_IS_IP_V4;
    keys[9] = FLEX_ACL_KEY_IP_OPT;
    keys[10] = FLEX_ACL_KEY_IP_FRAGMENT_NOT_FIRST;
    keys[11] = FLEX_ACL_KEY_L4_TYPE;
    keys[12] = FLEX_ACL_KEY_IS_ARP;
    keys[13] = FLEX_ACL_KEY_SRC_PORT;
    keys[14] = FLEX_ACL_KEY_DST_PORT;
    keys[15] = FLEX_ACL_KEY_DSCP;
    keys[16] = FLEX_ACL_KEY_ECN;
    keys[17] = FLEX_ACL_KEY_TCP_CONTROL;
    keys[18] = FLEX_ACL_KEY_TCP_ECN;
    keys[19] = FLEX_ACL_KEY_L4_PORT_RANGE;
    rc = flex_acl_create_basic_key(g_acl_stage, keys, 20, &key_type);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Failed creation of basic key reserved\n");
        goto out;
    }


    rc = flex_acl_db_region_allocate(&params->region_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to allocate ACL id \n");
        goto out;
    }

    rc = flex_acl_db_region_params_set(params->region_id, params->region_size,
                                       params->key_type, reserved_rules_num, FALSE, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set ACL attributes, region_id: %u, region_size: %u, key_handle: %u\n",
                   params->region_id, params->region_size, params->key_type);
        goto destroy_region;
    }

    rc = flex_acl_hw_region_attribs_set(params->region_id, &attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set hw attributes for region id %d\n", params->region_id);
        goto destroy_region;
    }

    rc = flex_acl_db_region_reserved_set(params->region_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL DB: Failed to set acl reserved region attributes, region_id: %u\n", params->region_id);
        goto destroy_region;
    }

    goto out;

destroy_region:
    /* will free all rules that was allocated */
    if (SX_CHECK_FAIL(rb_rc = flex_acl_db_region_destroy(params->region_id, &(params->region_size)))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_destroy_reserved_region(sx_acl_region_id_t region_id)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    sx_status_t                     rb_rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t rollback_attribs;
    uint32_t                        rollback_size = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(rollback_attribs);

    rc = flex_acl_hw_region_attribs_remove(region_id, &rollback_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to remove region attributes for region id [%u]\n",
                   region_id);
        goto out;
    }

    rc = flex_acl_db_region_reserved_set(FLEX_ACL_INVALID_REGION_ID);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to remove region attributes for region id [%u]\n",
                   region_id);
        goto attribs_set;
    }

    rc = flex_acl_db_region_destroy(region_id, &rollback_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to destroy region id [%u]\n", region_id);
        goto reserved_set;
    }

    rc = flex_acl_remove_basic_key(SX_ACL_KEY_TYPE_RESERVED);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed removal of basic key reserved");
        goto out;
    }

    goto out;
reserved_set:
    if (SX_CHECK_FAIL(rb_rc = flex_acl_db_region_reserved_set(region_id))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
attribs_set:
    if (SX_CHECK_FAIL(rb_rc = flex_acl_hw_region_attribs_set(region_id, &rollback_attribs))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_acl_create_new_region(sx_api_acl_region_set_params_t *params,
                                                uint32_t                        reserved_rules_num,
                                                system_acl_client_id_e          client_id,
                                                boolean_t                       stateful_db_region)
{
    sx_status_t                                 rc = SX_STATUS_SUCCESS;
    sx_status_t                                 rb_rc = SX_STATUS_SUCCESS;
    flex_acl_hw_db_region_attribs_t             attribs;
    flex_acl_db_acl_region_t                   *region = NULL;
    sx_api_acl_flex_default_action_set_params_t default_action_params;

    SX_LOG_ENTER();

    SX_MEM_CLR(attribs);

    rc = flex_acl_db_region_allocate(&params->region_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to allocate region id \n");
        goto out;
    }

    rc = flex_acl_db_region_params_set(params->region_id, params->region_size + reserved_rules_num,
                                       params->key_type, reserved_rules_num, FALSE, stateful_db_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set ACL attributes, region_id: %u, region_size: %u, key_handle: %u\n",
                   params->region_id, params->region_size + reserved_rules_num, params->key_type);
        goto destroy_region;
    }

    rc = flex_acl_hw_region_attribs_set(params->region_id, &attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set hw attributes for region id %d\n", params->region_id);
        goto destroy_region;
    }
    /* For system ACL we might need to change the register update functions. */
    if (client_id != SYSTEM_ACL_CLIENT_ID_INVALID_E) {
        rc = system_acl_set_register_callbacks(client_id, params->region_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set region hw callbacks for system region id[%u]\n", params->region_id);
            goto destroy_region;
        }
    }

    rc = flex_acl_db_region_get(params->region_id, &region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to get region, region_id [%u].\n", params->region_id);
        goto destroy_region;
    }

    /* [SPC2+] Set the default action for the region. */
    if (flex_acl_ops_g->acl_default_action_needed_p()) {
        default_action_params.cmd = SX_ACCESS_CMD_UNSET; /* Set a NOP action as a default action */
        default_action_params.region_id = region->region_id;

        rc = flex_acl_default_actions_set(&default_action_params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to set hw default action for region id %d\n", params->region_id);
            goto destroy_region;
        }
    }

    /* Write the new region to the hw */
    rc = flex_acl_hw_region_update(region, ACL_REGION_HW_OP_ALLOCATE_E, region->size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to write region [%u] to HW.\n", params->region_id);
        goto destroy_region;
    }

    goto out;

destroy_region:
    /* will free all rules that was allocated */
    rb_rc = flex_acl_db_region_destroy(params->region_id, &(params->region_size));
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_acl_resize_region(flex_acl_db_acl_region_t *acl_region,
                                            sx_acl_size_t             from_size,
                                            sx_acl_size_t             to_size,
                                            boolean_t                 is_rollback)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_status_t                      rb_st = SX_STATUS_SUCCESS;
    sx_api_acl_block_move_params_t   block_move_params = {.region_id = 0};
    uint32_t                         dev_idx = 0;
    sx_dev_id_t                      devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t                         dev_info_arr_size = 0;
    boolean_t                        no_wc_rule = FALSE;
    system_acl_client_table_entry_t *client_table_entry_p;

    SX_LOG_ENTER();

    block_move_params.region_id = acl_region->region_id;
    block_move_params.block_size = 1;
    block_move_params.block_start = from_size - acl_region->reserved_rules_num;
    block_move_params.new_block_start = to_size - acl_region->reserved_rules_num;

    if (!flex_acl_ops_g->acl_wc_rule_needed_p()) {
        no_wc_rule = TRUE;
    } else if (acl_region->entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) {
        /* Check system ACL */
        rc = system_acl_client_get(acl_region->region_id, &client_table_entry_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : cannot find system ACL region id [%u] in client table\n", acl_region->region_id);
            goto out;
        }
        if (client_table_entry_p->wc_rule_type == SYSTEM_ACL_WC_RULE_TYPE_NONE_E) {
            /* No need in WC rule */
            no_wc_rule = TRUE;
        }
    }

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get all devices \n");
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    /* if size is decreased, move the wild card rule in FW before ptar update*/
    if ((to_size < from_size) && !no_wc_rule) {
        rc = flex_acl_hw_rule_move(&block_move_params, devs_list[dev_idx], acl_region, !no_wc_rule);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to move wild card rule\n");
            goto out;
        }
    }

    rc = flex_acl_hw_region_update(acl_region, ACL_REGION_HW_OP_RESIZE_E, to_size);
    if ((rc != SX_STATUS_SUCCESS) && !is_rollback) {
        /* rollback: move back the wild card rule if size decreased */
        if ((to_size < from_size) && !no_wc_rule) {
            block_move_params.block_start = to_size - acl_region->reserved_rules_num;
            block_move_params.new_block_start = from_size - acl_region->reserved_rules_num;

            rb_st = flex_acl_hw_rule_move(&block_move_params, devs_list[dev_idx], acl_region, !no_wc_rule);
            if (SX_CHECK_FAIL(rb_st)) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
            }
        }
        goto out;
    }

    /* if size is increased, move the wild card rule in FW (after PTAR update) */
    if ((to_size > from_size) && !no_wc_rule) {
        rc = flex_acl_hw_rule_move(&block_move_params, devs_list[dev_idx], acl_region, !no_wc_rule);
        /* if failed to move rule, roll back to original size (PTAR already accessed) */
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("failed to move rules at hw\n");
            rb_st = flex_acl_hw_region_update(acl_region,
                                              ACL_REGION_HW_OP_RESIZE_E,
                                              from_size);
            if (SX_CHECK_FAIL(rb_st)) {
                SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
            }
            goto out;
        }
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_region_is_bound(sx_acl_region_id_t region_id, boolean_t *is_bound)
{
    flex_acl_db_acl_region_t *region = NULL;
    sx_status_t               rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    *is_bound = FALSE;

    rc = flex_acl_db_region_get(region_id, &region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find region id [%u]\n", region_id);
        goto out;
    }

    if (region->bound_acl != FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG_ERR("ACL : ACL region [%u] is bound to an ACL table %d\n", region_id, region->bound_acl);
        *is_bound = TRUE;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_resize_acl_region(sx_api_acl_region_set_params_t *params,
                                                uint32_t                       *region_size_ret)
{
    flex_acl_db_acl_region_t *acl_region = NULL;
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_status_t               rb_rc = SX_STATUS_SUCCESS;
    sx_acl_size_t             region_new_size = 0;
    sx_acl_size_t             region_old_size = 0;
    boolean_t                 size_hit = FALSE;

    UNUSED_PARAM(region_size_ret);

    SX_LOG_ENTER();

    rc = flex_acl_db_region_get(params->region_id, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL region id [%u]\n", params->region_id);
        goto out;
    }
    region_old_size = acl_region->size; /* region old size contain wild card rule */
    region_new_size = params->region_size + acl_region->reserved_rules_num; /* region new size also contain wild card rule */

    if (region_new_size == region_old_size) {
        SX_LOG_ERR("ACL : No change in region size, ACL region id [%u],\n", params->region_id);
        goto out;
    }

    /* Check if all existing rules can fit in new region size */
    rc =
        flex_acl_db_region_size_validate(params->region_id, region_new_size, acl_region->reserved_rules_num,
                                         &size_hit);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed validation of region size, region_id: %u, region new size: %u\n",
                   params->region_id, region_new_size);
        goto out;
    }
    if (FALSE == size_hit) {
        SX_LOG_ERR("ACL : Cannot resize existing ACL region [%u] to size [%d], it contains rules in higher offsets\n",
                   params->region_id, params->region_size);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_db_region_resize_set(acl_region->region_id,
                                       region_new_size,
                                       acl_region->reserved_rules_num,
                                       flex_acl_hw_copy_rule_ptr);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to resize region in DB, region id [%u]\n", acl_region->region_id);
        /* Rollback */
        goto out;
    }

    rc = __flex_acl_resize_region(acl_region, region_old_size, region_new_size, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc,
                                 "ACL : Failed to resize region [%#x]. rc=%s\n",
                                 acl_region->region_id, sx_status_str(rc));
        goto set_db_resize;
    }

    goto out;

set_db_resize:
    rb_rc = flex_acl_db_region_resize_set(acl_region->region_id,
                                          region_old_size,
                                          acl_region->reserved_rules_num,
                                          flex_acl_hw_copy_rule_ptr);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_destroy_acl_region(sx_api_acl_region_set_params_t *params,
                                                 uint32_t                       *region_size)
{
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    boolean_t                       is_bound = FALSE;
    flex_acl_hw_db_region_attribs_t rollback_attribs;
    boolean_t                       valid_rules_exist = FALSE;
    flex_acl_db_acl_region_t       *region = NULL;

    SX_LOG_ENTER();

    SX_MEM_CLR(rollback_attribs);

    /* This will clear resources, allowed only on non-dirty ACL*/
    rc = __flex_acl_region_is_bound(params->region_id, &is_bound);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Can not check region bound or not, id [%u]\n", params->region_id);
        goto out;
    }
    if (is_bound) {
        SX_LOG_ERR("ACL : Can not destroy bound ACL region [%u]\n", params->region_id);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }
    rc = __flex_acl_is_region_have_valid_rules(params->region_id, &valid_rules_exist);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at valid rules validation, region_id: %u\n", params->region_id);
        goto out;
    }
    if (valid_rules_exist) {
        SX_LOG_ERR("The region can't be destroyed, still have valid rules\n");
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    rc = __flex_acl_invalidate_default_action(params->region_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to invalidate default actions for region id %d\n", params->region_id);
        goto out;
    }

    rc = __flex_acl_invalidate_wild_card_rule(params->region_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to invalidate wild card rule, region_id: %u\n", params->region_id);
        goto out;
    }

    rc = flex_acl_db_region_get(params->region_id, &region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to get region, region_id [%u].\n", params->region_id);
        goto out;
    }

    rc = flex_acl_hw_region_update(region, ACL_REGION_HW_OP_DEALLOCATE_E, 0);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to deallocated hw region, region_id [%u].\n", params->region_id);
        goto out;
    }

    rc = flex_acl_hw_region_attribs_remove(params->region_id, &rollback_attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to destroy region id [%u]\n", params->region_id);
    }

    rc = flex_acl_db_region_destroy(params->region_id, region_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to destroy region id [%u]\n",
                   params->region_id);
    }

    goto out;

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_update_rm(uint32_t               region_new_size,
                                        uint32_t               region_old_size,
                                        system_acl_client_id_e client_id,
                                        sx_acl_key_type_t      key_handle)
{
    sx_access_cmd_t                  rm_cmd = SX_ACCESS_CMD_NONE;
    uint32_t                         rm_cnt = 0;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    system_acl_client_table_entry_t *client_p;
    rm_sdk_table_params_t            params;
    rm_sdk_table_type_e              resource;


    SX_LOG_ENTER();

    /* try to get client entry, if such does not exist - simple continue execution */
    rc = system_acl_client_get_by_id(client_id, &client_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL :Failed to get system client entry, client_id[%u], err = %s\n", client_id, sx_status_str(rc));
        goto out;
    }
    if ((client_id != SYSTEM_ACL_CLIENT_ID_INVALID_E) && !client_p->is_rules_rm_needed) {
        goto out;
    }

    if (region_new_size > region_old_size) {
        rm_cmd = SX_ACCESS_CMD_ADD;
        rm_cnt = region_new_size - region_old_size;
    } else if (region_new_size < region_old_size) {
        rm_cmd = SX_ACCESS_CMD_DELETE;
        rm_cnt = region_old_size - region_new_size;
    } else {
        goto out; /* if equal return success */
    }
    SX_LOG_DBG("rm_allocate_entries_check and update: cmd = %s, count = %u\n",
               rm_cmd == SX_ACCESS_CMD_ADD ? "add" : "delete",
               rm_cnt);

    params.attrs.acl_attr.is_ctcam = TRUE;

    rc = flex_acl_get_rm_resource(key_handle, &resource);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Could not get ACL resource type, key_handle = %u\n", key_handle);
        goto out;
    }


    /* Makes sure RM allows the allocation */
    rc = rm_allocate_entries_check(resource, rm_cmd, rm_cnt, &params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc,
                                 "ACL : RM Denied to %s ACL Rules status = %d \n",
                                 (rm_cmd == SX_ACCESS_CMD_ADD) ? "Allocate" : "Free",
                                 rc);
        goto out;
    }

    rc = rm_allocate_entries_update(resource, rm_cmd, rm_cnt,  &params);
    SX_LOG_DBG("Update cmd %d, entries %d\n", rm_cmd, rm_cnt);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : RM Denied to %s ACL Rules\n", (rm_cmd == SX_ACCESS_CMD_ADD) ? "Allocate" : "Free");
    }
out:
    SX_LOG_EXIT();
    return rc;
}


/**
 *  This function is used to create ACL region (rules list).
 *  for creation use command CREATE and supply key_type and
 *  size. region_id is returned on successful creation.
 *  for destroying an ACL region it is required that the ACL
 *  region is not bound and the region_id should be provided.
 *  EDIT command is used for resizing an existing ACL region.
 *  region_id and new size should be provided.
 *
 * @param[in] params - struct with relevant parameters
 * @param[in] client id - client id of system acl group.
 *                        User should pass SYSTEM_ACL_CLIENT_ID_INVALID_E
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *  @return SX_STATUS_PARAM_ERROR if any input parameter is
 *  invalid
 *  @return SX_STATUS_ENTRY_NOT_FOUND if requested element is
 *  not found in DB
 *  @return SX_STATUS_NO_RESOURCES if no ACL is available to
 *  create
 *  @return SX_STATUS_CMD_UNSUPPORTED if unsupported command is
 *  requested
 */
static sx_status_t __flex_acl_region_set_internal(sx_api_acl_region_set_params_t *params,
                                                  system_acl_client_id_e          client_id,
                                                  boolean_t                       stateful_db_region)
{
    sx_api_flex_acl_key_get_params_t key_params = {.key_handle = 0};
    sx_status_t                      rc = SX_STATUS_SUCCESS, rb_st = SX_STATUS_SUCCESS;
    uint32_t                         region_old_size = 0;
    uint32_t                         region_new_size = 0;
    flex_acl_db_acl_region_t        *region = NULL;
    uint32_t                         reserved_rules_num = RESERVED_FLEX_ACL_RULES_NUM;
    system_acl_client_table_entry_t *client_table_entry_p = NULL;
    boolean_t                        region_rm_updated = FALSE;

    SX_LOG_ENTER();
    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    /**** Check input parameters */
    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (params->cmd == SX_ACCESS_CMD_CREATE) {
        key_params.key_handle = params->key_type;
        if (flex_acl_key_get(&key_params) != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: key_handler is invalid \n");
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
    }
    if (params->cmd != SX_ACCESS_CMD_DESTROY) {
        if (params->region_size > rm_resource_global.acl_region_size_max) {
            SX_LOG_ERR("ACL: acl_size has invalid value [%u]\n", params->region_size);
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
    }

    /* first update the rm */
    if (params->cmd != SX_ACCESS_CMD_CREATE) {
        rc = flex_acl_db_region_get(params->region_id, &region);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL:filed to get acl region, region_id: %u\n", params->region_id);
            goto out;
        }

        if ((region->entry_type == FLEX_ACL_ENTRY_TYPE_USER_E) && (client_id != SYSTEM_ACL_CLIENT_ID_INVALID_E)) {
            SX_LOG_ERR("ACL: Illegal state of region entry\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        if ((region->entry_type == FLEX_ACL_ENTRY_TYPE_SYSTEM_E) && (client_id == SYSTEM_ACL_CLIENT_ID_INVALID_E)) {
            SX_LOG_ERR("ACL: Client id  INVALID for SYSTEM_ENTRY_TYPE region\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    if (!flex_acl_ops_g->acl_wc_rule_needed_p()) {
        reserved_rules_num = 0;
    } else if (client_id != SYSTEM_ACL_CLIENT_ID_INVALID_E) {
        /* invalidate space for wild card rule */
        rc = system_acl_client_get_by_id(client_id, &client_table_entry_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : cannot find system ACL entry for client[%u]\n", client_id);
            goto out;
        }
        if (client_table_entry_p->wc_rule_type == SYSTEM_ACL_WC_RULE_TYPE_NONE_E) {
            /* No need in WC rule */
            reserved_rules_num = 0;
        }
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        region_old_size = 0;
        region_new_size = params->region_size + reserved_rules_num;
        rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_E, SX_ACCESS_CMD_ADD, 1, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR_RESOURCE_COND(rc, "ACL: No resources available to create region: rc=%d", rc);
            goto out;
        }
        region_rm_updated = TRUE;

        break;

    case SX_ACCESS_CMD_EDIT:

        region_new_size = params->region_size + reserved_rules_num;
        region_old_size = region->size;

        if (region_new_size == region_old_size) {
            return rc;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        region_new_size = 0;
        region_old_size = region->size;
        rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_E, SX_ACCESS_CMD_DELETE, 1, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR_RESOURCE_COND(rc, "ACL: Failed to delete region from RM rc = %d\n", rc);
            goto out;
        }
        region_rm_updated = TRUE;

        break;

    default:
        SX_LOG_ERR("Command is not supported.\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    rc = __flex_acl_update_rm(region_new_size, region_old_size, client_id, params->key_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc, "ACL: Failed to update rm [%u] at region set rc = %d\n", params->region_size, rc);
        goto rollback_region;
    }

    /* perform operation actually */
    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        rc = __flex_acl_create_new_region(params, reserved_rules_num, client_id, stateful_db_region);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to create new ACL region[%#x] rc:%s\n",
                       params->region_id, sx_status_str(rc));
            goto exit;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        rc = __flex_acl_resize_acl_region(params, &region_old_size);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR_RESOURCE_COND(rc,
                                     "ACL : Failed to resize ACL region [%#x]. rc=%s\n",
                                     params->region_id, sx_status_str(rc));
            goto exit;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        rc = __flex_acl_destroy_acl_region(params, &region_old_size);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to destroy ACL region [%#x] rc:%s\n",
                       params->region_id, sx_status_str(rc));
            goto exit;
        }
        break;

    default:
        SX_LOG_ERR("Command is not supported.\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto exit;
    }
    goto out;

exit:
    rb_st = __flex_acl_update_rm(region_old_size, region_new_size, client_id, params->key_type);
    if (SX_CHECK_FAIL(rb_st)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
    }

rollback_region:
    if (region_rm_updated) {
        if (params->cmd == SX_ACCESS_CMD_CREATE) {
            rb_st = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_E, SX_ACCESS_CMD_DELETE, 1, NULL);
        } else if (params->cmd == SX_ACCESS_CMD_DESTROY) {
            rb_st = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_E, SX_ACCESS_CMD_ADD, 1, NULL);
        }
        if (SX_CHECK_FAIL(rb_st)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_st));
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_region_set_internal(sx_api_acl_region_set_params_t *params, system_acl_client_id_e client_id)
{
    return __flex_acl_region_set_internal(params, client_id, FALSE);
}

sx_status_t flex_acl_stateful_db_region_set_internal(sx_api_acl_region_set_params_t *params)
{
    return __flex_acl_region_set_internal(params, SYSTEM_ACL_CLIENT_ID_INVALID_E, TRUE);
}

/**
 *  This function is used to create ACL region (rules list).
 *  for creation use command CREATE and supply key_type and
 *  size. region_id is returned on successful creation.
 *  for destroying an ACL region it is required that the ACL
 *  region is not bound and the region_id should be provided.
 *  EDIT command is used for resizing an existing ACL region.
 *  region_id and new size should be provided.
 *
 * @param[in] params - struct with relevant parameters
 * @param[in] default_action - default action for wild card rule
 * @param[in] default_action_attr - attributes for provided action
 * @param[in] wildcard_rule_flow_counter - flow counter for wild card rule
 *
 *  @return SX_STATUS_SUCCESS if operation completes successfully
 *  @return SX_STATUS_PARAM_ERROR if any input parameter is
 *   invalid
 *  @return SX_STATUS_ENTRY_NOT_FOUND if requested element is
 *   not found in DB
 *  @return SX_STATUS_NO_RESOURCES if no ACL is available to
 *   create
 *  @return SX_STATUS_CMD_UNSUPPORTED if unsupported command is
 *   requested
 */
/* the function separates user level from system level and checks that id provided by user is
 * not id belonging to system */
sx_status_t flex_acl_region_set(sx_api_acl_region_set_params_t *params)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e     entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;
    flex_acl_db_acl_region_t *acl_region = NULL;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if ((params->cmd == SX_ACCESS_CMD_EDIT) || (params->cmd == SX_ACCESS_CMD_DESTROY)) {
        /* check that region id is not system */
        rc = flex_acl_db_region_entry_type_get(params->region_id, &entry_type);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get region entry type, region_id[%#x].\n", params->region_id);
            goto out;
        }
        if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
            SX_LOG_ERR("ACL: Region access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        /* Get Key Type for RM */

        rc = flex_acl_db_region_get(params->region_id, &acl_region);
        if (SX_STATUS_SUCCESS == rc) {
            params->key_type = acl_region->key_handle;
        } else {
            SX_LOG_ERR("Failed to get region id [%u]\n", params->region_id);
            goto out;
        }
    }

    rc = flex_acl_region_set_internal(params, SYSTEM_ACL_CLIENT_ID_INVALID_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc, "ACL: Region set failed. region_id[%#x]\n", params->region_id);
        goto out;
    }

    if (params->cmd == SX_ACCESS_CMD_CREATE) {
        rc = flex_acl_region_wc_rule_set(params->region_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: wildcard rule set failed. region_id[%#x]\n", params->region_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_redirect_region_set(sx_api_acl_region_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* first find if exist */
    rc = flex_acl_region_set(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc, "Error at find region_id[%#x] record\n", params->region_id);
        goto out;
    }

    if (params->cmd == SX_ACCESS_CMD_CREATE) {
        rc = flex_acl_redirect_db_add_region(params->region_id, params->action_type);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at adding region id[%u] to redirection db\n", params->region_id);
        }
    } else if (params->cmd == SX_ACCESS_CMD_DESTROY) {
        rc = flex_acl_redirect_db_remove_region_entry(params->region_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Error at remove region id[%u] from redirection db\n", params->region_id);
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_redirect_region_get(sx_api_acl_region_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_region_get(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed at region get redirection, region_id[%#x]\n", params->region_id);
        goto out;
    }

    flex_acl_redirection_get_region_record(params->region_id, &params->action_type);

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_region_get_internal(sx_api_acl_region_set_params_t *params)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *acl_region = NULL;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    rc = flex_acl_db_region_get(params->region_id, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Region get error, region_id[%#x]\n", params->region_id);
        goto out;
    }

    rc = flex_acl_db_region_params_get(params->region_id, &params->region_size, &params->key_type);
    params->region_size -= acl_region->reserved_rules_num;

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_region_get(sx_api_acl_region_set_params_t *params)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* checks if Region ID is legal */
    if (FLEX_ACL_REGION_BIT_CHECK(params->region_id)) {
        SX_LOG_ERR("ACL: Region ID is not valid, region_id[%#x].\n", params->region_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_db_region_entry_type_get(params->region_id, &entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get region entry type, region_id[%#x].\n", params->region_id);
        goto out;
    }

    if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL: Region access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_region_get_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get params for region_id[%#x].\n", params->region_id);
    }

out:
    SX_LOG_EXIT();
    return rc;
}


/* The function writes rules to dev */
static sx_status_t __flex_acl_update_rules_to_devs(flex_acl_db_acl_region_t *acl_region,
                                                   flex_acl_db_flex_rule_t  *rules,
                                                   uint16_t                  rules_count,
                                                   boolean_t                 is_full_write)
{
    uint32_t                 i = 0, success_count = 0;
    sx_status_t              rc = SX_STATUS_SUCCESS, rb_st = SX_STATUS_SUCCESS;
    boolean_t                is_key_changed = FALSE, is_prio_changed = FALSE;
    flex_acl_db_flex_rule_t *rule = NULL, help_rule;
    acl_rule_hw_op_e         hw_op = ACL_RULE_HW_OP_WRITE_E;

    SX_LOG_DBG("FLOWD going to update %d rules \n", rules_count);
    for (i = 0; i < rules_count; i++) {
        rc = flex_acl_db_get_rule_by_offset(acl_region->region_id, rules[i].offset, &rule);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get rule from db for offset [%u]\n", rules[i].offset);
            goto error;
        }
        if ((rule->valid == FLEX_ACL_RULE_INVALID) && (rules[i].valid == FLEX_ACL_RULE_INVALID)) {
            /* Nothing to do with rule. */
            success_count++;
            continue;
        }
        is_key_changed = FALSE;
        is_prio_changed = FALSE;
        if (rule->is_exist && (rule->valid == FLEX_ACL_RULE_VALID)) {
            rc = flex_acl_compare_keys(rule, &rules[i], &is_key_changed);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to compare keys offset [%u]\n", rules[i].offset);
                goto error;
            }
            if ((acl_region->rules_priority_mode == FLEX_RULES_PRIORITY_MODE_PRIORITY) &&
                (rule->priority != rules[i].priority)) {
                is_prio_changed = TRUE;
            }
        }
        /* Flex-2 should be aware which type of update we are doing
         * There are 3 cases :
         * - key change - a totally new rule taking the spot of an old rule
         * - priority change - only priority has changed (action may change as well)
         * - action only change - only action was changed
         */
        if (is_full_write || !rule->is_exist || is_prio_changed ||
            is_key_changed || (rule->valid != rules[i].valid)) {
            hw_op = ACL_RULE_HW_OP_WRITE_E;
            if (is_key_changed) {
                hw_op = ACL_RULE_HW_OP_OVERWRITE_E;
            } else if (is_prio_changed) {
                hw_op = ACL_RULE_HW_OP_PRIO_SET_E;
            }
        } else {
            /* Only action is updated */
            hw_op = ACL_RULE_HW_OP_UPDATE_E;
        }

        rc = flex_acl_hw_write_rule(&rules[i],
                                    acl_region,
                                    hw_op);

        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to configure rule offset %u to dev \n", rules[i].offset);
            goto error;
        }
        success_count++;
    }

    goto out;

error:

    /* Rollback */
    SX_LOG_DBG("**** FLOWD Failed HW writing rule needs to fully rollback %d rules and one partial.\n", success_count);
    for (i = 0; i < success_count + 1; i++) {
        rb_st = flex_acl_db_get_rule_by_offset(acl_region->region_id, rules[i].offset, &rule);
        if (SX_STATUS_SUCCESS != rb_st) {
            SX_LOG_ERR("ACL: Rollback Failed to get rule by offset.\n");
            goto out;
        }
        /* Nothing to do with rule. */
        if ((rule->valid == FLEX_ACL_RULE_INVALID) && (rules[i].valid == FLEX_ACL_RULE_INVALID)) {
            SX_LOG_DBG("FLOWD Rollback rule offset: %d invalid to invalid - nothing to do.\n", rules[i].offset);
            continue;
        }

        /* Free resource taken by written rules. */
        SX_LOG_DBG("FLOWD Rollback written %s rule offset:%u \n",
                   i < success_count ? "Successful" : "Failed",
                   rules[i].offset);
        rb_st = flex_acl_hw_free_rule_third_party_resources(&rules[i]);
        if (SX_STATUS_SUCCESS != rb_st) {
            SX_LOG_ERR("ACL: Rollback Failed to free third party.\n");
            goto out;
        }
        if (i < success_count) {
            /* Free KVD only for rules that were written successfully */
            SX_LOG_DBG("Free KVD for successful rule offset :%u \n", rules[i].offset);
            rb_st = flex_acl_hw_free_rule_kvd(&rules[i]);
            if (SX_STATUS_SUCCESS != rb_st) {
                SX_LOG_ERR("ACL: Rollback Failed to free kvd.\n");
                goto out;
            }
        }

        /* Free resource for rules that will be rewritten */
        if (rule->valid == FLEX_ACL_RULE_INVALID) {
            SX_LOG_DBG("FLOWD Rollback NO need free rule offset:%d from DB\n", rules[i].offset);
            help_rule = rules[i];
            help_rule.valid = FLEX_ACL_RULE_INVALID;
            rule = &help_rule;
        } else {
            SX_LOG_DBG("FLOWD Rollback free rule offset:%d from DB since it needs to be rewritten\n", rule->offset);
            rb_st = flex_acl_hw_free_rule_third_party_resources(rule);
            if (SX_STATUS_SUCCESS != rb_st) {
                SX_LOG_ERR("ACL: Failed to free third party.\n");
                goto out;
            }
            rb_st = flex_acl_hw_free_rule_kvd(rule);
            if (SX_STATUS_SUCCESS != rb_st) {
                SX_LOG_ERR("ACL: Failed to free kvd.\n");
                goto out;
            }
        }
        SX_LOG_DBG("FLOWD Rollback write old rules offset:%d valid:%d \n", rule->offset, rule->valid);
        rb_st = flex_acl_hw_write_rule(rule, acl_region, ACL_RULE_HW_OP_WRITE_E);
        if (SX_STATUS_SUCCESS != rb_st) {
            SX_LOG_ERR("ACL: Failed to write old rule.\n");
            goto out;
        }
    }

out:
    return rc;
}

sx_status_t flex_acl_get_is_defer(boolean_t *is_defer)
{
    if (NULL == is_defer) {
        SX_LOG_ERR("is_defer null ptr\n");
        return SX_STATUS_PARAM_NULL;
    }

    return flex_acl_db_get_is_parallel(is_defer);
}

sx_status_t __flex_acl_rules_validation(sx_api_flex_acl_rules_set_params_t *params,
                                        flex_acl_db_acl_region_t           *acl_region,
                                        boolean_t                           is_flex)
{
    uint32_t    i;
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((acl_region->bound_acl == FLEX_ACL_INVALID_ACL_ID) && is_flex) {
        SX_LOG_ERR("ACL : The region id [%u] are not bound to acl, failed to set rule\n", acl_region->region_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    for (i = 0; i < params->rules_count; i++) {
        /* rules key fields validation */
        rc = flex_acl_keys_validate(params->rules[i].key_desc_list_p,
                                    params->rules[i].key_desc_count,
                                    acl_region,
                                    FLEX_ACL_KEY_BUILD_VALUE_MASK_E,
                                    is_flex);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed key validation for region id %u offset %u.\n",
                       acl_region->region_id, params->offsets_list_p[i]);
            goto out;
        }

        /* Validate offset */
        if (params->offsets_list_p[i] >= acl_region->size) {
            SX_LOG_ERR("ACL : At least one of the rules has an "
                       "offset which exceeds the region size\n");
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        /* rules action fields validation */
        rc = flex_acl_actions_validate(&(params->rules[i]), acl_region, is_flex);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed action validation for region id %u offset %u.\n",
                       acl_region->region_id, params->offsets_list_p[i]);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t __flex_acl_rules_l4_port_range_ref_count(sx_flex_acl_key_desc_t *key, boolean_t is_inc)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i;

    for (i = 0; i < key->key.l4_port_range.port_range_cnt; i++) {
        rc = flex_acl_db_port_range_update_ref_count(key->key.l4_port_range.port_range_list[i], is_inc, 1);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed handle ref count for l4_port_range, port range ID: %u.\n",
                       key->key.l4_port_range.port_range_list[i]);
            goto out;
        }
    }

out:
    return rc;
}


sx_status_t __flex_acl_rules_keys_ref_update(flex_acl_db_flex_rule_t *rule,
                                             boolean_t                is_inc,
                                             sx_acl_region_id_t       region_id)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    flex_acl_rule_id_t   acl_rule_id = { .region_id = 0 };
    uint32_t             i;
    sx_access_cmd_t      cmd;
    sx_mc_container_id_t mc_container_id;
    sx_register_key_t    reg_key;
    boolean_t            rx_list_mask = FALSE;

    for (i = 0; i < rule->key_desc_count; i++) {
        switch (rule->key_desc_list[i].key_id) {
        case FLEX_ACL_KEY_L4_PORT_RANGE:
            rc = __flex_acl_rules_l4_port_range_ref_count(&(rule->key_desc_list[i]), is_inc);
            SX_LOG_DBG("ACL rules keys ref count key:FLEX_ACL_KEY_L4_PORT_RANGE %s \n", is_inc ? "Inc" : "Dec");
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed handle ref count for l4_port_range.\n");
                goto out;
            }
            break;

        case FLEX_ACL_KEY_RX_LIST:
        case FLEX_ACL_KEY_RX_TUNNEL_LIST:

            if (rule->key_desc_list[i].key_id == FLEX_ACL_KEY_RX_LIST) {
                rx_list_mask = rule->key_desc_list[i].mask.rx_list;
            } else {
                rx_list_mask = rule->key_desc_list[i].mask.rx_tunnel_list;
            }

            if (rx_list_mask == FALSE) {
                continue;
            }
            acl_rule_id.region_id = region_id;
            acl_rule_id.offset = rule->offset;
            cmd = is_inc ? SX_ACCESS_CMD_SOFT_ADD : SX_ACCESS_CMD_SOFT_DELETE;
            rc = flex_acl_db_update_rules_ref_rx_list(rule->key_desc_list[i].key.rx_list, &acl_rule_id, cmd);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to update rules ref rx list id:[%u]\n", rule->key_desc_list[i].key.rx_list);
                goto out;
            }
            break;

        case FLEX_ACL_KEY_GP_REGISTER_0:
        case FLEX_ACL_KEY_GP_REGISTER_1:
        case FLEX_ACL_KEY_GP_REGISTER_2:
        case FLEX_ACL_KEY_GP_REGISTER_3:
        case FLEX_ACL_KEY_GP_REGISTER_4:
        case FLEX_ACL_KEY_GP_REGISTER_5:
        case FLEX_ACL_KEY_GP_REGISTER_6:
        case FLEX_ACL_KEY_GP_REGISTER_7:
        case FLEX_ACL_KEY_GP_REGISTER_8:
        case FLEX_ACL_KEY_GP_REGISTER_9:
        case FLEX_ACL_KEY_GP_REGISTER_10:
        case FLEX_ACL_KEY_GP_REGISTER_11:
        case FLEX_ACL_KEY_GP_REGISTER_0_OFFSET:
        case FLEX_ACL_KEY_GP_REGISTER_1_OFFSET:
            SX_MEM_CLR(reg_key);
            reg_key.type = SX_REGISTER_KEY_TYPE_GENERAL_PURPOSE_E;
            reg_key.key.gp_reg.reg_id = rule->key_desc_list[i].key_id - FLEX_ACL_KEY_GP_REGISTER_START;

            if ((rule->key_desc_list[i].key_id >= FLEX_ACL_KEY_GP_REGISTER_OFFSET_START) &&
                (rule->key_desc_list[i].key_id <= FLEX_ACL_KEY_GP_REGISTER_OFFSET_LAST)) {
                reg_key.key.gp_reg.reg_id = rule->key_desc_list[i].key_id - FLEX_ACL_KEY_GP_REGISTER_OFFSET_START;
            }

            if (is_inc) {
                rc = sdk_register_impl_ref_increase(reg_key, &acl_gp_register_name_data, &rule->key_refs[i].ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL: Failed to increase key GP register [%u] rule ref\n", reg_key.key.gp_reg.reg_id);
                    goto out;
                }
            } else {
                rc = sdk_register_impl_ref_decrease(reg_key, &rule->key_refs[i].ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL: Failed to decrease key GP register [%u] rule ref\n", reg_key.key.gp_reg.reg_id);
                    goto out;
                }
            }
            break;

        case FLEX_ACL_KEY_RX_PORT_LIST_1_128:
        case FLEX_ACL_KEY_RX_PORT_LIST_129_258:
        case FLEX_ACL_KEY_TX_PORT_LIST_1_128:
        case FLEX_ACL_KEY_TX_PORT_LIST_129_258:
        case FLEX_ACL_KEY_RX_PORT_LIST:
        case FLEX_ACL_KEY_TX_PORT_LIST:
        case FLEX_ACL_KEY_RX_PORT_LIST_0:
        case FLEX_ACL_KEY_RX_PORT_LIST_1:
        case FLEX_ACL_KEY_RX_PORT_LIST_2:
        case FLEX_ACL_KEY_RX_PORT_LIST_3:
        case FLEX_ACL_KEY_TX_PORT_LIST_0:
        case FLEX_ACL_KEY_TX_PORT_LIST_1:
        case FLEX_ACL_KEY_TX_PORT_LIST_2:
        case FLEX_ACL_KEY_TX_PORT_LIST_3:

            rc = flex_acl_key_port_list_get_info(&rule->key_desc_list[i], &mc_container_id, NULL, &rx_list_mask);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL: Reference updated failed port list info get for key type [%u]\n",
                           rule->key_desc_list[i].key_id);
                goto out;
            }

            if (rx_list_mask == FALSE) {
                continue;
            }

            acl_rule_id.region_id = region_id;
            acl_rule_id.offset = rule->offset;

            if (is_inc) {
                rc = __flex_acl_mc_container_port_ref_inc(mc_container_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to increment flex acl MC container port ref id:[%u] \n", mc_container_id);
                    goto out;
                }
                rc = sdk_mc_container_ref_inc(mc_container_id, &acl_mc_name_data,
                                              &rule->key_refs[i].ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to increment sdk_mc_container_ref_inc id:[%u]\n",
                               mc_container_id);
                    goto out;
                }
                rc =
                    flex_acl_db_mc_container_to_rule_refs_add(MCC_TO_RULE_PORT_LIST_KEY, mc_container_id,
                                                              &acl_rule_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to update rules ref MC container id:[%u]\n",
                               rule->key_desc_list[i].key.rx_port_list.mc_container_id);
                    goto out;
                }
            } else {
                rc = flex_acl_db_mc_container_to_rule_refs_delete(MCC_TO_RULE_PORT_LIST_KEY,
                                                                  mc_container_id,
                                                                  &acl_rule_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to update rules ref MC container id:[%u]\n",
                               rule->key_desc_list[i].key.rx_port_list.mc_container_id);
                    goto out;
                }
                rc = sdk_mc_container_ref_dec(mc_container_id, &rule->key_refs[i].ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to decrement sdk_mc_container_ref_dec id:[%u]\n",
                               mc_container_id);
                    goto out;
                }
                rc = __flex_acl_mc_container_port_ref_dec(mc_container_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to increment MC container ref id:[%u] \n", mc_container_id);
                    continue;
                }
            }
            break;

        default:
            break;
        }
    }

out:
    return rc;
}

sx_status_t __flex_acl_rules_update(sx_acl_region_id_t        region_id,
                                    flex_acl_db_flex_rule_t  *rules,
                                    uint16_t                  rules_count,
                                    flex_acl_db_acl_region_t *acl_region)
{
    uint32_t                     i = 0;
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    sx_status_t                  rb_rc = SX_STATUS_SUCCESS;
    boolean_t                    is_defer = FALSE;
    uint32_t                     old_valid_rules_num = 0, action_sets_count = 0, action_sets_deleted = 0;
    flex_acl_db_flex_rule_t     *rule = NULL;
    sx_acl_action_container_id_t action_container_id = 0;

    rc = flex_acl_get_is_defer(&is_defer);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL action : Failed getting defer.\n");
        goto out;
    }
    /* Increase ref count. */
    for (i = 0; i < rules_count; i++) {
        if (rules[i].valid == FLEX_ACL_RULE_INVALID) {
            continue;
        }
        rc = __flex_acl_rules_keys_ref_update(&rules[i], TRUE, region_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to update keys ref count rule, region:%d offset:%d\n",  rules[i].region_id,
                       rules[i].offset);
            goto out;
        }
        rc = __flex_acl_add_actions_ref(&rules[i], region_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to update action ref count rule, region:%d offset:%d\n",  rules[i].region_id,
                       rules[i].offset);
            goto out;
        }
    }
    /* Create action sets */
    for (i = 0; i < rules_count; i++) {
        rules[i].region_id = region_id;
        if (rules[i].valid == FLEX_ACL_RULE_INVALID) {
            continue;
        }
        rc = flex_acl_hw_gen_hw_action_sets(&rules[i], is_defer,
                                            (flex_acl_hw_db_action_set_t**)&(rules[i].hw_action_handle));

        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR_RESOURCE_COND(rc,
                                     "Failed to generate action sets rule offset:%u region:%#x rc:%s\n",
                                     rules[i].offset, region_id, sx_status_str(rc));

            goto error;
        }
        action_sets_count++;
    }

    rc = __flex_acl_update_rules_to_devs(acl_region,
                                         rules,
                                         rules_count,
                                         FLEX_ACL_HW_ALLOW_WRITE_ONLY_ACTION);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to write rules to dev \n");
        goto error;
    }

    for (i = 0; i < rules_count; i++) {
        if ((rules[i].valid) && (rules[i].hw_action_handle != NULL) &&
            ((uint64_t)rules[i].hw_action_handle != FLEX_ACL_INVALID_HANDLE)) {
            if (rules[i].offset == SX_ACL_DEFAULT_ACTION_OFFSET) {
                /* Container ID does't supports default actions, because the first action resides in the same pre-allocated KVD index.
                 * The container ID associated with KVD index, and we need to handle with how to hold temporary the associated to same KVD index. */
                continue;
            }

            rc = flex_acl_db_action_container_add(rules[i].hw_action_handle, &action_container_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to add action container.\n");
                goto error;
            }
            rules[i].action_container_id = action_container_id;
        }
    }

    /* Handle overwrite. If param rule is valid and old rule is also valid free resources*/
    for (i = 0; i < rules_count; i++) {
        rc = flex_acl_db_get_rule_by_offset(acl_region->region_id, rules[i].offset, &rule);
        if ((rc != SX_STATUS_SUCCESS) || (rule->valid == FALSE)) {
            /* Nothing to free */
            continue;
        }
        SX_LOG_DBG("FLOWD ACL Handle override to rule offset :%d\n", rules[i].offset);
        if (rules[i].valid == TRUE) {
            rc = flex_acl_hw_free_third_parties(acl_region->region_id, rule->offset);
            if (SX_STATUS_SUCCESS != rc) {
                SX_LOG_ERR("ACL: Failed to free third party, region_id: %u, offset: %u\n",
                           acl_region->region_id,
                           rule->offset);
                goto error;
            }
            SX_LOG_DBG("ACL Handle override to rule offset :%d third party's freed\n", rules[i].offset);
            rc = flex_acl_hw_free_kvd(acl_region->region_id, rule->offset);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to free kvd, region_id: %u, offset: %u\n", acl_region->region_id,
                           rule->offset);
                goto error;
            }
            SX_LOG_DBG("ACL Handle override to rule offset :%d KVD freed\n", rules[i].offset);

            rc = __flex_acl_acl_drop_db_update(rule, &rules[i]);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL: Failed to update acl drop trap db \n");
                goto error;
            }
        }

        /* At this stage we have older valid rule resources that should be freed */
        rc = __flex_acl_rules_keys_ref_update(rule, FALSE, region_id);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL:  failed to delete ref count for keys. region:%d offset :%d\n",
                       rules[i].region_id,
                       rules[i].offset);
            goto error;
        }
        rc = __flex_acl_dec_actions_ref(rule, region_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: __flex_acl_dec_actions_ref Failed to free, region_id: %u\n", region_id);
            goto error;
        }

        rc = flex_acl_hw_free_action_sets(rule);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to free hw action set.\n");
            goto error;
        }

        if (rule->action_container_id != FLEX_ACL_INVALID_ACTION_CONTAINER_ID) {
            rc = flex_acl_db_action_container_delete(rule->action_container_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to delete action container.\n");
                goto error;
            }
            rule->action_container_id = FLEX_ACL_INVALID_ACTION_CONTAINER_ID;
        }

        SX_LOG_DBG("ACL Handle override to rule offset :%d HW action destroyed\n", rules[i].offset);
    }

    /* write rules to DB */
    old_valid_rules_num = acl_region->valid_rules_num;
    rc = flex_acl_db_update_rules(region_id, rules, rules_count, flex_acl_hw_copy_rule_ptr);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to Update rules to ACL group id [%#x]\n", region_id);
        goto devices_unupdate;
    }
    rc = flex_acl_rm_entries_set(acl_region->valid_rules_num,
                                 old_valid_rules_num,
                                 acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to Update rules to ACL group id [%#x]\n", region_id);
        goto db_unupdate;
    }
    return rc;

db_unupdate:
    for (i = 0; i < rules_count; i++) {
        rb_rc = flex_acl_db_invalidate_rules(region_id, &rules[i].offset, 1);
        if (rb_rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to invalidate rules id DB in rollback. region:%d offset: %d \n",
                       acl_region->region_id, rules[i].offset);
        }
    }
/* Invalidate all rules */
devices_unupdate:
    for (i = 0; i < rules_count; i++) {
        rules[i].valid = FLEX_ACL_RULE_INVALID; /* if rule was invalid it will be written twice */
    }
    rb_rc = __flex_acl_update_rules_to_devs(acl_region, rules, rules_count, FLEX_ACL_HW_FULL_WRITE);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in device update rollback. region:%d \n", acl_region->region_id);
    }

error:
    /* Decrease ref count. */
    for (i = 0; i < rules_count; i++) {
        if (rules[i].valid == FLEX_ACL_RULE_INVALID) {
            continue;
        }
        rb_rc = __flex_acl_rules_keys_ref_update(&rules[i], FALSE, region_id);
        if (rb_rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in rollback and delete ref count for keys. region:%d offset :%d\n",
                       region_id,
                       rules[i].offset);
        }
        rb_rc = __flex_acl_dec_actions_ref(&rules[i], region_id);
        if (rb_rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to rollback and decrease action ref count, region_id: %u offset: %d\n",
                       region_id,
                       rules[i].offset);
        }
    }

    SX_LOG_DBG("FLOWD Error - destroy %d HW action sets \n", action_sets_count);
    for (i = 0; i < rules_count; i++) {
        if (rules[i].valid == FLEX_ACL_RULE_INVALID) {
            continue;
        }
        if (++action_sets_deleted > action_sets_count) {
            break;
        }
        SX_LOG_DBG("FLOWD Destroying HW action #%u \n", i);

        if (rules[i].hw_action_handle != (void*)FLEX_ACL_INVALID_HANDLE) {
            rb_rc = flex_acl_hw_db_action_set_destroy(rules[i].hw_action_handle);
            if (rb_rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed in DB action destroy as rollback. region: %d offset:%d \n",
                           region_id, rules[i].offset);
            }
            rules[i].hw_action_handle = (void*)FLEX_ACL_INVALID_HANDLE;
        }
    }

out:
    return rc;
}

/* Helper function to be used in __flex_acl_add_actions_ref */
static sx_status_t __flex_acl_add_next_hop_ref(sx_flex_acl_flex_action_t *action, flex_acl_db_ref_handlers_t *ref)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_ecmp_id_t                      ecmp_id = SX_ROUTER_ECMP_ID_INVALID;
    sx_ecmp_attributes_t              ecmp_attributes;
    boolean_t                         is_empty;
    boolean_t                         ref_set = FALSE;
    hwi_ecmp_hw_block_handle_t        ecmp_block_handle;
    kvd_linear_manager_handle_t       mpls_adj_block_handle;
    kvd_linear_manager_index_t        mpls_adj_index[1];
    kvd_linear_manager_block_length_t ecmp_size;

    SX_MEM_CLR(ecmp_attributes);


    if (action->type == SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP) {
        ecmp_id = action->fields.action_nve_tunnel_encap.ecmp_id;
    } else if (action->type == SX_FLEX_ACL_ACTION_UC_ROUTE) {
        ecmp_id = action->fields.action_uc_route.uc_route_param.ecmp_id;
    } else if (action->type == SX_FLEX_ACL_ACTION_AR_UC_ROUTE) {
        ecmp_id = action->fields.action_ar_uc_route.ecmp_id;
    } else {
        SX_LOG_ERR("ACL: inappropriate type of action %u \n", action->type);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto error;
    }

    /* Get ECMP container attributes */
    rc = sdk_router_ecmp_impl_attributes_get(ecmp_id, &ecmp_attributes);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: failed to get attributes from ECMP %u \n", ecmp_id);
        goto error;
    }

    /* Increase the reference to the ECMP container we have got */
    rc = sdk_router_ecmp_impl_external_ref_inc(ecmp_id,
                                               ecmp_attributes.container_type,
                                               &ref->ref,
                                               &acl_ecmp_name_data);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: failed to add ACL reference to ECMP %u \n", ecmp_id);
        goto error;
    }

    /* Keep the type of the ecmp we got */
    ref->ecmp_container_type = ecmp_attributes.container_type;
    ref_set = TRUE;

    /* For MPLS we need to go through the ftn to create a pointer to nhlfe */
    if (ecmp_attributes.container_type == SX_ECMP_CONTAINER_TYPE_MPLS) {
        rc = sdk_router_ecmp_impl_active_set_get(ecmp_id,
                                                 &ecmp_block_handle,
                                                 &is_empty);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL:failed to get info from ECMP %u \n", ecmp_id);
            /* Remember to decrease the ecmp reference */
            goto error;
        }
        /* Now let the ftn know we'll be using it and create a reference*/
        rc = hwd_mpls_ftn_reference_block(ecmp_block_handle,
                                          &mpls_adj_block_handle,
                                          mpls_adj_index,
                                          &ecmp_size, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL:failed to get ftn block reference for ECMP %u block handle 0x%" PRIx64 " \n",
                       ecmp_id, ecmp_block_handle);
            /* Remember to decrease the ecmp reference */
            goto error;
        }
    }

    return rc;
error:
    if (ref_set) {
        sdk_router_ecmp_impl_external_ref_dec(
            action->fields.action_uc_route.uc_route_param.ecmp_id,
            &ref->ref,
            NULL);
    }

    return rc;
}

static sx_status_t __flex_acl_tunnel_id_get(sx_tunnel_id_t *tunnel_id_p)
{
    sx_status_t      sx_status = SX_STATUS_SUCCESS;
    sx_port_log_id_t log_port = 0;

    sx_status = sx_fdb_get_nve_log_port(&log_port);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_INF("Failed to get NVE logical port, err = %s\n",
                   sx_status_str(sx_status));
        goto out;
    }

    sx_status = sdk_tunnel_impl_tunnel_id_by_log_port_get(log_port, tunnel_id_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_INF("Failed to get tunnel id for NVE log port: %u, err = %s\n",
                   log_port, sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}


/* For all the rules connected to pbs increase/decrease a reference counter
 *  of relevant tunnel map entry. */
static sx_status_t __flex_acl_pbs_tunnel_map_entry_ref_inc_dec(sx_access_cmd_t          cmd,
                                                               flex_acl_db_pbs_entry_t *pbs_entry_p,
                                                               sx_tunnel_id_t           tunnel_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS, rb_rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t          rb_cmd = cmd == SX_ACCESS_CMD_ADD ? SX_ACCESS_CMD_DELETE : SX_ACCESS_CMD_ADD;
    flex_acl_rule_id_t      *rule_id_p = NULL;
    cl_list_iterator_t       iter = NULL;
    cl_list_iterator_t       list_end = NULL;
    cl_list_iterator_t       list_head = NULL;
    uint32_t                 num_of_successfull = 0, i = 0;
    flex_acl_db_flex_rule_t *rule_p = NULL;

    SX_LOG_ENTER();

    /* for all the rules connected to pbs */
    list_head = cl_list_head(&(pbs_entry_p->rules_list));
    list_end = cl_list_end(&(pbs_entry_p->rules_list));
    for (iter = list_head; iter != list_end;
         iter = cl_list_next(iter)) {
        rule_id_p = (flex_acl_rule_id_t*)cl_list_obj(iter);

        rc = flex_acl_db_get_rule_by_offset(rule_id_p->region_id, rule_id_p->offset, &rule_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL : Failed to get rule from db for region:%u offset:%u\n",
                       rule_id_p->region_id, rule_id_p->offset);
            goto rollback;
        }

        rc = sdk_tunnel_impl_map_entry_ref_inc_dec(cmd, tunnel_id, pbs_entry_p->fid,
                                                   &acl_mc_name_data,
                                                   &rule_p->action_refs[i].extra_ref);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to modify[%s] tunnel mapping ref for tunnel[0x%08x] and fid (%u)\n",
                       sx_access_cmd_str(cmd), tunnel_id, pbs_entry_p->fid);
            goto rollback;
        }
        num_of_successfull++;
    }

    goto out;

rollback:
    list_end = cl_list_end(&(pbs_entry_p->rules_list));
    list_head = cl_list_head(&(pbs_entry_p->rules_list));
    for (i = 0, iter = list_head;
         i < num_of_successfull && iter != list_end;
         i++, iter = cl_list_next(iter)) {
        rule_id_p = (flex_acl_rule_id_t*)cl_list_obj(iter);

        rb_rc = flex_acl_db_get_rule_by_offset(rule_id_p->region_id, rule_id_p->offset, &rule_p);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_ERR("ACL : Failed to get rule from db for region:%u offset:%u\n",
                       rule_id_p->region_id, rule_id_p->offset);
            continue;
        }

        rb_rc = sdk_tunnel_impl_map_entry_ref_inc_dec(rb_cmd, tunnel_id, pbs_entry_p->fid,
                                                      &acl_mc_name_data,
                                                      &rule_p->action_refs[i].extra_ref);
        if (SX_STATUS_SUCCESS != rb_rc) {
            SX_LOG_ERR("Failed to rollback[%s] modification of tunnel mapping ref for tunnel[0x%08x] and fid (%u)\n",
                       sx_access_cmd_str(cmd), tunnel_id, pbs_entry_p->fid);
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_add_actions_ref(flex_acl_db_flex_rule_t *rule, sx_acl_region_id_t region_id)
{
    uint32_t                     i = 0, j = 0;
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    sdk_ref_t                    reference = 0;
    flex_acl_db_pbs_entry_t     *pbs_entry = NULL;
    flex_acl_rule_id_t           rule_id;
    sx_tunnel_id_t               tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_mc_container_attributes_t attr;
    boolean_t                    first_ref = TRUE;
    flex_acl_rule_id_t           acl_rule_id = { .region_id = 0 };
    sx_fm_fid_type_t             fid_type = SX_FM_FID_TYPE_INVALID;
    uint32_t                     tunnel_port_bitmap = 0;

    SX_MEM_CLR(attr);

    SX_LOG_ENTER();

    SX_LOG_DBG("FLOWD Add ref for rule offset:%u \n", rule->offset);

    for (i = 0; i < rule->action_count; i++) {
        switch (rule->actions[i].type) {
        case SX_FLEX_ACL_ACTION_POLICER:
            rc = policer_manager_ref_add(rule->actions[i].fields.action_policer.policer_id,
                                         POLICER_MANAGER_GLOBAL_POLICER_TYPE_GET(
                                             rule->actions[i].fields.action_policer.policer_id));
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL policer action failed policer_manager_ref_add failed, policer_id: %" PRIu64 "\n",
                           rule->actions[i].fields.action_policer.policer_id);
                goto out;
            }
            SX_LOG_DBG("FLOWD ACL : Populates action Policer ref ADD policer_id:%u \n",
                       (unsigned int)rule->actions[i].fields.action_policer.policer_id);
            break;

        case SX_FLEX_ACL_ACTION_COUNTER:
            rc = flow_counter_ref_inc(rule->actions[i].fields.action_counter.counter_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL counter action failed flow_counter_ref_inc failed, counter_id: %u\n",
                           rule->actions[i].fields.action_counter.counter_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_TRUNCATION:
            rc = truncation_profile_refcount_inc(&rule->actions[i].fields.action_truncation.trunc_profile_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "ACL truncation action failed truncation truncation_profile_refcount_inc failed, trunc_profile id: %d.\n",
                    rule->actions[i].fields.action_truncation.trunc_profile_id.trunc_profile_id.acl_trunc_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_EGRESS_MIRROR:
            rc = flex_acl_db_egress_mirror_actions_count_inc(region_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL EGRESS_MIRROR action failed flex_acl_db_egress_mirror_actions_count_inc failed :%d \n",
                           rule->actions[i].fields.action_mirror.session_id);
                goto out;
            }

        /* fall through */
        case SX_FLEX_ACL_ACTION_MIRROR:
            rc = span_session_ref_cnt_inc(acl_span_handle, rule->actions[i].fields.action_mirror.session_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL span action failed span_session_ref_cnt_inc failed handle:%pid:%d \n",
                           acl_span_handle, rule->actions[i].fields.action_mirror.session_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_TUNNEL_DECAP:
            rc = sdk_tunnel_impl_ref_increase(rule->actions[i].fields.action_tunnel_decap.tunnel_id,
                                              &acl_tunnel_name_data, &rule->action_refs[i].ref,
                                              SX_TUNNEL_CAP_ACL_DECAP_E);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL action failed sdk_tunnel_impl_ref_increase failed %u \n",
                           rule->actions[i].fields.action_tunnel_decap.tunnel_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP:
            switch (rule->actions[i].fields.action_nve_tunnel_encap.encap_type) {
            case SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_NEXT_HOP:
                rc = sdk_tunnel_impl_ref_increase(rule->actions[i].fields.action_nve_tunnel_encap.tunnel_id,
                                                  &acl_tunnel_name_data, &rule->action_refs[i].ref,
                                                  SX_TUNNEL_CAP_ACL_ENCAP_E);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL action failed sdk_tunnel_impl_ref_increase failed %u \n",
                               rule->actions[i].fields.action_nve_tunnel_encap.tunnel_id);
                    goto out;
                }
                break;

            case SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_ECMP:
                /* Increase reference to next hop ECMP container */
                rc = __flex_acl_add_next_hop_ref(&rule->actions[i],
                                                 &rule->action_refs[i]);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL: failed to add ACL next hop reference to ECMP %u \n",
                               rule->actions[i].fields.action_nve_tunnel_encap.ecmp_id);
                    goto out;
                }
                break;

            default:
                SX_LOG_ERR("Invalid encapsulation type used [encap_type = %d]\n",
                           rule->actions[i].fields.action_nve_tunnel_encap.encap_type);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP:
            rc = sdk_mc_container_ref_inc(rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                                          &acl_mc_name_data,
                                          &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL action failed sdk_mc_container_ref_inc failed %u \n",
                           rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id);
                goto out;
            }

            rc = sdk_mc_container_tunnel_bitmap_get(rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                                                    &tunnel_port_bitmap);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get tunnel bitmap by MC container ID[%u], rc [%s]\n",
                           rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                           sx_status_str(rc));
                goto out;
            }

            if (tunnel_port_bitmap & (1 << SX_PORT_TUNNEL_NVE)) {
                rc = sdk_tunnel_impl_tunnel_id_by_log_port_get(SX_TUNNEL_PORT_ID_NVE, &tunnel_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to get tunnel ID for the NVE port, error: %s \n",
                               sx_status_str(rc));
                    goto out;
                }

                rc = sdk_mc_container_impl_get(rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                                               NULL, NULL, &attr, NULL);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to get FID by MC container ID[%u], rc [%s]\n",
                               rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                               sx_status_str(rc));
                    goto out;
                }

                if (attr.type != SX_MC_CONTAINER_TYPE_VLAN_UNAWARE) {
                    /* MC container is FID aware, thus we increase the tunnel reference */
                    rc = sdk_tunnel_impl_map_entry_ref_inc_dec(SX_ACCESS_CMD_ADD, tunnel_id, attr.fid,
                                                               &acl_mc_name_data,
                                                               &rule->action_refs[i].extra_ref);
                    if (SX_STATUS_SUCCESS != rc) {
                        SX_LOG_ERR("Failed to increase tunnel mapping ref for tunnel[0x%08x] and fid (%u)\n",
                                   tunnel_id, attr.fid);
                        sdk_mc_container_ref_dec(rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                                                 &rule->action_refs[i].ref);
                        goto out;
                    }
                }
            }
            break;

        case SX_FLEX_ACL_ACTION_PBS:
            rc = flex_acl_db_pbs_get_entry(0, rule->actions[i].fields.action_pbs.pbs_id, &pbs_entry);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL Action forward : failed to find PBS  ID [%u]\n",
                           rule->actions[i].fields.action_pbs.pbs_id);
                goto out;
            }
            rule_id.region_id = region_id;
            rule_id.offset = rule->offset;
            rc = flex_acl_db_pbs_add_rule_to_list(pbs_entry, rule_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL Action forward : failed to add rule to list in PBS [%u]\n",
                           rule->actions[i].fields.action_pbs.pbs_id);
                goto out;
            }
            rc = flex_acl_db_pbs_update_ref_count(0, rule->actions[i].fields.action_pbs.pbs_id, TRUE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL Action forward : failed to increment PBS [%u]\n",
                           rule->actions[i].fields.action_pbs.pbs_id);
                flex_acl_db_pbs_del_rule_from_list(pbs_entry, rule_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_MC:
            rc =
                sdk_mc_container_ref_inc(rule->actions[i].fields.action_mc.mc_container_id,
                                         &acl_mc_name_data,
                                         &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL MC action failed sdk_mc_container_ref_inc failed %u \n",
                           rule->actions[i].fields.action_mc.mc_container_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_MC_ROUTE:
            rc = sdk_mc_container_ref_inc(rule->actions[i].fields.action_mc_route.egress_mc_container,
                                          &acl_mc_name_data,
                                          &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL MC action failed sdk_mc_container_ref_inc failed %u \n",
                           rule->actions[i].fields.action_mc_route.egress_mc_container);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_SET_ROUTER:
            rc = sdk_router_vrid_impl_refcnt_inc(rule->actions[i].fields.action_set_router.vrid, &acl_vrid_name_data,
                                                 &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL action failed sdk_router_vrid_impl_refcnt_inc failed %u \n",
                           rule->actions[i].fields.action_set_router.vrid);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_GOTO:
            if ((rule->actions[i].fields.action_goto.goto_action_cmd == SX_ACL_ACTION_GOTO_JUMP) ||
                (rule->actions[i].fields.action_goto.goto_action_cmd == SX_ACL_ACTION_GOTO_CALL)) {
                rc = flex_acl_db_group_rules_ref_cnt_update(rule->actions[i].fields.action_goto.acl_group_id,
                                                            TRUE,
                                                            &reference);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL:failed to add acl rule reference to group %u \n",
                               rule->actions[i].fields.action_goto.acl_group_id);
                    goto out;
                }
                rule->goto_rule_ref = reference;
            }
            break;

        case SX_FLEX_ACL_ACTION_SET_BRIDGE:
            rc = sdk_fid_manager_get_fid_type(rule->actions[i].fields.action_set_bridge.bridge_id, &fid_type);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get fid (%u) type. rc=[%s]\n",
                           rule->actions[i].fields.action_set_bridge.bridge_id, sx_status_str(rc));
                goto out;
            }

            if (fid_type == SX_FM_FID_TYPE_BRIDGE_REWRITE_E) {
                rc = bridge_ref_cnt_increase(rule->actions[i].fields.action_set_bridge.bridge_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL:failed to add acl reference to bridge %u \n",
                               rule->actions[i].fields.action_set_bridge.bridge_id);
                    goto out;
                }
            } else if (fid_type == SX_FM_FID_TYPE_VLAN_REWRITE_E) {
                rc = vlan_ref_cnt_increase(0, rule->actions[i].fields.action_set_bridge.bridge_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL:failed to add acl reference to VLAN %u \n",
                               rule->actions[i].fields.action_set_bridge.bridge_id);
                    goto out;
                }
            }

            break;

        case SX_FLEX_ACL_ACTION_UC_ROUTE:
            switch (rule->actions[i].fields.action_uc_route.uc_route_type) {
            case SX_UC_ROUTE_TYPE_LOCAL:
                rc = sdk_rif_impl_ref_increase(rule->actions[i].fields.action_uc_route.uc_route_param.local_egress_rif,
                                               &acl_rif_name_data,
                                               &rule->action_refs[i].ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL:failed to add ACL reference to RIF %u \n",
                               rule->actions[i].fields.action_uc_route.uc_route_param.local_egress_rif);
                    goto out;
                }
                break;

            case SX_UC_ROUTE_TYPE_NEXT_HOP:
                rc = __flex_acl_add_next_hop_ref(&rule->actions[i],
                                                 &rule->action_refs[i]);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL:failed to add ACL next hop reference to ECMP %u \n",
                               rule->actions[i].fields.action_uc_route.uc_route_param.ecmp_id);
                    goto out;
                }
                break;

            default:
                break;
            }
            break;

        case SX_FLEX_ACL_ACTION_AR_UC_ROUTE:
            rc = __flex_acl_add_next_hop_ref(&rule->actions[i],
                                             &rule->action_refs[i]);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL:failed to add ACL AR reference to ECMP %u \n",
                           rule->actions[i].fields.action_ar_uc_route.ecmp_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_PORT_FILTER:
            rc = __flex_acl_mc_container_port_ref_inc(rule->actions[i].fields.action_port_filter.mc_container_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to increment flex acl MC container port ref id:[%u] \n",
                           rule->actions[i].fields.action_port_filter.mc_container_id);
                goto out;
            }
            rc =
                sdk_mc_container_ref_inc(rule->actions[i].fields.action_port_filter.mc_container_id,
                                         &acl_mc_name_data,
                                         &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to increment sdk_mc_container_ref_inc id:[%u] \n",
                           rule->actions[i].fields.action_port_filter.mc_container_id);
                goto out;
            }
            acl_rule_id.region_id = region_id;
            acl_rule_id.offset = rule->offset;
            rc = flex_acl_db_mc_container_to_rule_refs_add(MCC_TO_RULE_PORT_FILTER_ACTION,
                                                           rule->actions[i].fields.action_port_filter.mc_container_id,
                                                           &acl_rule_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to add port filter rules ref MC container id:[%u]\n",
                           rule->actions[i].fields.action_port_filter.mc_container_id);
                goto out;
            }

            break;

        case SX_FLEX_ACL_ACTION_PBILM:
            rc = flex_acl_db_pbilm_ref_inc(rule->actions[i].fields.action_pbilm.pbilm_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to increment pbilm ref for pbilm_id:[%u], \n",
                           rule->actions[i].fields.action_pbilm.pbilm_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_SET_EMT:
            for (j = 0; j < SX_FLEX_MODIFIER_EMT_BIND_INDEX_LAST_E; j++) {
                if ((rule->actions[i].fields.action_set_emt.emt_bind_action[j].emt_bind_type !=
                     SX_FLEX_MODIFIER_BIND_TYPE_NOP_E) &&
                    (rule->actions[i].fields.action_set_emt.emt_bind_action[j].emt_bind_type !=
                     SX_FLEX_MODIFIER_BIND_TYPE_DISABLE_E)) {
                    rc = flex_modifier_emt_ref_inc(
                        rule->actions[i].fields.action_set_emt.emt_bind_action[j].emt_bind_type_attr.emt_id.emt_id,
                        &acl_flex_modifier_emt_name_data,
                        (first_ref) ? &rule->action_refs[i].ref : &rule->action_refs[i].extra_ref);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed to increment flex modifier EMT id:[%u]\n",
                                   rule->actions[i].fields.action_set_emt.emt_bind_action[j].emt_bind_type_attr.emt_id.emt_id);
                        goto out;
                    }
                    first_ref = FALSE;
                }
            }
            break;

        case SX_FLEX_ACL_ACTION_NAT:
            rc = sdk_nat_4to6_ref_inc(rule->actions[i].fields.action_nat.nat_id,
                                      &acl_nat_name_data,
                                      &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to increment NAT IPv4/IPv6 [%u] ACL action reference\n",
                           rule->actions[i].fields.action_nat.nat_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_STATEFUL_DB:
            rc = stateful_db_key_id_ref_inc(rule->actions[i].fields.action_stateful_db.stateful_key_id,
                                            &acl_stateful_db_name_data,
                                            &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to increment stateful DB key ID [%u] ACL action reference\n",
                           rule->actions[i].fields.action_stateful_db.stateful_key_id);
                goto out;
            }
            rc = stateful_db_partition_ref_inc(rule->actions[i].fields.action_stateful_db.partition_id,
                                               &acl_stateful_db_name_data,
                                               &rule->action_refs[i].extra_ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to increment stateful DB partition [%u] ACL action reference\n",
                           rule->actions[i].fields.action_stateful_db.partition_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_FLOW_ESTIMATOR:
            rc = flow_counter_ref_inc(rule->actions[i].fields.action_flow_estimator.counter.base_counter_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL counter action failed flow_counter_ref_inc failed, counter_id: %u\n",
                           rule->actions[i].fields.action_flow_estimator.counter.base_counter_id);
                continue;
            }
            rc = flow_estimator_profile_ref_inc(&(rule->actions[i].fields.action_flow_estimator.profile_key));
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL counter action failed flow_estimator_profile_ref_inc failed, profile id: %u\n",
                           rule->actions[i].fields.action_flow_estimator.profile_key.profile_id);
                continue;
            }
            SX_LOG_DBG("FLOWD ACL estimator ref INC (profile:%u, cntr:%u) \n",
                       rule->actions[i].fields.action_flow_estimator.profile_key.profile_id,
                       rule->actions[i].fields.action_flow_estimator.counter.base_counter_id);
            break;

        default:
            break;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_fdb_mc_mid_changed(adviser_event_e event_type, void *param)
{
    fdb_mc_mid_change_event_data_t *mid_change_info_p;
    sx_status_t                     rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t        *pbs_entry = NULL;
    sx_acl_pbs_id_t                 pbs_id = SX_ACL_PBS_ID_INVALID;
    sx_fid_t                        fid = SX_FID_ID_INVALID;

    SX_LOG_ENTER();

    UNUSED_PARAM(event_type);

    mid_change_info_p = (fdb_mc_mid_change_event_data_t*)param;

    SX_LOG_DBG("old mid = %u, new mid = %u.\n", mid_change_info_p->old_mid, mid_change_info_p->new_mid);

    __flex_acl_mc_key_to_pbs(mid_change_info_p->key, &pbs_id, &fid);
    rc = flex_acl_db_pbs_get_entry(mid_change_info_p->swid,
                                   pbs_id,
                                   &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__flex_acl_fdb_mc_mid_changed Error at get entry of pbs, key:%u\n", mid_change_info_p->key.key);
        goto out;
    }
    pbs_entry->mid = mid_change_info_p->new_mid;
    rc = flex_acl_hw_config_pbs(pbs_entry, pbs_entry->is_vport);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL flex_acl_hw_add_pbs failed: flex_acl_hw_config_pbs failed.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_mc_container_ptr_update(sx_mc_container_id_t           mc_container_id,
                                             hw_mc_list_pointer_t          *old_pointer,
                                             hw_mc_list_pointer_t          *new_pointer,
                                             sx_flex_acl_flex_action_type_t api_action_type)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t    * pbs_entry = NULL;
    uint32_t                     ref_count;
    sx_acl_pbs_id_t              pbs_id;
    sx_tunnel_id_t               tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_mc_container_attributes_t attr;
    sx_access_cmd_t              cmd = SX_ACCESS_CMD_NONE;
    uint8_t                      old_nve_bit = old_pointer->data.tnumt_pointer.tunnel_bitmap &
                                               (1 << SX_PORT_TUNNEL_NVE);
    uint8_t new_nve_bit = new_pointer->data.tnumt_pointer.tunnel_bitmap &
                          (1 << SX_PORT_TUNNEL_NVE);
    boolean_t nve_bit_was_enabled = (~old_nve_bit) & new_nve_bit;
    boolean_t nve_bit_was_disabled = old_nve_bit & (~new_nve_bit);
    boolean_t nve_bit_was_not_changed = !(old_nve_bit ^ new_nve_bit);

    SX_LOG_ENTER();

    rc = flex_acl_db_pbs_mc_get(mc_container_id, &pbs_id, &ref_count, api_action_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("ACL change MC container ptr failed mc container id :%u.\n", mc_container_id);
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    rc = flex_acl_db_pbs_get_entry(0, pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_mc_container_ptr_update Error at get entry of pbs, container id:%u pbs_id:%u \n",
                   mc_container_id, pbs_id);
        goto out;
    }

    /* Get MC container attributes to check its type later */
    rc = hwd_mc_container_attr_get(mc_container_id, &attr);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get MC container attributes %u\n", mc_container_id);
        goto out;
    }

#if 0
    SX_LOG_NTC("^^^ MCC ptr update [mcc = %d, FID = %d]\n", mc_container_id, pbs_entry->fid);
    if (new_pointer->type == HW_MC_LIST_POINTER_TYPE_TUNNEL_ENCAP) {
        SX_LOG_NTC("^^^ New PTR = TNUMT \n");
    }
    if (new_pointer->type == HW_MC_LIST_POINTER_TYPE_NONE) {
        SX_LOG_NTC("^^^ New PTR = NONE \n");
    }

    if (old_pointer->type == HW_MC_LIST_POINTER_TYPE_TUNNEL_ENCAP) {
        SX_LOG_NTC("^^^ Old PTR = TNUMT \n");
    }
    if (old_pointer->type == HW_MC_LIST_POINTER_TYPE_NONE) {
        SX_LOG_NTC("^^^ Old PTR = NONE \n");
    }

    if (new_pointer->type == HW_MC_LIST_POINTER_TYPE_SMID) {
        SX_LOG_NTC("^^^ New PTR = SMID \n");
    }
    if (old_pointer->type == HW_MC_LIST_POINTER_TYPE_SMID) {
        SX_LOG_NTC("^^^ Old PTR = SMID \n");
    }
#endif
    if (new_pointer->type == HW_MC_LIST_POINTER_TYPE_SMID) {
        pbs_entry->mid = new_pointer->data.smid_index;
    } else if (new_pointer->type == HW_MC_LIST_POINTER_TYPE_TUNNEL_ENCAP) {
        pbs_entry->tnumt = new_pointer->data.tnumt_pointer.tnumt_index;
        pbs_entry->ecmp_size = new_pointer->data.tnumt_pointer.ecmp_size;
        pbs_entry->tnumt_valid = TRUE;
        if (attr.type != SX_MC_CONTAINER_TYPE_VLAN_UNAWARE) {
            if (old_pointer->type == HW_MC_LIST_POINTER_TYPE_NONE) {
                /* MC container is FID aware, thus we increase the tunnel reference */
                if (nve_bit_was_enabled) {
                    rc = __flex_acl_tunnel_id_get(&tunnel_id);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed to get tunnel ID by PBS ID[%u], rc [%s]\n",
                                   pbs_entry->pbs_id, sx_status_str(rc));
                        goto out;
                    }

                    rc = __flex_acl_pbs_tunnel_map_entry_ref_inc_dec(SX_ACCESS_CMD_ADD, pbs_entry, tunnel_id);
                    if (SX_STATUS_SUCCESS != rc) {
                        SX_LOG_ERR("Failed to increase tunnel mapping ref for PBS (%u)\n",
                                   pbs_entry->pbs_id);
                        goto out;
                    }
                }
            } else if (old_pointer->type == HW_MC_LIST_POINTER_TYPE_TUNNEL_ENCAP) {
                /* Check if VNI reference counter should be update */
                if (nve_bit_was_not_changed == FALSE) {
                    cmd = SX_ACCESS_CMD_DELETE;
                    if (nve_bit_was_enabled) {
                        cmd = SX_ACCESS_CMD_ADD;
                    }

                    rc = __flex_acl_tunnel_id_get(&tunnel_id);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed to get tunnel ID by PBS ID[%u], rc [%s]\n",
                                   pbs_entry->pbs_id, sx_status_str(rc));
                        goto out;
                    }

                    rc = __flex_acl_pbs_tunnel_map_entry_ref_inc_dec(cmd, pbs_entry, tunnel_id);
                    if (SX_STATUS_SUCCESS != rc) {
                        SX_LOG_ERR("Failed to update tunnel mapping ref for PBS (%u)\n",
                                   pbs_entry->pbs_id);
                        goto out;
                    }
                }
            }
        }
    } else if ((new_pointer->type == HW_MC_LIST_POINTER_TYPE_NONE) &&
               (old_pointer->type == HW_MC_LIST_POINTER_TYPE_TUNNEL_ENCAP)) {
        pbs_entry->ecmp_size = 0;
        pbs_entry->tnumt = 0;
        pbs_entry->tnumt_valid = FALSE;

        if (attr.type != SX_MC_CONTAINER_TYPE_VLAN_UNAWARE) {
            /* MC container is FID aware, thus we decrease the tunnel reference */
            if (nve_bit_was_disabled) {
                rc = __flex_acl_tunnel_id_get(&tunnel_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to get tunnel ID by PBS ID[%u], rc [%s]\n",
                               pbs_entry->pbs_id, sx_status_str(rc));
                    goto out;
                }
                rc = __flex_acl_pbs_tunnel_map_entry_ref_inc_dec(SX_ACCESS_CMD_DELETE, pbs_entry, tunnel_id);
                if (SX_STATUS_SUCCESS != rc) {
                    SX_LOG_ERR("Failed to decrease tunnel mapping ref for PBS (%u)\n",
                               pbs_entry->pbs_id);
                    goto out;
                }
            }
        }
    }

    rc = flex_acl_hw_config_pbs(pbs_entry, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_mc_container_ptr_update Error, flex_acl_hw_config_pbs failed.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_mc_container_ptr_changed(adviser_event_e event_type, void *param)
{
    mc_container_pointer_change_event_data_t *container_change_info_p;
    sx_status_t                               rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(event_type);

    container_change_info_p = (mc_container_pointer_change_event_data_t*)param;

    if ((container_change_info_p->new_pointer.type != HW_MC_LIST_POINTER_TYPE_SMID) &&
        (container_change_info_p->new_pointer.type != HW_MC_LIST_POINTER_TYPE_TUNNEL_ENCAP) &&
        (container_change_info_p->new_pointer.type != HW_MC_LIST_POINTER_TYPE_NONE)) {
        SX_LOG_DBG("MC container ptr change only HW_MC_LIST_POINTER_TYPE_SMID/TNUMT supported.\n");
        goto out;
    }

    rc = flex_acl_mc_container_ptr_update(container_change_info_p->container_id,
                                          &container_change_info_p->old_pointer,
                                          &container_change_info_p->new_pointer,
                                          SX_FLEX_ACL_ACTION_MC);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__flex_acl_mc_container_ptr_changed Error\n");
        goto out;
    }

    /* Also look up tunnel entry */
    rc = flex_acl_mc_container_ptr_update(container_change_info_p->container_id,
                                          &container_change_info_p->old_pointer,
                                          &container_change_info_p->new_pointer,
                                          SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__flex_acl_mc_container_ptr_changed (Tunnel) Error\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_clean_mc_container_action(sx_mc_container_id_t           mc_container_id,
                                               sx_flex_acl_flex_action_type_t api_action_type,
                                               flex_acl_rule_id_t             rule_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_acl_pbs_id_t          pbs_id;
    uint32_t                 ref_count;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_pbs_mc_ref_dec(mc_container_id, api_action_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL Action forward : failed to increment MC PBS [%u]\n", mc_container_id);
        goto out;
    }
    rc = flex_acl_db_pbs_mc_get(mc_container_id, &pbs_id, &ref_count, api_action_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL action forward action  dec ref. flex_acl_db_pbs_mc_get failed, MC container: %u.\n",
                   mc_container_id);
        goto out;
    }
    if (api_action_type == SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP) {
        rc = flex_acl_db_pbs_get_entry(0, pbs_id, &pbs_entry);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_NTC("ACL action forward: Error at get entry of pbs, pbs id:%u \n",
                       pbs_id);
            goto out;
        }
        rc = flex_acl_db_pbs_del_rule_from_list(pbs_entry, rule_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_NTC("ACL action forward: Failed deleting rule from PBS, region_id: %u, offset: %u\n",
                       rule_id.region_id, rule_id.offset);
            goto out;
        }
    }
    if (ref_count == 0) {
        rc = flex_acl_db_pbs_update_ref_count(0, pbs_id, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL clean mc container : failed to decrement PBS [%u]\n", pbs_id);
            goto out;
        }
        rc = flex_acl_pbs_del(pbs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL clean mc container : failed to increment PBS [%u]\n", pbs_id);
            goto out;
        }
        rc = flex_acl_db_pbs_mc_destroy(mc_container_id, api_action_type);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL clean mc container : failed to delete MC PBS [%u]\n", mc_container_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_ipv6_reloc_changed(adviser_event_e event_type, void *param_p)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    uint32_t                   ref_count = 0;
    flex_acl_db_pbs_entry_t   *pbs_entry_p = NULL;
    sx_acl_pbs_id_t            pbs_id = SX_ACL_PBS_ID_INVALID;
    sx_ip_next_hop_ip_tunnel_t ip_tunnel_id;
    hwd_ipv6_cb_t             *relocate_context = NULL;

    SX_MEM_CLR(ip_tunnel_id);

    SX_LOG_ENTER();

    /* Validate parameters */
    if (SX_CHECK_FAIL(rc = utils_check_pointer(param_p, "IPv6 update event params"))) {
        goto out;
    }

    if (event_type != ADVISER_EVENT_POST_IPV6_CHANGE_E) {
        SX_LOG_ERR("Wrong event type, expected event type is"
                   " [%s], received event type: [%s].\n",
                   ADVISER_EVENT_STR(ADVISER_EVENT_POST_IPV6_CHANGE_E),
                   ADVISER_EVENT_STR(event_type));
        rc = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    relocate_context = (hwd_ipv6_cb_t*)param_p;

    rc = __flex_acl_tunnel_id_get(&ip_tunnel_id.tunnel_id);
    if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_DBG("NVE Tunnel is not found; error = %s.\n", sx_status_str(rc));
        rc = SX_STATUS_SUCCESS;
        goto out;
    } else if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get NVE Tunnel; error = %s.\n", sx_status_str(rc));
        goto out;
    }

    rc = sdk_ipv6_impl_get_by_handle(relocate_context->handle, &ip_tunnel_id.underlay_dip);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("IPv6 MGR: Failed to get address by IPv6 handle [0x%" PRIx64 "], err =%s\n",
                   relocate_context->handle, sx_status_str(rc));
        goto out;
    }

    /* Check if Tunnel PBS record exist */
    rc = flex_acl_db_pbs_nve_get(ip_tunnel_id, &pbs_id, &ref_count);
    if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_DBG("NVE DB record for Tunnel ID = %u is not found; error = %s.\n",
                   ip_tunnel_id.tunnel_id, sx_status_str(rc));
        rc = SX_STATUS_SUCCESS;
        goto out;
    } else if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get NVE DB record [Tunnel ID = %u; error = %s].\n",
                   ip_tunnel_id.tunnel_id, sx_status_str(rc));
        goto out;
    }

    /* Get PBS record via pbs_id */
    rc = flex_acl_db_pbs_get_entry(0, pbs_id, &pbs_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get PBS record [PBS ID = %u; error = %s].\n",
                   pbs_id, sx_status_str(rc));
        goto out;
    }

    pbs_entry_p->ipv6_hw_index = relocate_context->new_index;

    /* Apply config to HW */
    rc = flex_acl_hw_config_pbs(pbs_entry_p, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to update PBS HW config [PBS ID = %u; error = %s].\n",
                   pbs_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_ecmp_update_ptr_changed(adviser_event_e event_type, void *param_p)
{
    uint32_t                       ref_count = 0;
    flex_acl_db_pbs_entry_t       *pbs_entry_p = NULL;
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    post_ecmp_update_event_data_t *ecmp_change_info_p = NULL;
    sx_acl_pbs_id_t                pbs_id = SX_ACL_PBS_ID_INVALID;
    sx_flex_acl_flex_action_type_t api_action_type = SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP;
    uint32_t                       tunnel_port_bitmap = 0;


    SX_LOG_ENTER();

    /* Validate parameters */
    if (event_type != ADVISER_EVENT_POST_ECMP_UPDATE_E) {
        rc = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Unexpected event %s [error = %s].\n",
                   ADVISER_EVENT_STR(event_type),
                   sx_status_str(rc));
        goto out;
    } else if (SX_CHECK_FAIL(rc = utils_check_pointer(param_p,
                                                      "ECMP Update event params"))) {
        goto out;
    }

    ecmp_change_info_p = (post_ecmp_update_event_data_t*)param_p;

    /* Get ECMP map data via ecmp_block_handle */
    rc = flex_acl_db_pbs_ecmp_get(ecmp_change_info_p->ecmp_block_handle, &pbs_id, &ref_count,
                                  api_action_type);
    if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_DBG("ECMP map data not found [ECMP handle = 0x%" PRIx64 "].\n",
                   ecmp_change_info_p->ecmp_block_handle);
        rc = SX_STATUS_SUCCESS;
        goto out;
    } else if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get ECMP map data [ECMP handle = 0x%" PRIx64 "; error = %s].\n",
                   ecmp_change_info_p->ecmp_block_handle, sx_status_str(rc));
        goto out;
    }

    /* Get PBS record via pbs_id */
    rc = flex_acl_db_pbs_get_entry(0, pbs_id, &pbs_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get PBS record [PBS ID = %u; error = %s].\n",
                   pbs_id, sx_status_str(rc));
        goto out;
    }

    /* Invalidate PBS entry if new ECMP size is 0 */
    if (ecmp_change_info_p->new_ecmp_size > 0) {
        /* NOTE: Currently it's difficult to extract from the ECMP in this callback context real tunnel usage.
         * so for now we set all tunnels in case of ECMP modification. There might be a slight performance penalty in
         * case the packet is dropped in the loopback check.
         */
        tunnel_port_bitmap = (1 << SX_PORT_TUNNEL_NVE) | (1 << SX_PORT_TUNNEL_FLEX0) | (1 << SX_PORT_TUNNEL_FLEX1);
        pbs_entry_p->ecmp_size = ecmp_change_info_p->new_ecmp_size;
        pbs_entry_p->tnumt = ecmp_change_info_p->new_adjacency_index;
        pbs_entry_p->tnumt_valid = TRUE;
        pbs_entry_p->tunnel_port_bitmap = tunnel_port_bitmap;
    } else {
        pbs_entry_p->ecmp_size = 0;
        pbs_entry_p->tnumt = 0;
        pbs_entry_p->tnumt_valid = FALSE;
        pbs_entry_p->tunnel_port_bitmap = 0;
    }

    /* Apply config to HW */
    rc = flex_acl_hw_config_pbs(pbs_entry_p, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to update PBS HW config [PBS ID = %u; error = %s].\n",
                   pbs_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_clean_ecmp_action(hwi_ecmp_hw_block_handle_t     ecmp_handle,
                                       sx_flex_acl_flex_action_type_t api_action_type,
                                       flex_acl_rule_id_t             rule_id)
{
    uint32_t                 ref_count = 0;
    flex_acl_db_pbs_entry_t *pbs_entry_p = NULL;
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_acl_pbs_id_t          pbs_id = SX_ACL_PBS_ID_INVALID;


    SX_LOG_ENTER();
    UNUSED_PARAM(rule_id);

    /* Decrease reference counter to ECMP DB record*/
    rc = flex_acl_db_pbs_ecmp_ref_dec(ecmp_handle, api_action_type);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to decrement ECMP map reference counter [ECMP handle: 0x%" PRIx64 "; error = %s]\n",
                   ecmp_handle, sx_status_str(rc));
        goto out;
    }

    /* Get PBS ID and reference counter via ECMP handle */
    rc = flex_acl_db_pbs_ecmp_get(ecmp_handle, &pbs_id, &ref_count, api_action_type);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get ECMP map data [ECMP handle = 0x%" PRIx64 "; error = %s].\n",
                   ecmp_handle, sx_status_str(rc));
        goto out;
    }

    /* Get PBS DB record via PBS ID */
    rc = flex_acl_db_pbs_get_entry(0, pbs_id, &pbs_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get PBS record [PBS ID = %u; error = %s].\n",
                   pbs_id, sx_status_str(rc));
        goto out;
    }

    /* Check if ECMP PBS record is no more referenced */
    if (ref_count == 0) {
        /* Delete related PBS DB record */
        rc = flex_acl_pbs_del(pbs_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to delete PBS DB record [PBS ID = %u; error = %s]\n",
                       pbs_id, sx_status_str(rc));
            goto out;
        }

        /* Delete ECMP DB record */
        rc = flex_acl_db_pbs_ecmp_destroy(ecmp_handle, api_action_type);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to delete ECMP DB record [ECMP handle: 0x%" PRIx64 "; error = %s]\n",
                       ecmp_handle, sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* Helper function to be used in  __flex_acl_dec_actions_ref */
static sx_status_t __flex_acl_dec_next_hop_ref(sx_flex_acl_flex_action_t *action, flex_acl_db_ref_handlers_t *ref)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    hwi_ecmp_hw_block_handle_t ecmp_block_handle;
    boolean_t                  is_empty;
    sx_ecmp_id_t               ecmp_id = SX_ROUTER_ECMP_ID_INVALID;

    if (action->type == SX_FLEX_ACL_ACTION_UC_ROUTE) {
        ecmp_id = action->fields.action_uc_route.uc_route_param.ecmp_id;
    } else if (action->type == SX_FLEX_ACL_ACTION_AR_UC_ROUTE) {
        ecmp_id = action->fields.action_ar_uc_route.ecmp_id;
    } else {
        SX_LOG_ERR("ACL: inappropriate type of action %u \n", action->type);
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto error;
    }

    rc = sdk_router_ecmp_impl_external_ref_dec(
        ecmp_id,
        &ref->ref,
        NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL:failed to dec ACL reference to ECMP %u \n", ecmp_id);
        goto error;
    }

    /* If we are referencing a MPLS container we need to release the ftn as well */
    if (ref->ecmp_container_type == SX_ECMP_CONTAINER_TYPE_MPLS) {
        rc = sdk_router_ecmp_impl_active_set_get(ecmp_id,
                                                 &ecmp_block_handle,
                                                 &is_empty);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL:failed to get info from ECMP %u \n", ecmp_id);
            goto error;
        }
        /* Release the ftn block we got to point to the MPLS */
        rc = hwd_mpls_ftn_release_block(ecmp_block_handle);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL:failed to release ftn handle for ECMP %u handle 0x%" PRIx64 "\n",
                       ecmp_id,
                       ecmp_block_handle);
            goto error;
        }
    }
error:
    return rc;
}

sx_status_t flex_acl_clean_nve_action(sx_ip_next_hop_ip_tunnel_t ip_tunnel_id)
{
    sx_status_t     rc = SX_STATUS_SUCCESS;
    sx_acl_pbs_id_t pbs_id = 0;
    uint32_t        ref_count = 0;

    SX_LOG_ENTER();

    rc = flex_acl_db_pbs_nve_ref_dec(ip_tunnel_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL Action forward : failed to decrement NVE PBS [%u]\n", ip_tunnel_id.tunnel_id);
        goto out;
    }
    rc = flex_acl_db_pbs_nve_get(ip_tunnel_id, &pbs_id, &ref_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL action forward action dec ref. flex_acl_db_pbs_nve_get failed, tunnel ID: %u.\n",
                   ip_tunnel_id.tunnel_id);
        goto out;
    }
    if (ref_count == 0) {
        rc = flex_acl_db_pbs_update_ref_count(0, pbs_id, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL clean nve container : failed to decrement PBS [%u]\n", pbs_id);
            goto out;
        }
        rc = flex_acl_nve_tunnel_pbs_del(pbs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL clean mc container : failed to decrement PBS [%u]\n", pbs_id);
            goto out;
        }
        rc = flex_acl_db_pbs_nve_destroy(ip_tunnel_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL clean nve  : failed to delete NVE PBS [%u]\n", ip_tunnel_id.tunnel_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_dec_actions_ref(flex_acl_db_flex_rule_t *rule, sx_acl_region_id_t region_id)
{
    uint32_t                     i = 0, j = 0;
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    flex_acl_rule_id_t           rule_id;
    flex_acl_db_pbs_entry_t     *pbs_entry = NULL;
    sx_ip_next_hop_ip_tunnel_t   ip_tunnel_id;
    sx_tunnel_id_t               tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_mc_container_attributes_t attr;
    hwi_ecmp_hw_block_handle_t   ecmp_handle = INVALID_ECMP_BLOCK_HANDLE;
    boolean_t                    first_ref = TRUE;
    flex_acl_rule_id_t           acl_rule_id = { .region_id = 0 };
    sx_fm_fid_type_t             fid_type = SX_FM_FID_TYPE_INVALID;
    uint32_t                     tunnel_port_bitmap = 0;

    SX_MEM_CLR(attr);

    SX_LOG_ENTER();

    SX_LOG_DBG("FLOWD Dec ref for rule offset:%u \n", rule->offset);

    for (i = 0; i < rule->action_count; i++) {
        switch (rule->actions[i].type) {
        case SX_FLEX_ACL_ACTION_PBS:
            rule_id.region_id = rule->region_id;
            rule_id.offset = rule->offset;
            rc = flex_acl_db_pbs_get_entry(0, rule->actions[i].fields.action_pbs.pbs_id, &pbs_entry);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("__flex_acl_dec_actions_ref, Error at get entry of pbs, pbs id:%u \n",
                           rule->actions[i].fields.action_pbs.pbs_id);
                continue;
            }
            rc = flex_acl_db_pbs_del_rule_from_list(pbs_entry, rule_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL action forward: Failed deleting rule from PBS, region_id: %u, offset: %u\n",
                           rule_id.region_id, rule_id.offset);
                continue;
            }
            rc = flex_acl_db_pbs_update_ref_count(0, rule->actions[i].fields.action_pbs.pbs_id, FALSE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL Action forward action dec ref : failed to increment PBS [%u]\n",
                           rule->actions[i].fields.action_pbs.pbs_id);
                flex_acl_db_pbs_add_rule_to_list(pbs_entry, rule_id);
                continue;
            }
            SX_LOG_DBG("FLOWD ACL PBS ref DEC \n");
            break;

        case SX_FLEX_ACL_ACTION_MC:
            rule_id.region_id = rule->region_id;
            rule_id.offset = rule->offset;
            rc = flex_acl_clean_mc_container_action(
                rule->actions[i].fields.action_mc.mc_container_id, rule->actions[i].type, rule_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL MC action failed flex_acl_clean_mc_container_action failed, MC container: %u\n",
                           rule->actions[i].fields.action_mc.mc_container_id);
                continue;
            }
            rc = sdk_mc_container_ref_dec(rule->actions[i].fields.action_mc.mc_container_id,
                                          &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL Free action failed sdk_mc_container_ref_dec, MC container: %u\n",
                           rule->actions[i].fields.action_mc.mc_container_id);
                continue;
            }
            SX_LOG_DBG("FLOWD ACL free third party MC DEC handle:%d\n",
                       rule->actions[i].fields.action_mc.mc_container_id);
            break;

        case SX_FLEX_ACL_ACTION_MC_ROUTE:
            rc = sdk_mc_container_ref_dec(rule->actions[i].fields.action_mc_route.egress_mc_container,
                                          &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL MC action failed sdk_mc_container_ref_dec failed %u \n",
                           rule->actions[i].fields.action_mc_route.egress_mc_container);
                continue;
            }
            break;

        case SX_FLEX_ACL_ACTION_COUNTER:
            rc = flow_counter_ref_dec(rule->actions[i].fields.action_counter.counter_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL counter action failed flow_counter_ref_dec failed, counter_id: %u\n",
                           rule->actions[i].fields.action_counter.counter_id);
                continue;
            }
            SX_LOG_DBG("FLOWD ACL cm ref DEC \n");
            break;

        case SX_FLEX_ACL_ACTION_POLICER:
            rc = policer_manager_ref_delete(rule->actions[i].fields.action_policer.policer_id,
                                            POLICER_MANAGER_GLOBAL_POLICER_TYPE_GET(
                                                rule->actions[i].fields.action_policer.policer_id));
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL policer action failed policer_manager_ref_delete failed, policer_id: %" PRIu64 "\n",
                           rule->actions[i].fields.action_policer.policer_id);
                continue;
            }
            SX_LOG_DBG("FLOWD ACL policer ref DELETE \n");
            break;

        case SX_FLEX_ACL_ACTION_TRUNCATION:
            rc = truncation_profile_refcount_dec(&rule->actions[i].fields.action_truncation.trunc_profile_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "ACL truncation action failed truncation_profile_refcount_dec failed, trunc_profile id: %d.\n",
                    rule->actions[i].fields.action_truncation.trunc_profile_id.trunc_profile_id.acl_trunc_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_EGRESS_MIRROR:
            rc = flex_acl_db_egress_mirror_actions_count_dec(region_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL EGRESS_MIRROR action failed flex_acl_db_egress_mirror_actions_count_inc failed :%d \n",
                           rule->actions[i].fields.action_mirror.session_id);
                continue;
            }

        /* fall through */
        case SX_FLEX_ACL_ACTION_MIRROR:
            rc = span_session_ref_cnt_dec(acl_span_handle, rule->actions[i].fields.action_mirror.session_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL Free action failed span_session_ref_cnt_dec, span_session_id: %u\n",
                           rule->actions[i].fields.action_mirror.session_id);
                goto out;
            }
            SX_LOG_DBG("FLOWD ACL free third party span DEC span handle:%p id: %d\n",
                       acl_span_handle, rule->actions[i].fields.action_mirror.session_id);
            break;

        case SX_FLEX_ACL_ACTION_TUNNEL_DECAP:
            rc = sdk_tunnel_impl_ref_decrease(rule->actions[i].fields.action_tunnel_decap.tunnel_id,
                                              &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL Free action failed sdk_tunnel_impl_ref_decrease, tunnel ID: %u\n",
                           rule->actions[i].fields.action_tunnel_decap.tunnel_id);
                continue;
            }
            SX_LOG_DBG("FLOWD ACL free third party tunnel decap DEC handle:%d\n",
                       rule->actions[i].fields.action_tunnel_decap.tunnel_id);
            break;

        case SX_FLEX_ACL_ACTION_NVE_TUNNEL_ENCAP:
            if (rule->actions[i].fields.action_nve_tunnel_encap.encap_type ==
                SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_NEXT_HOP) {
                ip_tunnel_id.tunnel_id = rule->actions[i].fields.action_nve_tunnel_encap.tunnel_id;
                ip_tunnel_id.underlay_dip = rule->actions[i].fields.action_nve_tunnel_encap.underlay_dip;
                rc = flex_acl_clean_nve_action(ip_tunnel_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_NTC("ACL MC action failed flex_acl_clean_nve_action failed, tunnel ID: %u\n",
                               rule->actions[i].fields.action_nve_tunnel_encap.tunnel_id);
                    continue;
                }
                rc = sdk_tunnel_impl_ref_decrease(rule->actions[i].fields.action_nve_tunnel_encap.tunnel_id,
                                                  &rule->action_refs[i].ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_NTC("ACL Free action failed sdk_tunnel_impl_ref_decrease, tunnel ID: %u\n",
                               rule->actions[i].fields.action_nve_tunnel_encap.tunnel_id);
                    continue;
                }
            } else if (rule->actions[i].fields.action_nve_tunnel_encap.encap_type ==
                       SX_FLEX_ACL_FLEX_ACTION_NVE_TUNNEL_ENCAP_TYPE_ECMP) {
                /* Get ECMP container type and handle via ECMP ID */
                rc = sdk_router_ecmp_impl_active_set_get(rule->actions[i].fields.action_nve_tunnel_encap.ecmp_id,
                                                         &ecmp_handle,
                                                         NULL);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to get ECMP data [ECMP ID = %u; error = %s].\n",
                               rule->actions[i].fields.action_nve_tunnel_encap.ecmp_id,
                               sx_status_str(rc));
                    goto out;
                }

                /* Clean ECMP DB record */
                rc = flex_acl_clean_ecmp_action(ecmp_handle, rule->actions[i].type, rule_id);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to clean ECMP action [ECMP handle = 0x%" PRIx64 "; error = %s].\n",
                               ecmp_handle, sx_status_str(rc));
                    goto out;
                }

                /* Decrease the reference to the ECMP container */
                rc = sdk_router_ecmp_impl_external_ref_dec(rule->actions[i].fields.action_nve_tunnel_encap.ecmp_id,
                                                           &rule->action_refs[i].ref,
                                                           NULL);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("Failed to decrease ECMP refcount [ECMP ID = %u; error = %s].\n",
                               rule->actions[i].fields.action_nve_tunnel_encap.ecmp_id,
                               sx_status_str(rc));
                    goto out;
                }
            }
            break;

        case SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP:
            rule_id.region_id = rule->region_id;
            rule_id.offset = rule->offset;
            rc = flex_acl_clean_mc_container_action(
                rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id, rule->actions[i].type,
                rule_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC(
                    "ACL MC Tunnel action failed flex_acl_clean_mc_container_action failed, MC container: %u\n",
                    rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id);
                continue;
            }
            rc = sdk_mc_container_ref_dec(rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                                          &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL Free action failed sdk_mc_container_ref_dec, MC container: %u\n",
                           rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id);
                continue;
            }

            rc = sdk_mc_container_tunnel_bitmap_get(rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                                                    &tunnel_port_bitmap);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get tunnel bitmap by MC container ID[%u], rc [%s]\n",
                           rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                           sx_status_str(rc));
                goto out;
            }

            if (tunnel_port_bitmap & (1 << SX_PORT_TUNNEL_NVE)) {
                rc = sdk_tunnel_impl_tunnel_id_by_log_port_get(SX_TUNNEL_PORT_ID_NVE, &tunnel_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to get tunnel ID for the NVE port, error: %s \n",
                               sx_status_str(rc));
                    goto out;
                }

                rc = sdk_mc_container_impl_get(rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                                               NULL, NULL, &attr, NULL);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to get FID by MC container ID[%u], rc [%s]\n",
                               rule->actions[i].fields.action_nve_mc_tunnel_encap.mc_container_id,
                               sx_status_str(rc));
                    goto out;
                }

                if (attr.type != SX_MC_CONTAINER_TYPE_VLAN_UNAWARE) {
                    /* MC container is FID aware, thus we decrease the tunnel reference */
                    rc = sdk_tunnel_impl_map_entry_ref_inc_dec(SX_ACCESS_CMD_DELETE,
                                                               tunnel_id, attr.fid,
                                                               &acl_mc_name_data,
                                                               &rule->action_refs[i].extra_ref);
                    if (SX_STATUS_SUCCESS != rc) {
                        SX_LOG_NTC("Failed to decrease tunnel mapping ref for tunnel[0x%08x] and fid (%u)\n",
                                   tunnel_id, attr.fid);
                        continue;
                    }
                }
            }
            break;

        case SX_FLEX_ACL_ACTION_GOTO:
            if ((rule->actions[i].fields.action_goto.goto_action_cmd == SX_ACL_ACTION_GOTO_JUMP) ||
                (rule->actions[i].fields.action_goto.goto_action_cmd == SX_ACL_ACTION_GOTO_CALL)) {
                rc = flex_acl_db_group_rules_ref_cnt_update(rule->actions[i].fields.action_goto.acl_group_id,
                                                            FALSE,
                                                            &rule->goto_rule_ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_NTC("ACL:failed to remove acl rule reference to group %u \n",
                               rule->actions[i].fields.action_goto.acl_group_id);
                    continue;
                }
                rule->goto_rule_ref = 0;
            }
            break;

        case SX_FLEX_ACL_ACTION_SET_ROUTER:
            rc =
                sdk_router_vrid_impl_refcnt_dec(rule->actions[i].fields.action_set_router.vrid,
                                                &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL Free action failed sdk_router_vrid_impl_refcnt_dec, vrid: %u\n",
                           rule->actions[i].fields.action_set_router.vrid);
                continue;
            }
            SX_LOG_DBG("FLOWD ACL free third party tunnel decap DEC handle:%u\n",
                       rule->actions[i].fields.action_set_router.vrid);
            break;

        case SX_FLEX_ACL_ACTION_SET_BRIDGE:
            rc = sdk_fid_manager_get_fid_type(rule->actions[i].fields.action_set_bridge.bridge_id, &fid_type);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Failed to get fid (%u) type. rc=[%s]\n",
                           rule->actions[i].fields.action_set_bridge.bridge_id, sx_status_str(rc));
                goto out;
            }

            if (fid_type == SX_FM_FID_TYPE_BRIDGE_REWRITE_E) {
                rc = bridge_ref_cnt_decrease(rule->actions[i].fields.action_set_bridge.bridge_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_NTC("ACL:failed to decrease acl reference to bridge %u \n",
                               rule->actions[i].fields.action_set_bridge.bridge_id);
                    continue;
                }
            } else if (fid_type == SX_FM_FID_TYPE_VLAN_REWRITE_E) {
                rc = vlan_ref_cnt_decrease(0, rule->actions[i].fields.action_set_bridge.bridge_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_NTC("ACL:failed to decrease acl reference to VLAN %u \n",
                               rule->actions[i].fields.action_set_bridge.bridge_id);
                    continue;
                }
            }
            break;

        case SX_FLEX_ACL_ACTION_UC_ROUTE:
            switch (rule->actions[i].fields.action_uc_route.uc_route_type) {
            case SX_UC_ROUTE_TYPE_LOCAL:
                rc = sdk_rif_impl_ref_decrease(rule->actions[i].fields.action_uc_route.uc_route_param.local_egress_rif,
                                               &rule->action_refs[i].ref);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_NTC("ACL:failed to dec ACL reference to RIF %u \n",
                               rule->actions[i].fields.action_uc_route.uc_route_param.local_egress_rif);
                    continue;
                }
                break;

            case SX_UC_ROUTE_TYPE_NEXT_HOP:
                rc = __flex_acl_dec_next_hop_ref(&rule->actions[i], &rule->action_refs[i]);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_NTC("ACL:failed to dec ACL next hop reference to ECMP %u \n",
                               rule->actions[i].fields.action_uc_route.uc_route_param.ecmp_id);
                    continue;
                }
                break;

            default:
                break;
            }
            break;

        case SX_FLEX_ACL_ACTION_AR_UC_ROUTE:
            rc = __flex_acl_dec_next_hop_ref(&rule->actions[i], &rule->action_refs[i]);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("ACL:failed to dec ACL AR reference to ECMP %u \n",
                           rule->actions[i].fields.action_ar_uc_route.ecmp_id);
                continue;
            }
            break;

        case SX_FLEX_ACL_ACTION_PORT_FILTER:
            rc =
                sdk_mc_container_ref_dec(rule->actions[i].fields.action_port_filter.mc_container_id,
                                         &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("Failed sdk_mc_container_ref_dec mc container id:[%u] \n",
                           rule->actions[i].fields.action_port_filter.mc_container_id);
                continue;
            }
            rc = __flex_acl_mc_container_port_ref_dec(rule->actions[i].fields.action_port_filter.mc_container_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("Failed to increment MC container ref id:[%u] \n",
                           rule->actions[i].fields.action_port_filter.mc_container_id);
                continue;
            }
            acl_rule_id.region_id = region_id;
            acl_rule_id.offset = rule->offset;
            rc = flex_acl_db_mc_container_to_rule_refs_delete(MCC_TO_RULE_PORT_FILTER_ACTION,
                                                              rule->actions[i].fields.action_port_filter.mc_container_id,
                                                              &acl_rule_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("Failed to dec port filter rules ref MC container id:[%u]\n",
                           rule->actions[i].fields.action_port_filter.mc_container_id);
                continue;
            }

            break;

        case SX_FLEX_ACL_ACTION_PBILM:
            rc = flex_acl_db_pbilm_ref_dec(rule->actions[i].fields.action_pbilm.pbilm_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_NTC("Failed to decrement pbilm ref for pbilm_id:[%u], \n",
                           rule->actions[i].fields.action_pbilm.pbilm_id);
                continue;
            }
            break;

        case SX_FLEX_ACL_ACTION_SET_EMT:
            for (j = 0; j < SX_FLEX_MODIFIER_EMT_BIND_INDEX_LAST_E; j++) {
                if ((rule->actions[i].fields.action_set_emt.emt_bind_action[j].emt_bind_type !=
                     SX_FLEX_MODIFIER_BIND_TYPE_NOP_E) &&
                    (rule->actions[i].fields.action_set_emt.emt_bind_action[j].emt_bind_type !=
                     SX_FLEX_MODIFIER_BIND_TYPE_DISABLE_E)) {
                    rc = flex_modifier_emt_ref_dec(
                        rule->actions[i].fields.action_set_emt.emt_bind_action[j].emt_bind_type_attr.emt_id.emt_id,
                        (first_ref) ? &rule->action_refs[i].ref : &rule->action_refs[i].extra_ref);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed to decrement flex modifier EMT id:[%u]\n",
                                   rule->actions[i].fields.action_set_emt.emt_bind_action[j].emt_bind_type_attr.emt_id.emt_id);
                        goto out;
                    }
                    first_ref = FALSE;
                }
            }
            break;

        case SX_FLEX_ACL_ACTION_NAT:
            rc = sdk_nat_4to6_ref_dec(rule->actions[i].fields.action_nat.nat_id, &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to decrement NAT IPv4/IPv6 [%u] ACL action reference\n",
                           rule->actions[i].fields.action_nat.nat_id);
                goto out;
            }
            break;

        case SX_FLEX_ACL_ACTION_STATEFUL_DB:
            rc = stateful_db_key_id_ref_dec(rule->actions[i].fields.action_stateful_db.stateful_key_id,
                                            &rule->action_refs[i].ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to decrement stateful DB key ID [%u] ACL action reference\n",
                           rule->actions[i].fields.action_stateful_db.stateful_key_id);
                goto out;
            }
            rc = stateful_db_partition_ref_dec(rule->actions[i].fields.action_stateful_db.partition_id,
                                               &rule->action_refs[i].extra_ref);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to decrement stateful DB partition [%u] ACL action reference\n",
                           rule->actions[i].fields.action_stateful_db.partition_id);
                goto out;
            }

            break;

        case SX_FLEX_ACL_ACTION_FLOW_ESTIMATOR:
            rc = flow_counter_ref_dec(rule->actions[i].fields.action_flow_estimator.counter.base_counter_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL counter action failed flow_counter_ref_dec failed, counter_id: %u\n",
                           rule->actions[i].fields.action_flow_estimator.counter.base_counter_id);
                continue;
            }
            rc = flow_estimator_profile_ref_dec(&(rule->actions[i].fields.action_flow_estimator.profile_key));
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL counter action failed flow_estimator_profile_ref_dec failed, profile id: %u\n",
                           rule->actions[i].fields.action_flow_estimator.profile_key.profile_id);
                continue;
            }
            break;

        default:
            break;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_keys_update_rules_references_on_rule_move(sx_acl_region_id_t   region_id,
                                                                        sx_acl_rule_offset_t block_start,
                                                                        sx_acl_rule_offset_t new_block_start,
                                                                        sx_acl_size_t        size)
{
    uint32_t                 ri, ai;
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_rule_id_t       rule_id;
    sx_mc_container_id_t     mc_container_id;
    flex_acl_db_flex_rule_t *rule = NULL;

    SX_LOG_ENTER();

    rule_id.region_id = region_id;

    for (ri = 0; ri < size; ri++) {
        rc = flex_acl_db_get_rule_by_offset(region_id, block_start + ri, &rule);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get rule from db for region [%u] offset [%u]\n", region_id, block_start + ri);
            goto out;
        }
        if (rule->valid == FLEX_ACL_RULE_INVALID) {
            continue;
        }
        for (ai = 0; ai < rule->key_desc_count; ai++) {
            switch (rule->key_desc_list[ai].key_id) {
            case FLEX_ACL_KEY_RX_LIST:
            case FLEX_ACL_KEY_RX_TUNNEL_LIST:
                rule_id.offset = block_start + ri;

                SX_LOG_DBG("RX_LIST :%u DELETE rule reference %u %u from list \n",
                           rule->key_desc_list[ai].key.rx_list,
                           region_id,
                           rule_id.offset);

                rc = flex_acl_db_update_rules_ref_rx_list(rule->key_desc_list[ai].key.rx_list,
                                                          &rule_id,
                                                          SX_ACCESS_CMD_SOFT_DELETE);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL : Failed to delete rule from db for region [%u] offset [%u]\n",
                               region_id,
                               block_start + ri);
                    goto out;
                }
                rule_id.offset = new_block_start + ri;
                SX_LOG_DBG("RX_LIST :%u add rule reference %u %u from list \n",
                           rule->key_desc_list[ai].key.rx_list,
                           region_id,
                           rule_id.offset);
                rc = flex_acl_db_update_rules_ref_rx_list(rule->key_desc_list[ai].key.rx_list,
                                                          &rule_id,
                                                          SX_ACCESS_CMD_SOFT_ADD);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL : Failed to add rule from db for region [%u] offset [%u]\n",
                               region_id,
                               block_start + ri);
                    goto out;
                }
                break;

            case FLEX_ACL_KEY_RX_PORT_LIST:
            case FLEX_ACL_KEY_RX_PORT_LIST_1_128:
            case FLEX_ACL_KEY_RX_PORT_LIST_129_258:
            case FLEX_ACL_KEY_RX_PORT_LIST_0:
            case FLEX_ACL_KEY_RX_PORT_LIST_1:
            case FLEX_ACL_KEY_RX_PORT_LIST_2:
            case FLEX_ACL_KEY_RX_PORT_LIST_3:
            case FLEX_ACL_KEY_TX_PORT_LIST:
            case FLEX_ACL_KEY_TX_PORT_LIST_1_128:
            case FLEX_ACL_KEY_TX_PORT_LIST_129_258:
            case FLEX_ACL_KEY_TX_PORT_LIST_0:
            case FLEX_ACL_KEY_TX_PORT_LIST_1:
            case FLEX_ACL_KEY_TX_PORT_LIST_2:
            case FLEX_ACL_KEY_TX_PORT_LIST_3:

                rc = flex_acl_key_port_list_get_info(&rule->key_desc_list[ai], &mc_container_id, NULL, NULL);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("ACL: Reference updated failed port list info get for key type [%u]\n",
                               rule->key_desc_list[ai].key_id);
                    goto out;
                }

                rule_id.offset = block_start + ri;

                SX_LOG_DBG("%s: %u DELETE rule reference %u %u from list \n",
                           flex_acl_db_key_id_to_str(rule->key_desc_list[ai].key_id),
                           mc_container_id, region_id, rule_id.offset);

                rc =
                    flex_acl_db_mc_container_to_rule_refs_delete(MCC_TO_RULE_PORT_LIST_KEY, mc_container_id, &rule_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL : Failed to delete rule from db for region [%u] offset [%u]\n",
                               region_id, block_start + ri);
                    goto out;
                }
                rule_id.offset = new_block_start + ri;
                SX_LOG_DBG("%s: %u add rule reference %u %u from list \n",
                           flex_acl_db_key_id_to_str(rule->key_desc_list[ai].key_id),
                           mc_container_id, region_id, rule_id.offset);
                rc = flex_acl_db_mc_container_to_rule_refs_add(MCC_TO_RULE_PORT_LIST_KEY, mc_container_id, &rule_id);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL : Failed to add rule from db for region [%u] offset [%u]\n",
                               region_id, block_start + ri);
                    goto out;
                }
                break;

            default:
                break;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_actions_update_rules_list(sx_acl_region_id_t   region_id,
                                                        sx_acl_rule_offset_t block_start,
                                                        sx_acl_rule_offset_t new_block_start,
                                                        sx_acl_size_t        size,
                                                        boolean_t            is_del)
{
    uint32_t                   ri, ai;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_rule_id_t         rule_id;
    flex_acl_db_pbs_entry_t   *pbs_entry = NULL;
    flex_acl_db_flex_rule_t   *rule = NULL;
    flex_acl_bind_attribs_id_t attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    sx_acl_pbs_id_t            pbs_id = 0;
    uint32_t                   ref_count = 0;
    flex_acl_rule_id_t         acl_rule_id = { .region_id = 0 };

    SX_LOG_ENTER();

    SX_LOG_DBG("Update action pbs rules list region:%u  old offset:%u new offset :%u \n",
               region_id,
               block_start,
               new_block_start);

    rule_id.region_id = region_id;
    /* Remove old offset from PBS list */
    for (ri = 0; ri < size; ri++) {
        rc = flex_acl_db_get_rule_by_offset(region_id, block_start + ri, &rule);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get rule from db for region [%u] offset [%u]\n", region_id, block_start + ri);
            goto out;
        }
        if (rule->valid == FLEX_ACL_RULE_INVALID) {
            continue;
        }
        for (ai = 0; ai < rule->action_count; ai++) {
            switch (rule->actions[ai].type) {
            case SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP:
                rc = flex_acl_db_pbs_mc_get(rule->actions[ai].fields.action_nve_mc_tunnel_encap.mc_container_id,
                                            &pbs_id,
                                            &ref_count,
                                            SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "ACL __flex_acl_actions_update_rules_list. flex_acl_db_pbs_mc_get failed, mc_container_id: %u.\n",
                        rule->actions[ai].fields.action_nve_mc_tunnel_encap.mc_container_id);
                    goto out;
                }

            /* fall through */
            case SX_FLEX_ACL_ACTION_PBS:
                if (rule->actions[ai].type == SX_FLEX_ACL_ACTION_PBS) {
                    pbs_id = rule->actions[ai].fields.action_pbs.pbs_id;
                }
                rc = flex_acl_db_pbs_get_entry(0, pbs_id, &pbs_entry);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed fetch PBS id %u\n", pbs_id);
                    goto out;
                }
                if (is_del) {
                    rule_id.offset = block_start + ri;
                    SX_LOG_DBG("PBS :%u DELETE rule %u %u from list \n", pbs_entry->pbs_id, region_id, rule_id.offset);
                    rc = flex_acl_db_pbs_del_rule_from_list(pbs_entry, rule_id);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("ACL : Failed to delete rule from db for region [%u] offset [%u]\n",
                                   region_id,
                                   block_start + ri);
                        goto out;
                    }
                } else {
                    rule_id.offset = new_block_start + ri;
                    rc = flex_acl_db_pbs_add_rule_to_list(pbs_entry, rule_id);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("ACL : Failed to add rule from db for region [%u] offset [%u]\n",
                                   region_id,
                                   block_start + ri);
                        goto out;
                    }
                }
                break;

            case SX_FLEX_ACL_ACTION_GOTO:
                /* if group id is in rule - the group bound on hw */
                if ((rule->actions[ai].fields.action_goto.goto_action_cmd == SX_ACL_ACTION_GOTO_JUMP) ||
                    (rule->actions[ai].fields.action_goto.goto_action_cmd == SX_ACL_ACTION_GOTO_CALL)) {
                    attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
                    /* get bind attributes of group */
                    rc = flex_acl_db_acl_group_get_bind_attribs_id(rule->actions[ai].fields.action_goto.acl_group_id,
                                                                   &attribs_id);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("failed to get bind attributes id of group[%x]\n",
                                   rule->actions[ai].fields.action_goto.acl_group_id);
                        goto out;
                    }
                    if (is_del) {
                        rc = flex_acl_db_attribs_unbind_rule(attribs_id, region_id, block_start + ri);
                        if (rc != SX_STATUS_SUCCESS) {
                            SX_LOG_ERR("Failed to unbind attributes id[%u] from rule offset[%x], region_id[%x]\n",
                                       attribs_id,
                                       block_start + ri,
                                       region_id);
                            goto out;
                        }
                    } else {
                        rc = flex_acl_db_attribs_bind_rule(attribs_id, region_id, new_block_start + ri);
                        if (rc != SX_STATUS_SUCCESS) {
                            SX_LOG_ERR("Failed to bind attributes id[%u] from rule offset[%x], region_id[%x]\n",
                                       attribs_id,
                                       block_start + ri,
                                       region_id);
                            goto out;
                        }
                    }
                }
                break;

            case SX_FLEX_ACL_ACTION_PORT_FILTER:
                acl_rule_id.region_id = region_id;
                acl_rule_id.offset = rule->offset;
                if (is_del) {
                    rc = flex_acl_db_mc_container_to_rule_refs_delete(MCC_TO_RULE_PORT_FILTER_ACTION,
                                                                      rule->actions[ai].fields.action_port_filter.mc_container_id,
                                                                      &acl_rule_id);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed to add port filter rules move ref MC container id:[%u]\n",
                                   rule->actions[ai].fields.action_port_filter.mc_container_id);
                        goto out;
                    }
                } else {
                    rc = flex_acl_db_mc_container_to_rule_refs_add(MCC_TO_RULE_PORT_FILTER_ACTION,
                                                                   rule->actions[ai].fields.action_port_filter.mc_container_id,
                                                                   &acl_rule_id);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed to delete port filter rules move ref MC container id:[%u]\n",
                                   rule->actions[ai].fields.action_port_filter.mc_container_id);
                        goto out;
                    }
                }

                break;

            default:
                break;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_actions_update_rules_list_delete(sx_acl_region_id_t   region_id,
                                                               sx_acl_rule_offset_t block_start,
                                                               sx_acl_rule_offset_t new_block_start,
                                                               sx_acl_size_t        size)
{
    return __flex_acl_actions_update_rules_list(region_id, block_start, new_block_start, size, TRUE);
}

static sx_status_t __flex_acl_actions_update_rules_list_add(sx_acl_region_id_t   region_id,
                                                            sx_acl_rule_offset_t block_start,
                                                            sx_acl_rule_offset_t new_block_start,
                                                            sx_acl_size_t        size)
{
    return __flex_acl_actions_update_rules_list(region_id, block_start, new_block_start, size, FALSE);
}

static sx_status_t __flex_acl_delete_rule_refs(sx_acl_region_id_t region_id, flex_acl_db_flex_rule_t *rule)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = __flex_acl_rules_keys_ref_update(rule, FALSE, region_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL:  Rule delete failed to delete ref count for keys. region:%d offset :%d\n",
                   rule->region_id,
                   rule->offset);
        goto out;
    }
    rc = __flex_acl_dec_actions_ref(rule, region_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Rule delete failed to decrease ref count, region_id: %u\n", region_id);
        goto out;
    }

    rc = __flex_acl_drop_trap_hw_db_del(rule);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Rule delete failed to delete from acl drop db, region_id: %u\n", region_id);
        goto out;
    }

out:
    return rc;
}

sx_status_t __flex_acl_rules_delete(sx_api_flex_acl_rules_set_params_t *params,
                                    flex_acl_db_flex_rule_t            *rules,
                                    flex_acl_db_acl_region_t           *region)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    uint32_t                 i = 0;
    uint32_t                 old_valid_rules_num = 0;
    flex_acl_db_flex_rule_t *rule = NULL;

    rc = flex_acl_db_verify_rules_exist(params->region_id, rules, params->rules_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Not all rules exist in the region %u\n", params->region_id);
        goto out;
    }
    /* Invalidate all rules */
    for (i = 0; i < params->rules_count; i++) {
        rules[i].valid = FLEX_ACL_RULE_INVALID;
    }

    rc = __flex_acl_update_rules_to_devs(region,
                                         rules,
                                         params->rules_count,
                                         FLEX_ACL_HW_FULL_WRITE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to write rules to dev \n");
        goto out;
    }

    old_valid_rules_num = region->valid_rules_num;

    for (i = 0; i < params->rules_count; i++) {
        rc = flex_acl_db_get_rule_by_offset(region->region_id, rules[i].offset, &rule);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get rule from db for offset [%u]\n", rules[i].offset);
            return rc;
        }
        if (rule->valid == FLEX_ACL_RULE_VALID) {
            rc = __flex_acl_delete_rule_refs(params->region_id, rule);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL:  failed to delete refs for rule delete. region:%d offset :%d\n",
                           rules[i].region_id,
                           rules[i].offset);
                goto out;
            }
        }
    }

    rc = flex_acl_db_invalidate_rules(params->region_id, params->offsets_list_p,
                                      params->rules_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to invalidate rules in region ID [%u]\n", params->region_id);
        goto out;
    }

    rc = flex_acl_db_delete_rules(params->region_id, params->offsets_list_p,
                                  params->rules_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to delete rules in region ID [%u]\n", params->region_id);
        goto out;
    }

    rc = flex_acl_rm_entries_set(region->valid_rules_num, old_valid_rules_num,
                                 region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to invalidate rules in region ID [%u]\n", params->region_id);
        goto out;
    }

out:
    return rc;
}

sx_status_t flex_acl_rules_set(sx_api_flex_acl_rules_set_params_t *params)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* checks if Region ID is legal */
    if (FLEX_ACL_REGION_BIT_CHECK(params->region_id)) {
        SX_LOG_ERR("ACL: Region ID is not valid, region_id[%#x].\n", params->region_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* check that region id is not system */
    rc = flex_acl_db_region_entry_type_get(params->region_id, &entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get region entry type, region_id[%#x].\n", params->region_id);
        goto out;
    }

    if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL: Region access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_rules_set_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc, "ACL : Failed to set rules, region_id [%#x] rc:%s.\n",
                                 params->region_id, sx_status_str(rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* the function separates user level from system level and checks that id provided by user is
 * not id belonging to system */
sx_status_t flex_acl_rules_set_internal(sx_api_flex_acl_rules_set_params_t *params)
{
    return __flex_acl_rules_set_internal(params, TRUE);
}

static sx_status_t __flex_acl_rules_set_internal(sx_api_flex_acl_rules_set_params_t *params, boolean_t flex)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *acl_region = NULL;
    flex_acl_db_flex_rule_t  *rules = NULL;
    uint32_t                  i = 0, j = 0;
    uint32_t                  current_offset = 0, offset_count = 0;
    flex_acl_db_acl_table_t  *acl_table = NULL;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (params->rules_count == 0) {
        SX_LOG_ERR("Invalid rules block size\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_db_region_get(params->region_id, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL region id [%u]\n", params->region_id);
        goto out;
    }

    if (flex) {
        if (acl_region->bound_acl == FLEX_ACL_INVALID_ACL_ID) {
            SX_LOG_ERR("ACL : The region id [%u] are not bound to acl, failed to set rule\n", params->region_id);
            rc = SX_STATUS_ERROR;
            goto out;
        }

        rc = flex_acl_db_acl_get(acl_region->bound_acl, &acl_table);
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("ACL : Failed get an ACL table.\n");
            goto out;
        }

        if ((acl_table->direction == SX_ACL_DIRECTION_MULTI_POINTS_E) &&
            (acl_table->acl_attributes.multi_direction.acl_direction_bitmap == 0)) {
            SX_LOG_ERR("ACL : ACL direction bitmap is not set, region id [%u], acl id [%u] failed to set rule\n",
                       params->region_id, acl_table->acl_id);
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    /* validate that rules are in region size boundaries */
    for (i = 0; i < params->rules_count; i++) {
        if (params->offsets_list_p[i] >= (acl_region->size - acl_region->reserved_rules_num)) {
            SX_LOG_ERR("ACL : At least one of the rules has an offset which exceeds the region size\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        current_offset = params->offsets_list_p[i];
        offset_count = 0;
        for (j = i + 1; j < params->rules_count; j++) {
            if (current_offset == params->offsets_list_p[j]) {
                offset_count++;
            }
        }
        if (offset_count > 0) {
            SX_LOG_ERR("ACL : The offset %d received twice in offset list \n", current_offset);
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (params->cmd == SX_ACCESS_CMD_SET) {
            /*
             * We allow rules to carry no priority, in this case we need to
             * convert rule's offset to a valid priority
             */
            if (acl_region->rules_priority_mode == FLEX_RULES_PRIORITY_MODE_UNSET) {
                acl_region->rules_priority_mode = FLEX_RULES_PRIORITY_MODE_LEGACY; /*
                                                                                    * We allow rules to carry no priority, in this case we need to
                                                                                    * convert rule's offset to a valid priority
                                                                                    */
                if (params->rules[i].priority != FLEX_ACL_INVALID_RULE_PRIORITY) {
                    acl_region->rules_priority_mode = FLEX_RULES_PRIORITY_MODE_PRIORITY;
                }
            }
            /* There are 2 modes - priority and legacy.
             * legacy means we translate given offset to priority. In legacy mode we
             * expect there is no rule with explicit priority
             * Validate that this region is in legacy mode
             */
            if (acl_region->rules_priority_mode == FLEX_RULES_PRIORITY_MODE_LEGACY) {
                if (params->rules[i].priority != FLEX_ACL_INVALID_RULE_PRIORITY) {
                    SX_LOG_ERR("ACL : Rule [%d] priority is invalid, should be [%d]\n",
                               current_offset, FLEX_ACL_INVALID_RULE_PRIORITY);
                    rc = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
                /* Calculate priority from offset */
                params->rules[i].priority = FLEX_ACL_OFFSET_TO_PRIO(current_offset);
            } else if ((params->rules[i].priority == FLEX_ACL_INVALID_RULE_PRIORITY) ||
                       (params->rules[i].priority > FLEX_ACL_RULE_PRIORITY_MAX)) {
                SX_LOG_ERR("ACL : Rule [%d] priority is invalid [%d]\n",
                           current_offset, params->rules[i].priority);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
        /* check that actions count and key_desc count are bounded */
    }

    rc = flex_acl_db_allocate_and_fill_rules(params->rules, params->offsets_list_p, params->rules_count, &rules);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error in allocating rules memory.\n");
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_SET:
        rc = __flex_acl_rules_validation(params, acl_region, flex);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed rules validation\n");
            goto out;
        }
        rc = __flex_acl_rules_update(params->region_id, rules, params->rules_count, acl_region);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed update rules\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        rc = __flex_acl_rules_delete(params, rules, acl_region);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed delete rules\n");
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Command is not supported.\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    if (rules) {
        flex_acl_db_free_rules(rules, params->rules_count);
    }
    /* If we're in legacy mode, the priority is artificially created here. We need to restore it to zero. */
    if ((params->cmd == SX_ACCESS_CMD_SET) && (acl_region != NULL) &&
        (acl_region->rules_priority_mode == FLEX_RULES_PRIORITY_MODE_LEGACY)) {
        for (i = 0; i < params->rules_count; i++) {
            params->rules[i].priority = FLEX_ACL_INVALID_RULE_PRIORITY;
        }
    }

    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_get_rules_counts_and_offsets(sx_api_flex_acl_rules_get_params_t *params)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *region = NULL;
    flex_acl_db_flex_rule_t  *db_rule = NULL;
    uint32_t                  i = 0;
    uint32_t                  out_cnt = 0;

    SX_LOG_ENTER();

    if ((params->rules_count == 0) || (params->rules == NULL) || (params->offsets_list_p == NULL)) {
        SX_LOG_ERR("ACL : The parameters are illegal\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_db_region_get(params->region_id, &region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL region id [%u]\n", params->region_id);
        goto out;
    }

    for (i = params->start_offset;
         ((i < (region->size - region->reserved_rules_num)) && (out_cnt < params->rules_count));
         i++) {
        if ((params->rules[out_cnt].key_desc_list_p != NULL) || (params->rules[out_cnt].action_list_p != NULL)) {
            SX_LOG_ERR("The input rule parameters key_p and action_p in rule offset[%u] aren't equal to NULL \n", i);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (region->rules[i].valid) {
            db_rule = &region->rules[i];
            params->rules[out_cnt].action_count = db_rule->action_count;
            params->rules[out_cnt].key_desc_count = db_rule->key_desc_count;
            params->rules[out_cnt].valid = db_rule->valid;
            params->offsets_list_p[out_cnt] = i;
            out_cnt++;
        }
    }
    params->rules_count = out_cnt;
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t __flex_acl_get_rules_by_offset_list(sx_api_flex_acl_rules_get_params_t *params)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *region = NULL;
    flex_acl_db_flex_rule_t  *db_rule = NULL;
    uint32_t                  i = 0;
    uint32_t                  out_cnt = 0;
    sx_acl_rule_offset_t      cur_offset = 0;

    SX_LOG_ENTER();

    if ((params->rules == NULL) || (params->offsets_list_p == NULL)) {
        SX_LOG_ERR("ACL : The parameters are illegal params->rules %p offsets_list_p %p \n",
                   params->rules, params->offsets_list_p);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_db_region_get(params->region_id, &region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL region id [%#x]\n", params->region_id);
        goto out;
    }

    for (i = 0; i < params->rules_count; i++) {
        cur_offset = params->offsets_list_p[i];
        if (cur_offset == SX_ACL_DEFAULT_ACTION_OFFSET) {
            continue;
        }
        if (cur_offset >= (region->size - region->reserved_rules_num)) {
            SX_LOG_ERR("The desired offset[%u] exceeds the region size[%u]\n", cur_offset, region->size);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (!region->rules[cur_offset].valid) {
            SX_LOG_DBG("The rule at desired offset[%u] are invalid\n", cur_offset);
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
    }
    for (i = 0; i < params->rules_count; i++) {
        cur_offset = params->offsets_list_p[i];
        if (cur_offset == SX_ACL_DEFAULT_ACTION_OFFSET) {
            if (ACL_STAGE_IS_FLEX2_OR_ABOVE(g_acl_stage)) {
                db_rule = &region->default_rule;
            } else {
                db_rule = &region->rules[region->size - 1];
            }
        } else {
            db_rule = &region->rules[cur_offset];
        }
        /* copy inner arrays just in case the place for them was allocated */
        if (params->rules[out_cnt].key_desc_list_p != NULL) {
            if (params->rules[out_cnt].key_desc_count < db_rule->key_desc_count) {
                SX_LOG_ERR(
                    "The key count[%u] in parameter's rule[%u] to get are less that region's[%u] rule[%u] key count[%u]\n",
                    params->rules[out_cnt].key_desc_count,
                    out_cnt,
                    region->region_id,
                    i,
                    db_rule->key_desc_count);
                goto out;
            }
            memcpy(params->rules[out_cnt].key_desc_list_p, db_rule->key_desc_list,
                   sizeof(sx_flex_acl_key_desc_t) * db_rule->key_desc_count);
        }
        if (params->rules[out_cnt].action_list_p != NULL) {
            if (params->rules[out_cnt].action_count < db_rule->action_count) {
                SX_LOG_ERR(
                    "The action count[%u] in parameter's db_rule[%u] to get are less that region's[%u] db_rule[%u] action count[%u]\n",
                    params->rules[out_cnt].action_count,
                    out_cnt,
                    region->region_id,
                    i,
                    db_rule->action_count);
                goto out;
            }
            memcpy(params->rules[out_cnt].action_list_p, db_rule->actions,
                   sizeof(sx_flex_acl_flex_action_t) * db_rule->action_count);
        }

        params->rules[out_cnt].action_count = db_rule->action_count;
        params->rules[out_cnt].key_desc_count = db_rule->key_desc_count;
        params->rules[out_cnt].valid = db_rule->valid;
        params->rules[out_cnt].priority = db_rule->priority;
        if (region->rules_priority_mode == FLEX_RULES_PRIORITY_MODE_LEGACY) {
            params->rules[out_cnt].priority = 0;
        }

        out_cnt++;
    }

    params->rules_count = out_cnt;
out:
    SX_LOG_EXIT();
    return rc;
}


/*
 * the get rule flow can be based on offsets list or on start offset.
 * when start offset is given - the system will return all valid rules that start from start offset.
 * current implementation cares only on get rule from db.
 */
sx_status_t flex_acl_rules_get_internal(sx_api_flex_acl_rules_get_params_t *params)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *region = NULL;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }


    switch (params->get_cmd) {
    case RULES_GET_COUNT_E:
        rc = flex_acl_db_region_get(params->region_id, &region);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to find ACL region id [%#x]\n", params->region_id);
            goto out;
        }
        params->rules_count = region->valid_rules_num - region->reserved_rules_num;
        break;

    case RULES_GET_INNER_COUNTS_AND_OFFSET_LIST_E:
        rc = __flex_acl_get_rules_counts_and_offsets(params);
        break;

    case RULES_GET_INNER_COUNTS_BY_OFFSET_LIST_E:
    case RULES_GET_FULL_E:
        rc = __flex_acl_get_rules_by_offset_list(params);
        break;

    default:
        SX_LOG_ERR("ACL : Invalid get command [%u]\n", params->get_cmd);
        rc = SX_STATUS_ERROR;
        break;
    }
    /* the function at current flow will get rules from the db, in feature will be added register get function */
    if (rc != SX_STATUS_SUCCESS) {
        if (rc != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("ACL : Failed to get rules from region id [%u]\n", params->region_id);
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rules_get(sx_api_flex_acl_rules_get_params_t *params)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* checks if Region ID is legal */
    if (FLEX_ACL_REGION_BIT_CHECK(params->region_id)) {
        SX_LOG_ERR("ACL: Region ID is not valid, region_id[%#x].\n", params->region_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* check that region id is not system */
    rc = flex_acl_db_region_entry_type_get(params->region_id, &entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get region entry type, region_id[%#x].\n", params->region_id);
        goto out;
    }

    if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL: Region access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_rules_get_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        if (rc != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("ACL : Failed to get rules, region_id[%#x].\n", params->region_id);
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}
/**
 * Validate that region not bounded to any acl.
 */
sx_status_t __validate_acl_region(sx_acl_region_id_t id)
{
    flex_acl_db_acl_region_t *region_p = NULL;
    sx_status_t               rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_db_region_get(id, &region_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get region id %d \n", id);
        goto out;
    }

    if (region_p->bound_acl != FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG_ERR("ACL : region ID %u is already bound to ACL.\n", id);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __acl_create_and_set(sx_api_flex_acl_set_params_t *params)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_status_t              rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_table_t *acl_table = NULL;

    SX_LOG_ENTER();

    /* Check Validity of ACL regions */
    rc = __validate_acl_region(params->region_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Bad ACL region was provided, region_id: %u\n", params->region_id);
        return rc;
    }
    /* Allocate new ACL, check that are available resources*/
    rc = flex_acl_db_acl_allocate(&(params->acl_id), params->acl_direction);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to allocate ACL id \n");
        return rc;
    }
    /* update regions with the binding ACL*/
    rc = flex_acl_db_set_acl_attributes(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set ACL attributes DB \n");
        goto out;
    }

    rc = flex_acl_db_set_region_acl_table(params->region_id, params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to bind between ACL [%u] to region [%u]\n", params->acl_id, params->region_id);
        goto acl_destroy;
    }

    rc = flex_acl_db_acl_get(params->acl_id, &acl_table);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get new ACL table from DB for region [%u].\n", params->region_id);
        goto acl_db_region_remove;
    }
    /* Write the ACL to the hardware */
    rc = flex_acl_hw_reg_write_acls(acl_table, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to create ACL [%u] in HW for region [%u].\n", params->acl_id, params->region_id);
        goto acl_db_region_remove;
    }

    goto out;

acl_db_region_remove:
    rb_rc = flex_acl_db_set_region_acl_table(params->region_id, FLEX_ACL_INVALID_ACL_ID);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at set region acl rollback, err [%s]\n", sx_status_str(rb_rc));
    }
acl_destroy:
    rb_rc = flex_acl_db_acl_destroy(params->acl_id);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at destroy acl rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* This function will clear resources, allowed only on non-dirty ACL*/
sx_status_t __acl_clean_and_destroy(sx_api_flex_acl_set_params_t *params)
{
    sx_status_t                                 rc = SX_STATUS_SUCCESS;
    sx_status_t                                 rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_table_t                    *acl_table = NULL;
    sx_acl_id_t                                 group_id = FLEX_ACL_INVALID_ACL_ID;
    uint8_t                                     groups_count = 0;
    boolean_t                                   adhoc_group = FALSE;
    sx_api_acl_flex_default_action_set_params_t default_action_params;
    sx_api_acl_flex_default_action_get_params_t flex_default_action_get_params;

    SX_LOG_ENTER();

    rc = flex_acl_db_acl_get(params->acl_id, &acl_table);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL id [%u]\n", params->acl_id);
        goto out;
    }

    /* should db check that acl is not in any acl group */
    /* Note: It is assumed here that if an ACL in not part of a group it's also not bound to any port/rif etc. */
    groups_count = cl_list_count(&(acl_table->bound_group_list));
    if (groups_count != 0) {
        SX_LOG_ERR("ACL : Can not destroy ACL id %d ,groups count %u\n", params->acl_id, groups_count);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    rc = __flex_acl_delete_all_rules_from_region(acl_table->bound_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("failed to delete all rules from region %u\n", acl_table->bound_region);
        goto out;
    }

    /* Unset default actions */
    if (flex_acl_ops_g->acl_default_action_needed_p()) {
        SX_MEM_CLR(flex_default_action_get_params);

        flex_default_action_get_params.region_id = acl_table->bound_region;
        if (flex_acl_default_actions_get(&flex_default_action_get_params) == SX_STATUS_SUCCESS) {
            SX_MEM_CLR(default_action_params);
            default_action_params.cmd = SX_ACCESS_CMD_UNSET; /* Set a NOP action as a default action */
            default_action_params.region_id = acl_table->bound_region;

            rc = flex_acl_default_actions_set(&default_action_params);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL : Failed to unset default actions for region id %d\n", acl_table->bound_region);
            }
        }
    }

    if (acl_table->adhoc_acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
        /* destroy the group created for direct acl bind */
        rc = flex_acl_clean_adhoc_acl_group(params->acl_id, TRUE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to clean system group that allocated for direct binding, acl id [%u]\n",
                       params->acl_id);
            goto out;
        }
        adhoc_group = TRUE;
    }

    /* update regions with the binding ACL*/
    rc = flex_acl_db_set_region_acl_table(acl_table->bound_region, FLEX_ACL_INVALID_ACL_ID);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set acl table in region id [%u]\n", acl_table->bound_region);
        goto rollback_adhoc_group;
    }

    /* No rollback for these operations on */
    rc = flex_acl_hw_reg_write_acls(acl_table, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at write acl [%u] to register.\n", params->acl_id);
        goto rollback;
    }

    rc = flex_acl_db_acl_destroy(params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL id [%u]\n", params->acl_id);
        goto out;
    }
    goto out;


rollback:
    rb_rc = flex_acl_db_set_region_acl_table(acl_table->bound_region, params->acl_id);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_adhoc_group:
    if (adhoc_group) {
        rb_rc = flex_acl_allocate_adhoc_acl_group(params->acl_id, &group_id);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_redirect_acl_set(sx_api_acl_set_params_t *params)
{
    sx_status_t                  rc = SX_STATUS_SUCCESS;
    sx_api_flex_acl_set_params_t flex_cmd_body_p;

    SX_LOG_ENTER();

    flex_cmd_body_p.cmd = params->cmd;
    flex_cmd_body_p.acl_id = params->acl_id;
    flex_cmd_body_p.acl_direction = params->acl_direction;
    switch (params->acl_type) {
    case SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC:
        flex_cmd_body_p.region_id = params->region_group.regions.acl_packet_agnostic.region;
        rc = flex_acl_set(&flex_cmd_body_p);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }
        params->acl_id = flex_cmd_body_p.acl_id;
        break;

    case SX_ACL_TYPE_PACKET_TYPES_SENSITIVE:
    default:
        if (params->cmd == SX_ACCESS_CMD_DESTROY) {
            rc = flex_acl_set(&flex_cmd_body_p);
            if (rc != SX_STATUS_SUCCESS) {
                goto out;
            }
        } else {
            rc = SX_STATUS_PARAM_ERROR;
        }
        break;
    }

    SX_LOG_EXIT();
out:
    return rc;
}

/**
 *  This function is used to create ACL (rules list).
 *  for creation use command CREATE and supply key_type and
 *  size. acl_id is returned on successful creation.
 *  for destroying an ACL it is required that the ACL is not
 *  bound and the acl_id should be provided.
 *  EDIT command is used for resizing an existing ACL. acl_id
 *  and new size should be provided.
 *
 * @param[in] params - struct with relevant parameters
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *  @return SX_STATUS_PARAM_ERROR if any input parameter is
 *  invalid
 *  @return SX_STATUS_ENTRY_NOT_FOUND if requested element is
 *  not found in DB
 *  @return SX_STATUS_NO_RESOURCES if no ACL is available to
 *  create
 *  @return SX_STATUS_CMD_UNSUPPORTED if unsupported command is
 *  requested
 */

sx_status_t flex_acl_set_internal(sx_api_flex_acl_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }
    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        rc = __acl_create_and_set(params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to create and set acl\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        rc = __acl_clean_and_destroy(params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed acl deletion\n");
            goto out;
        }
        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("Cmd %d not supported\n", params->cmd);
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_set(sx_api_flex_acl_set_params_t *params)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        rc = flex_acl_db_region_entry_type_get(params->region_id, &entry_type);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get region entry type, region_id[%#x].\n", params->region_id);
            goto out;
        }
        if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
            SX_LOG_ERR("ACL: Region access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        rc = flex_acl_db_acl_entry_type_get(params->acl_id, &entry_type);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get acl entry type, acl_id[%u].\n", params->acl_id);
            goto out;
        }
        if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
            SX_LOG_ERR("ACL: ACL table access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        break;

    default:
        break;
        /* do nothing */
    }

    rc = flex_acl_set_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set acl, acl_id[%u].\n", params->acl_id);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_redirect_acl_get(sx_api_acl_set_params_t *params)
{
    sx_api_flex_acl_set_params_t flex_cmd_body;
    sx_status_t                  rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    memset((void*)&flex_cmd_body, 0, sizeof(flex_cmd_body));

    flex_cmd_body.acl_id = params->acl_id;
    rc = flex_acl_get(&flex_cmd_body);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

    params->cmd = flex_cmd_body.cmd;
    params->acl_direction = flex_cmd_body.acl_direction;
    params->acl_type = SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC;
    params->region_group.regions.acl_packet_agnostic.region = flex_cmd_body.region_id;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_iter_get(sx_api_acl_iter_get_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        SX_LOG_ERR("Input params is NULL\n");
        return SX_STATUS_PARAM_ERROR;
    }
    rc = flex_acl_db_iter_get(params->cmd,
                              params->acl_id_key,
                              &(params->acl_id_filter),
                              params->acl_id_list,
                              &(params->acl_id_cnt));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Iterator failed Key [%u], Count [%d] \n",
                   params->acl_id_key, params->acl_id_cnt);
        return rc;
    }
    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_group_iter_get(sx_api_acl_group_iter_get_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        SX_LOG_ERR("Input params is NULL\n");
        return SX_STATUS_PARAM_ERROR;
    }
    rc = flex_acl_group_db_iter_get(params->cmd,
                                    params->acl_id_key,
                                    &(params->acl_id_filter),
                                    params->acl_id_list,
                                    &(params->acl_id_cnt));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : ACL Group Iterator failed:  Key [%u], Count [%d] \n",
                   params->acl_id_key, params->acl_id_cnt);
        return rc;
    }
    return SX_STATUS_SUCCESS;
}

/**
 *  This function is used to get ACL attributes . the ACL id is
 *  given and the function returns ACL attributes : type and a
 *  list of attached regions. the length of the regions list
 *  depends on the ACL type
 *
 * @param[in,out] params - ACL parameters
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 *  @return SX_STATUS_PARAM_ERROR if any input parameter is
 *  invalid
 *  @return SX_STATUS_ENTRY_NOT_FOUND if requested element is
 *  not found in DB
 *
 */
sx_status_t flex_acl_get_internal(sx_api_flex_acl_set_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_get_acl_attributes(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to get acl attributes\n");
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_get(sx_api_flex_acl_set_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }
    /* check that group id is not system */
    rc = flex_acl_check_priveleges(params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for acl id[%u].\n", params->acl_id);
        goto out;
    }

    rc = flex_acl_get_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for acl id[%u].\n", params->acl_id);
    }
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t __flex_acl_allocate_group(sx_acl_id_t * group_id, sx_acl_direction_t direction)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rb_rc = SX_STATUS_SUCCESS;
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    SX_LOG_ENTER();

    if (NULL == group_id) {
        SX_LOG_ERR("Null ptr\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* * * * IMPORTANT NOTE: * * *
     * The code assumes this is the ONLY place in which bind attributes a.k.a
     * ACL group elements are allocated. In case we've upgraded with ISSU from
     * SDK using PAGT (and not PAGT_V2) we might need to align entries to
     * the correct bank. This will be done only once before any actual
     * bind attributes are used.
     */
    if (g_pagt_v2_issu_alignment_check == TRUE) {
        __flex_acl_issu_acl_group_alignment_needed();
    }

    rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_ADD, 1, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_RESOURCE_COND(rc, "ACL: Failed to Allocate acl group in RM\n");
        rc = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    rc = flex_acl_db_allocate_acl_group(group_id, direction);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to allocate acl group in DB\n");
        goto rollback_rm;
    }

    /* Create binding attributes for this new group */
    rc = flex_acl_create_bind_attribs(*group_id, &bind_attribs_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: Failed to allocate bind attributes for new acl group 0x%x\n", *group_id);
        goto rollback_allocate;
    }

    goto out;

rollback_allocate:
    if (SX_CHECK_FAIL(rb_rc = flex_acl_db_destroy_acl_group(*group_id))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_rm:
    if (SX_CHECK_FAIL(rb_rc =
                          rm_entries_set(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_DELETE, 1, NULL))) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_update_acl_group(sx_acl_id_t group_id, sx_acl_id_t * acl_ids, uint32_t acl_ids_num)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    uint32_t                 i = 0, j = 0, k = 0;
    flex_acl_db_acl_group_t *acl_group = NULL;
    sx_acl_id_t              old_ids[SPECTRUM_ACL_GROUPS_SIZE_MAX] = {0};
    uint32_t                 old_ids_num = 0;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(acl_ids, "acl_ids"))) {
        goto out;
    }
    SX_LOG_ENTER();

    if (acl_ids_num > rm_resource_global.acl_groups_size_max) {
        SX_LOG(SX_LOG_ERROR, "Num of acl id's exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    /* parameter checking is being done under acl_db_get_acl_group */
    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "get acl group failed, group_id: %u\n", group_id);
        goto out;
    }

    /* store old acl ids for rollback*/
    old_ids_num = acl_group->acl_num;
    memcpy(old_ids, acl_group->acl_ids, sizeof(sx_acl_id_t) * old_ids_num);

    /* update db of old acls */
    for (i = 0; i < old_ids_num; i++) {
        rc = flex_acl_db_acl_remove_from_group(old_ids[i], group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Removing ACL ID %#x from ACL group ID %#x in DB failed, [%s]\n",
                   acl_ids[j], group_id, sx_status_str(rc));
            goto rollback;
        }
    }
    /* copy new acls to group db and update acls db with group id */
    for (j = 0; j < acl_ids_num; j++) {
        rc = flex_acl_db_acl_add_to_group(acl_ids[j], group_id);
        SX_LOG_DBG("Add ACL ID %#x to group %#x, j:%d, rc:%d, acl_ids_num %d\n",
                   acl_ids[j], group_id, j, rc, acl_ids_num);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Adding ACL ID %#x to ACL group ID %#x in DB failed. [%s]\n",
                   acl_ids[j], group_id, sx_status_str(rc));
            goto rollback;
        }
    }

    rc = flex_acl_db_update_acl_group(group_id, acl_ids, acl_ids_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to update group db, group_id: %u\n", group_id);
        goto rollback;
    }

    goto out;

rollback:
    for (k = 0; k < j; k++) {
        /* acl_group->acl_ids[k] = FLEX_ACL_INVALID_ACL_ID; */
        if (SX_STATUS_SUCCESS != flex_acl_db_acl_remove_from_group(acl_ids[k], group_id)) {
            SX_LOG(SX_LOG_ERROR, "Remove group id %d from acl table id %d failed\n", group_id, acl_ids[k]);
        }
    }
    for (k = 0; k < i; k++) {
        if (SX_STATUS_SUCCESS != flex_acl_db_acl_add_to_group(old_ids[k], group_id)) {
            SX_LOG(SX_LOG_ERROR, "Remove group id %d from acl table id %d failed\n", group_id, acl_ids[k]);
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_acl_add_acl_to_group(sx_acl_id_t group_id, uint32_t acl_ids_num, sx_acl_id_t *acl_ids)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t *acl_group = NULL;
    flex_acl_db_acl_table_t *acl_table = NULL;
    uint32_t                 i = 0;
    sx_acl_id_t              group_head_id = FLEX_ACL_INVALID_ACL_ID;
    boolean_t                same_group = FALSE;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL group id [0x%x]\n", group_id);
        goto out;
    }

    /* Validate we that the new group is not the same as the old one.
     * Inserting the same group again might corrupt our DB.
     * Returning success in this case.
     */
    if (acl_group->acl_num == acl_ids_num) {
        same_group = TRUE;
        for (i = 0; i < acl_ids_num; i++) {
            if (acl_group->acl_ids[i] != acl_ids[i]) {
                same_group = FALSE;
                break;
            }
        }
    }
    if (same_group == TRUE) {
        SX_LOG_INF("ACL : Group [0x%x] was updated to contain the same ACLs. \n", group_id);
        goto out;
    }

    /* validate all ACLs in same direction as the ACL Group */
    for (i = 0; i < acl_ids_num; i++) {
        rc = flex_acl_db_acl_get(acl_ids[i], &acl_table);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to find ACL table id [0x%x]\n", acl_ids[i]);
            goto out;
        }

        if (acl_table->direction != SX_ACL_DIRECTION_MULTI_POINTS_E) {
            if (acl_table->direction != acl_group->direction) {
                SX_LOG_ERR(
                    "ACL : ACL id [0x%x] direction [%u] is not the same as ACL group id [%#x] direction [%u]\n",
                    acl_ids[i], acl_table->direction, group_id, acl_group->direction);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        } else {
            if (acl_table->acl_attributes.multi_direction.acl_direction_bitmap == 0) {
                SX_LOG_ERR(
                    "ACL : Failed to set ACL id [0x%x] to ACL group id [%#x] because the ACL direction bitmap is not set\n",
                    acl_ids[i],
                    group_id);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            if ((acl_table->acl_attributes.multi_direction.acl_direction_bitmap & (1 << acl_group->direction)) == 0) {
                SX_LOG_ERR(
                    "ACL : ACL id [0x%x] direction bitmap [%x] is not good for ACL group id [%#x] direction [%u]\n",
                    acl_ids[i],
                    acl_table->acl_attributes.multi_direction.acl_direction_bitmap,
                    group_id,
                    acl_group->direction);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
    }
    /* validate that go to action not creates nested call*/
    rc = validate_goto_action_on_group_update(acl_group, acl_ids_num, acl_ids);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed at validation of goto action at group[%x] update\n", group_id);
        goto out;
    }

    rc = flex_acl_db_get_groups_head(acl_group->group_id, &group_head_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed get group head, group_id: %u\n", acl_group->group_id);
        goto out;
    }
    /* Edit ACL Group Flow */
    rc = __flex_acl_group_edit(group_id, acl_ids, acl_ids_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to edit ACL group id [%#x]\n", group_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_free_group_bind_attributes(sx_acl_id_t group_id)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t          *acl_group = NULL;
    flex_acl_db_group_bind_attribs_t *attribs = NULL;
    uint32_t                          acl_ids_num = 0, i = 0;
    acl_id_group_entry_t              acl_ids[SPECTRUM_ACL_GROUPS_SIZE_MAX] = {
        {0}
    };
    flex_acl_bind_attribs_id_t        bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL group id [%#x]\n", group_id);
        goto out;
    }
    if (acl_group->bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        SX_LOG_ERR("ACL: Failed to invalidate group on register\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }
    rc = flex_acl_db_attribs_get(acl_group->bind_attribs_id, &attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: get bind attributes error for group id %d\n", group_id);
        goto out;
    }
    /* Store the old acl ids for rollback */
    for (i = 0; i < attribs->acl_id_num; i++) {
        acl_ids[i] = attribs->acl_id_list[i];
    }
    acl_ids_num = attribs->acl_id_num;
    /* Remove the group from hardware */
    rc = flex_acl_write_bind_attributes(acl_group->bind_attribs_id,
                                        FALSE,
                                        acl_ids,
                                        acl_ids_num,
                                        (acl_ids_num) ? TRUE : FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to invalidate group on register, bind attributes: %u\n", acl_group->bind_attribs_id);
        goto out;
    }
    bind_attribs_id = acl_group->bind_attribs_id;
    rc = flex_acl_remove_bind_attribs(group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to remove bind attributes for group [%u]\n", group_id);
        goto rollback_invalidate_hw;
    }

    goto out;

rollback_invalidate_hw:
    rb_rc = flex_acl_write_bind_attributes(bind_attribs_id, TRUE, acl_ids, acl_ids_num, TRUE);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_free_group(sx_acl_id_t group_id)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t          *acl_group = NULL;
    int32_t                           ref_count = 0;
    uint32_t                          i = 0;
    flex_acl_db_group_bind_attribs_t *attribs = NULL;
    uint32_t                          acl_ids_num = 0;
    acl_id_group_entry_t              acl_ids[SPECTRUM_ACL_GROUPS_SIZE_MAX] = {
        {0}
    };
    flex_acl_bind_attribs_id_t        bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL group id [%#x]\n", group_id);
        goto out;
    }
    /* check if group bound to any device/rif/vlan/port */
    if (flex_acl_db_is_acl_group_bound(acl_group->group_id)) {
        SX_LOG_ERR("ACL : Can not destroy bound ACL group id [%#x]\n", group_id);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }
    rc = flex_acl_db_group_rules_ref_cnt_get(group_id, &ref_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get ref count of rules for group id [%#x]\n", group_id);
        goto out;
    }
    if (ref_count != 0) {
        SX_LOG_ERR("ACL : Can not destroy ACL group id [%#x], have rule references\n", group_id);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }
    if ((acl_group->next_acl_group_id != FLEX_ACL_INVALID_ACL_ID) ||
        (acl_group->prev_acl_group_id != FLEX_ACL_INVALID_ACL_ID)) {
        SX_LOG_ERR("ACL : Can not destroy group that bound to another group\n");
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* Try to remove the group's bind attributes if it's relevant */
    rc = flex_acl_db_attribs_get(acl_group->bind_attribs_id, &attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: get bind attributes error for group id %d\n", group_id);
        goto out;
    }
    /* Store the old acl ids for rollback */
    for (i = 0; i < attribs->acl_id_num; i++) {
        acl_ids[i] = attribs->acl_id_list[i];
    }
    acl_ids_num = attribs->acl_id_num;
    rc = __flex_acl_free_group_bind_attributes(group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to free acl group's [%u] bind attributes\n", group_id);
        goto out;
    }

    rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_DELETE, 1, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to free acl group 0x%x from RM\n", group_id);
        goto rollback_bind;
    }

    rc = flex_acl_db_destroy_acl_group(group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to free acl group 0x%x in DB\n", group_id);
        goto rollback_rm;
    }
    goto out;

rollback_rm:
    rb_rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACL_GROUPS_E, SX_ACCESS_CMD_ADD, 1, NULL);
    if (SX_CHECK_FAIL(rb_rc = rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }

rollback_bind:
    rb_rc = flex_acl_create_bind_attribs(group_id, &bind_attribs_id);
    if (SX_CHECK_FAIL(rb_rc = rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
    rb_rc = flex_acl_write_bind_attributes(bind_attribs_id, TRUE, acl_ids, acl_ids_num, TRUE);
    if (SX_CHECK_FAIL(rb_rc = rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* the function updates the head of groups with new bind attributes id and group with new acl*/
static sx_status_t __flex_acl_group_update_current_and_head(sx_acl_id_t                group_id,
                                                            flex_acl_bind_attribs_id_t attribs_id,
                                                            sx_acl_id_t              * acl_ids,
                                                            uint32_t                   count)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_acl_id_t              group_head_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_db_acl_group_t *head_group = NULL;

    SX_LOG_ENTER();

    /* update group with new acls */
    rc = __flex_acl_update_acl_group(group_id, acl_ids, count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to update acl group, id [0x%x]\n", group_id);
        goto out;
    }

    /* update head of linked groups with new bind attributes id */
    rc = flex_acl_db_get_groups_head(group_id, &group_head_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get group head for group id %d\n", group_id);
        goto out;
    }

    rc = flex_acl_db_get_acl_group(group_head_id, &head_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get group id [%#x]\n", group_id);
        goto out;
    }
    head_group->bind_attribs_id = attribs_id;

out:
    SX_LOG_EXIT();
    return rc;
}

/* This function assumes that the groups are correct in the DB and all that remains is to write to HW.
 * It should be used only when linking/unlinking several groups together. It is assumed that the groups are not bound.
 */
static sx_status_t __flex_acl_group_write(sx_acl_id_t group_id)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    acl_id_group_entry_t       acl_ids_prepared[SPECTRUM_ACL_GROUPS_SIZE_MAX] = {
        {0}
    };
    uint32_t                   prepared_ids_num = rm_resource_global.acl_groups_size_max;
    flex_acl_db_acl_group_t   *acl_group = NULL;
    sx_acl_id_t                group_head_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL group id [%#x]\n", group_id);
        goto out;
    }
    /* Get bind attributes id of current head bind attributes */
    rc = flex_acl_db_get_groups_head(group_id, &group_head_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed get group head, group_id: %u\n", group_id);
        goto out;
    }
    if (flex_acl_db_is_acl_group_bound(group_head_id)) {
        SX_LOG_ERR("ACL: group[%x] is bound\n", group_head_id);
        rc = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }

    rc = flex_acl_db_acl_group_get_bind_attribs_id(group_head_id, &bind_attribs_id);
    if ((rc != SX_STATUS_SUCCESS) || (bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID)) {
        SX_LOG_ERR("ACL : Failed to find bind attributes id for group [0x%x]\n", group_id);
        goto out;
    }

    /* Prepare a list of all the ACLs in the groups */
    rc = flex_acl_hw_prepare_acl_list_from_groups(group_id,
                                                  acl_ids_prepared,
                                                  &prepared_ids_num,
                                                  acl_group->direction);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to prepare acl list from group [0x%x] \n", group_id);
        goto out;
    }

    if (prepared_ids_num > 0) {
        /* Write the new group to the bind attributes if it's not empty */
        rc = flex_acl_write_bind_attributes(bind_attribs_id,
                                            TRUE,
                                            acl_ids_prepared,
                                            prepared_ids_num,
                                            TRUE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to write group [%u] to register\n", group_id);
            goto out;
        }
    } else {
        /* Invalidate the bind attributes if it's now empty */
        rc = flex_acl_write_bind_attributes(bind_attribs_id, FALSE, NULL, 0, TRUE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to invalidate group [%u]\n", group_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_group_edit(sx_acl_id_t group_id, sx_acl_id_t * acl_ids, uint32_t acl_ids_num)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rb_rc = SX_STATUS_SUCCESS;
    acl_id_group_entry_t       acl_ids_prepared[SPECTRUM_ACL_GROUPS_SIZE_MAX] = {
        {0}
    };
    uint32_t                   prepared_ids_num = rm_resource_global.acl_groups_size_max;
    acl_id_group_entry_t       acl_ids_prepared_old[SPECTRUM_ACL_GROUPS_SIZE_MAX] = {
        {0}
    };
    uint32_t                   prepared_ids_num_old = rm_resource_global.acl_groups_size_max;
    sx_acl_id_t                acl_ids_old[SPECTRUM_ACL_GROUPS_SIZE_MAX] = {0};
    uint32_t                   ids_num_old = 0;
    sx_acl_id_t                group_head_id = FLEX_ACL_INVALID_ACL_ID;
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    flex_acl_db_acl_group_t   *acl_group = NULL;
    boolean_t                  write_new_group_to_reg = TRUE;
    boolean_t                  write_old_group_to_reg = TRUE;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_acl_group(group_id, &acl_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to find ACL group id [%#x]\n", group_id);
        goto out;
    }
    /* copy old acl ids to temporary container */
    memcpy(acl_ids_old, acl_group->acl_ids, sizeof(sx_acl_id_t) * acl_group->acl_num);
    ids_num_old = acl_group->acl_num;

    /* Get bind attributes id of current and reserved bind attributes */
    rc = flex_acl_db_get_groups_head(group_id, &group_head_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed get group head, group_id: %u\n", group_id);
        goto out;
    }
    rc = flex_acl_db_acl_group_get_bind_attribs_id(group_head_id, &bind_attribs_id);
    if ((rc != SX_STATUS_SUCCESS) || (bind_attribs_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID)) {
        SX_LOG_ERR("ACL : Failed to find bind attributes id for group [0x%x]\n", group_id);
        goto out;
    }

    /* prepare old acl list from original group for rollback operation */
    /* now gets from db, with or without system acl */
    rc = flex_acl_hw_prepare_acl_list_from_groups(group_id,
                                                  acl_ids_prepared_old,
                                                  &prepared_ids_num_old,
                                                  acl_group->direction);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to prepare acl list from group [0x%x] \n", group_id);
        goto out;
    }

    /* Create acl list that contain linked acls and new acls */
    rc = flex_acl_hw_prepare_acl_list_from_groups_update(group_id,
                                                         acl_ids,
                                                         acl_ids_num,
                                                         acl_ids_prepared,
                                                         &prepared_ids_num,
                                                         acl_group->direction);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to prepare acl list from group [0x%x] \n",
                   group_id);
        goto out;
    }

    if (prepared_ids_num == 0) {
        write_new_group_to_reg = FALSE;
    }
    if (prepared_ids_num_old == 0) {
        write_old_group_to_reg = FALSE;
    }

    SX_LOG_DBG("write_new_group_to_reg[%d], write_old_group_to_reg[%d]\n",
               write_new_group_to_reg,
               write_old_group_to_reg);

    /* Write the new group to the bind attributes if it's not empty */
    rc = flex_acl_write_bind_attributes(bind_attribs_id,
                                        TRUE,
                                        acl_ids_prepared,
                                        prepared_ids_num,
                                        write_new_group_to_reg);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to write group to register, bind attributes: %u\n", bind_attribs_id);
        goto out;
    }

    SX_LOG_DBG("Update current ACL group ID %#x with new ACLs\n", group_id);

    /* Update current ACL group with new ACLs and update head of linked groups with new attributes id. */
    /* After this function the old ACLs are unbounded from group and don't have any reference to
     * group that was contain them */
    rc = __flex_acl_group_update_current_and_head(group_id, bind_attribs_id, acl_ids, acl_ids_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "ACL : Failed to update current group id [%#x] with new ACLs, and head with new bind attributes\n",
            acl_group->group_id);
        goto rollback_write_groups;
    }

    /* If the group is now zero or going to be zero we must update all binding points related to this group */
    if (write_new_group_to_reg != write_old_group_to_reg) {
        rc = flex_acl_bind_update_rules_and_bind_points(group_head_id,
                                                        bind_attribs_id,
                                                        acl_group->direction,
                                                        write_new_group_to_reg);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to rebind ports, vlans or RIFs for ACL group id [0x%x]\n",
                       acl_group->group_id);
            goto rollback_rebind_ports_vlans_rifs;
        }
    } else if (write_new_group_to_reg) {
        /* The group has changed, it is critical to update all aggregated groups that contain this group */
        rc = flex_acl_update_bind_points_on_group_edit(group_head_id, bind_attribs_id, acl_group->direction);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to update rif system acls for ACL group id [0x%x]\n",
                       acl_group->group_id);
            goto rollback_rebind_ports_vlans_rifs;
        }
    }
    /* Invalidate the bind attributes if it's now empty */
    rc = flex_acl_write_bind_attributes(bind_attribs_id,
                                        FALSE,
                                        acl_ids_prepared_old,
                                        prepared_ids_num_old,
                                        !write_new_group_to_reg);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to invalidate group\n");
        goto rollback_rebind_ports_vlans_rifs;
    }

    goto out;

rollback_rebind_ports_vlans_rifs:
    rb_rc = __flex_acl_group_update_current_and_head(group_id, bind_attribs_id, acl_ids_old, ids_num_old);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
    if (write_new_group_to_reg != write_old_group_to_reg) {
        rb_rc = flex_acl_bind_update_rules_and_bind_points(group_head_id,
                                                           bind_attribs_id,
                                                           acl_group->direction,
                                                           write_old_group_to_reg);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
    } else if (write_new_group_to_reg) {
        rb_rc = flex_acl_update_bind_points_on_group_edit(group_head_id,
                                                          bind_attribs_id,
                                                          acl_group->direction);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
    }
rollback_write_groups:
    rb_rc = flex_acl_write_bind_attributes(bind_attribs_id,
                                           TRUE,
                                           acl_ids_prepared_old,
                                           ids_num_old,
                                           write_old_group_to_reg);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
    rb_rc = flex_acl_write_bind_attributes(bind_attribs_id,
                                           FALSE,
                                           acl_ids_prepared_old,
                                           prepared_ids_num_old,
                                           !write_old_group_to_reg);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/**
 *  This function is used for controlling a group of ACL or in
 *  other words cascaded ACL blocks up to the size of
 *  SX_ACL_MAX_ACL_GROUP_SIZE. When using CREATE command a new
 *  group is allocated, and a free group ID is returned. Use SET
 *  command to define an ordered cascaded ACL group.
 *  DESTROY command will free the list resource and is allowed
 *  only when the ACL list is not configured in HW.
 *
 * @param[in] params - struct containing parameters
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameter is
 *  invalid
 *  @return SX_STATUS_PARAM_EXCEEDS_RANGE if input parameter
 *          exceeds allowed values
 *  @return SX_STATUS_ENTRY_NOT_FOUND if requested element is
 *  not found in DB
 *  @return SX_STATUS_NO_RESOURCES if no group is available to
 *  create
 *  @return SX_STATUS_CMD_UNSUPPORTED if unsupported command is
 *  requested
 */

sx_status_t flex_acl_group_set_internal(sx_api_acl_group_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        /* Allocate new ACL, check that are available resources*/
        rc = __flex_acl_allocate_group(&(params->group_id),
                                       params->acl_direction);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to allocate acl group 0x%x in DB\n", params->group_id);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_SET:
        rc = __flex_acl_add_acl_to_group(params->group_id, params->acl_ids_num,
                                         params->acl_ids);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to add acls to group 0x%x in DB\n", params->group_id);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        /* This will clear resources, allowed only on non-dirty ACL*/
        rc = __flex_acl_free_group(params->group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Failed to destroy acl group 0x%x in DB\n", params->group_id);
            goto out;
        }
        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("CMD unsupported\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }
out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_group_set(sx_api_acl_group_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    i = 0;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        break;

    case SX_ACCESS_CMD_SET:
        for (i = 0; i < params->acl_ids_num; i++) {
            rc = flex_acl_check_priveleges(params->acl_ids[i]);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to check ACL privileges, acl_id[%u].\n", params->acl_ids[i]);
                goto out;
            }
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        /* check first group */
        rc = flex_acl_check_priveleges(params->group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to check group privileges, group_id[%u].\n", params->group_id);
            goto out;
        }
        break;

    default:
        /* do nothing*/
        break;
    }

    rc = flex_acl_group_set_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set group, group_id[%u].\n", params->group_id);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/**
 *
 *
 *  This function is used to get ACL group attributes . the ACL
 *  group id is given and the function returns ACL group
 *  attributes : direction and a list of attached ACLs.
 *
 * @param[in] handle - SX-API handle
 * @param[in] group_id - ACL group ID
 * @param[out] acl_direction - ACL direction (ingress or egress
 *       ACL)
 * @param[out] acl_ids_p - list of the group ACL IDs.
 * @param[in,out] acl_ids_num - In - size of the ACL IDs array,
 *       OUT - number of valid ACL IDs.
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_NULL or SX_STATUS_PARAM_EXCEEDS_RANGE
 *  if any input parameter is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND if requested element is
 *  not found in DB
 *
 */
sx_status_t flex_acl_group_get_internal(sx_api_acl_group_params_t * params)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t *acl_group = NULL;
    uint32_t                 i = 0;

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_GET:
        rc = flex_acl_db_get_acl_group(params->group_id, &acl_group);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to find ACL group id [0x%x]\n", params->group_id);
            return rc;
        }
        params->acl_direction = acl_group->direction;

        if (params->acl_ids_num == 0) {
            params->acl_ids_num = acl_group->acl_num;
            return rc;
        }

        if (params->acl_ids_num > acl_group->acl_num) {
            params->acl_ids_num = acl_group->acl_num;
        }

        for (i = 0; i < params->acl_ids_num; i++) {
            params->acl_ids[i] = acl_group->acl_ids[i];
        }

        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("CMD unsupported\n");
        return SX_STATUS_CMD_UNSUPPORTED;
    }
    return rc;
}


sx_status_t flex_acl_group_get(sx_api_acl_group_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }
    /* check that group id is not system */
    rc = flex_acl_check_priveleges(params->group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->group_id);
        goto out;
    }

    rc = flex_acl_group_get_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->group_id);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_write_bind_attributes(flex_acl_bind_attribs_id_t bind_attribs_id,
                                           boolean_t                  set_acls,
                                           acl_id_group_entry_t      *acl_ids_prepared,
                                           uint32_t                   prepared_ids_num,
                                           boolean_t                  write_to_reg)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_group_bind_attribs_t *bind_attribs = NULL;
    uint32_t                          old_acl_num = 0;
    acl_id_group_entry_t              acl_ids_with_shadow[FLEX_ACL_MAX_ACL_GROUP_SIZE];
    acl_id_group_entry_t              old_acl_ids[FLEX_ACL_MAX_ACL_GROUP_SIZE];
    uint32_t                          acls_with_shadow_count = 0;
    uint32_t                          free_attributes_count = 0;
    uint32_t                          i = 0;

    SX_LOG_ENTER();

    if (!write_to_reg) {
        goto out;
    }
    if ((prepared_ids_num > 0) && (SX_CHECK_FAIL(rc = utils_check_pointer(acl_ids_prepared, "acl_ids_prepared")))) {
        goto out;
    }

    SX_MEM_CLR(acl_ids_with_shadow);
    /* Get the current bind attributes to determine its old size */
    rc = flex_acl_db_attribs_get(bind_attribs_id, &bind_attribs);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("ACL : Failed to get bind attributes with id %d\n", bind_attribs_id);
        goto out;
    }
    /* Store the old ACLs & group elements so we can remove them later */
    old_acl_num = bind_attribs->acl_id_num;
    for (i = 0; i < old_acl_num; i++) {
        old_acl_ids[i] = bind_attribs->acl_id_list[i];
    }

    if (set_acls) {
        if (prepared_ids_num == 0) {
            SX_LOG_ERR("ACL : Unexpected group size 0\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        /* Check if we need to insert a shadow acl to the lists of acls */
        if (flex_acl_db_get_shadow_acl_count() > 0) {
            /* Update the list with shadow acls if they exists */
            acls_with_shadow_count = rm_resource_global.acl_groups_size_max;
            rc = flex_acl_hw_update_acl_list_with_shadows(acl_ids_prepared, prepared_ids_num,
                                                          acl_ids_with_shadow, &acls_with_shadow_count);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to add shadow ACL for bind attributes ID [%u]\n", bind_attribs_id);
                goto out;
            }
            acl_ids_prepared = acl_ids_with_shadow;
            prepared_ids_num = acls_with_shadow_count;
        }

        /* Check if we have enough entries available in the HW to add this group
         * NOTE: It is assumed the the group head entry was already allocate by previous calls
         * so we need to allocate more PAGT entries only for groups larger than 1. */
        if (prepared_ids_num > 1) {
            free_attributes_count = flex_acl_db_attribs_free_count();
            if (free_attributes_count < prepared_ids_num - 1) {
                SX_LOG_ERR("ACL: No enough HW resources for write HW ACL group [%u]\n", bind_attribs_id);
                rc = SX_STATUS_NO_RESOURCES;
                goto out;
            }
            /* Allocate the HW group elements that will be used to hold the acl entries of the group */
            for (i = 1; i < prepared_ids_num; i++) {
                rc = flex_acl_db_attribs_allocate(&(acl_ids_prepared[i].acl_group_element),
                                                  bind_attribs->direction,
                                                  bind_attribs->bound_logic_group_id,
                                                  FALSE);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("ACL: Failed allocating group elements from DB\n");
                    goto out;
                }
            }
        }
        /* The first HW element of the group is always the bind attribute id */
        acl_ids_prepared[0].acl_group_element = bind_attribs_id;

        /*If we have entries in the group we need to make sure we have room for adding them */
        rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E, SX_ACCESS_CMD_ADD, prepared_ids_num, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR_RESOURCE_COND(rc, "ACL: No resources available to add acls to groups: rc=%d", rc);
            goto out;
        }
        /* Perform the actual write to hw */
        rc = flex_acl_hw_reg_write_group(bind_attribs_id, acl_ids_prepared, prepared_ids_num);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to write bind attributes [%u] to register\n", bind_attribs_id);
            goto rb_rm_entries_set;
        }
    } else {
        /* If this groups it going to be zero now */
        rc = flex_acl_hw_reg_invalidate_group(bind_attribs_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to invalidate bind attributes [%u] to register\n", bind_attribs_id);
            goto out;
        }
    }

    if (old_acl_num > 0) {
        /* Remove the size of the old group so the bookkeeping is correct */
        rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E, SX_ACCESS_CMD_DELETE, old_acl_num, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            /* This is a very problematic situation and therefore we cannot do a rollback for it */
            SX_LOG_ERR("ACL : Failed deleting resources for acls in groups. No rollback.\n");
            goto out;
        }
        /* We need to return the freed PAGT entries to the pool (without the list head) */
        for (i = 1; i < old_acl_num; i++) {
            rc = flex_acl_db_attribs_free(old_acl_ids[i].acl_group_element);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("ACL: Failed returning group elements to DB\n");
                goto out;
            }
        }
    }
    goto out;

rb_rm_entries_set:
    rb_rc = rm_entries_set(RM_SDK_TABLE_TYPE_ACLS_IN_GROUPS_E, SX_ACCESS_CMD_DELETE, prepared_ids_num, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: acls in groups rm rollback failure, err [%s]\n", sx_status_str(rb_rc));
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* This function is used to link together several groups. This can happen only when the groups are not bound */
sx_status_t __flex_acl_group_bind_group(sx_api_flex_acl_group_bind_params_t * params)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_status_t                       rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t          *parent_group = NULL;
    flex_acl_db_acl_group_t          *child_group = NULL;
    flex_acl_db_acl_group_t          *check_group = NULL;
    flex_acl_bind_attribs_id_t        bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;
    uint32_t                          acl_ids_num = 0, i = 0;
    acl_id_group_entry_t              acl_ids[SPECTRUM_ACL_GROUPS_SIZE_MAX] = {
        {0}
    };
    flex_acl_db_group_bind_attribs_t *attribs = NULL;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }
    SX_LOG_ENTER();

    if (params->group_id == params->next_group_id) {
        SX_LOG(SX_LOG_ERROR, "ID's of groups are identical\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_db_get_acl_group(params->group_id, &parent_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to get acl group[%d]\n", params->group_id);
        goto out;
    }

    rc = flex_acl_db_get_acl_group(params->next_group_id, &child_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to get acl group[%d]\n", params->group_id);
        goto out;
    }

    if (parent_group->direction != child_group->direction) {
        SX_LOG(SX_LOG_ERROR, "Acl types of groups are different\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (parent_group->next_acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG(SX_LOG_ERROR, "Failed to set child group, already set\n");
        rc = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }

    if (child_group->prev_acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG(SX_LOG_ERROR, "Failed to set parent group, already set\n");
        rc = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }
    /* check circles in binding */
    check_group = child_group;
    while (check_group->next_acl_group_id != FLEX_ACL_INVALID_ACL_ID) {
        if (check_group->next_acl_group_id == params->group_id) {
            SX_LOG(SX_LOG_ERROR, "Bind of two groups creates circle binding\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        rc = flex_acl_db_get_acl_group(check_group->next_acl_group_id, &check_group);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to get linked group, group_id: %u\n", check_group->next_acl_group_id);
            goto out;
        }
    }
    rc = __flex_acl_validate_groups_bind(params->group_id, params->next_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed at group bind validation, parent_group_id: %u, child_group_id: %u\n",
                   params->group_id,
                   params->next_group_id);
        goto out;
    }
    /* Update the change to the DB */
    rc = flex_acl_db_acl_group_bind_acl_group(params->group_id, params->next_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to bind between groups %d and %d\n", params->group_id,
                   params->next_group_id);
        goto out;
    }

    rc = flex_acl_db_attribs_get(child_group->bind_attribs_id, &attribs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: get bind attributes error for group id %d\n", params->next_group_id);
        goto out;
    }
    /* Store the old acl ids for rollback */
    for (i = 0; i < attribs->acl_id_num; i++) {
        acl_ids[i] = attribs->acl_id_list[i];
    }
    acl_ids_num = attribs->acl_id_num;
    /* Remove the bind attributes of the child group so to save some space */
    rc = __flex_acl_free_group_bind_attributes(params->next_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to free bind attributes for group [%u]\n", params->next_group_id);
        goto rollback_group_bind;
    }
    /* Write the group to HW */
    rc = __flex_acl_group_write(params->group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to write group [%u] to hw\n", params->group_id);
        goto rollback_free_attributes;
    }
    goto out;

rollback_free_attributes:
    rb_rc = flex_acl_create_bind_attribs(params->next_group_id, &bind_attribs_id);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
    rb_rc = flex_acl_write_bind_attributes(bind_attribs_id, TRUE, acl_ids, acl_ids_num, TRUE);
    if (SX_CHECK_FAIL(rb_rc)) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
    }
rollback_group_bind:
    rb_rc = flex_acl_db_acl_group_unbind_acl_group(params->group_id, params->next_group_id);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to rollback unbind  groups [%u] and [%u]\n", params->group_id, params->next_group_id);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_group_unbind_group(sx_api_flex_acl_group_bind_params_t * params)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_group_t   *parent_group = NULL;
    flex_acl_db_acl_group_t   *child_group = NULL;
    flex_acl_bind_attribs_id_t bind_attribs_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }
    SX_LOG_ENTER();

    rc = flex_acl_db_get_acl_group(params->group_id, &parent_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to get acl group[%d]\n", params->group_id);
        goto out;
    }
    rc = flex_acl_db_get_acl_group(params->next_group_id, &child_group);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "failed to get acl group[%d]\n", params->group_id);
        goto out;
    }
    if (parent_group->next_acl_group_id != params->next_group_id) {
        SX_LOG(SX_LOG_ERROR, "Failed to unbind parent group, wrong child group id\n");
        rc = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }
    if (child_group->prev_acl_group_id != params->group_id) {
        SX_LOG(SX_LOG_ERROR, "Failed to unbind child group, wrong parent group id\n");
        rc = SX_STATUS_ENTRY_NOT_BOUND;
        goto out;
    }

    rc = __flex_acl_validate_groups_bind(params->group_id, params->next_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to check if group bound to dev, parent_group_id: %u, child_group_id: %u\n",
                   params->group_id, params->next_group_id);
        goto out;
    }

    rc = flex_acl_db_acl_group_unbind_acl_group(params->group_id, params->next_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to unbind  groups %d and %d\n", params->group_id, params->next_group_id);
        goto out;
    }
    /* Create bind attributes to the unbound child group */
    rc = flex_acl_create_bind_attribs(params->next_group_id, &bind_attribs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        goto rollback_unbind_group;
    }
    /* Write the parent group to HW */
    rc = __flex_acl_group_write(params->group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to write group [%u] to hw\n", params->group_id);
        goto rollback_create_bind_attributes;
    }
    /* Write the child group to HW */
    rc = __flex_acl_group_write(params->next_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to write group [%u] to hw\n", params->next_group_id);
        goto rollback_create_bind_attributes;
    }
    goto out;

rollback_create_bind_attributes:
    rb_rc = flex_acl_remove_bind_attribs(params->next_group_id);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to rollback bind attributes for groups [%u] and [%u]\n",
                   params->group_id,
                   params->next_group_id);
    }

rollback_unbind_group:
    rb_rc = flex_acl_db_acl_group_bind_acl_group(params->group_id, params->next_group_id);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to rollback bind groups [%u] and [%u]\n", params->group_id, params->next_group_id);
    }
    rb_rc = __flex_acl_group_write(params->group_id);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to write rollback group [%u] to hw\n", params->group_id);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_validate_groups_bind(sx_acl_id_t parent_group_id, sx_acl_id_t child_group_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_acl_id_t group_head_id = FLEX_ACL_INVALID_ACL_ID;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_groups_head(parent_group_id, &group_head_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed get group head\n");
        goto out;
    }
    /* check bind attributes id of parent group if exist */
    if (flex_acl_db_is_acl_group_bound(group_head_id)) {
        SX_LOG_ERR("ACL: Groups head[%x] of parent group[%x] are bound\n", group_head_id, parent_group_id);
        rc = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }
    if (flex_acl_db_is_acl_group_bound(child_group_id)) {
        SX_LOG_ERR("ACL: Child group[%x] are bound\n", child_group_id);
        rc = SX_STATUS_ENTRY_ALREADY_BOUND;
        goto out;
    }
    /* Check if the groups have goto actions and are they valid */
    rc = validate_goto_action_on_groups_bind(group_head_id, child_group_id);
    if (SX_STATUS_PARAM_ERROR == rc) {
        SX_LOG_ERR("ACL: Invalid GOTO operation when binding parent acl group[%x] to child group [%x].\n",
                   parent_group_id, child_group_id);
        goto out;
    } else if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed validation GOTO operation when binding parent acl group[%x] to child group [%x].\n",
                   parent_group_id, child_group_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_group_bind_set_internal(sx_api_flex_acl_group_bind_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_BIND:
        rc = __flex_acl_group_bind_group(params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: Group bind operation failed\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_UNBIND:
        rc = __flex_acl_group_unbind_group(params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Group unbind operation failed\n");
            goto out;
        }
        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("CMD %d unsupported\n", params->cmd);
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_group_bind_set(sx_api_flex_acl_group_bind_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    /* check that group id is not system */
    rc = flex_acl_check_priveleges(params->group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->group_id);
        goto out;
    }
    /* check second group */
    rc = flex_acl_check_priveleges(params->next_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->next_group_id);
        goto out;
    }

    rc = flex_acl_group_bind_set_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at group bind group, head group id[%u].\n", params->group_id);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_group_bind_get_internal(sx_api_flex_acl_group_bind_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    rc = flex_acl_db_acl_group_bind_group_get(params->group_id, &(params->next_group_id));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to get  bounded group to group id %d\n", params->group_id);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* the function checks privileges for ACL or ACL group */
sx_status_t flex_acl_check_priveleges(sx_acl_id_t acl_id)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;

    SX_LOG_EXIT();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (flex_acl_db_is_acl_group(acl_id)) {
        rc = flex_acl_db_group_entry_type_get(acl_id, &entry_type);
    } else {
        rc = flex_acl_db_acl_entry_type_get(acl_id, &entry_type);
    }
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get ACL (or ACL group entry type), ACL id[%u].\n", acl_id);
        goto out;
    }
    if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL: ACL group access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
        rc = SX_STATUS_ERROR;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_group_bind_get(sx_api_flex_acl_group_bind_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }
    /* check group */
    rc = flex_acl_check_priveleges(params->group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to check group privileges, group_id[%u].\n", params->group_id);
        goto out;
    }

    rc = flex_acl_group_bind_get_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get group bind, group_id[%u].\n", params->group_id);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* Check access violation */
sx_status_t flex_acl_rule_activity_get(sx_api_acl_rule_activity_get_params_t * params)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    /* checks if Region ID is legal */
    if (FLEX_ACL_REGION_BIT_CHECK(params->region_id)) {
        SX_LOG_ERR("ACL: Region ID is not valid, region_id[%#x].\n", params->region_id);
        return SX_STATUS_PARAM_ERROR;
    }

    /* check that region id is not system */
    rc = flex_acl_db_region_entry_type_get(params->region_id, &entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get region entry type, region_id[%#x].\n", params->region_id);
        return rc;
    }
    if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL: Region access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
        return SX_STATUS_ERROR;
    }

    return flex_acl_rule_activity_get_internal(params);
}

sx_status_t flex_acl_rule_activity_get_internal(sx_api_acl_rule_activity_get_params_t * params)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *acl_region = NULL;
    uint32_t                  offset = 0, region_size = 0;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_region_get(params->region_id, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get Region ID 0x%x [%u]\n", params->region_id, params->region_id);
        goto out;
    }

    offset = params->rule_offset;
    region_size = (acl_region->size - acl_region->reserved_rules_num);

    if (offset != SX_ACL_DEFAULT_ACTION_OFFSET) {
        /* Size validation */
        if (offset >= region_size) {
            SX_LOG_ERR("ACL : requested offset [%u] exceeds ACL region size [%u]\n", offset, region_size);
            rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }

        if (acl_region->rules[offset].valid != TRUE) {
            SX_LOG_ERR("ACL : requested offset [%u] is not valid\n", offset);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    } else if (!ACL_STAGE_IS_FLEX2_OR_ABOVE(g_acl_stage)) {
        offset = acl_region->size - 1;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:
        rc = flex_acl_hw_read_activity(acl_region, offset, params->cmd == SX_ACCESS_CMD_READ_CLEAR, &params->activity);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get Activity Region ID 0x%x [%u] offset [%u]\n",
                       params->region_id, params->region_id, offset);
            goto out;
        }
        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("acl_rule_activity_get CMD: [%s], unsupported.\n", sx_access_cmd_str(params->cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rule_activity_dump(sx_api_acl_rule_activity_dump_params_t *params)
{
    sx_status_t               status = SX_STATUS_SUCCESS;
    sx_utils_status_t         utils_status = SX_UTILS_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *acl_region = NULL;
    sx_acl_rule_offset_t      offset = params->rule_offset;
    bit_vector_t              activities;
    boolean_t                 activities_allocated = FALSE;
    uint32_t                  num_entries = params->num_entries;
    uint32_t                  region_size = 0, vector_bit_num = 0, next_offset = 0;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    status = flex_acl_db_region_get(params->region_id, &acl_region);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("ACL : Failed to get Region ID 0x%x [%u]\n", params->region_id, params->region_id);
        goto out;
    }

    if (FLEX_ACL_INVALID_ACL_ID == acl_region->bound_acl) {
        SX_LOG_DBG("ACL : ACL region [%u] not bound to an ACL table %d\n", params->region_id, acl_region->bound_acl);
        goto out;
    }

    region_size = (acl_region->size - acl_region->reserved_rules_num);

    /* Size validation */
    if ((offset + num_entries) > region_size) {
        SX_LOG_ERR("ACL : requested num entries [%u] exceeds ACL region size [%u]\n", offset, region_size);
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* allocate temporary bit vector to filter invalid offsets */
    utils_status = bit_vector_allocate(SDK_MC_ACTIVITY_DUMP_SIZE, &activities);
    if (utils_status != SX_UTILS_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate activities bit vector: %s\n", SX_UTILS_STATUS_MSG(utils_status));
        status = sx_utils_status_to_sx_status(utils_status);
        goto out;
    }
    activities_allocated = TRUE;

    switch (params->cmd) {
    case SX_ACCESS_CMD_READ:
    case SX_ACCESS_CMD_READ_CLEAR:
        status = flex_acl_hw_dump_activity(acl_region, params->cmd, offset, params->num_entries, &activities);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("ACL : Failed to dump active mc entries, Region ID 0x%x [%u] offset [%u]\n",
                       params->region_id, params->region_id, offset);
            goto out;
        }

        /* find first set bit in bit vector */
        utils_status = bit_vector_find_first_set(activities, &vector_bit_num);

        while (SX_UTILS_STATUS_SUCCESS == utils_status) {
            next_offset = vector_bit_num + offset;
            if (acl_region->rules[next_offset].valid == TRUE) {
                bit_vector_set(params->activities, vector_bit_num);
            }
            utils_status = bit_vector_find_next_set(activities, &vector_bit_num);
            /* if bit number in vector bigger than num entries we want to read - success */
            if (vector_bit_num > params->num_entries) {
                break;
            }
        }
        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("ACL: activity dump is not supported with CMD: [%s].\n", sx_access_cmd_str(params->cmd));
        status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    if (activities_allocated) {
        bit_vector_free(activities);
    }

    SX_LOG_EXIT();
    return status;
}

sx_status_t flex_acl_rules_move(sx_api_acl_block_move_params_t * params)
{
    flex_acl_entry_type_e entry_type;
    sx_status_t           rc;

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    /* check that region id is valid */
    if (FLEX_ACL_REGION_BIT_CHECK(params->region_id)) {
        SX_LOG_ERR("ACL: Region ID is not valid, region_id[%#x].\n", params->region_id);
        return SX_STATUS_PARAM_ERROR;
    }

    /* check that region id is not system */
    rc = flex_acl_db_region_entry_type_get(params->region_id, &entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get region entry type, region_id[%#x].\n", params->region_id);
        goto out;
    }
    if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL: Region access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_rules_move_internal(params, TRUE);
out:
    return rc;
}

static sx_status_t __flex_acl_actions_update_rules_references_on_rule_move(sx_acl_region_id_t   region_id,
                                                                           sx_acl_rule_offset_t block_start,
                                                                           sx_acl_rule_offset_t new_block_start,
                                                                           sx_acl_size_t        size)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = __flex_acl_actions_update_rules_list_delete(region_id,
                                                     block_start,
                                                     new_block_start,
                                                     size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to delete rules from pbs list . Unrecoverable error, region_id: %u\n", region_id);
        goto out;
    }
    /* Add new offsets from actions list */
    rc = __flex_acl_actions_update_rules_list_add(region_id,
                                                  block_start,
                                                  new_block_start,
                                                  size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to add rules to pbs list. Unrecoverable error, region_id: %u\n", region_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

/* The function moves rules according to params.
 * 1. validation of movement
 * 2. prepare rules to invalidate(gets ptr and num)
 * 3. move rules on devices, if one dev are used no need in rollback
 * 4. update db about moving(delete overwritten rules and overwrite them with new
 * 5. in case of fail at dev update - rollback move on previous devices and write to devices overwritten
 *   rules(no changes in db, so all info there)
 * 6. in case of db update failure - rollback flow
 */
sx_status_t flex_acl_rules_move_internal(sx_api_acl_block_move_params_t * params, boolean_t change_priority)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_status_t                    rb_rc = SX_STATUS_SUCCESS;
    sx_api_acl_block_move_params_t rb_params;
    flex_acl_db_acl_region_t      *acl_region = NULL;
    sx_dev_id_t                    devs_list[SX_DEV_NUM_MAX] = { 0 };
    uint16_t                       dev_info_arr_size = 0;
    uint32_t                       dev_idx = 0, i = 0;
    flex_acl_db_flex_rule_t       *rules_to_free = NULL;
    uint32_t                       rules_count = 0;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    rb_params = *params;

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at get devices list\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_db_region_get(params->region_id, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get region id [%u]\n", params->region_id);
        goto out;
    }

    if ((acl_region->rules_priority_mode == FLEX_RULES_PRIORITY_MODE_PRIORITY) && change_priority) {
        SX_LOG_ERR("Rules move is not supported for a priority mode region. Region id [%u]\n", params->region_id);
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    /* the function validate that rules can be moved and also calculate the start offset of rules to be cleared */
    rc =
        flex_acl_db_validate_and_prepare_rules_move(params, acl_region->reserved_rules_num, &rules_to_free,
                                                    &rules_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to validate and prepare rules move [%u]\n", params->region_id);
        goto out;
    }

    if (params->block_start == params->new_block_start) {
        SX_LOG_DBG("source and dest are the same (%d)- returning\n", params->block_start);
        goto out;
    }
    /* update all devices */
    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    rc = flex_acl_hw_rule_move(params, devs_list[dev_idx], acl_region, change_priority);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to move rules on device %d\n", devs_list[dev_idx]);
        goto error;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

    for (i = 0; i < rules_count; i++) {
        if (rules_to_free[i].valid == FLEX_ACL_RULE_INVALID) {
            continue;
        }
        rc = __flex_acl_rules_keys_ref_update(&rules_to_free[i], FALSE, params->region_id);
        /* coverity[example_checked] */
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL:  failed to delete ref count for keys. region:%d offset :%d\n",
                       rules_to_free[i].region_id,
                       rules_to_free[i].offset);
            goto error;
        }
        rc = __flex_acl_dec_actions_ref(&rules_to_free[i], params->region_id);
        /* coverity[example_checked] */
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: __flex_acl_dec_ref Failed to free, region_id: %u.\n", params->region_id);
            goto error;
        }
    }
    /* Delete old offsets from actions list */
    rc = __flex_acl_actions_update_rules_references_on_rule_move(params->region_id,
                                                                 params->block_start,
                                                                 params->new_block_start,
                                                                 params->block_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to add rules to pbs list. Unrecoverable error, region_id: %u\n", params->region_id);
        goto error;
    }

    /* Delete old offsets from keys list */
    rc = __flex_acl_keys_update_rules_references_on_rule_move(params->region_id,
                                                              params->block_start,
                                                              params->new_block_start,
                                                              params->block_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to add rules to pbs list. Unrecoverable error, region_id: %u\n", params->region_id);
        goto error;
    }
    /*  Update rule in db and update all inner references.  */
    rc = flex_acl_hw_rules_move_update_db(params, rules_to_free, rules_count, change_priority);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to update db. Unrecoverable error\n");
        goto error;
    }

    goto out;

error:
    /* the rollback cares just about fail on device updating */
    rb_params.block_start = params->new_block_start;
    rb_params.new_block_start = params->block_start;
    /* rollback all previous devices that was set */
    for (i = 0; i < dev_idx; i++) {
        if (SX_CHECK_FAIL(rb_rc = flex_acl_hw_rule_move(&rb_params, devs_list[i], acl_region, change_priority))) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
        /* write rules to register, no changes was performed to db */
        if (SX_CHECK_FAIL(rb_rc =
                              flex_acl_hw_write_rollback_move_rules(rules_to_free, rules_count, acl_region,
                                                                    devs_list[i]))) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
    }


out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_rx_list_port_validation(sx_api_rx_list_set_params_t *params)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    uint32_t       port_idx = 0;
    sx_port_type_t port_type = SX_PORT_TYPE_NETWORK;
    uint32_t       phy_port = 0;
    uint8_t        port_bit_map[FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS];
    sx_port_info_t port_info;
    sx_port_type_t list_port_type = FLEX_ACL_INVALID_PORT_TYPE;

    SX_LOG_ENTER();

    if (params->port_list_count > RM_API_ACL_PORT_LIST_MAX) {
        SX_LOG_ERR("Failed on port validation: Number of rx_list ports %d exceeds the maximum:%d \n",
                   params->port_list_count,
                   RM_API_ACL_PORT_LIST_MAX);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    memset(port_bit_map, 0, FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS);

    for (port_idx = 0; port_idx < params->port_list_count; port_idx++) {
        rc = port_db_info_get(params->port_list[port_idx].log_port, &port_info);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed on port validation: Logical port[0x%08X] not found [%s]\n",
                       params->port_list[port_idx].log_port,
                       sx_status_str(rc));
            goto out;
        }
        /* LAG not supported */
        port_type = SX_PORT_TYPE_ID_GET(params->port_list[port_idx].log_port);
        if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_TUNNEL)) {
            SX_LOG_ERR("Failed on port validation: Logical port[0x%08X] type:[%s] not supported\n",
                       params->port_list[port_idx].log_port, sx_port_type_str(port_type));
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (params->port_list[port_idx].port_match >= SX_ACL_PORT_LIST_MATCH_LAST) {
            SX_LOG_ERR("Failed on port validation: Logical port[0x%08X] define with unsupported match\n",
                       params->port_list[port_idx].log_port);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (port_idx > 0) {
            if (list_port_type != port_type) {
                SX_LOG_ERR("Failed on rx list port validation: Cannot mix port types in the same list\n");
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        } else {
            list_port_type = port_type;
        }

        /* Checks if current port is already in port list */
        phy_port = SX_PORT_PHY_ID_GET(params->port_list[port_idx].log_port);
        if (SXD_BITMAP_GET(port_bit_map, FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS, FLEX_ACL_BITS_IN_BYTE,
                           phy_port)) {
            SX_LOG_ERR("Failed on port validation: Logical port[0x%08X] already exist in port list\n",
                       params->port_list[port_idx].log_port);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        SXD_BITMAP_SET(port_bit_map, FLEX_ACL_NUM_OF_BYTES_TO_CONV_RX_LIST_PORTS, FLEX_ACL_BITS_IN_BYTE, phy_port);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_rx_list_create(sx_api_rx_list_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = __flex_acl_rx_list_port_validation(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create new rx list on port validation, rc=[%s]\n", sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_db_rx_list_create(params->port_list, params->port_list_count, &params->port_list_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create new rx list in DB, rc=[%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_rx_list_set(sx_api_rx_list_set_params_t *params)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_status_t                 rb_rc = SX_STATUS_SUCCESS;
    cl_qlist_t                 *rules_ref_set_list = NULL;
    cl_list_item_t             *iter = NULL;
    cl_list_item_t             *iter_rollback = NULL;
    sx_acl_port_list_entry_t    port_list_current[RM_API_ACL_PORT_LIST_MAX];
    uint32_t                    port_list_count_current = RM_API_ACL_PORT_LIST_MAX;
    flex_acl_db_rule_id_item_t *db_rule_id_entry_p = NULL;
    sx_port_type_t              port_type = FLEX_ACL_INVALID_PORT_TYPE;

    SX_LOG_ENTER();
    /* Validate rx_list port list */
    rc = __flex_acl_rx_list_port_validation(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set rx list id [%u] on port validation\n", params->port_list_id);
        goto out;
    }

    /* Save current rx list from DB for rollback */
    memset(port_list_current, 0, sizeof(sx_acl_port_list_entry_t) * RM_API_ACL_PORT_LIST_MAX);
    rc = flex_acl_db_rx_list_get(params->port_list_id, port_list_current, &port_list_count_current, &port_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set rx list id [%u] in DB\n", params->port_list_id);
        goto out;
    }

    /* Check that the ports are compatible with the current container port type */
    if (params->port_list_count > 0) {
        if (port_type != FLEX_ACL_INVALID_PORT_TYPE) {
            if (port_type != SX_PORT_TYPE_ID_GET(params->port_list[0].log_port)) {
                rc = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Failed to set rx list id [%u]. Port types are incompatible with list type.\n",
                           params->port_list_id);
                goto out;
            }
        } else {
            /* Set the port type of the first port as the type of the whole container */
            rc =
                flex_acl_db_rx_list_set_port_type(params->port_list_id,
                                                  SX_PORT_TYPE_ID_GET(params->port_list[0].log_port));
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to set rx list id [%u] port type in DB\n", params->port_list_id);
            }
        }
    }

    /* Update RX list in DB */
    rc = flex_acl_db_rx_list_set(params->port_list, params->port_list_count, params->port_list_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set rx list id [%u] in DB\n", params->port_list_id);
        goto out;
    }


    rc = flex_acl_db_rx_list_rules_ref_list_get(params->port_list_id, &rules_ref_set_list);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get rules ref list of rx list id:[%u] from DB, rc=[%s]\n",
                   params->port_list_id,
                   sx_status_str(rc));
        goto out;
    }

    /* Write to HW */
    for (iter = cl_qlist_head(rules_ref_set_list); iter != cl_qlist_end(rules_ref_set_list);
         iter = cl_qlist_next(iter)) {
        db_rule_id_entry_p = PARENT_STRUCT(iter, flex_acl_db_rule_id_item_t, list_item);
        rc = __flex_acl_write_region_offset_rule(db_rule_id_entry_p->rule_id.region_id,
                                                 db_rule_id_entry_p->rule_id.offset);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to write rule to dev, region_id: %u, offset: %u, rc=[%s]\n",
                       db_rule_id_entry_p->rule_id.region_id, db_rule_id_entry_p->rule_id.offset, sx_status_str(rc));
            iter_rollback = iter;
            goto rollback;
        }
    }
    goto out;

rollback:
    rb_rc = flex_acl_db_rx_list_set(port_list_current, port_list_count_current, params->port_list_id);
    if (SX_STATUS_SUCCESS != rb_rc) {
        SX_LOG_ERR("Fatal error at rollback, failed to set rx list id [%u] with old port list in DB\n",
                   params->port_list_id);
        goto out;
    }

    for (iter = cl_qlist_head(rules_ref_set_list); iter != iter_rollback;
         iter = cl_qlist_next(iter)) {
        db_rule_id_entry_p = PARENT_STRUCT(iter, flex_acl_db_rule_id_item_t, list_item);
        rb_rc = __flex_acl_write_region_offset_rule(db_rule_id_entry_p->rule_id.region_id,
                                                    db_rule_id_entry_p->rule_id.offset);
        if (SX_STATUS_SUCCESS != rb_rc) {
            SX_LOG_ERR(
                "Fatal error at rollback, failed to configure rule to dev, region_id: %u, offset: %u, rb_rc=[%s]\n",
                db_rule_id_entry_p->rule_id.region_id,
                db_rule_id_entry_p->rule_id.offset,
                sx_status_str(rb_rc));
        }
    }


out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_rx_list_destroy(sx_acl_port_list_id_t port_list_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    cl_qlist_t *rules_ref_set_list = NULL;

    SX_LOG_ENTER();

    rc = flex_acl_db_rx_list_rules_ref_list_get(port_list_id, &rules_ref_set_list);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to destroy flex_acl_db_rx_list_rules_ref_list_get failed [%u], rc=[%s]\n",
                   port_list_id,
                   sx_status_str(rc));
        goto out;
    }

    if (FALSE == cl_is_qlist_empty(rules_ref_set_list)) {
        rc = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("Failed to destroy rx list id [%u], rules list not empty, rc=[%s]\n", port_list_id, sx_status_str(
                       rc));
        goto out;
    }

    rc = flex_acl_db_rx_list_destroy(port_list_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to destroy rx list id [%u], flex_acl_db_rx_list_destroy rc=[%s]\n",
                   port_list_id,
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rx_list_set(sx_api_rx_list_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if ((params->cmd == SX_ACCESS_CMD_SET) || (params->cmd == SX_ACCESS_CMD_DESTROY)) {
        if (params->port_list_id < FLEX_ACL_PORT_LIST_MIN_ID) {
            SX_LOG_ERR("invalid rx list id [%u]\n", params->port_list_id);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        rc = __flex_acl_rx_list_create(params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to create new rx list \n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_SET:
        rc = __flex_acl_rx_list_set(params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set rx list [%u]. rc=[%s]\n", params->port_list_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        rc = __flex_acl_rx_list_destroy(params->port_list_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to destroy rx list [%u]. rc=[%s]\n", params->port_list_id, sx_status_str(rc));
            goto out;
        }
        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("rx list cmd: [%s] unsupported.\n", sx_access_cmd_str(params->cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }
out:

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rx_list_get(sx_api_rx_list_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (params->port_list_id < FLEX_ACL_PORT_LIST_MIN_ID) {
        SX_LOG_ERR("Failed to get rx list, invalid id [%u]\n", params->port_list_id);
        goto out;
    }

    memset(params->port_list, 0, sizeof(sx_acl_port_list_entry_t) * RM_API_ACL_PORT_LIST_MAX);

    /* Get rx list from db */
    rc = flex_acl_db_rx_list_get(params->port_list_id, params->port_list, &(params->port_list_count), NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get rx list id:[%u] from DB, rc=[%s]\n", params->port_list_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_bind_port(sx_api_acl_bind_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    /* Check that group id is a user group */
    rc = flex_acl_check_priveleges(params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->acl_id);
        goto out;
    }

    /* Validate Port */
    rc = flex_acl_validate_port(params->log_port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error when trying to validate port[%#x]\n", params->log_port);
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(params->log_port) == SX_PORT_TYPE_TUNNEL) {
        rc = flex_acl_db_validate_nve_port_bind(params->log_port, params->acl_direction);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to bind to NVE Port %#x, err %s\n", params->log_port, sx_status_str(rc));
            goto out;
        }
    }

    rc = flex_acl_bind_port_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at port bind, port 0x[%x] to group 0x[%x]\n", params->log_port, params->acl_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_unbind_port(sx_api_acl_bind_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Check that group id is not system */
    rc = flex_acl_check_priveleges(params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->acl_id);
        goto out;
    }

    /* Validate Port */
    rc = flex_acl_validate_port(params->log_port);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("Error when trying to validate port [%#x]\n", params->log_port);
        goto out;
    }

    rc = flex_acl_unbind_port_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at unbind port [%u] from group id[%u].\n", params->log_port, params->acl_id);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_bind_vlan_group(sx_api_acl_bind_params_t *params, boolean_t rebinding)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    /* Check that group id is not system */
    rc = flex_acl_check_priveleges(params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->acl_id);
        goto out;
    }
    rc = flex_acl_db_vlan_group_entry_type_get(params->vlan_group, &entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at get VLAN group entry_type, group id[%u].\n", params->vlan_group);
        goto out;
    }

    if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL :Error, illegal entry type[%u] of vlan group id[%u]\n", entry_type, params->vlan_group);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_bind_vlan_group_internal(params, rebinding);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at bind vlan group[%u] to  group id[%u].\n", params->vlan_group, params->acl_id);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_unbind_vlan_group(sx_api_acl_bind_params_t * params)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    /* Check that group id is not system */
    rc = flex_acl_check_priveleges(params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->acl_id);
        goto out;
    }

    rc = flex_acl_db_vlan_group_entry_type_get(params->vlan_group, &entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at get VLAN group entry_type, group id[%u].\n", params->vlan_group);
        goto out;
    }

    if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL :Error, illegal entry type[%u] of VLAN group id[%u]\n", entry_type, params->vlan_group);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_unbind_vlan_group_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at VLAN group unbind, acl group id[%u].\n", params->acl_id);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_bind_rif(sx_api_flex_acl_bind_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    /* Check that group id is a user group */
    rc = flex_acl_check_priveleges(params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->acl_id);
        goto out;
    }
    rc = flex_acl_bind_rif_internal(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at bind rif[%u] to group id[%u].\n", params->rif, params->acl_id);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_unbind_rif(sx_api_flex_acl_bind_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }
    /* check that group id is a user group */
    rc = flex_acl_check_priveleges(params->acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at check access for group id[%u].\n", params->acl_id);
        goto out;
    }
    rc = flex_acl_unbind_rif_internal(params, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Error at unbind rif[%u] from group id[%u].\n", params->rif, params->acl_id);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_is_region_have_valid_rules(sx_acl_region_id_t region_id, boolean_t *
                                                         valid_rules_exist)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *region = NULL;


    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(valid_rules_exist, "valid_rules_exist"))) {
        goto out;
    }
    rc = flex_acl_db_region_get(region_id, &region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("get region error, region_id: %u\n", region_id);
        goto out;
    }

    *valid_rules_exist = (region->valid_rules_num > region->reserved_rules_num);
out:
    SX_LOG_EXIT();
    return rc;
}

/* the trigger to bind acl group :GOTO action */
static sx_status_t __flex_acl_bind_group_on_goto_action_cb(flex_acl_db_flex_rule_t    *rule_p,
                                                           boolean_t                   rebind,
                                                           flex_acl_bind_attribs_id_t *bind_id,
                                                           boolean_t                  *is_empty_group)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    flex_acl_group_creation_data_t rollback_data;
    sx_acl_direction_t             direction = SX_ACL_DIRECTION_LAST;
    acl_id_group_entry_t           acl_ids_prepared[SPECTRUM_ACL_GROUPS_SIZE_MAX];
    uint32_t                       prepared_acls_num = rm_resource_global.acl_groups_size_max;
    boolean_t                      is_found = FALSE;
    sx_flex_acl_flex_action_goto_t goto_action;

    SX_LOG_ENTER();

    SX_MEM_CLR(rollback_data);
    memset(acl_ids_prepared, 0, sizeof(acl_ids_prepared));

    rc = flex_acl_db_rule_get_goto_action(rule_p, &is_found, &goto_action);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Get goto action failed, rc:%s\n", sx_status_str(rc));
        goto out;
    }
    if (!is_found ||
        !((goto_action.goto_action_cmd == SX_ACL_ACTION_GOTO_JUMP) ||
          (goto_action.goto_action_cmd == SX_ACL_ACTION_GOTO_CALL))) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("ACL action: GOTO action not found in rule\n");
        goto out;
    }

    /* Get the bind attributes for this ACL group */
    rc = flex_acl_get_bind_attribs(goto_action.acl_group_id, bind_id, &direction, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("error when trying to get bind attributes id for ACL group [%u]\n", goto_action.acl_group_id);
        goto out;
    }

    if (*bind_id == FLEX_ACL_INVALID_BIND_ATTRIBS_ID) {
        SX_LOG_ERR("ACL :failed to find bind attributes for goto rule: group[%d], region_id[%x] offset [%u] \n",
                   goto_action.acl_group_id,
                   rule_p->region_id,
                   rule_p->offset);
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* check if group configuration should be write to register */
    rc = flex_acl_hw_prepare_acl_list_from_groups(goto_action.acl_group_id, acl_ids_prepared, &prepared_acls_num,
                                                  direction);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to prepare acl list from group [0x%x] \n", goto_action.acl_group_id);
        goto out;
    }
    if (prepared_acls_num == 0) {
        *is_empty_group = TRUE;
    }
    /* If this is not a rebind of the attributes to rule, add it to the db */
    if (!rebind) {
        rc = flex_acl_db_attribs_bind_rule(*bind_id, rule_p->region_id, rule_p->offset);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL :failed bind rule to group[%d], region_id[%x] offset [%u] \n",
                       goto_action.acl_group_id,
                       rule_p->region_id,
                       rule_p->offset);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_unbind_group_on_goto_action_cb(sx_acl_id_t group_id, flex_acl_db_flex_rule_t *rule_p)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t         direction = SX_ACL_DIRECTION_LAST;
    flex_acl_bind_attribs_id_t bind_id = FLEX_ACL_INVALID_BIND_ATTRIBS_ID;

    SX_LOG_ENTER();
    /* Get the bind attributes for this ACL group */
    rc = flex_acl_get_bind_attribs(group_id, &bind_id, &direction, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("error when trying to get bind attributes id\n");
        goto out;
    }

    rc = flex_acl_db_attribs_unbind_rule(bind_id, rule_p->region_id, rule_p->offset);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL :failed bind rule to group[%d], region_id[%x] offset [%u] \n",
                   group_id,
                   rule_p->region_id,
                   rule_p->offset);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_l4_port_range_check_range(uint16_t min, uint16_t max)
{
    if (min > max) {
        return SX_STATUS_PARAM_ERROR;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t __flex_acl_set_range_on_all_devs(sx_acl_port_range_id_t id, sx_acl_port_range_entry_t *
                                             port_range)
{
    sx_dev_id_t devs_list[SX_DEV_NUM_MAX] = {0};
    uint16_t    dev_info_arr_size = 0;
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Prepare a list of relevant devices */
    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get devices list\n");
        goto out;
    }

    rc = flex_acl_hw_set_range_to_devs(port_range, id, devs_list, dev_info_arr_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to set port range [%u] \n", id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_port_range_add(sx_api_acl_l4_range_params_t * params)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_status_t            rb_rc = SX_STATUS_SUCCESS;
    sx_acl_port_range_id_t id = 0;

    SX_LOG_ENTER();
    /* Validate the range */
    rc = __flex_acl_l4_port_range_check_range(params->l4_port_range.port_range_min,
                                              params->l4_port_range.port_range_max);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to add new port range (max range must be >= min range)\n");
        goto out;
    }

    /* Validate available port range register */
    rc = flex_acl_db_port_range_get_available_idx(&id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to add new port range (no available port range)\n");
        goto out;
    }

    /* Return the index upwards  */
    params->range_id = id;

    /* Write ranges to DB*/
    rc = flex_acl_db_port_range_update(id, &(params->l4_port_range));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to update port range [%u] in db  \n", id);
        goto out;
    }
    /* Try to configure HW */
    rc = __flex_acl_set_range_on_all_devs(id, &(params->l4_port_range));
    if (rc != SX_STATUS_SUCCESS) {
        rb_rc = flex_acl_db_port_range_delete(id);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
        SX_LOG_ERR("ACL : Failed to write port range id [%u] to HW \n", id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return (rc);
}

sx_status_t __flex_acl_port_range_edit(sx_api_acl_l4_range_params_t * params)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_status_t               rb_rc = SX_STATUS_SUCCESS;
    sx_acl_port_range_entry_t rollback_range = {.port_range_min = 0};

    SX_LOG_ENTER();

    /* Validate the range */
    rc = __flex_acl_l4_port_range_check_range(params->l4_port_range.port_range_min,
                                              params->l4_port_range.port_range_max);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to add new port range (max range must be >= min range)\n");
        goto out;
    }

    /* DB pre edit validations*/
    rc = flex_acl_db_port_range_pre_edit(params->range_id, &(params->l4_port_range));
    if (SX_STATUS_ENTRY_ALREADY_EXISTS == rc) {
        /* no need to update DB or HW */
        rc = SX_STATUS_SUCCESS;
        goto out;
    }
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Pre edit port range failed, port_range_id: %u\n", params->range_id);
        goto out;
    }

    rc = flex_acl_db_port_range_get(params->range_id, &rollback_range);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get port range id [%u] in db \n", params->range_id);
        goto out;
    }

    /* Write ranges to DB*/
    rc = flex_acl_db_port_range_update(params->range_id, &(params->l4_port_range));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to update port range [%u] in db \n", params->range_id);
        goto out;
    }
    /* Try to configure HW */
    rc = __flex_acl_set_range_on_all_devs(params->range_id, &(params->l4_port_range));
    if (rc != SX_STATUS_SUCCESS) {
        rb_rc = flex_acl_db_port_range_update(params->range_id, &rollback_range);
        if (SX_CHECK_FAIL(rb_rc)) {
            SX_LOG_ERR("Fatal error at rollback, err [%s]\n", sx_status_str(rb_rc));
        }
        SX_LOG_ERR("ACL : Failed to write port range id [%u] to HW \n", params->range_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_l4_port_range_set(sx_api_acl_l4_range_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_ADD:
        rc = __flex_acl_port_range_add(params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to add new port range \n");
            goto out;
        }

        break;

    case SX_ACCESS_CMD_EDIT:
        rc = __flex_acl_port_range_edit(params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to edit port range [%u] \n", params->range_id);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        /* Delete range from DB, no HW intervention */
        rc = flex_acl_db_port_range_delete(params->range_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to delete port range [%u]. rc=[%u]\n", params->range_id, rc);
            goto out;
        }

        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("ACL l4 port range: [%s] unsupported.\n", sx_access_cmd_str(params->cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_l4_port_range_get(sx_api_acl_l4_range_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }

    /* Get port range from db */
    rc = flex_acl_db_port_range_get(params->range_id, &(params->l4_port_range));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get port range from db [%u] \n",
                   params->range_id);
        return rc;
    }

    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_range_set(sx_api_acl_range_params_t *params)
{
    UNUSED_PARAM(params);

    SX_LOG_ERR("Command in unsupported \n");
    return SX_STATUS_CMD_UNSUPPORTED;
}

sx_status_t flex_acl_range_get(sx_api_acl_range_params_t *params)
{
    UNUSED_PARAM(params);

    SX_LOG_ERR("Command in unsupported \n");
    return SX_STATUS_CMD_UNSUPPORTED;
}

inline static void __flex_acl_pbs_to_mc_key(sx_acl_pbs_id_t pbs_id, sx_fid_t fid, fdb_ext_mc_key_t *key_p)
{
    key_p->fid = fid;
    key_p->key = (0x230000 | pbs_id);
}

inline static void __flex_acl_mc_key_to_pbs(fdb_ext_mc_key_t key, sx_acl_pbs_id_t *pbs_id_p, sx_fid_t *fid_p)
{
    *fid_p = key.fid;
    *pbs_id_p = (key.key & (~0x230000));
}

sx_status_t flex_acl_l4_port_range_iter_get(sx_api_acl_l4_port_range_iter_get_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        return SX_STATUS_PARAM_NULL;
    }
    rc = flex_acl_db_port_range_iter_get(params->cmd,
                                         params->range_id_key,
                                         &(params->range_id_filter),
                                         params->range_id_list,
                                         &(params->range_id_cnt));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Port range iterator failed: Key [%u],  Count [%d]\n",
                   params->range_id_key, params->range_id_cnt);
        return rc;
    }
    return SX_STATUS_SUCCESS;
}


sx_status_t flex_acl_pbs_iter_get(sx_api_acl_pbs_iter_get_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return SX_STATUS_MODULE_UNINITIALIZED;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        return SX_STATUS_PARAM_NULL;
    }
    rc = flex_acl_db_pbs_iter_get(params->cmd,
                                  params->swid,
                                  params->pbs_id_key,
                                  &(params->pbs_id_filter),
                                  params->pbs_id_list,
                                  &(params->pbs_id_cnt));

    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Policy Based Switching iterator failed: Key [%u],  Count [%d]\n",
                   params->pbs_id_key, params->pbs_id_cnt);
        return rc;
    }
    return SX_STATUS_SUCCESS;
}

sx_status_t __flex_acl_validate_pbs_ports(uint32_t                ports_count,
                                          sx_port_id_t            log_ports[],
                                          sx_swid_id_t            param_swid,
                                          boolean_t             * is_vport,
                                          sx_fid_t              * fid,
                                          sx_acl_pbs_entry_type_t entry_type)
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    uint32_t       port_idx = 0;
    sx_fid_t       group_fid = 0;
    sx_port_info_t port_info;

    SX_LOG_ENTER();

    *is_vport = FALSE;
    for (port_idx = 0; port_idx < ports_count; port_idx++) {
        rc = port_db_info_get(log_ports[port_idx], &port_info);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL PBS port validation: Logical port[0x%08X] is not found [%s]\n",
                       log_ports[port_idx],
                       sx_status_str(rc));
            goto out;
        }
        if (port_info.swid_id != param_swid) {
            SX_LOG_ERR("ACL PBS port validation : Logical port[0x%08X] is not in PBS SWID [%u] \n",
                       log_ports[port_idx], param_swid);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (port_info.part_of_lag_fl && ((entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) ||
                                         (entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST))) {
            SX_LOG_ERR(
                "ACL PBS port validation : Logical port[0x%08X] is member of lag, cannot add to multicast pbs\n",
                log_ports[port_idx]);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (SX_PORT_TYPE_ID_GET(log_ports[port_idx]) == SX_PORT_TYPE_TUNNEL) {
            SX_LOG_ERR(
                "ACL PBS port validation : Logical port[0x%08X] is of type NVE, not supported for pbs\n",
                log_ports[port_idx]);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (IS_VPORT_OR_VLAG(log_ports[port_idx])) {
            rc = bridge_vport_fid_get(log_ports[port_idx], fid);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL PBS port validation : bridge_vport_fid_get failed, log_port: %u\n",
                           log_ports[port_idx]);
                goto out;
            }
            if (*fid == SX_FID_ID_INVALID) {
                SX_LOG_ERR("FID %u is invalid.\n", *fid);
                rc = SX_STATUS_PARAM_ERROR;
                goto out;
            }
            if (*is_vport) {
                if (*fid != group_fid) {
                    rc = SX_STATUS_ERROR;
                    SX_LOG_ERR("ACL PBS port validation : All vports should be of the same bridge\n");
                    goto out;
                }
            } else {
                if (port_idx > 0) {
                    rc = SX_STATUS_ERROR;
                    SX_LOG_ERR("Mix of vport and physical port. Vport port after non vport\n");
                    goto out;
                }
                group_fid = *fid;
                *is_vport = TRUE;
            }
        } else {
            if (*is_vport) {
                rc = SX_STATUS_ERROR;
                SX_LOG_ERR("Mix of vport and physical port. No vport after vport.\n");
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_ecmp_container_pbs_add(sx_ecmp_id_t                   ecmp_id,
                                            sx_acl_pbs_id_t               *pbs_id_p,
                                            sx_flex_acl_flex_action_type_t api_action_type)
{
    uint32_t                   ecmp_index = 0;
    flex_acl_db_pbs_entry_t    pbs_entry;
    flex_acl_db_pbs_entry_t   *pbs_edit_entry_p = NULL;
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_status_t                rollback_rc = SX_STATUS_SUCCESS;
    boolean_t                  is_empty = FALSE;
    boolean_t                  flex_acl_hw_add_pbs_done = FALSE;
    boolean_t                  flex_acl_db_pbs_set_entry_done = FALSE;
    hwd_ecmp_block_size_t      ecmp_size = ECMP_CONTAINER_INVALID_BLOCK_SIZE;
    hwi_ecmp_hw_block_handle_t ecmp_handle = INVALID_ECMP_BLOCK_HANDLE;
    uint32_t                   tunnel_port_bitmap = 0;


    SX_LOG_ENTER();
    UNUSED_PARAM(api_action_type);
    SX_MEM_CLR(pbs_entry);

    /* Save initial data */
    pbs_entry.ecmp_id = ecmp_id;
    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_LAST;
    pbs_entry.extended_entry_type = SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL_WITH_ECMP;

    /* Get ECMP container type and handle via ECMP ID */
    rc = sdk_router_ecmp_impl_active_set_get(ecmp_id,
                                             &ecmp_handle,
                                             &is_empty);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get ECMP data [ECMP ID = %u; error = %s].\n",
                   ecmp_id, sx_status_str(rc));
        goto out;
    }

    /*  Get KVD entry index and block size via ECMP handle */
    rc = hwd_router_ecmp_block_get(ecmp_handle, &ecmp_index, &ecmp_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get KVD entry data [ECMP handle = 0x%" PRIx64 "; error = %s].\n",
                   ecmp_handle, sx_status_str(rc));
        goto out;
    }

    /* Get the bitmap of the active tunnels in the ECMP */
    rc = sdk_router_ecmp_impl_l2_tunnel_get(ecmp_id, &tunnel_port_bitmap);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get ECMP L2 tunnel info [ECMP ID = %u; error = %s].\n",
                   ecmp_id, sx_status_str(rc));
        goto out;
    }


    /* Save KVD index, ECMP size to PBS entry */
    if (ecmp_size > 0) {
        pbs_entry.tnumt = ecmp_index;
        pbs_entry.tnumt_valid = TRUE;
        pbs_entry.ecmp_size = ecmp_size;
        pbs_entry.tunnel_port_bitmap = tunnel_port_bitmap;
    } else {
        pbs_entry.tnumt = 0;
        pbs_entry.tnumt_valid = FALSE;
        pbs_entry.ecmp_size = 0;
        pbs_entry.tunnel_port_bitmap = 0;
    }

    /* Get PBS ID from PBS records pool */
    rc = flex_acl_db_pbs_set_entry(&pbs_entry, pbs_id_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to create PBS DB record [error = %s].\n",
                   sx_status_str(rc));
        goto out;
    }
    flex_acl_db_pbs_set_entry_done = TRUE;

    /* Update config in HW */
    rc = flex_acl_hw_add_pbs(&pbs_entry, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to configure PBS HW entry [error = %s].\n",
                   sx_status_str(rc));
        goto out;
    }
    flex_acl_hw_add_pbs_done = TRUE;

    /* Get HW KVD handle via PBS ID */
    rc = flex_acl_db_pbs_get_entry(0, *pbs_id_p, &pbs_edit_entry_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL PBS add : failed to find PBS ID [%u]\n", *pbs_id_p);
        goto out;
    }

    pbs_edit_entry_p->kvd_handle = pbs_entry.kvd_handle;
    pbs_edit_entry_p->extended_entry_type = pbs_entry.extended_entry_type;
    pbs_edit_entry_p->is_system = TRUE;

out:
    if (SX_CHECK_FAIL(rc)) {
        if (flex_acl_hw_add_pbs_done) {
            rollback_rc = flex_acl_hw_del_pbs(&pbs_entry);
            if (SX_STATUS_SUCCESS != rollback_rc) {
                SX_LOG_ERR("Failed to delete PBS entry from HW on a rollback, rc [%s]\n",
                           sx_status_str(rollback_rc));
            }
        }
        if (flex_acl_db_pbs_set_entry_done) {
            rollback_rc = flex_acl_db_pbs_delete_entry(0, *pbs_id_p);
            if (SX_STATUS_SUCCESS != rollback_rc) {
                SX_LOG_ERR("Failed to delete DB PBs entry PBS on a rollback, rc [%s]\n",
                           sx_status_str(rollback_rc));
            }
        }
    }

    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_mc_container_pbs_add(sx_mc_container_id_t           mc_container_id,
                                          sx_acl_pbs_id_t               *pbs_id,
                                          sx_flex_acl_flex_action_type_t api_action_type)
{
    flex_acl_db_pbs_entry_t      pbs_entry;
    flex_acl_db_pbs_entry_t     *pbs_edit_entry = NULL;
    sx_status_t                  rc;
    sx_status_t                  rollback_rc;
    hw_mc_list_pointer_t         port_mc_list_pointer;
    hw_mc_list_pointer_t         nve_mc_list_pointer;
    sx_mc_container_attributes_t mc_container_attrs;
    boolean_t                    flex_acl_db_pbs_set_entry_done = FALSE;
    boolean_t                    flex_acl_hw_add_pbs_done = FALSE;
    boolean_t                    nve_mc_list_pointer_locked = FALSE;
    boolean_t                    port_mc_list_pointer_locked = FALSE;
    sx_mc_container_attributes_t attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(pbs_entry);
    SX_MEM_CLR(attr);

    pbs_entry.container_id = mc_container_id;

    if (api_action_type == SX_FLEX_ACL_ACTION_MC) {
        pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_MULTICAST;
    } else if (api_action_type == SX_FLEX_ACL_ACTION_NVE_MC_TUNNEL_ENCAP) {
        pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_LAST;
        pbs_entry.extended_entry_type = SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_MULTICAST_TUNNEL;

        rc = sdk_mc_container_impl_get(mc_container_id, NULL, NULL, &attr, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get FID by MC container ID[%u], rc [%s]\n",
                       mc_container_id,
                       sx_status_str(rc));
            goto rollback;
        }
        pbs_entry.fid = attr.fid;

        SX_MEM_CLR(nve_mc_list_pointer);
        rc = hwd_mc_container_nve_mc_list_get_with_lock(mc_container_id, &nve_mc_list_pointer, NULL);
        if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
            rc = SX_STATUS_SUCCESS;
            pbs_entry.tnumt_valid = FALSE;
        } else if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Mc container PBS add failed hwd_mc_container_nve_mc_list_get, MC container: %u, error: [%s]\n",
                mc_container_id,
                sx_status_str(rc));
            goto rollback;
        } else if (nve_mc_list_pointer.type == HW_MC_LIST_POINTER_TYPE_TUNNEL_ENCAP) {
            pbs_entry.tnumt = nve_mc_list_pointer.data.tnumt_pointer.tnumt_index;
            pbs_entry.tnumt_valid = TRUE;
            pbs_entry.ecmp_size = nve_mc_list_pointer.data.tnumt_pointer.ecmp_size;
            nve_mc_list_pointer_locked = TRUE;
        }
    }

    rc = hwd_mc_container_port_mc_list_get_with_lock(mc_container_id,  &port_mc_list_pointer, &mc_container_attrs);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "Mc container PBS add failed hwd_mc_container_port_mc_list_get_with_lock, MC container: %u, error: [%s]\n",
            mc_container_id,
            sx_status_str(rc));
        goto rollback;
    }
    port_mc_list_pointer_locked = TRUE;
    pbs_entry.mid = port_mc_list_pointer.data.smid_index;

    rc = flex_acl_db_pbs_set_entry(&pbs_entry, pbs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create DB PBs entry PBS rc [%s]\n", sx_status_str(rc));
        goto rollback;
    }
    flex_acl_db_pbs_set_entry_done = TRUE;

    rc = flex_acl_hw_add_pbs(&pbs_entry, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to configure PBS entry rc [%s]\n", sx_status_str(rc));
        goto rollback;
    }
    flex_acl_hw_add_pbs_done = TRUE;

    rc = flex_acl_db_pbs_get_entry(0, *pbs_id, &pbs_edit_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL PBS add : failed to find PBS ID [%u]\n", *pbs_id);
        goto rollback;
    }
    pbs_edit_entry->kvd_handle = pbs_entry.kvd_handle;
    pbs_edit_entry->extended_entry_type = pbs_entry.extended_entry_type;
    pbs_edit_entry->is_system = TRUE;

    goto out;

rollback:
    if (rc != SX_STATUS_SUCCESS) {
        if (flex_acl_hw_add_pbs_done) {
            rollback_rc = flex_acl_hw_del_pbs(&pbs_entry);
            if (SX_STATUS_SUCCESS != rollback_rc) {
                SX_LOG_ERR("Failed to delete PBS entry from HW on a rollback, rc [%s]\n",
                           sx_status_str(rollback_rc));
            }
        }
        if (flex_acl_db_pbs_set_entry_done) {
            rollback_rc = flex_acl_db_pbs_delete_entry(0, *pbs_id);
            if (SX_STATUS_SUCCESS != rollback_rc) {
                SX_LOG_ERR("Failed to delete DB PBs entry PBS on a rollback, rc [%s]\n",
                           sx_status_str(rollback_rc));
            }
        }
    }

out:
    if (port_mc_list_pointer_locked) {
        rollback_rc = hwd_mc_container_port_mc_list_unlock(&port_mc_list_pointer);
        if (SX_STATUS_SUCCESS != rollback_rc) {
            SX_LOG_ERR("Mc container PBS add failed in the hwd_mc_container_port_mc_list_unlock, rc [%s]\n",
                       sx_status_str(rollback_rc));
        }
        /* if rc == SX_STATUS_SUCCESS the port_mc_list_unlock call is a part of "good" flow
         *  and we should return a rc from this call, otherwise we should return a first error code and
         *  not the last one. */
        rc = (rc == SX_STATUS_SUCCESS) ? rollback_rc : rc;
    }
    if (nve_mc_list_pointer_locked) {
        rollback_rc = hwd_mc_container_nve_mc_list_unlock(mc_container_id);
        if (SX_STATUS_SUCCESS != rollback_rc) {
            SX_LOG_ERR("Mc container PBS add failed in hwd_mc_container_nve_mc_list_unlock, rc [%s]\n",
                       sx_status_str(rollback_rc));
        }
        /* if rc == SX_STATUS_SUCCESS the nve_mc_list_unlock call is a part of "good" flow
         *  and we should return a rc from this call, otherwise we should return a first error code and
         *  not the last one. */
        rc = (rc == SX_STATUS_SUCCESS) ? rollback_rc : rc;
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_pbs_del(sx_acl_pbs_id_t pbs_id)
{
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;
    sx_status_t              rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Validate PBS exists */
    rc = flex_acl_db_pbs_get_entry(0, pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL PBS delete: failed to find PBS swid [%u] PBS ID [%u]\n",
                   0, pbs_id);
        goto out;
    }

    /* Validate PBS not in use */
    if (pbs_entry->rules_ref_cnt > 0) {
        SX_LOG_ERR("ACL PBS delete: PBS [%u,%u] is in use by [%u] rules\n",
                   0, pbs_id, pbs_entry->rules_ref_cnt);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* Delete HW PBS entry */
    rc = flex_acl_hw_del_pbs(pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to delete PBS entry from HW rc [%s]\n", sx_status_str(rc));
        return rc;
    }

    /* Delete PBS record in DB */
    rc = flex_acl_db_pbs_delete_entry(0, pbs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL PBS delete:  Failed to delete entry from DB [%u,%u]\n", 0, pbs_id);
        return rc;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_ipv6_addr_add(const sx_ip_addr_t   *ip_addr_p,
                                            hwi_ipv6_hw_handle_t *handle_p,
                                            hwi_ipv6_hw_index_t  *hw_index_p,
                                            boolean_t            *ipv6_added_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_status_t rc_rb = SX_STATUS_SUCCESS;
    char        ipv6_addr_str[FORMAT_BUFFER_SIZE] = {0};

    rc = sdk_ipv6_impl_add(ip_addr_p, handle_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to add address [%s] to IPv6 manager.\n",
                   format_ip_addr(ip_addr_p, ipv6_addr_str));
        goto out;
    }
    *ipv6_added_p = TRUE;

    rc = sdk_ipv6_impl_block_lock(*handle_p, hw_index_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to lock IPv6 handle [0x%" PRIx64 "] in hwd, err = %s\n",
                   *handle_p, sx_status_str(rc));
        goto out;
    }

    rc = sdk_ipv6_impl_block_unlock(*handle_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to unlock IPv6 handle [0x%" PRIx64 "] in hwd, err = %s\n",
                   *handle_p, sx_status_str(rc));
        goto out;
    }

out:
    if (rc != SX_STATUS_SUCCESS) {
        if (*ipv6_added_p) {
            *ipv6_added_p = FALSE;

            rc_rb = __flex_acl_ipv6_addr_free(ip_addr_p);
            if (rc_rb != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Rollback: Failed to free IPv6 address [%s].\n", format_ip_addr(ip_addr_p, ipv6_addr_str));
            }
        }
    }
    return rc;
}

static sx_status_t __flex_acl_ipv6_addr_free(const sx_ip_addr_t *ip_addr_p)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    hwi_ipv6_hw_handle_t handle = 0;
    char                 ipv6_addr_str[FORMAT_BUFFER_SIZE] = {0};

    rc = sdk_ipv6_impl_get(ip_addr_p, &handle);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get the handle of IPv6 address [%s].\n",
                   format_ip_addr(ip_addr_p, ipv6_addr_str));
        goto out;
    }

    rc = sdk_ipv6_impl_delete(handle);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to release IPv6 handle [0x%" PRIx64 "]\n", handle);
        goto out;
    }

out:
    return rc;
}

sx_status_t flex_acl_nve_tunnel_pbs_add(sx_ip_next_hop_ip_tunnel_t tunnel_info, sx_acl_pbs_id_t *pbs_id)
{
    flex_acl_db_pbs_entry_t  pbs_entry;
    flex_acl_db_pbs_entry_t *pbs_edit_entry = NULL;
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_status_t              rc_rb = SX_STATUS_SUCCESS;
    sx_port_log_id_t         log_port;
    hwi_ipv6_hw_handle_t     ipv6_handle = 0;
    hwi_ipv6_hw_index_t      ipv6_hw_index = 0;
    boolean_t                ipv6_added = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(pbs_entry);

    rc = sdk_tunnel_impl_log_port_by_tunnel_id_get(tunnel_info.tunnel_id, &log_port);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to lookup nve log port from tunnel id rc [%s]\n", sx_status_str(rc));
        goto out;
    }

    if (tunnel_info.underlay_dip.version == SX_IP_VERSION_IPV6) {
        rc = __flex_acl_ipv6_addr_add(&tunnel_info.underlay_dip, &ipv6_handle, &ipv6_hw_index, &ipv6_added);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to add address to IPv6 manager.\n");
            goto out;
        }
    }

    pbs_entry.entry_type = SX_ACL_PBS_ENTRY_TYPE_LAST;
    pbs_entry.extended_entry_type = SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL;
    pbs_entry.ip_tunnel.tunnel_id = tunnel_info.tunnel_id;
    pbs_entry.ip_tunnel.underlay_dip = tunnel_info.underlay_dip;
    pbs_entry.log_port = log_port;
    pbs_entry.port_num = 1;
    pbs_entry.is_system = TRUE;
    if (tunnel_info.underlay_dip.version == SX_IP_VERSION_IPV6) {
        pbs_entry.ipv6_hw_index = ipv6_hw_index;
    }

    rc = flex_acl_db_pbs_set_entry(&pbs_entry, pbs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create DB PBs entry PBS rc [%s]\n", sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_hw_add_pbs(&pbs_entry, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        flex_acl_db_pbs_delete_entry(0, pbs_entry.pbs_id);
        SX_LOG_ERR("Failed to configure PBS entry rc [%s]\n", sx_status_str(rc));
        return rc;
    }

    rc = flex_acl_db_pbs_get_entry(0, *pbs_id, &pbs_edit_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL pbs add : failed to find PBS ID [%u]\n", *pbs_id);
        return rc;
    }

    pbs_edit_entry->kvd_handle = pbs_entry.kvd_handle;
    pbs_edit_entry->is_system = TRUE;
    pbs_edit_entry->ip_tunnel.tunnel_id = pbs_entry.ip_tunnel.tunnel_id;
    pbs_edit_entry->ip_tunnel.underlay_dip = pbs_entry.ip_tunnel.underlay_dip;
    pbs_edit_entry->extended_entry_type = SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL;

out:
    if (rc != SX_STATUS_SUCCESS) {
        if (ipv6_added) {
            rc_rb = __flex_acl_ipv6_addr_free(&tunnel_info.underlay_dip);
            if (rc_rb != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Rollback: Failed to free IPv6 address.\n");
            }
        }
    }
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_nve_tunnel_pbs_del(sx_acl_pbs_id_t pbs_id)
{
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;
    sx_status_t              rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* validate PBS exists */
    rc = flex_acl_db_pbs_get_entry(0, pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "ACL PBS delete : failed to find PBS swid [%u] PBS ID [%u]\n", 0, pbs_id);
        goto out;
    }

    /* Validate PBS not in use */
    if (pbs_entry->rules_ref_cnt > 0) {
        SX_LOG_ERR("ACL PBS delete : PBS [%u,%u] is in use by [%u] rules\n",
                   0, pbs_id, pbs_entry->rules_ref_cnt);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    rc = flex_acl_hw_del_pbs(pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to delete PBS entry from HW rc [%s]\n", sx_status_str(rc));
        return rc;
    }

    if (pbs_entry->ip_tunnel.underlay_dip.version == SX_IP_VERSION_IPV6) {
        rc = __flex_acl_ipv6_addr_free(&(pbs_entry->ip_tunnel.underlay_dip));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to free IPv6 address, PBS ID [%u], error: [%s].\n", pbs_id, sx_status_str(rc));
            goto out;
        }
    }

    rc = flex_acl_db_pbs_delete_entry(0, pbs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL PBS delete:  Failed to delete entry from DB [%u,%u]\n", 0, pbs_id);
        return rc;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t __flex_acl_pbs_add(sx_api_acl_pbs_set_params_t * params)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t pbs_entry, *pbs_edit_entry = NULL;
    sx_acl_pbs_id_t         pbs_id = 0;
    boolean_t               is_vport;
    sx_fid_t                fid = SX_FID_ID_INVALID;
    uint8_t                 ports_bitmap[FLEX_ACL_NUM_OF_BYTES_TO_LIST_PORTS];
    fdb_ext_mc_key_t        key;

    SX_LOG_ENTER();

    SX_MEM_CLR(pbs_entry);
    SX_MEM_CLR_ARRAY(ports_bitmap, FLEX_ACL_NUM_OF_BYTES_TO_LIST_PORTS, uint8_t);
    SX_MEM_CLR(key);

    rc = __flex_acl_validate_pbs_ports(params->port_num, params->log_ports, params->swid, &is_vport, &fid,
                                       params->entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("PBS add failed port validation\n");
        goto out;
    }

    if (params->entry_type > SX_ACL_PBS_ENTRY_TYPE_MAX) {
        SX_LOG_ERR("PBS entry type invalid.\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    pbs_entry.swid = params->swid;
    pbs_entry.entry_type = params->entry_type;
    pbs_entry.port_num = params->port_num;
    pbs_entry.log_port = SX_INVALID_PORT;
    if (pbs_entry.port_num > 0) {
        pbs_entry.log_port = params->log_ports[0];
    }
    pbs_entry.is_vport = is_vport;
    pbs_entry.fid = SX_FID_ID_INVALID;
    if (is_vport) {
        pbs_entry.fid = fid;
    }
    rc = flex_acl_db_pbs_set_entry(&pbs_entry, &pbs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to create DB PBs entry PBS rc [%u]\n", rc);
        return rc;
    }

    pbs_entry.pbs_id = pbs_id;

    SX_LOG_DBG("PBS entry created in DB pbs id :%u \n", pbs_id);

    __flex_acl_pbs_to_mc_key(pbs_entry.pbs_id, pbs_entry.fid, &key);

    if ((params->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) ||
        (params->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
        /* Get MID, PGI for this record */
        rc = fdb_ext_mc_mac_addr_set(SX_ACCESS_CMD_ADD, params->swid,
                                     key, 0, NULL, &(pbs_entry.pgi),
                                     &(pbs_entry.mid));
        if (rc != SX_STATUS_SUCCESS) {
            flex_acl_db_pbs_delete_entry(params->swid, pbs_entry.pbs_id);
            SX_LOG_ERR("Failed to get MID for PBS rc [%u]\n", rc);
            return SX_STATUS_NO_RESOURCES;
        }

        SX_LOG_DBG("MULTICAST PBS is created pgi:%d mid:%d num of ports:%d \n",
                   pbs_entry.pgi,
                   pbs_entry.mid,
                   params->port_num);

        /* Check that there is no duplicate network ports or LAG ports */
        rc = __flex_acl_set_ports_bitmap(params->log_ports, params->port_num, is_vport, ports_bitmap);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set ports bitmap\n, rc=[%s]\n", sx_status_str(rc));
            goto out;
        }

        /* If there are ports, add them to entry */
        if (params->port_num > 0) {
            rc = fdb_ext_mc_mac_addr_set(SX_ACCESS_CMD_ADD_PORTS, params->swid,
                                         key, params->port_num,
                                         params->log_ports, &(pbs_entry.pgi), &(pbs_entry.mid));
            if (rc != SX_STATUS_SUCCESS) {
                fdb_ext_mc_mac_addr_set(SX_ACCESS_CMD_DELETE, params->swid,
                                        key, 0, NULL,
                                        &(pbs_entry.pgi), &(pbs_entry.mid));
                SX_LOG_ERR("Failed to get Add ports to Multicast PBS rc [%u]\n", rc);
                return SX_STATUS_NO_RESOURCES;
            }
            SX_LOG_DBG("PBS MULTICAST %d ports added to pbs:%u \n", params->port_num, pbs_id);
        }
    }

    rc = flex_acl_hw_add_pbs(&pbs_entry, is_vport);
    if (rc != SX_STATUS_SUCCESS) {
        if ((params->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) ||
            (params->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
            fdb_ext_mc_mac_addr_set(SX_ACCESS_CMD_DELETE, params->swid,
                                    key, 0, NULL,
                                    &(pbs_entry.pgi), &(pbs_entry.mid));
        }
        flex_acl_db_pbs_delete_entry(params->swid, pbs_entry.pbs_id);
        SX_LOG_ERR("Failed to configure PBS entry, pbs_id: %u, rc [%u]\n", pbs_entry.pbs_id, rc);
        return rc;
    }

    rc = flex_acl_db_pbs_get_entry(0, pbs_id, &pbs_edit_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL pbs add : failed to find PBS  ID [%u]\n", pbs_id);
        return rc;
    }
    pbs_edit_entry->kvd_handle = pbs_entry.kvd_handle;
    pbs_edit_entry->is_system = FALSE;
    if ((params->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) ||
        (params->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
        pbs_edit_entry->pgi = pbs_entry.pgi;
        pbs_edit_entry->mid = pbs_entry.mid;
    }

    params->pbs_id = pbs_id;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_pbs_del(sx_api_acl_pbs_set_params_t * params)
{
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;
    sx_status_t              rc = SX_STATUS_SUCCESS;
    fdb_ext_mc_key_t         key;

    SX_LOG_ENTER();

    SX_MEM_CLR(key);

    /* validate PBS exists */
    rc = flex_acl_db_pbs_get_entry(params->swid, params->pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "ACL PBS delete : failed to find PBS swid [%u] PBS ID [%u]\n",
            params->swid, params->pbs_id);
        return rc;
    }
    if (pbs_entry->is_system) {
        SX_LOG_ERR("ACL PBS delete : PBS [%u,%u] is a system PBS\n",
                   params->swid, params->pbs_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }
    /* Validate PBS not in use */
    if (pbs_entry->rules_ref_cnt > 0) {
        SX_LOG_ERR("ACL PBS delete : PBS [%u,%u] is in use by [%u] rules\n",
                   params->swid, params->pbs_id, pbs_entry->rules_ref_cnt);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }
    /* The rules list should be empty. Otherwise we have data integrity issue */
    if (!cl_is_list_empty(&(pbs_entry->rules_list))) {
        SX_LOG_ERR("ACL PBS delete : PBS [%u,%u]. rules list is not empty\n",
                   params->swid, params->pbs_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_hw_del_pbs(pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to delete PBS entry from HW rc [%u]\n", rc);
        return rc;
    }

    /* If mcast entries delete MID */
    if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) ||
        (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
        /* Return MID*/
        __flex_acl_pbs_to_mc_key(pbs_entry->pbs_id, pbs_entry->fid, &key);

        rc = fdb_ext_mc_mac_addr_set(SX_ACCESS_CMD_DELETE, params->swid,
                                     key, 0, NULL,
                                     &(pbs_entry->pgi),
                                     &(pbs_entry->mid));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to return MID [0x%x] for PBS rc [%u]\n",
                       pbs_entry->mid, rc);
            return rc;
        }
    }

    /* Update entry in DB */
    rc = flex_acl_db_pbs_delete_entry(params->swid, params->pbs_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL PBS delete:  Failed to delete entry from DB [%u,%u]\n",
                   params->swid, params->pbs_id);
        return rc;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_change_pbs_actions(flex_acl_db_pbs_entry_t *pbs_entry,
                                          boolean_t                to_pbs_action,
                                          boolean_t                full_rewrite)
{
    sx_status_t         rc = SX_STATUS_SUCCESS, rb_rc;
    flex_acl_rule_id_t *rule_id_p;
    cl_list_iterator_t  iter = NULL;
    cl_list_iterator_t  list_end = NULL;
    cl_list_iterator_t  list_head = NULL;
    uint32_t            num_of_successfull = 0, i;

    SX_LOG_ENTER();

    /* for all the rules connected to pbs */
    list_head = cl_list_head(&(pbs_entry->rules_list));
    list_end = cl_list_end(&(pbs_entry->rules_list));
    for (iter = list_head; iter != list_end;
         iter = cl_list_next(iter)) {
        rule_id_p = (flex_acl_rule_id_t*)cl_list_obj(iter);
        SX_LOG_DBG("Change pbs action %s for rule region:%d offset:%d \n", to_pbs_action ? "PBS" : "Drop",
                   rule_id_p->region_id, rule_id_p->offset);
        if (full_rewrite) {
            /* Write the rule again and by thus updating the actions */
            rc = __flex_acl_rewrite_rule_actions(rule_id_p->region_id, rule_id_p->offset);
        } else {
            rc = flex_acl_hw_change_pbs_action(rule_id_p, pbs_entry, to_pbs_action);
        }
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed in to write pbs new action\n");
            goto rollback;
        }
        num_of_successfull++;
    }

    goto out;

rollback:
    /* Rollback is impossible for full rewrite */
    list_end = cl_list_end(&(pbs_entry->rules_list));
    list_head = cl_list_head(&(pbs_entry->rules_list));
    if (!full_rewrite) {
        for (i = 0, iter = list_head;
             i < num_of_successfull && iter != list_end;
             i++, iter = cl_list_next(iter)) {
            rule_id_p = (flex_acl_rule_id_t*)cl_list_obj(iter);
            SX_LOG_DBG("Rollback change pbs action %s for rule region:%d offset:%d \n",
                       !to_pbs_action ? "PBS" : "Drop",
                       rule_id_p->region_id,
                       rule_id_p->offset);
            rb_rc = flex_acl_hw_change_pbs_action(rule_id_p, pbs_entry, !to_pbs_action);
            if (SX_STATUS_SUCCESS != rb_rc) {
                SX_LOG_ERR("rollback Failed in to write pbs new action\n");
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_acl_set_ports_bitmap(sx_port_id_t *port_list,
                                               uint32_t      port_count,
                                               boolean_t     is_vport,
                                               uint8_t      *ports_bitmap)
{
    sx_status_t   rc = SX_STATUS_SUCCESS;
    uint32_t      lag_port_count = rm_resource_global.lag_port_members_max;
    sx_port_id_t *lag_port_list_p = NULL;
    uint32_t      port_idx = 0, lag_port_idx = 0;
    uint32_t      phy_port = 0;

    SX_LOG_ENTER();

    lag_port_list_p = (sx_port_log_id_t*)cl_malloc(lag_port_count * sizeof(sx_port_log_id_t));
    if (lag_port_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory for lag port list\n");
        goto out;
    }

    for (port_idx = 0; port_idx < port_count; port_idx++) {
        lag_port_count = rm_resource_global.lag_port_members_max;
        memset(lag_port_list_p, 0, lag_port_count * sizeof(sx_port_log_id_t));
        rc = flex_acl_get_lag_ports_list(port_list[port_idx], is_vport, lag_port_list_p, &lag_port_count);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get port list for LAG [0x%x], rc=[%s]\n",
                       (uint32_t)port_list[port_idx],
                       sx_status_str(rc));
            goto out;
        }

        for (lag_port_idx = 0; lag_port_idx < lag_port_count; lag_port_idx++) {
            SX_LOG_DBG("\n lag_port[%#x], port_count[%d],ports_list_p[%u]=[%u]\n", (uint32_t)port_list[port_idx],
                       lag_port_count, lag_port_idx, lag_port_list_p[lag_port_idx]);
            phy_port = SX_PORT_PHY_ID_GET(lag_port_list_p[lag_port_idx]);
            if (SXD_BITMAP_GET(ports_bitmap, FLEX_ACL_NUM_OF_BYTES_TO_LIST_PORTS, FLEX_ACL_BITS_IN_BYTE, phy_port)) {
                rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
                SX_LOG_ERR("Logical port[0x%08X] already exist in pbs port list\n", lag_port_list_p[lag_port_idx]);
                goto out;
            }

            SXD_BITMAP_SET(ports_bitmap, FLEX_ACL_NUM_OF_BYTES_TO_LIST_PORTS, FLEX_ACL_BITS_IN_BYTE, phy_port);
        }
    }

out:
    if (lag_port_list_p != NULL) {
        cl_free(lag_port_list_p);
    }

    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_change_mc_pbs_empty_vport_fid(flex_acl_db_pbs_entry_t *pbs_entry,
                                                            sx_fid_t                 old_fid,
                                                            sx_fid_t                 new_fid)
{
    sx_status_t      rc = SX_STATUS_SUCCESS;
    fdb_ext_mc_key_t key;

    SX_LOG_ENTER();

    /* When we're are changing to/from an empty PBS to/from a vport one,
     * we need to to change the fid in the FDB database.
     * We're doing so be removing the entry with the old fid and add it again with the new fid.
     * Note: The mid previously allocated will be released and a new one will be used.
     */
    __flex_acl_pbs_to_mc_key(pbs_entry->pbs_id, old_fid, &key);
    rc = fdb_ext_mc_mac_addr_set(SX_ACCESS_CMD_DELETE, pbs_entry->swid,
                                 key, 0, NULL,
                                 &(pbs_entry->pgi),
                                 &(pbs_entry->mid));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("PBS change empty vport fid: Failed to delete MID [0x%x] for PBS [%u] rc [%u]\n",
                   pbs_entry->mid, pbs_entry->pbs_id, rc);
        goto out;
    }
    __flex_acl_pbs_to_mc_key(pbs_entry->pbs_id, new_fid, &key);
    rc = fdb_ext_mc_mac_addr_set(SX_ACCESS_CMD_ADD, pbs_entry->swid,
                                 key, 0, NULL, &(pbs_entry->pgi),
                                 &(pbs_entry->mid));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("PBS change empty vport fid: Failed to set MID for PBS [%u] rc [%u]\n", pbs_entry->pbs_id, rc);
        goto out;
    }

    rc = flex_acl_hw_config_pbs(pbs_entry, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("PBS change empty vport fid: PBS %u failed to change fid to %u rc [%u]\n",
                   pbs_entry->pbs_id,
                   new_fid,
                   rc);
        rc = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static boolean_t __flex_acl_is_port_in_pbs(sx_swid_t       swid,
                                           uint32_t        port_num,
                                           sx_port_id_t   *ports_to_add,
                                           sx_acl_pbs_id_t pbs_id,
                                           sx_fid_t        fid,
                                           uint16_t        old_ports_count,
                                           boolean_t       is_vport)
{
    boolean_t        is_found = TRUE;
    sx_status_t      rc = SX_STATUS_SUCCESS;
    sx_port_id_t    *old_port_list = NULL;
    uint8_t          ports_bitmap[FLEX_ACL_NUM_OF_BYTES_TO_LIST_PORTS];
    fdb_ext_mc_key_t key;

    SX_LOG_ENTER();

    SX_MEM_CLR(key);

    rc = utils_clr_memory_get((void**)&old_port_list, old_ports_count, sizeof(sx_port_id_t), UTILS_MEM_TYPE_ID_ACL_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("PBS add ports : Failed to allocate memory rc=[%s]\n", sx_status_str(rc));
        goto out;
    }

    __flex_acl_pbs_to_mc_key(pbs_id, fid, &key);

    rc = fdb_ext_mc_mac_addr_get(swid, key,
                                 &old_ports_count, old_port_list);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get PBS multicast ports list pbs_entry [%u], rc=[%s]\n", pbs_id, sx_status_str(rc));
        goto out;
    }

    memset(ports_bitmap, 0, sizeof(ports_bitmap));
    /* existing ports */
    rc = __flex_acl_set_ports_bitmap(old_port_list, old_ports_count, is_vport, ports_bitmap);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set ports bitmap\n, rc=[%s]\n", sx_status_str(rc));
        goto out;
    }

    /* new ports to add */
    rc = __flex_acl_set_ports_bitmap(ports_to_add, port_num, is_vport, ports_bitmap);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Logical port already exist in pbs port list\n, rc=[%s]\n", sx_status_str(rc));
        goto out;
    }
    is_found = FALSE;

out:
    if (old_port_list) {
        if (utils_memory_put(old_port_list, UTILS_MEM_TYPE_ID_ACL_E) != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL PBS add ports : Failed to deallocate memory\n");
            if (rc == SX_STATUS_SUCCESS) {
                rc = SX_STATUS_NO_MEMORY;
            }
        }
    }

    SX_LOG_EXIT();
    return is_found;
}


sx_status_t __flex_acl_pbs_add_ports(sx_api_acl_pbs_set_params_t * params)
{
    sx_status_t              rc = SX_STATUS_SUCCESS, rb_rc;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;
    flex_acl_db_pbs_entry_t  edit_entry;
    boolean_t                is_vport = FALSE, old_is_vport = FALSE;
    sx_fid_t                 fid = 0, old_fid = 0;
    uint16_t                 old_ports_count = 0;
    fdb_ext_mc_key_t         key;

    SX_LOG_ENTER();

    SX_MEM_CLR(edit_entry);
    SX_MEM_CLR(key);

    /* validate PBS exists */
    rc = flex_acl_db_pbs_get_entry(params->swid, params->pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "ACL PBS delete : failed to find PBS swid [%u] PBS ID [%u]\n",
            params->swid, params->pbs_id);
        goto out;
    }

    if (pbs_entry->entry_type != params->entry_type) {
        SX_LOG_ERR(
            "ACL PBS add ports : entry type mismatch between existing entry and received entry\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (pbs_entry->is_system) {
        SX_LOG_ERR("ACL PBS add ports : PBS [%u,%u] is a system PBS\n",
                   params->swid, params->pbs_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (params->port_num == 0) {
        goto out;
    }

    if (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_ROUTING) {
        SX_LOG_ERR("In ACL PBS add ports: Pbs entry type not supported\n");
        rc = SX_STATUS_UNSUPPORTED;
        goto out;
    }


    /* Unicast PBS can contain only one port*/
    if (((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_UNICAST) ||
         (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST))
        && ((pbs_entry->port_num + params->port_num) > 1)) {
        SX_LOG_ERR("ACL PBS : Unicast PBS can not contain [%u] ports\n",
                   (pbs_entry->port_num + params->port_num));
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* validate new ports exist */
    rc = __flex_acl_validate_pbs_ports(params->port_num, params->log_ports, params->swid, &is_vport, &fid,
                                       pbs_entry->entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("PBS add ports. port validation failed\n");
        goto out;
    }

    /* Validate that new ports types do not conflict existing port types */
    if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) ||
        (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
        old_ports_count = 0;
        __flex_acl_pbs_to_mc_key(pbs_entry->pbs_id, pbs_entry->fid, &key);

        rc =
            fdb_ext_mc_mac_addr_get(params->swid, key,
                                    &old_ports_count, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get number of PBS multicast ports pbs_entry [%u]\n", pbs_entry->pbs_id);
            goto out;
        }
        SX_LOG_DBG("PBS entry port_num:%d is vport:%d fid:%d \n", old_ports_count, pbs_entry->is_vport,
                   pbs_entry->fid);
        if ((old_ports_count > 0) && (is_vport != pbs_entry->is_vport)) {
            SX_LOG_ERR("PBS add ports - Mix between new ports and existing ports. vport and real port\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
        if (old_ports_count && is_vport && (fid != pbs_entry->fid)) {
            SX_LOG_ERR("PBS add ports -vport, fid of existing ports is not equal to fid of new ports\n");
            rc = SX_STATUS_ERROR;
            goto out;
        }

        /* check that new ports aren't already in PBS */
        if (__flex_acl_is_port_in_pbs(params->swid, params->port_num, params->log_ports, pbs_entry->pbs_id,
                                      pbs_entry->fid, old_ports_count, is_vport)) {
            SX_LOG_ERR("PBS add ports failed -Logical port already exist in port list \n");
            rc = SX_STATUS_ERROR;
            goto out;
        }
    }

    switch (pbs_entry->entry_type) {
    case SX_ACL_PBS_ENTRY_TYPE_MULTICAST:
    case SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST:
        if (is_vport && (fid != pbs_entry->fid)) {
            /* When we're are changing from an empty PBS to a vport one,
             * we need to to change the fid in the FDB database.
             * Note: The mid previously allocated will be released and a new one will be used.
             */
            rc = __flex_acl_change_mc_pbs_empty_vport_fid(pbs_entry, pbs_entry->fid, fid);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("PBS port add: Failed to set MID for PBS [%u] rc [%u]\n", pbs_entry->pbs_id, rc);
                goto out;
            }
            pbs_entry->is_vport = is_vport;
            pbs_entry->fid = fid;
        }
        /* For Spectrum2 we need to add for every MC vport pbs a set FID action.
         * So if we change a PBS to have vports (after having zero vports) we need
         * to update all rules having that pbs to include the set fid action. We do
         * that by rewriting the entry action lists of the affected rules.
         */
        if ((g_acl_stage != ACL_STAGE_FLEX) && (old_ports_count == 0) && is_vport) {
            /* We store the old values since the update to the actual entry db will be done later.
             * However, the pbs entry needs to be updated now in order for the pbs actions
             * to be updated correctly to hw.
             */
            old_is_vport = pbs_entry->is_vport;
            old_fid = pbs_entry->fid;
            pbs_entry->is_vport = is_vport;
            pbs_entry->fid = fid;
            rc = __flex_acl_change_pbs_actions(pbs_entry, TRUE, TRUE);
            pbs_entry->is_vport = old_is_vport;
            pbs_entry->fid = old_fid;
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL failed to rewrite pbs actions for adding ports. pbs id:[%u] \n", params->pbs_id);
                pbs_entry->is_vport = FALSE;
                rb_rc = __flex_acl_change_pbs_actions(pbs_entry, TRUE, TRUE);
                if (rb_rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("ACL Failed to configure PBS entry on on rollback rc [%u]\n", rc);
                }
                goto out;
            }
        }

        __flex_acl_pbs_to_mc_key(pbs_entry->pbs_id, pbs_entry->fid, &key);

        rc = fdb_ext_mc_mac_addr_set(SX_ACCESS_CMD_ADD_PORTS, pbs_entry->swid,
                                     key, params->port_num,
                                     params->log_ports, &(pbs_entry->pgi), &(pbs_entry->mid));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to Add ports to Multicast PBS [%u,%u] rc [%u]\n",
                       pbs_entry->swid, pbs_entry->pbs_id, rc);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        break;

    case SX_ACL_PBS_ENTRY_TYPE_UNICAST:
    case SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST:
        edit_entry.entry_type = pbs_entry->entry_type;
        edit_entry.swid = pbs_entry->swid;
        edit_entry.pbs_id = params->pbs_id;
        edit_entry.port_num = pbs_entry->port_num + params->port_num;
        edit_entry.log_port = params->log_ports[0];
        edit_entry.kvd_handle = pbs_entry->kvd_handle;
        rc = flex_acl_hw_config_pbs(&edit_entry, is_vport);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Failed to configure PBS entry rc [%u]\n", rc);
            goto out;
        }
        pbs_entry->log_port = params->log_ports[0];
        break;

    default:
        break;
    }

    pbs_entry->is_vport = is_vport;
    if (is_vport) {
        pbs_entry->fid = fid;
    }
    pbs_entry->port_num += params->port_num;

    if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_UNICAST) ||
        (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST)) {
        rc = __flex_acl_change_pbs_actions(pbs_entry, TRUE, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL failed to change pbs actions PBS ID:%u \n", params->pbs_id);
            pbs_entry->port_num = 0;
            edit_entry.port_num = 0;
            edit_entry.kvd_handle = pbs_entry->kvd_handle;
            rb_rc = flex_acl_hw_config_pbs(&edit_entry, is_vport);
            if (rb_rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL Failed to configure PBS entry on on rollback rc [%u]\n", rc);
            }
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_pbs_del_ports(sx_api_acl_pbs_set_params_t * params)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;
    uint32_t                 port_idx = 0;
    sx_port_info_t           port_info;

    SX_LOG_ENTER();

    /* validate PBS exists */
    rc = flex_acl_db_pbs_get_entry(params->swid, params->pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(
            "ACL PBS delete : failed to find PBS swid [%u] PBS ID [%u]\n",
            params->swid, params->pbs_id);
        return rc;
    }
    if (pbs_entry->is_system) {
        SX_LOG_ERR("ACL PBS delete ports : PBS [%u,%u] is a system PBS\n",
                   params->swid, params->pbs_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (params->port_num == 0) {
        return SX_STATUS_SUCCESS;
    }

    if (pbs_entry->swid != params->swid) {
        SX_LOG_ERR("Invalid SWID given [%u]\n", params->swid);
        return SX_STATUS_PARAM_ERROR;
    }

    /* validate ports exist */
    for (port_idx = 0; port_idx < params->port_num; port_idx++) {
        rc = port_db_info_get(params->log_ports[port_idx], &port_info);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL PBS port validation: Logical port[0x%08X] is not found [%s]\n",
                       params->log_ports[port_idx],
                       sx_status_str(rc));
            goto out;
        }
        if (port_info.swid_id != params->swid) {
            SX_LOG_ERR("ACL PBS port validation : Logical port[0x%08X] is not in PBS SWID [%u] \n",
                       params->log_ports[port_idx], params->swid);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    rc = __flex_acl_pbs_del_ports_internal(pbs_entry, params->swid, params->log_ports, params->port_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__flex_acl_pbs_del_ports_internal failed rc = %d \n", rc);
        goto out;
    }

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t __flex_acl_pbs_del_ports_internal(flex_acl_db_pbs_entry_t *pbs_entry,
                                              sx_swid_id_t             swid,
                                              sx_port_id_t            *log_ports,
                                              uint32_t                 port_num)
{
    sx_status_t      rc = SX_STATUS_SUCCESS, rb_rc;
    uint32_t         port_idx, idx;
    boolean_t        found;
    uint16_t         mc_ports_cnt;
    sx_port_id_t    *mc_port_list = NULL, old_port;
    fdb_ext_mc_key_t key;

    SX_LOG_ENTER();

    SX_MEM_CLR(key);

    switch (pbs_entry->entry_type) {
    case SX_ACL_PBS_ENTRY_TYPE_MULTICAST:
    case SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST:
        /* Get current ports list*/
        mc_ports_cnt = 0;
        __flex_acl_pbs_to_mc_key(pbs_entry->pbs_id, pbs_entry->fid, &key);
        rc = fdb_ext_mc_mac_addr_get(swid,
                                     key, &mc_ports_cnt, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to get number of PBS multicast ports pbs_entry [%u]\n",
                pbs_entry->pbs_id);
            return rc;
        }
        rc = utils_clr_memory_get((void**)&mc_port_list, mc_ports_cnt,
                                  sizeof(sx_port_id_t), UTILS_MEM_TYPE_ID_ACL_E);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL PBS add ports : Failed to allocate memory\n");
            rc = SX_STATUS_NO_MEMORY;
            goto out;
        }
        rc = fdb_ext_mc_mac_addr_get(pbs_entry->swid,
                                     key, &mc_ports_cnt, mc_port_list);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL PBS add ports : Failed to get mcast PBS ports\n");
            rc = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
        /* compare given ports to configured ports */
        for (port_idx = 0; port_idx < port_num; port_idx++) {
            found = 0;
            for (idx = 0; idx < mc_ports_cnt; idx++) {
                if (mc_port_list[idx] == log_ports[port_idx]) {
                    found = 1;
                    break;
                }
            }
            if (found == 0) {
                /* one of the ports not found */
                SX_LOG_ERR(
                    "ACL PBS delete ports : port [0x%x] is not a member in PBS entry [%u]\n",
                    log_ports[port_idx], pbs_entry->pbs_id);
                rc = SX_STATUS_ENTRY_NOT_FOUND;
                goto out;
            }
        }
        rc = fdb_ext_mc_mac_addr_set(SX_ACCESS_CMD_DELETE_PORTS,
                                     pbs_entry->swid, key,
                                     port_num, log_ports, &(pbs_entry->pgi),
                                     &(pbs_entry->mid));
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(
                "Failed to delete ports from Multicast PBS [%u,%u] rc [%u]\n",
                pbs_entry->swid, pbs_entry->pbs_id, rc);
            rc = SX_STATUS_ERROR;
            goto out;
        }
        pbs_entry->port_num = pbs_entry->port_num - port_num;
        /* For Spectrum2 we need to add for every MC vport pbs a set FID action.
         * So if we removed all vports we need to update all rules having that pbs
         * not to include the set FID actions. We do that by
         * rewriting the entire action lists of the affected rules.
         */
        if ((g_acl_stage != ACL_STAGE_FLEX) && (pbs_entry->port_num == 0) && pbs_entry->is_vport) {
            pbs_entry->is_vport = FALSE;
            rc = __flex_acl_change_pbs_actions(pbs_entry, FALSE, TRUE);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL failed to rewrite pbs actions for port delete. pbs id:[%u] \n", pbs_entry->pbs_id);
                goto out;
            }
        }
        if ((pbs_entry->port_num == 0) && pbs_entry->is_vport) {
            /* When we're are changing from a vport PBS to empty one,
             * we need to to change the fid in the FDB database to the default.
             * Note: The mid previously allocated will be released and a new one will be used.
             */
            rc = __flex_acl_change_mc_pbs_empty_vport_fid(pbs_entry, pbs_entry->fid, SX_FID_ID_INVALID);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("PBS port delete: Failed to set MID for PBS [%u] rc [%u]\n", pbs_entry->pbs_id, rc);
                goto out;
            }
            pbs_entry->fid = SX_FID_ID_INVALID;
        }
        if (pbs_entry->port_num == 0) {
            pbs_entry->is_vport = FALSE;
        }
        break;

    case SX_ACL_PBS_ENTRY_TYPE_UNICAST:
    case SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST:
        if ((log_ports[0] != pbs_entry->log_port)
            || (pbs_entry->port_num == 0)) {
            SX_LOG_ERR(
                "ACL PBS delete ports : port [0x%x] is not a member in PBS entry [%u]\n",
                log_ports[0], pbs_entry->pbs_id);
            return SX_STATUS_PARAM_ERROR;
        }
        old_port = pbs_entry->log_port;
        pbs_entry->log_port = SX_INVALID_PORT;
        pbs_entry->port_num = 0;
        rc = __flex_acl_change_pbs_actions(pbs_entry, FALSE, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            pbs_entry->port_num = 1;
            pbs_entry->log_port = old_port;
            SX_LOG_ERR("ACL failed to change PBS actions PBS ID:%u \n", pbs_entry->pbs_id);
            goto out;
        }
        rc = flex_acl_hw_config_pbs(pbs_entry, FALSE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Failed to configure PBS entry rc [%u]\n", rc);
            rb_rc = __flex_acl_change_pbs_actions(pbs_entry, TRUE, FALSE);
            if (SX_STATUS_SUCCESS != rb_rc) {
                SX_LOG_ERR("rollback - ACL failed to change PBS actions PBS ID:%u \n", pbs_entry->pbs_id);
            }
            pbs_entry->port_num = 1;
            pbs_entry->log_port = old_port;
            return rc;
        }
        break;

    case SX_ACL_PBS_ENTRY_TYPE_ROUTING:
        SX_LOG_ERR("In ACL PBS delete ports: PBS entry type not supported\n");
        rc = SX_STATUS_UNSUPPORTED;
        break;

    default:
        SX_LOG_ERR("In ACL PBS delete ports: Failed to configure PBS - unknown entry type.\n");
        rc = SX_STATUS_PARAM_ERROR;
        break;
    }

out:
    if (mc_port_list) {
        if (utils_memory_put(mc_port_list, UTILS_MEM_TYPE_ID_ACL_E)
            != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL PBS add ports : Failed to deallocate memory\n");
            if (rc == SX_STATUS_SUCCESS) {
                rc = SX_STATUS_NO_MEMORY;
            }
        }
    }

    SX_LOG_EXIT();

    return rc;
}


sx_status_t flex_acl_pbs_set(sx_api_acl_pbs_set_params_t * params)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sx_swid_type_t swid_type = KU_SWID_TYPE_DISABLED;

    UNUSED_PARAM(params);

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Validate swid */
    if (!flex_acl_db_swid_in_range(params->swid)) {
        SX_LOG_ERR("swid param exceeds range\n");
        sx_status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    sx_status = port_db_swid_type_get(params->swid, &swid_type);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get SWID(%d) type - %s.\n",
                   params->swid, sx_status_str(sx_status));
        goto out;
    }
    if (swid_type != SX_SWID_TYPE_ETHERNET) {
        SX_LOG_ERR(
            "SWID(%d) type is %s not ETH \n",
            params->swid, (swid_type == SX_SWID_TYPE_DISABLED) ? "DISABLED" : "INFINIBAND");
        sx_status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_ADD:
        sx_status = __flex_acl_pbs_add(params);
        break;

    case SX_ACCESS_CMD_ADD_PORTS:
        sx_status = __flex_acl_pbs_add_ports(params);
        break;

    case SX_ACCESS_CMD_DELETE_PORTS:
        sx_status = __flex_acl_pbs_del_ports(params);
        break;

    case SX_ACCESS_CMD_DELETE:
        sx_status = __flex_acl_pbs_del(params);
        break;

    default:
        SX_LOG_ERR("cmd [%u] is not supported for PBS set\n", params->cmd);
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __flex_acl_pbs_get(sx_api_acl_pbs_get_params_t * params)
{
    uint32_t                 idx;
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t *pbs_entry;
    uint16_t                 port_num, max_ports;
    sx_port_id_t            *log_ports = NULL;
    fdb_ext_mc_key_t         key;

    SX_MEM_CLR(key);

    rc = flex_acl_db_pbs_get_entry(params->swid, params->pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Cannot find PBS entry swid %u id %u\n", params->swid, params->pbs_id);
        return rc;
    }

    if (pbs_entry->is_system) {
        SX_LOG_ERR("ACL PBS add ports : PBS [%u,%u] is a system PBS\n",
                   params->swid, params->pbs_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    if (params->port_num == 0) {
        rc = __flex_acl_pbs_count_ports(params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Cannot find PBS entry swid %u id %u\n", params->swid, params->pbs_id);
            return rc;
        }
        params->entry_type = pbs_entry->entry_type;
        return SX_STATUS_SUCCESS;
    }

    max_ports = params->port_num;
    rc = __flex_acl_pbs_count_ports(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Cannot find PBS entry swid %u id %u\n", params->swid, params->pbs_id);
        return rc;
    }
    port_num = params->port_num;
    if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) ||
        (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
        SX_LOG_DBG("Allocating %d log ports entry's \n", port_num);
        rc =
            utils_memory_get((void**)&log_ports, port_num * sizeof(sx_port_id_t), UTILS_MEM_TYPE_ID_ACL_E);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to allocated memory for PBS entry swid %u id %u port_num [%u]\n",
                       params->swid,
                       params->pbs_id,
                       port_num);
            return rc;
        }
        __flex_acl_pbs_to_mc_key(pbs_entry->pbs_id, pbs_entry->fid, &key);
        rc =
            fdb_ext_mc_mac_addr_get(pbs_entry->swid, key,
                                    &port_num,
                                    log_ports);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Cannot find PBS entry MC swid %u id %u\n", pbs_entry->swid, pbs_entry->pbs_id);
            utils_memory_put((void*)log_ports, UTILS_MEM_TYPE_ID_ACL_E);
            return rc;
        }
        /* copy ports from requested index */
        for (idx = 0; idx < max_ports && idx < port_num; idx++) {
            params->log_ports[idx] = log_ports[params->start_at_port++];
        }
        rc = utils_memory_put((void*)log_ports, UTILS_MEM_TYPE_ID_ACL_E);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to release mem for PBS entry swid %u id %u\n", params->swid,
                       params->pbs_id);
            return rc;
        }
    }
    params->entry_type = pbs_entry->entry_type;
    if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_UNICAST) ||
        (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST)) {
        params->log_ports[0] = pbs_entry->log_port;
    }

out:
    return rc;
}

sx_status_t __flex_acl_pbs_count_ports(sx_api_acl_pbs_get_params_t * params)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbs_entry_t *pbs_entry;
    uint16_t                 port_count = 0;

    SX_LOG_ENTER();

    params->port_num = 0;
    rc = flex_acl_db_pbs_get_entry(params->swid, params->pbs_id, &pbs_entry);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Cannot find PBS entry swid %u id %u\n", params->swid, params->pbs_id);
        goto out;
    }

    if (pbs_entry->is_system) {
        SX_LOG_ERR("ACL PBS add ports : PBS [%u,%u] is a system PBS\n",
                   params->swid, params->pbs_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    params->port_num = pbs_entry->port_num;
    params->entry_type = pbs_entry->entry_type;
    if ((pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_MULTICAST) ||
        (pbs_entry->entry_type == SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST)) {
        /* count using multicast entry */
        fdb_ext_mc_key_t key;
        __flex_acl_pbs_to_mc_key(pbs_entry->pbs_id, pbs_entry->fid, &key);
        rc =
            fdb_ext_mc_mac_addr_get(params->swid, key, &port_count,
                                    NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get number of PBS multicast ports pbs_entry [%u]\n", pbs_entry->pbs_id);
            goto out;
        }
        SX_LOG_DBG("MULTICAST port_num:%d PBS id :%u \n", port_count, pbs_entry->pbs_id);
        params->port_num = port_count;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_pbs_get(sx_api_acl_pbs_get_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        return M_UTILS_SX_LOG_EXIT(SX_STATUS_MODULE_UNINITIALIZED);
    }

    if (!flex_acl_db_swid_in_range(params->swid)) {
        SX_LOG_ERR("swid param exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_GET:
        rc = __flex_acl_pbs_get(params);
        break;

    case SX_ACCESS_CMD_COUNT:
        rc = __flex_acl_pbs_count_ports(params);
        break;

    default:
        SX_LOG_ERR("cmd %u is not supported for PBS set\n", params->cmd);
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_validate_pbilm_params(sx_api_acl_pbilm_set_params_t * params)
{
    sx_status_t          rc = SX_STATUS_SUCCESS;
    sx_ecmp_attributes_t ecmp_attributes;


    SX_LOG_ENTER();

    if (params->pbilm_params.action != SX_ROUTER_ACTION_FORWARD) {
        SX_LOG_ERR("Only forward action is allowed for ACL PBILM\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (SX_MPLS_ILM_FORWARD_ACTION_CHECK_RANGE(params->pbilm_params.ilm_fwd_action) != TRUE) {
        SX_LOG_ERR("Illegal ILM forwarding action for ACL PBILM\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (params->pbilm_params.ilm_fwd_action == SX_MPLS_ILM_GOTO_ECMP) {
        rc = sdk_router_ecmp_impl_attributes_get(params->pbilm_params.fwd_actions_params.ecmp_id,
                                                 &ecmp_attributes);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Unknown ecmp id %u for ACL PBILM\n", params->pbilm_params.fwd_actions_params.ecmp_id);
            goto out;
        }
        if (ecmp_attributes.container_type != SX_ECMP_CONTAINER_TYPE_MPLS) {
            SX_LOG_ERR("ecmp id %u is not of type MPLS for ACL PBILM\n",
                       params->pbilm_params.fwd_actions_params.ecmp_id);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_pbilm_create(sx_api_acl_pbilm_set_params_t * params)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbilm_entry_t pbilm_entry;
    boolean_t                 hw_set = FALSE;
    boolean_t                 ecmp_ref_set = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(pbilm_entry);

    rc = __flex_acl_validate_pbilm_params(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Invalid PBILM params.\n");
        goto out;
    }

    if (params->pbilm_params.ilm_fwd_action == SX_MPLS_ILM_GOTO_ECMP) {
        rc = sdk_router_ecmp_impl_external_ref_inc(params->pbilm_params.fwd_actions_params.ecmp_id,
                                                   SX_ECMP_CONTAINER_TYPE_MPLS,
                                                   &(pbilm_entry.ecmp_ref),
                                                   &acl_ecmp_name_data);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL:failed to add ACL reference to ECMP %u \n",
                       params->pbilm_params.fwd_actions_params.ecmp_id);
            goto out;
        }
        ecmp_ref_set = TRUE;
    }

    pbilm_entry.params = params->pbilm_params;
    /* Let the hardware do its thing and return the hw info in the db entry */
    rc = flex_acl_hw_add_pbilm(&pbilm_entry, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed adding PBILM to hw.\n");
        goto out;
    }
    hw_set = TRUE;
    /* Set the entry in the database and get the ID */
    rc = flex_acl_db_pbilm_set_entry(&pbilm_entry, &(params->pbilm_id));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed adding PBILM to database.\n");
        goto out;
    }

out:
    if (rc != SX_STATUS_SUCCESS) {
        if (hw_set) {
            if (flex_acl_hw_del_pbilm(&pbilm_entry, TRUE) != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed rollback PBILM from hw.\n");
            }
        }
        if (ecmp_ref_set) {
            if (sdk_router_ecmp_impl_external_ref_dec(params->pbilm_params.fwd_actions_params.ecmp_id,
                                                      &(pbilm_entry.ecmp_ref), NULL) != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed rollback PBILM ecmp reference.\n");
            }
        }
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_pbilm_set(sx_api_acl_pbilm_set_params_t * params)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbilm_entry_t               *db_pbilm_entry;
    flex_acl_db_pbilm_entry_t                old_pbilm_entry;
    flex_acl_db_pbilm_entry_t                new_pbilm_entry;
    boolean_t                                new_ecmp_ref_set = FALSE;
    flex_acl_hw_ecmp_container_change_data_t container_change_data;

    SX_LOG_ENTER();

    SX_MEM_CLR(new_pbilm_entry);
    SX_MEM_CLR(container_change_data);

    rc = __flex_acl_validate_pbilm_params(params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Invalid PBILM params.\n");
        goto out;
    }

    rc = flex_acl_db_pbilm_get_entry(params->pbilm_id, &db_pbilm_entry);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to find PBILM id %u entry in Db.\n", params->pbilm_id);
        goto out;
    }

    /* Preserve the old values of the pbilm db entry */
    old_pbilm_entry = *db_pbilm_entry;

    /* Mimic the entry of the database and go and write to the hw.
     * the same kvd PPBMI entry will be used here.
     * Preserve all parameters that won't be changed by the hw */
    new_pbilm_entry = *db_pbilm_entry;
    new_pbilm_entry.params = params->pbilm_params;

    if (params->pbilm_params.ilm_fwd_action == SX_MPLS_ILM_GOTO_ECMP) {
        rc = sdk_router_ecmp_impl_external_ref_inc(params->pbilm_params.fwd_actions_params.ecmp_id,
                                                   SX_ECMP_CONTAINER_TYPE_MPLS,
                                                   &(new_pbilm_entry.ecmp_ref),
                                                   &acl_ecmp_name_data);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL:failed to add ACL reference to ECMP %u \n",
                       params->pbilm_params.fwd_actions_params.ecmp_id);
            goto out;
        }
        new_ecmp_ref_set = TRUE;
    }
    /* Let the hardware do its thing and return the hw info in the db entry */
    rc = flex_acl_hw_add_pbilm(&new_pbilm_entry, FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed adding PBILM to hw.\n");
        goto out;
    }

    /* Now that the hw operation succeeded we update the database entry */
    *db_pbilm_entry = new_pbilm_entry;
    /* NOTE: The following actions are assumed to be successful. No rollback will be performed. */
    new_ecmp_ref_set = FALSE;

    /* if the ecmp size has changed from/to zero we need to updated all related rules */
    if (((old_pbilm_entry.nhlfe_size == 0) && (new_pbilm_entry.nhlfe_size != 0)) ||
        ((old_pbilm_entry.nhlfe_size != 0) && (new_pbilm_entry.nhlfe_size == 0))) {
        container_change_data.new_ecmp_size = (new_pbilm_entry.nhlfe_size > 0) ? 1 : 0;
        container_change_data.old_ecmp_size = (old_pbilm_entry.nhlfe_size > 0) ? 1 : 0;
        rc = flex_acl_hw_pbilm_update_nhfle_related_rules(params->pbilm_id, &container_change_data);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed updating rules related to PBILM id %u.\n", params->pbilm_id);
            goto out;
        }
    }

    /* Now it's time to release the old entry. Note that the kvdl won't be updated or released
     * since it's used for the new entry already*/
    rc = flex_acl_hw_del_pbilm(&old_pbilm_entry, FALSE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed removing PBILM id %u from HW.\n", params->pbilm_id);
        goto out;
    }

    /* Remove reference from the ecmp if it's relevant */
    if (old_pbilm_entry.params.ilm_fwd_action == SX_MPLS_ILM_GOTO_ECMP) {
        rc = sdk_router_ecmp_impl_external_ref_dec(old_pbilm_entry.params.fwd_actions_params.ecmp_id,
                                                   &(old_pbilm_entry.ecmp_ref), NULL);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed removing PBILM id %u from HW.\n", params->pbilm_id);
            goto out;
        }
    }

out:
    if (SX_CHECK_FAIL(rc)) {
        if (new_ecmp_ref_set) {
            sdk_router_ecmp_impl_external_ref_dec(params->pbilm_params.fwd_actions_params.ecmp_id,
                                                  &(new_pbilm_entry.ecmp_ref), NULL);
        }
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_pbilm_destroy(sx_api_acl_pbilm_set_params_t * params)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbilm_entry_t *pbilm_entry;

    SX_LOG_ENTER();

    rc = flex_acl_db_pbilm_get_entry(params->pbilm_id, &pbilm_entry);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to find PBILM id %u entry in Db.\n", params->pbilm_id);
        goto out;
    }

    if (pbilm_entry->rules_ref_cnt > 0) {
        SX_LOG_ERR("PBILM id %u is referenced by %u rules and cannot be deleted.\n",
                   params->pbilm_id, pbilm_entry->rules_ref_cnt);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* Remove reference from the ecmp if it's relevant */
    if (pbilm_entry->params.ilm_fwd_action == SX_MPLS_ILM_GOTO_ECMP) {
        rc = sdk_router_ecmp_impl_external_ref_dec(pbilm_entry->params.fwd_actions_params.ecmp_id,
                                                   &(pbilm_entry->ecmp_ref), NULL);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed removing PBILM id %u from HW.\n", params->pbilm_id);
            goto out;
        }
    }

    /* NOTE: If removing from hw failed we continue with the flow since this
     *       is not a reversible operation */
    rc = flex_acl_hw_del_pbilm(pbilm_entry, TRUE);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed removing PBILM id %u from HW.\n", params->pbilm_id);
    }

    rc = flex_acl_db_pbilm_delete_entry(params->pbilm_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed removing PBILM id %u from database.\n", params->pbilm_id);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_pbilm_set(sx_api_acl_pbilm_set_params_t * params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        rc = __flex_acl_pbilm_create(params);
        break;

    case SX_ACCESS_CMD_SET:
        rc = __flex_acl_pbilm_set(params);
        break;

    case SX_ACCESS_CMD_DESTROY:
        rc = __flex_acl_pbilm_destroy(params);
        break;

    default:
        SX_LOG_ERR("cmd [%u] is not supported for PBILM set\n", params->cmd);
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_pbilm_get(sx_api_acl_pbilm_get_params_t * params)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_db_pbilm_entry_t *pbilm_entry = NULL;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_pbilm_get_entry(params->pbilm_id, &pbilm_entry);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to find PBILM id %u entry in Db.\n", params->pbilm_id);
        goto out;
    }

    params->pbilm_params = pbilm_entry->params;
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t rc = utils_check_dbg_params(dbg_dump_params_p);

    if (!SX_CHECK_FAIL(rc)) {
        dbg_utils_pprinter_general_header_print(dbg_dump_params_p->stream, "ACL DB Dump");
    }

    return rc;
}

static sx_status_t __dump_module_flex_acl_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = flex_acl_debug_dump(dbg_dump_params_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("dbg_dump failed to generate ACL module dump.\n");
    }

    return err;
}

static sx_status_t __dump_module_flex_acl_main_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    FILE       *stream = dbg_dump_params_p->stream;

    SX_LOG_ENTER();
    if (!g_flex_acl_initialized) {
        dbg_utils_pprinter_module_header_print(stream, "Flex ACL");
        dbg_utils_pprinter_field_print(stream, "Modules are not initialized", &g_flex_acl_initialized, PARAM_BOOL_E);
        return rc;
    }

    dbg_utils_pprinter_module_header_print(stream, "Flex ACL");
    dbg_utils_pprinter_field_print(stream,
                                   "Flex acl module are initialized",
                                   &g_flex_acl_initialized,
                                   PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "Modules are initialized", &g_init_flags.basic_keys_inited,
                                   PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "Synchronized with adviser", &g_init_flags.lag_sinc_advised,
                                   PARAM_BOOL_E);

    return rc;
}

static sx_status_t __dump_module_flex_acl_db_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (!g_flex_acl_initialized) {
        return err;
    }

    flex_acl_db_debug_dump(dbg_dump_params_p);

    return err;
}

static sx_status_t __dump_module_flex_acl_rbb_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (!g_flex_acl_initialized) {
        return err;
    }

    flex_acl_rule_based_binding_debug_dump(dbg_dump_params_p);

    return err;
}

static sx_status_t __dump_module_flex_acl_hw_db_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (!g_flex_acl_initialized) {
        return err;
    }

    flex_acl_hw_db_debug_dump(dbg_dump_params_p);

    return err;
}

static sx_status_t __dump_module_flex_acl_system_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (!g_flex_acl_initialized) {
        return err;
    }

    system_acl_dump(dbg_dump_params_p);


    return err;
}

static sx_status_t flex_acl_debug_dump_self(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    FILE       *stream = dbg_dump_params_p->stream;

    SX_LOG_ENTER();
    if (!g_flex_acl_initialized) {
        dbg_utils_pprinter_module_header_print(stream, "Flex ACL");
        dbg_utils_pprinter_field_print(stream, "Modules are not initialized", &g_flex_acl_initialized, PARAM_BOOL_E);
        return rc;
    }

    dbg_utils_pprinter_module_header_print(stream, "Flex ACL");
    dbg_utils_pprinter_field_print(stream,
                                   "Flex acl module are initialized",
                                   &g_flex_acl_initialized,
                                   PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "Modules are initialized", &g_init_flags.basic_keys_inited,
                                   PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "Synchronized with adviser", &g_init_flags.lag_sinc_advised,
                                   PARAM_BOOL_E);

    flex_acl_db_debug_dump(dbg_dump_params_p);
    flex_acl_rule_based_binding_debug_dump(dbg_dump_params_p);
    flex_acl_hw_db_debug_dump(dbg_dump_params_p);
    system_acl_dump(dbg_dump_params_p);

    return rc;
}

void sx_fuse_flex_acl_debug_dump_self(dbg_dump_params_t *dbg_dump_params_p)
{
    flex_acl_debug_dump_self(dbg_dump_params_p);
    return;
}

sx_status_t flex_acl_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        goto out;
    }

    sx_status = flex_acl_debug_dump_self(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
    return sx_status;
}

boolean_t flex_acl_is_extended_action(void)
{
    return FLEX_ACL_IS_EXTENDED_ACTION;
}

span_client_handle_t flex_acl_get_span_user_handle(void)
{
    return acl_span_handle;
}

sx_status_t __flex_acl_delete_all_rules_from_region(sx_acl_region_id_t region_id)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t  *region = NULL;
    uint32_t                   i = 0;
    uint32_t                   valid_i = 0;
    sx_flex_acl_rule_offset_t *offsets_list_p = NULL;
    flex_acl_db_flex_rule_t   *rule = NULL, help_rule;

    SX_LOG_ENTER();
    rc = flex_acl_db_region_get(region_id, &region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("get region error\n");
        goto out;
    }

    if (region->rules == NULL) {
        /* No rules to delete */
        goto out;
    }

    offsets_list_p = (sx_flex_acl_rule_offset_t*)cl_malloc(
        sizeof(sx_flex_acl_rule_offset_t) * region->valid_rules_num);
    if (!offsets_list_p) {
        SX_LOG_ERR("Failed allocating memory for offset list.\n");
        goto out;
    }
    for (i = 0; i < region->size - region->reserved_rules_num; i++) {
        if (region->rules[i].valid == FLEX_ACL_RULE_INVALID) {
            continue;
        }
        offsets_list_p[valid_i] = region->rules[i].offset;
        valid_i++;
        rc = flex_acl_db_get_rule_by_offset(region->region_id, region->rules[i].offset, &rule);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get rule from db for offset [%u]\n", region->rules[i].offset);
            goto out;
        }

        /* Temporarily set the rule as invalid so to delete it from hw */
        help_rule = *rule;
        help_rule.valid = FLEX_ACL_RULE_INVALID;
        /* Remove the rule from the hw */
        rc = __flex_acl_update_rules_to_devs(region,
                                             &help_rule,
                                             1,
                                             FLEX_ACL_HW_FULL_WRITE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to write rules to dev \n");
            goto out;
        }

        SX_LOG_DBG("Region:%u Delete unbind rule:%d \n", region->region_id, region->rules[i].offset);
        rc = __flex_acl_delete_rule_refs(region_id, rule);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL:  failed to delete refs for delete all rules. region:%d offset :%d\n",
                       rule->region_id,
                       rule->offset);
            goto out;
        }
    }

    rc = flex_acl_db_invalidate_rules(region_id, offsets_list_p, valid_i);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to invalidate rules in region ID [%u]\n", region_id);
        goto out;
    }

    rc = flex_acl_rm_entries_set(0, valid_i,  region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to invalidate rules in region ID [%u]\n", region_id);
        goto out;
    }

out:
    if (offsets_list_p) {
        cl_free(offsets_list_p);
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_pbs_get_mcast_ports(sx_swid_t       swid,
                                         sx_acl_pbs_id_t pbs_id,
                                         sx_fid_t        fid,
                                         uint16_t       *port_cnt,
                                         sx_port_id_t   *port_list)
{
    sx_status_t      rc = SX_STATUS_SUCCESS;
    fdb_ext_mc_key_t key;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    __flex_acl_pbs_to_mc_key(pbs_id, fid, &key);
    rc = fdb_ext_mc_mac_addr_get(swid, key, port_cnt, port_list);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Cannot find PBS entry MC swid %u id %u\n", swid, pbs_id);
        goto out;
    }

out:
    SX_LOG_EXIT();

    return rc;
}

sx_status_t flex_acl_set_region_entry_type(sx_acl_region_id_t region_id, flex_acl_entry_type_e entry_type)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_db_region_entry_type_set(region_id, entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed set entry type to region[%u]\n", region_id);
    }

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_set_acl_entry_type(sx_acl_id_t acl_id, flex_acl_entry_type_e entry_type)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (flex_acl_db_is_acl_group(acl_id)) {
        rc = flex_acl_db_group_entry_type_set(acl_id, entry_type);
    } else {
        rc = flex_acl_db_acl_entry_type_set(acl_id, entry_type);
    }
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed set entry type to acl id[%u]\n", acl_id);
    }

    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_rebind_user_group(flex_acl_db_acl_group_t *acl_group, void *param_p)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_acl_direction_t direction = (sx_acl_direction_t)(param_p);

    if (acl_group->direction == direction) {
        if ((acl_group->entry_type == FLEX_ACL_ENTRY_TYPE_USER_E) &&
            (acl_group->bind_attribs_id != FLEX_ACL_INVALID_BIND_ATTRIBS_ID)) {
            /* trigger group update flow with same acls in group - the group will be rewritten with or without system acls*/
            rc = __flex_acl_group_edit(acl_group->group_id,
                                       acl_group->acl_ids,
                                       acl_group->acl_num);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "Failed to edit group[%u] at system acl add/delete\n", acl_group->group_id);
            }
        }
    }
    return rc;
}

/* the function triggers edit flow for each bound group, the flow adds/removes system acl from
 * current hw configuration
 */
sx_status_t flex_acl_update_all_groups_with_system_acl(sx_acl_direction_t direction)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = flex_acl_db_group_bind_foreach(__flex_acl_rebind_user_group, (void*)direction);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fail in for each function, rc = %s\n", sx_status_str(rc));
    }

    return SX_STATUS_SUCCESS;
}

/* this function triggers edit flow for each group that contains the specified ACL
 */
sx_status_t flex_acl_updated_acl_groups(sx_acl_id_t acl_id)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    const cl_list_t         *groups_list = NULL;
    cl_list_iterator_t       list_iter = NULL;
    cl_list_iterator_t       list_end = NULL;
    sx_acl_id_t             *group_id_get = NULL;
    flex_acl_db_acl_group_t *acl_group = NULL;

    /* Get the list of groups using this ACL */
    rc = flex_acl_db_acl_get_group_list(acl_id, &groups_list);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Get acl groups failed for update acl groups, acl_id: %u\n", acl_id);
        goto out;
    }

    list_end = cl_list_end(groups_list);
    list_iter = cl_list_head(groups_list);
    while (list_iter != list_end) {
        group_id_get = cl_list_obj(list_iter);

        rc = flex_acl_db_get_acl_group(*group_id_get, &acl_group);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Get group failed for update acl groups, group_id: %u\n", *group_id_get);
            goto out;
        }

        /* trigger group update flow with same acls in group - the group will be rewritten with or without system acls*/
        rc = __flex_acl_group_edit(acl_group->group_id,
                                   acl_group->acl_ids,
                                   acl_group->acl_num);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to edit group[%u] for update acl groups\n", acl_group->group_id);
            goto out;
        }

        list_iter = cl_list_next(list_iter);
    }

out:
    return rc;
}

static sx_status_t __flex_acl_rif_destroy_adviser_cb(adviser_event_e event_type, void *param)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_router_interface_t *rif_id_p = (sx_router_interface_t*)param;

    SX_LOG_ENTER();
    UNUSED_PARAM(event_type);

    /* Notify the rule based binding that the port was deleted */
    rc = flex_acl_rule_based_binding_rif_delete_update(*rif_id_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to clear rif rule based binding [%u] , error: %s\n", *rif_id_p, sx_status_str(rc));
    }

    rc = flex_acl_clear_rif_binding(*rif_id_p, TRUE);

    SX_LOG_EXIT();
    return rc;
}

/* the function binds rif to existing system group, one per direction */
static sx_status_t __flex_acl_rif_create_adviser_cb(adviser_event_e event_type, void *param)
{
    sx_status_t            rc = SX_STATUS_SUCCESS;
    sx_router_interface_t *rif_id_p = (sx_router_interface_t*)param;
    sx_acl_direction_t     direction = SX_ACL_DIRECTION_RIF_INGRESS;
    sx_acl_id_t            group_id = FLEX_ACL_INVALID_ACL_ID;
    boolean_t              is_decap_rif = FALSE;

    SX_LOG_ENTER();
    UNUSED_PARAM(event_type);

    for (direction = SX_ACL_DIRECTION_RIF_INGRESS; direction <= SX_ACL_DIRECTION_RIF_EGRESS; direction++) {
        rc = flex_acl_db_get_system_acl_group(direction, &group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get client id for rif[%u] bind, rc = %s\n", *rif_id_p, sx_status_str(rc));
            goto out;
        }
        if (group_id == FLEX_ACL_INVALID_ACL_ID) {
            continue;
        }

        /* [DECAP_SYSTEM_ACL] Workaround :
         *  Please read the commit message for this change first.
         *
         *  The code below assumes that only system ACLs that can be bound to RIFs in
         *  the ingress direction are decap system ACLs.
         *
         *  Therefore it check whether a new RIF is a decap RIF.
         *  The new RIF can be decap one if it's created on top of decap VRF.
         *
         *  If the new RIF is not decap RIF, SDK doesn't bind decap system ACLs to it.
         */
        if (direction == SX_ACL_DIRECTION_RIF_INGRESS) {
            rc = sdk_rif_impl_decap_check(*rif_id_p, &is_decap_rif);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to check if a new RIF[%u] is a decap RIF, rc = %s\n",
                           *rif_id_p,
                           sx_status_str(rc));
                goto out;
            }

            if (is_decap_rif == FALSE) {
                continue;
            }
        }

        rc = flex_acl_rif_bind_internal(*rif_id_p,
                                        group_id,
                                        TRUE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to bind RIF [%u] to group_id[%u], rc = %s\n",
                       *rif_id_p, group_id, sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_acl_vport_bridge_delete_cb(adviser_event_e event_type, void *param)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    vport_bridge_cb_t       *vport_bridge_cb;
    flex_acl_db_pbs_entry_t *pbs_entry = NULL;

    UNUSED_PARAM(event_type);

    SX_LOG_ENTER();

    vport_bridge_cb = (vport_bridge_cb_t*)param;

    rc = flex_acl_db_pbs_by_log_port(vport_bridge_cb->log_port, &pbs_entry);
    switch (rc) {
    case SX_STATUS_SUCCESS:
        SX_LOG_ERR("port 0x%X is in pbs %d - failing\n", vport_bridge_cb->log_port, pbs_entry->pbs_id);
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;

    case SX_STATUS_ENTRY_NOT_FOUND:
        rc = SX_STATUS_SUCCESS;
        goto out;

    default:
        break;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_write_region_offset_rule(sx_acl_region_id_t region_id, sx_acl_rule_offset_t offset)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_flex_rule_t  *rule_p = NULL;
    flex_acl_db_acl_region_t *acl_region_p = NULL;
    sx_dev_id_t               devs_list[SX_DEV_NUM_MAX];
    uint16_t                  dev_info_arr_size = 0;
    uint32_t                  dev_idx = 0;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_rule_by_offset(region_id, offset, &rule_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get rule from db for offset [%u]\n", offset);
        goto out;
    }
    if ((rule_p->valid == FLEX_ACL_RULE_INVALID) && (rule_p->valid == FLEX_ACL_RULE_INVALID)) {
        /* Nothing to do with rule. */
        goto out;
    }

    SX_MEM_CLR(devs_list);
    rc = flex_acl_hw_get_all_devs_list(devs_list, &dev_info_arr_size);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at get devices list\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to find ACL region id [%u]\n", region_id);
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    {
        rc = flex_acl_hw_write_only_rule(rule_p,
                                         acl_region_p,
                                         devs_list[dev_idx],
                                         FALSE,
                                         FLEX_ACL_HW_FULL_WRITE,
                                         TRUE);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to configure rule offset %u to dev \n", rule_p->offset);
            goto out;
        }
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_port_exists_in_container(sx_mc_container_id_t container_id,
                                              sx_port_id_t         log_port,
                                              boolean_t           *is_exist)
{
    sx_mc_next_hop_t        * next_hops = NULL;
    uint32_t                  next_hop_count, i;
    mc_container_owner_type_t container_owner_type;
    sx_status_t               rc;

    SX_LOG_ENTER();
    rc = sdk_mc_container_impl_get(container_id,
                                   NULL,
                                   &next_hop_count,
                                   NULL,
                                   &container_owner_type);

    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve MC container, container id :%u rc=[%s]\n", container_id, sx_status_str(rc));
        goto out;
    }

    if (container_owner_type != MC_CONTAINER_OWNER_TYPE_EXTERNAL) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Container %u is an internal container\n", container_id);
        goto out;
    }

    next_hops = cl_calloc(next_hop_count, sizeof(sx_mc_next_hop_t));
    if (next_hops == NULL) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("No memory for MC container %u next hops\n", container_id);
        goto out;
    }
    rc = sdk_mc_container_impl_get(container_id,
                                   next_hops,
                                   &next_hop_count,
                                   NULL,
                                   NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to retrieve MC container, container id :%u rc=[%s]\n", container_id, sx_status_str(rc));
        goto out;
    }

    *is_exist = FALSE;
    for (i = 0; i < next_hop_count && *is_exist == FALSE; i++) {
        if (next_hops[i].data.log_port == log_port) {
            *is_exist = TRUE;
        }
    }

out:
    if (next_hops != NULL) {
        cl_free(next_hops);
    }
    SX_LOG_EXIT();

    return rc;
}


static sx_status_t __flex_acl_custom_bytes_set_update(sx_api_custom_bytes_set_params_t *params)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    flex_acl_extraction_point_t extraction_points[ACL_MAX_EXTRACTION_POINTS_IN_GROUP];
    uint32_t                    extraction_points_count, i;
    acl_custom_bytes_set_id_e   custom_bytes_set_id = ACL_CUSTOM_BYTES_SET_LAST;

    SX_LOG_ENTER();

    SX_MEM_CLR(extraction_points);

    /* Parsing and validation of extraction point -conversion to DB simple structure */
    rc = flex_acl_db_custom_bytes_create_extraction_points(&(params->custom_bytes_set_attributes),
                                                           extraction_points,
                                                           &extraction_points_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Parsing and validation of extraction point failed.\n");
        goto out;
    }

    if (extraction_points_count == 0) {
        SX_LOG_ERR("No extractions points were provided.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    for (i = 0; i < extraction_points_count; i++) {
        if (extraction_points[i].offset > rm_resource_global.acl_custom_bytes_extraction_point_offset_max) {
            SX_LOG_ERR("Offset of extraction point :%u is to big offset:%u max offset:%u\n",
                       extraction_points[i].extraction_point,
                       extraction_points[i].offset,
                       rm_resource_global.acl_custom_bytes_extraction_point_offset_max);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (extraction_points[i].offset % 2 != 0) {
            SX_LOG_ERR("Offset of extraction point must be even. Extraction point code:%u offset:%u\n",
                       extraction_points[i].extraction_point,
                       extraction_points[i].offset);
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
        if (is_flex_acl_key_custom_byte_key(params->custom_bytes_set_key_id_p[0])) {
            /* Custom byte set is identified */
            rc = flex_acl_key_id_to_custom_byte_set(params->custom_bytes_set_key_id_p[0], &custom_bytes_set_id);
            if ((rc != SX_STATUS_SUCCESS) && (rc != SX_STATUS_ENTRY_NOT_FOUND)) {
                SX_LOG_ERR("Failed getting CUSTOM_BYTE_SET for key:%d \n", params->custom_bytes_set_key_id_p[0]);
                goto out;
            }

            /* If the custom bytes set corresponding to the specified key is not available due to the bank switching caused
             * by ISSU, then we try to allocate a custom bytes set according to current bank.
             */
            if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
                custom_bytes_set_id = ACL_CUSTOM_BYTES_SET_LAST;
            }
        }

        rc = flex_acl_db_custom_bytes_set_create(
            params->custom_bytes_set_attributes.extraction_point.extraction_group_type,
            extraction_points_count,
            extraction_points,
            &custom_bytes_set_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("flex_acl_db_custom_bytes_set_create failed.\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        rc = flex_acl_key_id_to_custom_byte_set(params->custom_bytes_set_key_id_p[0], &custom_bytes_set_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed getting CUSTOM_BYTE_SET for key:%d \n", params->custom_bytes_set_key_id_p[0]);
            goto out;
        }
        rc = flex_acl_db_custom_bytes_set_edit(
            custom_bytes_set_id,
            params->custom_bytes_set_attributes.extraction_point.extraction_group_type,
            extraction_points_count,
            extraction_points);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("flex_acl_db_custom_bytes_set_edit failed, set:%u.\n", custom_bytes_set_id);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Invalid command :%u \n", params->cmd);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_hw_handle_custom_bytes_register(custom_bytes_set_id,
                                                  extraction_points,
                                                  extraction_points_count, TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Writing custom bytes register failed.\n");
        flex_acl_db_custom_bytes_set_delete(custom_bytes_set_id);
        goto out;
    }

    if (params->cmd == SX_ACCESS_CMD_CREATE) {
        params->custom_bytes_set_key_id_count =
            MIN(params->custom_bytes_set_key_id_count, custom_bytes_set_data[custom_bytes_set_id].size);
        for (i = 0; i < params->custom_bytes_set_key_id_count; i++) {
            params->custom_bytes_set_key_id_p[i] =
                custom_bytes_set_data[custom_bytes_set_id].start_key_id +
                custom_bytes_set_data[custom_bytes_set_id].size - 1 - i;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_key_id_to_custom_byte_set(sx_acl_key_t               custom_bytes_key_id,
                                               acl_custom_bytes_set_id_e *custom_bytes_set_id)
{
    uint32_t    i;
    boolean_t   found = FALSE;
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    start = 0;
    uint32_t    step = 1;

    SX_LOG_ENTER();

    rc = flex_acl_db_get_iteration_start_and_step(&start, &step);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG_ERR("flex_acl_db_get_iteration_start_and_step failed, err [%s]\n", sx_status_str(rc));
        goto out;
    }

    for (i = start; i < rm_resource_global.acl_custom_bytes_set_max && !found; i = i + step) {
        if ((custom_bytes_set_data[i].start_key_id == custom_bytes_key_id) ||
            ((custom_bytes_key_id > custom_bytes_set_data[i].start_key_id) &&
             (custom_bytes_key_id - custom_bytes_set_data[i].start_key_id < custom_bytes_set_data[i].size))) {
            *custom_bytes_set_id = i;
            found = TRUE;
        }
    }
    if (!found) {
        rc = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Custom bytes key id :%d is not associated with custom bytes set.\n", custom_bytes_key_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_custom_bytes_set_delete(sx_acl_key_t custom_bytes_set_key_id)
{
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    acl_custom_bytes_set_id_e            custom_bytes_set_id;
    sx_acl_custom_bytes_set_attributes_t custom_bytes_set_attributes;

    SX_LOG_ENTER();

    rc = flex_acl_key_id_to_custom_byte_set(custom_bytes_set_key_id, &custom_bytes_set_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed getting CUSTOM_BYTE_SET for key:%d \n", custom_bytes_set_key_id);
        goto out;
    }
    rc = flex_acl_db_custom_bytes_set_get(custom_bytes_set_id, &custom_bytes_set_attributes);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed flex_acl_db_custom_bytes_set_get for key:%d \n", custom_bytes_set_key_id);
        goto out;
    }

    rc = flex_acl_hw_handle_custom_bytes_register(custom_bytes_set_id,
                                                  (flex_acl_extraction_point_t*)&custom_bytes_set_attributes.extraction_point.params,
                                                  custom_bytes_set_attributes.extraction_points_count,
                                                  FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed flex_acl_hw_handle_custom_bytes_register for key:%d \n", custom_bytes_set_key_id);
        goto out;
    }

    rc = flex_acl_db_custom_bytes_set_delete(custom_bytes_set_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed flex_acl_db_custom_bytes_set_delete for key:%d \n", custom_bytes_set_key_id);
        goto out;
    }


out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_custom_bytes_set(sx_api_custom_bytes_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    rc = sdk_register_mode_test_and_set(REGISTER_MODE_CUTSOM_BYTES_E);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set custom bytes set: sx_api_register_set() already called.\n");
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_CREATE:
    case SX_ACCESS_CMD_EDIT:
        rc = __flex_acl_custom_bytes_set_update(params);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to update customer bytes set\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        rc = __flex_acl_custom_bytes_set_delete(params->custom_bytes_set_key_id_p[0]);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to destroy custom bytes set [%u]. rc=[%s]\n",
                       params->custom_bytes_set_key_id_p[0],
                       sx_status_str(rc));
            goto out;
        }
        break;

    default:
        /* cmd not supported */
        SX_LOG_ERR("custom byte cmd: [%s] unsupported.\n", sx_access_cmd_str(params->cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        break;
    }
out:

    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_custom_bytes_get(sx_api_custom_bytes_set_params_t *params)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    acl_custom_bytes_set_id_e custom_bytes_set_id;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    rc = flex_acl_key_id_to_custom_byte_set(params->custom_bytes_set_key_id_p[0], &custom_bytes_set_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed getting CUSTOM_BYTE_SET for key:%d \n", params->custom_bytes_set_key_id_p[0]);
        goto out;
    }

    rc = flex_acl_db_custom_bytes_set_get(custom_bytes_set_id, &(params->custom_bytes_set_attributes));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed flex_acl_db_custom_bytes_set_get for custom byte:%u \n", custom_bytes_set_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_rules_priority_set(sx_api_acl_flex_rules_priority_set_params_t *params)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t   *acl_region = NULL;
    uint32_t                    i = 0;
    sx_flex_acl_rule_priority_t max_limit = 0, min_limit = FLEX_ACL_RULE_PRIORITY_MAX + 1;
    sx_flex_acl_rule_priority_t prio_upper_limit = 0, prio_lower_limit = 0;
    int64_t                     max_prio_bound, min_prio_bound;

    SX_LOG_ENTER();

    if (g_flex_acl_initialized == FALSE) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (g_acl_stage == ACL_STAGE_FLEX) {
        SX_LOG(SX_LOG_ERROR, "The bulk priorities change is not supported in this chip type.\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    /* checks if Region ID is legal */
    if (FLEX_ACL_REGION_BIT_CHECK(params->region_id)) {
        SX_LOG_ERR("ACL: Region ID is not valid, region_id[%#x].\n", params->region_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_db_region_get(params->region_id, &acl_region);
    if (SX_STATUS_SUCCESS != rc) {
        SX_LOG(SX_LOG_ERROR,
               "In flex_acl_rules_priority_set. ACL : Region get error, region_id[%#x] \n",
               params->region_id);
        goto out;
    }

    /* The function is supported only in prio mode */
    if (acl_region->rules_priority_mode == FLEX_RULES_PRIORITY_MODE_UNSET) {
        goto out;
    } else if (acl_region->rules_priority_mode == FLEX_RULES_PRIORITY_MODE_LEGACY) {
        SX_LOG(SX_LOG_ERROR, "The bulk priorities change is not supported in legacy mode.\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (params->min_priority > params->max_priority) {
        SX_LOG(SX_LOG_ERROR, "Min priority is bigger than max priority\n");
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    max_prio_bound = (int64_t)params->max_priority + (int64_t)params->priority_change;
    min_prio_bound = (int64_t)params->min_priority + (int64_t)params->priority_change;

    if ((max_prio_bound > FLEX_ACL_RULE_PRIORITY_MAX) || (min_prio_bound < FLEX_ACL_RULE_PRIORITY_MIN)) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed flex_acl_rules_priority_set - priority is invalid, err [%s]\n", sx_status_str(rc));
        goto out;
    }

    /*Limitation verification:
     * The priority can be changed only if there is no other rules between min priority + change  to
     * max priority + change (and the opposite if the priority_change < 0 )*/

    for (i = 0; i < acl_region->size; i++) {
        if ((acl_region->rules[i].priority <= params->max_priority) &&
            (acl_region->rules[i].priority >= params->min_priority)) {
            if (acl_region->rules[i].priority > max_limit) {
                max_limit = acl_region->rules[i].priority;
            }
            if (acl_region->rules[i].priority < min_limit) {
                min_limit = acl_region->rules[i].priority;
            }
        }
    }

    /* If MAX limit=0 so we didn't find a matching rule in range [min_priority,max_priority] */
    if (max_limit == 0) {
        goto out;
    }

    max_limit = max_limit + params->priority_change;
    min_limit = min_limit + params->priority_change;

    if (params->priority_change > 0) {
        prio_lower_limit = params->max_priority + 1;
        prio_upper_limit = max_limit;
    } else {
        prio_lower_limit = min_limit;
        prio_upper_limit = params->min_priority - 1;
    }

    for (i = 0; i < acl_region->size; i++) {
        if ((acl_region->rules[i].priority <= prio_upper_limit) &&
            (acl_region->rules[i].priority >= prio_lower_limit)) {
            rc = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Failed flex_acl_rules_priority_set - The priority can be changed "
                       "only if there is no other rules between min priority + change to rule priority + change"
                       "(and the opposite if the priority_change < 0 ), err [%s]\n",
                       sx_status_str(rc));
            goto out;
        }
    }

    rc = flex_acl_db_rules_priority_set(params->region_id,
                                        params->min_priority,
                                        params->max_priority,
                                        params->priority_change);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed flex_acl_db_rules_priority_set, err [%s]\n", sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_hw_rule_prio_update(acl_region->region_id,
                                      params->min_priority,
                                      params->max_priority,
                                      params->priority_change);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("flex_acl_hw_prio_update failed, err [%s]\n", sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_validate_pbs_lag(flex_acl_db_pbs_entry_t *pbs_entry, void *param_p)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_port_log_id_t *log_ports = cl_malloc(
        sizeof(sx_port_log_id_t) * rm_resource_global.port_ext_num_max);
    uint16_t                            num_ports = 0;
    uint32_t                            i;
    boolean_t                           is_log_port_found = FALSE;
    flex_acl_validate_pbs_lag_params_t *validate_pbs_lag_params;


    SX_LOG_ENTER();

    validate_pbs_lag_params = (flex_acl_validate_pbs_lag_params_t*)(param_p);

    switch (pbs_entry->entry_type) {
    case SX_ACL_PBS_ENTRY_TYPE_MULTICAST:
    case SX_ACL_PBS_ENTRY_TYPE_OUTPUT_MULTICAST:
        if (pbs_entry->is_system) {
            rc = flex_acl_port_exists_in_container(pbs_entry->container_id,
                                                   validate_pbs_lag_params->log_port,
                                                   &is_log_port_found);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("flex_acl_port_exists_in_container failed for pbs %d rc=[%s]\n", pbs_entry->pbs_id,
                           sx_status_str(rc));
                goto out;
            }
        } else {
            num_ports = (uint16_t)rm_resource_global.port_ext_num_max;
            rc =
                flex_acl_pbs_get_mcast_ports(pbs_entry->swid, pbs_entry->pbs_id, pbs_entry->fid, &num_ports,
                                             log_ports);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__flex_acl_pbs_get_mcast_ports failed for pbs %d rc=[%s]\n", pbs_entry->pbs_id,
                           sx_status_str(rc));
                goto out;
            }
            for (i = 0; i < num_ports; i++) {
                if (log_ports[i] == validate_pbs_lag_params->log_port) {
                    is_log_port_found = TRUE;
                }
            }
        }
        if (is_log_port_found == TRUE) {
            rc = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("Port:0x%X is in use by PBS id:%d rc=[%s]\n", validate_pbs_lag_params->log_port,
                       pbs_entry->pbs_id, sx_status_str(rc));
            goto out;
        }
        break;

    case SX_ACL_PBS_ENTRY_TYPE_ROUTING:
    case SX_ACL_PBS_ENTRY_TYPE_UNICAST:
    case SX_ACL_PBS_ENTRY_TYPE_OUTPUT_UNICAST:
    default:
        break;
    }


out:
    if (log_ports != NULL) {
        cl_free(log_ports);
    }

    SX_LOG_EXIT();
    return rc;
}

boolean_t flex_acl_is_initialized(void)
{
    return g_flex_acl_initialized;
}


sx_status_t flex_acl_region_get_hw_size(sx_api_acl_region_hw_size_get_params_t *params)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t        *acl_region = NULL;
    flex_acl_hw_db_region_attribs_t *region_attributes = NULL;
    sx_dev_id_t                      dev_id = 1;


    SX_LOG_ENTER();


    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    /* checks if Region ID is legal */
    if (FLEX_ACL_REGION_BIT_CHECK(params->region_id)) {
        SX_LOG_ERR("ACL: Region ID is not valid, region_id[%#x].\n", params->region_id);
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    rc = flex_acl_db_region_get(params->region_id, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Region get error, region_id[%#x]\n", params->region_id);
        goto out;
    }

    rc = flex_acl_hw_db_get_region_attributes(acl_region->hw_region_attribs_handle, &region_attributes);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Region attributes get error, region_id[%#x]\n", params->region_id);
        goto out;
    }

    params->hw_size = region_attributes->hw_size[dev_id];

out:
    SX_LOG_EXIT();
    return rc;
}
#define FLEX_ACL_NUM_OF_VIDS_IN_SYSTEM_VLAN_GROUP 100
/* Can be only single default vlan group */
/* the default vlan group is initialized when first client of bind point type vlan group is initialized */
sx_status_t system_acl_create_default_vlan_group(system_acl_client_id_e client_id)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_api_acl_vlan_group_set_params_t params;

    SX_LOG_ENTER();
    SX_MEM_CLR(params);

    if (!g_init_flags.default_vlan_group_created) {
        params.cmd = SX_ACCESS_CMD_CREATE;
        /* create default vlan group  */
        rc = flex_acl_vlan_group_set_internal(&params, client_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up system vlan group, client id: [%u]\n", client_id);
            goto out;
        }
        /* initialize the db of system vlan group */
        rc = flex_acl_db_system_acl_vlan_group_init(params.vlan_group_id, FLEX_ACL_NUM_OF_VIDS_IN_SYSTEM_VLAN_GROUP);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to initialize system vlan group db, client id: [%u]\n", client_id);
            goto out;
        }
        g_init_flags.default_vlan_group_created = TRUE;
    }

    /* Many clients may try to create the default VLAN group */
    rc = flex_acl_db_system_acl_vlan_ref_count_update(TRUE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update ref counter for system vlan group db, client id: [%u]\n", client_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}
sx_status_t system_acl_delete_default_vlan_group(system_acl_client_id_e client_id)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_api_acl_vlan_group_set_params_t params;
    uint32_t                           refcount = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(params);

    if (!g_init_flags.default_vlan_group_created) {
        SX_LOG_ERR("Default VLAN group not created\n");
        rc = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    rc = flex_acl_db_get_default_vlan_group_id(&params.vlan_group_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get default vlan group id: client id: [%u]\n", client_id);
        goto out;
    }
    /* decrease and get_refcount */
    rc = flex_acl_db_system_acl_vlan_ref_count_update(FALSE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update ref counter for system vlan group db, client id: [%u]\n", client_id);
        goto out;
    }

    rc = flex_acl_db_system_acl_vlan_ref_count_get(&refcount);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get refcount for system vlan group, client id: [%u]\n", client_id);
        goto out;
    }

    if (refcount == 0) {
        /* deinit and get vlan group id */
        rc = flex_acl_db_system_acl_vlan_group_deinit(&params.vlan_group_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up system vlan group, client id: [%u]\n", client_id);
            goto out;
        }

        params.cmd = SX_ACCESS_CMD_DESTROY;
        /* create default vlan group  */
        rc = flex_acl_vlan_group_set_internal(&params, client_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set up system vlan group, client id: [%u]\n", client_id);
            goto out;
        }
        g_init_flags.default_vlan_group_created = FALSE;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_mc_container_port_ref_inc(sx_mc_container_id_t mc_container_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    /*
     * If mc container id not exists:
     * 1. Add it to DB
     * 2. Add all log ports to DB of mc container id
     */
    rc = flex_acl_db_mc_container_to_log_port_add(mc_container_id);
    if (rc == SX_STATUS_SUCCESS) {
        rc = __flex_acl_mc_container_port_add_log_ports(mc_container_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to add port filter mc container id:[%u] to DB, rc=[%s] \n",
                       mc_container_id,
                       sx_status_str(rc));
            goto out;
        }
    } else if (rc != SX_STATUS_ENTRY_ALREADY_EXISTS) {
        SX_LOG_ERR("Failed to add port filter mc container id:[%u] to DB, rc=[%s] \n", mc_container_id,
                   sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_db_mc_container_rule_ref_inc(mc_container_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to increment MC container rules ref id:[%u] , rc=[%s] \n", mc_container_id, sx_status_str(
                       rc));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_mc_container_port_get_validate(sx_mc_container_id_t mc_container_id,
                                                             uint32_t            *log_ports_count,
                                                             sx_port_id_t        *log_ports_ref_list_p)
{
    sx_status_t       rc = SX_STATUS_SUCCESS;
    sx_mc_next_hop_t *next_hops_list_p = NULL;
    sx_port_type_t    port_type = SX_PORT_TYPE_NETWORK;
    uint32_t          port_idx = 0;
    uint32_t          next_hops_count = 0;

    SX_LOG_ENTER();

    rc = sdk_mc_container_impl_get(mc_container_id,
                                   next_hops_list_p,
                                   &next_hops_count,
                                   NULL,
                                   NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed getting port filter mc container log ports list mc id:[%u] Error:[%s]\n",
                   mc_container_id, sx_status_str(rc));
        goto out;
    }
    if (log_ports_ref_list_p == NULL) {
        *log_ports_count = next_hops_count;
        goto out;
    }
    if (*log_ports_count < next_hops_count) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("buffer too small mc id:[%u] Error:[%s]\n",
                   mc_container_id, sx_status_str(rc));
        goto out;
    }

    /* get mc container SX_MC_NEXT_HOP_TYPE_LOG_PORT */

    next_hops_list_p = (sx_mc_next_hop_t*)cl_malloc(next_hops_count * sizeof(sx_mc_next_hop_t));
    rc = sdk_mc_container_impl_get(mc_container_id,
                                   next_hops_list_p,
                                   &next_hops_count,
                                   NULL,
                                   NULL);
    if (next_hops_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory port list of mc container id:[%u], Error:[%s]\n",
                   mc_container_id,
                   sx_status_str(rc));
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed getting port filter mc container log ports list mc id:[%u] Error:[%s]\n",
                   mc_container_id, sx_status_str(rc));
        goto out;
    }
    /* Convert next hops list to log ports list and validate supported port type */
    for (port_idx = 0; port_idx < next_hops_count; port_idx++) {
        port_type = SX_PORT_TYPE_ID_GET(next_hops_list_p[port_idx].data.log_port);
        if ((SX_PORT_TYPE_LAG != port_type) && (SX_PORT_TYPE_NETWORK != port_type)) {
            SX_LOG_ERR("Unsupported port [0x%x] type [%s]\n",
                       next_hops_list_p[port_idx].data.log_port,
                       sx_port_type_str(port_type));
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        log_ports_ref_list_p[port_idx] = next_hops_list_p[port_idx].data.log_port;
    }

out:
    if (next_hops_list_p) {
        cl_free(next_hops_list_p);
    }

    SX_LOG_EXIT();
    return rc;
}


sx_status_t __flex_acl_mc_container_port_add_log_ports(sx_mc_container_id_t mc_container_id)
{
    sx_status_t   rc = SX_STATUS_SUCCESS;
    uint32_t      next_hops_count = 0;
    sx_port_id_t *log_ports_ref_list_p = NULL;
    uint32_t      port_idx = 0;

    SX_LOG_ENTER();

    /* get mc container next hops count SX_MC_NEXT_HOP_TYPE_LOG_PORT */
    rc = __flex_acl_mc_container_port_get_validate(mc_container_id, &next_hops_count, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get mc container id[%u] port list Error:[%s]\n",
                   mc_container_id, sx_status_str(rc));
        goto out;
    }

    /* get converted next hops list to log ports list and validate supported port type */
    log_ports_ref_list_p = (sx_port_id_t*)cl_malloc(next_hops_count * sizeof(sx_port_id_t));
    if (log_ports_ref_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory port list of mc container id:[%u], Error:[%s]\n",
                   mc_container_id,
                   sx_status_str(rc));
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    rc = __flex_acl_mc_container_port_get_validate(mc_container_id, &next_hops_count, log_ports_ref_list_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get mc container id[%u] port list Error:[%s]\n",
                   mc_container_id, sx_status_str(rc));
        goto out;
    }

    /* Update DB with log_ports_ref_list_p */
    for (port_idx = 0; port_idx < next_hops_count; port_idx++) {
        rc = __flex_acl_add_log_port_to_mc_container_port(log_ports_ref_list_p[port_idx], mc_container_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to add log port:[0x%x] to MC container id:[%u] \n",
                       log_ports_ref_list_p[port_idx],
                       mc_container_id);
            goto out;
        }
    }

out:
    if (log_ports_ref_list_p) {
        cl_free(log_ports_ref_list_p);
    }
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_rule_key_mc_container_change_cb(flex_acl_rule_id_t *rule_id_p, void *param_p)
{
    UNUSED_PARAM(param_p);
    return __flex_acl_write_region_offset_rule(rule_id_p->region_id, rule_id_p->offset);
}

static sx_status_t __flex_acl_rule_key_mc_container_change(sx_mc_container_id_t mc_container_id)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_db_mcc_rule_pfn_t func = __flex_acl_rule_key_mc_container_change_cb;

    rc = flex_acl_db_mc_container_to_rule_refs_foreach(MCC_TO_RULE_PORT_LIST_KEY, mc_container_id, func, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update mc container id:[%u] with changes, rc=[%s]\n",
                   mc_container_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_rule_port_filter_action_container_change_cb(flex_acl_rule_id_t *rule_id_p, void *param_p)
{
    UNUSED_PARAM(param_p);
    return __flex_acl_rewrite_rule_actions(rule_id_p->region_id, rule_id_p->offset);
}

static sx_status_t __flex_acl_rule_port_filter_action_container_change(sx_mc_container_id_t mc_container_id)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_db_mcc_rule_pfn_t func = __flex_acl_rule_port_filter_action_container_change_cb;

    rc = flex_acl_db_mc_container_to_rule_refs_foreach(MCC_TO_RULE_PORT_FILTER_ACTION, mc_container_id, func, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to update mc container id:[%u] with port filter action changes, rc=[%s]\n",
                   mc_container_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t __flex_acl_mc_container_change_write_to_hw(sx_mc_container_id_t mc_container_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = __flex_acl_rule_port_filter_action_container_change(mc_container_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed update rules with MC container id:[%u] changes, rc=[%s]\n",
                   mc_container_id, sx_status_str(rc));
        goto out;
    }

    rc = __flex_acl_rule_key_mc_container_change(mc_container_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed update rule keys with MC container id:[%u] changes, rc=[%s]\n",
                   mc_container_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_mc_container_port_next_hops_change_cb(adviser_event_e event_type, void *param)
{
    post_mc_container_next_hops_change_data_t *mc_container_change_info_p;
    sx_status_t                                rc = SX_STATUS_SUCCESS, rc_rb = SX_STATUS_SUCCESS;
    sx_port_id_t                              *old_log_ports_ref_list_p = NULL;
    uint32_t                                   old_log_port_count = 0;
    uint32_t                                   new_log_port_count = 0;
    sx_port_id_t                              *new_log_ports_ref_list_p = NULL;

    UNUSED_PARAM(event_type);

    SX_LOG_ENTER();

    mc_container_change_info_p = (post_mc_container_next_hops_change_data_t*)param;
    /* get old log ports list */
    rc = flex_acl_db_mc_container_to_log_ports_ref_list_get(mc_container_change_info_p->container_id,
                                                            &old_log_port_count,
                                                            NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Failed to get log_ports_ref count of mc container id:[%u] from DB, rc=[%s]\n",
                   mc_container_change_info_p->container_id, sx_status_str(rc));
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    old_log_ports_ref_list_p = (sx_port_id_t*)cl_malloc(old_log_port_count * sizeof(sx_port_id_t));
    if (old_log_ports_ref_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory port list of mc container id:[%u], Error:[%s]\n",
                   mc_container_change_info_p->container_id, sx_status_str(rc));
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    rc = flex_acl_db_mc_container_to_log_ports_ref_list_get(mc_container_change_info_p->container_id,
                                                            &old_log_port_count,
                                                            old_log_ports_ref_list_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get log_ports_ref list of mc container id:[%u] from DB, rc=[%s]\n",
                   mc_container_change_info_p->container_id,
                   sx_status_str(rc));
        goto out;
    }

    /* get new mc container next hops count SX_MC_NEXT_HOP_TYPE_LOG_PORT */
    rc =
        __flex_acl_mc_container_port_get_validate(mc_container_change_info_p->container_id, &new_log_port_count, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get mc container id[%u] port list, rc=[%s]\n",
                   mc_container_change_info_p->container_id, sx_status_str(rc));
        goto out;
    }

    /* get new log ports list and validate supported port type */
    new_log_ports_ref_list_p = (sx_port_id_t*)cl_malloc(new_log_port_count * sizeof(sx_port_id_t));
    if (new_log_ports_ref_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory port list of mc container id:[%u], Error:[%s]\n",
                   mc_container_change_info_p->container_id, sx_status_str(rc));
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }
    rc = __flex_acl_mc_container_port_get_validate(mc_container_change_info_p->container_id,
                                                   &new_log_port_count,
                                                   new_log_ports_ref_list_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get mc container id[%u] port list, rc=[%s]\n",
                   mc_container_change_info_p->container_id, sx_status_str(rc));
        goto out;
    }

    /* Remove old ports and add new port to mc container DB*/
    rc = __flex_acl_update_mc_container_port(mc_container_change_info_p->container_id,
                                             old_log_port_count, old_log_ports_ref_list_p,
                                             new_log_port_count, new_log_ports_ref_list_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed tu update mc container id:[%u] with changes, rc=[%s]\n",
                   mc_container_change_info_p->container_id, sx_status_str(rc));
        goto out;
    }

    /* Write to HW */
    rc = __flex_acl_mc_container_change_write_to_hw(mc_container_change_info_p->container_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed update MC container id:[%u] changes, rc=[%s]\n",
                   mc_container_change_info_p->container_id,
                   sx_status_str(rc));
        goto rollback_db;
    }
    goto out;

rollback_db:
    rc_rb = __flex_acl_mc_container_port_rollback_db(mc_container_change_info_p->container_id,
                                                     old_log_port_count,
                                                     old_log_ports_ref_list_p);
    if (rc_rb != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to rollback MC container id:[%u] db rb_rc = [%s]\n",
                   mc_container_change_info_p->container_id,
                   sx_status_str(rc_rb));
        goto out;
    }

out:
    if (old_log_ports_ref_list_p) {
        cl_free(old_log_ports_ref_list_p);
    }
    if (new_log_ports_ref_list_p) {
        cl_free(new_log_ports_ref_list_p);
    }
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_mc_container_port_rollback_db(sx_mc_container_id_t mc_container_id,
                                                            uint32_t             log_port_count,
                                                            sx_port_id_t        *log_ports_ref_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    port_idx = 0;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(log_ports_ref_list_p, "log_ports_ref_list_p"))) {
        goto out;
    }

    /* Remove old ports */
    rc = __flex_acl_remove_all_log_ports_from_mc_container_port(mc_container_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to rollback MC container id:[%u] DB, rc=[%s] \n", mc_container_id, sx_status_str(rc));
        goto out;
    }

    /* Update with log_ports_ref_list_p */
    for (port_idx = 0; port_idx < log_port_count; port_idx++) {
        rc = __flex_acl_add_log_port_to_mc_container_port(log_ports_ref_list_p[port_idx], mc_container_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to add log port:[0x%x] to MC container id:[%u] \n",
                       log_ports_ref_list_p[port_idx],
                       mc_container_id);
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_mc_container_port_ref_dec(sx_mc_container_id_t mc_container_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    rules_ref_count = 0;

    SX_LOG_ENTER();

    rc = flex_acl_db_mc_container_rule_ref_dec(mc_container_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to increment MC container rules ref id:[%u], rc=[%s] \n", mc_container_id,
                   sx_status_str(rc));
        goto out;
    }

    /* get rules ref count of mc container id
     * If rules_ref_count is 0 then we can remove mc container from DB */
    rc = flex_acl_db_mc_container_rule_ref_get(mc_container_id, &rules_ref_count);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get mc container id:[%u] from DB, rc=[%s]  \n", mc_container_id, sx_status_str(rc));
        goto out;
    }
    if (rules_ref_count == 0) {
        rc = __flex_acl_remove_all_log_ports_from_mc_container_port(mc_container_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to remove log ports from mc container id:[%u] from DB, rc=[%s] \n",
                       mc_container_id,
                       sx_status_str(rc));
            goto out;
        }
        rc = flex_acl_db_mc_container_to_log_port_destroy(mc_container_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to destroy mc container id:[%u] from DB, rc=[%s] \n", mc_container_id,
                       sx_status_str(rc));
            goto out;
        }
    }


out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_update_mc_container_port(sx_mc_container_id_t mc_container_id,
                                                       uint32_t             old_port_count,
                                                       sx_port_id_t        *old_log_ports_ref_list_p,
                                                       uint32_t             new_port_count,
                                                       sx_port_id_t        *new_log_ports_ref_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    old_port_idx, new_port_idx;

    SX_LOG_ENTER();


    for (old_port_idx = 0; old_port_idx < old_port_count; ++old_port_idx) {
        for (new_port_idx = 0; new_port_idx < new_port_count; ++new_port_idx) {
            if (old_log_ports_ref_list_p[old_port_idx] == new_log_ports_ref_list_p[new_port_idx]) {
                break;
            }
        }
        /* if old log port not found in new port list - it has been removed from container - remove from DB */
        if (new_port_idx == new_port_count) {
            rc = __flex_acl_remove_log_port_from_mc_container_port(old_log_ports_ref_list_p[old_port_idx],
                                                                   mc_container_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to remove log port:[0x%x] from MC container id:[%u] \n",
                           old_log_ports_ref_list_p[old_port_idx], mc_container_id);
                goto out;
            }
        }
    }

    for (new_port_idx = 0; new_port_idx < new_port_count; ++new_port_idx) {
        for (old_port_idx = 0; old_port_idx < old_port_count; ++old_port_idx) {
            if (new_log_ports_ref_list_p[new_port_idx] == old_log_ports_ref_list_p[old_port_idx]) {
                break;
            }
        }
        /* if new log port not found in old port list - it has been added to container - add to DB */
        if (old_port_idx == old_port_count) {
            rc = __flex_acl_add_log_port_to_mc_container_port(new_log_ports_ref_list_p[new_port_idx], mc_container_id);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to add log port:[0x%x] to MC container id:[%u] \n",
                           new_log_ports_ref_list_p[new_port_idx], mc_container_id);
                goto out;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_add_log_port_to_mc_container_port(sx_port_id_t         log_port_id,
                                                                sx_mc_container_id_t mc_container_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_db_log_port_to_mc_container_add(log_port_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to add port filter log port:[0x%x] to DB, rc=[%s] \n", log_port_id, sx_status_str(rc));
        goto out;
    }
    rc = flex_acl_db_log_port_to_mc_containers_ref_list_update(log_port_id, mc_container_id, SX_ACCESS_CMD_ADD);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to add port filter mc container id:[%u] to ref_list log port id:[0x%x] DB, rc=[%s] \n",
                   mc_container_id, log_port_id, sx_status_str(rc));
        goto out;
    }
    rc = flex_acl_db_mc_container_to_log_ports_ref_list_update(mc_container_id, log_port_id, SX_ACCESS_CMD_ADD);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to add port filter log port:[0x%x] to ref_list mc container id:[%u] DB, rc=[%s] \n",
                   log_port_id, mc_container_id, sx_status_str(rc));
        goto out;
    }


out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_remove_log_port_from_mc_container_port(sx_port_id_t         log_port_id,
                                                                     sx_mc_container_id_t mc_container_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Delete mc container id from mc_containers_ref_list */
    rc = flex_acl_db_log_port_to_mc_containers_ref_list_update(log_port_id, mc_container_id, SX_ACCESS_CMD_DELETE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to delete port filter mc container id:[%u] from ref_list log port id:[0x%x] DB, rc=[%s] \n",
                   mc_container_id, log_port_id, sx_status_str(rc));
        goto out;
    }
    /* Delete log port id from log_ports_ref_list */
    rc = flex_acl_db_mc_container_to_log_ports_ref_list_update(mc_container_id, log_port_id, SX_ACCESS_CMD_DELETE);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to delete port filter log port:[0x%x] from ref_list mc container id:[%u] DB, rc=[%s] \n"
                   , log_port_id, mc_container_id, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_remove_all_log_ports_from_mc_container_port(sx_mc_container_id_t mc_container_id)
{
    sx_status_t   rc = SX_STATUS_SUCCESS;
    sx_port_id_t *log_ports_ref_list_p = NULL;
    uint32_t      log_port_count = 0, i = 0;

    SX_LOG_ENTER();

    /* get log_port_ref_list of mc container id*/
    rc = flex_acl_db_mc_container_to_log_ports_ref_list_get(mc_container_id, &log_port_count, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get  logical ports reference count of mc container id:[%u] from DB, rc=[%s]\n",
                   mc_container_id,
                   sx_status_str(rc));
        goto out;
    }

    log_ports_ref_list_p = (sx_port_id_t*)cl_malloc(log_port_count * sizeof(sx_port_id_t));
    if (log_ports_ref_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory port list of mc container id:[%u], Error:[%s]\n",
                   mc_container_id,
                   sx_status_str(rc));
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    rc = flex_acl_db_mc_container_to_log_ports_ref_list_get(mc_container_id, &log_port_count, log_ports_ref_list_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get logical ports reference list of mc container id:[%u] from DB, rc=[%s]\n",
                   mc_container_id,
                   sx_status_str(rc));
        goto out;
    }

    for (i = 0; i < log_port_count; ++i) {
        /* Delete mc container id from mc_containers_ref_list */
        rc = __flex_acl_remove_log_port_from_mc_container_port(log_ports_ref_list_p[i], mc_container_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to remove log port:[0x%x] from MC container id:[%u] \n",
                       log_ports_ref_list_p[i],
                       mc_container_id);
            goto out;
        }
    }


out:
    if (log_ports_ref_list_p != NULL) {
        cl_free(log_ports_ref_list_p);
    }
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_mc_container_post_port_changed(sx_port_id_t log_port_id,
                                                             boolean_t    write_to_hw,
                                                             boolean_t    remove_from_db)
{
    sx_status_t           rc = SX_STATUS_SUCCESS, rc_rb = SX_STATUS_SUCCESS;
    sx_mc_container_id_t *mc_container_ref_list_p = NULL;
    uint32_t              mc_containers_count = 0, i = 0;

    SX_LOG_ENTER();

    rc = flex_acl_db_log_port_to_mc_containers_ref_list_get(log_port_id, &mc_containers_count, NULL);
    if (SX_STATUS_ENTRY_NOT_FOUND == rc) {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

    mc_container_ref_list_p = (sx_mc_container_id_t*)cl_malloc(mc_containers_count * sizeof(sx_mc_container_id_t));
    if (mc_container_ref_list_p == NULL) {
        SX_LOG_ERR("Failed to allocate memory mc container list of log port:[0x%x], Error:[%s]\n",
                   log_port_id,
                   sx_status_str(rc));
        rc = SX_STATUS_MEMORY_ERROR;
        goto out;
    }

    rc =
        flex_acl_db_log_port_to_mc_containers_ref_list_get(log_port_id, &mc_containers_count, mc_container_ref_list_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get mc_containers_ref list of log port id:[%u] from DB, rc=[%s]\n",
                   log_port_id,
                   sx_status_str(rc));
        goto out;
    }

    for (i = 0; i < mc_containers_count; ++i) {
        /* Remove from DB */
        if (remove_from_db) {
            rc = __flex_acl_remove_log_port_from_mc_container_port(log_port_id, mc_container_ref_list_p[i]);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to remove log port:[0x%x] from MC container id:[%u] rc=[%s]\n",
                           log_port_id, mc_container_ref_list_p[i], sx_status_str(rc));
                goto out;
            }
        }

        /* Write to HW */
        if (write_to_hw) {
            rc = __flex_acl_mc_container_change_write_to_hw(mc_container_ref_list_p[i]);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed update HW with MC container id:[%u] changes, rc=[%s] \n",
                           mc_container_ref_list_p[i],
                           sx_status_str(rc));
                if (remove_from_db) {
                    goto rollback_db;
                }
            }
        }
    }
    goto out;

rollback_db:
    for (i = 0; i < mc_containers_count; ++i) {
        rc_rb = __flex_acl_add_log_port_to_mc_container_port(log_port_id, mc_container_ref_list_p[i]);
        if (rc_rb != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to rollback MC container id:[%u] db rb_rc = [%s] \n",
                       mc_container_ref_list_p[i],
                       sx_status_str(rc_rb));
            goto out;
        }
    }

out:
    if (mc_container_ref_list_p) {
        cl_free(mc_container_ref_list_p);
    }
    SX_LOG_EXIT();
    return rc;
}


static sx_status_t __flex_acl_lag_destroyed_mc_container(sx_port_id_t lag_port_log_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   write_to_hw = FALSE, remove_from_db = TRUE;

    SX_LOG_ENTER();

    rc = __flex_acl_mc_container_post_port_changed(lag_port_log_id, write_to_hw, remove_from_db);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("failed handling post port deleted from swid, port: %#x, error: %s\n",
                   lag_port_log_id,
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_post_port_removed_from_lag_mc_container(sx_port_id_t lag_port_log_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   write_to_hw = TRUE, remove_from_db = FALSE;

    SX_LOG_ENTER();

    rc = __flex_acl_mc_container_post_port_changed(lag_port_log_id, write_to_hw, remove_from_db);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("failed handling port filter removing port from lag %#x, error: %s\n",
                   lag_port_log_id,
                   sx_status_str(rc));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_post_port_added_to_lag_mc_container(sx_port_id_t lag_port_log_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   write_to_hw = TRUE, remove_from_db = FALSE;

    SX_LOG_ENTER();

    rc = __flex_acl_mc_container_post_port_changed(lag_port_log_id, write_to_hw, remove_from_db);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("failed handling port filter adding port to lag %#x, error: %s\n", lag_port_log_id, sx_status_str(
                       rc));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __flex_acl_post_port_del_from_swid_mc_container_port(sx_port_id_t port_log_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   write_to_hw = TRUE, remove_from_db = TRUE;

    rc = __flex_acl_mc_container_post_port_changed(port_log_id, write_to_hw, remove_from_db);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("failed handling post port deleted from swid, port: %#x, error: %s\n", port_log_id, sx_status_str(
                       rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_get_rm_attrs(rm_sdk_table_type_e resource, sx_hw_entries_param_t *hw_params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    uint32_t    num_of_copies = 0;

    UNUSED_PARAM(resource);
    rc = flex_acl_get_hw_opt(FLEX_ACL_INVALID_REGION_ID, &num_of_copies);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: filed to get key attributes\n");
        goto out;
    }
    hw_params->hw_attr.tcam_attrs.number_of_copies = num_of_copies;

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_get_rm_resource(uint32_t key_handle, rm_sdk_table_type_e *resource)
{
    sx_status_t             rc = SX_STATUS_SUCCESS;
    sx_acl_flex_key_width_t key_width = SX_ACL_FLEX_KEY_WIDTH_NONE_E;

    rc = flex_acl_key_sizes_get(key_handle, NULL, &key_width);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL: failed to get key sizes for key handle [0x%x]\n", key_handle);
        goto out;
    }

    switch (key_width) {
    case SX_ACL_FLEX_KEY_WIDTH_9_E:
    case SX_ACL_FLEX_KEY_WIDTH_18_E:
        *resource = RM_SDK_TABLE_TYPE_ACL_RULES_TWO_KEY_BLOCK_E;
        break;

    case SX_ACL_FLEX_KEY_WIDTH_36_E:
        *resource = RM_SDK_TABLE_TYPE_ACL_RULES_FOUR_KEY_BLOCK_E;
        break;

    case SX_ACL_FLEX_KEY_WIDTH_54_E:
        *resource = RM_SDK_TABLE_TYPE_ACL_RULES_SIX_KEY_BLOCK_E;
        break;

    default:
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ACL: Unexpected key width [%u] when getting rm resource\n", key_width);
        break;
    }

out:
    return rc;
}

sx_status_t flex_acl_region_initial_activity_set(sx_acl_region_id_t region_id, boolean_t activity_cleared)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    rc = flex_acl_db_initial_activity_set(region_id, activity_cleared);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl set initial activity failed for region [%u]\n", region_id);
        goto out;
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_issu_bind_router_trigger(sx_access_cmd_t cmd)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    boolean_t                 is_router_init_done = FALSE;
    sdk_router_init_params_t *sdk_router_init_params_p = NULL;
    sx_issu_bank_e            issu_bank = SX_ISSU_BANK_1_E;

    SX_LOG_ENTER();

    rc = sdk_router_cmn_impl_init_params_get(&is_router_init_done, &sdk_router_init_params_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get router initial parameters %s.\n", sx_status_str(rc));
        goto out;
    }

    if ((is_router_init_done == FALSE) ||
        ((sdk_router_init_params_p->general_param.ipv4_mc_enable == FALSE) &&
         (sdk_router_init_params_p->general_param.ipv6_mc_enable == FALSE))) {
        goto out;
    }

    rc = issu_bank_get(&issu_bank);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get ISSU Bank %s \n", sx_status_str(rc));
        goto out;
    }

    if (sdk_router_init_params_p->general_param.ipv4_mc_enable == TRUE) {
        rc = system_acl_mc_router_hw_bind_region_spc(cmd, SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E,
                                                     (issu_bank == SX_ISSU_BANK_1_E) ? FALSE : TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to bind MC router region, ISSU bank = %u, client = IPV4, err = %s\n",
                       issu_bank, sx_status_str(rc));
            goto out;
        }
    }


    if (sdk_router_init_params_p->general_param.ipv6_mc_enable == TRUE) {
        rc = system_acl_mc_router_hw_bind_region_spc(cmd, SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E,
                                                     (issu_bank == SX_ISSU_BANK_1_E) ? FALSE : TRUE);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to bind MC router region, ISSU bank = %u, client = IPV6, err = %s\n",
                       issu_bank, sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_issu_bind_router_trigger_spc2(sx_access_cmd_t cmd)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    boolean_t                 is_router_init_done = FALSE;
    sdk_router_init_params_t *sdk_router_init_params_p = NULL;

    SX_LOG_ENTER();

    rc = sdk_router_cmn_impl_init_params_get(&is_router_init_done, &sdk_router_init_params_p);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get router initial parameters %s.\n", sx_status_str(rc));
        goto out;
    }

    if ((is_router_init_done == FALSE) ||
        ((sdk_router_init_params_p->general_param.ipv4_mc_enable == FALSE) &&
         (sdk_router_init_params_p->general_param.ipv6_mc_enable == FALSE))) {
        goto out;
    }

    if (sdk_router_init_params_p->general_param.ipv4_mc_enable == TRUE) {
        rc = system_acl_issu_mc_router_bind_trigger_spc2(cmd, SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV4_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to bind MC router region, client = IPV4, err = %s\n",
                       sx_status_str(rc));
            goto out;
        }
    }

    if (sdk_router_init_params_p->general_param.ipv6_mc_enable == TRUE) {
        rc = system_acl_issu_mc_router_bind_trigger_spc2(cmd, SYSTEM_ACL_CLIENT_ID_MC_ROUTER_IPV6_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to bind MC router region, client = IPV6, err = %s\n",
                       sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_issu_bind_acl_set(sx_access_cmd_t cmd)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((cmd != SX_ACCESS_CMD_BIND) && (cmd != SX_ACCESS_CMD_ADD)) {
        SX_LOG_ERR("CMD: %s not supported when calling ISSU acl bind.\n", sx_access_cmd_str(cmd));
        rc = SX_STATUS_CMD_UNPERMITTED;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_ADD) {
        rc = flex_acl_hw_issu_bind_acl_trigger();
        if (SX_STATUS_SUCCESS != rc) {
            SX_LOG_ERR("Flex acl bind acl trigger failed.\n");
            goto out;
        }
        rc = flex_acl_rule_based_binding_issu_set();
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Flex acl rule based binding ISSU failed.\n");
            goto out;
        }
    }

    if (brg_context.spec_cb_g.issu_mc_router_region_bind_trigger_cb != NULL) {
        rc = brg_context.spec_cb_g.issu_mc_router_region_bind_trigger_cb(cmd);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in issu_mc_router_region_bind_trigger_cb %s.\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t __flex_acl_update_bind_attribute(flex_acl_db_group_bind_attribs_t *bind_attribute, void *param_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sx_acl_id_t acl_id = (sx_acl_id_t)((intptr_t)param_p);
    uint32_t    i = 0;

    SX_LOG_ENTER();

    if (bind_attribute->acl_id_num > 0) {
        /* Check if the acl is part of the bind attributes. No point updating the list if it's not */
        for (i = 0; i < bind_attribute->acl_id_num; i++) {
            if (bind_attribute->acl_id_list[i].acl_id == acl_id) {
                rc = flex_acl_write_bind_attributes(bind_attribute->bind_id, TRUE, bind_attribute->acl_id_list,
                                                    bind_attribute->acl_id_num, TRUE);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed re-writing bind attributes [%u].\n", bind_attribute->bind_id);
                    goto out;
                }
                break;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_create_shadow_acl_region(sx_acl_region_id_t  region_id,
                                              sx_acl_region_id_t *shadow_region_id,
                                              sx_acl_id_t        *shadow_acl_id)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_status_t                    rb_rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t      *acl_region = NULL;
    flex_acl_db_acl_table_t       *acl_table = NULL;
    sx_api_acl_region_set_params_t new_region_params;
    sx_api_flex_acl_set_params_t   new_acl_params;

    SX_LOG_ENTER();

    SX_MEM_CLR(new_region_params);
    SX_MEM_CLR(new_acl_params);

    /**** Check input parameters */
    if (g_flex_acl_initialized == FALSE) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(shadow_region_id, "shadow_region_id"))) {
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(shadow_acl_id, "shadow_acl_id"))) {
        goto out;
    }
    /* Try to get the original region */
    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to find region_id %d for multi region creation\n", region_id);
        goto out;
    }

    if (acl_region->shadowed_by_region_id != FLEX_ACL_INVALID_REGION_ID) {
        SX_LOG_ERR("Flex acl shadow region already exists for region %d\n", region_id);
        rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    rc = flex_acl_db_acl_get(acl_region->bound_acl, &acl_table);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl cannot create multi region for non acl bound region %d\n", region_id);
        goto out;
    }

    if (acl_table->shadowed_by_acl_id != FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG_ERR("Flex acl shadow acl already exists for region %d, acl %d\n",
                   region_id,
                   acl_table->shadowed_by_acl_id);
        rc = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    /* Create a new region */
    new_region_params.cmd = SX_ACCESS_CMD_CREATE;
    new_region_params.region_size = acl_region->size - acl_region->reserved_rules_num;
    new_region_params.key_type = acl_region->key_handle;
    rc = flex_acl_region_set_internal(&new_region_params, SYSTEM_ACL_CLIENT_ID_INVALID_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to create shadow region for region %d, err [%s]\n", region_id,  sx_status_str(rc));
        goto out;
    }

    /* Create a new acl */
    new_acl_params.acl_direction = acl_table->direction;
    new_acl_params.cmd = SX_ACCESS_CMD_CREATE;
    new_acl_params.region_id = new_region_params.region_id;
    rc = flex_acl_set_internal(&new_acl_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to create shadow acl for region %d, err [%s]\n", region_id,  sx_status_str(rc));
        goto failed_acl_create;
    }

    /* Copy the ACL attributes */
    rc = flex_acl_db_acl_attributes_set(new_acl_params.acl_id, &acl_table->acl_attributes);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to copy acl attribute to shadow acl for acl %d, err [%s]\n",
                   acl_table->acl_id,
                   sx_status_str(rc));
        goto failed_region_db_set;
    }

    /* Indicate in the db about the shadow region/acl */
    rc = flex_acl_db_region_set_shadow_region(region_id, new_region_params.region_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to set shadow region for region %d, err [%s]\n", region_id,  sx_status_str(rc));
        goto failed_region_db_set;
    }
    rc = flex_acl_db_acl_set_shadow_acl(acl_table->acl_id, new_acl_params.acl_id);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to set shadow acl for acl %d, err [%s]\n", acl_table->acl_id,  sx_status_str(rc));
        goto failed_acl_db_set;
    }

    /* Go over all the existing bind attributes and update with the new shadow ACL */
    rc = flex_acl_db_attribs_foreach(__flex_acl_update_bind_attribute, (void*)((intptr_t)acl_table->acl_id));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to update all bind attributes with shadow acl %d, err [%s]\n",
                   acl_table->acl_id,
                   sx_status_str(rc));
        goto failed_attribs_foreach;
    }

    *shadow_region_id = new_region_params.region_id;
    *shadow_acl_id = new_acl_params.acl_id;

    goto out;

failed_acl_db_set:
    rb_rc = flex_acl_db_region_set_shadow_region(region_id, FLEX_ACL_INVALID_REGION_ID);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Rollback Flex acl failed to set shadow region for region %d, err [%s]\n",
                   region_id,
                   sx_status_str(rc));
    }
failed_region_db_set:
    new_acl_params.cmd = SX_ACCESS_CMD_DESTROY;
    rb_rc = flex_acl_set_internal(&new_acl_params);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to create shadow acl for region %d, err [%s]\n", region_id,  sx_status_str(rc));
    }
failed_acl_create:
    new_region_params.cmd = SX_ACCESS_CMD_DESTROY;
    rb_rc = flex_acl_region_set_internal(&new_region_params, SYSTEM_ACL_CLIENT_ID_INVALID_E);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to create shadow region for region %d, err [%s]\n", region_id,  sx_status_str(rc));
    }
out:
    SX_LOG_EXIT();
    return rc;

failed_attribs_foreach:
    rb_rc = flex_acl_remove_shadow_acl_region(region_id, new_region_params.region_id);
    if (rb_rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed rollback for remove shadow region [%d], err [%s]\n", region_id,  sx_status_str(rc));
    }
    goto out;
}

sx_status_t flex_acl_remove_shadow_acl_region(sx_acl_region_id_t region_id, sx_acl_region_id_t shadow_region_id)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t      *acl_region = NULL;
    flex_acl_db_acl_table_t       *acl_table = NULL;
    sx_acl_region_id_t             shadowed_by_region_id = FLEX_ACL_INVALID_REGION_ID;
    sx_acl_id_t                    shadowed_by_acl_id = FLEX_ACL_INVALID_ACL_ID;
    boolean_t                      valid_rules_exist = FALSE;
    sx_api_acl_region_set_params_t region_params;
    sx_api_flex_acl_set_params_t   acl_params;

    SX_MEM_CLR(region_params);
    SX_MEM_CLR(acl_params);

    /**** Check input parameters */
    if (g_flex_acl_initialized == FALSE) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Try to get the original region */
    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to find region_id %d for multi region creation\n", region_id);
        goto out;
    }

    if ((acl_region->shadowed_by_region_id == FLEX_ACL_INVALID_REGION_ID) ||
        ((acl_region->shadowed_by_region_id | FLEX_ACL_REGION_BIT_MASK) !=
         (shadow_region_id | FLEX_ACL_REGION_BIT_MASK))) {
        SX_LOG_ERR("Flex acl shadow region does not exist or is inconsistent for region %d\n", region_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_db_acl_get(acl_region->bound_acl, &acl_table);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to get ACL [%d] from DB\n", acl_region->bound_acl);
        goto out;
    }

    if (acl_table->shadowed_by_acl_id == FLEX_ACL_INVALID_ACL_ID) {
        SX_LOG_ERR("Flex acl shadow does not exist for acl %d\n", acl_table->acl_id);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* Make sure we don't have any valid rules in the region */
    rc = __flex_acl_is_region_have_valid_rules(acl_region->shadowed_by_region_id, &valid_rules_exist);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error at valid rules validation\n");
        goto out;
    }
    if (valid_rules_exist) {
        SX_LOG_ERR("The region can't be destroyed, still have valid rules\n");
        rc = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    shadowed_by_region_id = acl_region->shadowed_by_region_id;
    shadowed_by_acl_id = acl_table->shadowed_by_acl_id;
    /* We now do a nasty trick in order to remove all the shadowed ACLS from the hw bind attributes.
     * We temporarily set in the ACLs DB that the ACL does not have a shadow and iterate over all the bind attributes.
     * This will remove the shadow ACL from the linked list. We'll then restore the DB and delete it the shadow from the DB.
     */
    acl_table->shadowed_by_acl_id = FLEX_ACL_INVALID_ACL_ID;
    /* Go over all the existing bind attributes and update without this shadow ACL */
    rc = flex_acl_db_attribs_foreach(__flex_acl_update_bind_attribute, (void*)((intptr_t)acl_table->acl_id));
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to remove bind attributes with shadow acl %d, err [%s]\n",
                   acl_table->acl_id,
                   sx_status_str(rc));
        /* No roll back here */
    }
    acl_table->shadowed_by_acl_id = shadowed_by_acl_id;
    /* Indicate in the DB that we do not have a shadow anymore */
    rc = flex_acl_db_acl_set_shadow_acl(acl_table->acl_id, FLEX_ACL_INVALID_ACL_ID);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to set shadow acl for acl %d, err [%s]\n", acl_table->acl_id,  sx_status_str(rc));
        /* No roll back here */
    }
    rc = flex_acl_db_region_set_shadow_region(region_id, FLEX_ACL_INVALID_REGION_ID);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to set shadow region for region %d, err [%s]\n", region_id,  sx_status_str(rc));
        /* No roll back here */
    }

    /* Destroy the shadow acl */
    acl_params.cmd = SX_ACCESS_CMD_DESTROY;
    acl_params.acl_id = shadowed_by_acl_id;
    rc = flex_acl_set_internal(&acl_params);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to destroy shadow acl for region %d, err [%s]\n", region_id,  sx_status_str(rc));
        /* No roll back here */
    }

    /* Destroy the shadow region */
    region_params.cmd = SX_ACCESS_CMD_DESTROY;
    region_params.region_id = shadowed_by_region_id;
    region_params.key_type = acl_region->key_handle;
    rc = flex_acl_region_set_internal(&region_params, SYSTEM_ACL_CLIENT_ID_INVALID_E);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Flex acl failed to destroy shadow region for region %d, err [%s]\n", region_id,
                   sx_status_str(rc));
        /* No roll back here */
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_attr_set(sx_api_acl_attrib_set_params_t *params)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e      entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;
    sx_acl_attributes_t        prev_acl_attributes;
    sx_acl_global_attributes_t global_acl_attr;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_acl_entry_type_get(params->acl_id, &entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get acl entry type, acl_id[%u].\n", params->acl_id);
        goto out;
    }
    if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL: ACL table access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_SET:
        /* get current attributes */
        rc = flex_acl_db_acl_attributes_get(params->acl_id, &prev_acl_attributes);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get acl attributes for ACL ID[%u].\n", params->acl_id);
            goto out;
        }
        rc = flex_acl_db_acl_attributes_set(params->acl_id, &params->acl_attributes);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
        break;
    }
    rc = flex_acl_db_acl_global_attr_get(&global_acl_attr);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }
    /* If the global flag for acl drop trap is disabled, then
     * do not relocate the trap action now. Only update the flag state
     * When the global flag state changes, all the individual ACLs will be
     * updated then based on the respective ACL flag state
     */
    if (!global_acl_attr.disable_acl_drop_trap) {
        if (prev_acl_attributes.disable_acl_drop_monitoring_trap !=
            params->acl_attributes.disable_acl_drop_monitoring_trap) {
            /* Monitor state has changed. Need to update all the rules */
            SX_LOG_INF("ACL Drop Monitor State changed. Prev: %s, New %s\n",
                       (prev_acl_attributes.disable_acl_drop_monitoring_trap ? "DISABLED" : "ENABLED"),
                       (params->acl_attributes.disable_acl_drop_monitoring_trap ? "DISABLED" : "ENABLED"));
            SX_LOG_INF("Updating all the rules in this ACL ID: %u. This can take some time\n",
                       params->acl_id);
            rc = flex_acl_hw_acl_drop_action_relocate(params->acl_id,
                                                      prev_acl_attributes.disable_acl_drop_monitoring_trap,
                                                      params->acl_attributes.disable_acl_drop_monitoring_trap);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(" Updating Drop Monitoring Trap State failed. Err = %s\n", sx_status_str(rc));
                goto out;
            }
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_attr_get(sx_api_acl_attrib_get_params_t *params)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    flex_acl_entry_type_e entry_type = FLEX_ACL_ENTRY_TYPE_USER_E;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }
    rc = flex_acl_db_acl_entry_type_get(params->acl_id, &entry_type);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to get acl entry type, acl_id[%u].\n", params->acl_id);
        goto out;
    }
    if (entry_type != FLEX_ACL_ENTRY_TYPE_USER_E) {
        SX_LOG_ERR("ACL: ACL table access denied, entry type is not FLEX_ACL_ENTRY_TYPE_USER_E.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    rc = flex_acl_db_acl_attributes_get(params->acl_id, &params->acl_attributes);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_commit_set_internal(sx_acl_id_t acl_id, boolean_t is_commit)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_table_t *acl_table = NULL;

    SX_LOG_ENTER();

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_acl_get(acl_id, &acl_table);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed getting ACL for commit set, acl id[%d]\n", acl_id);
        goto out;
    }

    /* Change the commit state only if necessary */
    if (acl_table->is_commit != is_commit) {
        acl_table->is_commit = is_commit;
        /* After we've set the commit, we need to update all groups containing the ACL */
        rc = flex_acl_updated_acl_groups(acl_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed updating ACL groups for commit set, acl id[%d]\n", acl_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_group_attr_set(sx_api_acl_grp_attrib_set_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }
    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_acl_grp_attributes_set(params->acl_grp_id, &params->acl_grp_attributes);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_group_attr_get(sx_api_acl_grp_attrib_get_params_t *params)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params, "params"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_acl_grp_attributes_get(params->acl_grp_id, &params->acl_grp_attributes);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* Rules with Drop Actions are stored in a FMAP so that we can monitor them when enabled.
 * Deleting a rule with a soft/hard discard forward action must be deleted from the fmap as well
 * in the hw db.
 */
static sx_status_t __flex_acl_drop_trap_hw_db_del(flex_acl_db_flex_rule_t *rule)
{
    sx_status_t        rc = SX_STATUS_SUCCESS;
    flex_acl_rule_id_t drop_rule_id;
    uint32_t           usr_def_val = 0;


    /* Note: In the delete flow this function will be called after the
     * flex_acl_hw.c: __flex_acl_free_third_parties_action where we
     *  delete the entry from acl drop relocate db. so here simply delete from
     * the acl drop trap data db.
     */

    drop_rule_id.region_id = rule->region_id;
    drop_rule_id.offset = rule->offset;

    rc = flex_acl_hw_acl_drop_trap_usr_def_val_get(drop_rule_id, &usr_def_val);
    if (rc == SX_STATUS_SUCCESS) {
        rc = flex_acl_hw_acl_drop_trap_usr_def_val_del(drop_rule_id);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL Drop Trap Data Delete failed for region:%u, offset%u.\n",
                       drop_rule_id.region_id, drop_rule_id.offset);
            goto out;
        }
    } else if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
        rc = SX_STATUS_SUCCESS;
    } else {
        SX_LOG_ERR("ACL Drop Trap Data Get failed for region:%u, offset%u.RC = %s\n",
                   drop_rule_id.region_id, drop_rule_id.offset, sx_status_str(rc));
    }
out:
    return rc;
}

boolean_t is_system_acl_drop_monitor_trap_en(void)
{
    return g_init_flags.sys_acl_drop_trap_enabled;
}

boolean_t flex_acl_is_using_soft_drop_for_empty_container(void)
{
    return g_init_flags.use_soft_drop_for_empty_container;
}

sx_status_t flex_acl_global_attr_set(sx_api_global_acl_attrib_set_params_t *params)
{
    sx_status_t                rc = SX_STATUS_SUCCESS;
    sx_acl_global_attributes_t prev_acl_global_attributes;

    SX_LOG_ENTER();


    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }
    switch (params->cmd) {
    case SX_ACCESS_CMD_SET:
        /* get current attributes */
        rc = flex_acl_db_acl_global_attr_get(&prev_acl_global_attributes);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to get acl attributes.\n");
            goto out;
        }
        rc = flex_acl_db_acl_global_attr_set(&params->global_acl_attr);
        if (rc != SX_STATUS_SUCCESS) {
            goto out;
        }
        break;

    default:
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
        break;
    }

    if (prev_acl_global_attributes.disable_acl_drop_trap !=
        params->global_acl_attr.disable_acl_drop_trap) {
        /* Monitor state has changed. Need to update all the actions in all rules in all ACLs*/
        SX_LOG_DBG("GLOBAL ACL Drop Trap State changed. Prev: %s, New %s\n",
                   (prev_acl_global_attributes.disable_acl_drop_trap ? "DISABLED" : "ENABLED"),
                   (params->global_acl_attr.disable_acl_drop_trap ? "DISABLED" : "ENABLED"));

        rc = flex_acl_hw_acl_drop_trap_action_iter_relocate(prev_acl_global_attributes.disable_acl_drop_trap,
                                                            params->global_acl_attr.disable_acl_drop_trap);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR(" Updating Drop Monitoring Trap State failed. Err = %s\n", sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_global_attr_get(sx_api_global_acl_attrib_get_params_t *params_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(params_p, "params_p"))) {
        goto out;
    }

    if (FALSE == g_flex_acl_initialized) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_acl_global_attr_get(&params_p->global_acl_attr);
    if (rc != SX_STATUS_SUCCESS) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

/* When a rule is updated, the free third party's will take care of clearing
 * the acl drop relocate db. This function will check and delete the entry
 * from the acl drop trap attr db when the rule has been overwritten by a rule
 * with no ACL drop Trap action. If new rule has drop action, then we should not
 * delete the drop trap attribute db entry because the region/offset/usr-def-val
 * all are the same.
 */
static sx_status_t __flex_acl_acl_drop_db_update(flex_acl_db_flex_rule_t *old_rule_p,
                                                 flex_acl_db_flex_rule_t *new_rule_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    boolean_t   del_acl_drop_action = FALSE;

    SX_LOG_ENTER();

    rc = flex_acl_hw_rule_upd_is_acl_drop_trap_overwritten(old_rule_p, new_rule_p, &del_acl_drop_action);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL: Failed to get if acl drop action was overwritten. RC = %s \n", sx_status_str(rc));
        goto out;
    }
    if (del_acl_drop_action) {
        rc = __flex_acl_drop_trap_hw_db_del(old_rule_p);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Delete from acl drop db failed. RC = %s \n", sx_status_str(rc));
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_write_default_action(sx_acl_region_id_t region_id, boolean_t write_all_regions)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    boolean_t                 is_defer = FALSE;
    sx_flex_acl_flex_action_t default_action = {.type = SX_FLEX_ACL_ACTION_FORWARD,
                                                .fields.action_forward.action =
                                                    SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT};
    uint32_t                  iii = 0, region_count = 0;

    SX_LOG_ENTER();

    /* NOTE: If we would want to support different default actions for different regions
     * we need to consider the issu. Currently, in issu mode we configure all regions'
     * default actions on initialization and therefore per region configuration might be difficult to support.
     */
    rc = flex_acl_get_is_defer(&is_defer);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL action : Failed getting defer for init default actions.\n");
        goto out;
    }
    /* If we need to go over one region we start from region 0 and go through all of them. */
    if (write_all_regions) {
        region_id = 0;
        region_count = rm_resource_global.acl_regions_max;
    } else {
        region_count = 1;
    }

    for (iii = 0; iii < region_count; iii++, region_id++) {
        rc = flex_acl_hw_write_nop_default_action_set(region_id, &default_action, 1, is_defer);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL : Failed to write HW default action set for region id %d\n", region_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

void flex_acl_manual_unbind_set(boolean_t manual_unbind)
{
    SX_LOG_ENTER();

    g_flex_acl_manual_unbind = manual_unbind;
    SX_LOG_NTC("Manual unbind is set to %s\n", g_flex_acl_manual_unbind ? "TRUE" : "FALSE");

    SX_LOG_EXIT();
}

sx_status_t flex_acl_activity_notify(sx_access_cmd_t cmd, sx_flex_acl_activity_notify_attr_t activity_notify_attr)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_sdk_entries_param_t    action_entry_param;
    uint32_t                  actual_num_of_entries = 0;
    flex_acl_db_acl_region_t *acl_region_p = NULL;
    boolean_t                 in_progress = FALSE;
    sx_boot_mode_e            boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_LOG_ENTER();

    if (g_flex_acl_initialized == FALSE) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (g_acl_stage == ACL_STAGE_FLEX) {
        SX_LOG(SX_LOG_ERROR, "The ACL activity notify is not supported in this chip type.\n");
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG(SX_LOG_ERROR, "CMD (%s) Unsupported.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    rc = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG(SX_LOG_ERROR, "Failed to get Boot Mode err %s.\n", sx_status_str(rc));
        goto out;
    }

    if (boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        SX_LOG(SX_LOG_NOTICE, "Notifier is not allowed during ISSU flow.\n");
        goto out;
    }

    SX_MEM_CLR(action_entry_param);
    action_entry_param.resource = RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E;
    action_entry_param.attr.acl_action_attr.default_action = TRUE;
    rc = rm_sdk_table_duplication_actual_entries_num_get(RM_SDK_TABLE_TYPE_ACL_EXTENDED_ACTIONS_E,
                                                         &action_entry_param, 1, &actual_num_of_entries);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed getting action duplication factor\n");
        goto out;
    }

    if (activity_notify_attr.filter_by_region_id == SX_FLEX_ACL_KEY_FILTER_FIELD_VALID_E) {
        if (actual_num_of_entries > 1) {
            /* DDD enabled */
            rc = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Region filter is not supported in case DDD is enabled\n");
            goto out;
        }

        rc = flex_acl_db_region_get(activity_notify_attr.region_id, &acl_region_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed getting region of region id %d, err: %s\n",
                       activity_notify_attr.region_id,
                       sx_status_str(rc));
            goto out;
        }
    }

    rc = flex_acl_db_activity_notify_get(&in_progress, NULL, NULL);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get activity notify progress.\n");
        goto out;
    }
    if (in_progress) {
        rc = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_INF("An activity notification process is still running, err: %s.\n",
                   sx_status_str(rc));
        goto out;
    }

    rc = flex_acl_db_activity_notify_set(SX_ACCESS_CMD_SET, cmd, activity_notify_attr);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to store notification info to db.\n");
        goto out;
    }

    /*Add an internal job to start the polling */
    sx_core_api_add_internal_job(SX_API_INT_CMD_ACL_ACTIVITY_NOTIFY_JOB_PROCESS_E,
                                 NULL,
                                 0,
                                 SX_CORE_MED_PRIO_BUF_E);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_activity_notify_job_process()
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    kvd_linear_manager_index_t         kvd_index_arr[SX_ACL_ACTIVITY_NOTIFY_CNT_MAX];
    uint32_t                           kvd_index_num = SX_ACL_ACTIVITY_NOTIFY_CNT_MAX;
    sx_acl_region_id_t                 region_id = FLEX_ACL_INVALID_REGION_ID;
    boolean_t                          in_progress = FALSE;
    sx_access_cmd_t                    cmd = SX_ACCESS_CMD_NONE;
    sx_flex_acl_activity_notify_attr_t activity_notify_attr;
    sx_acl_action_container_id_t       container_id = FLEX_ACL_INVALID_ACTION_CONTAINER_ID;
    sx_event_info_t                    event_info;
    uint32_t                           i = 0, entry_cnt = 0;
    sx_boot_mode_e                     boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_LOG_ENTER();

    rc = issu_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get boot mode %s.\n", sx_status_str(rc));
        goto out;
    }

    if (boot_mode == SX_BOOT_MODE_ISSU_STARTED_E) {
        SX_LOG_NTC("Activity notify internal job is not allowed during ISSU reconfiguration stage\n");
        goto out;
    }

    SX_MEM_CLR(activity_notify_attr);

    rc = flex_acl_db_activity_notify_get(&in_progress, &cmd, &activity_notify_attr);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get notification process info from db.\n");
        goto out;
    }

    if (in_progress == FALSE) {
        /* Process is ended */
        goto out;
    }

    if (activity_notify_attr.filter_by_region_id == SX_FLEX_ACL_KEY_FILTER_FIELD_VALID_E) {
        region_id = activity_notify_attr.region_id;
    }

    SX_MEM_CLR_ARRAY(kvd_index_arr, SX_ACL_ACTIVITY_NOTIFY_CNT_MAX, kvd_linear_manager_index_t);

    rc = flex_acl_hw_bulk_dump_activity(region_id, FALSE, FALSE, kvd_index_arr, &kvd_index_num);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to dump activity for region id %d\n", region_id);
        goto out;
    }

    /* Create event for user */
    if (kvd_index_num > 0) {
        SX_LOG(SX_LOG_DEBUG, "Send event on %u activity notifications.\n", kvd_index_num);
        for (i = 0; i < kvd_index_num; i++) {
            rc = flex_acl_db_action_container_get_by_kvd_index(kvd_index_arr[i], &container_id);
            if (rc == SX_STATUS_ENTRY_NOT_FOUND) {
                rc = SX_STATUS_SUCCESS;
                continue;
            }
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG_ERR("Got error during action container getting from kvd index %d.\n", kvd_index_arr[i]);
                goto out;
            }
            event_info.acl_activity_notification.notify_entry[entry_cnt].action_container_id = container_id;
            entry_cnt++;
        }
        event_info.acl_activity_notification.entry_cnt = entry_cnt;

        if (entry_cnt > 0) {
            rc = host_ifc_send_event(SX_TRAP_ID_ACL_ACTIVITY,
                                     &(event_info.acl_activity_notification),
                                     sizeof(event_info.acl_activity_notification),
                                     SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
            if (SX_CHECK_FAIL(rc)) {
                SX_LOG(SX_LOG_ERROR, "Could not send ACL_ACTIVITY event.\n");
                goto out;
            }
        }
    }

    if (kvd_index_num < SX_ACL_ACTIVITY_NOTIFY_CNT_MAX) {
        /* Dump completed */
        if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
            rc = flex_acl_hw_bulk_dump_activity(region_id, TRUE, FALSE, NULL, NULL);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL : Failed to dump activity for region id %d\n", region_id);
                goto out;
            }
        }
        /* Send another event to signal the end of session */
        event_info.acl_activity_notification.entry_cnt = 0;
        rc = host_ifc_send_event(SX_TRAP_ID_ACL_ACTIVITY,
                                 &(event_info.acl_activity_notification),
                                 sizeof(event_info.acl_activity_notification),
                                 SX_EV_SEND_MODE_WITHOUT_EMAD_HDR_E);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to send ACL_ACTIVITY event.\n");
            goto out;
        }

        /* Clear request info in DB*/
        rc = flex_acl_db_activity_notify_set(SX_ACCESS_CMD_UNSET, SX_ACCESS_CMD_NONE, activity_notify_attr);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to clear request info db, err: %s.\n",
                       sx_status_str(rc));
            goto out;
        }

        goto out;
    }

    /*Add an internal job to start the polling */
    sx_core_api_add_internal_job(SX_API_INT_CMD_ACL_ACTIVITY_NOTIFY_JOB_PROCESS_E,
                                 NULL,
                                 0,
                                 SX_CORE_MED_PRIO_BUF_E);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_activity_notify_stop()
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_acl_region_id_t                 region_id = FLEX_ACL_INVALID_REGION_ID;
    sx_access_cmd_t                    cmd = SX_ACCESS_CMD_NONE;
    sx_flex_acl_activity_notify_attr_t activity_notify_attr;
    boolean_t                          in_progress = FALSE;

    SX_LOG_ENTER();

    rc = flex_acl_db_activity_notify_get(&in_progress, &cmd, &activity_notify_attr);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to get notification process info from db.\n");
        goto out;
    }

    if (in_progress == FALSE) {
        /* Process is ended */
        goto out;
    }

    if (activity_notify_attr.filter_by_region_id == SX_FLEX_ACL_KEY_FILTER_FIELD_VALID_E) {
        region_id = activity_notify_attr.region_id;
    }

    rc = flex_acl_hw_bulk_dump_activity(region_id, FALSE, TRUE, NULL, NULL);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("ACL : Failed to force end dumping activity for region id %d\n", region_id);
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        rc = flex_acl_hw_bulk_dump_activity(region_id, TRUE, FALSE, NULL, NULL);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL : Failed to dump activity for region id %d\n", region_id);
            goto out;
        }
    }

    /* Clear request info in DB*/
    rc = flex_acl_db_activity_notify_set(SX_ACCESS_CMD_UNSET, SX_ACCESS_CMD_NONE, activity_notify_attr);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to clear request info db, err: %s.\n",
                   sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_global_mask_set(sx_acl_region_id_t      region_id,
                                     sx_flex_acl_key_desc_t *keys_p,
                                     uint32_t                keys_cnt,
                                     uint8_t                 global_mask[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES])
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *acl_region = NULL;
    uint8_t                   key_value[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES] = {0};
    uint8_t                   key_mask[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES] = {0};

    SX_LOG_ENTER();

    if (g_flex_acl_initialized == FALSE) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(keys_p, "keys_p"))) {
        goto out;
    }

    if (keys_cnt == 0) {
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to get region [%u] for global mask set, err = %s\n", region_id, sx_status_str(rc));
        goto out;
    }

    /* First generate the mask key blocks using the keys provided */
    rc = flex_acl_key_generate(region_id, keys_p, keys_cnt, FLEX_ACL_KEY_BUILD_MASK_ONLY_E, key_value, key_mask);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to generate key for global mask region: %u\n", region_id);
        goto out;
    }
    /* Write the global mask to the hardware */
    rc = flex_acl_hw_global_mask_set(acl_region, key_mask);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to set global mask for region: %u\n", region_id);
        goto out;
    }
    /* If needed we return the global mask created to the caller */
    if (global_mask != NULL) {
        SX_MEM_CPY_BUF(global_mask, key_mask, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_lookup_region_id_set(sx_acl_region_id_t region_id, sx_acl_region_id_t lookup_region_id)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    flex_acl_db_acl_region_t *acl_region = NULL;

    SX_LOG_ENTER();

    if (g_flex_acl_initialized == FALSE) {
        SX_LOG_ERR("ACL module was not initialized.\n");
        rc = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    rc = flex_acl_db_region_get(region_id, &acl_region);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to get region [%u] for global mask set, err = %s\n", region_id, sx_status_str(rc));
        goto out;
    }

    /* Write the global mask to the hardware */
    rc = flex_acl_hw_lookup_region_id_set(acl_region, lookup_region_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to set lookup region id: [0x%x] [0x%x]\n", region_id, lookup_region_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


boolean_t is_flex_acl_key_custom_byte_key(sx_acl_key_t key)
{
    boolean_t    rc = FALSE;
    sx_acl_key_t custom_byte_first_key = FLEX_ACL_KEY_CUSTOM_BYTES_START;
    sx_acl_key_t custom_byte_last_key = FLEX_ACL_KEY_CUSTOM_BYTES_START +
                                        (rm_resource_global.acl_custom_bytes_set_max *
                                         rm_resource_global.acl_custom_bytes_set_size_max);

    SX_LOG_ENTER();

    if ((key >= custom_byte_first_key) && (key < custom_byte_last_key)) {
        rc = TRUE;
    }

    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_default_actions_set(sx_api_acl_flex_default_action_set_params_t *params)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    sx_acl_default_action_cfg_t default_action_cfg;

    SX_LOG_ENTER();

    /* Check that the Flex ACL initialized*/
    if (g_flex_acl_initialized == FALSE) {
        SX_LOG_ERR("Flex ACL isn't initialized.\n");
        rc = SX_STATUS_ERROR;
        goto out;
    }

    switch (params->cmd) {
    case SX_ACCESS_CMD_UNSET:
        SX_MEM_CLR(default_action_cfg);
        default_action_cfg.action_list[0].type = SX_FLEX_ACL_ACTION_FORWARD;
        default_action_cfg.action_list[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_PERMIT;
        default_action_cfg.action_count = 1;

        rc = __flex_acl_region_default_actions_rule_set(params->region_id, &default_action_cfg);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL action : Failed set rule in region id [%d] for default actions.\n", params->region_id);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_SET:
        rc = __flex_acl_region_default_actions_rule_set(params->region_id, &params->default_action_cfg);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("ACL action : Failed set rule in region id [%d] for default actions.\n", params->region_id);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Access command: [%s] is not supported by default actions set.\n", sx_access_cmd_str(params->cmd));
        rc = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t flex_acl_default_actions_get(sx_api_acl_flex_default_action_get_params_t *params)
{
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_flex_acl_rule_offset_t rule_offset;
    flex_acl_db_flex_rule_t  *rule = NULL;
    flex_acl_db_acl_region_t *acl_region = NULL;

    SX_LOG_ENTER();

    SX_MEM_CLR(params->default_action_cfg);

    if (ACL_STAGE_IS_FLEX2_OR_ABOVE(g_acl_stage)) {
        rule_offset = SX_ACL_DEFAULT_ACTION_OFFSET;
    } else {
        rc = flex_acl_db_region_get(params->region_id, &acl_region);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_DBG("ACL : Failed to find region id [%u]\n", params->region_id);
            goto out;
        }
        rule_offset = acl_region->size - 1;
    }

    rc = flex_acl_db_get_rule_by_offset(params->region_id, rule_offset, &rule);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("ACL : Failed to get rule from db for region:%u offset:%u\n",
                   params->region_id,
                   rule_offset);
        goto out;
    }

    params->default_action_cfg.action_count = rule->action_count;
    SX_MEM_CPY_ARRAY(params->default_action_cfg.action_list,
                     rule->actions,
                     params->default_action_cfg.action_count,
                     sx_flex_acl_flex_action_t);

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t flex_acl_issu_default_actions_support(boolean_t is_enabled)
{
    g_default_action_issu_support = is_enabled;
    return SX_STATUS_SUCCESS;
}

sx_status_t flex_acl_issu_pagt_v2_support(boolean_t is_enabled)
{
    g_pagt_v2_issu_support = is_enabled;
    return SX_STATUS_SUCCESS;
}

static sx_status_t __flex_acl_issu_acl_group_alignment_needed()
{
    sx_status_t    rc = SX_STATUS_SUCCESS;
    sx_boot_mode_e issu_boot_mode;
    sx_issu_bank_e align_issu_bank, clear_issu_bank;

    /* If the previous SDK version worked with PAGT group mechanism */
    if (g_pagt_v2_issu_support == FALSE) {
        rc = issu_boot_mode_get(&issu_boot_mode);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("ACL: failed to issu_boot_mode_get for ACL group bank alignment, sx_status = %s\n",
                       sx_status_str(rc));
            goto out;
        }
        if (issu_boot_mode != SX_BOOT_MODE_DISABLED_E) {
            /* If we're in ISSU mode we need to align the previous bank's
             * bind attributes to the correct bank.
             */
            rc = issu_bank_get(&clear_issu_bank);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL:failed to issu_bank_get for ACL group bank alignment, sx_status = %s\n",
                           sx_status_str(rc));
                goto out;
            }
            /* We need to align the bank from previous life */
            align_issu_bank = (clear_issu_bank == SX_ISSU_BANK_1_E) ? SX_ISSU_BANK_2_E : SX_ISSU_BANK_1_E;
            rc = flex_acl_hw_issu_bind_attributes_align(align_issu_bank, clear_issu_bank);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("ACL:failed group bank alignment, bank = [%u], sx_status = %s\n",
                           align_issu_bank, sx_status_str(rc));
                goto out;
            }
        }
    }
out:
    /* In any case the alignment check is done only once */
    g_pagt_v2_issu_alignment_check = FALSE;
    return rc;
}
