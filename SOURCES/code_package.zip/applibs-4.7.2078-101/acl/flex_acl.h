/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __FLEX_ACL_H_INCL__
#define __FLEX_ACL_H_INCL__

#include "flex_acl_gen_def.h"
#include "acl.h"
#include "system_acl.h"
#include "sx/sdk/sx_flex_acl.h"
#include <sx_api/sx_api_internal.h>
#include <span/span.h>
#include <mc_container/hwd/hwd_mc_container.h>
#include "ethl3/hwi/ecmp/router_ecmp.h"
#include "flex_acl_common.h"


/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/
#define RESERVED_FLEX_ACL_RULES_NUM         1
#define ACL_TUNNEL_REF                      "ACL_TUNNEL_REF"
#define ACL_VRID_REF                        "ACL_VRID_REF"
#define ACL_MC_REF                          "ACL_MC_REF"
#define ACL_RIF_REF                         "ACL_RIF_REF"
#define ACL_ECMP_REF                        "ACL_ECMP_REF"
#define ACL_GP_REGISTER_REF                 "ACL_GP_REGISTER_REF"
#define ACL_FLEX_MODIFIER_EMT_REF           "ACL_EMT_REF"
#define ACL_NAT_REF                         "ACL_NAT_REF"
#define ACL_STATEFUL_DB_REF                 "ACL_STATEFUL_DB_REF"
#define ACL_SYSTEM_IGMPV3_PBS_TOKEN         0x8000
#define ACL_SYSTEM_TOKEN_MASK               0xF000
#define ACL_USER_TOKEN_MASK                 0x0FFF
#define L4_PORT_MAX_MASK                    0xFFFF
#define IP_PROTO_MAX_MASK                   0xFF
#define TTL_MAX_MASK                        0xFF
#define PORT_USER_MEM_MAX_MASK              0xFF
#define TCP_CONTROL_MAX_MASK                0x3F
#define ETHERTYPE_MAX_MASK                  0xFFFF
#define VID_MAX_MASK                        0xFFF
#define DEI_MAX_MASK                        0x1
#define PCP_MAX_MASK                        0x7
#define MIRROR_SAMPLER_PROBABILITY_RATE_MAX 0xFFFFFF
/************************************************
 *  Type definitions
 ***********************************************/
typedef struct {
    sx_acl_region_id_t        region_id;
    sx_flex_acl_rule_offset_t offset;
} flex_acl_rule_id_t;

typedef uint32_t flex_acl_bind_attribs_id_t;

typedef enum flex_rule_priority_mode {
    FLEX_RULES_PRIORITY_MODE_UNSET    = 0,
    FLEX_RULES_PRIORITY_MODE_PRIORITY = 1,
    FLEX_RULES_PRIORITY_MODE_LEGACY   = 2
} flex_rule_priority_mode_e;

typedef enum flex_acl_entry_type {
    FLEX_ACL_ENTRY_TYPE_USER_E      = 0,
    FLEX_ACL_ENTRY_TYPE_SYSTEM_E    = 1,
    FLEX_ACL_ENTRY_TYPE_AGGREGATE_E = 2,    /**< Internal aggregate groups */
    FLEX_ACL_ENTRY_TYPE_MAX_E       = FLEX_ACL_ENTRY_TYPE_AGGREGATE_E,
    FLEX_ACL_ENTRY_TYPE_LAST_E,
} flex_acl_entry_type_e;

/*
 * sx_acl_pbs_extended_entry_type_t enumerated type is used to note PBS
 * extended entry type
 */
typedef enum {
    SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL           = 0, /**< Unicast tunnel entry  */
    SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_MULTICAST_TUNNEL         = 1, /**< Multicast entry  */
    SX_ACL_PBS_ENTRY_TYPE_EXTENDED_NVE_UNICAST_TUNNEL_WITH_ECMP = 2, /**< Unicast tunnel entry with ECMP */
    SX_ACL_PBS_ENTRY_TYPE_EXTENDED_LAST
} sx_acl_pbs_entry_type_extended_t;

typedef enum {
    ACL_CUSTOM_BYTES_SET_0,
    ACL_CUSTOM_BYTES_SET_1,
    ACL_CUSTOM_BYTES_SET_2,
    ACL_CUSTOM_BYTES_SET_3,
    ACL_CUSTOM_BYTES_SET_4,
    ACL_CUSTOM_BYTES_SET_5,
    ACL_CUSTOM_BYTES_SET_6,
    ACL_CUSTOM_BYTES_SET_7,
    ACL_CUSTOM_BYTES_SET_8,
    ACL_CUSTOM_BYTES_SET_9,
    ACL_CUSTOM_BYTES_SET_10,
    ACL_CUSTOM_BYTES_SET_11,
    ACL_CUSTOM_BYTES_SET_LAST,
} acl_custom_bytes_set_id_e;

typedef struct {
    sx_acl_key_t start_key_id;
    uint32_t     size;
} acl_custom_bytes_set_data_t;

typedef struct {
    acl_extraction_point_type_t  extraction_point;
    sx_acl_custom_bytes_offset_t offset;
} flex_acl_extraction_point_t;

typedef union {
    sx_rif_id_t         rif_id;
    sx_port_id_t        port_id;
    sx_acl_vlan_group_t vlan_group_id;
} flex_acl_bind_point_id;

typedef struct {
    sx_status_t (*acl_stage_get_p)(acl_stage_e *acl_stage_p);
    boolean_t (*acl_wc_rule_needed_p)(void);
    boolean_t (*acl_default_action_needed_p)(void);
    sx_status_t (*system_acl_set_mc_register_callbacks_p)(system_acl_client_id_e client_id,
                                                          system_acl_hw_cb_t    *system_acl_hw_cb_p,
                                                          boolean_t             *change_needed);
} flex_acl_ops_t;

typedef enum {
    FLEX_ACL_KEY_BUILD_VALUE_MASK_E,   /* Validate and create both the value and mask of the key */
    FLEX_ACL_KEY_BUILD_VALUE_ONLY_E,   /* Validate and create the value part of the key only*/
    FLEX_ACL_KEY_BUILD_MASK_ONLY_E,    /* Validate and create the mask part of the key only*/
    FLEX_ACL_KEY_BUILD_LAST_E
} flex_acl_key_build_mode_e;

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t flex_acl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t flex_acl_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level);

sx_status_t flex_acl_enable_system(boolean_t enable);

sx_status_t flex_acl_init(sx_api_sx_sdk_init_t *init_params);
sx_status_t flex_acl_init_with_callbacks(sx_api_sx_sdk_init_t *init_params, acl_cb_t *acl_cbs_p);
void flex_acl_deinit(void);

sx_status_t flex_acl_key_layout_constructor(acl_stage_e               acl_stage,
                                            sx_flex_acl_key_desc_t   *keys,
                                            uint32_t                  keys_count,
                                            sx_acl_key_block_e       *key_blocks,
                                            uint32_t                  key_blocks_count,
                                            uint8_t                  *key,
                                            uint8_t                  *mask,
                                            flex_acl_key_build_mode_e build_mode);

sx_status_t flex_acl_keys_extractor(acl_stage_e             acl_stage,
                                    sx_flex_acl_key_desc_t *keys,
                                    uint32_t                keys_count,
                                    sx_acl_key_block_e     *key_blocks,
                                    uint32_t                key_blocks_count,
                                    uint8_t                *key);

sx_status_t flex_acl_key_set(sx_api_flex_acl_key_set_params_t *params);
sx_status_t flex_acl_key_ext_set(sx_api_flex_acl_key_set_params_t *params, boolean_t is_symmetric);
sx_status_t flex_acl_symmetric_key_handle_create(sx_acl_key_type_t key_handle, sx_acl_key_type_t *new_key_handle_p);
sx_status_t flex_acl_key_get(sx_api_flex_acl_key_get_params_t *param);

sx_status_t flex_acl_region_set(sx_api_acl_region_set_params_t *params);
sx_status_t flex_acl_region_set_internal(sx_api_acl_region_set_params_t *params,
                                         system_acl_client_id_e          client_id);
sx_status_t flex_acl_stateful_db_region_set_internal(sx_api_acl_region_set_params_t *params);
sx_status_t flex_acl_region_wc_rule_set(sx_acl_region_id_t region_id);
sx_status_t flex_acl_write_default_action(sx_acl_region_id_t region_id, boolean_t write_all_regions);
sx_status_t flex_acl_region_get(sx_api_acl_region_set_params_t *params);
sx_status_t flex_acl_region_get_internal(sx_api_acl_region_set_params_t *params);


sx_status_t flex_acl_vlan_group_set(sx_api_acl_vlan_group_set_params_t *params);
sx_status_t flex_acl_vlan_group_set_internal(sx_api_acl_vlan_group_set_params_t *params,
                                             system_acl_client_id_e              client_id);
sx_status_t flex_acl_vlan_group_get(sx_acl_vlan_group_t group_id,
                                    sx_swid_id_t        swid,
                                    sx_vlan_id_t       *vlan_list,
                                    uint32_t           *vlan_num);

sx_status_t flex_acl_rules_set(sx_api_flex_acl_rules_set_params_t *params);
sx_status_t flex_acl_rules_set_internal(sx_api_flex_acl_rules_set_params_t *params);
sx_status_t flex_acl_rules_get(sx_api_flex_acl_rules_get_params_t *params);
sx_status_t flex_acl_rules_get_internal(sx_api_flex_acl_rules_get_params_t *params);

void flex_acl_copy_key_to_block(uint8_t  *block,
                                int       block_bit_offset,
                                uint8_t   block_shift,
                                uint8_t  *key,
                                uint32_t  key_bit_offset,
                                uint32_t  len,
                                uint16_t  key_size,
                                boolean_t is_end);

sx_status_t flex_acl_set(sx_api_flex_acl_set_params_t *params);
sx_status_t flex_acl_set_internal(sx_api_flex_acl_set_params_t *params);
sx_status_t flex_acl_get(sx_api_flex_acl_set_params_t *params);
sx_status_t flex_acl_get_internal(sx_api_flex_acl_set_params_t * params);
sx_status_t flex_acl_iter_get(sx_api_acl_iter_get_params_t *params);

sx_status_t flex_acl_redirect_region_set(sx_api_acl_region_set_params_t *params);
sx_status_t flex_acl_redirect_region_get(sx_api_acl_region_set_params_t *params);
sx_status_t flex_acl_redirect_acl_set(sx_api_acl_set_params_t *params);
sx_status_t flex_acl_redirect_acl_get(sx_api_acl_set_params_t *params);

sx_status_t flex_acl_group_set(sx_api_acl_group_params_t *params);
sx_status_t flex_acl_group_set_internal(sx_api_acl_group_params_t * params);
sx_status_t flex_acl_group_get(sx_api_acl_group_params_t *params);
sx_status_t flex_acl_group_get_internal(sx_api_acl_group_params_t * params);
sx_status_t flex_acl_group_iter_get(sx_api_acl_group_iter_get_params_t *params);

sx_status_t flex_acl_group_bind_set(sx_api_flex_acl_group_bind_params_t *params);
sx_status_t flex_acl_group_bind_set_internal(sx_api_flex_acl_group_bind_params_t * params);
sx_status_t flex_acl_group_bind_get(sx_api_flex_acl_group_bind_params_t *params);
sx_status_t flex_acl_group_bind_get_internal(sx_api_flex_acl_group_bind_params_t *params);

sx_status_t flex_acl_port_bind_internal(sx_port_log_id_t log_port,
                                        sx_acl_id_t      group_id,
                                        boolean_t        write_to_reg);
sx_status_t flex_acl_bind_port(sx_api_acl_bind_params_t *params);
sx_status_t flex_acl_bind_port_internal(sx_api_acl_bind_params_t *params);
sx_status_t flex_acl_unbind_port(sx_api_acl_bind_params_t *params);
sx_status_t flex_acl_unbind_port_internal(sx_api_acl_bind_params_t *params);
sx_status_t flex_acl_port_unbind_internal(sx_acl_id_t                group_id,
                                          sx_port_log_id_t           log_lag_port,
                                          flex_acl_bind_attribs_id_t attribs_id);
sx_status_t flex_acl_bind_port_get(sx_api_acl_bind_get_params_t *params);


sx_status_t flex_acl_bind_rif(sx_api_flex_acl_bind_params_t *params);
sx_status_t flex_acl_bind_rif_internal(sx_api_flex_acl_bind_params_t *params);
sx_status_t flex_acl_rif_bind_internal(sx_rif_id_t rif,
                                       sx_acl_id_t group_id,
                                       boolean_t   write_to_reg);
sx_status_t flex_acl_unbind_rif(sx_api_flex_acl_bind_params_t *params);
sx_status_t flex_acl_unbind_rif_internal(sx_api_flex_acl_bind_params_t *params, boolean_t full_unbind);
sx_status_t flex_acl_rif_unbind_internal(sx_acl_id_t                group_id,
                                         sx_rif_id_t                log_lag_port,
                                         flex_acl_bind_attribs_id_t attribs_id);
sx_status_t flex_acl_bind_rif_get(sx_api_acl_bind_get_params_t *params);

sx_status_t flex_acl_rule_activity_dump(sx_api_acl_rule_activity_dump_params_t *params);
sx_status_t flex_acl_rule_activity_get(sx_api_acl_rule_activity_get_params_t *params);
sx_status_t flex_acl_rule_activity_get_internal(sx_api_acl_rule_activity_get_params_t *params);

sx_status_t flex_acl_rules_move(sx_api_acl_block_move_params_t *params);
sx_status_t flex_acl_rules_move_internal(sx_api_acl_block_move_params_t *params, boolean_t change_priority);

sx_status_t flex_acl_bind_vlan_group(sx_api_acl_bind_params_t *params, boolean_t rebinding);
sx_status_t flex_acl_bind_vlan_group_internal(sx_api_acl_bind_params_t *params, boolean_t rebinding);
sx_status_t flex_acl_unbind_vlan_group(sx_api_acl_bind_params_t *params);
sx_status_t flex_acl_unbind_vlan_group_internal(sx_api_acl_bind_params_t *params);
sx_status_t flex_acl_bind_vlan_group_get(sx_api_acl_bind_get_params_t *params);

sx_status_t flex_acl_l4_port_range_set(sx_api_acl_l4_range_params_t *params);
sx_status_t flex_acl_l4_port_range_get(sx_api_acl_l4_range_params_t *params);
sx_status_t flex_acl_l4_port_range_iter_get(sx_api_acl_l4_port_range_iter_get_params_t *params);
sx_status_t flex_acl_range_set(sx_api_acl_range_params_t *params);
sx_status_t flex_acl_range_get(sx_api_acl_range_params_t *params);
sx_status_t flex_acl_pbs_set(sx_api_acl_pbs_set_params_t *params);
sx_status_t flex_acl_pbs_get(sx_api_acl_pbs_get_params_t *params);
sx_status_t flex_acl_pbs_iter_get(sx_api_acl_pbs_iter_get_params_t *params);

sx_status_t flex_acl_pbilm_set(sx_api_acl_pbilm_set_params_t *params);
sx_status_t flex_acl_pbilm_get(sx_api_acl_pbilm_get_params_t *params);

sx_status_t flex_acl_region_initial_activity_set(sx_acl_region_id_t region_id, boolean_t activity_cleared);

sx_status_t flex_acl_debug_dump(dbg_dump_params_t *dbg_dump_params_p);
void sx_fuse_flex_acl_debug_dump_self(dbg_dump_params_t *dbg_dump_params_p);

boolean_t flex_acl_is_extended_action(void);

span_client_handle_t flex_acl_get_span_user_handle(void);

sx_status_t flex_acl_pbs_get_mcast_ports(sx_swid_t       swid,
                                         sx_acl_pbs_id_t pbs_id,
                                         sx_fid_t        fid,
                                         uint16_t       *port_cnt,
                                         sx_port_id_t   *port_list);
sx_status_t flex_acl_mc_container_pbs_add(sx_mc_container_id_t mc_container_id, sx_acl_pbs_id_t *pbs_id,
                                          sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_ecmp_container_pbs_add(sx_ecmp_id_t                   ecmp_id,
                                            sx_acl_pbs_id_t               *pbs_id_p,
                                            sx_flex_acl_flex_action_type_t api_action_type);
sx_status_t flex_acl_pbs_del(sx_acl_pbs_id_t pbs_id);

sx_status_t flex_acl_clean_nve_action(sx_ip_next_hop_ip_tunnel_t ip_tunnel_id);
sx_status_t flex_acl_clean_ecmp_action(hwi_ecmp_hw_block_handle_t     ecmp_handle,
                                       sx_flex_acl_flex_action_type_t api_action_type,
                                       flex_acl_rule_id_t             rule_id);
sx_status_t flex_acl_nve_tunnel_pbs_add(sx_ip_next_hop_ip_tunnel_t tunnel_info, sx_acl_pbs_id_t *pbs_id);
sx_status_t flex_acl_nve_tunnel_pbs_del(sx_acl_pbs_id_t pbs_id);

sx_status_t flex_acl_set_region_entry_type(sx_acl_region_id_t region_id, flex_acl_entry_type_e entry_type);
sx_status_t flex_acl_set_acl_entry_type(sx_acl_region_id_t region_id, flex_acl_entry_type_e entry_type);

sx_status_t flex_acl_remove_basic_key(sx_acl_key_type_t key_handle);
sx_status_t flex_acl_create_basic_key(acl_stage_e acl_stage,
                                      sx_acl_key_t keys[], uint32_t keys_count, sx_acl_key_type_t *key_type);
sx_status_t flex_acl_update_all_groups_with_system_acl(sx_acl_direction_t direction);
sx_status_t flex_acl_updated_acl_groups(sx_acl_id_t acl_id);
sx_status_t flex_acl_rx_list_set(sx_api_rx_list_set_params_t *params);
sx_status_t flex_acl_rx_list_get(sx_api_rx_list_set_params_t *params);
sx_status_t flex_acl_get_is_defer(boolean_t *is_defer);

sx_status_t flex_acl_key_attribs_get(sx_api_acl_flex_key_attr_get_params_t *params);

sx_status_t flex_acl_key_sizes_get(sx_acl_key_type_t        key_handle,
                                   uint32_t                *blocks_count_p,
                                   sx_acl_flex_key_width_t *key_width_p);

sx_status_t flex_acl_custom_bytes_set(sx_api_custom_bytes_set_params_t *params);
sx_status_t flex_acl_custom_bytes_get(sx_api_custom_bytes_set_params_t *params);
sx_status_t flex_acl_rules_priority_set(sx_api_acl_flex_rules_priority_set_params_t *params);

sx_status_t flex_acl_clean_mc_container_action(sx_mc_container_id_t           mc_container_id,
                                               sx_flex_acl_flex_action_type_t api_action_type,
                                               flex_acl_rule_id_t             rule_id);


sx_status_t system_acl_create_default_vlan_group(system_acl_client_id_e client_id);
sx_status_t system_acl_delete_default_vlan_group(system_acl_client_id_e client_id);
sx_status_t system_acl_add_vlan_to_default_vlan_group(system_acl_client_id_e client_id,
                                                      sx_acl_vlan_group_t    vlan_group_id,
                                                      sx_swid_id_t           swid,
                                                      sx_vlan_id_t          *vlan_list,
                                                      uint32_t               vlan_num);
sx_status_t system_acl_remove_vlan_from_default_vlan_group(system_acl_client_id_e client_id,
                                                           sx_acl_vlan_group_t    vlan_group_id,
                                                           sx_swid_id_t           swid,
                                                           sx_vlan_id_t          *vlan_list,
                                                           uint32_t               vlan_num);
/* adds vlan to user vlan group */
sx_status_t system_acl_add_vlan_to_user_vlan_group(sx_acl_vlan_group_t vlan_group_id,
                                                   sx_swid_id_t        swid,
                                                   sx_vlan_id_t       *vlan_list,
                                                   uint32_t            vlan_num);
sx_status_t system_acl_remove_vlan_from_user_vlan_group(sx_acl_vlan_group_t vlan_group_id,
                                                        sx_swid_id_t        swid,
                                                        sx_vlan_id_t       *vlan_list,
                                                        uint32_t            vlan_num);
boolean_t flex_acl_is_initialized(void);
sx_status_t flex_acl_region_get_hw_size(sx_api_acl_region_hw_size_get_params_t *params);

sx_status_t flex_acl_port_exists_in_container(sx_mc_container_id_t container_id,
                                              sx_port_id_t         log_port,
                                              boolean_t           *is_exist);

void flex_acl_handle_endianess(uint8_t *key, uint16_t size);

sx_status_t flex_acl_egress_mirror_handle_buffer(sx_access_cmd_t cmd, sx_port_log_id_t log_port);

sx_status_t flex_acl_keys_custom_byte_id_is_valid(sx_acl_key_t key);
sx_status_t flex_acl_keys_custom_bytes_set_lock_unlock(sx_acl_key_t    key,
                                                       sx_access_cmd_t cmd,
                                                       boolean_t       validate_only);
sx_status_t flex_acl_key_id_to_custom_byte_set(sx_acl_key_t               custom_bytes_set_key_id,
                                               acl_custom_bytes_set_id_e *custom_bytes_set_id);

sx_status_t flex_acl_key_directions_get(const sx_acl_key_t        key_id,
                                        sx_acl_multi_direction_t *directions_p);
sx_status_t flex_acl_key_port_list_get_info(const sx_flex_acl_key_desc_t *key_p,
                                            sx_mc_container_id_t         *mc_container_id_p,
                                            sx_acl_port_list_match_t     *match_type_p,
                                            boolean_t                    *mask_boolean_p);

sx_status_t flex_acl_global_mask_set(sx_acl_region_id_t      region_id,
                                     sx_flex_acl_key_desc_t *keys_p,
                                     uint32_t                keys_cnt,
                                     uint8_t                 global_mask[SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES]);
sx_status_t flex_acl_lookup_region_id_set(sx_acl_region_id_t region_id,
                                          sx_acl_region_id_t lookup_region_id);
sx_status_t flex_acl_init_ops(void);
sx_status_t flex_acl_set_ops(flex_acl_ops_t* ops_p);

sx_status_t flex_acl_get_rm_attrs(rm_sdk_table_type_e    resource,
                                  sx_hw_entries_param_t *hw_params);

sx_status_t flex_acl_get_rm_resource(uint32_t key_handle, rm_sdk_table_type_e *resource);
sx_status_t flex_acl_get_key_kvd_size(uint32_t key_handle, uint32_t *kvd_size_p);
sx_status_t flex_acl_validate_port(sx_port_log_id_t log_port);

sx_status_t flex_acl_issu_bind_router_trigger(sx_access_cmd_t cmd);
sx_status_t flex_acl_issu_bind_router_trigger_spc2(sx_access_cmd_t cmd);
sx_status_t flex_acl_issu_bind_acl_set(sx_access_cmd_t cmd);

sx_status_t flex_acl_create_shadow_acl_region(sx_acl_region_id_t  region_id,
                                              sx_acl_region_id_t *shadow_region_id,
                                              sx_acl_id_t        *shadow_acl_id);
sx_status_t flex_acl_remove_shadow_acl_region(sx_acl_region_id_t region_id,
                                              sx_acl_region_id_t shadow_region_id);
sx_status_t flex_acl_attr_set(sx_api_acl_attrib_set_params_t *params);
sx_status_t flex_acl_attr_get(sx_api_acl_attrib_get_params_t *params);
sx_status_t flex_acl_commit_set_internal(sx_acl_id_t acl_id, boolean_t is_commit);
sx_status_t flex_acl_group_attr_set(sx_api_acl_grp_attrib_set_params_t *params);
sx_status_t flex_acl_group_attr_get(sx_api_acl_grp_attrib_get_params_t *params);
boolean_t is_system_acl_drop_monitor_trap_en(void);
boolean_t flex_acl_is_using_soft_drop_for_empty_container(void);
sx_status_t flex_acl_global_attr_set(sx_api_global_acl_attrib_set_params_t *params);
sx_status_t flex_acl_global_attr_get(sx_api_global_acl_attrib_get_params_t *params);
sx_status_t flex_acl_check_priveleges(sx_acl_id_t group_id);
sx_status_t flex_acl_mc_container_ptr_update(sx_mc_container_id_t           mc_container_id,
                                             hw_mc_list_pointer_t          *old_pointer,
                                             hw_mc_list_pointer_t          *new_pointer,
                                             sx_flex_acl_flex_action_type_t api_action_type);
void flex_acl_manual_unbind_set(boolean_t manual_unbind);

sx_status_t flex_acl_activity_notify(sx_access_cmd_t cmd, sx_flex_acl_activity_notify_attr_t activity_notify_attr);
sx_status_t flex_acl_activity_notify_job_process();
sx_status_t flex_acl_activity_notify_stop();
boolean_t is_flex_acl_key_custom_byte_key(sx_acl_key_t key);
boolean_t flex_acl_is_port_direction(sx_acl_direction_t direction);
boolean_t flex_acl_is_rif_direction(sx_acl_direction_t direction);
boolean_t flex_acl_is_vlan_direction(sx_acl_direction_t direction);

sx_status_t flex_acl_default_actions_set(sx_api_acl_flex_default_action_set_params_t *params);
sx_status_t flex_acl_default_actions_get(sx_api_acl_flex_default_action_get_params_t *params);
sx_status_t flex_acl_issu_default_actions_support(boolean_t is_enabled);
sx_status_t flex_acl_issu_pagt_v2_support(boolean_t is_enabled);

#endif /* ifndef __FLEX_ACL_H_INCL__ */
