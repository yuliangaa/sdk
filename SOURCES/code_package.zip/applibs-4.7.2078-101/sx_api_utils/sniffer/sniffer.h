/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef SNIFFER_H
#define SNIFFER_H

extern boolean_t g_sniffer_enabled;

boolean_t sdk_sniffer_legacy_enable_check();
sx_status_t sdk_sniffer_legacy_param_get(sx_dbg_api_logger_params_t *params_p);
sx_status_t sdk_sniffer_stop_if_needed();

sx_status_t sdk_sniffer_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t sdk_sniffer_params_set(const sx_access_cmd_t             cmd,
                                   const sx_dbg_api_logger_params_t *params_p,
                                   boolean_t                         legacy_call);
sx_status_t sdk_sniffer_params_get(sx_dbg_api_logger_params_t *params_p);

void sdk_sniffer_debug_dump(dbg_dump_params_t *dbg_dump_params_p);

void sdk_sniffer_api_dispatch(const sx_api_command_head_t * const p_head,
                              const uint8_t * const               p_body,
                              uint32_t                            body_size);
void sdk_sniffer_api_reply(const sx_api_reply_head_t *reply_head,
                           uint32_t                   head_size,
                           const uint8_t             *reply_body,
                           uint32_t                   reply_body_size);

void sysfs_sniffer_access_dispatch(const sx_api_sysfs_head_t* const p_sysfs_head,
                                   uint8_t                        * write_buffer,
                                   struct timespec                  timestamp);

void events_sniffer_access_dispatch(const sx_api_events_head_t* const p_events_head);


sx_status_t sysfs_sniffer_recording_set(sx_access_cmd_t cmd);


sx_status_t sdk_api_sniffer_folder_path_set(char *file_path_p);
sx_status_t sdk_mkdir_p(const char *path, int mode);

#endif /* SNIFFER_H */
