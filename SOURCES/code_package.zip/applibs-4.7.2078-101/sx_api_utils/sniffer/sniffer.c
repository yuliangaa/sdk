/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <stdio.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <signal.h>
#include <dirent.h>
#include <ethl2/brg.h>
#include <zlib.h>

#include "sx_core/sx_core_td.h"
#include "sx_core/sx_core_api.h"
#include "sx_api_utils/include/hook.h"
#include "sx_api_utils/include/pcap.h"
#include "sx_api/sx_api_internal.h"
#include "sniffer.h"
#include <complib/cl_dbg.h>
#include <sx/sxd/sxd_access_register.h>

#undef  __MODULE__
#define __MODULE__ SNIFFER

/************************************************
 *  Global variables
 ***********************************************/
#define SX_ZLIB_CHUNK 16384

/************************************************
 *  Local variables
 ***********************************************/
/*
 * Initially, i thought i'll need to lock dispatch. so it won't run more than once in the same time,
 * but it seems like it's not necessary. (Since there is only 1 worker now)
 * So For now, It is disabled. (Until there will be more than 1 worker)
 * */
#define LOCK_DISPATCH (SX_CORE_TD_WORKER_NUM > 1)
#if LOCK_DISPATCH
#error "The new sniffer was not designed and verified with the LOCK_DISPATCH option"
#endif

#define SDK_SYS_INFO_PATH         ("SDK_SYS_INFO_PATH")
#define SX_SNIFFER_WRITE_INTERVAL ("SX_SNIFFER_WRITE_INTERVAL")
#define SX_SNIFFER_LOG_MODE       ("SX_SNIFFER_LOG_MODE")
#define SX_SNIFFER_FILTER_MODE    ("SX_SNIFFER_FILTER_MODE")
#define SX_SNIFFER_FILTER_FILE    ("SX_SNIFFER_FILTER_FILE")
#define SX_SNIFFER_LOG_NUM        ("SX_SNIFFER_LOG_NUM")
#define SX_SNIFFER_LOG_MAX_SIZE   ("SX_SNIFFER_LOG_MAX_SIZE")

#define SNIFFER_API_QUEUE_SIZE     (5 * 1024 * 1024)            /* 5 Mbyte */
#define SNIFFER_API_NUM            (SX_API_INT_CMD_MAX_E + 1)
#define SNIFFER_API_MARKER         (1)
#define SNIFFER_API_SLOT_SIZE      (SX_API_MESSAGE_SIZE_LIMIT + sizeof(pcap_pkthdr_t))
#define SNIFFER_DEFAULT_LOG_NUM    (10)
#define SNIFFER_DEFAULT_LOG_SIZE   (300 * 1024 * 1024)
#define SNIFFER_DEFAULT_PATH       "/var/log/sdk_dbg" /*sniffer may start before sx_api_sx_sdk_init*/
#define SNIFFER_DEFAULT_FILE       "sx_sdk"
#define SNIFFER_DEFAULT_INTERVAL   1000 /*1S for cyclic mode, 0 for linear mode*/
#define SNIFFER_DEFAULT_FILTER     "/usr/bin/sx_def_filter"
#define SNIFFER_MAX_FILES          50
#define SNIFFER_DEFAULT_MACSEC_KEY 0x11

#define SNIFFER_RETURN_IF_NOT_INITIALIZED()         \
    if (FALSE == g_sniffer_db.initialized) {        \
        SX_LOG_ERR("Sniffer is not initialized\n"); \
        return SX_STATUS_MODULE_UNINITIALIZED;      \
    }

#define SNIFFER_API_QUEUE_RESET() \
    memset(g_sniffer_db.api_queue, 0, SNIFFER_API_QUEUE_SIZE)

#define SNIFFER_API_DROP_COUNTER_INC() \
    g_sniffer_db.apis_drop_counters[g_sniffer_db.last_api_opcode]++

#define SNIFFER_RETURN_IF_API_SHOULD_BE_SKIPPED() \
    if (g_sniffer_db.apis_filter_marker[g_sniffer_db.last_api_opcode]) return

static int __api_fd;

typedef struct {
    char   name[SX_DBG_API_LOG_FILENAME_MAX];
    time_t update_time;
} sniffer_file_info_t;

typedef struct {
    boolean_t                  initialized;
    boolean_t                  error;
    sx_dbg_api_logger_params_t params;

    /* Handle to the output pcap file */
    uint32_t      log_file_size_max;
    uint16_t      log_file_num;
    char          current_log_file_path[SX_DBG_API_LOG_FILENAME_MAX];
    FILE        * current_log_file_fd;
    uint32_t      current_log_file_size;
    uint16_t      current_log_file_idx;
    cl_spinlock_t current_log_file_wr_lock;

    /* Needed data per client */
    buffer_side_e expected_side;

    /*Sysfs sniffer*/
    boolean_t sysfs_sniffer_enable;
    boolean_t sysfs_sniffer_include_read;

    /* Async infra */
    boolean_t     exit_signal_issued;
    cl_thread_t   sniffer_thread;
    cl_spinlock_t api_queue_lock;
    uint8_t      *api_queue;
    uint32_t      api_queue_head;
    uint32_t      api_queue_tail;
    uint8_t       api_slot[SNIFFER_API_SLOT_SIZE];

    /* Statistics and filtering */
    uint32_t last_api_opcode;
    uint32_t apis_drop_counters[SNIFFER_API_NUM];
    uint8_t  apis_filter_marker[SNIFFER_API_NUM];
    uint32_t idx;
} sniffer_db_t;

typedef struct _sx_gzip_ctx {
    cl_thread_t gzip_thread;
    char        source[SX_DBG_API_LOG_FILENAME_MAX + 1];
} sx_gzip_ctx;

boolean_t           g_sniffer_enabled;
static sniffer_db_t g_sniffer_db;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
/************************************************
 *  Local function declarations
 ***********************************************/
inline static sx_status_t __sdk_sniffer_writefile(const unsigned char * const buffer,  uint32_t buffer_len);
static sx_status_t __sdk_sniffer_init_file(const sx_dbg_api_logger_params_t *params_p);
inline static void __sdk_sniffer_sniff_buffer(buffer_side_e         side,
                                              const uint8_t * const p_head,
                                              uint32_t              head_size,
                                              const uint8_t * const p_body,
                                              uint32_t              body_size,
                                              struct timespec      *ext_timestamp);
static void __sdk_sniffer_thread(void *context);
static sx_status_t __sdk_sniffer_async_register();
static void __sdk_sniffer_async_unregister(boolean_t on_error);
static void __sdk_sniffer_on_error();
inline static sx_status_t __sdk_sniffer_flush_file();
inline static sx_status_t __sdk_sniffer_open_file();
inline static void __sdk_sniffer_close_file();
static void __sdk_sniffer_stop(boolean_t on_error);
static sx_status_t __sdk_sniffer_filter_file_upload(void);
inline static int __sdk_sniffer_api_queue_pop();
inline static void __sdk_sniffer_apis_data_reset();
inline static void __sdk_sniffer_logger_reset();
inline static void __sdk_sniffer_apis_filter_marker_invert();
static void __sdk_sniffer_params_enable_selfsniff(const sx_dbg_api_logger_params_t *params_p);
static void __sdk_sniffer_params_disable_selfsniff(const sx_dbg_api_logger_params_t *params_p);
inline static void __sdk_sniffer_disable(boolean_t skip_api_queue_flush);
static sx_status_t __sdk_sniffer_self_init();

/************************************************
 *  Function implementations
 ***********************************************/
inline static void __sdk_sniffer_apis_filter_marker_invert()
{
    uint32_t idx = 0;

    for (idx = 0; idx < SNIFFER_API_NUM; idx++) {
        g_sniffer_db.apis_filter_marker[idx] = g_sniffer_db.apis_filter_marker[idx] ^ 1; /* convert 0 to 1 and 1 to 0 */
    }
}

inline static void __sdk_sniffer_apis_data_reset()
{
    SX_MEM_CLR_ARRAY(g_sniffer_db.apis_drop_counters, SNIFFER_API_NUM, uint16_t);
    SX_MEM_CLR_ARRAY(g_sniffer_db.apis_filter_marker, SNIFFER_API_NUM, uint8_t);
    g_sniffer_db.last_api_opcode = 0;
}

inline static void __sdk_sniffer_logger_reset()
{
    g_sniffer_db.params.logger_mode = SX_DBG_API_LOGGER_DISABLED_MODE;
    g_sniffer_db.expected_side = BUFFER_SIDE_CMD_E; /* We start with command */
}

inline static sx_status_t __sdk_sniffer_flush_file()
{
    if (fflush(g_sniffer_db.current_log_file_fd) == 0) {
        return SX_STATUS_SUCCESS;
    }
    return SX_STATUS_ERROR;
}

inline static sx_status_t __sdk_sniffer_writefile(const unsigned char * const buffer,  uint32_t buffer_len)
{
    if (buffer_len == fwrite(buffer, 1, buffer_len, g_sniffer_db.current_log_file_fd)) {
        return SX_STATUS_SUCCESS;
    }

    return SX_STATUS_ERROR;
}

inline static void __sdk_sniffer_close_file()
{
    if (g_sniffer_db.current_log_file_fd != NULL) {
        fclose(g_sniffer_db.current_log_file_fd);
        g_sniffer_db.current_log_file_fd = NULL;
    }
}

static void __sdk_sniffer_stop(boolean_t on_error)
{
    /* Skip if not initialized */
    if (FALSE == g_sniffer_db.initialized) {
        return;
    }

    sx_api_sniffer_enabled_set(FALSE);

    __sdk_sniffer_disable(on_error);

    sx_api_sniffer_api_reply_set(NULL);

    __sdk_sniffer_async_unregister(on_error);

    __sdk_sniffer_close_file();

    SX_LOG_NTC("Sniffing Done. Output saved to %s\n", g_sniffer_db.current_log_file_path);

    g_sniffer_db.initialized = FALSE;
    if (on_error == FALSE) {
        SX_MEM_CLR(g_sniffer_db);
        __sdk_sniffer_logger_reset();
    }
}

static void __sdk_sniffer_on_error()
{
    g_sniffer_db.error = TRUE;
    __sdk_sniffer_stop(TRUE);
}

/*create every dir along the path*/
sx_status_t sdk_mkdir_p(const char *path, int mode)
{
    char       *buf = strdup(path);
    char       *p = buf;
    sx_status_t ret = SX_STATUS_SUCCESS;

    if (buf == NULL) {
        return SX_STATUS_PARAM_NULL;
    }

    do {
        p = strchr(p + 1, '/');
        if (p) {
            *p = '\0';
        }
        if (mkdir(buf, mode) != 0) {
            if (errno != EEXIST) {
                ret = SX_STATUS_ERROR;
                break;
            }
        }
        if (p) {
            *p = '/';
        }
    } while (p);

    free(buf);

    return (ret);
}

int sniffer_compare_fileinfo(const void *a, const void *b)
{
    return ((sniffer_file_info_t *)b)->update_time - ((sniffer_file_info_t *)a)->update_time;
}

static void _sx_gzip_file_thread(void *context)
{
    sx_gzip_ctx              *gzip_ctx = (sx_gzip_ctx *)context;
    char                     *source = gzip_ctx->source;
    char                     *dest = NULL;
    int                       ret, flush;
    unsigned                  have;
    z_stream                  strm;
    unsigned char            *in = NULL;
    unsigned char            *out = NULL;
    FILE                     *sourceFile = NULL;
    FILE                     *destFile = NULL;
    cl_dbg_bp_ctl_db_entry_t *bp_ctl_db_entry_p = NULL;

    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, FALSE);

    memset(&strm, 0, sizeof(strm));
    /*larger space for appending .gz, prevent coverity warning*/
    dest = cl_malloc(sizeof(gzip_ctx->source) + 3);
    if (!dest) {
        SX_LOG_ERR("Memory error while allocating gzip_ctx\n");
        goto out;
    }

    in = cl_malloc(SX_ZLIB_CHUNK);
    if (!in) {
        SX_LOG_ERR("Memory error while allocating gzip in\n");
        goto out;
    }

    out = cl_malloc(SX_ZLIB_CHUNK);
    if (!out) {
        SX_LOG_ERR("Memory error while allocating gzip out\n");
        goto out;
    }

    snprintf(dest, sizeof(gzip_ctx->source) + 3, "%s.gz", source);

    sourceFile = fopen(source, "rb");
    if (sourceFile == NULL) {
        SX_LOG_ERR("Failed to open gzip source file %s %s\n", source, strerror(errno));
        goto out;
    }

    destFile = fopen(dest, "wb");
    if (destFile == NULL) {
        SX_LOG_ERR("Failed to open gzip destination file %s %s\n", dest, strerror(errno));
        goto out;
    }

    /* Allocate deflate state */
    strm.zalloc = Z_NULL;
    strm.zfree = Z_NULL;
    strm.opaque = Z_NULL;
    ret = deflateInit2(&strm, Z_DEFAULT_COMPRESSION, Z_DEFLATED, 15 | 16, 8, Z_DEFAULT_STRATEGY);
    if (ret != Z_OK) {
        SX_LOG_ERR("deflateInit2 Failed");
        goto out;
    }

    /* Compress until end of file */
    do {
        strm.avail_in = fread(in, 1, SX_ZLIB_CHUNK, sourceFile);
        if (ferror(sourceFile)) {
            SX_LOG_ERR("Failed to read gzip source file %s\n", strerror(errno));
            goto out;
        }
        flush = feof(sourceFile) ? Z_FINISH : Z_NO_FLUSH;
        strm.next_in = in;

        do {
            strm.avail_out = SX_ZLIB_CHUNK;
            strm.next_out = out;
            ret = deflate(&strm, flush);
            if (ret == Z_STREAM_ERROR) {
                SX_LOG_ERR("gzip state not clobbered");
                goto out;
            }
            have = SX_ZLIB_CHUNK - strm.avail_out;
            if ((fwrite(out, 1, have, destFile) != have) || ferror(destFile)) {
                SX_LOG_ERR("gzip fwrite error\n");
                goto out;
            }
        } while (strm.avail_out == 0);
        /* All input will be used */
    } while (flush != Z_FINISH);

    if (remove(source) != 0) {
        SX_LOG_ERR("\nFailed to remove gzip %s %s\n", source, strerror(errno));
    }
out:
    cl_thread_detach_n_destroy(&(gzip_ctx->gzip_thread));
    /* Clean up and close files */
    deflateEnd(&strm);
    if (in) {
        cl_free(in);
    }
    if (out) {
        cl_free(out);
    }
    if (dest) {
        cl_free(dest);
    }
    if (gzip_ctx) {
        cl_free(gzip_ctx);
    }
    if (sourceFile) {
        fclose(sourceFile);
    }
    if (destFile) {
        fclose(destFile);
    }
    return;
}


void _sx_gzip_file(const char *src)
{
    sx_gzip_ctx *gzip_ctx = NULL;
    cl_status_t  cl_err = CL_SUCCESS;

    /*will free when thread exit*/
    gzip_ctx = cl_malloc(sizeof(sx_gzip_ctx));
    if (!gzip_ctx) {
        SX_LOG_ERR("Memory error while allocating gzip gzip_ctx\n");
        goto out;
    }

    snprintf(gzip_ctx->source, sizeof(gzip_ctx->source), "%s", src);
    /*not blocking main thread while gzip*/
    cl_err = cl_thread_init(&(gzip_ctx->gzip_thread),
                            _sx_gzip_file_thread,
                            (void *)gzip_ctx,
                            "sxSnifferGzip",
                            0);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Could not create SX gzip thread\n");
        cl_free(gzip_ctx);
    }

out:
    return;
}

sx_status_t sniffer_log_cleanup(void)
{
    DIR                 *dir;
    struct dirent       *entry;
    sniffer_file_info_t *files;
    int                  file_count = 0;
    sx_status_t          status = SX_STATUS_SUCCESS;
    struct stat          file_stat;
    int                  i = 0;

    files = cl_malloc(SNIFFER_MAX_FILES * sizeof(sniffer_file_info_t));
    if (!files) {
        status = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("sniffer malloc failed\n");
        return status;
    }

    if ((dir = opendir(g_sniffer_db.params.log_file_path)) == NULL) {
        /*no need to cleanup dir */
        goto malloc_rollback;
    }

    /* Get files which start with "sx_sdk" and contains ".pcap" */
    while ((entry = readdir(dir)) != NULL && file_count < SNIFFER_MAX_FILES) {
        if ((strncmp(entry->d_name, SNIFFER_DEFAULT_FILE,
                     strlen(SNIFFER_DEFAULT_FILE)) == 0) && strstr(entry->d_name, ".pcap")) {
            snprintf(files[file_count].name,
                     SX_DBG_API_LOG_FILENAME_MAX,
                     "%s/%s",
                     g_sniffer_db.params.log_file_path,
                     entry->d_name);
            if (stat(files[file_count].name, &file_stat) == 0) {
                files[file_count].update_time = file_stat.st_mtime;
                file_count++;
            } else {
                SX_LOG_ERR("sniffer can't get file stats %s error %s\n", files[file_count].name,  strerror(errno));
                status = SX_STATUS_ERROR;
                goto out;
            }
        }
    }

    if (file_count) {
        /* Sort files by update time */
        qsort(files, file_count, sizeof(sniffer_file_info_t), sniffer_compare_fileinfo);

        /* Delete old files except the last round of logs. there is a non zipped pcap will zipped later*/
        for (i = g_sniffer_db.log_file_num + 1; i < file_count; i++) {
            if (remove(files[i].name) != 0) {
                SX_LOG_ERR("\nFailed to remove %s\n", files[i].name);
            } else {
                SX_LOG_NTC("\nDeleted: %s\n", files[i].name);
            }
        }

        /*zip the log if not already */
        for (i = 0; i < (g_sniffer_db.log_file_num + 1) && i < file_count; i++) {
            if (strstr(files[i].name, ".gz") == NULL) {
                _sx_gzip_file(files[i].name);
            }
        }
    }
out:
    closedir(dir);
malloc_rollback:
    cl_free(files);
    return status;
}

static sx_status_t __sdk_sniffer_init_file(const sx_dbg_api_logger_params_t *params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    char       *tmp;
    struct stat st = {0};

    tmp = strchr(params_p->log_file_path, '/');
    if (tmp) {
        if (stat(params_p->log_file_path, &st) == -1) {
            if (sdk_mkdir_p(params_p->log_file_path, 0755) != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("sniffer can't create directory %s\n", params_p->log_file_path);
                return SX_STATUS_PARAM_ERROR;
            }
        }
    } else {
        SX_LOG_ERR("Please include full directory in %s\n", params_p->log_file_path);
        return SX_STATUS_PARAM_ERROR;
    }

    /* params_p->log_file_path only contain directory
     * g_sniffer_db.current_log_file_path will append /sx_sdk and timestamp
     */
    snprintf(g_sniffer_db.current_log_file_path,
             sizeof(g_sniffer_db.current_log_file_path),
             "%s/sx_sdk_%ld",
             params_p->log_file_path,
             time(NULL) + g_sniffer_db.idx); /*idx to make sure in same second we use different name*/
    g_sniffer_db.idx++;
    switch (g_sniffer_db.params.logger_mode) {
    case SX_DBG_API_LOGGER_LINEAR_MODE:
        g_sniffer_db.log_file_size_max = g_sniffer_db.params.logger_mode_params.linear_params.max_log_size;
        g_sniffer_db.log_file_num = 1;
        break;

    case SX_DBG_API_LOGGER_CYCLIC_MODE:
        g_sniffer_db.log_file_size_max = g_sniffer_db.params.logger_mode_params.cyclic_params.max_log_size;
        g_sniffer_db.log_file_num = g_sniffer_db.params.logger_mode_params.cyclic_params.log_file_num;
        break;

    default:
        break;
    }

    g_sniffer_db.current_log_file_idx = 0;
    g_sniffer_db.current_log_file_size = 0;

    if (g_sniffer_db.params.logger_mode == SX_DBG_API_LOGGER_CYCLIC_MODE) {
        err = sniffer_log_cleanup();
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to sniffer log cleanup.\n");
            return err;
        }
    }
    return __sdk_sniffer_open_file();
}

inline static sx_status_t __sdk_sniffer_open_file()
{
    pcap_file_header_t header;
    uint32_t           snaplen = 0;
    sx_status_t        status = SX_STATUS_SUCCESS;
    char               file_path[SX_DBG_API_LOG_FILENAME_MAX + 1];

    if (g_sniffer_db.params.logger_mode == SX_DBG_API_LOGGER_CYCLIC_MODE) {
        if (NULL != g_sniffer_db.current_log_file_fd) {
            fclose(g_sniffer_db.current_log_file_fd);
            /*add sequence number here*/
            snprintf(file_path,
                     sizeof(file_path),
                     "%s_%d.pcap",
                     g_sniffer_db.current_log_file_path,
                     g_sniffer_db.current_log_file_idx);
            _sx_gzip_file(file_path);
            g_sniffer_db.current_log_file_idx = (g_sniffer_db.current_log_file_idx + 1) % g_sniffer_db.log_file_num;
            if (g_sniffer_db.current_log_file_idx == 0) { /*never overwritten first log*/
                g_sniffer_db.current_log_file_idx = 1;
            }
        }

        /*add sequence number here*/
        snprintf(file_path,
                 sizeof(file_path),
                 "%s_%d.pcap",
                 g_sniffer_db.current_log_file_path,
                 g_sniffer_db.current_log_file_idx);
        g_sniffer_db.current_log_file_size = sizeof(header);
        g_sniffer_db.current_log_file_fd = fopen(file_path, "w");
        if (NULL == g_sniffer_db.current_log_file_fd) {
            SX_LOG_ERR("Failed to write file %s\n", file_path);
            return SX_STATUS_ERROR;
        }
    } else if (g_sniffer_db.params.logger_mode == SX_DBG_API_LOGGER_LINEAR_MODE) {
        /* Makes sure we don't have a file to write to already */
        if (NULL != g_sniffer_db.current_log_file_fd) {
            return SX_STATUS_ERROR;
        }
        snprintf(file_path,
                 sizeof(file_path),
                 "%s.pcap",
                 g_sniffer_db.current_log_file_path);

        g_sniffer_db.current_log_file_fd = fopen(file_path, "w");
        if (NULL == g_sniffer_db.current_log_file_fd) {
            SX_LOG_ERR("Failed to write file %s\n", g_sniffer_db.current_log_file_path);
            return SX_STATUS_ERROR;
        }
    }
    SX_LOG_NTC("Started sniffing to %s\n", file_path);


    /* Maximum allowed size*/
    snaplen = sizeof(packet_t);

    /* Writing the PCAP Header */
    header.magic = PCAP_MAGIC;
    header.version_major = PCAP_VERSION_MAJOR;
    header.version_minor = PCAP_VERSION_MINOR;
    header.thiszone = 0;
    header.sigfigs = 0;
    header.snaplen = snaplen;
    header.linktype = LINKTYPE_NULL;
    status = __sdk_sniffer_writefile((unsigned char*)&header, sizeof(header));
    if (SX_CHECK_FAIL(status)) {
        return status;
    }

    return __sdk_sniffer_flush_file();
}


/* This function will sniff target buffer into the output file */
inline static void __sdk_sniffer_sniff_buffer(buffer_side_e         side,
                                              const uint8_t * const p_head,
                                              uint32_t              head_size,
                                              const uint8_t * const p_body,
                                              uint32_t              body_size,
                                              struct timespec      *ext_timestamp)
{
    uint32_t                       idx = 0;
    pcap_pkthdr_t                  pcap_hdr;
    timeval_t                      ts;
    uint32_t                       pkt_size = 0;
    uint32_t                       tmp_size = 0;
    uint32_t                       used_size = 0;
    sx_api_command_head_t * const  p_cmd_head = (sx_api_command_head_t *)p_head;
    sx_macsec_sa_obj_set_params_t *set_cmd_body;

    memset(&pcap_hdr, 0, sizeof(pcap_hdr));
    memset(&ts, 0, sizeof(ts));

    /* if error occurs, we cannot work anymore. */
    if (TRUE == g_sniffer_db.error) {
        SX_LOG_NTC("API[0x%x] call will not be recorded - sniffer is in the error state.\n",
                   g_sniffer_db.last_api_opcode);
        SNIFFER_API_DROP_COUNTER_INC();
        return;
    }

    if ((NULL == p_head) || (0 == head_size)) {
        SX_LOG_NTC("API[0x%x] call will not be recorded - Invalid api_queue_head received: p_head %p, head_size %u.\n",
                   g_sniffer_db.last_api_opcode, p_head, head_size);
        SNIFFER_API_DROP_COUNTER_INC();
        return;
    }
    if ((NULL == p_body) && (body_size > 0)) {
        SX_LOG_NTC("API[0x%x] call will not be recorded - Invalid body received: p_body %p, body_size %u.\n",
                   g_sniffer_db.last_api_opcode, p_body, body_size);
        SNIFFER_API_DROP_COUNTER_INC();
        return;
    }

    /* Makes sure this is the side we expecting */
    cl_spinlock_acquire(&g_sniffer_db.api_queue_lock);
    if ((side != BUFFER_SIDE_SYSFS_E) && (side != g_sniffer_db.expected_side) && (side != BUFFER_SIDE_EVENTS_E)) {
        SX_LOG_ERR("Packet received from a different side then expected! API opcode: 0x%x\n",
                   g_sniffer_db.last_api_opcode);
        SNIFFER_API_DROP_COUNTER_INC();
        cl_spinlock_release(&g_sniffer_db.api_queue_lock);
        return;
    }

    /* Calculate PCAP packet size */
    pkt_size = sizeof(pcap_pkthdr_t) + sizeof(side) + head_size + body_size;

    if (ext_timestamp != NULL) {
        ts.tv_sec = ext_timestamp->tv_sec;
        ts.tv_usec = 0.001 * ext_timestamp->tv_nsec;
    } else {
        /* Preparing header */
        if (0 != gettimeofday(&ts, NULL)) {
            SX_LOG_NTC("API[0x%x] call will not be recorded - failed to get time of day.\n",
                       g_sniffer_db.last_api_opcode);
            SNIFFER_API_DROP_COUNTER_INC();
            cl_spinlock_release(&g_sniffer_db.api_queue_lock);
            return;
        }
    }

    pcap_hdr.tv_sec = ts.tv_sec;
    /* 64 bits uses too high numbering for the file format to handle */
#if __x86_64__ || __ppc64__
    pcap_hdr.tv_usec = (ts.tv_usec >> 1);
#else
    pcap_hdr.tv_usec = ts.tv_usec;
#endif
    pcap_hdr.caplen = pkt_size - sizeof(pcap_pkthdr_t);
    pcap_hdr.len = pcap_hdr.caplen;

    memcpy(&g_sniffer_db.api_slot[idx], &pcap_hdr, sizeof(pcap_hdr));
    idx += sizeof(pcap_hdr);
    memcpy(&g_sniffer_db.api_slot[idx], (unsigned char*)&side, sizeof(side));
    idx += sizeof(side);
    memcpy(&g_sniffer_db.api_slot[idx], p_head, head_size);
    idx += head_size;
    if (body_size > 0) {
        memcpy(&g_sniffer_db.api_slot[idx], p_body, body_size);
        if (p_cmd_head->opcode == SX_API_INT_CMD_MACSEC_SA_OBJ_SET_E) {
            set_cmd_body = (sx_macsec_sa_obj_set_params_t *)&g_sniffer_db.api_slot[idx];
            memset(set_cmd_body->sa_attr.sak, SNIFFER_DEFAULT_MACSEC_KEY, sizeof(set_cmd_body->sa_attr.sak));
        }
        idx += body_size;
    }

    /* There is a room for optimization.
     *  We can check runtime queue occupancy,
     *  and set a threshold when we write the data to the flash. */
    /* Verify there is enough room in the buffer for the packet */
    if ((g_sniffer_db.api_queue_head < g_sniffer_db.api_queue_tail) &&
        ((g_sniffer_db.api_queue_head + pkt_size) >= g_sniffer_db.api_queue_tail)) {
        SX_LOG_NTC("API[0x%x] call will not be recorded - no space in the queue.\n", g_sniffer_db.last_api_opcode);
        SNIFFER_API_DROP_COUNTER_INC();
        cl_spinlock_release(&g_sniffer_db.api_queue_lock);
        return;
    }
    if ((g_sniffer_db.api_queue_head >= g_sniffer_db.api_queue_tail) &&
        ((g_sniffer_db.api_queue_head + pkt_size) >= SNIFFER_API_QUEUE_SIZE) &&
        (((g_sniffer_db.api_queue_head + pkt_size) % SNIFFER_API_QUEUE_SIZE) >= g_sniffer_db.api_queue_tail)) {
        SX_LOG_NTC("API[0x%x] call won't be recorded - no space in the queue.\n", g_sniffer_db.last_api_opcode);
        SNIFFER_API_DROP_COUNTER_INC();
        cl_spinlock_release(&g_sniffer_db.api_queue_lock);
        return;
    }

    /* Update next side */
    if ((side != BUFFER_SIDE_SYSFS_E) && (side != BUFFER_SIDE_EVENTS_E)) {
        g_sniffer_db.expected_side = (side == BUFFER_SIDE_CMD_E) ? BUFFER_SIDE_REPLY_E : BUFFER_SIDE_CMD_E;
    }

    /* Push data to the buffer queue */
    if ((g_sniffer_db.api_queue_tail <= g_sniffer_db.api_queue_head) &&
        ((g_sniffer_db.api_queue_head + pkt_size) > SNIFFER_API_QUEUE_SIZE)) {
        tmp_size = SNIFFER_API_QUEUE_SIZE - g_sniffer_db.api_queue_head;
        memcpy(&g_sniffer_db.api_queue[g_sniffer_db.api_queue_head], g_sniffer_db.api_slot, tmp_size);
        /* Move pointer to the beginning of the queue */
        g_sniffer_db.api_queue_head = 0;
        /* Write rest of the buffer */
        memcpy(&g_sniffer_db.api_queue[g_sniffer_db.api_queue_head],
               &g_sniffer_db.api_slot[tmp_size],
               pkt_size - tmp_size);
        g_sniffer_db.api_queue_head = g_sniffer_db.api_queue_head + pkt_size - tmp_size;
    } else {
        memcpy(&g_sniffer_db.api_queue[g_sniffer_db.api_queue_head], g_sniffer_db.api_slot, pkt_size);
        g_sniffer_db.api_queue_head = (g_sniffer_db.api_queue_head + pkt_size) % SNIFFER_API_QUEUE_SIZE;
    }

    if (g_sniffer_db.api_queue_tail <= g_sniffer_db.api_queue_head) {
        used_size = g_sniffer_db.api_queue_head - g_sniffer_db.api_queue_tail;
    } else {
        used_size = SNIFFER_API_QUEUE_SIZE - g_sniffer_db.api_queue_tail + g_sniffer_db.api_queue_head;
    }
    cl_spinlock_release(&g_sniffer_db.api_queue_lock);

    if ((g_sniffer_db.params.write_interval == 0) ||
        (g_sniffer_db.current_log_file_size > g_sniffer_db.log_file_size_max)
        || (used_size > SNIFFER_API_QUEUE_SIZE / 2)) {
        if (cl_fd_signal(__api_fd)) {
            SX_LOG_ERR("Failed writing to the api PIPE of Sniffer thread \n");
        }
    }
}

inline static int __sdk_sniffer_api_queue_pop()
{
    uint32_t      tmp_size = 0;
    int           ret = 0;
    uint32_t      tmp_head = 0;
    uint32_t      tmp_tail = 0;
    buffer_side_e expected_side;

    /* Enter critical zone */
    cl_spinlock_acquire(&g_sniffer_db.api_queue_lock);

    if (g_sniffer_db.api_queue_head == g_sniffer_db.api_queue_tail) {
        cl_spinlock_release(&g_sniffer_db.api_queue_lock);
        return ret;
    }

    tmp_head = g_sniffer_db.api_queue_head;
    tmp_tail = g_sniffer_db.api_queue_tail;
    if (g_sniffer_db.api_queue_tail < tmp_head) {
        tmp_size = tmp_head - g_sniffer_db.api_queue_tail;
    } else {
        tmp_size = SNIFFER_API_QUEUE_SIZE - g_sniffer_db.api_queue_tail;
    }

    g_sniffer_db.api_queue_tail = tmp_head;

    expected_side = g_sniffer_db.expected_side;
    cl_spinlock_release(&g_sniffer_db.api_queue_lock);

    g_sniffer_db.current_log_file_size += tmp_size;
    /* Write to the file */
    if (tmp_tail < tmp_head) {
        ret = __sdk_sniffer_writefile(&g_sniffer_db.api_queue[tmp_tail], tmp_size);
        if (ret != 0) {
            goto out;
        }
    } else {
        /* write it to file. */
        ret = __sdk_sniffer_writefile(&g_sniffer_db.api_queue[tmp_tail], tmp_size);
        if (ret != 0) {
            goto out;
        }
        ret = __sdk_sniffer_writefile(&g_sniffer_db.api_queue[0], tmp_head);
        if (ret != 0) {
            goto out;
        }
        g_sniffer_db.current_log_file_size += tmp_head;
    }

    __sdk_sniffer_flush_file();

    if (g_sniffer_db.params.logger_mode == SX_DBG_API_LOGGER_CYCLIC_MODE) {
        if ((g_sniffer_db.current_log_file_size > g_sniffer_db.log_file_size_max) &&
            (expected_side == BUFFER_SIDE_CMD_E)) {
            ret = __sdk_sniffer_open_file();
            if (ret != 0) {
                SX_LOG_ERR("Failed to open file.\n");
                goto out;
            }
        }
    } else if (g_sniffer_db.params.logger_mode == SX_DBG_API_LOGGER_LINEAR_MODE) {
        if ((g_sniffer_db.log_file_size_max != SX_DBG_API_LOG_SIZE_UNLIMITED) &&
            (g_sniffer_db.log_file_size_max < g_sniffer_db.current_log_file_size) &&
            (expected_side == BUFFER_SIDE_CMD_E)) {
            SX_LOG_WRN("API sniffing is stopped - the log file size exceeds the limit.\n");
            sx_api_sniffer_enabled_set(FALSE);
            __sdk_sniffer_disable(TRUE);
            goto out;
        }
    }

out:
    return ret;
}

static void __sdk_sniffer_thread(void *context)
{
    cl_status_t    cl_err = CL_SUCCESS;
    int            hc_fd = -1, max_fd;
    fd_set         read_fds;
    int            rc;
    struct timeval timeout;

    UNUSED_PARAM(context);

    cl_dbg_bp_ctl_db_entry_t *bp_ctl_db_entry_p = NULL;

    cl_dbg_bp_ctl_thread_mutable_set(&bp_ctl_db_entry_p, FALSE);

    max_fd = __api_fd;

    if (bp_ctl_db_entry_p != NULL) {
        hc_fd = bp_ctl_db_entry_p->health_check_fd;
        max_fd = MAX(max_fd, hc_fd);
    }

    while (TRUE) {
        FD_ZERO(&read_fds);

        FD_SET(__api_fd, &read_fds);
        if (hc_fd >= 0) {
            FD_SET(hc_fd, &read_fds);
        }

        memset(&timeout, 0, sizeof(timeout));

        if (g_sniffer_db.params.write_interval == 0) { /*In this case every api will call cl_event_signal*/
            timeout.tv_sec = SNIFFER_DEFAULT_INTERVAL / 1000;
            timeout.tv_usec = (SNIFFER_DEFAULT_INTERVAL % 1000) * 1000;
        } else {
            timeout.tv_sec = g_sniffer_db.params.write_interval / 1000;
            timeout.tv_usec = (g_sniffer_db.params.write_interval % 1000) * 1000;
        }

        cl_fd_wait_on(max_fd, &read_fds, NULL, &timeout, &rc);
        if (rc < 0) {
            SX_LOG_ERR("Sniffer thread: select() failed [max_fd=%d, errno=%d]\n", max_fd, errno);
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
        }

        if (g_sniffer_db.exit_signal_issued == TRUE) {
            return;
        }

        cl_dbg_bp_ctl_thread_sync(&bp_ctl_db_entry_p);

        if (hc_fd >= 0) {
            cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, FALSE);
        }

        if (FD_ISSET(__api_fd, &read_fds)) {
            cl_err = cl_fd_read(__api_fd);
            if (cl_err != CL_SUCCESS) {
                SX_LOG_ERR("Sniffer thread: error in reading from notification pipe [err=%d]\n", cl_err);
                cl_dbg_bp_hc_thread_update(bp_ctl_db_entry_p, hc_fd, &read_fds, TRUE);
            }
        }

        if (g_sniffer_enabled != FALSE) {
            cl_spinlock_acquire(&g_sniffer_db.current_log_file_wr_lock);
            rc = __sdk_sniffer_api_queue_pop();
            cl_spinlock_release(&g_sniffer_db.current_log_file_wr_lock);
            if (rc) {
                /* Stop sniffing from now on. */
                SX_LOG_ERR("Failed to flush API queue to a file, error: %d \n", rc);
                __sdk_sniffer_on_error();
                return;
            }
        }
    }
}

static sx_status_t __sdk_sniffer_async_register()
{
    cl_status_t cl_err = CL_SUCCESS;
    sx_status_t sx_status = SX_STATUS_SUCCESS;
    boolean_t   spinlock_init = FALSE;
    boolean_t   file_wr_lock_init = FALSE;

    cl_err = cl_fd_init(&__api_fd);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Could not initialize SX Sniffer queue event\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    g_sniffer_db.api_queue = (uint8_t*)cl_malloc(SNIFFER_API_QUEUE_SIZE);
    if (!g_sniffer_db.api_queue) {
        SX_LOG_ERR("No memory for SX Sniffer pool\n");
        sx_status = SX_STATUS_NO_MEMORY;
        goto out;
    }
    SNIFFER_API_QUEUE_RESET();

    g_sniffer_db.exit_signal_issued = FALSE;

    cl_err = cl_spinlock_init(&g_sniffer_db.api_queue_lock);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Could not create SX Sniffer spinlock\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    spinlock_init = TRUE;

    cl_err = cl_spinlock_init(&g_sniffer_db.current_log_file_wr_lock);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Could not create SX Sniffer log write spinlock\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }
    file_wr_lock_init = TRUE;

    cl_err = cl_thread_init(&g_sniffer_db.sniffer_thread,
                            __sdk_sniffer_thread,
                            NULL,
                            "sxSniffer",
                            THREAD_MAX_ALLOWED_TIME_DEFAULT);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Could not create SX Sniffer thread\n");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

out:
    if (SX_CHECK_FAIL(sx_status)) {
        if (file_wr_lock_init == TRUE) {
            cl_spinlock_destroy(&g_sniffer_db.current_log_file_wr_lock);
        }
        if (spinlock_init == TRUE) {
            cl_spinlock_destroy(&g_sniffer_db.api_queue_lock);
        }
        if (g_sniffer_db.api_queue != NULL) {
            cl_free(g_sniffer_db.api_queue);
            g_sniffer_db.api_queue = NULL;
        }
    }
    return sx_status;
}

static void __sdk_sniffer_async_unregister(boolean_t on_error)
{
    g_sniffer_db.exit_signal_issued = TRUE;
    if (cl_fd_signal(__api_fd)) {
        SX_LOG_ERR("Failed writing to the PIPE of Sniffer thread in order to close him \n");
    }
    /*
     * On error, we call this function from within the sniffer thread itself.
     * Therefore we can destroy the thread with pthread_join,
     * however we can use pthread_detach as the SDK process continue to live
     * and there will be enough time to complete the sniffer's "error" flow.
     *
     * In the normal flow, when sdk is being terminated, from the main SDK thread,
     * we use pthread_join to synchronously close the sniffer thread and avoid
     * a race on the deinit (as we stop the sniffer at the end right next to the complib deinit).
     */
    if (on_error) {
        cl_thread_detach_n_destroy(&(g_sniffer_db.sniffer_thread));
    } else {
        cl_thread_destroy(&(g_sniffer_db.sniffer_thread));
    }
    close(__api_fd);
    cl_spinlock_destroy(&g_sniffer_db.api_queue_lock);
    cl_spinlock_destroy(&g_sniffer_db.current_log_file_wr_lock);
    if (g_sniffer_db.api_queue) {
        cl_free(g_sniffer_db.api_queue);
        g_sniffer_db.api_queue = NULL;
    }

    SX_LOG_NTC("Sniffer thread closed.\n");

    return;
}


void sysfs_sniffer_access_dispatch(const sx_api_sysfs_head_t* const p_sysfs_head,
                                   uint8_t                        * write_buffer,
                                   struct timespec                  timestamp)
{
    __sdk_sniffer_sniff_buffer(BUFFER_SIDE_SYSFS_E, (const uint8_t*const)p_sysfs_head, sizeof(sx_api_sysfs_head_t),
                               write_buffer, p_sysfs_head->buf_len, &timestamp);
}


void events_sniffer_access_dispatch(const sx_api_events_head_t* const p_events_head)
{
    __sdk_sniffer_sniff_buffer(BUFFER_SIDE_EVENTS_E, (const uint8_t*const)p_events_head, sizeof(sx_api_events_head_t),
                               NULL, 0, NULL);
}

void sdk_sniffer_api_dispatch(const sx_api_command_head_t * const p_head,
                              const uint8_t * const               p_body,
                              uint32_t                            body_size)
{
    /* Makes sure the buffer size is at least command header */
    if (p_head->msg_size < sizeof(sx_api_command_head_t)) {
        SX_LOG_NTC("API[0x%x] call will not be recorded - Invalid buffer size sent in dispatch.\n", p_head->opcode);
        SNIFFER_API_DROP_COUNTER_INC();
        return;
    }

    g_sniffer_db.last_api_opcode = p_head->opcode;
    SNIFFER_RETURN_IF_API_SHOULD_BE_SKIPPED();

    __sdk_sniffer_sniff_buffer(BUFFER_SIDE_CMD_E, (const uint8_t*const)p_head, sizeof(sx_api_command_head_t),
                               p_body, body_size, NULL);
}

void sdk_sniffer_api_reply(const sx_api_reply_head_t *reply_head,
                           uint32_t                   head_size,
                           const uint8_t             *reply_body,
                           uint32_t                   reply_body_size)
{
    SNIFFER_RETURN_IF_API_SHOULD_BE_SKIPPED();

    /* Makes sure buffer size is valid */
    if (reply_head->msg_size < sizeof(sx_api_reply_head_t)) {
        SX_LOG_NTC("API[0x%x] call will not be recorded - Invalid buffer size sent in reply.\n",
                   g_sniffer_db.last_api_opcode);
        SNIFFER_API_DROP_COUNTER_INC();
        return;
    }

    __sdk_sniffer_sniff_buffer(BUFFER_SIDE_REPLY_E, (const uint8_t*const)reply_head, head_size,
                               reply_body, reply_body_size, NULL);
}

static sx_status_t __sdk_sniffer_filter_file_upload()
{
    FILE      * fp = NULL;
    int         read = 0;
    uint32_t    opcode = 0;
    uint32_t    idx = 0;
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_sniffer_db.params.filter_mode == SX_DBG_API_LOGGER_FILTER_NONE_MODE) {
        goto out;
    }

    fp = fopen(g_sniffer_db.params.filter_file_path, "r");
    if (fp == NULL) {
        SX_LOG_ERR("Failed to open a filter file %s.\n", g_sniffer_db.params.filter_file_path);
        status = SX_STATUS_ERROR;
        goto out;
    }

    for (idx = 0; idx < SNIFFER_API_NUM; idx++) {
        /* fscanf returns number of read values */
        read = fscanf(fp, "%x", &opcode);
        if (read != 1) {
            /* nothing to read or something went wrong */
            break;
        }
        if (opcode >= SNIFFER_API_NUM) {
            SX_LOG_ERR("Invalid opcode %u in filter file on %u position.\n", opcode, idx);
            status = SX_STATUS_ERROR;
            goto out;
        }
        g_sniffer_db.apis_filter_marker[opcode] = SNIFFER_API_MARKER;
    }

    if (read != EOF) {
        /* Reading process finished with error */
        SX_LOG_ERR("Bad value %u in filter file on %u position.\n", opcode, idx);
        status = SX_STATUS_ERROR;
        goto out;
    }

    /* Prepare filtering array according the filter mode to process requested APIs properly using simple if:
     * if API mark == 1, skip it.
     * To do so, filtering array should be properly filled according the filter mode:
     * | API name   | Opcode in the filter file     | array for EXCLUDE mode    | array for INCLUDE mode  |
     * | api_x_set  |     1 (present)               |     1                     |     0                   |
     * | api_y_set  |     0 (not present)           |     0                     |     1                   |
     * | api_z_set  |     1 (present)               |     1                     |     0                   |
     */
    if (g_sniffer_db.params.filter_mode == SX_DBG_API_LOGGER_FILTER_INCLUDE_APIS_MODE) {
        __sdk_sniffer_apis_filter_marker_invert();
    }

out:
    if (fp != NULL) {
        fclose(fp);
    }
    SX_LOG_EXIT();
    return status;
}

boolean_t sdk_sniffer_legacy_enable_check()
{
    return TRUE;
}

sx_status_t sdk_sniffer_legacy_param_get(sx_dbg_api_logger_params_t *params_p)
{
    char       *tmp = NULL;
    int         write_interval = 0, log_num = 0, log_size = 0, filter_mode = 0;
    sx_status_t status = SX_STATUS_SUCCESS;

    tmp = getenv(SX_SNIFFER_LOG_MODE);
    if (tmp && strlen(tmp)) {
        if (!strcasecmp("linear", tmp)) {
            params_p->logger_mode = SX_DBG_API_LOGGER_LINEAR_MODE;
        } else if (!strcasecmp("cyclic", tmp)) {
            params_p->logger_mode = SX_DBG_API_LOGGER_CYCLIC_MODE;
        } else {
            SX_LOG_ERR("%s provided %s is invalid.\n", SX_SNIFFER_LOG_MODE, tmp);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    } else {
        params_p->logger_mode = SX_DBG_API_LOGGER_LINEAR_MODE;
    }

    tmp = getenv(SX_SNIFFER_WRITE_INTERVAL);
    if (tmp && strlen(tmp)) {
        write_interval = atoi(tmp);
        if (write_interval >= 0) {
            params_p->write_interval = write_interval;
        } else {
            SX_LOG_ERR("%s provided %d is invalid.\n", SX_SNIFFER_WRITE_INTERVAL, write_interval);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    } else {
        if (params_p->logger_mode == SX_DBG_API_LOGGER_LINEAR_MODE) {
            params_p->write_interval = 0;
        } else {
            params_p->write_interval = SNIFFER_DEFAULT_INTERVAL;
        }
    }

    tmp = getenv(SX_SNIFFER_FILTER_MODE);
    if (tmp && strlen(tmp)) {
        filter_mode = atoi(tmp);
        if ((filter_mode >= SX_DBG_API_LOGGER_FILTER_MODE_MIN) && (filter_mode <= SX_DBG_API_LOGGER_FILTER_MODE_MAX)) {
            params_p->filter_mode = filter_mode;
        } else {
            SX_LOG_ERR("%s provided %d is invalid.\n", SX_SNIFFER_FILTER_MODE, filter_mode);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    } else {
        if (params_p->logger_mode == SX_DBG_API_LOGGER_LINEAR_MODE) {
            params_p->filter_mode = SX_DBG_API_LOGGER_FILTER_NONE_MODE;
        } else {
            params_p->filter_mode = SX_DBG_API_LOGGER_FILTER_EXCLUDE_APIS_MODE;
        }
    }

    tmp = getenv(SX_SNIFFER_FILTER_FILE);
    if (tmp && strlen(tmp)) {
        snprintf(params_p->filter_file_path, sizeof(params_p->filter_file_path), "%s", tmp);
    } else {
        snprintf(params_p->filter_file_path, sizeof(params_p->filter_file_path), "%s", SNIFFER_DEFAULT_FILTER);
    }

    tmp = getenv(SX_SNIFFER_LOG_NUM);
    if (tmp && strlen(tmp)) {
        log_num = atoi(tmp);
        if (params_p->logger_mode == SX_DBG_API_LOGGER_CYCLIC_MODE) {
            if (log_num > 1) {
                params_p->logger_mode_params.cyclic_params.log_file_num = log_num;
            } else {
                SX_LOG_ERR("%s provided %d is invalid .\n", SX_SNIFFER_LOG_NUM, log_num);
                status = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
    } else {
        params_p->logger_mode_params.cyclic_params.log_file_num = SNIFFER_DEFAULT_LOG_NUM;
    }

    tmp = getenv(SX_SNIFFER_LOG_MAX_SIZE);
    if (tmp && strlen(tmp)) {
        log_size = atoi(tmp);
        if (log_size > 0) {
            params_p->logger_mode_params.cyclic_params.max_log_size = log_size;
        } else {
            SX_LOG_ERR("%s provided %d is invalid.\n", SX_SNIFFER_LOG_MAX_SIZE, log_size);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    } else {
        if (params_p->logger_mode == SX_DBG_API_LOGGER_CYCLIC_MODE) {
            params_p->logger_mode_params.cyclic_params.max_log_size = SNIFFER_DEFAULT_LOG_SIZE;
        } else if (params_p->logger_mode == SX_DBG_API_LOGGER_LINEAR_MODE) {
            params_p->logger_mode_params.linear_params.max_log_size = SX_DBG_API_LOG_SIZE_UNLIMITED;
        }
    }

    /* Tries to get target path from ENV, if fails, use default one.*/
    tmp = getenv(SDK_SYS_INFO_PATH);
    if ((NULL == tmp) || (strlen(tmp) == 0)) {
        snprintf(params_p->log_file_path, sizeof(params_p->log_file_path), "%s", SNIFFER_DEFAULT_PATH);
    } else {
        snprintf(params_p->log_file_path, sizeof(params_p->log_file_path), "%s", tmp);
    }

out:
    return status;
}

sx_status_t sdk_sniffer_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    return SX_STATUS_SUCCESS;
}

void sniffer_signal_handler(int signum);

static sx_status_t sniffer_catch_signals(void (*handler)(int))
{
    struct sigaction action;
    unsigned int     i = 0;
    int              ret = 0;
    sx_status_t      err = SX_STATUS_SUCCESS;
    int              sniffer_signals[] = {SIGFPE, SIGSEGV, SIGILL, SIGBUS};

    UNUSED_PARAM(handler);

    memset(&action, 0, sizeof(action));
    action.sa_handler = handler;
    sigemptyset(&action.sa_mask);
    action.sa_flags = 0;


    for (i = 0; i < (sizeof(sniffer_signals) / sizeof(sniffer_signals[0])); i++) {
        ret = sigaction(sniffer_signals[i], &action, NULL);
        if (ret == -1) {
            SX_LOG(SX_LOG_ERROR, "sigaction error: %u %s %d\n", ret, strerror(errno), i);
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

void sniffer_signal_handler(int signum)
{
    static int ct = 0;

    if (ct > 0) { /*To prevent recursive signal handling*/
        return;
    }
    ct++;

    cl_spinlock_acquire(&g_sniffer_db.current_log_file_wr_lock);
    (void)__sdk_sniffer_api_queue_pop();
    cl_spinlock_release(&g_sniffer_db.current_log_file_wr_lock);
    __sdk_sniffer_close_file();

    sniffer_catch_signals(SIG_DFL); /*set back to default handler*/
    raise(signum);
}

static sx_status_t __sdk_sniffer_self_init()
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_sniffer_db.initialized != FALSE) {
        status = SX_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    sx_log_init(TRUE, NULL, NULL);

    SX_MEM_CLR(g_sniffer_db);
    __sdk_sniffer_logger_reset();

    status = __sdk_sniffer_async_register();
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Could not init SX Sniffer to async infra!\n");
        goto out;
    }

    sx_api_sniffer_api_reply_set(sdk_sniffer_api_reply);
    status = sniffer_catch_signals(sniffer_signal_handler);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Could not init SX Sniffer to async infra!\n");
        goto out;
    }
    g_sniffer_db.initialized = TRUE;

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_sniffer_stop_if_needed()
{
    SX_LOG_ENTER();

    __sdk_sniffer_stop(FALSE);

    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}

static void __sdk_sniffer_params_enable_selfsniff(const sx_dbg_api_logger_params_t *params_p)
{
    sx_api_dbg_api_logger_set_params_t cmd_body;
    sx_api_command_head_t              cmd_head;
    uint32_t                           header_size = sizeof(cmd_head);
    uint32_t                           body_size = sizeof(cmd_body);

    g_sniffer_db.last_api_opcode = SX_API_INT_DBG_API_LOGGER_SET_E;
    SNIFFER_RETURN_IF_API_SHOULD_BE_SKIPPED();

    SX_MEM_CLR(cmd_body);
    cmd_body.cmd = SX_ACCESS_CMD_ENABLE;
    SX_MEM_CPY(cmd_body.params, *params_p);

    SX_MEM_CLR(cmd_head);
    cmd_head.opcode = SX_API_INT_DBG_API_LOGGER_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = header_size + body_size;

    __sdk_sniffer_sniff_buffer(BUFFER_SIDE_CMD_E,
                               (const uint8_t*const)&cmd_head, header_size,
                               (const uint8_t*const)&cmd_body, body_size, NULL);
}

static void __sdk_sniffer_params_disable_selfsniff(const sx_dbg_api_logger_params_t *params_p)
{
    sx_api_dbg_api_logger_set_params_t reply_body;
    sx_api_reply_head_t                reply_head;
    uint32_t                           header_size = sizeof(sx_api_reply_head_t);
    uint32_t                           body_size = 0;

    SNIFFER_RETURN_IF_API_SHOULD_BE_SKIPPED();

    if (params_p != NULL) {
        body_size = sizeof(reply_body);
        SX_MEM_CLR(reply_body);
        reply_body.cmd = SX_ACCESS_CMD_DISABLE;
        SX_MEM_CPY(reply_body.params, *params_p);
    }

    SX_MEM_CLR(reply_head);
    reply_head.retcode = SX_STATUS_SUCCESS;
    reply_head.version = SX_API_INT_VERSION;
    reply_head.msg_size = header_size + body_size;

    __sdk_sniffer_sniff_buffer(BUFFER_SIDE_REPLY_E,
                               (const uint8_t*const)&reply_head, header_size,
                               (const uint8_t*const)&reply_body, body_size, NULL);
}


sx_status_t sysfs_sniffer_recording_set(sx_access_cmd_t cmd)
{
    ku_sysfs_sniffer_params_t ku_sysfs_sniffer_params;
    sxd_status_t              sxd_status = SXD_STATUS_SUCCESS;
    sx_status_t               err = SX_STATUS_SUCCESS;

    if (!g_sniffer_db.sysfs_sniffer_enable || !g_sniffer_db.initialized) {
        goto out;
    }
    if (!g_sniffer_db.sysfs_sniffer_enable) {
        ku_sysfs_sniffer_params.sysfs_sniffer_mode = SXD_SYSFS_SNIFFER_NONE_E;
    } else if (!g_sniffer_db.sysfs_sniffer_include_read) {
        ku_sysfs_sniffer_params.sysfs_sniffer_mode = SXD_SYSFS_SNIFFER_WRITE_ONLY_E;
    } else {
        ku_sysfs_sniffer_params.sysfs_sniffer_mode = SXD_SYSFS_SNIFFER_READ_WRITE_E;
    }

    sxd_status = sxd_access_sysfs_sniffer_mode_set(&ku_sysfs_sniffer_params);
    if (sxd_status != SXD_STATUS_SUCCESS) {
        err = sxd_status_to_sx_status(sxd_status);
        SX_LOG_ERR(
            "Failed to set sysfs sniffer mode to the driver, error (%s)\n",
            sx_status_str(err));
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_NONE) {
        err = host_ifc_sysfs_sniffer_trap_register_set(cmd);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to register sysfs sniffer trap\n");
            goto out;
        }
    }
out:
    return err;
}


static sx_status_t __sysfs_sniffer_set(boolean_t sysfs_recording_enable,
                                       boolean_t sysfs_read_recording,
                                       boolean_t legacy_call)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    sx_access_cmd_t cmd = SX_ACCESS_CMD_NONE;
    boolean_t       sdk_init_status = FALSE;

    if (((sysfs_recording_enable == TRUE) &&
         (g_sniffer_db.sysfs_sniffer_enable == TRUE) &&
         (g_sniffer_db.sysfs_sniffer_include_read == sysfs_read_recording))
        ||
        ((sysfs_recording_enable == FALSE) && (g_sniffer_db.sysfs_sniffer_enable == FALSE))) {
        /* Nothing to change*/
        goto out;
    }

    if ((g_sniffer_db.sysfs_sniffer_enable == FALSE) && (sysfs_recording_enable == TRUE)) {
        cmd = SX_ACCESS_CMD_ADD;
    } else if ((g_sniffer_db.sysfs_sniffer_enable == TRUE) && (sysfs_recording_enable == FALSE)) {
        cmd = SX_ACCESS_CMD_DELETE;
    }

    g_sniffer_db.sysfs_sniffer_enable = sysfs_recording_enable;
    g_sniffer_db.sysfs_sniffer_include_read = sysfs_read_recording;
    SX_LOG(SX_LOG_NOTICE, " g_sniffer_db.sysfs_sniffer_enable %d, g_sniffer_db.sysfs_sniffer_include_read %d\n",
           g_sniffer_db.sysfs_sniffer_enable,
           g_sniffer_db.sysfs_sniffer_include_read);

    /* In case that legacy_call = FALSE, check that SDK is already up*/
    if (legacy_call == FALSE) {
        sdk_init_status = sx_core_api_init_status_get();
        if (sdk_init_status == FALSE) {
            legacy_call = TRUE;
        }
    }

    if (!legacy_call) {
        err = sysfs_sniffer_recording_set(cmd);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to configure sysfs sniffer.\n");
            goto out;
        }
    }

out:
    return err;
}

inline static void __sdk_sniffer_disable(boolean_t skip_api_queue_flush)
{
    int rc = 0;

    g_sniffer_enabled = FALSE;

    if (skip_api_queue_flush == FALSE) {
        cl_spinlock_acquire(&g_sniffer_db.current_log_file_wr_lock);
        rc = __sdk_sniffer_api_queue_pop();
        cl_spinlock_release(&g_sniffer_db.current_log_file_wr_lock);
        if (rc) {
            /* Stop sniffing from now on. */
            SX_LOG_ERR("Failed to flush API queue to a file, error: %d \n", rc);
            __sdk_sniffer_on_error();
        }
    }

    __sdk_sniffer_close_file();

    SX_MEM_CLR(g_sniffer_db.params);
    SNIFFER_API_QUEUE_RESET();
    __sdk_sniffer_apis_data_reset();
    __sdk_sniffer_logger_reset();
    __sysfs_sniffer_set(FALSE, FALSE, FALSE);
}

sx_status_t sdk_sniffer_params_set(const sx_access_cmd_t             cmd,
                                   const sx_dbg_api_logger_params_t *params_p,
                                   boolean_t                         legacy_call)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    char        log_file_path_save[SX_DBG_API_LOG_FILENAME_MAX];

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_ENABLE:
        if (params_p == NULL) {
            SX_LOG_ERR("params_p is NULL\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }

        if (FALSE == g_sniffer_db.initialized) {
            err = __sdk_sniffer_self_init();
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to initialize the API sniffer.\n");
                goto out;
            }
        }

        if (g_sniffer_enabled == TRUE) {
            SX_LOG_ERR("The API logger is already enabled\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (!SX_DBG_API_LOGGER_FILTER_MODE_E_CHECK_RANGE(params_p->filter_mode)) {
            SX_LOG_ERR("Invalid filter mode: %s %u\n", sx_dbg_api_logger_filter_mode_str(params_p->filter_mode),
                       params_p->filter_mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (!SX_DBG_API_LOGGER_MODE_E_CHECK_RANGE(params_p->logger_mode)) {
            SX_LOG_ERR("Invalid logger mode: %s %u \n", sx_dbg_api_logger_mode_str(params_p->logger_mode),
                       params_p->logger_mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (params_p->logger_mode == SX_DBG_API_LOGGER_DISABLED_MODE) {
            SX_LOG_ERR("The API logger cannot be enabled in the DISABLED mode\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (params_p->logger_mode == SX_DBG_API_LOGGER_CYCLIC_MODE) {
            if (params_p->logger_mode_params.cyclic_params.log_file_num < 2) {
                SX_LOG_ERR("cyclic mode log_file_num %d should larger than 1.\n",
                           params_p->logger_mode_params.cyclic_params.log_file_num);
            }
        }
        if (!legacy_call && (params_p->log_file_path[0] == 0)) {
            /*If user don't specify the path, use the one from sx_api_sx_sdk_init.sdk_sys_info_params.sdk_sys_info_path,
             *  which was saved in g_sniffer_db.params.log_file_path by sdk_api_sniffer_folder_path_set()*/
            snprintf(log_file_path_save, sizeof(log_file_path_save), "%s", g_sniffer_db.params.log_file_path);
        }

        SX_MEM_CPY_P(&g_sniffer_db.params, params_p);

        if (!legacy_call && (params_p->log_file_path[0] == 0)) {
            /*restore*/
            snprintf(g_sniffer_db.params.log_file_path,
                     sizeof(g_sniffer_db.params.log_file_path),
                     "%s",
                     log_file_path_save);
        }

        __sdk_sniffer_apis_data_reset();

        err = __sdk_sniffer_filter_file_upload();
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to initialize filtering\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        err = __sdk_sniffer_init_file(&g_sniffer_db.params);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to initialize out file\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        g_sniffer_enabled = TRUE;
        sx_api_sniffer_enabled_set(g_sniffer_enabled);

        /* a legacy call is internal one and there will be no reply */
        if (legacy_call != TRUE) {
            __sdk_sniffer_params_enable_selfsniff(params_p);
        }

        err = __sysfs_sniffer_set((!params_p->sysfs_logger_mode.sysfs_sniffer_disable),
                                  params_p->sysfs_logger_mode.sysfs_sniffer_include_read_access,
                                  legacy_call);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to initialize sysfs sniffer\n");
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DISABLE:
        SNIFFER_RETURN_IF_NOT_INITIALIZED();

        if (g_sniffer_enabled == FALSE) {
            SX_LOG_ERR("The API logger is already disabled\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        __sdk_sniffer_params_disable_selfsniff(params_p);

        sx_api_sniffer_enabled_set(FALSE);
        __sdk_sniffer_disable(FALSE);

        break;

    default:
        SX_LOG_ERR("Unsupported command - %s \n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_sniffer_params_get(sx_dbg_api_logger_params_t *params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == g_sniffer_db.initialized) {
        memset(params_p, 0, sizeof(*params_p));
        goto out;
    }

    if (params_p == NULL) {
        SX_LOG_ERR("params_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CPY(*params_p, g_sniffer_db.params);

out:
    SX_LOG_EXIT();
    return err;
}

void sdk_sniffer_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    uint32_t                  idx = 0;
    dbg_utils_table_columns_t api_drop_counters_table[] = {
        {"Opcode", 10, PARAM_HEX_E, NULL},
        {"Drop counter", 15, PARAM_UINT32_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    dbg_utils_table_columns_t api_filter_markers_table[] = {
        {"Opcode", 10, PARAM_HEX_E, NULL},
        {"Filter marker", 15, PARAM_UINT8_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                     *stream = NULL;
    char                      path[SX_DBG_API_LOG_FILENAME_MAX];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_module_header_print(stream, "API sniffer");

    dbg_utils_pprinter_field_print(stream, "Module initialized", &g_sniffer_db.initialized, PARAM_BOOL_E);

    if ((FALSE == g_sniffer_db.initialized) && (FALSE == g_sniffer_db.error)) {
        goto out;
    }

    dbg_utils_pprinter_field_print(stream, "Error", &g_sniffer_db.error, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "Enabled", &g_sniffer_enabled, PARAM_BOOL_E);

    dbg_utils_pprinter_field_print(stream,
                                   "Logger mode",
                                   sx_dbg_api_logger_mode_str(g_sniffer_db.params.logger_mode),
                                   PARAM_STRING_E);

    switch (g_sniffer_db.params.logger_mode) {
    case SX_DBG_API_LOGGER_LINEAR_MODE:
        dbg_utils_pprinter_field_print(stream,
                                       "Max log size",
                                       &g_sniffer_db.params.logger_mode_params.linear_params.max_log_size,
                                       PARAM_UINT32_E);
        break;

    case SX_DBG_API_LOGGER_CYCLIC_MODE:
        dbg_utils_pprinter_field_print(stream,
                                       "Max log size",
                                       &g_sniffer_db.params.logger_mode_params.cyclic_params.max_log_size,
                                       PARAM_UINT32_E);
        dbg_utils_pprinter_field_print(stream,
                                       "Log file number",
                                       &g_sniffer_db.params.logger_mode_params.cyclic_params.log_file_num,
                                       PARAM_UINT32_E);
        break;

    default:
        break;
    }

    dbg_utils_pprinter_field_print(stream, "Log file path", g_sniffer_db.params.log_file_path, PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Filter mode",
                                   sx_dbg_api_logger_filter_mode_str(g_sniffer_db.params.filter_mode),
                                   PARAM_STRING_E);
    dbg_utils_pprinter_field_print(stream, "Filter file path", g_sniffer_db.params.filter_file_path, PARAM_STRING_E);
    if (g_sniffer_db.params.logger_mode == SX_DBG_API_LOGGER_CYCLIC_MODE) {
        snprintf(path,
                 sizeof(path),
                 "%s_%d.pcap",
                 g_sniffer_db.current_log_file_path,
                 g_sniffer_db.current_log_file_idx);
        dbg_utils_pprinter_field_print(stream, "Current log file", path, PARAM_STRING_E);
    } else {
        dbg_utils_pprinter_field_print(stream, "Current log file", g_sniffer_db.current_log_file_path, PARAM_STRING_E);
    }
    dbg_utils_pprinter_field_print(stream, "Current log file size", &g_sniffer_db.current_log_file_size,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Current log file size max", &g_sniffer_db.log_file_size_max,
                                   PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Exit signal issued", &g_sniffer_db.exit_signal_issued, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "API queue head", &g_sniffer_db.api_queue_head, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "API queue tail", &g_sniffer_db.api_queue_tail, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Last api opcode", &g_sniffer_db.last_api_opcode, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream, "Sysfs sniffer enable", &g_sniffer_db.sysfs_sniffer_enable, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream,
                                   "Sysfs sniffer record read access",
                                   &g_sniffer_db.sysfs_sniffer_include_read,
                                   PARAM_BOOL_E);

    dbg_utils_pprinter_print(stream, "\nThe table below will be empty if all API packets are sniffed.");
    dbg_utils_pprinter_table_headline_print(stream, api_drop_counters_table);
    for (idx = 0; idx < SNIFFER_API_NUM; idx++) {
        if (g_sniffer_db.apis_drop_counters[idx] != 0) {
            api_drop_counters_table[0].data = &idx;
            api_drop_counters_table[1].data = &g_sniffer_db.apis_drop_counters[idx];
            dbg_utils_pprinter_table_data_line_print(stream, api_drop_counters_table);
        }
    }

    dbg_utils_pprinter_print(stream, "\nThe table below will be empty if API filtering is not applied.");
    dbg_utils_pprinter_table_headline_print(stream, api_filter_markers_table);
    for (idx = 0; idx < SNIFFER_API_NUM; idx++) {
        if (g_sniffer_db.apis_filter_marker[idx] != 0) {
            api_filter_markers_table[0].data = &idx;
            api_filter_markers_table[1].data = &g_sniffer_db.apis_filter_marker[idx];
            dbg_utils_pprinter_table_data_line_print(stream, api_filter_markers_table);
        }
    }

out:
    SX_LOG_EXIT();
}

sx_status_t sdk_api_sniffer_folder_path_set(char *file_path_p)
{
    sx_status_t ret = SX_STATUS_SUCCESS;

    if (strcmp(file_path_p, g_sniffer_db.params.log_file_path)) { /*if path changed*/
        if (g_sniffer_enabled) {
            SX_LOG_ERR(
                "Sniffer is enabled by sx_sdk with different path, please export same environment variable 'SDK_SYS_INFO_PATH'\n");
            ret = SX_STATUS_PARAM_ERROR;
        } else {
            snprintf(g_sniffer_db.params.log_file_path, sizeof(g_sniffer_db.params.log_file_path), "%s", file_path_p);
        }
    }

    return ret;
}
