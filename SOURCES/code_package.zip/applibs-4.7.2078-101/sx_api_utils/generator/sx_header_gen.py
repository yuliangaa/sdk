#!/usr/bin/env python3
"""
# SX API Generator
#
# Provide generation of SX API header files based on
# ADABE files database. ADABE file is XML-formatted
# file with all data about APIs data structures.
#
"""
__title__ = 'SX_API_GENERATOR'
__author__ = 'oleksandrv'
__version__ = '1.7.1'
__release__ = 'Mar-2021'

import os
import re
import sys
import json
import time
import getpass
import argparse
import xml.etree.ElementTree as ET

from string import Template
from datetime import datetime

# import SX API Utils library
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.utils import g_logger, g_pbar, AdbParser, LogLevel as llvl, NodeType as nt, FontColor as fc


class DescTmpl:
    """
    Class used to unify Descriptions Templates
    """
    SECTION = '/{0}\n * {{0}}\n {0}/\n\n'.format('*' * 78)
    FRONTAL = '/**\n * {0}\n */\n'
    ENDSIDE = '/**< {0} */'


class NodesGenerator(object):
    """
    Class provide functionality for C header node generation.

    Attributes
    ----------
    _node_gen : dict
                set of data type generators
    """

    def __init__(self):
        """ Constructor define set of nodes generators """
        # define generators for different node types
        self._node_gen = {nt.INCLUDE: self.__gen_include,
                          nt.TYPEDEF: self.__gen_typedef,
                          nt.DEFINE: self.__gen_define,
                          nt.STRUCT: self.__gen_struct,
                          nt.UNION: self.__gen_union,
                          nt.ENUM: self.__gen_enum,
                          nt.CODE: self.__gen_code}

    def _desc_prep(self, node, template=DescTmpl.ENDSIDE):
        """ Function is used to check and preformat nodes description.
        This functionality is similar for several flows.

        :param node: node which description should be prepared
        :param template: template used to preformat description string
        :return: preformatted description or, in case of issues, empty string
        """
        if node['desc']:
            return template.format('\n *'.join([nd.rstrip() for nd in node['desc'].split('\\n')]))

        return ''

    def _strip_typename(self, tname, starts=None, ends=None):
        """ Function strips name of the type.

        :param tname: type name
        :param starts: list of prefixes to strip
        :param ends: list of postfixes to strip
        :return: stripped type name
        """
        for prefix in starts or []:
            tname = tname[len(prefix):] if tname.startswith(prefix) else tname

        for postfix in ends or []:
            tname = tname[:-len(postfix)] if tname.endswith(postfix) else tname

        return tname

    def _gen_node(self, node_type, data):
        """ Function is builder for multiple node types.

        :param node_type: type of node user wants to generate
        :param data: data needed for node generation
        :return: string with generated node code
        """
        if node_type in self._node_gen:
            return self._node_gen[node_type](data)

        return None

    def __gen_include(self, node):
        """ Build "include" node. """
        tmpl = '#include {} {}'
        wrapped_name = ('<%s>' if node['type'] == 'bracket' else '"%s"') % node['name']

        return tmpl.format(wrapped_name, self._desc_prep(node)).rstrip(' ') + '\n'

    def __gen_code(self, node, tabs=0, end=''):
        """ Build "code" node. """
        if node['type'] == 'comment':
            tmpl = '{0}{1}\n{0}/**{1}\n{0} * {{}}{1}\n{0} */{1}\n'.format('\t' * tabs, end)
            line_tmpl = '{}\n{} * '.format(end, '\t' * tabs)
        else:
            tmpl = '{0}\n{0}{{}}\n{0}'.format('\t' * tabs)
            line_tmpl = '\n{}'.format('\t' * tabs)

        return tmpl.format(line_tmpl.join(node['lines']))

    def __gen_define(self, node):
        """ Build "define" node. """
        tmpl = '{{}}#define {{:<{}}}'.format(0)
        return tmpl.format(self._desc_prep(node, DescTmpl.FRONTAL), '%s %s' % (node['name'], node['value'])).rstrip(' ') + '\n'

    def __gen_enum(self, node):
        """ Build "enum" node. For each enum we build:
            HEAD - enum specific define
            BODY - list of enum items
            FOOT - enum declaration
        """

        # create data columns to align enum declaration (ei = enumeration item)
        e_order = []
        for ei in node['fields']:
            if ei['name'].startswith(nt.CODE):
                e_order.append({'field': False,
                                'comnt': ei['type'] == 'comment',
                                'lines': ei['lines']})
            else:
                e_order.append({'field': True,
                                'value': ei['name'] + (' = %s,' % ei['value'] if ei['value'] else ','),
                                'cont': '"%s"' % ei['cont'],
                                'desc': self._desc_prep(ei)})

        # calculate maximum size of columns
        if any([ei['field'] for ei in e_order]):
            # use items attributes to calculate maximum sizes
            e_value_sz = max([len(ei['value']) for ei in e_order if ei['field']])
            e_cont_sz = max([len(ei['cont']) for ei in e_order if ei['field']]) + 1  # align column by 1
            e_desc_sz = max([len(ei['desc']) for ei in e_order if ei['field']])
            e_desc_sz = e_desc_sz + bool(e_desc_sz)  # align by 1 if there is at least 1 symbol

        else:
            # there are not any valid enum items, so use default sizes
            e_value_sz = 0
            e_cont_sz = 0
            e_desc_sz = 0

        # create body template using calculated columns sizes
        tmpl = ' ' * 4 + 'F({{:<{}}} {{:<{}}}{{:<{}}}'.format(e_value_sz, e_cont_sz, e_desc_sz)

        # generate body content
        e_lines = []
        e_width = len(tmpl.format('', '', ''))
        com_line = '{{:<{}}}'.format(e_width)

        for ei in e_order:
            if ei['field']:  # generate field
                e_lines.append(tmpl.format(ei['value'], ei['cont'] + ')', (' ' + ei['desc']) if ei['desc'] else ''))
            else:
                if ei['comnt']:  # generate comment
                    code = [(' * ' if i else '/* ') + line for i, line in enumerate(ei['lines'])]
                    code[-1] = code[-1] + ' */'
                    if len(e_lines):
                        # prepend newline before comment
                        e_lines.append(('%%%ds' % (e_value_sz + e_cont_sz + e_desc_sz + 7)) % '')
                else:  # use raw code as is
                    code = ei['lines']

                e_lines += [com_line.format(' ' * 4 + '{}'.format(line)) for line in code]
        enum_body = ' \\\n'.join(e_lines).rstrip(' ') + '\n'

        # generate head content
        foreach_name = node['foreach'] or self._strip_typename(node['typename'], ['sx_'], ['_t', '_e']).upper()

        head_tmpl = '{{:<{}}} \\'.format(e_width)
        enum_head = head_tmpl.format('#define FOREACH_{}(F)'.format(foreach_name))

        # get own name if provided
        own_name = (node['name'] + ' ') if node['name'] else ''
        node_name = (' ' + node['typename']) if node['typename'] else ''

        # pack if required
        pack_suffix = (' ' + node['pack']) if node['pack'] else ''

        # generate foot content
        enum_foot = '{}{}enum {}{{\n    FOREACH_{}(SX_GENERATE_ENUM) \\\n}}{}{};'.format(self._desc_prep(node, DescTmpl.FRONTAL),
                                                                                         'typedef ' if node_name else '',
                                                                                         own_name,
                                                                                         foreach_name,
                                                                                         pack_suffix,
                                                                                         node_name)

        # compile head, body and foot
        return '\n%s\n%s\n%s\n' % (enum_head, enum_body, enum_foot)

    def __gen_typedef(self, node):
        """ Function build "typedef" node. """
        def make_array(n): return ''.join(['[%s]' % dim for dim in n['arraysize']]) if n['arraysize'] else ''

        tmpl = '{}typedef {} {}{}{};'
        desc = self._desc_prep(node, DescTmpl.FRONTAL)

        return tmpl.format(('\n%s' % desc) if desc else '', node['type'],
                           node['pointer'] if node['pointer'] else '',
                           node['name'], make_array(node)).rstrip(' ') + '\n'

    def __gen_union(self, node):
        """ Function build "union" node. """
        def validate_field(ui):
            """ Checks if field is a pointer or an array """
            if ui['pointer']:  # field is an pointer
                return '%s%s;' % (ui['pointer'], ui['name'])
            elif ui['arraysize']:  # field is an array
                return '%s%s;' % (ui['name'], ''.join(['[%s]' % dim for dim in ui['arraysize']]))

            return '%s;' % ui['name']

        union_body = '\n{}{}union {}{{\n{}\n}}{}{};\n'

        # create data columns (ui = union item)
        u_order = []
        for ui in node['fields']:
            if ui['name'].startswith(nt.CODE):
                u_order.append({'field': False,
                                'comnt': ui['type'] == 'comment',
                                'lines': ui['lines']})
            else:
                u_order.append({'field': True,
                                'type': ui['type'],
                                'name': validate_field(ui),
                                'desc': self._desc_prep(ui)})

        # calculate maximal size of each column
        u_type_sz = max([len(ui['type']) for ui in u_order if ui['field']] or [0])
        u_name_sz = max([len(ui['name']) for ui in u_order if ui['field']] or [0])

        # get biggest pointer order
        u_mptr_sz = max([ui['name'].count('*') for ui in u_order if ui['field']] or [0])

        # create union fields template using calculated columns sizes
        tmpl = ' ' * 4 + '{{:<{}}} {{:<{}}} {{}}'.format(u_type_sz, u_name_sz)

        # list of generated union fields
        u_lines = []

        for ui in u_order:
            if ui['field']:  # generate union field
                u_lines.append(tmpl.format(ui['type'],
                                           ' ' * (u_mptr_sz - ui['name'].count('*')) + ui['name'],
                                           ui['desc']).rstrip(' '))
            else:
                if ui['comnt']:  # generate comment
                    code = [(' * ' if i else '/* ') + line for i, line in enumerate(ui['lines'])]
                    code[-1] = code[-1] + ' */'
                else:  # use raw code as is
                    code = ui['lines']

                u_lines += [' ' * 4 + '{}'.format(line) for line in code]
        u_fields = '\n'.join(u_lines)

        # get own name if provided
        own_name = (node['name'] + ' ') if node['name'] else ''
        node_name = (' ' + node['typename']) if node['typename'] else ''

        # pack if required
        pack_suffix = (' ' + node['pack']) if node['pack'] else ''

        # compile union parts
        return union_body.format(self._desc_prep(node, DescTmpl.FRONTAL),
                                 'typedef ' if node_name else '', own_name, u_fields, pack_suffix, node_name)

    def __gen_struct(self, node):
        """ Function build "struct" node. """
        def validate_field(si, node):
            """ Checks if field is a pointer, bit field or an array """
            if si['arraysize']:  # field is an array
                node_fields = [field['name'] for field in node['fields']]
                ptr_prefix = ''
                arr_suffix = ''
                for dim in si['arraysize']:
                    # if array size defined by node member it should be a pointer, otherwise 'as is'
                    if any([fld for fld in node_fields if dim.startswith(fld)]):
                        # NOTE: if we have pointer attribute along with arraysize,
                        # we assume, that user want to generate a pointer instead
                        # of zero-sized array.
                        if si['pointer']:
                            ptr_prefix += '*'
                        else:
                            arr_suffix += '[0]'
                    else:
                        arr_suffix += '[%s]' % dim
                return '%s%s%s;' % (ptr_prefix, si['name'], arr_suffix)
            elif si['pointer']:  # field is an pointer
                return '%s%s;' % (si['pointer'], si['name'])
            elif si['bits']:  # field is an bitfield
                return ' %s: %s;' % (si['name'], si['bits'])

            return '%s;' % si['name']

        struct_body = '\n{}{}struct {}{{\n{}\n}}{}{};\n'

        # create data columns (si = struct item)
        s_order = []
        for si in node['fields']:
            if si['name'].startswith(nt.CODE):
                s_order.append({'field': False,
                                'comnt': si['type'] == 'comment',
                                'lines': si['lines']})
            else:
                s_order.append({'field': True,
                                'type': si['type'],
                                'name': validate_field(si, node),
                                'desc': self._desc_prep(si)})

        # calculate maximal size of each column
        s_type_sz = max([len(si['type']) for si in s_order if si['field']] or [0])
        s_name_sz = max([len(si['name']) for si in s_order if si['field']] or [0])

        # get biggest pointer order
        s_mptr_sz = max([si['name'].count('*') for si in s_order if si['field']] or [0])

        # create union fields template using calculated columns sizes
        tmpl = ' ' * 4 + '{{:<{}}} {{:<{}}} {{}}'.format(s_type_sz, s_name_sz)

        # list of generated struct fields
        s_lines = []

        for si in s_order:
            if si['field']:
                s_lines.append(tmpl.format(si['type'],
                                           ' ' * (s_mptr_sz - si['name'].count('*')) + si['name'],
                                           si['desc']).rstrip(' '))
            else:
                if si['comnt']:
                    code = [(' * ' if i else '/* ') + line for i, line in enumerate(si['lines'])]
                    code[-1] = code[-1] + ' */'
                else:
                    code = si['lines']

                s_lines += [' ' * 4 + '{}'.format(line) for line in code]
        s_fields = '\n'.join(s_lines)

        # get own name if provided
        own_name = (node['name'] + ' ') if node['name'] else ''
        node_name = (' ' + node['typename']) if node['typename'] else ''

        # pack if required
        pack_suffix = (' ' + node['pack']) if node['pack'] else ''

        # compile union parts
        return struct_body.format(self._desc_prep(node, DescTmpl.FRONTAL),
                                  'typedef ' if node_name else '', own_name, s_fields, pack_suffix, node_name)


class HeaderGenerator(NodesGenerator):
    """
    Class provides functionality for C-header files generation.
    As input data, object get ADABE file with all data structures
    description. Generator uses external AdbParser object for
    ADB file processing and as a database.

    Attributes
    ----------
    _adb_parser : utils.HeaderAdbProcessor
                  object for ADB files processing and DB storage
    __adb_files : dict
                  path to ADABE files and path to target C headers
    """

    def __init__(self, adb_files, validate='all', debug=False, fix_xml=False):
        super(HeaderGenerator, self).__init__()
        self.show_head()

        # configure log level
        g_logger.set_level(llvl.DEBUG if debug else llvl.NORMAL)

        # upload XML DB
        self._adb_parser = AdbParser(adb_files, validate, fix_xml=fix_xml)

        # if user not specified output file in ADB file, script will generate new path
        self.__adb_files = {adb: target or (adb + '.h') for adb, target in self._adb_parser.hdr_files.items()}

    def __cut_path(self, filepath, dirname):
        """ Cut off path before particular directory.
        Function remove all directories before and including
        user-specified directory.

        :param filepath: path to file
        :param dirname: name of new root directory
        :return: cutted path with new root or same path
        """
        idx = filepath.find(dirname)
        if idx != -1:
            return filepath[idx:]

        return filepath

    def __generate_top_header(self, adb_file):
        """ This function generate top header for each generated file.
        Header contains information about file, the way it was created
        and how it can be modified.
        """

        content = '/*\n' \
                  ' * [[ WARNING | AUTOMATICALLY GENERATED FILE ]]\n' \
                  ' * $splitline\n' \
                  ' * This file has been generated by the script:\n' \
                  ' *     $genscript.\n' \
                  ' *\n' \
                  ' * You can manually modify this file ONLY for your testing needs.\n' \
                  ' * In all other cases manual changes in this file must be removed\n' \
                  ' * before committing. To modify content of this file in legal way\n' \
                  ' * use $adbfile file.\n' \
                  ' * $splitline\n' \
                  ' */\n\n'

        t = Template(content)
        line = '-' * 72
        script_path = self.__cut_path(os.path.realpath(__file__), 'applibs/')
        adb_path = self.__cut_path(os.path.realpath(adb_file), 'applibs/')
        return t.substitute(splitline=line, genscript=script_path, adbfile=adb_path)

    def ensure_dir(self, file_path):
        """ Function checks if path to file exists.
        If not exist, function will create it.

        :param file_path: Path to the file in directory user need to check
        """
        directory = os.path.dirname(file_path)
        if directory and not os.path.exists(directory):
            os.makedirs(directory)

    def generate(self, target):
        """ Function run header files generation.
        Each header file has its own types order, which is defined
        by ADABE file structure.
        """

        def is_content_diff(header, content):
            """ Function check if header file content is not the same

            Arguments:
                header {str} -- path to the header file
                content {str} -- expected file content
            """
            # check if header file exist
            if os.path.isfile(header):
                # compare content of existing header
                with open(header, 'r') as f:
                    if f.read() == content:
                        # content is the same
                        return False

            return True

        # prepare for targeted ADB-generation
        if os.path.isfile(target):
            # user specified own ADB file
            target = os.path.relpath(target)  # use relative path instead of user provided

            if target not in self.__adb_files:
                # we need to generate custom header file as user specified non-standard ADB
                self.__adb_files[target] = target + '.h'

            if target not in self._adb_parser.db_access('types_order', None):
                # we have to validate user's file before using it
                self._adb_parser.db_validate(target)

            target_files = [target]
        else:
            # user specified part of ADB filename or 'all'
            target_files = [f for f in self.__adb_files if target == 'all' or target in f]

        # check if there is any generation target
        if not target_files:
            g_logger.error('Invalid generation target provided "{}"'.format(target))
            exit(1)  # catchall for general errors

        # notify user
        g_logger.normal('Started generation of {} H-file(s) ..'.format(len(target_files)))
        begin = time.time()  # save timestamp before generation

        # start task "H-files generation"
        g_pbar.start('H-files generation')

        # define progress per H-file generation (round step to 6 digits after point)
        per_file_progress = round(100.0 / len(target_files), 6)

        for adb_file in sorted(target_files):
            order = self._adb_parser.db_access('types_order', adb_file)  # types generation order
            content = ''  # content of C-header file
            enum_macro_exist = False  # used for one-time enum MACRO generation
            out_file = os.path.basename(self.__adb_files[adb_file])  # name of header file

            # for each header ADB file generate corresponding C-header
            g_logger.debug('Generating {}'.format(out_file))

            # save previous node type for better nodes separation
            prev_ntype = None

            for node_name in order:
                # generate each type according to generation order
                item = self._adb_parser.db_access('types', node_name)
                item_name = item.get('typename') or item.get('name') or 'unknown'

                g_logger.log_stage(0, '[%s] %s' % (item['node_type'], item_name),
                                   last=(node_name is order[-1]))

                # one-time enum MACRO generation before first enum definition
                if not enum_macro_exist and item['node_type'] == nt.ENUM:
                    content += '\n/* Enum specific MACRO */\n' \
                        '#define SX_GENERATE_ENUM(ENUM, STR)   ENUM,\n' \
                        '#define SX_GENERATE_STRING(ENUM, STR) STR,\n'
                    enum_macro_exist = True

                # add newline if previous node type was different
                if prev_ntype and item['node_type'] != prev_ntype:
                    content += '\n'

                # data type generation
                content += self._gen_node(item['node_type'], item)
                prev_ntype = item['node_type']

                g_logger.log_stage_done(True)

            # wrap header with guard macro
            content = self.__wrap_header(adb_file, content)

            # ensure path to the file exist
            self.ensure_dir(self.__adb_files[adb_file])

            # beautify generated content
            content = self.__beautify_h_file_content(self.__adb_files[adb_file], content)

            if is_content_diff(self.__adb_files[adb_file], content):
                g_logger.success('File {} updated'.format(out_file))

                # write generated content to the file
                with open(self.__adb_files[adb_file], 'w') as f:
                    f.write(content)
            else:
                g_logger.debug('Content of {} was not changed'.format(out_file))

            # update progress "H-files generation"
            g_pbar.progress_inc(per_file_progress)

        # notify user
        g_logger.success('Generation finished in {:.4f} seconds'.format(time.time() - begin))

        # finish task "H-files generation"
        g_pbar.finish()

        begin = time.time()  # save timestamp before generation

        # Add license headers to the whole batch at a time
        ngci_tool = '/auto/sw_system_release/ci/ngci/ngci_tool/ngci_tool.sh'
        delimeter = ","
        target_files_names = delimeter.join([self.__adb_files[adb_file] for adb_file in target_files])
        cmd = "{} -hc --header-check repair-path {} >/dev/null 2>&1".format(ngci_tool, target_files_names)

        # trace the command
        g_logger.normal('Running NGCI_TOOL header checker...')
        g_logger.trace('Run NGCI_TOOL header checker over next files: {}'.format(target_files_names), end='\n')

        if os.system(cmd):
            g_logger.error('License beautification for {} has failed'.format(target_files_names))

        g_logger.success('NGCI_TOOL has finished in {:.4f} seconds'.format(time.time() - begin))

    def __beautify_h_file_content(self, header, content):
        """ Function create temp file, beautify its content and
            return this content back.

        Arguments:
            header {str} -- path to the original header
            content {str} -- content of the file
        """
        # write content to the temp file
        tmp_header = header[:-2] + '.tmp.h'
        with open(tmp_header, 'w') as f:
            f.write(content)

        # beautify temp file
        self.__beautify_h_file(tmp_header, silent=True)

        # upload beautified content
        with open(tmp_header, 'r') as f:
            content = f.read()

        # remove temp file
        if os.remove(tmp_header):
            g_logger.error('Failed to remove temp header file {}'.format(tmp_header))

        return content

    def __beautify_h_file(self, header, silent=False):
        """ Function runs beautification of the header file

        Arguments:
            header {str} -- path to header file
        """
        filename = os.path.basename(header)
        if not silent:
            # notify user
            g_logger.info('Run beautifier for {} ..'.format(filename))

        # beautify using Uncrustify tool
        uncrustify = '/auto/mswg/projects/sx_mlnx_os/tools/uncrustify'
        cfg_file = '/auto/sw_system_project/sx_mlnx_os/sx_fit_regression/infra/configuration/uncrustify.cfg'
        cmd = "{} -l C -c {} {} --replace --no-backup >/dev/null 2>&1".format(uncrustify, cfg_file, header)

        if not silent:
            # trace the command
            g_logger.trace('[command 1] {}'.format(cmd), end='\n')

        # run uncrustify tool for two times for better code beautification
        for i in range(2):
            if os.system(cmd):
                g_logger.error('Beautification for {} has failed on {} stage'.format(filename, i))
                return

        if not silent:
            # success
            g_logger.info('File {} has been beautified'.format(filename))

    def __wrap_header(self, adb_file, content):
        """ Function wrap content of header file with guard macro

        Arguments:
            adb_file {str} -- path to the ADB file
            content {str} -- original file content

        Returns:
            str -- wrapped file content
        """
        exclude_gates_name = self.__adb_files[adb_file].split('/')[-1].upper().replace('.', '_')
        wrap_tmpl = '{1}\n\n{2}#ifndef __{0}__\n#define __{0}__\n\n{3}\n#endif /* __{0}__ */\n'

        return wrap_tmpl.format(exclude_gates_name, "" if not self._adb_parser.licenses else self._adb_parser.licenses[adb_file],
                                self.__generate_top_header(adb_file), content)

    def show_head(self):
        """ Function print tool info at the beginning of execution """
        head = '  {}{{}}[version {} | {}]\n'.format(__title__, __version__, __release__)
        aligned_head = head.format(' ' * (93 - len(head)))

        g_logger.normal(' {0:-^90}\n{1} {0:-^90}\n'.format('', aligned_head), end='\n', label=False)


def show_help():
    head = '  {}{{}}[version {} | {}]\n'.format(__title__, __version__, __release__)
    aligned_head = head.format(' ' * (93 - len(head)))

    text = ' {0:-^90}\n{1} {0:-^90}\n\n'.format('', aligned_head)
    text += ' 1. How to run validation process?\n' + \
            '    [ for all files ] sx_header_gen.py -v [-d|--debug] [-f|--fix-xml]\n' + \
            '    [ for one file  ] sx_header_gen.py -v <adb_file> [-d|--debug] [-f|--fix-xml]\n' + \
            '    [    disable    ] sx_header_gen.py -v none [-d|--debug] [-f|--fix-xml]\n' + \
            '\n' + \
            ' 2. How to run generation process?\n' + \
            '    [ for all files ] sx_header_gen.py -g [-d|--debug] [-f|--fix-xml]\n' + \
            '    [ for one file  ] sx_header_gen.py -g <adb_file> [-d|--debug] [-f|--fix-xml]\n' + \
            '\n' + \
            ' Examples:\n' + \
            '    1. sx_header_gen.py -g -v -d\n' + \
            '    2. sx_header_gen.py -g -v none -f\n' + \
            '    3. sx_header_gen.py -g -v sx_port.adb --debug\n' + \
            '    4. sx_header_gen.py -g sx_port.adb -v\n' + \
            '    5. sx_header_gen.py -g sx_port.adb -v none --debug\n' + \
            '    6. sx_header_gen.py -g sx_port.adb -v sx_port.adb --fix-xml\n' + \
            '\n'

    g_logger.normal(text, end='\n', label=False)


def main(validate=None, generate=None, fix_xml=None, debug=None, help=None):
    # check if user required a help
    if help:
        show_help()
        return  # we should not do anything more when help requested

    if validate or generate:
        if debug:
            # disable progress bar when verbosity is high
            g_pbar.disable()

        # lookup ADB files
        includes = os.path.relpath(os.path.dirname(os.path.realpath(__file__)) + '/../../include/')
        adb_files = []
        for root, _, files in os.walk(includes):
            adb_files += [os.path.join(root, file) for file in files if file.endswith('.adb')]

        # create HeaderGenerator object (implicit ADABE validation here)
        h_gen = HeaderGenerator(adb_files, validate or 'all', debug=bool(debug), fix_xml=fix_xml)

        if validate:
            # notify user about successful validation
            g_logger.success('ADABE files validation passed')

        if generate:
            # run headers generation
            h_gen.generate(generate)
    else:
        # if no flags specified we shall print a help
        show_help()


if __name__ == '__main__':
    # parse script options
    argparser = argparse.ArgumentParser(description='SX API Generation tool.', add_help=False)

    argparser.add_argument('-g', '--generate', type=str, nargs='?', const='all', help='Run SX API headers generation')
    argparser.add_argument('-v', '--validate', type=str, nargs='?', const='all', help='Validate ADABE files without running headers generation ')
    argparser.add_argument('-f', '--fix-xml', action='store_true', help='Fix special characters in ADB files')
    argparser.add_argument('-d', '--debug', action='store_true', help='Enables debug logging level')
    argparser.add_argument('-h', '--help', action='store_true', help='Get help instructions')

    args = argparser.parse_args()
    sys.exit(main(**(vars(args))))
