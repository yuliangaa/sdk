/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __PCAP_H_INCLUDED__
#define __PCAP_H_INCLUDED__

#include <sys/types.h>
#include <sys/time.h>
#include <stdint.h>
#include <stdio.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define PCAP_VERSION_MAJOR 2
#define PCAP_VERSION_MINOR 4
#define PCAP_MAGIC         (0xa1b2c3d4)

#define PCAP_ERRBUF_SIZE 256
#define PCAP_MAX_SNAPLEN (65535)
#define LINKTYPE_NULL    (0)

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct pcap_file_header {
    uint32_t magic;
    uint16_t version_major;
    uint16_t version_minor;
    int32_t  thiszone;
    uint32_t sigfigs;
    uint32_t snaplen;
    uint32_t linktype;
} pcap_file_header_t;

typedef struct pcap_pkthdr {
    uint32_t tv_sec;
    uint32_t tv_usec;
    uint32_t caplen;
    uint32_t len;
} pcap_pkthdr_t;

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __PCAP_H_INCLUDED__ */
