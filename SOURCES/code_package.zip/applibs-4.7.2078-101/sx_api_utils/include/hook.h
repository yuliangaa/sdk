/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __HOOK_H_INCLUDED__
#define __HOOK_H_INCLUDED__

#include <complib/cl_commchnl.h>

#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/sdk/sx_api_cos.h>
#include <sx/sdk/sx_api_fdb.h>
#include <sx/sdk/sx_api_flow_counter.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_lag.h>
#include <sx/sdk/sx_api_mstp.h>
#include <sx/sdk/sx_api_policer.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_api_router.h>
#include <sx/sdk/sx_api_span.h>
#include <sx/sdk/sx_api_topo.h>
#include <sx/sdk/sx_api_vlan.h>
#include <sx/sdk/sx_api_bridge.h>
#include <sx/sdk/sx_api_tunnel.h>

#include <sx_api/sx_api_internal.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
#define HOOKED_FILE_PATH SX_API_COMMCHNL_ADDRESS

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
/*
 * The packet can be either one of two types:
 * Command => command from the user to the sx_sdk.
 *                        in this case, it will be received on sniffer side, and send on player side.
 * Reply   => reply from the sx_sdk back to the user.
 *                        in this case, it will be received on player side, and send on sniffer side.
 * Sysfs   => sysfs read or write access from the user to sysfs files.
 *                        in this case, it will be received on sniffer side, and send on player side.
 * */
typedef enum {
    BUFFER_SIDE_REPLY_E = 0,
    BUFFER_SIDE_CMD_E,
    BUFFER_SIDE_SYSFS_E,
    BUFFER_SIDE_EVENTS_E
} buffer_side_e;

typedef struct {
    /* Which packet type is that? (Read comment above) */
    buffer_side_e side;
    union {
        unsigned char         raw[SX_API_MESSAGE_SIZE_LIMIT];
        sx_api_reply_head_t   reply;
        sx_api_command_head_t cmd;
        sx_api_sysfs_head_t   sysfs_access;
    } buffer;
} packet_t;

typedef struct timeval timeval_t;

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* __HOOK_H_INCLUDED__ */
