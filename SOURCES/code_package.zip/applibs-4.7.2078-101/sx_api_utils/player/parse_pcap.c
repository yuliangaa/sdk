/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "parse_pcap.h"
#include <unistd.h>
#include <stdio.h>
#include <pcap.h>
#include <stdbool.h>
#include <malloc.h>
#include <string.h>

#include "player_internal.h"


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/* Store last user command on mismatch */
static char     last_user_cmd = 0;
extern uint32_t g_iter_num;
/************************************************
 *  Local function declarations
 ***********************************************/
static int __pcap_read_loop(FILE * f, uint32_t max_buffer_size, parse_func parser, void * hContext);
int sysfs_parser(void             * hContext,
                 const char * const buffer,
                 uint32_t           tv_sec,
                 uint32_t           tv_usec,
                 uint32_t           buffer_size);
/************************************************
 *  Function implementations
 ***********************************************/
#define SYSFS_FILE_PATH_LEN 256
#define SYSFS_READ_BUF_SIZE 4096

int sysfs_parser(void * hContext, const char * const buffer, uint32_t tv_sec, uint32_t tv_usec, uint32_t buffer_size)
{
    context_t            * pCtx = (context_t*)hContext;
    sx_player_status_t     ret = SX_PLAYER_OK_E;
    char                   read_buf[SYSFS_READ_BUF_SIZE + 1] = {'\0'};
    int                    write_buffer_size = 0;
    FILE                  *f_sysfs = NULL;
    char                   file_path[SYSFS_FILE_PATH_LEN + 1] = {'\0'};
    timeval_t              packet_timeval;
    const packet_t * const pPkt = (const packet_t*const)buffer;
    int                    i = 0;
    int                    open_for_binary = 0;
    char                  *read_s_ret = NULL;

    memset(&packet_timeval, 0, sizeof(packet_timeval));

    if ((NULL == pCtx) || (NULL == buffer)) {
        return SX_PLAYER_ERROR_E;
    }

    if (pCtx->sysfs_mode == SYSFS_EXCLUDE) {
        return SX_PLAYER_OK_E;
    }

    if ((pPkt->buffer.sysfs_access.is_write == 0) && (pCtx->sysfs_mode == SYSFS_SET_ONLY)) {
        return SX_PLAYER_OK_E;
    }

    pCtx->cap_id += 1;
    if (pCtx->cap_id > g_iter_num) {
        return SX_PLAYER_ITER_OVERFLOW_E;
    }

    packet_timeval.tv_sec = tv_sec;
    packet_timeval.tv_usec = tv_usec;

    printf(CAP_LINE_SYM "orig..... (%ld.%06lu secs)\n",
           pCtx->cap_id,
           packet_timeval.tv_sec,
           packet_timeval.tv_usec);

    strncpy(file_path, (char*)pPkt->buffer.sysfs_access.path, SYSFS_FILE_PATH_LEN);


    if (FALSE == pCtx->dry_run) {
        if (pPkt->buffer.sysfs_access.is_write) {
            write_buffer_size = buffer_size - sizeof(sx_api_sysfs_head_t) - sizeof(pPkt->side);
            /* check if we should open the file as "w" or "wb" */
            for (i = 0; i < write_buffer_size; i++) {
                if ((pPkt->buffer.raw + sizeof(sx_api_sysfs_head_t))[i] > 127) {
                    open_for_binary = 1;
                    break;
                }
            }

            if (open_for_binary) {
                f_sysfs = fopen(file_path, "wb");
            } else {
                f_sysfs = fopen(file_path, "w");
            }
            if (NULL == f_sysfs) {
                fprintf(stderr, "Could not open sysfs file %s for writing.\n", file_path);
                ret = SX_PLAYER_ERROR_E;
                goto out;
            }
            fwrite(pPkt->buffer.raw + sizeof(sx_api_sysfs_head_t), sizeof(char), write_buffer_size, f_sysfs);
        } else {
            f_sysfs = fopen(file_path, "r");
            if (NULL == f_sysfs) {
                fprintf(stderr, "Could not open sysfs file %s for reading.\n", file_path);
                ret = SX_PLAYER_ERROR_E;
                goto out;
            }
            /*read the first 128 bytes in the sysfs file */
            read_s_ret = fgets(read_buf, SYSFS_READ_BUF_SIZE, f_sysfs);
            if (read_s_ret == NULL) {
                fprintf(stderr, "Could not read sysfs file %s.\n", file_path);
                /* The file might be empty, so we continue to play. */
            }
        }
    }

    if (pPkt->buffer.sysfs_access.is_write) {
        printf(CAP_LINE_SYM "SYSFS write to file %s Sent. Size = %d\n", pCtx->cap_id, file_path, write_buffer_size);
    } else {
        printf(CAP_LINE_SYM "SYSFS read from file %s.\n", pCtx->cap_id, file_path);
    }

/*
 *   fprintf(stderr, "sysfs path: [%s], is_write: [%d], CB name: [%s], buffer_size: [%d], write_buffer_size [%d], write_buffer [%s].\n",
 *           file_path,
 *           pPkt->buffer.sysfs_access.is_write,
 *           pPkt->buffer.sysfs_access.func_name,
 *           buffer_size,
 *           write_buffer_size,
 *           write_buffer);
 */


out:

    if (f_sysfs) {
        fclose(f_sysfs);
    }
    return ret;
}


static int __pcap_read_loop(FILE * f, uint32_t max_buffer_size, parse_func parser, void * hContext)
{
    context_t     * pCtx = (context_t*)hContext;
    pcap_pkthdr_t   packet_header;     /* Header of command/replay/sysfs packet */
    pcap_pkthdr_t   cmd_header;         /* Header of command packet */
    pcap_pkthdr_t   reply_header;       /* Header of reply packet */
    char          * packet_buffer = NULL; /* Data buffer of command/replay/sysfs packet */
    char          * cmd_buffer = NULL;  /* Data buffer of command packet */
    char          * reply_buffer = NULL; /* Data buffer of reply packet */
    int             ret = 0;
    int16_t         user_cmd = 0;
    boolean_t       ask_user_action = TRUE;
    boolean_t       flush_stdin = TRUE;
    const packet_t *pPkt;
    boolean_t       cmd_found = FALSE;
    boolean_t       reply_found = FALSE;

    /* Clean headers */
    memset(&cmd_header, 0, sizeof(cmd_header));
    memset(&reply_header, 0, sizeof(reply_header));

    /* Allocate maximum buffer allowed for current packet content */
    packet_buffer = (char*)malloc(max_buffer_size);
    if (NULL == packet_buffer) {
        fprintf(stderr, "Failed to allocate memory for packet buffer (size=%d)\n", max_buffer_size);
        ret = SX_PLAYER_ERROR_E;
        goto out;
    }

    cmd_buffer = (char*)malloc(max_buffer_size);
    if (NULL == cmd_buffer) {
        fprintf(stderr, "Failed to allocate memory for command buffer (size=%d)\n", max_buffer_size);
        ret = SX_PLAYER_ERROR_E;
        goto out;
    }

    /* Allocate maximum buffer allowed for previous packet content */
    reply_buffer = (char*)malloc(max_buffer_size);
    if (NULL == reply_buffer) {
        fprintf(stderr, "Failed to allocate memory for reply buffer (size=%d)\n", max_buffer_size);
        ret = SX_PLAYER_ERROR_E;
        goto out;
    }

    /* For each frame, run parser */
    do {
        /*read packets from the pcap file until we have command and replay buffers ready */
        while ((cmd_found == FALSE) || (reply_found == FALSE)) {
            /* Read the PCAP packet header */
            if (sizeof(packet_header) != fread((char*)&packet_header, 1, sizeof(packet_header), f)) {
                if (0 != feof(f)) {
                    /* EOF Reached */
                    break;
                }

                fprintf(stderr, "Failed to read packet header.");
                ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
                goto out;
            }

            /* Make sure capture length is valid */
            if (packet_header.caplen > max_buffer_size) {
                fprintf(stderr,
                        "Found packet frame with bigger capture length (%d) than allowed (%d)\n",
                        packet_header.caplen,
                        max_buffer_size);
                ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
                goto out;
            }

            /* Read the packet frame */
            if (packet_header.caplen != fread(packet_buffer, 1, packet_header.caplen, f)) {
                fprintf(stderr, "Failed to read PCAP packet.\n");
                ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
                goto out;
            }

            /* check if the packet is sysfs/command/replay */
            pPkt = (const packet_t*)packet_buffer;
            switch (pPkt->side) {
            case BUFFER_SIDE_SYSFS_E:
                ret = sysfs_parser(hContext,
                                   packet_buffer,
                                   packet_header.tv_sec,
                                   packet_header.tv_usec,
                                   packet_header.caplen);
                if (ret) {
                    fprintf(stderr, "Failed to read sysfs PCAP packet. parsing error. ");
                    if (pCtx->ignore_sysfs_fail == FALSE) {
                        fprintf(stderr,
                                "Exit player. To run player and ignore sysfs failure, use --ignore-sysfs-fail.\n");
                        ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
                    } else {
                        fprintf(stderr, "Ignoring sysfs failures.\n");
                        ret = SX_PLAYER_OK_E;
                    }
                }
                break;

            case BUFFER_SIDE_CMD_E:
                if (pCtx->sysfs_mode == SYSFS_ONLY) {
                    continue;
                }
                if (cmd_found) {
                    fprintf(stderr, "Failed to read PCAP packet.expected replay, got command.\n");
                    ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
                    goto out;
                }
                SX_MEM_CPY(cmd_header, packet_header);
                SX_MEM_CPY_BUF(cmd_buffer, packet_buffer, packet_header.caplen);
                cmd_found = TRUE;
                break;

            case BUFFER_SIDE_REPLY_E:
                if (pCtx->sysfs_mode == SYSFS_ONLY) {
                    continue;
                }
                if (!cmd_found) {
                    fprintf(stderr, "Failed to read PCAP packet. Got replay before command.\n");
                    ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
                    goto out;
                }

                SX_MEM_CPY(reply_header, packet_header);
                SX_MEM_CPY_BUF(reply_buffer, packet_buffer, packet_header.caplen);
                reply_found = TRUE;
                break;

            case BUFFER_SIDE_EVENTS_E:
                /* We dont want to play these events*/
                continue;
                break;

            default:
                fprintf(stderr, "Failed to read PCAP packet. side sysfs side parse error.\n");
                ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
                goto out;
            }
        }
        if (0 != feof(f)) {
            /* EOF Reached */
            break;
        }
        cmd_found = FALSE;
        reply_found = FALSE;


        /* Stop before fail if user asked */
        if ((pCtx->stop_before_fail == TRUE) && (((packet_t*)reply_buffer)->buffer.reply.retcode != 0)) {
            WAIT_FOR_ENTER_PRESS(PREFIX_BEFORE_FAIL, user_cmd);
        }

        /* Check if user wants to stop before next packet */
        if (pCtx->stop_on_id == (pCtx->cap_id + 1)) {
            WAIT_FOR_ENTER_PRESS(PREFIX_STOP_ON_ID, user_cmd);
        }

        /* Call the parser for command packet */
        ret = parser(hContext, cmd_header.tv_sec, cmd_header.tv_usec, cmd_buffer, cmd_header.caplen);
        if (ret == SX_PLAYER_ITER_OVERFLOW_E) {
            /* Provide normal processing for this error code */
            ret = SX_PLAYER_OK_E;
            goto out;
        } else if (SX_PLAYER_OK_E != ret) {
            /* Fail otherwise */
            goto out;
        }

        /* Check if user wants to stop before next packet */
        if (pCtx->stop_on_id == (pCtx->cap_id + 1)) {
            WAIT_FOR_ENTER_PRESS(PREFIX_STOP_ON_ID, user_cmd);
        }

        /* Call the parser for reply packet */
        ret = parser(hContext, reply_header.tv_sec, reply_header.tv_usec, reply_buffer, reply_header.caplen);
        if (ret == SX_PLAYER_ITER_OVERFLOW_E) {
            /* Provide normal processing for this error code */
            ret = SX_PLAYER_OK_E;
            goto out;
        } else if (ret == SX_PLAYER_CALL_MISMATCH_E) {
            /* Stop on mismatch */
            ask_user_action = TRUE;

            do {
                /* Ask user */
                printf(PREFIX_ON_MISMATCH "Choose the option below:\n"
                       "  > Enter 'r' to re-send previous API call.\n"
                       "  > Enter 'c' to continue playing APIs.\n"
                       "  > Enter 'q' to stop sx_player.\n"
                       PREFIX_ON_MISMATCH ": ");

                /* Get user input */
                user_cmd = getchar();

                /* Set flag to flush any other input from stdin */
                flush_stdin = TRUE;

                if (user_cmd == '\n') {
                    /* No need to flush input */
                    flush_stdin = FALSE;

                    if (last_user_cmd != 0) {
                        /* Re-use the last command */
                        printf(PREFIX_ON_MISMATCH "Re-use last command '%c'.\n", last_user_cmd);
                        user_cmd = last_user_cmd;
                    }
                }

                /* Process user input */
                switch (user_cmd) {
                case 'c':
                case 'C':
                    /* Continue */
                    last_user_cmd = 'c';

                    /* User wants to continue execution */
                    ask_user_action = FALSE;
                    break;

                case 'r':
                case 'R':
                    /* Re-play */
                    last_user_cmd = 'r';

                    /* Decrease packet capture ID because we re-send previous packets */
                    pCtx->cap_id -= 2;

                    /* Send previous and current packets again */
                    ret = parser(hContext, cmd_header.tv_sec, cmd_header.tv_usec,
                                 cmd_buffer, cmd_header.caplen);
                    if (SX_PLAYER_OK_E != ret) {
                        fprintf(stderr, PREFIX_ON_MISMATCH "Command packet re-send failed.\n");
                    }

                    ret = parser(hContext, reply_header.tv_sec, reply_header.tv_usec,
                                 reply_buffer, reply_header.caplen);
                    if (SX_PLAYER_OK_E != ret) {
                        fprintf(stderr, PREFIX_ON_MISMATCH "Reply packet re-send failed.\n");
                    }

                    break;

                case 'q':
                case 'Q':
                    /* Quit */
                    printf(PREFIX_ON_MISMATCH "Exiting sx_player on user demand.\n");
                    ret = SX_PLAYER_OK_E;
                    goto out;

                default:
                    fprintf(stderr, PREFIX_ON_MISMATCH "Invalid command used.\n");
                    break;
                }

                if (TRUE == flush_stdin) {
                    /* Flush stdin before getting the next symbol */
                    while ((user_cmd = getchar()) != '\n' && user_cmd != EOF) {
                    }
                }
            } while (TRUE == ask_user_action);
        } else if (SX_PLAYER_OK_E != ret) {
            /* Fail otherwise */
            goto out;
        }
    } while (1);

out:
    if (cmd_buffer != NULL) {
        free(cmd_buffer);
        cmd_buffer = NULL;
    }

    if (reply_buffer != NULL) {
        free(reply_buffer);
        reply_buffer = NULL;
    }

    if (packet_buffer != NULL) {
        free(packet_buffer);
        packet_buffer = NULL;
    }

    return ret;
}

int parse_pcap(const char * file_path,
               uint32_t     expected_linktype,
               parse_func   parser,
               void       * hContext,
               uint32_t     max_snaplen)
{
    FILE             * f = NULL;
    int                ret = 0;
    pcap_file_header_t pcap_header;

    memset(&pcap_header, 0, sizeof(pcap_header));

    /* Param validation */
    if ((NULL == file_path) || (NULL == parser)) {
        fprintf(stderr, "NULL provided for mandatory parameter.\n");
        ret = SX_PLAYER_ERROR_E;
        goto out;
    }

    /* Open the file */
    f = fopen(file_path, "r");
    if (NULL == f) {
        fprintf(stderr, "Could not open file %s\n", file_path);
        ret = SX_PLAYER_ERROR_E;
        goto out;
    }

    /* Read the pcap header */
    if (sizeof(pcap_header) != fread((char*)&pcap_header, 1, sizeof(pcap_header), f)) {
        fprintf(stderr, "Failed to read pcap header\n");
        ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
        goto out;
    }

    /* Verify the pcap header */
    if (pcap_header.magic != PCAP_MAGIC) {
        fprintf(stderr, "Failed to validate pcap header, found 0x%08X instead.\n", pcap_header.magic);
        ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
        goto out;
    }

    /* Verify link type */
    if (expected_linktype != pcap_header.linktype) {
        fprintf(stderr, "Failed to link type, found 0x%08X instead.\n", pcap_header.linktype);
        ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
        goto out;
    }

    /* Verify snaplen (maximum packet length allowed) */
    if (pcap_header.snaplen > max_snaplen) {
        fprintf(stderr, "Snaplen 0x%08X is higher then allowed\n", pcap_header.snaplen);
        ret = SX_PLAYER_PCAP_PARSE_FAIL_E;
        goto out;
    }

    /* Start processing the packet frames */
    ret = __pcap_read_loop(f, pcap_header.snaplen, parser, hContext);
    if (SX_PLAYER_OK_E != ret) {
        fprintf(stderr, "Parsing loop failed.\n");
        goto out;
    }

out:
    if (NULL != f) {
        fclose(f);
        f = NULL;
    }

    return ret;
}
