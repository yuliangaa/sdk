#!/usr/bin/env python3
import sys
import argparse

'''
 * The PKCMU CRC-16 and CRC-32 polynomials.
 * =========================================================
 * PKCMU - Philip Koopman Carnegie Mellon University.
 * =========================================================
 * The polynomial value is based on Philip Koopman research
 * in Carnegie Mellon University.
 *
 * Research results: https://users.ece.cmu.edu/~koopman/crc/
 * License: https://creativecommons.org/licenses/by/4.0/
'''
CRC16_PKCMU_NORMAL_POLY = 0x800b
CRC32_PKCMU_NORMAL_POLY = 0x973AFB51


class CRC16:
    """ CRC-16 hash function class
    """

    def __init__(self):
        self.__poly = 0  # hashing polynomial
        self.__byte_sz = 8  # size of byte
        self.__table_sz = 256  # size of hashing table
        self.__crc16_start = 0  # initial value of CRC16 hash

        # Hashing table
        self.__table_inited = False
        self.__table = [0 for i in range(self.__table_sz)]

    def init_table(self, poly):
        """ Function performs hash table initialization

        Arguments:
            poly {hexadecimal} -- polynomial used for hashing
        """
        # save the polynomial
        self.__poly = poly

        # run hash table initialization
        for i in range(self.__table_sz):
            thash = i
            for j in range(self.__byte_sz):
                if thash & 0x0001:
                    thash = (thash >> 1) ^ self.__poly
                else:
                    thash = thash >> 1
            self.__table[i] = thash & 0xFFFF

        # mark table initialized
        self.__table_inited = True

    def hash(self, input_str: bytes, poly=CRC16_PKCMU_NORMAL_POLY):
        """ Function perform string hashing

        Arguments:
            input_str {bytes} -- string to be hashed

        Keyword Arguments:
            poly {hexadecimal} -- polynomial used for hashing (default: {CRC16_PKCMU_NORMAL_POLY})

        Returns:
            hexadecimal -- hashed value
        """

        # check if hash table has been initialized
        if not self.__table_inited:
            self.init_table(poly)
        elif self.__poly != poly:
            # polynomial for hashing is another that was used before
            print('[[ Polynomial mismatch ]] CFG: {}; USED: {}'.format(self.__poly, poly))
            return None

        # prepare initial values for hashing
        crc16 = self.__crc16_start
        itext = bytes(input_str, encoding='utf8')

        if itext:
            # run hashing for the string
            for alpha in itext:
                short_c = 0x00ff & alpha
                tmp = crc16 ^ short_c
                crc16 = (crc16 >> 8) ^ self.__table[tmp & 0xff]

        return crc16 & 0xFFFF

    def __str__(self):
        """ Function dumps hash table
        """
        text = '---------------------------\n' + \
               'CRC-16 HASH TABLE DUMP\n' + \
               'Inited: {}; '.format(self.__table_inited) + \
               'Size: {}\n'.format(self.__table_sz) + \
               'Poly: 0x{:04x}\n'.format(self.__poly) + \
               '---------------------------\n'

        block_sz = 16
        text += '\n'.join([' '.join(['%04x' % x for x in self.__table[i: i + block_sz]]) for i in range(block_sz)])
        text += '\n---------------------------\n'
        return text


def test_crc16(silent=True):
    """ Function tests CRC-16 function to be valid.

    Keyword Arguments:
        silent {bool} -- enables test info output (default: {True})

    Raises:
        Exception: Test mismatch
    """
    crc16 = CRC16()
    data = {'in': ['SX_API_INT_CMD_SDK_INIT_E', 'SX_API_INT_CMD_CLOSE_EVENT_SRC_E'],
            'out': [0x11a1, 0x4172]}

    for i, text in enumerate(data['in']):
        hashed = crc16.hash(text, CRC16_PKCMU_NORMAL_POLY)

        if not silent:
            res = '\n--- Test case #%d ---------------------------\n' % i + \
                  'String: "{}".\n'.format(text) + \
                  'Expect: {:04x}.\n'.format(data['out'][i]) + \
                  'Hashed: {:04x}.\n'.format(hashed) + \
                  'Status: [ %s ]\n' % ('OK' if hashed == data['out'][i] else 'MISMATCH')
            print(res)

        if hashed != data['out'][i]:
            raise Exception('[Hashing test] Mismatch occured.')

    print('[Hashing test for CRC-16] Passed.')


class CRC32:
    """ CRC-32 hash function class
    """

    def __init__(self):
        self.__poly = 0  # hashing polynomial
        self.__byte_sz = 8  # size of byte
        self.__table_sz = 256  # size of hashing table
        self.__crc32_start = 0  # initial value of CRC32 hash

        # Hashing table
        self.__table_inited = False
        self.__table = [0 for i in range(self.__table_sz)]

    def init_table(self, poly):
        """ Function performs hash table initialization

        Arguments:
            poly {hexadecimal} -- polynomial used for hashing
        """
        # save the polynomial
        self.__poly = poly

        # run hash table initialization
        for i in range(self.__table_sz):
            thash = i << 24
            for j in range(self.__byte_sz):
                if thash & 0x80000000:
                    thash = (thash << 1) ^ self.__poly
                else:
                    thash = thash << 1
            self.__table[i] = thash & 0xFFFFFFFF

        # mark table initialized
        self.__table_inited = True

    def hash(self, input_str: bytes, poly=CRC32_PKCMU_NORMAL_POLY):
        """ Function perform string hashing

        Arguments:
            input_str {bytes} -- string to be hashed

        Keyword Arguments:
            poly {hexadecimal} -- polynomial used for hashing (default: {CRC32_PKCMU_NORMAL_POLY})

        Returns:
            hexadecimal -- hashed value
        """

        # check if hash table has been initialized
        if not self.__table_inited:
            self.init_table(poly)
        elif self.__poly != poly:
            # polynomial for hashing is another that was used before
            print('[[ Polynomial mismatch ]] CFG: {}; USED: {}'.format(self.__poly, poly))
            return None

        # prepare initial values for hashing
        crc32 = self.__crc32_start
        itext = bytes(input_str, encoding='utf8')

        if itext:
            # run hashing for the string
            for alpha in itext:
                short_c = 0x00ff & alpha
                tmp = (crc32 >> 24) ^ short_c
                crc32 = (crc32 << 8) ^ self.__table[tmp & 0xff]

        return crc32 & 0xFFFFFFFF

    def __str__(self):
        """ Function dumps hash table
        """
        text = '---------------------------\n' + \
               'CRC-32 HASH TABLE DUMP\n' + \
               'Inited: {}; '.format(self.__table_inited) + \
               'Size: {}\n'.format(self.__table_sz) + \
               'Poly: 0x{:08x}\n'.format(self.__poly) + \
               '---------------------------\n'

        block_sz = 8
        text += '\n'.join([' '.join(['%08x' % x for x in self.__table[i: i + block_sz]]) for i in range(int(self.__table_sz / block_sz))])
        text += '\n---------------------------\n'
        return text


def test_crc32(silent=True):
    """ Function tests CRC-32 function to be valid.

    Keyword Arguments:
        silent {bool} -- enables test info output (default: {True})

    Raises:
        Exception: Test mismatch
    """
    crc32 = CRC32()
    data = {'in': ['SX_API_INT_CMD_SDK_INIT_E', 'SX_API_INT_CMD_CLOSE_EVENT_SRC_E'],
            'out': [0xa7d1fd08, 0xe878af49]}

    for i, text in enumerate(data['in']):
        hashed = crc32.hash(text, CRC32_PKCMU_NORMAL_POLY)

        if not silent:
            res = '\n--- Test case #%d ---------------------------\n' % i + \
                  'String: "{}".\n'.format(text) + \
                  'Expect: {:04x}.\n'.format(data['out'][i]) + \
                  'Hashed: {:04x}.\n'.format(hashed) + \
                  'Status: [ %s ]\n' % ('OK' if hashed == data['out'][i] else 'MISMATCH')
            print(res)

        if hashed != data['out'][i]:
            raise Exception('[Hashing test] Mismatch occured.')

    print('[Hashing test for CRC-32] Passed.')


def main(hash16, hash, test):
    if hash16 or test:
        test_crc16(silent=(False if test else True))
    if hash or test:
        test_crc32(silent=(False if test else True))

    if not test:
        crc = CRC16() if hash16 else CRC32()
        print('Input string: "{}"'.format(hash))
        print('Hashed value: 0x{:04x}'.format(crc.hash(hash)))

    return 0


if __name__ == '__main__':
    argparser = argparse.ArgumentParser(description='SX API Hash generator tool.')

    megroup = argparser.add_mutually_exclusive_group(required=True)
    megroup.add_argument('--hash16', required=False, help="String to hash using CRC-16", metavar="STRING")
    megroup.add_argument('--hash', required=False, help="String to hash using CRC-32", metavar="STRING")
    megroup.add_argument('-t', '--test', action='store_true', help='Test SX API Hash generation')

    args = argparser.parse_args()
    sys.exit(main(**(vars(args))))
