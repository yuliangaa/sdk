/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __PLAYER_H_INCLUDED__
#define __PLAYER_H_INCLUDED__

#include <stdio.h>
#include <stdint.h>
#include <malloc.h>
#include <unistd.h>
#include <getopt.h>
#include <sys/time.h>
#include <hook.h>
#include <pcap.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Defines
 ***********************************************/

#define TS_CMP_GREATER >

#define HEXDUMP_LINE (0x10)
/*
 * Characters			   = HEXDUMP
 * \n\0					   = 1
 * */
#define CHARDUMP_LINE (HEXDUMP_LINE + 1)

/* Line start is '\t%04X:' = 6
 * BYTES with spaces       = 3 * HEXDUMP_LINE
 * Space				   = 1
 * Char Dump			   = HEXDUMP
 * \n\0					   = 2
 */
#define HEXDUMP_PRINT_LINE (6 + (3 * HEXDUMP_LINE) + 1 + CHARDUMP_LINE + 2)

#define CAP_LINE_SYM "[%05d] "

#define API_FILTER_SIZE 1000


/************************************************
 *  Local Macros
 ***********************************************/
#define ENUM_TO_STR(op) \
case op:                \
    return #op;


/************************************************
 *  Local Type definitions
 ***********************************************/

/* Filtering mode type */
typedef enum {
    FILTER_MODE_NONE    = 0,
    FILTER_MODE_INCLUDE = 1,
    FILTER_MODE_EXCLUDE = 2,
} filter_mode_t;

/* Type of packet mismatch */
typedef enum {
    MISMATCH_TYPE_NONE = 0,
    MISMATCH_TYPE_DATA,
    MISMATCH_TYPE_RC,
    MISMATCH_TYPE_ANY,
} mismatch_type_t;


/* Sysfs mode type */
typedef enum {
    SYSFS_SET_GET  = 0,  /* play both read and write sysfs access */
    SYSFS_SET_ONLY = 1,    /* play only write sysfs access */
    SYSFS_EXCLUDE  = 2, /* don't play sysfs access */
    SYSFS_ONLY     = 3, /* play only sysfs access */
} sysfs_mode_t;


/* Parsing context object */
typedef struct {
    uint32_t             cap_id;
    buffer_side_e        expected_side;
    boolean_t            sync;
    boolean_t            dry_run;
    boolean_t            filter_next;
    timeval_t            last_call_ts;
    filter_mode_t        filter_mode;
    mismatch_type_t      stop_mismatch_type;
    boolean_t            stop_before_fail;
    uint32_t             stop_on_id;
    sysfs_mode_t         sysfs_mode;
    boolean_t            ignore_sysfs_fail;
    const char         * pFilterFilePath;
    const char         * pFilePath;
    sx_api_user_ctxt_t * sx_api_ctx; /* Context from sx_api_open */
} context_t;

typedef enum {
    ARG_NO_SYNC_E           = 1000,
    ARG_DRY_RUN_E           = 1001,
    ARG_INCLUDE_E           = 1002,
    ARG_EXCLUDE_E           = 1003,
    ARG_ITER_E              = 1004,
    ARG_STOP_ON_MISMATCH_E  = 1005,
    ARG_STOP_BEFORE_FAIL_E  = 1006,
    ARG_STOP_ON_ID_E        = 1007,
    ARG_SYSFS_MODE_E        = 1008,
    ARG_IGNORE_SYSFS_FAIL_E = 1009,

    /* Keep last */
    ARG_HELP_E = 'h',
} ARGS_e;

/* sx_player_status_t is used to exchange information regarding
 * the execution status of different flows in this tool. */
typedef enum {
    SX_PLAYER_OK_E                 = 0,  /* Operation succeed */
    SX_PLAYER_ERROR_E              = -1, /* Some sort of error happened */
    SX_PLAYER_ARGS_PARSE_FAIL_E    = -2, /* Failed to parse arguments */
    SX_PLAYER_PCAP_PARSE_FAIL_E    = -3, /* Failed to parse PCAP */
    SX_PLAYER_CHANNEL_OPEN_FAIL_E  = -4, /* Failed to open communication channel */
    SX_PLAYER_CHANNEL_CLOSE_FAIL_E = -5, /* Failed to close communication channel */
    SX_PLAYER_TIME_GET_FAIL_E      = -6, /* Failed to get time */
    SX_PLAYER_BUFFER_WRONG_SIDE_E  = -7, /* Wrong value in API packet side */
    SX_PLAYER_BUFFER_SEND_FAIL_E   = -8, /* Failed to send buffer */
    SX_PLAYER_BUFFER_RECV_FAIL_E   = -9, /* Failed to receive buffer */
    SX_PLAYER_ITER_OVERFLOW_E      = -10, /* Capture ID overflow happened */
    SX_PLAYER_CALL_MISMATCH_E      = -11, /* Packets mismatched */
} sx_player_status_t;

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
#endif /* __PLAYER_H_INCLUDED__ */
