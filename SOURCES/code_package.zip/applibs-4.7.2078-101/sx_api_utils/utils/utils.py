"""
# SX API Utils Library
#
# Provide functionality for logging and ADB files
# parsing to SX API Generator and SX API Logger.
# Contain common objects implementation.
#
"""
__title__ = 'SX_API_UTILS_LIBRARY'
__author__ = 'oleksandrv, ypasichnyk'
__version__ = '1.11.0'
__release__ = 'June-2022'

import os
import re
import sys
import time
import signal
import threading
import functools
import xml.etree.ElementTree as ET

from glob import glob
from datetime import datetime


class NodeType:
    """
    Class used to unify node types definition
    """
    CODE = 'code'
    ENUM = 'enum'
    UNION = 'union'
    DEFINE = 'define'
    STRUCT = 'struct'
    INCLUDE = 'include'
    TYPEDEF = 'typedef'


class FontColor:
    NRM = '\x1b[0m'
    RED = '\x1b[31m'
    BLE = '\x1b[34m'
    CYA = '\x1b[36m'
    GRN = '\x1b[92m'
    YLW = '\x1b[33m'
    MGN = '\x1b[35m'
    WHT = '\x1b[97m'


class LogLevel:
    CRITICAL = 0
    ERROR = 1
    WARNING = 2
    SUCCESS = 3
    NORMAL = 4
    INFO = 5
    DEBUG = 6
    TRACE = 7

    token = {CRITICAL: 'CRITICAL',
             ERROR: 'ERROR',
             WARNING: 'Warning',
             SUCCESS: 'Success',
             NORMAL: 'Normal',
             INFO: 'info',
             DEBUG: 'debug',
             TRACE: 'trace'}

    color = {CRITICAL: FontColor.MGN,
             ERROR: FontColor.RED,
             WARNING: FontColor.YLW,
             SUCCESS: FontColor.GRN,
             NORMAL: FontColor.NRM,
             INFO: FontColor.WHT,
             DEBUG: FontColor.BLE,
             TRACE: FontColor.CYA}


class Singleton(type):
    """ Class implements Singleton pattern """
    _instances = {}

    def __call__(cls, *args, **kwargs):
        # Small hack to make sure a class using Singleton as metaclass, always referenced by same path.
        # This is in order to avoid scenarios where same class was imported from different paths, e.g.:
        #   from x.y.z import SomeClass
        #   from y.z import SomeClass
        # -> This results in 2 different instances of SomeClass, although SomeClass should be a singleton
        from utils.utils import Singleton as RealSingleton    # pylint: disable=import-self
        if cls.__name__ not in RealSingleton._instances:
            RealSingleton._instances[cls.__name__] = super(Singleton, cls).__call__(*args, **kwargs)
        return RealSingleton._instances[cls.__name__]


class Logger(object, metaclass=Singleton):
    # logger is a singleton object
    """
    Class provide functionality for printing user-friendly
    logs into CLI.

    Attributes
    ----------
    __stage   : dict
                stage information
    __dump    : str
                path to dump file
    gLogLevel : int
                identificator of current logging verbosity level
    """

    def __init__(self, log_level=LogLevel.CRITICAL, dump=None, cli=True, color=True):
        """ Logger constructor perform basic object initialization

        :param log_level: global LogLevel
        :param dump: path to dump file
        :param cli: print logs to console
        :param color: flag for colored text
        """
        self._stage = {'id': 1, 'done': True}
        self.params_set(log_level, dump, cli, color)

    def params_set(self, log_level=LogLevel.CRITICAL, dump=None, cli=True, color=True):
        self.gLogLevel = log_level
        self._dump = dump
        self._cli = cli
        self._color = color

        # flush output file
        if self._dump and os.path.isfile(self._dump):
            with open(self._dump, 'w') as f:
                f.write('')

    def log(self, lvl, user_msg, end='.\n', label=True, force_cli=False, only_cli=False):
        """ Function prints log messages according to log levels
        configuration.

        :param lvl: log level of message
        :param user_msg: message itself
        :param end: custom sequence at the end of log
        :param label: enable timestamp and log level label before message
        :param force_cli: print message to CLI anyway
        :param only_cli: print message only to CLI
        """
        # check if log level is valid and higher that configured verbosity
        if lvl not in LogLevel.token or lvl > self.gLogLevel:
            return

        # prepend timestamp and log level
        log_label = ' [%s] %s: ' % (datetime.now().time(),
                                    self.highlight(LogLevel.color[lvl], LogLevel.token[lvl])) if label else ''

        # compose final message
        log_msg = log_label + str(user_msg) + end

        if self._cli or force_cli or only_cli:
            # print log message to the CLI
            sys.stdout.write(log_msg if self._color else self.uncolor(log_msg))
            sys.stdout.flush()

        if not only_cli:
            # print log message to the file
            self.dump(log_msg)

    def dump(self, data):
        """ Function dump data to the file

        :param data: data that should be written into a file
        """
        # write to dump file if file path has been provided
        if self._dump:
            with open(self._dump, 'a+') as f:
                f.write(self.uncolor(data))

    def get_dump_file(self):
        """ Function return path to dump file """
        return self._dump

    def set_level(self, lvl):
        """ Set new logging level """
        if lvl not in LogLevel.token or lvl == self.gLogLevel:
            # user provided invalid or existing log level
            return

        self.gLogLevel = lvl

    def get_level(self):
        """ Get current logging level """
        return self.gLogLevel

    def set_color(self, enable):
        self._color = True if enable else False

    def log_stage(self, tabs, name, offset=60, last=False, level=LogLevel.DEBUG):
        """ Function prints some procedure stage information

        :param tabs: identation of stages printout
        :param name: name of stage
        :param offset: total stage output width
        :param last: point that this stage is last in procedure
        """
        if not self._stage['done']:
            # show fail if previous stage was not finished
            self.log_stage_done(False)

        stage_str = '{}{:> 3}. {} '.format('  ' * tabs, self._stage['id'], name)
        self.log(level, '{{:.<{}}}'.format(offset).format(stage_str), end='')

        # increment or flush stage ID and set stage not done
        self._stage['id'] = 1 if last else (self._stage['id'] + 1)
        self._stage['done'] = False

    def log_stage_done(self, success=True, level=LogLevel.DEBUG):
        """ Function finish stage and print it's status.

        :param success: status of stage execution
        """
        msg = self.highlight(FontColor.GRN, '[OK]') if success else self.highlight(FontColor.RED, '[FAIL]')
        self.log(level, msg, end='\n', label=False)

        # mark stage as done
        self._stage['done'] = True

    def highlight(self, color, text):
        """ Function highlight text by some font color

        :param color: needed color of text
        :param text: text itself
        :return: colorized text
        """
        return color + text + FontColor.NRM

    def uncolor(self, data):
        """ Function remove any ANSI colours from data

        :param data: text with colors inside
        :return: uncolored data
        """
        # regexp used to remove colours from data
        ansi_clear = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
        return ansi_clear.sub('', data)

    def critical(self, user_msg, end='.\n', label=True, force_cli=False, only_cli=False):
        self.log(LogLevel.CRITICAL, user_msg, end=end, label=label, force_cli=force_cli, only_cli=only_cli)

    def error(self, user_msg, end='.\n', label=True, force_cli=False, only_cli=False):
        self.log(LogLevel.ERROR, user_msg, end=end, label=label, force_cli=force_cli, only_cli=only_cli)

    def warning(self, user_msg, end='.\n', label=True, force_cli=False, only_cli=False):
        self.log(LogLevel.WARNING, user_msg, end=end, label=label, force_cli=force_cli, only_cli=only_cli)

    def normal(self, user_msg, end='.\n', label=True, force_cli=False, only_cli=False):
        self.log(LogLevel.NORMAL, user_msg, end=end, label=label, force_cli=force_cli, only_cli=only_cli)

    def info(self, user_msg, end='.\n', label=True, force_cli=False, only_cli=False):
        self.log(LogLevel.INFO, user_msg, end=end, label=label, force_cli=force_cli, only_cli=only_cli)

    def success(self, user_msg, end='.\n', label=True, force_cli=False, only_cli=False):
        self.log(LogLevel.SUCCESS, user_msg, end=end, label=label, force_cli=force_cli, only_cli=only_cli)

    def debug(self, user_msg, end='.\n', label=True, force_cli=False, only_cli=False):
        self.log(LogLevel.DEBUG, user_msg, end=end, label=label, force_cli=force_cli, only_cli=only_cli)

    def trace(self, user_msg, end='.\n', label=True, force_cli=False, only_cli=False):
        self.log(LogLevel.TRACE, user_msg, end=end, label=label, force_cli=force_cli, only_cli=only_cli)


# global logger object
g_logger = Logger(LogLevel.NORMAL)


class ProgressBar(object, metaclass=Singleton):
    # progress bar is a singletone object
    def __init__(self):
        """ Initialize progress bar """
        # initialize object
        self._is_enabled = True
        self._task_name = 'unknown'
        self._percent = 0.0
        self._sleep_time = 0.2  # 200 ms delay of animation
        self._unpredictable = False  # True if user cannot estimate progress

    def _reset(self):
        """ Reset progress bar configuration """
        self._task_name = 'unknown'
        self._percent = 0.0

    def start(self, task_name, unpredictable=False):
        """ New task start """
        # check if any other task is running
        if 0.0 < self._percent < 100.0:
            raise RuntimeError('Progress bar is used by "%s" task' % self._task_name)

        # initialize task data
        self._task_name = task_name
        self._unpredictable = unpredictable
        self._percent = 0.0

        # start progress thread as a daemon
        self._thread = threading.Thread(target=self._progress_thread)
        self._thread.setDaemon(True)
        self._thread.start()

    def _progress_thread(self):
        """ Progress working thread """
        # init local variables
        i = 0
        sun_seq = ['-', '\\', '/']

        # other variants of progress animation
        # sun_seq = ['#  ', '## ', '###', ' ##', '  #', '   ']
        # sun_seq = ['  W', ' WI', 'WIP', 'IP ', 'P  ', '   ']

        try:
            # try to get console width once (not best, but fast)
            columns = int(os.popen('tput cols', 'r').read())
        except ValueError:
            # we failed to get width, so use the default value
            g_logger.warning('Failed to get terminal width. Using default size value')
            columns = 80

        # run animation loop
        while self._percent < 100.0 and self._is_enabled:
            # prepare percent value
            percent_value = '%.1f%%' % self._percent if not self._unpredictable else '...'

            # format progress bar string
            progress_bar = '\r [%s] Progress of %s: %s' % (sun_seq[i], self._task_name, percent_value)

            # print progress bar
            g_logger.normal(progress_bar + ' ' * (columns - len(progress_bar)), end='\r', label=False, only_cli=True)

            # change the sun position and sleep
            i = (i + 1) % len(sun_seq)
            time.sleep(self._sleep_time)

        # reset object data
        self._reset()

    def finish(self):
        """ Task done, stop the thread """
        # set thread stop condition
        self._percent = 100.0

        # wait for thread end
        self._thread.join(5)
        if self._thread.is_alive():
            g_logger.warning('Progress bar thread did not exit correctly')

    def progress_set(self, value):
        """ Set task progress value """
        # check if progress is predictable
        if self._unpredictable:
            raise RuntimeError('Progress is unpredictable for current task')

        # check progress is float
        if not isinstance(value, float):
            raise TypeError('Progress value must be float')

        # check progress value is valid
        # [note] Unlike progress increase function, when the user
        #        set progress value explicitly, he must ensure that
        #        the new value is valid.
        if value < 0.0 or value > 100.0:
            raise ValueError('Progress cannot be less than 0 and more than 100')

        # save the value
        self._percent = value

    def progress_inc(self, delta):
        """ Increase task progress value by delta """
        # check if progress is predictable
        if self._unpredictable:
            raise RuntimeError('Progress is unpredictable for current task')

        # check progress is float
        if not isinstance(delta, float):
            raise TypeError('Progress delta must be float')

        # check progress value is valid
        if delta < 0.0:
            raise ValueError('Invalid delta provided: {} (progress: {})'.format(delta, self._percent))

        # check delta and update percent value
        # [note] In some cases, there may be percent value overflow.
        #        For example, it may happen due to known inaccuracy
        #        of Python with float data type. In case of progress
        #        increase action, such inaccuracy is allowed and will
        #        be resolved by the following internal check.
        if (self._percent + delta) < 100.0:
            self._percent += delta
        else:
            # in case of overflow assign value 99.99
            self._percent = 99.99

    def progress_get(self):
        """ Get current task progress value """
        # check if progress is predictable
        if self._unpredictable:
            raise RuntimeError('Progress is unpredictable for current task')

        return self._percent

    def enable(self):
        """ Enable progress bar display """
        self._is_enabled = True
        g_logger.debug('Progress bar has been enabled')

    def disable(self):
        """ Disable progress bar display """
        self._is_enabled = False
        g_logger.debug('Progress bar has been disabled')

    def is_enabled(self):
        """ Return the state of progress bar """
        return self._is_enabled


# global progress bar
g_pbar = ProgressBar()


class AdbParser:
    """
    Class provides functionality to collect, store and share
    data about nodes inside of ADB file. Major class purpose
    is to provide data, required by C-headers generator.

    Attributes
    ----------
    hdr_files : dict
                all ADABE files with headers data
    com_files : dict
                all ADABE files with common data
    licenses  : dict
                licenses from all ADABE files
    __xml_db  : dict
                database with all collected data
    __code_id : int
                counter used to give unique names for code nodes
    _parsers  : dict
                parsing callbacks for XML nodes
    """

    def __init__(self, adb_files, validate='all', fix_xml=False):
        """ HeaderAdbProcessor object constructor. Initialize,
        run ADABE files parsing and validation.

        :param adb_files: paths to all ADABE files
        :param validate: specify DB validation target
        :param fix_xml: enable parser to fix ADB files
        """
        # initialize XML DB
        self.__xml_db = {'types': {}, 'types_order': {}, 'api_params': {}, 'base_types': {}, 'job_params': {}, 'obsolete': {}}
        self.__code_id = 0
        self.__adb_files = adb_files

        # map of known nodes and their parsing functions
        self._parsers = {NodeType.INCLUDE: self.__parse_include,
                         NodeType.TYPEDEF: self.__parse_typedef,
                         NodeType.DEFINE: self.__parse_define,
                         NodeType.STRUCT: self.__parse_struct,
                         NodeType.UNION: self.__parse_union,
                         NodeType.ENUM: self.__parse_enum,
                         NodeType.CODE: self.__parse_code}

        # fix special characters in ADB files
        if fix_xml:
            self._fix_spec_chars(self.__adb_files)

        # clasify ADB files to header and common files
        self.hdr_files = {file: None for file in adb_files if not self.__is_common(file)}
        self.com_files = {file: None for file in adb_files if self.__is_common(file)}
        self.licenses = {}  # licenses per header file

        # notify user regarding ADB files upload
        g_logger.info('ADB files upload has started ..')

        # start task "ADB files upload"
        g_pbar.start('ADB files upload')

        # parsing progress per each ADB file from 20%
        self._adb_upload_step = 20.0 / len(adb_files)

        # parse all common ADB files
        [self.parse(file, is_common=True) for file in self.com_files]

        # parse all header ADB files
        [self.parse(file) for file in self.hdr_files]

        # notify user that ADB files upload finished
        g_logger.info('ADB files have been uploaded')

        # analyze ADB files and save named values
        # e.g. SX_NEXT_HOP_TYPE_IP = 1
        self.__store_named_values()

        if validate != 'none':
            # run DB validation
            self.db_validate(validate)

        # finish task "ADB files upload"
        g_pbar.finish()

    def _fix_spec_chars(self, adb_files, auto_fix=True):
        """ Function is used to fix special characters usage in ADB files """
        inv_files_cnt = 0  # counter used to get number of invalid ADB files
        xml_spec_chars = {'\'': '&apos;', '<': '&lt;', '>': '&gt;'}

        for adb_file in adb_files:
            file_changed = False  # used to track if file was changed

            # read all ADB file content
            with open(adb_file, 'r') as fp:
                orig_content = fp.read()

            # fix all ampersands using regular expression
            regex = re.compile(r"&(?!amp;|lt;|gt;|quot;|apos;)")
            fixed_content, updates = regex.subn("&amp;", orig_content)

            if updates:
                # there are updates in the file content
                file_changed = True

            # find all other special characters in the XML
            pattern = r'=\s*(?P<value>\"[^\"]*\")'
            matches = re.findall(pattern, fixed_content)

            # look for every special character in every matched value
            for spec_char, spec_seq in xml_spec_chars.items():
                for match in matches:
                    if spec_char in match:
                        # replace special character with certain code sequence
                        fixed_match = match.replace(spec_char, spec_seq)
                        fixed_content = fixed_content.replace(match, fixed_match)
                        file_changed = True

            if file_changed:
                # add file to invalid files
                inv_files_cnt += 1

                if auto_fix:
                    # write fixed content back to the ADB file
                    with open(adb_file, 'w+') as fp:
                        fp.write(fixed_content)

                    g_logger.debug('Special characters fixed in {}'.format(adb_file))

        if inv_files_cnt:
            # notify user about special characters
            if auto_fix:
                # script already fixed them
                g_logger.success('Special XML characters fixed in %d ADB file(s)' % inv_files_cnt)
            else:
                # script can fix them
                g_logger.warning('Special XML characters detected in %d ADB file(s)' % inv_files_cnt)
                g_logger.warning('Try "--fix-xml" option to fix them automatically')

    def __is_common(self, filepath):
        """ Function checks if ADB file is common.

        :param filepath: path to ADABE file
        :return: True is file is common. Else return False.
        """
        try:
            return (ET.parse(filepath).getroot().tag == 'commonData')
        except ET.ParseError as e:
            # check if there are special characters without fixing them
            self._fix_spec_chars(self.__adb_files, auto_fix=False)

            # notify user about problems
            g_logger.error('Failed to parse ADB file: {}'.format(filepath))
            g_logger.error(str(e))
            exit(1)

    def parse(self, adb_file, is_common=False):
        """ Run parsing for all known XML nodes in
        common and header ADABE files.

        :param adb_file: path to ADABE file
        :param is_common: flag used to indicate common files
        """
        def fail_parser(node, adb_name):
            """ Stub for unknown nodes """
            g_logger.log_stage_done(False)
            g_logger.error('No parser for "{}" node used in {}'.format(node.tag, adb_name))
            exit(1)  # just exit

        g_logger.debug('Parsing ADB-file: {}'.format(adb_file), end='')

        # get XML file root
        root = ET.parse(adb_file).getroot()

        # get output file path if available
        if 'path' in root.attrib:
            self.hdr_files[adb_file] = os.path.relpath(os.path.join(os.path.dirname(adb_file),
                                                                    root.attrib['path']))
        elif not is_common:
            # all header ADABE files should have "path" attribute
            raise AttributeError('File {} doesn`t have "path" attribute.'.format(adb_file))

        # get ADABE file name
        adb_name = os.path.basename(adb_file)

        # look for parsers and run nodes parsing
        for child in root:
            if child.tag == 'nodes':
                types_order = [self._parsers.get(node.tag, fail_parser)(node, adb_name) for node in child]
                if not is_common:
                    # unlike common files, header files should be generated
                    self.__xml_db['types_order'][adb_file] = types_order

            elif child.tag == 'license':
                self.__parse_license(child, adb_file)

            elif is_common:
                if child.tag == 'apiList':
                    self.__xml_db['api_params'] = self.__parse_api_params(child)
                elif child.tag == 'joblist':
                    self.__xml_db['job_params'] = self.__parse_api_params(child)
                elif child.tag == 'obsoleteList':
                    self.__xml_db['obsolete'] = self.__parse_api_params(child)
                elif child.tag == 'baseTypes':
                    self.__xml_db['base_types'] = self.__parse_base_types(child)

            else:
                fail_parser(child, adb_name)

        g_logger.log_stage_done(True)

        # update progress "ADB files upload"
        g_pbar.progress_inc(self._adb_upload_step)

    def arraysize_eval(self, arrsz):
        """ Performs evaluation of array size into some number

        Arguments:
            arrsz {string} -- string that describes array size

        Returns:
            int -- size of array
        """
        # try to check if array size is complex expression
        for nv in sorted(self.__named_values, key=len, reverse=True):
            if nv in arrsz:
                # replace known parts of the value
                arrsz = arrsz.replace(nv, str(self.__named_values[nv][0]))

        # try to evaluate final value
        try:
            return eval(arrsz)
        except BaseException:
            return None

    def db_validate(self, target):
        """ Performs ADABE files consistency validation.
        Consistency check have several test cases:
            - Underlay type is known as base type;
            - Underlay type is known as user type;
            - Underlay type is not parent type name;
            - Type name is not same with typename;
            - Struct field is not bitfield and array simultaneously;

        Checks for includes and defines currently are not
        supported.
        """
        def validate_nodename(node, field, is_field=False):
            """ Validate that name or (and) typename exist """
            if not (node['typename'] or node['name']):
                return 'Node should have at least name or(and) typename.'

        def validate_nametype(node, field, is_field=False):
            """ Validate name and underlaying type are different in typedef """
            if node['type'] == node['name']:
                return 'Underlaying type in typedef should be different.'

        def validate_nestedtype(node, field, is_field=False):
            """ Validate that field type is not parent node """
            node_type = node['typename'] if node['typename'] else '%s %s' % (node['node_type'], node['name'])
            if field['type'] == node_type:
                return 'Field cannot have type of parent node.'

        def validate_type(node, field, is_field=False):
            """ Validate that data type is known """
            type_name = field['type'] if is_field else node['type']
            if not (type_name in self.__xml_db['types']
                    or type_name in self.__xml_db['base_types']):
                return 'Type "{}" is not described in ADB files.'.format(type_name)

        def validate_arrbits(node, field, is_field=False):
            """ Validate that field is not array and bitfield at the same time """
            if field['bits'] and field['arraysize']:
                return 'Field cannot be array and bitfield simultaneously.'

        def validate_arrsize(node, field, is_field=False):
            """ Validate that array size is known or can be clarified """
            data = field if is_field else node

            for arrsz in data['arraysize']:
                # check if array size is defined by another field
                arrsz_as_field = False
                if node['node_type'] == NodeType.STRUCT:
                    # Note: this check process only fields in the current structure.
                    #       it does not check fields recursively. so here we assume
                    #       that user provided valid path further.
                    arrsz_as_field = any([fld['name'] for fld in node['fields'] if arrsz.startswith(fld['name'])])

                # array size may be defined by the field path
                # in such case we can't check if path is valid
                arrsz_as_path = '.' in arrsz

                # check if array size if known value
                if arrsz and not (arrsz in self.__named_values or arrsz.isdigit()
                                  or arrsz_as_field or arrsz_as_path):
                    if not self.arraysize_eval(arrsz):
                        return 'Unable to recognize array size \'{}\'.'.format(arrsz)

        def validate_bitsize(node, field, is_field=False):
            """ Validate that bitfield size is known """
            if field['bits'] and \
               not (field['bits'] in self.__named_values
                    or field['bits'].isdigit()):
                return 'Unable to recognize bitfield size \'{}\'.'.format(field['bits'])

        def validate_unknown_attrs(node, field, is_field=False):
            """ Validate that nodes does not have unexpected attributes """
            if is_field and field['unknown']:
                return 'Unknown field attribute(s) used: "%s"' % '", "'.join(field['unknown'])
            elif not is_field and node['unknown']:
                return 'Unknown node attribute(s) used: "%s"' % '", "'.join(node['unknown'])

        def validate_selected_by(node, field, is_field=False):
            """ Validate that union fields has "selected_by" attribute """
            if not field['selected_by']:
                g_logger.debug('Union "%s" (%s) has a field "%s" without "selected_by" attribute' %
                               (node['typename'], node['file'], field['name']))

        def validate_union_selector(node, field, is_field=False):
            """ Validate that union with 2+ fields has "union_selector" attribute """
            if field['type'] in self.__xml_db['types']:
                # field is not base type
                field_data = self.__xml_db['types'].get(field['type'])

                if field_data['node_type'] == NodeType.UNION and not field['union_selector']:
                    g_logger.debug('Union\'s "%s" (%s) field "%s" should have "union_selector" attribute' %
                                   (node['typename'], node['file'], field['name']))

        def validate_style(node, field, is_field=False):
            """ Validate that style attribute can be used by this node """
            data = field if is_field else node
            is_complex = False  # mark if field has complex sub-type
            types_trace = [data.get('name', '')]  # list of types checked

            # get sub-type data if node is not ENUM (enum has no "type" attribute)
            if is_field or data['node_type'] == NodeType.TYPEDEF:
                sub_data = self.__xml_db['types'].get(data['type'])
            else:
                sub_data = data

            # check underlay types till they exist
            while sub_data:
                if sub_data['node_type'] == NodeType.TYPEDEF:
                    # we should check underlay typedef type
                    sub_data = self.__xml_db['types'].get(sub_data['type'])
                    if not sub_data:
                        # no subtype description
                        break

                    # check if we used this type before
                    if sub_data.get('name') not in types_trace:
                        types_trace.append(sub_data.get('name'))
                        continue

                elif sub_data['node_type'] in [NodeType.STRUCT, NodeType.UNION]:
                    # field's type is complex (struct or union)
                    is_complex = True

                # no need for underlay type investigation
                break

            if data.get('style') and is_complex:
                # nodes with non-base type cannot have style attribute
                return 'Complex {} cannot have custom output style'.format('field' if is_field else 'type')

        def validate_api_list(mistakes):
            """ Validate that each API has its OPCODE and vice versa """
            # {"opcode": ["api_name", "params_type_name"]}
            api_codes = self.db_access('api_params', None)
            job_codes = self.db_access('job_params', None)
            obsolete_codes = self.db_access('obsolete', None)

            # get the list of all known opcodes from sx_api_int_cmd_e
            opcodes_map = {}
            int_cmd_fields = self.db_access('types', 'sx_api_int_cmd_e')['fields']
            for fld in [f for f in int_cmd_fields if not f['name'].startswith(NodeType.CODE)]:
                # save opcode if it has hexadecimal value
                # skipping opcode 0x1801 as it is not for APIs
                if fld['value'].startswith('0x') and fld['value'] != '0x1801':
                    opcodes_map[fld['value'][2:].lower()] = fld['name']

            # get opcodes missed in Api List
            missed_opcodes = set(opcodes_map) - set(api_codes) - set(job_codes) - set(obsolete_codes)
            for opcode in missed_opcodes:
                # define template and highlight missing opcode
                opcode_name = g_logger.highlight(FontColor.YLW, opcodes_map[opcode])
                node_str = '{} > {} > {} [{}]'.format('common.adb', 'apiList', opcode_name, opcode)
                mistakes[node_str] = 'API mapping is missing in <apiList> node for this opcode.'

            # get deprecated opcodes removed from sx_api_int_cmd_e
            lost_opcodes = set(api_codes) - set(opcodes_map)
            for opcode in lost_opcodes:
                # define template and highlight deprecated opcode
                opcode_name = g_logger.highlight(FontColor.YLW, opcodes_map[opcode])
                node_str = '{} > {} > {} [{}]'.format('common.adb', 'apiList', opcode_name, opcode)
                mistakes[node_str] = 'API mapping in <apiList> node contains deprecated opcode.'

            return mistakes

        # notify user that ADABE validation have started
        g_logger.info('ADABE files consistency check has started ..')

        # stores mistakes in ADB files using format {'location': 'problem'}
        mistakes = {}

        # validators per each node type can validate node itself or its fields
        validators = {
            NodeType.INCLUDE: {
                'node': [validate_unknown_attrs]
            },
            NodeType.DEFINE: {
                'node': [validate_unknown_attrs]
            },
            NodeType.TYPEDEF: {
                'node': [validate_nametype, validate_type, validate_unknown_attrs, validate_style]
            },
            NodeType.ENUM: {
                'node': [validate_nodename, validate_unknown_attrs, validate_style],
                'field': [validate_unknown_attrs]
            },
            NodeType.UNION: {
                'node': [validate_nodename, validate_unknown_attrs],
                'field': [validate_nestedtype, validate_type, validate_unknown_attrs, validate_selected_by, validate_style]
            },
            NodeType.STRUCT: {
                'node': [validate_nodename, validate_unknown_attrs],
                'field': [validate_nestedtype, validate_type, validate_arrbits, validate_arrsize, validate_bitsize, validate_unknown_attrs, validate_union_selector, validate_style]
            }
        }

        # name of the attribute which can describe node in the best way
        self.t_name_keys = {NodeType.INCLUDE: 'name', NodeType.DEFINE: 'name', NodeType.TYPEDEF: 'type',
                            NodeType.ENUM: 'typename', NodeType.UNION: 'node_type', NodeType.STRUCT: 'node_type'}

        # prepare data nodes for targeted validation
        if target == 'all':
            # user wants to validate all the files
            target_types = self.db_access('types', None)
            g_logger.debug('Run validation for all ADB files')

        elif os.path.isfile(target):
            # user provided a file path, so we have to process it
            target = os.path.relpath(target)  # use relative path instead of user provided

            if target not in self.db_access('types_order', None):
                self.parse(target, is_common=self.__is_common(target))

            target_types = self.db_access('types_order', target)
            g_logger.debug('Run validation for "{}"'.format(target))

        elif any([f for f in self.db_access('types_order', None) if target in f]):
            # user provided a keyword that points to a target file
            target_types = []
            for f in self.db_access('types_order', None):
                if target in f:
                    target_types += self.db_access('types_order', f)
                    g_logger.debug('Run validation for "{}"'.format(f))

        else:
            # validation target is wrong
            g_logger.error('Invalid validation target provided "{}"'.format(target))
            exit(1)  # catchall for general errors

        # update progress "ADB files upload"
        g_pbar.progress_set(65.0)

        # go through all known nodes and validate them
        for node_name in self.db_access('types', None):
            if node_name not in target_types:
                # skip validation of data types outside of target
                continue

            node = self.db_access('types', node_name)  # get the node data

            if node['node_type'] not in validators:
                # no validation flows for this node type
                continue

            # run validations for node attributes
            for validator in validators[node['node_type']]['node']:
                if validator(node, None):
                    # define template and highlight missing type
                    t_name = g_logger.highlight(FontColor.YLW, node[self.t_name_keys[node['node_type']]])
                    node_str = '{} > {} {} [{}]'.format(node['file'], node['node_type'],
                                                        node.get('typename', node['name']),
                                                        t_name)
                    mistakes[node_str] = validator(node, None)

            if node.get('fields'):
                # run validations for node fields
                for field in node['fields']:
                    if field['name'].startswith(NodeType.CODE):
                        # skip code nodes
                        continue

                    for validator in validators[node['node_type']]['field']:
                        if validator(node, field, True):
                            # define template and highlight missing type
                            t_name = g_logger.highlight(FontColor.YLW, field['type'])
                            node_str = '{} > {} {}.{} [{}]'.format(node['file'], node['node_type'],
                                                                   node['typename'], field['name'], t_name)
                            mistakes[node_str] = validator(node, field, True)

        # update progress "ADB files upload"
        g_pbar.progress_set(80.0)

        # check if all opcodes, described in sx_api_int_cmd_e present in apiList node.
        mistakes = validate_api_list(mistakes)

        if mistakes:
            # print all detected mistakes
            errmsg = 'ADABE files consistency check has failed. Resolve following {} issue(s):'.format(len(mistakes))
            tmpl = '  {} {{}}\n  {} {{}}\n'.format(g_logger.highlight(FontColor.BLE, ' Problem'),
                                                   g_logger.highlight(FontColor.YLW, 'Location'))
            msgtxt = '\n'.join(tmpl.format(reason, location) for location, reason in mistakes.items())

            g_logger.error(errmsg, end='\n\n')
            g_logger.error(msgtxt, end='', label=False)
            exit(1)  # catchall for general errors

        else:
            g_logger.info('ADABE files consistency check passed')

    def __store_named_values(self):
        """ Function collect all named values from enumerations and defines """
        def is_used_by(key, value):
            if key not in value:
                # key is not used by value
                return False

            idx = value.find(key)
            pre_symb = value[idx - 1] if idx > 0 else ' '
            if pre_symb.isalpha() or pre_symb.isdigit() or pre_symb == '_':
                # key is just a part of bigger named value
                return False

            post_symb = value[idx + len(key)] if (idx + len(key)) < len(value) else ' '
            if post_symb.isalpha() or post_symb.isdigit() or post_symb == '_':
                # key is just a part of bigger named value
                return False

            return True

        def blockers_check(value):
            """ Function performs replacement of some redundant expressions
                that may block value resolution, but are not important for
                the final value.
            """
            # blockers are used to filter redundant info during evaluation
            blockers = {'0x1LL': '0x1',
                        '0x0LL': '0x0',
                        'UL': '', 'U': '', 'u': '',
                        '(sx_mc_container_id_t)': '', '(int)': '',
                        '(sx_flow_counter_id_t)': '',
                        '(sx_ecmp_id_t)': '',
                        '(sx_tunnel_id_t)': '',
                        '(sx_rpf_group_id_t)': '',
                        '(int32_t)': ''}
            for blocker, replacer in blockers.items():
                value = value.replace(blocker, replacer)

            return eval(value)

        g_logger.info('Names resolution has started ..')

        # declare dictionary for named values
        # {name: [value, parent_node]}
        self.__named_values = {}

        g_logger.log_stage(0, 'Prepare nodes for resolution')

        # collect all known enum's and define's names and values
        for node_name in self.db_access('types', None):
            node = self.db_access('types', node_name)  # get node data
            if node['node_type'] == NodeType.ENUM:
                last_value = -1  # used to set enum item value if explicit value is absent

                # go through all items except code nodes
                for fld in [f for f in node['fields'] if not f['name'].startswith(NodeType.CODE)]:
                    # if value is absent in ADB, use automatic increment
                    value = fld['value'] or '{} + 1'.format(last_value)

                    self.__named_values[fld['name']] = [value, node_name]  # save value and enum name
                    last_value = self.__named_values[fld['name']][0]  # save last value

            elif node['node_type'] == NodeType.DEFINE:
                if node_name and node['value']:
                    # consider only defines with not empty name and value
                    self.__named_values[node_name] = [node['value'], None]

        # update progress "ADB files upload"
        g_pbar.progress_set(35.0)

        g_logger.log_stage_done(True)
        g_logger.log_stage(0, 'Run cross-substitution', last=True)

        # start timer
        begin = time.time()

        # substitute all values that present in other named values
        # ENUM_1 = 0,           > ENUM_1 = 0
        # ENUM_2 = ENUM_1 + 1,  > ENUM_2 = 0 + 1
        for i in range(3):
            # Note: 3 iterations here used to limit total execution time.
            #       Usually, 1 or 2 iterations are enough.
            replaced = False

            # go through all named values from the longest to the smallest
            # named value. Order is required for correct values resolution
            for key in sorted(self.__named_values, key=len, reverse=True):
                value = self.__named_values[key]

                # check if key is part of any other named value
                target = {k: v for k, v in self.__named_values.items() if is_used_by(key, v[0])}

                # replace key in found named values
                for tkey, tval in target.items():
                    g_logger.trace('Replace "{}" to "{}"'.format(key, str(value[0])))
                    self.__named_values[tkey] = [tval[0].replace(key, '(%s)' % str(value[0])), tval[1]]
                    replaced = True

            # update progress "ADB files upload"
            g_pbar.progress_inc(5.0)

            if not replaced:
                break

        # update progress "ADB files upload"
        g_pbar.progress_set(50.0)

        g_logger.log_stage_done(True)
        g_logger.debug('Cross-substitution was performed in {:.3f} s'.format(time.time() - begin))

        # attempt to evaluate each named value
        for key, value in self.__named_values.items():
            try:
                self.__named_values[key] = [eval(value[0]), value[1]]

            except BaseException:
                # normal evaluation failed, but we can try to do typical
                # replacements to resolve named value
                try:
                    self.__named_values[key] = [blockers_check(value[0]), value[1]]
                except BaseException:
                    g_logger.debug('Cannot eval \'{}\' underlay value [{}]'.format(value[0], key))

        g_logger.info('Names resolution has been finished')

        # update progress "ADB files upload"
        g_pbar.progress_set(60.0)

    def get_named_value(self, name=None, parent=False):
        """ Function return value of named instance

        :param name: name of value. E.g. SX_STATUS_SUCCESS or SX_BRIDGE_ID_INVALID
        :param parent: flag that parent node name required
        """
        value = self.__named_values.get(name)  # look for named value
        return list(self.__named_values.keys()) if value is None else (value if parent else value[0])

    def db_access(self, section, node_name):
        """ Provide access to data inside XML DB.

        :param section: type of data user want to access
        :param node_name: name of node in DB section
        :return: node`s data or all known nodes
        """
        if section in self.__xml_db:
            if node_name in self.__xml_db[section]:
                # return node`s information
                return self.__xml_db[section][node_name]

            if node_name is not None:
                # user provided unknown node name
                g_logger.error('Unknown node specified: {}'.format(node_name))
            # return all known nodes in DB section
            return list(self.__xml_db[section].keys())

        if section is not None:
            # user provided unknown section name
            g_logger.error('Unknown type specified: {}'.format(section))
        # return all sections in DB
        return list(self.__xml_db.keys())

    def is_known_type(self, name):
        """ Check if data type present in any types section """
        if name in self.__xml_db['types']:
            return 'types'  # type is user-defined
        elif name in self.__xml_db['base_types']:
            return 'base_types'  # type is base

        return None  # type is unknown

    def _get_node_attrs(self, node, attributes, default=None, adb_file=None):
        """ Get a set of required node attributes.
        If attribute is absent, its value becomes default.

        :param node: an XML node
        :param attributes: a list of attributes, user is looking for
        :param default: default value for attribute
        :param adb_file: name of ADABE file. Used when field attributes has to be parsed
        :return: dict with all required attributes and their values
        """
        # if code node is inside of other, like struct, we do code node parsing
        if adb_file and node.tag == NodeType.CODE:
            return self.__parse_code(node, adb_file, nested=True)

        # get all requested attributes
        attrs = {attr: node.attrib.get(attr, default) for attr in attributes}

        # check unexpected attributes in nodes
        attrs['unknown'] = [attr for attr in node.attrib if attr not in attributes]

        return attrs

    def __parse_license(self, node, adb_file):
        """ Parse license in ADABE file and saves it per each file

        :param node: license node
        :param adb_file: name of ADABE file
        """
        template_str = '/{}\n */'
        lines = ['* {}'.format(line.lstrip()).rstrip() for line in node.text.split('\n')]
        self.licenses[adb_file] = template_str.format('\n '.join(lines))

    def __parse_base_types(self, node):
        """ Function perform parsing of base types, teir format and printing style.

        :param node: node with all base types
        :return: dict with all base types description
        """
        return {btype.attrib['name']: [btype.attrib['format'], btype.attrib['style']] for btype in node}

    def __parse_api_params(self, node):
        """ Function perform parsing of APIs list, opcodes and corresponding params.

        :param node: node with all APIs
        :return dict with all api_params description
        """
        return {api.attrib['opcode']: [api.attrib['name'], api.attrib['params']] for api in node}

    def __parse_code(self, node, adb_file, nested=False):
        """ Function parses all code nodes in ADB file.
        These code will be directly inserted into C code.
        All parsed data will be stored in XML DB.

        :param node: XML-node called 'code'
        :param adb_file: name of ADABE file
        :param nested: parsing code inside of another data type node
        :return: name of code node
        """
        code_data = self._get_node_attrs(node, ['type'])
        code_data['node_type'] = NodeType.CODE
        code_data['file'] = adb_file
        code_data['name'] = '%s#%d' % (NodeType.CODE, self.__code_id)
        code_data['lines'] = [row.strip() for row in node.text.split('\n') if row.strip()]
        self.__code_id += 1

        if code_data['type'] != 'comment':
            # if node is not node marked as comment, we suppose it's code
            code_data['type'] = 'code'

        self.__xml_db['types'][code_data['name']] = code_data
        return code_data if nested else code_data['name']

    def __parse_include(self, node, adb_file):
        """ Function parses all C-includes in ADB file.
        All parsed data will be stored in XML DB.

        :param node: XML-node called 'include'
        :param adb_file: name of ADABE file
        :return: name of include node
        """
        include_data = self._get_node_attrs(node, ['name', 'type', 'desc'])
        include_data['node_type'] = NodeType.INCLUDE
        include_data['file'] = adb_file

        if not include_data['type']:
            # by default all includes use double quotes
            include_data['type'] = "quote"

        # unique naming resolve includes collisions during generation
        unique_name = adb_file + include_data['name']

        self.__xml_db['types'][unique_name] = include_data
        return unique_name

    def __parse_define(self, node, adb_file):
        """ Function parses all defines in ADB file.
        All parsed data will be stored in XML DB.

        :param node: XML-node called 'define'
        :param adb_file: name of ADABE file
        :return: name of define node
        """
        define_data = self._get_node_attrs(node, ['name', 'value', 'desc'])
        define_data['node_type'] = NodeType.DEFINE
        define_data['file'] = adb_file

        self.__xml_db['types'][define_data['name']] = define_data
        return define_data['name']

    def __parse_enum(self, node, adb_file):
        """ Function parses all enums in ADB file.
        All parsed data will be stored in XML DB.

        :param node: XML-node called 'enum'
        :param adb_file: name of ADABE file
        :return: name of enum node
        """
        enum_data = self._get_node_attrs(node, ['typename', 'desc', 'foreach', 'name', 'style', 'pack'])
        enum_data['node_type'] = NodeType.ENUM
        enum_data['file'] = adb_file
        enum_data['fields'] = [self._get_node_attrs(item,
                                                    ['name', 'value', 'cont', 'desc'],
                                                    adb_file=adb_file) for item in node]

        node_name = ''
        if enum_data['name']:
            # enum has its own name
            node_name = 'enum %s' % enum_data['name']
            self.__xml_db['types'][node_name] = enum_data

        if enum_data['typename']:
            # enum is under typedef
            node_name = enum_data['typename']
            self.__xml_db['types'][node_name] = enum_data

        if not node_name:
            # we have found unnamed enum
            node_name = 'unknown enum'
            self.__xml_db['types'][node_name] = enum_data

        return node_name

    def __parse_typedef(self, node, adb_file):
        """ Function parses all typedefs in ADB file.
        All parsed data will be stored in XML DB.

        :param node: XML-node called 'typedefs'
        :param adb_file: name of ADABE file
        :return: name of typedef node
        """
        typedef_data = self._get_node_attrs(node, ['name', 'type', 'desc', 'arraysize', 'pointer', 'style'])
        typedef_data['node_type'] = NodeType.TYPEDEF
        typedef_data['file'] = adb_file

        # split multidimensional array sizes
        typedef_data['arraysize'] = typedef_data['arraysize'].split(';') if typedef_data.get('arraysize') else []

        self.__xml_db['types'][typedef_data['name']] = typedef_data
        return typedef_data['name']

    def __parse_union(self, node, adb_file):
        """ Function parses all unions in ADB file.
        All parsed data will be stored in XML DB.

        :param node: XML-node called 'unions'
        :param adb_file: name of ADABE file
        :return: name of unions node
        """
        union_data = self._get_node_attrs(node, ['typename', 'desc', 'name', 'pack'])
        union_data['node_type'] = NodeType.UNION
        union_data['file'] = adb_file
        union_data['fields'] = [self._get_node_attrs(item,
                                                     ['name', 'type', 'desc', 'selected_by', 'arraysize', 'pointer', 'style'],
                                                     adb_file=adb_file) for item in node]

        # split multidimensional array sizes and selected_by values
        for field in union_data['fields']:
            field['arraysize'] = field['arraysize'].split(';') if field.get('arraysize') else []
            field['selected_by'] = field['selected_by'].split(';') if field.get('selected_by') else []

        node_name = ''
        if union_data['name']:
            # union has its own name
            node_name = 'union %s' % union_data['name']
            self.__xml_db['types'][node_name] = union_data

        if union_data['typename']:
            # union is under typedef
            node_name = union_data['typename']
            self.__xml_db['types'][node_name] = union_data

        if not node_name:
            # we found unnamed union
            node_name = 'unknown union'
            self.__xml_db['types'][node_name] = union_data

        return node_name

    def __parse_struct(self, node, adb_file):
        """ Function parses all structs in ADB file.
        All parsed data will be stored in XML DB.

        :param node: XML-node called 'structs'
        :param adb_file: name of ADABE file
        :return: name of structs node
        """
        struct_data = self._get_node_attrs(node, ['typename', 'desc', 'name', 'pack'])
        struct_data['node_type'] = NodeType.STRUCT
        struct_data['file'] = adb_file
        struct_data['fields'] = [self._get_node_attrs(item,
                                                      ['name', 'type', 'desc', 'union_selector', 'arraysize', 'bits', 'pointer', 'style'],
                                                      adb_file=adb_file) for item in node]

        # split multidimensional array sizes
        for field in struct_data['fields']:
            field['arraysize'] = field['arraysize'].split(';') if field.get('arraysize') else []

        node_name = ''
        if struct_data['name']:
            # struct has its own name
            node_name = 'struct %s' % struct_data['name']
            self.__xml_db['types'][node_name] = struct_data

        if struct_data['typename']:
            #  struct is under typedef
            node_name = struct_data['typename']
            self.__xml_db['types'][node_name] = struct_data

        if not node_name:
            # we found unnamed struct
            node_name = 'unknown struct'
            self.__xml_db['types'][node_name] = struct_data

        return node_name


class TimeOutException(Exception):
    """ Exception to be raised in case of timeout """
    pass


def timeout(timeout):
    """ Timeout in seconds used to stop execution """
    def decorate(f):
        def handler(signum, frame):
            error_str = "Function %s - TIMEOUT [%f seconds]" % (f.__name__, timeout)
            raise TimeOutException(error_str)

        @functools.wraps(f)
        def new_f(*args, **kwargs):
            try:
                signal.signal(signal.SIGALRM, handler)
                signal.alarm(timeout)
                return f(*args, **kwargs)
            finally:
                signal.alarm(0)

        return new_f

    return decorate


class SxLoggerProcessingError(Exception):
    """ Exception to be raised in case of parameters
        processing issues in Logger
    """
    pass
