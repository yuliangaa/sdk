#!/usr/bin/env python3
"""
# SX Runner Wrapper
#
# Provide common user interface for SX API Logger
# and SX Player. Performs user command validation.
#
"""
__title__ = 'SX_RUNNER'
__author__ = 'oleksandrv'
__version__ = '1.7.8'
__release__ = 'Apr-2021'

import os
import sys
import argparse
import subprocess

# import SX API Utils library
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from logger.logger import SxLogger
from logger.logger import __version__ as __lver__, __title__ as __ltitle__
from utils.utils import g_logger, g_pbar, Logger, AdbParser, LogLevel as llvl, FontColor as fc
from utils.utils import __version__ as __uver__, __title__ as __utitle__


# default file paths used by SX Runner
DEFAULT_OUTPUT_PATH = '/tmp/logged_{}_{}.txt'
DEFAULT_FILTER_GEN_PATH = '/tmp/filter_{}.txt'


class SxRunner():
    """ Wrapper class for sx_player and sx_logger """

    def __init__(self):
        """ Constructor parse arguments and define working mode """

        # create parser and major argument groups
        parser = argparse.ArgumentParser(add_help=False)

        cmd_group = parser.add_mutually_exclusive_group(required=True)
        filter_group = parser.add_mutually_exclusive_group(required=False)
        verbosity_group = parser.add_mutually_exclusive_group(required=False)

        # sx_runner flows arguments
        cmd_group.add_argument('-p', '--play', type=str, metavar='FILE')
        cmd_group.add_argument('-l', '--log', type=str, metavar='FILE')
        cmd_group.add_argument('-a', '--apilist', type=str, metavar='FILE')
        cmd_group.add_argument('-h', '--help', nargs='?', const='help')

        # sx_player arguments
        parser.add_argument('--pcap-source', type=str)
        parser.add_argument('--no-sync', action='store_true')
        parser.add_argument('--dry-run', action='store_true')
        parser.add_argument('--stop-on-mismatch', type=str, metavar='TYPE')
        parser.add_argument('--stop-before-fail', action='store_true')
        parser.add_argument('--stop-on-id', type=int, metavar='ID')
        parser.add_argument('--sysfs-mode', type=str, metavar='TYPE')
        parser.add_argument('--ignore-sysfs-fail', action='store_true')

        # sx_logger arguments
        parser.add_argument('--from-id', type=int, metavar='ID')
        parser.add_argument('--till-id', type=int, metavar='ID')
        parser.add_argument('--params', type=str, metavar='TYPE')
        parser.add_argument('--skip-zero', action='store_true')

        # filter arguments
        filter_group.add_argument('-i', '--include', type=str, metavar='FILE')
        filter_group.add_argument('-e', '--exclude', type=str, metavar='FILE')
        filter_group.add_argument('-s', '--set_only', action='store_true')

        # output arguments
        parser.add_argument('-c', '--cli', action='store_true')
        parser.add_argument('-d', '--dump', type=str, nargs='?', const='default', metavar='FILE')

        # logs verbosity arguments
        verbosity_group.add_argument('-v', '--vinfo', action='store_true')
        verbosity_group.add_argument('-vv', '--vdebug', action='store_true')
        verbosity_group.add_argument('-vvv', '--vtrace', action='store_true')

        # other arguments
        parser.add_argument('-f', '--filter-gen', nargs='?', const='default', metavar='FILE')
        parser.add_argument('--fix-xml', action='store_true')
        parser.add_argument('--color', action='store_true')

        self.args = parser.parse_args()

        # initialize parameters metadata
        self._initialize_parameters()

        # define workflow
        if self.args.play:
            self.flow = 'play'
        elif self.args.log:
            self.flow = 'log'
        elif self.args.apilist:
            self.flow = 'apilist'
        elif self.args.help:
            self.flow = 'help'

        # check if all arguments are compatible
        self._check_args_compatibility()

        # ---------------------
        # Filter configuration
        # ---------------------
        self.filter_cfg = {'range': False, 'api': None}

        if self.args.from_id or self.args.till_id:
            # config for filtering by call id range
            self.filter_cfg['range'] = True
            self.filter_cfg['from_id'] = self.args.from_id
            self.filter_cfg['till_id'] = self.args.till_id

        if self.args.include:
            # config for inclusive filtering
            self.filter_cfg['api'] = 'include'
            self.filter_cfg['file'] = self.args.include

        elif self.args.exclude:
            # config for exclusive filtering
            self.filter_cfg['api'] = 'exclude'
            self.filter_cfg['file'] = self.args.exclude

        # ---------------------------------
        # Parameters parsing configuration
        # ---------------------------------

        # check parameters parsing mode
        params_modes = ['all', 'native', 'cmd', 'reply', 'off']
        if self.args.params and self.args.params not in params_modes:
            parser.error('Supported parameters modes: {}.'.format(', '.join(params_modes)))

        # set default parameters parsing mode to all
        if self.flow == 'log' and not self.args.params:
            self.args.params = 'all'

        self.params_cfg = {'mode': self.args.params, 'skip_zero': self.args.skip_zero}

        sysfs_modes = ['sysfs_set_get', 'sysfs_set', 'sysfs_exclude', 'sysfs_only']
        if self.args.sysfs_mode and self.args.sysfs_mode not in sysfs_modes:
            parser.error('Supported sysfs sniffer modes: {}.'.format(', '.join(sysfs_modes)))

        # ----------------------------
        # Mismatch type configuration
        # ----------------------------

        # check provided mismatch type
        mismatch_types = ['any', 'rc', 'data']
        if self.args.stop_on_mismatch and self.args.stop_on_mismatch not in mismatch_types:
            parser.error('Supported mismatch types: {}.'.format(', '.join(mismatch_types)))

        # --------------------------
        # Logs output configuration
        # --------------------------

        # prepare logs printing configuration
        log_to_cli = True if self.args.cli else False
        log_to_file = self.args.dump

        if self.flow in ['play', 'apilist', 'log']:
            # get the name of PCAP file
            pcap_name = os.path.basename(vars(self.args)[self.flow])

            if (not log_to_cli and not log_to_file) or (log_to_file == 'default'):
                # user did not provided output target; dump logs by default
                log_to_file = DEFAULT_OUTPUT_PATH.format(self.flow, pcap_name)

            if self.args.filter_gen == 'default':
                # use default path for filter file generation
                self.args.filter_gen = DEFAULT_FILTER_GEN_PATH.format(pcap_name)

        elif self.flow == 'help':
            # help is always printed to the CLI
            log_to_cli = True

        # define what logs user wants to see
        if self.args.vtrace:
            usr_log_level = llvl.TRACE
        elif self.args.vdebug:
            usr_log_level = llvl.DEBUG
        elif self.args.vinfo:
            usr_log_level = llvl.INFO
        else:
            usr_log_level = llvl.NORMAL

        # configure the already inited global logger, which is a singleton, and imported at top of the file
        g_logger.params_set(usr_log_level, log_to_file, log_to_cli, self.args.color)

        if usr_log_level > llvl.INFO and log_to_cli:
            # disable progress bar when verbosity is high
            # and if logs should be printed to the CLI
            g_pbar.disable()

    def _initialize_parameters(self):
        # dict of supported flows
        # {'flow': ['short', 'value', 'description', [options]}
        self.flows = {
            'play': ['p', '<pcap>', 'Reproduce API calls recorded in the PCAP file', ['pcap-source', 'dry-run', 'no-sync', 'include', 'exclude', 'set-only', 'fix-xml', 'stop-on-mismatch', 'stop-before-fail', 'stop-on-id', 'sysfs-mode', 'ignore-sysfs-fail', 'cli', 'dump', 'color', 'vinfo', 'vdebug', 'vtrace']],
            'apilist': ['a', '<pcap>', 'Collect general information about PCAP file content', ['cli', 'dump', 'color', 'filter-gen', 'fix-xml', 'vinfo', 'vdebug', 'vtrace']],
            'log': ['l', '<pcap>', 'Convert PCAP packets into readable API calls', ['include', 'exclude', 'params', 'from-id', 'till-id', 'cli', 'dump', 'color', 'skip-zero', 'fix-xml', 'vinfo', 'vdebug', 'vtrace']],
            'help': ['h', '[play|apilist|log]', 'Print user\'s manual for this utility', ['color']]
        }

        # dict of supported options
        # {'option': ['short', 'value', 'default_value', [allowed values], 'description']}
        self.options = {
            'cli': ['c', None, None, None, 'Print logs to the console'],
            'dump': ['d', 'FILE', DEFAULT_OUTPUT_PATH.format('<flow>', '<pcap_name>'), None,
                     'Print logs to the file. Used as default if user did not specify logs direction'],
            'color': [None, None, None, None, 'Enable colourization of log messages'],
            'vinfo': ['v', None, None, None, 'Enable info level logs'],
            'vdebug': ['vv', None, None, None, 'Enable debug level logs'],
            'vtrace': ['vvv', None, None, None, 'Enable trace level logs'],
            'params': [None, 'TYPE', None, [
                ('all', 'Always parse CMD and REPLY packets'),
                ('native', 'Always parse CMD packets, but REPLY packets on API get call only'),
                ('cmd', 'Parse CMD packets only'),
                ('reply', 'Parse REPLY packets only'),
                ('off', 'Do not parse parameters')],
                'Specify the way of API parameters parsing. If not provided, "all" mode is used'],
            'from-id': [None, 'ID', None, None, 'Skip all API calls before specified ID'],
            'till-id': [None, 'ID', None, None, 'Skip all API calls after specified ID'],
            'include': ['i', 'FILE', None, None, 'Enable inclusive filtering using filter file'],
            'exclude': ['e', 'FILE', None, None, 'Enable exclusive filtering using filter file'],
            'pcap-source': [None, 'SOURCE', None, None, 'Set the source of the PCAP file: DVS_OS, CL, SONIC, Unknown'],
            'no-sync': [None, None, None, None, 'Run PCAP file without synchronization delays'],
            'set-only': [None, 'None', None, None, 'Enable filter with set only API calls'],
            'dry-run': [None, None, None, None, 'Run PCAP file without real calls to the SDK'],
            'fix-xml': [None, None, None, None, 'Fix special XML characters in ADB files'],
            'skip-zero': [None, None, None, None, 'Skip parameters\' fields with meaningless zero value'],
            'filter-gen': ['f', 'FILE', DEFAULT_FILTER_GEN_PATH.format('<pcap_name>'), None, 'Generate filter file with all APIs recorded in the PCAP file'],
            'stop-on-mismatch': [None, 'TYPE', None, [
                ('rc', 'Return code is not as expected'),
                ('any', 'Any mismatch with expected packet'),
                ('data', 'Mismatch in other packet data')],
                'Stop SX Player on certain type of REPLY mismatch'],
            'sysfs-mode': [None, 'TYPE', None, [
                ('sysfs_set_get', 'Parse sysfs write access packets and SX-API packets only'),
                ('sysfs_set', 'Always parse sysfs write and read access packets'),
                ('sysfs_exclude', 'Do not parse sysfs access packets'),
                ('sysfs_only', 'Parse sysfs access packets only')],
                'Specify the way of SYSFS access parsing. If not provided, "sysfs_set" mode is used'],
            'stop-before-fail': [None, None, None, None, 'Stop sx_player before API call that is expected to fail'],
            'stop-on-id': [None, 'ID', None, None, 'Stop sx_player before packet with specific ID'],
            'ignore-sysfs-fail': [None, None, None, None, 'Ignore sysfs failures']
        }

    def _check_args_compatibility(self):
        """ Function check if all provided arguments are compatible """

        for arg in vars(self.args):
            # replace underscores to hyphens in the argument name
            h_arg = arg.replace('_', '-')

            if arg == self.flow:
                # skip args that point to mode
                continue

            # check if argument used and is supported
            if vars(self.args)[arg] and (h_arg not in self.flows[self.flow][3]):
                exit(' [Error] Argument \'{}\' is not supported in the "{}" mode.'.format(h_arg, self.flow))

    def _help(self, help_flow='help'):
        """ Print user's manual on how to use this tool """
        # create flows description
        flow_desc = {
            'play': "  [ Play flow manual ]\n"
                    + "  --------------------\n"
                    + "  This flow is used to reproduce SDK API calls recorded inside the PCAP file. Script runs\n"
                    + "  external tool (SX Player) providing it all used options. You do not have to run the SDK\n"
                    + "  by yourself. Internal script sx_player_start.sh will take care of it.\n"
                    + "\n\n",
            'apilist': "  [ Apilist flow manual ]\n"
                       + "  -----------------------\n"
                       + "  This flow is used to analyze content of the PCAP file. It collects several kinds of the\n"
                       + "  information about which APIs were recorded, number of calls, time between CMD and REPLY\n"
                       + "  packets, failed API calls and so on. You may generate the filter file based on recorded\n"
                       + "  API functions also.\n"
                       + "\n\n",
            'log': "  [ Log flow manual ]\n"
                   + "  -------------------\n"
                   + "  This flow is used to convert content of the PCAP file into a human readable format with\n"
                   + "  detailed description of each API call including API name, return code, runtime duration\n"
                   + "  and even API call parameters. Advanced users may use more specific options like parame-\n"
                   + "  ters printing type or skipping parameters with zero value.\n"
                   + "\n\n",
            'help': "  This tool is a simple Python wrapper that provides common interface for other API utils.\n"
                    + "  Its command interface is described below. Each sort of functionality is called a 'flow'.\n"
                    + "  If you need more detailed information about specific flow, put its name behind '--help'\n"
                    + "  option and voila.\n"
                    + "\n\n"
        }

        # create tool header
        info = '  {}{{}}[version {} | {}]'.format(__title__, __version__, __release__)
        filled_info = info.format(' ' * (92 - len(info)))

        libs = '{::^90}'.format('  %s [%s]  %s [%s]  ' % (__utitle__.lower(), __uver__, __ltitle__.lower(), __lver__))
        filled_libs = g_logger.highlight(fc.YLW, libs)
        header = ' {0:-^90}\n{1}\n {0:-^90}\n {2}\n\n'.format('', filled_info, filled_libs)

        if help_flow in ['play', 'apilist', 'log']:
            # create tool description
            body = flow_desc[help_flow]

            body += "  Command: {} -{}|--{} {} [options]\n".format(os.path.basename(__file__), self.flows[help_flow][0], help_flow, self.flows[help_flow][1])
            body += "  Options:\n\n"

            for opt in sorted(self.flows[help_flow][3]):
                opt_short = ('-%s|' % self.options[opt][0]) if self.options[opt][0] else ''
                opt_value = ((' [%s]' if self.options[opt][2] else ' <%s>') % self.options[opt][1]) if self.options[opt][1] else ''
                opt_default = ('        [default value] %s\n' % self.options[opt][2]) if self.options[opt][2] else ''
                opt_allowed = ('        [allowed values]\n            %s\n' % ',\n            '.join(['%s - %s' % a_val for a_val in self.options[opt][3]])) if self.options[opt][3] else ''

                body += "        {}--{}{}\n".format(opt_short, opt, opt_value) + \
                        "        {}.\n".format(self.options[opt][4]) + \
                        opt_default + opt_allowed + \
                        "\n\n"

        else:
            # create tool description
            body = flow_desc['help']

            # create flows description
            body += "  Following flows are supported:\n\n"
            for i, sup_flow in enumerate(sorted(self.flows), 1):
                body += "  [ {}. {} ] {}.\n  {}\n".format(i, sup_flow, self.flows[sup_flow][2], '-' * (len(sup_flow) + 7)) + \
                        "  Command: {} -{}|--{} {}\n".format(os.path.basename(__file__), self.flows[sup_flow][0], sup_flow, self.flows[sup_flow][1]) + \
                        "\n\n"

        # create footer
        wiki_link = "More at https://wikinox.mellanox.com/display/SW/SX+API+Runner+and+Logger"
        footer = ' {0:-^90}\n | {1:<86} | \n \'{0:-^88}\'\n\n'.format('', wiki_link)

        # compile and print final help text
        g_logger.normal(header + body + footer, end='\n', label=False)

    def _get_adb_files(self):
        """ Lookup all ADB files in applibs/include folder """
        adb_files = []
        includes = os.path.relpath(os.path.dirname(os.path.realpath(__file__)) + '/../include/')
        for root, _, files in os.walk(includes):
            adb_files += [os.path.join(root, file) for file in files if file.endswith('.adb')]

        return adb_files

    def run(self):
        """ Run specific flow depending on runner mode """

        try:
            # run flow specified by the user
            if self.flow == 'play':
                self.play()
            elif self.flow == 'log':
                self.log()
            elif self.flow == 'apilist':
                self.apilist()
            elif self.flow == 'help':
                self._help(self.args.help)

        except IOError:
            # notify user about an error
            g_logger.error('Operation has failed')

        if g_logger.get_dump_file():
            # notify user about dumped logs
            g_logger.normal('Logs have been saved in %s' % g_logger.get_dump_file(),
                            end='\n', force_cli=True)

    def _player_filter_prepare(self, filter_file):
        """ Function performs conversion of API names into API opcodes
            using common ADB file. Created filter file with opcodes
            will be processed by SX Player.
        """
        def is_hex(value):
            """ Function checks if passed value is a hexadecimal number """
            try:
                value = int(value, 16)
                return True
            except ValueError as e:
                return False

        api_to_opcode = {}  # mapping between api name and opcode
        is_binary = False  # flag points that filter file is binary

        # upload mapping API to opcode
        common_adb = os.path.relpath(os.path.dirname(os.path.realpath(__file__)) + '/../include/adb/common.adb')
        adb_parser = AdbParser([common_adb], validate='none', fix_xml=self.args.fix_xml)

        # api codes upload from 'api_params' section
        # {"opcode": ["api_name", "params_type_name"]}
        for opcode in adb_parser.db_access('api_params', None):
            api_to_opcode[adb_parser.db_access('api_params', opcode)[0]] = opcode

        g_logger.debug('API names mapped to opcodes')

        if filter_file:
            # upload filterfile
            with open(filter_file, 'r') as f:
                lines = [line.strip() for line in f.read().split('\n')]
                # check if user provided normal or binary filter file
                if is_hex(lines[0].split()[0]):
                    # first item inside binary file is a hex number - opcode
                    is_binary = True
                else:
                    filter_apis = [row for row in lines if row and not row.startswith('#')]
        else:
            filter_apis = []

        g_logger.debug('Filter file uploaded')

        if is_binary:
            # just copy opcodes from the first line
            filter_opcodes = lines[0].split()
        else:
            # convert api names to opcodes
            filter_opcodes = []
            if not filter_apis:
                for opcode in adb_parser.db_access('api_params', None):
                    if not adb_parser.db_access('api_params', opcode)[0].endswith('get'):
                        filter_opcodes.append(opcode)
            else:
                for api in filter_apis:
                    if api_to_opcode.get(api):
                        filter_opcodes.append(api_to_opcode[api])
                    else:
                        g_logger.warning('Unknown API in the filter file - "{}"'.format(api))

        g_logger.debug('Filter file processed')

        # create new filter file in /tmp/
        if filter_file:
            tmp_filter_file = '/tmp/' + os.path.basename(filter_file) + '.tmp'
        else:
            tmp_filter_file = '/tmp/set_only.tmp'
        with open(tmp_filter_file, 'w+') as f:
            f.write(' '.join(filter_opcodes))

        g_logger.debug('Temp filter file with opcodes created')
        return tmp_filter_file

    def play(self):
        """ Run sx_player with options """
        # check if sx_player is already installed
        if not os.path.exists('/usr/bin/sx_player_start.sh'):
            g_logger.error('You have to install SX player before')
            return

        # prepare filter flags
        if self.args.include:
            filt = ' --include {0}'.format(self._player_filter_prepare(self.args.include))
        elif self.args.exclude:
            filt = ' --exclude {0}'.format(self._player_filter_prepare(self.args.exclude))
        elif self.args.set_only:
            filt = ' --include {0}'.format(self._player_filter_prepare(None))
        else:
            filt = ''

        # prepare stop-on-mismatch flag
        stop_on_mismatch = ' --stop-on-mismatch %s' % self.args.stop_on_mismatch if self.args.stop_on_mismatch else ''

        # prepare stop-on-id flag
        stop_on_id = ' --stop-on-id %s' % self.args.stop_on_id if self.args.stop_on_id else ''

        # prepare sysfs-mode flag
        sysfs_mode = ' --sysfs-mode %s' % self.args.sysfs_mode if self.args.sysfs_mode else ''

        pcap_source = ' --pcap_source=%s ' % self.args.pcap_source if self.args.pcap_source else ''

        # build cli command and run it
        cmd = 'sx_player_start.sh {0}'.format(pcap_source
                                              + self.args.play
                                              + (' --dry-run' if self.args.dry_run else '')
                                              + (' --no-sync' if self.args.no_sync else '')
                                              + (' --stop-before-fail' if self.args.stop_before_fail else '')
                                              + (' --ignore-sysfs-fail' if self.args.ignore_sysfs_fail else '')
                                              + filt + stop_on_mismatch + stop_on_id + sysfs_mode)

        g_logger.debug('Run: %s' % cmd, end='\n')
        rc = subprocess.call(cmd.split())
        g_logger.debug('Return code: %d' % rc)

    def log(self):
        """ Run logger with options """
        sx_logger = SxLogger(pcap_file=self.args.log, adb_files=self._get_adb_files(),
                             filter_cfg=self.filter_cfg, params=self.params_cfg, fix_xml=self.args.fix_xml)
        g_logger.normal(sx_logger.reader, end='\n', label=False)
        g_logger.normal(sx_logger.reader.gheader, end='\n', label=False)
        sx_logger.run()

    def apilist(self):
        """ Print list of available APIs in PCAP file """
        sx_logger = SxLogger(pcap_file=self.args.apilist, adb_files=self._get_adb_files(),
                             filter_cfg=self.filter_cfg, params=self.params_cfg, fix_xml=self.args.fix_xml)
        sx_logger.reader.apilist_print(self.args.filter_gen)


def main():
    sx_runner = SxRunner()
    sx_runner.run()


if __name__ == '__main__':
    main()
