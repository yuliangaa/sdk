#!/usr/bin/env python3
"""
# SX API time line generator.
#
# This script generates the time line of SX API's called
# First API start time is taken as the baseline for time.
# This script supports both pcap file and txt file generated using sx runner
#
"""

import re
import argparse
import subprocess
import os
import sys

# Process the txt file


def parse_pcap_txt_file(txt_file):
    api_data = []
    first_start_time = None
    with open(txt_file, 'r') as file:
        # parse each line and pick the line that has API name, start/end time, return code.
        for line in file:
            if '|       ' in line:
                row = line.strip().split('|')
                if '_set' in row[2]:
                    if args.ignore_verbosity and 'verbosity' in row[2]:
                        continue
                elif '_get' in row[2]:
                    if args.ignore_get:
                        continue
                    if args.ignore_verbosity and 'verbosity' in row[2]:
                        continue
                else:
                    continue

                api_name_with_code = row[2].strip()
                api_name = re.sub(r'\s*\(\w+\)', '', api_name_with_code)
                api_code = re.search(r'\((\w+)\)', api_name_with_code).group(1)
                start_time = int(float(row[5].replace('s', '')))
                end_time = int(float(row[6].replace('s', '')))

                if first_start_time is None:
                    first_start_time = start_time

                start_time -= first_start_time
                end_time -= first_start_time

                if args.start_time is not None and start_time < args.start_time:
                    continue
                if end_time > args.end_time:
                    continue

                if api_data and api_data[-1]['api_name'] == api_name:
                    if start_time - api_data[-1]['end_time'] <= 1:
                        api_data[-1]['end_time'] = end_time
                        api_data[-1]['count'] += 1
                    else:
                        api_data.append({
                            'api_name': api_name,
                            'api_code': api_code,
                            'start_time': start_time,
                            'end_time': end_time,
                            'count': 1
                        })
                else:
                    api_data.append({
                        'api_name': api_name,
                        'api_code': api_code,
                        'start_time': start_time,
                        'end_time': end_time,
                        'count': 1
                    })
        return api_data


def print_api_time_line(api_data):

    # print header.
    print("{:<50} {:<10} {:<10} {:<5}".format("API Name", "Start Time", "End Time", "Count"))
    print("-" * 80)

    # print timeline
    for data in api_data:
        api_name = data['api_name']
        start_time = data['start_time']
        end_time = data['end_time']
        count = data['count']
        print("{:<50} {:<10} {:<10} {:<5}".format(api_name, start_time, end_time, count))


def get_pcap_txt_log_file():
    # Check if the input file is a pcap file or txt file
    if args.input_file.endswith('.pcap'):
        filename = os.path.basename(args.input_file)
        # Run runner.py with the pcap file to generate the .txt file
        txt_file = "/tmp/logged_log_" + filename + ".txt"
        with open(txt_file, "w") as outfile:
            subprocess.run(['python', args.runner_path, '-l', args.input_file], stdout=outfile, check=True)
    else:
        txt_file = args.input_file
    return txt_file


def print_help():
    print("""Example :\n
    sx_api_time_line_gen.py --input-file <pcap file> --runner-path ./sys_sdk/applibs/sx_api_utils/sx_runner.py
    sx_api_time_line_gen.py --input-file <txt file> --start-time 0 --end-time 5""")


def parse_args():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Process API data from a pcap file or txt file.')
    parser.add_argument('--input-file', help='Path to the pcap file or txt file')
    parser.add_argument('--runner-path', default="sx_runner.py", help='Path to the runner.py script (required for pcap files)')
    parser.add_argument('--ignore-get', action='store_true', help='Ignore APIs with "_get" in the name')
    parser.add_argument('--ignore-verbosity', action='store_true', help='Ignore APIs with "verbosity" in the name')
    parser.add_argument('--start-time', type=int, help='Start time for processing (in seconds)')
    parser.add_argument('--end-time', type=int, default=sys.maxsize, help='End time for processing (in seconds)')
    try:
        args = parser.parse_args()
    except SystemExit:
        print("\n\n")
        print_help()
        sys.exit(1)
    return args


################################################
# Run the MAIN function
################################################
if __name__ == "__main__":

    args = parse_args()

    try:
        txt_file = get_pcap_txt_log_file()
        api_data = parse_pcap_txt_file(txt_file)
        print_api_time_line(api_data)

    finally:
        # Remove the generated .txt file if it was generated from a pcap file
        if args.input_file.endswith('.pcap'):
            os.remove(txt_file)
