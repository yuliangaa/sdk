/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "mpe_manager.h"
#include "mc_container/hwd/rmid_manager.h"
#include "ethl2/vlan.h"
#include "ethl2/lag.h"
#include "ethl2/la_db.h"
#include "ethl2/lag_sink.h"
#include "ethl2/port.h"
#include "ethl2/fid_manager.h"
#include "utils/sx_mem.h"
#include "sx/utils/dbg_utils.h"
#include "sx/utils/dbg_utils_pretty_printer.h"
#include "sx/sxd/sxd_access_register.h"
#include "complib/cl_mem.h"
#include "sx/utils/gc.h"
#include "sx/sdk/sx_status_convertor.h"
#include <complib/cl_dbg.h>

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ MPE

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/
typedef struct mpe_allocation_object {
    cl_pool_item_t pool_item;
    cl_map_item_t  map_item;
    cl_map_item_t  port_index_map_item;
    mpe_key_t      mpe_key;
    uint16_t       mpe_index;
    sx_vlan_id_t   vlan_list[MAX_PHYPORT_NUM];
} mpe_allocation_object_t;

typedef struct mpe_lag_object {
    cl_pool_item_t   pool_item;
    cl_map_item_t    map_item;
    sx_port_log_id_t lag;
    uint32_t         refcount;
} mpe_lag_object_t;

static boolean_t is_initialized = FALSE;
static struct {
    cl_qmap_t  lookup_map;
    cl_qmap_t  port_index_lookup_map;
    cl_qpool_t allocation_pool;
    cl_qmap_t  lag_map;
    cl_qpool_t lag_pool;
    uint32_t   max_mpe;
    uint16_t   rif_start_index;
} mpe_manager_db_s;

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __mpe_manager_lag_event_cb(sx_port_log_id_t      log_lag_port,
                                              lag_sink_event_type_e event_type,
                                              sx_port_log_id_t      log_port,
                                              void                 *context_p);

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t mpe_manager_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

static sx_utils_status_t __mpe_delete_cb(const void *gc_context_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    mpe_allocation_object_t *p_object = (mpe_allocation_object_t*)gc_context_p;

    SX_LOG_ENTER();

    if (!gc_context_p) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("gc_context is NULL\n");
        goto out;
    }

    if (p_object->mpe_key.type == MPE_KEY_RIF_E) {
        cl_qmap_remove_item(&mpe_manager_db_s.port_index_lookup_map, &p_object->port_index_map_item);
    }
    cl_qpool_put(&mpe_manager_db_s.allocation_pool, &p_object->pool_item);

out:
    SX_LOG_EXIT();
    return sx_status_to_sx_utils_status(err);
}

sx_status_t mpe_manager_init(sx_api_sx_sdk_init_t *sx_sdk_params_p, uint32_t max_mpe)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_utils_status_t           utils_err = SX_UTILS_STATUS_SUCCESS;
    cl_status_t                 cl_err = CL_SUCCESS;
    boolean_t                   allocation_pool_initialized = FALSE;
    gc_object_type_attributes_t object_attr;
    boolean_t                   lag_pool_initialized = FALSE;
    uint32_t                    rif_num = 0;
    uint32_t                    lag_num = 0;
    uint32_t                    fid_num = 0;

    /* In fid_manager sdk_fid_manager_init() : fid_map_size = max_bridge_num + num_of_active_vlans
     * (in both cases we need to ad 1 to VLAN_NUMS_MAX or num_of_active_vlans).
     *  Later fid_num + 1 will be set to rif_start_index. __mpe_lookup_map_key() will use rif_start_index to separate key space
     *  for fid and rif. */
    if (sx_sdk_params_p->vlan_params.num_of_active_vlans != 0) {
        fid_num = sx_sdk_params_p->vlan_params.num_of_active_vlans;
    } else {
        fid_num = VLAN_NUMS_MAX;
    }
    uint32_t pool_size = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(object_attr);

    if (utils_check_pointer(sx_sdk_params_p, "sx_sdk_params_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    rif_num = rm_resource_global.router_rifs_max;
    lag_num = rm_resource_global.lag_num_max;
    if (sx_sdk_params_p->bridge_init_params.sdk_mode == SX_MODE_HYBRID) {
        fid_num += sx_sdk_params_p->bridge_init_params.sdk_mode_params.mode_hybrid.max_bridge_num;
    }

    if (is_initialized) {
        SX_LOG_ERR("MPE manager is already initialized\n");
        err = SX_STATUS_DB_ALREADY_INITIALIZED;
        goto out;
    }

    if (rif_num < 1) {
        /* Nothing to initialize. Simply return success. */
        goto out;
    }

    if (max_mpe < 1) {
        SX_LOG_ERR("MPE manager cannot be initialized with %u max MPE\n", max_mpe);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    pool_size = rif_num + fid_num;
    cl_err = CL_QPOOL_INIT(&mpe_manager_db_s.allocation_pool,
                           pool_size,
                           pool_size,
                           0,
                           sizeof(mpe_allocation_object_t),
                           NULL,
                           NULL,
                           NULL);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Failed to allocate MPE allocation pool: %s\n", CL_STATUS_MSG(cl_err));
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }
    allocation_pool_initialized = TRUE;

    if (lag_num > 0) {
        cl_err = CL_QPOOL_INIT(&mpe_manager_db_s.lag_pool,
                               lag_num,
                               lag_num,
                               0,
                               sizeof(mpe_lag_object_t),
                               NULL,
                               NULL,
                               NULL);
        if (cl_err != CL_SUCCESS) {
            SX_LOG_ERR("Failed to allocate MPE lag pool: %s\n", CL_STATUS_MSG(cl_err));
            err = SX_STATUS_NO_MEMORY;
            goto out;
        }
        lag_pool_initialized = TRUE;
    }

    object_attr.fence_type = GC_FENCE_TYPE_SLOW;
    object_attr.free_objects_threshold = pool_size / 10;
    object_attr.per_object_threshold = pool_size / 2;
    object_attr.hw_operation_needed = FALSE;
    object_attr.immediate_fence_needed = FALSE;
    object_attr.max_object_count = pool_size;
    utils_err = gc_object_init(GC_OBJECT_TYPE_MPE, &object_attr,
                               __mpe_delete_cb, NULL);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to initialize GC MPE object type, utils_err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

    cl_qmap_init(&mpe_manager_db_s.lag_map);
    cl_qmap_init(&mpe_manager_db_s.port_index_lookup_map);
    cl_qmap_init(&mpe_manager_db_s.lookup_map);
    mpe_manager_db_s.max_mpe = max_mpe;
    /* smpe_index == hwfid, hwfid starts from 1
     *  so the first rmpe_index should the num of l2 fids (hwfid) + 1 */
    mpe_manager_db_s.rif_start_index = (uint16_t)fid_num + 1;

    is_initialized = TRUE;

out:
    if (SX_CHECK_FAIL(err)) {
        if (lag_pool_initialized) {
            CL_QPOOL_DESTROY(&mpe_manager_db_s.lag_pool);
        }
        if (allocation_pool_initialized) {
            CL_QPOOL_DESTROY(&mpe_manager_db_s.allocation_pool);
        }
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t mpe_manager_deinit(boolean_t is_forced)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_utils_status_t        utils_err = SX_UTILS_STATUS_SUCCESS;
    cl_map_item_t          * map_item_p = NULL;
    mpe_allocation_object_t* object_p = NULL;
    mpe_lag_object_t       * lag_object_p = NULL;

    SX_LOG_ENTER();

    if (FALSE == is_initialized) {
        if (FALSE == is_forced) {
            SX_LOG_ERR("MPE manager is not initialized\n");
            err = SX_STATUS_DB_NOT_INITIALIZED;
        }
        goto out;
    }

    if ((FALSE == is_forced) && (cl_qmap_count(&mpe_manager_db_s.lookup_map) != 0)) {
        err = SX_STATUS_DB_NOT_EMPTY;
        SX_LOG_ERR("Failed to deinit, found used MPE entries, err: %s.\n", sx_status_str(err));
        goto out;
    }

    utils_err = gc_object_deinit(GC_OBJECT_TYPE_MPE);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to deinitialize GC MPE object type, utils_err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

    map_item_p = cl_qmap_head(&mpe_manager_db_s.lag_map);
    while (map_item_p != cl_qmap_end(&mpe_manager_db_s.lag_map)) {
        lag_object_p = PARENT_STRUCT(map_item_p, mpe_lag_object_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        err = lag_sink_lag_unadvise(lag_object_p->lag, __mpe_manager_lag_event_cb);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to deinit MPE lag sink advise for lag 0x%x: %s\n", lag_object_p->lag,
                       sx_status_str(err));
            goto out;
        }

        cl_qmap_remove_item(&mpe_manager_db_s.lag_map, &lag_object_p->map_item);
        cl_qpool_put(&mpe_manager_db_s.lag_pool, &lag_object_p->pool_item);
    }
    CL_QPOOL_DESTROY(&mpe_manager_db_s.lag_pool);

    map_item_p = cl_qmap_head(&mpe_manager_db_s.lookup_map);
    while (map_item_p != cl_qmap_end(&mpe_manager_db_s.lookup_map)) {
        object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        if (object_p->mpe_key.type == MPE_KEY_RIF_E) {
            cl_qmap_remove_item(&mpe_manager_db_s.port_index_lookup_map, &object_p->port_index_map_item);
        }

        cl_qmap_remove_item(&mpe_manager_db_s.lookup_map, &object_p->map_item);
        cl_qpool_put(&mpe_manager_db_s.allocation_pool, &object_p->pool_item);
    }
    CL_QPOOL_DESTROY(&mpe_manager_db_s.allocation_pool);
    is_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mpe_manager_smpe_table_port_set(uint16_t mpe_index, sx_port_log_id_t log_port, sx_vlan_id_t vlan)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;
    struct ku_smpe_reg smpe;
    sxd_reg_meta_t     reg_meta;

    SX_LOG_ENTER();

    if (SX_PORT_TYPE_ID_GET(log_port) != SX_PORT_TYPE_NETWORK) {
        SX_LOG_ERR("Cannot write SMPE for a port of this type 0x%x\n", SX_PORT_TYPE_ID_GET(log_port));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.dev_id = SX_PORT_DEV_ID_GET(log_port);

    SX_MEM_CLR(smpe);
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(smpe.local_port,
                                        smpe.lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));
    smpe.smpe_index = mpe_index;
    smpe.evid = vlan;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SMPE_E, &smpe, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed SMPE set dev %u port %u index %u egress VLAN %u: %s\n", SX_PORT_DEV_ID_GET(log_port),
                   SX_PORT_PHY_ID_GET(log_port), mpe_index, vlan, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mpe_manager_smpe_table_bulk_set(uint16_t          mpe_index,
                                                     sx_port_log_id_t *log_port_p,
                                                     sx_vlan_id_t     *vlan_arr_p,
                                                     uint16_t          entry_num)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sxd_status_t        sxd_err = SXD_STATUS_SUCCESS;
    struct ku_smpeb_reg smpeb;
    sxd_reg_meta_t      reg_meta;
    uint16_t            i = 0, j = 0, cnt = 0;
    uint16_t            index = 0;

    SX_LOG_ENTER();

    for (i = 0; i < entry_num; i++) {
        if (SX_PORT_TYPE_ID_GET(log_port_p[i]) != SX_PORT_TYPE_NETWORK) {
            SX_LOG_ERR("Cannot write SMPE for a port %x of this type 0x%x\n",
                       log_port_p[i], SX_PORT_TYPE_ID_GET(log_port_p[i]));
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

    SX_MEM_CLR(reg_meta);
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.dev_id = SX_PORT_DEV_ID_GET(log_port_p[0]);

    for (j = 0; j <= (rm_resource_global_default.port_ext_num_max / SXD_SMPEB_ELPORT_RECORD_NUM); j++) {
        SX_MEM_CLR(smpeb);
        cnt = 0;
        smpeb.smpe_index = mpe_index;
        smpeb.elport_page = j;
        for (i = 0; i < entry_num; i++) {
            index = SX_PORT_PHY_ID_GET(log_port_p[i]);
            if ((index / SXD_SMPEB_ELPORT_RECORD_NUM) != j) {
                continue;
            }
            cnt++;
            index = index % SXD_SMPEB_ELPORT_RECORD_NUM;
            smpeb.elport_record[index].smpeb_elport_record.update = 1;
            smpeb.elport_record[index].smpeb_elport_record.value = vlan_arr_p[i];
        }

        if (cnt == 0) {
            continue;
        }

        sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SMPEB_E, &smpeb, &reg_meta, 1, NULL, NULL);
        if (sxd_err != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set SMPEB for MPE index %u: %s\n", mpe_index, SXD_STATUS_MSG(sxd_err));
            err = SXD_STATUS_TO_SX_STATUS(sxd_err);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mpe_manager_rmpe_table_port_set(sx_port_log_id_t log_port, uint16_t mpe_index, hwd_rif_id_t rif)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_err = SXD_STATUS_SUCCESS;
    struct ku_rmpe_reg rmpe;
    sxd_reg_meta_t     reg_meta;

    SX_LOG_ENTER();

    if (SX_PORT_TYPE_ID_GET(log_port) != SX_PORT_TYPE_NETWORK) {
        SX_LOG_ERR("Cannot write RMPE for a port of this type 0x%x\n", log_port);
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_MEM_CLR(reg_meta);
    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.dev_id = SX_PORT_DEV_ID_GET(log_port);

    SX_MEM_CLR(rmpe);
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(rmpe.local_port, rmpe.lp_msb, SX_PORT_PHY_ID_GET(log_port));
    rmpe.rmpe_index = mpe_index;
    rmpe.erif = rif;

    sxd_err = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RMPE_E, &rmpe, &reg_meta, 1, NULL, NULL);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed RMPE set dev %u port %u index %u erif %u: %s\n", SX_PORT_DEV_ID_GET(log_port),
                   SX_PORT_PHY_ID_GET(log_port), mpe_index, rif, SXD_STATUS_MSG(sxd_err));
        err = SXD_STATUS_TO_SX_STATUS(sxd_err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mpe_manager_rif_table_set(mpe_allocation_object_t* object_p)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    length_t          index = 0, log_port_cnt = 0;
    sx_lag_id_t       lid = 0;
    sx_port_log_id_t* lag_port_list_p = NULL;

    SX_LOG_ENTER();

    switch (SX_PORT_TYPE_ID_GET(object_p->mpe_key.log_port)) {
    case SX_PORT_TYPE_NETWORK:
        err = __mpe_manager_rmpe_table_port_set(object_p->mpe_key.log_port,
                                                object_p->mpe_index,
                                                object_p->mpe_key.key.rif);
        break;

    case SX_PORT_TYPE_LAG:
        lag_port_list_p =
            (sx_port_log_id_t*)cl_calloc(rm_resource_global.lag_port_members_max,
                                         sizeof(sx_port_log_id_t));
        if (lag_port_list_p == NULL) {
            SX_LOG_ERR("Failed to allocate ports list for MPE lag iteration\n");
            err = SX_STATUS_NO_MEMORY;
            goto out;
        }
        lid = SX_PORT_LAG_ID_GET(object_p->mpe_key.log_port);
        log_port_cnt = rm_resource_global.lag_port_members_max;
        err = sx_la_db_log_port_get(lid, 0, lag_port_list_p, &log_port_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve LAG member ports of lag 0x%x for MPE: %s\n",
                       object_p->mpe_key.log_port,
                       sx_status_str(err));
            goto out;
        }

        for (index = 0; index < log_port_cnt; index++) {
            err = __mpe_manager_rmpe_table_port_set(lag_port_list_p[index],
                                                    object_p->mpe_index,
                                                    object_p->mpe_key.key.rif);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to set MPE for port 0x%x LAG member of 0x%x: %s\n",
                           lag_port_list_p[index],
                           object_p->mpe_key.log_port,
                           sx_status_str(err));
                goto out;
            }
        }
        break;

    default:
        SX_LOG_ERR("Wrong type of log port provided in MPE: 0x%x\n", object_p->mpe_key.log_port);
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    if (lag_port_list_p != NULL) {
        CL_FREE_N_NULL(lag_port_list_p);
    }
    SX_LOG_EXIT();
    return err;
}

static inline uint64_t __mpe_lookup_map_key(mpe_key_t mpe_key)
{
    switch (mpe_key.type) {
    case MPE_KEY_RIF_E:
        /* rif_start_index and key.rif are 16 bit so its safe to add type after 16 bits */
        return ((uint64_t)(mpe_manager_db_s.rif_start_index + mpe_key.key.rif)) | (MPE_KEY_RIF_E << 16);

    case MPE_KEY_FID_E:
        /* fid is 16 bit so its safe to add type after 16 bits */
        return ((uint64_t)mpe_key.key.fid) | (MPE_KEY_FID_E << 16);

    default:
        SX_LOG_ERR("Invalid MPE key type %d\n", mpe_key.type);
        return 0;
    }
}

static inline uint64_t __mpe_port_index_key(sx_port_log_id_t log_port, uint32_t mpe_index)
{
    return ((uint64_t)log_port << 32) | (uint64_t)mpe_index;
}

static inline uint64_t __mpe_lag_map_key(sx_port_log_id_t lag)
{
    return (uint64_t)lag;
}

static sx_status_t __mpe_manager_lag_unadvise(sx_port_log_id_t lag)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    uint64_t          key = 0;
    cl_map_item_t   * map_item_p = NULL;
    mpe_lag_object_t* lag_object_p = NULL;

    SX_LOG_ENTER();

    key = __mpe_lag_map_key(lag);
    map_item_p = cl_qmap_get(&mpe_manager_db_s.lag_map, key);
    if (map_item_p == cl_qmap_end(&mpe_manager_db_s.lag_map)) {
        SX_LOG_ERR("Cannot unadvise MPE lag 0x%x whose object does not exist\n", lag);
        err = SX_STATUS_ERROR;
        goto out;
    }

    lag_object_p = PARENT_STRUCT(map_item_p, mpe_lag_object_t, map_item);
    if (lag_object_p->lag != lag) {
        SX_LOG_ERR("Cannot unadvise MPE lag object with wrong lag 0x%x instead of 0x%x\n", lag_object_p->lag, lag);
        err = SX_STATUS_ERROR;
        goto out;
    }
    if (lag_object_p->refcount < 1) {
        SX_LOG_ERR("Cannot unadvise MPE lag object 0x%x with refcount %u\n", lag, lag_object_p->refcount);
        err = SX_STATUS_ERROR;
        goto out;
    }

    lag_object_p->refcount--;

    if (lag_object_p->refcount == 0) {
        err = lag_sink_lag_unadvise(lag, __mpe_manager_lag_event_cb);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to unregister MPE lag sink advise for lag 0x%x: %s\n", lag, sx_status_str(err));
            goto out;
        }
        cl_qmap_remove_item(&mpe_manager_db_s.lag_map, &lag_object_p->map_item);
        cl_qpool_put(&mpe_manager_db_s.lag_pool, &lag_object_p->pool_item);
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mpe_manager_lag_advise(sx_port_log_id_t lag)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    uint64_t          key = 0;
    cl_map_item_t   * map_item_p = NULL;
    mpe_lag_object_t* lag_object_p = NULL;
    cl_pool_item_t  * pool_item_p = NULL;

    SX_LOG_ENTER();

    key = __mpe_lag_map_key(lag);
    map_item_p = cl_qmap_get(&mpe_manager_db_s.lag_map, key);
    if (map_item_p == cl_qmap_end(&mpe_manager_db_s.lag_map)) {
        pool_item_p = cl_qpool_get(&mpe_manager_db_s.lag_pool);
        if (pool_item_p == NULL) {
            SX_LOG_ERR("Failed to allocate MPE lag object 0x%x from pool\n", lag);
            err = SX_STATUS_ERROR;
            goto out;
        }

        lag_object_p = PARENT_STRUCT(pool_item_p, mpe_lag_object_t, pool_item);
        lag_object_p->lag = lag;
        lag_object_p->refcount = 0;
        cl_qmap_insert(&mpe_manager_db_s.lag_map, key, &lag_object_p->map_item);

        err = lag_sink_lag_advise(lag, __mpe_manager_lag_event_cb, NULL, 0);
        if (SX_CHECK_FAIL(err)) {
            cl_qmap_remove_item(&mpe_manager_db_s.lag_map, &lag_object_p->map_item);
            cl_qpool_put(&mpe_manager_db_s.lag_pool, &lag_object_p->pool_item);
            SX_LOG_ERR("Failed to register MPE lag sink advise for lag 0x%x: %s\n", lag, sx_status_str(err));
            goto out;
        }
    } else {
        lag_object_p = PARENT_STRUCT(map_item_p, mpe_lag_object_t, map_item);
    }

    lag_object_p->refcount++;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mpe_manager_fid_allocate(mpe_key_t mpe_key, uint16_t* mpe_index_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_utils_status_t        utils_err = SX_UTILS_STATUS_SUCCESS;
    uint64_t                 key = 0;
    cl_map_item_t           *map_item_p = NULL;
    mpe_allocation_object_t *object_p = NULL;
    cl_pool_item_t          *pool_item_p = NULL;
    boolean_t                map_update = FALSE;
    uint32_t                 free_objects = 0;
    sxd_fid_t                hwfid = 0;

    SX_LOG_ENTER();

    err = sdk_fid_manager_get_hwfid_by_fid(mpe_key.key.fid, &hwfid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get hwFid for fid:[%u]. err=[%s]\n",
                   mpe_key.key.fid, sx_status_str(err));
        goto out;
    }

    key = __mpe_lookup_map_key(mpe_key);
    map_item_p = cl_qmap_get(&mpe_manager_db_s.lookup_map, key);
    if (map_item_p != cl_qmap_end(&mpe_manager_db_s.lookup_map)) {
        object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, map_item);
        *mpe_index_p = object_p->mpe_index;
        goto out;
    }

    pool_item_p = cl_qpool_get(&mpe_manager_db_s.allocation_pool);
    if (pool_item_p == NULL) {
        SX_LOG_ERR("Failed to allocate MPE index object for FID %u\n", mpe_key.key.fid);
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }


    *mpe_index_p = hwfid;
    object_p = PARENT_STRUCT(pool_item_p, mpe_allocation_object_t, pool_item);
    object_p->mpe_key = mpe_key;
    object_p->mpe_key.log_port = SX_INVALID_PORT;
    object_p->mpe_index = *mpe_index_p;
    cl_qmap_insert(&mpe_manager_db_s.lookup_map, key, &object_p->map_item);
    map_update = TRUE;

    free_objects = cl_qpool_count(&mpe_manager_db_s.allocation_pool);
    utils_err = gc_object_check_thresholds(GC_OBJECT_TYPE_MPE, free_objects);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to check GC thresholds for MPE object type with %u free objects, utils_err = [%s]\n",
                   free_objects, SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

out:
    if (SX_CHECK_FAIL(err)) {
        if (map_update) {
            cl_qmap_remove_item(&mpe_manager_db_s.lookup_map, &object_p->map_item);
        }
        if (pool_item_p != NULL) {
            cl_qpool_put(&mpe_manager_db_s.allocation_pool, pool_item_p);
        }
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mpe_manager_rif_allocate(mpe_key_t mpe_key, uint16_t* mpe_index_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_utils_status_t         utils_err = SX_UTILS_STATUS_SUCCESS;
    uint16_t                  index = 0;
    uint64_t                  key = 0;
    cl_map_item_t           * map_item_p = NULL;
    mpe_allocation_object_t * object_p = NULL;
    cl_pool_item_t          * pool_item_p = NULL;
    boolean_t                 found = FALSE;
    uint32_t                  free_objects = 0;

    SX_LOG_ENTER();

    key = __mpe_lookup_map_key(mpe_key);
    map_item_p = cl_qmap_get(&mpe_manager_db_s.lookup_map, key);
    if (map_item_p != cl_qmap_end(&mpe_manager_db_s.lookup_map)) {
        object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, map_item);
        *mpe_index_p = object_p->mpe_index;
        err = SX_STATUS_ENTRY_ALREADY_EXISTS;
        goto out;
    }

    pool_item_p = cl_qpool_get(&mpe_manager_db_s.allocation_pool);
    if (pool_item_p == NULL) {
        SX_LOG_ERR("Failed to allocate MPE index object for RIF %u port 0x%x\n",
                   mpe_key.key.rif, mpe_key.log_port);
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    index = mpe_manager_db_s.rif_start_index;
    while (index < (uint16_t)mpe_manager_db_s.max_mpe) {
        key = __mpe_port_index_key(mpe_key.log_port, index);
        map_item_p = cl_qmap_get(&mpe_manager_db_s.port_index_lookup_map, key);
        if (map_item_p == cl_qmap_end(&mpe_manager_db_s.port_index_lookup_map)) {
            found = TRUE;
            break;
        }
        index++;
    }

    if (!found) {
        SX_LOG_NTC("Failed to allocate MPE index for RIF %u port 0x%x. All %u indices taken\n",
                   mpe_key.key.rif,
                   mpe_key.log_port,
                   mpe_manager_db_s.max_mpe);
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(mpe_key.log_port) == SX_PORT_TYPE_LAG) {
        err = __mpe_manager_lag_advise(mpe_key.log_port);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to MPE advise for lag 0x%x: %s\n",
                       mpe_key.log_port, sx_status_str(err));
            goto out;
        }
    }

    /* Point of no return. No rollback after this point */
    object_p = PARENT_STRUCT(pool_item_p, mpe_allocation_object_t, pool_item);
    pool_item_p = NULL;

    object_p->mpe_key = mpe_key;
    object_p->mpe_index = index;
    cl_qmap_insert(&mpe_manager_db_s.port_index_lookup_map, key, &object_p->port_index_map_item);
    key = __mpe_lookup_map_key(mpe_key);
    cl_qmap_insert(&mpe_manager_db_s.lookup_map, key, &object_p->map_item);
    *mpe_index_p = index;

    err = __mpe_manager_rif_table_set(object_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to write MPE table for new rif %u port 0x%x: %s\n",
                   mpe_key.key.rif, mpe_key.log_port, sx_status_str(err));
        goto out;
    }

    free_objects = cl_qpool_count(&mpe_manager_db_s.allocation_pool);
    utils_err = gc_object_check_thresholds(GC_OBJECT_TYPE_MPE, free_objects);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to check GC thresholds for MPE object type with %u free objects, utils_err = [%s]\n",
                   free_objects, SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

out:
    if (SX_CHECK_FAIL(err)) {
        if (pool_item_p != NULL) {
            cl_qpool_put(&mpe_manager_db_s.allocation_pool, pool_item_p);
        }
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mpe_manager_entry_deallocate(mpe_key_t mpe_key)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_utils_status_t         utils_err = SX_UTILS_STATUS_SUCCESS;
    uint64_t                  key = 0;
    cl_map_item_t           * map_item_p = NULL;
    mpe_allocation_object_t * object_p = NULL;

    SX_LOG_ENTER();

    key = __mpe_lookup_map_key(mpe_key);
    map_item_p = cl_qmap_get(&mpe_manager_db_s.lookup_map, key);
    if (map_item_p == cl_qmap_end(&mpe_manager_db_s.lookup_map)) {
        SX_LOG_INF("Cannot delete MPE object which does not exist\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, map_item);

    if ((object_p->mpe_key.log_port != SX_INVALID_PORT) &&
        (SX_PORT_TYPE_ID_GET(object_p->mpe_key.log_port) == SX_PORT_TYPE_LAG)) {
        err = __mpe_manager_lag_unadvise(object_p->mpe_key.log_port);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to unadvise MPE lag 0x%x: %s\n",
                       object_p->mpe_key.log_port,
                       sx_status_str(err));
            goto out;
        }
    }

    /* Remove RIF from lookup map, so that if this RIF is added again, it will
     * receive a different index. If FID is removed then it always receives the same index.
     */
    cl_qmap_remove_item(&mpe_manager_db_s.lookup_map, &object_p->map_item);

    /* Push index/port pair to garbage collector. The pair will be freed after
     * fence is performed.
     */
    utils_err = gc_object_push(GC_OBJECT_TYPE_MPE, object_p,
                               GC_STATE_PENDING_FENCE, 1,
                               GC_OBJECT_SUBTYPE_NONE, object_p->mpe_index,
                               NULL);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to push MPE object (log_port 0x%x, index %u) to GC, utils_err = [%s]\n",
                   object_p->mpe_key.log_port, object_p->mpe_index,
                   SX_UTILS_STATUS_MSG(utils_err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __mpe_manager_lag_event_cb(sx_port_log_id_t      log_lag_port,
                                              lag_sink_event_type_e event_type,
                                              sx_port_log_id_t      log_port,
                                              void                 *context_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    cl_map_item_t          * map_item_p = NULL;
    mpe_allocation_object_t* object_p = NULL;

    UNUSED_PARAM(context_p);

    SX_LOG_ENTER();

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_POST_PORT_ADDED_E:
        map_item_p = cl_qmap_head(&mpe_manager_db_s.port_index_lookup_map);
        while (map_item_p != cl_qmap_end(&mpe_manager_db_s.port_index_lookup_map)) {
            object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, port_index_map_item);
            map_item_p = cl_qmap_next(map_item_p);

            if (object_p->mpe_key.log_port != log_lag_port) {
                continue;
            }

            err = __mpe_manager_rmpe_table_port_set(log_port, object_p->mpe_index,
                                                    object_p->mpe_key.key.rif);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to add port 0x%x to LAG 0x%x in MPE table: %s\n",
                           log_port,
                           log_lag_port,
                           sx_status_str(err));
                goto out;
            }

            err = rmid_manager_lag_port_added(log_port, object_p->mpe_key.key.rif,
                                              object_p->mpe_index);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Error notifying RMID manager of adding LAG RIF %u port 0x%x: %s\n",
                           object_p->mpe_key.key.rif,
                           log_port,
                           sx_status_str(err));
                goto out;
            }
        }

        break;

    case LAG_SINK_EVENT_TYPE_LAG_PORT_REMOVED_E:
        map_item_p = cl_qmap_head(&mpe_manager_db_s.port_index_lookup_map);
        while (map_item_p != cl_qmap_end(&mpe_manager_db_s.port_index_lookup_map)) {
            object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, port_index_map_item);
            map_item_p = cl_qmap_next(map_item_p);

            if (object_p->mpe_key.log_port != log_lag_port) {
                continue;
            }

            err = rmid_manager_lag_port_deleted(log_port, object_p->mpe_key.key.rif,
                                                object_p->mpe_index);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Error notifying RMID manager of LAG RIF %u port 0x%x deletion: %s\n",
                           object_p->mpe_key.key.rif,
                           log_port,
                           sx_status_str(err));
                goto out;
            }
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_PRE_PORT_ADDED_VALIDATIONS_E:
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        break;

    default:
        SX_LOG_ERR("Unexpected event %u in MPE lag even advisor\n", event_type);
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mpe_manager_create(mpe_key_t mpe_key, uint16_t *index_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (is_initialized == FALSE) {
        SX_LOG_ERR("MPE manager is not initialized for mpe manager create\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }


    if (utils_check_pointer(index_p, "index_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (mpe_key.type) {
    case MPE_KEY_RIF_E:
        err = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Use get index to create entry for RMPE\n");
        break;

    case MPE_KEY_FID_E:
        err = __mpe_manager_fid_allocate(mpe_key, index_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Cannot lookup and/or allocate MPE for FID %u: %s\n",
                       mpe_key.key.fid, sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unexpected key type %u in MPE get\n", mpe_key.type);
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mpe_manager_get_index(mpe_key_t mpe_key, uint16_t *index_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint64_t                 key;
    mpe_allocation_object_t* object_p = NULL;
    cl_map_item_t          * map_item_p = NULL;

    SX_LOG_ENTER();

    if (is_initialized == FALSE) {
        SX_LOG_ERR("MPE manager is not initialized for mpe manager get index\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (utils_check_pointer(index_p, "index_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (mpe_key.type) {
    case MPE_KEY_RIF_E:
        if ((SX_PORT_TYPE_ID_GET(mpe_key.log_port) != SX_PORT_TYPE_LAG) &&
            (SX_PORT_TYPE_ID_GET(mpe_key.log_port) != SX_PORT_TYPE_NETWORK)) {
            SX_LOG_ERR("Wrong log-port 0x%x type specified for MPE. "
                       "Only LAG and Network ports supported\n", mpe_key.log_port);
            err = SX_STATUS_ERROR;
            goto out;
        }

        key = __mpe_lookup_map_key(mpe_key);
        map_item_p = cl_qmap_get(&mpe_manager_db_s.lookup_map, key);
        if (map_item_p != cl_qmap_end(&mpe_manager_db_s.lookup_map)) {
            object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, map_item);
            if (mpe_key.log_port != object_p->mpe_key.log_port) {
                SX_LOG_ERR("Wrong log-port 0x%x specified in MPE get. Should be 0x%x\n",
                           mpe_key.log_port, object_p->mpe_key.log_port);
                err = SX_STATUS_ERROR;
                goto out;
            }
            *index_p = object_p->mpe_index;
            goto out;
        }

        err = __mpe_manager_rif_allocate(mpe_key, index_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Cannot lookup and/or allocate MPE for RIF %u port 0x%x: %s\n",
                       mpe_key.key.rif, mpe_key.log_port, sx_status_str(err));
            goto out;
        }
        break;

    case MPE_KEY_FID_E:
        key = __mpe_lookup_map_key(mpe_key);
        map_item_p = cl_qmap_get(&mpe_manager_db_s.lookup_map, key);
        if (map_item_p != cl_qmap_end(&mpe_manager_db_s.lookup_map)) {
            object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, map_item);
            *index_p = object_p->mpe_index;
            goto out;
        }
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Could not find MPE for FID %u: %s\n", mpe_key.key.fid, sx_status_str(err));
        goto out;

    default:
        SX_LOG_ERR("Unexpected key type %u in MPE get\n", mpe_key.type);
        err = SX_STATUS_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mpe_manager_fid_deleted(sx_fid_t fid)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    mpe_key_t   mpe_key;

    SX_LOG_ENTER();

    if (is_initialized == FALSE) {
        SX_LOG_ERR("MPE manager is not initialized for mpe manager rif delete\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    mpe_key.log_port = 0;
    mpe_key.key.fid = fid;
    mpe_key.type = MPE_KEY_FID_E;

    err = __mpe_manager_entry_deallocate(mpe_key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to delete MPE FID %u: %s\n", fid, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mpe_manager_rif_deleted(hwd_rif_id_t rif)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    mpe_key_t   mpe_key;

    SX_LOG_ENTER();

    if (is_initialized == FALSE) {
        SX_LOG_ERR("MPE manager is not initialized for mpe manager rif delete\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    mpe_key.log_port = 0;
    mpe_key.key.rif = rif;
    mpe_key.type = MPE_KEY_RIF_E;

    err = __mpe_manager_entry_deallocate(mpe_key);
    if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Failed to delete MPE RIF %u: %s\n", rif, sx_status_str(err));
        goto out;
    }
    err = SX_STATUS_SUCCESS;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mpe_manager_set(mpe_key_t mpe_key, uint16_t val)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint64_t                 key = 0;
    cl_map_item_t           *map_item_p = NULL;
    mpe_allocation_object_t *object_p = NULL;

    SX_LOG_ENTER();

    if (is_initialized == FALSE) {
        SX_LOG_ERR("MPE manager is not initialized for mpe manager set\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    key = __mpe_lookup_map_key(mpe_key);
    map_item_p = cl_qmap_get(&mpe_manager_db_s.lookup_map, key);
    if (map_item_p != cl_qmap_end(&mpe_manager_db_s.lookup_map)) {
        object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, map_item);
    } else {
        SX_LOG_ERR("Couldn't find MPE index for FID %u\n", mpe_key.key.fid);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (mpe_key.type == MPE_KEY_FID_E) {
        if (SX_PORT_TYPE_ID_GET(mpe_key.log_port) == SX_PORT_TYPE_LAG) {
            SX_LOG_ERR("Lag is not supported for MPE FID entries.\n");
            err = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        /* Update DB for debug purpose */
        object_p->vlan_list[SX_PORT_PHY_ID_GET(mpe_key.log_port)] = val;
        /* Update HW */
        err = __mpe_manager_smpe_table_port_set(object_p->mpe_index,
                                                mpe_key.log_port,
                                                val);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to update SMPE entry for PORT %x in FID %u, mpe %u, vlan %u: %s\n",
                       mpe_key.log_port, mpe_key.key.fid, object_p->mpe_index, val, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t mpe_manager_bulk_set(mpe_key_t mpe_key, uint16_t entry_num, sx_port_log_id_t *log_port_p, uint16_t *val_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    uint64_t                 key = 0;
    cl_map_item_t           *map_item_p = NULL;
    mpe_allocation_object_t *object_p = NULL;
    uint32_t                 i = 0;

    SX_LOG_ENTER();

    if (is_initialized == FALSE) {
        SX_LOG_ERR("MPE manager is not initialized for mpe manager bulk set\n");
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (utils_check_pointer(log_port_p, "log_port_p") ||
        utils_check_pointer(val_p, "val_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    key = __mpe_lookup_map_key(mpe_key);
    map_item_p = cl_qmap_get(&mpe_manager_db_s.lookup_map, key);
    if (map_item_p != cl_qmap_end(&mpe_manager_db_s.lookup_map)) {
        object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, map_item);
    } else {
        SX_LOG_ERR("Couldn't find MPE index\n");
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (mpe_key.type == MPE_KEY_FID_E) {
        /* Update DB for debug purpose */
        for (i = 0; i < entry_num; i++) {
            object_p->vlan_list[SX_PORT_PHY_ID_GET(log_port_p[i])] = val_p[i];
        }
        /* Update HW */
        err = __mpe_manager_smpe_table_bulk_set(object_p->mpe_index,
                                                log_port_p,
                                                val_p,
                                                entry_num);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to update SMPEB entry for FID %u, mpe %u: %s\n",
                       mpe_key.key.fid, object_p->mpe_index, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

void mpe_manager_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    uint32_t                  num = 0;
    uint32_t                  port_cnt = 0;
    uint32_t                  port_list_filtered_cnt = 0;
    uint32_t                  port_index = 0;
    uint32_t                  i = 0, j = 0;
    sx_port_log_id_t         *port_list = NULL;
    sx_port_log_id_t         *port_list_filtered = NULL;
    cl_map_item_t           * map_item_p = NULL;
    mpe_allocation_object_t * object_p = NULL;
    dbg_utils_table_columns_t rmpe_allocation_table[] = {
        {"Log-port", 10, PARAM_PORT_ID_E, NULL},
        {"Rif", 5, PARAM_UINT16_E, NULL},
        {"MPE Index", 15, PARAM_UINT16_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    dbg_utils_table_columns_t smpe_allocation_table[] = {
        {"FID", 7, PARAM_UINT16_E, NULL},
        {"MPE Index", 11, PARAM_UINT16_E, NULL},
        {"Log-port", 10, PARAM_PORT_ID_E, NULL},
        {"VLAN", 6, PARAM_UINT16_E, NULL},
        {NULL, 0, PARAM_LAST_E, NULL}
    };
    FILE                     *stream_p = NULL;


    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }
    stream_p = dbg_dump_params_p->stream;


    dbg_utils_pprinter_module_header_print(stream_p, "MPE Manager");
    dbg_utils_pprinter_field_print(stream_p, "Module initialized", &is_initialized, PARAM_BOOL_E);

    if (!is_initialized) {
        goto out;
    }

    /* DB common information */
    dbg_utils_pprinter_field_print(stream_p, "Max MPE index", &mpe_manager_db_s.max_mpe, PARAM_UINT32_E);
    dbg_utils_pprinter_field_print(stream_p, "RIF start MPE index", &mpe_manager_db_s.rif_start_index, PARAM_UINT16_E);
    num = cl_qpool_count(&mpe_manager_db_s.allocation_pool);
    dbg_utils_pprinter_field_print(stream_p, "Allocation pool count", &num, PARAM_UINT32_E);
    num = cl_qmap_count(&mpe_manager_db_s.port_index_lookup_map);
    dbg_utils_pprinter_field_print(stream_p, "Port index map count", &num, PARAM_UINT32_E);
    num = cl_qmap_count(&mpe_manager_db_s.lookup_map);
    dbg_utils_pprinter_field_print(stream_p, "Lookup map count", &num, PARAM_UINT32_E);
    num = cl_qmap_count(&mpe_manager_db_s.lag_map);
    dbg_utils_pprinter_field_print(stream_p, "LAG map count", &num, PARAM_UINT32_E);

    /* RMPE dump */
    dbg_utils_pprinter_secondary_header_print(stream_p, "RMPE Allocation Table");
    dbg_utils_pprinter_table_headline_print(stream_p, rmpe_allocation_table);
    map_item_p = cl_qmap_head(&mpe_manager_db_s.port_index_lookup_map);
    while (map_item_p != cl_qmap_end(&mpe_manager_db_s.port_index_lookup_map)) {
        object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, port_index_map_item);
        map_item_p = cl_qmap_next(map_item_p);

        rmpe_allocation_table[0].data = &object_p->mpe_key.log_port;
        rmpe_allocation_table[1].data = &object_p->mpe_key.key.rif;
        rmpe_allocation_table[2].data = &object_p->mpe_index;

        dbg_utils_pprinter_table_data_line_print(stream_p, rmpe_allocation_table);
    }

    /* SMPE dump */
    err = port_swid_get(SX_ACCESS_CMD_COUNT, 0, NULL, &port_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("port_swid_get (get) fails\n");
        goto out;
    }

    if (port_cnt == 0) {
        dbg_utils_pprinter_print(stream_p, "No available ports.\n");
        goto out;
    }

    port_list = cl_malloc(port_cnt * sizeof(sx_port_log_id_t));
    if (port_list == NULL) {
        SX_LOG_ERR("Failed to allocate memory for port list\n");
        goto out;
    }

    err = port_swid_get(SX_ACCESS_CMD_GET, 0, port_list, &port_cnt);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("port_swid_get (get) fails\n");
        goto out;
    }

    /* Filter port list. Only network ports are allowed. */
    port_list_filtered = cl_malloc(port_cnt * sizeof(sx_port_log_id_t));
    if (port_list_filtered == NULL) {
        SX_LOG_ERR("Failed to allocate memory for port list filter\n");
        goto out;
    }
    for (i = 0, j = 0; i < port_cnt; i++) {
        if (SX_PORT_TYPE_ID_GET(port_list[i]) == SX_PORT_TYPE_NETWORK) {
            port_list_filtered[j++] = port_list[i];
        }
    }
    port_list_filtered_cnt = j;

    dbg_utils_pprinter_secondary_header_print(stream_p, "SMPE Allocation Table");
    dbg_utils_pprinter_table_headline_print(stream_p, smpe_allocation_table);
    map_item_p = cl_qmap_head(&mpe_manager_db_s.lookup_map);
    while (map_item_p != cl_qmap_end(&mpe_manager_db_s.lookup_map)) {
        object_p = PARENT_STRUCT(map_item_p, mpe_allocation_object_t, map_item);
        map_item_p = cl_qmap_next(map_item_p);

        if (object_p->mpe_key.type != MPE_KEY_FID_E) {
            continue;
        }

        for (i = 0; i < port_list_filtered_cnt; i++) {
            port_index = SX_PORT_PHY_ID_GET(port_list_filtered[i]);

            /* Don't print zeros */
            if (object_p->vlan_list[port_index] == 0) {
                continue;
            }

            smpe_allocation_table[0].data = &object_p->mpe_key.key.fid;
            smpe_allocation_table[1].data = &object_p->mpe_index;
            smpe_allocation_table[2].data = &port_list_filtered[i];
            smpe_allocation_table[3].data = &object_p->vlan_list[port_index];

            dbg_utils_pprinter_table_data_line_print(stream_p, smpe_allocation_table);
        }
    }

out:
    if (port_list != NULL) {
        cl_free(port_list);
    }
    if (port_list_filtered != NULL) {
        cl_free(port_list_filtered);
    }
}
