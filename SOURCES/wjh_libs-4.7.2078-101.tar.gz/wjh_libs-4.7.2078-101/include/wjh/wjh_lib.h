/*
 * Copyright © 2001-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_LIB_H_
#define WJH_LIB_H_

#include "wjh_lib_types.h"

/************************************************
 *  API functions
 ***********************************************/

/**
 * This API sets the log verbosity level.
 *
 * @param[in] level    - verbosity level
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_log_verbosity_level_set(const wjh_verbosity_level_t level);

/**
 * This API gets the log verbosity level.
 *
 * @param[out] level    - verbosity level
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_log_verbosity_level_get(wjh_verbosity_level_t *level_p);

/**
 * This API init WJH service lib.
 * Note: During initialization, shared memory file /dev/shm/wjh_libs_shm will be created for synchronization,
 *       it must be accessible (read and write) among any WJH clients.
 *
 * @param[in] param_p    - init param
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_init(const wjh_init_param_t *param_p);

/**
 * This API deinit WJH service lib.
 *
 *
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_deinit(void);

/**
 * This API init drop reason group.
 *
 * @param[in] drop_reason_group    - drop reason group
 * @param[in] attr_p               - drop reason group attribute
 * @param[in] callbacks_p          - callbacks for the drop packets of input drop reason group
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_init(const wjh_drop_reason_group_e       drop_reason_group,
                                        const wjh_drop_reason_group_attr_t *attr_p,
                                        const wjh_drop_callbacks_t         *callbacks_p);

/**
 * This API deinit drop reason group.
 *
 * @param[in] drop_reason_group    - drop reason group
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_deinit(const wjh_drop_reason_group_e drop_reason_group);

/**
 * This API create user channel.
 * SDK module TELE should be initialized with TAC enabled (sx_api_tele_init_set) to use channel type WJH_USER_CHANNEL_TAC_E
 * @param[in] channel_type          - user channel type
 * @param[out] channel_id_p         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 * @return WJH_STATUS_UNSUPPORTED if the channel type is WJH_USER_CHANNEL_TAC_E and not on spectrum4
 */
wjh_status_t wjh_user_channel_create(const wjh_user_channel_type_e channel_type,
                                     wjh_user_channel_id_t        *channel_id_p);

/**
 * This API set the wjh user channel attributes.
 *
 * @param[in] channel_id          - user channel id
 * @param[in] channel_attr_p      - user channel attributes
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_set(const wjh_user_channel_id_t    channel_id,
                                  const wjh_user_channel_attr_t *channel_attr_p);

/**
 * This API pulls the user channel which is in pull mode.
 * Supported channel types: cyclic and aggregation.
 *
 * @param[in] channel_id          - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 * @return WJH_STATUS_UNSUPPORTED if the channel type is WJH_USER_CHANNEL_TAC_E
 */
wjh_status_t wjh_user_channel_pull(const wjh_user_channel_id_t channel_id);

/**
 * This API destroy wjh user channel.
 *
 * @param[in] channel_id         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_destroy(const wjh_user_channel_id_t channel_id);

/**
 * This API flush user channel.
 *
 * @param[in] channel_id         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_UNSUPPORTED if operation unsupported
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_user_channel_flush(const wjh_user_channel_id_t channel_id);

/**
 * This API bind drop reason group to user channel.
 * If any trap in the drop reason group is used somewhere else, that trap will not be sent to a TAC channel.
 * @param[in] drop_reason_group  - drop reason group
 * @param[in] channel_id         - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_bind(const wjh_drop_reason_group_e drop_reason_group,
                                        const wjh_user_channel_id_t   channel_id);

/**
 * This API unbind drop reason group from user channel.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_unbind(const wjh_drop_reason_group_e drop_reason_group);

/**
 * This API enable drop reason group to get dropped packets via callbacks.
 * Only the drop reasons in the drop reason group with specified severity will be enabled.
 * And all ACL drop reasons should have the same severity.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @param[in] severity           - severity, ignored for L1
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_enable(const wjh_drop_reason_group_e drop_reason_group,
                                          const wjh_severity_e          severity);

/**
 * This API disable drop reason group to stop getting dropped packets.
 * Only the drop reasons in the drop reason group with specified severity will be enabled.
 * And all ACL drop reasons should have the same severity.
 *
 * @param[in] drop_reason_group  - drop reason group
 * @param[in] severity           - severity, ignored for L1
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_group_disable(const wjh_drop_reason_group_e drop_reason_group,
                                           const wjh_severity_e          severity);

/**
 * This API get severity of drop reason.
 *
 * @param[in] drop_reason          - drop reason
 * @param[in] severity_p           - severity
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is null
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_drop_reason_severity_get(const wjh_drop_reason_id_e drop_reason,
                                          wjh_severity_e            *severity_p);

/**
 * This API get counter per user channel.
 *
 * @param[in] channel_id         - user channel id
 * @param[out] counter_p         - drop counter
 * @param[in] clear              - clear drop counter
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if channel id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_counter_get(const wjh_user_channel_id_t channel_id,
                             wjh_drop_counter_t         *counter_p,
                             const uint8_t               clear);

/**
 * This API get global counter of all user channel.
 *
 * @param[in] channel_id         - user channel id
 * @param[out] counter_p         - drop counter
 * @param[in] clear              - clear drop counter
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_global_counter_get(wjh_drop_counter_t *counter_p,
                                    const uint8_t       clear);

/**
 * This API create a filter with a list of filter key.
 * 256 filter will be supported at most
 * Note: This API is not relevant when channel type is WJH_USER_CHANNEL_TAC_E
 *
 * @param[in] key_list_p    - filter key list
 * @param[in] count         - filter key list count
 * @param[out] filter_id_p  - filter id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_filter_create(wjh_filter_key_e *key_list_p, uint32_t count, wjh_filter_id_t *filter_id_p);

/**
 * This API get the list of filter key from a filter.
 * Note: This API is not relevant when channel type is WJH_USER_CHANNEL_TAC_E
 *
 * @param[in] filter_id        - filter id
 * @param[out] key_list_p      - filter key list
 * @param[out] count_p         - filter key list count
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if filter id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_filter_get(wjh_filter_id_t filter_id, wjh_filter_key_e  *key_list_p, uint32_t *count_p);

/**
 * This API destroy the filter.
 * Note: This API is not relevant when channel type is WJH_USER_CHANNEL_TAC_E
 *
 * @param[in] filter_id        - filter id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_ENTRY_NOT_FOUND if filter id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_filter_destroy(wjh_filter_id_t filter_id);

/**
 * This API add a list of filter rule to a filter.
 * Duplicated rule will be ignored. 1024 rules will be supported at most.
 * Note: This API is not relevant when channel type is WJH_USER_CHANNEL_TAC_E
 *
 * @param[in] filter_id        - filter id
 * @param[in] rule_list_p      - rule list
 * @param[in] rule_count       - rule list count
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if filter id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_filter_rule_add(wjh_filter_id_t filter_id, wjh_filter_rule_t *rule_list_p, uint32_t rule_count);

/**
 * This API remove a list of filter rule from a filter.
 * Note: This API is not relevant when channel type is WJH_USER_CHANNEL_TAC_E
 *
 * @param[in] filter_id        - filter id
 * @param[in] rule_list_p      - rule list
 * @param[in] rule_count       - rule list count
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if filter id or rule is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_filter_rule_remove(wjh_filter_id_t filter_id, wjh_filter_rule_t *rule_list_p, uint32_t rule_count);

/**
 * This API get the list of filter rules and the rule counters of the packets filtered out from a filter.
 * User need to make sure enough memory is allocated for rule_counter_list_p,
 * for rule_list_p and for each rule_list_p[i].key_desc_list_p
 * Call with *rule_count_p = 0, will return the real rule list count.
 * Call with rule_list_p[i].key_desc_count = 0, will return the real key_desc_count for the rule.
 * Note: This API is not relevant when channel type is WJH_USER_CHANNEL_TAC_E
 *
 * @param[in] filter_id                - filter id
 * @param[in/out] rule_list_p          - rule list
 * @param[out] rule_counter_list_p     - rule counter for each rule
 * @param[in/out] rule_count_p         - rule list count
 * @param[in] clear                    - clear the counter of filter and the rule list in it
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if filter id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_filter_rules_get(wjh_filter_id_t    filter_id,
                                  wjh_filter_rule_t *rule_list_p,
                                  uint64_t          *rule_counter_list_p,
                                  uint32_t          *rule_count_p,
                                  uint8_t            clear);

/**
 * This API get the rule counter of the packets filtered out in a filter.
 * Note: This API is not relevant when channel type is WJH_USER_CHANNEL_TAC_E
 *
 * @param[in] filter_id        - filter id
 * @param[in] rule_p           - filter rule
 * @param[out] rule_counter_p  - rule counter of the packets filtered out
 * @param[int] clear           - clear the counter of the rule
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if filter id or rule is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_filter_rule_counter_get(wjh_filter_id_t    filter_id,
                                         wjh_filter_rule_t *rule_p,
                                         uint64_t          *rule_counter_p,
                                         uint8_t            clear);

/**
 * This API get the filter counter of the packets filtered out.
 * Note: This API is not relevant when channel type is WJH_USER_CHANNEL_TAC_E
 *
 * @param[in] filter_id        - filter id
 * @param[out] counter_p       - counter of the packets filtered out
 * @param[int] clear           - clear the counter of filter and the rule list in it
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if filter id is not found
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_filter_counter_get(wjh_filter_id_t filter_id, uint64_t *counter_p, uint8_t clear);

/**
 * This API bind the filter to the user channel.
 *
 * @param[in] filter_id       - filter id
 * @param[in] channel_id      - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if filter id or channel_id is not found
 * @return WJH_STATUS_ERROR for a general error
 * @return WJH_STATUS_UNSUPPORTED if the channel type is WJH_USER_CHANNEL_TAC_E
 */
wjh_status_t wjh_filter_bind_user_channel(wjh_filter_id_t filter_id, wjh_user_channel_id_t channel_id);

/**
 * This API unbind the filter from the user channel.
 *
 * @param[in] filter_id       - filter id
 * @param[in] channel_id      - user channel id
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ENTRY_NOT_FOUND if filter id or channel_id is not found
 * @return WJH_STATUS_ERROR for a general error
 * @return WJH_STATUS_UNSUPPORTED if the channel type is WJH_USER_CHANNEL_TAC_E
 */
wjh_status_t wjh_filter_unbind_user_channel(wjh_filter_id_t filter_id, wjh_user_channel_id_t channel_id);


/**
 * This API generate the debug dump to file stream.
 *
 * @param[in] stream_p         - file stream
 * @return WJH_STATUS_SUCCESS if operation completes successfully
 * @return WJH_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return WJH_STATUS_PARAM_NULL if an input parameter is NULL
 * @return WJH_STATUS_ERROR for a general error
 */
wjh_status_t wjh_dbg_generate_dump(FILE* stream_p);

#endif /* WJH_LIB_H_ */
