#!/usr/bin/env python3

import signal
import sys
import socket

from libnl.misc import c_int
from libnl.socket_ import nl_socket_alloc, nl_socket_free, nl_socket_add_membership, nl_socket_get_cb
from libnl.msg import nlmsg_alloc, nlmsg_hdr, NL_AUTO_SEQ, nlmsg_data, print_msg
from libnl.nl import nl_connect, nl_send_auto, nl_recvmsgs
from libnl.attr import nla_put_flag, NLA_U8, NLA_U64, NLA_STRING, NLA_NESTED, NLA_U16, NLA_UNSPEC, NLA_U32, nla_policy, nla_for_each_nested, nla_parse_nested, nla_get_u32, nla_get_string
from libnl.genl.ctrl import genl_ctrl_resolve, genl_ctrl_resolve_grp
from libnl.genl.genl import genlmsg_put, genl_connect, genlmsg_parse
from libnl.error import errmsg
from libnl.linux_private.netlink import NETLINK_GENERIC, NLM_F_REQUEST, NLM_F_ACK
from libnl.handlers import NL_CB_CUSTOM, NL_CB_VALID, NL_OK, nl_cb_clone, nl_cb_set, NL_CB_ACK, NL_CB_INVALID, NL_CB_MSG_IN

NET_DM_GRP_ALERT = 1
NET_DM_CMD_START = 3
NET_DM_CMD_STOP = 4

NET_DM_ATTR_UNSPEC = 0
NET_DM_ATTR_ALERT_MODE = 1
NET_DM_ATTR_PC = 2
NET_DM_ATTR_SYMBOL = 3
NET_DM_ATTR_IN_PORT = 4
NET_DM_ATTR_TIMESTAMP = 5
NET_DM_ATTR_PROTO = 6
NET_DM_ATTR_PAYLOAD = 7
NET_DM_ATTR_PAD = 8
NET_DM_ATTR_TRUNC_LEN = 9
NET_DM_ATTR_ORIG_LEN = 10
NET_DM_ATTR_QUEUE_LEN = 11
NET_DM_ATTR_STATS = 12
NET_DM_ATTR_HW_STATS = 13
NET_DM_ATTR_ORIGIN = 14
NET_DM_ATTR_HW_TRAP_GROUP_NAME = 15
NET_DM_ATTR_HW_TRAP_NAME = 16
NET_DM_ATTR_HW_ENTRIES = 17
NET_DM_ATTR_HW_ENTRY = 18
NET_DM_ATTR_HW_TRAP_COUNT = 19
NET_DM_ATTR_SW_DROPS = 20
NET_DM_ATTR_HW_DROPS = 21
NET_DM_ATTR_FLOW_ACTION_COOKIE = 22
NET_DM_ATTR_MAX = NET_DM_ATTR_FLOW_ACTION_COOKIE

net_dm_policy = {
    NET_DM_ATTR_UNSPEC: nla_policy(type_=NLA_UNSPEC),
    NET_DM_ATTR_ALERT_MODE: nla_policy(type_=NLA_U8),
    NET_DM_ATTR_PC: nla_policy(type_=NLA_U64),
    NET_DM_ATTR_SYMBOL: nla_policy(type_=NLA_STRING),
    NET_DM_ATTR_IN_PORT: nla_policy(type_=NLA_NESTED),
    NET_DM_ATTR_TIMESTAMP: nla_policy(type_=NLA_U64),
    NET_DM_ATTR_PROTO: nla_policy(type_=NLA_U16),
    NET_DM_ATTR_PAYLOAD: nla_policy(type_=NLA_UNSPEC),
    NET_DM_ATTR_TRUNC_LEN: nla_policy(type_=NLA_U32),
    NET_DM_ATTR_ORIG_LEN: nla_policy(type_=NLA_U32),
    NET_DM_ATTR_QUEUE_LEN: nla_policy(type_=NLA_U32),
    NET_DM_ATTR_STATS: nla_policy(type_=NLA_NESTED),
    NET_DM_ATTR_HW_STATS: nla_policy(type_=NLA_NESTED),
    NET_DM_ATTR_ORIGIN: nla_policy(type_=NLA_U16),
    NET_DM_ATTR_HW_TRAP_GROUP_NAME: nla_policy(type_=NLA_STRING),
    NET_DM_ATTR_HW_TRAP_NAME: nla_policy(type_=NLA_STRING),
    NET_DM_ATTR_HW_ENTRIES: nla_policy(type_=NLA_NESTED),
    NET_DM_ATTR_HW_ENTRY: nla_policy(type_=NLA_NESTED),
    NET_DM_ATTR_HW_TRAP_COUNT: nla_policy(type_=NLA_U32),
}

started = False


def netdm_ack_cb(msg, _):
    return NL_OK


def netdm_invalid_cb(msg, _):
    return NL_OK


def netdm_valid_cb(msg, _):
    nlh = nlmsg_hdr(msg)
    tb = {}
    err = genlmsg_parse(nlh, 0, tb, NET_DM_ATTR_MAX, net_dm_policy)
    if err < 0:
        print("genlmsg_parse failed with error %d" % (err))
        return NL_OK

    if NET_DM_ATTR_HW_ENTRIES in tb:
        rem = c_int()
        for attr in nla_for_each_nested(tb[NET_DM_ATTR_HW_ENTRIES], rem):
            tb1 = {}
            err = nla_parse_nested(tb1, NET_DM_ATTR_MAX, attr, net_dm_policy)
            if err < 0:
                print("nla_parse_nested failed with error %d" % (err))
                return NL_OK
            if NET_DM_ATTR_HW_TRAP_NAME not in tb1 or NET_DM_ATTR_HW_TRAP_COUNT not in tb1:
                continue

            print("%d drops at %s [hardware]" % (nla_get_u32(tb1[NET_DM_ATTR_HW_TRAP_COUNT]), nla_get_string(tb1[NET_DM_ATTR_HW_TRAP_NAME])))

    return NL_OK


def signal_handler(sig, frame):
    global started
    print("Exiting...")
    if started:
        start_stop_drop_monitor(sd, cb, family, False)
        started = False
    sys.exit(0)


def create_netlink_socket():
    sd = nl_socket_alloc()
    genl_connect(sd)
    family = genl_ctrl_resolve(sd, "NET_DM")
    if family < 0:
        raise RuntimeError('genl_ctrl_resolve() returned {0} ({1})'.format(family, errmsg[abs(family)]))
    nl_socket_free(sd)

    sd = nl_socket_alloc()
    nl_connect(sd, NETLINK_GENERIC)
    nl_socket_add_membership(sd, NET_DM_GRP_ALERT)
    return sd, family


def create_callback(sd):
    orig = nl_socket_get_cb(sd)
    cb = nl_cb_clone(orig)
    nl_cb_set(cb, NL_CB_ACK, NL_CB_CUSTOM, netdm_ack_cb, None)
    nl_cb_set(cb, NL_CB_VALID, NL_CB_CUSTOM, netdm_valid_cb, None)
    nl_cb_set(cb, NL_CB_INVALID, NL_CB_CUSTOM, netdm_invalid_cb, None)
    return cb


def start_stop_drop_monitor(sd, cb, family, is_start):
    if is_start:
        cmd = NET_DM_CMD_START
    else:
        cmd = NET_DM_CMD_STOP
    msg = nlmsg_alloc()
    genlmsg_put(msg, 0, NL_AUTO_SEQ, family, 0, NLM_F_REQUEST | NLM_F_ACK, cmd, 1)
    nla_put_flag(msg, NET_DM_ATTR_HW_DROPS)

    ret = nl_send_auto(sd, msg)
    if ret < 0:
        raise RuntimeError('nl_send_auto() returned {0} ({1})'.format(ret, errmsg[abs(ret)]))

    ret = nl_recvmsgs(sd, cb)
    if ret < 0:
        raise RuntimeError('nl_recvmsgs() returned {0} ({1})'.format(ret, errmsg[abs(ret)]))


if __name__ == "__main__":
    sd, family = create_netlink_socket()
    cb = create_callback(sd)
    signal.signal(signal.SIGINT, signal_handler)

    start_stop_drop_monitor(sd, cb, family, True)
    started = True
    try:
        while True:
            ret = nl_recvmsgs(sd, cb)
            if ret < 0:
                raise RuntimeError('nl_recvmsgs() returned {0} ({1})'.format(ret, errmsg[abs(ret)]))
    except BaseException:
        if started:
            start_stop_drop_monitor(sd, cb, family, False)
            started = False
        raise
