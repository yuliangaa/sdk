--/*
-- * Copyright © 2019-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
-- *
-- * This software product is a proprietary product of Nvidia Corporation and its affiliates
-- * (the "Company") and all right, title, and interest in and to the software product,
-- * including all associated intellectual property rights, are and shall
-- * remain exclusively with the Company.
-- *
-- * This software product is governed by the End User License Agreement
-- * provided with the software product.
-- *
-- */

--[[
 <<Release log>>
-->Parser Version v1.0

 For back-compatibility, in first parser, called 0.x, only support 5 fields.
 As a result, will combine all new fields as second-level fields in one first-level field, 
 which previous owned by Size(removed).
 
 General introduction,
 <> first-level fields - sPort, dPort, drop_group, drop_reason
 <> second-level fields - severity, proposed_action
 <> {{second_token, second_len, {TLV1, TLV2, ...}}, sPort_TLV, dPort_TLV, drop_group_TLV, drop_reason_TLV}
 <> version format in *.xy, only 2 numbers after decimal point
 
 Limitation
 <>  For future extension, second_len field should be enlarged to 2B or more, however, for back-com
     to first parser, called 0.x, only 1B could be reserved, that is only 255B for all second-level fields.
     When first parser is obsolete, DO enlarge this field.
--]]

--NVIDIA WJH protocol
local wjh_meta_data = {
    WJH_META_DATA_SOURCE_PORT = 1,
    WJH_META_DATA_DEST_PORT = 2,
    WJH_META_DATA_ORIG_PACKET_SIZE = 3,
    WJH_META_DATA_DROP_GROUP = 4,
    WJH_META_DATA_DROP_REASON = 5,
    WJH_META_DATA_SECOND_LEVEL_TOKEN = 6,
    WJH_META_DATA_SECOND_LEVEL_VERSION = 7,
    WJH_META_DATA_SECOND_LEVEL_SEVERITY = 8,
    WJH_META_DATA_SECOND_LEVEL_PROPOSED_ACTION = 9,
    WJH_META_DATA_MIN = 1,
    WJH_META_DATA_LEGACY_MAX = 5,
    WJH_META_DATA_MAX_V_1_0 = 9
}

local function define_and_register_nvidia_wjh()
local proto_obj_wjh = Proto('NVIDIA_WJH', 'NVIDIA WJH protocol')

	
local f_sport = ProtoField.stringz("wjh.src_port", "Source port")
local f_dport = ProtoField.stringz("wjh.dst_port", "Destination port")
local f_orig_pkt_size = ProtoField.stringz("wjh.orig_pkt_size", "Original packet size")
local f_drop_group = ProtoField.stringz("wjh.drop_group", "Drop group")
local f_drop_reason = ProtoField.stringz("wjh.drop_reason", "Drop reason")
local f_severity = ProtoField.stringz("wjh.severity", "Severity")
local f_proposed_action = ProtoField.stringz("wjh.proposed_action", "Proposed Action")
local f_ctrl_field = ProtoField.stringz("wjh.ctrl_field", "Ctrl field, not present")

-- map to wjh_meta_data, 1:1
local wjh_proto_fields = {
	f_sport,
	f_dport,
	f_orig_pkt_size,
	f_drop_group,
	f_drop_reason,
	f_ctrl_field,  -- second_level_token
	f_ctrl_field,  -- second_level_version
	f_severity,
	f_proposed_action
}

local cur_fields = { f_sport, f_dport, f_orig_pkt_size, f_drop_group, f_drop_reason, f_severity, f_proposed_action }

function get_tlv (buffer, index_location)
	field_type = buffer(index_location, 1):uint()
	index_location = index_location + 1
	field_len = buffer(index_location, 1):uint()
	index_location = index_location + 1
	field_val = string.format('%s',buffer(index_location, field_len):string())
    return field_type, field_len, field_val
end

	proto_obj_wjh.fields = cur_fields
	
	function proto_obj_wjh.dissector(buffer, pinfo, tree)
		length = buffer:len()
		if length == 0 then return end
		local index_location = 10
		local field_id = 0
		local num_of_fields = 0
		local i = 0
		wjh_header = buffer(0,index_location):string()
		
		if(wjh_header == "NVIDIA WJH") then
			pinfo.cols.protocol = proto_obj_wjh.name
			-- Check version
			pcap_tokened = buffer(index_location, 1):uint()
			
			-- Legacy version
			if(pcap_tokened ~= wjh_meta_data.WJH_META_DATA_SECOND_LEVEL_TOKEN) then
				local subtree = tree:add(proto_obj_wjh, buffer(), wjh_header)
				num_of_fields = wjh_meta_data.WJH_META_DATA_LEGACY_MAX
			
				for i = 1, num_of_fields, 1 do
					field_id, field_len, field_val = get_tlv(buffer, index_location)
					index_location = index_location + field_len + 2
					if(field_id <= num_of_fields) then
						subtree:add(wjh_proto_fields[field_id], field_val)
					end
				end
			end
			
			if(pcap_tokened == wjh_meta_data.WJH_META_DATA_SECOND_LEVEL_TOKEN) then
				index_location = index_location + 1
				second_field_len = buffer(index_location, 1):uint()
				index_location = index_location + 1
				
			    -- get ver_num_major
				field_id, field_len, ver_num_str = get_tlv(buffer, index_location)
				index_location = index_location + 2 + field_len
				
				ver_num = tonumber(ver_num_str) * 100; -- version format in *.xy, only 2 numbers after decimal point
				-- v1.0 parser
				if(ver_num >= 100) then
					local subtree = tree:add(proto_obj_wjh, buffer(), wjh_header)

					-- for present sequence, {sPort, dPort, drop_reason, severity, drop_reason, prop_action}
					severity_val = nil
					proposed_action_val = nil
					
					second_field_len_left = second_field_len - field_len - 2
					while(second_field_len_left > 0)
					do
						field_id, field_len, field_val = get_tlv(buffer, index_location)
						index_location = index_location + field_len + 2
						second_field_len_left = second_field_len_left - field_len - 2
						if(field_id <= wjh_meta_data.WJH_META_DATA_MAX_V_1_0) then
							if(field_id == wjh_meta_data.WJH_META_DATA_SECOND_LEVEL_SEVERITY) then
								severity_val = field_val
							elseif(field_id == wjh_meta_data.WJH_META_DATA_SECOND_LEVEL_PROPOSED_ACTION) then
								proposed_action_val = field_val
							else
								subtree:add(wjh_proto_fields[field_id], field_val)
							end
						end						
					end
					
					num_of_fields = wjh_meta_data.WJH_META_DATA_LEGACY_MAX - 1
					for i = 1, num_of_fields, 1 do
						field_id, field_len, field_val = get_tlv(buffer, index_location)
						index_location = index_location + field_len + 2
						
						if(field_id <= wjh_meta_data.WJH_META_DATA_MAX_V_1_0) then
							subtree:add(wjh_proto_fields[field_id], field_val)
							
							if(field_id == wjh_meta_data.WJH_META_DATA_DROP_GROUP) and severity_val ~= nil then
								subtree:add(wjh_proto_fields[wjh_meta_data.WJH_META_DATA_SECOND_LEVEL_SEVERITY], severity_val)
							end
							
							if(field_id == wjh_meta_data.WJH_META_DATA_DROP_REASON) and proposed_action_val ~= nil then
								subtree:add(wjh_proto_fields[wjh_meta_data.WJH_META_DATA_SECOND_LEVEL_PROPOSED_ACTION], proposed_action_val)
							end							
						end
					end
				end
			end
		end
		
		local wtap_encap_table = DissectorTable.get("wtap_encap")

		eth_dissector = wtap_encap_table:get_dissector(wtap["ETHERNET"])
		eth_dissector:call(buffer(index_location):tvb(),pinfo, tree)
	end

	local wtap_encap_table = DissectorTable.get("wtap_encap")
	wtap_encap_table:add(wtap.USER15, proto_obj_wjh)
end

define_and_register_nvidia_wjh()
	
--NVIDIA SPAN v1 protocol

local mlnx_span = Proto.new("MSPAN", "NVIDIA SPAN Mirror Header")
local MLNX_SPAN_ETHER_TYPE = 0x8949

mlnx_span.fields = {}
local fds = mlnx_span.fields
fds.ingress_label_port = ProtoField.new("Label Port", "mlnx_span.label_port", ftypes.UINT16, nil, base.DEC,"0xFFF0")
fds.ingress_label_port_split = ProtoField.new("Label Port Split", "mlnx_span.label_port_split", ftypes.UINT8, nil, base.DEC,"0x0F")
fds.has_timestamp = ProtoField.new("Has Timestamp", "mlnx_span.has_timestamp", ftypes.UINT8, {[1]="Yes",[0]="No"}, base.DEC, "0x80")
fds.timestamp = ProtoField.absolute_time("mlnx_span.timestamp", "Timestamp", base.UTC)


function mlnx_span.dissector(tvbuf, pktinfo, root)

	-- Dissector.get('eth_withoutfcs'):call(tvbuf(12):tvb(), pktinfo, root)

	local tree = root:add(mlnx_span, tvbuf:range(0, 14))	
	tree:add(fds.ingress_label_port, tvbuf(0, 2))
	tree:add(fds.ingress_label_port_split, tvbuf(1, 1))
	tree:add(fds.has_timestamp, tvbuf(4, 1))
	-- tree:add(fds.timestamp, tvbuf(6, 8))
	local usecs = tvbuf(6,8):uint64()
	local secs = (usecs / (2^30)):tonumber()
	local  nsecs = (usecs % (2^30)):tonumber()
	local nstime = NSTime.new(secs, nsecs)
	tree:add(fds.timestamp, tvbuf(6,8), nstime)
	
	return Dissector.get('eth_withoutfcs'):call(tvbuf(14):tvb(), pktinfo, root)
	
end

DissectorTable.get("ethertype"):add(MLNX_SPAN_ETHER_TYPE, mlnx_span)

