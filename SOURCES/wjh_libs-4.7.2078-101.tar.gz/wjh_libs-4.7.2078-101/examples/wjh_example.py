#!/usr/bin/env python
'''
This file contains Python front end for "What just happened" lib feature and does the following with respective options
1. Enable WJH example backend with agent mode or manual mode.
2. Disable WJH example backend.
3. Enable drop reason group.
4. Disable drop reason group.
5. Fetch the dropped packets and print to console.
6. Fetch the dropped packets and save to pcap file or txt file for aggregation channel.

For default manual mode, wjh_example.py will exit after each command, and the basic flow could be
wjh_example.py --enable                            # enable the wjh_example_backend to start capture the dropped packets
wjh_example.py --disable_drop_reason_group=l1      # disable l1 drop reason group for example
wjh_example.py --print                             # print the captured the dropped packets to console
wjh_example.py --save                              # save the captured the dropped packets to file /tmp/wjh_raw.pcap or /tmp/wjh_agg.txt
wjh_example.py --disable                           # disable the wjh_example_backend to stop capture

For agent mode, wjh_example.py will not exit and wait for traffic, the flow could be
wjh_example.py --mode=agent --print                # enable the wjh_example_backend and wait for the dropped packets and print to console
OR
wjh_example.py --mode=agent --save                 # enable the wjh_example_backend and wait for the dropped packets and save to file
'''

import argparse
import subprocess
import socket
import time
import os
import sys
import signal
import pickle
from test_infra_common import *

######################################################
#    defines
######################################################
WJH_BACKEND_SCRIPT = 'wjh_example_backend.py'
WJH_DIR_SLASH = '/'
WJH_MONITOR_SERVER_PORT = 20000
WJH_TOOL_BUF_SIZE = 1024
WJH_SOCKET_TIMEOUT = 20
WJH_SERVER_UPTIME_WAIT_PERIOD = 20

# API to send/receive message to/from WJH example backend


def wait_for_port(port, host, timeout):
    """Wait until a port starts accepting TCP connections.
    Args:
        port (int): Port number.
        host (str): Host address on which the port should exist.
        timeout (float): In seconds. How long to wait before raising errors.
    Raises:
        TimeoutError: The port isn't accepting connection after time specified in `timeout`.
    """
    until = time.time() + timeout
    while True:
        try:
            sock = socket.create_connection((host, port), timeout=WJH_SOCKET_TIMEOUT)
            return sock
        except Exception:
            time.sleep(0.1)
            if time.time() > until:
                raise TimeoutError('Waited too long for the port {} on host {} to start accepting '
                                   'connections.'.format(port, host))


def wjh_client_send(buf, timeout=2):
    data = None
    sock = None
    try:
        sock = wait_for_port(port=WJH_MONITOR_SERVER_PORT, host='localhost', timeout=timeout)
        sock.sendall(buf)
        data = sock.recv(WJH_TOOL_BUF_SIZE)
    except Exception:
        print("use --enable to enable the WJH example backend.")
    finally:
        if sock is not None:
            sock.close()
        return data


def wjh_action_enable(cmd):
    path = os.path.dirname(sys.argv[0])
    python_version = sys.version_info.major
    subprocess.Popen(["python{}".format(python_version), path + WJH_DIR_SLASH + WJH_BACKEND_SCRIPT])
    data = wjh_client_send(cmd, timeout=WJH_SERVER_UPTIME_WAIT_PERIOD)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to enable the WJH example backend - please try again")


def wjh_action_save(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to save the packets - please enable the WJH example")


def wjh_action_enable_group(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to enable the drop reason group - please enable the WJH example")


def wjh_action_disable_group(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to disable the drop reason group - please enable the WJH example")


def wjh_action_print(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to save the packets - please enable the WJH example")


def wjh_action_disable(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to disable the WJH example backend - please check status and try again")


def wjh_action_tac(cmd, args):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        if args.tac_dst_ip:
            print("Failed to set tac destination ip - please enable the WJH example")
        elif args.tac_src_ip:
            print("Failed to set tac source ip - please enable the WJH example")
        elif args.tac_dmac:
            print("Failed to set tac destination ip - please enable the WJH example")
        elif args.tac_vlan:
            print("Failed to set tac vlan - please enable the WJH example")
        elif args.tac_analyzer_port:
            print("Failed to set tac analyzer port - please enable the WJH example")


def bandwidth_type(x):
    x = int(x)
    if x < 0 or x > 100:
        raise argparse.ArgumentTypeError("Bandwidth is 0 - 100")
    return x


def handler(signum, frame):
    print('Ctrl+C pressed, exit...')
    sys.exit(0)


def wjh_action_bind_to_aggregation_channel(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to bind the drop reason group to aggregation channel - please enable the WJH example")


def wjh_action_bind_to_cyclic_channel(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to bind the drop reason group to cyclic channel - please enable the WJH example")


def wjh_action_bind_to_cyclic_and_aggregation_channel(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to bind the drop reason group to cyclic-and-aggregation channel - please enable the WJH example")


def wjh_action_set_aggregation_channel_aggregation_read_mode(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to set the aggregation read mode of aggregation channel - please enable the WJH example")


def wjh_action_set_cyclic_and_aggregation_channel_aggregation_read_mode(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to set the aggregation read mode of cyclic-and-aggregation channel - please enable the WJH example")


def wjh_action_set_channel_timestamp_source(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to set the user channel timestamp source - please enable the WJH example")


def wjh_action_set_channel_destination(cmd):
    data = wjh_client_send(cmd)
    if data:
        print(('%s' % data.decode()))
    else:
        print("Failed to set the user channel destination - please enable the WJH example")


parser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter,
                                 description='''WJH lib example front end does the following with respective options
1. Enable WJH example backend with agent mode or manual mode.
2. Disable WJH example backend.
3. Enable drop reason group.
4. Disable drop reason group.
5. Fetch the dropped packets and print to console.
6. Fetch the dropped packets and save to pcap file or txt file for aggregation channel.

For default manual mode, wjh_example.py will exit after each command, and the basic flow could be
wjh_example.py --enable                            # Enable the wjh_example_backend to start capture the dropped packets.
                                                     By default, all drop reason groups will be initialized and enabled,
                                                     all types of channels will be created, and all drop reason groups will be
                                                     bound to the cyclic channel.
wjh_example.py --disable_drop_reason_group=l1      # disable l1 drop reason group for example
wjh_example.py --print                             # print the captured the dropped packets to console
wjh_example.py --save                              # save the captured the dropped packets to file /tmp/wjh_raw.pcap or /tmp/wjh_agg.txt
wjh_example.py --disable                           # disable the wjh_example_backend to stop capture

For agent mode, wjh_example.py will not exit and wait for traffic, the flow could be
wjh_example.py --enable --mode=agent --print                # enable the wjh_example_backend and wait for the dropped packets and print to console
OR
wjh_example.py --enable --mode=agent --save                 # enable the wjh_example_backend and wait for the dropped packets and save to file''')

# Deinit/Force Shouldn't be used by user, equivalent to disable / enable. Used for internal testing. So help supressed
parser.add_argument('--deinit', action='store_true', help=argparse.SUPPRESS)
parser.add_argument('--force', action='store_true', help=argparse.SUPPRESS)

parser.add_argument('--disable', action='store_true', help='disables the WJH example backend')
parser.add_argument('--enable', action='store_true', help='enables the WJH example backend')
parser.add_argument('--trap_group_mode', default='auto', choices=['static', 'dynamic', 'auto'], help='set WJH trap group allocation mode for enable action')
parser.add_argument('--bandwidth', default=0, type=bandwidth_type, help='set pcie bandwidth percentage for WJH for enable option')
parser.add_argument('--mode', default='manual', choices=['agent', 'manual'], help='set WJH mode for enable option')
parser.add_argument('--aggregation_key_mode', default='streaming', choices=['streaming', 'detailed'], help='set WJH aggregation key mode for enable action')
parser.add_argument('--recirculation_port', default=0x10001, type=auto_int, help='''set buffer drop recirculation port for enable action,
                                                                                    0x0 or 0x40010000 represents CPU port, other value represents network port''')
parser.add_argument('--print', action='store_true', help='prints the WJH captured packets, can be used solely or along with --enable')
parser.add_argument('--save', action='store_true', help='saves the WJH captured packets, can be used solely or along with --enable')
parser.add_argument('--raw_file', help='the optional file full path of the WJH raw packets, can only be used along with --save')
parser.add_argument('--agg_file', help='the optional file full path of the WJH aggregation info, can only be used along with --save')

parser.add_argument('--tac_dst_ip', help='dst ip for the tac span session')
parser.add_argument('--tac_src_ip', help='src ip for the tac span session')
parser.add_argument('--tac_vlan', help='vlan for the tac span session')
parser.add_argument('--tac_dmac', help='destination MAC for the tac span session')
parser.add_argument('--tac_analyzer_port', help='analyzer_port for the tac span session')
parser.add_argument('--bind_to_tac_channel',
                    choices=['all', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                    help='bind drop reason group to tac channel')
parser.add_argument('--enable_drop_reason_group',
                    choices=['all', 'l1', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                    help='enable drop reason group, can only be used solely')
parser.add_argument('--disable_drop_reason_group',
                    choices=['all', 'l1', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                    help='disable drop reason group, can only be used solely')
parser.add_argument('--severity', default='all',
                    choices=['all', 'notice', 'warning', 'error'],
                    help='drop reason severity for drop reason group disable/enable')
parser.add_argument('--bind_to_aggregation_channel',
                    choices=['all', 'l1', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                    help='bind drop reason group to aggregation channel, can be used solely or along with --enable')
parser.add_argument('--bind_to_cyclic_channel',
                    choices=['all', 'l1', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                    help='bind drop reason group to cyclic channel, can only be used solely')
parser.add_argument('--bind_to_cyclic_and_aggregation_channel',
                    choices=['all', 'l1', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                    help='bind drop reason group to cyclic-and-aggregation channel, can be used solely or along with --enable')
parser.add_argument('--set_aggregation_channel_aggregation_read_mode',
                    choices=['read_clear', 'read'],
                    help='set the aggregation read mode of the aggregation channel, can be used solely or along with --enable')
parser.add_argument('--set_cyclic_and_aggregation_channel_aggregation_read_mode',
                    choices=['read_clear', 'read'],
                    help='set the aggregation read mode of the cyclic-and-aggregation channel, can be used solely or along with --enable')
parser.add_argument('--set_channel_timestamp_source',
                    choices=['linux', 'hw_clock'],
                    help='set the channel timestamp source, can be used solely or along with --enable')
parser.add_argument('--set_channel_destination',
                    choices=['callback_and_drop_monitor', 'drop_monitor'],
                    help='set the channel destination, can be used solely or along with --enable')

args = parser.parse_args()
cmd = pickle.dumps(sys.argv[1:])
if args.force and args.deinit:
    cmd = pickle.dumps(['--enable'])
    wjh_action_enable(cmd)
    cmd = pickle.dumps(['--disable'])
    wjh_action_disable(cmd)
elif args.enable or args.force:
    wjh_action_enable(cmd)
    if args.mode == 'agent':
        signal.signal(signal.SIGINT, handler)
        input("Press the Enter key to disable WJH example backend.")
        cmd = pickle.dumps(['--disable'])
        wjh_action_disable(cmd)
elif args.disable or args.deinit:
    wjh_action_disable(cmd)
elif args.save:
    wjh_action_save(cmd)
elif vars(args)['print']:
    wjh_action_print(cmd)
elif args.tac_dst_ip:
    wjh_action_tac(cmd, args)
elif args.tac_src_ip:
    wjh_action_tac(cmd, args)
elif args.tac_vlan:
    wjh_action_tac(cmd, args)
elif args.tac_dmac:
    wjh_action_tac(cmd, args)
elif args.tac_analyzer_port:
    wjh_action_tac(cmd, args)
elif args.bind_to_tac_channel:
    wjh_action_tac(cmd, args)
elif args.enable_drop_reason_group:
    wjh_action_enable_group(cmd)
elif args.disable_drop_reason_group:
    wjh_action_disable_group(cmd)
elif args.bind_to_aggregation_channel:
    wjh_action_bind_to_aggregation_channel(cmd)
elif args.bind_to_cyclic_channel:
    wjh_action_bind_to_cyclic_channel(cmd)
elif args.bind_to_cyclic_and_aggregation_channel:
    wjh_action_bind_to_cyclic_and_aggregation_channel(cmd)
elif args.set_aggregation_channel_aggregation_read_mode:
    wjh_action_set_aggregation_channel_aggregation_read_mode(cmd)
elif args.set_cyclic_and_aggregation_channel_aggregation_read_mode:
    wjh_action_set_cyclic_and_aggregation_channel_aggregation_read_mode(cmd)
elif args.set_channel_timestamp_source:
    wjh_action_set_channel_timestamp_source(cmd)
elif args.set_channel_destination:
    wjh_action_set_channel_destination(cmd)
else:
    print("usage: wjh_example.py [-h|--help] [--enable] [--disable] [--print] [--save] [--trap_group_mode] [--enable_drop_reason_group] [--disable_drop_reason_group] [--severity] [--bind_to_aggregation_channel] [--bind_to_cyclic_channel] [--bind_to_cyclic_and_aggregation_channel] [--bind_to_tac_channel] [--tac_src_ip] [--tac_dst_ip] [--tac_dmac] [--tac_vlan] [--tac_analyzer_port]")
