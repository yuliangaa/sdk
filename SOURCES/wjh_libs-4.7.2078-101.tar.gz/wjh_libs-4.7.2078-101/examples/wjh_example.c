/*
 * Copyright © 2019-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <string.h>
#include <unistd.h>
#include <inttypes.h>
#include <stdlib.h>
#include "wjh/wjh_lib.h"
#include <sx/sdk/sx_api_cos.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_api_port.h>
#include <sx/sdk/sx_strings.h>
#include <signal.h>

#define WJH_CONGESTION_MULTIPLIER (8)
#define WJH_LATENCY_MULTIPLIER    (64)

#define ING_POOL_ID      0
#define EGR_POOL_ID      11
#define ING_DESC_POOL_ID 21
#define EGR_DESC_POOL_ID 30

#define INGR_EGR_POOL_SIZE ((128 * 1000) / 96)
#define POOL_DESC_CELLS    128

#define SX_COS_ING_PG_0_E  0
#define SX_COS_ING_PG_1_E  1
#define SX_COS_ING_PG_7_E  7
#define SX_COS_EGR_TC_0_E  0
#define SX_COS_EGR_TC_1_E  1
#define SX_COS_EGR_TC_15_E 15

#define WJH_BUFFER_DROP_RECYCLE_PORT 0x10001

#define FILTER_DROP_REASON WJH_DROP_REASON_ID_TAIL_DROP_E

static sx_cos_port_buffer_attr_t        port_def_pg_buffer[SX_COS_ING_PG_7_E + 1];
static sx_cos_port_buffer_attr_t        port_def_pg_desc_buffer[SX_COS_ING_PG_7_E + 1];
static sx_cos_port_buffer_attr_t        port_def_tc_buffer[SX_COS_EGR_TC_15_E + 1];
static sx_cos_port_buffer_attr_t        port_def_tc_desc_buffer[SX_COS_EGR_TC_15_E + 1];
static sx_cos_port_buffer_attr_t        port_def_ing_port_buffer;
static sx_cos_port_buffer_attr_t        port_def_egr_port_buffer;
static sx_cos_port_buffer_attr_t        port_def_ing_port_desc_buffer;
static sx_cos_port_buffer_attr_t        port_def_egr_port_desc_buffer;
static sx_cos_port_shared_buffer_attr_t port_def_pg_shared_buffer[SX_COS_ING_PG_7_E + 1];
static sx_cos_port_shared_buffer_attr_t port_def_pg_desc_shared_buffer[SX_COS_ING_PG_7_E + 1];
static sx_cos_port_shared_buffer_attr_t port_def_tc_shared_buffer[SX_COS_EGR_TC_15_E + 1];
static sx_cos_port_shared_buffer_attr_t port_def_tc_desc_shared_buffer[SX_COS_EGR_TC_15_E + 1];
static sx_cos_port_shared_buffer_attr_t port_def_ing_port_shared_buffer;
static sx_cos_port_shared_buffer_attr_t port_def_egr_port_shared_buffer;
static sx_cos_port_shared_buffer_attr_t port_def_ing_port_desc_shared_buffer;
static sx_cos_port_shared_buffer_attr_t port_def_egr_port_desc_shared_buffer;
static sx_cos_port_prio_buff_t          port_prio_def_pg_buff_map;
static uint8_t                          port_prio_def_tc_buff_map[RM_API_COS_PORT_PRIO_MAX + 1];
static sx_api_handle_t                  handle = 0;
static const char                      *event_type_2str[WJH_EVENT_MAX_E + 1] = {
    [WJH_EVENT_NONE_E] = "None",
    [WJH_EVENT_PACKET_DROP_E] = "Packet drop",
    [WJH_EVENT_EXCEPTION_E] = "Exception"
};
static const char* get_event_type_str(wjh_event_type_e event_type)
{
    return (event_type >= WJH_EVENT_MIN_E && event_type <= WJH_EVENT_MAX_E) ? event_type_2str[event_type] : "Unknown";
}

static void force_deinit_notify(void)
{
    printf("The current instance has been force deactivated by another instance.\n");
}

wjh_status_t dump_raw_packet(void *packet, uint32_t packet_size)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;
    uint8_t     *bytes = (uint8_t*)packet;

    for (i = 0; i < packet_size; i++) {
        if (i % 16 == 0) {
            printf("\n");
        }
        printf("%02x ", bytes[i]);
    }
    printf("\n");

    return status;
}

wjh_status_t L2_drop_raw_cb(wjh_L2_drop_raw_info_t *raw_info_list_p, uint32_t               *raw_info_list_size_p)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    for (i = 0; i < *raw_info_list_size_p; i++) {
        printf(
            "l2 drop packet: ingress port [0x%x], size[%d], reason[%s], reason_id[%u], description[%s], event_type[%s], timestamp[%ld.%ld].\n",
            raw_info_list_p[i].ingress_port,
            raw_info_list_p[i].packet_size,
            raw_info_list_p[i].drop_reason.reason,
            raw_info_list_p[i].drop_reason.id,
            raw_info_list_p[i].drop_reason.description,
            get_event_type_str(raw_info_list_p[i].drop_reason.event_type),
            raw_info_list_p[i].timestamp.tv_sec,
            raw_info_list_p[i].timestamp.tv_nsec);
        dump_raw_packet(raw_info_list_p[i].packet, raw_info_list_p[i].packet_size);
    }

    fflush(stdout);
    return status;
}

wjh_status_t router_drop_raw_cb(wjh_router_drop_raw_info_t *raw_info_list_p,
                                uint32_t                   *raw_info_list_size_p)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    for (i = 0; i < *raw_info_list_size_p; i++) {
        printf(
            "router drop packet: ingress port [0x%x], size[%d], reason[%s], reason_id[%u], description[%s], event_type[%s], timestamp[%ld.%ld].\n",
            raw_info_list_p[i].ingress_port,
            raw_info_list_p[i].packet_size,
            raw_info_list_p[i].drop_reason.reason,
            raw_info_list_p[i].drop_reason.id,
            raw_info_list_p[i].drop_reason.description,
            get_event_type_str(raw_info_list_p[i].drop_reason.event_type),
            raw_info_list_p[i].timestamp.tv_sec,
            raw_info_list_p[i].timestamp.tv_nsec);
        dump_raw_packet(raw_info_list_p[i].packet, raw_info_list_p[i].packet_size);
    }

    fflush(stdout);
    return status;
}

wjh_status_t tunnel_drop_raw_cb(wjh_tunnel_drop_raw_info_t *raw_info_list_p,
                                uint32_t                   *raw_info_list_size_p)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    for (i = 0; i < *raw_info_list_size_p; i++) {
        printf(
            "tunnel drop packet: ingress port [0x%x], size[%d], reason[%s], reason_id[%u], description[%s], event_type[%s], timestamp[%ld.%ld].\n",
            raw_info_list_p[i].ingress_port,
            raw_info_list_p[i].packet_size,
            raw_info_list_p[i].drop_reason.reason,
            raw_info_list_p[i].drop_reason.id,
            raw_info_list_p[i].drop_reason.description,
            get_event_type_str(raw_info_list_p[i].drop_reason.event_type),
            raw_info_list_p[i].timestamp.tv_sec,
            raw_info_list_p[i].timestamp.tv_nsec);
        dump_raw_packet(raw_info_list_p[i].packet, raw_info_list_p[i].packet_size);
    }

    fflush(stdout);
    return status;
}

wjh_status_t acl_drop_raw_cb(wjh_acl_drop_raw_info_t *raw_info_list_p, uint32_t *raw_info_list_size_p)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    for (i = 0; i < *raw_info_list_size_p; i++) {
        printf(
            "acl drop packet: ingress port [0x%x], size[%d], rule_id[0x%lx], binding_point[%d], acl_name[%s], rule {%s}, event_type[%s], timestamp[%ld.%ld].\n",
            raw_info_list_p[i].ingress_port,
            raw_info_list_p[i].packet_size,
            raw_info_list_p[i].rule_id,
            raw_info_list_p[i].binding_point,
            raw_info_list_p[i].acl_name,
            raw_info_list_p[i].rule,
            get_event_type_str(raw_info_list_p[i].drop_reason.event_type),
            raw_info_list_p[i].timestamp.tv_sec,
            raw_info_list_p[i].timestamp.tv_nsec);
        dump_raw_packet(raw_info_list_p[i].packet, raw_info_list_p[i].packet_size);
    }

    fflush(stdout);
    return status;
}

wjh_status_t buffer_drop_raw_cb(wjh_buffer_drop_raw_info_t *raw_info_list_p, uint32_t *raw_info_list_size_p)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    for (i = 0; i < *raw_info_list_size_p; i++) {
        printf(
            "buffer drop packet: ingress port [0x%x], size[%d], reason[%s], event_type[%s], timestamp[%ld.%ld], ",
            raw_info_list_p[i].ingress_port,
            raw_info_list_p[i].packet_size,
            raw_info_list_p[i].drop_reason.reason,
            get_event_type_str(raw_info_list_p[i].drop_reason.event_type),
            raw_info_list_p[i].timestamp.tv_sec,
            raw_info_list_p[i].timestamp.tv_nsec);

        if (raw_info_list_p[i].egress_port_valid) {
            printf("egress port [0x%x], ", raw_info_list_p[i].egress_port);
        }
        if (raw_info_list_p[i].original_occupancy != WJH_MIRROR_CONG_INVALID) {
            printf("Tclass Buffer Occupancy [%u] KB, ",
                   raw_info_list_p[i].original_occupancy * WJH_CONGESTION_MULTIPLIER);
        }
        if (raw_info_list_p[i].tc != WJH_MIRROR_TCLASS_INVALID) {
            printf("Egress Tclass [%u], ", raw_info_list_p[i].tc);
        }
        if (raw_info_list_p[i].original_latency != WJH_MIRROR_LATENCY_INVALID) {
            printf("Latency [%lu] nsec", (uint64_t)raw_info_list_p[i].original_latency * WJH_LATENCY_MULTIPLIER);
        }

        dump_raw_packet(raw_info_list_p[i].packet, raw_info_list_p[i].packet_size);
    }

    fflush(stdout);
    return status;
}

wjh_status_t roce_drop_raw_cb(wjh_roce_drop_raw_info_t *raw_info_list_p, uint32_t *raw_info_list_size_p)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    for (i = 0; i < *raw_info_list_size_p; i++) {
        printf(
            "roce packet: ingress port [0x%x], size[%d], switch_prio[%d], timestamp[%ld.%ld].\n" \
            "roce packet: reason[%s], reason_id[%u], description[%s], event_type[%s].\n",
            raw_info_list_p[i].ingress_port,
            raw_info_list_p[i].packet_size,
            raw_info_list_p[i].switch_prio,
            raw_info_list_p[i].timestamp.tv_sec,
            raw_info_list_p[i].timestamp.tv_nsec,
            raw_info_list_p[i].drop_reason.reason,
            raw_info_list_p[i].drop_reason.id,
            raw_info_list_p[i].drop_reason.description,
            get_event_type_str(raw_info_list_p[i].drop_reason.event_type));
        dump_raw_packet(raw_info_list_p[i].packet, raw_info_list_p[i].packet_size);
    }

    fflush(stdout);
    return status;
}

wjh_status_t L1_drop_aggregate_cb(wjh_L1_drop_aggregate_key_t  *key_list_p,
                                  wjh_L1_drop_aggregate_data_t *data_list_p,
                                  uint32_t                     *keys_cnt_p,
                                  wjh_drop_aggregate_attr_t    *attr_p)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    UNUSED_PARAM(attr_p);

    for (i = 0; i < *keys_cnt_p; ++i) {
        printf("port 0x%x: is_port_up: %u, port_down_reason: %s, description: %s, state_change_count: %" PRIu64 "\n",
               key_list_p[i].ingress_port, data_list_p[i].is_port_up, data_list_p[i].port_down_reason,
               data_list_p[i].description, data_list_p[i].state_change_count);
        printf("           symbol_error_count: %" PRIu64 ", crc_error_count: %" PRIu64 "\n",
               data_list_p[i].symbol_error_count, data_list_p[i].crc_error_count);
        if (data_list_p[i].state_change_count > 0) {
            printf("           port_state_change_reason: reason[%s], reason_id[%u], description[%s], event_type[%s]\n",
                   data_list_p[i].port_state_change_reason.reason, data_list_p[i].port_state_change_reason.id,
                   data_list_p[i].port_state_change_reason.description,
                   get_event_type_str(data_list_p[i].port_state_change_reason.event_type));
        }
        if (data_list_p[i].crc_error_count > 0) {
            printf("           crc_error_reason: reason[%s], reason_id[%u], description[%s], event_type[%s]\n",
                   data_list_p[i].crc_error_reason.reason, data_list_p[i].crc_error_reason.id,
                   data_list_p[i].crc_error_reason.description,
                   get_event_type_str(data_list_p[i].crc_error_reason.event_type));
        }
        if (data_list_p[i].symbol_error_count > 0) {
            printf("           symbol_error_reason: reason[%s], reason_id[%u], description[%s], event_type[%s]\n",
                   data_list_p[i].symbol_error_reason.reason, data_list_p[i].symbol_error_reason.id,
                   data_list_p[i].symbol_error_reason.description,
                   get_event_type_str(data_list_p[i].symbol_error_reason.event_type));
        }
        printf("           timestamp[%ld.%ld, %ld.%ld]\n", data_list_p[i].timestamp.first_timestamp.tv_sec,
               data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
               data_list_p[i].timestamp.last_timestamp.tv_nsec);
    }

    fflush(stdout);
    return status;
}

wjh_status_t buffer_drop_aggregate_cb(wjh_buffer_drop_aggregate_key_t  *key_list_p,
                                      wjh_buffer_drop_aggregate_data_t *data_list_p,
                                      uint32_t                         *keys_cnt_p,
                                      wjh_drop_aggregate_attr_t        *attr_p)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    UNUSED_PARAM(attr_p);

    for (i = 0; i < *keys_cnt_p; ++i) {
        if (!key_list_p[i].non_ip) {
            printf("sip [%s], dip [%s], proto [%u], sport [%u], dport [%u], reason [%s], event_type [%s]\n",
                   key_list_p[i].five_tuples.sip, key_list_p[i].five_tuples.dip, key_list_p[i].five_tuples.proto,
                   key_list_p[i].five_tuples.sport, key_list_p[i].five_tuples.dport, key_list_p[i].reason.reason,
                   get_event_type_str(key_list_p[i].reason.event_type));
        } else {
            printf("Non IP packet, reason [%s], event_type [%s]\n", key_list_p[i].reason.reason,
                   get_event_type_str(key_list_p[i].reason.event_type));
        }
        printf("     count [%" PRIu64 "], timestamp[%ld.%ld, %ld.%ld]\n",
               data_list_p[i].count,
               data_list_p[i].timestamp.first_timestamp.tv_sec,
               data_list_p[i].timestamp.first_timestamp.tv_nsec,
               data_list_p[i].timestamp.last_timestamp.tv_sec,
               data_list_p[i].timestamp.last_timestamp.tv_nsec);
        if (data_list_p[i].egress_data_valid) {
            printf("egress port [0x%x], ", data_list_p[i].egress_data.egress_port);
            if (data_list_p[i].egress_data.port_tc_watermark != WJH_MIRROR_CONG_INVALID) {
                printf("Port TC watermark [%u] KB, ",
                       data_list_p[i].egress_data.port_tc_watermark * WJH_CONGESTION_MULTIPLIER);
            }
            if (data_list_p[i].egress_data.tc != WJH_MIRROR_TCLASS_INVALID) {
                printf("Egress Tclass [%u], ", data_list_p[i].egress_data.tc);
            }
            if (data_list_p[i].egress_data.latency_watermark != WJH_MIRROR_LATENCY_INVALID) {
                printf("Latency watermark [%lu] nsec",
                       (uint64_t)data_list_p[i].egress_data.latency_watermark * WJH_LATENCY_MULTIPLIER);
            }
            printf("\n");
        }
    }

    fflush(stdout);
    return status;
}

wjh_status_t acl_drop_aggregate_cb(wjh_acl_drop_aggregate_key_t  *key_list_p,
                                   wjh_acl_drop_aggregate_data_t *data_list_p,
                                   uint32_t                      *keys_cnt_p,
                                   wjh_drop_aggregate_attr_t     *attr_p)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    UNUSED_PARAM(attr_p);

    for (i = 0; i < *keys_cnt_p; ++i) {
        if (!key_list_p[i].non_ip) {
            printf("sip [%s], dip [%s], proto [%u], sport [%u], dport [%u]\n",
                   key_list_p[i].five_tuples.sip, key_list_p[i].five_tuples.dip, key_list_p[i].five_tuples.proto,
                   key_list_p[i].five_tuples.sport, key_list_p[i].five_tuples.dport);
        } else {
            printf("Non IP packet\n");
        }
        printf("reason_id [%u], reason [%s], severity[%u], description[%s], event_type[%s]\n",
               key_list_p[i].reason.id,
               key_list_p[i].reason.reason,
               key_list_p[i].reason.severity,
               key_list_p[i].reason.description,
               get_event_type_str(key_list_p[i].reason.event_type));
        printf("rule_id [%" PRIu64 "], acl_name [%s], rule [%s]\n",
               key_list_p[i].rule_id, key_list_p[i].acl_name, key_list_p[i].rule);
        printf("     count [%" PRIu64 "], timestamp[%ld.%ld, %ld.%ld]\n",
               data_list_p[i].count,
               data_list_p[i].timestamp.first_timestamp.tv_sec,
               data_list_p[i].timestamp.first_timestamp.tv_nsec,
               data_list_p[i].timestamp.last_timestamp.tv_sec,
               data_list_p[i].timestamp.last_timestamp.tv_nsec);
    }

    fflush(stdout);
    return status;
}

wjh_status_t roce_drop_aggregate_cb(wjh_roce_drop_aggregate_key_t  *key_list_p,
                                    wjh_roce_drop_aggregate_data_t *data_list_p,
                                    uint32_t                       *keys_cnt_p,
                                    wjh_drop_aggregate_attr_t      *attr_p)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    UNUSED_PARAM(attr_p);

    for (i = 0; i < *keys_cnt_p; ++i) {
        if (!key_list_p[i].non_ip) {
            printf("sip [%s], dip [%s], proto [%u], sport [%u], dport [%u], reason [%s], event_type [%s]\n",
                   key_list_p[i].five_tuples.sip, key_list_p[i].five_tuples.dip, key_list_p[i].five_tuples.proto,
                   key_list_p[i].five_tuples.sport, key_list_p[i].five_tuples.dport, key_list_p[i].reason.reason,
                   get_event_type_str(key_list_p[i].reason.event_type));
        } else {
            printf("Non IP packet, event_type [%s]\n", get_event_type_str(key_list_p[i].reason.event_type));
        }
        printf("     count [%" PRIu64 "], timestamp[%ld.%ld, %ld.%ld]\n",
               data_list_p[i].count,
               data_list_p[i].timestamp.first_timestamp.tv_sec,
               data_list_p[i].timestamp.first_timestamp.tv_nsec,
               data_list_p[i].timestamp.last_timestamp.tv_sec,
               data_list_p[i].timestamp.last_timestamp.tv_nsec);
    }

    fflush(stdout);
    return status;
}

/* Deconfigure reserved buffers and reserved descriptors on per port basis */
int deconfigure_recirculation_port_reserved_buffer(wjh_port_log_id_t         log_port,
                                                   sx_cos_port_buffer_attr_t port_def_buffer[],
                                                   uint32_t                  size)
{
    int             ret = 0;
    sx_status_t     rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t cmd = SX_ACCESS_CMD_SET;

    rc = sx_api_cos_port_buff_type_set(handle, cmd, log_port, port_def_buffer, size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set cos port buffer error: %s\n",
               sx_status_str(rc));
        ret = -1;
    }


    return ret;
}

/* Deconfigure shared buffers and shared descriptors on per port basis */
int deconfigure_recirculation_port_shared_buffer(wjh_port_log_id_t                log_port,
                                                 sx_cos_port_shared_buffer_attr_t port_def_buffer[],
                                                 uint32_t                         size)
{
    int             ret = 0;
    sx_status_t     rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t cmd = SX_ACCESS_CMD_SET;

    rc = sx_api_cos_port_shared_buff_type_set(handle, cmd, log_port, port_def_buffer, size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set cos port buffer error: %s\n",
               sx_status_str(rc));
        ret = -1;
    }

    return ret;
}

/* Configure recirculation port pg shared  buffer and pg shared descriptors settings */
int configure_recirculation_port_pg_shared_buffer_desc(wjh_port_log_id_t                log_port,
                                                       sx_cos_port_buff_attr_type_e     type,
                                                       uint32_t                         pool_id,
                                                       buffer_units_t                   size,
                                                       sx_cos_buffer_max_mode_e         buf_mode,
                                                       sx_cos_port_buff_alpha_e         alpha,
                                                       sx_cos_port_shared_buffer_attr_t port_def_buffer[],
                                                       uint32_t                        *def_buf_list_size)
{
    int                              ret = 0;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    uint32_t                         pg_idx = SX_COS_ING_PG_0_E;
    sx_cos_port_shared_buffer_attr_t port_buffer_list[SX_COS_ING_PG_7_E + 1];
    uint32_t                         port_buffer_list_size = SX_COS_ING_PG_7_E + 1;
    sx_access_cmd_t                  cmd = SX_ACCESS_CMD_SET;

    /* Make all PG shared buffer sizes to be 0 except for PG(1)*/
    memset(&port_buffer_list, 0, sizeof(port_buffer_list));
    for (pg_idx = SX_COS_ING_PG_0_E; pg_idx <= SX_COS_ING_PG_7_E; pg_idx++) {
        port_buffer_list[pg_idx].type = type;
        port_buffer_list[pg_idx].attr.ingress_port_pg_shared_buff_attr.pool_id = pool_id;
        port_buffer_list[pg_idx].attr.ingress_port_pg_shared_buff_attr.pg = pg_idx;
        if (pg_idx == SX_COS_ING_PG_1_E) {
            port_buffer_list[pg_idx].attr.ingress_port_pg_shared_buff_attr.max.mode = buf_mode;
            if (buf_mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E) {
                port_buffer_list[pg_idx].attr.ingress_port_pg_shared_buff_attr.max.max.alpha = alpha;
            } else {
                port_buffer_list[pg_idx].attr.ingress_port_pg_shared_buff_attr.max.max.size = size;
            }
        } else {
            port_buffer_list[pg_idx].attr.ingress_port_pg_shared_buff_attr.max.mode = SX_COS_BUFFER_MAX_MODE_STATIC_E;
            port_buffer_list[pg_idx].attr.ingress_port_pg_shared_buff_attr.max.max.size = 0;
        }
        port_def_buffer[pg_idx].type = type;
        port_def_buffer[pg_idx].attr.ingress_port_pg_shared_buff_attr.pool_id = pool_id;
        port_def_buffer[pg_idx].attr.ingress_port_pg_shared_buff_attr.pg = pg_idx;
    }
    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_def_buffer, def_buf_list_size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to get cos port buffer ingress error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    rc = sx_api_cos_port_shared_buff_type_set(handle, cmd, log_port, port_buffer_list, port_buffer_list_size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set cos port buffer ingress error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

out:
    return ret;
}

/* Configure recirculation port pg reserved buffer and pg reserved descriptors settings */
int configure_recirculation_port_pg_buffer_desc(wjh_port_log_id_t            log_port,
                                                sx_cos_port_buff_attr_type_e type,
                                                uint32_t                     pool_id,
                                                buffer_units_t               size,
                                                sx_cos_port_buffer_attr_t    port_def_buffer[],
                                                uint32_t                    *def_buf_list_size)
{
    int                       ret = 0;
    sx_status_t               rc = SX_STATUS_SUCCESS;
    uint32_t                  pg_idx = SX_COS_ING_PG_0_E;
    sx_cos_port_buffer_attr_t port_buffer_list[SX_COS_ING_PG_7_E + 1];
    uint32_t                  port_buffer_list_size = SX_COS_ING_PG_7_E + 1;
    sx_access_cmd_t           cmd = SX_ACCESS_CMD_SET;

    /* Make all PG reserved buffer sizes to be 0 except for PG(1)*/
    memset(&port_buffer_list, 0, sizeof(port_buffer_list));
    for (pg_idx = SX_COS_ING_PG_0_E; pg_idx <= SX_COS_ING_PG_7_E; pg_idx++) {
        port_buffer_list[pg_idx].type = type;
        port_buffer_list[pg_idx].attr.ingress_port_pg_buff_attr.pool_id = pool_id;
        port_buffer_list[pg_idx].attr.ingress_port_pg_buff_attr.xon = 0;
        port_buffer_list[pg_idx].attr.ingress_port_pg_buff_attr.xoff = 0;
        port_buffer_list[pg_idx].attr.ingress_port_pg_buff_attr.is_lossy = 1;
        port_buffer_list[pg_idx].attr.ingress_port_pg_buff_attr.pipeline_latency.override_default = 0;
        port_buffer_list[pg_idx].attr.ingress_port_pg_buff_attr.pg = pg_idx;
        if (pg_idx == SX_COS_ING_PG_1_E) {
            port_buffer_list[pg_idx].attr.ingress_port_pg_buff_attr.size = size;
        } else {
            port_buffer_list[pg_idx].attr.ingress_port_pg_buff_attr.size = 0;
        }
        port_def_buffer[pg_idx].type = type;
        port_def_buffer[pg_idx].attr.ingress_port_pg_buff_attr.pool_id = pool_id;
        port_def_buffer[pg_idx].attr.ingress_port_pg_buff_attr.pg = pg_idx;
    }
    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_def_buffer, def_buf_list_size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to get cos port buffer ingress error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    rc = sx_api_cos_port_buff_type_set(handle, cmd, log_port, port_buffer_list, port_buffer_list_size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set cos port buffer ingress error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

out:
    return ret;
}

/* Configure recirculation port tc shared buffer and tc shared descriptors settings */
int configure_recirculation_port_tc_shared_buffer_desc(wjh_port_log_id_t                log_port,
                                                       sx_cos_port_buff_attr_type_e     type,
                                                       uint32_t                         pool_id,
                                                       buffer_units_t                   size,
                                                       sx_cos_buffer_max_mode_e         buf_mode,
                                                       sx_cos_port_buff_alpha_e         alpha,
                                                       sx_cos_port_shared_buffer_attr_t port_def_buffer[],
                                                       uint32_t                        *def_buf_list_size)
{
    int                              ret = 0;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    uint32_t                         tc_idx = SX_COS_EGR_TC_0_E;
    sx_cos_port_shared_buffer_attr_t port_buffer_list[SX_COS_EGR_TC_15_E + 1];
    uint32_t                         port_buffer_list_size = SX_COS_EGR_TC_15_E + 1;
    sx_access_cmd_t                  cmd = SX_ACCESS_CMD_SET;

    /* Make all TC shared buffer sizes to be 0 except for TC(1)*/
    memset(&port_buffer_list, 0, sizeof(port_buffer_list));

    for (tc_idx = SX_COS_EGR_TC_0_E; tc_idx <= SX_COS_EGR_TC_15_E; tc_idx++) {
        port_buffer_list[tc_idx].type = type;
        port_buffer_list[tc_idx].attr.egress_port_tc_shared_buff_attr.pool_id = pool_id;
        port_buffer_list[tc_idx].attr.egress_port_tc_shared_buff_attr.tc = tc_idx;
        if (tc_idx == SX_COS_EGR_TC_1_E) {
            port_buffer_list[tc_idx].attr.egress_port_tc_shared_buff_attr.max.mode = buf_mode;
            if (buf_mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E) {
                port_buffer_list[tc_idx].attr.egress_port_tc_shared_buff_attr.max.max.alpha = alpha;
            } else {
                port_buffer_list[tc_idx].attr.egress_port_tc_shared_buff_attr.max.max.size = size;
            }
        } else {
            port_buffer_list[tc_idx].attr.egress_port_tc_shared_buff_attr.max.mode = SX_COS_BUFFER_MAX_MODE_STATIC_E;
            port_buffer_list[tc_idx].attr.egress_port_tc_shared_buff_attr.max.max.size = 0;
        }
        port_def_buffer[tc_idx].type = type;
        port_def_buffer[tc_idx].attr.egress_port_tc_shared_buff_attr.pool_id = pool_id;
        port_def_buffer[tc_idx].attr.egress_port_tc_shared_buff_attr.tc = tc_idx;
    }
    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_def_buffer, def_buf_list_size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to get cos port shared buffer egress, error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    rc = sx_api_cos_port_shared_buff_type_set(handle, cmd, log_port, port_buffer_list, port_buffer_list_size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set cos port shared buffer egress tc, error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

out:
    return ret;
}

/* Configure recirculation port tc reserved buffer and tc reserved descriptors settings */
int configure_recirculation_port_tc_buffer_desc(wjh_port_log_id_t            log_port,
                                                sx_cos_port_buff_attr_type_e type,
                                                uint32_t                     pool_id,
                                                buffer_units_t               size,
                                                sx_cos_port_buffer_attr_t    port_def_buffer[],
                                                uint32_t                    *def_buf_list_size)
{
    int                       ret = 0;
    sx_status_t               rc = SX_STATUS_SUCCESS;
    uint32_t                  tc_idx = SX_COS_EGR_TC_0_E;
    sx_cos_port_buffer_attr_t port_buffer_list[SX_COS_EGR_TC_15_E + 1];
    uint32_t                  port_buffer_list_size = SX_COS_EGR_TC_15_E + 1;
    sx_access_cmd_t           cmd = SX_ACCESS_CMD_SET;

    /* Make all TC reserved buffer sizes to be 0 except for TC(1)*/
    memset(&port_buffer_list, 0, sizeof(port_buffer_list));

    for (tc_idx = SX_COS_EGR_TC_0_E; tc_idx <= SX_COS_EGR_TC_15_E; tc_idx++) {
        port_buffer_list[tc_idx].type = type;
        port_buffer_list[tc_idx].attr.egress_port_tc_buff_attr.pool_id = pool_id;
        port_buffer_list[tc_idx].attr.egress_port_tc_buff_attr.tc = tc_idx;
        if (tc_idx == SX_COS_EGR_TC_1_E) {
            port_buffer_list[tc_idx].attr.egress_port_tc_buff_attr.size = size;
        } else {
            port_buffer_list[tc_idx].attr.egress_port_tc_buff_attr.size = 0;
        }
        port_def_buffer[tc_idx].type = type;
        port_def_buffer[tc_idx].attr.egress_port_tc_buff_attr.pool_id = pool_id;
        port_def_buffer[tc_idx].attr.egress_port_tc_buff_attr.tc = tc_idx;
    }
    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_def_buffer, def_buf_list_size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to get cos port buffer egress, error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    rc = sx_api_cos_port_buff_type_set(handle, cmd, log_port, port_buffer_list, port_buffer_list_size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set cos port buffer egress tc, error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

out:
    return ret;
}

/* Configure recirculation port shared buffer and shared descriptors settings */
int configure_recirculation_port_shared_buffer_desc(wjh_port_log_id_t                log_port,
                                                    sx_cos_port_buff_attr_type_e     type,
                                                    uint32_t                         pool_id,
                                                    buffer_units_t                   size,
                                                    sx_cos_buffer_max_mode_e         buf_mode,
                                                    sx_cos_port_buff_alpha_e         alpha,
                                                    sx_cos_port_shared_buffer_attr_t port_def_buffer[],
                                                    uint32_t                        *def_buf_list_size)
{
    int                              ret = 0;
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_cos_port_shared_buffer_attr_t port_buffer;
    sx_access_cmd_t                  cmd = SX_ACCESS_CMD_SET;

    /* Allocate descriptor shared buffer for shared buffers */
    memset(&port_buffer, 0, sizeof(port_buffer));
    port_buffer.type = type;
    port_def_buffer[0].type = type;
    if (type == SX_COS_INGRESS_PORT_ATTR_E) {
        port_buffer.attr.ingress_port_shared_buff_attr.pool_id = pool_id;
        port_buffer.attr.ingress_port_shared_buff_attr.max.mode = buf_mode;
        if (buf_mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E) {
            port_buffer.attr.ingress_port_shared_buff_attr.max.max.alpha = alpha;
        } else {
            port_buffer.attr.ingress_port_shared_buff_attr.max.max.size = size;
        }
        port_def_buffer[0].attr.ingress_port_shared_buff_attr.pool_id = pool_id;
    } else {
        port_buffer.attr.egress_port_shared_buff_attr.pool_id = pool_id;
        port_buffer.attr.egress_port_shared_buff_attr.max.mode = buf_mode;
        if (buf_mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E) {
            port_buffer.attr.egress_port_shared_buff_attr.max.max.alpha = alpha;
        } else {
            port_buffer.attr.egress_port_shared_buff_attr.max.max.size = size;
        }
        port_def_buffer[0].attr.egress_port_shared_buff_attr.pool_id = pool_id;
    }

    rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_def_buffer, def_buf_list_size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to get cos port buffer ingress error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    rc = sx_api_cos_port_shared_buff_type_set(handle, cmd, log_port, &port_buffer, 1);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set cos port buffer ingress error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

out:
    return ret;
}

/* Configure recirculation port reserved buffer and reserved descriptors settings */
int configure_recirculation_port_buffer_desc(wjh_port_log_id_t            log_port,
                                             sx_cos_port_buff_attr_type_e type,
                                             uint32_t                     pool_id,
                                             buffer_units_t               size,
                                             sx_cos_port_buffer_attr_t    port_def_buffer[],
                                             uint32_t                    *def_buf_list_size)
{
    int                       ret = 0;
    sx_status_t               rc = SX_STATUS_SUCCESS;
    sx_cos_port_buffer_attr_t port_buffer;
    sx_access_cmd_t           cmd = SX_ACCESS_CMD_SET;

    /* Allocate descriptor reserved buffer for reserved buffers */
    memset(&port_buffer, 0, sizeof(port_buffer));
    port_buffer.type = type;
    port_def_buffer[0].type = type;
    if (type == SX_COS_INGRESS_PORT_ATTR_E) {
        port_buffer.attr.ingress_port_buff_attr.pool_id = pool_id;
        port_buffer.attr.ingress_port_buff_attr.size = size;
        port_def_buffer[0].attr.ingress_port_buff_attr.pool_id = pool_id;
    } else {
        port_buffer.attr.egress_port_buff_attr.pool_id = pool_id;
        port_buffer.attr.egress_port_buff_attr.size = size;
        port_def_buffer[0].attr.egress_port_buff_attr.pool_id = pool_id;
    }

    rc = sx_api_cos_port_buff_type_get(handle, log_port, port_def_buffer, def_buf_list_size);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to get cos port buffer ingress error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    rc = sx_api_cos_port_buff_type_set(handle, cmd, log_port, &port_buffer, 1);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set cos port buffer ingress error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

out:
    return ret;
}

/* wrapper API to configure reserved buffer settings for recirculation port */
int configure_recirculation_port_reserved_buffer_settings(wjh_port_log_id_t log_port)
{
    int      ret = 0;
    int      rollback_ret = 0;
    uint32_t size = 0;

    /* PG(1) Reserved buffer */
    size = (SX_COS_ING_PG_7_E + 1);
    ret = configure_recirculation_port_pg_buffer_desc(log_port, SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                                                      ING_POOL_ID, INGR_EGR_POOL_SIZE, port_def_pg_buffer, &size);
    if (ret != 0) {
        printf("recirculation port pg reserved buffer configuration failed\n");
        goto out;
    }

    /* TC(1) Reserved buffer */
    size = (SX_COS_EGR_TC_15_E + 1);
    ret = configure_recirculation_port_tc_buffer_desc(log_port, SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E,
                                                      EGR_POOL_ID, INGR_EGR_POOL_SIZE, port_def_tc_buffer, &size);
    if (ret != 0) {
        printf("recirculation port tc reserved buffer configuration failed\n");
        goto rollback_pg_buffer;
    }


    /* PG(1) Reserved Desc buffer */
    size = (SX_COS_ING_PG_7_E + 1);
    ret = configure_recirculation_port_pg_buffer_desc(log_port, SX_COS_PORT_BUFF_ATTR_RESERVED2_E,
                                                      ING_DESC_POOL_ID, POOL_DESC_CELLS, port_def_pg_desc_buffer,
                                                      &size);
    if (ret != 0) {
        printf("recirculation port pg reserved desc buffer configuration failed\n");
        goto rollback_tc_buffer;
    }

    /* TC(1) Reserved Desc buffer */
    size = (SX_COS_EGR_TC_15_E + 1);
    ret = configure_recirculation_port_tc_buffer_desc(log_port, SX_COS_PORT_BUFF_ATTR_RESERVED4_E,
                                                      EGR_DESC_POOL_ID, POOL_DESC_CELLS, port_def_tc_desc_buffer,
                                                      &size);
    if (ret != 0) {
        printf("recirculation port tc reserved desc buffer configuration failed\n");
        goto rollback_pg_desc;
    }

    /* Ingress Port Reserved buffer */
    size = 1;
    ret = configure_recirculation_port_buffer_desc(log_port, SX_COS_INGRESS_PORT_ATTR_E, ING_POOL_ID,
                                                   INGR_EGR_POOL_SIZE, &port_def_ing_port_buffer, &size);
    if (ret != 0) {
        printf("recirculation port ingress port reserved buffer configuration failed\n");
        goto rollback_tc_desc;
    }

    /* Egress Port Reserved buffer */
    size = 1;
    ret = configure_recirculation_port_buffer_desc(log_port, SX_COS_EGRESS_PORT_ATTR_E, EGR_POOL_ID,
                                                   INGR_EGR_POOL_SIZE, &port_def_egr_port_buffer, &size);
    if (ret != 0) {
        printf("recirculation port egress port reserved buffer configuration failed\n");
        goto rollback_ing_buffer;
    }

    /* Ingress Port Desc Reserved buffer */
    size = 1;
    ret = configure_recirculation_port_buffer_desc(log_port, SX_COS_PORT_BUFF_ATTR_RESERVED1_E, ING_DESC_POOL_ID,
                                                   POOL_DESC_CELLS, &port_def_ing_port_desc_buffer, &size);
    if (ret != 0) {
        printf("recirculation port ingress reserved desc buffer configuration failed\n");
        goto rollback_egr_buffer;
    }

    /* Egress Port Desc Reserved buffer */
    size = 1;
    ret = configure_recirculation_port_buffer_desc(log_port, SX_COS_PORT_BUFF_ATTR_RESERVED3_E, EGR_DESC_POOL_ID,
                                                   POOL_DESC_CELLS, &port_def_egr_port_desc_buffer, &size);
    if (ret != 0) {
        printf("recirculation port egress reserved desc buffer configuration failed\n");
        goto rollback_ing_desc;
    }

    goto out;

rollback_ing_desc:
    rollback_ret = deconfigure_recirculation_port_reserved_buffer(log_port, &port_def_ing_port_desc_buffer, 1);
    if (rollback_ret != 0) {
        printf("recirculation port egr reserved buffer rollback configuration failed\n");
    }

rollback_egr_buffer:
    rollback_ret = deconfigure_recirculation_port_reserved_buffer(log_port, &port_def_egr_port_buffer, 1);
    if (rollback_ret != 0) {
        printf("recirculation port egr reserved buffer rollback configuration failed\n");
    }


rollback_ing_buffer:
    rollback_ret = deconfigure_recirculation_port_reserved_buffer(log_port, &port_def_ing_port_buffer, 1);
    if (rollback_ret != 0) {
        printf("recirculation port ing reserved buffer rollback configuration failed\n");
    }


rollback_tc_desc:
    rollback_ret =
        deconfigure_recirculation_port_reserved_buffer(log_port, port_def_tc_desc_buffer, (SX_COS_EGR_TC_15_E + 1));
    if (rollback_ret != 0) {
        printf("recirculation port pg reserved buffer rollback configuration failed\n");
    }

rollback_pg_desc:
    rollback_ret =
        deconfigure_recirculation_port_reserved_buffer(log_port, port_def_pg_desc_buffer, (SX_COS_ING_PG_7_E + 1));
    if (rollback_ret != 0) {
        printf("recirculation port pg reserved buffer rollback configuration failed\n");
    }

rollback_tc_buffer:
    rollback_ret = deconfigure_recirculation_port_reserved_buffer(log_port,
                                                                  port_def_tc_buffer,
                                                                  (SX_COS_EGR_TC_15_E + 1));
    if (rollback_ret != 0) {
        printf("recirculation port tc reserved buffer rollback configuration failed\n");
    }

rollback_pg_buffer:
    rollback_ret =
        deconfigure_recirculation_port_reserved_buffer(log_port, port_def_pg_buffer, (SX_COS_ING_PG_7_E + 1));
    if (rollback_ret != 0) {
        printf("recirculation port pg reserved buffer rollback configuration failed\n");
    }
out:
    return ret;
}

/* wrapper API to configure shared buffer settings for recirculation port */
int configure_recirculation_port_shared_buffer_settings(wjh_port_log_id_t log_port)
{
    int      ret = 0;
    int      rollback_ret = 0;
    uint32_t size = 0;

    /* PG(1) shared buffer */
    size = (SX_COS_ING_PG_7_E + 1);
    ret = configure_recirculation_port_pg_shared_buffer_desc(log_port,
                                                             SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E,
                                                             ING_POOL_ID,
                                                             INGR_EGR_POOL_SIZE,
                                                             SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                                                             SX_COS_PORT_BUFF_ALPHA_0_E,
                                                             port_def_pg_shared_buffer,
                                                             &size);
    if (ret != 0) {
        printf("recirculation port pg shared buffer configuration failed\n");
        goto out;
    }

    /* TC(1) shared buffer */
    size = (SX_COS_EGR_TC_15_E + 1);
    ret = configure_recirculation_port_tc_shared_buffer_desc(log_port,
                                                             SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E,
                                                             EGR_POOL_ID,
                                                             INGR_EGR_POOL_SIZE,
                                                             SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                                                             SX_COS_PORT_BUFF_ALPHA_0_E,
                                                             port_def_tc_shared_buffer,
                                                             &size);
    if (ret != 0) {
        printf("recirculation port tc shared buffer configuration failed\n");
        goto rollback_pg_buffer;
    }

    /* PG(1) shared buffer pool desc */
    size = (SX_COS_ING_PG_7_E + 1);
    ret = configure_recirculation_port_pg_shared_buffer_desc(log_port,
                                                             SX_COS_PORT_BUFF_ATTR_RESERVED2_E,
                                                             ING_DESC_POOL_ID,
                                                             POOL_DESC_CELLS,
                                                             SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                                                             SX_COS_PORT_BUFF_ALPHA_0_E,
                                                             port_def_pg_desc_shared_buffer,
                                                             &size);
    if (ret != 0) {
        printf("recirculation port pg shared desc buffer configuration failed\n");
        goto rollback_tc_buffer;
    }

    /* TC(1) shared buffer pool desc */
    size = (SX_COS_EGR_TC_15_E + 1);
    ret = configure_recirculation_port_tc_shared_buffer_desc(log_port,
                                                             SX_COS_PORT_BUFF_ATTR_RESERVED4_E,
                                                             EGR_DESC_POOL_ID,
                                                             POOL_DESC_CELLS,
                                                             SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                                                             SX_COS_PORT_BUFF_ALPHA_0_E,
                                                             port_def_tc_desc_shared_buffer,
                                                             &size);
    if (ret != 0) {
        printf("recirculation port tc shared desc buffer configuration failed\n");
        goto rollback_pg_desc;
    }

    /* Ingress Port Shared buffer */
    size = 1;
    ret = configure_recirculation_port_shared_buffer_desc(log_port,
                                                          SX_COS_INGRESS_PORT_ATTR_E,
                                                          ING_POOL_ID,
                                                          INGR_EGR_POOL_SIZE,
                                                          SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                                                          SX_COS_PORT_BUFF_ALPHA_0_E,
                                                          &port_def_ing_port_shared_buffer,
                                                          &size);
    if (ret != 0) {
        printf("recirculation port ingress port shared buffer configuration failed\n");
        goto rollback_tc_desc;
    }

    /* Egress Port Shared buffer */
    size = 1;
    ret = configure_recirculation_port_shared_buffer_desc(log_port,
                                                          SX_COS_EGRESS_PORT_ATTR_E,
                                                          EGR_POOL_ID,
                                                          INGR_EGR_POOL_SIZE,
                                                          SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                                                          SX_COS_PORT_BUFF_ALPHA_0_E,
                                                          &port_def_egr_port_shared_buffer,
                                                          &size);
    if (ret != 0) {
        printf("recirculation port egress port shared buffer configuration failed\n");
        goto rollback_ing_buffer;
    }

    /* Ingress Port Shared buffer Pool desc */
    size = 1;
    ret = configure_recirculation_port_shared_buffer_desc(log_port,
                                                          SX_COS_PORT_BUFF_ATTR_RESERVED1_E,
                                                          ING_DESC_POOL_ID,
                                                          POOL_DESC_CELLS,
                                                          SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                                                          SX_COS_PORT_BUFF_ALPHA_0_E,
                                                          &port_def_ing_port_desc_shared_buffer,
                                                          &size);
    if (ret != 0) {
        printf("recirculation port ingress port shared desc buffer configuration failed\n");
        goto rollback_egr_buffer;
    }

    /* Egress Port Shared buffer Pool desc */
    size = 1;
    ret = configure_recirculation_port_shared_buffer_desc(log_port,
                                                          SX_COS_PORT_BUFF_ATTR_RESERVED3_E,
                                                          EGR_DESC_POOL_ID,
                                                          POOL_DESC_CELLS,
                                                          SX_COS_BUFFER_MAX_MODE_DYNAMIC_E,
                                                          SX_COS_PORT_BUFF_ALPHA_0_E,
                                                          &port_def_egr_port_desc_shared_buffer,
                                                          &size);
    if (ret != 0) {
        printf("recirculation port egress port shared desc buffer configuration failed\n");
        goto rollback_ing_desc;
    }

    goto out;

rollback_ing_desc:
    rollback_ret = deconfigure_recirculation_port_shared_buffer(log_port, &port_def_ing_port_desc_shared_buffer, 1);
    if (rollback_ret != 0) {
        printf("recirculation port ingress port desc shared buffer rollback configuration failed\n");
    }

rollback_egr_buffer:
    rollback_ret = deconfigure_recirculation_port_shared_buffer(log_port, &port_def_egr_port_shared_buffer, 1);
    if (rollback_ret != 0) {
        printf("recirculation port egr port shared buffer rollback configuration failed\n");
    }


rollback_ing_buffer:
    rollback_ret = deconfigure_recirculation_port_shared_buffer(log_port, &port_def_ing_port_shared_buffer, 1);
    if (rollback_ret != 0) {
        printf("recirculation port ing port shared buffer rollback configuration failed\n");
    }


rollback_tc_desc:
    rollback_ret =
        deconfigure_recirculation_port_shared_buffer(log_port, port_def_tc_desc_shared_buffer,
                                                     (SX_COS_EGR_TC_15_E + 1));
    if (rollback_ret != 0) {
        printf("recirculation port tc desc shared buffer rollback configuration failed\n");
    }

rollback_pg_desc:
    rollback_ret =
        deconfigure_recirculation_port_shared_buffer(log_port, port_def_pg_desc_shared_buffer,
                                                     (SX_COS_ING_PG_7_E + 1));
    if (rollback_ret != 0) {
        printf("recirculation port pg desc shared buffer rollback configuration failed\n");
    }

rollback_tc_buffer:
    rollback_ret =
        deconfigure_recirculation_port_shared_buffer(log_port, port_def_tc_shared_buffer, (SX_COS_EGR_TC_15_E + 1));
    if (rollback_ret != 0) {
        printf("recirculation port tc shared buffer rollback configuration failed\n");
    }

rollback_pg_buffer:
    rollback_ret =
        deconfigure_recirculation_port_shared_buffer(log_port, port_def_pg_shared_buffer, (SX_COS_ING_PG_7_E + 1));
    if (rollback_ret != 0) {
        printf("recirculation port pg shared buffer rollback configuration failed\n");
    }
out:
    return ret;
}

/* Configure reserved and shared buffer for recirculation ports */
int configure_recirculation_port_buffer_settings(wjh_port_log_id_t log_port)
{
    int ret = 0;

    ret = configure_recirculation_port_reserved_buffer_settings(log_port);
    if (ret != 0) {
        printf("recirculation port reserved buffer configuration failed\n");
        goto out;
    }

    ret = configure_recirculation_port_shared_buffer_settings(log_port);
    if (ret != 0) {
        printf("recirculation port reserved buffer configuration failed\n");
        goto out;
    }

out:
    return ret;
}

/* Deconfigure the settings of reserved buffer for recirculation port */
int deconfigure_recirculation_port_reserved_buffer_settings(wjh_port_log_id_t log_port)
{
    int ret = 0;

    ret = deconfigure_recirculation_port_reserved_buffer(log_port, port_def_pg_buffer, (SX_COS_ING_PG_7_E + 1));
    if (ret != 0) {
        printf("recirculation port pg buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_reserved_buffer(log_port, port_def_tc_buffer, (SX_COS_EGR_TC_15_E + 1));
    if (ret != 0) {
        printf("recirculation port tc buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_reserved_buffer(log_port, port_def_pg_desc_buffer, (SX_COS_ING_PG_7_E + 1));
    if (ret != 0) {
        printf("recirculation port pg desc buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_reserved_buffer(log_port, port_def_tc_desc_buffer, (SX_COS_EGR_TC_15_E + 1));
    if (ret != 0) {
        printf("recirculation port tc desc buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_reserved_buffer(log_port, &port_def_ing_port_buffer, 1);
    if (ret != 0) {
        printf("recirculation port ing reserved buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_reserved_buffer(log_port, &port_def_egr_port_buffer, 1);
    if (ret != 0) {
        printf("recirculation port egr reserved buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_reserved_buffer(log_port, &port_def_ing_port_desc_buffer, 1);
    if (ret != 0) {
        printf("recirculation port egr reserved buffer rollback configuration failed\n");
    }

    ret = deconfigure_recirculation_port_reserved_buffer(log_port, &port_def_egr_port_desc_buffer, 1);
    if (ret != 0) {
        printf("recirculation port egr reserved buffer rollback configuration failed\n");
    }

    return ret;
}

/* Deconfigure the settings of shared buffer for recirculation port */
int deconfigure_recirculation_port_shared_buffer_settings(wjh_port_log_id_t log_port)
{
    int ret = 0;

    ret = deconfigure_recirculation_port_shared_buffer(log_port, port_def_pg_shared_buffer, (SX_COS_ING_PG_7_E + 1));
    if (ret != 0) {
        printf("recirculation port pg shared buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_shared_buffer(log_port, port_def_tc_shared_buffer, (SX_COS_EGR_TC_15_E + 1));
    if (ret != 0) {
        printf("recirculation port tc shared buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_shared_buffer(log_port,
                                                       port_def_pg_desc_shared_buffer,
                                                       (SX_COS_ING_PG_7_E + 1));
    if (ret != 0) {
        printf("recirculation port pg desc shared buffer deconfigure failed\n");
    }

    ret =
        deconfigure_recirculation_port_shared_buffer(log_port, port_def_tc_desc_shared_buffer,
                                                     (SX_COS_EGR_TC_15_E + 1));
    if (ret != 0) {
        printf("recirculation port tc desc shared buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_shared_buffer(log_port, &port_def_ing_port_shared_buffer, 1);
    if (ret != 0) {
        printf("recirculation port ing port shared buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_shared_buffer(log_port, &port_def_egr_port_shared_buffer, 1);
    if (ret != 0) {
        printf("recirculation port egr port shared buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_shared_buffer(log_port, &port_def_ing_port_desc_shared_buffer, 1);
    if (ret != 0) {
        printf("recirculation port ing port desc shared buffer rollback configuration failed\n");
    }

    ret = deconfigure_recirculation_port_shared_buffer(log_port, &port_def_egr_port_desc_shared_buffer, 1);
    if (ret != 0) {
        printf("recirculation port egr port desc shared buffer rollback configuration failed\n");
    }

    return ret;
}


/* Deconfigure reserved and shared buffer for recirculation ports */
int deconfigure_recirculation_port_buffer_settings(wjh_port_log_id_t log_port)
{
    int ret = 0;

    ret = deconfigure_recirculation_port_reserved_buffer_settings(log_port);
    if (ret != 0) {
        printf("recirculation port reserved buffer deconfigure failed\n");
    }

    ret = deconfigure_recirculation_port_shared_buffer_settings(log_port);
    if (ret != 0) {
        printf("recirculation port shared buffer deconfigure failed\n");
    }

    return ret;
}

/* Configure Switch Priority and PG/TC mapping for analyzer port */
int configure_recirculation_port_prio_pg_tc_buff_map(wjh_port_log_id_t log_port)
{
    int                     ret = 0;
    uint32_t                i = 0;
    sx_status_t             rc = SX_STATUS_SUCCESS;
    sx_cos_port_prio_buff_t cos_prio_to_buff;


    /* Map  priority to PG buffer*/
    memset(&port_prio_def_pg_buff_map, 0, sizeof(port_prio_def_pg_buff_map));
    rc = sx_api_cos_port_prio_buff_map_get(handle, log_port, &port_prio_def_pg_buff_map);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to get cos priority to buffer mapping error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    memset(&cos_prio_to_buff, 0, sizeof(cos_prio_to_buff));
    for (i = 0; i < (RM_API_COS_PORT_PRIO_MAX + 1); i++) {
        cos_prio_to_buff.prio_to_buff[i] = 1;
    }

    rc = sx_api_cos_port_prio_buff_map_set(handle, SX_ACCESS_CMD_SET, log_port, &cos_prio_to_buff);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set cos priority to buffer mapping error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    /* Map  priority to TC buffer*/
    for (i = 0; i < (RM_API_COS_PORT_PRIO_MAX + 1); i++) {
        rc = sx_api_cos_port_tc_prio_map_get(handle, log_port, i, &port_prio_def_tc_buff_map[i]);
        if (SX_CHECK_FAIL(rc)) {
            printf("Failed to get cos priority to buffer mapping error: %s\n", sx_status_str(rc));
            ret = -1;
            goto out;
        }

        rc = sx_api_cos_port_tc_prio_map_set(handle, SX_ACCESS_CMD_ADD, log_port, i, SX_COS_EGR_TC_1_E);
        if (SX_CHECK_FAIL(rc)) {
            printf("Failed to get cos priority to buffer mapping error: %s\n", sx_status_str(rc));
            ret = -1;
            goto out;
        }
    }

out:
    return ret;
}

/* Revert Switch Priority and PG/TC mapping for analyzer port */
int deconfigure_recirculation_port_prio_def_pg_tc_buff_map(wjh_port_log_id_t log_port)
{
    int         ret = 0;
    uint32_t    i = 0;
    sx_status_t rc = SX_STATUS_SUCCESS;

    rc = sx_api_cos_port_prio_buff_map_set(handle, SX_ACCESS_CMD_SET, log_port, &port_prio_def_pg_buff_map);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set revert cos priority to buffer mapping error: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    /* Map  priority to TC buffer*/
    for (i = 0; i < (RM_API_COS_PORT_PRIO_MAX + 1); i++) {
        rc = sx_api_cos_port_tc_prio_map_set(handle, SX_ACCESS_CMD_ADD, log_port, i, port_prio_def_tc_buff_map[i]);
        if (SX_CHECK_FAIL(rc)) {
            printf("Failed to get cos priority to buffer mapping error: %s\n", sx_status_str(rc));
            ret = -1;
            goto out;
        }
    }

out:
    return ret;
}

/* Configure loopback mode for recirculation port */
int configure_recirculation_port_loopback_mode(wjh_port_log_id_t port)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    int         ret = 0;

    rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to bring recirculation port down to enable loopback: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    rc = sx_api_port_phys_loopback_set(handle, port, SX_PORT_PHYS_LOOPBACK_ENABLE_INTERNAL);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to set loopback for recirculation port loopback: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to bring recirculation port up to enable loopback: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }
out:
    return ret;
}

/* Remove loopback mode for recirculation port */
int deconfigure_recirculation_port_loopback_mode(wjh_port_log_id_t port)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    int         ret = 0;

    rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to bring recirculation port down to disable loopback: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    rc = sx_api_port_phys_loopback_set(handle, port, SX_PORT_PHYS_LOOPBACK_DISABLE);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to remove loopback mode for recirculation port loopback: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }

    rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to bring recirculation port up to disable loopback: %s\n", sx_status_str(rc));
        ret = -1;
        goto out;
    }
out:
    return ret;
}

/* Configure recirculation port's loopback, buffer and SP mapping */
int configure_recirculation_port(wjh_port_log_id_t log_port)
{
    int ret = 0;

    ret = configure_recirculation_port_loopback_mode(log_port);
    if (ret != 0) {
        printf("failed to set the recirculation port in loopback mode, init failed for buffer drop reason group.\n");
        goto out;
    }

    ret = configure_recirculation_port_buffer_settings(log_port);
    if (ret != 0) {
        printf("failed to set buffer for recirculation port, init failed for buffer drop reason group.\n");
        goto out;
    }
    ret = configure_recirculation_port_prio_pg_tc_buff_map(log_port);
    if (ret != 0) {
        printf("failed to set SP to TC/PG mapping, init failed for buffer drop reason group.\n");
        goto out;
    }
out:
    return ret;
}


/* Revert recirculation port's loopback, buffer and SP mapping */
void deconfigure_recirculation_port(wjh_port_log_id_t log_port)
{
    deconfigure_recirculation_port_loopback_mode(log_port);
    deconfigure_recirculation_port_buffer_settings(log_port);
    deconfigure_recirculation_port_prio_def_pg_tc_buff_map(log_port);
}


wjh_status_t configure_drop_reason_group(wjh_drop_reason_group_e drop_reason_group,
                                         wjh_drop_callbacks_t   *drop_callbacks_p,
                                         wjh_user_channel_id_t   channel_id)
{
    wjh_status_t                 status = WJH_STATUS_SUCCESS;
    int                          ret = 0;
    wjh_drop_reason_group_attr_t attr;

    memset(&attr, 0, sizeof(wjh_drop_reason_group_attr_t));

    if (drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) {
        attr.attr.buffer_drop.basic_attr.truncate_size = 0;
        attr.attr.buffer_drop.advanced_attr.trap_probability = 0;
        attr.attr.buffer_drop.advanced_attr.trap_id = 0;
        attr.attr.buffer_drop.advanced_attr.ptp_disabled = 0;
        attr.attr.buffer_drop.basic_attr.recirculation_port = WJH_BUFFER_DROP_RECYCLE_PORT;
        ret = configure_recirculation_port(attr.attr.buffer_drop.basic_attr.recirculation_port);
        if (ret != 0) {
            printf("failed to init drop reason group %d.\n", drop_reason_group);
            status = WJH_STATUS_ERROR;
            goto out;
        }
    }

    if (drop_reason_group == WJH_DROP_REASON_GROUP_ROCE_E) {
        attr.attr.roce_drop.roce_monitor_point = WJH_ROCE_MONITOR_POINT_INGRESS;
        attr.attr.roce_drop.cnp_switch_prio = 6;
        attr.attr.roce_drop.roce_switch_prio = 7;
    }

    status = wjh_drop_reason_group_init(drop_reason_group, &attr, drop_callbacks_p);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to init drop reason group %d.\n", drop_reason_group);
        goto out;
    }

    status = wjh_drop_reason_group_bind(drop_reason_group, channel_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to bind drop reason group %d on channel %d.\n",
               drop_reason_group, channel_id);
        goto out;
    }

    status = wjh_drop_reason_group_enable(drop_reason_group, WJH_SEVERITY_ALL_E);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to enable drop reason group %d.\n", drop_reason_group);
        goto out;
    }

out:
    return status;
}

wjh_status_t deconfigure_drop_reason_group(wjh_drop_reason_group_e drop_reason_group)
{
    wjh_status_t status = WJH_STATUS_SUCCESS;

    if (drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) {
        deconfigure_recirculation_port(WJH_BUFFER_DROP_RECYCLE_PORT);
    }
    /* de-configuration */
    status = wjh_drop_reason_group_disable(drop_reason_group, WJH_SEVERITY_ALL_E);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to disable drop reason group %d.\n", drop_reason_group);
        goto out;
    }

    status = wjh_drop_reason_group_unbind(drop_reason_group);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to unbind drop reason group %d.\n", drop_reason_group);
        goto out;
    }

    status = wjh_drop_reason_group_deinit(drop_reason_group);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to deinit drop reason group %d. \n", drop_reason_group);
        goto out;
    }

out:
    return status;
}

wjh_status_t configure_filter(wjh_filter_id_t *filter_id_p)
{
    wjh_status_t      status = WJH_STATUS_SUCCESS;
    wjh_filter_id_t   filter_id = 0;
    wjh_filter_key_e  filter_key[4];
    wjh_filter_rule_t filter_rule[5];
    int               i = 0;

    memset(filter_rule, 0, sizeof(wjh_filter_rule_t) * 5);

    filter_key[0] = WJH_FILTER_KEY_PORT_E;
    filter_key[1] = WJH_FILTER_KEY_DROP_REASON_E;
    filter_key[2] = WJH_FILTER_KEY_IP_PROTO_E;
    filter_key[3] = WJH_FILTER_KEY_ETHER_TYPE_E;

    status = wjh_filter_create(filter_key, 4, &filter_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to create filter. \n");
        goto out;
    }

    filter_rule[0].key_desc_count = 1;
    filter_rule[0].key_desc_list_p = calloc(1, sizeof(wjh_filter_key_desc_t));
    filter_rule[0].key_desc_list_p[0].key = WJH_FILTER_KEY_DROP_REASON_E;
    filter_rule[0].key_desc_list_p[0].field.drop_reason = FILTER_DROP_REASON;

    filter_rule[1].key_desc_count = 2;
    filter_rule[1].key_desc_list_p = calloc(2, sizeof(wjh_filter_key_desc_t));
    filter_rule[1].key_desc_list_p[0].key = WJH_FILTER_KEY_PORT_E;
    filter_rule[1].key_desc_list_p[0].field.port = 0x10005;
    filter_rule[1].key_desc_list_p[1].key = WJH_FILTER_KEY_DROP_REASON_E;
    filter_rule[1].key_desc_list_p[1].field.drop_reason = WJH_DROP_REASON_ID_INGRESS_PORT_ACL_E;

    filter_rule[2].key_desc_count = 2;
    filter_rule[2].key_desc_list_p = calloc(2, sizeof(wjh_filter_key_desc_t));
    filter_rule[2].key_desc_list_p[0].key = WJH_FILTER_KEY_IP_PROTO_E;
    filter_rule[2].key_desc_list_p[0].field.ip_proto = 0x06;
    filter_rule[2].key_desc_list_p[1].key = WJH_FILTER_KEY_ETHER_TYPE_E;
    filter_rule[2].key_desc_list_p[1].field.ether_type = 0x0800;

    filter_rule[3].key_desc_count = 2;
    filter_rule[3].key_desc_list_p = calloc(2, sizeof(wjh_filter_key_desc_t));
    filter_rule[3].key_desc_list_p[0].key = WJH_FILTER_KEY_PORT_E;
    filter_rule[3].key_desc_list_p[0].field.port = 0x10005;
    filter_rule[3].key_desc_list_p[1].key = WJH_FILTER_KEY_DROP_REASON_E;
    filter_rule[3].key_desc_list_p[1].field.drop_reason = WJH_DROP_REASON_ID_SOURCE_MAC_EQUALS_DESTINATION_MAC_E;

    filter_rule[4].key_desc_count = 1;
    filter_rule[4].key_desc_list_p = calloc(2, sizeof(wjh_filter_key_desc_t));
    filter_rule[4].key_desc_list_p[0].key = WJH_FILTER_KEY_DROP_REASON_E;
    filter_rule[4].key_desc_list_p[0].field.drop_reason = WJH_DROP_REASON_ID_TAIL_DROP_E;

    status = wjh_filter_rule_add(filter_id, filter_rule, 5);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to add rules to filter %d. \n", filter_id);
        goto out;
    }

    *filter_id_p = filter_id;

out:
    for (i = 0; i < 5; i++) {
        if (filter_rule[i].key_desc_list_p) {
            free(filter_rule[i].key_desc_list_p);
        }
    }

    return status;
}

wjh_status_t deconfigure_filter(wjh_filter_id_t filter_id)
{
    wjh_status_t      status = WJH_STATUS_SUCCESS;
    wjh_filter_rule_t filter_rule[2];

    memset(filter_rule, 0, sizeof(wjh_filter_rule_t) * 2);

    filter_rule[0].key_desc_count = 1;
    filter_rule[0].key_desc_list_p = calloc(1, sizeof(wjh_filter_key_desc_t));
    if (filter_rule[0].key_desc_list_p == NULL) {
        status = WJH_STATUS_NO_MEMORY;
        goto out;
    }

    filter_rule[0].key_desc_list_p[0].key = WJH_FILTER_KEY_DROP_REASON_E;
    filter_rule[0].key_desc_list_p[0].field.drop_reason = FILTER_DROP_REASON;

    filter_rule[1].key_desc_count = 2;
    filter_rule[1].key_desc_list_p = calloc(2, sizeof(wjh_filter_key_desc_t));
    if (filter_rule[1].key_desc_list_p == NULL) {
        status = WJH_STATUS_NO_MEMORY;
        goto out;
    }
    filter_rule[1].key_desc_list_p[0].key = WJH_FILTER_KEY_PORT_E;
    filter_rule[1].key_desc_list_p[0].field.port = 0x10005;
    filter_rule[1].key_desc_list_p[1].key = WJH_FILTER_KEY_DROP_REASON_E;
    filter_rule[1].key_desc_list_p[1].field.drop_reason = WJH_DROP_REASON_ID_SOURCE_MAC_EQUALS_DESTINATION_MAC_E;

    status = wjh_filter_rule_remove(filter_id, filter_rule, 2);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to remove rules from filter %d, status = %d \n", filter_id, status);
    }

    status = wjh_filter_destroy(filter_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to destroy filter (%d).\n", filter_id);
        goto out;
    }

out:
    if (filter_rule[0].key_desc_list_p) {
        free(filter_rule[0].key_desc_list_p);
    }
    if (filter_rule[1].key_desc_list_p) {
        free(filter_rule[1].key_desc_list_p);
    }
    return status;
}

void debug_generate_dump(int signo)
{
    char* dump_file = "/tmp/wjh_dbg_dump.log";
    FILE* stream_p = NULL;

    if (signo != SIGUSR1) {
        return;
    }

    stream_p = fopen(dump_file, "w");
    if (stream_p == NULL) {
        printf("failed to open dump file.\n");
        return;
    }
    wjh_dbg_generate_dump(stream_p);
    fclose(stream_p);
}

int main(int argc, const char *argv[])
{
    wjh_status_t            status = WJH_STATUS_SUCCESS;
    wjh_init_param_t        init_param;
    wjh_user_channel_id_t   channel_id_1 = 0;
    wjh_user_channel_id_t   channel_id_2 = 0;
    wjh_user_channel_id_t   aggregation_channel_id = 0;
    wjh_drop_callbacks_t    L2_drop_callbacks, router_drop_callbacks, tunnel_drop_callbacks, acl_drop_callbacks;
    wjh_drop_callbacks_t    L1_drop_callbacks, buffer_drop_callbacks, roce_drop_callbacks;
    wjh_drop_counter_t      counter, global_counter;
    char                  * dump_file = "/tmp/wjh_dbg_dump";
    FILE                   *stream_p = NULL;
    wjh_user_channel_attr_t channel_attr;
    sx_status_t             rc = SX_STATUS_SUCCESS;

#ifdef WJH_EBPF_PRESENT
    wjh_filter_id_t filter_id = 0;
    uint64_t        filter_counter = 0;
#endif

    UNUSED_PARAM(argc);
    UNUSED_PARAM(argv);

    memset(&init_param, 0, sizeof(wjh_init_param_t));
    memset(&channel_attr, 0, sizeof(channel_attr));
    rc = sx_api_open(NULL, &handle);
    if (SX_CHECK_FAIL(rc)) {
        printf("Failed to open SX-API , error: %s\n", sx_status_str(rc));
        return -1;
    }

    init_param.force = 1;
    init_param.deactive_cb = force_deinit_notify;
    init_param.ingress_info_type = WJH_INGRESS_INFO_TYPE_LOGPORT;
    status = wjh_init(&init_param);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to init wjh lib.\n");
        return -1;
    }

    if (signal(SIGUSR1, debug_generate_dump) == SIG_ERR) {
        printf("\ncan't catch SIGUSR1\n");
    }

    status = wjh_user_channel_create(WJH_USER_CHANNEL_CYCLIC_E, &channel_id_1);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to create user channel.\n");
        return -1;
    }

    status = wjh_user_channel_create(WJH_USER_CHANNEL_CYCLIC_E, &channel_id_2);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to create user channel.\n");
        return -1;
    }

    status = wjh_user_channel_create(WJH_USER_CHANNEL_AGGREGATE_E, &aggregation_channel_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to create aggregation user channel.\n");
        return -1;
    }

    memset(&L2_drop_callbacks, 0, sizeof(wjh_drop_callbacks_t));
    memset(&router_drop_callbacks, 0, sizeof(wjh_drop_callbacks_t));
    memset(&tunnel_drop_callbacks, 0, sizeof(wjh_drop_callbacks_t));
    memset(&acl_drop_callbacks, 0, sizeof(wjh_drop_callbacks_t));
    memset(&buffer_drop_callbacks, 0, sizeof(wjh_drop_callbacks_t));
    memset(&roce_drop_callbacks, 0, sizeof(wjh_drop_callbacks_t));
    memset(&L1_drop_callbacks, 0, sizeof(L1_drop_callbacks));

    L2_drop_callbacks.drop_reason_group = WJH_DROP_REASON_GROUP_L2_E;
    L2_drop_callbacks.raw_cb.L2 = L2_drop_raw_cb;

    router_drop_callbacks.drop_reason_group = WJH_DROP_REASON_GROUP_ROUTER_E;
    router_drop_callbacks.raw_cb.router = router_drop_raw_cb;

    tunnel_drop_callbacks.drop_reason_group = WJH_DROP_REASON_GROUP_TUNNEL_E;
    tunnel_drop_callbacks.raw_cb.tunnel = tunnel_drop_raw_cb;

    acl_drop_callbacks.drop_reason_group = WJH_DROP_REASON_GROUP_ACL_E;
    acl_drop_callbacks.raw_cb.acl = acl_drop_raw_cb;
    acl_drop_callbacks.aggregate_cb.acl = acl_drop_aggregate_cb;

    L1_drop_callbacks.drop_reason_group = WJH_DROP_REASON_GROUP_L1_E;
    L1_drop_callbacks.aggregate_cb.L1 = L1_drop_aggregate_cb;

    buffer_drop_callbacks.drop_reason_group = WJH_DROP_REASON_GROUP_BUFFER_E;
    buffer_drop_callbacks.raw_cb.buffer = buffer_drop_raw_cb;
    buffer_drop_callbacks.aggregate_cb.buffer = buffer_drop_aggregate_cb;

    roce_drop_callbacks.drop_reason_group = WJH_DROP_REASON_GROUP_ROCE_E;
    roce_drop_callbacks.raw_cb.roce = roce_drop_raw_cb;
    roce_drop_callbacks.aggregate_cb.roce = roce_drop_aggregate_cb;

    status = configure_drop_reason_group(WJH_DROP_REASON_GROUP_L2_E,
                                         &L2_drop_callbacks,
                                         channel_id_1);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to configure L2 drop reason group. \n");
        return -1;
    }
    status = configure_drop_reason_group(WJH_DROP_REASON_GROUP_ROUTER_E,
                                         &router_drop_callbacks,
                                         channel_id_1);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to configure router drop reason group. \n");
        return -1;
    }
    status = configure_drop_reason_group(WJH_DROP_REASON_GROUP_TUNNEL_E,
                                         &tunnel_drop_callbacks,
                                         channel_id_1);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to configure tunnel drop reason group. \n");
        return -1;
    }

#ifdef WJH_EBPF_PRESENT
    status = configure_drop_reason_group(WJH_DROP_REASON_GROUP_ACL_E,
                                         &acl_drop_callbacks,
                                         aggregation_channel_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to configure acl drop reason group. \n");
        return -1;
    }

    status = configure_drop_reason_group(WJH_DROP_REASON_GROUP_BUFFER_E,
                                         &buffer_drop_callbacks,
                                         aggregation_channel_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to configure buffer drop reason group. \n");
        return -1;
    }

    status = configure_drop_reason_group(WJH_DROP_REASON_GROUP_ROCE_E,
                                         &roce_drop_callbacks,
                                         aggregation_channel_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to configure roce drop reason group. \n");
        return -1;
    }
#else
    status = configure_drop_reason_group(WJH_DROP_REASON_GROUP_ACL_E,
                                         &acl_drop_callbacks,
                                         channel_id_2);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to configure acl drop reason group. \n");
        return -1;
    }

    /*
     * Prerequisites configuration :
     * 1. SPAN module initialized
     * 2. For Spectrum only: recirculation port should be configured
     */
    status = configure_drop_reason_group(WJH_DROP_REASON_GROUP_BUFFER_E,
                                         &buffer_drop_callbacks,
                                         channel_id_2);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to configure buffer drop reason group. \n");
        printf("please check if SPAN module is initialized and other prerequisites are met.\n");
        return -1;
    }
#endif

    status = configure_drop_reason_group(WJH_DROP_REASON_GROUP_L1_E,
                                         &L1_drop_callbacks,
                                         aggregation_channel_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to configure L1 drop reason group. \n");
        return -1;
    }

    channel_attr.polling_interval = 200;
    status = wjh_user_channel_set(channel_id_1, &channel_attr);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to set user channel.\n");
        return -1;
    }

    /* Wait for traffic */
    printf("Waiting for traffic, press any key to continue to configure filter.\n");
    getchar();

#ifdef WJH_EBPF_PRESENT
    status = configure_filter(&filter_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to configure filter. \n");
        return -1;
    }

    status = wjh_filter_bind_user_channel(filter_id, channel_id_1);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to bind filter %d to channel %d. \n", filter_id, channel_id_1);
        return -1;
    }

    status = wjh_filter_bind_user_channel(filter_id, aggregation_channel_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to bind filter %d to channel %d. \n", filter_id, aggregation_channel_id);
        return -1;
    }
#endif

    stream_p = fopen(dump_file, "w");
    if (stream_p == NULL) {
        printf("failed to open dump file.\n");
        return -1;
    }
    wjh_dbg_generate_dump(stream_p);
    fclose(stream_p);

    /* Wait for traffic */
    printf("Waiting for traffic, press any key to continue.\n");
    getchar();

    printf("Press any key to change the user channels to pull mode.\n ");
    getchar();

    channel_attr.mode = WJH_USER_CHANNEL_MODE_PULL_E;
    status = wjh_user_channel_set(channel_id_1, &channel_attr);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to set user channel.\n");
        return -1;
    }

    status = wjh_user_channel_set(channel_id_2, &channel_attr);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to set user channel.\n");
        return -1;
    }

    status = wjh_user_channel_set(aggregation_channel_id, &channel_attr);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to set user channel.\n");
        return -1;
    }

    printf("Press any key to pull the user channels.\n ");
    getchar();

    status = wjh_user_channel_pull(channel_id_1);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to pull user channel.\n");
        return -1;
    }

    status = wjh_user_channel_pull(channel_id_2);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to pull user channel.\n");
        return -1;
    }

    status = wjh_user_channel_pull(aggregation_channel_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to pull user channel.\n");
        return -1;
    }

    memset(&counter, 0, sizeof(wjh_drop_counter_t));
    memset(&global_counter, 0, sizeof(wjh_drop_counter_t));

    status = wjh_counter_get(channel_id_1, &counter, 0);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to get counter on user channel %u.\n", channel_id_1);
        return -1;
    }
    printf("channel[%d]: drop_counter [%lu], receive_counter [%lu].\n",
           channel_id_1, counter.dropped_packets, counter.received_packets);

    status = wjh_counter_get(channel_id_2, &counter, 0);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to get counter on user channel %u.\n", channel_id_2);
        return -1;
    }
    printf("channel[%d]: drop_counter [%lu], receive_counter [%lu].\n",
           channel_id_2, counter.dropped_packets, counter.received_packets);

    status = wjh_global_counter_get(&global_counter, 0);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to get global counter.\n");
        return -1;
    }
    printf("global: drop_counter [%lu], receive_counter [%lu].\n",
           global_counter.dropped_packets, global_counter.received_packets);

    status = deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_ROCE_E);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to de-configure RoCE drop reason group. \n");
        return -1;
    }
    status = deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_L2_E);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to de-configure L2 drop reason group. \n");
        return -1;
    }
    status = deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_ROUTER_E);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to de-configure router drop reason group. \n");
        return -1;
    }
    status = deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_TUNNEL_E);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to de-configure tunnel drop reason group. \n");
        return -1;
    }
    status = deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_ACL_E);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to de-configure acl drop reason group. \n");
        return -1;
    }

    status = deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_BUFFER_E);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to de-configure buffer drop reason group. \n");
        return -1;
    }

    status = deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_L1_E);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to de-configure L1 drop reason group. \n");
        return -1;
    }

#ifdef WJH_EBPF_PRESENT
    status = wjh_filter_counter_get(filter_id, &filter_counter, 0);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to get counter on filter %u.\n", filter_id);
        return -1;
    }
    printf("filter[%d]: dropped by filter [%lu].\n",
           filter_id, filter_counter);

    status = wjh_filter_unbind_user_channel(filter_id, channel_id_1);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to unbind filter %d from channel %d. \n", filter_id, channel_id_1);
        return -1;
    }

    status = wjh_filter_unbind_user_channel(filter_id, aggregation_channel_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to unbind filter %d from channel %d. \n", filter_id, channel_id_1);
        return -1;
    }

    status = deconfigure_filter(filter_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to deconfigure filter\n");
        return -1;
    }
#endif

    status = wjh_user_channel_destroy(channel_id_1);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to destroy user channel %u.\n", channel_id_1);
        return -1;
    }

    status = wjh_user_channel_destroy(channel_id_2);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to destroy user channel %u.\n", channel_id_2);
        return -1;
    }

    status = wjh_user_channel_destroy(aggregation_channel_id);
    if (status != WJH_STATUS_SUCCESS) {
        printf("failed to destroy aggregation user channel %u.\n", aggregation_channel_id);
        return -1;
    }

    status = wjh_deinit();
    if (status != WJH_STATUS_SUCCESS) {
        printf("Failed to deinit wjh lib.\n");
        return -1;
    }
    return 0;
}
