#!/usr/bin/env python
'''
This file contains python based "What just happened" library backend for processing commands send by the WJH example frontend.
The backend is started by executing the wjh_example.py --enable commands. The WJH backend processes the following options from frontend
This is supported on Spectrum/Spectrum-2 devices.
    -h, --help            show this help message and exit
    --disable             disables the WJH example backend
    --enable              enables the WJH example backend
    --bandwidth BANDWIDTH
                          set pcie bandwidth percentage for WJH for enable
                          option
    --mode {agent,manual}
                          set WJH example mode for enable option
    --print               prints the WJH captured packets
    --save                saves the WJH captured packets
    --raw_file RAW_FILE   the optional file full path of the WJH raw packets
    --agg_file AGG_FILE   the optional file full path of the WJH aggregation
                          info
    --enable_drop_reason_group {all,l1,l2,router,tunnel,acl,buffer}
                          enable drop reason group
    --disable_drop_reason_group {all,l1,l2,router,tunnel,acl,buffer}
                          disable drop reason group
    --severity {all}      drop reason severity for drop reason group
                          disable/enable

'''

import sys
import argparse
import ctypes
from ctypes import *
from ctypes.util import find_library
import socket
import signal
import pickle
import struct
import os
import os.path
from python_sdk_api.sx_api import *

from test_infra_common import *
import json

######################################################
#    defines
######################################################
WJH_SOCKET_BUFFER_SIZE = 1024
WJH_MONITOR_SERVER_PORT = 20000
WJH_MAX_PKT_SIZE = 10000
WJH_PCAP_NAME = "/tmp/wjh_raw.pcap"
WJH_TXT_NAME = "/tmp/wjh_agg.txt"
WJH_AGG_JSON_NAME = "/tmp/wjh_agg.json"
WJH_SERVER_LISTEN_QUEUE_SIZE = 1

WJH_TRUNC_PROFILE_ID = 0
WJH_TRUNC_SIZE = 8000

WJH_TRAP_GROUP_ALLOCATE_MODE_STATIC_E = 0
WJH_TRAP_GROUP_ALLOCATE_MODE_DYNAMIC_E = 1

WJH_USER_CHANNEL_TAILDROP_E = 0
WJH_USER_CHANNEL_CYCLIC_E = 1
WJH_USER_CHANNEL_AGGREGATE_E = 2
WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E = 3
WJH_USER_CHANNEL_TAC_E = 4

WJH_DROP_REASON_GROUP_BUFFER_E = 0
WJH_DROP_REASON_GROUP_ACL_E = 1
WJH_DROP_REASON_GROUP_L1_E = 2
WJH_DROP_REASON_GROUP_L2_E = 3
WJH_DROP_REASON_GROUP_ROUTER_E = 4
WJH_DROP_REASON_GROUP_TUNNEL_E = 5
WJH_DROP_REASON_GROUP_ALL_E = 6

WJH_USER_CHANNEL_MODE_PUSH_E = 0
WJH_USER_CHANNEL_MODE_PULL_E = 1

WJH_SEVERITY_ALL_E = 0
WJH_SEVERITY_NOTICE_E = 1
WJH_SEVERITY_WARNING_E = 2
WJH_SEVERITY_ERROR_E = 3

WJH_ACL_BINDING_POINT_INGRESS = 0
WJH_ACL_BINDING_POINT_EGRESS = 1
WJH_ACL_BINDING_POINT_RIF_INGRESS = 2
WJH_ACL_BINDING_POINT_RIF_EGRESS = 3

WJH_INGRESS_INFO_TYPE_LOGPORT = 0
WJH_INGRESS_INFO_TYPE_IF_INDEX = 1

WJH_AGGREGATION_READ_MODE_READ_CLEAR = 0
WJH_AGGREGATION_READ_MODE_READ = 1

WJH_AGGREGATION_KEY_MODE_STREAMING_E = 0
WJH_AGGREGATION_KEY_MODE_DETAILED_E = 1

WJH_USER_CHANNEL_TIMESTAMP_SOURCE_LINUX_E = 0
WJH_USER_CHANNEL_TIMESTAMP_SOURCE_HW_CLOCK_E = 1

WJH_USER_CHANNEL_DESTINATION_CALLBACK_AND_DROP_MONITOR_E = 0
WJH_USER_CHANNEL_DESTINATION_DROP_MONITOR_E = 1

WJH_EVENT_NONE_E = 0
WJH_EVENT_PACKET_DROP_E = 1
WJH_EVENT_EXCEPTION_E = 2

RECYCLE_PORT = 0x10001
WJH_CPU_PORT_ID = 0x40010000
RECYCLE_PORT_PG_TC = 1

SX_COS_ING_PG_0_E = 0
SX_COS_ING_PG_1_E = 1
SX_COS_ING_PG_7_E = 7
SX_COS_EGR_TC_0_E = 0
SX_COS_EGR_TC_1_E = 1
SX_COS_EGR_TC_15_E = 15

port_def_pg_buffer = new_sx_cos_port_buffer_attr_t_arr(SX_COS_ING_PG_7_E + 1)
port_def_pg_desc_buffer = new_sx_cos_port_buffer_attr_t_arr(SX_COS_ING_PG_7_E + 1)
port_def_tc_buffer = new_sx_cos_port_buffer_attr_t_arr(SX_COS_EGR_TC_15_E + 1)
port_def_tc_desc_buffer = new_sx_cos_port_buffer_attr_t_arr(SX_COS_EGR_TC_15_E + 1)
port_def_ing_port_buffer = sx_cos_port_buffer_attr_t()
port_def_egr_port_buffer = sx_cos_port_buffer_attr_t()
port_def_ing_port_desc_buffer = sx_cos_port_buffer_attr_t()
port_def_egr_port_desc_buffer = sx_cos_port_buffer_attr_t()

port_def_pg_shared_buffer = new_sx_cos_port_shared_buffer_attr_t_arr(SX_COS_ING_PG_7_E + 1)
port_def_pg_desc_shared_buffer = new_sx_cos_port_shared_buffer_attr_t_arr(SX_COS_ING_PG_7_E + 1)
port_def_tc_shared_buffer = new_sx_cos_port_shared_buffer_attr_t_arr(SX_COS_EGR_TC_15_E + 1)
port_def_tc_desc_shared_buffer = new_sx_cos_port_shared_buffer_attr_t_arr(SX_COS_EGR_TC_15_E + 1)
port_def_ing_port_shared_buffer = sx_cos_port_shared_buffer_attr_t()
port_def_egr_port_shared_buffer = sx_cos_port_shared_buffer_attr_t()
port_def_ing_port_desc_shared_buffer = sx_cos_port_shared_buffer_attr_t()
port_def_egr_port_desc_shared_buffer = sx_cos_port_shared_buffer_attr_t()
def_prio_to_pg_mapping = {}
prio_to_tc_mapping = {}
PORT_PRIO_MAX = 15

channel_type_to_str = {
    WJH_USER_CHANNEL_TAILDROP_E: 'Taildrop',
    WJH_USER_CHANNEL_CYCLIC_E: 'Cyclic',
    WJH_USER_CHANNEL_AGGREGATE_E: 'Aggregate',
    WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E: 'Cyclic-and-Aggregate',
    WJH_USER_CHANNEL_TAC_E: 'Tac',
}

drop_reason_group_to_str = {
    WJH_DROP_REASON_GROUP_BUFFER_E: "buffer",
    WJH_DROP_REASON_GROUP_ACL_E: "acl",
    WJH_DROP_REASON_GROUP_L1_E: "l1",
    WJH_DROP_REASON_GROUP_L2_E: "l2",
    WJH_DROP_REASON_GROUP_ROUTER_E: "router",
    WJH_DROP_REASON_GROUP_TUNNEL_E: "tunnel",
    WJH_DROP_REASON_GROUP_ALL_E: "all"
}

drop_reason_group_str_to_enum = {
    "buffer": WJH_DROP_REASON_GROUP_BUFFER_E,
    "acl": WJH_DROP_REASON_GROUP_ACL_E,
    "l1": WJH_DROP_REASON_GROUP_L1_E,
    "l2": WJH_DROP_REASON_GROUP_L2_E,
    "router": WJH_DROP_REASON_GROUP_ROUTER_E,
    "tunnel": WJH_DROP_REASON_GROUP_TUNNEL_E,
    "all": WJH_DROP_REASON_GROUP_ALL_E
}

channel_mode_str_to_enum = {
    "agent": WJH_USER_CHANNEL_MODE_PUSH_E,
    "manual": WJH_USER_CHANNEL_MODE_PULL_E
}

severity_to_str = {
    WJH_SEVERITY_NOTICE_E: 'notice',
    WJH_SEVERITY_WARNING_E: 'warning',
    WJH_SEVERITY_ERROR_E: 'error',
    WJH_SEVERITY_ALL_E: 'all'
}

severity_str_to_enum = {
    "notice": WJH_SEVERITY_NOTICE_E,
    "warning": WJH_SEVERITY_WARNING_E,
    "error": WJH_SEVERITY_ERROR_E,
    "all": WJH_SEVERITY_ALL_E,
}

binding_point_to_str = {
    WJH_ACL_BINDING_POINT_INGRESS: 'Ingress port ACL',
    WJH_ACL_BINDING_POINT_EGRESS: 'Egress port ACL',
    WJH_ACL_BINDING_POINT_RIF_INGRESS: 'Ingress router ACL',
    WJH_ACL_BINDING_POINT_RIF_EGRESS: 'Egress router ACL'
}

agg_read_mode_str_to_enum = {
    "read_clear": WJH_AGGREGATION_READ_MODE_READ_CLEAR,
    "read": WJH_AGGREGATION_READ_MODE_READ
}

agg_key_mode_str_to_enum = {
    "streaming": WJH_AGGREGATION_KEY_MODE_STREAMING_E,
    "detailed": WJH_AGGREGATION_KEY_MODE_DETAILED_E
}

trap_group_mode_str_to_enum = {
    "static": WJH_TRAP_GROUP_ALLOCATE_MODE_STATIC_E,
    "dynamic": WJH_TRAP_GROUP_ALLOCATE_MODE_DYNAMIC_E
}

channel_timestamp_source_str_to_enum = {
    "linux": WJH_USER_CHANNEL_TIMESTAMP_SOURCE_LINUX_E,
    "hw_clock": WJH_USER_CHANNEL_TIMESTAMP_SOURCE_HW_CLOCK_E
}

channel_destination_str_to_enum = {
    "callback_and_drop_monitor": WJH_USER_CHANNEL_DESTINATION_CALLBACK_AND_DROP_MONITOR_E,
    "drop_monitor": WJH_USER_CHANNEL_DESTINATION_DROP_MONITOR_E
}

event_type_to_str = {
    WJH_EVENT_NONE_E: 'none',
    WJH_EVENT_PACKET_DROP_E: 'packet drop',
    WJH_EVENT_EXCEPTION_E: 'exception'
}

event_type_str_to_enum = {
    'none': WJH_EVENT_NONE_E,
    'packet drop': WJH_EVENT_PACKET_DROP_E,
    'exception': WJH_EVENT_EXCEPTION_E
}

drop_reason_group_to_channel = {}
WJH_MIRROR_CONG_INVALID = 0xFFFF
WJH_MIRROR_TCLASS_INVALID = 0x1F
WJH_MIRROR_LATENCY_INVALID = 0xFFFFFF

NVIDIA_WJH_HEADER = 'NVIDIA WJH'

WJH_META_DATA_SOURCE_PORT = 1
WJH_META_DATA_DEST_PORT = 2
WJH_META_DATA_ORIG_PACKET_SIZE = 3
WJH_META_DATA_DROP_GROUP = 4
WJH_META_DATA_DROP_REASON = 5
WJH_META_DATA_MIN = 1
WJH_META_DATA_MAX = 5

PCAP_VERSION_MAJOR = 2
PCAP_VERSION_MINOR = 4
PCAP_MAGIC = 0xa1b2c3d4
PCAP_ERRBUF_SIZE = 256
PCAP_MAX_SNAPLEN = 65535
LINKTYPE_USER15 = 162

WjhDeactiveCb = CFUNCTYPE(None)

raw_channel = 0
aggregation_channel = 0
cyclic_and_aggregation_channel = 0
tac_channel = 0
channel_mode = WJH_USER_CHANNEL_MODE_PUSH_E
channel_to_agg_read_mode = {}
channel_timestamp_source = WJH_USER_CHANNEL_TIMESTAMP_SOURCE_LINUX_E
channel_destination = WJH_USER_CHANNEL_DESTINATION_CALLBACK_AND_DROP_MONITOR_E

enable_print = False
enable_save = False
tac_span_session_id = None

pcap_fd = None
txt_fd = None
handle = -1  # SDK handle

pcap_user_fd = None
txt_user_fd = None
agg_json_fd = None

wjh_raw_file = WJH_PCAP_NAME
wjh_agg_file = WJH_TXT_NAME
wjh_agg_json_file = WJH_AGG_JSON_NAME

span_inited = False

# for aggregate json dump
# maximum size for json file reading
WJH_AGG_READ_LIMITS = (100 * 1024 * 1024)
l1_ret = []
l2_ret = []
acl_ret = []
buffer_ret = []
router_ret = []
tunnel_ret = []

tac_dst_ip = "10.200.2.2"
tac_src_ip = "10.2.2.2"
tac_dmac = "00:04:05:06:11:99"
tac_vlan = 1
tac_analyzer_port = 0x10005
tele_inited = False
chip_type = None


def is_tac_supported():
    if chip_type not in [SX_CHIP_TYPE_SPECTRUM, SX_CHIP_TYPE_SPECTRUM_A1, SX_CHIP_TYPE_SPECTRUM2, SX_CHIP_TYPE_SPECTRUM3]:
        return True
    return False


def tele_init():
    " This function init tele. "
    global tele_inited
    tele_param_p = new_sx_tele_init_params_t_p()
    rc = sx_api_tele_init_set(handle, tele_param_p)
    assert (SX_STATUS_SUCCESS == rc or SX_STATUS_ALREADY_INITIALIZED == rc), "tele init failed rc: %d" % (rc)
    if rc == SX_STATUS_SUCCESS:
        tele_inited = True


def tele_deinit():
    " This function deinit tele. "

    rc = sx_api_tele_deinit_set(handle)
    assert SX_STATUS_SUCCESS == rc, "tele deinit failed rc %d" % (rc)


def tele_attributes_set(internal_ts_enable=SX_TS_OVER_CRC_INGRESS_MODE_DISABLE_E, tac_enable=False):
    " This function set telemetry attributes. "

    tele_attr = sx_tele_attrib_t()
    tele_attr.internal_ts_enable = internal_ts_enable
    tac_attr = sx_tele_tac_attr_t()
    tac_attr.tac_mode = SX_TELE_TAC_MODE_TO_NETWORK_E
    tac_attr.tac_periodic_action_enabled = True
    tac_attr.tac_periodic_action = SX_TELE_TAC_ACTION_FLUSH_AND_REPORT_E
    tac_attr.tac_periodic_action_interval = 10
    tac_attr.tac_truncation_size = 0
    tele_attr.tac_attr_valid = tac_enable
    tele_attr.tac_attr = tac_attr
    rc = sx_api_tele_attributes_set(handle, tele_attr)
    assert SX_STATUS_SUCCESS == rc, "sx_api_tele_attributes_set rc %d" % (rc)
    return rc


class WjhDriverInitParam(ctypes.Structure):
    """Python class for c library structure wjh_driver_init_param_t"""
    _fields_ = [("trap_group_allocate_mode", ctypes.c_uint32)]


class WjhInitParam(Structure):
    _fields_ = [("force", c_uint8), ("deactive_cb", WjhDeactiveCb), ("bandwidth_percent", c_uint8),
                ("log_cb", c_void_p), ("conf_xml_path", c_char_p), ("debug_fs_path", c_char_p), ("ingress_info_type", c_int),
                ("aggregation_key_mode", c_int), ("driver_init_param", WjhDriverInitParam), ("trunc_profile_id", c_uint8)]


class WjhDropCounter(Structure):
    _fields_ = [("dropped", c_uint64), ("received", c_uint64)]


class WjhTimespec(Structure):
    _fields_ = [("tv_sec", c_long), ("tv_nsec", c_long)]


class WjhDropReason(Structure):
    _fields_ = [("id", c_uint32),
                ("reason", c_char_p),
                ("severity", c_int),
                ("description", c_char_p),
                ("event_type", c_int)]


class WjhDropBasicAttr(Structure):
    _fields_ = [("recirculation_port", c_uint32),
                ("truncate_size", c_uint16)]


class WjhDropAdvancedAttr(Structure):
    _fields_ = [("trap_probability", c_uint32),
                ("trap_id", c_uint32),
                ("ptp_disabled", c_uint32)]


class WjhBufferDropAttr(Structure):
    _fields_ = [("basic_attr", WjhDropBasicAttr),
                ("advanced_attr", WjhDropAdvancedAttr)]


class WjhDropReasonGroupAttrUnion(Union):
    _fields_ = [("buffer_drop", WjhBufferDropAttr)]


class WjhDropReasonGroupAttr(Structure):
    _fields_ = [("attr", WjhDropReasonGroupAttrUnion),
                ("max_aggregation_entries_cnt", c_uint32)]


class WjhUserChannelAttr(Structure):
    _fields_ = [("polling_interval", c_uint32),
                ("mode", c_int),
                ("aggregation_read_mode", c_int),
                ("timestamp_source", c_int),
                ("user_channel_dest", c_int),
                ("span_session_id", ctypes.c_uint8)]


class WjhDropAggregateAttr(Structure):
    _fields_ = [("mode", c_int)]


class WjhL2DropRawInfo(Structure):
    _fields_ = [("packet", c_void_p),
                ("packet_size", c_uint32),
                ("ingress_port", c_uint32),
                ("drop_reason", WjhDropReason),
                ("timestamp", WjhTimespec),
                ("is_lag_member", c_uint8),
                ("ingress_lag", c_uint32)]


WjhL2DropRawCb = CFUNCTYPE(c_int, POINTER(WjhL2DropRawInfo), POINTER(c_uint32))


class WjhRouterDropRawInfo(Structure):
    _fields_ = [("packet", c_void_p),
                ("packet_size", c_uint32),
                ("ingress_port", c_uint32),
                ("drop_reason", WjhDropReason),
                ("timestamp", WjhTimespec),
                ("is_lag_member", c_uint8),
                ("ingress_lag", c_uint32)]


WjhRouterDropRawCb = CFUNCTYPE(c_int, POINTER(WjhRouterDropRawInfo), POINTER(c_uint32))


class WjhTunnelDropRawInfo(Structure):
    _fields_ = [("packet", c_void_p),
                ("packet_size", c_uint32),
                ("ingress_port", c_uint32),
                ("drop_reason", WjhDropReason),
                ("timestamp", WjhTimespec),
                ("is_lag_member", c_uint8),
                ("ingress_lag", c_uint32)]


WjhTunnelDropRawCb = CFUNCTYPE(c_int, POINTER(WjhTunnelDropRawInfo), POINTER(c_uint32))


class WjhL1DropRawInfo(Structure):
    _fields_ = [("ingress_port", c_uint32),
                ("timestamp", WjhTimespec),
                ("reason", WjhDropReason)]


WjhL1DropRawCb = CFUNCTYPE(c_int, POINTER(WjhL1DropRawInfo), POINTER(c_uint32))


class WjhL1DropAggregateKey(Structure):
    _fields_ = [("ingress_port", c_uint32)]


class WjhAggregateTimestamp(Structure):
    _fields_ = [("first_timestamp", WjhTimespec), ("last_timestamp", WjhTimespec)]


class WjhL1DropAggregateData(Structure):
    _fields_ = [("is_port_up", c_uint8),
                ("port_down_reason", c_char_p),
                ("description", c_char_p),
                ("state_change_count", c_uint64),
                ("symbol_error_count", c_uint64),
                ("crc_error_count", c_uint64),
                ("timestamp", WjhAggregateTimestamp),
                ("port_state_change_reason", WjhDropReason),
                ("symbol_error_reason", WjhDropReason),
                ("crc_error_reason", WjhDropReason)]


WjhL1DropAggregateCb = CFUNCTYPE(c_int, POINTER(WjhL1DropAggregateKey), POINTER(WjhL1DropAggregateData), POINTER(c_uint32), POINTER(WjhDropAggregateAttr))


class WjhAclDropRawInfo(Structure):
    _fields_ = [("packet", c_void_p),
                ("packet_size", c_uint32),
                ("ingress_port", c_uint32),
                ("binding_point", c_int),
                ("rule_id", c_uint64),
                ("acl_name", c_char_p),
                ("rule", c_char_p),
                ("timestamp", WjhTimespec),
                ("is_lag_member", c_uint8),
                ("ingress_lag", c_uint32),
                ("drop_reason", WjhDropReason)]


WjhAclDropRawCb = CFUNCTYPE(c_int, POINTER(WjhAclDropRawInfo), POINTER(c_uint32))


class WjhBufferDropRawInfo(Structure):
    _fields_ = [("packet", ctypes.c_void_p),
                ("packet_size", ctypes.c_uint32),
                ("ingress_port", ctypes.c_uint32),
                ("egress_port", ctypes.c_uint32),
                ("tc", ctypes.c_uint8),
                ("drop_reason", WjhDropReason),
                ("timestamp", WjhTimespec),
                ("is_lag_member", ctypes.c_uint8),
                ("ingress_lag", ctypes.c_uint32),
                ("egress_port_valid", ctypes.c_uint8),
                ("is_egress_lag_member", ctypes.c_uint8),
                ("egress_lag", ctypes.c_uint32),
                ("original_occupancy", ctypes.c_uint16),
                ("original_latency", ctypes.c_uint32)]


WjhBufferDropRawCb = CFUNCTYPE(c_int, POINTER(WjhBufferDropRawInfo), POINTER(c_uint32))


class WjhAggregateFiveTuples(Structure):
    _fields_ = [("sip", c_char_p),
                ("dip", c_char_p),
                ("proto", c_uint8),
                ("sport", c_uint32),
                ("dport", c_uint32)]


class WjhBufferDropAggregateKey(Structure):
    _fields_ = [("five_tuples", WjhAggregateFiveTuples),
                ("non_ip", c_uint8),
                ("ingress_port", c_uint32),
                ("is_lag_member", ctypes.c_uint8),
                ("ingress_lag", ctypes.c_uint32),
                ("vlan", ctypes.c_uint16),
                ("ether_type", ctypes.c_uint16),
                ("dmac", c_uint8 * 6),
                ("smac", c_uint8 * 6),
                ("reason", WjhDropReason)]


class WjhBufferDropAggregateEgressData(Structure):
    _fields_ = [("egress_port", ctypes.c_uint32),
                ("tc", ctypes.c_uint8),
                ("is_egress_lag_member", ctypes.c_uint8),
                ("egress_lag", ctypes.c_uint32),
                ("port_tc_watermark", ctypes.c_uint16),
                ("latency_watermark", ctypes.c_uint32)]


class WjhBufferDropAggregateData(Structure):
    _fields_ = [("timestamp", WjhAggregateTimestamp),
                ("count", c_uint64),
                ("egress_data_valid", c_uint8),
                ("egress_data", WjhBufferDropAggregateEgressData)]


class WjhAclDropAggregateKey(Structure):
    _fields_ = [("five_tuples", WjhAggregateFiveTuples),
                ("non_ip", c_uint8),
                ("ingress_port", c_uint32),
                ("is_lag_member", ctypes.c_uint8),
                ("ingress_lag", ctypes.c_uint32),
                ("vlan", ctypes.c_uint16),
                ("ether_type", ctypes.c_uint16),
                ("dmac", c_uint8 * 6),
                ("smac", c_uint8 * 6),
                ("rule_id", c_uint64),
                ("acl_name", c_char_p),
                ("rule", c_char_p),
                ("reason", WjhDropReason)]


class WjhAclDropAggregateData(Structure):
    _fields_ = [("timestamp", WjhAggregateTimestamp),
                ("count", c_uint64),
                ("flows_num", c_uint64)]


class WjhL2DropAggregateKey(Structure):
    _fields_ = [("five_tuples", WjhAggregateFiveTuples),
                ("non_ip", c_uint8),
                ("ingress_port", c_uint32),
                ("is_lag_member", ctypes.c_uint8),
                ("ingress_lag", ctypes.c_uint32),
                ("vlan", ctypes.c_uint16),
                ("ether_type", ctypes.c_uint16),
                ("dmac", c_uint8 * 6),
                ("smac", c_uint8 * 6),
                ("reason", WjhDropReason)]


class WjhL2DropAggregateData(Structure):
    _fields_ = [("timestamp", WjhAggregateTimestamp),
                ("count", c_uint64)]


class WjhRouterDropAggregateKey(Structure):
    _fields_ = [("five_tuples", WjhAggregateFiveTuples),
                ("non_ip", c_uint8),
                ("ingress_port", c_uint32),
                ("is_lag_member", ctypes.c_uint8),
                ("ingress_lag", ctypes.c_uint32),
                ("vlan", ctypes.c_uint16),
                ("ether_type", ctypes.c_uint16),
                ("dmac", c_uint8 * 6),
                ("smac", c_uint8 * 6),
                ("reason", WjhDropReason)]


class WjhRouterDropAggregateData(Structure):
    _fields_ = [("timestamp", WjhAggregateTimestamp),
                ("count", c_uint64)]


class WjhTunnelDropAggregateKey(Structure):
    _fields_ = [("five_tuples", WjhAggregateFiveTuples),
                ("non_ip", c_uint8),
                ("ingress_port", c_uint32),
                ("is_lag_member", ctypes.c_uint8),
                ("ingress_lag", ctypes.c_uint32),
                ("vlan", ctypes.c_uint16),
                ("ether_type", ctypes.c_uint16),
                ("dmac", c_uint8 * 6),
                ("smac", c_uint8 * 6),
                ("reason", WjhDropReason)]


class WjhTunnelDropAggregateData(Structure):
    _fields_ = [("timestamp", WjhAggregateTimestamp),
                ("count", c_uint64)]


WjhBufferDropAggregateCb = CFUNCTYPE(c_int, POINTER(WjhBufferDropAggregateKey), POINTER(WjhBufferDropAggregateData), POINTER(c_uint32), POINTER(WjhDropAggregateAttr))
WjhAclDropAggregateCb = CFUNCTYPE(c_int, POINTER(WjhAclDropAggregateKey), POINTER(WjhAclDropAggregateData), POINTER(c_uint32), POINTER(WjhDropAggregateAttr))
WjhL2DropAggregateCb = CFUNCTYPE(c_int, POINTER(WjhL2DropAggregateKey), POINTER(WjhL2DropAggregateData), POINTER(c_uint32), POINTER(WjhDropAggregateAttr))
WjhRouterDropAggregateCb = CFUNCTYPE(c_int, POINTER(WjhRouterDropAggregateKey), POINTER(WjhRouterDropAggregateData), POINTER(c_uint32), POINTER(WjhDropAggregateAttr))
WjhTunnelDropAggregateCb = CFUNCTYPE(c_int, POINTER(WjhTunnelDropAggregateKey), POINTER(WjhTunnelDropAggregateData), POINTER(c_uint32), POINTER(WjhDropAggregateAttr))


def wjh_deactive_cb():
    print("This WJH client is deactivated by another WJH client")
    sys.exit(0)


def prepare_pcap(fd):
    thiszone = 0
    sigfigs = 0
    pcap_hdr = struct.pack('IHHIIII', PCAP_MAGIC, PCAP_VERSION_MAJOR, PCAP_VERSION_MINOR, thiszone, sigfigs, PCAP_MAX_SNAPLEN, LINKTYPE_USER15)
    fd.write(pcap_hdr)


def open_new_files():
    global pcap_fd, txt_fd

    pcap_fd = open(WJH_PCAP_NAME, "wb")
    txt_fd = open(WJH_TXT_NAME, "w")

    prepare_pcap(pcap_fd)


def save_packet_pcap(drop_reason_group, raw_info, packet):
    global pcap_fd, pcap_user_fd

    if pcap_user_fd:
        fd = pcap_user_fd
    else:
        fd = pcap_fd

    src_port = "0x%X" % raw_info.ingress_port
    dest_port = 'N/A'
    packet_size = str(raw_info.packet_size)
    drop_group = drop_reason_group_to_str[drop_reason_group]
    if drop_reason_group == WJH_DROP_REASON_GROUP_ACL_E:
        drop_reason = binding_point_to_str[raw_info.binding_point]
    else:
        drop_reason = raw_info.drop_reason.reason.decode()

    src_port_buf = struct.pack('BB', WJH_META_DATA_SOURCE_PORT, len(src_port)) + src_port.encode()
    dest_port_buf = struct.pack('BB', WJH_META_DATA_DEST_PORT, len(dest_port)) + dest_port.encode()
    packet_size_buf = struct.pack('BB', WJH_META_DATA_ORIG_PACKET_SIZE, len(packet_size)) + packet_size.encode()
    drop_group_buf = struct.pack('BB', WJH_META_DATA_DROP_GROUP, len(drop_group)) + drop_group.encode()
    drop_reason_buf = struct.pack('BB', WJH_META_DATA_DROP_REASON, len(drop_reason)) + drop_reason.encode()

    meta_data_buff = src_port_buf + dest_port_buf + packet_size_buf + drop_group_buf + drop_reason_buf

    wjhhdr_buf = NVIDIA_WJH_HEADER.encode()

    meta_data_len = len(meta_data_buff)
    nvidia_header_len = len(NVIDIA_WJH_HEADER)
    packet_len = raw_info.packet_size

    hdr_len = packet_len + nvidia_header_len + meta_data_len
    hdr_caplen = packet_len + nvidia_header_len + meta_data_len
    hdr_tv_sec = raw_info.timestamp.tv_sec
    hdr_tv_usec = raw_info.timestamp.tv_nsec // 1000000
    pkthdr_buf = struct.pack('IIII', hdr_tv_sec, hdr_tv_usec, hdr_caplen, hdr_len)

    packet_buf = packet

    fd.write(pkthdr_buf)
    fd.write(wjhhdr_buf)
    fd.write(meta_data_buff)
    fd.write(packet_buf)

    fd.flush()

    return


def wjh_print_raw_meta(drop_reason_group, raw_info):
    print("%s drop reason group: ingress port [0x%x], size[%d], id[%d], reason[%s], description[%s], severity[%s], event_type[%s], timestamp[%d.%d]."
          % (drop_reason_group_to_str[drop_reason_group],
              raw_info.ingress_port,
              raw_info.packet_size,
              raw_info.drop_reason.id,
              raw_info.drop_reason.reason.decode(),
              raw_info.drop_reason.description.decode(),
              severity_to_str[raw_info.drop_reason.severity],
              event_type_to_str[raw_info.drop_reason.event_type],
              raw_info.timestamp.tv_sec,
              raw_info.timestamp.tv_nsec))

    if drop_reason_group is WJH_DROP_REASON_GROUP_ACL_E:
        print("binding point[%s], rule_id(0x%x), acl_name[%s], rule{%s}"
              % (binding_point_to_str[raw_info.binding_point],
                  raw_info.rule_id,
                  raw_info.acl_name.decode(),
                  raw_info.rule.decode()))

    if drop_reason_group is WJH_DROP_REASON_GROUP_BUFFER_E:
        if raw_info.egress_port_valid:
            print("egress port [0x%x], " % raw_info.egress_port)
        if raw_info.original_occupancy != WJH_MIRROR_CONG_INVALID:
            print("Tclass Buffer Occupancy [%u] KB, " % (raw_info.original_occupancy * 8))
        if raw_info.tc != WJH_MIRROR_TCLASS_INVALID:
            print("Egress Tclass [%u], " % (raw_info.tc))
        if raw_info.original_latency != WJH_MIRROR_LATENCY_INVALID:
            print("Latency [%lu] nsec" % (raw_info.original_latency * 32))

    return


def wjh_process_raw_packet(drop_reason_group, raw_info_list_p, raw_info_list_size_p):
    list_size = raw_info_list_size_p.contents.value
    if enable_print:
        print("")
    for i in range(list_size):
        packet_size = raw_info_list_p[i].packet_size

        if enable_print:
            wjh_print_raw_meta(drop_reason_group, raw_info_list_p[i])

            packet = list((packet_size * ctypes.c_ubyte).from_address(raw_info_list_p[i].packet))

            if packet_size > 0:
                for ii in range(0, packet_size):
                    if (0 == ii % 16) and (ii > 0):
                        print("")
                    print("%02x" % packet[ii], end=" ")
                print("")

        if enable_save:
            buf = (ctypes.c_char * packet_size)()
            ctypes.memmove(buf, raw_info_list_p[i].packet, packet_size)
            packet_str = ctypes.string_at(buf, packet_size)
            save_packet_pcap(drop_reason_group, raw_info_list_p[i], packet_str)

    return 0


def wjh_l2_drop_raw_cb(raw_info_list_p, raw_info_list_size_p):
    rc = wjh_process_raw_packet(WJH_DROP_REASON_GROUP_L2_E, raw_info_list_p, raw_info_list_size_p)
    return rc


def wjh_router_drop_raw_cb(raw_info_list_p, raw_info_list_size_p):
    rc = wjh_process_raw_packet(WJH_DROP_REASON_GROUP_ROUTER_E, raw_info_list_p, raw_info_list_size_p)
    return rc


def wjh_tunnel_drop_raw_cb(raw_info_list_p, raw_info_list_size_p):
    rc = wjh_process_raw_packet(WJH_DROP_REASON_GROUP_TUNNEL_E, raw_info_list_p, raw_info_list_size_p)
    return rc


def wjh_acl_drop_raw_cb(raw_info_list_p, raw_info_list_size_p):
    rc = wjh_process_raw_packet(WJH_DROP_REASON_GROUP_ACL_E, raw_info_list_p, raw_info_list_size_p)
    return rc


def wjh_buffer_drop_raw_cb(raw_info_list_p, raw_info_list_size_p):
    rc = wjh_process_raw_packet(WJH_DROP_REASON_GROUP_BUFFER_E, raw_info_list_p, raw_info_list_size_p)
    return rc


def wjh_l1_drop_raw_cb(raw_info_list_p, raw_info_list_size_p):
    global txt_fd, txt_user_fd
    fd = None
    if enable_print:
        fd = sys.stdout
    if enable_save:
        if txt_user_fd:
            fd = txt_user_fd
        else:
            fd = txt_fd

    list_size = raw_info_list_size_p.contents.value

    if fd:
        print("", file=fd)
    for i in range(list_size):
        if fd:
            print("port 0x%x, timestamp[%ld.%ld], reason_str[%s], reason_id[%u], description[%s], severity[%s]" %
                  (raw_info_list_p[i].ingress_port, raw_info_list_p[i].timestamp.tv_sec,
                   raw_info_list_p[i].timestamp.tv_nsec, raw_info_list_p[i].reason.reason.decode(),
                   raw_info_list_p[i].reason.id, raw_info_list_p[i].reason.description.decode(),
                   severity_to_str[raw_info_list_p[i].reason.severity]), file=fd)

    if enable_save:
        txt_fd.flush()

    return 0


def wjh_save_aggregate_json(file_name=WJH_AGG_JSON_NAME):
    global l1_ret, l2_ret, acl_ret, buffer_ret, router_ret, tunnel_ret
    wjh_json_ret = {
        drop_reason_group_to_str[WJH_DROP_REASON_GROUP_L1_E]: l1_ret,
        drop_reason_group_to_str[WJH_DROP_REASON_GROUP_L2_E]: l2_ret,
        drop_reason_group_to_str[WJH_DROP_REASON_GROUP_ACL_E]: acl_ret,
        drop_reason_group_to_str[WJH_DROP_REASON_GROUP_BUFFER_E]: buffer_ret,
        drop_reason_group_to_str[WJH_DROP_REASON_GROUP_ROUTER_E]: router_ret,
        drop_reason_group_to_str[WJH_DROP_REASON_GROUP_TUNNEL_E]: tunnel_ret
    }
    write_json_str = json.dumps(wjh_json_ret, indent=4)
    with open(file_name, 'w') as json_file:
        json_file.write(write_json_str)
        json_file.flush()


def wjh_drop_aggregate_json_dump_clear():
    global l1_ret, l2_ret, acl_ret, buffer_ret, router_ret, tunnel_ret
    l1_ret = []
    l2_ret = []
    acl_ret = []
    buffer_ret = []
    router_ret = []
    tunnel_ret = []


def wjh_l1_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global l1_ret
    list_size = keys_cnt_p.contents.value
    for i in range(list_size):
        l1_rec = {
            "ingress_port": 0, "is_port_up": 0, "port_down_reason": None, "description": None,
            "state_change_count": 0, "symbol_error_count": 0, "crc_error_count": 0,
            "port_state_change_reason": None, "port_state_change_reason_id": 0,
            "port_state_change_reason_description": None, "port_state_change_reason_event_type": None,
            "crc_error_reason": None, "crc_error_reason_id": 0,
            "crc_error_reason_description": None, "crc_error_reason_event_type": None,
            "symbol_error_reason": None, "symbol_error_reason_id": 0,
            "symbol_error_reason_description": None, "symbol_error_reason_event_type": None,
            "timestamp": None, "user_channel_mode": 0
        }
        l1_rec["ingress_port"] = "0x%x" % key_list_p[i].ingress_port
        l1_rec["is_port_up"] = "%u" % data_list_p[i].is_port_up
        l1_rec["port_down_reason"] = data_list_p[i].port_down_reason.decode()
        l1_rec["description"] = data_list_p[i].description.decode()
        l1_rec["state_change_count"] = "%u" % data_list_p[i].state_change_count
        l1_rec["symbol_error_count"] = "%u" % data_list_p[i].symbol_error_count
        l1_rec["crc_error_count"] = "%u" % data_list_p[i].crc_error_count
        if data_list_p[i].state_change_count > 0:
            l1_rec["port_state_change_reason"] = data_list_p[i].port_state_change_reason.reason.decode()
            l1_rec["port_state_change_reason_id"] = "%u" % data_list_p[i].port_state_change_reason.id
            l1_rec["port_state_change_reason_description"] = data_list_p[i].port_state_change_reason.description.decode()
            l1_rec["port_state_change_reason_event_type"] = event_type_to_str[data_list_p[i].port_state_change_reason.event_type]
        if data_list_p[i].crc_error_count > 0:
            l1_rec["crc_error_reason"] = data_list_p[i].crc_error_reason.reason.decode()
            l1_rec["crc_error_reason_id"] = "%u" % data_list_p[i].crc_error_reason.id
            l1_rec["crc_error_reason_description"] = data_list_p[i].crc_error_reason.description.decode()
            l1_rec["crc_error_reason_event_type"] = event_type_to_str[data_list_p[i].crc_error_reason.event_type]
        if data_list_p[i].symbol_error_count > 0:
            l1_rec["symbol_error_reason"] = data_list_p[i].symbol_error_reason.reason.decode()
            l1_rec["symbol_error_reason_id"] = "%u" % data_list_p[i].symbol_error_reason.id
            l1_rec["symbol_error_reason_description"] = data_list_p[i].symbol_error_reason.description.decode()
            l1_rec["symbol_error_reason_event_type"] = event_type_to_str[data_list_p[i].symbol_error_reason.event_type]
        l1_rec["timestamp"] = "%ld.%ld %ld.%ld" % (data_list_p[i].timestamp.first_timestamp.tv_sec,
                                                   data_list_p[i].timestamp.first_timestamp.tv_nsec,
                                                   data_list_p[i].timestamp.last_timestamp.tv_sec,
                                                   data_list_p[i].timestamp.last_timestamp.tv_nsec)
        l1_rec["user_channel_mode"] = "%d" % (attr_p[0].mode)
        # copy the record to ret
        l1_ret.insert(0, l1_rec.copy())


def wjh_buffer_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global buffer_ret
    list_size = keys_cnt_p.contents.value
    for i in range(list_size):
        buffer_rec = {
            "sip": None, "dip": None, "proto": 0,
            "sport": 0, "dport": 0, "non_ip": 0,
            "reason": None, "event_type": 0,
            "ingress_port": 0, "is_lag_member": 0,
            "ingress_lag": 0, "vlan": 0,
            "ether_type": 0, "dmac": None,
            "smac": None, "count": 0,
            "timestamp": None, "user_channel_mode": 0
        }
        buffer_rec["sip"] = key_list_p[i].five_tuples.sip
        buffer_rec["dip"] = key_list_p[i].five_tuples.dip
        buffer_rec["proto"] = "%u" % key_list_p[i].five_tuples.proto
        buffer_rec["sport"] = "%u" % key_list_p[i].five_tuples.sport
        buffer_rec["dport"] = "%u" % key_list_p[i].five_tuples.dport
        buffer_rec["non_ip"] = "%u" % key_list_p[i].non_ip
        buffer_rec["reason"] = key_list_p[i].reason.reason.decode()
        buffer_rec["event_type"] = event_type_to_str[key_list_p[i].reason.event_type]
        buffer_rec["ingress_port"] = "0x%x" % key_list_p[i].ingress_port
        buffer_rec["is_lag_member"] = "%u" % key_list_p[i].is_lag_member
        buffer_rec["ingress_lag"] = "0x%x" % key_list_p[i].ingress_lag
        buffer_rec["vlan"] = "%u" % key_list_p[i].vlan
        buffer_rec["ether_type"] = "0x%x" % key_list_p[i].ether_type
        buffer_rec["dmac"] = "%02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].dmac[0], key_list_p[i].dmac[1], key_list_p[i].dmac[2],
                                                                key_list_p[i].dmac[3], key_list_p[i].dmac[4], key_list_p[i].dmac[5])
        buffer_rec["smac"] = "%02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].smac[0], key_list_p[i].smac[1], key_list_p[i].smac[2],
                                                                key_list_p[i].smac[3], key_list_p[i].smac[4], key_list_p[i].smac[5])
        buffer_rec["count"] = "%u" % data_list_p[i].count
        buffer_rec["timestamp"] = "%ld.%ld %ld.%ld" % (data_list_p[i].timestamp.first_timestamp.tv_sec,
                                                       data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                                                       data_list_p[i].timestamp.last_timestamp.tv_nsec)
        buffer_rec["user_channel_mode"] = "%d" % (attr_p[0].mode)
        # copy the record to ret
        buffer_ret.insert(0, buffer_rec.copy())


def wjh_acl_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global acl_ret
    list_size = keys_cnt_p.contents.value
    for i in range(list_size):
        acl_rec = {
            "sip": None, "dip": None, "proto": 0,
            "sport": 0, "dport": 0, "non_ip": 0,
            "reason": None, "event_type": 0,
            "ingress_port": 0, "is_lag_member": 0,
            "ingress_lag": 0, "vlan": 0,
            "ether_type": 0, "dmac": None,
            "smac": None, "rule_id": 0,
            "acl_name": None, "rule": None, "count": 0,
            "timestamp": None, "user_channel_mode": 0
        }
        acl_rec["sip"] = key_list_p[i].five_tuples.sip
        acl_rec["dip"] = key_list_p[i].five_tuples.dip
        acl_rec["proto"] = "%u" % key_list_p[i].five_tuples.proto
        acl_rec["sport"] = "%u" % key_list_p[i].five_tuples.sport
        acl_rec["dport"] = "%u" % key_list_p[i].five_tuples.dport
        acl_rec["non_ip"] = "%u" % key_list_p[i].non_ip
        acl_rec["reason"] = key_list_p[i].reason.reason.decode()
        acl_rec["event_type"] = event_type_to_str[key_list_p[i].reason.event_type]
        acl_rec["ingress_port"] = "0x%x" % key_list_p[i].ingress_port
        acl_rec["is_lag_member"] = "%u" % key_list_p[i].is_lag_member
        acl_rec["ingress_lag"] = "0x%x" % key_list_p[i].ingress_lag
        acl_rec["vlan"] = "%u" % key_list_p[i].vlan
        acl_rec["ether_type"] = "0x%x" % key_list_p[i].ether_type
        acl_rec["dmac"] = "%02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].dmac[0], key_list_p[i].dmac[1], key_list_p[i].dmac[2],
                                                             key_list_p[i].dmac[3], key_list_p[i].dmac[4], key_list_p[i].dmac[5])
        acl_rec["smac"] = "%02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].smac[0], key_list_p[i].smac[1], key_list_p[i].smac[2],
                                                             key_list_p[i].smac[3], key_list_p[i].smac[4], key_list_p[i].smac[5])
        acl_rec["rule_id"] = "%u" % key_list_p[i].rule_id
        acl_rec["acl_name"] = key_list_p[i].acl_name.decode()
        acl_rec["rule"] = key_list_p[i].rule.decode()
        acl_rec["count"] = "%u" % data_list_p[i].count
        acl_rec["timestamp"] = "%ld.%ld %ld.%ld" % (data_list_p[i].timestamp.first_timestamp.tv_sec,
                                                    data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                                                    data_list_p[i].timestamp.last_timestamp.tv_nsec)
        acl_rec["user_channel_mode"] = "%d" % (attr_p[0].mode)
        # copy the record to ret
        acl_ret.insert(0, acl_rec.copy())


def wjh_l2_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global l2_ret
    list_size = keys_cnt_p.contents.value
    for i in range(list_size):
        l2_rec = {
            "sip": None, "dip": None, "proto": 0,
            "sport": 0, "dport": 0, "non_ip": 0,
            "reason": None, "event_type": 0,
            "ingress_port": 0, "is_lag_member": 0,
            "ingress_lag": 0, "vlan": 0,
            "ether_type": 0, "dmac": None,
            "smac": None, "count": 0,
            "timestamp": None, "user_channel_mode": 0
        }
        l2_rec["sip"] = key_list_p[i].five_tuples.sip
        l2_rec["dip"] = key_list_p[i].five_tuples.dip
        l2_rec["proto"] = "%u" % key_list_p[i].five_tuples.proto
        l2_rec["sport"] = "%u" % key_list_p[i].five_tuples.sport
        l2_rec["dport"] = "%u" % key_list_p[i].five_tuples.dport
        l2_rec["non_ip"] = "%u" % key_list_p[i].non_ip
        l2_rec["reason"] = key_list_p[i].reason.reason.decode()
        l2_rec["event_type"] = event_type_to_str[key_list_p[i].reason.event_type]
        l2_rec["ingress_port"] = "0x%x" % key_list_p[i].ingress_port
        l2_rec["is_lag_member"] = "%u" % key_list_p[i].is_lag_member
        l2_rec["ingress_lag"] = "0x%x" % key_list_p[i].ingress_lag
        l2_rec["vlan"] = "%u" % key_list_p[i].vlan
        l2_rec["ether_type"] = "0x%x" % key_list_p[i].ether_type
        l2_rec["dmac"] = "%02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].dmac[0], key_list_p[i].dmac[1], key_list_p[i].dmac[2],
                                                            key_list_p[i].dmac[3], key_list_p[i].dmac[4], key_list_p[i].dmac[5])
        l2_rec["smac"] = "%02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].smac[0], key_list_p[i].smac[1], key_list_p[i].smac[2],
                                                            key_list_p[i].smac[3], key_list_p[i].smac[4], key_list_p[i].smac[5])
        l2_rec["count"] = "%u" % data_list_p[i].count
        l2_rec["timestamp"] = "%ld.%ld %ld.%ld" % (data_list_p[i].timestamp.first_timestamp.tv_sec,
                                                   data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                                                   data_list_p[i].timestamp.last_timestamp.tv_nsec)
        l2_rec["user_channel_mode"] = "%d" % (attr_p[0].mode)
        # copy the record to ret
        l2_ret.insert(0, l2_rec.copy())


def wjh_router_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global router_ret
    list_size = keys_cnt_p.contents.value
    for i in range(list_size):
        router_rec = {
            "sip": None, "dip": None, "proto": 0,
            "sport": 0, "dport": 0, "non_ip": 0,
            "reason": None, "event_type": 0,
            "ingress_port": 0, "is_lag_member": 0,
            "ingress_lag": 0, "vlan": 0,
            "ether_type": 0, "dmac": None,
            "smac": None, "count": 0,
            "timestamp": None, "user_channel_mode": 0
        }
        router_rec["sip"] = key_list_p[i].five_tuples.sip
        router_rec["dip"] = key_list_p[i].five_tuples.dip
        router_rec["proto"] = "%u" % key_list_p[i].five_tuples.proto
        router_rec["sport"] = "%u" % key_list_p[i].five_tuples.sport
        router_rec["dport"] = "%u" % key_list_p[i].five_tuples.dport
        router_rec["non_ip"] = "%u" % key_list_p[i].non_ip
        router_rec["reason"] = key_list_p[i].reason.reason.decode()
        router_rec["event_type"] = event_type_to_str[key_list_p[i].reason.event_type]
        router_rec["ingress_port"] = "0x%x" % key_list_p[i].ingress_port
        router_rec["is_lag_member"] = "%u" % key_list_p[i].is_lag_member
        router_rec["ingress_lag"] = "0x%x" % key_list_p[i].ingress_lag
        router_rec["vlan"] = "%u" % key_list_p[i].vlan
        router_rec["ether_type"] = "0x%x" % key_list_p[i].ether_type
        router_rec["dmac"] = "%02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].dmac[0], key_list_p[i].dmac[1], key_list_p[i].dmac[2],
                                                                key_list_p[i].dmac[3], key_list_p[i].dmac[4], key_list_p[i].dmac[5])
        router_rec["smac"] = "%02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].smac[0], key_list_p[i].smac[1], key_list_p[i].smac[2],
                                                                key_list_p[i].smac[3], key_list_p[i].smac[4], key_list_p[i].smac[5])
        router_rec["count"] = "%u" % data_list_p[i].count
        router_rec["timestamp"] = "%ld.%ld %ld.%ld" % (data_list_p[i].timestamp.first_timestamp.tv_sec,
                                                       data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                                                       data_list_p[i].timestamp.last_timestamp.tv_nsec)
        router_rec["user_channel_mode"] = "%d" % (attr_p[0].mode)
        # copy the record to ret
        router_ret.insert(0, router_rec.copy())


def wjh_tunnel_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global tunnel_ret
    list_size = keys_cnt_p.contents.value
    for i in range(list_size):
        tunnel_rec = {
            "sip": None, "dip": None, "proto": 0,
            "sport": 0, "dport": 0, "non_ip": 0,
            "reason": None, "event_type": 0,
            "ingress_port": 0, "is_lag_member": 0,
            "ingress_lag": 0, "vlan": 0,
            "ether_type": 0, "dmac": None,
            "smac": None, "count": 0,
            "timestamp": None, "user_channel_mode": 0
        }
        tunnel_rec["sip"] = key_list_p[i].five_tuples.sip
        tunnel_rec["dip"] = key_list_p[i].five_tuples.dip
        tunnel_rec["proto"] = "%u" % key_list_p[i].five_tuples.proto
        tunnel_rec["sport"] = "%u" % key_list_p[i].five_tuples.sport
        tunnel_rec["dport"] = "%u" % key_list_p[i].five_tuples.dport
        tunnel_rec["non_ip"] = "%u" % key_list_p[i].non_ip
        tunnel_rec["reason"] = key_list_p[i].reason.reason.decode()
        tunnel_rec["event_type"] = event_type_to_str[key_list_p[i].reason.event_type]
        tunnel_rec["ingress_port"] = "0x%x" % key_list_p[i].ingress_port
        tunnel_rec["is_lag_member"] = "%u" % key_list_p[i].is_lag_member
        tunnel_rec["ingress_lag"] = "0x%x" % key_list_p[i].ingress_lag
        tunnel_rec["vlan"] = "%u" % key_list_p[i].vlan
        tunnel_rec["ether_type"] = "0x%x" % key_list_p[i].ether_type
        tunnel_rec["dmac"] = "%02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].dmac[0], key_list_p[i].dmac[1], key_list_p[i].dmac[2],
                                                                key_list_p[i].dmac[3], key_list_p[i].dmac[4], key_list_p[i].dmac[5])
        tunnel_rec["smac"] = "%02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].smac[0], key_list_p[i].smac[1], key_list_p[i].smac[2],
                                                                key_list_p[i].smac[3], key_list_p[i].smac[4], key_list_p[i].smac[5])
        tunnel_rec["count"] = "%u" % data_list_p[i].count
        tunnel_rec["timestamp"] = "%ld.%ld %ld.%ld" % (data_list_p[i].timestamp.first_timestamp.tv_sec,
                                                       data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                                                       data_list_p[i].timestamp.last_timestamp.tv_nsec)
        tunnel_rec["user_channel_mode"] = "%d" % (attr_p[0].mode)
        # copy the record to ret
        tunnel_ret.insert(0, tunnel_rec.copy())


def wjh_l1_drop_aggregate_cb(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global txt_fd, txt_user_fd
    fd = None
    if enable_print:
        fd = sys.stdout
    if enable_save:
        if txt_user_fd:
            fd = txt_user_fd
        else:
            fd = txt_fd

    list_size = keys_cnt_p.contents.value

    if fd:
        print("", file=fd)
    for i in range(list_size):
        if fd:
            print("port 0x%x: is_port_up: %u, port_down_reason: %s, description: %s, state_change_count: %u" %
                  (key_list_p[i].ingress_port, data_list_p[i].is_port_up, data_list_p[i].port_down_reason.decode(),
                   data_list_p[i].description.decode(), data_list_p[i].state_change_count), file=fd)
            print("           symbol_error_count: %u, crc_error_count: %u" %
                  (data_list_p[i].symbol_error_count, data_list_p[i].crc_error_count), file=fd)
            if data_list_p[i].state_change_count > 0:
                print("           port_state_change_reason: reason[%s], reason_id[%u], description[%s], event_type[%s]" %
                      (data_list_p[i].port_state_change_reason.reason.decode(), data_list_p[i].port_state_change_reason.id,
                       data_list_p[i].port_state_change_reason.description.decode(), event_type_to_str[data_list_p[i].port_state_change_reason.event_type]),
                      file=fd)
            if data_list_p[i].crc_error_count > 0:
                print("           crc_error_reason: reason[%s], reason_id[%u], description[%s], event_type[%s]" %
                      (data_list_p[i].crc_error_reason.reason.decode(), data_list_p[i].crc_error_reason.id,
                       data_list_p[i].crc_error_reason.description.decode(), event_type_to_str[data_list_p[i].crc_error_reason.event_type]),
                      file=fd)
            if data_list_p[i].symbol_error_count > 0:
                print("           symbol_error_reason: reason[%s], reason_id[%u], description[%s], event_type[%s]" %
                      (data_list_p[i].symbol_error_reason.reason.decode(), data_list_p[i].symbol_error_reason.id,
                       data_list_p[i].symbol_error_reason.description.decode(), event_type_to_str[data_list_p[i].symbol_error_reason.event_type]),
                      file=fd)
            print("           timestamp[%ld.%ld, %ld.%ld]" % (data_list_p[i].timestamp.first_timestamp.tv_sec,
                                                              data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                                                              data_list_p[i].timestamp.last_timestamp.tv_nsec), file=fd)
            print("           user channel mode: %d" % (attr_p[0].mode), file=fd)

    if enable_save:
        txt_fd.flush()
    # generate aggregate json dump
    wjh_l1_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p)
    return 0


def wjh_buffer_drop_aggregate_cb(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global txt_fd, txt_user_fd
    fd = None
    if enable_print:
        fd = sys.stdout
    if enable_save:
        if txt_user_fd:
            fd = txt_user_fd
        else:
            fd = txt_fd

    list_size = keys_cnt_p.contents.value

    if fd:
        print("", file=fd)
    for i in range(list_size):
        if fd:
            print("sip [%s], dip [%s], proto [%u], sport [%u], dport [%u], non_ip [%u], reason [%s], event_type [%s]" %
                  (key_list_p[i].five_tuples.sip, key_list_p[i].five_tuples.dip, key_list_p[i].five_tuples.proto,
                   key_list_p[i].five_tuples.sport, key_list_p[i].five_tuples.dport, key_list_p[i].non_ip, key_list_p[i].reason.reason.decode(),
                   event_type_to_str[key_list_p[i].reason.event_type]), file=fd)
            print("ingress_port [0x%x] is_lag_member [%u] ingress_lag [0x%x] vlan [%u] ether_type [0x%x]" %
                  (key_list_p[i].ingress_port, key_list_p[i].is_lag_member, key_list_p[i].ingress_lag,
                   key_list_p[i].vlan, key_list_p[i].ether_type), file=fd)
            print("dmac: %02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].dmac[0], key_list_p[i].dmac[1], key_list_p[i].dmac[2],
                                                           key_list_p[i].dmac[3], key_list_p[i].dmac[4], key_list_p[i].dmac[5]), file=fd)
            print("smac: %02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].smac[0], key_list_p[i].smac[1], key_list_p[i].smac[2],
                                                           key_list_p[i].smac[3], key_list_p[i].smac[4], key_list_p[i].smac[5]), file=fd)
            print("           count [%u], timestamp [%ld.%ld %ld.%ld]" %
                  (data_list_p[i].count, data_list_p[i].timestamp.first_timestamp.tv_sec,
                   data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                   data_list_p[i].timestamp.last_timestamp.tv_nsec), file=fd)
            print("           user channel mode: %d" % (attr_p[0].mode), file=fd)

    if enable_save:
        txt_fd.flush()

    # generate aggregate json dump
    wjh_buffer_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p)
    return 0


def wjh_acl_drop_aggregate_cb(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global txt_fd, txt_user_fd
    fd = None
    if enable_print:
        fd = sys.stdout
    if enable_save:
        if txt_user_fd:
            fd = txt_user_fd
        else:
            fd = txt_fd

    list_size = keys_cnt_p.contents.value

    if fd:
        print("", file=fd)
    for i in range(list_size):
        if fd:
            print("sip [%s], dip [%s], proto [%u], sport [%u], dport [%u], non_ip [%u], reason [%s], event_type [%s]" %
                  (key_list_p[i].five_tuples.sip, key_list_p[i].five_tuples.dip, key_list_p[i].five_tuples.proto,
                   key_list_p[i].five_tuples.sport, key_list_p[i].five_tuples.dport, key_list_p[i].non_ip, key_list_p[i].reason.reason.decode(),
                   event_type_to_str[key_list_p[i].reason.event_type]), file=fd)
            print("ingress_port [0x%x] is_lag_member [%u] ingress_lag [0x%x] vlan [%u] ether_type [0x%x]" %
                  (key_list_p[i].ingress_port, key_list_p[i].is_lag_member, key_list_p[i].ingress_lag,
                   key_list_p[i].vlan, key_list_p[i].ether_type), file=fd)
            print("dmac: %02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].dmac[0], key_list_p[i].dmac[1], key_list_p[i].dmac[2],
                                                           key_list_p[i].dmac[3], key_list_p[i].dmac[4], key_list_p[i].dmac[5]), file=fd)
            print("smac: %02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].smac[0], key_list_p[i].smac[1], key_list_p[i].smac[2],
                                                           key_list_p[i].smac[3], key_list_p[i].smac[4], key_list_p[i].smac[5]), file=fd)
            print("rule_id [%u], acl_name [%s], rule [%s]" %
                  (key_list_p[i].rule_id, key_list_p[i].acl_name.decode(), key_list_p[i].rule.decode()), file=fd)
            print("           count [%u], timestamp [%ld.%ld %ld.%ld]" %
                  (data_list_p[i].count, data_list_p[i].timestamp.first_timestamp.tv_sec,
                   data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                   data_list_p[i].timestamp.last_timestamp.tv_nsec), file=fd)
            print("           user channel mode: %d" % (attr_p[0].mode), file=fd)

    if enable_save:
        txt_fd.flush()

    # generate aggregate json dump
    wjh_acl_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p)
    return 0


def wjh_l2_drop_aggregate_cb(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global txt_fd, txt_user_fd
    fd = None
    if enable_print:
        fd = sys.stdout
    if enable_save:
        if txt_user_fd:
            fd = txt_user_fd
        else:
            fd = txt_fd

    list_size = keys_cnt_p.contents.value

    if fd:
        print("", file=fd)
    for i in range(list_size):
        if fd:
            print("sip [%s], dip [%s], proto [%u], sport [%u], dport [%u], non_ip [%u], reason [%s], event_type [%s]" %
                  (key_list_p[i].five_tuples.sip, key_list_p[i].five_tuples.dip, key_list_p[i].five_tuples.proto,
                   key_list_p[i].five_tuples.sport, key_list_p[i].five_tuples.dport, key_list_p[i].non_ip, key_list_p[i].reason.reason.decode(),
                   event_type_to_str[key_list_p[i].reason.event_type]), file=fd)
            print("ingress_port [0x%x] is_lag_member [%u] ingress_lag [0x%x] vlan [%u] ether_type [0x%x]" %
                  (key_list_p[i].ingress_port, key_list_p[i].is_lag_member, key_list_p[i].ingress_lag,
                   key_list_p[i].vlan, key_list_p[i].ether_type), file=fd)
            print("dmac: %02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].dmac[0], key_list_p[i].dmac[1], key_list_p[i].dmac[2],
                                                           key_list_p[i].dmac[3], key_list_p[i].dmac[4], key_list_p[i].dmac[5]), file=fd)
            print("smac: %02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].smac[0], key_list_p[i].smac[1], key_list_p[i].smac[2],
                                                           key_list_p[i].smac[3], key_list_p[i].smac[4], key_list_p[i].smac[5]), file=fd)
            print("           count [%u], timestamp [%ld.%ld %ld.%ld]" %
                  (data_list_p[i].count, data_list_p[i].timestamp.first_timestamp.tv_sec,
                   data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                   data_list_p[i].timestamp.last_timestamp.tv_nsec), file=fd)
            print("           user channel mode: %d" % (attr_p[0].mode), file=fd)

    if enable_save:
        txt_fd.flush()

    # generate aggregate json dump
    wjh_l2_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p)
    return 0


def wjh_router_drop_aggregate_cb(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global txt_fd, txt_user_fd
    fd = None
    if enable_print:
        fd = sys.stdout
    if enable_save:
        if txt_user_fd:
            fd = txt_user_fd
        else:
            fd = txt_fd

    list_size = keys_cnt_p.contents.value

    if fd:
        print("", file=fd)
    for i in range(list_size):
        if fd:
            print("sip [%s], dip [%s], proto [%u], sport [%u], dport [%u], non_ip [%u], reason [%s], event_type [%s]" %
                  (key_list_p[i].five_tuples.sip, key_list_p[i].five_tuples.dip, key_list_p[i].five_tuples.proto,
                   key_list_p[i].five_tuples.sport, key_list_p[i].five_tuples.dport, key_list_p[i].non_ip, key_list_p[i].reason.reason.decode(),
                   event_type_to_str[key_list_p[i].reason.event_type]), file=fd)
            print("ingress_port [0x%x] is_lag_member [%u] ingress_lag [0x%x] vlan [%u] ether_type [0x%x]" %
                  (key_list_p[i].ingress_port, key_list_p[i].is_lag_member, key_list_p[i].ingress_lag,
                   key_list_p[i].vlan, key_list_p[i].ether_type), file=fd)
            print("dmac: %02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].dmac[0], key_list_p[i].dmac[1], key_list_p[i].dmac[2],
                                                           key_list_p[i].dmac[3], key_list_p[i].dmac[4], key_list_p[i].dmac[5]), file=fd)
            print("smac: %02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].smac[0], key_list_p[i].smac[1], key_list_p[i].smac[2],
                                                           key_list_p[i].smac[3], key_list_p[i].smac[4], key_list_p[i].smac[5]), file=fd)
            print("           count [%u], timestamp [%ld.%ld %ld.%ld]" %
                  (data_list_p[i].count, data_list_p[i].timestamp.first_timestamp.tv_sec,
                   data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                   data_list_p[i].timestamp.last_timestamp.tv_nsec), file=fd)
            print("           user channel mode: %d" % (attr_p[0].mode), file=fd)

    if enable_save:
        txt_fd.flush()

    # generate aggregate json dump
    wjh_router_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p)
    return 0


def wjh_tunnel_drop_aggregate_cb(key_list_p, data_list_p, keys_cnt_p, attr_p):
    global txt_fd, txt_user_fd
    fd = None
    if enable_print:
        fd = sys.stdout
    if enable_save:
        if txt_user_fd:
            fd = txt_user_fd
        else:
            fd = txt_fd

    list_size = keys_cnt_p.contents.value

    if fd:
        print("", file=fd)
    for i in range(list_size):
        if fd:
            print("sip [%s], dip [%s], proto [%u], sport [%u], dport [%u], non_ip [%u], reason [%s], event_type [%s]" %
                  (key_list_p[i].five_tuples.sip, key_list_p[i].five_tuples.dip, key_list_p[i].five_tuples.proto,
                   key_list_p[i].five_tuples.sport, key_list_p[i].five_tuples.dport, key_list_p[i].non_ip, key_list_p[i].reason.reason.decode(),
                   event_type_to_str[key_list_p[i].reason.event_type]), file=fd)
            print("ingress_port [0x%x] is_lag_member [%u] ingress_lag [0x%x] vlan [%u] ether_type [0x%x]" %
                  (key_list_p[i].ingress_port, key_list_p[i].is_lag_member, key_list_p[i].ingress_lag,
                   key_list_p[i].vlan, key_list_p[i].ether_type), file=fd)
            print("dmac: %02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].dmac[0], key_list_p[i].dmac[1], key_list_p[i].dmac[2],
                                                           key_list_p[i].dmac[3], key_list_p[i].dmac[4], key_list_p[i].dmac[5]), file=fd)
            print("smac: %02x:%02x:%02x:%02x:%02x:%02x" % (key_list_p[i].smac[0], key_list_p[i].smac[1], key_list_p[i].smac[2],
                                                           key_list_p[i].smac[3], key_list_p[i].smac[4], key_list_p[i].smac[5]), file=fd)
            print("           count [%u], timestamp [%ld.%ld %ld.%ld]" %
                  (data_list_p[i].count, data_list_p[i].timestamp.first_timestamp.tv_sec,
                   data_list_p[i].timestamp.first_timestamp.tv_nsec, data_list_p[i].timestamp.last_timestamp.tv_sec,
                   data_list_p[i].timestamp.last_timestamp.tv_nsec), file=fd)
            print("           user channel mode: %d" % (attr_p[0].mode), file=fd)

    if enable_save:
        txt_fd.flush()

    # generate aggregate json dump
    wjh_tunnel_drop_aggregate_json_dump(key_list_p, data_list_p, keys_cnt_p, attr_p)
    return 0


class RawCallback(Union):
    _fields_ = [("buffer", WjhBufferDropRawCb),
                ("acl", WjhAclDropRawCb),
                ("router", WjhRouterDropRawCb),
                ("L2", WjhL2DropRawCb),
                ("L1", WjhL1DropRawCb),
                ("tunnel", WjhTunnelDropRawCb)]


class AggregateCallback(Union):
    _fields_ = [("buffer", WjhBufferDropAggregateCb),
                ("acl", WjhAclDropAggregateCb),
                ("router", WjhRouterDropAggregateCb),
                ("L2", WjhL2DropAggregateCb),
                ("L1", WjhL1DropAggregateCb),
                ("tunnel", WjhTunnelDropAggregateCb)]


class WjhDropCallbacks(Structure):
    _fields_ = [("drop_reason_group", c_int),
                ("raw_cb", RawCallback),
                ("aggregate_cb", AggregateCallback)]


def create_user_channel(channel_type):
    user_channel = c_uint32()
    rc = wjh_lib.wjh_user_channel_create(channel_type, byref(user_channel))

    return user_channel.value


def get_counter(user_channel_id):
    drop_counter = WjhDropCounter()

    rc = wjh_lib.wjh_counter_get(user_channel_id, byref(drop_counter), 0)

    print("channel[%d]: drop_counter [%d], receive_counter [%d]" % (user_channel_id, drop_counter.dropped, drop_counter.received))

    return drop_counter.dropped, drop_counter.received


def get_global_counter():
    drop_counter = WjhDropCounter()

    rc = wjh_lib.wjh_global_counter_get(byref(drop_counter), 0)

    print("global: drop_counter [%d], receive_counter [%d]" % (drop_counter.dropped, drop_counter.received))

    return drop_counter.dropped, drop_counter.received


def configure_drop_reason_group(drop_reason_group):
    channel_id = raw_channel
    drop_reason_group_to_channel[drop_reason_group] = channel_id
    rc = wjh_lib.wjh_drop_reason_group_bind(drop_reason_group, channel_id)

    rc = wjh_lib.wjh_drop_reason_group_enable(drop_reason_group, WJH_SEVERITY_ALL_E)


def deconfigure_drop_reason_group(drop_reason_group):
    rc = wjh_lib.wjh_drop_reason_group_disable(drop_reason_group, WJH_SEVERITY_ALL_E)

    rc = wjh_lib.wjh_drop_reason_group_unbind(drop_reason_group)

    rc = wjh_lib.wjh_drop_reason_group_deinit(drop_reason_group)

# configure loopback mode for recirculation port


def configure_recirculation_port_loopback_mode(port):
    global handle
    rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
    assert rc == 0, "Failed to bring down the port"
    sx_api_port_phys_loopback_set(handle, port, SX_PORT_PHYS_LOOPBACK_ENABLE_INTERNAL)
    assert rc == 0, "Failed to put the port in loopback mode"
    sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)
    assert rc == 0, "Failed to bring up the port"


# disable loopback mode for recirculation port
def deconfigure_recirculation_port_loopback_mode(port):
    global handle
    rc = sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_DOWN)
    assert rc == 0, "Failed to bring down the port"
    sx_api_port_phys_loopback_set(handle, port, SX_PORT_PHYS_LOOPBACK_DISABLE)
    assert rc == 0, "Failed to put the port in loopback mode"
    sx_api_port_state_set(handle, port, SX_PORT_ADMIN_STATUS_UP)
    assert rc == 0, "Failed to bring up the port"

# configure recirculation port's loopback, buffer and SP mapping


def configure_recirculation_port(analyzer_port):
    configure_recirculation_port_loopback_mode(analyzer_port)
    configure_recirculation_port_pg_tc_map(analyzer_port)
    configure_recirculation_port_buffer(analyzer_port)


# revert recirculation port's loopback, buffer and SP mapping
def deconfigure_recirculation_port(analyzer_port):
    deconfigure_recirculation_port_loopback_mode(analyzer_port)
    deconfigure_recirculation_port_pg_tc_map(analyzer_port)
    deconfigure_recirculation_port_buffer(analyzer_port)


# configure Switch Priority to PG and TC mapping
def configure_recirculation_port_pg_tc_map(analyzer_port):

    global def_prio_to_pg_mapping
    port = analyzer_port
    def_prio_to_pg_mapping = cos_port_pg_prio_buff_map_get(handle, port)

    new_prio_to_pg_mapping = {}
    for sp in range(0, PORT_PRIO_MAX):
        new_prio_to_pg_mapping[sp] = RECYCLE_PORT_PG_TC

    # set the new priority to PG mapping
    cos_port_prio_buff_map_to_pg(handle, port, prio_to_buff_dict=new_prio_to_pg_mapping)

    new_prio_to_tc_mapping = {}
    for sp in range(0, PORT_PRIO_MAX):
        new_prio_to_tc_mapping[sp] = RECYCLE_PORT_PG_TC
        # get the existing TC mapping
        prio_to_tc_mapping[sp] = cos_port_tc_prio_map_get(handle, port, sp)
        # set the new SP to TC mapping
        cos_port_prio_buff_map_to_tc(handle, port, sp, new_prio_to_tc_mapping[sp])

# Revert Switch Priority to PG and TC  mapping


def deconfigure_recirculation_port_pg_tc_map(analyzer_port):
    global def_prio_to_pg_mapping
    global prio_to_tc_mapping
    port = analyzer_port
    # revert the priority to PG mapping
    cos_port_prio_buff_map_to_pg(handle, port, prio_to_buff_dict=def_prio_to_pg_mapping)

    for sp in range(0, PORT_PRIO_MAX):
        # set the new SP to TC mapping
        cos_port_prio_buff_map_to_tc(handle, port, sp, prio_to_tc_mapping[sp])

# configure recirculation port buffer settings.


def configure_def_pool_id(handle, pool_info):

    assert SX_COS_POOL_INFO_MIN <= pool_info <= SX_COS_POOL_INFO_MAX, "pool_info type is invalid"

    try:
        pool_cnt_p = copy_uint32_t_p(0)
        rc = sx_api_cos_pools_list_get(handle, pool_cnt_p, None)
        assert rc == 0, "Failed to get cos pools list"
        pools_count = uint32_t_p_value(pool_cnt_p)

        pool_list_p = new_sx_cos_pool_id_t_arr(pools_count)

        rc = sx_api_cos_pools_list_get(handle, pool_cnt_p, pool_list_p)
        assert rc == 0, "Failed to get cos pools list"

        pools_list = []
        for i in range(pools_count):
            pools_list.append(sx_cos_pool_id_t_arr_getitem(pool_list_p, i))

        pool_attr_p = new_sx_cos_pool_attr_t_p()
        for pool_id in pools_list:
            rc = sx_api_cos_shared_buff_pool_get(handle, pool_id, pool_attr_p)
            assert rc == 0, "Failed to get pool_attr_p"
            pool_attr = sx_cos_pool_attr_t_p_value(pool_attr_p)

            if pool_attr.pool_info == pool_info:
                return pool_id

        print("No user-defined pool_id found")
        return SX_COS_POOL_ID_INVALID

    finally:
        delete_uint32_t_p(pool_cnt_p)
        delete_sx_cos_pool_id_t_arr(pool_list_p)
        delete_sx_cos_pool_attr_t_p(pool_attr_p)


def configure_recirculation_port_buffer(analyzer_port):
    global port_def_pg_buffer, port_def_pg_desc_buffer, port_def_tc_buffer, port_def_tc_desc_buffer
    global port_def_ing_port_buffer, port_def_egr_port_buffer, port_def_ing_port_desc_buffer, port_def_egr_port_desc_buffer
    global port_def_pg_shared_buffer, port_def_pg_desc_shared_buffer, port_def_tc_shared_buffer, port_def_tc_desc_shared_buffer
    global port_def_ing_port_shared_buffer, port_def_egr_port_shared_buffer, port_def_ing_port_desc_shared_buffer, port_def_egr_port_desc_shared_buffer
    global def_prio_to_pg_mapping, prio_to_tc_mapping, handle

    # get default pool_id's per type
    in_pool_id = configure_def_pool_id(handle, SX_COS_POOL_INFO_DEFAULT_DATA_INGRESS_E)
    eg_pool_id = configure_def_pool_id(handle, SX_COS_POOL_INFO_DEFAULT_DATA_EGRESS_E)
    in_desc_pool_id = configure_def_pool_id(handle, SX_COS_POOL_INFO_DEFAULT_DESCRIPTOR_INGRESS_E)
    eg_desc_pool_id = configure_def_pool_id(handle, SX_COS_POOL_INFO_DEFAULT_DESCRIPTOR_EGRESS_E)

    buff_mode = SX_COS_BUFFER_MAX_MODE_DYNAMIC_E
    alpha0 = SX_COS_PORT_BUFF_ALPHA_0_E
    port = analyzer_port
    cmd = SX_ACCESS_CMD_SET

    data_res_size = ((128 * 1024) // 96)
    desc_res_size = 128

    port_buffer_attr_item = sx_cos_port_buffer_attr_t()
    port_shared_buffer_attr_item = sx_cos_port_shared_buffer_attr_t()

    # Save current configuration of ingress/egress port and desc reserved/shared buffers.
    # set the new configuration for analyzer port
    buff_type = SX_COS_INGRESS_PORT_ATTR_E
    port_buffer_attr_item = get_reserved_buffer_attributes(handle, port, buff_type, in_pool_id)
    port_def_ing_port_buffer = port_buffer_attr_item
    port_shared_buffer_attr_item = get_shared_buffer_attributes(handle, port, buff_type, in_pool_id)
    port_def_ing_port_shared_buffer = port_shared_buffer_attr_item
    modify_port_reserved_buffer(handle, cmd, port, buff_type, in_pool_id, size=data_res_size)
    modify_port_shared_buffer(handle, cmd, port, buff_type, in_pool_id, mode=buff_mode, alpha=alpha0)

    buff_type = SX_COS_EGRESS_PORT_ATTR_E
    port_buffer_attr_item = get_reserved_buffer_attributes(handle, port, buff_type, eg_pool_id)
    port_def_egr_port_buffer = port_buffer_attr_item
    port_shared_buffer_attr_item = get_shared_buffer_attributes(handle, port, buff_type, eg_pool_id)
    port_def_egr_port_shared_buffer = port_shared_buffer_attr_item
    modify_port_reserved_buffer(handle, cmd, port, buff_type, eg_pool_id, size=data_res_size)
    modify_port_shared_buffer(handle, cmd, port, buff_type, eg_pool_id, mode=buff_mode, alpha=alpha0)

    buff_type = SX_COS_PORT_BUFF_ATTR_RESERVED1_E
    port_buffer_attr_item = get_reserved_buffer_attributes(handle, port, buff_type, in_desc_pool_id)
    port_def_ing_port_desc_buffer = port_buffer_attr_item
    port_shared_buffer_attr_item = get_shared_buffer_attributes(handle, port, buff_type, in_desc_pool_id)
    port_def_ing_port_desc_shared_buffer = port_shared_buffer_attr_item
    modify_port_reserved_buffer(handle, cmd, port, buff_type, in_desc_pool_id, size=desc_res_size)
    modify_port_shared_buffer(handle, cmd, port, buff_type, in_desc_pool_id, mode=buff_mode, alpha=alpha0)

    buff_type = SX_COS_PORT_BUFF_ATTR_RESERVED3_E
    port_buffer_attr_item = get_reserved_buffer_attributes(handle, port, buff_type, eg_desc_pool_id)
    port_def_egr_port_desc_buffer = port_buffer_attr_item
    port_shared_buffer_attr_item = get_shared_buffer_attributes(handle, port, buff_type, eg_desc_pool_id)
    port_def_egr_port_desc_shared_buffer = port_shared_buffer_attr_item
    modify_port_reserved_buffer(handle, cmd, port, buff_type, eg_desc_pool_id, size=desc_res_size)
    modify_port_shared_buffer(handle, cmd, port, buff_type, eg_desc_pool_id, mode=buff_mode, alpha=alpha0)

    # Save current configuration of TC/PG and desc reserved/shared buffers
    # set the new configuration for analyzer port
    for tc_pg in range(0, 8):
        if tc_pg == RECYCLE_PORT_PG_TC:
            data_res_size = 128 * 1024 // 96
            desc_res_size = 128
        else:
            data_res_size = 0
            desc_res_size = 0

        buff_type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
        port_buffer_attr_item = get_reserved_buffer_attributes(handle, port, buff_type, tc_pg)
        sx_cos_port_buffer_attr_t_arr_setitem(port_def_pg_buffer, tc_pg, port_buffer_attr_item)
        port_shared_buffer_attr_item = get_shared_buffer_attributes(handle, port, buff_type, tc_pg)
        sx_cos_port_shared_buffer_attr_t_arr_setitem(port_def_pg_shared_buffer, tc_pg, port_shared_buffer_attr_item)
        modify_port_reserved_buffer(handle, cmd, port, buff_type, tc_pg, size=data_res_size)
        modify_port_shared_buffer(handle, cmd, port, buff_type, tc_pg, pool_id=in_pool_id, mode=buff_mode, alpha=alpha0)

        buff_type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
        port_buffer_attr_item = get_reserved_buffer_attributes(handle, port, buff_type, tc_pg)
        sx_cos_port_buffer_attr_t_arr_setitem(port_def_tc_buffer, tc_pg, port_buffer_attr_item)
        port_shared_buffer_attr_item = get_shared_buffer_attributes(handle, port, buff_type, tc_pg)
        sx_cos_port_shared_buffer_attr_t_arr_setitem(port_def_tc_shared_buffer, tc_pg, port_shared_buffer_attr_item)
        modify_port_reserved_buffer(handle, cmd, port, buff_type, tc_pg, size=data_res_size)
        modify_port_shared_buffer(handle, cmd, port, buff_type, tc_pg, pool_id=eg_pool_id, mode=buff_mode, alpha=alpha0)

        buff_type = SX_COS_PORT_BUFF_ATTR_RESERVED2_E
        port_buffer_attr_item = get_reserved_buffer_attributes(handle, port, buff_type, tc_pg)
        sx_cos_port_buffer_attr_t_arr_setitem(port_def_pg_desc_buffer, tc_pg, port_buffer_attr_item)
        port_shared_buffer_attr_item = get_shared_buffer_attributes(handle, port, buff_type, tc_pg)
        sx_cos_port_shared_buffer_attr_t_arr_setitem(port_def_pg_desc_shared_buffer, tc_pg, port_shared_buffer_attr_item)
        modify_port_reserved_buffer(handle, cmd, port, buff_type, tc_pg, size=desc_res_size)
        modify_port_shared_buffer(handle, cmd, port, buff_type, tc_pg, pool_id=in_desc_pool_id, mode=buff_mode, alpha=alpha0)

        buff_type = SX_COS_PORT_BUFF_ATTR_RESERVED4_E
        port_buffer_attr_item = get_reserved_buffer_attributes(handle, port, buff_type, tc_pg)
        sx_cos_port_buffer_attr_t_arr_setitem(port_def_tc_desc_buffer, tc_pg, port_buffer_attr_item)
        port_shared_buffer_attr_item = get_shared_buffer_attributes(handle, port, buff_type, tc_pg)
        sx_cos_port_shared_buffer_attr_t_arr_setitem(port_def_tc_desc_shared_buffer, tc_pg, port_shared_buffer_attr_item)
        modify_port_reserved_buffer(handle, cmd, port, buff_type, tc_pg, size=desc_res_size)
        modify_port_shared_buffer(handle, cmd, port, buff_type, tc_pg, pool_id=eg_desc_pool_id, mode=buff_mode, alpha=alpha0)


# revert recirculation port buffer configuration.
def deconfigure_recirculation_port_buffer(analyzer_port):

    global port_def_pg_buffer, port_def_pg_desc_buffer, port_def_tc_buffer, port_def_tc_desc_buffer
    global port_def_ing_port_buffer, port_def_egr_port_buffer, port_def_ing_port_desc_buffer, port_def_egr_port_desc_buffer
    global port_def_pg_shared_buffer, port_def_pg_desc_shared_buffer, port_def_tc_shared_buffer, port_def_tc_desc_shared_buffer
    global port_def_ing_port_shared_buffer, port_def_egr_port_shared_buffer, port_def_ing_port_desc_shared_buffer, port_def_egr_port_desc_shared_buffer
    global def_prio_to_pg_mapping, prio_to_tc_mapping

    port = analyzer_port
    cmd = SX_ACCESS_CMD_SET

    port_buffer_attr_item = sx_cos_port_buffer_attr_t()
    port_shared_buffer_attr_item = sx_cos_port_shared_buffer_attr_t()
    # Revert the ingress/egress port and desc reserved and shared buffer configuration.
    buff_type = SX_COS_INGRESS_PORT_ATTR_E
    size = port_def_ing_port_buffer.attr.ingress_port_buff_attr.size
    pool_id = port_def_ing_port_buffer.attr.ingress_port_buff_attr.pool_id
    modify_port_reserved_buffer(handle, cmd, port, buff_type, pool_id, size)
    buff_mode = port_def_ing_port_shared_buffer.attr.ingress_port_shared_buff_attr.max.mode
    alpha_val = port_def_ing_port_shared_buffer.attr.ingress_port_shared_buff_attr.max.max.alpha
    modify_port_shared_buffer(handle, cmd, port, buff_type, pool_id, mode=buff_mode, alpha=alpha_val)

    buff_type = SX_COS_EGRESS_PORT_ATTR_E
    size = port_def_egr_port_buffer.attr.egress_port_buff_attr.size
    pool_id = port_def_egr_port_buffer.attr.egress_port_buff_attr.pool_id
    modify_port_reserved_buffer(handle, cmd, port, buff_type, pool_id, size)
    buff_mode = port_def_egr_port_shared_buffer.attr.egress_port_shared_buff_attr.max.mode
    alpha_val = port_def_egr_port_shared_buffer.attr.egress_port_shared_buff_attr.max.max.alpha
    modify_port_shared_buffer(handle, cmd, port, buff_type, pool_id, mode=buff_mode, alpha=alpha_val)

    buff_type = SX_COS_PORT_BUFF_ATTR_RESERVED1_E
    size = port_def_ing_port_desc_buffer.attr.ingress_port_buff_attr.size
    pool_id = port_def_ing_port_desc_buffer.attr.ingress_port_buff_attr.pool_id
    modify_port_reserved_buffer(handle, cmd, port, buff_type, pool_id, size)
    buff_mode = port_def_ing_port_desc_shared_buffer.attr.ingress_port_shared_buff_attr.max.mode
    alpha_val = port_def_ing_port_desc_shared_buffer.attr.ingress_port_shared_buff_attr.max.max.alpha
    modify_port_shared_buffer(handle, cmd, port, buff_type, pool_id, mode=buff_mode, alpha=alpha_val)

    buff_type = SX_COS_PORT_BUFF_ATTR_RESERVED3_E
    size = port_def_egr_port_desc_buffer.attr.egress_port_buff_attr.size
    pool_id = port_def_egr_port_desc_buffer.attr.egress_port_buff_attr.pool_id
    modify_port_reserved_buffer(handle, cmd, port, buff_type, pool_id, size)
    buff_mode = port_def_egr_port_desc_shared_buffer.attr.egress_port_shared_buff_attr.max.mode
    alpha_val = port_def_egr_port_desc_shared_buffer.attr.egress_port_shared_buff_attr.max.max.alpha
    modify_port_shared_buffer(handle, cmd, port, buff_type, pool_id, mode=buff_mode, alpha=alpha_val)

    # Revert configuration of shared and resreved buffers and desc buffers for tc/pg
    for tc_pg in range(0, 8):
        buff_type = SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E
        port_buffer_attr_item = sx_cos_port_buffer_attr_t_arr_getitem(port_def_pg_buffer, tc_pg)
        size = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.size
        pool_id = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pool_id
        is_lossy = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.is_lossy
        xon = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.xon
        xoff = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.xoff
        latency_override = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pipeline_latency.override_default
        latency_size = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pipeline_latency.size
        modify_port_reserved_buffer(handle, cmd, port, buff_type, tc_pg, size, is_lossy=is_lossy, xon=xon,
                                    xoff=xoff, pipeline_latency_override=latency_override, pipeline_latency_size=latency_size)
        port_shared_buffer_attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_def_pg_shared_buffer, tc_pg)
        buff_mode = port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode
        alpha_val = port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha
        modify_port_shared_buffer(handle, cmd, port, buff_type, tc_pg, pool_id=pool_id, mode=buff_mode, alpha=alpha_val)

        buff_type = SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E
        port_buffer_attr_item = sx_cos_port_buffer_attr_t_arr_getitem(port_def_tc_buffer, tc_pg)
        size = port_buffer_attr_item.attr.egress_port_tc_buff_attr.size
        pool_id = port_buffer_attr_item.attr.egress_port_tc_buff_attr.pool_id
        modify_port_reserved_buffer(handle, cmd, port, buff_type, tc_pg, size)
        port_shared_buffer_attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_def_tc_shared_buffer, tc_pg)
        buff_mode = port_shared_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.max.mode
        alpha_val = port_shared_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.max.max.alpha
        modify_port_shared_buffer(handle, cmd, port, buff_type, tc_pg, pool_id=pool_id, mode=buff_mode, alpha=alpha_val)

        buff_type = SX_COS_PORT_BUFF_ATTR_RESERVED2_E
        port_buffer_attr_item = sx_cos_port_buffer_attr_t_arr_getitem(port_def_pg_desc_buffer, tc_pg)
        size = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.size
        pool_id = port_buffer_attr_item.attr.ingress_port_pg_buff_attr.pool_id
        modify_port_reserved_buffer(handle, cmd, port, buff_type, tc_pg, size)
        port_shared_buffer_attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_def_pg_desc_shared_buffer, tc_pg)
        buff_mode = port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.mode
        alpha_val = port_shared_buffer_attr_item.attr.ingress_port_pg_shared_buff_attr.max.max.alpha
        modify_port_shared_buffer(handle, cmd, port, buff_type, tc_pg, pool_id=pool_id, mode=buff_mode, alpha=alpha_val)

        buff_type = SX_COS_PORT_BUFF_ATTR_RESERVED4_E
        port_buffer_attr_item = sx_cos_port_buffer_attr_t_arr_getitem(port_def_tc_desc_buffer, tc_pg)
        size = port_buffer_attr_item.attr.egress_port_tc_buff_attr.size
        pool_id = port_buffer_attr_item.attr.egress_port_tc_buff_attr.pool_id
        modify_port_reserved_buffer(handle, cmd, port, buff_type, tc_pg, size)
        port_shared_buffer_attr_item = sx_cos_port_shared_buffer_attr_t_arr_getitem(port_def_tc_desc_shared_buffer, tc_pg)
        buff_mode = port_shared_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.max.mode
        alpha_val = port_shared_buffer_attr_item.attr.egress_port_tc_shared_buff_attr.max.max.alpha
        modify_port_shared_buffer(handle, cmd, port, buff_type, tc_pg, pool_id=pool_id, mode=buff_mode, alpha=alpha_val)


# API to get SP to PG mapping
def cos_port_pg_prio_buff_map_get(handle, log_port):
    prio_to_buff_get_p = new_sx_cos_port_prio_buff_t_p()
    try:
        rc = sx_api_cos_port_prio_buff_map_get(handle, log_port, prio_to_buff_get_p)
        assert rc == 0, "Failed to get pg, switch priority mapping"
        return {prio: sx_cos_port_buff_t_arr_getitem(prio_to_buff_get_p.prio_to_buff, prio) for prio in
                range(PORT_PRIO_MAX)}
    finally:
        delete_sx_cos_port_prio_buff_t_p(prio_to_buff_get_p)

# API to set SP to PG mapping


def cos_port_prio_buff_map_to_pg(handle, port, prio_id=0, pg_buffer_id=0, prio_to_buff_dict=None):

    prio_to_buff_p = new_sx_cos_port_prio_buff_t_p()
    try:
        for prio in prio_to_buff_dict:
            sx_cos_port_buff_t_arr_setitem(prio_to_buff_p.prio_to_buff, prio, prio_to_buff_dict[prio])

        rc = sx_api_cos_port_prio_buff_map_set(handle, SX_ACCESS_CMD_SET, port, prio_to_buff_p)
        assert rc == 0, "Failed to set pg, switch priority mapping"
    finally:
        delete_sx_cos_port_prio_buff_t_p(prio_to_buff_p)

# API to get SP to TC mapping


def cos_port_tc_prio_map_get(handle, log_port, prio_id):
    traffic_class_p = new_sx_cos_traffic_class_t_p()
    try:
        rc = sx_api_cos_port_tc_prio_map_get(handle, log_port, prio_id, traffic_class_p)
        assert rc == 0, "Failed to set pg, switch priority mapping"
        return sx_cos_traffic_class_t_p_value(traffic_class_p)
    finally:
        delete_sx_cos_traffic_class_t_p(traffic_class_p)


# API to set SP to TC mapping
def cos_port_prio_buff_map_to_tc(handle, log_port, prio_id, tc_buffer_id):
    rc = sx_api_cos_port_tc_prio_map_set(handle, SX_ACCESS_CMD_ADD, log_port, prio_id, tc_buffer_id)
    assert rc == 0, "Failed to set tc, switch priority mapping"


def init_drop_reason_groups(recirculation_port):
    global l2_cb, router_cb, tunnel_cb, acl_cb, l1_cb, buffer_cb, RECYCLE_PORT
    l2_cb = WjhDropCallbacks()
    l2_cb.drop_reason_group = WJH_DROP_REASON_GROUP_L2_E
    l2_cb.raw_cb.L2 = WjhL2DropRawCb(wjh_l2_drop_raw_cb)
    l2_cb.aggregate_cb.L2 = WjhL2DropAggregateCb(wjh_l2_drop_aggregate_cb)
    attr = c_uint32()
    rc = wjh_lib.wjh_drop_reason_group_init(WJH_DROP_REASON_GROUP_L2_E, byref(attr), byref(l2_cb))

    router_cb = WjhDropCallbacks()
    router_cb.drop_reason_group = WJH_DROP_REASON_GROUP_ROUTER_E
    router_cb.raw_cb.router = WjhRouterDropRawCb(wjh_router_drop_raw_cb)
    router_cb.aggregate_cb.router = WjhRouterDropAggregateCb(wjh_router_drop_aggregate_cb)
    attr = c_uint32()
    rc = wjh_lib.wjh_drop_reason_group_init(WJH_DROP_REASON_GROUP_ROUTER_E, byref(attr), byref(router_cb))

    tunnel_cb = WjhDropCallbacks()
    tunnel_cb.drop_reason_group = WJH_DROP_REASON_GROUP_TUNNEL_E
    tunnel_cb.raw_cb.tunnel = WjhTunnelDropRawCb(wjh_tunnel_drop_raw_cb)
    tunnel_cb.aggregate_cb.tunnel = WjhTunnelDropAggregateCb(wjh_tunnel_drop_aggregate_cb)
    attr = c_uint32()
    rc = wjh_lib.wjh_drop_reason_group_init(WJH_DROP_REASON_GROUP_TUNNEL_E, byref(attr), byref(tunnel_cb))

    acl_cb = WjhDropCallbacks()
    acl_cb.drop_reason_group = WJH_DROP_REASON_GROUP_ACL_E
    acl_cb.raw_cb.acl = WjhAclDropRawCb(wjh_acl_drop_raw_cb)
    acl_cb.aggregate_cb.acl = WjhAclDropAggregateCb(wjh_acl_drop_aggregate_cb)
    attr = c_uint32()
    rc = wjh_lib.wjh_drop_reason_group_init(WJH_DROP_REASON_GROUP_ACL_E, byref(attr), byref(acl_cb))

    buffer_cb = WjhDropCallbacks()
    buffer_cb.drop_reason_group = WJH_DROP_REASON_GROUP_BUFFER_E
    buffer_cb.raw_cb.buffer = WjhBufferDropRawCb(wjh_buffer_drop_raw_cb)
    buffer_cb.aggregate_cb.buffer = WjhBufferDropAggregateCb(wjh_buffer_drop_aggregate_cb)
    attr = WjhDropReasonGroupAttr()
    attr.attr.buffer_drop.basic_attr.recirculation_port = recirculation_port
    RECYCLE_PORT = recirculation_port
    attr.attr.buffer_drop.advanced_attr.trap_probability = 1
    attr.max_aggregation_entries_cnt = 0
    if recirculation_port != 0x0 and recirculation_port != WJH_CPU_PORT_ID:
        configure_recirculation_port(attr.attr.buffer_drop.basic_attr.recirculation_port)
    rc = wjh_lib.wjh_drop_reason_group_init(WJH_DROP_REASON_GROUP_BUFFER_E, byref(attr), byref(buffer_cb))
    assert 0 == rc, "Failed to init buffer drop reason group"

    l1_cb = WjhDropCallbacks()
    l1_cb.drop_reason_group = WJH_DROP_REASON_GROUP_L1_E
    l1_cb.aggregate_cb.L1 = WjhL1DropAggregateCb(wjh_l1_drop_aggregate_cb)
    l1_cb.raw_cb.L1 = WjhL1DropRawCb(wjh_l1_drop_raw_cb)
    attr = c_uint32()
    rc = wjh_lib.wjh_drop_reason_group_init(WJH_DROP_REASON_GROUP_L1_E, byref(attr), byref(l1_cb))

    return rc


def create_channels(mode):
    global raw_channel, aggregation_channel, cyclic_and_aggregation_channel, tac_channel, channel_mode, channel_to_agg_read_mode
    if is_tac_supported():
        tac_channel = create_user_channel(WJH_USER_CHANNEL_TAC_E)
    raw_channel = create_user_channel(WJH_USER_CHANNEL_CYCLIC_E)
    aggregation_channel = create_user_channel(WJH_USER_CHANNEL_AGGREGATE_E)
    cyclic_and_aggregation_channel = create_user_channel(WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)

    if (mode is WJH_USER_CHANNEL_MODE_PULL_E):
        channel_mode = WJH_USER_CHANNEL_MODE_PULL_E
        user_channel_attr = WjhUserChannelAttr()
        user_channel_attr.polling_interval = 0
        user_channel_attr.mode = WJH_USER_CHANNEL_MODE_PULL_E
        user_channel_attr.aggregation_read_mode = WJH_AGGREGATION_READ_MODE_READ_CLEAR

        rc = wjh_lib.wjh_user_channel_set(raw_channel, byref(user_channel_attr))
        rc = wjh_lib.wjh_user_channel_set(aggregation_channel, byref(user_channel_attr))
        rc = wjh_lib.wjh_user_channel_set(cyclic_and_aggregation_channel, byref(user_channel_attr))

    for channel in (raw_channel, aggregation_channel, cyclic_and_aggregation_channel):
        channel_to_agg_read_mode[channel] = WJH_AGGREGATION_READ_MODE_READ_CLEAR

    return raw_channel, aggregation_channel, cyclic_and_aggregation_channel


def destroy_channels():
    global raw_channel, aggregation_channel, cyclic_and_aggregation_channel, tac_channel
    rc = wjh_lib.wjh_user_channel_destroy(raw_channel)
    if is_tac_supported():
        rc = wjh_lib.wjh_user_channel_destroy(tac_channel)

    rc = wjh_lib.wjh_user_channel_destroy(aggregation_channel)
    rc = wjh_lib.wjh_user_channel_destroy(cyclic_and_aggregation_channel)


def trunc_profile_set(handle, cmd, profile_id, size):
    if not is_tac_supported():
        return      # supported only when TAC is (SPC4 and above)
    trunc_profile_cfg = sx_trap_truncate_profile_cfg_t()
    trunc_profile_cfg.truncate_size = size
    trunc_profile_cfg_p = new_sx_trap_truncate_profile_cfg_t_p()
    sx_trap_truncate_profile_cfg_t_p_assign(trunc_profile_cfg_p, trunc_profile_cfg)

    rc = sx_api_host_ifc_trap_truncate_profile_set(handle, cmd, 0, profile_id, trunc_profile_cfg_p)
    assert rc == SX_STATUS_SUCCESS, "sx_api_host_ifc_trap_truncate_profile_set failed, rc = %d\n" % (rc)


def wjh_init(bandwidth, aggregation_key_mode, trap_group_mode):
    global init_param
    init_param = WjhInitParam()
    init_param.force = 1
    init_param.deactive_cb = WjhDeactiveCb(wjh_deactive_cb)
    init_param.bandwidth_percent = bandwidth
    init_param.log_cb = 0
    init_param.conf_xml_path = 0
    init_param.debug_fs_path = 0
    init_param.ingress_info_type = WJH_INGRESS_INFO_TYPE_LOGPORT
    init_param.aggregation_key_mode = agg_key_mode_str_to_enum[aggregation_key_mode]
    init_param.trunc_profile_id = WJH_TRUNC_PROFILE_ID

    if trap_group_mode == 'auto':
        trap_group_set_cmd, _ = trap_group_set_unset_cmd_get(handle)
        if trap_group_set_cmd == SX_ACCESS_CMD_CREATE:
            trap_group_allocate_mode = WJH_TRAP_GROUP_ALLOCATE_MODE_DYNAMIC_E
        else:
            trap_group_allocate_mode = WJH_TRAP_GROUP_ALLOCATE_MODE_STATIC_E
    else:
        trap_group_allocate_mode = trap_group_mode_str_to_enum[trap_group_mode]

    driver_init_param = WjhDriverInitParam()
    driver_init_param.trap_group_allocate_mode = trap_group_allocate_mode
    init_param.driver_init_param.trap_group_allocate_mode = trap_group_allocate_mode

    rc = wjh_lib.wjh_init(byref(init_param))

    return rc


def wjh_deinit():
    rc = wjh_lib.wjh_deinit()
    return rc


def span_init(handle):
    init_params_p = new_sx_span_init_params_t_p()
    init_params = sx_span_init_params_t()
    init_params.version = SX_SPAN_MIRROR_HEADER_NONE
    sx_span_init_params_t_p_assign(init_params_p, init_params)
    rc = sx_api_span_init_set(handle, init_params_p)
    delete_sx_span_init_params_t_p(init_params_p)
    return rc


def span_deinit(handle):
    rc = sx_api_span_deinit_set(handle)
    return rc


def wjh_action_enable(args, print_packet, save_packet):
    global enable_print, enable_save, span_inited, tele_inited
    open_new_files()

    # Try to init span in case it's not inited.
    rc = span_init(handle)
    if rc == SX_STATUS_SUCCESS:
        span_inited = True

    if is_tac_supported():
        tele_init()
        tele_attributes_set(tac_enable=True)

    trunc_profile_set(handle, SX_ACCESS_CMD_CREATE, WJH_TRUNC_PROFILE_ID, WJH_TRUNC_SIZE)

    rc = wjh_init(args.bandwidth, args.aggregation_key_mode, args.trap_group_mode)
    assert 0 == rc, "Failed to init wjh service lib"

    mode = channel_mode_str_to_enum[args.mode]
    if mode is WJH_USER_CHANNEL_MODE_PUSH_E:
        enable_print = print_packet
        enable_save = save_packet
        if enable_save:
            print("Dropped packets will be saved to %s and aggregation statistics will be saved to %s" % (wjh_raw_file, wjh_agg_file))
    create_channels(mode)
    init_drop_reason_groups(args.recirculation_port)

    configure_drop_reason_group(WJH_DROP_REASON_GROUP_L2_E)
    configure_drop_reason_group(WJH_DROP_REASON_GROUP_ROUTER_E)
    configure_drop_reason_group(WJH_DROP_REASON_GROUP_TUNNEL_E)
    configure_drop_reason_group(WJH_DROP_REASON_GROUP_ACL_E)
    configure_drop_reason_group(WJH_DROP_REASON_GROUP_BUFFER_E)
    configure_drop_reason_group(WJH_DROP_REASON_GROUP_L1_E)
    wjh_drop_aggregate_json_dump_clear()

    if args.bind_to_aggregation_channel:
        rc, msg = wjh_action_bind_to_channel(args.bind_to_aggregation_channel, WJH_USER_CHANNEL_AGGREGATE_E)
        assert 0 == rc, "Failed to bind to aggregation channel"

    if args.bind_to_cyclic_and_aggregation_channel:
        rc, msg = wjh_action_bind_to_channel(args.bind_to_cyclic_and_aggregation_channel, WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)
        assert 0 == rc, "Failed to bind to cyclic-and-aggregation channel"

    if args.set_aggregation_channel_aggregation_read_mode:
        rc, msg = wjh_action_set_aggregation_channel_aggregation_read_mode(args.set_aggregation_channel_aggregation_read_mode)
        assert 0 == rc, "Failed to set the aggregation read mode of aggregation channel"

    if args.set_cyclic_and_aggregation_channel_aggregation_read_mode:
        rc, msg = wjh_action_set_cyclic_and_aggregation_channel_aggregation_read_mode(args.set_cyclic_and_aggregation_channel_aggregation_read_mode)
        assert 0 == rc, "Failed to set the aggregation read mode of cyclic-and-aggregation channel"

    if args.set_channel_timestamp_source:
        rc, msg = wjh_action_set_channel_timestamp_source(args.set_channel_timestamp_source)
        assert 0 == rc, "Failed to set channel timestamp source"

    if args.set_channel_destination:
        rc, msg = wjh_action_set_channel_destination(args.set_channel_destination)
        assert 0 == rc, "Failed to set channel destination"

    return rc, "WJH example - Backend started"


def wjh_action_print_save(raw_file_path, agg_file_path):
    global raw_channel, aggregation_channel, enable_print, enable_save, pcap_user_fd, txt_user_fd

    enable_print = True
    rc, msg = wjh_action_save(raw_file_path, agg_file_path)
    enable_print = False

    return rc, "WJH example - dropped packets printed and saved"


def wjh_action_print():
    global raw_channel, aggregation_channel, cyclic_and_aggregation_channel, enable_print

    enable_print = True
    rc = wjh_lib.wjh_user_channel_pull(raw_channel)
    rc = wjh_lib.wjh_user_channel_pull(aggregation_channel)
    rc = wjh_lib.wjh_user_channel_pull(cyclic_and_aggregation_channel)
    enable_print = False

    return rc, "WJH example - dropped packets printed"


def wjh_action_save(raw_file_path, agg_file_path):
    global raw_channel, aggregation_channel, cyclic_and_aggregation_channel, enable_save, pcap_user_fd, txt_user_fd, wjh_raw_file, wjh_agg_file

    enable_save = True

    new_pcap = False
    if raw_file_path:
        try:
            if os.path.isfile(raw_file_path):
                pcap_user_fd = open(raw_file_path, "ab")
            else:
                pcap_user_fd = open(raw_file_path, "wb")
                new_pcap = True
        except BaseException:
            return -1, "WJH example - failed to open raw file to save"
        if new_pcap:
            prepare_pcap(pcap_user_fd)
        wjh_raw_file = raw_file_path

    if agg_file_path:
        try:
            if os.path.isfile(agg_file_path):
                txt_user_fd = open(agg_file_path, "a")
            else:
                txt_user_fd = open(agg_file_path, "w")
        except BaseException:
            return -1, "WJH example - failed to open raw file to save"
        wjh_agg_file = agg_file_path

    rc = wjh_lib.wjh_user_channel_pull(raw_channel)
    rc = wjh_lib.wjh_user_channel_pull(aggregation_channel)
    rc = wjh_lib.wjh_user_channel_pull(cyclic_and_aggregation_channel)
    wjh_save_aggregate_json()

    print("Dropped packets saved to %s and aggregation statistics saved to %s" % (wjh_raw_file, wjh_agg_file))

    if pcap_user_fd:
        pcap_user_fd.close()
        pcap_user_fd = None
    if txt_user_fd:
        txt_user_fd.close()
        txt_user_fd = None

    enable_save = False
    wjh_raw_file = WJH_PCAP_NAME
    wjh_agg_file = WJH_TXT_NAME

    return rc, "WJH example - dropped packets saved"


def wjh_action_enable_group(drop_reason_group_str, severity_str):
    drop_reason_group = drop_reason_group_str_to_enum[drop_reason_group_str]
    severity = severity_str_to_enum[severity_str]
    if drop_reason_group is WJH_DROP_REASON_GROUP_ALL_E:
        for i in range(WJH_DROP_REASON_GROUP_BUFFER_E, WJH_DROP_REASON_GROUP_ALL_E):
            rc = wjh_lib.wjh_drop_reason_group_enable(i, severity)
    else:
        rc = wjh_lib.wjh_drop_reason_group_enable(drop_reason_group, severity)

    return rc, "WJH example - drop reason group enabled"


def wjh_action_disable_group(drop_reason_group_str, severity_str):
    drop_reason_group = drop_reason_group_str_to_enum[drop_reason_group_str]
    severity = severity_str_to_enum[severity_str]
    if drop_reason_group is WJH_DROP_REASON_GROUP_ALL_E:
        for i in range(WJH_DROP_REASON_GROUP_BUFFER_E, WJH_DROP_REASON_GROUP_ALL_E):
            rc = wjh_lib.wjh_drop_reason_group_disable(i, severity)
    else:
        rc = wjh_lib.wjh_drop_reason_group_disable(drop_reason_group, severity)

    return rc, "WJH example - drop reason group disabled"


def span_session_state_set(handle, session_id, admin_state):
    """SPAN SESSION STATE SET """
    rc = sx_api_span_session_state_set(handle, session_id, admin_state)
    return rc


def wjh_action_bind_to_channel_impl(drop_reason_group, channel_type):
    global tac_span_session_id

    drop_reason_group_str = drop_reason_group_to_str[drop_reason_group]
    channel_id = 0
    if channel_type is WJH_USER_CHANNEL_CYCLIC_E:
        channel_id = raw_channel
    elif channel_type is WJH_USER_CHANNEL_AGGREGATE_E:
        channel_id = aggregation_channel
    elif channel_type is WJH_USER_CHANNEL_TAC_E:
        channel_id = tac_channel
        if tac_span_session_id is None:
            user_channel_attr = WjhUserChannelAttr()
            user_channel_attr.span_session_id = span_session_create_remote(handle, tac_vlan, tac_dmac, tac_dst_ip)
            tac_span_session_id = user_channel_attr.span_session_id

            port_params_p = new_sx_span_analyzer_port_params_t_p()
            port_params = sx_span_analyzer_port_params_t()
            port_params.cng_mng = SX_SPAN_CNG_MNG_DISCARD
            sx_span_analyzer_port_params_t_p_assign(port_params_p, port_params)
            rc = span_analyzer_set(handle, SX_ACCESS_CMD_ADD, tac_analyzer_port, port_params_p, user_channel_attr.span_session_id)
            if rc != 0:
                return rc, "WJH example - failed set tac analyzer"

            rc = span_session_state_set(handle, user_channel_attr.span_session_id, True)
            if rc != 0:
                return rc, "WJH example - failed set tac analyzer"

            rc = wjh_lib.wjh_user_channel_set(tac_channel, byref(user_channel_attr))
            if rc != 0:
                return rc, "WJH example - failed set tac span session"
    else:
        channel_id = cyclic_and_aggregation_channel
    if drop_reason_group_to_channel[drop_reason_group] == channel_id:
        return 0, "WJH example - drop reason group %s is already bound to %s channel" % (drop_reason_group_str, channel_type_to_str[channel_type])
    rc = wjh_lib.wjh_drop_reason_group_unbind(drop_reason_group)
    if rc != 0:
        return rc, "WJH example - failed to unbind drop reason group %s" % (drop_reason_group_str)
    rc = wjh_lib.wjh_drop_reason_group_bind(drop_reason_group, channel_id)
    if rc != 0:
        return rc, "WJH example - failed to bind drop reason group %s to raw channel" % (drop_reason_group_str)
    drop_reason_group_to_channel[drop_reason_group] = channel_id
    rc = wjh_lib.wjh_drop_reason_group_enable(drop_reason_group, WJH_SEVERITY_ALL_E)
    if rc != 0:
        return rc, "WJH example - failed to enable severity \"all\" for drop reason group %s" % (drop_reason_group_str)
    return rc, "WJH example - drop reason group %s is bound to %s channel, severity \"all\" is enabled for it" % (drop_reason_group_str, channel_type_to_str[channel_type])


def wjh_action_bind_to_channel(drop_reason_group_str, channel_type):
    rc = 0
    str = ""
    drop_reason_group = drop_reason_group_str_to_enum[drop_reason_group_str]
    if drop_reason_group is WJH_DROP_REASON_GROUP_ALL_E:
        for i in range(WJH_DROP_REASON_GROUP_BUFFER_E, WJH_DROP_REASON_GROUP_ALL_E):
            if channel_type is WJH_USER_CHANNEL_TAC_E and i == WJH_DROP_REASON_GROUP_L1_E:
                continue
            rc1, str1 = wjh_action_bind_to_channel_impl(i, channel_type)
            if rc1 != 0:
                rc = rc1
                str = str1
                break
            else:
                str += str1
                str += "\n"
    else:
        rc1, str1 = wjh_action_bind_to_channel_impl(drop_reason_group, channel_type)
        if rc1 != 0:
            rc = rc1
            str = str1
        else:
            str += str1
            str += "\n"

    if rc == 0:
        str += "Successfully bound drop reason group %s to %s channel" % (drop_reason_group_str, channel_type_to_str[channel_type])

    return rc, str


def wjh_action_set_channel_aggregation_read_mode(channel_id, agg_read_mode_str):
    global channel_mode, channel_to_agg_read_mode, channel_timestamp_source, channel_destination

    user_channel_attr = WjhUserChannelAttr()
    user_channel_attr.polling_interval = 0
    user_channel_attr.mode = channel_mode
    user_channel_attr.aggregation_read_mode = agg_read_mode_str_to_enum[agg_read_mode_str]
    user_channel_attr.timestamp_source = channel_timestamp_source
    user_channel_attr.user_channel_dest = channel_destination

    rc = wjh_lib.wjh_user_channel_set(channel_id, byref(user_channel_attr))
    if rc != 0:
        return rc, "WJH example - failed to set user channel %d aggregation read mode to %s" % (channel_id, agg_read_mode_str)

    channel_to_agg_read_mode[channel_id] = agg_read_mode_str_to_enum[agg_read_mode_str]

    return rc, "WJH example - successfully set user channel %d aggregation read mode to %s" % (channel_id, agg_read_mode_str)


def wjh_action_set_aggregation_channel_aggregation_read_mode(agg_read_mode_str):
    global aggregation_channel
    return wjh_action_set_channel_aggregation_read_mode(aggregation_channel, agg_read_mode_str)


def wjh_action_set_cyclic_and_aggregation_channel_aggregation_read_mode(agg_read_mode_str):
    global cyclic_and_aggregation_channel
    return wjh_action_set_channel_aggregation_read_mode(cyclic_and_aggregation_channel, agg_read_mode_str)


def wjh_action_set_channel_timestamp_source(channel_timestamp_source_str):
    global channel_mode, channel_to_agg_read_mode, channel_timestamp_source, channel_destination
    ret_str = ""

    for channel in (raw_channel, aggregation_channel, cyclic_and_aggregation_channel):
        user_channel_attr = WjhUserChannelAttr()
        user_channel_attr.polling_interval = 0
        user_channel_attr.mode = channel_mode
        user_channel_attr.aggregation_read_mode = channel_to_agg_read_mode[channel]
        user_channel_attr.timestamp_source = channel_timestamp_source_str_to_enum[channel_timestamp_source_str]
        user_channel_attr.user_channel_dest = channel_destination

        rc = wjh_lib.wjh_user_channel_set(channel, byref(user_channel_attr))
        if rc != 0:
            return rc, "WJH example - failed to set user channel %d timestamp source to %s" % (channel, channel_timestamp_source_str)

        ret_str += "WJH example - successfully set user channel %d timestamp source to %s\n" % (channel, channel_timestamp_source_str)

    channel_timestamp_source = channel_timestamp_source_str_to_enum[channel_timestamp_source_str]

    return rc, ret_str


def wjh_action_set_channel_destination(channel_destination_str):
    global channel_mode, channel_to_agg_read_mode, channel_timestamp_source, channel_destination
    ret_str = ""

    for channel in (raw_channel, aggregation_channel, cyclic_and_aggregation_channel):
        user_channel_attr = WjhUserChannelAttr()
        user_channel_attr.polling_interval = 0
        user_channel_attr.mode = channel_mode
        user_channel_attr.aggregation_read_mode = channel_to_agg_read_mode[channel]
        user_channel_attr.timestamp_source = channel_timestamp_source
        user_channel_attr.user_channel_dest = channel_destination_str_to_enum[channel_destination_str]

        rc = wjh_lib.wjh_user_channel_set(channel, byref(user_channel_attr))
        if rc != 0:
            return rc, "WJH example - failed to set user channel %d destination to %s" % (channel, channel_destination_str)

        ret_str += "WJH example - successfully set user channel %d destination to %s\n" % (channel, channel_destination_str)

    channel_destination = channel_destination_str_to_enum[channel_destination_str]

    return rc, ret_str


def wjh_action_disable():
    global pcap_fd, txt_fd, span_inited, RECYCLE_PORT, tac_span_session_id
    rc = 0

    deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_ACL_E)
    deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_BUFFER_E)
    deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_L1_E)
    deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_L2_E)
    deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_ROUTER_E)
    deconfigure_drop_reason_group(WJH_DROP_REASON_GROUP_TUNNEL_E)
    if RECYCLE_PORT != 0x0 and RECYCLE_PORT != WJH_CPU_PORT_ID:
        deconfigure_recirculation_port(RECYCLE_PORT)

    destroy_channels()
    if tac_span_session_id is not None:
        rc = span_session_state_set(handle, tac_span_session_id, False)
        if rc != 0:
            return rc, "WJH example - failed set disable span_session_state_set"
        port_params_p = new_sx_span_analyzer_port_params_t_p()
        port_params = sx_span_analyzer_port_params_t()
        port_params.cng_mng = SX_SPAN_CNG_MNG_DISCARD
        sx_span_analyzer_port_params_t_p_assign(port_params_p, port_params)
        rc = span_analyzer_set(handle, SX_ACCESS_CMD_DELETE, tac_analyzer_port, port_params_p, tac_span_session_id)
        if rc != 0:
            return rc, "WJH example - failed delete tac analyzer"
        span_session_destroy(handle, tac_span_session_id)
        if rc != 0:
            return rc, "WJH example - failed destroy tac span session"

    wjh_deinit()

    if span_inited:
        span_deinit(handle)

    if tele_inited:
        tele_deinit()

    pcap_fd.close()
    txt_fd.close()
    trunc_profile_set(handle, SX_ACCESS_CMD_DESTROY, WJH_TRUNC_PROFILE_ID, WJH_TRUNC_SIZE)

    return rc, "WJH example - Backend stopped"


def wjh_receive_signal(signum, frame):
    print("WJH example - Backend stopped")
    wjh_action_disable()
    sys.exit(0)

# API to send message to wjh tool client


def wjh_send_client_msg(conn, msg, rc):
    if rc != 0:
        msg = msg + " rc:" + str(rc)

    msg = msg.encode()
    try:
        conn.sendall(msg)
        rval = True
    except Exception as e:
        print("Stopping WJH monitor exit: Unable to send message (%s)" % str(e))
        rval = False
    return rval


def bandwidth_type(x):
    x = int(x)
    if x < 0 or x > 100:
        raise argparse.ArgumentTypeError("Bandwidth is 0 - 100")
    return x


def make_sx_ip_addr_v4(addr):
    " This function creates ipv4 sx_ip_addr struct with given ip address. "

    ip_addr = sx_ip_addr_t()
    ip_addr.version = SX_IP_VERSION_IPV4
    ip_addr.addr.ipv4.s_addr = struct.unpack('>I', socket.inet_pton(socket.AF_INET, addr))[0]
    return ip_addr


def span_session_create(handle, span_session_param_p):
    """SPAN SESSION CREATE"""

    span_session_id_p = new_sx_span_session_id_t_p()

    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_CREATE, span_session_param_p,
                                 span_session_id_p)
    if rc != SX_STATUS_SUCCESS:
        sys.exit(rc)

    return span_session_id_p


def span_session_destroy(handle, span_session_id):
    """SPAN SESSION DESTROY"""
    span_session_id_p = new_sx_span_session_id_t_p()
    span_session_param_p = new_sx_span_session_params_t_p()
    span_session_param = sx_span_session_params_t()
    sx_span_session_params_t_p_assign(span_session_param_p, span_session_param)

    sx_span_session_id_t_p_assign(span_session_id_p, span_session_id)
    rc = sx_api_span_session_set(handle, SX_ACCESS_CMD_DESTROY, span_session_param_p,
                                 span_session_id_p)

    return rc


def span_analyzer_set(handle, cmd, log_port, port_paramas_p, session_id):
    """SPAN ANALYZER ADD/DELETE"""
    rc = sx_api_span_analyzer_set(handle, cmd, log_port, port_paramas_p, session_id)
    return rc


def span_session_create_remote(handle, vlan, dmac, remote_ip):
    # create a span session
    span_session_param_p = new_sx_span_session_params_t_p()
    span_session_param = sx_span_session_params_t()
    span_session_param.span_type = SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1
    span_session_param.version = SX_SPAN_MIRROR_HEADER_NONE
    span_session_param.span_type_format.remote_eth_l3_type1.qos_mode = SX_SPAN_QOS_CONFIGURED
    span_session_param.span_type_format.remote_eth_l3_type1.switch_prio = 0
    span_session_param.span_type_format.remote_eth_l3_type1.vid = vlan
    span_session_param.span_type_format.remote_eth_l3_type1.vlan_ethertype_id = 0
    span_session_param.span_type_format.remote_eth_l3_type1.dei = 0
    span_session_param.span_type_format.remote_eth_l3_type1.pcp = 0
    span_session_param.span_type_format.remote_eth_l3_type1.tp = 0
    span_session_param.span_type_format.remote_eth_l3_type1.mac = ether_addr(tac_dmac)
    span_session_param.span_type_format.remote_eth_l3_type1.smac = ether_addr("00:04:05:06:07:0A")
    span_session_param.span_type_format.remote_eth_l3_type1.ttl = 64
    span_session_param.span_type_format.remote_eth_l3_type1.src_ip = make_sx_ip_addr_v4(tac_src_ip)
    span_session_param.span_type_format.remote_eth_l3_type1.dest_ip = make_sx_ip_addr_v4(tac_dst_ip)
    span_session_param.truncate = True
    span_session_param.truncate_size = 4000
    sx_span_session_params_t_p_assign(span_session_param_p, span_session_param)
    span_session_id_p = span_session_create(handle, span_session_param_p)
    span_session_id = sx_span_session_id_t_p_value(span_session_id_p)
    return span_session_id

# API to wait for incoming connection and messages from tool front end


def wjh_wait_incoming_connection():
    global tac_src_ip, tac_dst_ip, tac_dmac, tac_vlan, tac_analyzer_port, chip_type
    parser = argparse.ArgumentParser(description='WJH example Backend')
    parser.add_argument('--disable', action='store_true', help='disables the WJH example backend')
    parser.add_argument('--enable', action='store_true', help='enables the WJH example backend')
    parser.add_argument('--trap_group_mode', default='auto', choices=['static', 'dynamic', 'auto'], help='set WJH trap group allocation mode for enable action')
    parser.add_argument('--bandwidth', default=0, type=bandwidth_type, help='set pcie bandwidth percentage for WJH for enable option')
    parser.add_argument('--mode', default='manual', choices=['agent', 'manual'], help='set WJH mode for enable option')
    parser.add_argument('--aggregation_key_mode', default='streaming', choices=['streaming', 'detailed'], help='set WJH aggregation key mode for enable action')
    parser.add_argument('--recirculation_port', default=0x10001, type=auto_int, help='set recirculation port for enable action')
    parser.add_argument('--print', action='store_true', help='prints the WJH captured packets')
    parser.add_argument('--save', action='store_true', help='saves the WJH captured packets')
    parser.add_argument('--raw_file', help='the optional file full path of the WJH raw packets')
    parser.add_argument('--agg_file', help='the optional file full path of the WJH aggregation info')
    parser.add_argument('--enable_drop_reason_group',
                        choices=['all', 'l1', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                        help='enable drop reason group')
    parser.add_argument('--disable_drop_reason_group',
                        choices=['all', 'l1', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                        help='disable drop reason group')
    parser.add_argument('--severity', default='all',
                        choices=['all', 'notice', 'warning', 'error'],
                        help='drop reason severity for drop reason group disable/enable')
    parser.add_argument('--bind_to_aggregation_channel',
                        choices=['all', 'l1', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                        help='bind drop reason group to aggregation channel')
    parser.add_argument('--bind_to_cyclic_channel',
                        choices=['all', 'l1', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                        help='bind drop reason group to cyclic channel')
    parser.add_argument('--bind_to_cyclic_and_aggregation_channel',
                        choices=['all', 'l1', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                        help='bind drop reason group to cyclic-and-aggregation channel')
    parser.add_argument('--bind_to_tac_channel',
                        choices=['all', 'l2', 'router', 'tunnel', 'acl', 'buffer'],
                        help='bind drop reason group to tac channel')
    parser.add_argument('--set_aggregation_channel_aggregation_read_mode',
                        choices=['read_clear', 'read'],
                        help='set the aggregation read mode of the aggregation channel')
    parser.add_argument('--set_cyclic_and_aggregation_channel_aggregation_read_mode',
                        choices=['read_clear', 'read'],
                        help='set the aggregation read mode of the cyclic-and-aggregation channel')
    parser.add_argument('--set_channel_timestamp_source',
                        choices=['linux', 'hw_clock'],
                        help='set the channel timestamp source')
    parser.add_argument('--set_channel_destination',
                        choices=['callback_and_drop_monitor', 'drop_monitor'],
                        help='set the channel destination')
    parser.add_argument('--tac_dst_ip', help='dst ip for the tac span session')
    parser.add_argument('--tac_src_ip', help='src ip for the tac span session')
    parser.add_argument('--tac_vlan', help='vlan for the tac span session')
    parser.add_argument('--tac_dmac', help='destination MAC for the tac span session')
    parser.add_argument('--tac_analyzer_port', help='analyzer_port for the tac span session')

    chip_type = get_chip_type(handle)
    is_monitoring = False
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        server_address = ('localhost', WJH_MONITOR_SERVER_PORT)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(server_address)
        sock.listen(WJH_SERVER_LISTEN_QUEUE_SIZE)
    except socket.error:
        print("WJH example backend already running.")
        enabled = False
    except Exception:
        print("WJH example backend- Failed.")
        enabled = False
    else:
        enabled = True
        while enabled:
            try:
                connection, client_address = sock.accept()
                recv_data = connection.recv(WJH_SOCKET_BUFFER_SIZE)
                cmd = pickle.loads(recv_data)
                args = parser.parse_args(cmd)
                # handle --enable
                if args.enable:
                    if is_monitoring:
                        rval = wjh_send_client_msg(connection, "WJH example backend - Monitoring is already ON", 0)
                        enabled = rval
                    else:
                        print_packet = False
                        save_packet = False
                        if vars(args)['print']:
                            print_packet = True
                        if args.save:
                            save_packet = True
                        rc, msg = wjh_action_enable(args, print_packet, save_packet)
                        rval = wjh_send_client_msg(connection, msg, rc)
                        # start failure would result in agent termination
                        if rc == 0:
                            enabled = rval
                            is_monitoring = True
                        else:
                            enabled = False
                            is_monitoring = False
                # handle --disable
                elif args.disable:
                    enabled = False
                    rc, msg = wjh_action_disable()
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --print and --save:
                elif vars(args)['print'] and args.save:
                    rc, msg = wjh_action_print_save(args.raw_file, args.agg_file)
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --print
                elif vars(args)['print']:
                    rc, msg = wjh_action_print()
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --save
                elif args.save:
                    rc, msg = wjh_action_save(args.raw_file, args.agg_file)
                    rval = wjh_send_client_msg(connection, msg, rc)
                elif args.tac_src_ip:
                    if not is_tac_supported():
                        rval = wjh_send_client_msg(connection, "TAC is supported on spectrum4 and above", 1)
                        continue
                    tac_src_ip = args.tac_src_ip
                    rval = wjh_send_client_msg(connection, "succeed", 0)
                elif args.tac_dst_ip:
                    if not is_tac_supported():
                        rval = wjh_send_client_msg(connection, "TAC is supported on spectrum4 and above", 1)
                        continue
                    tac_dst_ip = args.tac_dst_ip
                    rval = wjh_send_client_msg(connection, "succeed", 0)
                elif args.tac_vlan:
                    if not is_tac_supported():
                        rval = wjh_send_client_msg(connection, "TAC is supported on spectrum4 and above", 1)
                        continue
                    tac_vlan = int(args.tac_vlan)
                    rval = wjh_send_client_msg(connection, "succeed", 0)
                elif args.tac_dmac:
                    if not is_tac_supported():
                        rval = wjh_send_client_msg(connection, "TAC is supported on spectrum4 and above", 1)
                        continue
                    tac_dmac = args.tac_dmac
                    rval = wjh_send_client_msg(connection, "succeed", 0)
                elif args.tac_analyzer_port:
                    if not is_tac_supported():
                        rval = wjh_send_client_msg(connection, "TAC is supported on spectrum4 and above", 1)
                        continue
                    tac_analyzer_port = int(args.tac_analyzer_port, 16)
                    rval = wjh_send_client_msg(connection, "succeed", 0)
                # handle --enable_drop_reason_group
                elif args.enable_drop_reason_group:
                    rc, msg = wjh_action_enable_group(args.enable_drop_reason_group, args.severity)
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --disable_drop_reason_group
                elif args.disable_drop_reason_group:
                    rc, msg = wjh_action_disable_group(args.disable_drop_reason_group, args.severity)
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --bind_to_aggregation_channel
                elif args.bind_to_aggregation_channel:
                    rc, msg = wjh_action_bind_to_channel(args.bind_to_aggregation_channel, WJH_USER_CHANNEL_AGGREGATE_E)
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --bind_to_cyclic_channel
                elif args.bind_to_cyclic_channel:
                    rc, msg = wjh_action_bind_to_channel(args.bind_to_cyclic_channel, WJH_USER_CHANNEL_CYCLIC_E)
                    rval = wjh_send_client_msg(connection, msg, rc)
                elif args.bind_to_tac_channel:
                    if not is_tac_supported():
                        rval = wjh_send_client_msg(connection, "TAC is supported on spectrum4 and above", 1)
                        continue
                    rc, msg = wjh_action_bind_to_channel(args.bind_to_tac_channel, WJH_USER_CHANNEL_TAC_E)
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --bind_to_cyclic_and_aggregation_channel
                elif args.bind_to_cyclic_and_aggregation_channel:
                    rc, msg = wjh_action_bind_to_channel(args.bind_to_cyclic_and_aggregation_channel, WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --set_aggregation_channel_aggregation_read_mode
                elif args.set_aggregation_channel_aggregation_read_mode:
                    rc, msg = wjh_action_set_aggregation_channel_aggregation_read_mode(args.set_aggregation_channel_aggregation_read_mode)
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --set_cyclic_and_aggregation_channel_aggregation_read_mode
                elif args.set_cyclic_and_aggregation_channel_aggregation_read_mode:
                    rc, msg = wjh_action_set_cyclic_and_aggregation_channel_aggregation_read_mode(args.set_cyclic_and_aggregation_channel_aggregation_read_mode)
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --set_channel_timestamp_source
                elif args.set_channel_timestamp_source:
                    rc, msg = wjh_action_set_channel_timestamp_source(args.set_channel_timestamp_source)
                    rval = wjh_send_client_msg(connection, msg, rc)
                # handle --set_channel_destination
                elif args.set_channel_destination:
                    rc, msg = wjh_action_set_channel_destination(args.set_channel_destination)
                    rval = wjh_send_client_msg(connection, msg, rc)
                else:
                    rval = wjh_send_client_msg(connection, "WJH example backend- Invalid command", 0)
                    enabled = rval

                connection.close()
            except socket.error:
                print("WJH example backend - Unable to accept or recv data from new connection start again")
                enabled = False
                is_monitoring = False
            except Exception as e:
                print("WJH example backend - Failure occurred (%s) , exiting.." % (str(e)))
                enabled = False
                is_monitoring = False
    finally:
        sock.close()
        if enabled:
            wjh_action_disable()

#######################################################################################
################################### BUFFER FUNCTIONS####################################
#######################################################################################


# Dictionaries used by buffer API's
reserved_buffer_types_to_field_names_dict = {
    SX_COS_INGRESS_PORT_ATTR_E: "ingress_port_buff_attr",
    SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E: "ingress_port_pg_buff_attr",
    SX_COS_EGRESS_PORT_ATTR_E: "egress_port_buff_attr",
    SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E: "egress_port_tc_buff_attr",
    SX_COS_MULTICAST_ATTR_E: "multicast_buff_attr",
    SX_COS_MULTICAST_PORT_ATTR_E: "multicast_port_buff_attr",
    SX_COS_PORT_BUFF_ATTR_RESERVED1_E: "ingress_port_buff_attr",
    SX_COS_PORT_BUFF_ATTR_RESERVED2_E: "ingress_port_pg_buff_attr",
    SX_COS_PORT_BUFF_ATTR_RESERVED3_E: "egress_port_buff_attr",
    SX_COS_PORT_BUFF_ATTR_RESERVED4_E: "egress_port_tc_buff_attr"
}

buffer_types_to_buffer_id_names_dict = {
    SX_COS_INGRESS_PORT_ATTR_E: "pool_id",
    SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E: "pg",
    SX_COS_EGRESS_PORT_ATTR_E: "pool_id",
    SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E: "tc",
    SX_COS_MULTICAST_ATTR_E: "sp",
    SX_COS_MULTICAST_PORT_ATTR_E: "pool_id",
    SX_COS_PORT_BUFF_ATTR_RESERVED1_E: "pool_id",
    SX_COS_PORT_BUFF_ATTR_RESERVED2_E: "pg",
    SX_COS_PORT_BUFF_ATTR_RESERVED3_E: "pool_id",
    SX_COS_PORT_BUFF_ATTR_RESERVED4_E: "tc"
}

shared_buffer_types_to_field_names_dict = {
    SX_COS_INGRESS_PORT_ATTR_E: "ingress_port_shared_buff_attr",
    SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E: "ingress_port_pg_shared_buff_attr",
    SX_COS_EGRESS_PORT_ATTR_E: "egress_port_shared_buff_attr",
    SX_COS_EGRESS_PORT_TRAFFIC_CLASS_ATTR_E: "egress_port_tc_shared_buff_attr",
    SX_COS_MULTICAST_ATTR_E: "multicast_shared_buff_attr",
    SX_COS_MULTICAST_PORT_ATTR_E: "multicast_port_shared_buff_attr",
    SX_COS_PORT_BUFF_ATTR_RESERVED1_E: "ingress_port_shared_buff_attr",
    SX_COS_PORT_BUFF_ATTR_RESERVED2_E: "ingress_port_pg_shared_buff_attr",
    SX_COS_PORT_BUFF_ATTR_RESERVED3_E: "egress_port_shared_buff_attr",
    SX_COS_PORT_BUFF_ATTR_RESERVED4_E: "egress_port_tc_shared_buff_attr"
}

# API to change the reserved buffer settings.


def modify_port_reserved_buffer(handle, cmd, log_port, type, buffer_id, size=0, pool_id=0, is_lossy=1,
                                xon=0, xoff=0, count=1, pipeline_latency_override=0, pipeline_latency_size=0,
                                attr_list=None):

    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(count)
    attr_item = new_sx_cos_port_buffer_attr_t_p()
    try:
        if attr_list is None:
            if type > SX_COS_PORT_BUFF_ATTR_RESERVED4_E or type < SX_COS_INGRESS_PORT_ATTR_E or \
                    type in [SX_COS_INGRESS_PORT_PRIORITY_GROUP_PIPELINE_LATENCY_ATTR_E, SX_COS_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_ATTR_E]:
                return (-1)

            attr_item.type = type
            attr = getattr(attr_item.attr, reserved_buffer_types_to_field_names_dict[type])
            attr.size = size
            if type == SX_COS_INGRESS_PORT_PRIORITY_GROUP_ATTR_E:
                attr.is_lossy = is_lossy
                attr.xon = xon
                attr.xoff = xoff
                attr.pipeline_latency.override_default = pipeline_latency_override
                attr.pipeline_latency.size = pipeline_latency_size
            setattr(attr, buffer_types_to_buffer_id_names_dict[type], buffer_id)

            sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 0, attr_item)

        else:
            for i in range(count):
                sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, i, attr_list[i])

        rc = sx_api_cos_port_buff_type_set(handle, cmd, log_port, port_buffer_attr_list_p, count)
        assert 0 == rc, "Failed to set port reserved buffer"
    finally:
        delete_sx_cos_port_buffer_attr_t_p(attr_item)
        delete_sx_cos_port_buffer_attr_t_arr(port_buffer_attr_list_p)


# API to change the shared buffer settings.
def modify_port_shared_buffer(handle, cmd, log_port, type, buffer_id, pool_id=0, mode=0, size=0, alpha=0,
                              count=1, attr_list=None):
    port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(count)
    attr_item = new_sx_cos_port_shared_buffer_attr_t_p()
    try:
        if attr_list is None:
            if type > SX_COS_PORT_BUFF_ATTR_RESERVED4_E or type < SX_COS_INGRESS_PORT_ATTR_E or \
                    type in [SX_COS_INGRESS_PORT_PRIORITY_GROUP_PIPELINE_LATENCY_ATTR_E, SX_COS_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_ATTR_E]:
                return (-1)

            attr_item.type = type
            attr = getattr(attr_item.attr, shared_buffer_types_to_field_names_dict[type])

            attr.pool_id = pool_id  # this has effect only for non-pool buffers.
            attr.max.mode = mode
            if mode in [SX_COS_BUFFER_MAX_MODE_STATIC_E, SX_COS_BUFFER_MAX_MODE_BUFFER_UNITS_E]:
                attr.max.max.size = size
            elif mode == SX_COS_BUFFER_MAX_MODE_DYNAMIC_E:
                attr.max.max.alpha = alpha
            setattr(attr, buffer_types_to_buffer_id_names_dict[type], buffer_id)

            sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, 0, attr_item)

        else:
            for i in range(count):
                sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, i, attr_list[i])

        rc = sx_api_cos_port_shared_buff_type_set(handle, cmd, log_port, port_shared_buffer_attr_list_p, count)
        assert 0 == rc, "Failed to set port shared buffer"
    finally:
        delete_sx_cos_port_shared_buffer_attr_t_p(attr_item)
        delete_sx_cos_port_shared_buffer_attr_t_arr(port_shared_buffer_attr_list_p)

# API to get the reserved buffer attributes


def get_reserved_buffer_attributes(handle, log_port, type, value):

    if type > SX_COS_PORT_BUFF_ATTR_RESERVED4_E or type < SX_COS_INGRESS_PORT_ATTR_E or \
        type in [SX_COS_INGRESS_PORT_PRIORITY_GROUP_PIPELINE_LATENCY_ATTR_E,
                 SX_COS_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_ATTR_E]:
        return (-1)

    port_buffer_attr_cnt = copy_uint32_t_p(1)
    port_buffer_attr_list_p = new_sx_cos_port_buffer_attr_t_arr(1)

    try:
        port_buffer_attr_item = sx_cos_port_buffer_attr_t()
        port_buffer_attr_item.type = type
        attr = getattr(port_buffer_attr_item.attr, reserved_buffer_types_to_field_names_dict[type])
        setattr(attr, buffer_types_to_buffer_id_names_dict[type], value)

        sx_cos_port_buffer_attr_t_arr_setitem(port_buffer_attr_list_p, 0, port_buffer_attr_item)

        rc = sx_api_cos_port_buff_type_get(handle, log_port, port_buffer_attr_list_p, port_buffer_attr_cnt)
        assert 0 == rc, "Failed to get port reserved buffer"

        return sx_cos_port_buffer_attr_t_arr_getitem(port_buffer_attr_list_p, 0)
    finally:
        delete_sx_cos_port_buffer_attr_t_arr(port_buffer_attr_list_p)
        delete_uint32_t_p(port_buffer_attr_cnt)


# API to get the shared  buffer attributes
def get_shared_buffer_attributes(handle, log_port, type, value):

    if type > SX_COS_PORT_BUFF_ATTR_RESERVED4_E or type < SX_COS_INGRESS_PORT_ATTR_E or \
        type in [SX_COS_INGRESS_PORT_PRIORITY_GROUP_PIPELINE_LATENCY_ATTR_E,
                 SX_COS_INGRESS_PORT_PRIORITY_GROUP_HEADROOM_ATTR_E]:
        return (-1)

    port_shared_buffer_attr_cnt = copy_uint32_t_p(1)
    port_shared_buffer_attr_list_p = new_sx_cos_port_shared_buffer_attr_t_arr(1)

    try:
        port_shared_buffer_attr_item = sx_cos_port_shared_buffer_attr_t()
        port_shared_buffer_attr_item.type = type

        attr = getattr(port_shared_buffer_attr_item.attr, shared_buffer_types_to_field_names_dict[type])
        setattr(attr, buffer_types_to_buffer_id_names_dict[type], value)

        sx_cos_port_shared_buffer_attr_t_arr_setitem(port_shared_buffer_attr_list_p, 0, port_shared_buffer_attr_item)

        rc = sx_api_cos_port_shared_buff_type_get(handle, log_port, port_shared_buffer_attr_list_p,
                                                  port_shared_buffer_attr_cnt)
        assert 0 == rc, "Failed to get port reserved buffer"
        return sx_cos_port_shared_buffer_attr_t_arr_getitem(port_shared_buffer_attr_list_p, 0)
    finally:
        delete_sx_cos_port_shared_buffer_attr_t_arr(port_shared_buffer_attr_list_p)
        delete_uint32_t_p(port_shared_buffer_attr_cnt)

#######################################################################################
############################### BUFFER API END##########################################
#######################################################################################


def main():
    global handle
    rc, handle = sx_api_open(None)
    if (rc != SX_STATUS_SUCCESS):
        print("Failed to open api handle.\nPlease check that SDK is running.")
    wjh_wait_incoming_connection()


signal.signal(signal.SIGTERM, wjh_receive_signal)
signal.signal(signal.SIGINT, wjh_receive_signal)

ctypes.CDLL('libsxapi.so', mode=ctypes.RTLD_GLOBAL)
ctypes.CDLL('libsxadviser.so', mode=ctypes.RTLD_GLOBAL)
ctypes.CDLL('libsxaclhelper.so', mode=ctypes.RTLD_GLOBAL)

try:
    wjh_lib = ctypes.CDLL('libwjh.so', mode=ctypes.RTLD_GLOBAL)
except OSError as e:
    ctypes.CDLL(find_library('elf'), mode=ctypes.RTLD_GLOBAL)
    wjh_lib = ctypes.CDLL('libwjh.so', mode=ctypes.RTLD_GLOBAL)


if __name__ == "__main__":
    main()
