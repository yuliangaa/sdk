/*
 * Copyright © 2001-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef __WJH_DEV_SDK_H__
#define __WJH_DEV_SDK_H__

#include "wjh_common.h"
#include "wjh_sdk_dev_cb.h"

static wjh_dev_specific_cb_t wjh_dev_cb_sdk_spc = {
    wjh_buffer_drop_sdk_span_init_spc,  /*  wjh_buffer_drop_span_init_cb  */
    wjh_buffer_drop_sdk_span_session_set, /*  wjh_buffer_drop_span_session_set_cb */
    NULL,                                /*  wjh_buffer_drop_span_session_bind_unbind_cb */
    wjh_buffer_drop_sdk_span_deinit_spc, /*  wjh_buffer_drop_span_deinit_cb */
    wjh_buffer_drop_sdk_adviser_port_event_spc, /* wjh_buffer_drop_adviser_port_event_cb */
    wjh_buffer_drop_acl_create_spc,             /* wjh_buffer_drop_acl_create_cb */
    wjh_buffer_drop_acl_destroy_spc,            /* wjh_buffer_drop_acl_destroy_cb */
    wjh_roce_drop_acl_create,                    /* wjh_roce_drop_acl_create_cb */
    wjh_roce_drop_acl_destroy,                   /* wjh_roce_drop_acl_destroy_cb */
    wjh_roce_drop_acl_rules_set,                 /* wjh_roce_drop_acl_rules_set_cb */
    wjh_user_channel_timestamp_source_set_spc, /* wjh_user_channel_timestamp_source_set_cb */
    wjh_policer_limits_get_spc, /* wjh_policer_limits_get_cb */
    wjh_mirror_header_v2_size_get, /* wjh_mirror_header_v2_size_get_cb */
    wjh_buffer_drop_sdk_mirror_to_cpu_mode_set, /* wjh_buffer_drop_mirror_to_cpu_mode_set_cb */
};
static wjh_dev_specific_cb_t wjh_dev_cb_sdk_spc2 = {
    wjh_buffer_drop_sdk_span_init_spc2, /*  wjh_buffer_drop_span_init_cb    */
    wjh_buffer_drop_sdk_span_session_set, /*  wjh_buffer_drop_span_session_set_cb */
    wjh_buffer_drop_sdk_span_session_bind_unbind, /*  wjh_buffer_drop_span_session_bind_unbind_cb */
    wjh_buffer_drop_sdk_span_deinit_spc2, /*  wjh_buffer_drop_span_deinit_cb */
    wjh_buffer_drop_sdk_adviser_port_event_spc2, /* wjh_buffer_drop_adviser_port_event_cb */
    wjh_buffer_drop_acl_create_spc2,             /* wjh_buffer_drop_acl_create_cb. ACL is same for spc1&2*/
    wjh_buffer_drop_acl_destroy_spc2,            /* wjh_buffer_drop_acl_destroy_cb */
    wjh_roce_drop_acl_create,                    /* wjh_roce_drop_acl_create_cb */
    wjh_roce_drop_acl_destroy,                   /* wjh_roce_drop_acl_destroy_cb */
    wjh_roce_drop_acl_rules_set,                 /* wjh_roce_drop_acl_rules_set_cb */
    wjh_user_channel_timestamp_source_set_spc2, /* wjh_user_channel_timestamp_source_set_cb */
    wjh_policer_limits_get_spc2, /* wjh_policer_limits_get_cb */
    wjh_mirror_header_v2_size_get, /* wjh_mirror_header_v2_size_get_cb */
    wjh_buffer_drop_sdk_mirror_to_cpu_mode_set, /* wjh_buffer_drop_mirror_to_cpu_mode_set_cb */
};

static wjh_dev_specific_cb_t wjh_dev_cb_sdk_spc4 = {
    wjh_buffer_drop_sdk_span_init_spc2, /*  wjh_buffer_drop_span_init_cb    */
    wjh_buffer_drop_sdk_span_session_set, /*  wjh_buffer_drop_span_session_set_cb */
    wjh_buffer_drop_sdk_span_session_bind_unbind, /*  wjh_buffer_drop_span_session_bind_unbind_cb */
    wjh_buffer_drop_sdk_span_deinit_spc2, /*  wjh_buffer_drop_span_deinit_cb */
    wjh_buffer_drop_sdk_adviser_port_event_spc2, /* wjh_buffer_drop_adviser_port_event_cb */
    wjh_buffer_drop_acl_create_spc2,             /* wjh_buffer_drop_acl_create_cb. ACL is same for spc1&2*/
    wjh_buffer_drop_acl_destroy_spc2,            /* wjh_buffer_drop_acl_destroy_cb */
    wjh_roce_drop_acl_create,                    /* wjh_roce_drop_acl_create_cb */
    wjh_roce_drop_acl_destroy,                   /* wjh_roce_drop_acl_destroy_cb */
    wjh_roce_drop_acl_rules_set,                 /* wjh_roce_drop_acl_rules_set_cb */
    wjh_user_channel_timestamp_source_set_spc2, /* wjh_user_channel_timestamp_source_set_cb */
    wjh_policer_limits_get_spc2, /* wjh_policer_limits_get_cb */
    wjh_mirror_header_v2_size_get_spc4, /* wjh_mirror_header_v2_size_get_cb */
    wjh_buffer_drop_sdk_mirror_to_cpu_mode_set, /* wjh_buffer_drop_mirror_to_cpu_mode_set_cb */
};

#endif /* __WJH_DEV_SDK_H__ */
