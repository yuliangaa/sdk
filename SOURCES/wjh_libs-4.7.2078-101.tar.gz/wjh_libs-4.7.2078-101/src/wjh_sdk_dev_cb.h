/*
 * Copyright © 2001-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef __WJH_SDK_DEV_CB_H__
#define __WJH_SDK_DEV_CB_H__

#include <stdio.h>
#include "wjh/wjh_lib.h"
#include <sx/sdk/sx_api.h>
#include "wjh_common.h"

/* SPC callback */
wjh_status_t wjh_buffer_drop_sdk_span_init_spc(sx_api_handle_t                     sx_api_handle_s,
                                               const wjh_drop_reason_group_attr_t *attr_p,
                                               const wjh_policer_attrs_t          *policer_attrs_p);
wjh_status_t wjh_buffer_drop_sdk_span_deinit_spc(sx_api_handle_t sx_api_handle_s);
wjh_status_t wjh_buffer_drop_sdk_adviser_port_event_spc(sx_api_handle_t sx_api_handle_s,
                                                        void           *event,
                                                        uint8_t         reason_bits);

wjh_status_t wjh_buffer_drop_acl_create_spc(sx_api_handle_t handle, const wjh_drop_reason_group_attr_t *attr_p);
wjh_status_t wjh_buffer_drop_acl_destroy_spc(sx_api_handle_t handle);
wjh_status_t wjh_user_channel_timestamp_source_set_spc(sx_api_handle_t                     handle,
                                                       wjh_user_channel_id_t               channel_id,
                                                       wjh_user_channel_timestamp_source_e timestamp_source);
wjh_status_t wjh_policer_limits_get_spc(wjh_policer_limits_t *limits_p);

/* SPC2 callback */
wjh_status_t wjh_buffer_drop_sdk_span_init_spc2(sx_api_handle_t                     sx_api_handle_s,
                                                const wjh_drop_reason_group_attr_t *attr_p,
                                                const wjh_policer_attrs_t          *policer_attrs_p);
wjh_status_t wjh_buffer_drop_sdk_span_session_bind_unbind(sx_api_handle_t sx_api_handle_s, boolean_t bind);
wjh_status_t wjh_buffer_drop_sdk_span_session_set(sx_api_handle_t sx_api_handle_s, boolean_t enable);
wjh_status_t wjh_buffer_drop_sdk_span_deinit_spc2(sx_api_handle_t sx_api_handle_s);
wjh_status_t wjh_buffer_drop_sdk_mirror_to_cpu_mode_set(boolean_t mode);
wjh_status_t wjh_buffer_drop_sdk_adviser_port_event_spc2(sx_api_handle_t sx_api_handle_s,
                                                         void           *event,
                                                         uint8_t         reason_bits);
wjh_status_t wjh_buffer_drop_acl_create_spc2(sx_api_handle_t handle, const wjh_drop_reason_group_attr_t *attr_p);
wjh_status_t wjh_buffer_drop_acl_destroy_spc2(sx_api_handle_t handle);
wjh_status_t wjh_user_channel_timestamp_source_set_spc2(sx_api_handle_t                     handle,
                                                        wjh_user_channel_id_t               channel_id,
                                                        wjh_user_channel_timestamp_source_e timestamp_source);
wjh_status_t wjh_policer_limits_get_spc2(wjh_policer_limits_t *limits_p);

/* For both SPC1 & SPC2 */
wjh_status_t wjh_roce_drop_acl_create(sx_api_handle_t handle, const wjh_drop_reason_group_attr_t *attr_p);
wjh_status_t wjh_roce_drop_acl_destroy(sx_api_handle_t handle);
wjh_status_t wjh_roce_drop_acl_rules_set(uint64_t  handle,
                                         uint8_t   reason_bits,
                                         boolean_t trap);
wjh_status_t wjh_mirror_header_v2_size_get(uint32_t *size_p);

/*SPC4 callback */
wjh_status_t wjh_mirror_header_v2_size_get_spc4(uint32_t *size_p);

#endif /* __WJH_SDK_DEV_CB_H__ */
