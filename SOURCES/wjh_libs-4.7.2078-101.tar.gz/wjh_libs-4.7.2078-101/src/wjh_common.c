/*
 * Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <errno.h>
#include <stdint.h>
#include <endian.h>
#include <byteswap.h>
#include <sys/types.h>
#include <sys/utsname.h>
#include <fcntl.h>
#include <complib/cl_mem.h>
#include <ctype.h>
#include <dirent.h>
#include "wjh_log.h"
#include "wjh_common.h"

#undef  __MODULE__
#define __MODULE__ WJH_UTIL

/************************************************
 *  Local Macros
 ***********************************************/

#define WJH_SYSFS_PCI_PATH     "/sys/bus/pci/devices"
#define WJH_PROC_UPTIME_PATH   "/proc/uptime"
#define WJH_PCI_UTILS_BUF_LEN  (1024)
#define WJH_MELLANOX_VENDOR_ID (0x15b3)

#define WJH_PCI_STATUS           (0x06)     /* 16 bits */
#define WJH_PCI_STATUS_CAP_LIST  (0x10)     /* Support Capability List */
#define WJH_PCI_CAPABILITY_LIST  (0x34)     /* Offset of first capability list entry */
#define WJH_PCI_CAP_LIST_ID      (0)        /* Capability ID */
#define WJH_PCI_CAP_LIST_NEXT    (1)        /* Next capability in the list */
#define WJH_PCI_CAP_ID_EXP       (0x10)     /* PCI Express */
#define WJH_PCI_EXP_LNKSTA       (0x12)     /* Link Status */
#define WJH_PCI_EXP_LNKSTA_SPEED (0x000f)   /* Negotiated Link Speed */
#define WJH_PCI_EXP_LNKSTA_WIDTH (0x03f0)   /* Negotiated Link Width */

#if __BYTE_ORDER == __BIG_ENDIAN
#define wjh_letoh16(x) bswap_16(x)
#else               /* Little Endian */
#define wjh_letoh16(x) (x)
#endif

/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/
static wjh_status_t __wjh_read_pci_data(int fd, void *buf_p, off_t offset, size_t len)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    int          ret = 0;

    if (lseek(fd, offset, SEEK_SET) < 0) {
        WJH_LOG_INF("Failed to seek the pci proc file, err: %s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    ret = read(fd, buf_p, len);
    if ((ret < 0) || (ret != ((int)len))) {
        WJH_LOG_INF("Failed to read the pci proc file, err: %s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_read_pci_uint8(int fd, uint8_t *dest_p, off_t offset)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint8_t      dest;

    err = __wjh_read_pci_data(fd, &dest, offset, sizeof(uint8_t));
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_INF("__wjh_read_pci_data failed\n");
        goto out;
    }

    *dest_p = dest;

out:
    return err;
}

static wjh_status_t __wjh_read_pci_uint16(int fd, uint16_t *dest_p, off_t offset)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint16_t     dest;

    err = __wjh_read_pci_data(fd, &dest, offset, sizeof(uint16_t));
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_INF("__wjh_read_pci_data failed\n");
        goto out;
    }

    *dest_p = wjh_letoh16(dest);

out:
    return err;
}

static wjh_status_t __wjh_get_pci_link_status(int fd, uint16_t *speed_p, uint16_t *width_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint16_t     status;
    uint8_t      been_there[256];
    uint8_t      where;
    uint8_t      id;
    uint8_t      next;
    uint16_t     speed_width;

    err = __wjh_read_pci_uint16(fd, &status, WJH_PCI_STATUS);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_INF("__wjh_read_pci_uint16 failed\n");
        goto out;
    }

    if (!(status & WJH_PCI_STATUS_CAP_LIST)) {
        WJH_LOG_INF("PCI capability list is not supported\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    err = __wjh_read_pci_uint8(fd, &where, WJH_PCI_CAPABILITY_LIST);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_INF("__wjh_read_pci_uint8 failed\n");
        goto out;
    }
    where = where & ~3;

    memset(been_there, 0, sizeof(been_there));
    while (where) {
        if (been_there[where]) {
            break;
        } else {
            been_there[where] = 1;
        }

        err = __wjh_read_pci_uint8(fd, &id, where + WJH_PCI_CAP_LIST_ID);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_INF("__wjh_read_pci_uint8 failed\n");
            goto out;
        }

        err = __wjh_read_pci_uint8(fd, &next, where + WJH_PCI_CAP_LIST_NEXT);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_INF("__read_pci_uint8 failed\n");
            goto out;
        }
        next = next & ~3;

        if (id == 0xff) {
            break;
        } else if (id == WJH_PCI_CAP_ID_EXP) {
            err = __wjh_read_pci_uint16(fd, &speed_width, where + WJH_PCI_EXP_LNKSTA);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_INF("__wjh_read_pci_uint16 failed\n");
                goto out;
            }

            *speed_p = speed_width & WJH_PCI_EXP_LNKSTA_SPEED;
            *width_p = (speed_width & WJH_PCI_EXP_LNKSTA_WIDTH) >> 4;

            goto out;
        } else {
            where = next;
        }
    }

    WJH_LOG_INF("Couldn't find the PCI speed and width information\n");
    err = WJH_STATUS_ERROR;

out:
    return err;
}

static boolean_t __is_spectrum_family_device(uint32_t vendor, uint32_t device)
{
    if (vendor != WJH_MELLANOX_VENDOR_ID) {
        return FALSE;
    }

    switch (device) {
    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
    case SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        return TRUE;

    default:
        return FALSE;
    }
}

static wjh_status_t __get_integer_from_file(const char* path, uint32_t *num_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    FILE        *f = NULL;
    int          cnt;
    char         buf[WJH_PCI_UTILS_BUF_LEN];

    f = fopen(path, "r");
    if (f == NULL) {
        WJH_LOG_INF("Failed to open file %s, err: %s\n", path, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (fgets(buf, sizeof(buf) - 1, f) == NULL) {
        WJH_LOG_INF("Failed to read file %s, err: %s\n", path, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    cnt = sscanf(buf, "%x", num_p);
    if (cnt != 1) {
        WJH_LOG_INF("Failed to parse content of file %s, err: %s\n", path, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    if (f != NULL) {
        fclose(f);
    }

    return err;
}


wjh_status_t wjh_pci_link_status_get(uint16_t *speed_p, uint16_t *width_p)
{
    wjh_status_t   err = WJH_STATUS_SUCCESS;
    char           buf[WJH_PCI_UTILS_BUF_LEN];
    uint32_t       vendor;
    uint32_t       device;
    struct dirent *entry;
    DIR           *dir = NULL;
    boolean_t      found = FALSE;
    uint16_t       speed;
    uint16_t       width;
    int            fd = -1;

    WJH_CHECK_NULL_PTR(speed_p, speed_p);
    WJH_CHECK_NULL_PTR(width_p, width_p);

    dir = opendir(WJH_SYSFS_PCI_PATH);
    if (dir == NULL) {
        WJH_LOG_INF("Failed to open directory %s, err: %s\n", WJH_SYSFS_PCI_PATH, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    while ((entry = readdir(dir)) != NULL) {
        if (strcmp(entry->d_name, ".") == 0) {
            continue;
        }
        if (strcmp(entry->d_name, "..") == 0) {
            continue;
        }

        snprintf(buf, sizeof(buf), "%s/%s/vendor", WJH_SYSFS_PCI_PATH, entry->d_name);
        err = __get_integer_from_file(buf, &vendor);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_INF("Failed to get vendor ID from file %s, err: %d\n", buf, err);
            continue;
        }

        snprintf(buf, sizeof(buf), "%s/%s/device", WJH_SYSFS_PCI_PATH, entry->d_name);
        err = __get_integer_from_file(buf, &device);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_INF("Failed to get device ID from file %s, err: %d\n", buf, err);
            continue;
        }

        if (__is_spectrum_family_device(vendor, device)) {
            found = TRUE;
            break;
        }
    }

    if (!found) {
        WJH_LOG_INF("Failed to find NVIDIA PCI device\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    snprintf(buf, sizeof(buf), "%s/%s/config", WJH_SYSFS_PCI_PATH, entry->d_name);
    fd = open(buf, O_RDONLY, 0);
    if (fd < 0) {
        WJH_LOG_INF("Failed to open file %s, err: %s\n", buf, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    err = __wjh_get_pci_link_status(fd, &speed, &width);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_INF("__wjh_get_pci_link_status failed\n");
        goto out;
    }

    *speed_p = speed;
    *width_p = width;

out:
    if (fd >= 0) {
        close(fd);
    }

    if (dir != NULL) {
        closedir(dir);
    }

    return err;
}

wjh_status_t wjh_str_dup(char **dst, const char *src)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    char        *str = NULL;

    WJH_CHECK_NULL_PTR(dst, dst);
    WJH_CHECK_NULL_PTR(src, src);

    str = (char*)cl_malloc(strlen(src) + 1);
    if (str == NULL) {
        WJH_LOG_ERR("Failed to allocate memory for string\n");
        err = WJH_STATUS_NO_MEMORY;
        goto out;
    }
    strcpy(str, src);
    *dst = str;

out:
    return err;
}

wjh_status_t wjh_system_boot_time_get(struct timespec *ts_p)
{
    wjh_status_t    err = WJH_STATUS_SUCCESS;
    time_t          sec = 0;
    long            nsec = 0;
    FILE           *fp = NULL;
    char            buf[1024];
    char           *endptr = NULL;
    double          upsecs = 0.0f;
    struct timespec ts;
    int             ret;

    WJH_CHECK_NULL_PTR(ts_p, ts_p);

    fp = fopen(WJH_PROC_UPTIME_PATH, "r");
    if (fp == NULL) {
        WJH_LOG_ERR("Failed to open %s, err: %s\n", WJH_PROC_UPTIME_PATH, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (fgets(buf, sizeof(buf), fp) == NULL) {
        WJH_LOG_ERR("Failed to read the content of %s\n", WJH_PROC_UPTIME_PATH);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    upsecs = strtod(buf, &endptr);
    if (endptr == buf) {
        WJH_LOG_ERR("Failed to parse the content of %s\n", WJH_PROC_UPTIME_PATH);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    sec = (time_t)upsecs;
    nsec = (upsecs - sec) * 1000000000;

    ret = clock_gettime(CLOCK_REALTIME, &ts);
    if (ret < 0) {
        WJH_LOG_ERR("clock_gettime failed, err: %s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if ((ts.tv_sec < sec) || ((ts.tv_sec == sec) && (ts.tv_nsec < nsec))) {
        WJH_LOG_ERR("Invalid system time, tv_sec: %ld, tv_nsec: %ld\n",
                    ts.tv_sec, ts.tv_nsec);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (ts.tv_nsec >= nsec) {
        ts_p->tv_sec = ts.tv_sec - sec;
        ts_p->tv_nsec = ts.tv_nsec - nsec;
    } else {
        ts_p->tv_sec = ts.tv_sec - sec - 1;
        ts_p->tv_nsec = ts.tv_nsec + 1000000000 - nsec;
    }

out:
    if (fp != NULL) {
        fclose(fp);
    }
    return err;
}

wjh_status_t wjh_get_linux_kernel_version(int *version_p, int *major_p, int *minor_p)
{
    wjh_status_t   err = WJH_STATUS_SUCCESS;
    int            ver[3] = { 0 };
    struct utsname buffer;
    char          *p;
    int            i = 0;

    WJH_CHECK_NULL_PTR(version_p, version_p);
    WJH_CHECK_NULL_PTR(major_p, major_p);
    WJH_CHECK_NULL_PTR(minor_p, minor_p);

    if (uname(&buffer) < 0) {
        WJH_LOG_ERR("uname failed, err:%s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    p = buffer.release;
    while ((*p) && (i < 3)) {
        if (isdigit(*p)) {
            ver[i] = strtol(p, &p, 10);
            i++;
        } else {
            p++;
        }
    }

    *version_p = ver[0];
    *major_p = ver[1];
    *minor_p = ver[2];

out:
    return err;
}
