/*
 * Copyright © 2001-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <complib/cl_spinlock.h>
#include "wjh_callbacks.h"
#ifdef SDK_PRESENT
#include "wjh_callbacks_sdk.h"
#elif MLXSW_PRESENT
#include "wjh_callbacks_mlxsw.h"
#endif

/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/

#ifdef SDK_PRESENT
wjh_driver_specific_callback_t *wjh_driver_specific_callbacks_g = &wjh_sdk_callbacks;
#elif MLXSW_PRESENT
wjh_driver_specific_callback_t *wjh_driver_specific_callbacks_g = &wjh_mlxsw_callbacks;
#endif

/************************************************
 *  Local variables
 ***********************************************/


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/
