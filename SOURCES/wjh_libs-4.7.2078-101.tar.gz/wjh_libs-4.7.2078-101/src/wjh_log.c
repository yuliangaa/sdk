/*
 * Copyright © 2001-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <complib/cl_types.h>
#include "wjh_log.h"
#include "wjh_common.h"

/************************************************
 *  Local Macros
 ***********************************************/

#define WJH_LOG_STR_SIZE_MAX 1024

/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/

static wjh_verbosity_level_t wjh_log_verbosity_level_s = WJH_VERBOSITY_LEVEL_NOTICE;
static boolean_t             wjh_sys_log_opened_s = FALSE;
static wjh_log_cb_t          wjh_log_cb_s = NULL;


/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/

wjh_status_t wjh_log_verbosity_level_set(const wjh_verbosity_level_t level)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (!WJH_VERBOSITY_LEVEL_CHECK_RANGE(level)) {
        err = WJH_STATUS_PARAM_ERROR;
        WJH_LOG_ERR("Verbosity level exceeds range.\n");
        goto out;
    }

    wjh_log_verbosity_level_s = level;

out:
    return err;
}

wjh_status_t wjh_log_verbosity_level_get(wjh_verbosity_level_t *level_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    WJH_CHECK_NULL_PTR(level_p, level_p);

    *level_p = wjh_log_verbosity_level_s;

out:
    return err;
}

void wjh_log(wjh_verbosity_level_t level, const char *fmt, ...)
{
    int     priority;
    char    buf[WJH_LOG_STR_SIZE_MAX];
    va_list args;

    if ((int)wjh_log_verbosity_level_s < (int)level) {
        return;
    }

    va_start(args, fmt);
    vsnprintf(buf, WJH_LOG_STR_SIZE_MAX, fmt, args);

    if (wjh_log_cb_s == NULL) {
        if (!wjh_sys_log_opened_s) {
            openlog(NULL, LOG_NDELAY | LOG_PID, LOG_USER);
            wjh_sys_log_opened_s = TRUE;
        }

        switch (level) {
        case WJH_VERBOSITY_LEVEL_NONE:
            goto out;

        case WJH_VERBOSITY_LEVEL_ERROR:
            priority = LOG_ERR;
            break;

        case WJH_VERBOSITY_LEVEL_WARNING:
            priority = LOG_WARNING;
            break;

        case WJH_VERBOSITY_LEVEL_NOTICE:
            priority = LOG_NOTICE;
            break;

        case WJH_VERBOSITY_LEVEL_INFO:
            priority = LOG_INFO;
            break;

        case WJH_VERBOSITY_LEVEL_DEBUG:
        default:
            priority = LOG_DEBUG;
            break;
        }

        syslog(priority, "[WJH_LIB.%s]: %s", WJH_VERBOSITY_LEVEL_STR(level), buf);
    } else {
        wjh_log_cb_s(level, buf);
    }

out:
    va_end(args);
}

void wjh_log_cb_set(wjh_log_cb_t log_cb)
{
    wjh_log_cb_s = log_cb;
}
