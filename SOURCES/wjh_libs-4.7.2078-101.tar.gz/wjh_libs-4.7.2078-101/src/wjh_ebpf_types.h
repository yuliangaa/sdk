/*
 * Copyright © 2001-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_EBPF_TYPES_H_
#define WJH_EBPF_TYPES_H_

typedef struct wjh_agg_ebpf_five_tuples {
    uint32_t sip[4];
    uint32_t dip[4];
    uint8_t  is_ipv6;
    uint8_t  ip_proto;
    uint16_t sport;
    uint16_t dport;
} __attribute__((packed)) wjh_agg_ebpf_five_tuples_t;

typedef struct wjh_agg_ebpf_key {
    wjh_agg_ebpf_five_tuples_t five_tuples;
    uint8_t                    non_ip;
    uint32_t                   port;
    uint16_t                   vlan;
    uint16_t                   ether_type;
    uint8_t                    dmac[6];
    uint8_t                    smac[6];
    uint32_t                   reason_id;
} __attribute__((packed)) wjh_agg_ebpf_key_t;

typedef struct wjh_agg_ebpf_timestamp {
    uint32_t tv_sec;
    uint32_t tv_nsec;
} __attribute__((packed)) wjh_agg_ebpf_timestamp_t;

typedef struct wjh_agg_ebpf_egress_data {
    uint32_t egress_port;
    uint8_t  tc;
    uint16_t port_tc_watermark;
    uint32_t latency_watermark;
} __attribute__((packed)) wjh_agg_ebpf_egress_data_t;

typedef struct wjh_agg_ebpf_value {
    wjh_agg_ebpf_timestamp_t   first_timestamp;
    wjh_agg_ebpf_timestamp_t   last_timestamp;
    uint64_t                   count;
    uint8_t                    egress_data_valid;
    wjh_agg_ebpf_egress_data_t egress_data;
} __attribute__((packed)) wjh_agg_ebpf_value_t;

typedef struct wjh_filter_rule_ebpf_key {
    uint32_t hw_port;
    uint32_t drop_reason;
    uint8_t  ip_proto;
    uint16_t ether_type;
    uint8_t  valid_mask;
} __attribute__((packed)) wjh_filter_rule_ebpf_key_t;

#endif /* WJH_EBPF_TYPES_H_ */
