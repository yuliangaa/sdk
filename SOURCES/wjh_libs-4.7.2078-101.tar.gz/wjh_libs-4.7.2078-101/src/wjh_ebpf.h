/*
 * Copyright © 2001-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_EBPF_H_
#define WJH_EBPF_H_

#include <linux/bpf.h>
#include "wjh/wjh_lib.h"

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef struct wjh_ebpf_trace_point_attach_attr {
    const char *event_id_path_p;
    int         event_fd;
} wjh_ebpf_trace_point_attach_attr_t;

typedef struct wjh_ebpf_socket_filter_attach_attr {
    int socket_fd;
} wjh_ebpf_socket_filter_attach_attr_t;

typedef struct wjh_ebpf_prog_attach_attr {
    union {
        wjh_ebpf_trace_point_attach_attr_t   trace_point;
        wjh_ebpf_socket_filter_attach_attr_t socket_filter;
    } attach_attr;
} wjh_ebpf_prog_attach_attr_t;

typedef enum wjh_ebpf_prog_op {
    WJH_EBPF_PROG_OP_ATTACH,
    WJH_EBPF_PROG_OP_DETACH,
    WJH_EBPF_PROG_OP_MIN = WJH_EBPF_PROG_OP_ATTACH,
    WJH_EBPF_PROG_OP_MAX = WJH_EBPF_PROG_OP_DETACH,
} wjh_ebpf_prog_op_e;

/************************************************
 *  Function declarations
 ***********************************************/

wjh_status_t wjh_ebpf_map_create(const enum bpf_map_type map_type,
                                 const uint32_t          key_size,
                                 const uint32_t          value_size,
                                 const uint32_t          max_entries_cnt,
                                 int                    *map_fd_p);

wjh_status_t wjh_ebpf_map_elem_update(const int      map_fd,
                                      const void    *key_p,
                                      const void    *value_p,
                                      const uint64_t flags);

wjh_status_t wjh_ebpf_map_elem_lookup(const int map_fd, const void *key_p, void *value_p);

wjh_status_t wjh_ebpf_map_elem_delete(const int map_fd, const void *key_p);

wjh_status_t wjh_ebpf_map_next_key_get(const int map_fd, const void *key_p, void *next_key_p);

wjh_status_t wjh_ebpf_program_load(const char              *elf_file_path_p,
                                   const enum bpf_prog_type prog_type,
                                   const char              *bpf_prog_sec_name,
                                   const char             **bpf_map_name_list_p,
                                   const int               *bpf_map_fd_list_p,
                                   const uint32_t           bpf_map_count,
                                   int                     *bpf_prog_fd_p);

wjh_status_t wjh_ebpf_program_set(const int                    bpf_prog_fd,
                                  const enum bpf_prog_type     prog_type,
                                  const wjh_ebpf_prog_op_e     op,
                                  wjh_ebpf_prog_attach_attr_t *attach_attr_p);

#endif /* WJH_EBPF_H_ */
