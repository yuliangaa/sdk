/*
 * Copyright © 2001-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_DB_H_
#define WJH_DB_H_

#include <sys/ioctl.h>
#include <net/if.h>
#include <wjh/wjh_lib.h>
#include "wjh_common.h"
#include "wjh_ebpf_types.h"
#include <complib/cl_types.h>
#include <complib/cl_event.h>
#include <complib/cl_passivelock.h>
#include <complib/cl_thread.h>
#include <complib/cl_fleximap.h>
#ifdef SDK_PRESENT
#include <sx/sdk/sx_host.h>
#endif
#include <sx/utils/id_allocator.h>

/************************************************
 *  Macros
 ***********************************************/
#define WJH_DROP_REASON_GROUP_NUM (WJH_DROP_REASON_GROUP_MAX_E + 1)
#define WJH_USER_CHANNEL_MAX_NUM  (5)
#define WJH_FILTER_KEY_NUM        (WJH_FILTER_KEY_MAX_E + 1)
#define WJH_FILTER_RULE_NUM_MAX   (1024)
#define WJH_FILTER_NUM_MAX        (256)
#define WJH_PORT_NUM_MAX          (512)

#ifdef SDK_PRESENT
#define WJH_TRAP_ID_MAX          SX_TRAP_ID_MAX
#define WJH_BUFFER_DROP_ACL_NUM  2
#define WJH_BUFFER_DROP_RULE_NUM 3
#define WJH_ROCE_RULE_NUM_MAX    64
#elif MLXSW_PRESENT
#define WJH_TRAP_ID_MAX (0x210)
#endif
#define WJH_TRAP_GROUP_INVALID (0xffff)

#define WJH_L1_PORT_DOWN_REASON_INDEX_MIN                             (0)
#define WJH_L1_PORT_DOWN_REASON_NUM                                   (11)
#define WJH_L1_PORT_DOWN_REASON_ID_PORT_ADMIN_DOWN                    (10021)
#define WJH_L1_PORT_DOWN_REASON_ID_AUTO_NEGOTIATION_FAILURE           (10022)
#define WJH_L1_PORT_DOWN_REASON_ID_LOGICAL_MISMATCH_WITH_PEER_LINK    (10023)
#define WJH_L1_PORT_DOWN_REASON_ID_LINK_TRAINING_FAILURE              (10024)
#define WJH_L1_PORT_DOWN_REASON_ID_PEER_IS_SENDING_REMOTE_FAULTS      (10025)
#define WJH_L1_PORT_DOWN_REASON_ID_BAD_SIGNAL_INTEGRITY               (10026)
#define WJH_L1_PORT_DOWN_REASON_ID_CABLE_TRANSCEIVER_IS_NOT_SUPPORTED (10027)
#define WJH_L1_PORT_DOWN_REASON_ID_CABLE_TRANSCEIVER_IS_UNPLUGGED     (10028)
#define WJH_L1_PORT_DOWN_REASON_ID_CALIBRATION_FAILURE                (10029)
#define WJH_L1_PORT_DOWN_REASON_ID_CABLE_TRANSCEIVER_BAD_STATUS       (10030)
#define WJH_L1_PORT_DOWN_REASON_ID_OTHER_REASON                       (10031)
#define WJH_L1_PORT_DOWN_REASON_ID_MIN                                (WJH_L1_PORT_DOWN_REASON_ID_PORT_ADMIN_DOWN)
#define WJH_L1_DROP_REASON_ID_PORT_STATE_CHANGE                       (1002)
#define WJH_L1_DROP_REASON_ID_SYMBOL_ERROR                            (1004)
#define WJH_L1_DROP_REASON_ID_CRC_ERROR                               (1005)
#define WJH_L1_DROP_REASON_INDEX_MIN     \
    (WJH_L1_PORT_DOWN_REASON_INDEX_MIN + \
     WJH_L1_PORT_DOWN_REASON_NUM)
#define WJH_L1_DROP_REASON_NUM    (4)
#define WJH_L1_DROP_REASON_ID_MIN (1002)
#define WJH_ACL_DROP_REASON_INDEX_MIN \
    (WJH_L1_DROP_REASON_INDEX_MIN +   \
     WJH_L1_DROP_REASON_NUM)
#define WJH_ACL_DROP_REASON_NUM    (9)
#define WJH_ACL_DROP_REASON_ID_MIN (601)
#define WJH_BUFFER_DROP_REASON_INDEX_MIN \
    (WJH_ACL_DROP_REASON_INDEX_MIN +     \
     WJH_ACL_DROP_REASON_NUM)
#define WJH_BUFFER_DROP_REASON_NUM    (4)
#define WJH_BUFFER_DROP_REASON_ID_MIN (503)
#define WJH_L2_DROP_REASON_INDEX_MIN    \
    (WJH_BUFFER_DROP_REASON_INDEX_MIN + \
     WJH_BUFFER_DROP_REASON_NUM)
#define WJH_L2_DROP_REASON_NUM    (13)
#define WJH_L2_DROP_REASON_ID_MIN (201)
#define WJH_ROUTER_DROP_REASON_INDEX_MIN \
    (WJH_L2_DROP_REASON_INDEX_MIN +      \
     WJH_L2_DROP_REASON_NUM)
#define WJH_ROUTER_DROP_REASON_NUM    (29)
#define WJH_ROUTER_DROP_REASON_ID_MIN (301)
#define WJH_TUNNEL_DROP_REASON_INDEX_MIN \
    (WJH_ROUTER_DROP_REASON_INDEX_MIN +  \
     WJH_ROUTER_DROP_REASON_NUM)
#define WJH_TUNNEL_DROP_REASON_NUM    (5)
#define WJH_TUNNEL_DROP_REASON_ID_MIN (402)
#define WJH_ROCE_DROP_REASON_INDEX_MIN  \
    (WJH_TUNNEL_DROP_REASON_INDEX_MIN + \
     WJH_TUNNEL_DROP_REASON_NUM)
#define WJH_ROCE_DROP_REASON_NUM    (3)
#define WJH_ROCE_DROP_REASON_ID_MIN (701)

#define WJH_DROP_REASONS_NUM                                                          \
    (WJH_L1_PORT_DOWN_REASON_NUM + WJH_L1_DROP_REASON_NUM + WJH_ACL_DROP_REASON_NUM + \
     WJH_BUFFER_DROP_REASON_NUM + WJH_L2_DROP_REASON_NUM +                            \
     WJH_ROUTER_DROP_REASON_NUM + WJH_TUNNEL_DROP_REASON_NUM +                        \
     WJH_ROCE_DROP_REASON_NUM)
#define WJH_DB_EMPTY_STR ""
#define WJH_DB_NA_STR    "N/A"

#define WJH_BUFFER_DROP_REASON_ALL ((1 << WJH_BUFFER_DROP_REASON_NUM) - 1)
#define WJH_BUFFER_DROP_REASON_SET(reason_bits, reason) \
    (reason_bits |=                                     \
         (1 << (reason - WJH_BUFFER_DROP_REASON_ID_MIN)))
#define WJH_BUFFER_DROP_REASON_CHECK(reason_bits, \
                                     reason) ((reason_bits >> (reason - WJH_BUFFER_DROP_REASON_ID_MIN)) & 1)

#define WJH_ROCE_DROP_REASON_ALL ((1 << WJH_ROCE_DROP_REASON_NUM) - 1)
#define WJH_ROCE_DROP_REASON_SET(reason_bits, reason) \
    (reason_bits |=                                   \
         (1 << (reason - WJH_ROCE_DROP_REASON_ID_MIN)))
#define WJH_ROCE_DROP_REASON_CHECK(reason_bits, \
                                   reason) ((reason_bits >> (reason - WJH_ROCE_DROP_REASON_ID_MIN)) & 1)

#define WJH_DROP_REASON_SET(reason_bits, reason_id, reason_id_min) \
    (reason_bits |=                                                \
         (1 << (reason_id - reason_id_min)))
/************************************************
 *  Type definitions
 ***********************************************/

#ifdef SDK_PRESENT
typedef sx_trap_id_t wjh_trap_id_t;
typedef sx_trap_group_t wjh_trap_group_t;
typedef sx_fd_t wjh_fd_t;
#elif MLXSW_PRESENT
typedef uint32_t wjh_trap_id_t;
typedef uint32_t wjh_trap_group_t;
typedef int wjh_fd_t;
#endif


typedef struct wjh_trap_id_item {
    wjh_trap_id_t        trap_id;
    wjh_drop_reason_id_t reason_id;
} wjh_trap_id_item_t;

typedef struct wjh_drop_reason_item {
    wjh_drop_reason_id_t id;
    wjh_severity_e       severity;
    wjh_event_type_e     event_type;
    char                *reason;
    char                *description;
    boolean_t            enabled;
    boolean_t            filtered;
} wjh_drop_reason_item_t;

typedef struct wjh_trap_id_attr {
    wjh_trap_id_t           trap_id;
    sx_trap_action_t        trap_action;
    wjh_drop_reason_group_e drop_reason_group;
    wjh_drop_reason_item_t *drop_reason;
} wjh_trap_id_attr_t;

typedef struct wjh_drop_reason_group_record {
    wjh_drop_reason_group_e      drop_reason_group;
    wjh_drop_reason_group_attr_t attr;
    wjh_drop_callbacks_t         callbacks;
    wjh_user_channel_id_t        channel_id;
    wjh_trap_id_item_t          *trap_ids;
    uint32_t                     trap_id_num;
    boolean_t                    bound;
    uint8_t                      enabled_severity_bits;
    uint8_t                      enabled_drop_reason_bits;
    boolean_t                    enabled;
    boolean_t                    inited;
#ifdef WJH_EBPF_PRESENT
    int       aggregation_ebpf_prog_fd;
    int       aggregation_ebpf_map_fd;
    boolean_t aggregation_ebpf_prog_fd_attached;
    void     *aggregation_key_buf;
    void     *aggregation_data_buf;
    void     *aggregation_key_sip_buf;
    void     *aggregation_key_dip_buf;
#endif
} wjh_drop_reason_group_record_t;

typedef struct wjh_db_filter_rule_map_key {
    wjh_port_log_id_t    port;
    wjh_drop_reason_id_e drop_reason;
    uint8_t              ip_proto;
    uint16_t             ether_type;
    uint8_t              valid_mask;
} wjh_db_filter_rule_map_key_t;

typedef struct wjh_db_filter_rule_record {
    cl_pool_item_t               pool_item;
    cl_fmap_item_t               map_item;
    wjh_db_filter_rule_map_key_t map_key;
    wjh_filter_rule_ebpf_key_t   ebpf_key;
    boolean_t                    is_key_set[WJH_FILTER_KEY_NUM];
    wjh_filter_key_field_t       key_field[WJH_FILTER_KEY_NUM];
    uint32_t                     key_desc_count;
    uint16_t                     label_port;                    /**< valid in case port key is set */
    uint64_t                     counter;
} wjh_db_filter_rule_record_t;

typedef struct wjh_db_filter_record {
    cl_pool_item_t  pool_item;
    cl_map_item_t   map_item;
    wjh_filter_id_t filter_id;
    boolean_t       is_key_set[WJH_FILTER_KEY_NUM];
    boolean_t       bound[WJH_USER_CHANNEL_MAX_NUM];
    uint32_t        keys_num;
    uint32_t        rules_num;
    uint64_t        counter;
    cl_qpool_t      rules_pool;
    cl_fmap_t       rules_map;
    int             ebpf_prog_fd;
    int             ebpf_map_fd;
} wjh_db_filter_record_t;

typedef struct wjh_user_channel_record {
    wjh_user_channel_id_t               channel_id;
    wjh_user_channel_type_e             channel_type;
    wjh_fd_t                            fd;
    wjh_trap_group_t                    trap_group_id;
    boolean_t                           bound[WJH_DROP_REASON_GROUP_NUM];
    boolean_t                           created;
    uint32_t                            group_enable_count;
    uint64_t                            received_packets;
    uint64_t                            dropped_packets;
    uint32_t                            polling_interval;
    cl_spinlock_t                       lock;
    cl_thread_t                         thread;
    boolean_t                           stop_thread;
    int                                 cmd_event_fd;
    wjh_user_channel_mode_e             mode;
    uint32_t                            hw_trap_group;
    wjh_db_filter_record_t             *filter_record_p;
    wjh_aggregation_read_mode_e         aggregation_read_mode;
    wjh_user_channel_timestamp_source_e timestamp_source;
    wjh_user_channel_destination_e      user_channel_dest;
} wjh_user_channel_record_t;

typedef struct wjh_hw_info_db {
    wjh_chip_types_t      chip_type;
    wjh_dev_specific_cb_t wjh_dev_cb;
} wjh_hwd_info_db_t;

#ifdef SDK_PRESENT
typedef struct wjh_buffer_drop_db {
    sx_span_session_id_t    span_session_id;
    sx_policer_id_t         span_session_policer_id;
    wjh_port_log_id_t       recirculation_port;
    uint32_t                sampling_rate;
    sx_acl_id_t             acl_list[WJH_BUFFER_DROP_ACL_NUM];
    sx_acl_id_t             acl_group_list[WJH_BUFFER_DROP_ACL_NUM];
    sx_acl_region_id_t      acl_region_list[WJH_BUFFER_DROP_ACL_NUM];
    sx_acl_key_type_t       key_handle[WJH_BUFFER_DROP_RULE_NUM];
    sx_flex_acl_flex_rule_t acl_rules[WJH_BUFFER_DROP_RULE_NUM];
    sx_acl_rule_offset_t    rule_offset[WJH_BUFFER_DROP_RULE_NUM];
    uint32_t                rules_per_region[WJH_BUFFER_DROP_ACL_NUM];
} wjh_buffer_drop_db_t;

typedef struct wjh_roce_drop_acl_rule_info {
    sx_acl_rule_offset_t offset_start;
    uint32_t             count;
} wjh_roce_drop_acl_rule_info_t;

typedef struct wjh_roce_drop_db {
    wjh_switch_prio_t             roce_switch_prio; /* The switch priority expected for RoCE (non-CNP) traffic */
    wjh_switch_prio_t             cnp_switch_prio; /* The switch priority expected for CNP RoCE traffic */
    sx_acl_id_t                   acl_id;
    sx_acl_id_t                   acl_group_id;
    sx_acl_region_id_t            region_id;
    sx_acl_key_type_t             key_handle;
    uint32_t                      rules_count;
    wjh_roce_drop_acl_rule_info_t roce_wrong_prio_rule;
    wjh_roce_drop_acl_rule_info_t non_roce_rule;
    wjh_roce_drop_acl_rule_info_t roce_flood_rule;
} wjh_roce_drop_db_t;
#else
typedef void wjh_buffer_drop_db_t;
typedef void wjh_roce_drop_db_t;
#endif

typedef struct wjh_hw_db {
    wjh_hwd_info_db_t hw_info_db;
} wjh_hw_db_t;

#define WJH_INVALID_IF_INDEX 0xFFFFFFFF

typedef enum wjh_netdev_type {
    WJH_NETDEV_TYPE_PHY_PORT = 0,
    WJH_NETDEV_TYPE_LAG      = 1,
    WJH_NETDEV_TYPE_NUM_OF_TYPES
} wjh_netdev_type_e;

typedef struct wjh_log_port_attr {
    wjh_netdev_type_e netdev_type;
    char              netdev_name[IFNAMSIZ];
    uint32_t          log_port;
    uint32_t          lid_local;              /* lag id or local port */
    uint32_t          if_index;
} wjh_log_port_attr_t;

typedef struct wjh_db {
    wjh_drop_reason_group_record_t drop_reason_groups[WJH_DROP_REASON_GROUP_NUM];
    wjh_user_channel_record_t      user_channels[WJH_USER_CHANNEL_MAX_NUM];
    wjh_trap_id_attr_t             trap_id_attrs[WJH_TRAP_ID_MAX + 1];
#ifdef SDK_PRESENT
    wjh_buffer_drop_db_t buffer_drop_db;
    wjh_roce_drop_db_t   roce_drop_db;
#endif
    wjh_drop_reason_item_t drop_reasons[WJH_DROP_REASONS_NUM];
    cl_qpool_t             filter_pool;
    cl_qmap_t              filter_map;
    id_allocator_t         filter_id_allocator;
    /* key (log_port_type,lag_id or local_port) => log_port_attr */
    wjh_log_port_attr_t log_port_attr_db[WJH_NETDEV_TYPE_NUM_OF_TYPES][MAX_PHYPORT_NUM + 1];
} wjh_db_t;

#ifdef SDK_PRESENT
typedef struct wjh_buffer_drop_reason_group_shm_data {
    boolean_t               inited;
    boolean_t               enabled;
    uint8_t                 enabled_severity_bits;
    uint8_t                 drop_reason_bits;
    boolean_t               bound;
    sx_span_session_id_t    span_session_id;
    sx_policer_id_t         span_session_policer_id;
    wjh_port_log_id_t       recirculation_port;
    sx_acl_id_t             acl_list[WJH_BUFFER_DROP_ACL_NUM];
    sx_acl_id_t             acl_group_list[WJH_BUFFER_DROP_ACL_NUM];
    sx_acl_region_id_t      acl_region_list[WJH_BUFFER_DROP_ACL_NUM];
    sx_acl_key_type_t       key_handle[WJH_BUFFER_DROP_RULE_NUM];
    sx_flex_acl_flex_rule_t acl_rules[WJH_BUFFER_DROP_RULE_NUM];
    sx_acl_rule_offset_t    rule_offset[WJH_BUFFER_DROP_RULE_NUM];
    uint32_t                rules_per_region[WJH_BUFFER_DROP_ACL_NUM];
} wjh_buffer_drop_reason_group_shm_data_t;

typedef struct wjh_sdk_ready_file_stat_info {
    struct timespec st_atim;  /* Time of last access */
    struct timespec st_mtim;  /* Time of last modification */
    struct timespec st_ctim;  /* Time of last status change */
} wjh_sdk_ready_file_stat_info_t;

typedef struct wjh_shm_sdk_instance_info_t {
    wjh_sdk_ready_file_stat_info_t sdk_file_stat_info;
} wjh_shm_sdk_instance_info_t;

#endif

typedef struct wjh_drop_reason_group_shm_data {
#ifdef SDK_PRESENT
    wjh_buffer_drop_reason_group_shm_data_t wjh_buffer_drop_shm_data;
#endif
} wjh_drop_reason_group_shm_data_t;

typedef struct wjh_driver_shm_data {
#ifdef SDK_PRESENT
    wjh_shm_sdk_instance_info_t shm_sdk_instance_info;
#endif
} wjh_driver_shm_data_t;

typedef struct wjh_user_channel_shm_data {
    uint32_t trap_groups[WJH_USER_CHANNEL_MAX_NUM];
} wjh_user_channel_shm_data_t;
/************************************************
 *  Function declarations
 ***********************************************/

wjh_status_t wjh_db_init(void);

void wjh_db_deinit(void);

wjh_status_t wjh_db_deinit_resource_check(void);

wjh_status_t wjh_db_init_hw_info();

wjh_status_t wjh_db_drop_reason_descriptions_load(const char *xml_file_path);

void wjh_db_drop_reason_group_get(const wjh_drop_reason_group_e    drop_reason_group,
                                  wjh_drop_reason_group_record_t **item_pp);

wjh_status_t wjh_db_free_user_channel_get(wjh_user_channel_record_t **user_channel_pp);

void wjh_db_user_channel_get(const wjh_user_channel_id_t id, wjh_user_channel_record_t **record_pp);

uint8_t wjh_db_buffer_drop_reason_bits_get(uint8_t severity_bits);

wjh_status_t wjh_db_get_drop_reason_group_shm_data(const wjh_drop_reason_group_e drop_reason_group,
                                                   boolean_t enabled, void *shm_data);

#ifdef SDK_PRESENT
void wjh_db_buffer_drop_get(wjh_buffer_drop_db_t **db_pp);

void wjh_db_buffer_drop_set(wjh_buffer_drop_db_t *db_p);

wjh_status_t wjh_db_buffer_drop_map_shm_data_to_db(
    wjh_buffer_drop_reason_group_shm_data_t *buffer_drop_reason_shm_data_p,
    wjh_buffer_drop_db_t                    *db_p);

wjh_status_t wjh_db_buffer_drop_map_db_to_shm_data(wjh_buffer_drop_db_t                    *db_p,
                                                   wjh_buffer_drop_reason_group_shm_data_t *buffer_drop_reason_shm_data_p);

void wjh_db_roce_drop_get(wjh_roce_drop_db_t **db_pp);
#endif

wjh_status_t wjh_db_set_drop_reason_db_with_shm_data(const wjh_drop_reason_group_e drop_reason_group,
                                                     void                         *drop_group_shm_data_p);

wjh_status_t wjh_db_get_chip_type(wjh_chip_types_t *chip_type);

wjh_dev_specific_cb_t* wjh_db_get_dev_cb();

boolean_t wjh_is_reason_group_db_inited(wjh_drop_reason_group_e reason_group);

void wjh_db_trap_id_attr_get(const wjh_trap_id_t trap_id, wjh_trap_id_attr_t **trap_id_attr_pp);

void wjh_db_get_drop_reason_item(const int index, wjh_drop_reason_item_t **drop_reason_item_pp);

wjh_status_t wjh_db_get_drop_reason_item_by_reason(wjh_drop_reason_id_t     reason_id,
                                                   wjh_drop_reason_item_t **drop_reason_item_pp);

wjh_status_t wjh_db_filter_create(wjh_filter_key_e        *key_list_p,
                                  uint32_t                 count,
                                  wjh_db_filter_record_t **filter_record_pp);

wjh_status_t wjh_db_filter_destroy(wjh_db_filter_record_t *filter_record_p);

wjh_status_t wjh_db_filter_get(wjh_filter_id_t filter_id, wjh_db_filter_record_t **filter_record_pp);

wjh_status_t wjh_db_filter_rule_add(wjh_db_filter_record_t       *filter_record_p,
                                    wjh_filter_rule_t            *rule_p,
                                    wjh_db_filter_rule_record_t **rule_record_pp);

wjh_status_t wjh_db_filter_rule_record_get(wjh_db_filter_record_t       *filter_record_p,
                                           wjh_filter_rule_t            *rule_p,
                                           wjh_db_filter_rule_record_t **rule_record_pp);

wjh_status_t wjh_db_filter_rule_record_list_get(wjh_db_filter_record_t       *filter_record_p,
                                                wjh_db_filter_rule_record_t **rule_record_list_pp,
                                                uint32_t                     *list_count_p);

wjh_status_t wjh_db_filter_rule_record_remove(wjh_db_filter_record_t      *filter_record_p,
                                              wjh_db_filter_rule_record_t *filter_rule_record_p);


cl_plock_t* wjh_db_get_rwlock(void);

wjh_status_t wjh_db_dbg_generate_dump(FILE* stream_p);

wjh_status_t wjh_db_log_port_attr_set(uint32_t             log_port,
                                      wjh_log_port_attr_t* log_port_attr_p);
wjh_status_t wjh_db_log_port_attr_get(uint32_t             log_port,
                                      wjh_log_port_attr_t* log_port_attr_p);


#endif /* WJH_DB_H_ */
