/*
 * Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <complib/cl_spinlock.h>
#include "wjh_netlink.h"
#include "wjh_db.h"

/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/
static boolean_t   wjh_stop_netlink_ev_handler_thread_s = FALSE;
static cl_thread_t wjh_netlink_ev_handler_thread_id_s;
int                nls_g;
static boolean_t   wjh_nl_init_done_g = FALSE;

/************************************************
 *  Local function declarations
 ***********************************************/
static wjh_status_t __wjh_netlink_msg_handler(struct nlmsghdr *msg);
static wjh_status_t __wjh_netlink_parse_link_kind_sdk(struct rtattr *tb,
                                                      uint32_t     * log_port_p);
/************************************************
 *  Local variables
 ***********************************************/
typedef struct wjh_netlink_ops {
    wjh_status_t (*wjh_netlink_msg_handler_pfn)(struct nlmsghdr *);
    wjh_status_t (*wjh_netlink_parse_link_kind_pfn)(struct rtattr *tb,
                                                    uint32_t     * log_port_p);
} wjh_netlink_ops_t;

static wjh_netlink_ops_t wjh_netlink_ops = {
    .wjh_netlink_msg_handler_pfn = __wjh_netlink_msg_handler,
    .wjh_netlink_parse_link_kind_pfn = __wjh_netlink_parse_link_kind_sdk,
};

/************************************************
 *  Function implementations
 ***********************************************/

wjh_status_t wjh_netlink_open(int* nls_p)
{
    wjh_status_t       err = WJH_STATUS_SUCCESS;
    int                sock;
    struct sockaddr_nl addr;

    sock = socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
    if (sock < 0) {
        WJH_LOG_ERR("Unable to open socket\n");
        return WJH_STATUS_ERROR;
    }

    memset((void*)&addr, 0, sizeof(addr));
    addr.nl_family = AF_NETLINK;
    addr.nl_groups = RTMGRP_LINK;
    if (bind(sock, (struct sockaddr *)&addr, sizeof(addr)) < 0) {
        WJH_LOG_ERR("Unable to bind socket\n");
        close(sock);
        return WJH_STATUS_ERROR;
    }

    *nls_p = sock;
    return err;
}


wjh_status_t wjh_netlink_read_event(int sockint)
{
    int                status;
    wjh_status_t       err = WJH_STATUS_SUCCESS;
    int                ret = 0;
    char               buf[10000];
    struct iovec       iov = { buf, sizeof buf };
    struct sockaddr_nl snl;
    struct msghdr      msg = { (void*)&snl, sizeof snl, &iov, 1, NULL, 0, 0};
    struct nlmsghdr   *h;

    status = recvmsg(sockint, &msg, 0);
    if (status < 0) {
        WJH_LOG_ERR("read_netlink: Error recvmsg: %d\n", status);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    /* We need to handle more than one message per 'recvmsg' */
    for (h = (struct nlmsghdr *)buf; NLMSG_OK(h, (unsigned int)status);
         h = NLMSG_NEXT(h, status)) {
        /* Finish reading */
        if (h->nlmsg_type == NLMSG_DONE) {
            err = WJH_STATUS_SUCCESS;
            goto out;
        }

        /* Message is some kind of error */
        if (h->nlmsg_type == NLMSG_ERROR) {
            WJH_LOG_ERR("read_netlink: Message is an error - decode TBD\n");
            err = WJH_STATUS_ERROR;
            goto out;
        }

        /* Call message handler */
        if (wjh_netlink_ops.wjh_netlink_msg_handler_pfn != NULL) {
            ret = wjh_netlink_ops.wjh_netlink_msg_handler_pfn(h);
            if (ret < 0) {
                WJH_LOG_ERR("read_netlink: Message handler error %d\n", ret);
                err = WJH_STATUS_ERROR;
                goto out;
            }
        } else {
            WJH_LOG_ERR("read_netlink: Error NULL message handler\n");
            err = WJH_STATUS_ERROR;
            goto out;
        }
    }

out:
    return err;
}

/* Construct and send a request for obtaining the list of network interfaces. */
static wjh_status_t wjh_netlink_send_if_list_req(int32_t sd)
{
    struct {
        struct nlmsghdr  nh;
        struct ifinfomsg ifinfomsg;
    } req;
    ssize_t ssize;

    memset(&req, 0, sizeof(req));
    req.nh.nlmsg_len = NLMSG_LENGTH(sizeof(req.ifinfomsg));
    req.nh.nlmsg_type = RTM_GETLINK;
    req.nh.nlmsg_flags = NLM_F_REQUEST | NLM_F_ROOT;
    req.ifinfomsg.ifi_family = AF_PACKET;

    ssize = send(sd, &req, sizeof(req), 0);
    if (ssize == -1) {
        WJH_LOG_ERR("Failed to send if_list req.");
        return WJH_STATUS_ERROR;
    }

    return WJH_STATUS_SUCCESS;
}


static uint32_t __rta_getattr_u32(struct rtattr *rta)
{
    return *(uint32_t*)RTA_DATA(rta);
}

static void __parse_rtattr(struct rtattr *tb[], int max, struct rtattr *rta, int len)
{
    unsigned short type;

    memset(tb, 0, sizeof(struct rtattr *) * (max + 1));
    /* coverity[sensitive_memory_access] */
    while (RTA_OK(rta, len)) {
        type = rta->rta_type;
        /* coverity[sensitive_memory_access] */
        if ((type <= max) && (!tb[type])) {
            tb[type] = rta;
        }
        rta = RTA_NEXT(rta, len);
    }

    if (len) {
        WJH_LOG_ERR("Warning!!! Deficit %d, rta_len=%d\n", len, rta->rta_len);
    }
}

static wjh_status_t __wjh_netlink_sx_netdev_get_attr(struct rtattr *tb[], uint32_t* log_port)
{
    if (!tb) {
        return WJH_STATUS_ERROR;
    }

    if (tb[IFLA_SX_NETDEV_PORT] && (RTA_PAYLOAD(tb[IFLA_SX_NETDEV_PORT]) == sizeof(__u32))) {
        *log_port = __rta_getattr_u32(tb[IFLA_SX_NETDEV_PORT]);
    } else {
        WJH_LOG_ERR("Can't find log_port param in attr ! \n");
        return WJH_STATUS_ERROR;
    }

    return WJH_STATUS_SUCCESS;
}

static wjh_status_t __wjh_netlink_parse_link_kind_sdk(struct rtattr *tb, uint32_t* log_port_p)
{
    wjh_status_t    err = WJH_STATUS_ENTRY_NOT_FOUND;
    struct rtattr  *linkinfo[IFLA_INFO_MAX + 1];
    struct rtattr * rta = NULL;
    char           *kind;
    struct rtattr  *attr[IFLA_INFO_MAX + 1];

    __parse_rtattr(linkinfo, IFLA_INFO_MAX, RTA_DATA(tb), RTA_PAYLOAD(tb));

    if (linkinfo[IFLA_INFO_KIND]) {
        kind = RTA_DATA(linkinfo[IFLA_INFO_KIND]);

        if (!strcmp(kind, "sx_netdev") && linkinfo[IFLA_INFO_DATA]) {
            rta = linkinfo[IFLA_INFO_DATA];
            __parse_rtattr(attr, IFLA_INFO_MAX, RTA_DATA(rta), RTA_PAYLOAD(rta));

            err = __wjh_netlink_sx_netdev_get_attr(attr, log_port_p);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Can't find log_port param in attr ! \n");
                return err;
            }
            /* SUCCESS will be returned only in case when sx_netdev found
             * and log_port is extracted */
        }
    }

    return err;
}

static int32_t wjh_netlink_if_get_log_port_attr(struct nlmsghdr * nh, wjh_log_port_attr_t *  log_port_attr_p)
{
    wjh_status_t      err = WJH_STATUS_ENTRY_NOT_FOUND;
    struct ifinfomsg *ifinfomsg;
    struct rtattr    *rta;
    int32_t           attr_len;

    if ((nh == NULL) || (log_port_attr_p == NULL)) {
        err = WJH_STATUS_ERROR;
        goto out;
    }

    ifinfomsg = NLMSG_DATA(nh);
    rta = IFLA_RTA(ifinfomsg);
    attr_len = IFLA_PAYLOAD(nh);
    /* coverity[sensitive_memory_access] */
    for (; RTA_OK(rta, attr_len); rta = RTA_NEXT(rta, attr_len)) {
        if (rta->rta_type == IFLA_LINKINFO) {
            err = __wjh_netlink_parse_link_kind_sdk(rta, &log_port_attr_p->log_port);
            if (WJH_CHECK_FAIL(err)) {
                return err;
            }
            WJH_LOG_DBG("DEBUG found sx_netdev with logport:0x%x \n", log_port_attr_p->log_port);
            goto out;
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_netlink_msg_handler(struct nlmsghdr *msg)
{
    wjh_status_t        err = WJH_STATUS_SUCCESS;
    struct ifaddrmsg   *ifa = NLMSG_DATA(msg);
    wjh_log_port_attr_t log_port_attr;

    memset(&log_port_attr, 0, sizeof(log_port_attr));

    switch (msg->nlmsg_type) {
    case RTM_NEWLINK:
        WJH_LOG_DBG("wjh_netlink_msg_handler: RTM_NEWLINK\n");

        err = wjh_netlink_if_get_log_port_attr(msg, &log_port_attr);
        if (err == WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_DBG("supported netdev type wasn't found.\n");
            err = WJH_STATUS_SUCCESS;
            goto out;
        } else if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_netlink_if_get_log_port_attr failed with err: %d\n", err);
            goto out;
        }

        log_port_attr.if_index = ifa->ifa_index;
        if_indextoname(ifa->ifa_index, log_port_attr.netdev_name);

        /* set in db */
        err = wjh_db_log_port_attr_set(log_port_attr.log_port, &log_port_attr);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_db_log_port_attr_set failed with err: %d\n", err);
            goto out;
        }

        break;

    case RTM_DELLINK:
        WJH_LOG_DBG("wjh_netlink_msg_handler: RTM_DELLINK \n");


        err = wjh_netlink_if_get_log_port_attr(msg, &log_port_attr);
        if (err == WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_DBG("supported netdev type wasn't found.\n");
            err = WJH_STATUS_SUCCESS;
            goto out;
        } else if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_netlink_if_get_log_port_attr failed with err: %d\n", err);
            goto out;
        }

        /* invalidate in db */
        log_port_attr.if_index = WJH_INVALID_IF_INDEX;
        err = wjh_db_log_port_attr_set(log_port_attr.log_port, &log_port_attr);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_db_log_port_attr_set failed with err: %d\n", err);
            goto out;
        }
        break;

    default:
        WJH_LOG_ERR("wjh_netlink_msg_handler: Unknown netlink nlmsg_type %d\n",
                    msg->nlmsg_type);
        break;
    }

out:
    return err;
}

static void __wjh_netlink_ev_handler_thread_func(void *args)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    int          nls = *(int*)args;

    /* request from netlink list of current interfaces */
    err = wjh_netlink_send_if_list_req(nls);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Unable to send GET INTERFACE request, err: %d\n", err);
        goto out;
    }

    while (!wjh_stop_netlink_ev_handler_thread_s) {
        err = wjh_netlink_read_event(nls);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_netlink_read_event failed with err: %d\n", err);
            goto out;
        }
    }

out:
    pthread_exit((void*)NULL);
}


int wjh_netlink_init()
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    cl_status_t  cl_rc;

    if (wjh_nl_init_done_g == TRUE) {
        WJH_LOG_ERR("Try to run wjh_netlink_init after init.\n");
        err = WJH_STATUS_ALREADY_INITIALIZED;
        goto out;
    }

    /* open netlink socket */
    err = wjh_netlink_open(&nls_g);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh_netlink_open failed with err: %d \n", err);
        goto out;
    }

    wjh_stop_netlink_ev_handler_thread_s = FALSE;
    cl_rc = cl_thread_init(&wjh_netlink_ev_handler_thread_id_s,
                           __wjh_netlink_ev_handler_thread_func,
                           &nls_g,
                           "wjhNetlinkEv", 0);
    if (cl_rc != CL_SUCCESS) {
        WJH_LOG_ERR("Could not create __wjh_netlink_ev_handler_thread_func thread.\n");
        err = WJH_STATUS_ERROR;
        goto close_nls;
    }

    wjh_nl_init_done_g = TRUE;

out:
    return err;

close_nls:
    close(nls_g);
    return err;
}

void wjh_netlink_deinit()
{
    if (wjh_nl_init_done_g == FALSE) {
        WJH_LOG_DBG("Try to run wjh_netlink_deinit before init \n");
        return;
    }

    wjh_stop_netlink_ev_handler_thread_s = TRUE;

    /* send request from netlink list to release read */
    wjh_netlink_send_if_list_req(nls_g);

    cl_thread_destroy(&wjh_netlink_ev_handler_thread_id_s);

    close(nls_g);

    wjh_nl_init_done_g = FALSE;
}
