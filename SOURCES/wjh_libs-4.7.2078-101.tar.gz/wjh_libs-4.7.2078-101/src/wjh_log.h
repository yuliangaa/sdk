/*
 * Copyright © 2001-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_LOG_H_
#define WJH_LOG_H_

#include <wjh/wjh_lib.h>

/************************************************
 *  Macros
 ***********************************************/

#define WJH_LOG_DBG(fmt, arg ...) wjh_log(WJH_VERBOSITY_LEVEL_DEBUG, fmt, ## arg)
#define WJH_LOG_INF(fmt, arg ...) wjh_log(WJH_VERBOSITY_LEVEL_INFO, fmt, ## arg)
#define WJH_LOG_WRN(fmt, arg ...) wjh_log(WJH_VERBOSITY_LEVEL_WARNING, fmt, ## arg)
#define WJH_LOG_ERR(fmt, arg ...) wjh_log(WJH_VERBOSITY_LEVEL_ERROR, fmt, ## arg)
#define WJH_LOG_NTC(fmt, arg ...) wjh_log(WJH_VERBOSITY_LEVEL_NOTICE, fmt, ## arg)


#define WJH_VERBOSITY_LEVEL_CHECK_RANGE(verbosity)  \
    (((int)verbosity <= WJH_VERBOSITY_LEVEL_MAX) && \
     ((int)verbosity >= WJH_VERBOSITY_LEVEL_MIN))

static const char *wjh_verbosity_level_name[] = {
    "NONE   ",
    "ERROR  ",
    "WARN   ",
    "NOTICE ",
    "INFO   ",
    "DEBUG  ",
    "FUNCS  ",
    "FRAMES ",
    "ALL    "
};
static const int   wjh_verbosity_level_name_len = sizeof(wjh_verbosity_level_name) / sizeof(char*);

#define WJH_VERBOSITY_LEVEL_STR(index) \
    (((int)index >= 0) &&              \
     ((int)index <                     \
      (int)wjh_verbosity_level_name_len) ? wjh_verbosity_level_name[index] : "UNKNOWN")

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

void wjh_log(wjh_verbosity_level_t level, const char *fmt, ...) __attribute__((format(printf, 2, 3)));
void wjh_log_cb_set(wjh_log_cb_t log_cb);


#endif /* WJH_LOG_H_ */
