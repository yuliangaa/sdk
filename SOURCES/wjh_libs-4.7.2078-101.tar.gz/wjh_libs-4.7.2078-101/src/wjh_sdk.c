/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#include <stdio.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sx/sdk/sx_api.h>
#include <sx/sdk/sx_lib_host_ifc.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_strings.h>
#include <sx/sdk/sx_api_policer.h>
#include <sx/sdk/sx_api_init.h>
#include <sx/sdk/sx_lib_flex_acl.h>
#include <sx/sdk/sx_api_acl.h>
#include <sx/acl_helper/sx_acl_helper.h>
#include <sx/sdk/sx_api_port.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_mem.h>
#include <errno.h>
#include <fcntl.h>
#include <linux/limits.h>
#include <sys/resource.h>
#include "wjh_log.h"
#include "wjh_common.h"
#include "wjh_db.h"
#include "wjh_sdk.h"
#include "sx/sdk/sx_api_port.h"
#include "sx/sdk/sx_api_span.h"
#include "sx/sdk/sx_api_acl.h"
#include "sx/sdk/sx_api_mgmt.h"
#include "sx/sdk/sx_api_tele.h"
#include "sx/sdk/sx_lib_flex_acl.h"
#include "sx/sdk/sx_lib_adviser.h"
#include <sx/sxd/sxd_dpt.h>
#ifdef WJH_EBPF_PRESENT
#include "wjh_ebpf_types.h"
#include "wjh_ebpf.h"
#endif
#include "wjh_kernel_user.h"

/************************************************
 *  Local Macros
 ***********************************************/

#define WJH_RECEIVED_PACKET_SIZE             (1024 * 10)
#define WJH_BUFFER_DROP_TS_UPDATE_TIMER_SECS (60)
#define WJH_L1_PORT_DOWN_REASON_SEPARATOR    "|"
#define SDK_READY_FILENAME                   "/tmp/sdk_ready"
#define WJH_ACL_DROP_TRAP_DISABLE_DEFAULT    TRUE

#define WJH_MIRROR_AGENT_TRAP_DEFAULT_ACTION (SX_TRAP_ACTION_DISCARD)
#define WJH_IS_MIRROR_AGENT_TRAP(trap_id)     \
    ((trap_id >= SX_TRAP_ID_MIRROR_AGENT0) && \
     (trap_id <= SX_TRAP_ID_MIRROR_AGENT7))

#ifdef WJH_EBPF_PRESENT
#define WJH_DEBUGFS_PATH_DEFAULT  "/sys/kernel/debug"
#define WJH_BPF_JIT_PROC_FS_ENTRY "/proc/sys/net/core/bpf_jit_enable"
#endif

#define WJH_ENABLE_MONITOR_RDQ_TRACE_POINTS_SYSFS_ENTRY \
    "/sys/module/sx_core/parameters/enable_monitor_rdq_trace_points"
#define WJH_ENABLE_DROP_MONITOR_SYSFS_ENTRY "/sys/module/sx_core/parameters/enable_drop_monitor_report"

#define GET_LAG_PORTS_INDEX(db_ptr, lag_id, port_index) (((lag_id) * db_ptr->max_lag_ports) + port_index)

#define FILL_COMMON_PART_OF_RAW_INFO(raw_info_type, drop_reason_group, packet_info_p, trap_id_attr_p)           \
    do {                                                                                                        \
        raw_info_type *raw_info_buf = (raw_info_type*)(raw_info_buffers_s[drop_reason_group].raw_info_buf);     \
        uint32_t      *raw_info_count = &(raw_info_buffers_s[drop_reason_group].raw_info_count);                \
        raw_info_buf[*raw_info_count].packet = (packet_info_p)->packet_p;                                       \
        raw_info_buf[*raw_info_count].packet_size = (packet_info_p)->packet_size;                               \
        raw_info_buf[*raw_info_count].ingress_port = wjh_sdk_interface_info_get(                                \
            (packet_info_p)->receive_info.source_log_port,                                                      \
            (packet_info_p)->receive_info.source_log_port);                                                     \
        raw_info_buf[*raw_info_count].is_lag_member = (packet_info_p)->receive_info.is_lag;                     \
        raw_info_buf[*raw_info_count].ingress_lag = wjh_sdk_interface_info_get(                                 \
            (packet_info_p)->receive_info.source_lag_port,                                                      \
            (packet_info_p)->receive_info.source_log_port);                                                     \
        if ((trap_id_attr_p)->drop_reason->reason) {                                                            \
            raw_info_buf[*raw_info_count].drop_reason.reason = (trap_id_attr_p)->drop_reason->reason;           \
        } else {                                                                                                \
            raw_info_buf[*raw_info_count].drop_reason.reason = WJH_DB_EMPTY_STR;                                \
        }                                                                                                       \
        if ((trap_id_attr_p)->drop_reason->description) {                                                       \
            raw_info_buf[*raw_info_count].drop_reason.description = (trap_id_attr_p)->drop_reason->description; \
        } else {                                                                                                \
            raw_info_buf[*raw_info_count].drop_reason.description = WJH_DB_EMPTY_STR;                           \
        }                                                                                                       \
        raw_info_buf[*raw_info_count].drop_reason.id = (trap_id_attr_p)->drop_reason->id;                       \
        raw_info_buf[*raw_info_count].drop_reason.severity = (trap_id_attr_p)->drop_reason->severity;           \
        raw_info_buf[*raw_info_count].drop_reason.event_type = (trap_id_attr_p)->drop_reason->event_type;       \
        memcpy(&raw_info_buf[*raw_info_count].timestamp, &((packet_info_p)->receive_info.timestamp),            \
               sizeof((packet_info_p)->receive_info.timestamp));                                                \
        *raw_info_count += 1;                                                                                   \
    } while (0)

#define PROCESS_PORT_DOWN_REASON_DESCRIPTION(reason_name, reason_id)                              \
    do {                                                                                          \
        if (phy_stat_p->port_down_reason.reason_name) {                                           \
            i = WJH_L1_PORT_DOWN_REASON_INDEX_MIN + (reason_id - WJH_L1_PORT_DOWN_REASON_ID_MIN); \
            wjh_db_get_drop_reason_item(i, &l1_drop_reason_item);                                 \
            port_down_reason_str_arr[i] = l1_drop_reason_item->reason;                            \
            port_down_reason_str_len_arr[i] = strlen(l1_drop_reason_item->reason);                \
            description_str_arr[i] = l1_drop_reason_item->description;                            \
            description_str_len_arr[i] = strlen(l1_drop_reason_item->description);                \
            reason_str_len += port_down_reason_str_len_arr[i];                                    \
            description_str_len += description_str_len_arr[i];                                    \
            ++reason_num;                                                                         \
        }                                                                                         \
    } while (0)

#define COPY_PORT_DOWN_REASON_DESCRIPTION(name, name_str_arr, name_str_len_arr)      \
    do {                                                                             \
        first_reason_str = TRUE;                                                     \
        index = 0;                                                                   \
        for (i = 0; i < WJH_L1_PORT_DOWN_REASON_NUM; ++i) {                          \
            if (name_str_arr[i] != NULL) {                                           \
                if (first_reason_str) {                                              \
                    strcpy(data_p->name + index, name_str_arr[i]);                   \
                    index += name_str_len_arr[i];                                    \
                    first_reason_str = FALSE;                                        \
                } else {                                                             \
                    strcpy(data_p->name + index, WJH_L1_PORT_DOWN_REASON_SEPARATOR); \
                    index += strlen(WJH_L1_PORT_DOWN_REASON_SEPARATOR);              \
                    strcpy(data_p->name + index, name_str_arr[i]);                   \
                    index += name_str_len_arr[i];                                    \
                }                                                                    \
            }                                                                        \
        }                                                                            \
    } while (0)

#define WJH_AGG_FILL_FIVE_TUPLES(agg_key_list, ebpf_key)                                            \
    do {                                                                                            \
        agg_key_list[index].non_ip = ebpf_key->non_ip;                                              \
        if (ebpf_key->non_ip) {                                                                     \
            memset(&(agg_key_list[index].five_tuples), 0, sizeof(agg_key_list[index].five_tuples)); \
        } else {                                                                                    \
            err = __wjh_aggregation_fill_five_tuples(&(agg_key_list[index].five_tuples),            \
                                                     &(ebpf_key->five_tuples),                      \
                                                     group_item_p->aggregation_key_sip_buf,         \
                                                     group_item_p->aggregation_key_dip_buf,         \
                                                     index);                                        \
            if (WJH_CHECK_FAIL(err)) {                                                              \
                WJH_LOG_ERR("__wjh_aggregation_fill_five_tuples failed, err: %d\n", err);           \
                goto out;                                                                           \
            }                                                                                       \
        }                                                                                           \
    } while (0)

#define WJH_AGG_FILL_PORT_VLAN_ETHER_TYPE(agg_key_list, ebpf_key, from_cqe)   \
    do {                                                                      \
        err = __wjh_get_port_lag_log_id(ebpf_key->port,                       \
                                        from_cqe,                             \
                                        &(agg_key_list[index].ingress_port),  \
                                        &(agg_key_list[index].is_lag_member), \
                                        &(agg_key_list[index].ingress_lag));  \
        if (WJH_CHECK_FAIL(err)) {                                            \
            WJH_LOG_ERR("__wjh_get_port_lag_log_id failed, err: %d\n", err);  \
            goto out;                                                         \
        }                                                                     \
        agg_key_list[index].vlan = ebpf_key->vlan;                            \
        agg_key_list[index].ether_type = ebpf_key->ether_type;                \
    } while (0)

#define WJH_AGG_PREPARE_KEY_DATA(agg_key_list, agg_data_list)                            \
    do {                                                                                 \
        agg_key_list = group_item_p->aggregation_key_buf;                                \
        agg_data_list = group_item_p->aggregation_data_buf;                              \
        memset(&(agg_key_list[index]), 0, sizeof(agg_key_list[index]));                  \
        memset(&(agg_data_list[index]), 0, sizeof(agg_data_list[index]));                \
        __wjh_aggregation_fill_timestamp(&agg_data_list[index].timestamp, ebpf_value_p); \
        agg_data_list[index].count = ebpf_value_p->count;                                \
    } while (0)

#define WJH_AGG_FILL_DROP_REASON(agg_key_list, reason_name, reason_id, index)          \
    do {                                                                               \
        wjh_db_get_drop_reason_item_by_reason(reason_id,                               \
                                              &drop_reason_item_p);                    \
        agg_key_list[index].reason_name.id = reason_id;                                \
        agg_key_list[index].reason_name.reason = drop_reason_item_p->reason;           \
        agg_key_list[index].reason_name.severity = drop_reason_item_p->severity;       \
        agg_key_list[index].reason_name.description = drop_reason_item_p->description; \
        agg_key_list[index].reason_name.event_type = drop_reason_item_p->event_type;   \
    } while (0)

#define WJH_AGG_FILL_L1_DROP_REASON(list, reason_name, reason_id, index, counter_name) \
    do {                                                                               \
        if (list[j2].counter_name > 0) {                                               \
            WJH_AGG_FILL_DROP_REASON(list, reason_name, reason_id, index);             \
        } else {                                                                       \
            memset(&(list[index].reason_name), 0, sizeof(list[index].reason_name));    \
        }                                                                              \
    } while (0)

#define WJH_AGG_FILL_DMAC_SMAC(agg_key_list, ebpf_key)       \
    do {                                                     \
        memcpy(agg_key_list[index].dmac, ebpf_key->dmac, 6); \
        memcpy(agg_key_list[index].smac, ebpf_key->smac, 6); \
    } while (0)

#define WJH_FILL_L1_CACHE(l1_cache_p)                                                            \
    do {                                                                                         \
        l1_cache_p->key[l1_cache_p->count].ingress_port = port_attributes_list_p[i].log_port;    \
        l1_cache_p->data[l1_cache_p->count].state_change_count = phy_stat.port_state_change_cnt; \
        l1_cache_p->data[l1_cache_p->count].crc_error_count =                                    \
            cntr_ieee_802_dot_3.a_frame_check_sequence_errors;                                   \
        l1_cache_p->data[l1_cache_p->count].symbol_error_count = cntr_phy_layer.symbol_errors;   \
        l1_cache_p->count += 1;                                                                  \
    } while (0)

#define WJH_IS_L1_COUNTER_CHANGED(old, new) (((old) < (new)) || (((old) > (new)) && ((new) > 0)))

#define WJH_EXTRACT_IS_LAG(port)         ((uint8_t)(((port) >> 24) & 0xff))
#define WJH_EXTRACT_LAG_SUBPORT(port)    ((uint8_t)(((port) >> 16) & 0xff))
#define WJH_EXTRACT_SYSPORT_LAG_ID(port) ((uint16_t)((port) & 0xffff))

#define TAC_INFORMATION_RATE 200 * 1024 /*200G for TAC bandwidth*/

/************************************************
 *  Local Type definitions
 ***********************************************/

typedef struct wjh_policer_data {
    uint16_t speed;
    uint16_t width;
    uint32_t information_rate;
} wjh_policer_data_t;

typedef struct wjh_raw_info_buffer {
    void    *raw_info_buf;
    uint32_t raw_info_count;
} wjh_raw_info_buffer_t;

typedef struct stat wjh_stat_t;

#ifdef WJH_EBPF_PRESENT
typedef struct wjh_agg_drop_reason_group_ebpf_attr {
    const char *ebpf_map_name;
    const char *ebpf_prog_name;
    const char *ebpf_prog_section_name;
} wjh_agg_drop_reason_group_ebpf_attr_t;
#endif

typedef struct wjh_l1_aggregation_key_data_cache {
    wjh_L1_drop_aggregate_key_t  key[MAX_PHYPORT_NUM + 1];
    wjh_L1_drop_aggregate_data_t data[MAX_PHYPORT_NUM + 1];
    uint32_t                     count;
} wjh_l1_aggregation_key_data_cache_t;

typedef sx_status_t (*sx_api_log_verb_get_pfn_t)(const sx_api_handle_t           handle,
                                                 const sx_log_verbosity_target_t verbosity_target,
                                                 sx_verbosity_level_t           *module_verbosity_level_p,
                                                 sx_verbosity_level_t           *api_verbosity_level_p);
typedef sx_status_t (*sx_api_log_verb_set_pfn_t)(const sx_api_handle_t           handle,
                                                 const sx_log_verbosity_target_t verbosity_target,
                                                 const sx_verbosity_level_t      module_verbosity_level,
                                                 const sx_verbosity_level_t      api_verbosity_level);

/************************************************
 *  Global variables
 ***********************************************/
extern cl_plock_t wjh_bind_enable_rwlock_g;
#ifdef WJH_EBPF_PRESENT
extern char wjh_ebpf_prog_dir_g[PATH_MAX];
#endif
extern wjh_init_param_t wjh_init_params_g;

/************************************************
 *  Local variables
 ***********************************************/
static sx_api_handle_t sx_api_handle_s;

/*Today WJH will add a policer with base of the rate of PCI for traps that go to CPU,
 * We need another policer for TAC traps and the base is 200G (SAM rate).
 */
static sx_policer_id_t wjh_policer_id_s = SX_POLICER_ID_INVALID;
static sx_policer_id_t wjh_policer_tac_id_s = SX_POLICER_ID_INVALID;
/* The original number came from https://zh.wikipedia.org/wiki/PCI_Express,
 * we reduce 1Gb/s for error correction protocols and the PCIe headers overhead,
 * see https://community.mellanox.com/s/article/understanding-pcie-configuration-for-maximum-performance
 */
static wjh_policer_data_t         wjh_policer_data_s[] = {
    {1, 1, 1000},    /* Speed 2.5GT/s, Width x1 */
    {1, 2, 3000},    /* Speed 2.5GT/s, Width x2 */
    {1, 4, 7000},    /* Speed 2.5GT/s, Width x4 */
    {1, 8, 15000},   /* Speed 2.5GT/s, Width x8 */
    {1, 16, 31000},  /* Speed 2.5GT/s, Width x16 */
    {2, 1, 3000},    /* Speed 5GT/s, Width x1 */
    {2, 2, 7000},    /* Speed 5GT/s, Width x2 */
    {2, 4, 15000},   /* Speed 5GT/s, Width x4 */
    {2, 8, 31000},   /* Speed 5GT/s, Width x8 */
    {2, 16, 63000},  /* Speed 5GT/s, Width x16 */
    {3, 1, 6876},    /* Speed 8GT/s, Width x1 */
    {3, 2, 14760},   /* Speed 8GT/s, Width x2 */
    {3, 4, 30520},   /* Speed 8GT/s, Width x4 */
    {3, 8, 62040},   /* Speed 8GT/s, Width x8 */
    {3, 16, 125400}, /* Speed 8GT/s, Width x16 */
    {4, 1, 14752},   /* Speed 16GT/s, Width x1 */
    {4, 2, 30520},   /* Speed 16GT/s, Width x2 */
    {4, 4, 62040},   /* Speed 16GT/s, Width x4 */
    {4, 8, 125000},  /* Speed 16GT/s, Width x8 */
    {4, 16, 251000}, /* Speed 16GT/s, Width x16 */
    {5, 1, 30504},   /* Speed 32GT/s, Width x1 */
    {5, 2, 62040},   /* Speed 32GT/s, Width x2 */
    {5, 4, 125000},  /* Speed 32GT/s, Width x4 */
    {5, 8, 251080},  /* Speed 32GT/s, Width x8 */
    {5, 16, 503000}, /* Speed 32GT/s, Width x16 */
    {6, 1, 59504},   /* Speed 64GT/s, Width x1 */
    {6, 2, 120000},   /* Speed 64GT/s, Width x2 */
    {6, 4, 241000},  /* Speed 64GT/s, Width x4 */
    {6, 8, 483000},  /* Speed 64GT/s, Width x8 */
    {6, 16, 967000}, /* Speed 64GT/s, Width x16 */
    {7, 1, 120000},   /* Speed 128GT/s, Width x1 */
    {7, 2, 241000},   /* Speed 128GT/s, Width x2 */
    {7, 4, 483000},  /* Speed 128GT/s, Width x4 */
    {7, 8, 967000},  /* Speed 128GT/s, Width x8 */
    {7, 16, 1935000}, /* Speed 128GT/s, Width x16 */
};
static wjh_buffer_drop_raw_info_t buffer_raw_info_buffer_s[READ_MULTI_BUFFS_MAX];
static wjh_L2_drop_raw_info_t     l2_raw_info_buffer_s[READ_MULTI_BUFFS_MAX];
static wjh_router_drop_raw_info_t router_raw_info_buffer_s[READ_MULTI_BUFFS_MAX];
static wjh_tunnel_drop_raw_info_t tunnel_raw_info_buffer_s[READ_MULTI_BUFFS_MAX];
static wjh_acl_drop_raw_info_t    acl_raw_info_buffer_s[READ_MULTI_BUFFS_MAX];
static wjh_roce_drop_raw_info_t   roce_raw_info_buffer_s[READ_MULTI_BUFFS_MAX];
static wjh_raw_info_buffer_t      raw_info_buffers_s[WJH_DROP_REASON_GROUP_MAX_E + 1] = {
    {(void*)buffer_raw_info_buffer_s, 0},     /* WJH_DROP_REASON_GROUP_BUFFER_E */
    {(void*)acl_raw_info_buffer_s, 0},     /* WJH_DROP_REASON_GROUP_ACL_E */
    {NULL, 0},     /* WJH_DROP_REASON_GROUP_L1_E */
    {(void*)l2_raw_info_buffer_s, 0},     /* WJH_DROP_REASON_GROUP_L2_E */
    {(void*)router_raw_info_buffer_s, 0},     /* WJH_DROP_REASON_GROUP_ROUTER_E */
    {(void*)tunnel_raw_info_buffer_s, 0},     /* WJH_DROP_REASON_GROUP_TUNNEL_E */
    {(void*)roce_raw_info_buffer_s, 0},     /* WJH_DROP_REASON_GROUP_ROCE_E */
};
static char                     * wjh_buffer_drop_reason_str = "Buffer drop";
static char                     * wjh_buffer_drop_desc_str = "Monitor network congestion";
static char                      *wjh_l1_general_drop_reason_str = "Generic L1 event";
static char                      *wjh_l1_general_drop_desc_str = "Check layer 1 aggregated information";
#ifdef WJH_EBPF_PRESENT
static wjh_agg_drop_reason_group_ebpf_attr_t wjh_agg_drop_reason_group_ebpf_attr_s[WJH_DROP_REASON_GROUP_MAX_E + 1] = {
    {"wjh_agg_buffer_map", "libwjh_agg_buffer_bpf_prog.so.1", "wjh_agg_buffer_bpf_prog"},
    {"wjh_agg_acl_map", "libwjh_agg_acl_bpf_prog.so.1", "wjh_agg_acl_bpf_prog"},
    {NULL, NULL, NULL},
    {"wjh_agg_l2_map", "libwjh_agg_l2_bpf_prog.so.1", "wjh_agg_l2_bpf_prog"},
    {"wjh_agg_router_map", "libwjh_agg_router_bpf_prog.so.1", "wjh_agg_router_bpf_prog"},
    {"wjh_agg_tunnel_map", "libwjh_agg_tunnel_bpf_prog.so.1", "wjh_agg_tunnel_bpf_prog"},
    {"wjh_agg_roce_map", "libwjh_agg_roce_bpf_prog.so.1", "wjh_agg_roce_bpf_prog"}
};
static const char                           *wjh_agg_comm_map_name = "wjh_agg_comm_map";
static uint32_t                              wjh_agg_comm_map_refcnt = 0;
static int                                   wjh_agg_comm_map_fd = -1;
static char                                  wjh_debugfs_path_s[PATH_MAX];
static const char                           *wjh_filter_epbf_prog_name = "libwjh_filter_bpf_prog.so.1";
static const char                           *wjh_filter_ebpf_prog_section_name = "wjh_filter_bpf_prog";
static const char                           *wjh_filter_ebpf_map_name = "wjh_filter_bpf_map";
static const char                           *wjh_drop_reason_ebpf_map_name = "wjh_drop_reason_bpf_map";
static const char                           *wjh_port_ebpf_map_name = "wjh_port_bpf_map";
static int                                   wjh_drop_reason_bpf_map_s = -1;
static int                                   wjh_port_bpf_map_s = -1;
static uint32_t                              wjh_enable_monitor_rdq_trace_points_refcnt = 0;
#endif
static sx_ladb_port_indices_t              *port_indices_db_p = NULL;
static int                                  port_indices_db_fd_s = -1;
static size_t                               port_indices_db_size_s = 0;
static uint32_t                             wjh_sx_lib_adviser_refcnt = 0;
static wjh_l1_aggregation_key_data_cache_t  wjh_l1_cache_s[4];
static wjh_l1_aggregation_key_data_cache_t *wjh_l1_cyclic_old_cache_s = &(wjh_l1_cache_s[0]);
static wjh_l1_aggregation_key_data_cache_t *wjh_l1_cyclic_new_cache_s = &(wjh_l1_cache_s[1]);
static wjh_l1_aggregation_key_data_cache_t *wjh_l1_agg_old_cache_s = &(wjh_l1_cache_s[2]);
static wjh_l1_aggregation_key_data_cache_t *wjh_l1_agg_new_cache_s = &(wjh_l1_cache_s[3]);
static wjh_L1_drop_aggregate_key_t          wjh_l1_agg_key_s[MAX_PHYPORT_NUM + 1];
static wjh_L1_drop_aggregate_data_t         wjh_l1_agg_data_s[MAX_PHYPORT_NUM + 1];
static wjh_L1_drop_raw_info_t               wjh_l1_raw_info_s[MAX_PHYPORT_NUM + 1];
static wjh_policer_attrs_t                  wjh_policer_attrs_s;

/************************************************
 *  Local function declarations
 ***********************************************/
static wjh_status_t __wjh_policer_settings_get(uint8_t percent, wjh_policer_attrs_t *policer_attrs_p);
static wjh_status_t __wjh_cyclic_channel_buf_create(void **buf_pp);
static wjh_status_t __wjh_cyclic_channel_buf_destroy(void *buf_p);
static void __wjh_acl_raw_info_fill(const sx_packet_info_t *packet_info_p);
static void __wjh_roce_raw_info_fill(const sx_packet_info_t *packet_info_p, const wjh_trap_id_attr_t *trap_id_attr_p);
static void __wjh_buffer_raw_info_fill(const sx_packet_info_t                   *packet_info_p,
                                       const wjh_user_channel_timestamp_source_e timestamp_source);
static void __wjh_acl_raw_info_list_free(void);
static wjh_status_t __wjh_acl_drop_reason_group_disable(boolean_t disable);
static uint32_t __wjh_packet_info_list_process(wjh_user_channel_record_t *user_channel_p,
                                               const sx_packet_info_t    *packet_info_list_p,
                                               const uint32_t             packet_info_list_size,
                                               boolean_t                  acquire_bind_enable_lock);
static wjh_status_t __wjh_cyclic_channel_process(wjh_user_channel_record_t *user_channel_p,
                                                 void                      *buf_p);
static wjh_status_t __wjh_taildrop_channel_process(wjh_user_channel_record_t *user_channel_p);
static wjh_status_t __wjh_prepare_l1_port_down_reason(wjh_L1_drop_aggregate_data_t *data_p,
                                                      const sx_port_phy_stat_t     *phy_stat_p,
                                                      uint8_t                       is_port_up);
static wjh_status_t __wjh_l1_data_read(wjh_user_channel_record_t  *channel_record_p,
                                       uint32_t                   *cyclic_cnt_p,
                                       uint32_t                   *agg_cnt_p,
                                       boolean_t                   is_pull_api,
                                       wjh_aggregation_read_mode_e agg_read_mode);
static wjh_status_t __wjh_l1_exec_callback(wjh_user_channel_type_e channel_type, uint32_t cyclic_cnt, uint32_t agg_cnt,
                                           boolean_t is_pull_api);
static wjh_status_t __wjh_aggregation_channel_process(wjh_user_channel_record_t  *user_channel_p,
                                                      boolean_t                   is_pull_api,
                                                      wjh_aggregation_read_mode_e agg_read_mode);
static wjh_status_t __wjh_policer_destroy_sdk(sx_policer_id_t policer_id);
static sx_status_t __sx_adviser_port_added_removed_cb(const sx_lib_adviser_event_info_t event_info,
                                                      const void                       *context);
static wjh_status_t __bind_unbind_buffer_drops_all_ports(sx_lib_adviser_event_type_e event_type, uint8_t reason_bits);
static wjh_status_t __buffer_drop_span_init(const wjh_drop_reason_group_attr_t *attr_p);
static wjh_status_t __buffer_drop_span_deinit(void);
static wjh_status_t __buffer_drop_mirror_to_cpu_mode_set(boolean_t mode);
static wjh_status_t __buffer_drop_sx_adviser_register(const wjh_drop_reason_group_attr_t *attr_p);
static wjh_status_t __buffer_drop_sx_adviser_deregister(void);
static wjh_status_t __buffer_drop_acl_create(const wjh_drop_reason_group_attr_t *attr_p);
static wjh_status_t __buffer_drop_acl_destory(void);
static wjh_status_t __wjh_buffer_drop_init(const wjh_drop_reason_group_attr_t *attr_p);
static wjh_status_t __wjh_buffer_drop_deinit(void);
static wjh_status_t __wjh_buffer_drop_span_clean_up(uint8_t drop_reason_bits);
static wjh_status_t __wjh_buffer_drop_pre_init_resource_clean_up(
    wjh_buffer_drop_reason_group_shm_data_t *wjh_buffer_drop_shm_data_p);
static wjh_status_t __wjh_buffer_drop_post_init_resource_clean_up();
static wjh_status_t __roce_drop_sx_advisers_register(void);
static wjh_status_t __roce_drop_sx_advisers_deregister(void);
static wjh_status_t __wjh_roce_drop_init(const wjh_drop_reason_group_attr_t *attr_p);
static wjh_status_t __wjh_roce_drop_deinit(void);
static wjh_status_t __wjh_roce_drop_reason_trap_set(uint8_t reason_bits, boolean_t trap);
static wjh_status_t __bind_unbind_roce_drops_all_ports(sx_lib_adviser_event_type_e event_type);
static wjh_status_t __wjh_sx_lib_adviser_init();
static wjh_status_t __wjh_sx_lib_adviser_deinit();
static sx_status_t __sx_lib_adviser_roce_cb(const sx_lib_adviser_event_info_t event_info,
                                            const void                       *context);
static wjh_status_t __wjh_drop_reason_group_traps_set(wjh_user_channel_record_t      *user_channel_p,
                                                      wjh_drop_reason_group_record_t *group_item_p,
                                                      uint8_t                         severity_bits,
                                                      sx_trap_action_t                action);
static wjh_status_t __wjh_drop_reason_group_traps_update(wjh_drop_reason_group_record_t *group_item_p,
                                                         sx_trap_action_t                trap_action);
static wjh_status_t __wjh_drop_reason_enable_set(wjh_drop_reason_group_record_t *group_item_p,
                                                 uint8_t                         drop_reason_bits,
                                                 boolean_t                       enable);
static wjh_status_t __wjh_drop_reason_update(wjh_drop_reason_group_record_t *group_item_p,
                                             sx_trap_action_t               *trap_action_p);
static wjh_status_t __wjh_buffer_drop_group_span_session_bind_unbind(boolean_t bind);
static wjh_status_t __wjh_drop_reason_set_by_severity(wjh_drop_reason_group_record_t *group_item_p,
                                                      uint8_t                         severity_bits,
                                                      boolean_t                       enable,
                                                      sx_trap_action_t               *trap_action_p);
static wjh_status_t __wjh_buffer_drop_group_span_session_set(boolean_t enable);
static wjh_status_t __wjh_drop_reason_group_enable_set(wjh_user_channel_record_t      *user_channel_p,
                                                       wjh_drop_reason_group_record_t *group_item_p,
                                                       boolean_t                       enable,
                                                       uint8_t                         severity_bits);

#ifdef WJH_EBPF_PRESENT
static wjh_status_t __wjh_aggregation_create_ebpf_prog_and_map(wjh_user_channel_record_t      *user_channel_p,
                                                               wjh_drop_reason_group_record_t *group_item_p);
static wjh_status_t __wjh_aggregation_destroy_ebpf_prog_and_map(wjh_drop_reason_group_record_t *group_item_p);
static boolean_t __wjh_is_any_drop_reason_enabled(wjh_drop_reason_group_record_t *group_item_p);
static wjh_status_t __wjh_agg_read_ebpf_map(wjh_drop_reason_group_record_t *group_item_p,
                                            uint64_t                       *received_packets_p,
                                            uint32_t                       *cnt_p,
                                            wjh_aggregation_read_mode_e     agg_read_mode);
static wjh_status_t __wjh_aggregation_create_buffer(wjh_drop_reason_group_record_t *group_item_p);
static void __wjh_aggregation_destroy_buffer(wjh_drop_reason_group_record_t *group_item_p);
static wjh_status_t __wjh_aggregation_fill_buffer(wjh_drop_reason_group_record_t *group_item_p,
                                                  void                           *key_p,
                                                  void                           *value_p,
                                                  uint32_t                        index);
static wjh_status_t __wjh_aggregation_fill_five_tuples(wjh_aggregate_five_tuples_t *aggregation_five_tuples_p,
                                                       wjh_agg_ebpf_five_tuples_t  *ebpf_five_tuples_p,
                                                       void                        *sip_buffer,
                                                       void                        *dip_buffer,
                                                       uint32_t                     index);
static wjh_status_t __wjh_aggregation_exec_callback(wjh_drop_reason_group_record_t *group_item_p,
                                                    uint32_t                        count,
                                                    boolean_t                       is_pull_api);
static wjh_status_t __wjh_agg_bpf_prog_attach_detach(wjh_user_channel_record_t      *channel_p,
                                                     wjh_drop_reason_group_record_t *group_item_p,
                                                     boolean_t                       is_attach);
static wjh_status_t __wjh_filter_attach_detach(wjh_db_filter_record_t    *filter_record_p,
                                               wjh_user_channel_record_t *channel_p,
                                               boolean_t                  is_attach);
static wjh_status_t __wjh_filter_l1_match_rules(wjh_db_filter_rule_record_t **rule_record_list_pp,
                                                uint32_t                      rules_num,
                                                sx_port_log_id_t             *log_port_p,
                                                boolean_t                    *rule_matched_p);
static wjh_status_t __wjh_get_port_lag_log_id(uint32_t           port,
                                              boolean_t          from_cqe,
                                              wjh_port_log_id_t *port_log_id_p,
                                              uint8_t           *is_lag_member_p,
                                              wjh_port_log_id_t *lag_log_id_p);
static wjh_status_t __wjh_monitor_rdq_trace_points_enable(void);
static wjh_status_t __wjh_monitor_rdq_trace_points_disable(void);
static wjh_status_t __wjh_bpf_jit_proc_fs_set(boolean_t enable);
#endif
static wjh_status_t __wjh_load_lag_shm(void);
static wjh_status_t __wjh_unload_lag_shm(void);
static wjh_status_t __prepare_port_lag_mapping(sx_port_log_id_t *phy_port_lag_mapping);
sx_port_log_id_t wjh_sdk_interface_info_get(sx_port_log_id_t ingress_port,
                                            sx_port_log_id_t ingress_network_port);
static wjh_status_t __wjh_get_port_log_id_from_label_port(uint16_t           label_port,
                                                          wjh_port_log_id_t *port_log_id_p);
static wjh_status_t __wjh_sysfs_entry_set(const char *sysfs_entry, boolean_t enable);


/************************************************
 *  Function implementations
 ***********************************************/
/*
 * When the WJH ingress info type is configured as WJH_INGRESS_INFO_TYPE_PORT_LABEL,
 * WJH lib needs to return the port label associated with the actual ingress network
 * port. When WJH ingress info type is configured as WJH_INGRESS_INFO_TYPE_IF_INDEX
 * then ingress logical port(network port/ lag) is used to determine the interface
 * index.
 * ingress_port         - hold logport is ingress port LAG/port
 * ingress_network_port - hold logport of physical ingress port for packets
 * that ingress from LAG and from ingress port.
 */
sx_port_log_id_t wjh_sdk_interface_info_get(sx_port_log_id_t ingress_port, sx_port_log_id_t ingress_network_port)
{
    wjh_status_t        err = WJH_STATUS_SUCCESS;
    sx_status_t         sdk_rc = SX_STATUS_SUCCESS;
    wjh_log_port_attr_t log_port_attr;
    sx_span_port_attr_t span_port_attr;

    if (wjh_init_params_g.ingress_info_type == WJH_INGRESS_INFO_TYPE_IF_INDEX) {
        err = wjh_db_log_port_attr_get(ingress_port, &log_port_attr);
        if (WJH_CHECK_FAIL(err)) {
            ingress_port = WJH_INVALID_IF_INDEX;
        } else {
            ingress_port = log_port_attr.if_index;
        }
    } else if (wjh_init_params_g.ingress_info_type == WJH_INGRESS_INFO_TYPE_PORT_LABEL) {
        sdk_rc = sx_api_span_port_attr_get(sx_api_handle_s,
                                           ingress_network_port,
                                           SX_SPAN_PORT_ATTR_LABEL_INFO_E,
                                           &span_port_attr);
        if (SX_CHECK_FAIL(sdk_rc)) {
            ingress_port = WJH_INVALID_PORT_LABEL;
        } else {
            ingress_port = span_port_attr.attr.label_info.port_label;
        }
    }

    return ingress_port;
}

static wjh_status_t __wjh_policer_limits_get(wjh_policer_limits_t *limits_p)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_policer_limits_get_cb == NULL)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific callback or wjh_policer_limits_get_cb not valid");
        goto out;
    }

    err = wjh_dev_cb_p->wjh_policer_limits_get_cb(limits_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific callback wjh_policer_limits_get_cb failed, err=%u\n", err);
        goto out;
    }
out:
    return err;
}

static wjh_status_t __wjh_policer_settings_get(uint8_t percent, wjh_policer_attrs_t *policer_attrs_p)
{
    wjh_status_t         err = WJH_STATUS_SUCCESS;
    uint32_t             i = 0;
    uint32_t             wjh_policer_data_size = sizeof(wjh_policer_data_s) / sizeof(wjh_policer_data_s[0]);
    uint64_t             tmp_value = 0;
    int                  log_value = -1;
    uint16_t             pci_speed;
    uint16_t             pci_width;
    wjh_policer_limits_t policer_limits;
    uint32_t             burst_size;
    uint32_t             information_rate;

    err = wjh_pci_link_status_get(&pci_speed, &pci_width);
    if (WJH_CHECK_FAIL(err)) {
        /* For platforms which doesn't support PCI link status capabilities for now (e.g. SimX),
         * we use default value to prevent the initialization from failing. */
        WJH_LOG_INF("Failed to get the PCI speed and width, use default value: PCIe Gen1, width x1\n");
        pci_speed = 1;
        pci_width = 1;
        err = WJH_STATUS_SUCCESS;
    }

    for (i = 0; i < wjh_policer_data_size; ++i) {
        if ((pci_speed == wjh_policer_data_s[i].speed) &&
            (pci_width == wjh_policer_data_s[i].width)) {
            break;
        }
    }

    if (i >= wjh_policer_data_size) {
        WJH_LOG_INF("Got unknown PCIe speed and width, use default value: PCIe Gen1, width x1\n");
        i = 0;
    }

    err = __wjh_policer_limits_get(&policer_limits);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_sdk_policer_limits_get failed, err=%d\n", err);
        goto out;
    }

    information_rate = (((uint64_t)(wjh_policer_data_s[i].information_rate)) * percent) / 100;
    if (information_rate > policer_limits.policer_ir_max_value_bytes) {
        information_rate = policer_limits.policer_ir_max_value_bytes;
    }

    tmp_value = (((uint64_t)(information_rate)) * 1000000) >> 9;
    /* Calculate log2(tmp_value) */
    if (tmp_value == 0) {
        burst_size = 0;
    } else {
        while (tmp_value) {
            ++log_value;
            tmp_value >>= 1;
        }
        burst_size = log_value;
    }

    if (burst_size > policer_limits.policer_bs_max_value_bytes) {
        burst_size = policer_limits.policer_bs_max_value_bytes;
    } else if (burst_size < policer_limits.policer_bs_min_value_bytes) {
        burst_size = policer_limits.policer_bs_min_value_bytes;
    }
    policer_attrs_p->burst_size = burst_size;
    policer_attrs_p->information_rate = information_rate;

out:
    return err;
}

static wjh_status_t __wjh_tac_policer_settings_get(uint8_t percent, wjh_policer_attrs_t *policer_attrs_p)
{
    wjh_status_t         err = WJH_STATUS_SUCCESS;
    uint64_t             tmp_value = 0;
    int                  log_value = -1;
    wjh_policer_limits_t policer_limits;
    uint32_t             burst_size;
    uint32_t             information_rate;

    err = __wjh_policer_limits_get(&policer_limits);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_sdk_policer_limits_get failed, err=%d\n", err);
        return WJH_STATUS_ERROR;
    }

    /*same formula in __wjh_policer_settings_get()*/
    information_rate = (((uint64_t)(TAC_INFORMATION_RATE)) * percent) / 100;

    tmp_value = (((uint64_t)(information_rate)) * 1000000) >> 9;
    /* Calculate log2(tmp_value) */
    if (tmp_value == 0) {
        burst_size = 0;
    } else {
        while (tmp_value) {
            ++log_value;
            tmp_value >>= 1;
        }
        burst_size = log_value;
    }

    if (burst_size > policer_limits.policer_bs_max_value_bytes) {
        burst_size = policer_limits.policer_bs_max_value_bytes;
    } else if (burst_size < policer_limits.policer_bs_min_value_bytes) {
        burst_size = policer_limits.policer_bs_min_value_bytes;
    }

    policer_attrs_p->burst_size = burst_size;
    policer_attrs_p->information_rate = information_rate;
    return WJH_STATUS_SUCCESS;
}

static wjh_status_t __wjh_cyclic_channel_buf_create(void **buf_pp)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    sx_packet_info_t *packet_info_list_p = NULL;
    uint32_t          i = 0;

    packet_info_list_p = cl_calloc(READ_MULTI_BUFFS_MAX, sizeof(sx_packet_info_t));
    if (packet_info_list_p == NULL) {
        WJH_LOG_ERR("Failed to allocate memory.\n");
        err = WJH_STATUS_NO_MEMORY;
        goto err_out;
    }

    for (i = 0; i < READ_MULTI_BUFFS_MAX; ++i) {
        packet_info_list_p[i].packet_p = cl_malloc(WJH_RECEIVED_PACKET_SIZE);
        if (packet_info_list_p[i].packet_p == NULL) {
            WJH_LOG_ERR("Failed to allocate memory.\n");
            err = WJH_STATUS_NO_MEMORY;
            goto err_out;
        }
        packet_info_list_p[i].packet_size = WJH_RECEIVED_PACKET_SIZE;
    }

    *buf_pp = (void*)packet_info_list_p;
    return err;

err_out:
    if (packet_info_list_p != NULL) {
        for (i = 0; i < READ_MULTI_BUFFS_MAX; ++i) {
            if (packet_info_list_p[i].packet_p != NULL) {
                cl_free(packet_info_list_p[i].packet_p);
            }
        }

        cl_free(packet_info_list_p);
    }

    return err;
}

static wjh_status_t __wjh_cyclic_channel_buf_destroy(void *buf_p)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    sx_packet_info_t *packet_info_list_p = (sx_packet_info_t*)buf_p;
    uint32_t          i = 0;

    if (packet_info_list_p != NULL) {
        for (i = 0; i < READ_MULTI_BUFFS_MAX; ++i) {
            if (packet_info_list_p[i].packet_p != NULL) {
                cl_free(packet_info_list_p[i].packet_p);
            }
        }

        cl_free(packet_info_list_p);
    }

    return err;
}

static void __wjh_parse_mirror_ext_header(const sx_packet_info_t     *packet_info_p,
                                          wjh_buffer_drop_raw_info_t *raw_info_buf_p,
                                          wjh_span_mirror_reason_e   *mirror_reason_p)
{
    wjh_buf_drop_pkt_hdr_ver2_t    *buf_drop_pkt_hdr = NULL;
    int                             count;
    uint32_t                       *mirror_header_tlv_long = NULL;
    uint16_t                       *mirror_header_tlv_short = NULL;
    wjh_mirror_header_v2_tlv_type_e type;
    boolean_t                       is_last_tlv = FALSE;

    buf_drop_pkt_hdr = (wjh_buf_drop_pkt_hdr_ver2_t*)packet_info_p->packet_p;
    for (count = 0; count < MIRROR_HEADER_TLV_LONG_COUNT; count++) {
        mirror_header_tlv_long = &buf_drop_pkt_hdr->mirror_header_tlvs_long[count];
        *mirror_header_tlv_long = ntohl(*mirror_header_tlv_long);

        type =
            (*mirror_header_tlv_long &
             WJH_BUF_DROP_HDR_EXTENDED_TYPE_MASK_LONG) >> WJH_BUF_DROP_HDR_EXTENDED_TYPE_OFFSET_LONG;

        switch (type) {
        case WJH_MIRROR_HEADER_V2_TLV_TYPE_EG_BUFF_OCCUPANCY:
            raw_info_buf_p->original_occupancy = *mirror_header_tlv_long & WJH_BUF_DROP_HDR_EXTENDED_VALUE_MASK_LONG;
            break;

        case WJH_MIRROR_HEADER_V2_TLV_TYPE_LATENCY:
            raw_info_buf_p->original_latency = *mirror_header_tlv_long & WJH_BUF_DROP_HDR_EXTENDED_VALUE_MASK_LONG;
            break;

        case WJH_MIRROR_HEADER_V2_TLV_TYPE_ING_BUFF_OCCUPANCY:
        case WJH_MIRROR_HEADER_V2_TLV_TYPE_FLAGS_EXT:
        default:
            break;
        }
        is_last_tlv = *mirror_header_tlv_long & WJH_BUF_DROP_HDR_EXTENDED_LAST_TLV_MASK_LONG;
        if (is_last_tlv) {
            break;
        }
    }
    /* If is_last_tlv is not set, continue processing the remaining tlvs */

    if (is_last_tlv == FALSE) {
        for (count = 0; count < MIRROR_HEADER_TLV_SHORT_COUNT; count++) {
            mirror_header_tlv_short = &buf_drop_pkt_hdr->mirror_header_tlvs_short[count];
            *mirror_header_tlv_short = ntohs(*mirror_header_tlv_short);
            type =
                (*mirror_header_tlv_short &
                 WJH_BUF_DROP_HDR_EXTENDED_TYPE_MASK_SHORT) >> WJH_BUF_DROP_HDR_EXTENDED_TYPE_OFFSET_SHORT;

            switch (type) {
            case WJH_MIRROR_HEADER_V2_TLV_TYPE_MIRROR_REASON:
                *mirror_reason_p = *mirror_header_tlv_short & WJH_BUF_DROP_HDR_EXTENDED_VALUE_MASK_SHORT;
                break;

            case WJH_MIRROR_HEADER_V2_TLV_TYPE_TCLASS:
                raw_info_buf_p->tc = *mirror_header_tlv_short & WJH_BUF_DROP_HDR_EXTENDED_VALUE_MASK_SHORT;
                break;

            case WJH_MIRROR_HEADER_V2_TLV_TYPE_MIRROR_AGENT:
            case WJH_MIRROR_HEADER_V2_TLV_TYPE_PG:
            default:
                break;
            }
            is_last_tlv = *mirror_header_tlv_short & WJH_BUF_DROP_HDR_EXTENDED_LAST_TLV_MASK_SHORT;
            if (is_last_tlv) {
                break;
            }
        }
    }
}

static wjh_status_t __wjh_mirror_header_v2_size_get(uint32_t *size_p)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_mirror_header_v2_size_get_cb == NULL)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific callback not valid");
        goto out;
    }

    err = wjh_dev_cb_p->wjh_mirror_header_v2_size_get_cb(size_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific cb mirror header v2 size get failed, err=%u\n", err);
        goto out;
    }

out:
    return err;
}

static void __wjh_buffer_raw_info_fill(const sx_packet_info_t                   *packet_info_p,
                                       const wjh_user_channel_timestamp_source_e timestamp_source)
{
    wjh_status_t                      err = WJH_STATUS_SUCCESS;
    wjh_buf_drop_pkt_common_header_t *buf_drop_pkt_hdr = NULL;
    uint32_t                         *raw_info_count_p =
        &(raw_info_buffers_s[WJH_DROP_REASON_GROUP_BUFFER_E].raw_info_count);
    wjh_trap_id_attr_t         *trap_id_attr_p = NULL;
    uint16_t                    mirror_ethertype = 0, ingress_label_port = 0, egress_label_port = 0;
    uint32_t                    secs_msb = 0,  nsecs_msb = 0;
    uint16_t                    secs_lsb = 0, nsecs_lsb = 0;
    uint64_t                    time_secs = 0, time_nsecs = 0;
    uint8_t                     is_lag_mask = 0;
    uint8_t                     is_eg_port_valid_mask = 0;
    uint32_t                    pkt_offset = 0;
    wjh_drop_reason_item_t     *drop_reason_item_p = NULL;
    wjh_buffer_drop_raw_info_t *raw_info_buf =
        (wjh_buffer_drop_raw_info_t*)(raw_info_buffers_s[WJH_DROP_REASON_GROUP_BUFFER_E].raw_info_buf);
    uint32_t                 mirror_header_size = sizeof(wjh_buf_drop_pkt_common_header_t);
    uint32_t                 index = 0;
    wjh_span_mirror_reason_e mirror_reason = WJH_SPAN_MIRROR_REASON_INVALID;
    sx_port_log_id_t         log_port = 0;

    /* Mirror to CPU Case */
    if ((SX_TRAP_ID_MIRROR_AGENT_CHECK_RANGE(packet_info_p->receive_info.trap_id))) {
        pkt_offset = 0;
        mirror_header_size = 0;
        mirror_reason = (wjh_span_mirror_reason_e)(packet_info_p->receive_info.mirror_info.mirror_reason);
        if (mirror_reason == WJH_SPAN_MIRROR_REASON_INVALID) {
            /* For mirror agent traps, we should ignore those packets carrying invalid mirror reason (0). */
            goto out;
        }
        /* Egress information copied here */
        if ((packet_info_p->receive_info.dest_port_type == SX_RECEIVE_DEST_PORT_INVALID_E) ||
            (packet_info_p->receive_info.dest_port_type == SX_RECEIVE_DEST_PORT_MULTI_PORT_E)) {
            /* SDK host interface explicitly set below ports as INVALID in case of
             * Multi port scenario. WJH lib does the same for raw information given
             * to application.
             */
            raw_info_buf[*raw_info_count_p].egress_port_valid = 0;
            raw_info_buf[*raw_info_count_p].egress_port = WJH_INVALID_PORT_ID;
            raw_info_buf[*raw_info_count_p].is_egress_lag_member = 0;
            raw_info_buf[*raw_info_count_p].egress_lag = WJH_INVALID_PORT_ID;
        } else {
            raw_info_buf[*raw_info_count_p].egress_port =
                wjh_sdk_interface_info_get(packet_info_p->receive_info.dest_log_port,
                                           packet_info_p->receive_info.dest_log_port);
            raw_info_buf[*raw_info_count_p].egress_port_valid = 1;
            /* Check if egress port is LAG or network port */
            if (packet_info_p->receive_info.dest_port_type == SX_RECEIVE_DEST_PORT_NETWORK_PORT_E) {
                raw_info_buf[*raw_info_count_p].is_egress_lag_member = 0;
                raw_info_buf[*raw_info_count_p].egress_lag = WJH_INVALID_PORT_ID;
            } else {
                raw_info_buf[*raw_info_count_p].is_egress_lag_member = 1;
                raw_info_buf[*raw_info_count_p].egress_lag =
                    wjh_sdk_interface_info_get(packet_info_p->receive_info.dest_lag_port,
                                               packet_info_p->receive_info.dest_log_port);
            }
        }
        raw_info_buf[*raw_info_count_p].is_lag_member = packet_info_p->receive_info.is_lag;
        memcpy(&raw_info_buf[*raw_info_count_p].timestamp, &packet_info_p->receive_info.timestamp,
               sizeof(struct timespec));
        raw_info_buf[*raw_info_count_p].original_occupancy =
            packet_info_p->receive_info.mirror_info.original_occupancy;
        raw_info_buf[*raw_info_count_p].original_latency = packet_info_p->receive_info.mirror_info.original_latency;
        raw_info_buf[*raw_info_count_p].tc = packet_info_p->receive_info.mirror_info.original_packet_tclass;

        /* Ingress information copied here */
        if (raw_info_buf[*raw_info_count_p].is_lag_member == 0) {
            raw_info_buf[*raw_info_count_p].ingress_port =
                wjh_sdk_interface_info_get(packet_info_p->receive_info.source_log_port,
                                           packet_info_p->receive_info.source_log_port);
            raw_info_buf[*raw_info_count_p].ingress_lag = WJH_INVALID_PORT_ID;
        } else {
            raw_info_buf[*raw_info_count_p].ingress_lag =
                wjh_sdk_interface_info_get(packet_info_p->receive_info.source_lag_port,
                                           packet_info_p->receive_info.source_log_port);
            raw_info_buf[*raw_info_count_p].ingress_port =
                wjh_sdk_interface_info_get(packet_info_p->receive_info.source_log_port,
                                           packet_info_p->receive_info.source_log_port);
        }
    } else { /* Legacy recirculation port case */
        buf_drop_pkt_hdr = (wjh_buf_drop_pkt_common_header_t*)packet_info_p->packet_p;
        mirror_ethertype = ntohs(buf_drop_pkt_hdr->mirror_ethertype);
        /* Ignore non SPAN packets */
        if (mirror_ethertype != WJH_BUF_DROP_HDR_COMMON_ETHER_TYPE) {
            goto out;
        }
        if (buf_drop_pkt_hdr->opcode == WJH_BUF_DROP_HDR_OPCODE_VER_2) {
            /* We may have some TLVs to process*/
            err = __wjh_mirror_header_v2_size_get(&mirror_header_size);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_mirror_header_v2_size_get failed, err: %d\n", err);
                goto out;
            }
            __wjh_parse_mirror_ext_header(packet_info_p, &raw_info_buf[*raw_info_count_p], &mirror_reason);
            if (mirror_reason == WJH_SPAN_MIRROR_REASON_INVALID) {
                /* For mirror header V2, we should ignore those packets carrying invalid mirror reason (0). */
                goto out;
            }
        }
        pkt_offset = mirror_header_size + buf_drop_pkt_hdr->pad_count;

        /* Check if ingress port is lag or network port based on flags field in SPAN header*/
        is_lag_mask = 0x1;
        is_lag_mask = is_lag_mask << WJH_BUF_DROP_HDR_COMMON_IS_INGRESS_LAG_OFFSET;
        if (buf_drop_pkt_hdr->flags & is_lag_mask) {
            raw_info_buf[*raw_info_count_p].is_lag_member = 1;
        } else {
            raw_info_buf[*raw_info_count_p].is_lag_member = 0;
        }

        /* Check if egress port is valid based on flags field in SPAN header*/
        is_eg_port_valid_mask = (0x1 << WJH_BUF_DROP_HDR_COMMON_IS_EGRESS_PORT_VALID_OFFSET);
        if (buf_drop_pkt_hdr->flags & is_eg_port_valid_mask) {
            raw_info_buf[*raw_info_count_p].egress_port_valid = 1;
        } else {
            raw_info_buf[*raw_info_count_p].egress_port_valid = 0;
            raw_info_buf[*raw_info_count_p].egress_port = WJH_INVALID_PORT_ID;
            raw_info_buf[*raw_info_count_p].is_egress_lag_member = 0;
            raw_info_buf[*raw_info_count_p].egress_lag = WJH_INVALID_PORT_ID;
        }

        /* Gather ingress information from SPAN header */
        ingress_label_port = ntohs(buf_drop_pkt_hdr->ingress_label_port);
        if (raw_info_buf[*raw_info_count_p].is_lag_member == 0) {
            /* - In case of PORT_LABEL mode the PORT_LABEL can be any value.
             *   In this case we will return to the user PORT_LABEL as is
             * - In all other cases PORT_LABEL have default value that programmed by SDK
             *   and contains PORT number embedded into it, so we will extract it .*/
            if (wjh_init_params_g.ingress_info_type == WJH_INGRESS_INFO_TYPE_PORT_LABEL) {
                raw_info_buf[*raw_info_count_p].ingress_port = ingress_label_port;
            } else {
                err = __wjh_get_port_log_id_from_label_port(ingress_label_port,
                                                            &(raw_info_buf[*raw_info_count_p].
                                                              ingress_port));
                if (WJH_CHECK_FAIL(err)) {
                    WJH_LOG_ERR("__wjh_get_port_log_id_from_label_port_and_split_num failed, err: %d\n", err);
                    goto out;
                }

                raw_info_buf[*raw_info_count_p].ingress_port =
                    wjh_sdk_interface_info_get(raw_info_buf[*raw_info_count_p].ingress_port,
                                               raw_info_buf[*raw_info_count_p].ingress_port);
                raw_info_buf[*raw_info_count_p].ingress_lag = WJH_INVALID_PORT_ID;
            }
        } else {
            /* - In case of PORT_LABEL mode the PORT_LABEL can be any value.
             *   In this case we will return to the user PORT_LABEL as is
             * - In all other cases PORT_LABEL have default value that programmed by SDK
             *   and contains PORT number embedded into it, so we will extract it .*/
            if (wjh_init_params_g.ingress_info_type == WJH_INGRESS_INFO_TYPE_PORT_LABEL) {
                raw_info_buf[*raw_info_count_p].ingress_port = ingress_label_port;
            } else {
                /* Explicitly use first index in the log_port_list instead of new variable */
                log_port = 0;
                SX_PORT_TYPE_ID_SET(log_port, SX_PORT_TYPE_LAG);
                SX_PORT_LAG_ID_SET(log_port, ingress_label_port);
                raw_info_buf[*raw_info_count_p].ingress_port = WJH_INVALID_PORT_ID;
                raw_info_buf[*raw_info_count_p].ingress_lag =
                    wjh_sdk_interface_info_get(log_port, log_port);
            }
        }

        /* Gather egress information from SPAN header */
        if (raw_info_buf[*raw_info_count_p].egress_port_valid) {
            egress_label_port = ntohs(buf_drop_pkt_hdr->egress_label_port);
            if (egress_label_port == WJH_BUF_DROP_EGRESS_PORT_MULTI_PORT) {
                /* Multi port scenario, Information composed similar to
                 * information obtained in mirror to CPU for multi port.
                 */
                raw_info_buf[*raw_info_count_p].egress_port_valid = 0;
                raw_info_buf[*raw_info_count_p].egress_port = WJH_INVALID_PORT_ID;
                raw_info_buf[*raw_info_count_p].is_egress_lag_member = 0;
                raw_info_buf[*raw_info_count_p].egress_lag = WJH_INVALID_PORT_ID;
            } else {
                /* Check if egress port is a LAG port based on flags in SPAN header */
                is_lag_mask = 0x1;
                is_lag_mask = is_lag_mask << WJH_BUF_DROP_HDR_COMMON_IS_EGRESS_LAG_OFFSET;
                if (buf_drop_pkt_hdr->flags & is_lag_mask) {
                    raw_info_buf[*raw_info_count_p].is_egress_lag_member = 1;
                } else {
                    raw_info_buf[*raw_info_count_p].is_egress_lag_member = 0;
                }
                /* Gather egress information depending on the port type */
                if (raw_info_buf[*raw_info_count_p].is_egress_lag_member == 0) {
                    /* - In case of PORT_LABEL mode the PORT_LABEL can be any value.
                     *   In this case we will return to the user PORT_LABEL as is
                     * - In all other cases PORT_LABEL have default value that programmed by SDK
                     *   and contains PORT number embedded into it, so we will extract it .*/
                    if (wjh_init_params_g.ingress_info_type == WJH_INGRESS_INFO_TYPE_PORT_LABEL) {
                        raw_info_buf[*raw_info_count_p].egress_port = egress_label_port;
                    } else {
                        err = __wjh_get_port_log_id_from_label_port(egress_label_port,
                                                                    &(raw_info_buf[*raw_info_count_p].
                                                                      egress_port));
                        if (WJH_CHECK_FAIL(err)) {
                            WJH_LOG_ERR("__wjh_get_port_log_id_from_label_port_and_split_num failed, err: %d\n", err);
                            goto out;
                        }

                        raw_info_buf[*raw_info_count_p].egress_port =
                            wjh_sdk_interface_info_get(raw_info_buf[*raw_info_count_p].egress_port,
                                                       raw_info_buf[*raw_info_count_p].egress_port);
                        raw_info_buf[*raw_info_count_p].egress_lag = WJH_INVALID_PORT_ID;
                    }
                } else {
                    if (wjh_init_params_g.ingress_info_type == WJH_INGRESS_INFO_TYPE_PORT_LABEL) {
                        raw_info_buf[*raw_info_count_p].egress_port = egress_label_port;
                    } else {
                        log_port = 0;
                        SX_PORT_TYPE_ID_SET(log_port, SX_PORT_TYPE_LAG);
                        SX_PORT_LAG_ID_SET(log_port,  egress_label_port);
                        raw_info_buf[*raw_info_count_p].egress_port = WJH_INVALID_PORT_ID;
                        raw_info_buf[*raw_info_count_p].egress_lag =
                            wjh_sdk_interface_info_get(log_port, log_port);
                    }
                }
            }
        }
        if (timestamp_source == WJH_USER_CHANNEL_TIMESTAMP_SOURCE_HW_CLOCK_E) {
            secs_msb = ntohl(buf_drop_pkt_hdr->secs_msb);
            secs_lsb = ntohs(buf_drop_pkt_hdr->secs_lsb);
            nsecs_msb = ntohs(buf_drop_pkt_hdr->nsecs_msb);
            nsecs_lsb = ntohs(buf_drop_pkt_hdr->nsecs_lsb);
            time_secs |= ((uint64_t)secs_msb << 16);
            time_secs |= secs_lsb;
            time_nsecs |= ((uint64_t)nsecs_msb << 16);
            time_nsecs |= nsecs_lsb;
            raw_info_buf[*raw_info_count_p].timestamp.tv_sec = time_secs;
            raw_info_buf[*raw_info_count_p].timestamp.tv_nsec = time_nsecs;
        } else {
            memcpy(&raw_info_buf[*raw_info_count_p].timestamp, &packet_info_p->receive_info.timestamp,
                   sizeof(struct timespec));
        }
    }

    wjh_db_trap_id_attr_get(packet_info_p->receive_info.trap_id, &trap_id_attr_p);
    /* Adjust packet length and packet pointer */
    raw_info_buf[*raw_info_count_p].packet = packet_info_p->packet_p + pkt_offset;
    raw_info_buf[*raw_info_count_p].packet_size =
        packet_info_p->packet_size - mirror_header_size;
    raw_info_buf[*raw_info_count_p].drop_reason.reason = wjh_buffer_drop_reason_str;
    raw_info_buf[*raw_info_count_p].drop_reason.description = wjh_buffer_drop_desc_str;
    raw_info_buf[*raw_info_count_p].drop_reason.id = 0;
    raw_info_buf[*raw_info_count_p].drop_reason.severity = WJH_SEVERITY_MIN_E;
    raw_info_buf[*raw_info_count_p].drop_reason.event_type = WJH_EVENT_NONE_E;

    if (mirror_reason != WJH_SPAN_MIRROR_REASON_INVALID) {
        switch (mirror_reason) {
        case WJH_SPAN_MIRROR_REASON_ING_SHARED_BUFFER_DROP:
            index = 0;
            break;

        case WJH_SPAN_MIRROR_REASON_ING_WRED:
            index = 1;
            break;

        case WJH_SPAN_MIRROR_REASON_ING_TC_CONGESTION:
            index = 2;
            break;

        case WJH_SPAN_MIRROR_REASON_EGR_TC_LATENCY:
            index = 3;
            break;

        default:
            WJH_LOG_INF("Unsupported mirror reason %u\n", mirror_reason);
            goto out;
            break;
        }
        wjh_db_get_drop_reason_item(WJH_BUFFER_DROP_REASON_INDEX_MIN + index, &drop_reason_item_p);

        if (drop_reason_item_p->reason) {
            raw_info_buf[*raw_info_count_p].drop_reason.reason = drop_reason_item_p->reason;
        }
        if (drop_reason_item_p->description) {
            raw_info_buf[*raw_info_count_p].drop_reason.description = drop_reason_item_p->description;
        }
        raw_info_buf[*raw_info_count_p].drop_reason.severity = drop_reason_item_p->severity;
        raw_info_buf[*raw_info_count_p].drop_reason.id = drop_reason_item_p->id;
        raw_info_buf[*raw_info_count_p].drop_reason.event_type = drop_reason_item_p->event_type;
    }

    *raw_info_count_p += 1;

out:
    return;
}

static wjh_status_t __wjh_acl_attributes_get(const uint32_t                acl_user_id,
                                             sx_acl_pkt_drop_attributes_t *acl_attr_p,
                                             wjh_acl_rule_id_t            *rule_id_p,
                                             char                        **acl_name_p,
                                             char                        **rule_p)
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    sx_status_t                  sdk_rc = SX_STATUS_SUCCESS;
    sx_acl_helper_status_t       acl_helper_rc = SX_ACL_HELPER_STATUS_SUCCESS;
    sx_acl_pkt_drop_attributes_t acl_attr;
    sx_acl_helper_acl_id_t       acl_id = 0;
    sx_acl_helper_rule_id_t      rule_id = 0;
    char                        *acl_name = NULL;
    uint32_t                     acl_name_len = 0;
    char                        *rule = NULL;
    uint32_t                     rule_len = 0;

    memset(&acl_attr, 0, sizeof(acl_attr));
    sdk_rc = sx_lib_flex_acl_drop_pkt_acl_data_get(acl_user_id, &acl_attr);
    if (SX_CHECK_FAIL(sdk_rc)) {
        if (sdk_rc != SX_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR(
                "sx_lib_acl_dropped_pkt_acl_data_get failed, acl_user_id: (%u), error: %s.\n",
                acl_user_id, sx_status_str(sdk_rc));
            err = WJH_STATUS_ERROR;
        } else {
            err = WJH_STATUS_ENTRY_NOT_FOUND;
        }
        goto out;
    }

    acl_id = (sx_acl_helper_acl_id_t)(acl_attr.acl_id);
    SX_ACL_HELPER_RULE_ID_BUILD(rule_id, ((uint64_t)(acl_attr.acl_region_id)),
                                acl_attr.acl_rule_offset);
    acl_helper_rc = sx_acl_helper_acl_description_get(acl_id, rule_id, NULL,
                                                      &acl_name_len, NULL, &rule_len);
    if (acl_helper_rc != SX_ACL_HELPER_STATUS_SUCCESS) {
        if (acl_helper_rc != SX_ACL_HELPER_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR(
                "sx_acl_helper_acl_description_get failed, acl_id: (%u), rule_id: (%" PRIu64 "), error: %d.\n",
                acl_id, rule_id, acl_helper_rc);
            err = WJH_STATUS_ERROR;
        } else {
            err = WJH_STATUS_ENTRY_NOT_FOUND;
        }
        goto out;
    }

    acl_name = cl_calloc(acl_name_len + 1, 1);
    if (acl_name == NULL) {
        WJH_LOG_ERR("Failed to allocate memory for ACL name string\n");
        err = WJH_STATUS_NO_MEMORY;
        goto out;
    }
    rule = cl_calloc(rule_len + 1, 1);
    if (rule == NULL) {
        WJH_LOG_ERR("Failed to allocate memory for ACL rule string\n");
        err = WJH_STATUS_NO_MEMORY;
        goto free_acl_name;
    }
    acl_helper_rc = sx_acl_helper_acl_description_get(acl_id, rule_id, acl_name,
                                                      &acl_name_len, rule, &rule_len);
    if (acl_helper_rc != SX_ACL_HELPER_STATUS_SUCCESS) {
        if (acl_helper_rc != SX_ACL_HELPER_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR(
                "sx_acl_helper_acl_description_get failed, acl_id: (%u), rule_id: (%" PRIu64 "), error: %d.\n",
                acl_id, rule_id, acl_helper_rc);
            err = WJH_STATUS_ERROR;
        } else {
            err = WJH_STATUS_ENTRY_NOT_FOUND;
        }
        goto free_rule;
    }

    memcpy(acl_attr_p, &acl_attr, sizeof(acl_attr));
    *rule_id_p = rule_id;
    *acl_name_p = acl_name;
    *rule_p = rule;
    goto out;

free_rule:
    cl_free(rule);

free_acl_name:
    cl_free(acl_name);

out:
    return err;
}

static void __wjh_acl_raw_info_fill(const sx_packet_info_t *packet_info_p)
{
    wjh_status_t             rc = WJH_STATUS_SUCCESS;
    wjh_acl_drop_raw_info_t *acl_raw_info_buf =
        (wjh_acl_drop_raw_info_t*)(raw_info_buffers_s[WJH_DROP_REASON_GROUP_ACL_E].raw_info_buf);
    uint32_t *acl_raw_info_cnt_p =
        &(raw_info_buffers_s[WJH_DROP_REASON_GROUP_ACL_E].raw_info_count);
    sx_acl_pkt_drop_attributes_t acl_attr;
    wjh_acl_rule_id_t            rule_id = 0;
    char                        *acl_name = NULL;
    char                        *rule = NULL;
    wjh_drop_reason_item_t      *drop_reason_item_p = NULL;
    uint32_t                     index = 0;

    memset(&acl_attr, 0, sizeof(acl_attr));
    rc = __wjh_acl_attributes_get(packet_info_p->receive_info.acl_user_id,
                                  &acl_attr, &rule_id, &acl_name, &rule);
    if (WJH_CHECK_FAIL(rc)) {
        if (rc != WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR("__wjh_acl_attributes_get failed, err: %d\n", rc);
        }
        goto err;
    }

    switch (acl_attr.acl_direction) {
    case SX_ACL_DIRECTION_INGRESS:
        index = 0;
        break;

    case SX_ACL_DIRECTION_EGRESS:
        index = 3;
        break;

    case SX_ACL_DIRECTION_RIF_INGRESS:
        index = 1;
        break;

    case SX_ACL_DIRECTION_RIF_EGRESS:
        index = 2;
        break;

    case SX_ACL_DIRECTION_TPORT_INGRESS:
        /* an index of relevant drop reason inside ACL drop reasons group:
         *  WJH_DROP_REASON_ID_INGRESS_PORT_ACL_E    (601) - 1st reason; index #0
         *  WJH_DROP_REASON_ID_INGRESS_TPORT_ACL_E   (605) - 5th reason; index #4 */
        index = 4;
        break;

    case SX_ACL_DIRECTION_TPORT_EGRESS:
        index = 5;
        break;

    case SX_ACL_DIRECTION_MULTI_POINTS_E:
        index = 6;
        break;

    case SX_ACL_DIRECTION_CPU_INGRESS:
        index = 7;
        break;

    case SX_ACL_DIRECTION_CPU_EGRESS:
        index = 8;
        break;


    default:
        WJH_LOG_ERR("Invalid acl direction %u\n", acl_attr.acl_direction);
        goto err;
        break;
    }

    wjh_db_get_drop_reason_item(WJH_ACL_DROP_REASON_INDEX_MIN + index, &drop_reason_item_p);

    acl_raw_info_buf[*acl_raw_info_cnt_p].packet = packet_info_p->packet_p;
    acl_raw_info_buf[*acl_raw_info_cnt_p].packet_size =
        packet_info_p->packet_size;
    acl_raw_info_buf[*acl_raw_info_cnt_p].ingress_port =
        wjh_sdk_interface_info_get(packet_info_p->receive_info.source_log_port,
                                   packet_info_p->receive_info.source_log_port);
    acl_raw_info_buf[*acl_raw_info_cnt_p].is_lag_member = packet_info_p->receive_info.is_lag;
    acl_raw_info_buf[*acl_raw_info_cnt_p].ingress_lag =
        wjh_sdk_interface_info_get(packet_info_p->receive_info.source_lag_port,
                                   packet_info_p->receive_info.source_log_port);
    acl_raw_info_buf[*acl_raw_info_cnt_p].binding_point = (wjh_acl_binding_point_t)(acl_attr.acl_direction);
    acl_raw_info_buf[*acl_raw_info_cnt_p].rule_id = rule_id;
    acl_raw_info_buf[*acl_raw_info_cnt_p].acl_name = acl_name;
    acl_raw_info_buf[*acl_raw_info_cnt_p].rule = rule;
    memcpy(&(acl_raw_info_buf[*acl_raw_info_cnt_p].timestamp),
           &(packet_info_p->receive_info.timestamp),
           sizeof(packet_info_p->receive_info.timestamp));
    if (drop_reason_item_p->reason) {
        acl_raw_info_buf[*acl_raw_info_cnt_p].drop_reason.reason = drop_reason_item_p->reason;
    } else {
        acl_raw_info_buf[*acl_raw_info_cnt_p].drop_reason.reason = WJH_DB_EMPTY_STR;
    }
    if (drop_reason_item_p->description) {
        acl_raw_info_buf[*acl_raw_info_cnt_p].drop_reason.description = drop_reason_item_p->description;
    } else {
        acl_raw_info_buf[*acl_raw_info_cnt_p].drop_reason.description = WJH_DB_EMPTY_STR;
    }
    acl_raw_info_buf[*acl_raw_info_cnt_p].drop_reason.severity = drop_reason_item_p->severity;
    acl_raw_info_buf[*acl_raw_info_cnt_p].drop_reason.id = drop_reason_item_p->id;
    acl_raw_info_buf[*acl_raw_info_cnt_p].drop_reason.event_type = drop_reason_item_p->event_type;
    *acl_raw_info_cnt_p += 1;
    return;

err:
    if (acl_name != NULL) {
        cl_free(acl_name);
    }

    if (rule != NULL) {
        cl_free(rule);
    }
}

static void __wjh_roce_raw_info_fill(const sx_packet_info_t *packet_info_p, const wjh_trap_id_attr_t *trap_id_attr_p)
{
    wjh_status_t              err = WJH_STATUS_SUCCESS;
    wjh_roce_drop_raw_info_t *roce_raw_info_buf = NULL;
    uint32_t                  roce_raw_info_cnt = 0;
    wjh_drop_reason_id_t      drop_reason_id = 0;
    wjh_drop_reason_item_t   *drop_reason_item_p = NULL;

    roce_raw_info_buf = (wjh_roce_drop_raw_info_t*)(raw_info_buffers_s[WJH_DROP_REASON_GROUP_ROCE_E].raw_info_buf);
    roce_raw_info_cnt = raw_info_buffers_s[WJH_DROP_REASON_GROUP_ROCE_E].raw_info_count;
    /* Get the drop reason id encoded in the acl used id */
    drop_reason_id = WJH_ROCE_ACL_USER_ID_DROP_REASON(packet_info_p->receive_info.acl_user_id);

    err = wjh_db_get_drop_reason_item_by_reason(drop_reason_id, &drop_reason_item_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to find drop reason item for drop reason id %d\n", drop_reason_id);
        goto out;
    }
    /* Fill the common parts of the raw info */
    FILL_COMMON_PART_OF_RAW_INFO(wjh_roce_drop_raw_info_t, WJH_DROP_REASON_GROUP_ROCE_E, packet_info_p,
                                 trap_id_attr_p);
    /* Get the switch priority encoded in the acl user id */
    roce_raw_info_buf[roce_raw_info_cnt].switch_prio = WJH_ROCE_ACL_USER_ID_SWITCH_PRIO(
        packet_info_p->receive_info.acl_user_id);

    if (drop_reason_item_p->reason) {
        roce_raw_info_buf[roce_raw_info_cnt].drop_reason.reason = drop_reason_item_p->reason;
    } else {
        roce_raw_info_buf[roce_raw_info_cnt].drop_reason.reason = WJH_DB_EMPTY_STR;
    }
    if (drop_reason_item_p->description) {
        roce_raw_info_buf[roce_raw_info_cnt].drop_reason.description = drop_reason_item_p->description;
    } else {
        roce_raw_info_buf[roce_raw_info_cnt].drop_reason.description = WJH_DB_EMPTY_STR;
    }
    roce_raw_info_buf[roce_raw_info_cnt].drop_reason.severity = drop_reason_item_p->severity;
    roce_raw_info_buf[roce_raw_info_cnt].drop_reason.id = drop_reason_item_p->id;
    roce_raw_info_buf[roce_raw_info_cnt].drop_reason.event_type = drop_reason_item_p->event_type;

out:
    return;
}


static void __wjh_acl_raw_info_list_free(void)
{
    wjh_acl_drop_raw_info_t * acl_raw_info_list =
        (wjh_acl_drop_raw_info_t*)(raw_info_buffers_s[WJH_DROP_REASON_GROUP_ACL_E].raw_info_buf);
    uint32_t acl_raw_info_count = raw_info_buffers_s[WJH_DROP_REASON_GROUP_ACL_E].raw_info_count;
    uint32_t i = 0;

    for (i = 0; i < acl_raw_info_count; ++i) {
        if (acl_raw_info_list[i].acl_name != NULL) {
            cl_free((void*)acl_raw_info_list[i].acl_name);
            acl_raw_info_list[i].acl_name = NULL;
        }
        if (acl_raw_info_list[i].rule != NULL) {
            cl_free((void*)acl_raw_info_list[i].rule);
            acl_raw_info_list[i].rule = NULL;
        }
    }
}

static wjh_status_t __wjh_acl_drop_reason_group_disable(boolean_t disable)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    sx_status_t                sdk_rc = SX_STATUS_SUCCESS;
    sx_acl_global_attributes_t global_attributes;

    memset(&global_attributes, 0, sizeof(sx_acl_global_attributes_t));
    global_attributes.disable_acl_drop_trap = disable;

    sdk_rc = sx_api_acl_global_attributes_set(sx_api_handle_s, SX_ACCESS_CMD_SET, global_attributes);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to set acl global attributes.\n");
        goto out;
    }

out:
    return err;
}

static uint32_t __wjh_packet_info_list_process(wjh_user_channel_record_t *user_channel_p,
                                               const sx_packet_info_t    *packet_info_list_p,
                                               const uint32_t             packet_info_list_size,
                                               boolean_t                  acquire_bind_enable_lock)
{
    wjh_status_t                        err = WJH_STATUS_SUCCESS;
    uint32_t                            i = 0;
    wjh_trap_id_attr_t                 *trap_id_attr_p = NULL;
    wjh_drop_reason_group_record_t     *group_items[WJH_DROP_REASON_GROUP_MAX_E + 1];
    wjh_drop_reason_group_e             drop_reason_group;
    boolean_t                           drop_reason_group_enabled[WJH_DROP_REASON_GROUP_MAX_E + 1];
    uint32_t                            received_packets = 0;
    cl_plock_t                         *db_rw_lock = wjh_db_get_rwlock();
    wjh_user_channel_timestamp_source_e timestamp_source = user_channel_p->timestamp_source;

    if (acquire_bind_enable_lock) {
        cl_plock_acquire(&wjh_bind_enable_rwlock_g);
    }

    for (drop_reason_group = WJH_DROP_REASON_GROUP_MIN_E;
         drop_reason_group <= WJH_DROP_REASON_GROUP_MAX_E;
         ++drop_reason_group) {
        if (raw_info_buffers_s[drop_reason_group].raw_info_buf != NULL) {
            wjh_db_drop_reason_group_get(drop_reason_group, &group_items[drop_reason_group]);
            drop_reason_group_enabled[drop_reason_group] = (user_channel_p->bound[drop_reason_group] &&
                                                            (group_items[drop_reason_group]->enabled_severity_bits !=
                                                             0));
            if (drop_reason_group_enabled[drop_reason_group]) {
                raw_info_buffers_s[drop_reason_group].raw_info_count = 0;
            }
        } else {
            drop_reason_group_enabled[drop_reason_group] = FALSE;
        }
    }

    cl_plock_acquire(db_rw_lock);

    for (i = 0; i < packet_info_list_size; ++i) {
        wjh_db_trap_id_attr_get(packet_info_list_p[i].receive_info.trap_id, &trap_id_attr_p);
        if (trap_id_attr_p->drop_reason == NULL) {
            /* This is not a trap ID registered by WJH library, ignore it. */
            continue;
        }

        if ((!drop_reason_group_enabled[trap_id_attr_p->drop_reason_group]) ||
            (packet_info_list_p[i].receive_info.source_log_port == SX_INVALID_PORT)) {
            continue;
        }

        switch (trap_id_attr_p->drop_reason_group) {
        case WJH_DROP_REASON_GROUP_L2_E:
            FILL_COMMON_PART_OF_RAW_INFO(wjh_L2_drop_raw_info_t,
                                         WJH_DROP_REASON_GROUP_L2_E,
                                         &packet_info_list_p[i],
                                         trap_id_attr_p);
            break;

        case WJH_DROP_REASON_GROUP_ROUTER_E:
            FILL_COMMON_PART_OF_RAW_INFO(wjh_router_drop_raw_info_t,
                                         WJH_DROP_REASON_GROUP_ROUTER_E,
                                         &packet_info_list_p[i],
                                         trap_id_attr_p);
            break;

        case WJH_DROP_REASON_GROUP_TUNNEL_E:
            FILL_COMMON_PART_OF_RAW_INFO(wjh_tunnel_drop_raw_info_t,
                                         WJH_DROP_REASON_GROUP_TUNNEL_E,
                                         &packet_info_list_p[i],
                                         trap_id_attr_p);
            break;

        case WJH_DROP_REASON_GROUP_ACL_E:
            __wjh_acl_raw_info_fill(&packet_info_list_p[i]);
            break;

        case WJH_DROP_REASON_GROUP_BUFFER_E:
            /* coverity[lock_order] */
            __wjh_buffer_raw_info_fill(&packet_info_list_p[i], timestamp_source);
            break;

        case WJH_DROP_REASON_GROUP_ROCE_E:
            __wjh_roce_raw_info_fill(&packet_info_list_p[i], trap_id_attr_p);
            break;

        default:
            break;
        }
    }

    for (drop_reason_group = WJH_DROP_REASON_GROUP_MIN_E;
         drop_reason_group <= WJH_DROP_REASON_GROUP_MAX_E;
         ++drop_reason_group) {
        if ((raw_info_buffers_s[drop_reason_group].raw_info_buf == NULL) ||
            (raw_info_buffers_s[drop_reason_group].raw_info_count == 0) ||
            (!drop_reason_group_enabled[drop_reason_group])) {
            continue;
        } else {
            received_packets += raw_info_buffers_s[drop_reason_group].raw_info_count;
        }

        switch (drop_reason_group) {
        case WJH_DROP_REASON_GROUP_L2_E:
            err = group_items[drop_reason_group]->callbacks.raw_cb.L2(
                (wjh_L2_drop_raw_info_t*)(raw_info_buffers_s[drop_reason_group].raw_info_buf),
                &(raw_info_buffers_s[drop_reason_group].raw_info_count));
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to execute wjh_L2_drop_raw_cb callback.\n");
            }
            break;

        case WJH_DROP_REASON_GROUP_ROUTER_E:
            err = group_items[drop_reason_group]->callbacks.raw_cb.router(
                (wjh_router_drop_raw_info_t*)(raw_info_buffers_s[drop_reason_group].raw_info_buf),
                &(raw_info_buffers_s[drop_reason_group].raw_info_count));
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to execute wjh_router_drop_raw_cb callback.\n");
            }
            break;


        case WJH_DROP_REASON_GROUP_TUNNEL_E:
            err = group_items[drop_reason_group]->callbacks.raw_cb.tunnel(
                (wjh_tunnel_drop_raw_info_t*)(raw_info_buffers_s[drop_reason_group].raw_info_buf),
                &(raw_info_buffers_s[drop_reason_group].raw_info_count));
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to execute wjh_tunnel_drop_raw_cb callback.\n");
            }
            break;

        case WJH_DROP_REASON_GROUP_BUFFER_E:
            err = group_items[drop_reason_group]->callbacks.raw_cb.buffer(
                (wjh_buffer_drop_raw_info_t*)(raw_info_buffers_s[drop_reason_group].raw_info_buf),
                &(raw_info_buffers_s[drop_reason_group].raw_info_count));
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to execute wjh_buffer_drop_raw_cb callback.\n");
            }
            break;

        case WJH_DROP_REASON_GROUP_ACL_E:
            err = group_items[drop_reason_group]->callbacks.raw_cb.acl(
                (wjh_acl_drop_raw_info_t*)(raw_info_buffers_s[drop_reason_group].raw_info_buf),
                &(raw_info_buffers_s[drop_reason_group].raw_info_count));
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to execute wjh_acl_drop_raw_cb callback.\n");
            }
            __wjh_acl_raw_info_list_free();
            break;

        case WJH_DROP_REASON_GROUP_ROCE_E:
            err = group_items[drop_reason_group]->callbacks.raw_cb.roce(
                (wjh_roce_drop_raw_info_t*)(raw_info_buffers_s[drop_reason_group].raw_info_buf),
                &(raw_info_buffers_s[drop_reason_group].raw_info_count));
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to execute wjh_buffer_drop_raw_cb callback.\n");
            }
            break;

        default:
            break;
        }
    }

    cl_plock_release(db_rw_lock);
    if (acquire_bind_enable_lock) {
        cl_plock_release(&wjh_bind_enable_rwlock_g);
    }

    return received_packets;
}

static wjh_status_t __wjh_non_l1_cyclic_channel_read(wjh_user_channel_record_t *user_channel_p,
                                                     void                      *buf_p,
                                                     uint32_t                  *packet_info_list_size_p)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    sx_status_t       sdk_rc = SX_STATUS_SUCCESS;
    uint32_t          packet_info_list_size = 0;
    uint32_t          i = 0;
    sx_packet_info_t *packet_info_list_p = (sx_packet_info_t*)buf_p;

    /* Get the total count of packets from the channel */
    packet_info_list_size = 0;
    sdk_rc = sx_lib_host_ifc_recv_list(&user_channel_p->fd, NULL, &packet_info_list_size);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("sx_lib_host_ifc_recv_list failed, error: %s.\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (packet_info_list_size == 0) {
        goto out;
    }

    /* Should not happen, sanity check */
    if (packet_info_list_size > READ_MULTI_BUFFS_MAX) {
        packet_info_list_size = READ_MULTI_BUFFS_MAX;
    }

    for (i = 0; i < packet_info_list_size; ++i) {
        packet_info_list_p[i].packet_size = WJH_RECEIVED_PACKET_SIZE;
    }

    sdk_rc = sx_lib_host_ifc_recv_list(&user_channel_p->fd, packet_info_list_p, &packet_info_list_size);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("sx_lib_host_ifc_recv_list failed, error: %s.\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    *packet_info_list_size_p = packet_info_list_size;

out:
    return err;
}

static wjh_status_t __wjh_l1_cyclic_channel_process(wjh_user_channel_record_t *user_channel_p)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_e         drop_reason_group = WJH_DROP_REASON_GROUP_L1_E;
    wjh_drop_reason_group_record_t *group_item_p = NULL;
    uint32_t                        cyclic_cnt = 0;
    uint32_t                        agg_cnt = 0;

    cl_plock_acquire(&wjh_bind_enable_rwlock_g);

    wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);
    if ((!user_channel_p->bound[drop_reason_group]) || (group_item_p->enabled_severity_bits == 0)) {
        goto out;
    }

    err = __wjh_l1_data_read(user_channel_p, &cyclic_cnt, &agg_cnt, FALSE, WJH_AGGREGATION_READ_MODE_READ_CLEAR);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_l1_data_read failed, err: %d\n", err);
        goto out;
    }

    err = __wjh_l1_exec_callback(user_channel_p->channel_type, cyclic_cnt, agg_cnt, FALSE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_l1_exec_callback failed, err: %d\n", err);
        goto out;
    }

out:
    cl_plock_release(&wjh_bind_enable_rwlock_g);
    return err;
}

static wjh_status_t __wjh_cyclic_channel_process(wjh_user_channel_record_t *user_channel_p,
                                                 void                      *buf_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint32_t     packet_info_list_size = 0;
    uint32_t     received_packets = 0;

    err = __wjh_l1_cyclic_channel_process(user_channel_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_l1_cyclic_channel_process failed, err: %d\n", err);
        goto out;
    }

    err = __wjh_non_l1_cyclic_channel_read(user_channel_p, buf_p, &packet_info_list_size);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_non_l1_cyclic_channel_read failed, err: %d\n", err);
        goto out;
    }

    if (packet_info_list_size > 0) {
        received_packets = __wjh_packet_info_list_process(user_channel_p,
                                                          (sx_packet_info_t*)buf_p,
                                                          packet_info_list_size,
                                                          TRUE);
        if (received_packets > 0) {
            /* Update the receive packets counter */
            user_channel_p->received_packets += received_packets;
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_taildrop_channel_process(wjh_user_channel_record_t *user_channel_p)
{
    wjh_status_t     err = WJH_STATUS_SUCCESS;
    sx_status_t      sdk_rc = SX_STATUS_SUCCESS;
    uint8_t          buffer[WJH_RECEIVED_PACKET_SIZE];
    sx_packet_info_t packet_info;
    uint32_t         received_packets = 0;

    packet_info.packet_p = (void*)buffer;
    packet_info.packet_size = WJH_RECEIVED_PACKET_SIZE;

    sdk_rc = sx_lib_host_ifc_recv(&user_channel_p->fd, packet_info.packet_p,
                                  &packet_info.packet_size, &packet_info.receive_info);
    if (SX_CHECK_FAIL(sdk_rc)) {
        if (errno != EAGAIN) {
            WJH_LOG_ERR("sx_lib_host_ifc_recv failed, error: %s.\n", sx_status_str(sdk_rc));
        }
        goto out;
    }

    received_packets = __wjh_packet_info_list_process(user_channel_p, &packet_info, 1, TRUE);
    if (received_packets > 0) {
        /* Update the receive packets counter */
        user_channel_p->received_packets += received_packets;
    }

out:
    return err;
}

static wjh_status_t __wjh_prepare_l1_port_down_reason(wjh_L1_drop_aggregate_data_t *data_p,
                                                      const sx_port_phy_stat_t     *phy_stat_p,
                                                      uint8_t                       is_port_up)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    uint32_t                reason_num = 0;
    uint32_t                reason_str_len = 0;
    const char             *port_down_reason_str_arr[WJH_L1_PORT_DOWN_REASON_NUM];
    uint32_t                port_down_reason_str_len_arr[WJH_L1_PORT_DOWN_REASON_NUM];
    uint32_t                description_str_len = 0;
    const char             *description_str_arr[WJH_L1_PORT_DOWN_REASON_NUM];
    uint32_t                description_str_len_arr[WJH_L1_PORT_DOWN_REASON_NUM];
    uint32_t                i = 0;
    boolean_t               first_reason_str = TRUE;
    uint32_t                index = 0;
    wjh_drop_reason_item_t *l1_drop_reason_item = NULL;
    char                   *port_down_reason = NULL;
    char                   *description = NULL;

    if (is_port_up) {
        err = wjh_str_dup(&port_down_reason, WJH_DB_NA_STR);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_str_dup failed, err: %d\n", err);
            goto out;
        }
        err = wjh_str_dup(&description, WJH_DB_NA_STR);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_str_dup failed, err: %d\n", err);
            goto out;
        }

        data_p->port_down_reason = port_down_reason;
        data_p->description = description;
        goto out;
    }

    for (i = 0; i < WJH_L1_PORT_DOWN_REASON_NUM; ++i) {
        port_down_reason_str_arr[i] = NULL;
        port_down_reason_str_len_arr[i] = 0;
        description_str_arr[i] = NULL;
        description_str_len_arr[i] = 0;
    }

    PROCESS_PORT_DOWN_REASON_DESCRIPTION(port_admin_down, WJH_L1_PORT_DOWN_REASON_ID_PORT_ADMIN_DOWN);
    PROCESS_PORT_DOWN_REASON_DESCRIPTION(auto_negotiation_failure,
                                         WJH_L1_PORT_DOWN_REASON_ID_AUTO_NEGOTIATION_FAILURE);
    PROCESS_PORT_DOWN_REASON_DESCRIPTION(logical_mismatch_with_peer_link,
                                         WJH_L1_PORT_DOWN_REASON_ID_LOGICAL_MISMATCH_WITH_PEER_LINK);
    PROCESS_PORT_DOWN_REASON_DESCRIPTION(link_training_failure, WJH_L1_PORT_DOWN_REASON_ID_LINK_TRAINING_FAILURE);
    PROCESS_PORT_DOWN_REASON_DESCRIPTION(peer_is_sending_remote_faults,
                                         WJH_L1_PORT_DOWN_REASON_ID_PEER_IS_SENDING_REMOTE_FAULTS);
    PROCESS_PORT_DOWN_REASON_DESCRIPTION(bad_signal_integrity, WJH_L1_PORT_DOWN_REASON_ID_BAD_SIGNAL_INTEGRITY);
    PROCESS_PORT_DOWN_REASON_DESCRIPTION(cable_transceiver_is_not_supported,
                                         WJH_L1_PORT_DOWN_REASON_ID_CABLE_TRANSCEIVER_IS_NOT_SUPPORTED);
    PROCESS_PORT_DOWN_REASON_DESCRIPTION(cable_transceiver_is_unplugged,
                                         WJH_L1_PORT_DOWN_REASON_ID_CABLE_TRANSCEIVER_IS_UNPLUGGED);
    PROCESS_PORT_DOWN_REASON_DESCRIPTION(calibration_failure, WJH_L1_PORT_DOWN_REASON_ID_CALIBRATION_FAILURE);
    PROCESS_PORT_DOWN_REASON_DESCRIPTION(cable_transceiver_bad_status,
                                         WJH_L1_PORT_DOWN_REASON_ID_CABLE_TRANSCEIVER_BAD_STATUS);

    if (reason_num == 0) {
        i = WJH_L1_PORT_DOWN_REASON_INDEX_MIN +
            (WJH_L1_PORT_DOWN_REASON_ID_OTHER_REASON - WJH_L1_PORT_DOWN_REASON_ID_MIN);
        wjh_db_get_drop_reason_item(i, &l1_drop_reason_item);
        err = wjh_str_dup(&port_down_reason, l1_drop_reason_item->reason);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_str_dup failed, err: %d\n", err);
            goto out;
        }
        err = wjh_str_dup(&description, l1_drop_reason_item->description);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_str_dup failed, err: %d\n", err);
            goto out;
        }

        data_p->port_down_reason = port_down_reason;
        data_p->description = description;
    } else {
        /* The final port down reason string contains N reason strings and (N-1) separators */
        port_down_reason = (char*)cl_malloc(reason_str_len + (reason_num - 1) + 1);
        if (port_down_reason == NULL) {
            WJH_LOG_ERR("Failed to allocate memory for port down reason string\n");
            err = WJH_STATUS_NO_MEMORY;
            goto out;
        }

        description = (char*)cl_malloc(description_str_len + (reason_num - 1) + 1);
        if (description == NULL) {
            WJH_LOG_ERR("Failed to allocate memory for port down description string\n");
            err = WJH_STATUS_NO_MEMORY;
            goto out;
        }

        data_p->port_down_reason = port_down_reason;
        data_p->description = description;
        COPY_PORT_DOWN_REASON_DESCRIPTION(port_down_reason, port_down_reason_str_arr, port_down_reason_str_len_arr);
        COPY_PORT_DOWN_REASON_DESCRIPTION(description, description_str_arr, description_str_len_arr);
    }

out:
    if (WJH_CHECK_FAIL(err)) {
        if (port_down_reason != NULL) {
            cl_free(port_down_reason);
        }
        if (description != NULL) {
            cl_free(description);
        }
    }
    return err;
}

static boolean_t __wjh_is_l1_data_different_from_last_polling(sx_port_log_id_t                     log_port,
                                                              uint64_t                             state_change_count,
                                                              uint64_t                             crc_error_count,
                                                              uint64_t                             symbol_error_count,
                                                              wjh_l1_aggregation_key_data_cache_t *l1_cache_p,
                                                              int64_t                             *index_p)
{
    uint32_t i = 0;

    *index_p = -1;

    if (l1_cache_p->count == 0) {
        return TRUE;
    }

    for (i = 0; i < l1_cache_p->count; i++) {
        if (l1_cache_p->key[i].ingress_port != log_port) {
            continue;
        }

        *index_p = i;
        if (WJH_IS_L1_COUNTER_CHANGED(l1_cache_p->data[i].state_change_count, state_change_count) ||
            WJH_IS_L1_COUNTER_CHANGED(l1_cache_p->data[i].crc_error_count, crc_error_count) ||
            WJH_IS_L1_COUNTER_CHANGED(l1_cache_p->data[i].symbol_error_count, symbol_error_count)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    return TRUE;
}

wjh_status_t __wjh_get_sx_port_from_wjh_port(wjh_port_log_id_t wjh_port, sx_port_log_id_t *sx_port_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    WJH_CHECK_NULL_PTR(sx_port_p, sx_port_p);

    *sx_port_p = wjh_port;

out:
    return err;
}

wjh_status_t __wjh_get_wjh_port_from_sx_port(sx_port_log_id_t sx_port, wjh_port_log_id_t *wjh_port_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    WJH_CHECK_NULL_PTR(wjh_port_p, wjh_port_p);

    *wjh_port_p = sx_port;

out:
    return err;
}

static void __wjh_l1_swap_cache(wjh_l1_aggregation_key_data_cache_t **cache_1_pp,
                                wjh_l1_aggregation_key_data_cache_t **cache_2_pp)
{
    wjh_l1_aggregation_key_data_cache_t *tmp_cache_p = *cache_1_pp;

    *cache_1_pp = *cache_2_pp;
    *cache_2_pp = tmp_cache_p;
}


static wjh_status_t __wjh_l1_data_read(wjh_user_channel_record_t  *channel_record_p,
                                       uint32_t                   *cyclic_cnt_p,
                                       uint32_t                   *agg_cnt_p,
                                       boolean_t                   is_pull_api,
                                       wjh_aggregation_read_mode_e agg_read_mode)
{
    wjh_status_t                  err = WJH_STATUS_SUCCESS;
    sx_status_t                   sdk_rc = SX_STATUS_SUCCESS;
    sx_port_attributes_t         *port_attributes_list_p = NULL;
    uint32_t                      port_cnt = 0;
    uint32_t                      i = 0;
    uint32_t                      j1 = 0;
    uint32_t                      j2 = 0;
    sx_port_phy_stat_t            phy_stat;
    sx_port_cntr_ieee_802_dot_3_t cntr_ieee_802_dot_3;
    sx_port_cntr_phy_layer_t      cntr_phy_layer;
    boolean_t                     locked = FALSE;
    cl_plock_t                   *db_rw_lock = wjh_db_get_rwlock();
    static struct timespec        last_regular_polling_ts;
    static struct timespec        last_manual_polling_ts;
    static struct timespec        this_polling_ts;
    static boolean_t              first_polling = TRUE;
    int                           ret = 0;
    int64_t                       index = -1;
    wjh_user_channel_type_e       channel_type = channel_record_p->channel_type;
    wjh_drop_reason_item_t       *drop_reason_item_p = NULL;

#ifdef WJH_EBPF_PRESENT
    wjh_db_filter_rule_record_t **rule_record_list_pp = NULL;
    uint32_t                      rules_num = 0;
    boolean_t                     rule_matched = FALSE;
    sx_port_log_id_t              phy_port_lag_mapping[MAX_PHYPORT_NUM + 1];
    sx_port_log_id_t              log_port = 0;
    uint16_t                      phy_port_id = 0;
#endif

    ret = clock_gettime(CLOCK_REALTIME, &this_polling_ts);
    if (ret < 0) {
        WJH_LOG_ERR("clock_gettime failed, err: %s\n", strerror(errno));
    }

    if (first_polling) {
        first_polling = FALSE;
        err = wjh_system_boot_time_get(&last_regular_polling_ts);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_system_boot_time_get failed, err: %d\n", err);
            if (ret == 0) {
                last_regular_polling_ts = this_polling_ts;
            }
        }
        last_manual_polling_ts = last_regular_polling_ts;
    }

#ifdef WJH_EBPF_PRESENT
    if (channel_record_p->filter_record_p) {
        rules_num = channel_record_p->filter_record_p->rules_num;
        rule_record_list_pp = cl_malloc(sizeof(wjh_db_filter_rule_record_t*) * rules_num);
        if (rule_record_list_pp == NULL) {
            err = WJH_STATUS_NO_MEMORY;
            WJH_LOG_ERR("Failed to allocate memory.\n");
            goto out;
        }

        wjh_db_filter_rule_record_list_get(channel_record_p->filter_record_p, rule_record_list_pp, &rules_num);

        err = __wjh_filter_l1_match_rules(rule_record_list_pp, rules_num, NULL, &rule_matched);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to match rules for l1.\n");
            goto out;
        }
        if (rule_matched) {
            goto out;
        }

        memset(phy_port_lag_mapping, 0, sizeof(sx_port_log_id_t) * (MAX_PHYPORT_NUM + 1));
        err = __prepare_port_lag_mapping(phy_port_lag_mapping);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to prepare port lag mapping.\n");
            goto out;
        }
    }
#endif

    sdk_rc = sx_api_port_device_get(sx_api_handle_s, 1, 0, NULL, &port_cnt);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("sx_api_port_device_get failed, err: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (port_cnt == 0) {
        goto out;
    }
    port_attributes_list_p = (sx_port_attributes_t*)cl_calloc(port_cnt, sizeof(sx_port_attributes_t));
    if (port_attributes_list_p == NULL) {
        WJH_LOG_ERR("Failed to allocate memory for port list.\n");
        err = WJH_STATUS_NO_MEMORY;
        goto out;
    }

    sdk_rc = sx_api_port_device_get(sx_api_handle_s, 1, 0, port_attributes_list_p, &port_cnt);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("sx_api_port_device_get failed, err: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    cl_plock_acquire(db_rw_lock);
    locked = TRUE;

    j1 = 0;
    j2 = 0;
    wjh_l1_cyclic_new_cache_s->count = 0;
    wjh_l1_agg_new_cache_s->count = 0;
    for (i = 0; i < port_cnt && j1 <= MAX_PHYPORT_NUM && j2 <= MAX_PHYPORT_NUM; ++i) {
        if (SX_PORT_TYPE_ID_GET(port_attributes_list_p[i].log_port) != SX_PORT_TYPE_NETWORK) {
            continue;
        }
#ifdef WJH_EBPF_PRESENT
        if (channel_record_p->filter_record_p) {
            log_port = port_attributes_list_p[i].log_port;
            phy_port_id = SX_PORT_PHY_ID_GET(log_port);
            if (phy_port_lag_mapping[phy_port_id] != 0) {
                log_port = phy_port_lag_mapping[phy_port_id];
            }

            err = __wjh_filter_l1_match_rules(rule_record_list_pp,
                                              rules_num,
                                              &log_port,
                                              &rule_matched);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to match rules for l1.\n");
                goto out;
            }
            if (rule_matched) {
                continue;
            }
        }
#endif

        memset(&phy_stat, 0, sizeof(phy_stat));
        sdk_rc = sx_api_port_phy_info_get(sx_api_handle_s,
                                          SX_ACCESS_CMD_READ,
                                          port_attributes_list_p[i].log_port,
                                          &phy_stat);
        if (SX_CHECK_FAIL(sdk_rc)) {
            if (sdk_rc == SX_STATUS_ENTRY_NOT_BOUND) {
                /* The port is not bound to a valid SWID, ignore it.*/
                continue;
            } else {
                WJH_LOG_ERR("sx_api_port_phy_info_get failed, err: %s\n", sx_status_str(sdk_rc));
                err = WJH_STATUS_ERROR;
                goto out;
            }
        }

        memset(&cntr_ieee_802_dot_3, 0, sizeof(cntr_ieee_802_dot_3));
        sdk_rc = sx_api_port_counter_ieee_802_dot_3_get(sx_api_handle_s, SX_ACCESS_CMD_READ,
                                                        port_attributes_list_p[i].log_port, &cntr_ieee_802_dot_3);
        if (SX_CHECK_FAIL(sdk_rc)) {
            WJH_LOG_ERR("sx_api_port_counter_ieee_802_dot_3_get failed, err: %s\n", sx_status_str(sdk_rc));
            err = WJH_STATUS_ERROR;
            goto out;
        }

        memset(&cntr_phy_layer, 0, sizeof(cntr_phy_layer));
        sdk_rc = sx_api_port_counter_phy_layer_get(sx_api_handle_s, SX_ACCESS_CMD_READ,
                                                   port_attributes_list_p[i].log_port, &cntr_phy_layer);

        if (SX_CHECK_FAIL(sdk_rc)) {
            WJH_LOG_ERR("sx_api_port_counter_phy_layer_get failed, err: %s\n", sx_status_str(sdk_rc));
            err = WJH_STATUS_ERROR;
            goto out;
        }

        WJH_FILL_L1_CACHE(wjh_l1_cyclic_new_cache_s);
        WJH_FILL_L1_CACHE(wjh_l1_agg_new_cache_s);

        if ((channel_type == WJH_USER_CHANNEL_CYCLIC_E) ||
            (channel_type == WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) {
            if (__wjh_is_l1_data_different_from_last_polling(port_attributes_list_p[i].log_port,
                                                             phy_stat.port_state_change_cnt,
                                                             cntr_ieee_802_dot_3.a_frame_check_sequence_errors,
                                                             cntr_phy_layer.symbol_errors, wjh_l1_cyclic_old_cache_s,
                                                             &index)) {
                wjh_l1_raw_info_s[j1].ingress_port = wjh_sdk_interface_info_get(port_attributes_list_p[i].log_port,
                                                                                port_attributes_list_p[i].log_port);
                wjh_l1_raw_info_s[j1].timestamp = this_polling_ts;
                /* For now we don't allow user to override the reason string and description string of the L1 general drop reason. */
                wjh_l1_raw_info_s[j1].reason.id = WJH_DROP_REASON_ID_L1_GENERAL_E;
                wjh_l1_raw_info_s[j1].reason.reason = wjh_l1_general_drop_reason_str;
                wjh_l1_raw_info_s[j1].reason.description = wjh_l1_general_drop_desc_str;
                wjh_l1_raw_info_s[j1].reason.severity = WJH_SEVERITY_WARNING_E;
                ++j1;
            }
        }

        if ((channel_type == WJH_USER_CHANNEL_AGGREGATE_E) ||
            (channel_type == WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) {
            if (__wjh_is_l1_data_different_from_last_polling(port_attributes_list_p[i].log_port,
                                                             phy_stat.port_state_change_cnt,
                                                             cntr_ieee_802_dot_3.a_frame_check_sequence_errors,
                                                             cntr_phy_layer.symbol_errors, wjh_l1_agg_old_cache_s,
                                                             &index)) {
                wjh_l1_agg_key_s[j2].ingress_port = wjh_sdk_interface_info_get(port_attributes_list_p[i].log_port,
                                                                               port_attributes_list_p[i].log_port);
                wjh_l1_agg_data_s[j2].is_port_up = (phy_stat.port_state == SX_PORT_OPER_STATUS_UP);
                if (index >= 0) {
                    if (phy_stat.port_state_change_cnt < wjh_l1_agg_old_cache_s->data[index].state_change_count) {
                        wjh_l1_agg_data_s[j2].state_change_count = phy_stat.port_state_change_cnt;
                    } else {
                        wjh_l1_agg_data_s[j2].state_change_count = phy_stat.port_state_change_cnt -
                                                                   wjh_l1_agg_old_cache_s->data[index].
                                                                   state_change_count;
                    }
                } else {
                    wjh_l1_agg_data_s[j2].state_change_count = phy_stat.port_state_change_cnt;
                }

                WJH_AGG_FILL_L1_DROP_REASON(wjh_l1_agg_data_s,
                                            port_state_change_reason,
                                            WJH_L1_DROP_REASON_ID_PORT_STATE_CHANGE,
                                            j2,
                                            state_change_count);

                err = __wjh_prepare_l1_port_down_reason(&wjh_l1_agg_data_s[j2],
                                                        &phy_stat,
                                                        wjh_l1_agg_data_s[j2].is_port_up);
                if (WJH_CHECK_FAIL(err)) {
                    WJH_LOG_ERR("__wjh_prepare_l1_port_down_reason failed, err: %d\n", err);
                    goto out;
                }

                if (index >= 0) {
                    if (cntr_ieee_802_dot_3.a_frame_check_sequence_errors <
                        wjh_l1_agg_old_cache_s->data[index].crc_error_count) {
                        wjh_l1_agg_data_s[j2].crc_error_count = cntr_ieee_802_dot_3.a_frame_check_sequence_errors;
                    } else {
                        wjh_l1_agg_data_s[j2].crc_error_count = cntr_ieee_802_dot_3.a_frame_check_sequence_errors -
                                                                wjh_l1_agg_old_cache_s->data[index].crc_error_count;
                    }
                    if (cntr_phy_layer.symbol_errors < wjh_l1_agg_old_cache_s->data[index].symbol_error_count) {
                        wjh_l1_agg_data_s[j2].symbol_error_count = cntr_phy_layer.symbol_errors;
                    } else {
                        wjh_l1_agg_data_s[j2].symbol_error_count = cntr_phy_layer.symbol_errors -
                                                                   wjh_l1_agg_old_cache_s->data[index].
                                                                   symbol_error_count;
                    }
                } else {
                    wjh_l1_agg_data_s[j2].crc_error_count = cntr_ieee_802_dot_3.a_frame_check_sequence_errors;
                    wjh_l1_agg_data_s[j2].symbol_error_count = cntr_phy_layer.symbol_errors;
                }

                WJH_AGG_FILL_L1_DROP_REASON(wjh_l1_agg_data_s, crc_error_reason, WJH_L1_DROP_REASON_ID_CRC_ERROR,
                                            j2, crc_error_count);
                WJH_AGG_FILL_L1_DROP_REASON(wjh_l1_agg_data_s, symbol_error_reason, WJH_L1_DROP_REASON_ID_SYMBOL_ERROR,
                                            j2, symbol_error_count);

                if (is_pull_api) {
                    wjh_l1_agg_data_s[j2].timestamp.first_timestamp = last_manual_polling_ts;
                } else {
                    wjh_l1_agg_data_s[j2].timestamp.first_timestamp = last_regular_polling_ts;
                }
                wjh_l1_agg_data_s[j2].timestamp.last_timestamp = this_polling_ts;
                ++j2;
            }
        }
    }

    cl_plock_release(db_rw_lock);
    locked = FALSE;

    if (((channel_type == WJH_USER_CHANNEL_CYCLIC_E) ||
         (channel_type == WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) &&
        (j1 > 0)) {
        __wjh_l1_swap_cache(&wjh_l1_cyclic_new_cache_s, &wjh_l1_cyclic_old_cache_s);
    }

    if (((channel_type == WJH_USER_CHANNEL_AGGREGATE_E) ||
         (channel_type == WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E))) {
        if ((is_pull_api ||
             (agg_read_mode == WJH_AGGREGATION_READ_MODE_READ_CLEAR)) &&
            (j2 > 0)) {
            __wjh_l1_swap_cache(&wjh_l1_agg_new_cache_s, &wjh_l1_agg_old_cache_s);
        }
        if (is_pull_api) {
            last_manual_polling_ts = this_polling_ts;
        } else {
            last_regular_polling_ts = this_polling_ts;
        }
    }

    *cyclic_cnt_p = j1;
    *agg_cnt_p = j2;

out:
    if (locked) {
        cl_plock_release(db_rw_lock);
    }

    if (port_attributes_list_p) {
        cl_free(port_attributes_list_p);
    }
#ifdef WJH_EBPF_PRESENT
    if (rule_record_list_pp) {
        CL_FREE_N_NULL(rule_record_list_pp);
    }
#endif
    if (WJH_CHECK_FAIL(err)) {
        if ((channel_type == WJH_USER_CHANNEL_AGGREGATE_E) ||
            (channel_type == WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) {
            for (i = 0; i <= MAX_PHYPORT_NUM; ++i) {
                if (wjh_l1_agg_data_s[i].port_down_reason != NULL) {
                    cl_free(wjh_l1_agg_data_s[i].port_down_reason);
                    wjh_l1_agg_data_s[i].port_down_reason = NULL;
                }
                if (wjh_l1_agg_data_s[i].description != NULL) {
                    cl_free(wjh_l1_agg_data_s[i].description);
                    wjh_l1_agg_data_s[i].description = NULL;
                }
            }
        }
    }

    return err;
}

static wjh_status_t __wjh_l1_exec_callback(wjh_user_channel_type_e channel_type,
                                           uint32_t                cyclic_cnt,
                                           uint32_t                agg_cnt,
                                           boolean_t               is_pull_api)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_drop_aggregate_attr_t       drop_attributes;
    wjh_drop_reason_group_record_t *group_item_p = NULL;
    uint32_t                        i = 0;

    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_L1_E, &group_item_p);

    if (((channel_type == WJH_USER_CHANNEL_CYCLIC_E) ||
         (channel_type == WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) &&
        (cyclic_cnt > 0)) {
        err = group_item_p->callbacks.raw_cb.L1(wjh_l1_raw_info_s, &cyclic_cnt);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("L1 raw callback failed, err: %d\n", err);
            goto out;
        }
    }

    if (((channel_type == WJH_USER_CHANNEL_AGGREGATE_E) ||
         (channel_type == WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) &&
        (agg_cnt > 0)) {
        memset(&drop_attributes, 0, sizeof(drop_attributes));
        if (is_pull_api) {
            drop_attributes.mode = WJH_USER_CHANNEL_MODE_PULL_E;
        } else {
            drop_attributes.mode = WJH_USER_CHANNEL_MODE_PUSH_E;
        }
        err = group_item_p->callbacks.aggregate_cb.L1(wjh_l1_agg_key_s, wjh_l1_agg_data_s, &agg_cnt, &drop_attributes);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("L1 aggregation callback failed, err: %d\n", err);
            goto out;
        }
    }

out:
    if ((channel_type == WJH_USER_CHANNEL_AGGREGATE_E) ||
        (channel_type == WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) {
        for (i = 0; i < agg_cnt; ++i) {
            cl_free(wjh_l1_agg_data_s[i].port_down_reason);
            wjh_l1_agg_data_s[i].port_down_reason = NULL;
            cl_free(wjh_l1_agg_data_s[i].description);
            wjh_l1_agg_data_s[i].description = NULL;
        }
    }

    return err;
}

static wjh_status_t __wjh_aggregation_channel_process(wjh_user_channel_record_t  *user_channel_p,
                                                      boolean_t                   is_pull_api,
                                                      wjh_aggregation_read_mode_e agg_read_mode)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_e         drop_reason_group;
    wjh_drop_reason_group_record_t *group_item_p = NULL;
    uint32_t                        cyclic_cnt = 0;
    uint32_t                        agg_cnt = 0;

#ifdef WJH_EBPF_PRESENT
    uint64_t received_packets = 0;
#endif

    cl_plock_acquire(&wjh_bind_enable_rwlock_g);
    for (drop_reason_group = WJH_DROP_REASON_GROUP_MIN_E;
         drop_reason_group <= WJH_DROP_REASON_GROUP_MAX_E;
         ++drop_reason_group) {
        wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);
        if ((!user_channel_p->bound[drop_reason_group]) || (group_item_p->enabled_severity_bits == 0)) {
            continue;
        }
        if (drop_reason_group == WJH_DROP_REASON_GROUP_L1_E) {
            err = __wjh_l1_data_read(user_channel_p, &cyclic_cnt, &agg_cnt, is_pull_api, agg_read_mode);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_l1_data_read failed, err: %d\n", err);
                goto out;
            }

            err = __wjh_l1_exec_callback(user_channel_p->channel_type, cyclic_cnt, agg_cnt, is_pull_api);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_l1_exec_callback failed, err: %d\n", err);
                goto out;
            }
        } else {
#ifdef WJH_EBPF_PRESENT
            err = __wjh_agg_read_ebpf_map(group_item_p, &received_packets, &agg_cnt,
                                          is_pull_api ? WJH_AGGREGATION_READ_MODE_READ_CLEAR : agg_read_mode);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_agg_read_ebpf_map failed, err: %d\n", err);
                goto out;
            }

            err = __wjh_aggregation_exec_callback(group_item_p, agg_cnt, is_pull_api);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_aggregation_exec_callback failed, err: %d\n", err);
                goto out;
            }
#endif
        }
    }

out:
    cl_plock_release(&wjh_bind_enable_rwlock_g);
#ifdef WJH_EBPF_PRESENT
    if (received_packets > 0) {
        user_channel_p->received_packets += received_packets;
    }
#endif
    return err;
}

static wjh_status_t __wjh_cyclic_and_agg_channel_process(wjh_user_channel_record_t  *user_channel_p,
                                                         void                       *buf_p,
                                                         boolean_t                   is_pull_api,
                                                         wjh_aggregation_read_mode_e agg_read_mode)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    uint32_t                        packet_info_list_size = 0;
    uint32_t                        received_packets = 0;
    uint32_t                        counts[WJH_DROP_REASON_GROUP_MAX_E + 1];
    wjh_drop_reason_group_e         drop_reason_group;
    wjh_drop_reason_group_record_t *group_item_p = NULL;
    wjh_drop_reason_group_record_t *l1_group_item_p = NULL;
    boolean_t                       l1_enabled = FALSE;
    uint32_t                        l1_cyclic_cnt = 0;
    uint32_t                        l1_agg_cnt = 0;

#ifdef WJH_EBPF_PRESENT
    uint64_t received_packets_agg = 0;
#endif

    cl_plock_acquire(&wjh_bind_enable_rwlock_g);

    memset(counts, 0, sizeof(counts));

    /* Read the L1 data. The reason that we handle L1 separately is that we want to minimize the delay between
     *  reading an RDQ and reading the corresponding eBPF maps so as to improve the correlation as much as possible. */
    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_L1_E, &l1_group_item_p);
    l1_enabled = (user_channel_p->bound[WJH_DROP_REASON_GROUP_L1_E]) && (l1_group_item_p->enabled_severity_bits != 0);
    if (l1_enabled) {
        err = __wjh_l1_data_read(user_channel_p, &l1_cyclic_cnt, &l1_agg_cnt, is_pull_api, agg_read_mode);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_l1_data_read failed, err: %d\n", err);
            goto out;
        }
    }

    /* Read the cyclic data */
    err = __wjh_non_l1_cyclic_channel_read(user_channel_p, buf_p, &packet_info_list_size);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_non_l1_cyclic_channel_read failed, err: %d\n", err);
        goto out;
    }

    /* Read the aggregation data */
    for (drop_reason_group = WJH_DROP_REASON_GROUP_MIN_E;
         drop_reason_group <= WJH_DROP_REASON_GROUP_MAX_E;
         ++drop_reason_group) {
        wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);
        if ((!user_channel_p->bound[drop_reason_group]) || (group_item_p->enabled_severity_bits == 0)) {
            continue;
        }
        if (drop_reason_group == WJH_DROP_REASON_GROUP_L1_E) {
            continue;
        } else {
#ifdef WJH_EBPF_PRESENT
            err = __wjh_agg_read_ebpf_map(group_item_p, &received_packets_agg, &counts[drop_reason_group],
                                          is_pull_api ? WJH_AGGREGATION_READ_MODE_READ_CLEAR : agg_read_mode);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_agg_read_ebpf_map failed, err: %d\n", err);
                goto out;
            }
#endif
        }
    }

    /* We first call the L1 cyclic callback, then the rest cyclic callbacks, after that we call
     * the L1 aggregation callback, then the rest aggregation callbacks. */
    if (l1_enabled) {
        err = __wjh_l1_exec_callback(WJH_USER_CHANNEL_CYCLIC_E, l1_cyclic_cnt, l1_agg_cnt, is_pull_api);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_l1_exec_callback failed, err: %d\n", err);
            goto out;
        }
    }

    if (packet_info_list_size > 0) {
        received_packets = __wjh_packet_info_list_process(user_channel_p,
                                                          (sx_packet_info_t*)buf_p,
                                                          packet_info_list_size,
                                                          FALSE);
    }

    if (l1_enabled) {
        err = __wjh_l1_exec_callback(WJH_USER_CHANNEL_AGGREGATE_E, l1_cyclic_cnt, l1_agg_cnt, is_pull_api);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_l1_exec_callback failed, err: %d\n", err);
            goto out;
        }
    }

    for (drop_reason_group = WJH_DROP_REASON_GROUP_MIN_E;
         drop_reason_group <= WJH_DROP_REASON_GROUP_MAX_E;
         ++drop_reason_group) {
        wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);
        if ((!user_channel_p->bound[drop_reason_group]) || (group_item_p->enabled_severity_bits == 0)) {
            continue;
        }
        if (drop_reason_group == WJH_DROP_REASON_GROUP_L1_E) {
            continue;
        } else {
#ifdef WJH_EBPF_PRESENT
            err = __wjh_aggregation_exec_callback(group_item_p, counts[drop_reason_group], is_pull_api);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_aggregation_exec_callback failed, err: %d\n", err);
                goto out;
            }
#endif
        }
    }

out:
    cl_plock_release(&wjh_bind_enable_rwlock_g);
    if (received_packets > 0) {
        user_channel_p->received_packets += received_packets;
    }
    return err;
}


static wjh_status_t __wjh_policer_destroy_sdk(sx_policer_id_t policer_id)
{
    sx_status_t  sdk_rc = SX_STATUS_SUCCESS;
    wjh_status_t err = WJH_STATUS_SUCCESS;

    sdk_rc = sx_api_policer_set(sx_api_handle_s, SX_ACCESS_CMD_DESTROY, NULL, &policer_id);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to destroy policer, error: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}

#ifdef WJH_EBPF_PRESENT
static wjh_status_t __wjh_aggregation_create_ebpf_prog_and_map(wjh_user_channel_record_t      *user_channel_p,
                                                               wjh_drop_reason_group_record_t *group_item_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint32_t     key_size = sizeof(wjh_agg_ebpf_key_t);
    char         ebpf_prog_path[PATH_MAX] = {0};
    const char  *ebpf_prog_name = NULL;
    int          ebpf_prog_fd = -1;
    const char  *ebpf_map_names[2] = {NULL, NULL};
    int          ebpf_map_fds[2] = {-1, -1};
    uint32_t     index = 0;
    uint32_t     trap_id = 0;
    uint32_t     aggregation_key_mode = (uint32_t)(wjh_init_params_g.aggregation_key_mode);

    if (group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) {
        trap_id = group_item_p->trap_ids[0].trap_id;
    }

    ebpf_prog_name = wjh_agg_drop_reason_group_ebpf_attr_s[group_item_p->drop_reason_group].ebpf_prog_name;

    err = wjh_ebpf_map_create(BPF_MAP_TYPE_HASH, key_size, sizeof(wjh_agg_ebpf_value_t),
                              group_item_p->attr.max_aggregation_entries_cnt,
                              &ebpf_map_fds[0]);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to create eBPF map, key_size (%u), value_size (%lu), max_entries_cnt (%u), err: %d\n",
                    key_size, sizeof(wjh_agg_ebpf_value_t), group_item_p->attr.max_aggregation_entries_cnt, err);
        goto out;
    }
    ebpf_map_names[0] = wjh_agg_drop_reason_group_ebpf_attr_s[group_item_p->drop_reason_group].ebpf_map_name;

    /* For all drop reason groups, we used a shared communication eBPF map to notify the eBPF programs about the
     * aggregation key mode. This map also stores the trap ID used by buffer drop reason group. The third entry
     * stores the timestamp source needed by buffer drop reason group.
     */
    if (wjh_agg_comm_map_refcnt == 0) {
        err = wjh_ebpf_map_create(BPF_MAP_TYPE_ARRAY, sizeof(uint32_t), sizeof(uint32_t), 3, &wjh_agg_comm_map_fd);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_map_create failed, err: %d\n", err);
            goto close_first_map;
        }
    }
    ebpf_map_fds[1] = wjh_agg_comm_map_fd;
    ebpf_map_names[1] = wjh_agg_comm_map_name;
    ++wjh_agg_comm_map_refcnt;

    err = wjh_ebpf_map_elem_update(ebpf_map_fds[1], &index, &aggregation_key_mode, BPF_ANY);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh_ebpf_map_elem_update failed, err: %d\n", err);
        goto close_second_map;
    }

    if (group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) {
        index = 1;
        err = wjh_ebpf_map_elem_update(ebpf_map_fds[1], &index, &trap_id, BPF_ANY);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_map_elem_update failed, err: %d\n", err);
            goto close_second_map;
        }

        index = 2;
        err = wjh_ebpf_map_elem_update(ebpf_map_fds[1], &index, &(user_channel_p->timestamp_source), BPF_ANY);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_map_elem_update failed, err: %d\n", err);
            goto close_second_map;
        }
    }

    if ((strlen(wjh_ebpf_prog_dir_g) + strlen(ebpf_prog_name) + 1) > PATH_MAX) {
        WJH_LOG_ERR("The eBPF program file path is too long\n");
        err = WJH_STATUS_ERROR;
        goto close_second_map;
    }
    snprintf(ebpf_prog_path, sizeof(ebpf_prog_path), "%s%s", wjh_ebpf_prog_dir_g, ebpf_prog_name);
    err = wjh_ebpf_program_load(ebpf_prog_path,
                                BPF_PROG_TYPE_SCHED_CLS,
                                wjh_agg_drop_reason_group_ebpf_attr_s[group_item_p->drop_reason_group].ebpf_prog_section_name,
                                ebpf_map_names,
                                ebpf_map_fds,
                                2,
                                &ebpf_prog_fd);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh_ebpf_program_load failed, err = %d\n", err);
        goto close_second_map;
    }

    group_item_p->aggregation_ebpf_map_fd = ebpf_map_fds[0];
    group_item_p->aggregation_ebpf_prog_fd = ebpf_prog_fd;
    goto out;

close_second_map:
    if (wjh_agg_comm_map_refcnt > 0) {
        --wjh_agg_comm_map_refcnt;
        if (wjh_agg_comm_map_refcnt == 0) {
            close(wjh_agg_comm_map_fd);
            wjh_agg_comm_map_fd = -1;
        }
    }

close_first_map:
    if (ebpf_map_fds[0] >= 0) {
        close(ebpf_map_fds[0]);
    }

out:
    return err;
}

static wjh_status_t __wjh_aggregation_destroy_ebpf_prog_and_map(wjh_drop_reason_group_record_t *group_item_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (group_item_p->aggregation_ebpf_prog_fd >= 0) {
        close(group_item_p->aggregation_ebpf_prog_fd);
        group_item_p->aggregation_ebpf_prog_fd = -1;
    }

    if (wjh_agg_comm_map_refcnt > 0) {
        --wjh_agg_comm_map_refcnt;
        if (wjh_agg_comm_map_refcnt == 0) {
            close(wjh_agg_comm_map_fd);
            wjh_agg_comm_map_fd = -1;
        }
    }

    if (group_item_p->aggregation_ebpf_map_fd >= 0) {
        close(group_item_p->aggregation_ebpf_map_fd);
        group_item_p->aggregation_ebpf_map_fd = -1;
    }

    return err;
}

static boolean_t __wjh_is_any_drop_reason_enabled(wjh_drop_reason_group_record_t *group_item_p)
{
    wjh_trap_id_attr_t *trap_id_attr_p = NULL;
    uint32_t            i = 0;

    if ((group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) ||
        (group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_ROCE_E)) {
        if (group_item_p->enabled_drop_reason_bits > 0) {
            return TRUE;
        }
    } else {
        for (i = 0; i < group_item_p->trap_id_num; ++i) {
            wjh_db_trap_id_attr_get(group_item_p->trap_ids[i].trap_id, &trap_id_attr_p);
            if (trap_id_attr_p->drop_reason->enabled) {
                return TRUE;
            }
        }
    }

    return FALSE;
}

static void __wjh_swap_key_and_next_key(void **key_pp, void *next_key_pp)
{
    void *tmp_key_p = *(char**)key_pp;

    *(char**)key_pp = *(char**)next_key_pp;
    *(char**)next_key_pp = tmp_key_p;
}

static wjh_status_t __wjh_aggregation_read_ebpf_entry(int                             map_fd,
                                                      void                           *key_p,
                                                      wjh_agg_ebpf_value_t           *value_p,
                                                      uint32_t                       *index_p,
                                                      wjh_drop_reason_group_record_t *group_item_p,
                                                      uint64_t                       *received_packets_p,
                                                      wjh_aggregation_read_mode_e     agg_read_mode)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    boolean_t    key_deleted = FALSE;

    err = wjh_ebpf_map_elem_lookup(map_fd, key_p, value_p);
    if (WJH_CHECK_FAIL(err)) {
        if (err == WJH_STATUS_ENTRY_NOT_FOUND) {
            err = WJH_STATUS_SUCCESS;
        } else {
            WJH_LOG_ERR("wjh_ebpf_map_elem_lookup failed, err: %d\n", err);
        }
        goto out;
    }
    if (agg_read_mode == WJH_AGGREGATION_READ_MODE_READ_CLEAR) {
        err = wjh_ebpf_map_elem_delete(map_fd, key_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_map_elem_delete failed, err: %d\n", err);
            goto out;
        }
        key_deleted = TRUE;
    }
    err = __wjh_aggregation_fill_buffer(group_item_p, key_p, value_p, *index_p);
    if (WJH_CHECK_FAIL(err)) {
        if (err == WJH_STATUS_ENTRY_NOT_FOUND) {
            if (key_deleted == FALSE) {
                err = wjh_ebpf_map_elem_delete(map_fd, key_p);
                if (WJH_CHECK_FAIL(err)) {
                    WJH_LOG_ERR("wjh_ebpf_map_elem_delete failed, err: %d\n", err);
                    goto out;
                }
            }
            err = WJH_STATUS_SUCCESS;
        } else {
            WJH_LOG_ERR("__wjh_aggregation_fill_buffer failed, err: %d\n", err);
        }
        goto out;
    }

    *received_packets_p = (*received_packets_p) + value_p->count;
    *index_p = (*index_p) + 1;

out:
    return err;
}

static wjh_status_t __wjh_agg_read_ebpf_map(wjh_drop_reason_group_record_t *group_item_p,
                                            uint64_t                       *received_packets_p,
                                            uint32_t                       *cnt_p,
                                            wjh_aggregation_read_mode_e     agg_read_mode)
{
    wjh_status_t         err = WJH_STATUS_SUCCESS;
    void                *key_p = NULL;
    wjh_agg_ebpf_value_t value;
    void                *next_key_p = NULL;
    wjh_agg_ebpf_key_t   key;
    wjh_agg_ebpf_key_t   non_exist_key;
    int                  map_fd = group_item_p->aggregation_ebpf_map_fd;
    uint32_t             index = 0;
    uint64_t             received_packets = 0;
    uint32_t             max_entries_cnt = group_item_p->attr.max_aggregation_entries_cnt;
    boolean_t            first_lookup = TRUE;


    memset(&value, 0, sizeof(value));
    memset(&key, 0, sizeof(key));
    memset(&non_exist_key, 0, sizeof(non_exist_key));
    non_exist_key.reason_id = 0xFFFFFFFF;

    key_p = &non_exist_key;
    next_key_p = &key;

    while (index < max_entries_cnt) {
        err = wjh_ebpf_map_next_key_get(map_fd, key_p, next_key_p);
        if (WJH_CHECK_FAIL(err)) {
            if (err == WJH_STATUS_ENTRY_NOT_FOUND) {
                if (first_lookup) {
                    err = WJH_STATUS_SUCCESS;
                } else {
                    err = __wjh_aggregation_read_ebpf_entry(map_fd,
                                                            key_p,
                                                            &value,
                                                            &index,
                                                            group_item_p,
                                                            &received_packets,
                                                            agg_read_mode);
                    if (WJH_CHECK_FAIL(err)) {
                        WJH_LOG_ERR("__wjh_aggregation_read_ebpf_entry failed, err: %d\n", err);
                        goto out;
                    }
                }
                break;
            } else {
                WJH_LOG_ERR("wjh_ebpf_map_next_key_get failed, err: %d\n", err);
                goto out;
            }
        }

        if (first_lookup) {
            __wjh_swap_key_and_next_key(&key_p, &next_key_p);
            first_lookup = FALSE;
            continue;
        }

        err = __wjh_aggregation_read_ebpf_entry(map_fd,
                                                key_p,
                                                &value,
                                                &index,
                                                group_item_p,
                                                &received_packets,
                                                agg_read_mode);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_aggregation_read_ebpf_entry failed, err: %d\n", err);
            goto out;
        }

        __wjh_swap_key_and_next_key(&key_p, &next_key_p);
    }

    *received_packets_p = received_packets;
    *cnt_p = index;

out:
    return err;
}

static wjh_status_t __wjh_aggregation_create_buffer(wjh_drop_reason_group_record_t *group_item_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint32_t     key_size = 0;
    uint32_t     data_size = 0;
    void        *key_buffer = NULL;
    void        *data_buffer = NULL;
    void        *sip_buffer = NULL;
    void        *dip_buffer = NULL;
    uint32_t     ebpf_map_size = group_item_p->attr.max_aggregation_entries_cnt;

    switch (group_item_p->drop_reason_group) {
    case WJH_DROP_REASON_GROUP_BUFFER_E:
        key_size = sizeof(wjh_buffer_drop_aggregate_key_t);
        data_size = sizeof(wjh_buffer_drop_aggregate_data_t);
        break;

    case WJH_DROP_REASON_GROUP_ACL_E:
        key_size = sizeof(wjh_acl_drop_aggregate_key_t);
        data_size = sizeof(wjh_acl_drop_aggregate_data_t);
        break;

    case WJH_DROP_REASON_GROUP_L2_E:
        key_size = sizeof(wjh_L2_drop_aggregate_key_t);
        data_size = sizeof(wjh_L2_drop_aggregate_data_t);
        break;

    case WJH_DROP_REASON_GROUP_ROUTER_E:
        key_size = sizeof(wjh_router_drop_aggregate_key_t);
        data_size = sizeof(wjh_router_drop_aggregate_data_t);
        break;

    case WJH_DROP_REASON_GROUP_TUNNEL_E:
        key_size = sizeof(wjh_tunnel_drop_aggregate_key_t);
        data_size = sizeof(wjh_tunnel_drop_aggregate_data_t);
        break;

    case WJH_DROP_REASON_GROUP_ROCE_E:
        key_size = sizeof(wjh_roce_drop_aggregate_key_t);
        data_size = sizeof(wjh_roce_drop_aggregate_data_t);
        break;

    default:
        WJH_LOG_ERR("Unsupported drop reason group (%u)\n", group_item_p->drop_reason_group);
        err = WJH_STATUS_UNSUPPORTED;
        goto out;
    }

    key_buffer = cl_malloc(key_size * ebpf_map_size);
    if (key_buffer == NULL) {
        WJH_LOG_ERR("Failed to allocate memory for aggregation key buffer of drop reason group (%u)\n",
                    group_item_p->drop_reason_group);
        err = WJH_STATUS_NO_MEMORY;
        goto out;
    }

    data_buffer = cl_malloc(data_size * ebpf_map_size);
    if (data_buffer == NULL) {
        WJH_LOG_ERR("Failed to allocate memory for aggregation data buffer of drop reason group (%u)\n",
                    group_item_p->drop_reason_group);
        err = WJH_STATUS_NO_MEMORY;
        goto free_key_buffer;
    }

    sip_buffer = cl_malloc(INET6_ADDRSTRLEN * ebpf_map_size);
    if (sip_buffer == NULL) {
        WJH_LOG_ERR("Failed to allocate memory for aggregation key SIP buffer of drop reason group (%u)\n",
                    group_item_p->drop_reason_group);
        err = WJH_STATUS_NO_MEMORY;
        goto free_data_buffer;
    }

    dip_buffer = cl_malloc(INET6_ADDRSTRLEN * ebpf_map_size);
    if (dip_buffer == NULL) {
        WJH_LOG_ERR("Failed to allocate memory for aggregation key DIP buffer of drop reason group (%u)\n",
                    group_item_p->drop_reason_group);
        err = WJH_STATUS_NO_MEMORY;
        goto free_sip_buffer;
    }

    group_item_p->aggregation_key_buf = key_buffer;
    group_item_p->aggregation_data_buf = data_buffer;
    group_item_p->aggregation_key_sip_buf = sip_buffer;
    group_item_p->aggregation_key_dip_buf = dip_buffer;
    goto out;

free_sip_buffer:
    if (sip_buffer != NULL) {
        cl_free(sip_buffer);
    }

free_data_buffer:
    if (data_buffer != NULL) {
        cl_free(data_buffer);
    }

free_key_buffer:
    if (key_buffer != NULL) {
        cl_free(key_buffer);
    }

out:
    return err;
}

static void __wjh_aggregation_destroy_buffer(wjh_drop_reason_group_record_t *group_item_p)
{
    if (group_item_p->aggregation_key_buf != NULL) {
        cl_free(group_item_p->aggregation_key_buf);
        group_item_p->aggregation_key_buf = NULL;
    }

    if (group_item_p->aggregation_data_buf != NULL) {
        cl_free(group_item_p->aggregation_data_buf);
        group_item_p->aggregation_data_buf = NULL;
    }

    if (group_item_p->aggregation_key_sip_buf != NULL) {
        cl_free(group_item_p->aggregation_key_sip_buf);
        group_item_p->aggregation_key_sip_buf = NULL;
    }

    if (group_item_p->aggregation_key_dip_buf != NULL) {
        cl_free(group_item_p->aggregation_key_dip_buf);
        group_item_p->aggregation_key_dip_buf = NULL;
    }
}

static void __wjh_aggregation_fill_timestamp(wjh_aggregate_timestamp_t *out, const wjh_agg_ebpf_value_t    *in)
{
    out->first_timestamp.tv_sec = in->first_timestamp.tv_sec;
    out->first_timestamp.tv_nsec = in->first_timestamp.tv_nsec;
    out->last_timestamp.tv_sec = in->last_timestamp.tv_sec;
    out->last_timestamp.tv_nsec = in->last_timestamp.tv_nsec;
}

static wjh_status_t __wjh_aggregation_fill_buffer(wjh_drop_reason_group_record_t *group_item_p,
                                                  void                           *key_p,
                                                  void                           *value_p,
                                                  uint32_t                        index)
{
    wjh_status_t                      err = WJH_STATUS_SUCCESS;
    wjh_buffer_drop_aggregate_key_t  *buffer_key_list_p = NULL;
    wjh_buffer_drop_aggregate_data_t *buffer_data_list_p = NULL;
    wjh_acl_drop_aggregate_key_t     *acl_key_list_p = NULL;
    wjh_acl_drop_aggregate_data_t    *acl_data_list_p = NULL;
    wjh_L2_drop_aggregate_key_t      *l2_key_list_p = NULL;
    wjh_L2_drop_aggregate_data_t     *l2_data_list_p = NULL;
    wjh_router_drop_aggregate_key_t  *router_key_list_p = NULL;
    wjh_router_drop_aggregate_data_t *router_data_list_p = NULL;
    wjh_tunnel_drop_aggregate_key_t  *tunnel_key_list_p = NULL;
    wjh_tunnel_drop_aggregate_data_t *tunnel_data_list_p = NULL;
    wjh_roce_drop_aggregate_key_t    *roce_key_list_p = NULL;
    wjh_roce_drop_aggregate_data_t   *roce_data_list_p = NULL;
    wjh_agg_ebpf_value_t             *ebpf_value_p = value_p;
    wjh_agg_ebpf_key_t               *ebpf_key_p = key_p;
    sx_acl_pkt_drop_attributes_t      acl_attr;
    wjh_drop_reason_id_t              reason_id = 0;
    wjh_acl_rule_id_t                 rule_id = 0;
    char                             *acl_name = NULL;
    char                             *rule = NULL;
    wjh_drop_reason_item_t           *drop_reason_item_p = NULL;
    wjh_aggregation_key_mode_e        agg_key_mode = wjh_init_params_g.aggregation_key_mode;
    boolean_t                         from_cqe = TRUE;
    wjh_buffer_drop_db_t             *buffer_drop_db_p = NULL;

    switch (group_item_p->drop_reason_group) {
    case WJH_DROP_REASON_GROUP_BUFFER_E:
        WJH_AGG_PREPARE_KEY_DATA(buffer_key_list_p, buffer_data_list_p);
        buffer_data_list_p[index].egress_data_valid = ebpf_value_p->egress_data_valid;
        if (ebpf_value_p->egress_data_valid) {
            buffer_data_list_p[index].egress_data.tc = ebpf_value_p->egress_data.tc;
            buffer_data_list_p[index].egress_data.latency_watermark = ebpf_value_p->egress_data.latency_watermark;
            buffer_data_list_p[index].egress_data.port_tc_watermark = ebpf_value_p->egress_data.port_tc_watermark;

            wjh_db_buffer_drop_get(&buffer_drop_db_p);

            from_cqe = (buffer_drop_db_p->recirculation_port == WJH_CPU_PORT_ID);
            err = __wjh_get_port_lag_log_id(ebpf_value_p->egress_data.egress_port, from_cqe,
                                            &buffer_data_list_p[index].egress_data.egress_port,
                                            &buffer_data_list_p[index].egress_data.is_egress_lag_member,
                                            &buffer_data_list_p[index].egress_data.egress_lag);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_get_port_lag_log_id failed, from_cqe: %d, egress_port: 0x%x, err: %d\n",
                            from_cqe, buffer_data_list_p[index].egress_data.egress_port, err);
                goto out;
            }
        }
        WJH_AGG_FILL_FIVE_TUPLES(buffer_key_list_p, ebpf_key_p);
        if (agg_key_mode == WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
            wjh_db_buffer_drop_get(&buffer_drop_db_p);
            from_cqe = (buffer_drop_db_p->recirculation_port == WJH_CPU_PORT_ID);
            WJH_AGG_FILL_PORT_VLAN_ETHER_TYPE(buffer_key_list_p, ebpf_key_p, from_cqe);
            WJH_AGG_FILL_DMAC_SMAC(buffer_key_list_p, ebpf_key_p);
        }
        if (ebpf_key_p->reason_id == 0) {
            buffer_key_list_p[index].reason.id = 0;
            buffer_key_list_p[index].reason.reason = wjh_buffer_drop_reason_str;
            buffer_key_list_p[index].reason.severity = WJH_SEVERITY_MIN_E;
            buffer_key_list_p[index].reason.description = wjh_buffer_drop_desc_str;
            buffer_key_list_p[index].reason.event_type = WJH_EVENT_NONE_E;
        } else {
            WJH_AGG_FILL_DROP_REASON(buffer_key_list_p, reason, ebpf_key_p->reason_id, index);
        }
        goto out;

    case WJH_DROP_REASON_GROUP_ACL_E:
        WJH_AGG_PREPARE_KEY_DATA(acl_key_list_p, acl_data_list_p);
        if (agg_key_mode == WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
            WJH_AGG_FILL_FIVE_TUPLES(acl_key_list_p, ebpf_key_p);
            WJH_AGG_FILL_PORT_VLAN_ETHER_TYPE(acl_key_list_p, ebpf_key_p, TRUE);
            WJH_AGG_FILL_DMAC_SMAC(acl_key_list_p, ebpf_key_p);
        }

        memset(&acl_attr, 0, sizeof(acl_attr));
        err = __wjh_acl_attributes_get(ebpf_key_p->reason_id,
                                       &acl_attr, &rule_id, &acl_name, &rule);
        if (WJH_CHECK_FAIL(err)) {
            if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
                WJH_LOG_ERR("__wjh_acl_attributes_get failed, err: %d\n", err);
            }
            goto clean_up;
        }
        acl_key_list_p[index].rule_id = rule_id;
        acl_key_list_p[index].acl_name = acl_name;
        acl_key_list_p[index].rule = rule;
        /* TO DO - handle flows_num in Spectrum-2 */
        acl_data_list_p[index].flows_num = 0;

        switch (acl_attr.acl_direction) {
        case SX_ACL_DIRECTION_INGRESS:
            reason_id = WJH_DROP_REASON_ID_INGRESS_PORT_ACL_E;
            break;

        case SX_ACL_DIRECTION_EGRESS:
            reason_id = WJH_DROP_REASON_ID_EGRESS_PORT_ACL_E;
            break;

        case SX_ACL_DIRECTION_RIF_INGRESS:
            reason_id = WJH_DROP_REASON_ID_INGRESS_ROUTER_ACL_E;
            break;

        case SX_ACL_DIRECTION_RIF_EGRESS:
            reason_id = WJH_DROP_REASON_ID_EGRESS_ROUTER_ACL_E;
            break;

        case SX_ACL_DIRECTION_TPORT_INGRESS:
            reason_id = WJH_DROP_REASON_ID_INGRESS_TPORT_ACL_E;
            break;

        case SX_ACL_DIRECTION_TPORT_EGRESS:
            reason_id = WJH_DROP_REASON_ID_EGRESS_TPORT_ACL_E;
            break;

        case SX_ACL_DIRECTION_MULTI_POINTS_E:
            reason_id = WJH_DROP_REASON_ID_MULTI_POINTS_ACL_E;
            break;

        default:
            WJH_LOG_ERR("Invalid acl direction %u\n", acl_attr.acl_direction);
            goto clean_up;
            break;
        }

        wjh_db_get_drop_reason_item_by_reason(reason_id, &drop_reason_item_p);
        acl_key_list_p[index].reason.id = reason_id;
        acl_key_list_p[index].reason.severity = drop_reason_item_p->severity;
        if (drop_reason_item_p->reason) {
            acl_key_list_p[index].reason.reason = drop_reason_item_p->reason;
        } else {
            acl_key_list_p[index].reason.reason = WJH_DB_EMPTY_STR;
        }
        if (drop_reason_item_p->description) {
            acl_key_list_p[index].reason.description = drop_reason_item_p->description;
        } else {
            acl_key_list_p[index].reason.description = WJH_DB_EMPTY_STR;
        }
        acl_key_list_p[index].reason.event_type = drop_reason_item_p->event_type;

        goto out;

    case WJH_DROP_REASON_GROUP_L2_E:
        WJH_AGG_PREPARE_KEY_DATA(l2_key_list_p, l2_data_list_p);
        WJH_AGG_FILL_FIVE_TUPLES(l2_key_list_p, ebpf_key_p);
        if (agg_key_mode == WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
            WJH_AGG_FILL_PORT_VLAN_ETHER_TYPE(l2_key_list_p, ebpf_key_p, TRUE);
        }
        WJH_AGG_FILL_DMAC_SMAC(l2_key_list_p, ebpf_key_p);
        WJH_AGG_FILL_DROP_REASON(l2_key_list_p, reason, ebpf_key_p->reason_id, index);
        goto out;

    case WJH_DROP_REASON_GROUP_ROUTER_E:
        WJH_AGG_PREPARE_KEY_DATA(router_key_list_p, router_data_list_p);
        WJH_AGG_FILL_FIVE_TUPLES(router_key_list_p, ebpf_key_p);
        if (agg_key_mode == WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
            WJH_AGG_FILL_PORT_VLAN_ETHER_TYPE(router_key_list_p, ebpf_key_p, TRUE);
            WJH_AGG_FILL_DMAC_SMAC(router_key_list_p, ebpf_key_p);
        }
        WJH_AGG_FILL_DROP_REASON(router_key_list_p, reason, ebpf_key_p->reason_id, index);
        goto out;

    case WJH_DROP_REASON_GROUP_TUNNEL_E:
        WJH_AGG_PREPARE_KEY_DATA(tunnel_key_list_p, tunnel_data_list_p);
        WJH_AGG_FILL_FIVE_TUPLES(tunnel_key_list_p, ebpf_key_p);
        if (agg_key_mode == WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
            WJH_AGG_FILL_PORT_VLAN_ETHER_TYPE(tunnel_key_list_p, ebpf_key_p, TRUE);
        }
        WJH_AGG_FILL_DMAC_SMAC(tunnel_key_list_p, ebpf_key_p);
        WJH_AGG_FILL_DROP_REASON(tunnel_key_list_p, reason, ebpf_key_p->reason_id, index);
        goto out;

    case WJH_DROP_REASON_GROUP_ROCE_E:
        WJH_AGG_PREPARE_KEY_DATA(roce_key_list_p, roce_data_list_p);
        WJH_AGG_FILL_FIVE_TUPLES(roce_key_list_p, ebpf_key_p);
        if (agg_key_mode == WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
            WJH_AGG_FILL_PORT_VLAN_ETHER_TYPE(roce_key_list_p, ebpf_key_p, TRUE);
            WJH_AGG_FILL_DMAC_SMAC(roce_key_list_p, ebpf_key_p);
        }
        WJH_AGG_FILL_DROP_REASON(roce_key_list_p, reason, ebpf_key_p->reason_id, index);
        goto out;

    default:
        WJH_LOG_ERR("Unsupported drop reason group (%u)\n", group_item_p->drop_reason_group);
        err = WJH_STATUS_UNSUPPORTED;
        goto out;
    }

clean_up:
    if (acl_name != NULL) {
        cl_free(acl_name);
    }

    if (rule != NULL) {
        cl_free(rule);
    }

out:
    return err;
}

static wjh_status_t __wjh_aggregation_fill_five_tuples(wjh_aggregate_five_tuples_t *aggregation_five_tuples_p,
                                                       wjh_agg_ebpf_five_tuples_t  *ebpf_five_tuples_p,
                                                       void                        *sip_buffer,
                                                       void                        *dip_buffer,
                                                       uint32_t                     index)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    boolean_t    is_ipv6 = ebpf_five_tuples_p->is_ipv6;
    int          af = is_ipv6 ? AF_INET6 : AF_INET;
    char        *sip_buf = (char*)sip_buffer;
    char        *dip_buf = (char*)dip_buffer;

    if (inet_ntop(af, ebpf_five_tuples_p->sip,
                  sip_buf + (index * INET6_ADDRSTRLEN), INET6_ADDRSTRLEN) == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("inet_ntop failed, err: %s\n", strerror(errno));
        goto out;
    }

    if (inet_ntop(af, ebpf_five_tuples_p->dip,
                  dip_buf + (index * INET6_ADDRSTRLEN), INET6_ADDRSTRLEN) == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("inet_ntop failed, err: %s\n", strerror(errno));
        goto out;
    }

    aggregation_five_tuples_p->sip = sip_buf + (index * INET6_ADDRSTRLEN);
    aggregation_five_tuples_p->dip = dip_buf + (index * INET6_ADDRSTRLEN);
    aggregation_five_tuples_p->proto = ebpf_five_tuples_p->ip_proto;
    aggregation_five_tuples_p->sport = ebpf_five_tuples_p->sport;
    aggregation_five_tuples_p->dport = ebpf_five_tuples_p->dport;

out:
    return err;
}

static wjh_status_t __wjh_aggregation_exec_callback(wjh_drop_reason_group_record_t *group_item_p,
                                                    uint32_t                        count,
                                                    boolean_t                       is_pull_api)
{
    wjh_status_t                  err = WJH_STATUS_SUCCESS;
    wjh_drop_aggregate_attr_t     drop_attributes;
    wjh_acl_drop_aggregate_key_t *acl_key_list_p = NULL;
    uint32_t                      i = 0;

    if (count == 0) {
        goto out;
    }

    memset(&drop_attributes, 0, sizeof(drop_attributes));
    if (is_pull_api) {
        drop_attributes.mode = WJH_USER_CHANNEL_MODE_PULL_E;
    } else {
        drop_attributes.mode = WJH_USER_CHANNEL_MODE_PUSH_E;
    }

    switch (group_item_p->drop_reason_group) {
    case WJH_DROP_REASON_GROUP_BUFFER_E:
        err = group_item_p->callbacks.aggregate_cb.buffer(group_item_p->aggregation_key_buf,
                                                          group_item_p->aggregation_data_buf, &count,
                                                          &drop_attributes);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to execute Buffer aggregation callback, err: %d\n", err);
            goto out;
        }
        break;

    case WJH_DROP_REASON_GROUP_ACL_E:
        err = group_item_p->callbacks.aggregate_cb.acl(group_item_p->aggregation_key_buf,
                                                       group_item_p->aggregation_data_buf, &count,
                                                       &drop_attributes);
        acl_key_list_p = group_item_p->aggregation_key_buf;
        for (i = 0; i < count; i++) {
            if (acl_key_list_p[i].acl_name != NULL) {
                cl_free((void*)acl_key_list_p[i].acl_name);
                acl_key_list_p[i].acl_name = NULL;
            }

            if (acl_key_list_p[i].rule != NULL) {
                cl_free((void*)acl_key_list_p[i].rule);
                acl_key_list_p[i].rule = NULL;
            }
        }
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to execute ACL aggregation callback, err: %d\n", err);
            goto out;
        }
        break;

    case WJH_DROP_REASON_GROUP_L2_E:
        err = group_item_p->callbacks.aggregate_cb.L2(group_item_p->aggregation_key_buf,
                                                      group_item_p->aggregation_data_buf, &count,
                                                      &drop_attributes);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to execute L2 aggregation callback, err: %d\n", err);
            goto out;
        }
        break;

    case WJH_DROP_REASON_GROUP_ROUTER_E:
        err = group_item_p->callbacks.aggregate_cb.router(group_item_p->aggregation_key_buf,
                                                          group_item_p->aggregation_data_buf, &count,
                                                          &drop_attributes);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to execute Router aggregation callback, err: %d\n", err);
            goto out;
        }
        break;

    case WJH_DROP_REASON_GROUP_TUNNEL_E:
        err = group_item_p->callbacks.aggregate_cb.tunnel(group_item_p->aggregation_key_buf,
                                                          group_item_p->aggregation_data_buf, &count,
                                                          &drop_attributes);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to execute Tunnel aggregation callback, err: %d\n", err);
            goto out;
        }
        break;

    case WJH_DROP_REASON_GROUP_ROCE_E:
        err = group_item_p->callbacks.aggregate_cb.roce(group_item_p->aggregation_key_buf,
                                                        group_item_p->aggregation_data_buf, &count,
                                                        &drop_attributes);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to execute RoCE aggregation callback, err: %d\n", err);
            goto out;
        }
        break;

    default:
        WJH_LOG_ERR("Unsupported drop reason group (%u)\n", group_item_p->drop_reason_group);
        err = WJH_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_set_rlimit_memory_lock(void)
{
    wjh_status_t  err = WJH_STATUS_SUCCESS;
    int           rc = 0;
    struct rlimit rlim;

    rc = getrlimit(RLIMIT_MEMLOCK, &rlim);
    if (rc < 0) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("getrlimit failed, err: %s\n", strerror(errno));
        goto out;
    }

    if ((rlim.rlim_cur != RLIM_INFINITY) || (rlim.rlim_max != RLIM_INFINITY)) {
        rlim.rlim_cur = RLIM_INFINITY;
        rlim.rlim_max = RLIM_INFINITY;
        rc = setrlimit(RLIMIT_MEMLOCK, &rlim);
        if (rc < 0) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("setrlimit failed, err: %s\n", strerror(errno));
            goto out;
        }
    }

out:
    return err;
}

wjh_status_t wjh_aggregation_set_monitor_rdq_trace_points_sdk(boolean_t enable)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    err = __wjh_sysfs_entry_set(WJH_ENABLE_MONITOR_RDQ_TRACE_POINTS_SYSFS_ENTRY, enable);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_sysfs_entry_set failed, err: %d\n", err);
        goto out;
    }

out:
    return err;
}

#endif /* ifdef WJH_EBPF_PRESENT */

static wjh_status_t __wjh_sysfs_entry_set(const char *sysfs_entry, boolean_t enable)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    FILE        *fp = NULL;
    int          value = enable ? 1 : 0;

    fp = fopen(sysfs_entry, "w");
    if (fp == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to open file %s, err: %s\n", sysfs_entry, strerror(errno));
        goto out;
    }

    if (fprintf(fp, "%d", value) < 0) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to write file %s\n", sysfs_entry);
        goto out;
    }

out:
    if (fp != NULL) {
        fclose(fp);
    }

    return err;
}

wjh_status_t wjh_init_sdk(void)
{
    sx_status_t  sdk_rc = SX_STATUS_SUCCESS;
    wjh_status_t err = WJH_STATUS_SUCCESS;

    sdk_rc = sx_api_open(NULL, &sx_api_handle_s);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to open SX-API, error: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

#ifdef WJH_EBPF_PRESENT
    err = __wjh_bpf_jit_proc_fs_set(TRUE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_bpf_jit_proc_fs_set failed, err: %d\n", err);
        goto out;
    }
#endif

    err = __wjh_sysfs_entry_set(WJH_ENABLE_DROP_MONITOR_SYSFS_ENTRY, TRUE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_sysfs_entry_set failed, err: %d\n", err);
        goto out;
    }

    err = __wjh_load_lag_shm();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_load_lag_shm failed, err: %d\n", err);
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_deinit_sdk(void)
{
    sx_status_t  sdk_rc = SX_STATUS_SUCCESS;
    wjh_status_t err = WJH_STATUS_SUCCESS;

    sdk_rc = sx_api_close(&sx_api_handle_s);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to close SX-API, error: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

#ifdef WJH_EBPF_PRESENT
    err = __wjh_bpf_jit_proc_fs_set(FALSE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_bpf_jit_proc_fs_set failed, err: %d\n", err);
        goto out;
    }
#endif

    err = __wjh_sysfs_entry_set(WJH_ENABLE_DROP_MONITOR_SYSFS_ENTRY, FALSE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_sysfs_entry_set failed, err: %d\n", err);
        goto out;
    }

    err = __wjh_unload_lag_shm();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_unload_lag_shm failed, err: %d\n", err);
        goto out;
    }

out:
    return err;
}

#ifdef WJH_EBPF_PRESENT
wjh_status_t wjh_ebpf_prepare_sdk(void)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_record_t *group_record_p = NULL;
    uint32_t                        i = 0;
    uint32_t                        j = 0;
    uint32_t                        trap_id = 0;
    uint32_t                        reason_id = 0;

    err = __wjh_set_rlimit_memory_lock();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_set_rlimit_memory_lock failed, err: %d\n", err);
        goto out;
    }

    err = wjh_ebpf_map_create(BPF_MAP_TYPE_HASH, sizeof(uint32_t), sizeof(uint32_t),
                              WJH_TRAP_ID_MAX + 1,
                              &wjh_drop_reason_bpf_map_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to create eBPF map, key_size (%lu), value_size (%lu), err: %d\n",
                    sizeof(uint32_t), sizeof(uint32_t), err);
        goto out;
    }

    for (i = 0; i < WJH_DROP_REASON_GROUP_NUM; i++) {
        wjh_db_drop_reason_group_get(i, &group_record_p);

        for (j = 0; j < group_record_p->trap_id_num; j++) {
            trap_id = (uint64_t)group_record_p->trap_ids[j].trap_id;
            reason_id = (uint64_t)group_record_p->trap_ids[j].reason_id;

            err = wjh_ebpf_map_elem_update(wjh_drop_reason_bpf_map_s,
                                           &trap_id, &reason_id, BPF_ANY);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("wjh_ebpf_map_elem_update failed, err: %d\n", err);
                goto out;
            }
        }
    }

    for (trap_id = SX_TRAP_ID_MIRROR_AGENT_MIN; trap_id <= SX_TRAP_ID_MIRROR_AGENT_MAX; trap_id++) {
        reason_id = WJH_BUFFER_DROP_REASON_ID_MIN;
        err = wjh_ebpf_map_elem_update(wjh_drop_reason_bpf_map_s,
                                       &trap_id, &reason_id, BPF_ANY);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_map_elem_update failed, err: %d\n", err);
            goto out;
        }
    }

    err = wjh_ebpf_map_create(BPF_MAP_TYPE_HASH, sizeof(uint16_t), sizeof(uint32_t),
                              WJH_PORT_NUM_MAX,
                              &wjh_port_bpf_map_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to create eBPF map, key_size (%lu), value_size (%lu), err: %d\n",
                    sizeof(uint16_t), sizeof(uint32_t), err);
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_ebpf_cleanup_sdk(void)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (wjh_drop_reason_bpf_map_s >= 0) {
        close(wjh_drop_reason_bpf_map_s);
        wjh_drop_reason_bpf_map_s = -1;
    }

    if (wjh_port_bpf_map_s >= 0) {
        close(wjh_port_bpf_map_s);
        wjh_port_bpf_map_s = -1;
    }

    return err;
}
#endif /* ifdef WJH_EBPF_PRESENT */


wjh_status_t _wjh_policer_create_for_tac(uint8_t percentage)
{
    sx_status_t             sdk_rc = SX_STATUS_SUCCESS;
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    sx_policer_attributes_t policer_attr;
    wjh_policer_attrs_t     wjh_policer_attrs;

    memset(&policer_attr, 0, sizeof(policer_attr));

    err = __wjh_tac_policer_settings_get(percentage, &wjh_policer_attrs);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_policer_settings_get failed, err = %d\n", err);
        goto out;
    }

    policer_attr.meter_type = SX_POLICER_METER_TRAFFIC;
    policer_attr.cbs = wjh_policer_attrs.burst_size;
    policer_attr.ebs = wjh_policer_attrs.burst_size;
    policer_attr.cir = wjh_policer_attrs.information_rate;
    policer_attr.yellow_action = SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR;
    policer_attr.red_action = SX_POLICER_ACTION_DISCARD;
    policer_attr.eir = wjh_policer_attrs.information_rate;
    policer_attr.rate_type = SX_POLICER_RATE_TYPE_SINGLE_RATE_E;
    policer_attr.color_aware = 0;
    policer_attr.is_host_ifc_policer = 1;
    policer_attr.ir_units = SX_POLICER_IR_UNITS_10_POWER_6_E;

    sdk_rc = sx_api_policer_set(sx_api_handle_s, SX_ACCESS_CMD_CREATE, &policer_attr, &wjh_policer_tac_id_s);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to create policer, error: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_policer_create_sdk(uint8_t percentage)
{
    sx_status_t             sdk_rc = SX_STATUS_SUCCESS;
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    sx_policer_attributes_t policer_attr;
    wjh_chip_types_t        chip_type;

    memset(&policer_attr, 0, sizeof(policer_attr));

    err = __wjh_policer_settings_get(percentage, &wjh_policer_attrs_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_policer_settings_get failed, err = %d\n", err);
        goto out;
    }

    policer_attr.meter_type = SX_POLICER_METER_TRAFFIC;
    policer_attr.cbs = wjh_policer_attrs_s.burst_size;
    policer_attr.ebs = wjh_policer_attrs_s.burst_size;
    policer_attr.cir = wjh_policer_attrs_s.information_rate;
    policer_attr.yellow_action = SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR;
    policer_attr.red_action = SX_POLICER_ACTION_DISCARD;
    policer_attr.eir = wjh_policer_attrs_s.information_rate;
    policer_attr.rate_type = SX_POLICER_RATE_TYPE_SINGLE_RATE_E;
    policer_attr.color_aware = 0;
    policer_attr.is_host_ifc_policer = 1;
    policer_attr.ir_units = SX_POLICER_IR_UNITS_10_POWER_6_E;

    sdk_rc = sx_api_policer_set(sx_api_handle_s, SX_ACCESS_CMD_CREATE, &policer_attr, &wjh_policer_id_s);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to create policer, error: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    err = wjh_db_get_chip_type(&chip_type);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("wjh_get_chip_type failed, err: %u\n", err);
        goto out;
    }

    if (chip_type >= SXD_CHIP_TYPE_SPECTRUM4) {
        err = _wjh_policer_create_for_tac(percentage);
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("_wjh_policer_create_for_tac failed, err: %u\n", err);
            goto out;
        }
    }

out:
    return err;
}

wjh_status_t wjh_policer_destroy_sdk(void)
{
    wjh_status_t     err = WJH_STATUS_SUCCESS;
    wjh_chip_types_t chip_type;

    err = wjh_db_get_chip_type(&chip_type);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("wjh_get_chip_type failed, err: %u\n", err);
        return WJH_STATUS_ERROR;
    }
    if (chip_type >= SXD_CHIP_TYPE_SPECTRUM4) {
        err = __wjh_policer_destroy_sdk(wjh_policer_tac_id_s);
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("destroy tac policy failed, err: %u\n", err);
        }
    }

    return __wjh_policer_destroy_sdk(wjh_policer_id_s);
}


wjh_status_t wjh_user_channel_create_sdk(wjh_user_channel_type_e    channel_type,
                                         wjh_user_channel_record_t *user_channel_p)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    sx_status_t                sdk_rc = SX_STATUS_SUCCESS;
    sx_trap_group_attributes_t trap_group_attr;
    sx_trap_group_t            trap_group_id = SX_TRAP_GROUP_INVALID;
    sx_access_cmd_t            cmd = SX_ACCESS_CMD_NONE;
    int                        fd_flags;
    sx_policer_id_t            wjh_policer_id;

    memset(&user_channel_p->fd, 0, sizeof(user_channel_p->fd));
    sdk_rc = sx_api_host_ifc_open(sx_api_handle_s, &user_channel_p->fd);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to open FD user channel, error: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    fd_flags = fcntl(user_channel_p->fd.fd, F_GETFL, 0);
    if ((fd_flags == -1) || (fcntl(user_channel_p->fd.fd, F_SETFL,
                                   fd_flags | O_NONBLOCK) == -1)) {
        WJH_LOG_ERR("Failed to set non-blocking flag for fd %d\n", user_channel_p->fd.fd);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    memset(&trap_group_attr, 0, sizeof(trap_group_attr));
    trap_group_attr.prio = SX_TRAP_PRIORITY_MIN;
    trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_DISABLE;
    trap_group_attr.truncate_size = 0;
    trap_group_attr.control_type = SX_CONTROL_TYPE_DEFAULT;
    trap_group_attr.add_timestamp = TRUE;
    if (channel_type == WJH_USER_CHANNEL_TAC_E) {
        trap_group_attr.is_tac_capable = TRUE;
        trap_group_attr.truncate_mode = SX_TRUNCATE_MODE_PROFILE_ENABLE;
        trap_group_attr.trunc_profile_id = wjh_init_params_g.trunc_profile_id;
    } else if (channel_type != WJH_USER_CHANNEL_TAILDROP_E) {
        trap_group_attr.is_monitor = TRUE;
        memcpy(&trap_group_attr.monitor_fd, &user_channel_p->fd, sizeof(user_channel_p->fd));
    }

    if (wjh_init_params_g.driver_init_param.trap_group_allocate_mode == WJH_TRAP_GROUP_ALLOCATE_MODE_STATIC_E) {
        trap_group_id = WJH_TRAP_GROUP_MIN + user_channel_p->channel_id;
        cmd = SX_ACCESS_CMD_SET;
    } else {
        cmd = SX_ACCESS_CMD_CREATE;
    }

    sdk_rc = sx_api_host_ifc_trap_group_ext_set(sx_api_handle_s,
                                                cmd,
                                                0,
                                                trap_group_id,
                                                &trap_group_attr);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to set trap group (%u), error: %s\n",
                    trap_group_id,
                    sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (wjh_init_params_g.driver_init_param.trap_group_allocate_mode == WJH_TRAP_GROUP_ALLOCATE_MODE_DYNAMIC_E) {
        trap_group_id = trap_group_attr.trap_group;
    }

    if (channel_type == WJH_USER_CHANNEL_TAC_E) {
        wjh_policer_id = wjh_policer_tac_id_s;
    } else {
        wjh_policer_id = wjh_policer_id_s;
    }

    /* Bind the global policer to trap group */
    sdk_rc = sx_api_host_ifc_policer_bind_set(sx_api_handle_s, SX_ACCESS_CMD_BIND, 0,
                                              trap_group_id,
                                              wjh_policer_id);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to bind policer (%" PRIu64 ") to trap group (%u), error: %s\n",
                    wjh_policer_id, trap_group_id,
                    sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }


    user_channel_p->trap_group_id = trap_group_id;

    memset(&trap_group_attr, 0, sizeof(trap_group_attr));
    sdk_rc = sx_api_host_ifc_trap_group_get(sx_api_handle_s, 0, user_channel_p->trap_group_id,
                                            &trap_group_attr);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("sx_api_host_ifc_trap_group_get failed, err: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }
    user_channel_p->hw_trap_group = trap_group_attr.hw_trap_group;

out:
    return err;
}

wjh_status_t wjh_user_channel_destroy_sdk(wjh_user_channel_record_t *user_channel_p)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    sx_status_t       sdk_rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t   cmd = SX_ACCESS_CMD_NONE;
    sx_policer_id_t   wjh_policer_id;
    sx_tele_tac_cfg_t tac_cfg = {0};

#ifdef WJH_EBPF_PRESENT
    if (user_channel_p->filter_record_p) {
        err = __wjh_filter_attach_detach(user_channel_p->filter_record_p, user_channel_p, FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to unbind filter %d from channel %d.\n",
                        user_channel_p->filter_record_p->filter_id,
                        user_channel_p->channel_id);
            goto out;
        }
    }
#endif

    if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAC_E) {
        wjh_policer_id = wjh_policer_tac_id_s;
    } else {
        wjh_policer_id = wjh_policer_id_s;
    }

    /* Unbind the global policer from trap group */
    sdk_rc = sx_api_host_ifc_policer_bind_set(sx_api_handle_s, SX_ACCESS_CMD_UNBIND, 0,
                                              user_channel_p->trap_group_id,
                                              wjh_policer_id);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to unbind policer (%" PRIu64 ") from trap group (%u), error: %s\n",
                    wjh_policer_id, user_channel_p->trap_group_id,
                    sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (wjh_init_params_g.driver_init_param.trap_group_allocate_mode == WJH_TRAP_GROUP_ALLOCATE_MODE_STATIC_E) {
        cmd = SX_ACCESS_CMD_UNSET;
    } else {
        cmd = SX_ACCESS_CMD_DESTROY;
    }


    if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAC_E) {
        sdk_rc = sx_api_tele_tac_get(sx_api_handle_s, SX_ACCESS_CMD_GET, user_channel_p->hw_trap_group, &tac_cfg);
        if (sdk_rc == SX_STATUS_SUCCESS) {
            sdk_rc =
                sx_api_tele_tac_set(sx_api_handle_s, SX_ACCESS_CMD_UNSET, user_channel_p->hw_trap_group, &tac_cfg);
            if (SX_CHECK_FAIL(sdk_rc)) {
                WJH_LOG_ERR("Failed to unset sx_api_tele_tac_set, error: %s\n", sx_status_str(sdk_rc));
                err = WJH_STATUS_ERROR;
                goto out;
            }
        }
    }


    /*  Unset or destroy the trap group associated with the user channel */
    sdk_rc = sx_api_host_ifc_trap_group_ext_set(sx_api_handle_s,
                                                cmd,
                                                0,
                                                user_channel_p->trap_group_id,
                                                NULL);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to unset trap group (%u), error: %s\n",
                    user_channel_p->trap_group_id,
                    sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    sdk_rc = sx_api_host_ifc_close(sx_api_handle_s, &user_channel_p->fd);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to close FD user channel, error: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}

#ifdef WJH_EBPF_PRESENT
static wjh_status_t __wjh_aggregation_channel_flush(wjh_user_channel_record_t *user_channel_p)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_e         drop_reason_group;
    wjh_drop_reason_group_record_t *group_item_p = NULL;
    void                           *key_p = NULL;
    void                           *next_key_p = NULL;
    wjh_agg_ebpf_key_t              key;
    wjh_agg_ebpf_key_t              non_exist_key;
    boolean_t                       first_lookup = TRUE;
    uint32_t                        max_entries_cnt = 0;
    uint32_t                        index = 0;

    cl_plock_acquire(&wjh_bind_enable_rwlock_g);
    for (drop_reason_group = WJH_DROP_REASON_GROUP_MIN_E;
         drop_reason_group <= WJH_DROP_REASON_GROUP_MAX_E;
         ++drop_reason_group) {
        wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);
        if ((!user_channel_p->bound[drop_reason_group]) || (drop_reason_group == WJH_DROP_REASON_GROUP_L1_E)) {
            continue;
        }

        memset(&key, 0, sizeof(key));
        memset(&non_exist_key, 0, sizeof(non_exist_key));
        non_exist_key.reason_id = 0xFFFFFFFF;
        key_p = &non_exist_key;
        next_key_p = &key;

        max_entries_cnt = group_item_p->attr.max_aggregation_entries_cnt;
        index = 0;
        first_lookup = TRUE;
        while (index < max_entries_cnt) {
            err = wjh_ebpf_map_next_key_get(group_item_p->aggregation_ebpf_map_fd, key_p, next_key_p);
            if (WJH_CHECK_FAIL(err)) {
                if (err == WJH_STATUS_ENTRY_NOT_FOUND) {
                    if (first_lookup) {
                        err = WJH_STATUS_SUCCESS;
                    } else {
                        err = wjh_ebpf_map_elem_delete(group_item_p->aggregation_ebpf_map_fd, key_p);
                        if (WJH_CHECK_FAIL(err)) {
                            WJH_LOG_ERR("wjh_ebpf_map_elem_delete failed, err: %d\n", err);
                            goto out;
                        }
                        ++index;
                    }
                    break;
                } else {
                    WJH_LOG_ERR("wjh_ebpf_map_next_key_get failed, err: %d\n", err);
                    goto out;
                }
            }

            if (first_lookup) {
                __wjh_swap_key_and_next_key(&key_p, &next_key_p);
                first_lookup = FALSE;
                continue;
            }

            err = wjh_ebpf_map_elem_delete(group_item_p->aggregation_ebpf_map_fd, key_p);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("wjh_ebpf_map_elem_delete failed, err: %d\n", err);
                goto out;
            }
            ++index;

            __wjh_swap_key_and_next_key(&key_p, &next_key_p);
        }
    }

out:
    cl_plock_release(&wjh_bind_enable_rwlock_g);
    return err;
}
#endif /* ifdef WJH_EBPF_PRESENT */

wjh_status_t wjh_user_channel_flush_sdk(wjh_user_channel_record_t *user_channel_p)
{
    wjh_status_t                err = WJH_STATUS_SUCCESS;
    sx_status_t                 sdk_rc = SX_STATUS_SUCCESS;
    int                         sxd_err = 0;
    sxd_ctrl_pack_t             ctrl_pack;
    sx_tele_tac_action_info_t   tac_action_info = {0};
    sx_tele_tac_action_filter_t tac_action_filter = {0};

    switch (user_channel_p->channel_type) {
    case WJH_USER_CHANNEL_CYCLIC_E:
        sdk_rc = sx_lib_host_ifc_recv_list(&user_channel_p->fd, NULL, NULL);
        if (SX_CHECK_FAIL(sdk_rc)) {
            WJH_LOG_ERR("Failed to flush user channel (id: %u), error: %s\n",
                        user_channel_p->channel_id, sx_status_str(sdk_rc));
            err = WJH_STATUS_ERROR;
        }
        break;

    case WJH_USER_CHANNEL_TAILDROP_E:
        ctrl_pack.cmd_body = NULL;
        ctrl_pack.ctrl_cmd = CTRL_CMD_FLUSH_EVLIST;
        sxd_err = sxd_ioctl(user_channel_p->fd.driver_handle, &ctrl_pack);
        if (sxd_err != 0) {
            WJH_LOG_ERR("Failed to flush user channel (id: %u), error: %s\n",
                        user_channel_p->channel_id, strerror(errno));
            err = WJH_STATUS_ERROR;
        }
        break;

    case WJH_USER_CHANNEL_AGGREGATE_E:
#ifdef WJH_EBPF_PRESENT
        err = __wjh_aggregation_channel_flush(user_channel_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_aggregation_channel_flush failed, err: %d\n", err);
        }
#endif
        break;

    case WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E:
        sdk_rc = sx_lib_host_ifc_recv_list(&user_channel_p->fd, NULL, NULL);
        if (SX_CHECK_FAIL(sdk_rc)) {
            WJH_LOG_ERR("Failed to flush user channel (id: %u), error: %s\n",
                        user_channel_p->channel_id, sx_status_str(sdk_rc));
            err = WJH_STATUS_ERROR;
            goto out;
        }
#ifdef WJH_EBPF_PRESENT
        err = __wjh_aggregation_channel_flush(user_channel_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_aggregation_channel_flush failed, err: %d\n", err);
        }
#endif
        break;

    case WJH_USER_CHANNEL_TAC_E:
        tac_action_filter.filter_by_trap_group = TRUE;
        tac_action_filter.trap_group = user_channel_p->hw_trap_group;
        tac_action_info.tac_action = SX_TELE_TAC_ACTION_FLUSH_AND_REPORT_E;
        sdk_rc = sx_api_tele_tac_action_set(sx_api_handle_s, SX_ACCESS_CMD_SET, &tac_action_filter, &tac_action_info);
        if (SX_CHECK_FAIL(sdk_rc)) {
            WJH_LOG_ERR("Failed to flush tac user channel (id: %u), error: %s\n",
                        user_channel_p->channel_id, sx_status_str(sdk_rc));
            err = WJH_STATUS_ERROR;
            goto out;
        }

        break;

    default:
        WJH_LOG_ERR("Flush operation is not supported for user channel (id: %u, type: %u).\n",
                    user_channel_p->channel_id, user_channel_p->channel_type);
        err = WJH_STATUS_UNSUPPORTED;
        break;
    }

out:
    return err;
}

wjh_status_t wjh_drop_reason_group_validate_sdk(wjh_drop_reason_group_e drop_reason_group)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    UNUSED_PARAM(drop_reason_group);

    return err;
}

wjh_status_t wjh_drop_reason_group_bind_sdk(wjh_user_channel_record_t      *user_channel_p,
                                            wjh_drop_reason_group_record_t *group_item_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

#ifdef WJH_EBPF_PRESENT
    wjh_status_t err1 = WJH_STATUS_SUCCESS;
#endif

    if (group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_L1_E) {
        if ((user_channel_p->channel_type == WJH_USER_CHANNEL_TAILDROP_E) ||
            (user_channel_p->channel_type == WJH_USER_CHANNEL_TAC_E)) {
            WJH_LOG_ERR("Not allowed to bind L1 drop reason group to channel (id: %u, type: %u).\n",
                        user_channel_p->channel_id, user_channel_p->channel_type);
            err = WJH_STATUS_ERROR;
        }

        /* For L1 drop reason group, nothing to do when binding it to an aggregation channel. */
        goto out;
    } else {
#ifndef WJH_EBPF_PRESENT
        if ((user_channel_p->channel_type == WJH_USER_CHANNEL_AGGREGATE_E) ||
            (user_channel_p->channel_type == WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) {
            WJH_LOG_ERR("At least one of the prerequisites of aggregation channel (eBPF) was not met when the WJH "
                        "library was built, please the check and fix all of them.\n");
            err = WJH_STATUS_UNSUPPORTED;
            goto out;
        }
#endif
    }

    if (group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_ACL_E) {
        err = __wjh_acl_drop_reason_group_disable(TRUE);
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to disable monitor on acl drop reason group.\n");
            goto out;
        }
    }

#ifdef WJH_EBPF_PRESENT
    if ((user_channel_p->channel_type != WJH_USER_CHANNEL_AGGREGATE_E) &&
        (user_channel_p->channel_type != WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) {
        goto out;
    }

    err = __wjh_aggregation_create_ebpf_prog_and_map(user_channel_p, group_item_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_aggregation_create_ebpf_prog_and_map failed, err = %d\n", err);
        goto out;
    }

    err = __wjh_aggregation_create_buffer(group_item_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_aggregation_create_buffer failed, err: %d\n", err);
        goto destroy_ebpf_prog_and_map;
    }

    goto out;

destroy_ebpf_prog_and_map:
    err1 = __wjh_aggregation_destroy_ebpf_prog_and_map(group_item_p);
    if (WJH_CHECK_FAIL(err1)) {
        WJH_LOG_ERR("__wjh_aggregation_destroy_ebpf_prog_and_map failed, err: %d\n", err1);
    }
#endif /* ifdef WJH_EBPF_PRESENT */

out:
    return err;
}

wjh_status_t wjh_drop_reason_group_unbind_sdk(wjh_user_channel_record_t      *user_channel_p,
                                              wjh_drop_reason_group_record_t *group_item_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_L1_E) {
        /* Nothing to do for L1 drop reason group */
        goto out;
    }

    if (group_item_p->enabled_severity_bits) {
        err = wjh_drop_reason_group_disable_sdk(user_channel_p, group_item_p, group_item_p->enabled_severity_bits);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_drop_reason_group_disable_sdk failed, err: %d\n", err);
            goto out;
        }
    }

    if (group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_ACL_E) {
        err = __wjh_acl_drop_reason_group_disable(WJH_ACL_DROP_TRAP_DISABLE_DEFAULT);
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to disable monitor on acl drop reason group.\n");
            goto out;
        }
    }

#ifdef WJH_EBPF_PRESENT
    if ((user_channel_p->channel_type != WJH_USER_CHANNEL_AGGREGATE_E) &&
        (user_channel_p->channel_type != WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) {
        goto out;
    }

    if (group_item_p->aggregation_ebpf_prog_fd_attached) {
        err = __wjh_agg_bpf_prog_attach_detach(user_channel_p, group_item_p, FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_agg_bpf_prog_attach_detach failed, err = %d\n", err);
            goto out;
        }
        err = __wjh_monitor_rdq_trace_points_disable();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_monitor_rdq_trace_points_disable failed, err: %d\n", err);
            goto out;
        }
    }

    err = __wjh_aggregation_destroy_ebpf_prog_and_map(group_item_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_aggregation_destroy_ebpf_prog_and_map failed, err = %d\n", err);
        goto out;
    }

    __wjh_aggregation_destroy_buffer(group_item_p);
#endif

out:
    return err;
}

static wjh_status_t __wjh_drop_reason_group_traps_set(wjh_user_channel_record_t      *user_channel_p,
                                                      wjh_drop_reason_group_record_t *group_item_p,
                                                      uint8_t                         severity_bits,
                                                      sx_trap_action_t                action)
{
    sx_status_t             sdk_rc = SX_STATUS_SUCCESS;
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    sx_host_ifc_trap_key_t  trap_key;
    sx_host_ifc_trap_attr_t trap_attr;
    wjh_trap_id_attr_t     *trap_id_attr_p = NULL;
    int                     i = 0;
    sx_user_channel_t       sx_user_channel;
    sx_user_channel_t       drop_monitor_channel;
    sx_access_cmd_t         cmd = (action == SX_TRAP_ACTION_EXCEPTION_TRAP) ? SX_ACCESS_CMD_SET : SX_ACCESS_CMD_UNSET;
    sx_access_cmd_t         register_cmd =
        (action == SX_TRAP_ACTION_EXCEPTION_TRAP) ? SX_ACCESS_CMD_REGISTER : SX_ACCESS_CMD_DEREGISTER;
    boolean_t   trap_id_set = FALSE;
    boolean_t   user_channel_registered = FALSE;
    sx_status_t sdk_rb_err = SX_STATUS_SUCCESS;

    memset(&trap_key, 0, sizeof(sx_host_ifc_trap_key_t));
    memset(&trap_attr, 0, sizeof(sx_host_ifc_trap_attr_t));

    trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E;
    trap_attr.attr.trap_id_attr.trap_group = user_channel_p->trap_group_id;

    if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAILDROP_E) {
        memset(&sx_user_channel, 0, sizeof(sx_user_channel));
        sx_user_channel.type = SX_USER_CHANNEL_TYPE_FD;
        memcpy(&sx_user_channel.channel.fd, &user_channel_p->fd, sizeof(user_channel_p->fd));
        memset(&drop_monitor_channel, 0, sizeof(drop_monitor_channel));
        drop_monitor_channel.type = SX_USER_CHANNEL_TYPE_DROP_MONITOR;
    }

    for (i = 0; i < (int)(group_item_p->trap_id_num); ++i) {
        trap_id_set = FALSE;
        user_channel_registered = FALSE;
        wjh_db_trap_id_attr_get(group_item_p->trap_ids[i].trap_id, &trap_id_attr_p);

        /* For the trap only mapping to one drop reason, check the severity and then skip trap set if it's already set to the same */
        if ((group_item_p->drop_reason_group != WJH_DROP_REASON_GROUP_BUFFER_E) &&
            (group_item_p->drop_reason_group != WJH_DROP_REASON_GROUP_ROCE_E)) {
            if (!WJH_SEVERITY_CHECK(severity_bits, trap_id_attr_p->drop_reason->severity)) {
                continue;
            }
        }

        trap_key.trap_key_attr.trap_id = group_item_p->trap_ids[i].trap_id;

        if (WJH_IS_MIRROR_AGENT_TRAP(trap_key.trap_key_attr.trap_id)) {
            if (action == SX_TRAP_ACTION_EXCEPTION_TRAP) {
                trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU;
            } else {
                trap_attr.attr.trap_id_attr.trap_action = WJH_MIRROR_AGENT_TRAP_DEFAULT_ACTION;
            }
        } else {
            trap_attr.attr.trap_id_attr.trap_action = action;
        }

        sdk_rc = sx_api_host_ifc_trap_id_ext_set(sx_api_handle_s,
                                                 cmd,
                                                 &trap_key,
                                                 &trap_attr);
        if (SX_CHECK_FAIL(sdk_rc)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set trap ID (%u) to trap group (%u) with trap action (%u), error: %s\n",
                        group_item_p->trap_ids[i].trap_id,
                        user_channel_p->trap_group_id,
                        trap_attr.attr.trap_id_attr.trap_action,
                        sx_status_str(sdk_rc));
            goto out;
        }
        if (cmd == SX_ACCESS_CMD_SET) {
            trap_id_set = TRUE;
        }

        if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAILDROP_E) {
            sdk_rc = sx_api_host_ifc_trap_id_register_set(sx_api_handle_s, register_cmd, 0,
                                                          group_item_p->trap_ids[i].trap_id, &sx_user_channel);
            if (SX_CHECK_FAIL(sdk_rc)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to register trap ID (%u) to user channel (id: %u), error: %s\n",
                            group_item_p->trap_ids[i].trap_id, user_channel_p->channel_id, sx_status_str(sdk_rc));
                goto out;
            }
            if (register_cmd == SX_ACCESS_CMD_REGISTER) {
                user_channel_registered = TRUE;
            }

            sdk_rc = sx_api_host_ifc_trap_id_register_set(sx_api_handle_s, register_cmd, 0,
                                                          group_item_p->trap_ids[i].trap_id, &drop_monitor_channel);
            if (SX_CHECK_FAIL(sdk_rc)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to register trap ID (%u) to drop monitor user channel, error: %s\n",
                            group_item_p->trap_ids[i].trap_id, sx_status_str(sdk_rc));
                goto out;
            }
        }

        trap_id_attr_p->drop_reason->enabled = (action == SX_TRAP_ACTION_EXCEPTION_TRAP) ? TRUE : FALSE;
    }

out:
    if (WJH_CHECK_FAIL(err)) {
        if (user_channel_registered) {
            sdk_rb_err = sx_api_host_ifc_trap_id_register_set(sx_api_handle_s, SX_ACCESS_CMD_DEREGISTER, 0,
                                                              group_item_p->trap_ids[i].trap_id, &sx_user_channel);
            if (SX_CHECK_FAIL(sdk_rb_err)) {
                WJH_LOG_ERR("Failed to deregister trap ID (%u) from user channel, error: %s\n",
                            group_item_p->trap_ids[i].trap_id, sx_status_str(sdk_rb_err));
            }
        }

        if (trap_id_set) {
            sdk_rb_err = sx_api_host_ifc_trap_id_ext_set(sx_api_handle_s,
                                                         SX_ACCESS_CMD_UNSET,
                                                         &trap_key,
                                                         &trap_attr);
            if (SX_CHECK_FAIL(sdk_rb_err)) {
                WJH_LOG_ERR("Failed to unset trap ID (%u) from trap group (%u) with trap action (%u), error: %s\n",
                            group_item_p->trap_ids[i].trap_id,
                            user_channel_p->trap_group_id,
                            trap_attr.attr.trap_id_attr.trap_action,
                            sx_status_str(sdk_rc));
            }
        }

        for (i--; i >= 0; i--) {
            wjh_db_trap_id_attr_get(group_item_p->trap_ids[i].trap_id, &trap_id_attr_p);

            /* For the trap only mapping to one drop reason, check the severity and then skip trap set if it's already set to the same */
            if ((group_item_p->drop_reason_group != WJH_DROP_REASON_GROUP_BUFFER_E) &&
                (group_item_p->drop_reason_group != WJH_DROP_REASON_GROUP_ROCE_E)) {
                if (!WJH_SEVERITY_CHECK(severity_bits, trap_id_attr_p->drop_reason->severity)) {
                    continue;
                }
            }

            trap_key.trap_key_attr.trap_id = group_item_p->trap_ids[i].trap_id;

            if (WJH_IS_MIRROR_AGENT_TRAP(trap_key.trap_key_attr.trap_id)) {
                trap_attr.attr.trap_id_attr.trap_action = WJH_MIRROR_AGENT_TRAP_DEFAULT_ACTION;
            } else {
                trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_SET_FW_DEFAULT;
            }

            if (SX_ACCESS_CMD_SET) {
                sdk_rb_err = sx_api_host_ifc_trap_id_ext_set(sx_api_handle_s,
                                                             SX_ACCESS_CMD_UNSET,
                                                             &trap_key,
                                                             &trap_attr);
                if (SX_CHECK_FAIL(sdk_rb_err)) {
                    WJH_LOG_ERR("Failed to unset trap ID (%u) from trap group (%u) with trap action (%u), error: %s\n",
                                group_item_p->trap_ids[i].trap_id,
                                user_channel_p->trap_group_id,
                                trap_attr.attr.trap_id_attr.trap_action,
                                sx_status_str(sdk_rc));
                }
            }

            if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAILDROP_E) {
                if (register_cmd == SX_ACCESS_CMD_REGISTER) {
                    sdk_rb_err = sx_api_host_ifc_trap_id_register_set(sx_api_handle_s,
                                                                      SX_ACCESS_CMD_DEREGISTER,
                                                                      0,
                                                                      group_item_p->trap_ids[i].trap_id,
                                                                      &drop_monitor_channel);
                    if (SX_CHECK_FAIL(sdk_rb_err)) {
                        WJH_LOG_ERR("Failed to deregister trap ID (%u) from drop monitor user channel, error: %s\n",
                                    group_item_p->trap_ids[i].trap_id, sx_status_str(sdk_rb_err));
                    }

                    sdk_rb_err = sx_api_host_ifc_trap_id_register_set(sx_api_handle_s,
                                                                      SX_ACCESS_CMD_DEREGISTER,
                                                                      0,
                                                                      group_item_p->trap_ids[i].trap_id,
                                                                      &sx_user_channel);
                    if (SX_CHECK_FAIL(sdk_rb_err)) {
                        WJH_LOG_ERR("Failed to deregister trap ID (%u) from user channel, error: %s\n",
                                    group_item_p->trap_ids[i].trap_id, sx_status_str(sdk_rb_err));
                    }
                }
            }
        }
    }

    return err;
}

static wjh_status_t __wjh_drop_reason_group_traps_update(wjh_drop_reason_group_record_t *group_item_p,
                                                         sx_trap_action_t                trap_action)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    sx_status_t                sdk_rc = SX_STATUS_SUCCESS;
    sx_host_ifc_trap_key_t     trap_key;
    sx_host_ifc_trap_attr_t    trap_attr;
    wjh_trap_id_attr_t        *trap_id_attr_p = NULL;
    uint32_t                   i = 0;
    wjh_user_channel_record_t *user_channel_p = NULL;
    sx_user_channel_t          sx_user_channel;
    sx_user_channel_t          drop_monitor_channel;
    boolean_t                  match = FALSE;
    sx_access_cmd_t            cmd = SX_ACCESS_CMD_NONE;
    sx_access_cmd_t            register_cmd = SX_ACCESS_CMD_NONE;

    wjh_db_user_channel_get(group_item_p->channel_id, &user_channel_p);

    memset(&trap_key, 0, sizeof(sx_host_ifc_trap_key_t));
    memset(&trap_attr, 0, sizeof(sx_host_ifc_trap_attr_t));

    if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAILDROP_E) {
        memset(&sx_user_channel, 0, sizeof(sx_user_channel));
        sx_user_channel.type = SX_USER_CHANNEL_TYPE_FD;
        memcpy(&sx_user_channel.channel.fd, &user_channel_p->fd, sizeof(user_channel_p->fd));
        memset(&drop_monitor_channel, 0, sizeof(drop_monitor_channel));
        drop_monitor_channel.type = SX_USER_CHANNEL_TYPE_DROP_MONITOR;
    }

    trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E;
    trap_attr.attr.trap_id_attr.trap_group = user_channel_p->trap_group_id;

    for (i = 0; i < group_item_p->trap_id_num; ++i) {
        wjh_db_trap_id_attr_get(group_item_p->trap_ids[i].trap_id, &trap_id_attr_p);
        trap_key.trap_key_attr.trap_id = group_item_p->trap_ids[i].trap_id;

        trap_key.trap_key_attr.trap_id = group_item_p->trap_ids[i].trap_id;

        switch (group_item_p->drop_reason_group) {
        case WJH_DROP_REASON_GROUP_BUFFER_E:
            if (trap_action == SX_TRAP_ACTION_IGNORE) {
                continue;
            }
            trap_attr.attr.trap_id_attr.trap_action = trap_action;
            if (WJH_IS_MIRROR_AGENT_TRAP(trap_key.trap_key_attr.trap_id)) {
                if (trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP) {
                    trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_TRAP_2_CPU;
                } else {
                    trap_attr.attr.trap_id_attr.trap_action = WJH_MIRROR_AGENT_TRAP_DEFAULT_ACTION;
                }
            }
            break;

        case WJH_DROP_REASON_GROUP_ROCE_E:
            if (trap_action == SX_TRAP_ACTION_IGNORE) {
                continue;
            }
            trap_attr.attr.trap_id_attr.trap_action = trap_action;
            break;

        default:
            match = WJH_SEVERITY_CHECK(group_item_p->enabled_severity_bits, trap_id_attr_p->drop_reason->severity);

            if (match && (!trap_id_attr_p->drop_reason->enabled)) {
                trap_action = SX_TRAP_ACTION_EXCEPTION_TRAP;
                trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_EXCEPTION_TRAP;
                trap_id_attr_p->drop_reason->enabled = TRUE;
            } else if ((!match) && trap_id_attr_p->drop_reason->enabled) {
                trap_action = SX_TRAP_ACTION_SET_FW_DEFAULT;
                trap_attr.attr.trap_id_attr.trap_action = SX_TRAP_ACTION_SET_FW_DEFAULT;
                trap_id_attr_p->drop_reason->enabled = FALSE;
            } else {
                continue;
            }
            break;
        }

        cmd = (trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP) ? SX_ACCESS_CMD_SET : SX_ACCESS_CMD_UNSET;
        sdk_rc = sx_api_host_ifc_trap_id_ext_set(sx_api_handle_s,
                                                 cmd,
                                                 &trap_key,
                                                 &trap_attr);
        if (SX_CHECK_FAIL(sdk_rc)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set trap ID (%u) to trap group (%u) with trap action (%u), error: %s\n",
                        group_item_p->trap_ids[i].trap_id,
                        user_channel_p->trap_group_id,
                        trap_attr.attr.trap_id_attr.trap_action,
                        sx_status_str(sdk_rc));
            goto out;
        }

        if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAILDROP_E) {
            register_cmd =
                (trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP) ? SX_ACCESS_CMD_REGISTER : SX_ACCESS_CMD_DEREGISTER;
            sdk_rc = sx_api_host_ifc_trap_id_register_set(sx_api_handle_s, register_cmd, 0,
                                                          group_item_p->trap_ids[i].trap_id, &sx_user_channel);
            if (SX_CHECK_FAIL(sdk_rc)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to register trap ID (%u) to user channel (id: %u), error: %s\n",
                            group_item_p->trap_ids[i].trap_id, user_channel_p->channel_id, sx_status_str(sdk_rc));
                goto out;
            }

            sdk_rc = sx_api_host_ifc_trap_id_register_set(sx_api_handle_s, register_cmd, 0,
                                                          group_item_p->trap_ids[i].trap_id, &drop_monitor_channel);
            if (SX_CHECK_FAIL(sdk_rc)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to register trap ID (%u) to drop monitor user channel, error: %s\n",
                            group_item_p->trap_ids[i].trap_id, sx_status_str(sdk_rc));
                goto out;
            }
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_roce_drop_reason_trap_set(uint8_t reason_bits, boolean_t trap)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_roce_drop_acl_rules_set_cb == NULL)) {
        WJH_LOG_ERR("Wjh lib dev specific callback not valid");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    err = wjh_dev_cb_p->wjh_roce_drop_acl_rules_set_cb(sx_api_handle_s, reason_bits, trap);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific cb roce acl rule set failed, err=%u\n", err);
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_drop_reason_enable_set(wjh_drop_reason_group_record_t *group_item_p,
                                                 uint8_t                         drop_reason_bits,
                                                 boolean_t                       enable)
{
    wjh_status_t                err = WJH_STATUS_SUCCESS;
    sx_lib_adviser_event_type_e event_type = SX_LIB_ADVISER_EVENT_NONE_E;

    if (drop_reason_bits) {
        switch (group_item_p->drop_reason_group) {
        case WJH_DROP_REASON_GROUP_BUFFER_E:
            event_type = enable ? SX_LIB_ADVISER_PORT_ADDED_E : SX_LIB_ADVISER_PORT_DELETED_E;
            err = __bind_unbind_buffer_drops_all_ports(event_type, drop_reason_bits);
            if (err != WJH_STATUS_SUCCESS) {
                WJH_LOG_ERR("Failed to bind all ports to the span session, err: %u\n", err);
                goto out;
            }
            break;

        case WJH_DROP_REASON_GROUP_ROCE_E:
            err = __wjh_roce_drop_reason_trap_set(drop_reason_bits, enable);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to enable roce drop reasons.\n");
                goto out;
            }
            break;

        default:
            break;
        }
        if (enable) {
            group_item_p->enabled_drop_reason_bits |= drop_reason_bits;
        } else {
            group_item_p->enabled_drop_reason_bits &= (~drop_reason_bits);
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_buffer_drop_group_span_session_bind_unbind(boolean_t bind)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p != NULL) && (wjh_dev_cb_p->wjh_buffer_drop_span_session_bind_unbind_cb != NULL)) {
        err = wjh_dev_cb_p->wjh_buffer_drop_span_session_bind_unbind_cb(sx_api_handle_s, bind);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to set span analyzer for buffer drop.\n");
            goto out;
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_drop_reason_set_by_severity(wjh_drop_reason_group_record_t *group_item_p,
                                                      uint8_t                         severity_bits,
                                                      boolean_t                       enable,
                                                      sx_trap_action_t               *trap_action_p)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    uint32_t                drop_reason_id_min = 0;
    uint32_t                drop_reason_num = 0;
    uint32_t                i = 0;
    wjh_drop_reason_item_t *drop_reason_item_p = NULL;
    uint8_t                 drop_reason_bits = 0;
    uint8_t                 old_enabled_drop_reason_bits = group_item_p->enabled_drop_reason_bits;
    uint8_t                 new_enabled_drop_reason_bits = 0;
    boolean_t               span_session_bound = FALSE;
    boolean_t               drop_reason_enabled = FALSE;
    wjh_status_t            rb_err = WJH_STATUS_SUCCESS;

    *trap_action_p = SX_TRAP_ACTION_IGNORE;

    switch (group_item_p->drop_reason_group) {
    case WJH_DROP_REASON_GROUP_BUFFER_E:
        drop_reason_id_min = WJH_BUFFER_DROP_REASON_ID_MIN;
        drop_reason_num = WJH_BUFFER_DROP_REASON_NUM;
        break;

    case WJH_DROP_REASON_GROUP_ROCE_E:
        drop_reason_id_min = WJH_ROCE_DROP_REASON_ID_MIN;
        drop_reason_num = WJH_ROCE_DROP_REASON_NUM;
        break;

    default:
        WJH_LOG_NTC("This function is not needed for drop group %d.\n", group_item_p->drop_reason_group);
        goto out;
        break;
    }

    for (i = drop_reason_id_min; i < (drop_reason_id_min + drop_reason_num); i++) {
        wjh_db_get_drop_reason_item_by_reason(i, &drop_reason_item_p);
        if (WJH_SEVERITY_CHECK(severity_bits, drop_reason_item_p->severity)) {
            drop_reason_item_p->enabled = enable;
            WJH_DROP_REASON_SET(drop_reason_bits, drop_reason_item_p->id, drop_reason_id_min);
        }
    }

    if (enable) {
        new_enabled_drop_reason_bits = old_enabled_drop_reason_bits | drop_reason_bits;
    } else {
        new_enabled_drop_reason_bits = old_enabled_drop_reason_bits & (~drop_reason_bits);
    }

    if ((old_enabled_drop_reason_bits > 0) && (new_enabled_drop_reason_bits == 0)) {
        *trap_action_p = SX_TRAP_ACTION_SET_FW_DEFAULT;
    } else if ((old_enabled_drop_reason_bits == 0) && (new_enabled_drop_reason_bits > 0)) {
        *trap_action_p = SX_TRAP_ACTION_EXCEPTION_TRAP;
    }

    if ((group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) &&
        (*trap_action_p == SX_TRAP_ACTION_EXCEPTION_TRAP)) {
        err = __wjh_buffer_drop_group_span_session_bind_unbind(TRUE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to bind span session for buffer drop reason group.\n");
            goto out;
        }
        span_session_bound = TRUE;
    }

    err = __wjh_drop_reason_enable_set(group_item_p, drop_reason_bits, enable);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to set drop reason bits 0x%x on group %u to state %d.\n",
                    drop_reason_bits, group_item_p->drop_reason_group, enable);
        goto out;
    }
    if (enable) {
        drop_reason_enabled = TRUE;
    }

    if ((group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) &&
        (*trap_action_p == SX_TRAP_ACTION_SET_FW_DEFAULT)) {
        err = __wjh_buffer_drop_group_span_session_bind_unbind(FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to unbind span session for buffer drop reason group.\n");
            goto out;
        }
    }

out:
    if (WJH_CHECK_FAIL(err)) {
        if (drop_reason_enabled) {
            rb_err = __wjh_drop_reason_enable_set(group_item_p, drop_reason_bits, FALSE);
            if (WJH_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to set drop reason bits 0x%x on group %u to state %d.\n",
                            drop_reason_bits, group_item_p->drop_reason_group, FALSE);
            }
        }

        if (span_session_bound) {
            rb_err = __wjh_buffer_drop_group_span_session_bind_unbind(FALSE);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to unbind span session for buffer drop reason group, err: %d\n", rb_err);
            }
        }
    }

    return err;
}

static wjh_status_t __wjh_drop_reason_update(wjh_drop_reason_group_record_t *group_item_p,
                                             sx_trap_action_t               *trap_action_p)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    uint32_t                drop_reason_id_min = 0;
    uint32_t                drop_reason_num = 0;
    uint32_t                i = 0;
    wjh_drop_reason_item_t *drop_reason_item_p = NULL;
    uint8_t                 enable_drop_reason_bits = 0;
    uint8_t                 disable_drop_reason_bits = 0;
    boolean_t               match = FALSE;
    uint8_t                 old_enabled_drop_reason_bits = group_item_p->enabled_drop_reason_bits;
    uint8_t                 new_enabled_drop_reason_bits = 0;

    *trap_action_p = SX_TRAP_ACTION_IGNORE;

    switch (group_item_p->drop_reason_group) {
    case WJH_DROP_REASON_GROUP_BUFFER_E:
        drop_reason_id_min = WJH_BUFFER_DROP_REASON_ID_MIN;
        drop_reason_num = WJH_BUFFER_DROP_REASON_NUM;
        break;

    case WJH_DROP_REASON_GROUP_ROCE_E:
        drop_reason_id_min = WJH_ROCE_DROP_REASON_ID_MIN;
        drop_reason_num = WJH_ROCE_DROP_REASON_NUM;
        break;

    default:
        WJH_LOG_NTC("This function is not needed for drop group %d.\n", group_item_p->drop_reason_group);
        goto out;
        break;
    }

    for (i = drop_reason_id_min; i < (drop_reason_id_min + drop_reason_num); i++) {
        wjh_db_get_drop_reason_item_by_reason(i, &drop_reason_item_p);
        match = WJH_SEVERITY_CHECK(group_item_p->enabled_severity_bits, drop_reason_item_p->severity);
        if (match && (!drop_reason_item_p->enabled)) {
            WJH_DROP_REASON_SET(enable_drop_reason_bits, drop_reason_item_p->id, drop_reason_id_min);
            drop_reason_item_p->enabled = TRUE;
        } else if ((!match) && drop_reason_item_p->enabled) {
            WJH_DROP_REASON_SET(disable_drop_reason_bits, drop_reason_item_p->id, drop_reason_id_min);
            drop_reason_item_p->enabled = FALSE;
        }
    }

    new_enabled_drop_reason_bits = old_enabled_drop_reason_bits | enable_drop_reason_bits;
    new_enabled_drop_reason_bits = new_enabled_drop_reason_bits & (~disable_drop_reason_bits);

    if ((old_enabled_drop_reason_bits > 0) && (new_enabled_drop_reason_bits == 0)) {
        *trap_action_p = SX_TRAP_ACTION_SET_FW_DEFAULT;
    } else if ((old_enabled_drop_reason_bits == 0) && (new_enabled_drop_reason_bits > 0)) {
        *trap_action_p = SX_TRAP_ACTION_EXCEPTION_TRAP;
    }

    if ((group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) &&
        (*trap_action_p == SX_TRAP_ACTION_EXCEPTION_TRAP)) {
        err = __wjh_buffer_drop_group_span_session_bind_unbind(TRUE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to bind span session for buffer drop reason group.\n");
            goto out;
        }
    }

    err = __wjh_drop_reason_enable_set(group_item_p, enable_drop_reason_bits, TRUE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to set drop reason bits 0x%x on group %u to enable.\n",
                    enable_drop_reason_bits, group_item_p->drop_reason_group);
        goto out;
    }

    err = __wjh_drop_reason_enable_set(group_item_p, disable_drop_reason_bits, FALSE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to set drop reason bits 0x%x on group %u to disable.\n",
                    disable_drop_reason_bits, group_item_p->drop_reason_group);
        goto out;
    }

    if ((group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) &&
        (*trap_action_p == SX_TRAP_ACTION_SET_FW_DEFAULT)) {
        err = __wjh_buffer_drop_group_span_session_bind_unbind(FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to unbind span session for buffer drop reason group.\n");
            goto out;
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_buffer_drop_group_span_session_set(boolean_t enable)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_buffer_drop_span_session_set_cb == NULL)) {
        WJH_LOG_ERR("Wjh lib dev specific callback not valid");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    err = wjh_dev_cb_p->wjh_buffer_drop_span_session_set_cb(sx_api_handle_s, enable);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to set span analyzer for buffer drop.\n");
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_drop_reason_group_enable_set(wjh_user_channel_record_t      *user_channel_p,
                                                       wjh_drop_reason_group_record_t *group_item_p,
                                                       boolean_t                       enable,
                                                       uint8_t                         severity_bits)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_item_t *drop_reason_item_p = NULL;
    sx_trap_action_t        trap_action = enable ? SX_TRAP_ACTION_EXCEPTION_TRAP : SX_TRAP_ACTION_SET_FW_DEFAULT;
    wjh_status_t            rb_err = WJH_STATUS_SUCCESS;
    boolean_t               severity_enabled = FALSE;
    boolean_t               traps_set = FALSE;
    boolean_t               span_session_set = FALSE;

    switch (group_item_p->drop_reason_group) {
    case WJH_DROP_REASON_GROUP_L1_E:
        /* Nothing to do for L1 drop reason group */
        goto out;
        break;

    case WJH_DROP_REASON_GROUP_BUFFER_E:
    /* Fall through */
    case WJH_DROP_REASON_GROUP_ROCE_E:
        err = __wjh_drop_reason_set_by_severity(group_item_p, severity_bits, enable, &trap_action);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to enable drop reasons for drop group %d.\n", group_item_p->drop_reason_group);
            goto out;
        }
        if (enable) {
            severity_enabled = TRUE;
        }
        break;

    default:
        break;
    }

    if ((group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) &&
        (trap_action == SX_TRAP_ACTION_SET_FW_DEFAULT)) {
        err = __wjh_buffer_drop_group_span_session_set(FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to disable buffer drop group span session.\n");
            goto out;
        }
    }

    if (((trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP) ||
         (trap_action == SX_TRAP_ACTION_SET_FW_DEFAULT))) {
        err = __wjh_drop_reason_group_traps_set(user_channel_p,
                                                group_item_p,
                                                severity_bits,
                                                trap_action);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to set traps.\n");
            goto out;
        }
        if (trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP) {
            traps_set = TRUE;
        }
    }

    if ((group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) &&
        (trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP)) {
        err = __wjh_buffer_drop_group_span_session_set(TRUE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to enable buffer drop group span session.\n");
            goto out;
        }
        span_session_set = TRUE;
    }

    /* Have to enable ACL drop after acl trap id associated to wjh trap group, to avoid unexpected behavior */
    if (group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_ACL_E) {
        /* All ACL drop reason use same severity */
        wjh_db_get_drop_reason_item(WJH_ACL_DROP_REASON_INDEX_MIN, &drop_reason_item_p);
        if (WJH_SEVERITY_CHECK(severity_bits, drop_reason_item_p->severity)) {
            err = __wjh_acl_drop_reason_group_disable(!enable);
            if (err != WJH_STATUS_SUCCESS) {
                WJH_LOG_ERR("Failed to enable monitor on acl drop reason group.\n");
                goto out;
            }
            drop_reason_item_p->enabled = enable;
        }
    }

out:
    if (WJH_CHECK_FAIL(err)) {
        if (span_session_set) {
            rb_err = __wjh_buffer_drop_group_span_session_set(FALSE);
            if (WJH_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to disable buffer drop group span session, err: %d\n", rb_err);
            }
        }

        if (traps_set) {
            rb_err = __wjh_drop_reason_group_traps_set(user_channel_p,
                                                       group_item_p,
                                                       severity_bits,
                                                       SX_TRAP_ACTION_SET_FW_DEFAULT);
            if (WJH_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to set the drop reason group traps to FW default, err: %d\n", rb_err);
            }
        }

        if (severity_enabled) {
            rb_err = __wjh_drop_reason_set_by_severity(group_item_p, severity_bits, FALSE, &trap_action);
            if (WJH_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to disable drop reasons for drop group %d, err: %d\n",
                            group_item_p->drop_reason_group,
                            rb_err);
            }
        }
    }
    return err;
}

wjh_status_t wjh_drop_reason_group_enable_sdk(wjh_user_channel_record_t      *user_channel_p,
                                              wjh_drop_reason_group_record_t *group_item_p,
                                              uint8_t                         severity_bits)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    boolean_t    drop_reason_group_enabled = FALSE;
    wjh_status_t rb_err = WJH_STATUS_SUCCESS;

#ifdef WJH_EBPF_PRESENT
    boolean_t bpf_prog_attached = FALSE;
#endif

    err = __wjh_drop_reason_group_enable_set(user_channel_p, group_item_p, TRUE, severity_bits);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to enable severity bits 0x%x on drop reason group %d\n",
                    severity_bits,
                    group_item_p->drop_reason_group);
        goto out;
    }
    drop_reason_group_enabled = TRUE;

#ifdef WJH_EBPF_PRESENT
    if ((user_channel_p->channel_type != WJH_USER_CHANNEL_AGGREGATE_E) &&
        (user_channel_p->channel_type != WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) {
        goto out;
    }

    if ((__wjh_is_any_drop_reason_enabled(group_item_p)) &&
        (!group_item_p->aggregation_ebpf_prog_fd_attached)) {
        err = __wjh_agg_bpf_prog_attach_detach(user_channel_p, group_item_p, TRUE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_agg_bpf_prog_attach_detach failed, err = %d\n", err);
            goto out;
        }
        bpf_prog_attached = TRUE;

        err = __wjh_monitor_rdq_trace_points_enable();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_monitor_rdq_trace_points_enable failed, err: %d\n", err);
            goto out;
        }
    }
#endif

out:
    if (WJH_CHECK_FAIL(err)) {
#ifdef WJH_EBPF_PRESENT
        if (bpf_prog_attached) {
            rb_err = __wjh_agg_bpf_prog_attach_detach(user_channel_p, group_item_p, FALSE);
            if (WJH_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to detach BPF program, err: %d\n", rb_err);
            }
        }
#endif

        if (drop_reason_group_enabled) {
            rb_err = __wjh_drop_reason_group_enable_set(user_channel_p, group_item_p, FALSE, severity_bits);
            if (WJH_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to disable severity bits 0x%x on drop reason group %d, err: %d\n",
                            severity_bits,
                            group_item_p->drop_reason_group,
                            rb_err);
            }
        }
    }
    return err;
}

wjh_status_t wjh_drop_reason_group_disable_sdk(wjh_user_channel_record_t      *user_channel_p,
                                               wjh_drop_reason_group_record_t *group_item_p,
                                               uint8_t                         severity_bits)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    err = __wjh_drop_reason_group_enable_set(user_channel_p, group_item_p, FALSE, severity_bits);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to enable severity bits 0x%x on drop reason group %d\n",
                    severity_bits,
                    group_item_p->drop_reason_group);
        goto out;
    }

#ifdef WJH_EBPF_PRESENT
    if ((user_channel_p->channel_type != WJH_USER_CHANNEL_AGGREGATE_E) &&
        (user_channel_p->channel_type != WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E)) {
        goto out;
    }

    if ((!__wjh_is_any_drop_reason_enabled(group_item_p)) &&
        (group_item_p->aggregation_ebpf_prog_fd_attached)) {
        err = __wjh_agg_bpf_prog_attach_detach(user_channel_p, group_item_p, FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_agg_bpf_prog_attach_detach failed, err = %d\n", err);
            goto out;
        }

        err = __wjh_monitor_rdq_trace_points_disable();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_monitor_rdq_trace_points_disable failed, err: %d\n", err);
            goto out;
        }
    }
#endif

out:
    return err;
}

wjh_status_t wjh_drop_reason_group_update_sdk(wjh_drop_reason_group_record_t *group_item_p)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_item_t *drop_reason_item_p = NULL;
    boolean_t               match = FALSE;
    sx_trap_action_t        trap_action = SX_TRAP_ACTION_IGNORE;

    switch (group_item_p->drop_reason_group) {
    case WJH_DROP_REASON_GROUP_L1_E:
        /* Nothing to do for L1 drop reason group */
        goto out;
        break;

    case WJH_DROP_REASON_GROUP_ACL_E:
        /* All ACL drop reason use same severity */
        wjh_db_get_drop_reason_item(WJH_ACL_DROP_REASON_INDEX_MIN, &drop_reason_item_p);
        match = WJH_SEVERITY_CHECK(group_item_p->enabled_severity_bits, drop_reason_item_p->severity);
        if (match && (!drop_reason_item_p->enabled)) {
            err = __wjh_acl_drop_reason_group_disable(FALSE);
        } else if ((!match) && drop_reason_item_p->enabled) {
            err = __wjh_acl_drop_reason_group_disable(TRUE);
        }
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to disable monitor on acl drop reason group.\n");
            goto out;
        }
        break;

    case WJH_DROP_REASON_GROUP_BUFFER_E:
    /* Fall through */
    case WJH_DROP_REASON_GROUP_ROCE_E:
        err = __wjh_drop_reason_update(group_item_p, &trap_action);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to update drop reason group %d.\n", group_item_p->drop_reason_group);
            goto out;
        }
        if (trap_action == SX_TRAP_ACTION_IGNORE) {
            goto out;
        }
        break;

    default:
        break;
    }

    if ((group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) &&
        (trap_action == SX_TRAP_ACTION_SET_FW_DEFAULT)) {
        err = __wjh_buffer_drop_group_span_session_set(FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to update buffer drop group span configuration for trap action %d.\n", trap_action);
            goto out;
        }
    }

    err = __wjh_drop_reason_group_traps_update(group_item_p, trap_action);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to update traps for drop reason group %d.\n", group_item_p->drop_reason_group);
        goto out;
    }

    if ((group_item_p->drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) &&
        (trap_action == SX_TRAP_ACTION_EXCEPTION_TRAP)) {
        err = __wjh_buffer_drop_group_span_session_set(TRUE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to update buffer drop group span configuration for trap action %d.\n", trap_action);
            goto out;
        }
    }

out:
    return err;
}

wjh_status_t wjh_user_channel_validate_sdk(wjh_user_channel_type_e channel_type)
{
    wjh_status_t     err = WJH_STATUS_SUCCESS;
    wjh_chip_types_t chip_type;

    if (channel_type == WJH_USER_CHANNEL_TAC_E) {
        err = wjh_db_get_chip_type(&chip_type);
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("wjh db get chip type failed, err: %u\n", err);
            return err;
        }

        if (chip_type < SXD_CHIP_TYPE_SPECTRUM4) {
            return WJH_STATUS_UNSUPPORTED;
        }
    }

    return err;
}

wjh_status_t wjh_counter_dropped_packets_get_sdk(wjh_user_channel_record_t *user_channel_p,
                                                 uint64_t                  *dropped_packets_p,
                                                 uint8_t                    clear)
{
    wjh_status_t                  err = WJH_STATUS_SUCCESS;
    sx_host_ifc_trap_group_key_t  sx_trap_group_key;
    sx_host_ifc_trap_group_stat_t sx_trap_group_stat;
    sx_status_t                   sdk_rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t               cmd = clear ? SX_ACCESS_CMD_READ_CLEAR : SX_ACCESS_CMD_READ;
    sx_tele_tac_statistics_t      tac_stat;
    uint32_t                      i;

    if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAILDROP_E) {
        goto out;
    }
    if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAC_E) {
        sdk_rc = sx_api_tele_tac_statistics_get(sx_api_handle_s, cmd, &tac_stat);
        if (SX_CHECK_FAIL(sdk_rc)) {
            WJH_LOG_ERR("Failed to get tac stat for trap group (%u), error: %s\n",
                        sx_trap_group_key.group_key_attr.trap_group_id, sx_status_str(sdk_rc));
            err = WJH_STATUS_ERROR;
            goto out;
        }
        for (i = 0; i < tac_stat.trap_group_tac_statistics_cnt; i++) {
            if (tac_stat.trap_group_tac_statistics[i].trap_group == user_channel_p->hw_trap_group) {
                *dropped_packets_p = tac_stat.trap_group_tac_statistics[i].tac_ingress_drop;
                break;
            }
        }

        if (i == tac_stat.trap_group_tac_statistics_cnt) {
            WJH_LOG_ERR("Failed to get tac stat for trap group (%u), error: %s\n",
                        user_channel_p->hw_trap_group, sx_status_str(sdk_rc));
            err = WJH_STATUS_ERROR;
            goto out;
        }
    } else {
        memset(&sx_trap_group_key, 0, sizeof(sx_trap_group_key));
        sx_trap_group_key.type = HOST_IFC_TRAP_GROUP_KEY_GROUP_ID_E;
        sx_trap_group_key.group_key_attr.trap_group_id = user_channel_p->trap_group_id;
        memset(&sx_trap_group_stat, 0, sizeof(sx_trap_group_stat));

        sdk_rc = sx_api_host_ifc_trap_group_stat_get(sx_api_handle_s,
                                                     cmd,
                                                     &sx_trap_group_key,
                                                     &sx_trap_group_stat);
        if (SX_CHECK_FAIL(sdk_rc)) {
            WJH_LOG_ERR("Failed to get stat for trap group (%u), error: %s\n",
                        sx_trap_group_key.group_key_attr.trap_group_id, sx_status_str(sdk_rc));
            err = WJH_STATUS_ERROR;
            goto out;
        }

        *dropped_packets_p = sx_trap_group_stat.data.total_cnt;
    }
out:
    return err;
}

wjh_status_t wjh_resources_post_init_clean_up_sdk()
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    err = __wjh_buffer_drop_post_init_resource_clean_up();
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to cleanup post init buffer drop \n");
        goto out;
    }
out:
    return err;
}

wjh_status_t wjh_resources_pre_init_clean_up_sdk(wjh_drop_reason_group_shm_data_t *drop_reason_shm_data_p,
                                                 wjh_user_channel_shm_data_t      *user_channel_shm_data_p)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    sx_status_t                sdk_err = SX_STATUS_SUCCESS;
    sx_trap_group_t            trap_group;
    sx_policer_id_t            policer_ids[WJH_USER_CHANNEL_MAX_NUM];
    uint32_t                   policer_id_cnt = 0;
    wjh_user_channel_id_t      user_channel_id = 0;
    sx_trap_group_t            trap_groups[WJH_USER_CHANNEL_MAX_NUM];
    uint32_t                   trap_group_cnt = 0;
    sx_trap_group_attributes_t trap_group_attributes;
    sx_policer_id_t            policer_id;
    uint32_t                   i, j;
    sx_trap_id_t               trap_id;
    sx_host_ifc_trap_attr_t    trap_group_attrs[SX_TRAP_GROUP_MAX + 1];
    uint32_t                   trap_group_attr_cnt;
    sx_host_ifc_trap_key_t     trap_key;
    sx_access_cmd_t            cmd = SX_ACCESS_CMD_NONE;

    for (user_channel_id = 0; user_channel_id < WJH_USER_CHANNEL_MAX_NUM; user_channel_id++) {
        trap_group = user_channel_shm_data_p->trap_groups[user_channel_id];
        if (trap_group == WJH_TRAP_GROUP_INVALID) {
            continue;
        }
        memset(&trap_group_attributes, 0, sizeof(trap_group_attributes));
        sdk_err = sx_api_host_ifc_trap_group_get(sx_api_handle_s, 0, trap_group, &trap_group_attributes);
        if (SX_CHECK_FAIL(sdk_err)) {
            if (sdk_err == SX_STATUS_ENTRY_NOT_FOUND) {
                continue;
            }
            WJH_LOG_ERR("sx_api_host_ifc_trap_group_get failed, trap_group: %u, err: %s\n",
                        trap_group, sx_status_str(sdk_err));
            err = WJH_STATUS_ERROR;
            goto out;
        }
        trap_groups[trap_group_cnt] = trap_group;
        ++trap_group_cnt;

        sdk_err = sx_api_host_ifc_policer_bind_get(sx_api_handle_s, 0, trap_group, &policer_id);
        if (SX_CHECK_FAIL(sdk_err)) {
            if (sdk_err == SX_STATUS_ENTRY_NOT_FOUND) {
                continue;
            }
            WJH_LOG_ERR("sx_api_host_ifc_policer_bind_get failed, trap_group: %u, err: %s\n",
                        trap_group, sx_status_str(sdk_err));
            err = WJH_STATUS_ERROR;
            goto out;
        }

        for (i = 0; i < policer_id_cnt; ++i) {
            if (policer_id == policer_ids[i]) {
                break;
            }
        }
        if (i >= policer_id_cnt) {
            policer_ids[policer_id_cnt] = policer_id;
            ++policer_id_cnt;
        }

        sdk_err = sx_api_host_ifc_policer_bind_set(sx_api_handle_s, SX_ACCESS_CMD_UNBIND, 0, trap_group, policer_id);
        if (SX_CHECK_FAIL(sdk_err)) {
            WJH_LOG_ERR("sx_api_host_ifc_policer_bind_set failed, trap_group: %u, err: %s\n",
                        trap_group, sx_status_str(sdk_err));
            err = WJH_STATUS_ERROR;
            goto out;
        }
    }

    for (trap_id = SX_TRAP_ID_MIN; trap_id <= SX_TRAP_ID_MAX; trap_id++) {
        memset(trap_group_attrs, 0, sizeof(trap_group_attrs));
        trap_key.type = HOST_IFC_TRAP_KEY_TRAP_ID_E;
        trap_key.trap_key_attr.trap_id = trap_id;
        trap_group_attr_cnt = SX_TRAP_GROUP_MAX + 1;
        sdk_err = sx_api_host_ifc_trap_id_ext_get(sx_api_handle_s, SX_ACCESS_CMD_GET, &trap_key,
                                                  trap_group_attrs, &trap_group_attr_cnt);
        if (SX_CHECK_FAIL(sdk_err)) {
            WJH_LOG_ERR("sx_api_host_ifc_trap_id_ext_get failed, trap_id: %u, err: %s\n",
                        trap_id, sx_status_str(sdk_err));
            err = WJH_STATUS_ERROR;
            goto out;
        }

        for (i = 0; i < trap_group_attr_cnt; i++) {
            trap_group = trap_group_attrs[i].attr.trap_id_attr.trap_group;
            for (j = 0; j < trap_group_cnt; j++) {
                if (trap_group == trap_groups[j]) {
                    sdk_err = sx_api_host_ifc_trap_id_ext_set(sx_api_handle_s, SX_ACCESS_CMD_UNSET,
                                                              &trap_key, &trap_group_attrs[i]);
                    if (SX_CHECK_FAIL(sdk_err)) {
                        WJH_LOG_ERR("sx_api_host_ifc_trap_id_ext_set failed, trap_id: %u, err: %s\n",
                                    trap_id, sx_status_str(sdk_err));
                        err = WJH_STATUS_ERROR;
                        goto out;
                    }
                }
            }
        }
    }

    err = __wjh_acl_drop_reason_group_disable(WJH_ACL_DROP_TRAP_DISABLE_DEFAULT);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to disable monitor on acl drop reason group.\n");
        goto out;
    }

    err = __wjh_buffer_drop_pre_init_resource_clean_up(&drop_reason_shm_data_p->wjh_buffer_drop_shm_data);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to disable monitor on buffer drop reason group.\n");
        goto out;
    }

    if (wjh_init_params_g.driver_init_param.trap_group_allocate_mode == WJH_TRAP_GROUP_ALLOCATE_MODE_STATIC_E) {
        cmd = SX_ACCESS_CMD_UNSET;
    } else {
        cmd = SX_ACCESS_CMD_DESTROY;
    }
    for (i = 0; i < trap_group_cnt; i++) {
        sdk_err = sx_api_host_ifc_trap_group_ext_set(sx_api_handle_s, cmd, 0,
                                                     trap_groups[i], NULL);
        if (SX_CHECK_FAIL(sdk_err)) {
            WJH_LOG_ERR("sx_api_host_ifc_trap_group_ext_set failed, trap_group: %u, err: %s\n",
                        trap_groups[i], sx_status_str(sdk_err));
            err = WJH_STATUS_ERROR;
            goto out;
        }
    }

    for (i = 0; i < policer_id_cnt; i++) {
        err = __wjh_policer_destroy_sdk(policer_ids[i]);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_sdk_policer_destroy failed, policer_id: %" PRIu64 ", err: %d\n",
                        policer_ids[i], err);
            goto out;
        }
    }

out:
    return err;
}

wjh_status_t wjh_polling_thread_buf_create_sdk(wjh_user_channel_record_t *user_channel_p, void **buf_pp)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    switch (user_channel_p->channel_type) {
    case WJH_USER_CHANNEL_CYCLIC_E:
    case WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E:
        err = __wjh_cyclic_channel_buf_create(buf_pp);
        break;

    case WJH_USER_CHANNEL_AGGREGATE_E:
        break;

    default:
        WJH_LOG_ERR("Invalid channel type %u for polling thread\n", user_channel_p->channel_type);
        err = WJH_STATUS_ERROR;
        break;
    }

    return err;
}

wjh_status_t wjh_polling_thread_buf_destroy_sdk(wjh_user_channel_record_t *user_channel_p, void *buf_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    switch (user_channel_p->channel_type) {
    case WJH_USER_CHANNEL_CYCLIC_E:
    case WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E:
        err = __wjh_cyclic_channel_buf_destroy(buf_p);
        break;

    case WJH_USER_CHANNEL_AGGREGATE_E:
        break;

    default:
        WJH_LOG_ERR("Invalid channel type %u for polling thread\n", user_channel_p->channel_type);
        err = WJH_STATUS_ERROR;
        break;
    }

    return err;
}

wjh_status_t wjh_user_channel_process_sdk(wjh_user_channel_record_t *user_channel_p, void *buf_p,
                                          boolean_t is_pull_api)
{
    wjh_status_t                err = WJH_STATUS_SUCCESS;
    wjh_aggregation_read_mode_e agg_read_mode = user_channel_p->aggregation_read_mode;

    switch (user_channel_p->channel_type) {
    case WJH_USER_CHANNEL_CYCLIC_E:
        err = __wjh_cyclic_channel_process(user_channel_p, buf_p);
        break;

    case WJH_USER_CHANNEL_TAILDROP_E:
        err = __wjh_taildrop_channel_process(user_channel_p);
        break;

    case WJH_USER_CHANNEL_AGGREGATE_E:
        err = __wjh_aggregation_channel_process(user_channel_p, is_pull_api, agg_read_mode);
        break;

    case WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E:
        err = __wjh_cyclic_and_agg_channel_process(user_channel_p, buf_p, is_pull_api, agg_read_mode);
        break;

    default:
        WJH_LOG_ERR("Invalid channel type %u\n", user_channel_p->channel_type);
        err = WJH_STATUS_ERROR;
        break;
    }

    return err;
}

wjh_status_t wjh_user_channel_fd_get_sdk(wjh_user_channel_record_t *user_channel_p, int *fd_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    *fd_p = user_channel_p->fd.fd;

    return err;
}

static wjh_status_t __wjh_sx_lib_adviser_init()
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_lib_adviser_init_params_t sx_adviser_init_params;

    memset(&sx_adviser_init_params, 0, sizeof(sx_adviser_init_params));

    sx_adviser_init_params.logging_cb = NULL;
    sx_adviser_init_params.verbosity_level = SX_VERBOSITY_LEVEL_INFO;
    sx_adviser_init_params.trap_group_allocate_mode =
        (sx_lib_adviser_trap_group_allocate_mode_e)(wjh_init_params_g.driver_init_param.trap_group_allocate_mode);
    /* Make sure the lib adviser was not initialized already */
    if (wjh_sx_lib_adviser_refcnt == 0) {
        sx_status = sx_lib_adviser_init(sx_adviser_init_params);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to initialize SX lib adviser, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
    }
    wjh_sx_lib_adviser_refcnt++;
out:
    return err;
}

static wjh_status_t __wjh_sx_lib_adviser_deinit()
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    sx_status_t  sx_status = SX_STATUS_SUCCESS;

    /* Make sure the lib adviser is not referenced anymore */
    if (wjh_sx_lib_adviser_refcnt == 1) {
        sx_status = sx_lib_adviser_deinit();
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to deinitialize SX lib adviser, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
    }
    if (wjh_sx_lib_adviser_refcnt > 0) {
        wjh_sx_lib_adviser_refcnt--;
    }
out:
    return err;
}


static sx_status_t __wjh_buffer_drop_reason_bind_unbind(const sx_lib_adviser_event_info_t event_info,
                                                        uint8_t                           reason_bits)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    wjh_drop_reason_group_record_t *drop_reason_db_p = NULL;
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t          *wjh_dev_cb_p = NULL;
    boolean_t                       is_db_valid = TRUE;

    if ((event_info.type != SX_LIB_ADVISER_PORT_ADDED_E) &&
        (event_info.type != SX_LIB_ADVISER_PORT_DELETED_E)) {
        sx_status = SX_STATUS_ERROR;
        WJH_LOG_ERR("Wrong adviser type %s, err: %s\n",
                    sx_lib_adviser_event_type_str(event_info.type), sx_status_str(sx_status));
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(event_info.info.port_added_deleted.log_port) != SX_PORT_TYPE_NETWORK) {
        goto out;
    }

    is_db_valid = wjh_is_reason_group_db_inited(WJH_DROP_REASON_GROUP_BUFFER_E);
    if (is_db_valid == FALSE) {
        sx_status = SX_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_BUFFER_E,
                                 &drop_reason_db_p);
    if (drop_reason_db_p == NULL) {
        sx_status = SX_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason group record is not valid\n");
        goto out;
    }

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_buffer_drop_adviser_port_event_cb == NULL)) {
        WJH_LOG_ERR("Wjh lib dev specific callback not valid");
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    err = wjh_dev_cb_p->wjh_buffer_drop_adviser_port_event_cb(sx_api_handle_s, (void*)&event_info, reason_bits);
    if (WJH_CHECK_FAIL(err)) {
        sx_status = SX_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific cb span init failed, err=%u\n", err);
        goto out;
    }
out:
    return sx_status;
}

static sx_status_t __set_wjh_and_sdk_verbosity_levels(wjh_verbosity_level_t     wjh_verb,
                                                      sx_verbosity_level_t      sdk_api_verb,
                                                      sx_verbosity_level_t      sdk_module_verb,
                                                      sx_api_log_verb_set_pfn_t verb_set_pfn,
                                                      wjh_verbosity_level_t    *wjh_orig_verb_p,
                                                      sx_verbosity_level_t     *sdk_api_orig_verb_p,
                                                      sx_verbosity_level_t     *sdk_module_orig_verb_p,
                                                      sx_api_log_verb_get_pfn_t verb_get_pfn,
                                                      const char              * sdk_module_name)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    wjh_status_t          wjh_status = WJH_STATUS_SUCCESS;
    wjh_verbosity_level_t wjh_orig_verb;

    wjh_status = wjh_log_verbosity_level_get(&wjh_orig_verb);
    if (WJH_CHECK_FAIL(wjh_status)) {
        WJH_LOG_ERR("Failed to get WJH original verbosity level, err: %d\n", wjh_status);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    if (wjh_orig_verb_p != NULL) {
        *wjh_orig_verb_p = wjh_orig_verb;
    }

    if ((sdk_api_orig_verb_p != NULL) && (sdk_module_orig_verb_p != NULL) && (verb_get_pfn != NULL)) {
        sx_status = verb_get_pfn(sx_api_handle_s, SX_LOG_VERBOSITY_BOTH, sdk_module_orig_verb_p, sdk_api_orig_verb_p);
        if (SX_CHECK_FAIL(sx_status)) {
            WJH_LOG_ERR("Failed to get %s API and module original verbosity levels, err: %s\n",
                        sdk_module_name, sx_status_str(sx_status));
            goto out;
        }
    }

    wjh_status = wjh_log_verbosity_level_set(wjh_verb);
    if (WJH_CHECK_FAIL(wjh_status)) {
        WJH_LOG_ERR("Failed to set WJH LOG verbosity level to %d, err: %d\n", wjh_verb, wjh_status);
        sx_status = SX_STATUS_ERROR;
        goto out;
    }

    sx_status = verb_set_pfn(sx_api_handle_s, SX_LOG_VERBOSITY_BOTH, sdk_module_verb, sdk_api_verb);
    if (SX_CHECK_FAIL(sx_status)) {
        WJH_LOG_ERR("Failed to set %s API verbosity level to %s and module verbosity level to %s, err: %s\n",
                    sdk_module_name, SX_VERBOSITY_LEVEL_STR(sdk_api_verb), SX_VERBOSITY_LEVEL_STR(sdk_module_verb),
                    sx_status_str(sx_status));
        goto verb_set_pfn_err;
    }
    goto out;

verb_set_pfn_err:
    wjh_status = wjh_log_verbosity_level_set(wjh_orig_verb);
    if (WJH_CHECK_FAIL(wjh_status)) {
        WJH_LOG_ERR("Failed to set WJH LOG verbosity level to %d, err: %d\n", wjh_orig_verb, wjh_status);
    }

out:
    return sx_status;
}

/*
 * The following function is provided to SX lib Adviser as a CB that will be
 * called when a port is added/removed.
 * For the WJH buffer drops we need to bind all active ports to buffer drops and
 * WRED discards.
 * */
static sx_status_t __sx_adviser_port_added_removed_cb(const sx_lib_adviser_event_info_t event_info,
                                                      const void                       *context)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    wjh_drop_reason_group_record_t *drop_reason_group_record_p = NULL;
    uint8_t                         reason_bits = 0;
    wjh_verbosity_level_t           wjh_orig_verb;
    sx_verbosity_level_t            sdk_api_orig_verb;
    sx_verbosity_level_t            sdk_module_orig_verb;
    const char                    * sdk_module_name = "SPAN";
    boolean_t                       verbs_set = FALSE;
    sx_status_t                     rb_sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(context);

    sx_status = __set_wjh_and_sdk_verbosity_levels(WJH_VERBOSITY_LEVEL_NONE,
                                                   SX_VERBOSITY_LEVEL_NONE,
                                                   SX_VERBOSITY_LEVEL_NONE,
                                                   sx_api_span_log_verbosity_level_set,
                                                   &wjh_orig_verb,
                                                   &sdk_api_orig_verb,
                                                   &sdk_module_orig_verb,
                                                   sx_api_span_log_verbosity_level_get,
                                                   sdk_module_name);
    if (SX_CHECK_FAIL(sx_status)) {
        WJH_LOG_ERR("Failed to set WJH and %s API/module verbosity levels to NONE, err: %s\n",
                    sdk_module_name, sx_status_str(sx_status));
        goto out;
    }
    verbs_set = TRUE;

    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_BUFFER_E,
                                 &drop_reason_group_record_p);
    if (drop_reason_group_record_p == NULL) {
        sx_status = SX_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason group record is not valid\n");
        goto out;
    }

    if (drop_reason_group_record_p->enabled_severity_bits == 0) {
        goto out;
    }

    reason_bits = wjh_db_buffer_drop_reason_bits_get(drop_reason_group_record_p->enabled_severity_bits);
    if (reason_bits == 0) {
        WJH_LOG_DBG("No drop reason enabled.\n");
        goto out;
    }

    sx_status = __wjh_buffer_drop_reason_bind_unbind(event_info, reason_bits);

    if (SX_CHECK_FAIL(sx_status)) {
        WJH_LOG_ERR("Wjh buffer drop reason bind/unbind failed, err=%u\n", sx_status);
        goto out;
    }

out:
    if (verbs_set) {
        rb_sx_status = __set_wjh_and_sdk_verbosity_levels(wjh_orig_verb,
                                                          sdk_api_orig_verb,
                                                          sdk_module_orig_verb,
                                                          sx_api_span_log_verbosity_level_set,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          sdk_module_name);
        if (SX_CHECK_FAIL(rb_sx_status)) {
            WJH_LOG_ERR("Failed to set WJH and %s API/module verbosity levels to original value, err: %s\n",
                        sdk_module_name, sx_status_str(rb_sx_status));
        }
    }

    return sx_status;
}

static wjh_status_t __bind_unbind_buffer_drops_all_ports(sx_lib_adviser_event_type_e event_type, uint8_t reason_bits)
{
    wjh_status_t                err = WJH_STATUS_SUCCESS;
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    uint32_t                    port_cnt = 0;
    int                         i = 0;
    sx_port_log_id_t           *log_port_p = NULL;
    sx_lib_adviser_event_info_t event_info;
    wjh_buffer_drop_db_t       *db_p = NULL;
    boolean_t                   is_db_valid = TRUE;
    sx_status_t                 rb_err = SX_STATUS_SUCCESS;

    if (reason_bits == 0) {
        goto out;
    }

    is_db_valid = wjh_is_reason_group_db_inited(WJH_DROP_REASON_GROUP_BUFFER_E);
    if (is_db_valid == FALSE) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    wjh_db_buffer_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    sx_status = sx_api_port_swid_port_list_get(sx_api_handle_s,
                                               0,
                                               NULL,
                                               &port_cnt);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to get the current number of ports, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    log_port_p = (sx_port_log_id_t*)cl_malloc(sizeof(log_port_p[0]) * port_cnt);
    if (log_port_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to allocate memory for port list\n");
        goto out;
    }

    sx_status = sx_api_port_swid_port_list_get(sx_api_handle_s,
                                               0,
                                               log_port_p,
                                               &port_cnt);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to retrieve all Ethernet ports, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    event_info.type = event_type;
    for (i = 0; i < (int)port_cnt; i++) {
        if (log_port_p[i] == db_p->recirculation_port) {
            continue;
        }
        event_info.info.port_added_deleted.log_port = log_port_p[i];
        sx_status = __wjh_buffer_drop_reason_bind_unbind(event_info, reason_bits);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set port 0x%x span binding, err: %s\n",
                        log_port_p[i], sx_status_str(sx_status));
            goto out;
        }
    }

out:
    if (WJH_CHECK_FAIL(err) && (event_type == SX_LIB_ADVISER_PORT_ADDED_E)) {
        event_info.type = SX_LIB_ADVISER_PORT_DELETED_E;
        for (i--; i >= 0; i--) {
            if (log_port_p[i] == db_p->recirculation_port) {
                continue;
            }
            event_info.info.port_added_deleted.log_port = log_port_p[i];
            rb_err = __wjh_buffer_drop_reason_bind_unbind(event_info, reason_bits);
            if (SX_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to set port 0x%x span binding, err: %s\n",
                            log_port_p[i], sx_status_str(rb_err));
            }
        }
    }

    if (log_port_p != NULL) {
        cl_free(log_port_p);
        log_port_p = NULL;
    }
    return err;
}

static wjh_status_t __bind_unbind_roce_drops_all_ports(sx_lib_adviser_event_type_e event_type)
{
    wjh_status_t        err = WJH_STATUS_SUCCESS;
    sx_status_t         sx_status = SX_STATUS_SUCCESS;
    uint32_t            port_cnt = 0;
    int                 i = 0;
    sx_port_log_id_t   *log_port_p = NULL;
    wjh_roce_drop_db_t *db_p = NULL;
    sx_access_cmd_t     sx_access_cmd = SX_ACCESS_CMD_ADD;
    sx_port_log_id_t    phy_port_lag_mapping[MAX_PHYPORT_NUM + 1];
    sx_port_type_t      port_type = SX_PORT_TYPE_INVALID;
    uint16_t            phy_port_id = 0;
    sx_status_t         rb_err = SX_STATUS_SUCCESS;

    memset(phy_port_lag_mapping, 0, sizeof(sx_port_log_id_t) * (MAX_PHYPORT_NUM + 1));

    err = __prepare_port_lag_mapping(phy_port_lag_mapping);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to prepare port lag mapping.\n");
        goto out;
    }

    wjh_db_roce_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    sx_status = sx_api_port_swid_port_list_get(sx_api_handle_s,
                                               0,
                                               NULL,
                                               &port_cnt);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to get the current number of ports for RoCE, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    log_port_p = (sx_port_log_id_t*)cl_malloc(sizeof(log_port_p[0]) * port_cnt);
    if (log_port_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to allocate memory for port list for RoCE\n");
        goto out;
    }

    sx_status = sx_api_port_swid_port_list_get(sx_api_handle_s,
                                               0,
                                               log_port_p,
                                               &port_cnt);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to retrieve all Ethernet ports, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    /* Bind/unbind to all ports the ingress RoCE ACL */
    sx_access_cmd = (event_type == SX_LIB_ADVISER_PORT_ADDED_E) ? SX_ACCESS_CMD_ADD : SX_ACCESS_CMD_DELETE;
    for (i = 0; i < (int)port_cnt; i++) {
        port_type = SX_PORT_TYPE_ID_GET(log_port_p[i]);
        if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_LAG)) {
            continue;
        }
        /* Check if the port is part of a lag. If so, we don't bind/unbind it directly */
        if (port_type == SX_PORT_TYPE_NETWORK) {
            phy_port_id = SX_PORT_PHY_ID_GET(log_port_p[i]);
            if (phy_port_lag_mapping[phy_port_id] != 0) {
                continue;
            }
        }

        sx_status = sx_api_acl_port_bind_set(sx_api_handle_s, sx_access_cmd, log_port_p[i], db_p->acl_group_id);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set port 0x%x for RoCE port binding, err: %s\n",
                        log_port_p[i], sx_status_str(sx_status));
            goto out;
        }
    }

out:
    if (WJH_CHECK_FAIL(err) && (event_type == SX_LIB_ADVISER_PORT_ADDED_E)) {
        for (i--; i >= 0; i--) {
            port_type = SX_PORT_TYPE_ID_GET(log_port_p[i]);
            if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_LAG)) {
                continue;
            }
            /* Check if the port is part of a lag. If so, we don't bind/unbind it directly */
            if (port_type == SX_PORT_TYPE_NETWORK) {
                phy_port_id = SX_PORT_PHY_ID_GET(log_port_p[i]);
                if (phy_port_lag_mapping[phy_port_id] != 0) {
                    continue;
                }
            }

            rb_err =
                sx_api_acl_port_bind_set(sx_api_handle_s, SX_ACCESS_CMD_DELETE, log_port_p[i], db_p->acl_group_id);
            if (SX_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to unbind port 0x%x from ROCE ACL, err: %s\n", log_port_p[i],
                            sx_status_str(rb_err));
            }
        }
    }

    if (log_port_p != NULL) {
        cl_free(log_port_p);
        log_port_p = NULL;
    }
    return err;
}

static wjh_status_t __buffer_drop_span_init(const wjh_drop_reason_group_attr_t *attr_p)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_buffer_drop_span_init_cb == NULL)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific callback not valid");
        goto out;
    }

    err = wjh_dev_cb_p->wjh_buffer_drop_span_init_cb(sx_api_handle_s, attr_p, &wjh_policer_attrs_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific cb span init failed, err=%u\n", err);
        goto out;
    }
out:
    return err;
}

static wjh_status_t __buffer_drop_span_deinit(void)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_buffer_drop_span_deinit_cb == NULL)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific callback not valid");
        goto out;
    }

    err = wjh_dev_cb_p->wjh_buffer_drop_span_deinit_cb(sx_api_handle_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific cb span deinit failed, err=%u\n", err);
        goto out;
    }
out:
    return err;
}

static wjh_status_t __buffer_drop_mirror_to_cpu_mode_set(boolean_t mode)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_buffer_drop_mirror_to_cpu_mode_set_cb == NULL)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific callback not valid");
        goto out;
    }

    err = wjh_dev_cb_p->wjh_buffer_drop_mirror_to_cpu_mode_set_cb(mode);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific cb mirror to cpu mode set failed, err=%u\n", err);
        goto out;
    }
out:
    return err;
}

static wjh_status_t __buffer_drop_sx_adviser_register(const wjh_drop_reason_group_attr_t *attr_p)
{
    sx_lib_adviser_event_registration_params_t event_registration_params;
    sx_port_log_id_t                           excluded_port = attr_p->attr.buffer_drop.basic_attr.recirculation_port;
    wjh_status_t                               err = WJH_STATUS_SUCCESS;
    sx_status_t                                sx_status = SX_STATUS_SUCCESS;
    wjh_status_t                               rb_err = WJH_STATUS_SUCCESS;
    boolean_t                                  adviser_inited = FALSE;

    err = __wjh_sx_lib_adviser_init();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("lib adviser init failed, err=%u\n", err);
        goto out;
    }
    adviser_inited = TRUE;

    event_registration_params.event_type = SX_LIB_ADVISER_PORT_ADDED_E;
    event_registration_params.excluded_ports_cnt = 1;
    event_registration_params.excluded_ports_p = &excluded_port;
    event_registration_params.callback = __sx_adviser_port_added_removed_cb;
    event_registration_params.context = NULL;

    sx_status = sx_lib_adviser_event_register(event_registration_params);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to register to SX lib adviser port added event, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

out:
    if (WJH_CHECK_FAIL(err)) {
        if (adviser_inited) {
            rb_err = __wjh_sx_lib_adviser_deinit();
            if (WJH_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("lib adviser deinit failed, err=%d\n", rb_err);
            }
        }
    }

    return err;
}

static wjh_status_t __buffer_drop_sx_adviser_deregister(void)
{
    sx_lib_adviser_event_registration_params_t event_registration_params;
    wjh_status_t                               err = WJH_STATUS_SUCCESS;
    sx_status_t                                sx_status = SX_STATUS_SUCCESS;

    event_registration_params.event_type = SX_LIB_ADVISER_PORT_ADDED_E;
    event_registration_params.callback = __sx_adviser_port_added_removed_cb;

    sx_status = sx_lib_adviser_event_deregister(event_registration_params);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to deregister SX lib adviser port added event, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    err = __wjh_sx_lib_adviser_deinit();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("lib adviser deinit failed, err=%u\n", err);
        goto out;
    }

out:
    return err;
}
static wjh_status_t __buffer_drop_acl_create(const wjh_drop_reason_group_attr_t *attr_p)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_buffer_drop_acl_create_cb == NULL)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific callback or wjh_buffer_drop_acl_create_cb not valid");
        goto out;
    }

    err = wjh_dev_cb_p->wjh_buffer_drop_acl_create_cb(sx_api_handle_s, attr_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific cb for acl destroy  failed, err=%u\n", err);
        goto out;
    }
out:
    return err;
}
static wjh_status_t __buffer_drop_acl_destory(void)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_buffer_drop_acl_destroy_cb == NULL)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific callback not valid");
        goto out;
    }

    err = wjh_dev_cb_p->wjh_buffer_drop_acl_destroy_cb(sx_api_handle_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific cb for acl create failed, err=%u\n", err);
        goto out;
    }
out:
    return err;
}

static wjh_status_t __wjh_buffer_drop_init(const wjh_drop_reason_group_attr_t *attr_p)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS, rb_err = WJH_STATUS_SUCCESS;
    boolean_t                       sx_adviser_registered = FALSE, span_set = FALSE;
    wjh_drop_reason_group_record_t *drop_reason_db_p;
    wjh_trap_id_attr_t             *trap_id_attr_p = NULL;
    wjh_trap_id_attr_t             *default_trap_id_attr_p = NULL;

    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_BUFFER_E,
                                 &drop_reason_db_p);
    if (drop_reason_db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason group record is not valid\n");
        goto out;
    }

    if (attr_p->attr.buffer_drop.advanced_attr.trap_id != 0) {
        wjh_db_trap_id_attr_get(drop_reason_db_p->trap_ids[0].trap_id, &default_trap_id_attr_p);
        drop_reason_db_p->trap_ids[0].trap_id = attr_p->attr.buffer_drop.advanced_attr.trap_id;
        wjh_db_trap_id_attr_get(drop_reason_db_p->trap_ids[0].trap_id, &trap_id_attr_p);
        memcpy(trap_id_attr_p, default_trap_id_attr_p, sizeof(wjh_trap_id_attr_t));
#ifdef WJH_EBPF_PRESENT
        err = wjh_ebpf_map_elem_update(wjh_drop_reason_bpf_map_s,
                                       &drop_reason_db_p->trap_ids[0].trap_id,
                                       &drop_reason_db_p->trap_ids[0].reason_id,
                                       BPF_ANY);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_map_elem_update failed, err: %d\n", err);
            goto out;
        }
#endif
    }

    err = __buffer_drop_sx_adviser_register(attr_p);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to register to SX Adviser lib err: %u\n", err);
        goto out;
    }
    sx_adviser_registered = TRUE;

    err = __buffer_drop_span_init(attr_p);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to set WJH span configuration, err: %u\n", err);
        goto out;
    }
    span_set = TRUE;

    err = __buffer_drop_acl_create(attr_p);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to set the required ACL configuration, err: %u\n", err);
        goto out;
    }

out:
    if (err != WJH_STATUS_SUCCESS) {
        if (span_set == TRUE) {
            rb_err = __buffer_drop_span_deinit();
            if (rb_err != WJH_STATUS_SUCCESS) {
                WJH_LOG_ERR("Failed to deinitialize the span configuration, err: %u\n", rb_err);
            }
        }
        if (sx_adviser_registered == TRUE) {
            rb_err = __buffer_drop_sx_adviser_deregister();
            if (rb_err != WJH_STATUS_SUCCESS) {
                WJH_LOG_ERR("Failed to deregister SX Adviser lib, err: %u\n", rb_err);
            }
        }
    }
    return err;
}

static wjh_status_t __wjh_buffer_drop_deinit(void)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_record_t *drop_reason_db_p = NULL;
    boolean_t                       is_db_valid = TRUE;


    is_db_valid = wjh_is_reason_group_db_inited(WJH_DROP_REASON_GROUP_BUFFER_E);
    if (is_db_valid == FALSE) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_BUFFER_E,
                                 &drop_reason_db_p);
    if (drop_reason_db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason group record is not valid\n");
        goto out;
    }

    err = __buffer_drop_acl_destory();
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to destroy the ACL configuration, err: %u\n", err);
        goto out;
    }

    err = __buffer_drop_span_deinit();
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to destroy WJH span configuration, err: %u\n", err);
        goto out;
    }

    err = __buffer_drop_sx_adviser_deregister();
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to deregister to SX Adviser lib err: %u\n", err);
        goto out;
    }

out:
    return err;
}

static sx_status_t __sx_lib_adviser_roce_cb(const sx_lib_adviser_event_info_t event_info,
                                            const void                       *context)
{
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    wjh_roce_drop_db_t   *db_p = NULL;
    sx_port_type_t        port_type = SX_PORT_TYPE_INVALID;
    wjh_verbosity_level_t wjh_orig_verb;
    sx_verbosity_level_t  sdk_api_orig_verb;
    sx_verbosity_level_t  sdk_module_orig_verb;
    const char          * sdk_module_name = "ACL";
    boolean_t             verbs_set = FALSE;
    sx_status_t           rb_sx_status = SX_STATUS_SUCCESS;

    UNUSED_PARAM(context);

    sx_status = __set_wjh_and_sdk_verbosity_levels(WJH_VERBOSITY_LEVEL_NONE,
                                                   SX_VERBOSITY_LEVEL_NONE,
                                                   SX_VERBOSITY_LEVEL_NONE,
                                                   sx_api_acl_log_verbosity_level_set,
                                                   &wjh_orig_verb,
                                                   &sdk_api_orig_verb,
                                                   &sdk_module_orig_verb,
                                                   sx_api_acl_log_verbosity_level_get,
                                                   sdk_module_name);
    if (SX_CHECK_FAIL(sx_status)) {
        WJH_LOG_ERR("Failed to set WJH and %s API/module verbosity levels to NONE, err: %s\n",
                    sdk_module_name, sx_status_str(sx_status));
        goto out;
    }
    verbs_set = TRUE;

    wjh_db_roce_drop_get(&db_p);
    if (db_p == NULL) {
        sx_status = SX_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    switch (event_info.type) {
    case SX_LIB_ADVISER_PORT_ADDED_E:
        /* If a new port was added we need to bind it to the RoCE ACL group */
        port_type = SX_PORT_TYPE_ID_GET(event_info.info.port_added_deleted.log_port);
        if ((port_type == SX_PORT_TYPE_NETWORK) || (port_type == SX_PORT_TYPE_LAG)) {
            sx_status = sx_api_acl_port_bind_set(sx_api_handle_s,
                                                 SX_ACCESS_CMD_ADD,
                                                 event_info.info.port_added_deleted.log_port,
                                                 db_p->acl_group_id);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to set new port 0x%x for RoCE port binding, err: %s\n",
                            event_info.info.port_added_deleted.log_port, sx_status_str(sx_status));
                goto out;
            }
        }
        break;

    case SX_LIB_ADVISER_PORT_DELETED_FROM_LAG:
        /* If a port was removed from LAG we need to individually bind it to the RoCE ACL group */
        sx_status = sx_api_acl_port_bind_set(sx_api_handle_s,
                                             SX_ACCESS_CMD_ADD,
                                             event_info.info.lag_changes.log_port,
                                             db_p->acl_group_id);
        if (SX_CHECK_FAIL(sx_status)) {
            WJH_LOG_ERR("Failed to set port 0x%x for RoCE port binding (after removed from lag), err: %s\n",
                        event_info.info.port_added_deleted.log_port, sx_status_str(sx_status));
            goto out;
        }
        break;

    default:
        WJH_LOG_ERR("Event type (%u) is not supported by the RoCE group\n", event_info.type);
        sx_status = SX_STATUS_ERROR;
        goto out;
        break;
    }

out:
    if (verbs_set) {
        rb_sx_status = __set_wjh_and_sdk_verbosity_levels(wjh_orig_verb,
                                                          sdk_api_orig_verb,
                                                          sdk_module_orig_verb,
                                                          sx_api_acl_log_verbosity_level_set,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          NULL,
                                                          sdk_module_name);
        if (SX_CHECK_FAIL(rb_sx_status)) {
            WJH_LOG_ERR("Failed to set WJH and %s API/module verbosity levels to original value, err: %s\n",
                        sdk_module_name, sx_status_str(rb_sx_status));
        }
    }

    return sx_status;
}

static wjh_status_t __roce_drop_sx_advisers_register()
{
    sx_lib_adviser_event_registration_params_t event_registration_params;
    wjh_status_t                               err = WJH_STATUS_SUCCESS;
    sx_status_t                                sx_status = SX_STATUS_SUCCESS;
    boolean_t                                  adviser_init = FALSE;
    uint32_t                                   i = 0;
    sx_lib_adviser_event_type_e                event_types[] =
    {SX_LIB_ADVISER_PORT_ADDED_E, SX_LIB_ADVISER_PORT_DELETED_FROM_LAG};
    uint32_t event_type_count = sizeof(event_types) / sizeof(event_types[0]);

    memset(&event_registration_params, 0, sizeof(event_registration_params));

    err = __wjh_sx_lib_adviser_init();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("lib adviser init failed, err=%u\n", err);
        goto out;
    }
    adviser_init = TRUE;

    /* Register to monitor the events that are relevant to binding the RoCE ACL
     * to created/modified ports/LAGS.
     */
    event_registration_params.excluded_ports_cnt = 0;
    event_registration_params.excluded_ports_p = NULL;
    event_registration_params.context = NULL;
    event_registration_params.callback = __sx_lib_adviser_roce_cb;

    for (i = 0; i < event_type_count; i++) {
        event_registration_params.event_type = event_types[i];
        sx_status = sx_lib_adviser_event_register(event_registration_params);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to register event type %u for RoCE, err: %s\n",
                        event_types[i], sx_status_str(sx_status));
            goto out;
        }
    }

out:
    if (WJH_CHECK_FAIL(err)) {
        event_type_count = i;
        for (i = 0; i < event_type_count; i++) {
            event_registration_params.event_type = event_types[i];
            sx_status = sx_lib_adviser_event_deregister(event_registration_params);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to deregister event type %u for RoCE rollback, err: %s\n",
                            event_types[i], sx_status_str(sx_status));
            }
        }
        if (adviser_init) {
            __wjh_sx_lib_adviser_deinit();
        }
    }
    return err;
}

static wjh_status_t __roce_drop_sx_advisers_deregister(void)
{
    sx_lib_adviser_event_registration_params_t event_registration_params;
    wjh_status_t                               err = WJH_STATUS_SUCCESS;
    sx_status_t                                sx_status = SX_STATUS_SUCCESS;
    uint32_t                                   i = 0;
    sx_lib_adviser_event_type_e                event_types[] =
    {SX_LIB_ADVISER_PORT_ADDED_E, SX_LIB_ADVISER_PORT_DELETED_FROM_LAG};
    uint32_t event_type_count = sizeof(event_types) / sizeof(event_types[0]);

    event_registration_params.excluded_ports_cnt = 0;
    event_registration_params.excluded_ports_p = NULL;
    event_registration_params.context = NULL;
    event_registration_params.callback = __sx_lib_adviser_roce_cb;

    for (i = 0; i < event_type_count; i++) {
        event_registration_params.event_type = event_types[i];
        sx_status = sx_lib_adviser_event_deregister(event_registration_params);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to deregister event type %u for RoCE, err: %s\n",
                        event_types[i], sx_status_str(sx_status));
            goto out;
        }
    }

    err = __wjh_sx_lib_adviser_deinit();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("lib adviser deinit failed, err=%u\n", err);
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_roce_drop_init(const wjh_drop_reason_group_attr_t *attr_p)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;
    wjh_roce_drop_db_t    *db_p = NULL;
    wjh_status_t           rb_err = WJH_STATUS_SUCCESS;
    boolean_t              roce_acl_created = FALSE;
    boolean_t              roce_acl_bound = FALSE;

    wjh_db_roce_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh roce drop reason db is not valid\n");
        goto out;
    }

    /* Store the CNP/RoCE switch priority in the RoCE DB for later use */
    db_p->cnp_switch_prio = attr_p->attr.roce_drop.cnp_switch_prio;
    db_p->roce_switch_prio = attr_p->attr.roce_drop.roce_switch_prio;

    wjh_dev_cb_p = wjh_db_get_dev_cb();
    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_roce_drop_acl_create_cb == NULL)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific callback for RoCE ACL create not valid");
        goto out;
    }

    err = wjh_dev_cb_p->wjh_roce_drop_acl_create_cb(sx_api_handle_s, attr_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific cb for roce ACL create failed, err=%u\n", err);
        goto out;
    }
    roce_acl_created = TRUE;

    err = __bind_unbind_roce_drops_all_ports(SX_LIB_ADVISER_PORT_ADDED_E);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to bind all ports to roce acl, err: %u\n", err);
        goto out;
    }
    roce_acl_bound = TRUE;

    err = __roce_drop_sx_advisers_register();
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to register Roce advisers, err: %u\n", err);
        goto out;
    }

out:
    if (WJH_CHECK_FAIL(err)) {
        if (roce_acl_bound) {
            rb_err = __bind_unbind_roce_drops_all_ports(SX_LIB_ADVISER_PORT_DELETED_E);
            if (WJH_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to unbind all ports from ROCE ACL, err: %d\n", rb_err);
            }
        }

        if (roce_acl_created) {
            rb_err = wjh_dev_cb_p->wjh_roce_drop_acl_destroy_cb(sx_api_handle_s);
            if (WJH_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to destroy ROCE drop ACL, err: %d\n", rb_err);
            }
        }
    }

    return err;
}

static wjh_status_t __wjh_roce_drop_deinit(void)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_roce_drop_acl_destroy_cb == NULL)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific callback for RoCE ACL destroy not valid");
        goto out;
    }

    /* Stop listening ports' events */
    err = __roce_drop_sx_advisers_deregister();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to deregister Roce advisers, err: %u\n", err);
        goto out;
    }

    /* Remove binding from all ports */
    err = __bind_unbind_roce_drops_all_ports(SX_LIB_ADVISER_PORT_DELETED_E);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to bind all ports for the RoCE drop reason, err: %u\n", err);
        goto out;
    }

    err = wjh_dev_cb_p->wjh_roce_drop_acl_destroy_cb(sx_api_handle_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific cb for RoCE ACL destroy failed, err=%u\n", err);
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_buffer_drop_span_clean_up(uint8_t drop_reason_bits)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    err = __bind_unbind_buffer_drops_all_ports(SX_LIB_ADVISER_PORT_DELETED_E, drop_reason_bits);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("Failed to disable all ports from the mirror trigger, err: %u\n", err);
        goto out;
    }
    err = __wjh_buffer_drop_group_span_session_bind_unbind(FALSE);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("wjh buffer cleanup failed to unbind span session, err: %u\n", err);
        goto out;
    }
    err = __wjh_buffer_drop_group_span_session_set(FALSE);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("wjh buffer cleanup failed to disable span session, err: %u\n", err);
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_buffer_drop_post_init_resource_clean_up()
{
    boolean_t                       is_db_valid = TRUE;
    wjh_drop_reason_group_record_t *drop_reason_db_p = NULL;
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    uint8_t                         buffer_drop_reason_bits = 0;

    is_db_valid = wjh_is_reason_group_db_inited(WJH_DROP_REASON_GROUP_BUFFER_E);
    if (is_db_valid == FALSE) {
        WJH_LOG_DBG("Wjh buffer drop reason db is init not done\n");
        goto out;
    }

    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_BUFFER_E, &drop_reason_db_p);
    if (drop_reason_db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason group record is not valid\n");
        goto out;
    }

    if (drop_reason_db_p->enabled_severity_bits != 0) {
        buffer_drop_reason_bits = wjh_db_buffer_drop_reason_bits_get(drop_reason_db_p->enabled_severity_bits);
        err = __wjh_buffer_drop_span_clean_up(buffer_drop_reason_bits);
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to clean up span resource, err: %u\n", err);
            goto out;
        }
        drop_reason_db_p->enabled_severity_bits = 0;
    }

    if (drop_reason_db_p->inited) {
        err = __wjh_buffer_drop_deinit();
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to deinitialize the WJH buffer drop mechanism, err:%u\n", err);
            goto out;
        }
        drop_reason_db_p->inited = FALSE;
    }

out:
    return err;
}

static wjh_status_t __wjh_buffer_drop_pre_init_resource_clean_up(
    wjh_buffer_drop_reason_group_shm_data_t *wjh_buffer_drop_shm_data_p)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_buffer_drop_db_t           *db_p = NULL;
    wjh_drop_reason_group_record_t *group_item_p = NULL;

    wjh_db_buffer_drop_get(&db_p);
    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_BUFFER_E, &group_item_p);

    if (wjh_buffer_drop_shm_data_p == NULL) {
        WJH_LOG_DBG("wjh buffer drop resource clean up not done, shm buffer drop data is null\n");
        goto out;
    }

    if (wjh_buffer_drop_shm_data_p->inited == FALSE) {
        WJH_LOG_DBG("wjh resource clean up not done, shm buffer drop init not done in previous instance\n");
        goto out;
    }

    err = wjh_db_set_drop_reason_db_with_shm_data(WJH_DROP_REASON_GROUP_BUFFER_E, wjh_buffer_drop_shm_data_p);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("wjh buffer db restoration for clean up failed, err: %u\n", err);
        goto out;
    }

    if (wjh_buffer_drop_shm_data_p->drop_reason_bits) {
        err = __wjh_buffer_drop_span_clean_up(wjh_buffer_drop_shm_data_p->drop_reason_bits);
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to clean up span resource, err: %u\n", err);
            goto out;
        }
    }

    err = __buffer_drop_mirror_to_cpu_mode_set(wjh_buffer_drop_shm_data_p->recirculation_port == WJH_CPU_PORT_ID);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("wjh buffer cleanup failed to set the mirror to CPU mode, err: %u\n", err);
    }

    err = __buffer_drop_acl_destory();
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("wjh buffer cleanup failed to destroy the ACL configuration, err: %u\n", err);
    }

    err = __buffer_drop_span_deinit();
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("wjh buffer cleanup failed to destroy WJH span configuration, err: %u\n", err);
    }

    /* Restore db for following init to happen */
    wjh_db_buffer_drop_set(db_p);
    group_item_p->inited = FALSE;
    group_item_p->enabled_severity_bits = 0;
    group_item_p->bound = FALSE;

    err = __buffer_drop_mirror_to_cpu_mode_set(FALSE);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("wjh buffer cleanup failed to set the mirror to CPU mode, err: %u\n", err);
    }

out:
    return err;
}

wjh_status_t wjh_drop_reason_group_deinit_sdk(const wjh_drop_reason_group_e drop_reason_group)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    sx_acl_helper_status_t acl_helper_status = SX_ACL_HELPER_STATUS_SUCCESS;

    switch (drop_reason_group) {
    case WJH_DROP_REASON_GROUP_BUFFER_E:
        err = __wjh_buffer_drop_deinit();
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to deinitialize the WJH buffer drop mechanism, err:%u\n", err);
            goto out;
        }
        break;

    case WJH_DROP_REASON_GROUP_ACL_E:
        acl_helper_status = sx_acl_helper_deinit();
        if (acl_helper_status != SX_ACL_HELPER_STATUS_SUCCESS) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to initialize acl helper.\n");
            goto out;
        }
        break;

    case WJH_DROP_REASON_GROUP_ROCE_E:
        err = __wjh_roce_drop_deinit();
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to deinitialize the WJH roce drop mechanism, err:%u\n", err);
            goto out;
        }
        break;

    default:
        /* No deinitialization is needed */
        goto out;
    }

out:
    return err;
}


wjh_status_t wjh_drop_reason_group_init_sdk(const wjh_drop_reason_group_e       drop_reason_group,
                                            const wjh_drop_reason_group_attr_t *attr_p)
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_attr_t attr;
    sx_acl_helper_status_t       acl_helper_status = SX_ACL_HELPER_STATUS_SUCCESS;


    switch (drop_reason_group) {
    case WJH_DROP_REASON_GROUP_BUFFER_E:
        if (attr_p == NULL) {
            err = WJH_STATUS_PARAM_NULL;
            WJH_LOG_ERR("attr_p is NULL, err : %u\n", err);
            goto out;
        }
        attr = *attr_p;
        err = __wjh_buffer_drop_init(&attr);
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to initialize the WJH buffer drop mechanism, err:%u\n", err);
            goto out;
        }
        break;

    case WJH_DROP_REASON_GROUP_ACL_E:
        acl_helper_status = sx_acl_helper_init();
        if (acl_helper_status != SX_ACL_HELPER_STATUS_SUCCESS) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to initialize acl helper.\n");
            goto out;
        }
        break;

    case WJH_DROP_REASON_GROUP_ROCE_E:
        if (attr_p == NULL) {
            err = WJH_STATUS_PARAM_NULL;
            WJH_LOG_ERR("attr_p is NULL, err : %u\n", err);
            goto out;
        }
        /* Currently we support only the ingress point monitoring for RoCE */
        if (attr_p->attr.roce_drop.roce_monitor_point != WJH_ROCE_MONITOR_POINT_INGRESS) {
            err = WJH_STATUS_PARAM_ERROR;
            WJH_LOG_ERR("RoCE monitor point [%u] is unsupported\n", attr_p->attr.roce_drop.roce_monitor_point);
            goto out;
        }
        attr = *attr_p;
        err = __wjh_roce_drop_init(&attr);
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to initialize the WJH roce drop mechanism, err:%u\n", err);
            goto out;
        }
        break;

    default:
        /* No initialization is needed */
        goto out;
    }

out:
    return err;
}

#ifdef WJH_EBPF_PRESENT
static wjh_status_t __wjh_agg_bpf_prog_attach_detach(wjh_user_channel_record_t      *channel_p,
                                                     wjh_drop_reason_group_record_t *group_item_p,
                                                     boolean_t                       is_attach)
{
    wjh_status_t                           err = WJH_STATUS_SUCCESS;
    sxd_ctrl_pack_t                        ctrl_pack;
    int                                    sxd_err = 0;
    struct ku_set_rdq_agg_ebpf_prog_params prog_params;

    WJH_CHECK_NULL_PTR(channel_p, channel_p);
    WJH_CHECK_NULL_PTR(group_item_p, group_item_p);

    if (is_attach && group_item_p->aggregation_ebpf_prog_fd_attached) {
        WJH_LOG_ERR("The eBPF program for drop reason group %u is already attached.\n",
                    group_item_p->drop_reason_group);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (!is_attach && !group_item_p->aggregation_ebpf_prog_fd_attached) {
        WJH_LOG_ERR("The eBPF program for drop reason group %u is not attached yet.\n",
                    group_item_p->drop_reason_group);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    prog_params.ebpf_prog_fd = group_item_p->aggregation_ebpf_prog_fd;
    prog_params.is_attach = (is_attach == TRUE) ? 1 : 0;
    prog_params.rdq = channel_p->hw_trap_group;
    prog_params.index = group_item_p->drop_reason_group;

    ctrl_pack.cmd_body = (void*)&prog_params;
    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_RDQ_AGG_EBPF_PROG;

    sxd_err = sxd_ioctl(channel_p->fd.driver_handle, &ctrl_pack);
    if (sxd_err != 0) {
        WJH_LOG_ERR("sxd_ioctl (CTRL_CMD_SET_RDQ_AGG_EBPF_PROG) error %s\n",
                    strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    group_item_p->aggregation_ebpf_prog_fd_attached = is_attach;

out:
    return err;
}

static wjh_status_t __wjh_filter_attach_detach(wjh_db_filter_record_t    *filter_record_p,
                                               wjh_user_channel_record_t *channel_p,
                                               boolean_t                  is_attach)
{
    wjh_status_t                              err = WJH_STATUS_SUCCESS;
    sxd_ctrl_pack_t                           ctrl_pack;
    int                                       sxd_err = 0;
    struct ku_set_rdq_filter_ebpf_prog_params prog_params;

    WJH_CHECK_NULL_PTR(filter_record_p, filter_record_p);
    WJH_CHECK_NULL_PTR(channel_p, channel_p);

    prog_params.ebpf_prog_fd = filter_record_p->ebpf_prog_fd;
    prog_params.is_attach = (is_attach == TRUE) ? 1 : 0;
    prog_params.rdq = channel_p->hw_trap_group;

    ctrl_pack.cmd_body = (void*)&prog_params;
    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_RDQ_FILTER_EBPF_PROG;

    sxd_err = sxd_ioctl(channel_p->fd.driver_handle, &ctrl_pack);
    if (sxd_err != 0) {
        WJH_LOG_ERR("sxd_ioctl (CTRL_CMD_SET_RDQ_FILTER_EBPF_PROG) error %s\n",
                    strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (is_attach) {
        err = __wjh_monitor_rdq_trace_points_enable();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_monitor_rdq_trace_points_enable failed, err: %d\n", err);
            goto out;
        }
    } else {
        err = __wjh_monitor_rdq_trace_points_disable();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_monitor_rdq_trace_points_disable failed, err: %d\n", err);
            goto out;
        }
    }

out:
    return err;
}

wjh_status_t wjh_filter_create_sdk(wjh_db_filter_record_t *filter_record_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint32_t     key_size = 0;
    char         ebpf_prog_path[PATH_MAX] = {0};
    int          ebpf_prog_fd = -1;
    const char  *ebpf_map_names[3] = {NULL, NULL, NULL};
    int          ebpf_map_fds[3] = {-1, -1, -1};
    uint32_t     map_count = 3;

    key_size = sizeof(wjh_filter_rule_ebpf_key_t);

    err = wjh_ebpf_map_create(BPF_MAP_TYPE_HASH, key_size, sizeof(uint64_t),
                              WJH_FILTER_RULE_NUM_MAX,
                              &ebpf_map_fds[0]);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to create eBPF map, key_size (%u), value_size (%lu), max_entries_cnt (%u), err: %d\n",
                    key_size, sizeof(uint64_t), WJH_FILTER_RULE_NUM_MAX, err);
        goto out;
    }
    ebpf_map_fds[1] = wjh_drop_reason_bpf_map_s;
    ebpf_map_fds[2] = wjh_port_bpf_map_s;

    ebpf_map_names[0] = wjh_filter_ebpf_map_name;
    ebpf_map_names[1] = wjh_drop_reason_ebpf_map_name;
    ebpf_map_names[2] = wjh_port_ebpf_map_name;

    snprintf(ebpf_prog_path, sizeof(ebpf_prog_path), "%s%s", wjh_ebpf_prog_dir_g, wjh_filter_epbf_prog_name);

    err = wjh_ebpf_program_load(ebpf_prog_path,
                                BPF_PROG_TYPE_SCHED_CLS,
                                wjh_filter_ebpf_prog_section_name,
                                ebpf_map_names,
                                ebpf_map_fds,
                                map_count, &ebpf_prog_fd);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh_ebpf_program_load failed, err = %d\n", err);
        goto out;
    }

    filter_record_p->ebpf_map_fd = ebpf_map_fds[0];
    filter_record_p->ebpf_prog_fd = ebpf_prog_fd;

out:
    return err;
}

wjh_status_t wjh_filter_destroy_sdk(wjh_db_filter_record_t *filter_record_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    UNUSED_PARAM(err);

    if (filter_record_p->ebpf_prog_fd >= 0) {
        close(filter_record_p->ebpf_prog_fd);
        filter_record_p->ebpf_prog_fd = -1;
    }

    if (filter_record_p->ebpf_map_fd >= 0) {
        close(filter_record_p->ebpf_map_fd);
        filter_record_p->ebpf_map_fd = -1;
    }

    return err;
}

wjh_status_t wjh_filter_rule_add_sdk(wjh_db_filter_record_t      *filter_record_p,
                                     wjh_db_filter_rule_record_t *filter_rule_record_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint64_t     counter = 0;

    err = wjh_ebpf_map_elem_update(filter_record_p->ebpf_map_fd,
                                   &filter_rule_record_p->ebpf_key, &counter, BPF_ANY);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh_ebpf_map_elem_update failed, err: %d\n", err);
        goto out;
    }

    if (filter_rule_record_p->is_key_set[WJH_FILTER_KEY_PORT_E]) {
        err = wjh_ebpf_map_elem_update(wjh_port_bpf_map_s,
                                       &filter_rule_record_p->label_port,
                                       &filter_rule_record_p->ebpf_key.hw_port,
                                       BPF_ANY);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_map_elem_update failed, err: %d\n", err);
            goto out;
        }
    }

out:
    return err;
}

wjh_status_t wjh_filter_rule_remove_sdk(wjh_db_filter_record_t      *filter_record_p,
                                        wjh_db_filter_rule_record_t *filter_rule_record_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    err = wjh_ebpf_map_elem_delete(filter_record_p->ebpf_map_fd,
                                   &filter_rule_record_p->ebpf_key);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh_ebpf_map_elem_delete failed, err: %d\n", err);
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_filter_rule_counter_get_sdk(wjh_db_filter_record_t      *filter_record_p,
                                             wjh_db_filter_rule_record_t *filter_rule_record_p,
                                             uint8_t                      clear)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint64_t     counter = 0;

    err = wjh_ebpf_map_elem_lookup(filter_record_p->ebpf_map_fd,
                                   &filter_rule_record_p->ebpf_key,
                                   &filter_rule_record_p->counter);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh_ebpf_map_elem_delete failed, err: %d\n", err);
        goto out;
    }

    if (clear) {
        err = wjh_ebpf_map_elem_update(filter_record_p->ebpf_map_fd,
                                       &filter_rule_record_p->ebpf_key, &counter, BPF_ANY);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_map_elem_update failed, err: %d\n", err);
            goto out;
        }
        filter_rule_record_p->counter = 0;
    }

out:
    return err;
}

wjh_status_t wjh_filter_bind_channel_sdk(wjh_db_filter_record_t *filter_record_p, wjh_user_channel_record_t *channel_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    WJH_CHECK_NULL_PTR(filter_record_p, filter_record_p);
    WJH_CHECK_NULL_PTR(channel_p, channel_p);

    err = __wjh_filter_attach_detach(filter_record_p, channel_p, TRUE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to bind filter %d to channel %d.\n", filter_record_p->filter_id, channel_p->channel_id);
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_filter_unbind_channel_sdk(wjh_db_filter_record_t    *filter_record_p,
                                           wjh_user_channel_record_t *channel_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    WJH_CHECK_NULL_PTR(filter_record_p, filter_record_p);
    WJH_CHECK_NULL_PTR(channel_p, channel_p);

    err = __wjh_filter_attach_detach(filter_record_p, channel_p, FALSE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to unbind filter %d from channel %d.\n", filter_record_p->filter_id,
                    channel_p->channel_id);
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_filter_l1_match_rules(wjh_db_filter_rule_record_t **rule_record_list_pp,
                                                uint32_t                      rules_num,
                                                sx_port_log_id_t             *log_port_p,
                                                boolean_t                    *rule_matched_p)
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    uint32_t                     i = 0;
    wjh_port_log_id_t            wjh_port = 0;
    wjh_db_filter_rule_map_key_t rule_map_key;

    WJH_CHECK_NULL_PTR(rule_matched_p, rule_matched_p);

    *rule_matched_p = FALSE;

    if (log_port_p) {
        __wjh_get_wjh_port_from_sx_port(*log_port_p, &wjh_port);
    }

    for (i = 0; i < rules_num; i++) {
        memset(&rule_map_key, 0, sizeof(wjh_db_filter_rule_map_key_t));
        rule_map_key.drop_reason = WJH_DROP_REASON_ID_L1_GENERAL_E;
        rule_map_key.valid_mask = 0x2;
        if (!memcmp(&rule_map_key, &rule_record_list_pp[i]->map_key, sizeof(wjh_db_filter_rule_map_key_t))) {
            *rule_matched_p = TRUE;
            goto out;
        }

        if (log_port_p) {
            memset(&rule_map_key, 0, sizeof(wjh_db_filter_rule_map_key_t));
            rule_map_key.port = wjh_port;
            rule_map_key.valid_mask = 0x1;
            if (!memcmp(&rule_map_key, &rule_record_list_pp[i]->map_key, sizeof(wjh_db_filter_rule_map_key_t))) {
                *rule_matched_p = TRUE;
                goto out;
            }

            memset(&rule_map_key, 0, sizeof(wjh_db_filter_rule_map_key_t));
            rule_map_key.port = wjh_port;
            rule_map_key.drop_reason = WJH_DROP_REASON_ID_L1_GENERAL_E;
            rule_map_key.valid_mask = 0x3;
            if (!memcmp(&rule_map_key, &rule_record_list_pp[i]->map_key, sizeof(wjh_db_filter_rule_map_key_t))) {
                *rule_matched_p = TRUE;
                goto out;
            }
        }
    }

out:
    return err;
}

wjh_status_t wjh_filter_rules_validate_sdk(wjh_filter_rule_t *rule_list_p, uint32_t rule_count)
{
    wjh_status_t     err = WJH_STATUS_SUCCESS;
    uint32_t         i = 0, j = 0;
    sx_port_log_id_t phy_port_lag_mapping[MAX_PHYPORT_NUM + 1];
    wjh_filter_key_e key = WJH_FILTER_KEY_MIN_E;
    sx_port_log_id_t sx_port = 0;
    sx_port_type_t   port_type = SX_PORT_TYPE_INVALID;
    uint16_t         phy_port_id = 0;

    memset(phy_port_lag_mapping, 0, sizeof(sx_port_log_id_t) * (MAX_PHYPORT_NUM + 1));

    err = __prepare_port_lag_mapping(phy_port_lag_mapping);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to prepare port lag mapping.\n");
        goto out;
    }

    for (i = 0; i < rule_count; i++) {
        for (j = 0; j < rule_list_p[i].key_desc_count; j++) {
            key = rule_list_p[i].key_desc_list_p[j].key;
            switch (key) {
            case WJH_FILTER_KEY_PORT_E:
                __wjh_get_sx_port_from_wjh_port(rule_list_p[i].key_desc_list_p[j].field.port, &sx_port);
                if (sx_port == SX_INVALID_PORT) {
                    err = WJH_STATUS_PARAM_ERROR;
                    WJH_LOG_ERR("Port 0x%x is invalid port.\n", rule_list_p[i].key_desc_list_p[j].field.port);
                    goto out;
                }
                port_type = SX_PORT_TYPE_ID_GET(sx_port);
                if ((port_type != SX_PORT_TYPE_NETWORK) && (port_type != SX_PORT_TYPE_LAG)) {
                    err = WJH_STATUS_PARAM_ERROR;
                    WJH_LOG_ERR("Port 0x%x type is not network port or lag port.\n",
                                rule_list_p[i].key_desc_list_p[j].field.port);
                    goto out;
                }
                phy_port_id = SX_PORT_PHY_ID_GET(sx_port);
                if (phy_port_lag_mapping[phy_port_id] != 0) {
                    err = WJH_STATUS_PARAM_ERROR;
                    WJH_LOG_ERR("Port 0x%x is lag member of 0x%x.\n", rule_list_p[i].key_desc_list_p[j].field.port,
                                phy_port_lag_mapping[phy_port_id]);
                    goto out;
                }
                break;

            default:
                break;
            }
        }
    }

out:
    return err;
}
#endif /* ifdef WJH_EBPF_PRESENT */

static wjh_status_t __wjh_load_lag_shm(void)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    int                     rc = 0;
    size_t                  size = 0;
    sx_ladb_port_indices_t *shm_p = NULL;
    int                     shmid = -1;

    rc = cl_shm_open(LAG_SHM_PATH, &shmid);
    if (rc) {
        WJH_LOG_ERR("Failed to open the LAG shared memory\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    shm_p = mmap(NULL, sizeof(sx_ladb_port_indices_t), PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
    if (shm_p == MAP_FAILED) {
        WJH_LOG_ERR("Failed to map the LAG shared memory\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    size = sizeof(sx_ladb_port_indices_t) +
           shm_p->max_lag_ports * shm_p->max_lid * sizeof(sx_ladb_port_data_t);

    rc = munmap(shm_p, sizeof(sx_ladb_port_indices_t));
    if (rc == -1) {
        WJH_LOG_ERR("Failed to unmap the LAG shared memory\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    shm_p = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
    if (shm_p == MAP_FAILED) {
        WJH_LOG_ERR("Failed to map the LAG shared memory\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    port_indices_db_fd_s = shmid;
    port_indices_db_p = shm_p;
    port_indices_db_size_s = size;

out:
    if (WJH_CHECK_FAIL(err) && (shmid >= 0)) {
        close(shmid);
    }
    return err;
}

static wjh_status_t __wjh_unload_lag_shm(void)
{
    int rc = 0;

    rc = munmap(port_indices_db_p, port_indices_db_size_s);
    if (rc) {
        WJH_LOG_ERR("Failed to unmap the LAG shared memory\n");
        return WJH_STATUS_ERROR;
    }

    close(port_indices_db_fd_s);

    return WJH_STATUS_SUCCESS;
}

static wjh_status_t __prepare_port_lag_mapping(sx_port_log_id_t *phy_port_lag_mapping)
{
    wjh_status_t     err = WJH_STATUS_SUCCESS;
    sx_lag_id_t      lid = 0;
    sx_port_log_id_t log_port = 0;
    sx_port_log_id_t lag_port = 0;
    uint32_t         i = 0;
    uint16_t         phy_port_id = 0;

    cl_plock_acquire(&port_indices_db_p->p_lock);

    for (lid = 0; lid < port_indices_db_p->max_lid; lid++) {
        for (i = 0; i < port_indices_db_p->max_lag_ports; i++) {
            log_port = port_indices_db_p->lag_ports[GET_LAG_PORTS_INDEX(port_indices_db_p, lid, i)].port;
            if (log_port == INVALID_LAG_LOG_PORT) {
                continue;
            }
            phy_port_id = SX_PORT_PHY_ID_GET(log_port);
            lag_port = 0;
            SX_PORT_TYPE_ID_SET(lag_port, SX_PORT_TYPE_LAG);
            SX_PORT_LAG_ID_SET(lag_port, lid);
            phy_port_lag_mapping[phy_port_id] = lag_port;
        }
    }

    cl_plock_release(&port_indices_db_p->p_lock);

    return err;
}

wjh_status_t wjh_get_hw_port_sdk(wjh_port_log_id_t port, uint32_t *hw_port_p, uint16_t *label_port_p)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    sxd_status_t      sxd_err = SXD_STATUS_SUCCESS;
    sx_port_log_id_t  sx_port = 0;
    uint16_t          sysport = 0;
    sxd_port_phy_id_t local_port = 0;

    WJH_CHECK_NULL_PTR(hw_port_p, hw_port_p);

    __wjh_get_sx_port_from_wjh_port(port, &sx_port);

    switch (SX_PORT_TYPE_ID_GET(sx_port)) {
    case SX_PORT_TYPE_LAG:
        *hw_port_p = (1 << 16) | SX_PORT_LAG_ID_GET(sx_port);
        *label_port_p = SX_PORT_LAG_ID_GET(sx_port);
        break;

    case SX_PORT_TYPE_NETWORK:
        sxd_err = sxd_dpt_get_uc_route_by_local_port(SX_PORT_DEV_ID_GET(sx_port),
                                                     SX_PORT_PHY_ID_GET(sx_port),
                                                     &sysport);
        if (sxd_err != SXD_STATUS_SUCCESS) {
            err = WJH_STATUS_PARAM_ERROR;
            WJH_LOG_ERR("Failed to get sys port of sx log port.\n");
            goto out;
        }
        *hw_port_p = sysport;

        local_port = SX_PORT_PHY_ID_GET(port);
        sxd_err = sxd_dpt_mirror_label_port_map_label_port_get(WJH_DEFAULT_DEVICE_NUMBER,
                                                               local_port,
                                                               label_port_p);
        if (sxd_err != SXD_STATUS_SUCCESS) {
            WJH_LOG_ERR("Failed to get mirror label port for port 0x%x.\n", port);
            err = WJH_STATUS_ERROR;
            goto out;
        }
        break;

    default:
        err = WJH_STATUS_PARAM_ERROR;
        WJH_LOG_ERR("Invalid port type.\n");
        break;
    }

out:
    return err;
}

wjh_status_t wjh_get_chip_type_sdk(wjh_chip_types_t* chip_type)
{
    wjh_status_t       ret = WJH_STATUS_SUCCESS;
    sxd_status_t       sxd_rc = SXD_STATUS_SUCCESS;
    struct ku_mgir_reg mgir_reg;
    FILE             * f = NULL;
    int                rc;
    sxd_reg_meta_t     reg_meta;


    memset(&mgir_reg, 0, sizeof(struct ku_mgir_reg));
    memset(&reg_meta, 0, sizeof(sxd_reg_meta_t));

    f = fopen("/sys/module/sx_core/parameters/chip_info_type", "r");
    if (f == NULL) {
        WJH_LOG_ERR("failed to open /sys/module/sx_core/parameters/chip_info_type");
        return WJH_STATUS_ERROR;
    }

    rc = fscanf(f, "%" SCNu16, &mgir_reg.hw_info.device_id);
    fclose(f);

    if (rc != 1) {
        WJH_LOG_ERR("failed to open /sys/module/sx_core/parameters/chip_info_type");
        return WJH_STATUS_ERROR;
    }

    f = fopen("/sys/module/sx_core/parameters/chip_info_revision", "r");
    if (f == NULL) {
        WJH_LOG_ERR("failed to open /sys/module/sx_core/parameters/chip_info_revision");
        return WJH_STATUS_ERROR;
    }

    rc = fscanf(f, "%" SCNu16, &mgir_reg.hw_info.device_hw_revision);
    fclose(f);

    if (rc != 1) {
        WJH_LOG_ERR("failed to open /sys/module/sx_core/parameters/chip_info_revision");
        return WJH_STATUS_ERROR;
    }

    /* Validate chip type value - if device ID is maximum 16 bit unsigned integer then call sx_access_reg_mgir to retrieve chip type */
    if (mgir_reg.hw_info.device_id == 0xFFFF) {
        reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        reg_meta.dev_id = WJH_DEFAULT_DEVICE_NUMBER;
        memset(&mgir_reg, 0, sizeof(struct ku_mgir_reg));

        sxd_rc = sxd_access_reg_mgir(&mgir_reg, &reg_meta, 1, NULL, NULL);
        if (SXD_CHECK_FAIL(sxd_rc)) {
            WJH_LOG_ERR("%s: failed in get MGIR for dev_id %d, error: %d \n",
                        __func__, WJH_DEFAULT_DEVICE_NUMBER, sxd_rc);
            return WJH_STATUS_ERROR;
        }
    }


    switch (mgir_reg.hw_info.device_id) {
    case SXD_MGIR_HW_DEV_ID_SX:
        if (mgir_reg.hw_info.device_hw_revision == 0xA1) {
            *chip_type = SXD_CHIP_TYPE_SWITCHX_A1;
        } else if (mgir_reg.hw_info.device_hw_revision == 0xA2) {
            *chip_type = SXD_CHIP_TYPE_SWITCHX_A2;
        } else {
            WJH_LOG_ERR("%s Error: MGIR has unsupported SX revision 0x%04x; dev_id 0x%04x\n",
                        __func__, mgir_reg.hw_info.device_hw_revision, mgir_reg.hw_info.device_id);
            ret = WJH_STATUS_ERROR;
        }
        break;

    case SXD_MGIR_HW_DEV_ID_SWITCH_IB:
        *chip_type = SXD_CHIP_TYPE_SWITCH_IB;
        break;

    case SXD_MGIR_HW_DEV_ID_SWITCH_IB2:
        *chip_type = SXD_CHIP_TYPE_SWITCH_IB2;
        break;

    case SXD_MGIR_HW_DEV_ID_QUANTUM:
        *chip_type = SXD_CHIP_TYPE_QUANTUM;
        break;

    case SXD_MGIR_HW_DEV_ID_QUANTUM2:
        *chip_type = SXD_CHIP_TYPE_QUANTUM2;
        break;

    case SXD_MGIR_HW_DEV_ID_QUANTUM3:
        *chip_type = SXD_CHIP_TYPE_QUANTUM3;
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM:
        *chip_type = SXD_CHIP_TYPE_SPECTRUM;
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM2:
        *chip_type = SXD_CHIP_TYPE_SPECTRUM2;
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM3:
        *chip_type = SXD_CHIP_TYPE_SPECTRUM3;
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM4:
        *chip_type = SXD_CHIP_TYPE_SPECTRUM4;
        break;

    case SXD_MGIR_HW_DEV_ID_SPECTRUM5:
        *chip_type = SXD_CHIP_TYPE_SPECTRUM5;
        break;

    default:
        WJH_LOG_ERR("%s Error: MGIR has unsupported Device ID 0x%04x; revision 0x%04x\n",
                    __func__, mgir_reg.hw_info.device_id, mgir_reg.hw_info.device_hw_revision);
        ret = WJH_STATUS_ERROR;
    }

    return ret;
}

wjh_status_t wjh_update_shm_sdk(wjh_driver_shm_data_t *driver_shm_data_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    wjh_stat_t   stat_buf;
    int          err_no = 0;
    char        *sdk_ready_file = NULL;

    if (driver_shm_data_p == NULL) {
        err = WJH_STATUS_PARAM_NULL;
        WJH_LOG_ERR("Wjh driver data ptr is not valid\n");
        goto out;
    }

    sdk_ready_file = getenv("SDK_READY_FILE");
    if (sdk_ready_file == NULL) {
        sdk_ready_file = SDK_READY_FILENAME;
    }

    err_no = stat(sdk_ready_file, &stat_buf);
    if (err_no != 0) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh failed to stat SDK ready file, SDK not ready \n");
        goto out;
    }

    driver_shm_data_p->shm_sdk_instance_info.sdk_file_stat_info.st_mtim.tv_sec = stat_buf.st_mtim.tv_sec;
    driver_shm_data_p->shm_sdk_instance_info.sdk_file_stat_info.st_mtim.tv_nsec = stat_buf.st_mtim.tv_nsec;

out:
    return err;
}

wjh_status_t wjh_user_channel_tac_set_sdk(wjh_user_channel_record_t *user_channel_p,
                                          wjh_span_session_id_t      span_session_id)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    sx_status_t       sdk_rc = SX_STATUS_SUCCESS;
    sx_tele_tac_cfg_t tac_cfg = {0};

    tac_cfg.tac_to_net_span_id = span_session_id;
    sdk_rc = sx_api_tele_tac_set(sx_api_handle_s, SX_ACCESS_CMD_SET, user_channel_p->hw_trap_group, &tac_cfg);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to set sx_api_tele_tac_set, error: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
    }
    return err;
}

wjh_status_t wjh_user_channel_timestamp_source_set_sdk(wjh_user_channel_id_t               channel_id,
                                                       wjh_user_channel_timestamp_source_e timestamp_source)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    wjh_dev_specific_cb_t *wjh_dev_cb_p = NULL;

#ifdef WJH_EBPF_PRESENT
    wjh_user_channel_record_t *user_channel_p = NULL;
    uint32_t                   index = 0;
#endif

    wjh_dev_cb_p = wjh_db_get_dev_cb();

    if ((wjh_dev_cb_p == NULL) || (wjh_dev_cb_p->wjh_user_channel_timestamp_source_set_cb == NULL)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh lib dev specific callback not valid");
        goto out;
    }

    err = wjh_dev_cb_p->wjh_user_channel_timestamp_source_set_cb(sx_api_handle_s, channel_id, timestamp_source);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Wjh lib dev specific cb wjh_user_channel_timestamp_source_set_cb failed, err=%u\n", err);
        goto out;
    }

#ifdef WJH_EBPF_PRESENT
    wjh_db_user_channel_get(channel_id, &user_channel_p);
    if (user_channel_p->bound[WJH_DROP_REASON_GROUP_BUFFER_E] &&
        (wjh_agg_comm_map_fd != -1)) {
        index = 2;
        err = wjh_ebpf_map_elem_update(wjh_agg_comm_map_fd, &index, &timestamp_source, BPF_ANY);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_map_elem_update failed, err: %d\n", err);
            goto out;
        }
    }
#endif

out:
    return err;
}

wjh_status_t wjh_validate_shm_sdk(wjh_driver_shm_data_t *driver_shm_data_p, boolean_t *is_valid_p)
{
    wjh_status_t                   err = WJH_STATUS_SUCCESS;
    wjh_sdk_ready_file_stat_info_t sdk_file_stat_info;
    wjh_stat_t                     stat_buf;
    int                            err_no = 0;
    char                          *sdk_ready_file = NULL;

    if (driver_shm_data_p == NULL) {
        err = WJH_STATUS_PARAM_NULL;
        WJH_LOG_ERR("Wjh driver data ptr is not valid\n");
        goto out;
    }

    WJH_MEM_CLR(stat_buf);

    sdk_ready_file = getenv("SDK_READY_FILE");
    if (sdk_ready_file == NULL) {
        sdk_ready_file = SDK_READY_FILENAME;
    }

    err_no = stat(sdk_ready_file, &stat_buf);
    if (err_no != 0) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh failed to stat SDK ready file, SDK not ready \n");
        goto out;
    }

    sdk_file_stat_info = driver_shm_data_p->shm_sdk_instance_info.sdk_file_stat_info;
    if ((sdk_file_stat_info.st_mtim.tv_sec == 0) && (sdk_file_stat_info.st_mtim.tv_nsec == 0)) {
        *is_valid_p = FALSE;
        goto out;
    }

    if ((sdk_file_stat_info.st_mtim.tv_sec != stat_buf.st_mtim.tv_sec) ||
        (sdk_file_stat_info.st_mtim.tv_nsec != stat_buf.st_mtim.tv_nsec)) {
        *is_valid_p = FALSE;
        goto out;
    }

    *is_valid_p = TRUE;
out:
    return err;
}

#ifdef WJH_EBPF_PRESENT
wjh_status_t wjh_set_debugfs_path_sdk(const wjh_init_param_t *param_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    const char * debugfs_path = WJH_DEBUGFS_PATH_DEFAULT;

    if ((param_p != NULL) && (param_p->debug_fs_path != NULL)) {
        if ((strlen(param_p->debug_fs_path) + 1) > PATH_MAX) {
            WJH_LOG_ERR("The specified debug file system path is too long.\n");
            err = WJH_STATUS_PARAM_ERROR;
            goto out;
        }
        debugfs_path = param_p->debug_fs_path;
    }

    strncpy(wjh_debugfs_path_s, debugfs_path, (PATH_MAX - 1));

out:
    return err;
}
#endif

static wjh_status_t __wjh_get_port_log_id_from_label_port(uint16_t label_port, wjh_port_log_id_t *port_log_id_p)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    sx_status_t       sx_rc = SX_STATUS_SUCCESS;
    sxd_port_phy_id_t local_port = 0;

    sx_rc =
        sxd_status_to_sx_status(sxd_dpt_mirror_label_port_map_port_get(WJH_DEFAULT_DEVICE_NUMBER, label_port,
                                                                       &local_port));
    if (SX_CHECK_FAIL(sx_rc)) {
        WJH_LOG_ERR("Failed to get mirror label port mapping for label port 0x%x, (%s)\n", label_port,
                    sx_status_str(sx_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    *port_log_id_p = 0;
    SX_PORT_DEV_ID_SET(*port_log_id_p, WJH_DEFAULT_DEVICE_NUMBER);
    SX_PORT_TYPE_ID_SET(*port_log_id_p, SX_PORT_TYPE_NETWORK);
    SX_PORT_PHY_ID_SET(*port_log_id_p, local_port);

out:
    return err;
}

#ifdef WJH_EBPF_PRESENT
static wjh_status_t __wjh_get_port_lag_log_id(uint32_t           port,
                                              boolean_t          from_cqe,
                                              wjh_port_log_id_t *port_log_id_p,
                                              uint8_t           *is_lag_member_p,
                                              wjh_port_log_id_t *lag_log_id_p)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    sx_status_t       sx_rc = SX_STATUS_SUCCESS;
    uint8_t           is_lag = WJH_EXTRACT_IS_LAG(port);
    uint8_t           lag_subport = WJH_EXTRACT_LAG_SUBPORT(port);
    uint16_t          sysport_lag_id = WJH_EXTRACT_SYSPORT_LAG_ID(port);
    wjh_port_log_id_t port_log_id = WJH_INVALID_PORT_ID;
    wjh_port_log_id_t lag_log_id = WJH_INVALID_PORT_ID;
    sxd_dev_id_t      dev_id;
    sxd_port_phy_id_t local_port;

    if (is_lag) {
        /* If the LAG information comes from CQE, we can get both the member port logical ID and LAG logical ID.
         * If the LAG information comes from mirror header, we can only get the LAG logical ID as the LAG subport index
         * is not provided in the mirror header.
         */
        if (from_cqe) {
            if ((sysport_lag_id > port_indices_db_p->max_lid) || (lag_subport > port_indices_db_p->max_lag_ports)) {
                WJH_LOG_ERR("Received invalid LAG ID %u or LAG subport index %u\n", sysport_lag_id, lag_subport);
                err = WJH_STATUS_ERROR;
                goto out;
            }

            cl_plock_acquire(&port_indices_db_p->p_lock);
            port_log_id =
                port_indices_db_p->lag_ports[GET_LAG_PORTS_INDEX(port_indices_db_p, sysport_lag_id, lag_subport)].port;
            cl_plock_release(&port_indices_db_p->p_lock);
            port_log_id = wjh_sdk_interface_info_get(port_log_id, port_log_id);
        }

        SX_PORT_TYPE_ID_SET(lag_log_id, SX_PORT_TYPE_LAG);
        SX_PORT_LAG_ID_SET(lag_log_id, sysport_lag_id);
        lag_log_id = wjh_sdk_interface_info_get(lag_log_id, port_log_id);
    } else {
        /* If the port information comes from CQE, it carries system port number.
         * If the port information comes from mirror header, it carries the label port number.
         */
        if (from_cqe) {
            sx_rc = sxd_status_to_sx_status(sxd_dpt_get_local_port_by_uc_route(sysport_lag_id, &dev_id, &local_port));
            if (SX_CHECK_FAIL(sx_rc)) {
                WJH_LOG_ERR("sxd_dpt_get_local_port_by_uc_route failed, error: %d\n", sx_rc);
                err = WJH_STATUS_ERROR;
                goto out;
            }

            SX_PORT_PHY_ID_SET(port_log_id, local_port);
            SX_PORT_DEV_ID_SET(port_log_id, dev_id);
            SX_PORT_TYPE_ID_SET(port_log_id, SX_PORT_TYPE_NETWORK);
        } else {
            err = __wjh_get_port_log_id_from_label_port(sysport_lag_id, &port_log_id);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_get_port_log_id_from_label_port_and_split_num failed, err: %d\n", err);
                goto out;
            }
        }
        port_log_id = wjh_sdk_interface_info_get(port_log_id, port_log_id);
    }

    *port_log_id_p = port_log_id;
    *is_lag_member_p = is_lag;
    *lag_log_id_p = lag_log_id;

out:
    return err;
}

static wjh_status_t __wjh_monitor_rdq_trace_points_enable(void)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (wjh_enable_monitor_rdq_trace_points_refcnt == 0) {
        err = wjh_aggregation_set_monitor_rdq_trace_points_sdk(TRUE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_aggregation_set_monitor_rdq_trace_points_sdk failed, err: %d\n", err);
            goto out;
        }
    }
    ++wjh_enable_monitor_rdq_trace_points_refcnt;

out:
    return err;
}

static wjh_status_t __wjh_monitor_rdq_trace_points_disable(void)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (wjh_enable_monitor_rdq_trace_points_refcnt > 0) {
        --wjh_enable_monitor_rdq_trace_points_refcnt;
        if (wjh_enable_monitor_rdq_trace_points_refcnt == 0) {
            err = wjh_aggregation_set_monitor_rdq_trace_points_sdk(FALSE);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("wjh_aggregation_set_monitor_rdq_trace_points_sdk failed, err: %d\n", err);
                goto out;
            }
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_bpf_jit_proc_fs_set(boolean_t enable)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    FILE        *fp = NULL;
    int          value = enable ? 1 : 0;

    fp = fopen(WJH_BPF_JIT_PROC_FS_ENTRY, "w");
    if (fp == NULL) {
        if (errno == ENOENT) {
            err = WJH_STATUS_SUCCESS;
            if (enable) {
                WJH_LOG_NTC("The file %s does not exist, please enable kernel option CONFIG_BPF_JIT "
                            "so as to benefit from the CPU utilization enhancement brought by kernel BPF just-in-time compiler.\n",
                            WJH_BPF_JIT_PROC_FS_ENTRY);
            }
        } else {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to open file %s, err: %s\n", WJH_BPF_JIT_PROC_FS_ENTRY, strerror(errno));
        }
        goto out;
    }

    if (fprintf(fp, "%d", value) < 0) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to write file %s\n", WJH_BPF_JIT_PROC_FS_ENTRY);
        goto out;
    }

out:
    if (fp != NULL) {
        fclose(fp);
    }

    return err;
}

#endif /* ifdef WJH_EBPF_PRESENT */
