/*
 * Copyright © 2001-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_CALLBACKS_H_
#define WJH_CALLBACKS_H_

#include "wjh/wjh_lib.h"
#include "wjh_db.h"

/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

typedef struct wjh_driver_specific_callback {
    wjh_status_t (*wjh_init_cb)(void);
    wjh_status_t (*wjh_deinit_cb)(void);
    wjh_status_t (*wjh_policer_create_cb)(uint8_t percentage);
    wjh_status_t (*wjh_policer_destroy_cb)(void);
    wjh_status_t (*wjh_user_channel_validate_cb)(wjh_user_channel_type_e channel_type);
    wjh_status_t (*wjh_user_channel_create_cb)(wjh_user_channel_type_e    channel_type,
                                               wjh_user_channel_record_t *user_channel_p);
    wjh_status_t (*wjh_user_channel_destroy_cb)(wjh_user_channel_record_t *user_channel_p);
    wjh_status_t (*wjh_user_channel_flush_cb)(wjh_user_channel_record_t *user_channel_p);
    wjh_status_t (*wjh_drop_reason_group_validate_cb)(wjh_drop_reason_group_e drop_reason_group);
    wjh_status_t (*wjh_drop_reason_group_init_cb)(const wjh_drop_reason_group_e       drop_reason_group,
                                                  const wjh_drop_reason_group_attr_t *attr_p);
    wjh_status_t (*wjh_drop_reason_group_deinit_cb)(const wjh_drop_reason_group_e drop_reason_group);
    wjh_status_t (*wjh_drop_reason_group_bind_cb)(wjh_user_channel_record_t      *user_channel_p,
                                                  wjh_drop_reason_group_record_t *group_item_p);
    wjh_status_t (*wjh_drop_reason_group_unbind_cb)(wjh_user_channel_record_t      *user_channel_p,
                                                    wjh_drop_reason_group_record_t *group_item_p);
    wjh_status_t (*wjh_drop_reason_group_enable_cb)(wjh_user_channel_record_t      *user_channel_p,
                                                    wjh_drop_reason_group_record_t *group_item_p,
                                                    uint8_t                         severity_bits);
    wjh_status_t (*wjh_drop_reason_group_disable_cb)(wjh_user_channel_record_t      *user_channel_p,
                                                     wjh_drop_reason_group_record_t *group_item_p,
                                                     uint8_t                         severity_bits);
    wjh_status_t (*wjh_drop_reason_group_update_cb)(wjh_drop_reason_group_record_t *group_item_p);
    wjh_status_t (*wjh_counter_dropped_packets_get_cb)(wjh_user_channel_record_t *user_channel_p,
                                                       uint64_t *dropped_packets_p, uint8_t clear);
    wjh_status_t (*wjh_get_hw_port_cb)(wjh_port_log_id_t port, uint32_t *hw_port_p, uint16_t *label_port_p);
    wjh_status_t (*wjh_filter_rules_validate_cb)(wjh_filter_rule_t *rule_list_p, uint32_t rule_count);
    wjh_status_t (*wjh_filter_create_cb)(wjh_db_filter_record_t *filter_record_p);
    wjh_status_t (*wjh_filter_destroy_cb)(wjh_db_filter_record_t *filter_record_p);
    wjh_status_t (*wjh_filter_rule_add_cb)(wjh_db_filter_record_t      *filter_record_p,
                                           wjh_db_filter_rule_record_t *filter_rule_record_p);
    wjh_status_t (*wjh_filter_rule_remove_cb)(wjh_db_filter_record_t      *filter_record_p,
                                              wjh_db_filter_rule_record_t *filter_rule_record_p);
    wjh_status_t (*wjh_filter_rule_counter_get_cb)(wjh_db_filter_record_t      *filter_record_p,
                                                   wjh_db_filter_rule_record_t *filter_rule_record_p,
                                                   uint8_t                      clear);
    wjh_status_t (*wjh_filter_bind_channel_cb)(wjh_db_filter_record_t    *filter_record_p,
                                               wjh_user_channel_record_t *channel_p);
    wjh_status_t (*wjh_filter_unbind_channel_cb)(wjh_db_filter_record_t    *filter_record_p,
                                                 wjh_user_channel_record_t *channel_p);

    wjh_status_t (*wjh_resources_pre_init_clean_up_cb)(wjh_drop_reason_group_shm_data_t *drop_reason_shm_data_p,
                                                       wjh_user_channel_shm_data_t      *user_channel_shm_data_p);
    wjh_status_t (*wjh_resources_post_init_clean_up_cb)();
    wjh_status_t (*wjh_polling_thread_buf_create_cb)(wjh_user_channel_record_t *user_channel_p, void **buf_pp);
    wjh_status_t (*wjh_polling_thread_buf_destroy_cb)(wjh_user_channel_record_t *user_channel_p, void *buf_p);
    wjh_status_t (*wjh_user_channel_process_cb)(wjh_user_channel_record_t *user_channel_p, void *buf_p,
                                                boolean_t is_pull_api);
    wjh_status_t (*wjh_user_channel_fd_get_cb)(wjh_user_channel_record_t *user_channel_p, int *fd_p);
    wjh_status_t (*wjh_get_chip_type_cb)(wjh_chip_types_t *chip_type_p);
    wjh_status_t (*wjh_validate_shm_cb)(wjh_driver_shm_data_t *driver_data_p, boolean_t *is_valid_p);
    wjh_status_t (*wjh_update_shm_cb)(wjh_driver_shm_data_t *driver_data_p);
    wjh_status_t (*wjh_user_channel_timestamp_source_set_cb)(wjh_user_channel_id_t               channel_id,
                                                             wjh_user_channel_timestamp_source_e timestamp_source);
    wjh_status_t (*wjh_user_channel_tac_set_cb)(wjh_user_channel_record_t *user_channel_p,
                                                wjh_span_session_id_t      span_session_id);
#ifdef WJH_EBPF_PRESENT
    wjh_status_t (*wjh_set_debugfs_path_cb)(const wjh_init_param_t *param_p);
    wjh_status_t (*wjh_ebpf_prepare_cb)(void);
    wjh_status_t (*wjh_ebpf_cleanup_cb)(void);
    wjh_status_t (*wjh_aggregation_set_monitor_rdq_trace_points_cb)(boolean_t enable);
#endif
} wjh_driver_specific_callback_t;

/************************************************
 *  Function declarations
 ***********************************************/


#endif /* WJH_CALLBACKS_H_ */
