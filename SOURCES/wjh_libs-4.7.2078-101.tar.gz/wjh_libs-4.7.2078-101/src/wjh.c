/*
 * Copyright © 2001-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <string.h>
#include <sys/eventfd.h>
#include <wjh/wjh_lib.h>
#include <complib/cl_thread.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_mem.h>
#include <complib/cl_shared_memory.h>
#include <complib/cl_math.h>
#include <linux/limits.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#ifdef WJH_INOTIFY_PRESENT
#include <sys/syscall.h>
#include <sys/inotify.h>
#endif
#include "wjh_db.h"
#include "wjh_common.h"
#include "wjh_callbacks.h"
#include "wjh_log.h"
#include "wjh_netlink.h"

/************************************************
 *  Local Macros
 ***********************************************/

#define WJH_LIBS_SHM_PATH                                "/wjh_libs_shm"
#define WJH_BANDWIDTH_PERCENTAGE_DEFAULT                 (80)
#define WJH_WATCHDOG_THREAD_SLEEP_INTERVAL               (100000)   /* 100 ms */
#define WJH_FORCE_INIT_SLEEP_COUNT                       (100)
#define WJH_FORCE_INIT_SLEEP_INTERVAL                    (100000)   /* 100 ms */
#define WJH_CYCLIC_CHANNEL_DEFAULT_POLLING_INTERVAL      (5000)  /* 5000 ms */
#define WJH_AGGREGATION_CHANNEL_DEFAULT_POLLING_INTERVAL (30000) /* 30000 ms */
#define WJH_LIB_NAME_STR                                 "libwjh.so"
#define WJH_CONF_FILE_RELATIVE_PATH                      "etc/wjh_lib_conf.xml"
#define WJH_DROP_REASON_GROUP_MAX_ENTRIES_CNT_DEFAULT    (1024)

#define WJH_FILTER_RULE_MAX_NUM (1024)
#define WJH_THREAD_NAME_MAX_LEN (15)

/************************************************
 *  Local Type definitions
 ***********************************************/

typedef enum wjh_force_init_status {
    WJH_FORCE_INIT_OK = 0, /* The force initialization is not started yet or ended successfully. */
    WJH_FORCE_INIT_IN_PROGRESS, /* The force initialization is in progress. */
    WJH_FORCE_INIT_ERROR, /* The force initialization ended with error. */
} wjh_force_init_status_e;

typedef struct wjh_shm_data {
    wjh_force_init_status_e          force_init_flag;
    int                              init_file_lock; /* Placeholder for the init file lock */
    int                              singleton_file_lock; /* Placeholder for the singleton file lock */
    wjh_drop_reason_group_shm_data_t drop_reason_shm_data; /*Shm data to clean up the previous instance if required */
    wjh_driver_shm_data_t            driver_shm_data;     /*wjh driver specific data in shm to aid proper clean up*/
    wjh_user_channel_shm_data_t      user_channel_shm_data;
} wjh_shm_data_t;

typedef enum wjh_file_lock_type {
    WJH_INIT_FILE_LOCK,
    WJH_SINGLETON_FILE_LOCK
} wjh_file_lock_type_e;

/************************************************
 *  Global variables
 ***********************************************/
boolean_t                              wjh_init_done_g = FALSE;
extern wjh_driver_specific_callback_t *wjh_driver_specific_callbacks_g;
cl_plock_t                             wjh_bind_enable_rwlock_g = {
    .lock = PTHREAD_RWLOCK_INITIALIZER,
    .state = CL_INITIALIZED
};
#ifdef WJH_EBPF_PRESENT
char wjh_ebpf_prog_dir_g[PATH_MAX];
#endif
wjh_init_param_t wjh_init_params_g;
/************************************************
 *  Local variables
 ***********************************************/
static cl_thread_t     wjh_watchdog_thread_id_s;
static cl_thread_t     wjh_xml_monitor_thread_id_s;
static cl_spinlock_t   wjh_api_spinlock_s = {
    .mutex = PTHREAD_MUTEX_INITIALIZER,
    .state = CL_INITIALIZED
};
static boolean_t       wjh_stop_xml_monitor_thread_s = TRUE;
static boolean_t       wjh_stop_watchdog_thread_s = TRUE;
static int             wjh_xml_monitor_thread_cmd_event_fd_s = -1;
static wjh_shm_data_t *wjh_shm_ptr_s = NULL;
static int             wjh_shm_fd_s;
static char            wjh_xml_path_s[PATH_MAX];
static char            wjh_default_xml_path_s[PATH_MAX];

/************************************************
 *  Local function declarations
 ***********************************************/
static wjh_status_t __wjh_open_shm(void);
static wjh_status_t __wjh_close_shm(void);
static wjh_status_t __wjh_get_file_lock_start_and_len(wjh_file_lock_type_e lock_type, off_t *start_p, off_t *len_p);
static wjh_status_t __wjh_acquire_file_lock(wjh_file_lock_type_e lock_type, boolean_t is_read_lock);
static wjh_status_t __wjh_release_file_lock(wjh_file_lock_type_e lock_type);
static wjh_status_t __wjh_is_file_locked(wjh_file_lock_type_e lock_type, boolean_t *is_locked_p);
static wjh_status_t __wjh_termiate_another_instance(void);
static wjh_status_t __wjh_resources_pre_init_clean_up(wjh_drop_reason_group_shm_data_t *drop_reason_shm_data_p,
                                                      wjh_user_channel_shm_data_t      *user_channel_shm_data_p);
static wjh_status_t __wjh_resources_post_init_clean_up();
static void __wjh_polling_thread_func(void *args_p);
static void __wjh_event_driven_thread_func(void *args_p);
#ifdef WJH_INOTIFY_PRESENT
static wjh_status_t __wjh_xml_monitor_prepare_inotify(int *inotify_fd_p, int *watch_fd_p, char *xml_file_name);
static wjh_status_t __wjh_xml_monitor_close_inotify(int notify_fd, int watch_fd);
static void __wjh_xml_monitor_thread_inotify(int inotify_fd, const char *xml_file_name);
#endif
static void __wjh_xml_monitor_thread_polling(void);
static void __wjh_xml_monitor_thread_func(void *args_p);
static wjh_status_t __wjh_deinit_from_watchdog_thread(void);
static void __wjh_watchdog_thread_func(void *args);
static wjh_status_t __wjh_destroy_cmd_event_fds(void);
static wjh_status_t __wjh_deinit_wrapper(void);
static wjh_status_t __wjh_thread_destroy(cl_thread_t *thread_id_p,
                                         boolean_t   *stop_thread_flag_p,
                                         int         *cmd_event_fd_p);
static wjh_status_t __wjh_user_channel_destroy(wjh_user_channel_record_t *user_channel_p);
static wjh_status_t __wjh_drop_reason_group_unbind(wjh_drop_reason_group_record_t *group_item_p);
static wjh_status_t __wjh_get_default_xml_file_path(char* path, int size);
static wjh_status_t __wjh_wipe_drop_reason_shm_data();
static wjh_status_t __wjh_drop_reason_item_wipe_shm_data(wjh_drop_reason_group_e drop_reason_group);
static wjh_status_t __wjh_drop_reason_item_save_shm_data(wjh_drop_reason_group_e drop_reason_group);
#ifdef WJH_EBPF_PRESENT
static wjh_status_t __wjh_get_ebpf_prog_path(void);
static wjh_status_t __wjh_set_debugfs_path(const wjh_init_param_t *param_p);
#endif
static wjh_status_t __wjh_drop_reason_severity_update(void);
static wjh_status_t __wjh_configuration_update(void);
static wjh_status_t __wjh_user_channel_thread_create(wjh_user_channel_record_t *user_channel_p);
static wjh_status_t __wjh_drop_reason_group_bind_check(wjh_user_channel_type_e         channel_type,
                                                       wjh_user_channel_destination_e  user_channel_dest,
                                                       wjh_drop_reason_group_record_t *group_item_p);


/************************************************
 *  Function implementations
 ***********************************************/
static wjh_status_t __wjh_open_shm(void)
{
    int          shmid;
    cl_status_t  cl_err = CL_SUCCESS;
    wjh_status_t err = WJH_STATUS_SUCCESS;
    int          unix_err = 0;
    boolean_t    shmid_opened = FALSE;

    cl_err = cl_shm_create(WJH_LIBS_SHM_PATH, &shmid);
    if (cl_err != CL_SUCCESS) {
        if (errno == EEXIST) {
            cl_err = cl_shm_open(WJH_LIBS_SHM_PATH, &shmid);
        }

        if (cl_err != CL_SUCCESS) {
            WJH_LOG_ERR("Failed to open the WJH libs shared memory, err=%s\n", strerror(errno));
            err = WJH_STATUS_ERROR;
            goto out;
        }
    }

    wjh_shm_fd_s = shmid;
    shmid_opened = TRUE;

    unix_err = ftruncate(shmid, sizeof(wjh_shm_data_t));
    if (unix_err) {
        WJH_LOG_ERR("truncate error %s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    wjh_shm_ptr_s = mmap(NULL, sizeof(wjh_shm_data_t), PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
    if (wjh_shm_ptr_s == MAP_FAILED) {
        WJH_LOG_ERR("Failed to map the shared memory of WJH libs\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    if (shmid_opened && WJH_CHECK_FAIL(err)) {
        close(shmid);
    }
    return err;
}

static wjh_status_t __wjh_close_shm(void)
{
    int unix_err = 0;

    unix_err = munmap(wjh_shm_ptr_s, sizeof(wjh_shm_data_t));
    if (unix_err) {
        WJH_LOG_ERR("Failed to unmap the shared memory of the WJH libs\n");
        return WJH_STATUS_ERROR;
    }

    close(wjh_shm_fd_s);

    return WJH_STATUS_SUCCESS;
}

static wjh_status_t __wjh_get_file_lock_start_and_len(wjh_file_lock_type_e lock_type, off_t *start_p, off_t *len_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    switch (lock_type) {
    case WJH_INIT_FILE_LOCK:
        *start_p = (off_t)(&(((wjh_shm_data_t*)0)->init_file_lock));
        *len_p = (off_t)(sizeof((((wjh_shm_data_t*)0)->init_file_lock)));
        break;

    case WJH_SINGLETON_FILE_LOCK:
        *start_p = (off_t)(&(((wjh_shm_data_t*)0)->singleton_file_lock));
        *len_p = (off_t)(sizeof((((wjh_shm_data_t*)0)->singleton_file_lock)));
        break;

    default:
        WJH_LOG_ERR("Invalid file lock type: %u\n", lock_type);
        err = WJH_STATUS_PARAM_ERROR;
        break;
    }

    return err;
}

static wjh_status_t __wjh_acquire_file_lock(wjh_file_lock_type_e lock_type, boolean_t is_read_lock)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    struct flock file_lock;
    off_t        start = 0;
    off_t        len = 0;

    err = __wjh_get_file_lock_start_and_len(lock_type, &start, &len);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_get_file_lock_start_and_len failed, err = %d\n", err);
        goto out;
    }

    memset(&file_lock, 0, sizeof(file_lock));
    file_lock.l_type = is_read_lock ? F_RDLCK : F_WRLCK;
    file_lock.l_start = start;
    file_lock.l_whence = SEEK_SET;
    file_lock.l_len = len;
    if (fcntl(wjh_shm_fd_s, F_SETLK, &file_lock) < 0) {
        if ((errno == EACCES) || (errno == EAGAIN)) {
            err = WJH_STATUS_IN_PROGRESS;
            WJH_LOG_ERR("Another process has already held lock type %u\n", lock_type);
        } else {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to acquire lock type %u, error: %s\n", lock_type, strerror(errno));
        }
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_release_file_lock(wjh_file_lock_type_e lock_type)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    struct flock file_lock;
    off_t        start = 0;
    off_t        len = 0;

    err = __wjh_get_file_lock_start_and_len(lock_type, &start, &len);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_get_file_lock_start_and_len failed, err = %d\n", err);
        goto out;
    }

    memset(&file_lock, 0, sizeof(file_lock));
    file_lock.l_type = F_UNLCK;
    file_lock.l_start = start;
    file_lock.l_whence = SEEK_SET;
    file_lock.l_len = len;
    if (fcntl(wjh_shm_fd_s, F_SETLK, &file_lock) < 0) {
        WJH_LOG_ERR("Failed to unlock lock type %u, error: %s\n", lock_type, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_is_file_locked(wjh_file_lock_type_e lock_type, boolean_t *is_locked_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    struct flock file_lock;
    off_t        start = 0;
    off_t        len = 0;

    err = __wjh_get_file_lock_start_and_len(lock_type, &start, &len);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_get_file_lock_start_and_len failed, err = %d\n", err);
        goto out;
    }

    memset(&file_lock, 0, sizeof(file_lock));
    file_lock.l_type = F_WRLCK;
    file_lock.l_start = start;
    file_lock.l_whence = SEEK_SET;
    file_lock.l_len = len;
    if (fcntl(wjh_shm_fd_s, F_GETLK, &file_lock) < 0) {
        WJH_LOG_ERR("Failed to get lock status of lock type %u, error: %s", lock_type, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    *is_locked_p = (file_lock.l_type != F_UNLCK);

out:
    return err;
}

static wjh_status_t __wjh_termiate_another_instance(void)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    int          i = 0;

    wjh_shm_ptr_s->force_init_flag = WJH_FORCE_INIT_IN_PROGRESS;
    msync(wjh_shm_ptr_s, sizeof(wjh_shm_data_t), MS_SYNC);
    while (i <= WJH_FORCE_INIT_SLEEP_COUNT) {
        if (wjh_shm_ptr_s->force_init_flag == WJH_FORCE_INIT_IN_PROGRESS) {
            usleep(WJH_FORCE_INIT_SLEEP_INTERVAL);
            ++i;
        } else {
            break;
        }
    }

    if (wjh_shm_ptr_s->force_init_flag == WJH_FORCE_INIT_OK) {
        err = WJH_STATUS_SUCCESS;
    } else {
        err = WJH_STATUS_ERROR;
    }

    return err;
}

static wjh_status_t __wjh_resources_pre_init_clean_up(wjh_drop_reason_group_shm_data_t *drop_reason_shm_data_p,
                                                      wjh_user_channel_shm_data_t      *user_channel_shm_data_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (wjh_driver_specific_callbacks_g->wjh_resources_pre_init_clean_up_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_resources_pre_init_clean_up_cb(drop_reason_shm_data_p,
                                                                                  user_channel_shm_data_p);
    }

    return err;
}

static wjh_status_t __wjh_drop_reason_group_deinit(const wjh_drop_reason_group_e drop_reason_group)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (wjh_driver_specific_callbacks_g->wjh_drop_reason_group_deinit_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_drop_reason_group_deinit_cb(drop_reason_group);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_drop_reason_group_deinit_cb failed, err: %d\n", err);
            goto out;
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_resources_post_init_clean_up()
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_e         drop_reason_group;
    wjh_drop_reason_group_record_t *drop_reason_group_item_p;

    for (drop_reason_group = WJH_DROP_REASON_GROUP_MIN_E;
         drop_reason_group <= WJH_DROP_REASON_GROUP_MAX_E;
         ++drop_reason_group) {
        wjh_db_drop_reason_group_get(drop_reason_group, &drop_reason_group_item_p);
        if (!drop_reason_group_item_p->bound) {
            continue;
        }

        err = __wjh_drop_reason_group_unbind(drop_reason_group_item_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_drop_reason_group_unbind failed, err = %d\n", err);
            goto out;
        }
    }

    if (wjh_driver_specific_callbacks_g->wjh_resources_post_init_clean_up_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_resources_post_init_clean_up_cb();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_resources_post_init_clean_up_cb failed, err = %d\n", err);
            goto out;
        }
    }

    for (drop_reason_group = WJH_DROP_REASON_GROUP_MIN_E;
         drop_reason_group <= WJH_DROP_REASON_GROUP_MAX_E;
         ++drop_reason_group) {
        wjh_db_drop_reason_group_get(drop_reason_group, &drop_reason_group_item_p);
        if (!drop_reason_group_item_p->inited) {
            continue;
        }

        err = __wjh_drop_reason_group_deinit(drop_reason_group);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_drop_reason_group_deinit failed, err: %d\n", err);
            goto out;
        }

        drop_reason_group_item_p->bound = FALSE;
        drop_reason_group_item_p->enabled_severity_bits = 0;
        drop_reason_group_item_p->inited = FALSE;
    }
out:
    return err;
}

static void __wjh_polling_thread_func(void *args_p)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    fd_set                     fds;
    int                        max_fd = 0;
    int                        ret = 0;
    uint64_t                   ef_cnt = 0;
    struct timeval             timeout;
    void                      *buff_p = NULL;
    wjh_user_channel_record_t *user_channel_p = (wjh_user_channel_record_t*)args_p;
    uint32_t                   polling_interval;
    struct timeval            *timeout_p = NULL;

    if (wjh_driver_specific_callbacks_g->wjh_polling_thread_buf_create_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_polling_thread_buf_create_cb(user_channel_p, &buff_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_polling_thread_buf_create_cb failed, err = %d\n", err);
            return;
        }
    }

    while (!user_channel_p->stop_thread) {
        max_fd = -1;
        FD_ZERO(&fds);
        FD_SET(user_channel_p->cmd_event_fd, &fds);
        max_fd = MAX(max_fd, user_channel_p->cmd_event_fd);

        if (user_channel_p->mode == WJH_USER_CHANNEL_MODE_PUSH_E) {
            polling_interval = user_channel_p->polling_interval;
            timeout.tv_sec = polling_interval / 1000;
            timeout.tv_usec = (__suseconds_t)(polling_interval - (1000 * (polling_interval / 1000))) * 1000;
            timeout_p = &timeout;
        } else {
            timeout_p = NULL;
        }

        ret = select(max_fd + 1, &fds, NULL, NULL, timeout_p);
        if (ret < 0) {
            WJH_LOG_DBG("The select returns error.\n");
            continue;
        }

        if (FD_ISSET(user_channel_p->cmd_event_fd, &fds)) {
            ret = read(user_channel_p->cmd_event_fd, &ef_cnt, sizeof(uint64_t));
            if (ret < 0) {
                WJH_LOG_DBG("The read returns error: %s\n.", strerror(errno));
            }
            continue;
        }

        if (wjh_driver_specific_callbacks_g->wjh_user_channel_process_cb != NULL) {
            cl_spinlock_acquire(&(user_channel_p->lock));
            err =
                wjh_driver_specific_callbacks_g->wjh_user_channel_process_cb(user_channel_p,
                                                                             buff_p,
                                                                             FALSE);
            cl_spinlock_release(&(user_channel_p->lock));
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_INF("wjh_user_channel_process_cb failed, err = %d\n", err);
            }
        }
    }

    if (wjh_driver_specific_callbacks_g->wjh_polling_thread_buf_destroy_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_polling_thread_buf_destroy_cb(user_channel_p, buff_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_polling_thread_buf_destroy_cb failed, err = %d\n", err);
        }
    }

    pthread_exit((void*)NULL);
}

static void __wjh_event_driven_thread_func(void *args_p)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    fd_set                     fds;
    int                        max_fd = 0;
    int                        user_channel_fd = 0;
    int                        ret = 0;
    uint64_t                   ef_cnt = 0;
    wjh_user_channel_record_t *user_channel_p = (wjh_user_channel_record_t*)args_p;

    if (wjh_driver_specific_callbacks_g->wjh_user_channel_fd_get_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_user_channel_fd_get_cb(user_channel_p, &user_channel_fd);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_user_channel_fd_get_cb failed, err = %d\n", err);
            return;
        }
    } else {
        WJH_LOG_ERR("wjh_user_channel_fd_get_cb is NULL\n");
        return;
    }

    while (!user_channel_p->stop_thread) {
        max_fd = -1;
        FD_ZERO(&fds);
        FD_SET(user_channel_p->cmd_event_fd, &fds);
        FD_SET(user_channel_fd, &fds);
        max_fd = MAX(max_fd, user_channel_p->cmd_event_fd);
        max_fd = MAX(max_fd, user_channel_fd);

        ret = select(max_fd + 1, &fds, NULL, NULL, NULL);
        if (ret < 0) {
            WJH_LOG_DBG("The select returns error.\n");
            continue;
        }

        if (FD_ISSET(user_channel_p->cmd_event_fd, &fds)) {
            ret = read(user_channel_p->cmd_event_fd, &ef_cnt, sizeof(uint64_t));
            if (ret < 0) {
                WJH_LOG_DBG("The read returns error: %s\n.", strerror(errno));
            }
            continue;
        }

        if (wjh_driver_specific_callbacks_g->wjh_user_channel_process_cb != NULL) {
            cl_spinlock_acquire(&(user_channel_p->lock));
            err =
                wjh_driver_specific_callbacks_g->wjh_user_channel_process_cb(user_channel_p,
                                                                             NULL,
                                                                             FALSE);
            cl_spinlock_release(&(user_channel_p->lock));
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_INF("wjh_user_channel_process_cb failed, err = %d\n", err);
            }
        }
    }

    pthread_exit((void*)NULL);
}

static wjh_status_t __wjh_drop_reason_severity_update(void)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_record_t *drop_reason_group_record_p = NULL;
    uint32_t                        i = 0;

    for (i = WJH_DROP_REASON_GROUP_MIN_E; i < WJH_DROP_REASON_GROUP_NUM; i++) {
        wjh_db_drop_reason_group_get(i, &drop_reason_group_record_p);
        if (drop_reason_group_record_p->bound == FALSE) {
            continue;
        }
        if (wjh_driver_specific_callbacks_g->wjh_drop_reason_group_update_cb != NULL) {
            err = wjh_driver_specific_callbacks_g->wjh_drop_reason_group_update_cb(drop_reason_group_record_p);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to update drop reason group %u\n", i);
                goto out;
            }
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_configuration_update(void)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    /* coverity[lock_order] */
    err = wjh_db_drop_reason_descriptions_load(wjh_xml_path_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_WRN("Failed to load XML file %s\n", wjh_xml_path_s);
        goto out;
    }

    err = __wjh_drop_reason_severity_update();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to update wjh drop reasons for severity update.\n");
    }

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

#ifdef WJH_INOTIFY_PRESENT
static wjh_status_t __wjh_xml_monitor_prepare_inotify(int *inotify_fd_p, int *watch_fd_p, char *xml_file_name)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    int          inotify_fd = -1;
    int          watch_fd = -1;
    int          i = (int)(strlen(wjh_xml_path_s)) - 1;
    char         xml_dir_path[PATH_MAX];

    while (i >= 0) {
        if (wjh_xml_path_s[i] == '/') {
            break;
        }
        --i;
    }

    if (i < 0) {
        /* Should not happen, sanity check */
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Invalid XML file path: %s\n", wjh_xml_path_s);
        goto out;
    }

    if (i == 0) {
        strcpy(xml_dir_path, "/");
    } else {
        strncpy(xml_dir_path, wjh_xml_path_s, i);
        xml_dir_path[i] = '\0';
    }
    strcpy(xml_file_name, wjh_xml_path_s + i + 1);

    inotify_fd = syscall(__NR_inotify_init);
    if (inotify_fd < 0) {
        WJH_LOG_ERR("syscall __NR_inotify_init failed, err: %s\n", strerror(errno));
        goto out;
    }

    watch_fd = syscall(__NR_inotify_add_watch, inotify_fd, xml_dir_path,
                       IN_MODIFY | IN_CREATE | IN_MOVED_TO);
    if (watch_fd < 0) {
        WJH_LOG_ERR("syscall __NR_inotify_add_watch failed, dir: %s, err: %s\n",
                    xml_dir_path, strerror(errno));
        goto close_inotify_fd;
    }

    *inotify_fd_p = inotify_fd;
    *watch_fd_p = watch_fd;
    goto out;

close_inotify_fd:
    if (close(inotify_fd) < 0) {
        WJH_LOG_ERR("Failed to close inotify file descriptor, err: %s\n", strerror(errno));
    }

out:
    return err;
}

static wjh_status_t __wjh_xml_monitor_close_inotify(int notify_fd, int watch_fd)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (syscall(__NR_inotify_rm_watch, notify_fd, watch_fd) < 0) {
        WJH_LOG_ERR("syscall __NR_inotify_rm_watch failed, err: %s\n", strerror(errno));
        goto out;
    }

    if (close(notify_fd) < 0) {
        WJH_LOG_ERR("Failed to close inotify file descriptor, err: %s\n", strerror(errno));
        goto out;
    }

out:
    return err;
}

static void __wjh_xml_monitor_thread_inotify(int inotify_fd, const char *xml_file_name)
{
    wjh_status_t          err = WJH_STATUS_SUCCESS;
    fd_set                fds;
    int                   max_fd = 0;
    int                   ret = 0;
    uint64_t              ef_cnt = 0;
    char                  buffer[PATH_MAX + sizeof(struct inotify_event)];
    int                   i = 0;
    int                   length = 0;
    struct inotify_event *event = NULL;

    while (!wjh_stop_xml_monitor_thread_s) {
        max_fd = -1;
        FD_ZERO(&fds);
        FD_SET(wjh_xml_monitor_thread_cmd_event_fd_s, &fds);
        FD_SET(inotify_fd, &fds);
        max_fd = MAX(max_fd, wjh_xml_monitor_thread_cmd_event_fd_s);
        max_fd = MAX(max_fd, inotify_fd);

        ret = select(max_fd + 1, &fds, NULL, NULL, NULL);
        if (ret < 0) {
            WJH_LOG_DBG("The select returns error.\n");
            continue;
        }

        if (FD_ISSET(wjh_xml_monitor_thread_cmd_event_fd_s, &fds)) {
            ret = read(wjh_xml_monitor_thread_cmd_event_fd_s, &ef_cnt, sizeof(uint64_t));
            if (ret < 0) {
                WJH_LOG_DBG("The read returns error: %s\n.", strerror(errno));
            }
            continue;
        }

        if (FD_ISSET(inotify_fd, &fds)) {
            i = 0;
            length = read(inotify_fd, buffer, sizeof(buffer));
            if (length < 0) {
                WJH_LOG_NTC("Failed to read from inotify file descriptor, err: %s\n", strerror(errno));
                continue;
            }

            while (i < length) {
                event = (struct inotify_event*)&buffer[i];
                if ((event->len > 0) && (strcmp(event->name, xml_file_name) == 0)) {
                    err = __wjh_configuration_update();
                    if (WJH_CHECK_FAIL(err)) {
                        WJH_LOG_ERR("Failed to update wjh configuration.\n");
                    }
                }

                i += (sizeof(struct inotify_event) + event->len);
            }
        }
    }
}
#endif /* ifdef WJH_INOTIFY_PRESENT */

static void __wjh_xml_monitor_thread_polling(void)
{
    wjh_status_t    err = WJH_STATUS_SUCCESS;
    fd_set          fds;
    int             max_fd = 0;
    int             ret = 0;
    uint64_t        ef_cnt = 0;
    struct timeval  timeout;
    struct stat     stat_buf;
    struct timespec last_modification;
    boolean_t       have_last_modification = FALSE;

    while (!wjh_stop_xml_monitor_thread_s) {
        max_fd = -1;
        FD_ZERO(&fds);
        FD_SET(wjh_xml_monitor_thread_cmd_event_fd_s, &fds);
        max_fd = MAX(max_fd, wjh_xml_monitor_thread_cmd_event_fd_s);

        timeout.tv_sec = 1;
        timeout.tv_usec = 0;

        ret = select(max_fd + 1, &fds, NULL, NULL, &timeout);
        if (ret < 0) {
            WJH_LOG_DBG("The select returns error.\n");
            continue;
        }

        if (FD_ISSET(wjh_xml_monitor_thread_cmd_event_fd_s, &fds)) {
            ret = read(wjh_xml_monitor_thread_cmd_event_fd_s, &ef_cnt, sizeof(uint64_t));
            if (ret < 0) {
                WJH_LOG_DBG("The read returns error: %s\n.", strerror(errno));
            }
            continue;
        }

        ret = stat(wjh_xml_path_s, &stat_buf);
        if (ret != 0) {
            WJH_LOG_NTC("Failed to stat XML file %s, err: %s\n", wjh_xml_path_s, strerror(errno));
        } else {
            if (!have_last_modification) {
                last_modification.tv_sec = stat_buf.st_mtim.tv_sec;
                last_modification.tv_nsec = stat_buf.st_mtim.tv_nsec;
                have_last_modification = TRUE;
            } else {
                if ((stat_buf.st_mtim.tv_sec != last_modification.tv_sec) ||
                    (stat_buf.st_mtim.tv_nsec != last_modification.tv_nsec)) {
                    last_modification.tv_sec = stat_buf.st_mtim.tv_sec;
                    last_modification.tv_nsec = stat_buf.st_mtim.tv_nsec;
                    err = __wjh_configuration_update();
                    if (WJH_CHECK_FAIL(err)) {
                        WJH_LOG_ERR("Failed to update wjh configuration.\n");
                    }
                }
            }
        }
    }
}

static void __wjh_xml_monitor_thread_func(void *args_p)
{
#ifdef WJH_INOTIFY_PRESENT
    wjh_status_t err = WJH_STATUS_SUCCESS;
    int          inotify_fd = -1;
    int          watch_fd = -1;
    char         xml_file_name[PATH_MAX];
#endif

    UNUSED_PARAM(args_p);

#ifdef WJH_INOTIFY_PRESENT
    err = __wjh_xml_monitor_prepare_inotify(&inotify_fd, &watch_fd, xml_file_name);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_xml_monitor_prepare_inotify failed, fallback to polling thread\n");
        __wjh_xml_monitor_thread_polling();
    } else {
        __wjh_xml_monitor_thread_inotify(inotify_fd, xml_file_name);
        __wjh_xml_monitor_close_inotify(inotify_fd, watch_fd);
    }
#else
    __wjh_xml_monitor_thread_polling();
#endif

    pthread_exit((void*)NULL);
}

static wjh_status_t __wjh_deinit_from_watchdog_thread(void)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    wjh_user_channel_id_t      channel_id = 0;
    wjh_user_channel_record_t *user_channel_p = NULL;
    int                        i = 0;

    err = __wjh_resources_post_init_clean_up();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_resources_post_init_clean_up failed, err = %d\n", err);
        goto out;
    }

    err = __wjh_wipe_drop_reason_shm_data();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_wipe_drop_reason_shm_data failed, err = %d\n", err);
        goto out;
    }

    for (channel_id = 0; channel_id < WJH_USER_CHANNEL_MAX_NUM; ++channel_id) {
        wjh_db_user_channel_get(channel_id, &user_channel_p);

        if (!user_channel_p->created) {
            continue;
        }

        err = __wjh_user_channel_destroy(user_channel_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_user_channel_destroy failed, err = %d\n", err);
            goto out;
        }

        for (i = 0; i < WJH_DROP_REASON_GROUP_NUM; i++) {
            user_channel_p->bound[i] = FALSE;
        }
        user_channel_p->created = FALSE;
    }

    err = __wjh_deinit_wrapper();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_deinit_wrapper failed, err = %d\n", err);
        goto out;
    }

out:
    return err;
}

static void __wjh_watchdog_thread_func(void *args)
{
    wjh_status_t    err = WJH_STATUS_SUCCESS;
    useconds_t      sleep_interval = WJH_WATCHDOG_THREAD_SLEEP_INTERVAL;
    wjh_deactive_cb deactive_cb = NULL;

    while (!wjh_stop_watchdog_thread_s) {
        if (wjh_shm_ptr_s->force_init_flag == WJH_FORCE_INIT_OK) {
            usleep(sleep_interval);
            continue;
        }
        break;
    }

    if (wjh_stop_watchdog_thread_s) {
        goto out;
    }

    if (wjh_shm_ptr_s->force_init_flag == WJH_FORCE_INIT_IN_PROGRESS) {
        cl_spinlock_acquire(&wjh_api_spinlock_s);
        if (!wjh_init_done_g) {
            cl_spinlock_release(&wjh_api_spinlock_s);
            goto out;
        }
        err = __wjh_deinit_from_watchdog_thread();
        cl_spinlock_release(&wjh_api_spinlock_s);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_deinit_from_watchdog_thread failed, err = %d\n", err);
            wjh_shm_ptr_s->force_init_flag = WJH_FORCE_INIT_ERROR;
        } else {
            wjh_shm_ptr_s->force_init_flag = WJH_FORCE_INIT_OK;
        }
        msync(wjh_shm_ptr_s, sizeof(wjh_shm_data_t), MS_SYNC);

        if (args != NULL) {
            deactive_cb = (wjh_deactive_cb)args;
            deactive_cb();
        }

        err = __wjh_close_shm();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_close_shm failed, err = %d\n", err);
        }
    }

out:
    pthread_exit((void*)NULL);
}

static wjh_status_t __wjh_destroy_cmd_event_fds(void)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (wjh_xml_monitor_thread_cmd_event_fd_s >= 0) {
        if (close(wjh_xml_monitor_thread_cmd_event_fd_s) < 0) {
            WJH_LOG_ERR("Failed to close event fd %d, err: %s\n",
                        wjh_xml_monitor_thread_cmd_event_fd_s, strerror(errno));
            err = WJH_STATUS_ERROR;
            goto out;
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_deinit_wrapper(void)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    wjh_netlink_deinit();

    if (!wjh_stop_xml_monitor_thread_s) {
        err = __wjh_thread_destroy(&wjh_xml_monitor_thread_id_s,
                                   &wjh_stop_xml_monitor_thread_s,
                                   &wjh_xml_monitor_thread_cmd_event_fd_s);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_thread_destroy failed, err: %d\n", err);
            goto out;
        }
    }

    if (wjh_driver_specific_callbacks_g->wjh_policer_destroy_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_policer_destroy_cb();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_policer_destroy_cb failed, err = %d.\n", err);
            goto out;
        }
    }

    err = __wjh_destroy_cmd_event_fds();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_destroy_cmd_event_fds failed, err: %d\n", err);
        goto out;
    }

#ifdef WJH_EBPF_PRESENT
    if (wjh_driver_specific_callbacks_g->wjh_ebpf_cleanup_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_ebpf_cleanup_cb();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_cleanup_cb failed, err: %d\n", err);
            goto out;
        }
    }
#endif

    wjh_db_deinit();

    if (wjh_driver_specific_callbacks_g->wjh_deinit_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_deinit_cb();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_deinit_cb failed, err = %d.\n", err);
            goto out;
        }
    }

    err = __wjh_release_file_lock(WJH_SINGLETON_FILE_LOCK);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_release_file_lock failed, lock type: %u, err: %d\n",
                    WJH_SINGLETON_FILE_LOCK, err);
        goto out;
    }

    wjh_init_done_g = FALSE;

out:
    return err;
}

static wjh_status_t __wjh_thread_destroy(cl_thread_t *thread_id_p,
                                         boolean_t   *stop_thread_flag_p,
                                         int         *cmd_event_fd_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint64_t     ef_cnt;
    int          ret;

    if (*stop_thread_flag_p) {
        goto out;
    }

    *stop_thread_flag_p = TRUE;
    if (cmd_event_fd_p != NULL) {
        ef_cnt = 1;
        ret = write(*cmd_event_fd_p, &ef_cnt, sizeof(uint64_t));
        if (ret != sizeof(uint64_t)) {
            WJH_LOG_ERR("Failed to write the cmd event fd, ret=%d.\n", ret);
            err = WJH_STATUS_ERROR;
            goto out;
        }
    }

    cl_thread_destroy(thread_id_p);

    if (cmd_event_fd_p != NULL) {
        ret = close(*cmd_event_fd_p);
        if (ret < 0) {
            WJH_LOG_ERR("Failed to close the cmd event fd, err: %s.\n", strerror(errno));
            err = WJH_STATUS_ERROR;
            goto out;
        }
        *cmd_event_fd_p = -1;
    }

out:
    return err;
}

static wjh_status_t __wjh_user_channel_destroy(wjh_user_channel_record_t *user_channel_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    /*Today TAC only supports send to remote, therefore no need of receive thread*/
    if (user_channel_p->channel_type != WJH_USER_CHANNEL_TAC_E) {
        err = __wjh_thread_destroy(&(user_channel_p->thread),
                                   &(user_channel_p->stop_thread),
                                   &(user_channel_p->cmd_event_fd));
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_user_channel_destroy failed, err: %d\n", err);
            goto out;
        }
    }
    cl_spinlock_destroy(&(user_channel_p->lock));

    if (wjh_driver_specific_callbacks_g->wjh_user_channel_destroy_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_user_channel_destroy_cb(user_channel_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_user_channel_destroy_cb failed, err = %d.\n", err);
            goto out;
        }
    }

out:
    return err;
}

static wjh_status_t __wjh_drop_reason_group_unbind(wjh_drop_reason_group_record_t *group_item_p)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t *user_channel_p = NULL;

    wjh_db_user_channel_get(group_item_p->channel_id, &user_channel_p);

    if (wjh_driver_specific_callbacks_g->wjh_drop_reason_group_unbind_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_drop_reason_group_unbind_cb(user_channel_p, group_item_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_drop_reason_group_unbind_cb failed, err = %d.\n", err);
            goto out;
        }
    }

    if (group_item_p->enabled_severity_bits) {
        group_item_p->enabled_severity_bits = 0;
        user_channel_p->group_enable_count--;
    }

    user_channel_p->bound[group_item_p->drop_reason_group] = FALSE;
    group_item_p->bound = FALSE;

out:
    return err;
}

static wjh_status_t __wjh_get_default_xml_file_path(char* path, int size)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    char         buf[PATH_MAX + 1024];
    FILE        *fp = NULL;
    int          slash_pos = -1;
    int          white_space_pos = -1;
    boolean_t    first_slash_found = FALSE;
    char        *str = NULL;

    sprintf(buf, "/proc/%d/maps", getpid());
    fp = fopen(buf, "r");
    if (fp == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to open file %s, err: %s\n", buf, strerror(errno));
        goto out;
    }

    while (fgets(buf, sizeof(buf), fp) != NULL) {
        str = strstr(buf, WJH_LIB_NAME_STR);
        if (str == NULL) {
            continue;
        }

        while (str != buf) {
            if (*str == '/') {
                if (!first_slash_found) {
                    first_slash_found = TRUE;
                } else {
                    if (slash_pos == -1) {
                        slash_pos = (int)(str - buf);
                    }
                }
            } else if ((*str == ' ') || (*str == '\t')) {
                white_space_pos = (int)(str - buf);
                break;
            }
            --str;
        }
        break;
    }

    if ((slash_pos == -1) || (white_space_pos == -1)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to locate %s\n", WJH_LIB_NAME_STR);
        goto out;
    }

    if ((slash_pos - white_space_pos + (int)strlen(WJH_CONF_FILE_RELATIVE_PATH) + 1) > size) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("The provided size %d for buffer path is too small\n", size);
        goto out;
    }

    snprintf(path, slash_pos - white_space_pos + 1, "%s", buf + white_space_pos + 1);
    snprintf(path + (slash_pos - white_space_pos), strlen(WJH_CONF_FILE_RELATIVE_PATH) + 1,
             "%s", WJH_CONF_FILE_RELATIVE_PATH);

out:
    if (fp != NULL) {
        fclose(fp);
    }
    return err;
}

static wjh_status_t __wjh_drop_reason_item_wipe_shm_data(wjh_drop_reason_group_e drop_reason_group)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    /*update shared memory with drop reason group for cleanup later as required */
    if (drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) {
        err = wjh_db_get_drop_reason_group_shm_data(drop_reason_group, FALSE, &wjh_shm_ptr_s->drop_reason_shm_data);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("drop reason shm info retrieve failed, err: %d\n", err);
            goto out;
        }
    }
    msync(wjh_shm_ptr_s, sizeof(wjh_shm_data_t), MS_SYNC);
out:
    return err;
}

static wjh_status_t __wjh_drop_reason_item_save_shm_data(wjh_drop_reason_group_e drop_reason_group)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    /*update shared memory with drop reason group for cleanup later as required */
    if (drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) {
        err = wjh_db_get_drop_reason_group_shm_data(drop_reason_group, TRUE, &wjh_shm_ptr_s->drop_reason_shm_data);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("drop reason shm info retrieve failed, err: %d\n", err);
            goto out;
        }
    }
    msync(wjh_shm_ptr_s, sizeof(wjh_shm_data_t), MS_SYNC);
out:
    return err;
}

static wjh_status_t __wjh_wipe_drop_reason_shm_data()
{
    wjh_drop_reason_group_e drop_reason_group;
    wjh_status_t            err = WJH_STATUS_SUCCESS;

    for (drop_reason_group = WJH_DROP_REASON_GROUP_MIN_E;
         drop_reason_group <= WJH_DROP_REASON_GROUP_MAX_E;
         ++drop_reason_group) {
        err = __wjh_drop_reason_item_wipe_shm_data(drop_reason_group);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_drop_reason_wipe_shm_data failed, err = %d\n", err);
            goto out;
        }
    }
out:
    return err;
}

static void __wjh_wipe_user_channel_shm_data()
{
    wjh_user_channel_id_t user_channel_id = 0;

    for (user_channel_id = 0; user_channel_id < WJH_USER_CHANNEL_MAX_NUM; user_channel_id++) {
        wjh_shm_ptr_s->user_channel_shm_data.trap_groups[user_channel_id] = WJH_TRAP_GROUP_INVALID;
    }

    msync(wjh_shm_ptr_s, sizeof(wjh_shm_data_t), MS_SYNC);

    return;
}


static wjh_status_t __wjh_validate_driver_shm(wjh_driver_shm_data_t *driver_shm_data_p, boolean_t *is_valid_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (wjh_driver_specific_callbacks_g->wjh_validate_shm_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_validate_shm_cb(driver_shm_data_p, is_valid_p);
    }
    return err;
}

static wjh_status_t __wjh_update_driver_shm(wjh_driver_shm_data_t *driver_shm_data_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (wjh_driver_specific_callbacks_g->wjh_update_shm_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_update_shm_cb(driver_shm_data_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("drop reason shm info retrieve failed, err: %d\n", err);
            goto out;
        }
    }
    msync(wjh_shm_ptr_s, sizeof(wjh_shm_data_t), MS_SYNC);
out:
    return err;
}

#ifdef WJH_EBPF_PRESENT
static wjh_status_t __wjh_get_ebpf_prog_path(void)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    char         buf[PATH_MAX + 1024];
    FILE        *fp = NULL;
    int          slash_pos = -1;
    int          white_space_pos = -1;
    char        *str = NULL;

    sprintf(buf, "/proc/%d/maps", getpid());
    fp = fopen(buf, "r");
    if (fp == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to open file %s, err: %s\n", buf, strerror(errno));
        goto out;
    }

    while (fgets(buf, sizeof(buf), fp) != NULL) {
        str = strstr(buf, WJH_LIB_NAME_STR);
        if (str == NULL) {
            continue;
        }

        while (str != buf) {
            if (*str == '/') {
                if (slash_pos == -1) {
                    slash_pos = (int)(str - buf);
                }
            } else if ((*str == ' ') || (*str == '\t')) {
                white_space_pos = (int)(str - buf);
                break;
            }
            --str;
        }
        break;
    }

    if ((slash_pos == -1) || (white_space_pos == -1)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to locate %s\n", WJH_LIB_NAME_STR);
        goto out;
    }

    if ((slash_pos - white_space_pos + 1) > PATH_MAX) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("The eBPF program file path is too long.\n");
        goto out;
    }

    snprintf(wjh_ebpf_prog_dir_g, slash_pos - white_space_pos + 1, "%s", buf + white_space_pos + 1);

out:
    if (fp != NULL) {
        fclose(fp);
    }
    return err;
}

static wjh_status_t __wjh_set_debugfs_path(const wjh_init_param_t *param_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (wjh_driver_specific_callbacks_g->wjh_set_debugfs_path_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_set_debugfs_path_cb(param_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to the set the debug file system path, err: %d\n", err);
            goto out;
        }
    }

out:
    return err;
}
#endif /* ifdef WJH_EBPF_PRESENT */

wjh_status_t wjh_init(const wjh_init_param_t *param_p)
{
    wjh_status_t    err = WJH_STATUS_SUCCESS;
    wjh_status_t    err1 = WJH_STATUS_SUCCESS;
    cl_status_t     cl_rc = CL_SUCCESS;
    boolean_t       is_singleton_locked = FALSE;
    wjh_deactive_cb deactive_cb = NULL;
    uint8_t         max_bandwidth_percent = WJH_BANDWIDTH_PERCENTAGE_DEFAULT;
    boolean_t       start_xml_monitor_thread = FALSE;
    boolean_t       is_shm_driver_data_valid = FALSE;

    if (wjh_init_done_g) {
        err = WJH_STATUS_ALREADY_INITIALIZED;
        WJH_LOG_ERR("WJH lib is already initialized.\n");
        goto out;
    }

    if (param_p != NULL) {
        if (param_p->driver_init_param.trap_group_allocate_mode > WJH_TRAP_GROUP_ALLOCATE_MODE_MAX_E) {
            err = WJH_STATUS_PARAM_ERROR;
            WJH_LOG_ERR("WJH trap group allocation mode is out of range.\n");
            goto out;
        }
    }

    if (param_p != NULL) {
        wjh_log_cb_set(param_p->log_cb);
        wjh_init_params_g = *param_p;
    } else {
        memset(&wjh_init_params_g, 0, sizeof(wjh_init_param_t));
    }

    err = __wjh_open_shm();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_open_shm failed, err = %d\n", err);
        goto out;
    }

    err = __wjh_validate_driver_shm(&wjh_shm_ptr_s->driver_shm_data, &is_shm_driver_data_valid);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_validate_driver_shm failed, err = %d\n", err);
        goto out;
    }

    if (is_shm_driver_data_valid == FALSE) {
        err = __wjh_wipe_drop_reason_shm_data();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wipe out drop reason data failed, err = %d\n", err);
            goto out;
        }
        __wjh_wipe_user_channel_shm_data();
        err = __wjh_update_driver_shm(&wjh_shm_ptr_s->driver_shm_data);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_update_driver_shm failed, err = %d\n", err);
            goto out;
        }
        msync(wjh_shm_ptr_s, sizeof(wjh_shm_data_t), MS_SYNC);
    }

    err = __wjh_acquire_file_lock(WJH_INIT_FILE_LOCK, FALSE);
    if (WJH_CHECK_FAIL(err)) {
        if (err == WJH_STATUS_IN_PROGRESS) {
            WJH_LOG_ERR("Another instance of WJH library is also initializing\n");
        } else {
            WJH_LOG_ERR("__wjh_acquire_file_lock failed, lock_type: %u, err: %d\n",
                        WJH_INIT_FILE_LOCK, err);
        }
        goto close_shm;
    }

    err = __wjh_is_file_locked(WJH_SINGLETON_FILE_LOCK, &is_singleton_locked);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_is_file_locked failed, lock type: %u, err: %d\n",
                    WJH_SINGLETON_FILE_LOCK, err);
        goto release_init_lock;
    }

    if (wjh_driver_specific_callbacks_g->wjh_init_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_init_cb();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_init_cb failed, err = %d.\n", err);
            goto release_init_lock;
        }
    }

    err = wjh_db_init_hw_info();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh_db_init_hw_info failed, err: %d\n", err);
        goto deinit_wjh;
    }

    err = __wjh_get_default_xml_file_path(wjh_default_xml_path_s, PATH_MAX);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_get_default_xml_file_path failed, err: %d\n", err);
        goto deinit_wjh;
    }
    strcpy(wjh_xml_path_s, wjh_default_xml_path_s);
    if (param_p != NULL) {
        if (param_p->max_bandwidth_percent > 100) {
            WJH_LOG_ERR("The maximum bandwidth percentage should be in range [0-100]\n");
            err = WJH_STATUS_PARAM_ERROR;
            goto deinit_wjh;
        }

        if (param_p->max_bandwidth_percent == 0) {
            max_bandwidth_percent = WJH_BANDWIDTH_PERCENTAGE_DEFAULT;
        } else {
            max_bandwidth_percent = param_p->max_bandwidth_percent;
        }

        if (param_p->conf_xml_path != NULL) {
            if (realpath(param_p->conf_xml_path, wjh_xml_path_s) == NULL) {
                WJH_LOG_ERR("realpath function failed on specified XML file %s, error: %s, "
                            "will fallback to default XML file %s\n", param_p->conf_xml_path,
                            strerror(errno), wjh_default_xml_path_s);
                strcpy(wjh_xml_path_s, wjh_default_xml_path_s);
            } else {
                if (strcmp(wjh_xml_path_s, wjh_default_xml_path_s) == 0) {
                    WJH_LOG_NTC("The specified XML file path %s is same as the default XML file path %s or "
                                "a symbolic link pointing to it.\n", param_p->conf_xml_path,
                                wjh_default_xml_path_s);
                } else {
                    start_xml_monitor_thread = TRUE;
                }
            }
        }
    }

#ifdef WJH_EBPF_PRESENT
    err = __wjh_set_debugfs_path(param_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_set_debugfs_path failed, err: %d\n", err);
        goto deinit_wjh;
    }

    err = __wjh_get_ebpf_prog_path();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_get_ebpf_prog_path failed, err: %d\n", err);
        goto deinit_wjh;
    }
#endif

    if ((!param_p) || (!param_p->force)) {
        if (is_singleton_locked) {
            WJH_LOG_ERR("It is not permitted to run multiple instances of WJH library at the same time\n");
            err = WJH_STATUS_ERROR;
            goto deinit_wjh;
        } else {
            err = __wjh_resources_pre_init_clean_up(&wjh_shm_ptr_s->drop_reason_shm_data,
                                                    &wjh_shm_ptr_s->user_channel_shm_data);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_resources_pre_init_clean_up failed, err = %d\n", err);
                err1 = __wjh_wipe_drop_reason_shm_data();
                if (WJH_CHECK_FAIL(err1)) {
                    WJH_LOG_ERR("__wjh_wipe_drop_reason_shm_data failed, err = %d\n", err);
                }
                __wjh_wipe_user_channel_shm_data();
                goto deinit_wjh;
            }
        }
    } else {
        if (is_singleton_locked) {
            WJH_LOG_NTC("Another WJH client is running, going to deactivate it now.\n");
            err = __wjh_termiate_another_instance();
            if (WJH_CHECK_FAIL(err)) {
                err = __wjh_resources_pre_init_clean_up(&wjh_shm_ptr_s->drop_reason_shm_data,
                                                        &wjh_shm_ptr_s->user_channel_shm_data);
                if (WJH_CHECK_FAIL(err)) {
                    WJH_LOG_ERR("__wjh_resources_pre_init_clean_up failed, err = %d\n", err);
                    err1 = __wjh_wipe_drop_reason_shm_data();
                    if (WJH_CHECK_FAIL(err1)) {
                        WJH_LOG_ERR("__wjh_wipe_drop_reason_shm_data failed, err = %d\n", err);
                    }
                    __wjh_wipe_user_channel_shm_data();
                    goto deinit_wjh;
                }
            }
        } else {
            err = __wjh_resources_pre_init_clean_up(&wjh_shm_ptr_s->drop_reason_shm_data,
                                                    &wjh_shm_ptr_s->user_channel_shm_data);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_resources_pre_init_clean_up failed, err = %d\n", err);
                err1 = __wjh_wipe_drop_reason_shm_data();
                if (WJH_CHECK_FAIL(err1)) {
                    WJH_LOG_ERR("__wjh_wipe_drop_reason_shm_data failed, err = %d\n", err);
                }
                __wjh_wipe_user_channel_shm_data();
                goto deinit_wjh;
            }
        }
    }

    /* Wipe out the wjh shm drop reason */
    err = __wjh_wipe_drop_reason_shm_data();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_wipe_drop_reason_shm_data failed, err = %d\n", err);
        goto deinit_wjh;
    }

    __wjh_wipe_user_channel_shm_data();

    err = wjh_db_init();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh_db_init failed, err: %d\n", err);
        goto deinit_wjh;
    }

#ifdef WJH_EBPF_PRESENT
    if (wjh_driver_specific_callbacks_g->wjh_ebpf_prepare_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_ebpf_prepare_cb();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_ebpf_prepare_cb failed, err: %d\n", err);
            goto deinit_wjh_db;
        }
    }

    if (wjh_driver_specific_callbacks_g->wjh_aggregation_set_monitor_rdq_trace_points_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_aggregation_set_monitor_rdq_trace_points_cb(FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_aggregation_set_monitor_rdq_trace_points_cb failed, err: %d\n", err);
            goto deinit_wjh_db;
        }
    }

#endif

    if (strcmp(wjh_xml_path_s, wjh_default_xml_path_s) != 0) {
        err = wjh_db_drop_reason_descriptions_load(wjh_default_xml_path_s);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to load default XML file %s\n", wjh_default_xml_path_s);
            goto deinit_wjh_db;
        }
    }

    err = wjh_db_drop_reason_descriptions_load(wjh_xml_path_s);
    if (WJH_CHECK_FAIL(err)) {
        if (start_xml_monitor_thread) {
            WJH_LOG_ERR("Failed to load XML file %s, will fallback to default XML file %s\n",
                        wjh_xml_path_s, wjh_default_xml_path_s);
            err = wjh_db_drop_reason_descriptions_load(wjh_default_xml_path_s);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to load default XML file %s\n", wjh_default_xml_path_s);
                goto deinit_wjh_db;
            }
        } else {
            WJH_LOG_ERR("Failed to load default XML file %s\n", wjh_xml_path_s);
            goto deinit_wjh_db;
        }
    }

    wjh_xml_monitor_thread_cmd_event_fd_s = eventfd(0, 0);
    if (wjh_xml_monitor_thread_cmd_event_fd_s == -1) {
        WJH_LOG_ERR("Failed to create cmd event fd.\n");
        err = WJH_STATUS_NO_RESOURCES;
        goto deinit_wjh_db;
    }

    if (wjh_driver_specific_callbacks_g->wjh_policer_create_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_policer_create_cb(max_bandwidth_percent);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_policer_create_cb failed, err = %d.\n", err);
            goto close_cmd_event_fds;
        }
    }

    wjh_shm_ptr_s->force_init_flag = WJH_FORCE_INIT_OK;
    msync(wjh_shm_ptr_s, sizeof(wjh_shm_data_t), MS_SYNC);

    wjh_stop_watchdog_thread_s = FALSE;

    if ((param_p != NULL) && (param_p->deactive_cb != NULL)) {
        deactive_cb = param_p->deactive_cb;
    }

    cl_rc = cl_thread_init(&wjh_watchdog_thread_id_s, __wjh_watchdog_thread_func, deactive_cb, "wjhWatchdog", 0);
    if (cl_rc != CL_SUCCESS) {
        WJH_LOG_ERR("Could not create __wjh_watchdog_thread_func thread.\n");
        err = WJH_STATUS_NO_RESOURCES;
        goto destroy_policer;
    }

    if (start_xml_monitor_thread) {
        wjh_stop_xml_monitor_thread_s = FALSE;
        cl_rc = cl_thread_init(&wjh_xml_monitor_thread_id_s,
                               __wjh_xml_monitor_thread_func,
                               NULL,
                               "wjhXmlMonitor",
                               0);
        if (cl_rc != CL_SUCCESS) {
            WJH_LOG_ERR("Could not create __wjh_xml_monitor_thread_func thread.\n");
            err = WJH_STATUS_NO_RESOURCES;
            goto destroy_watchdog_thread;
        }
    }

    if (param_p->ingress_info_type == WJH_INGRESS_INFO_TYPE_IF_INDEX) {
        err = wjh_netlink_init();
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_netlink_init failed, err: %d\n", err);
            goto destroy_xml_monitor_thread;
        }
    }

    err = __wjh_acquire_file_lock(WJH_SINGLETON_FILE_LOCK, TRUE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_acquire_file_lock failed, lock type: %u, err: %d\n",
                    WJH_SINGLETON_FILE_LOCK, err);
        goto destroy_xml_monitor_thread;
    }

    wjh_init_done_g = TRUE;

    err = __wjh_release_file_lock(WJH_INIT_FILE_LOCK);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_release_file_lock failed, lock type: %u, err: %d\n",
                    WJH_INIT_FILE_LOCK, err);
        wjh_init_done_g = FALSE;
        goto release_singleton_lock;
    }

    goto out;

release_singleton_lock:
    err1 = __wjh_release_file_lock(WJH_SINGLETON_FILE_LOCK);
    if (WJH_CHECK_FAIL(err1)) {
        WJH_LOG_ERR("__wjh_release_file_lock failed, lock type: %u, err: %d\n",
                    WJH_SINGLETON_FILE_LOCK, err1);
    }

destroy_xml_monitor_thread:
    if (!wjh_stop_xml_monitor_thread_s) {
        err1 = __wjh_thread_destroy(&wjh_xml_monitor_thread_id_s,
                                    &wjh_stop_xml_monitor_thread_s,
                                    &wjh_xml_monitor_thread_cmd_event_fd_s);
        if (WJH_CHECK_FAIL(err1)) {
            WJH_LOG_ERR("__wjh_thread_destroy failed, err: %d\n", err1);
        }
    }

destroy_watchdog_thread:
    err1 = __wjh_thread_destroy(&wjh_watchdog_thread_id_s, &wjh_stop_watchdog_thread_s, NULL);
    if (WJH_CHECK_FAIL(err1)) {
        WJH_LOG_ERR("__wjh_thread_destroy failed, err: %d\n", err1);
    }

destroy_policer:
    if (wjh_driver_specific_callbacks_g->wjh_policer_destroy_cb != NULL) {
        err1 = wjh_driver_specific_callbacks_g->wjh_policer_destroy_cb();
        if (WJH_CHECK_FAIL(err1)) {
            WJH_LOG_ERR("wjh_policer_destroy_cb failed, err = %d.\n", err1);
        }
    }

close_cmd_event_fds:
    err1 = __wjh_destroy_cmd_event_fds();
    if (WJH_CHECK_FAIL(err1)) {
        WJH_LOG_ERR("__wjh_destroy_cmd_event_fds failed, err: %d\n", err1);
    }

deinit_wjh_db:
    wjh_db_deinit();

deinit_wjh:
    if (wjh_driver_specific_callbacks_g->wjh_deinit_cb != NULL) {
        err1 = wjh_driver_specific_callbacks_g->wjh_deinit_cb();
        if (WJH_CHECK_FAIL(err1)) {
            WJH_LOG_ERR("wjh_deinit_cb failed, err = %d.\n", err1);
        }
    }

    __wjh_wipe_user_channel_shm_data();

release_init_lock:
    err1 = __wjh_release_file_lock(WJH_INIT_FILE_LOCK);
    if (WJH_CHECK_FAIL(err1)) {
        WJH_LOG_ERR("__wjh_release_file_lock failed, lock type: %u, err: %d\n",
                    WJH_INIT_FILE_LOCK, err1);
    }

close_shm:
    err1 = __wjh_close_shm();
    if (WJH_CHECK_FAIL(err1)) {
        WJH_LOG_ERR("__wjh_close_shm failed, err = %d\n", err1);
    }

out:
    return err;
}

wjh_status_t wjh_deinit(void)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);

    err = wjh_db_deinit_resource_check();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh_db_deinit_resource_check failed, err = %d\n", err);
        goto out;
    }

    err = __wjh_deinit_wrapper();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_deinit_wrapper failed, err = %d\n", err);
        goto out;
    }

    err = __wjh_thread_destroy(&wjh_watchdog_thread_id_s, &wjh_stop_watchdog_thread_s, NULL);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_thread_destroy failed, err: %d\n", err);
        goto out;
    }

    err = __wjh_close_shm();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_close_shm failed, err = %d\n", err);
        goto out;
    }

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_drop_reason_group_init(const wjh_drop_reason_group_e       drop_reason_group,
                                        const wjh_drop_reason_group_attr_t *attr_p,
                                        const wjh_drop_callbacks_t         *callbacks_p)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_record_t *group_item_p = NULL;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_DROP_REASON_GROUP_CHECK_RANGE(drop_reason_group);
    WJH_CHECK_NULL_PTR(attr_p, attr_p);

    if (wjh_driver_specific_callbacks_g->wjh_drop_reason_group_validate_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_drop_reason_group_validate_cb(drop_reason_group);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_drop_reason_group_validate_cb failed, err: %d\n", err);
            goto out;
        }
    }

    if ((callbacks_p != NULL) && (drop_reason_group != callbacks_p->drop_reason_group)) {
        err = WJH_STATUS_PARAM_ERROR;
        WJH_LOG_ERR("The drop reason group (%u) in the callback is different with (%u).\n",
                    callbacks_p->drop_reason_group, drop_reason_group);
        goto out;
    }

    wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);

    if (group_item_p->inited) {
        err = WJH_STATUS_ALREADY_INITIALIZED;
        WJH_LOG_ERR("The drop reason group (%u) is already initialized.\n", drop_reason_group);
        goto out;
    }

    if (wjh_driver_specific_callbacks_g->wjh_drop_reason_group_init_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_drop_reason_group_init_cb(drop_reason_group, attr_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_drop_reason_group_init_cb failed, err: %d\n", err);
            goto out;
        }
    }

    memcpy(&group_item_p->attr, attr_p, sizeof(wjh_drop_reason_group_attr_t));
    if (callbacks_p != NULL) {
        memcpy(&group_item_p->callbacks, callbacks_p, sizeof(wjh_drop_callbacks_t));
    }
    if (group_item_p->attr.max_aggregation_entries_cnt == 0) {
        group_item_p->attr.max_aggregation_entries_cnt = WJH_DROP_REASON_GROUP_MAX_ENTRIES_CNT_DEFAULT;
    }
    group_item_p->inited = TRUE;

    err = __wjh_drop_reason_item_save_shm_data(drop_reason_group);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh drop reason save shm data failed, err: %d\n", err);
        goto out;
    }


out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_drop_reason_group_deinit(const wjh_drop_reason_group_e drop_reason_group)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_record_t *group_item_p = NULL;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_DROP_REASON_GROUP_CHECK_RANGE(drop_reason_group);

    wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);

    if (!group_item_p->inited) {
        err = WJH_STATUS_NOT_INITIALIZED;
        WJH_LOG_ERR("The drop reason group (%u) is not initialized yet.\n", drop_reason_group);
        goto out;
    }

    if (group_item_p->bound) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("The drop reason group (%u) is already bound to user channel (id: %u), unbind it first.\n",
                    drop_reason_group, group_item_p->channel_id);
        goto out;
    }

    err = __wjh_drop_reason_group_deinit(drop_reason_group);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_drop_reason_group_deinit failed, err: %d\n", err);
        goto out;
    }

    memset(&group_item_p->attr, 0, sizeof(wjh_drop_reason_group_attr_t));
    memset(&group_item_p->callbacks, 0, sizeof(wjh_drop_callbacks_t));

    group_item_p->inited = FALSE;

    err = __wjh_drop_reason_item_wipe_shm_data(drop_reason_group);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh drop reason wipe shm data failed, err: %d\n", err);
        goto out;
    }

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

static wjh_status_t __wjh_user_channel_thread_create(wjh_user_channel_record_t *user_channel_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    cl_status_t  cl_rc = CL_SUCCESS;
    int          fd = -1;
    char         thread_name[WJH_THREAD_NAME_MAX_LEN + 1];

    void (*thread_func_p)(void*) = NULL;

    if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAILDROP_E) {
        thread_func_p = __wjh_event_driven_thread_func;
    } else {
        thread_func_p = __wjh_polling_thread_func;
    }

    fd = eventfd(0, 0);
    if (fd < 0) {
        WJH_LOG_ERR("Failed to create cmd event fd, err: %s\n", strerror(errno));
        err = WJH_STATUS_NO_RESOURCES;
        goto out;
    }
    user_channel_p->cmd_event_fd = fd;

    user_channel_p->stop_thread = FALSE;
    snprintf(thread_name, WJH_THREAD_NAME_MAX_LEN, "userChannel%u", user_channel_p->channel_id);
    thread_name[WJH_THREAD_NAME_MAX_LEN] = '\0';
    cl_rc = cl_thread_init(&(user_channel_p->thread), thread_func_p, user_channel_p, thread_name, 0);
    if (cl_rc != CL_SUCCESS) {
        WJH_LOG_ERR("Could not create __wjh_watchdog_thread_func thread.\n");
        err = WJH_STATUS_NO_RESOURCES;
        goto out;
    }

out:
    if (WJH_CHECK_FAIL(err)) {
        if ((fd >= 0) && (close(fd) < 0)) {
            WJH_LOG_ERR("Failed to close cmd event fd, err: %s\n", strerror(errno));
        }
    }

    return err;
}

wjh_status_t wjh_user_channel_create(const wjh_user_channel_type_e channel_type,
                                     wjh_user_channel_id_t        *channel_id_p)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    cl_status_t                cl_rc = CL_SUCCESS;
    wjh_user_channel_record_t *user_channel_p = NULL;
    boolean_t                  spinlock_inited = FALSE;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_USER_CHANNEL_TYPE_CHECK_RANGE(channel_type);
    WJH_CHECK_NULL_PTR(channel_id_p, channel_id_p);

    if (wjh_driver_specific_callbacks_g->wjh_user_channel_validate_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_user_channel_validate_cb(channel_type);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_user_channel_validate_cb failed, err = %d.\n", err);
            goto out;
        }
    }

    err = wjh_db_free_user_channel_get(&user_channel_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to get free user channel from DB.\n");
        goto out;
    }
    user_channel_p->dropped_packets = 0;
    user_channel_p->received_packets = 0;
    user_channel_p->group_enable_count = 0;
    user_channel_p->filter_record_p = NULL;

    if (wjh_driver_specific_callbacks_g->wjh_user_channel_create_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_user_channel_create_cb(channel_type, user_channel_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_user_channel_create_cb failed, err = %d.\n", err);
            goto out;
        }
    }

    user_channel_p->channel_type = channel_type;

    cl_rc = cl_spinlock_init(&(user_channel_p->lock));
    if (cl_rc != CL_SUCCESS) {
        WJH_LOG_ERR("Could not initialize spinlock for the user channel\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }
    spinlock_inited = TRUE;

    /*Today TAC only supports send to remote, therefore no need of receive thread*/
    if (channel_type != WJH_USER_CHANNEL_TAC_E) {
        if (channel_type != WJH_USER_CHANNEL_TAILDROP_E) {
            if (channel_type == WJH_USER_CHANNEL_CYCLIC_E) {
                user_channel_p->polling_interval = WJH_CYCLIC_CHANNEL_DEFAULT_POLLING_INTERVAL;
            } else {
                user_channel_p->polling_interval = WJH_AGGREGATION_CHANNEL_DEFAULT_POLLING_INTERVAL;
            }
            user_channel_p->mode = WJH_USER_CHANNEL_MODE_PUSH_E;
        }


        err = __wjh_user_channel_thread_create(user_channel_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_user_channel_thread_create failed, err = %d.\n", err);
            goto out;
        }

        user_channel_p->user_channel_dest = WJH_USER_CHANNEL_DESTINATION_CALLBACK_AND_DROP_MONITOR_E;
        wjh_shm_ptr_s->user_channel_shm_data.trap_groups[user_channel_p->channel_id] = user_channel_p->trap_group_id;
        msync(wjh_shm_ptr_s, sizeof(wjh_shm_data_t), MS_SYNC);
    }
    user_channel_p->created = TRUE;
    *channel_id_p = user_channel_p->channel_id;

out:
    if (WJH_CHECK_FAIL(err)) {
        if (spinlock_inited) {
            cl_spinlock_destroy(&(user_channel_p->lock));
        }
    }
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_user_channel_set(const wjh_user_channel_id_t    channel_id,
                                  const wjh_user_channel_attr_t *channel_attr_p)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t      *user_channel_p = NULL;
    uint64_t                        ef_cnt;
    int                             ret;
    wjh_drop_reason_group_e         drop_reason_group;
    wjh_drop_reason_group_record_t *drop_reason_group_item_p;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_USER_CHANNEL_ID_CHECK_RANGE(channel_id);
    WJH_CHECK_NULL_PTR(channel_attr_p, channel_attr_p);
    WJH_USER_CHANNEL_MODE_CHECK_RANGE(channel_attr_p->mode);
    WJH_AGGREGATION_READ_MODE_CHECK_RANGE(channel_attr_p->aggregation_read_mode);
    WJH_USER_CHANNEL_TIMESTAMP_SOURCE_CHECK_RANGE(channel_attr_p->timestamp_source);

    wjh_db_user_channel_get(channel_id, &user_channel_p);

    if (!user_channel_p->created) {
        WJH_LOG_ERR("The user channel (id: %u) does not exist.\n", channel_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    /*TAC channel will set span session id only*/
    if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAC_E) {
        if (wjh_driver_specific_callbacks_g->wjh_user_channel_tac_set_cb != NULL) {
            err = wjh_driver_specific_callbacks_g->wjh_user_channel_tac_set_cb(user_channel_p,
                                                                               channel_attr_p->span_session_id);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("wjh_user_channel_tac_set_cb failed, err = %d\n", err);
                goto out;
            }
        }
    } else {
        if ((user_channel_p->user_channel_dest != WJH_USER_CHANNEL_DESTINATION_DROP_MONITOR_E) &&
            (channel_attr_p->user_channel_dest == WJH_USER_CHANNEL_DESTINATION_DROP_MONITOR_E)) {
            err = __wjh_thread_destroy(&(user_channel_p->thread),
                                       &(user_channel_p->stop_thread),
                                       &(user_channel_p->cmd_event_fd));
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_user_channel_destroy failed, err: %d\n", err);
                goto out;
            }
        } else if ((user_channel_p->user_channel_dest == WJH_USER_CHANNEL_DESTINATION_DROP_MONITOR_E) &&
                   (channel_attr_p->user_channel_dest != WJH_USER_CHANNEL_DESTINATION_DROP_MONITOR_E)) {
            for (drop_reason_group = WJH_DROP_REASON_GROUP_MIN_E;
                 drop_reason_group <= WJH_DROP_REASON_GROUP_MAX_E;
                 ++drop_reason_group) {
                if (!user_channel_p->bound[drop_reason_group]) {
                    continue;
                }
                wjh_db_drop_reason_group_get(drop_reason_group, &drop_reason_group_item_p);
                err = __wjh_drop_reason_group_bind_check(user_channel_p->channel_type,
                                                         channel_attr_p->user_channel_dest,
                                                         drop_reason_group_item_p);
                if (WJH_CHECK_FAIL(err)) {
                    WJH_LOG_ERR("__wjh_drop_reason_group_bind_check failed, err: %d\n", err);
                    goto out;
                }
            }

            err = __wjh_user_channel_thread_create(user_channel_p);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_user_channel_thread_create failed, err = %d.\n", err);
                goto out;
            }
        }
        user_channel_p->user_channel_dest = channel_attr_p->user_channel_dest;

        if (channel_attr_p->polling_interval == 0) {
            if (user_channel_p->channel_type == WJH_USER_CHANNEL_CYCLIC_E) {
                user_channel_p->polling_interval = WJH_CYCLIC_CHANNEL_DEFAULT_POLLING_INTERVAL;
            } else {
                user_channel_p->polling_interval = WJH_AGGREGATION_CHANNEL_DEFAULT_POLLING_INTERVAL;
            }
        } else {
            user_channel_p->polling_interval = channel_attr_p->polling_interval;
        }

        user_channel_p->mode = channel_attr_p->mode;
        user_channel_p->aggregation_read_mode = channel_attr_p->aggregation_read_mode;
        if (wjh_driver_specific_callbacks_g->wjh_user_channel_timestamp_source_set_cb != NULL) {
            err = wjh_driver_specific_callbacks_g->wjh_user_channel_timestamp_source_set_cb(channel_id,
                                                                                            channel_attr_p->timestamp_source);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("wjh_user_channel_timestamp_source_set_cb failed, err = %d\n", err);
                goto out;
            }
        }
        user_channel_p->timestamp_source = channel_attr_p->timestamp_source;

        if (user_channel_p->cmd_event_fd >= 0) {
            ef_cnt = 1;
            ret = write(user_channel_p->cmd_event_fd, &ef_cnt, sizeof(uint64_t));
            if (ret != sizeof(uint64_t)) {
                WJH_LOG_ERR("Failed to write the cmd event fd, ret=%d.\n", ret);
                err = WJH_STATUS_ERROR;
                goto out;
            }
        }
    }
out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_user_channel_pull(const wjh_user_channel_id_t channel_id)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    wjh_status_t               err1 = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t *user_channel_p = NULL;
    void                      *buff_p = NULL;
    boolean_t                  buff_created = FALSE;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_USER_CHANNEL_ID_CHECK_RANGE(channel_id);

    wjh_db_user_channel_get(channel_id, &user_channel_p);

    if (!user_channel_p->created) {
        WJH_LOG_ERR("The user channel (id: %u) does not exist.\n", channel_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if ((user_channel_p->channel_type == WJH_USER_CHANNEL_TAILDROP_E) ||
        (user_channel_p->channel_type == WJH_USER_CHANNEL_TAC_E)) {
        WJH_LOG_ERR("The user channel (id: %u, type: %u) does support such operation.\n",
                    channel_id, user_channel_p->channel_type);
        err = WJH_STATUS_UNSUPPORTED;
        goto out;
    }

    if (wjh_driver_specific_callbacks_g->wjh_polling_thread_buf_create_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_polling_thread_buf_create_cb(user_channel_p, &buff_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_polling_thread_buf_create_cb failed, err = %d\n", err);
            goto out;
        }
        buff_created = TRUE;
    }

    if (wjh_driver_specific_callbacks_g->wjh_user_channel_process_cb != NULL) {
        cl_spinlock_acquire(&(user_channel_p->lock));
        err =
            wjh_driver_specific_callbacks_g->wjh_user_channel_process_cb(user_channel_p,
                                                                         buff_p,
                                                                         TRUE);
        cl_spinlock_release(&(user_channel_p->lock));
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_user_channel_process_cb failed, err = %d\n", err);
            goto out;
        }
    }

out:
    if (buff_created && (wjh_driver_specific_callbacks_g->wjh_polling_thread_buf_destroy_cb != NULL)) {
        err1 = wjh_driver_specific_callbacks_g->wjh_polling_thread_buf_destroy_cb(user_channel_p, buff_p);
        if (WJH_CHECK_FAIL(err1)) {
            WJH_LOG_ERR("wjh_polling_thread_buf_destroy_cb failed, err = %d\n", err1);
        }
    }
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_user_channel_destroy(const wjh_user_channel_id_t channel_id)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t *user_channel_p = NULL;
    uint32_t                   i = 0;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_USER_CHANNEL_ID_CHECK_RANGE(channel_id);

    wjh_db_user_channel_get(channel_id, &user_channel_p);

    if (!user_channel_p->created) {
        WJH_LOG_ERR("The user channel (id: %u) does not exist.\n", channel_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    for (i = 0; i < WJH_DROP_REASON_GROUP_NUM; ++i) {
        if (user_channel_p->bound[i]) {
            WJH_LOG_ERR("Drop reason group (%u) is bound to user channel (id: %u), please unbind first.\n",
                        i, channel_id);
            err = WJH_STATUS_ERROR;
            goto out;
        }
        if (user_channel_p->filter_record_p) {
            WJH_LOG_ERR("filter (%u) is bound to user channel (id: %u), please unbind first.\n",
                        user_channel_p->filter_record_p->filter_id, channel_id);
            err = WJH_STATUS_ERROR;
            goto out;
        }
    }

    err = __wjh_user_channel_destroy(user_channel_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_user_channel_destroy failed, err = %d\n", err);
        goto out;
    }

    wjh_shm_ptr_s->user_channel_shm_data.trap_groups[user_channel_p->channel_id] = WJH_TRAP_GROUP_INVALID;
    msync(wjh_shm_ptr_s, sizeof(wjh_shm_data_t), MS_SYNC);

    user_channel_p->created = FALSE;
    user_channel_p->filter_record_p = NULL;

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_user_channel_flush(const wjh_user_channel_id_t channel_id)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t *user_channel_p = NULL;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_USER_CHANNEL_ID_CHECK_RANGE(channel_id);

    wjh_db_user_channel_get(channel_id, &user_channel_p);

    if (!user_channel_p->created) {
        WJH_LOG_ERR("The user channel (id: %u) does not exist.\n", channel_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (wjh_driver_specific_callbacks_g->wjh_user_channel_flush_cb != NULL) {
        cl_spinlock_acquire(&(user_channel_p->lock));
        err = wjh_driver_specific_callbacks_g->wjh_user_channel_flush_cb(user_channel_p);
        cl_spinlock_release(&(user_channel_p->lock));
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_user_channel_flush_cb failed, err = %d.\n", err);
            goto out;
        }
    }

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

static wjh_status_t __wjh_drop_reason_group_check_callback(wjh_drop_reason_group_record_t *group_item_p,
                                                           boolean_t                       is_raw_callback)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    void        *callback_p = NULL;

    switch (group_item_p->drop_reason_group) {
    case WJH_DROP_REASON_GROUP_BUFFER_E:
        callback_p = is_raw_callback ? (void*)group_item_p->callbacks.raw_cb.buffer :
                     (void*)group_item_p->callbacks.aggregate_cb.buffer;
        break;

    case WJH_DROP_REASON_GROUP_ACL_E:
        callback_p = is_raw_callback ? (void*)group_item_p->callbacks.raw_cb.acl :
                     (void*)group_item_p->callbacks.aggregate_cb.acl;
        break;

    case WJH_DROP_REASON_GROUP_L1_E:
        callback_p = is_raw_callback ? (void*)group_item_p->callbacks.raw_cb.L1 :
                     (void*)group_item_p->callbacks.aggregate_cb.L1;
        break;

    case WJH_DROP_REASON_GROUP_L2_E:
        callback_p = is_raw_callback ? (void*)group_item_p->callbacks.raw_cb.L2 :
                     (void*)group_item_p->callbacks.aggregate_cb.L2;
        break;

    case WJH_DROP_REASON_GROUP_ROUTER_E:
        callback_p = is_raw_callback ? (void*)group_item_p->callbacks.raw_cb.router :
                     (void*)group_item_p->callbacks.aggregate_cb.router;
        break;

    case WJH_DROP_REASON_GROUP_TUNNEL_E:
        callback_p = is_raw_callback ? (void*)group_item_p->callbacks.raw_cb.tunnel :
                     (void*)group_item_p->callbacks.aggregate_cb.tunnel;
        break;

    case WJH_DROP_REASON_GROUP_ROCE_E:
        callback_p = is_raw_callback ? (void*)group_item_p->callbacks.raw_cb.roce :
                     (void*)group_item_p->callbacks.aggregate_cb.roce;
        break;

    default:
        WJH_LOG_ERR("Invalid drop reason group (%u).\n", group_item_p->drop_reason_group);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (callback_p == NULL) {
        WJH_LOG_ERR("The %s callback for drop reason group (%u) is NULL.\n",
                    is_raw_callback ? "raw" : "aggregation", group_item_p->drop_reason_group);
        err = WJH_STATUS_ERROR;
    }

out:
    return err;
}

static wjh_status_t __wjh_drop_reason_group_bind_check(wjh_user_channel_type_e         channel_type,
                                                       wjh_user_channel_destination_e  user_channel_dest,
                                                       wjh_drop_reason_group_record_t *group_item_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (user_channel_dest == WJH_USER_CHANNEL_DESTINATION_DROP_MONITOR_E) {
        /* If the user channel is drop monitor only, then the drop reason group callback will not be checked. */
        goto out;
    }

    switch (channel_type) {
    case WJH_USER_CHANNEL_TAILDROP_E:
    case WJH_USER_CHANNEL_CYCLIC_E:
        err = __wjh_drop_reason_group_check_callback(group_item_p, TRUE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_drop_reason_group_check_callback failed, err: %d\n", err);
            goto out;
        }
        break;

    case WJH_USER_CHANNEL_AGGREGATE_E:
        err = __wjh_drop_reason_group_check_callback(group_item_p, FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_drop_reason_group_check_callback failed, err: %d\n", err);
            goto out;
        }
        break;

    case WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E:
        err = __wjh_drop_reason_group_check_callback(group_item_p, TRUE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_drop_reason_group_check_callback failed, err: %d\n", err);
            goto out;
        }
        err = __wjh_drop_reason_group_check_callback(group_item_p, FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_drop_reason_group_check_callback failed, err: %d\n", err);
            goto out;
        }
        break;

    case WJH_USER_CHANNEL_TAC_E:
        break;

    default:
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Invalid channel type (%u).\n", channel_type);
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_drop_reason_group_bind(const wjh_drop_reason_group_e drop_reason_group,
                                        const wjh_user_channel_id_t   channel_id)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t      *user_channel_p = NULL;
    wjh_drop_reason_group_record_t *group_item_p = NULL;
    boolean_t                       rw_lock_acquired = FALSE;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_DROP_REASON_GROUP_CHECK_RANGE(drop_reason_group);
    WJH_USER_CHANNEL_ID_CHECK_RANGE(channel_id);

    wjh_db_user_channel_get(channel_id, &user_channel_p);
    wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);

    if (group_item_p->bound) {
        WJH_LOG_ERR("Drop reason group (%u) is already bound to user channel (id: %u).\n",
                    drop_reason_group, group_item_p->channel_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (!group_item_p->inited) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("The drop reason group (%u) is not initialized yet.\n", drop_reason_group);
        goto out;
    }

    if (!user_channel_p->created) {
        WJH_LOG_ERR("The user channel (id: %u) does not exist.\n", channel_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (user_channel_p->channel_type != WJH_USER_CHANNEL_TAC_E) {
        err = __wjh_drop_reason_group_bind_check(user_channel_p->channel_type,
                                                 user_channel_p->user_channel_dest,
                                                 group_item_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("__wjh_drop_reason_group_bind_check failed, err: %d\n", err);
            goto out;
        }
    }
    /* coverity[lock_order] */
    cl_plock_excl_acquire(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = TRUE;
    if (wjh_driver_specific_callbacks_g->wjh_drop_reason_group_bind_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_drop_reason_group_bind_cb(user_channel_p, group_item_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_drop_reason_group_bind_cb failed, err = %d.\n", err);
            goto out;
        }
    }

    user_channel_p->bound[drop_reason_group] = TRUE;
    group_item_p->channel_id = channel_id;
    group_item_p->bound = TRUE;
    cl_plock_release(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = FALSE;

    err = __wjh_drop_reason_item_save_shm_data(drop_reason_group);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh drop reason save shm data failed, err: %d\n", err);
        goto out;
    }

out:
    if (rw_lock_acquired) {
        cl_plock_release(&wjh_bind_enable_rwlock_g);
    }
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_drop_reason_group_unbind(const wjh_drop_reason_group_e drop_reason_group)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_status_t                    shm_err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_record_t *group_item_p = NULL;
    wjh_user_channel_record_t      *user_channel_p = NULL;
    boolean_t                       rw_lock_acquired = FALSE;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_DROP_REASON_GROUP_CHECK_RANGE(drop_reason_group);

    wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);

    if (!group_item_p->bound) {
        WJH_LOG_ERR("Drop reason group (%u) is not bound yet.\n", drop_reason_group);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    wjh_db_user_channel_get(group_item_p->channel_id, &user_channel_p);
    /* coverity[lock_order] */
    cl_plock_excl_acquire(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = TRUE;
    err = __wjh_drop_reason_group_unbind(group_item_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_drop_reason_group_unbind failed, err = %d\n", err);
        goto out;
    }

    cl_plock_release(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = FALSE;

out:
    if (rw_lock_acquired) {
        cl_plock_release(&wjh_bind_enable_rwlock_g);
    }
    if (wjh_init_done_g) {
        shm_err = __wjh_drop_reason_item_save_shm_data(drop_reason_group);
        if (WJH_CHECK_FAIL(shm_err)) {
            WJH_LOG_ERR("wjh drop reason save shm data failed, err: %d\n", shm_err);
            err = shm_err;
        }
    }
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_drop_reason_group_enable(const wjh_drop_reason_group_e drop_reason_group,
                                          const wjh_severity_e          severity)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_status_t                    shm_err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t      *user_channel_p = NULL;
    wjh_drop_reason_group_record_t *group_item_p = NULL;
    wjh_severity_e                  severity_to_set = severity;
    uint8_t                         enabled = 0;
    uint8_t                         to_enable = 0;
    boolean_t                       rw_lock_acquired = FALSE;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_DROP_REASON_GROUP_CHECK_RANGE(drop_reason_group);
    WJH_SEVERITY_CHECK_RANGE(severity_to_set);

    wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);

    if (!group_item_p->bound) {
        WJH_LOG_ERR("Drop reason group (%u) is not bound to a user channel yet.\n", drop_reason_group);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (drop_reason_group == WJH_DROP_REASON_GROUP_L1_E) {
        severity_to_set = WJH_SEVERITY_ALL_E;
    }

    enabled = group_item_p->enabled_severity_bits;
    WJH_SEVERITY_ENABLED_SET(group_item_p->enabled_severity_bits, severity_to_set);
    to_enable = group_item_p->enabled_severity_bits - enabled;

    if (!to_enable) {
        WJH_LOG_WRN("drop reason group %u on severity %u already enabled.\n", drop_reason_group, severity_to_set);
        goto out;
    }

    wjh_db_user_channel_get(group_item_p->channel_id, &user_channel_p);
    /* coverity[lock_order] */
    cl_plock_excl_acquire(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = TRUE;

    if (wjh_driver_specific_callbacks_g->wjh_drop_reason_group_enable_cb != NULL) {
        err =
            wjh_driver_specific_callbacks_g->wjh_drop_reason_group_enable_cb(user_channel_p, group_item_p, to_enable);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_drop_reason_group_enable_cb failed, err = %d.\n", err);
            goto rollback;
        }
    }

    if (!enabled) {
        user_channel_p->group_enable_count++;
    }
    cl_plock_release(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = FALSE;

rollback:
    if (WJH_CHECK_FAIL(err)) {
        /* coverity[check_after_deref] */
        if (group_item_p) {
            group_item_p->enabled_severity_bits = enabled;
        }
    }

out:
    if (rw_lock_acquired) {
        cl_plock_release(&wjh_bind_enable_rwlock_g);
    }

    if (wjh_init_done_g) {
        shm_err = __wjh_drop_reason_item_save_shm_data(drop_reason_group);
        if (WJH_CHECK_FAIL(shm_err)) {
            WJH_LOG_ERR("wjh drop reason save shm data failed, err: %d\n", shm_err);
            err = shm_err;
        }
    }

    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_drop_reason_group_disable(const wjh_drop_reason_group_e drop_reason_group,
                                           const wjh_severity_e          severity)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t      *user_channel_p = NULL;
    wjh_drop_reason_group_record_t *group_item_p = NULL;
    wjh_severity_e                  severity_to_set = severity;
    uint8_t                         enabled = 0;
    uint8_t                         to_disable = 0;
    boolean_t                       rw_lock_acquired = FALSE;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_DROP_REASON_GROUP_CHECK_RANGE(drop_reason_group);
    WJH_SEVERITY_CHECK_RANGE(severity_to_set);

    wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);

    if (!group_item_p->bound) {
        WJH_LOG_ERR("Drop reason group (%u) is not bound to a user channel yet.\n", drop_reason_group);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (drop_reason_group == WJH_DROP_REASON_GROUP_L1_E) {
        severity_to_set = WJH_SEVERITY_ALL_E;
    }

    enabled = group_item_p->enabled_severity_bits;
    WJH_SEVERITY_ENABLED_CLEAR(group_item_p->enabled_severity_bits, severity_to_set);
    to_disable = enabled - group_item_p->enabled_severity_bits;

    if (!to_disable) {
        WJH_LOG_WRN("drop reason group %u on severity %u already disabled.\n", drop_reason_group, severity_to_set);
        goto out;
    }

    wjh_db_user_channel_get(group_item_p->channel_id, &user_channel_p);
    /* coverity[lock_order] */
    cl_plock_excl_acquire(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = TRUE;
    if (wjh_driver_specific_callbacks_g->wjh_drop_reason_group_disable_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_drop_reason_group_disable_cb(user_channel_p,
                                                                                group_item_p,
                                                                                to_disable);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_drop_reason_group_disable_cb failed, err = %d.\n", err);
            goto rollback;
        }
    }

    if (group_item_p->enabled_severity_bits == 0) {
        user_channel_p->group_enable_count--;
    }
    cl_plock_release(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = FALSE;

    err = __wjh_drop_reason_item_save_shm_data(drop_reason_group);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("wjh drop reason save shm data failed, err: %d\n", err);
        goto out;
    }

rollback:
    if (WJH_CHECK_FAIL(err)) {
        /* coverity[check_after_deref] */
        if (group_item_p) {
            group_item_p->enabled_severity_bits = enabled;
        }
    }

out:
    if (rw_lock_acquired) {
        cl_plock_release(&wjh_bind_enable_rwlock_g);
    }

    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_drop_reason_severity_get(const wjh_drop_reason_id_e drop_reason,
                                          wjh_severity_e            *severity_p)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_item_t *drop_reason_item_p = NULL;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_CHECK_NULL_PTR(severity_p, severity_p);

    if (drop_reason == WJH_DROP_REASON_ID_L1_GENERAL_E) {
        err = WJH_STATUS_PARAM_ERROR;
        WJH_LOG_ERR(
            "Not applicable for L1 general reason %u, which is only for general usage of L1 raw info and L1 filter.\n",
            drop_reason);
        goto out;
    }

    if ((drop_reason >= WJH_L1_PORT_DOWN_REASON_ID_MIN) &&
        (drop_reason < (WJH_L1_PORT_DOWN_REASON_ID_MIN + WJH_L1_PORT_DOWN_REASON_NUM))) {
        err = WJH_STATUS_PARAM_ERROR;
        WJH_LOG_ERR("Not applicable for port down reason %u.\n", drop_reason);
        goto out;
    }

    err = wjh_db_get_drop_reason_item_by_reason(drop_reason, &drop_reason_item_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to get severity for drop reason %d.\n", drop_reason);
    }

    *severity_p = drop_reason_item_p->severity;

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_counter_get(const wjh_user_channel_id_t channel_id,
                             wjh_drop_counter_t         *counter_p,
                             const uint8_t               clear)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t *user_channel_p = NULL;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_USER_CHANNEL_ID_CHECK_RANGE(channel_id);
    WJH_CHECK_NULL_PTR(counter_p, counter_p);

    wjh_db_user_channel_get(channel_id, &user_channel_p);

    if (!user_channel_p->created) {
        WJH_LOG_ERR("The user channel (id: %u) does not exist.\n", channel_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    cl_spinlock_acquire(&(user_channel_p->lock));
    counter_p->received_packets = user_channel_p->received_packets;

    if (wjh_driver_specific_callbacks_g->wjh_counter_dropped_packets_get_cb != NULL) {
        if (user_channel_p->channel_type == WJH_USER_CHANNEL_TAC_E) {
            err = wjh_driver_specific_callbacks_g->wjh_counter_dropped_packets_get_cb(user_channel_p,
                                                                                      &(counter_p->tac_ingress_drop),
                                                                                      clear);
        } else {
            err = wjh_driver_specific_callbacks_g->wjh_counter_dropped_packets_get_cb(user_channel_p,
                                                                                      &(counter_p->dropped_packets),
                                                                                      clear);
        }
        if (WJH_CHECK_FAIL(err)) {
            cl_spinlock_release(&(user_channel_p->lock));
            WJH_LOG_ERR("wjh_counter_dropped_packets_get_cb failed, err = %d.\n", err);
            goto out;
        }
    }

    if (clear) {
        user_channel_p->received_packets = 0;
    }

    cl_spinlock_release(&(user_channel_p->lock));

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

wjh_status_t wjh_global_counter_get(wjh_drop_counter_t *counter_p, const uint8_t clear)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t *user_channel_p = NULL;
    wjh_user_channel_id_t      channel_id;
    uint64_t                   received_packets = 0;
    uint64_t                   dropped_packets = 0;
    uint64_t                   total_dropped_packets = 0;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_CHECK_NULL_PTR(counter_p, counter_p);

    for (channel_id = 0; channel_id < WJH_USER_CHANNEL_MAX_NUM; ++channel_id) {
        wjh_db_user_channel_get(channel_id, &user_channel_p);

        if (!user_channel_p->created) {
            continue;
        }

        cl_spinlock_acquire(&(user_channel_p->lock));
        received_packets += user_channel_p->received_packets;

        dropped_packets = 0;
        if (wjh_driver_specific_callbacks_g->wjh_counter_dropped_packets_get_cb != NULL) {
            err = wjh_driver_specific_callbacks_g->wjh_counter_dropped_packets_get_cb(user_channel_p,
                                                                                      &dropped_packets,
                                                                                      clear);
            if (WJH_CHECK_FAIL(err)) {
                cl_spinlock_release(&(user_channel_p->lock));
                WJH_LOG_ERR("wjh_counter_dropped_packets_get_cb failed, err = %d.\n", err);
                goto out;
            }
        }

        total_dropped_packets += dropped_packets;

        if (clear) {
            user_channel_p->received_packets = 0;
        }
        cl_spinlock_release(&(user_channel_p->lock));
    }

    counter_p->received_packets = received_packets;
    counter_p->dropped_packets = total_dropped_packets;

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}

#ifdef WJH_EBPF_PRESENT
static wjh_status_t __wjh_validate_filter_keys(wjh_filter_key_e *key_list_p, uint32_t count)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    boolean_t    is_key_set[WJH_FILTER_KEY_NUM];
    uint32_t     i = 0;

    WJH_CHECK_NULL_PTR(key_list_p, key_list_p);
    if (count == 0) {
        WJH_LOG_ERR("Filter key list count is 0.\n");
        goto out;
    }

    memset(is_key_set, FALSE, sizeof(wjh_filter_key_e) * WJH_FILTER_KEY_NUM);

    for (i = 0; i < count; i++) {
        if (is_key_set[key_list_p[i]] == TRUE) {
            err = WJH_STATUS_PARAM_ERROR;
            WJH_LOG_ERR("Duplicated filter key.\n");
            goto out;
        }
        is_key_set[key_list_p[i]] = TRUE;
    }

out:
    return err;
}
#endif

wjh_status_t wjh_filter_create(wjh_filter_key_e *key_list_p, uint32_t count, wjh_filter_id_t *filter_id_p)
{
#ifdef WJH_EBPF_PRESENT
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    wjh_db_filter_record_t *filter_record_p = NULL;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_CHECK_NULL_PTR(key_list_p, key_list_p);
    WJH_CHECK_NULL_PTR(filter_id_p, filter_id_p);

    err = __wjh_validate_filter_keys(key_list_p, count);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Filter key list validation failed.\n");
        goto out;
    }

    err = wjh_db_filter_create(key_list_p, count, &filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to create filter.\n");
        goto out;
    }

    if (wjh_driver_specific_callbacks_g->wjh_filter_create_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_filter_create_cb(filter_record_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to create filter %d\n", *filter_id_p);
            goto out;
        }
    }

    *filter_id_p = filter_record_p->filter_id;

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
#else
    UNUSED_PARAM(key_list_p);
    UNUSED_PARAM(count);
    UNUSED_PARAM(filter_id_p);

    WJH_LOG_ERR("Filter API not supported since ebpf is not present in the kernel.\n");

    return WJH_STATUS_UNSUPPORTED;
#endif
}

wjh_status_t wjh_filter_get(wjh_filter_id_t filter_id, wjh_filter_key_e  *key_list_p, uint32_t *count_p)
{
#ifdef WJH_EBPF_PRESENT
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    wjh_db_filter_record_t *filter_record_p = NULL;
    uint32_t                count = 0;
    uint32_t                i = 0;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);

    WJH_CHECK_NULL_PTR(count_p, count_p);
    if (*count_p != 0) {
        WJH_CHECK_NULL_PTR(key_list_p, key_list_p);
    }

    err = wjh_db_filter_get(filter_id, &filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR("Failed to get filter record for filter %d\n", filter_id);
        }
        goto out;
    }

    if (*count_p == 0) {
        *count_p = filter_record_p->keys_num;
        goto out;
    }

    for (i = 0; i < WJH_FILTER_KEY_NUM; i++) {
        if (count > *count_p) {
            break;
        }
        if (filter_record_p->is_key_set[i] == TRUE) {
            key_list_p[count] = i;
            count++;
        }
    }

    *count_p = count;

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
#else
    UNUSED_PARAM(filter_id);
    UNUSED_PARAM(key_list_p);
    UNUSED_PARAM(count_p);

    WJH_LOG_ERR("Filter API not supported since ebpf is not present in the kernel.\n");

    return WJH_STATUS_UNSUPPORTED;
#endif
}

wjh_status_t wjh_filter_destroy(wjh_filter_id_t filter_id)
{
#ifdef WJH_EBPF_PRESENT
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    wjh_db_filter_record_t *filter_record_p = NULL;
    uint32_t                i = 0;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);

    err = wjh_db_filter_get(filter_id, &filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR("Failed to get filter record for filter %d\n", filter_id);
        }
        goto out;
    }

    for (i = 0; i < WJH_USER_CHANNEL_MAX_NUM; i++) {
        if (filter_record_p->bound[i] == TRUE) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("filter %d is still bound to channel %d\n", filter_id, i);
            goto out;
        }
    }

    if (wjh_driver_specific_callbacks_g->wjh_filter_destroy_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_filter_destroy_cb(filter_record_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to destroy filter %d\n", filter_id);
            goto out;
        }
    }

    wjh_db_filter_destroy(filter_record_p);

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
#else
    UNUSED_PARAM(filter_id);

    WJH_LOG_ERR("Filter API not supported since ebpf is not present in the kernel.\n");
    return WJH_STATUS_UNSUPPORTED;
#endif
}

#ifdef WJH_EBPF_PRESENT
static wjh_status_t __wjh_validate_filter_rules(wjh_db_filter_record_t *filter_record_p,
                                                wjh_filter_rule_t      *rule_list_p,
                                                uint32_t                rule_count)
{
    wjh_status_t                err = WJH_STATUS_SUCCESS;
    uint32_t                    i = 0, j = 0;
    wjh_db_filter_rule_record_t filter_rule_record;
    wjh_filter_key_e            key = WJH_FILTER_KEY_MIN_E;
    wjh_chip_types_t            chip_type = 0;

    for (i = 0; i < rule_count; i++) {
        memset(&filter_rule_record, 0, sizeof(wjh_db_filter_rule_record_t));
        for (j = 0; j < rule_list_p[i].key_desc_count; j++) {
            key = rule_list_p[i].key_desc_list_p[j].key;
            if (filter_record_p->is_key_set[key] == FALSE) {
                err = WJH_STATUS_PARAM_ERROR;
                WJH_LOG_ERR("Failed to get the filter key of rule inside key list of filter.\n");
                goto out;
            }
            if (filter_rule_record.is_key_set[key] == TRUE) {
                err = WJH_STATUS_PARAM_ERROR;
                WJH_LOG_ERR("Duplicated filter key in rule.\n");
                goto out;
            }
            switch (key) {
            case WJH_FILTER_KEY_DROP_REASON_E:
                wjh_db_get_chip_type(&chip_type);
                if (chip_type == SXD_CHIP_TYPE_SPECTRUM) {
                    if ((rule_list_p[i].key_desc_list_p[j].field.drop_reason == WJH_DROP_REASON_ID_WRED_E) ||
                        (rule_list_p[i].key_desc_list_p[j].field.drop_reason ==
                         WJH_DROP_REASON_ID_ING_TC_CONGESTION) ||
                        (rule_list_p[i].key_desc_list_p[j].field.drop_reason == WJH_DROP_REASON_ID_EGR_TC_LATENCY)) {
                        err = WJH_STATUS_PARAM_ERROR;
                        WJH_LOG_ERR(
                            "Not support to filter buffer drop reason %d on SPC-1, please use WJH_DROP_REASON_ID_TAIL_DROP_E for all buffer drop.\n",
                            rule_list_p[i].key_desc_list_p[j].field.drop_reason);
                        goto out;
                    }
                }
                break;

            default:
                break;
            }
            filter_rule_record.is_key_set[key] = TRUE;
        }
    }

    if (wjh_driver_specific_callbacks_g->wjh_filter_rules_validate_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_filter_rules_validate_cb(rule_list_p, rule_count);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Validation failed on filter rule.\n");
            goto out;
        }
    }
out:
    return err;
}
#endif /* ifdef WJH_EBPF_PRESENT */

wjh_status_t wjh_filter_rule_add(wjh_filter_id_t filter_id, wjh_filter_rule_t *rule_list_p, uint32_t rule_count)
{
#ifdef WJH_EBPF_PRESENT
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    wjh_db_filter_record_t      *filter_record_p = NULL;
    wjh_db_filter_rule_record_t *filter_rule_record_p = NULL;
    uint32_t                     i = 0;
    boolean_t                    rw_lock_acquired = FALSE;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_CHECK_NULL_PTR(rule_list_p, key_list_p);

    if ((rule_count == 0) || (rule_count > WJH_FILTER_RULE_MAX_NUM)) {
        err = WJH_STATUS_PARAM_ERROR;
        WJH_LOG_ERR("Invalid rule count %d.\n", rule_count);
        goto out;
    }

    err = wjh_db_filter_get(filter_id, &filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR("Failed to get filter record for filter %d\n", filter_id);
        }
        goto out;
    }

    if ((filter_record_p->rules_num + rule_count) > WJH_FILTER_RULE_MAX_NUM) {
        err = WJH_STATUS_NO_RESOURCES;
        WJH_LOG_ERR("No more rule resource of the filter, %d rules allowed, %d rules exist, try to add %d rules.\n",
                    WJH_FILTER_RULE_MAX_NUM, filter_record_p->rules_num, rule_count);
        goto out;
    }

    err = __wjh_validate_filter_rules(filter_record_p, rule_list_p, rule_count);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Filter rules validation failed.\n");
        goto out;
    }

    /* coverity[lock_order] */
    cl_plock_acquire(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = TRUE;
    for (i = 0; i < rule_count; i++) {
        err = wjh_db_filter_rule_add(filter_record_p, &rule_list_p[i], &filter_rule_record_p);
        if (err == WJH_STATUS_ENTRY_ALREADY_EXIST) {
            err = WJH_STATUS_SUCCESS;
            continue;
        }
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to add filter rules to DB.\n");
            goto out;
        }

        if (filter_rule_record_p->is_key_set[WJH_FILTER_KEY_PORT_E]) {
            if (wjh_driver_specific_callbacks_g->wjh_get_hw_port_cb != NULL) {
                err =
                    wjh_driver_specific_callbacks_g->wjh_get_hw_port_cb(
                        filter_rule_record_p->key_field[WJH_FILTER_KEY_PORT_E].port,
                        &filter_rule_record_p->ebpf_key.hw_port,
                        &filter_rule_record_p->label_port);
                if (WJH_CHECK_FAIL(err)) {
                    WJH_LOG_ERR("Failed to get hw port of filter rule port 0x%x.\n",
                                filter_rule_record_p->key_field[WJH_FILTER_KEY_PORT_E].port);
                    goto out;
                }
            } else {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("No low layer function to get hw port of filter rule port 0x%x.\n",
                            filter_rule_record_p->key_field[WJH_FILTER_KEY_PORT_E].port);
                goto out;
            }
        }

        if (wjh_driver_specific_callbacks_g->wjh_filter_rule_add_cb != NULL) {
            err = wjh_driver_specific_callbacks_g->wjh_filter_rule_add_cb(filter_record_p, filter_rule_record_p);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to add filter rules.\n");
                goto out;
            }
        }
    }
    cl_plock_release(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = FALSE;

out:
    if (rw_lock_acquired) {
        cl_plock_release(&wjh_bind_enable_rwlock_g);
    }
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
#else /* ifdef WJH_EBPF_PRESENT */
    UNUSED_PARAM(filter_id);
    UNUSED_PARAM(rule_list_p);
    UNUSED_PARAM(rule_count);

    WJH_LOG_ERR("Filter API not supported since ebpf is not present in the kernel.\n");
    return WJH_STATUS_UNSUPPORTED;
#endif /* ifdef WJH_EBPF_PRESENT */
}

wjh_status_t wjh_filter_rule_remove(wjh_filter_id_t filter_id, wjh_filter_rule_t *rule_list_p, uint32_t rule_count)
{
#ifdef WJH_EBPF_PRESENT
    wjh_status_t                  err = WJH_STATUS_SUCCESS;
    wjh_db_filter_record_t       *filter_record_p = NULL;
    wjh_db_filter_rule_record_t **filter_rule_record_arr_p = NULL;
    wjh_db_filter_rule_record_t  *filter_rule_record_p = NULL;
    u_int32_t                     i = 0;
    boolean_t                     rw_lock_acquired = FALSE;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_CHECK_NULL_PTR(rule_list_p, key_list_p);

    if ((rule_count == 0) || (rule_count > WJH_FILTER_RULE_MAX_NUM)) {
        err = WJH_STATUS_PARAM_ERROR;
        WJH_LOG_ERR("Invalid rule count %d.\n", rule_count);
        goto out;
    }

    err = wjh_db_filter_get(filter_id, &filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR("Failed to get filter record for filter %d\n", filter_id);
        }
        goto out;
    }

    filter_rule_record_arr_p = cl_malloc(sizeof(wjh_db_filter_rule_record_t*) * rule_count);
    if (filter_rule_record_arr_p == NULL) {
        err = WJH_STATUS_NO_MEMORY;
        WJH_LOG_ERR("Failed to allocate memory for filter rule record array.\n");
        goto out;
    }

    for (i = 0; i < rule_count; i++) {
        err = wjh_db_filter_rule_record_get(filter_record_p, &rule_list_p[i], &filter_rule_record_p);
        if (WJH_CHECK_FAIL(err)) {
            if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
                WJH_LOG_ERR("Failed to delete filter rules.\n");
            } else {
                WJH_LOG_DBG("Filter rule is not found.\n");
            }
            goto out;
        }
        filter_rule_record_arr_p[i] = filter_rule_record_p;
    }

    /* coverity[lock_order] */
    cl_plock_acquire(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = TRUE;
    for (i = 0; i < rule_count; i++) {
        err = wjh_db_filter_rule_record_remove(filter_record_p, filter_rule_record_arr_p[i]);
        if (WJH_CHECK_FAIL(err)) {
            if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
                WJH_LOG_ERR("Failed to delete filter rules.\n");
                goto out;
            } else {
                err = WJH_STATUS_SUCCESS;
                WJH_LOG_DBG("Ignore the duplicated rules.\n");
                filter_rule_record_arr_p[i] = NULL;
                continue;
            }
        }

        if (filter_rule_record_arr_p[i]) {
            if (wjh_driver_specific_callbacks_g->wjh_filter_rule_remove_cb != NULL) {
                wjh_driver_specific_callbacks_g->wjh_filter_rule_remove_cb(filter_record_p,
                                                                           filter_rule_record_arr_p[i]);
                if (WJH_CHECK_FAIL(err)) {
                    WJH_LOG_ERR("Failed to remove filter rule.\n");
                    goto out;
                }
            }
        }
    }
    cl_plock_release(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = FALSE;

out:
    if (filter_rule_record_arr_p) {
        CL_FREE_N_NULL(filter_rule_record_arr_p);
    }
    if (rw_lock_acquired) {
        cl_plock_release(&wjh_bind_enable_rwlock_g);
    }
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
#else /* ifdef WJH_EBPF_PRESENT */
    UNUSED_PARAM(filter_id);
    UNUSED_PARAM(rule_list_p);
    UNUSED_PARAM(rule_count);

    WJH_LOG_ERR("Filter API not supported since ebpf is not present in the kernel.\n");
    return WJH_STATUS_UNSUPPORTED;
#endif /* ifdef WJH_EBPF_PRESENT */
}

#ifdef WJH_EBPF_PRESENT
static wjh_status_t __wjh_filter_rule_record_to_rule(wjh_db_filter_rule_record_t *rule_record_p,
                                                     wjh_filter_rule_t           *rule_p)
{
    wjh_status_t     err = WJH_STATUS_SUCCESS;
    wjh_filter_key_e key = WJH_FILTER_KEY_MIN_E;
    uint32_t         count = 0;

    if (rule_p->key_desc_list_p == NULL) {
        rule_p->key_desc_count = rule_record_p->key_desc_count;
        goto out;
    }

    for (key = WJH_FILTER_KEY_MIN_E; key < WJH_FILTER_KEY_NUM; key++) {
        if (rule_p->key_desc_count <= count) {
            break;
        }
        if (rule_record_p->is_key_set[key] == TRUE) {
            rule_p->key_desc_list_p[count].key = key;
            rule_p->key_desc_list_p[count].field = rule_record_p->key_field[key];
            count++;
        }
    }

    rule_p->key_desc_count = count;
out:
    return err;
}
#endif

wjh_status_t wjh_filter_rules_get(wjh_filter_id_t    filter_id,
                                  wjh_filter_rule_t *rule_list_p,
                                  uint64_t          *rule_counter_list_p,
                                  uint32_t          *rule_count_p,
                                  uint8_t            clear)
{
#ifdef WJH_EBPF_PRESENT
    wjh_status_t                  err = WJH_STATUS_SUCCESS;
    wjh_db_filter_record_t       *filter_record_p = NULL;
    wjh_db_filter_rule_record_t **filter_rule_record_list_pp = NULL;
    uint32_t                      i = 0;
    uint32_t                      rule_count = 0;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_NULL_PTR(rule_count_p, rule_count_p);

    err = wjh_db_filter_get(filter_id, &filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR("Failed to get filter record for filter %d\n", filter_id);
        }
        goto out;
    }

    if (*rule_count_p == 0) {
        *rule_count_p = filter_record_p->rules_num;
        goto out;
    }

    WJH_CHECK_NULL_PTR(rule_list_p, rule_list_p);

    rule_count = filter_record_p->rules_num;
    filter_rule_record_list_pp = cl_malloc(sizeof(wjh_db_filter_rule_record_t*) * rule_count);
    if (filter_rule_record_list_pp == NULL) {
        WJH_LOG_ERR("Failed allocate memory.\n");
        err = WJH_STATUS_NO_MEMORY;
        goto out;
    }

    err = wjh_db_filter_rule_record_list_get(filter_record_p, filter_rule_record_list_pp, &rule_count);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to get filter rule record list %d.\n", filter_id);
        goto out;
    }

    if (*rule_count_p > rule_count) {
        *rule_count_p = rule_count;
    }

    for (i = 0; i < *rule_count_p; i++) {
        __wjh_filter_rule_record_to_rule(filter_rule_record_list_pp[i], &rule_list_p[i]);

        if (wjh_driver_specific_callbacks_g->wjh_filter_rule_counter_get_cb != NULL) {
            err = wjh_driver_specific_callbacks_g->wjh_filter_rule_counter_get_cb(filter_record_p,
                                                                                  filter_rule_record_list_pp[i],
                                                                                  clear);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to get filter rule counter in filter %d.\n", filter_id);
                goto out;
            }
        }
        if (rule_counter_list_p != NULL) {
            rule_counter_list_p[i] = filter_rule_record_list_pp[i]->counter;
        }
        if (clear) {
            filter_rule_record_list_pp[i]->counter = 0;
        }
    }

    if (clear) {
        filter_record_p->counter = 0;
    }

out:
    if (filter_rule_record_list_pp) {
        CL_FREE_N_NULL(filter_rule_record_list_pp);
    }
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
#else /* ifdef WJH_EBPF_PRESENT */
    UNUSED_PARAM(filter_id);
    UNUSED_PARAM(rule_list_p);
    UNUSED_PARAM(rule_counter_list_p);
    UNUSED_PARAM(rule_count_p);
    UNUSED_PARAM(clear);

    WJH_LOG_ERR("Filter API not supported since ebpf is not present in the kernel.\n");
    return WJH_STATUS_UNSUPPORTED;
#endif /* ifdef WJH_EBPF_PRESENT */
}

wjh_status_t wjh_filter_rule_counter_get(wjh_filter_id_t    filter_id,
                                         wjh_filter_rule_t *rule_p,
                                         uint64_t          *rule_counter_p,
                                         uint8_t            clear)
{
#ifdef WJH_EBPF_PRESENT
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    wjh_db_filter_record_t      *filter_record_p = NULL;
    wjh_db_filter_rule_record_t *filter_rule_record_p = NULL;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_NULL_PTR(rule_p, rule_p);
    WJH_CHECK_NULL_PTR(rule_counter_p, rule_counter_p);

    err = wjh_db_filter_get(filter_id, &filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR("Failed to get filter record for filter %d\n", filter_id);
        }
        goto out;
    }

    err = wjh_db_filter_rule_record_get(filter_record_p, rule_p, &filter_rule_record_p);
    if (WJH_CHECK_FAIL(err)) {
        if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR("Failed to delete filter rules.\n");
        }
        goto out;
    }

    if (wjh_driver_specific_callbacks_g->wjh_filter_rule_counter_get_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_filter_rule_counter_get_cb(filter_record_p,
                                                                              filter_rule_record_p,
                                                                              clear);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to get filter rule counter in filter %d.\n", filter_id);
            goto out;
        }
    }

    *rule_counter_p = filter_rule_record_p->counter;

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
#else

    UNUSED_PARAM(filter_id);
    UNUSED_PARAM(rule_p);
    UNUSED_PARAM(rule_counter_p);
    UNUSED_PARAM(clear);

    WJH_LOG_ERR("Filter API not supported since ebpf is not present in the kernel.\n");
    return WJH_STATUS_UNSUPPORTED;
#endif
}

wjh_status_t wjh_filter_counter_get(wjh_filter_id_t filter_id, uint64_t *counter_p, uint8_t clear)
{
#ifdef WJH_EBPF_PRESENT
    wjh_status_t                  err = WJH_STATUS_SUCCESS;
    wjh_db_filter_record_t       *filter_record_p = NULL;
    wjh_db_filter_rule_record_t **filter_rule_record_list_pp = NULL;
    uint32_t                      rule_count = 0;
    uint32_t                      i = 0;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_NULL_PTR(counter_p, counter_p);

    err = wjh_db_filter_get(filter_id, &filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        if (err != WJH_STATUS_ENTRY_NOT_FOUND) {
            WJH_LOG_ERR("Failed to get filter record for filter %d\n", filter_id);
        }
        goto out;
    }

    rule_count = filter_record_p->rules_num;
    filter_rule_record_list_pp = cl_malloc(sizeof(wjh_db_filter_rule_record_t*) * rule_count);
    if (filter_rule_record_list_pp == NULL) {
        WJH_LOG_ERR("Failed allocate memory.\n");
        err = WJH_STATUS_NO_MEMORY;
        goto out;
    }

    err = wjh_db_filter_rule_record_list_get(filter_record_p, filter_rule_record_list_pp, &rule_count);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to get filter rule record list %d.\n", filter_id);
        goto out;
    }

    for (i = 0; i < rule_count; i++) {
        if (wjh_driver_specific_callbacks_g->wjh_filter_rule_counter_get_cb != NULL) {
            err = wjh_driver_specific_callbacks_g->wjh_filter_rule_counter_get_cb(filter_record_p,
                                                                                  filter_rule_record_list_pp[i],
                                                                                  clear);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Failed to get filter rule counter %d.\n", filter_id);
                goto out;
            }
        }
        filter_record_p->counter += filter_rule_record_list_pp[i]->counter;
    }

    *counter_p = filter_record_p->counter;

    if (clear) {
        filter_record_p->counter = 0;
    }

out:
    if (filter_rule_record_list_pp) {
        CL_FREE_N_NULL(filter_rule_record_list_pp);
    }
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
#else /* ifdef WJH_EBPF_PRESENT */
    UNUSED_PARAM(filter_id);
    UNUSED_PARAM(counter_p);
    UNUSED_PARAM(clear);

    WJH_LOG_ERR("Filter API not supported since ebpf is not present in the kernel.\n");
    return WJH_STATUS_UNSUPPORTED;
#endif /* ifdef WJH_EBPF_PRESENT */
}

wjh_status_t wjh_filter_bind_user_channel(wjh_filter_id_t filter_id, wjh_user_channel_id_t channel_id)
{
#ifdef WJH_EBPF_PRESENT
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t *channel_record_p = NULL;
    wjh_db_filter_record_t    *filter_record_p = NULL;
    boolean_t                  rw_lock_acquired = FALSE;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);

    wjh_db_user_channel_get(channel_id, &channel_record_p);
    if (channel_record_p->created == FALSE) {
        err = WJH_STATUS_ENTRY_NOT_FOUND;
        WJH_LOG_ERR("Failed to find channel %d.\n", channel_id);
        goto out;
    }

    if (channel_record_p->filter_record_p) {
        WJH_LOG_ERR("Filter %d is already bound to channel %d.\n",
                    channel_record_p->filter_record_p->filter_id,
                    channel_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (channel_record_p->channel_type == WJH_USER_CHANNEL_TAC_E) {
        WJH_LOG_ERR("Can't bind filter on TAC channel\n");
        err = WJH_STATUS_UNSUPPORTED;
        goto out;
    }

    err = wjh_db_filter_get(filter_id, &filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to get filter %d.\n", filter_id);
        goto out;
    }

    if (filter_record_p->bound[channel_id] == TRUE) {
        WJH_LOG_ERR("Filter %d is already bound to channel %d.\n", filter_id, channel_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    /* coverity[lock_order] */
    cl_plock_acquire(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = TRUE;

    if (wjh_driver_specific_callbacks_g->wjh_filter_bind_channel_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_filter_bind_channel_cb(filter_record_p, channel_record_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to bind filter %d to channel %d\n", filter_id, channel_id);
            goto out;
        }
    }

    filter_record_p->bound[channel_id] = TRUE;
    channel_record_p->filter_record_p = filter_record_p;

    cl_plock_release(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = FALSE;

out:
    if (rw_lock_acquired) {
        cl_plock_release(&wjh_bind_enable_rwlock_g);
    }
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
#else /* ifdef WJH_EBPF_PRESENT */
    UNUSED_PARAM(filter_id);
    UNUSED_PARAM(channel_id);

    WJH_LOG_ERR("Filter API not supported since ebpf is not present in the kernel.\n");
    return WJH_STATUS_UNSUPPORTED;
#endif /* ifdef WJH_EBPF_PRESENT */
}

wjh_status_t wjh_filter_unbind_user_channel(wjh_filter_id_t filter_id, wjh_user_channel_id_t channel_id)
{
#ifdef WJH_EBPF_PRESENT
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    wjh_user_channel_record_t *channel_record_p = NULL;
    wjh_db_filter_record_t    *filter_record_p = NULL;
    boolean_t                  rw_lock_acquired = FALSE;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);

    wjh_db_user_channel_get(channel_id, &channel_record_p);
    if (channel_record_p->created == FALSE) {
        err = WJH_STATUS_ENTRY_NOT_FOUND;
        WJH_LOG_ERR("Failed to find channel %d.\n", channel_id);
        goto out;
    }
    err = wjh_db_filter_get(filter_id, &filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to get filter %d.\n", filter_id);
        goto out;
    }

    if (filter_record_p->bound[channel_id] == FALSE) {
        WJH_LOG_ERR("Filter %d is not bound to channel %d.\n", filter_id, channel_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

    /* coverity[lock_order] */
    cl_plock_acquire(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = TRUE;

    if (wjh_driver_specific_callbacks_g->wjh_filter_unbind_channel_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_filter_unbind_channel_cb(filter_record_p, channel_record_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to unbind filter %d from channel %d\n", filter_id, channel_id);
            goto out;
        }
    }
    filter_record_p->bound[channel_id] = FALSE;
    channel_record_p->filter_record_p = NULL;

    cl_plock_release(&wjh_bind_enable_rwlock_g);
    rw_lock_acquired = FALSE;

out:
    if (rw_lock_acquired) {
        cl_plock_release(&wjh_bind_enable_rwlock_g);
    }
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
#else  /* ifdef WJH_EBPF_PRESENT */
    UNUSED_PARAM(filter_id);
    UNUSED_PARAM(channel_id);

    WJH_LOG_ERR("Filter API not supported since ebpf is not present in the kernel.\n");
    return WJH_STATUS_UNSUPPORTED;
#endif /* ifdef WJH_EBPF_PRESENT */
}

wjh_status_t wjh_get_chip_type(wjh_chip_types_t *chip_type)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (wjh_driver_specific_callbacks_g->wjh_get_chip_type_cb != NULL) {
        err = wjh_driver_specific_callbacks_g->wjh_get_chip_type_cb(chip_type);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_get_chip_type failed, err = %d.\n", err);
        }
    }
    return err;
}

wjh_status_t wjh_dbg_generate_dump(FILE* stream_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    cl_spinlock_acquire(&wjh_api_spinlock_s);

    WJH_CHECK_INITIALIZED(wjh_init_done_g);
    WJH_CHECK_NULL_PTR(stream_p, stream_p);

    fprintf(stream_p, "######## Init params #########\n");
    fprintf(stream_p,
            "force\t\t: %d \nmax_bw_percent\t: %d \nconf_xml_path\t: %s \ndbg_file_path\t: %s \ningress_info_type\t: %s \n",
            wjh_init_params_g.force,
            wjh_init_params_g.max_bandwidth_percent,
            wjh_init_params_g.conf_xml_path,
            wjh_init_params_g.debug_fs_path,
            wjh_init_params_g.ingress_info_type == WJH_INGRESS_INFO_TYPE_LOGPORT ? "log_port" : "if_index");


    wjh_db_dbg_generate_dump(stream_p);

out:
    cl_spinlock_release(&wjh_api_spinlock_s);
    return err;
}
