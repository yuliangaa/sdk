/*
 * Copyright © 2001-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_CALLBACKS_SDK_H_
#define WJH_CALLBACKS_SDK_H_

#include "wjh_callbacks.h"
#include "wjh_sdk.h"

static wjh_driver_specific_callback_t wjh_sdk_callbacks = {
    .wjh_init_cb = wjh_init_sdk,
    .wjh_deinit_cb = wjh_deinit_sdk,
    .wjh_policer_create_cb = wjh_policer_create_sdk,
    .wjh_policer_destroy_cb = wjh_policer_destroy_sdk,
    .wjh_user_channel_validate_cb = wjh_user_channel_validate_sdk,
    .wjh_user_channel_create_cb = wjh_user_channel_create_sdk,
    .wjh_user_channel_destroy_cb = wjh_user_channel_destroy_sdk,
    .wjh_user_channel_flush_cb = wjh_user_channel_flush_sdk,
    .wjh_drop_reason_group_validate_cb = wjh_drop_reason_group_validate_sdk,
    .wjh_drop_reason_group_init_cb = wjh_drop_reason_group_init_sdk,
    .wjh_drop_reason_group_deinit_cb = wjh_drop_reason_group_deinit_sdk,
    .wjh_drop_reason_group_bind_cb = wjh_drop_reason_group_bind_sdk,
    .wjh_drop_reason_group_unbind_cb = wjh_drop_reason_group_unbind_sdk,
    .wjh_drop_reason_group_enable_cb = wjh_drop_reason_group_enable_sdk,
    .wjh_drop_reason_group_disable_cb = wjh_drop_reason_group_disable_sdk,
    .wjh_drop_reason_group_update_cb = wjh_drop_reason_group_update_sdk,
    .wjh_counter_dropped_packets_get_cb = wjh_counter_dropped_packets_get_sdk,
    .wjh_get_hw_port_cb = wjh_get_hw_port_sdk,
    .wjh_user_channel_tac_set_cb = wjh_user_channel_tac_set_sdk,
#ifdef WJH_EBPF_PRESENT
    .wjh_filter_rules_validate_cb = wjh_filter_rules_validate_sdk,
    .wjh_filter_create_cb = wjh_filter_create_sdk,
    .wjh_filter_destroy_cb = wjh_filter_destroy_sdk,
    .wjh_filter_rule_add_cb = wjh_filter_rule_add_sdk,
    .wjh_filter_rule_remove_cb = wjh_filter_rule_remove_sdk,
    .wjh_filter_bind_channel_cb = wjh_filter_bind_channel_sdk,
    .wjh_filter_unbind_channel_cb = wjh_filter_unbind_channel_sdk,
    .wjh_filter_rule_counter_get_cb = wjh_filter_rule_counter_get_sdk,
#endif
    .wjh_resources_pre_init_clean_up_cb = wjh_resources_pre_init_clean_up_sdk,
    .wjh_resources_post_init_clean_up_cb = wjh_resources_post_init_clean_up_sdk,
    .wjh_polling_thread_buf_create_cb = wjh_polling_thread_buf_create_sdk,
    .wjh_polling_thread_buf_destroy_cb = wjh_polling_thread_buf_destroy_sdk,
    .wjh_user_channel_process_cb = wjh_user_channel_process_sdk,
    .wjh_user_channel_fd_get_cb = wjh_user_channel_fd_get_sdk,
    .wjh_get_chip_type_cb = wjh_get_chip_type_sdk,
    .wjh_validate_shm_cb = wjh_validate_shm_sdk,
    .wjh_update_shm_cb = wjh_update_shm_sdk,
    .wjh_user_channel_timestamp_source_set_cb = wjh_user_channel_timestamp_source_set_sdk,
#ifdef WJH_EBPF_PRESENT
    .wjh_set_debugfs_path_cb = wjh_set_debugfs_path_sdk,
    .wjh_ebpf_prepare_cb = wjh_ebpf_prepare_sdk,
    .wjh_ebpf_cleanup_cb = wjh_ebpf_cleanup_sdk,
    .wjh_aggregation_set_monitor_rdq_trace_points_cb = wjh_aggregation_set_monitor_rdq_trace_points_sdk,
#endif
};

#endif /* WJH_CALLBACKS_SDK_H_ */
