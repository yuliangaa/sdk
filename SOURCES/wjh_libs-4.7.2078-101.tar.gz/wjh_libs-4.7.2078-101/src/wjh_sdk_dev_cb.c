/*
 * Copyright © 2001-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <stdio.h>
#include <errno.h>
#include "sx/sdk/sx_lib_adviser.h"
#include "sx/sdk/sx_api_span.h"
#include "sx/sdk/sx_api_port.h"
#include "sx/sdk/sx_api_cos.h"
#include <sx/sxd/sxd_access_register.h>
#include "wjh_sdk_dev_cb.h"
#include "wjh_sdk.h"
#include "wjh_db.h"
#include "wjh_log.h"
#include "wjh_kernel_user.h"
#include "sx/sdk/sx_api_acl.h"
#include "sx/sdk/sx_lib_flex_acl.h"
#include "sx/sdk/sx_api_host_ifc.h"
#include "sx/sdk/sx_api_policer.h"

#define WJH_COS_PORT_ETS_TC_MIN                        SX_COS_TC_GROUP_ID_0
#define WJH_COS_PORT_MC_AWARE_ETS_TC_MAX               SX_COS_TC_GROUP_ID_7       /* COS_MC_AWARE_MAX_TC */
#define WJH_COS_PORT_NON_MC_AWARE_ETS_TC_MAX           SX_COS_TC_GROUP_ID_MAX       /*SX_COS_EGR_TC_MAX_E*/
#define WJH_BUFFER_DROP_TRUNCATE_DEFAULT_SIZE          (64)
#define WJH_BUFFER_DROP_TRAP_PROBABILITY_DEFAULT_VALUE (128)
#define WJH_ROCE_DROP_REGION_SIZE                      (70)
#define WJH_COS_PORT_PRIO_MAX                          (14)
#define WJH_ROCE_UDP_PORT                              (4791)
#define WJH_NVME_UDP_PORT                              (4420)
#define WJH_ROCE_BTH_CNP_OPCODE                        (129)
#define WJH_POLICER_BURST_SIZE_MIN_BYTES_SPC           (4)
#define WJH_POLICER_BURST_SIZE_MAX_BYTES_SPC           (25)
#define WJH_POLICER_BURST_SIZE_MIN_BYTES_SPC2          (4)
#define WJH_POLICER_BURST_SIZE_MAX_BYTES_SPC2          (26)
#define WJH_POLICER_INFORMATION_RATE_MAX_BYTES         (2000000)

extern wjh_init_param_t wjh_init_params_g;
static boolean_t        wjh_buffer_drop_spc2_cpu_mirror_mode_en = FALSE;
static wjh_status_t __wjh_roce_rule_set(sx_api_handle_t      handle,
                                        wjh_roce_drop_db_t  *db_p,
                                        wjh_drop_reason_id_e drop_reason,
                                        sx_acl_rule_offset_t offset_start,
                                        boolean_t            trap);

wjh_status_t wjh_buffer_drop_sdk_span_init_spc(sx_api_handle_t                     sx_api_handle_s,
                                               const wjh_drop_reason_group_attr_t *attr_p,
                                               const wjh_policer_attrs_t          *policer_attrs_p)
{
    wjh_status_t             err = WJH_STATUS_SUCCESS;
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    sx_span_session_params_t span_session_params;
    wjh_buffer_drop_db_t    *db_p = NULL;

    UNUSED_PARAM(policer_attrs_p);

    wjh_db_buffer_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    db_p->recirculation_port = attr_p->attr.buffer_drop.basic_attr.recirculation_port;

    memset(&span_session_params, 0, sizeof(span_session_params));
    span_session_params.span_type = SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1;
    span_session_params.truncate = TRUE;
    span_session_params.truncate_size = (attr_p->attr.buffer_drop.basic_attr.truncate_size == 0) ?
                                        WJH_BUFFER_DROP_TRUNCATE_DEFAULT_SIZE : attr_p->attr.buffer_drop.basic_attr.
                                        truncate_size;
    span_session_params.span_type_format.remote_eth_l2_type1.qos_mode = SX_SPAN_QOS_MAINTAIN;
    span_session_params.version = SX_SPAN_MIRROR_HEADER_VERSION_1;

    sx_status = sx_api_span_session_set(sx_api_handle_s,
                                        SX_ACCESS_CMD_CREATE,
                                        &span_session_params,
                                        &db_p->span_session_id);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to create a span session, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_buffer_drop_sdk_span_deinit_spc(sx_api_handle_t sx_api_handle_s)
{
    wjh_status_t             err = WJH_STATUS_SUCCESS;
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    sx_span_session_params_t span_session_params;
    wjh_buffer_drop_db_t    *db_p = NULL;
    boolean_t                is_db_valid = TRUE;

    is_db_valid = wjh_is_reason_group_db_inited(WJH_DROP_REASON_GROUP_BUFFER_E);
    if (is_db_valid == FALSE) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    wjh_db_buffer_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    sx_status = sx_api_span_session_set(sx_api_handle_s,
                                        SX_ACCESS_CMD_DESTROY,
                                        &span_session_params,
                                        &db_p->span_session_id);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to destroy the span session, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }


out:
    return err;
}

wjh_status_t wjh_buffer_drop_sdk_adviser_port_event_spc(sx_api_handle_t sx_api_handle_s,
                                                        void           *event,
                                                        uint8_t         reason_bits)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    sx_access_cmd_t                 cmd;
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_buffer_drop_db_t           *db_p = NULL;
    wjh_drop_reason_group_record_t *drop_reason_db_p;
    sx_span_mirror_bind_key_t       mirror_key;
    sx_span_mirror_bind_attr_t      mirror_attr;
    sx_lib_adviser_event_info_t    *event_info_p = (sx_lib_adviser_event_info_t*)event;
    sx_lib_adviser_event_info_t     event_info;
    boolean_t                       is_db_valid = TRUE;
    sx_status_t                     rb_err = SX_STATUS_SUCCESS;
    boolean_t                       span_mirror_bound = FALSE;

    event_info = *event_info_p;

    is_db_valid = wjh_is_reason_group_db_inited(WJH_DROP_REASON_GROUP_BUFFER_E);
    if (is_db_valid == FALSE) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    wjh_db_buffer_drop_get(&db_p);
    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_BUFFER_E,
                                 &drop_reason_db_p);

    if ((event_info.type != SX_LIB_ADVISER_PORT_ADDED_E) &&
        (event_info.type != SX_LIB_ADVISER_PORT_DELETED_E)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wrong adviser type %s, err: %s\n",
                    sx_lib_adviser_event_type_str(event_info.type), sx_status_str(sx_status));
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(event_info.info.port_added_deleted.log_port) != SX_PORT_TYPE_NETWORK) {
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (WJH_BUFFER_DROP_REASON_CHECK(reason_bits, WJH_DROP_REASON_ID_TAIL_DROP_E)) {
        cmd = (event_info.type == SX_LIB_ADVISER_PORT_ADDED_E) ? SX_ACCESS_CMD_BIND : SX_ACCESS_CMD_UNBIND;
        mirror_key.type = SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E;
        mirror_key.key.ing_sb_drop.log_port = event_info.info.port_added_deleted.log_port;
        mirror_attr.rate = 1;
        mirror_attr.span_session_id = db_p->span_session_id;
        sx_status = sx_api_span_mirror_bind_set(sx_api_handle_s,
                                                cmd,
                                                &mirror_key,
                                                &mirror_attr);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to bind port 0x%x to shared buffer drop mirroring, err: %s\n",
                        mirror_key.key.ing_sb_drop.log_port, sx_status_str(sx_status));
            goto out;
        }
        if (cmd == SX_ACCESS_CMD_BIND) {
            span_mirror_bound = TRUE;
        }
    }

    if (WJH_BUFFER_DROP_REASON_CHECK(reason_bits, WJH_DROP_REASON_ID_WRED_E)) {
        cmd = (event_info.type == SX_LIB_ADVISER_PORT_ADDED_E) ? SX_ACCESS_CMD_ADD : SX_ACCESS_CMD_DELETE;
        sx_status = sx_api_cos_redecn_mirroring_set(sx_api_handle_s,
                                                    cmd,
                                                    event_info.info.port_added_deleted.log_port,
                                                    db_p->span_session_id);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to bind port 0x%x to WRED discard mirroring, err: %s\n",
                        event_info.info.port_added_deleted.log_port, sx_status_str(sx_status));
            goto out;
        }
    }

out:
    if (WJH_CHECK_FAIL(err)) {
        if (span_mirror_bound) {
            rb_err = sx_api_span_mirror_bind_set(sx_api_handle_s,
                                                 SX_ACCESS_CMD_UNBIND,
                                                 &mirror_key,
                                                 &mirror_attr);
            if (SX_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to unbind port 0x%x from shared buffer drop mirroring, err: %s\n",
                            mirror_key.key.ing_sb_drop.log_port, sx_status_str(rb_err));
            }
        }
    }

    return err;
}

wjh_status_t __wjh_buffer_drop_trap_id_set(sx_api_handle_t sx_api_handle_s, sx_trap_id_t trap_id, boolean_t is_set)
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    sx_status_t                  sdk_rc = SX_STATUS_SUCCESS;
    sxd_ctrl_pack_t              ctrl_pack;
    int                          sxd_err = SXD_STATUS_SUCCESS;
    struct ku_buffer_drop_params buffer_drop_params;
    sx_fd_t                      fd;
    boolean_t                    fd_opened = FALSE;

    memset(&ctrl_pack, 0, sizeof(ctrl_pack));
    memset(&buffer_drop_params, 0, sizeof(buffer_drop_params));
    memset(&fd, 0, sizeof(fd));

    sdk_rc = sx_api_host_ifc_open(sx_api_handle_s, &fd);
    if (SX_CHECK_FAIL(sdk_rc)) {
        WJH_LOG_ERR("Failed to open FD, error: %s\n", sx_status_str(sdk_rc));
        err = WJH_STATUS_ERROR;
        goto out;
    }
    fd_opened = TRUE;

    if (is_set) {
        buffer_drop_params.is_set = 1;
        buffer_drop_params.trap_id = trap_id;
    }

    ctrl_pack.cmd_body = (void*)&buffer_drop_params;
    ctrl_pack.ctrl_cmd = CTRL_CMD_BUFFER_DROP_PARAMS;
    sxd_err = sxd_ioctl(fd.driver_handle, &ctrl_pack);
    if (SXD_CHECK_FAIL(sxd_err)) {
        WJH_LOG_ERR("sxd_ioctl CTRL_CMD_BUFFER_DROP_PARAMS error %s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    if (fd_opened) {
        sdk_rc = sx_api_host_ifc_close(sx_api_handle_s, &fd);
        if (SX_CHECK_FAIL(sdk_rc)) {
            WJH_LOG_ERR("Failed to close FD, error: %s\n", sx_status_str(sdk_rc));
        }
    }

    return err;
}

/* starting with SPC -2 we can configure the CPU port as a mirror port.
 * There is no need to sacrifice a regular port as mirror port.
 * Therefore enabling buffer drop with no recirculation port will automatically select CPU port.
 * However, we can continue to use valid recirculation port and be backward compatible
 */
wjh_status_t wjh_buffer_drop_sdk_span_init_spc2(sx_api_handle_t                     sx_api_handle_s,
                                                const wjh_drop_reason_group_attr_t *attr_p,
                                                const wjh_policer_attrs_t          *policer_attrs_p)
{
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    wjh_status_t                    rollback_err = WJH_STATUS_SUCCESS;
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    sx_span_session_params_t        span_session_params;
    boolean_t                       session_created = FALSE;
    boolean_t                       session_policer_created = FALSE;
    boolean_t                       session_policer_bound = FALSE;
    boolean_t                       buffer_drop_trap_id_set = FALSE;
    wjh_buffer_drop_db_t           *db_p = NULL;
    wjh_drop_reason_group_record_t *drop_reason_db_p;
    sx_trap_id_t                    mirror_trap_id;
    wjh_trap_id_attr_t             *trap_id_attr_p = NULL;
    wjh_trap_id_attr_t             *default_trap_id_attr_p = NULL;
    sx_policer_attributes_t         policer_attr;

    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_BUFFER_E,
                                 &drop_reason_db_p);
    if (drop_reason_db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason group record is not valid\n");
        goto out;
    }

    wjh_db_buffer_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    db_p->sampling_rate = (attr_p->attr.buffer_drop.advanced_attr.trap_probability == 0) ?
                          WJH_BUFFER_DROP_TRAP_PROBABILITY_DEFAULT_VALUE :
                          attr_p->attr.buffer_drop.advanced_attr.trap_probability;
    /* on SPC-2 when user provides WJH_CPU_PORT_ID or WJH_INVALID_PORT_ID it will be considered
     * as enabling Mirror to CPU mode. Else, legacy mode will apply (using recirculation
     * port in loop-back mode)
     */
    if ((attr_p->attr.buffer_drop.basic_attr.recirculation_port == WJH_INVALID_PORT_ID) ||
        (attr_p->attr.buffer_drop.basic_attr.recirculation_port == WJH_CPU_PORT_ID)) {
        wjh_buffer_drop_spc2_cpu_mirror_mode_en = TRUE;
        /* set the CPU port as the recirculation port in the db */
        db_p->recirculation_port = WJH_CPU_PORT_ID;
    } else {
        db_p->recirculation_port = attr_p->attr.buffer_drop.basic_attr.recirculation_port;
    }

    /* Configure the span session */
    memset(&span_session_params, 0, sizeof(span_session_params));

    if (!wjh_buffer_drop_spc2_cpu_mirror_mode_en) {
        span_session_params.span_type = SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1;
        span_session_params.truncate = TRUE;
        span_session_params.truncate_size = (attr_p->attr.buffer_drop.basic_attr.truncate_size == 0) ?
                                            WJH_BUFFER_DROP_TRUNCATE_DEFAULT_SIZE : attr_p->attr.buffer_drop.basic_attr
                                            .
                                            truncate_size;
        span_session_params.version = SX_SPAN_MIRROR_HEADER_VERSION_2;
        span_session_params.span_type_format.remote_eth_l2_type1.qos_mode = SX_SPAN_QOS_MAINTAIN;
    } else {
        span_session_params.span_type = SX_SPAN_TYPE_LOCAL_ETH_TYPE1;
        span_session_params.truncate = FALSE; /* truncate size is reserved when sending to CPU */
        span_session_params.span_type_format.local_eth_type1.qos_mode = SX_SPAN_QOS_MAINTAIN;
    }


    sx_status = sx_api_span_session_set(sx_api_handle_s,
                                        SX_ACCESS_CMD_CREATE,
                                        &span_session_params,
                                        &db_p->span_session_id);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to create a span session, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }
    session_created = TRUE;

    if (wjh_buffer_drop_spc2_cpu_mirror_mode_en) {
        memset(&policer_attr, 0, sizeof(policer_attr));

        policer_attr.meter_type = SX_POLICER_METER_TRAFFIC;
        policer_attr.cbs = policer_attrs_p->burst_size;
        policer_attr.ebs = policer_attrs_p->burst_size;
        policer_attr.cir = policer_attrs_p->information_rate;
        policer_attr.yellow_action = SX_POLICER_ACTION_FORWARD_SET_YELLOW_COLOR;
        policer_attr.red_action = SX_POLICER_ACTION_DISCARD;
        policer_attr.eir = policer_attrs_p->information_rate;
        policer_attr.rate_type = SX_POLICER_RATE_TYPE_SINGLE_RATE_E;
        policer_attr.color_aware = 0;
        policer_attr.is_span_session_policer = 1;
        policer_attr.ir_units = SX_POLICER_IR_UNITS_10_POWER_6_E;

        sx_status =
            sx_api_policer_set(sx_api_handle_s, SX_ACCESS_CMD_CREATE, &policer_attr, &(db_p->span_session_policer_id));
        if (SX_CHECK_FAIL(sx_status)) {
            WJH_LOG_ERR("Failed to create policer, error: %s\n", sx_status_str(sx_status));
            err = WJH_STATUS_ERROR;
            goto rollback;
        }
        session_policer_created = TRUE;

        sx_status = sx_api_span_session_policer_bind_set(sx_api_handle_s, SX_ACCESS_CMD_BIND,
                                                         db_p->span_session_id, db_p->span_session_policer_id);
        if (SX_CHECK_FAIL(sx_status)) {
            WJH_LOG_ERR("Failed to bind policer to the span session, error: %s\n", sx_status_str(sx_status));
            err = WJH_STATUS_ERROR;
            goto rollback;
        }
        session_policer_bound = TRUE;

        /* we need to get the MIRROR_SESSION_TRAP_ID that the SDK configured
         * on creating the span session. We have to update the db with this Trap
         */
        sx_status = sx_api_span_session_trap_id_get(sx_api_handle_s,
                                                    db_p->span_session_id,
                                                    &mirror_trap_id);

        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to get the Mirror Trap for span session %u, err: %s\n",
                        db_p->span_session_id, sx_status_str(sx_status));
            goto rollback;
        }

        err = __wjh_buffer_drop_trap_id_set(sx_api_handle_s,
                                            mirror_trap_id,
                                            TRUE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to set buffer drop trap ID in driver, error: %d\n", err);
            goto rollback;
        }
        buffer_drop_trap_id_set = TRUE;

        /* We need to overwrite the default TRAP with the mirror trap and update the
         * trap attributes for the new trap*/
        wjh_db_trap_id_attr_get(drop_reason_db_p->trap_ids[0].trap_id, &default_trap_id_attr_p);
        drop_reason_db_p->trap_ids[0].trap_id = mirror_trap_id;

        wjh_db_trap_id_attr_get(drop_reason_db_p->trap_ids[0].trap_id, &trap_id_attr_p);
        memcpy(trap_id_attr_p, default_trap_id_attr_p, sizeof(wjh_trap_id_attr_t));
    }

rollback:
    if (err != WJH_STATUS_SUCCESS) {
        /* coverity[dead_error_condition] */
        if (buffer_drop_trap_id_set) {
            rollback_err = __wjh_buffer_drop_trap_id_set(sx_api_handle_s,
                                                         0,
                                                         FALSE);
            if (WJH_CHECK_FAIL(rollback_err)) {
                WJH_LOG_ERR("Failed to unset buffer drop trap ID in driver, error: %d\n", rollback_err);
            }
        }
        if (session_policer_bound == TRUE) {
            sx_status = sx_api_span_session_policer_bind_set(sx_api_handle_s, SX_ACCESS_CMD_UNBIND,
                                                             db_p->span_session_id, db_p->span_session_policer_id);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to unbind the policer from span session, err: %s\n", sx_status_str(sx_status));
            }
        }
        if (session_policer_created == TRUE) {
            sx_status =
                sx_api_policer_set(sx_api_handle_s, SX_ACCESS_CMD_DESTROY, NULL, &(db_p->span_session_policer_id));
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to destroy policer, error: %s\n", sx_status_str(sx_status));
            }
        }
        if (session_created == TRUE) {
            sx_status = sx_api_span_session_set(sx_api_handle_s,
                                                SX_ACCESS_CMD_DESTROY,
                                                &span_session_params,
                                                &db_p->span_session_id);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to destroy the span session, err: %s\n",
                            sx_status_str(sx_status));
            }
        }
    }

out:
    return err;
}

wjh_status_t wjh_buffer_drop_sdk_span_session_bind_unbind(sx_api_handle_t sx_api_handle_s, boolean_t bind)
{
    wjh_status_t               err = WJH_STATUS_SUCCESS;
    sx_status_t                sx_status = SX_STATUS_SUCCESS;
    boolean_t                  sb_drop_span_bind = FALSE;
    boolean_t                  wred_drop_span_bind = FALSE;
    boolean_t                  tc_cong_span_bind = FALSE;
    wjh_buffer_drop_db_t      *db_p = NULL;
    sx_span_mirror_bind_key_t  mirror_key = {0};
    sx_span_mirror_bind_attr_t mirror_attr;
    sx_access_cmd_t            cmd = bind ? SX_ACCESS_CMD_BIND : SX_ACCESS_CMD_UNBIND;

    wjh_db_buffer_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    /*Add the different trigger points*/
    if (!wjh_buffer_drop_spc2_cpu_mirror_mode_en) {
        mirror_attr.rate = 1;
    } else {
        mirror_attr.rate = db_p->sampling_rate;
    }
    mirror_attr.span_session_id = db_p->span_session_id;

    mirror_key.type = SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E;
    sx_status = sx_api_span_mirror_bind_set(sx_api_handle_s,
                                            cmd,
                                            &mirror_key,
                                            &mirror_attr);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to bind span session to shared buffer drop mirroring, err: %s. Lets rollback\n",
                    sx_status_str(sx_status));
        goto rollback;
    }

    if (bind) {
        sb_drop_span_bind = TRUE;
    }

    mirror_key.type = SX_SPAN_MIRROR_BIND_ING_WRED_E;
    sx_status = sx_api_span_mirror_bind_set(sx_api_handle_s,
                                            cmd,
                                            &mirror_key,
                                            &mirror_attr);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to bind span session to wred drop mirroring, err: %s. Lets rollback\n",
                    sx_status_str(sx_status));
        goto rollback;
    }
    if (bind) {
        wred_drop_span_bind = TRUE;
    }

    mirror_key.type = SX_SPAN_MIRROR_BIND_ING_TC_CONGESTION_E;
    sx_status = sx_api_span_mirror_bind_set(sx_api_handle_s,
                                            cmd,
                                            &mirror_key,
                                            &mirror_attr);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to bind span session to tc_cong drop mirroring, err: %s\n",
                    sx_status_str(sx_status));
        goto rollback;
    }

    if (bind) {
        tc_cong_span_bind = TRUE;
    }

    mirror_key.type = SX_SPAN_MIRROR_BIND_EGR_TC_LATENCY_E;
    sx_status = sx_api_span_mirror_bind_set(sx_api_handle_s,
                                            cmd,
                                            &mirror_key,
                                            &mirror_attr);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to bind span session to latency drop mirroring, err: %s\n",
                    sx_status_str(sx_status));
        goto rollback;
    }

rollback:
    if (err != WJH_STATUS_SUCCESS) {
        if (tc_cong_span_bind == TRUE) {
            mirror_key.type = SX_SPAN_MIRROR_BIND_ING_TC_CONGESTION_E;
            mirror_attr.rate = 1;
            mirror_attr.span_session_id = db_p->span_session_id;
            sx_status = sx_api_span_mirror_bind_set(sx_api_handle_s,
                                                    SX_ACCESS_CMD_UNBIND,
                                                    &mirror_key,
                                                    &mirror_attr);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to unbind span session to congestion drop mirroring, err: %s\n",
                            sx_status_str(sx_status));
            }
        }
        if (wred_drop_span_bind == TRUE) {
            mirror_key.type = SX_SPAN_MIRROR_BIND_ING_WRED_E;
            mirror_attr.rate = 1;
            mirror_attr.span_session_id = db_p->span_session_id;
            sx_status = sx_api_span_mirror_bind_set(sx_api_handle_s,
                                                    SX_ACCESS_CMD_UNBIND,
                                                    &mirror_key,
                                                    &mirror_attr);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to unbind span session to wred drop mirroring, err: %s\n",
                            sx_status_str(sx_status));
            }
        }

        if (sb_drop_span_bind == TRUE) {
            mirror_key.type = SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E;
            mirror_attr.rate = 1;
            mirror_attr.span_session_id = db_p->span_session_id;
            sx_status = sx_api_span_mirror_bind_set(sx_api_handle_s,
                                                    SX_ACCESS_CMD_UNBIND,
                                                    &mirror_key,
                                                    &mirror_attr);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to unbind span session to shared buffer drop mirroring, err: %s\n",
                            sx_status_str(sx_status));
            }
        }
    }

out:
    return err;
}

wjh_status_t wjh_buffer_drop_sdk_span_session_set(sx_api_handle_t sx_api_handle_s, boolean_t enable)
{
    wjh_status_t                   err = WJH_STATUS_SUCCESS;
    sx_status_t                    sx_status = SX_STATUS_SUCCESS;
    sx_span_analyzer_port_params_t span_analyzer_params;
    wjh_buffer_drop_db_t          *db_p = NULL;
    sx_access_cmd_t                cmd = enable ? SX_ACCESS_CMD_ADD : SX_ACCESS_CMD_DELETE;
    sx_status_t                    rb_err = SX_STATUS_SUCCESS;
    boolean_t                      analyzer_set = FALSE;

    wjh_db_buffer_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    if (enable) {
        memset(&span_analyzer_params, 0, sizeof(span_analyzer_params));
        span_analyzer_params.cng_mng = SX_SPAN_CNG_MNG_DISCARD;
        sx_status = sx_api_span_analyzer_set(sx_api_handle_s,
                                             cmd,
                                             db_p->recirculation_port,
                                             &span_analyzer_params,
                                             db_p->span_session_id);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set the analyzer port to the span session, err: %s.\n",
                        sx_status_str(sx_status));
            goto out;
        }
        analyzer_set = TRUE;

        sx_status = sx_api_span_session_state_set(sx_api_handle_s,
                                                  db_p->span_session_id,
                                                  enable);
        if (SX_CHECK_FAIL(sx_status)) {
            WJH_LOG_ERR("Failed to enable span session admin state for buffer drop. Error: %s.\n",
                        sx_status_str(sx_status));
            err = WJH_STATUS_ERROR;
            goto out;
        }
    } else {
        sx_status = sx_api_span_session_state_set(sx_api_handle_s,
                                                  db_p->span_session_id,
                                                  enable);
        if (SX_CHECK_FAIL(sx_status)) {
            WJH_LOG_ERR("Failed to disable span session admin state for buffer drop. Error: %s.\n",
                        sx_status_str(sx_status));
            err = WJH_STATUS_ERROR;
            goto out;
        }

        memset(&span_analyzer_params, 0, sizeof(span_analyzer_params));
        span_analyzer_params.cng_mng = SX_SPAN_CNG_MNG_DISCARD;
        sx_status = sx_api_span_analyzer_set(sx_api_handle_s,
                                             cmd,
                                             db_p->recirculation_port,
                                             &span_analyzer_params,
                                             db_p->span_session_id);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to remove the analyzer port to the span session, err: %s.\n",
                        sx_status_str(sx_status));
            goto out;
        }
    }


out:
    if (WJH_CHECK_FAIL(err)) {
        if (analyzer_set) {
            rb_err = sx_api_span_analyzer_set(sx_api_handle_s,
                                              SX_ACCESS_CMD_DELETE,
                                              db_p->recirculation_port,
                                              &span_analyzer_params,
                                              db_p->span_session_id);
            if (SX_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to remove the analyzer port from the span session, err: %s.\n",
                            sx_status_str(rb_err));
            }
        }
    }

    return err;
}

wjh_status_t wjh_buffer_drop_sdk_span_deinit_spc2(sx_api_handle_t sx_api_handle_s)
{
    wjh_status_t             err = WJH_STATUS_SUCCESS;
    sx_status_t              sx_status = SX_STATUS_SUCCESS;
    sx_span_session_params_t span_session_params;
    wjh_buffer_drop_db_t    *db_p = NULL;
    boolean_t                is_db_valid = TRUE;

    is_db_valid = wjh_is_reason_group_db_inited(WJH_DROP_REASON_GROUP_BUFFER_E);
    if (is_db_valid == FALSE) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    wjh_db_buffer_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    if (wjh_buffer_drop_spc2_cpu_mirror_mode_en) {
        sx_status = sx_api_span_session_policer_bind_set(sx_api_handle_s, SX_ACCESS_CMD_UNBIND,
                                                         db_p->span_session_id, db_p->span_session_policer_id);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to unbind the policer from span session, err: %s\n", sx_status_str(sx_status));
            goto out;
        }

        sx_status = sx_api_policer_set(sx_api_handle_s, SX_ACCESS_CMD_DESTROY, NULL, &(db_p->span_session_policer_id));
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to destroy policer, error: %s\n", sx_status_str(sx_status));
            goto out;
        }

        err = __wjh_buffer_drop_trap_id_set(sx_api_handle_s,
                                            0,
                                            FALSE);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to unset buffer drop trap ID in driver, error: %d\n", err);
            goto out;
        }
    }

    sx_status = sx_api_span_session_set(sx_api_handle_s,
                                        SX_ACCESS_CMD_DESTROY,
                                        &span_session_params,
                                        &db_p->span_session_id);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to destroy the span session, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }


out:
    wjh_buffer_drop_spc2_cpu_mirror_mode_en = FALSE;
    return err;
}

wjh_status_t wjh_buffer_drop_sdk_mirror_to_cpu_mode_set(boolean_t mode)
{
    wjh_buffer_drop_spc2_cpu_mirror_mode_en = mode;
    return WJH_STATUS_SUCCESS;
}

wjh_status_t wjh_buffer_drop_sdk_adviser_port_event_spc2(sx_api_handle_t sx_api_handle_s,
                                                         void           *event,
                                                         uint8_t         reason_bits)
{
    sx_status_t                     sx_status = SX_STATUS_SUCCESS;
    sx_access_cmd_t                 cmd;
    wjh_buffer_drop_db_t           *db_p = NULL;
    wjh_drop_reason_group_record_t *drop_reason_db_p;
    wjh_status_t                    err = WJH_STATUS_SUCCESS;
    sx_span_mirror_enable_object_t  enable_object;
    sx_span_mirror_enable_attr_t    enable_attr;
    int                             tc_min = WJH_COS_PORT_ETS_TC_MIN;
    int                             tc_max = WJH_COS_PORT_NON_MC_AWARE_ETS_TC_MAX - 1;
    int                             idx = 0;
    sx_lib_adviser_event_info_t    *event_info_p = (sx_lib_adviser_event_info_t*)event;
    sx_lib_adviser_event_info_t     event_info;
    boolean_t                       is_db_valid = TRUE;
    sx_status_t                     rb_err = SX_STATUS_SUCCESS;
    int                             shared_buffer_uc_enabled_idx = tc_min - 1;
    boolean_t                       shared_buffer_mc_enabled = FALSE;
    int                             wred_enabled_idx = tc_min - 1;
    int                             tc_congestion_enabled_idx = tc_min - 1;
    int                             tc_latency_enabled_idx = tc_min - 1;

    event_info = *event_info_p;

    is_db_valid = wjh_is_reason_group_db_inited(WJH_DROP_REASON_GROUP_BUFFER_E);
    if (is_db_valid == FALSE) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }
    wjh_db_buffer_drop_get(&db_p);
    wjh_db_drop_reason_group_get(WJH_DROP_REASON_GROUP_BUFFER_E,
                                 &drop_reason_db_p);

    if ((event_info.type != SX_LIB_ADVISER_PORT_ADDED_E) &&
        (event_info.type != SX_LIB_ADVISER_PORT_DELETED_E)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wrong adviser type %s, err: %s\n",
                    sx_lib_adviser_event_type_str(event_info.type), sx_status_str(sx_status));
        goto out;
    }

    if (SX_PORT_TYPE_ID_GET(event_info.info.port_added_deleted.log_port) != SX_PORT_TYPE_NETWORK) {
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (WJH_BUFFER_DROP_REASON_CHECK(reason_bits, WJH_DROP_REASON_ID_TAIL_DROP_E)) {
        WJH_MEM_CLR(enable_object);
        WJH_MEM_CLR(enable_attr);
        cmd = (event_info.type == SX_LIB_ADVISER_PORT_ADDED_E) ? SX_ACCESS_CMD_SET : SX_ACCESS_CMD_DELETE;
        enable_object.type = SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_UC_E;
        enable_object.object.ing_sb_drop_uc.port = event_info.info.port_added_deleted.log_port;
        for (idx = tc_min; idx <= tc_max; idx++) {
            enable_object.object.ing_sb_drop_uc.tc = idx;
            sx_status = sx_api_span_mirror_enable_set(sx_api_handle_s, cmd, &enable_object, &enable_attr);
            if (SX_CHECK_FAIL(sx_status)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to enable UC shared buffer drop for port 0x%x, err: %s\n",
                            enable_object.object.ing_sb_drop_uc.port, sx_status_str(sx_status));
                goto out;
            }
            if (cmd == SX_ACCESS_CMD_SET) {
                shared_buffer_uc_enabled_idx++;
            }
        }

        WJH_MEM_CLR(enable_object);
        WJH_MEM_CLR(enable_attr);
        enable_object.type = SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_MC_E;
        enable_object.object.ing_sb_drop_mc.port = event_info.info.port_added_deleted.log_port;
        sx_status = sx_api_span_mirror_enable_set(sx_api_handle_s, cmd, &enable_object, &enable_attr);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to enable MC shared buffer drop for port 0x%x, err: %s\n",
                        enable_object.object.ing_sb_drop_mc.port, sx_status_str(sx_status));
            goto out;
        }
        if (cmd == SX_ACCESS_CMD_SET) {
            shared_buffer_mc_enabled = TRUE;
        }
    }

    if (WJH_BUFFER_DROP_REASON_CHECK(reason_bits, WJH_DROP_REASON_ID_WRED_E)) {
        WJH_MEM_CLR(enable_object);
        WJH_MEM_CLR(enable_attr);
        cmd = (event_info.type == SX_LIB_ADVISER_PORT_ADDED_E) ? SX_ACCESS_CMD_SET : SX_ACCESS_CMD_DELETE;
        enable_object.type = SX_SPAN_MIRROR_ENABLE_ING_WRED_E;
        enable_object.object.ing_wred.port = event_info.info.port_added_deleted.log_port;
        for (idx = tc_min; idx <= tc_max; idx++) {
            enable_object.object.ing_wred.tc = idx;
            sx_status = sx_api_span_mirror_enable_set(sx_api_handle_s, cmd, &enable_object, &enable_attr);
            if (SX_CHECK_FAIL(sx_status)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to enable wred drop for port 0x%x, err: %s\n",
                            enable_object.object.ing_wred.port, sx_status_str(sx_status));
                goto out;
            }
            if (cmd == SX_ACCESS_CMD_SET) {
                wred_enabled_idx++;
            }
        }
    }


    if (WJH_BUFFER_DROP_REASON_CHECK(reason_bits, WJH_DROP_REASON_ID_ING_TC_CONGESTION)) {
        WJH_MEM_CLR(enable_object);
        WJH_MEM_CLR(enable_attr);
        cmd = (event_info.type == SX_LIB_ADVISER_PORT_ADDED_E) ? SX_ACCESS_CMD_SET : SX_ACCESS_CMD_DELETE;
        enable_object.type = SX_SPAN_MIRROR_ENABLE_ING_TC_THRESHOLD_E;
        enable_object.object.ing_tc_threshold.port = event_info.info.port_added_deleted.log_port;
        for (idx = tc_min; idx <= tc_max; idx++) {
            enable_object.object.ing_tc_threshold.tc = idx;
            sx_status = sx_api_span_mirror_enable_set(sx_api_handle_s, cmd, &enable_object, &enable_attr);
            if (SX_CHECK_FAIL(sx_status)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to enable ing_tc threshold for port 0x%x, err: %s\n",
                            enable_object.object.ing_tc_threshold.port, sx_status_str(sx_status));
                goto out;
            }
            if (cmd == SX_ACCESS_CMD_SET) {
                tc_congestion_enabled_idx++;
            }
        }
    }
    if (WJH_BUFFER_DROP_REASON_CHECK(reason_bits, WJH_DROP_REASON_ID_EGR_TC_LATENCY)) {
        WJH_MEM_CLR(enable_object);
        WJH_MEM_CLR(enable_attr);
        cmd = (event_info.type == SX_LIB_ADVISER_PORT_ADDED_E) ? SX_ACCESS_CMD_SET : SX_ACCESS_CMD_DELETE;
        enable_object.type = SX_SPAN_MIRROR_ENABLE_EGR_TC_LATENCY_E;
        enable_object.object.egr_latency.port = event_info.info.port_added_deleted.log_port;
        for (idx = tc_min; idx <= tc_max; idx++) {
            enable_object.object.egr_latency.tc = idx;
            sx_status = sx_api_span_mirror_enable_set(sx_api_handle_s, cmd, &enable_object, &enable_attr);
            if (SX_CHECK_FAIL(sx_status)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to enable Eg TC latency Trigger for port 0x%x, err: %s\n",
                            enable_object.object.egr_latency.port, sx_status_str(sx_status));
                goto out;
            }
            if (cmd == SX_ACCESS_CMD_SET) {
                tc_latency_enabled_idx++;
            }
        }
    }

out:
    if (WJH_CHECK_FAIL(err)) {
        WJH_MEM_CLR(enable_object);
        WJH_MEM_CLR(enable_attr);
        enable_object.type = SX_SPAN_MIRROR_ENABLE_EGR_TC_LATENCY_E;
        enable_object.object.egr_latency.port = event_info.info.port_added_deleted.log_port;
        for (idx = tc_min; idx <= tc_latency_enabled_idx; idx++) {
            enable_object.object.egr_latency.tc = (sx_cos_traffic_class_t)idx;
            rb_err =
                sx_api_span_mirror_enable_set(sx_api_handle_s, SX_ACCESS_CMD_DELETE, &enable_object, &enable_attr);
            if (SX_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to disable Eg TC latency Trigger for port 0x%x, err: %s\n",
                            enable_object.object.egr_latency.port, sx_status_str(rb_err));
            }
        }

        WJH_MEM_CLR(enable_object);
        WJH_MEM_CLR(enable_attr);
        enable_object.type = SX_SPAN_MIRROR_ENABLE_ING_TC_THRESHOLD_E;
        enable_object.object.ing_tc_threshold.port = event_info.info.port_added_deleted.log_port;
        for (idx = tc_min; idx <= tc_congestion_enabled_idx; idx++) {
            enable_object.object.ing_tc_threshold.tc = (sx_cos_traffic_class_t)idx;
            rb_err =
                sx_api_span_mirror_enable_set(sx_api_handle_s, SX_ACCESS_CMD_DELETE, &enable_object, &enable_attr);
            if (SX_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to disable ing_tc threshold for port 0x%x, err: %s\n",
                            enable_object.object.ing_tc_threshold.port, sx_status_str(rb_err));
            }
        }

        WJH_MEM_CLR(enable_object);
        WJH_MEM_CLR(enable_attr);
        enable_object.type = SX_SPAN_MIRROR_ENABLE_ING_WRED_E;
        enable_object.object.ing_wred.port = event_info.info.port_added_deleted.log_port;
        for (idx = tc_min; idx <= wred_enabled_idx; idx++) {
            enable_object.object.ing_wred.tc = (sx_cos_traffic_class_t)idx;
            rb_err =
                sx_api_span_mirror_enable_set(sx_api_handle_s, SX_ACCESS_CMD_DELETE, &enable_object, &enable_attr);
            if (SX_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to disable wred drop for port 0x%x, err: %s\n",
                            enable_object.object.ing_wred.port, sx_status_str(rb_err));
            }
        }

        if (shared_buffer_mc_enabled) {
            WJH_MEM_CLR(enable_object);
            WJH_MEM_CLR(enable_attr);
            enable_object.type = SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_MC_E;
            enable_object.object.ing_sb_drop_mc.port = event_info.info.port_added_deleted.log_port;
            rb_err =
                sx_api_span_mirror_enable_set(sx_api_handle_s, SX_ACCESS_CMD_DELETE, &enable_object, &enable_attr);
            if (SX_CHECK_FAIL(rb_err)) {
                WJH_LOG_ERR("Failed to disable MC shared buffer drop for port 0x%x, err: %s\n",
                            enable_object.object.ing_sb_drop_mc.port, sx_status_str(rb_err));
            }
        }

        WJH_MEM_CLR(enable_object);
        WJH_MEM_CLR(enable_attr);
        enable_object.type = SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_UC_E;
        enable_object.object.ing_sb_drop_uc.port = event_info.info.port_added_deleted.log_port;
        for (idx = tc_min; idx <= shared_buffer_uc_enabled_idx; idx++) {
            enable_object.object.ing_sb_drop_uc.tc = (sx_cos_traffic_class_t)idx;
            rb_err =
                sx_api_span_mirror_enable_set(sx_api_handle_s, SX_ACCESS_CMD_DELETE, &enable_object, &enable_attr);
            if (SX_CHECK_FAIL(rb_err)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to disable UC shared buffer drop for port 0x%x, err: %s\n",
                            enable_object.object.ing_sb_drop_uc.port, sx_status_str(rb_err));
            }
        }
    }

    return err;
}
/**
 * We create 2 regions, ACLs and ACL groups.
 * Each region belongs to 1 ACL and ACL group.
 * The second ACL group is bound to the first ACL group.
 * In the first region, there's one rule, to catch everything and set the LAG hash to a random value.
 * In the second region, there are 2 rules:
 * the first one is catching packets according to the LAG hash value,
 * with probability defined by the user, and trapping it to the CPU.
 * The second one catches the rest and drops.
 * Resource consuming configuration can fail so a rollback is needed.
 */
/* wjh_buffer_drop_acl_config_cb */
wjh_status_t wjh_buffer_drop_acl_create_spc(sx_api_handle_t handle, const wjh_drop_reason_group_attr_t *attr_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    sx_status_t  sx_status = SX_STATUS_SUCCESS;
    uint32_t     acl_cnt = WJH_BUFFER_DROP_ACL_NUM, rule_cnt = WJH_BUFFER_DROP_RULE_NUM, i;
    sx_trap_id_t trap_id = (attr_p->attr.buffer_drop.advanced_attr.trap_id == 0) ?
                           WJH_BUFFER_DROP_TRAP_ID_DEFAULT_VALUE : attr_p->attr.buffer_drop.advanced_attr.trap_id;
    uint32_t trap_probability = (attr_p->attr.buffer_drop.advanced_attr.trap_probability == 0) ?
                                WJH_BUFFER_DROP_TRAP_PROBABILITY_DEFAULT_VALUE : attr_p->attr.buffer_drop.advanced_attr
                                .trap_probability;
    sx_acl_region_group_t region_group;
    boolean_t             region_created[acl_cnt], acl_created[acl_cnt], acl_group_created[acl_cnt],
                          rule_set[acl_cnt], key_handle_created[acl_cnt], rule_initialized[rule_cnt],
                          second_group_bound = FALSE;
    wjh_buffer_drop_db_t     *db_p = NULL;
    sx_acl_attributes_t       acl_attributes;
    sx_acl_key_t              rule_key[] = {FLEX_ACL_KEY_DMAC, FLEX_ACL_KEY_LAG_HASH};
    sx_acl_key_fields_t       key_fields[] = {
        {.dmac = {
             {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
         }
        }, {.lag_hash = 0},
        {.lag_hash = 0}
    };
    sx_acl_mask_fields_t      key_mask[] = {
        {.dmac = {
             {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
         }
        }, {.lag_hash = 0},
        {.lag_hash = 0}
    };
    sx_flex_acl_flex_action_t key_action[] = {
        {.type = SX_FLEX_ACL_ACTION_HASH, .fields =
         {.action_hash = {.command = SX_ACL_ACTION_HASH_COMMAND_RANDOM, .type = SX_ACL_ACTION_HASH_TYPE_LAG}
         }
        },
        {.type = SX_FLEX_ACL_ACTION_TRAP, .fields =
         {.action_trap = {.action = SX_ACL_TRAP_ACTION_TYPE_TRAP, .trap_id = trap_id}
         }
        },
        {.type = SX_FLEX_ACL_ACTION_FORWARD, .fields =
         {.action_forward = {.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_DISCARD}
         }
        }
    };

    memset(region_created, FALSE, sizeof(region_created));
    memset(acl_created, FALSE, sizeof(acl_created));
    memset(acl_group_created, FALSE, sizeof(acl_group_created));
    memset(key_handle_created, FALSE, sizeof(key_handle_created));
    memset(rule_set, FALSE, sizeof(rule_set));
    memset(rule_initialized, FALSE, sizeof(rule_initialized));
    memset(&acl_attributes, FALSE, sizeof(acl_attributes));

    wjh_db_buffer_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }
    db_p->rule_offset[0] = 0;
    db_p->rule_offset[1] = 0;
    db_p->rule_offset[2] = 1;
    db_p->rules_per_region[0] = 1;
    db_p->rules_per_region[1] = 2;

    /*
     * The mask is calculated by the trap probability the user set.
     * The mask will be the same for the second and the third rules
     *  */
    while (trap_probability > 1) {
        key_mask[1].lag_hash = (key_mask[1].lag_hash << 1) | 1;
        trap_probability = trap_probability / 2;
    }

    for (i = 0; i < acl_cnt; i++) {
        sx_status = sx_api_acl_flex_key_set(handle,
                                            SX_ACCESS_CMD_CREATE,
                                            &rule_key[i],
                                            1,
                                            &db_p->key_handle[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to create ACL flex keys, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        key_handle_created[i] = TRUE;

        sx_status = sx_api_acl_region_set(handle,
                                          SX_ACCESS_CMD_CREATE,
                                          db_p->key_handle[i],
                                          SX_ACL_ACTION_TYPE_BASIC,
                                          db_p->rules_per_region[i] + 1,
                                          &db_p->acl_region_list[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to create ACL region, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        region_created[i] = TRUE;

        region_group.acl_type = SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC;
        region_group.regions.acl_packet_agnostic.region = db_p->acl_region_list[i];
        sx_status = sx_api_acl_set(handle,
                                   SX_ACCESS_CMD_CREATE,
                                   SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                   SX_ACL_DIRECTION_INGRESS,
                                   &region_group,
                                   &db_p->acl_list[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to create ACL, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        acl_created[i] = TRUE;

        /* Disable acl drop monitoring for packets dropped by wjh buffer
         * acl due to low probability configuration. This is done
         * to avoid packets being trapped by acl monitoring that are
         * explicitly dropped by wjh buffer drop acl rules.
         */
        acl_attributes.disable_acl_drop_monitoring_trap = TRUE;
        sx_status = sx_api_acl_attributes_set(handle, SX_ACCESS_CMD_SET,
                                              db_p->acl_list[i], acl_attributes);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set ACL attribute, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        sx_status = sx_api_acl_group_set(handle,
                                         SX_ACCESS_CMD_CREATE,
                                         SX_ACL_DIRECTION_INGRESS,
                                         &db_p->acl_list[i],
                                         0,
                                         &db_p->acl_group_list[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to create ACL group, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        acl_group_created[i] = TRUE;

        sx_status = sx_api_acl_group_set(handle,
                                         SX_ACCESS_CMD_SET,
                                         SX_ACL_DIRECTION_INGRESS,
                                         &db_p->acl_list[i],
                                         1,
                                         &db_p->acl_group_list[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to create ACL group, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
    }

    for (i = 0; i < rule_cnt; i++) {
        /* 2nd rule is TRAP + DISCARD, so 2 actions are required */
        sx_status = sx_lib_flex_acl_rule_init((i == 0) ? db_p->key_handle[0] : db_p->key_handle[1],
                                              (i == 1) ? 2 : 1,
                                              &db_p->acl_rules[i]);

        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to initialize ACL rule struct, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }

        db_p->acl_rules[i].valid = 1;
        db_p->acl_rules[i].priority = 1;
        db_p->acl_rules[i].key_desc_count = 1;
        /* 2nd rule is TRAP + DISCARD, so 2 actions are required */
        db_p->acl_rules[i].action_count = (i == 1) ? 2 : 1;
        db_p->acl_rules[i].key_desc_list_p[0].key_id = (i == 0) ? rule_key[0] : rule_key[1];
        db_p->acl_rules[i].key_desc_list_p[0].key = key_fields[i];
        db_p->acl_rules[i].key_desc_list_p[0].mask = key_mask[i];
        db_p->acl_rules[i].action_list_p[0] = key_action[i];
        /* 2nd rule is TRAP + DISCARD, so 2nd action is DISCARD */
        if (i == 1) {
            db_p->acl_rules[i].action_list_p[1] = key_action[i + 1];
        }
        rule_initialized[i] = TRUE;
    }
    for (i = 0; i < acl_cnt; i++) {
        /* set the ACL Rules into the respective regions.
         * First we add 1 rule in the first region and the second time we add
         * 2 rules from the starting offset in the second region
         */
        sx_status = sx_api_acl_flex_rules_set(handle,
                                              SX_ACCESS_CMD_SET,
                                              db_p->acl_region_list[i],
                                              &db_p->rule_offset[i],
                                              &db_p->acl_rules[i],
                                              db_p->rules_per_region[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set ACL rule, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        rule_set[i] = TRUE;
    }


    sx_status = sx_api_acl_group_bind_set(handle,
                                          SX_ACCESS_CMD_BIND,
                                          db_p->acl_group_list[0],
                                          db_p->acl_group_list[1]);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to bind ACL group 1 after group 0, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }
    second_group_bound = TRUE;

    sx_status = sx_api_acl_port_bind_set(handle,
                                         SX_ACCESS_CMD_ADD,
                                         db_p->recirculation_port,
                                         db_p->acl_group_list[0]);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to bind ACL group to the analyzer port, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }
out:
    if (err != WJH_STATUS_SUCCESS) {
        if (second_group_bound == TRUE) {
            sx_status = sx_api_acl_group_bind_set(handle,
                                                  SX_ACCESS_CMD_UNBIND,
                                                  db_p->acl_group_list[0],
                                                  db_p->acl_group_list[1]);
            if (SX_CHECK_FAIL(sx_status)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to unbind ACL group 1 after group 0, err: %s\n",
                            sx_status_str(sx_status));
            }
        }
        for (i = 0; i < acl_cnt; i++) {
            if (rule_set[i] == TRUE) {
                sx_status = sx_api_acl_flex_rules_set(handle,
                                                      SX_ACCESS_CMD_DELETE,
                                                      db_p->acl_region_list[i],
                                                      &db_p->rule_offset[i],
                                                      &db_p->acl_rules[i],
                                                      db_p->rules_per_region[i]);
                if (SX_CHECK_FAIL(sx_status)) {
                    WJH_LOG_ERR("Failed to delete ACL rule, err: %s\n",
                                sx_status_str(sx_status));
                }
            }
        }
        for (i = 0; i < rule_cnt; i++) {
            sx_status = sx_lib_flex_acl_rule_deinit(&db_p->acl_rules[i]);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to deinit ACL rule, err: %s\n",
                            sx_status_str(sx_status));
            }
        }
        for (i = 0; i < acl_cnt; i++) {
            if (acl_group_created[i] == TRUE) {
                sx_status = sx_api_acl_group_set(handle,
                                                 SX_ACCESS_CMD_DESTROY,
                                                 SX_ACL_DIRECTION_INGRESS,
                                                 &db_p->acl_list[i],
                                                 1,
                                                 &db_p->acl_group_list[i]);
                if (SX_CHECK_FAIL(sx_status)) {
                    WJH_LOG_ERR("Failed to destroy ACL group, err: %s\n",
                                sx_status_str(sx_status));
                }
            }
            if (acl_created[i] == TRUE) {
                sx_status = sx_api_acl_set(handle,
                                           SX_ACCESS_CMD_DESTROY,
                                           SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                           SX_ACL_DIRECTION_INGRESS,
                                           &region_group,
                                           &db_p->acl_list[i]);
                if (SX_CHECK_FAIL(sx_status)) {
                    WJH_LOG_ERR("Failed to destroy ACL, err: %s\n",
                                sx_status_str(sx_status));
                }
            }
            if (region_created[i] == TRUE) {
                sx_status = sx_api_acl_region_set(handle,
                                                  SX_ACCESS_CMD_DESTROY,
                                                  db_p->key_handle[i],
                                                  SX_ACL_ACTION_TYPE_BASIC,
                                                  db_p->rules_per_region[i] + 1,
                                                  &db_p->acl_region_list[i]);
                if (SX_CHECK_FAIL(sx_status)) {
                    WJH_LOG_ERR("Failed to destroy ACL region, err: %s\n",
                                sx_status_str(sx_status));
                }
            }
            if (key_handle_created[i] == TRUE) {
                sx_status = sx_api_acl_flex_key_set(handle,
                                                    SX_ACCESS_CMD_DELETE,
                                                    &rule_key[i],
                                                    db_p->rules_per_region[i],
                                                    &db_p->key_handle[i]);
                if (SX_CHECK_FAIL(sx_status)) {
                    WJH_LOG_ERR("Failed to destroy ACL key handle, err: %s\n",
                                sx_status_str(sx_status));
                }
            }
        }
    }
    return err;
}


wjh_status_t wjh_buffer_drop_acl_destroy_spc(sx_api_handle_t handle)
{
    wjh_status_t          err = WJH_STATUS_SUCCESS;
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    uint32_t              acl_cnt = WJH_BUFFER_DROP_ACL_NUM, rule_cnt = WJH_BUFFER_DROP_RULE_NUM, i;
    sx_acl_region_group_t region_group;
    wjh_buffer_drop_db_t *db_p = NULL;
    boolean_t             is_db_valid = TRUE;

    is_db_valid = wjh_is_reason_group_db_inited(WJH_DROP_REASON_GROUP_BUFFER_E);
    if (is_db_valid == FALSE) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    wjh_db_buffer_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
        goto out;
    }

    sx_status = sx_api_acl_port_bind_set(handle,
                                         SX_ACCESS_CMD_DELETE,
                                         db_p->recirculation_port,
                                         db_p->acl_group_list[0]);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to unbind ACL group to the analyzer port, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }
    sx_status = sx_api_acl_group_bind_set(handle,
                                          SX_ACCESS_CMD_UNBIND,
                                          db_p->acl_group_list[0],
                                          db_p->acl_group_list[1]);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to unbind ACL group 1 after group 0, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    for (i = 0; i < acl_cnt; i++) {
        sx_status = sx_api_acl_flex_rules_set(handle,
                                              SX_ACCESS_CMD_DELETE,
                                              db_p->acl_region_list[i],
                                              &db_p->rule_offset[i],
                                              &db_p->acl_rules[i],
                                              db_p->rules_per_region[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to delete ACL rule, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
    }

    for (i = 0; i < rule_cnt; i++) {
        sx_status = sx_lib_flex_acl_rule_deinit(&db_p->acl_rules[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to deinitialize ACL rule struct, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
    }

    for (i = 0; i < acl_cnt; i++) {
        sx_status = sx_api_acl_group_set(handle,
                                         SX_ACCESS_CMD_DESTROY,
                                         SX_ACL_DIRECTION_INGRESS,
                                         &db_p->acl_list[i],
                                         1,
                                         &db_p->acl_group_list[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to destroy ACL group, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        sx_status = sx_api_acl_set(handle,
                                   SX_ACCESS_CMD_DESTROY,
                                   SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                   SX_ACL_DIRECTION_INGRESS,
                                   &region_group,
                                   &db_p->acl_list[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to destroy ACL, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        sx_status = sx_api_acl_region_set(handle,
                                          SX_ACCESS_CMD_DESTROY,
                                          db_p->key_handle[i],
                                          SX_ACL_ACTION_TYPE_BASIC,
                                          db_p->rules_per_region[i] + 1,
                                          &db_p->acl_region_list[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to destroy ACL region, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        sx_status = sx_api_acl_flex_key_set(handle,
                                            SX_ACCESS_CMD_DELETE,
                                            NULL,
                                            0,
                                            &db_p->key_handle[i]);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to destroy ACL flex keys, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
    }
out:
    return err;
}


wjh_status_t wjh_buffer_drop_acl_create_spc2(sx_api_handle_t handle, const wjh_drop_reason_group_attr_t *attr_p)
{
    if (!wjh_buffer_drop_spc2_cpu_mirror_mode_en) {
        /* we are operating in Legacy Mode on SPC-2. Simply do the same operations as SPC-1         */
        WJH_LOG_DBG("SPC-2 in Legacy Mode. Create ACLs.\n");
        return wjh_buffer_drop_acl_create_spc(handle, attr_p);
    } else {
        return WJH_STATUS_SUCCESS;
    }
}

wjh_status_t wjh_buffer_drop_acl_destroy_spc2(sx_api_handle_t handle)
{
    if (!wjh_buffer_drop_spc2_cpu_mirror_mode_en) {
        WJH_LOG_DBG("SPC-2 in Legacy Mode. Destroy ACLs.\n");
        return wjh_buffer_drop_acl_destroy_spc(handle);
    } else {
        return WJH_STATUS_SUCCESS;
    }
}

/* wjh_roce_drop_acl_create_cb */
wjh_status_t wjh_roce_drop_acl_create(sx_api_handle_t handle, const wjh_drop_reason_group_attr_t *attr_p)
{
    wjh_status_t          err = WJH_STATUS_SUCCESS;
    sx_status_t           sx_status = SX_STATUS_SUCCESS;
    wjh_roce_drop_db_t   *db_p = NULL;
    sx_acl_region_group_t region_group;
    sx_acl_key_t          key_list[] = {FLEX_ACL_KEY_L4_OK, FLEX_ACL_KEY_L4_TYPE, FLEX_ACL_KEY_L4_DESTINATION_PORT,
                                        FLEX_ACL_KEY_ROCE_BTH_OPCODE, FLEX_ACL_KEY_SWITCH_PRIO};
    uint32_t              key_count = sizeof(key_list) / sizeof(key_list[0]);
    boolean_t             region_created = FALSE, acl_created = FALSE, acl_group_created = FALSE,
                          key_handle_created = FALSE;

    UNUSED_PARAM(attr_p);

    wjh_db_roce_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh roce drop reason db is not valid\n");
        goto out;
    }

    memset(&db_p->roce_wrong_prio_rule, 0, sizeof(wjh_roce_drop_acl_rule_info_t));
    memset(&db_p->non_roce_rule, 0, sizeof(wjh_roce_drop_acl_rule_info_t));
    memset(&db_p->roce_flood_rule, 0, sizeof(wjh_roce_drop_acl_rule_info_t));

    sx_status = sx_api_acl_flex_key_set(handle,
                                        SX_ACCESS_CMD_CREATE,
                                        key_list,
                                        key_count,
                                        &db_p->key_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to create ACL flex keys for ingress RoCE, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }
    key_handle_created = TRUE;

    sx_status = sx_api_acl_region_set(handle,
                                      SX_ACCESS_CMD_CREATE,
                                      db_p->key_handle,
                                      SX_ACL_ACTION_TYPE_BASIC,
                                      WJH_ROCE_DROP_REGION_SIZE,
                                      &db_p->region_id);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to create ACL region for ingress RoCE, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }
    region_created = TRUE;

    memset(&region_group, 0, sizeof(region_group));
    region_group.acl_type = SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC;
    region_group.regions.acl_packet_agnostic.region = db_p->region_id;
    sx_status = sx_api_acl_set(handle,
                               SX_ACCESS_CMD_CREATE,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               SX_ACL_DIRECTION_INGRESS,
                               &region_group,
                               &db_p->acl_id);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to create ACL for ingress RoCE, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }
    acl_created = TRUE;

    sx_status = sx_api_acl_group_set(handle,
                                     SX_ACCESS_CMD_CREATE,
                                     SX_ACL_DIRECTION_INGRESS,
                                     &db_p->acl_id,
                                     0,
                                     &db_p->acl_group_id);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to create ACL group for ingress RoCE, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }
    acl_group_created = TRUE;

    sx_status = sx_api_acl_group_set(handle,
                                     SX_ACCESS_CMD_SET,
                                     SX_ACL_DIRECTION_INGRESS,
                                     &db_p->acl_id,
                                     1,
                                     &db_p->acl_group_id);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to create ACL group for ingress RoCE, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    err = __wjh_roce_rule_set(handle, db_p, WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY, 0, FALSE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to set roce rule.\n");
        goto out;
    }

    db_p->rules_count += db_p->roce_wrong_prio_rule.count;

    err = __wjh_roce_rule_set(handle, db_p, WJH_DROP_REASON_ID_NON_ROCE_ON_ROCE_PRIORITY, db_p->rules_count, FALSE);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to set roce rule.\n");
        goto out;
    }

    db_p->rules_count += db_p->non_roce_rule.count;

out:
    if (err != WJH_STATUS_SUCCESS) {
        if (acl_group_created == TRUE) {
            sx_status = sx_api_acl_group_set(handle,
                                             SX_ACCESS_CMD_DESTROY,
                                             SX_ACL_DIRECTION_INGRESS,
                                             NULL,
                                             0,
                                             &db_p->acl_group_id);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to destroy ACL group ingress RoCE rollback, err: %s\n",
                            sx_status_str(sx_status));
            }
        }
        if (acl_created == TRUE) {
            sx_status = sx_api_acl_set(handle,
                                       SX_ACCESS_CMD_DESTROY,
                                       SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                                       SX_ACL_DIRECTION_INGRESS,
                                       NULL,
                                       &db_p->acl_id);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to destroy ACL ingress RoCE rollback, err: %s\n",
                            sx_status_str(sx_status));
            }
        }
        if (region_created == TRUE) {
            sx_status = sx_api_acl_region_set(handle,
                                              SX_ACCESS_CMD_DESTROY,
                                              db_p->key_handle,
                                              SX_ACL_ACTION_TYPE_BASIC,
                                              0,
                                              &db_p->region_id);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to destroy ACL region ingress RoCE rollback, err: %s\n",
                            sx_status_str(sx_status));
            }
        }
        if (key_handle_created == TRUE) {
            sx_status = sx_api_acl_flex_key_set(handle,
                                                SX_ACCESS_CMD_DELETE,
                                                NULL,
                                                0,
                                                &db_p->key_handle);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to destroy ACL key handle ingress RoCE rollback, err: %s\n",
                            sx_status_str(sx_status));
            }
        }
    }

    return err;
}

wjh_status_t wjh_roce_drop_acl_destroy(sx_api_handle_t handle)
{
    wjh_status_t         err = WJH_STATUS_SUCCESS;
    sx_status_t          sx_status = SX_STATUS_SUCCESS;
    sx_acl_rule_offset_t offset = 0;
    wjh_roce_drop_db_t  *db_p = NULL;

    wjh_db_roce_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh roce drop reason db is not valid\n");
        goto out;
    }

    for (offset = 0; offset < db_p->rules_count; offset++) {
        sx_status = sx_api_acl_flex_rules_set(handle,
                                              SX_ACCESS_CMD_DELETE,
                                              db_p->region_id,
                                              &offset,
                                              NULL,
                                              1);
        if (SX_CHECK_FAIL(sx_status)) {
            WJH_LOG_ERR("Failed to delete ACL rule for ingress RoCE destroy, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
    }

    db_p->rules_count = 0;

    sx_status = sx_api_acl_group_set(handle,
                                     SX_ACCESS_CMD_DESTROY,
                                     SX_ACL_DIRECTION_INGRESS,
                                     NULL,
                                     0,
                                     &db_p->acl_group_id);
    if (SX_CHECK_FAIL(sx_status)) {
        WJH_LOG_ERR("Failed to destroy ACL group ingress RoCE destroy, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_acl_set(handle,
                               SX_ACCESS_CMD_DESTROY,
                               SX_ACL_TYPE_PACKET_TYPES_AGNOSTIC,
                               SX_ACL_DIRECTION_INGRESS,
                               NULL,
                               &db_p->acl_id);
    if (SX_CHECK_FAIL(sx_status)) {
        WJH_LOG_ERR("Failed to destroy ACL ingress RoCE destroy, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_acl_region_set(handle,
                                      SX_ACCESS_CMD_DESTROY,
                                      db_p->key_handle,
                                      SX_ACL_ACTION_TYPE_BASIC,
                                      0,
                                      &db_p->region_id);
    if (SX_CHECK_FAIL(sx_status)) {
        WJH_LOG_ERR("Failed to destroy ACL region ingress RoCE destroy, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    sx_status = sx_api_acl_flex_key_set(handle,
                                        SX_ACCESS_CMD_DELETE,
                                        NULL,
                                        0,
                                        &db_p->key_handle);
    if (SX_CHECK_FAIL(sx_status)) {
        WJH_LOG_ERR("Failed to destroy ACL key handle ingress RoCE destroy, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_roce_rule_set(sx_api_handle_t      handle,
                                        wjh_roce_drop_db_t  *db_p,
                                        wjh_drop_reason_id_e drop_reason,
                                        sx_acl_rule_offset_t offset_start,
                                        boolean_t            trap)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    sx_status_t             sx_status = SX_STATUS_SUCCESS;
    boolean_t               rule_allocated = FALSE;
    sx_flex_acl_flex_rule_t rule;
    sx_acl_rule_offset_t    offset = offset_start, i = 0;
    uint8_t                 switch_prio = 0;

    memset(&rule, 0, sizeof(sx_flex_acl_flex_rule_t));

    /* Allocate a rule info to be inserted */
    sx_status = sx_lib_flex_acl_rule_init(db_p->key_handle, 1, &rule);
    if (SX_CHECK_FAIL(sx_status)) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to initialize ACL rule struct for ingress RoCE, err: %s\n",
                    sx_status_str(sx_status));
        goto out;
    }

    rule_allocated = TRUE;

    rule.valid = 1;
    rule.action_count = 1;
    rule.key_desc_count = 5;
    rule.key_desc_list_p[0].key_id = FLEX_ACL_KEY_L4_OK;
    rule.key_desc_list_p[0].key.l4_ok = TRUE;
    rule.key_desc_list_p[0].mask.l4_ok = TRUE;
    rule.key_desc_list_p[1].key_id = FLEX_ACL_KEY_L4_TYPE;
    rule.key_desc_list_p[1].key.l4_type = SX_ACL_L4_TYPE_UDP;
    rule.key_desc_list_p[1].mask.l4_type = TRUE;
    rule.key_desc_list_p[2].key_id = FLEX_ACL_KEY_L4_DESTINATION_PORT;
    rule.key_desc_list_p[2].key.l4_destination_port = WJH_ROCE_UDP_PORT;
    rule.key_desc_list_p[2].mask.l4_destination_port = 0xFFFF;
    rule.key_desc_list_p[3].key_id = FLEX_ACL_KEY_SWITCH_PRIO;
    rule.key_desc_list_p[3].key.switch_prio = db_p->cnp_switch_prio;
    rule.key_desc_list_p[3].mask.switch_prio = TRUE;
    rule.key_desc_list_p[4].key_id = FLEX_ACL_KEY_ROCE_BTH_OPCODE;
    rule.key_desc_list_p[4].key.bth_opcode = WJH_ROCE_BTH_CNP_OPCODE;
    rule.key_desc_list_p[4].mask.bth_opcode = 0xFF;
    rule.action_list_p[0].type = SX_FLEX_ACL_ACTION_FORWARD;
    rule.action_list_p[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD;

    if (drop_reason == WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY) {
        db_p->roce_wrong_prio_rule.offset_start = offset;
        /* 1. Set rule to forward RoCE CNP traffic received on the correct priority */
        sx_status = sx_api_acl_flex_rules_set(handle, SX_ACCESS_CMD_SET, db_p->region_id, &offset, &rule, 1);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set ACL rule, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        offset++;

        /* 2. Set rules to trap RoCE CNP traffic received on the incorrect priority if reason enabled */
        if (trap) {
            rule.action_list_p[0].type = SX_FLEX_ACL_ACTION_TRAP_W_USER_ID;
            rule.action_list_p[0].fields.action_trap_w_user_id.action = SX_ACL_TRAP_ACTION_TYPE_TRAP;
            rule.action_list_p[0].fields.action_trap_w_user_id.trap_id = SX_TRAP_ID_ROCE_PRIO_MISMATCH;
        }

        for (switch_prio = 0; switch_prio <= WJH_COS_PORT_PRIO_MAX; switch_prio++) {
            if (switch_prio != db_p->cnp_switch_prio) {
                rule.key_desc_list_p[3].key.switch_prio = switch_prio;
                rule.action_list_p[0].fields.action_trap_w_user_id.user_id =
                    WJH_ROCE_ACL_USER_ID_CREATE(WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY, switch_prio);
            }
            sx_status = sx_api_acl_flex_rules_set(handle, SX_ACCESS_CMD_SET, db_p->region_id, &offset, &rule, 1);
            if (SX_CHECK_FAIL(sx_status)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to set ACL rule, err: %s\n",
                            sx_status_str(sx_status));
                goto out;
            }
            offset++;
        }

        /* Remove the BTH OPCODE from the key */
        rule.key_desc_count = 4;
        /* 3. Set rule to forward RoCE traffic received on the correct priority */
        rule.key_desc_list_p[2].key.l4_destination_port = WJH_ROCE_UDP_PORT;
        rule.key_desc_list_p[3].key.switch_prio = db_p->roce_switch_prio;
        rule.action_list_p[0].type = SX_FLEX_ACL_ACTION_FORWARD;
        rule.action_list_p[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD;

        sx_status = sx_api_acl_flex_rules_set(handle, SX_ACCESS_CMD_SET, db_p->region_id, &offset, &rule, 1);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set ACL rule for ingress RoCE, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        offset++;

        /* 4. Set rules to trap RoCE traffic received on the incorrect priority if reason enabled */
        if (trap) {
            rule.action_list_p[0].type = SX_FLEX_ACL_ACTION_TRAP_W_USER_ID;
            rule.action_list_p[0].fields.action_trap_w_user_id.action = SX_ACL_TRAP_ACTION_TYPE_TRAP;
            rule.action_list_p[0].fields.action_trap_w_user_id.trap_id = SX_TRAP_ID_ROCE_PRIO_MISMATCH;
        }

        for (switch_prio = 0; switch_prio <= WJH_COS_PORT_PRIO_MAX; switch_prio++) {
            if (switch_prio != db_p->roce_switch_prio) {
                rule.key_desc_list_p[3].key.switch_prio = switch_prio;
                rule.action_list_p[0].fields.action_trap_w_user_id.user_id =
                    WJH_ROCE_ACL_USER_ID_CREATE(WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY, switch_prio);
            }
            sx_status = sx_api_acl_flex_rules_set(handle, SX_ACCESS_CMD_SET, db_p->region_id, &offset, &rule, 1);
            if (SX_CHECK_FAIL(sx_status)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to set ACL rule for ingress RoCE, err: %s\n",
                            sx_status_str(sx_status));
                goto out;
            }
            offset++;
        }

        /* NOTE: Due to current hardware limitation we cannot differentiate CNP/Non-CNP traffic for NVME protocol.
         * Therefore we accept both priorities for all NVME traffic.
         */
        /* 5. Set rule to forward NVME traffic received on the CNP priority */
        rule.key_desc_list_p[2].key.l4_destination_port = WJH_NVME_UDP_PORT;
        rule.key_desc_list_p[3].key.switch_prio = db_p->cnp_switch_prio;
        rule.action_list_p[0].type = SX_FLEX_ACL_ACTION_FORWARD;
        rule.action_list_p[0].fields.action_forward.action = SX_ACL_TRAP_FORWARD_ACTION_TYPE_FORWARD;
        sx_status = sx_api_acl_flex_rules_set(handle, SX_ACCESS_CMD_SET, db_p->region_id, &offset, &rule, 1);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set ACL rule, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        offset++;

        /* 6. Set rule to forward NVME traffic received on the RoCE priority */
        rule.key_desc_list_p[2].key.l4_destination_port = WJH_NVME_UDP_PORT;
        rule.key_desc_list_p[3].key.switch_prio = db_p->roce_switch_prio;
        sx_status = sx_api_acl_flex_rules_set(handle, SX_ACCESS_CMD_SET, db_p->region_id, &offset, &rule, 1);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set ACL rule, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        offset++;

        /* 7. Set rules to trap NVME CNP traffic received on the incorrect priority if reason enabled */
        if (trap) {
            rule.action_list_p[0].type = SX_FLEX_ACL_ACTION_TRAP_W_USER_ID;
            rule.action_list_p[0].fields.action_trap_w_user_id.action = SX_ACL_TRAP_ACTION_TYPE_TRAP;
            rule.action_list_p[0].fields.action_trap_w_user_id.trap_id = SX_TRAP_ID_ROCE_PRIO_MISMATCH;
        }

        for (switch_prio = 0; switch_prio <= WJH_COS_PORT_PRIO_MAX; switch_prio++) {
            if ((switch_prio != db_p->cnp_switch_prio) &&
                (switch_prio != db_p->roce_switch_prio)) {
                rule.key_desc_list_p[3].key.switch_prio = switch_prio;
                rule.action_list_p[0].fields.action_trap_w_user_id.user_id =
                    WJH_ROCE_ACL_USER_ID_CREATE(WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY, switch_prio);
            }
            sx_status = sx_api_acl_flex_rules_set(handle, SX_ACCESS_CMD_SET, db_p->region_id, &offset, &rule, 1);
            if (SX_CHECK_FAIL(sx_status)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Failed to set ACL rule for ingress RoCE, err: %s\n",
                            sx_status_str(sx_status));
                goto out;
            }
            offset++;
        }
        db_p->roce_wrong_prio_rule.count = offset - offset_start;
    }

    if (drop_reason == WJH_DROP_REASON_ID_NON_ROCE_ON_ROCE_PRIORITY) {
        /* 8. Set rule to trap unexpected packets received on CNP priority (correct packets should have been handled by now)
         * if reason enabled */
        db_p->non_roce_rule.offset_start = offset;
        if (trap) {
            rule.action_list_p[0].type = SX_FLEX_ACL_ACTION_TRAP_W_USER_ID;
            rule.action_list_p[0].fields.action_trap_w_user_id.action = SX_ACL_TRAP_ACTION_TYPE_TRAP;
            rule.action_list_p[0].fields.action_trap_w_user_id.trap_id = SX_TRAP_ID_ROCE_PRIO_MISMATCH;
        }

        rule.action_list_p[0].fields.action_trap_w_user_id.user_id =
            WJH_ROCE_ACL_USER_ID_CREATE(WJH_DROP_REASON_ID_NON_ROCE_ON_ROCE_PRIORITY,
                                        db_p->cnp_switch_prio);
        /* Set to capture the CNP priority */
        rule.key_desc_count = 1;
        rule.key_desc_list_p[0].key_id = FLEX_ACL_KEY_SWITCH_PRIO;
        rule.key_desc_list_p[0].key.switch_prio = db_p->cnp_switch_prio;
        rule.key_desc_list_p[0].mask.switch_prio = TRUE;

        sx_status = sx_api_acl_flex_rules_set(handle, SX_ACCESS_CMD_SET, db_p->region_id, &offset, &rule, 1);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set ACL rule for ingress RoCE, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        offset++;

        /* 9. Set rule to trap unexpected packets received on RoCE priority (correct packets should have been handled by now),
         * if reason enabled */
        rule.action_list_p[0].fields.action_trap_w_user_id.user_id =
            WJH_ROCE_ACL_USER_ID_CREATE(WJH_DROP_REASON_ID_NON_ROCE_ON_ROCE_PRIORITY,
                                        db_p->roce_switch_prio);
        rule.key_desc_list_p[0].key.switch_prio = db_p->roce_switch_prio;
        sx_status = sx_api_acl_flex_rules_set(handle, SX_ACCESS_CMD_SET, db_p->region_id, &offset, &rule, 1);
        if (SX_CHECK_FAIL(sx_status)) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("Failed to set ACL rule for ingress RoCE, err: %s\n",
                        sx_status_str(sx_status));
            goto out;
        }
        offset++;
        db_p->non_roce_rule.count = offset - offset_start;
    }

out:
    if (err != WJH_STATUS_SUCCESS) {
        for (i = 0; i < offset; i++) {
            sx_status = sx_api_acl_flex_rules_set(handle,
                                                  SX_ACCESS_CMD_DELETE,
                                                  db_p->region_id,
                                                  &i,
                                                  NULL,
                                                  1);
            if (SX_CHECK_FAIL(sx_status)) {
                WJH_LOG_ERR("Failed to delete ACL rule for ingress RoCE rollback, err: %s\n",
                            sx_status_str(sx_status));
            }
        }
    }

    if (rule_allocated == TRUE) {
        sx_status = sx_lib_flex_acl_rule_deinit(&rule);
        if (SX_CHECK_FAIL(sx_status)) {
            WJH_LOG_ERR("Failed to deinit ACL rule ingress RoCE, err: %s\n",
                        sx_status_str(sx_status));
        }
    }

    return err;
}

wjh_status_t wjh_roce_drop_acl_rules_set(uint64_t handle, uint8_t reason_bits, boolean_t trap)
{
    wjh_status_t        err = WJH_STATUS_SUCCESS;
    wjh_roce_drop_db_t *db_p = NULL;

    wjh_db_roce_drop_get(&db_p);
    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Wjh roce drop reason db is not valid\n");
        goto out;
    }

    if (WJH_ROCE_DROP_REASON_CHECK(reason_bits, WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY)) {
        err = __wjh_roce_rule_set(handle,
                                  db_p,
                                  WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY,
                                  db_p->roce_wrong_prio_rule.offset_start,
                                  trap);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to set roce rule.\n");
            goto out;
        }
    }

    if (WJH_ROCE_DROP_REASON_CHECK(reason_bits, WJH_DROP_REASON_ID_NON_ROCE_ON_ROCE_PRIORITY)) {
        err = __wjh_roce_rule_set(handle,
                                  db_p,
                                  WJH_DROP_REASON_ID_NON_ROCE_ON_ROCE_PRIORITY,
                                  db_p->non_roce_rule.offset_start,
                                  trap);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to set roce rule.\n");
            goto out;
        }
    }

    if (WJH_ROCE_DROP_REASON_CHECK(reason_bits, WJH_DROP_REASON_ID_ROCE_FLOOD)) {
        WJH_LOG_DBG("RoCE flood reason is not supported yet.\n");
    }

out:
    return err;
}

static wjh_status_t __wjh_user_channel_timestamp_source_set(sx_api_handle_t                     handle,
                                                            wjh_user_channel_id_t               channel_id,
                                                            wjh_user_channel_timestamp_source_e timestamp_source)
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    sx_status_t                  sx_status = SX_STATUS_SUCCESS;
    sx_trap_group_attributes_t   trap_group_attr;
    sx_packet_timestamp_source_e sdk_timestamp_source = SX_PACKET_TIMESTAMP_SOURCE_LINUX_E;
    sx_access_cmd_t              cmd = SX_ACCESS_CMD_NONE;
    wjh_user_channel_record_t   *user_channel_p = NULL;

    if (timestamp_source == WJH_USER_CHANNEL_TIMESTAMP_SOURCE_HW_CLOCK_E) {
        sdk_timestamp_source = SX_PACKET_TIMESTAMP_SOURCE_HW_UTC_E;
    }

    wjh_db_user_channel_get(channel_id, &user_channel_p);

    memset(&trap_group_attr, 0, sizeof(trap_group_attr));
    sx_status = sx_api_host_ifc_trap_group_get(handle, 0, user_channel_p->trap_group_id,
                                               &trap_group_attr);
    if (SX_CHECK_FAIL(sx_status)) {
        WJH_LOG_ERR("sx_api_host_ifc_trap_group_get failed, err: %s\n", sx_status_str(sx_status));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (trap_group_attr.timestamp_source == sdk_timestamp_source) {
        /* The trap group timestamp source is already set to what we want, do nothing */
        goto out;
    }

    if (wjh_init_params_g.driver_init_param.trap_group_allocate_mode == WJH_TRAP_GROUP_ALLOCATE_MODE_STATIC_E) {
        cmd = SX_ACCESS_CMD_SET;
    } else {
        cmd = SX_ACCESS_CMD_EDIT;
    }

    trap_group_attr.timestamp_source = sdk_timestamp_source;
    sx_status = sx_api_host_ifc_trap_group_ext_set(handle,
                                                   cmd,
                                                   0,
                                                   user_channel_p->trap_group_id,
                                                   &trap_group_attr);
    if (SX_CHECK_FAIL(sx_status)) {
        WJH_LOG_ERR("Failed to set trap group (%u), error: %s\n",
                    user_channel_p->trap_group_id,
                    sx_status_str(sx_status));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_user_channel_timestamp_source_set_spc(sx_api_handle_t                     handle,
                                                       wjh_user_channel_id_t               channel_id,
                                                       wjh_user_channel_timestamp_source_e timestamp_source)
{
    UNUSED_PARAM(handle);
    UNUSED_PARAM(channel_id);
    UNUSED_PARAM(timestamp_source);

    /* SPC1 only supports Linux timestamp and the default is already Linux timestamp.
     * We need to allow user to configure HW UTC option on SPC1 since buffer drop can provide HW timestamp from mirror header v1.
     * So we do nothing here and return success.
     */
    return WJH_STATUS_SUCCESS;
}

wjh_status_t wjh_user_channel_timestamp_source_set_spc2(sx_api_handle_t                     handle,
                                                        wjh_user_channel_id_t               channel_id,
                                                        wjh_user_channel_timestamp_source_e timestamp_source)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    err = __wjh_user_channel_timestamp_source_set(handle, channel_id, timestamp_source);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_user_channel_timestamp_source_set failed, err: %d\n", err);
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_policer_limits_get_spc(wjh_policer_limits_t *limits_p)
{
    limits_p->policer_bs_min_value_bytes = WJH_POLICER_BURST_SIZE_MIN_BYTES_SPC;
    limits_p->policer_bs_max_value_bytes = WJH_POLICER_BURST_SIZE_MAX_BYTES_SPC;
    limits_p->policer_ir_max_value_bytes = WJH_POLICER_INFORMATION_RATE_MAX_BYTES;

    return WJH_STATUS_SUCCESS;
}

wjh_status_t wjh_policer_limits_get_spc2(wjh_policer_limits_t *limits_p)
{
    limits_p->policer_bs_min_value_bytes = WJH_POLICER_BURST_SIZE_MIN_BYTES_SPC2;
    limits_p->policer_bs_max_value_bytes = WJH_POLICER_BURST_SIZE_MAX_BYTES_SPC2;
    limits_p->policer_ir_max_value_bytes = WJH_POLICER_INFORMATION_RATE_MAX_BYTES;

    return WJH_STATUS_SUCCESS;
}

wjh_status_t wjh_mirror_header_v2_size_get(uint32_t *size_p)
{
    *size_p = sizeof(wjh_buf_drop_pkt_hdr_ver2_t);
    return WJH_STATUS_SUCCESS;
}

wjh_status_t wjh_mirror_header_v2_size_get_spc4(uint32_t *size_p)
{
    *size_p = sizeof(wjh_buf_drop_pkt_hdr_ver2_ext_t);
    return WJH_STATUS_SUCCESS;
}
