/*
 * Copyright © 2001-2022 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#include <unistd.h>
#include <libelf.h>
#include <gelf.h>
#include <sys/syscall.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <errno.h>
#include <linux/perf_event.h>
#include <fcntl.h>
#include <complib/cl_types.h>
#include "wjh_common.h"
#include "wjh_ebpf.h"
#include "wjh_log.h"

/************************************************
 *  Local Macros
 ***********************************************/

#define WJH_EBPF_LICENSE_BUF_LEN (128)
#define WJH_EBPF_LOG_BUF_LEN     (10240)

#ifndef __NR_bpf
# if defined(__i386__)
#  define __NR_bpf 357
# elif defined(__x86_64__)
#  define __NR_bpf 321
# elif defined(__aarch64__)
#  define __NR_bpf 280
# elif defined(__powerpc__)
#  define __NR_bpf 361
# elif defined(__ILP32__)
#  define __NR_bpf (0x40000000 + 321)
# elif defined(__arm__)
#  if defined(__thumb__) || defined(__ARM_EABI__)
#    define __NR_bpf 386
#  else
#    define __NR_bpf (0x900000 + 386)
#  endif
# else
#  define __NR_bpf 280
# endif
#endif

#ifndef SO_ATTACH_BPF
#define SO_ATTACH_BPF 50
#endif

#ifndef SO_DETACH_BPF
#define SO_DETACH_BPF 27
#endif


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Local variables
 ***********************************************/
static char wjh_ebpf_prog_log_buf[WJH_EBPF_LOG_BUF_LEN];

/************************************************
 *  Local function declarations
 ***********************************************/
static wjh_status_t __wjh_sys_bpf(const enum bpf_cmd    cmd,
                                  const union bpf_attr *attr_p,
                                  const uint32_t        attr_size,
                                  const boolean_t       item_not_found_as_error,
                                  int                  *syscall_ret_p);
static wjh_status_t __wjh_get_elf_section(Elf       *elf_p,
                                          uint32_t   i,
                                          GElf_Ehdr *ehdr_p,
                                          GElf_Shdr *shdr_p,
                                          char     **shname_p,
                                          Elf_Data **data_pp);
static wjh_status_t __wjh_load_bpf_program(const enum bpf_prog_type prog_type,
                                           const struct bpf_insn   *insn_p,
                                           const uint32_t           prog_len,
                                           const char              *license_p,
                                           int                     *prog_fd_p);
static wjh_status_t __wjh_set_bpf_socket_filter(const int                    bpf_prog_fd,
                                                const wjh_ebpf_prog_op_e     op,
                                                wjh_ebpf_prog_attach_attr_t *attach_attr_p);
static wjh_status_t __wjh_attach_bpf_trace_point(const int                    bpf_prog_fd,
                                                 wjh_ebpf_prog_attach_attr_t *attach_attr_p);
static wjh_status_t __wjh_detach_bpf_trace_point(const wjh_ebpf_prog_attach_attr_t *attach_attr_p);
static wjh_status_t __wjh_set_bpf_trace_point(const int                    bpf_prog_fd,
                                              const wjh_ebpf_prog_op_e     op,
                                              wjh_ebpf_prog_attach_attr_t *attach_attr_p);


/************************************************
 *  Function implementations
 ***********************************************/
static wjh_status_t __wjh_sys_bpf(const enum bpf_cmd    cmd,
                                  const union bpf_attr *attr_p,
                                  const uint32_t        attr_size,
                                  const boolean_t       item_not_found_as_error,
                                  int                  *syscall_ret_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    int          ret = 0;

    WJH_CHECK_NULL_PTR(attr_p, attr_p);
    WJH_CHECK_NULL_PTR(syscall_ret_p, syscall_ret_p);

    ret = syscall(__NR_bpf, cmd, attr_p, attr_size);
    if (ret < 0) {
        if (errno == ENOSYS) {
            WJH_LOG_ERR("The bpf system call is not supported by the current kernel.\n");
            err = WJH_STATUS_UNSUPPORTED;
        } else if (errno == ENOENT) {
            if (item_not_found_as_error) {
                WJH_LOG_ERR("Item not found.\n");
            } else {
                WJH_LOG_INF("Item not found.\n");
            }
            err = WJH_STATUS_ENTRY_NOT_FOUND;
        } else {
            WJH_LOG_ERR("The bpf system call failed, err: %s.\n", strerror(errno));
            err = WJH_STATUS_ERROR;
        }
        goto out;
    }

    *syscall_ret_p = ret;

out:
    return err;
}

static wjh_status_t __wjh_get_elf_section(Elf       *elf_p,
                                          uint32_t   i,
                                          GElf_Ehdr *ehdr_p,
                                          GElf_Shdr *shdr_p,
                                          char     **shname_p,
                                          Elf_Data **data_pp)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    Elf_Scn     *scn_p = NULL;

    scn_p = elf_getscn(elf_p, i);
    if (scn_p == NULL) {
        WJH_LOG_INF("elf_getscn failed, section %d, err: %s.\n", i, elf_errmsg(elf_errno()));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (gelf_getshdr(scn_p, shdr_p) != shdr_p) {
        WJH_LOG_INF("gelf_getshdr failed, err: %s.\n", elf_errmsg(elf_errno()));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    *shname_p = elf_strptr(elf_p, ehdr_p->e_shstrndx, shdr_p->sh_name);
    if ((*shname_p) == NULL) {
        WJH_LOG_INF("elf_strptr failed, err: %s.\n", elf_errmsg(elf_errno()));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    *data_pp = elf_getdata(scn_p, NULL);
    if ((*data_pp) == NULL) {
        WJH_LOG_INF("elf_getdata failed, err: %s.\n", elf_errmsg(elf_errno()));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_load_bpf_program(const enum bpf_prog_type prog_type,
                                           const struct bpf_insn   *insn_p,
                                           const uint32_t           prog_len,
                                           const char              *license_p,
                                           int                     *prog_fd_p)
{
    wjh_status_t   err = WJH_STATUS_SUCCESS;
    union bpf_attr attr;

    memset(&attr, 0, sizeof(union bpf_attr));
    attr.prog_type = prog_type;
    attr.insns = (uint64_t)((void*)insn_p);
    attr.insn_cnt = prog_len / sizeof(struct bpf_insn);
    attr.license = (uint64_t)((void*)license_p);
    attr.log_level = 0;
    attr.log_size = 0;
    attr.log_buf = (uint64_t)(NULL);
    attr.kern_version = 0;

    err = __wjh_sys_bpf(BPF_PROG_LOAD, &attr, sizeof(attr), TRUE, prog_fd_p);
    if (WJH_CHECK_FAIL(err)) {
        attr.log_level = 1;
        attr.log_size = WJH_EBPF_LOG_BUF_LEN;
        attr.log_buf = (uint64_t)(wjh_ebpf_prog_log_buf);
        wjh_ebpf_prog_log_buf[0] = 0;
        err = __wjh_sys_bpf(BPF_PROG_LOAD, &attr, sizeof(attr), TRUE, prog_fd_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Failed to load ebpf program, possible reason: %s\n", wjh_ebpf_prog_log_buf);
        }
    }

    return err;
}

static wjh_status_t __wjh_set_bpf_socket_filter(const int                    bpf_prog_fd,
                                                const wjh_ebpf_prog_op_e     op,
                                                wjh_ebpf_prog_attach_attr_t *attach_attr_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    int          ret = 0;
    int          prog_fd = bpf_prog_fd;
    int          sock_op;

    switch (op) {
    case WJH_EBPF_PROG_OP_ATTACH:
        sock_op = SO_ATTACH_BPF;
        break;

    case WJH_EBPF_PROG_OP_DETACH:
        sock_op = SO_DETACH_BPF;
        break;

    default:
        WJH_LOG_ERR("Unsupported WJH eBPF program operation type: %u\n", op);
        err = WJH_STATUS_UNSUPPORTED;
        goto out;
    }

    ret = setsockopt(attach_attr_p->attach_attr.socket_filter.socket_fd,
                     SOL_SOCKET, sock_op, &prog_fd, sizeof(prog_fd));
    if (ret != 0) {
        WJH_LOG_ERR("Failed to attach BPF program (fd: %u) to socket (fd: %u), err: %s\n",
                    bpf_prog_fd, attach_attr_p->attach_attr.socket_filter.socket_fd, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}

static wjh_status_t __wjh_attach_bpf_trace_point(const int bpf_prog_fd, wjh_ebpf_prog_attach_attr_t *attach_attr_p)
{
    wjh_status_t           err = WJH_STATUS_SUCCESS;
    int                    ret = 0;
    char                   buf[256];
    int                    event_file_fd = -1;
    int                    event_fd = -1;
    struct perf_event_attr perf_attr;
    boolean_t              failed = TRUE;

    event_file_fd = open(attach_attr_p->attach_attr.trace_point.event_id_path_p, O_RDONLY, 0);
    if (event_file_fd < 0) {
        WJH_LOG_ERR("Failed to open file %s, err: %s\n",
                    attach_attr_p->attach_attr.trace_point.event_id_path_p, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    ret = read(event_file_fd, buf, sizeof(buf));
    if ((ret < 0) || (ret >= (int)sizeof(buf))) {
        WJH_LOG_ERR("Failed to read from file %s, err: %s\n",
                    attach_attr_p->attach_attr.trace_point.event_id_path_p, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    buf[ret] = 0;
    memset(&perf_attr, 0, sizeof(perf_attr));
    perf_attr.config = atoi(buf);
    perf_attr.type = PERF_TYPE_TRACEPOINT;
    perf_attr.sample_type = PERF_SAMPLE_RAW;
    perf_attr.sample_period = 1;
    perf_attr.wakeup_events = 1;
    event_fd = syscall(__NR_perf_event_open, &perf_attr, -1, 0, -1, 0);
    if (event_fd < 0) {
        WJH_LOG_ERR("Failed to open perf event, err: %s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    ret = ioctl(event_fd, PERF_EVENT_IOC_ENABLE, 0);
    if (ret < 0) {
        WJH_LOG_ERR("Failed to enable perf event, err: %s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }
    ret = ioctl(event_fd, PERF_EVENT_IOC_SET_BPF, bpf_prog_fd);
    if (ret < 0) {
        WJH_LOG_ERR("Failed to attach bpf program to perf event, err: %s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    attach_attr_p->attach_attr.trace_point.event_fd = event_fd;
    failed = FALSE;

out:
    if (event_file_fd >= 0) {
        close(event_file_fd);
    }

    if (failed && (event_fd >= 0)) {
        close(event_fd);
    }

    return err;
}

static wjh_status_t __wjh_detach_bpf_trace_point(const wjh_ebpf_prog_attach_attr_t *attach_attr_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    int          ret = 0;
    int          event_fd = attach_attr_p->attach_attr.trace_point.event_fd;

    ret = ioctl(event_fd, PERF_EVENT_IOC_DISABLE, 0);
    if (ret < 0) {
        WJH_LOG_ERR("Failed to disable perf event, err: %s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    ret = close(event_fd);
    if (ret < 0) {
        WJH_LOG_ERR("Failed to close perf event, err: %s\n", strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}


static wjh_status_t __wjh_set_bpf_trace_point(const int                    bpf_prog_fd,
                                              const wjh_ebpf_prog_op_e     op,
                                              wjh_ebpf_prog_attach_attr_t *attach_attr_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    switch (op) {
    case WJH_EBPF_PROG_OP_ATTACH:
        err = __wjh_attach_bpf_trace_point(bpf_prog_fd, attach_attr_p);
        break;

    case WJH_EBPF_PROG_OP_DETACH:
        err = __wjh_detach_bpf_trace_point(attach_attr_p);
        break;

    default:
        WJH_LOG_ERR("Unsupported WJH eBPF program operation type: %u\n", op);
        err = WJH_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_ebpf_map_create(const enum bpf_map_type map_type,
                                 const uint32_t          key_size,
                                 const uint32_t          value_size,
                                 const uint32_t          max_entries_cnt,
                                 int                    *map_fd_p)
{
    wjh_status_t   err = WJH_STATUS_SUCCESS;
    union bpf_attr attr;

    memset(&attr, 0, sizeof(union bpf_attr));
    attr.map_type = map_type;
    attr.key_size = key_size;
    attr.value_size = value_size;
    attr.max_entries = max_entries_cnt;

    WJH_CHECK_NULL_PTR(map_fd_p, map_fd_p);

    err = __wjh_sys_bpf(BPF_MAP_CREATE, &attr, sizeof(attr), TRUE, map_fd_p);

out:
    return err;
}

wjh_status_t wjh_ebpf_map_elem_update(const int      map_fd,
                                      const void    *key_p,
                                      const void    *value_p,
                                      const uint64_t flags)
{
    wjh_status_t   err = WJH_STATUS_SUCCESS;
    int            syscall_ret;
    union bpf_attr attr;

    memset(&attr, 0, sizeof(union bpf_attr));
    attr.map_fd = map_fd;
    attr.key = (uint64_t)key_p;
    attr.value = (uint64_t)value_p;
    attr.flags = flags;

    WJH_CHECK_NULL_PTR(key_p, key_p);
    WJH_CHECK_NULL_PTR(value_p, value_p);

    err = __wjh_sys_bpf(BPF_MAP_UPDATE_ELEM, &attr, sizeof(attr), TRUE, &syscall_ret);

out:
    return err;
}

wjh_status_t wjh_ebpf_map_elem_lookup(const int map_fd, const void *key_p, void *value_p)
{
    wjh_status_t   err = WJH_STATUS_SUCCESS;
    int            syscall_ret;
    union bpf_attr attr;

    memset(&attr, 0, sizeof(union bpf_attr));
    attr.map_fd = map_fd;
    attr.key = (uint64_t)key_p;
    attr.value = (uint64_t)value_p;

    WJH_CHECK_NULL_PTR(key_p, key_p);
    WJH_CHECK_NULL_PTR(value_p, value_p);

    err = __wjh_sys_bpf(BPF_MAP_LOOKUP_ELEM, &attr, sizeof(attr), FALSE, &syscall_ret);

out:
    return err;
}

wjh_status_t wjh_ebpf_map_elem_delete(const int map_fd, const void *key_p)
{
    wjh_status_t   err = WJH_STATUS_SUCCESS;
    int            syscall_ret;
    union bpf_attr attr;

    memset(&attr, 0, sizeof(union bpf_attr));
    attr.map_fd = map_fd;
    attr.key = (uint64_t)key_p;

    WJH_CHECK_NULL_PTR(key_p, key_p);

    err = __wjh_sys_bpf(BPF_MAP_DELETE_ELEM, &attr, sizeof(attr), TRUE, &syscall_ret);

out:
    return err;
}

wjh_status_t wjh_ebpf_map_next_key_get(const int map_fd, const void *key_p, void *next_key_p)
{
    wjh_status_t   err = WJH_STATUS_SUCCESS;
    int            syscall_ret;
    union bpf_attr attr;

    memset(&attr, 0, sizeof(union bpf_attr));
    attr.map_fd = map_fd;
    attr.key = (uint64_t)key_p;
    attr.next_key = (uint64_t)next_key_p;

    WJH_CHECK_NULL_PTR(key_p, key_p);
    WJH_CHECK_NULL_PTR(next_key_p, next_key_p);

    err = __wjh_sys_bpf(BPF_MAP_GET_NEXT_KEY, &attr, sizeof(attr), FALSE, &syscall_ret);

out:
    return err;
}

wjh_status_t wjh_ebpf_program_load(const char              *elf_file_path_p,
                                   const enum bpf_prog_type prog_type,
                                   const char              *bpf_prog_sec_name,
                                   const char             **bpf_map_name_list_p,
                                   const int               *bpf_map_fd_list_p,
                                   const uint32_t           bpf_map_count,
                                   int                     *bpf_prog_fd_p)
{
    wjh_status_t     err = WJH_STATUS_SUCCESS;
    uint32_t         i = 0;
    uint32_t         j = 0;
    int              elf_file_fd = 0;
    Elf             *elf_p = NULL;
    GElf_Ehdr        ehdr;
    GElf_Shdr        shdr;
    GElf_Shdr        shdr_prog;
    Elf_Data        *data_p = NULL;
    Elf_Data        *data_prog_p = NULL;
    Elf_Data        *symbols_p = NULL;
    char            *shname_p = NULL;
    char            *shname_prog_p = NULL;
    char             license[WJH_EBPF_LICENSE_BUF_LEN] = {0};
    struct bpf_insn *bpf_insn_p = NULL;
    GElf_Sym         sym;
    GElf_Rel         rel;
    uint32_t         insn_index;
    uint32_t         rel_cnt;
    boolean_t        found_flag = FALSE;

    WJH_CHECK_NULL_PTR(elf_file_path_p, elf_file_path_p);
    WJH_CHECK_NULL_PTR(bpf_prog_sec_name, bpf_prog_sec_name);
    if (bpf_map_count != 0) {
        WJH_CHECK_NULL_PTR(bpf_map_name_list_p, bpf_map_name_list_p);
        for (i = 0; i < bpf_map_count; ++i) {
            if (bpf_map_name_list_p[i] == NULL) {
                WJH_LOG_ERR("bpf_map_name_list_p[%u] is NULL.\n", i);
                err = WJH_STATUS_PARAM_NULL;
                goto out;
            }
        }
        WJH_CHECK_NULL_PTR(bpf_map_fd_list_p, bpf_map_fd_list_p);
        for (i = 0; i < bpf_map_count; ++i) {
            if (bpf_map_fd_list_p[i] < 0) {
                WJH_LOG_ERR("bpf_map_fd_list_p[%u] is invalid.\n", i);
                err = WJH_STATUS_PARAM_ERROR;
                goto out;
            }
        }
    }
    WJH_CHECK_NULL_PTR(bpf_prog_fd_p, bpf_prog_fd_p);

    if (elf_version(EV_CURRENT) == EV_NONE) {
        WJH_LOG_ERR("The libelf version is too old.\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    elf_file_fd = open(elf_file_path_p, O_RDONLY, 0);
    if (elf_file_fd < 0) {
        WJH_LOG_ERR("Failed to open file %s, err: %s.\n", elf_file_path_p, strerror(errno));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    elf_p = elf_begin(elf_file_fd, ELF_C_READ, NULL);
    if (elf_p == NULL) {
        WJH_LOG_ERR("elf_begin failed, err: %s.\n", elf_errmsg(elf_errno()));
        err = WJH_STATUS_ERROR;
        goto close_elf_file;
    }

    if (gelf_getehdr(elf_p, &ehdr) != &ehdr) {
        WJH_LOG_ERR("gelf_getehdr failed, err: %s.\n", elf_errmsg(elf_errno()));
        err = WJH_STATUS_ERROR;
        goto end_elf;
    }

    /* scan over all elf sections to get license and symbol table */
    for (i = 1; i < ehdr.e_shnum; ++i) {
        err = __wjh_get_elf_section(elf_p, i, &ehdr, &shdr, &shname_p, &data_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_INF("Failed to get elf section %u\n", i);
            continue;
        }

        if (strcmp(shname_p, "license") == 0) {
            strncpy(license, data_p->d_buf, WJH_EBPF_LICENSE_BUF_LEN - 1);
            license[WJH_EBPF_LICENSE_BUF_LEN - 1] = 0;
        } else if (shdr.sh_type == SHT_SYMTAB) {
            symbols_p = data_p;
        }
    }

    if (strlen(license) == 0) {
        WJH_LOG_ERR("Failed to get license from the elf.\n");
        err = WJH_STATUS_ERROR;
        goto end_elf;
    }

    if (symbols_p == NULL) {
        WJH_LOG_ERR("Failed to get symbol table from the elf.\n");
        err = WJH_STATUS_ERROR;
        goto end_elf;
    }

    /* Try to find the ebpf program section and its relocation section */
    for (i = 1; i < ehdr.e_shnum; ++i) {
        err = __wjh_get_elf_section(elf_p, i, &ehdr, &shdr, &shname_p, &data_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_INF("Failed to get elf section %u\n", i);
            continue;
        }

        if (shdr.sh_type != SHT_REL) {
            continue;
        }

        err = __wjh_get_elf_section(elf_p, shdr.sh_info, &ehdr, &shdr_prog, &shname_prog_p, &data_prog_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_INF("Failed to get elf section %u\n", shdr.sh_info);
            continue;
        }

        if (strcmp(bpf_prog_sec_name, shname_prog_p) == 0) {
            break;
        }
    }

    if (i >= ehdr.e_shnum) {
        WJH_LOG_ERR("Failed to find section %s from elf\n", bpf_prog_sec_name);
        err = WJH_STATUS_ERROR;
        goto end_elf;
    }

    bpf_insn_p = (struct bpf_insn *)data_prog_p->d_buf;
    rel_cnt = shdr.sh_size / shdr.sh_entsize;

    for (i = 0; i < bpf_map_count; ++i) {
        found_flag = FALSE;

        for (j = 0; j < rel_cnt; ++j) {
            if (gelf_getrel(data_p, j, &rel) != &rel) {
                WJH_LOG_ERR("gelf_getrel failed, err: %s.\n", elf_errmsg(elf_errno()));
                err = WJH_STATUS_ERROR;
                goto end_elf;
            }

            insn_index = rel.r_offset / sizeof(struct bpf_insn);
            if (bpf_insn_p[insn_index].code != (BPF_LD | BPF_IMM | BPF_DW)) {
                WJH_LOG_ERR("Invalid code 0x%x for eBPF instance %u\n",
                            bpf_insn_p[insn_index].code, insn_index);
                err = WJH_STATUS_ERROR;
                goto end_elf;
            }

            if (gelf_getsym(symbols_p, GELF_R_SYM(rel.r_info), &sym) != &sym) {
                WJH_LOG_ERR("gelf_getrel failed, err: %s.\n", elf_errmsg(elf_errno()));
                err = WJH_STATUS_ERROR;
                goto end_elf;
            }

            if (strcmp(bpf_map_name_list_p[i],
                       elf_strptr(elf_p, ehdr.e_shstrndx, sym.st_name)) != 0) {
                continue;
            }

            bpf_insn_p[insn_index].src_reg = BPF_PSEUDO_MAP_FD;
            bpf_insn_p[insn_index].imm = bpf_map_fd_list_p[i];
            found_flag = TRUE;
        }

        if (!found_flag) {
            WJH_LOG_ERR("Failed to find eBPF map %s from the elf\n", bpf_map_name_list_p[i]);
            err = WJH_STATUS_ERROR;
            goto end_elf;
        }
    }

    err = __wjh_load_bpf_program(prog_type,
                                 bpf_insn_p,
                                 data_prog_p->d_size,
                                 license,
                                 bpf_prog_fd_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_load_bpf_program failed, err: %d\n", err);
        goto end_elf;
    }

end_elf:
    elf_end(elf_p);

close_elf_file:
    if (close(elf_file_fd) < 0) {
        WJH_LOG_ERR("Failed to close file %s, err: %s.\n", elf_file_path_p, strerror(errno));
    }

out:
    return err;
}

wjh_status_t wjh_ebpf_program_set(const int                    bpf_prog_fd,
                                  const enum bpf_prog_type     prog_type,
                                  const wjh_ebpf_prog_op_e     op,
                                  wjh_ebpf_prog_attach_attr_t *attach_attr_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (bpf_prog_fd < 0) {
        WJH_LOG_ERR("Invalid eBPF program fd: %d\n", bpf_prog_fd);
        err = WJH_STATUS_PARAM_ERROR;
        goto out;
    }
    WJH_CHECK_NULL_PTR(attach_attr_p, attach_attr_p);

    switch (prog_type) {
    case BPF_PROG_TYPE_SOCKET_FILTER:
        if (attach_attr_p->attach_attr.socket_filter.socket_fd < 0) {
            WJH_LOG_ERR("Invalid socket fd: %u\n", attach_attr_p->attach_attr.socket_filter.socket_fd);
            err = WJH_STATUS_PARAM_ERROR;
            goto out;
        }
        err = __wjh_set_bpf_socket_filter(bpf_prog_fd, op, attach_attr_p);
        break;

    case BPF_PROG_TYPE_TRACEPOINT:
        if (op == WJH_EBPF_PROG_OP_ATTACH) {
            if (attach_attr_p->attach_attr.trace_point.event_id_path_p == NULL) {
                WJH_LOG_ERR("The perf event id file path is NULL\n");
                err = WJH_STATUS_PARAM_ERROR;
                goto out;
            }
        } else if (op == WJH_EBPF_PROG_OP_DETACH) {
            if (attach_attr_p->attach_attr.trace_point.event_fd < 0) {
                WJH_LOG_ERR("Invalid perf event fd\n");
                err = WJH_STATUS_PARAM_ERROR;
                goto out;
            }
        }
        err = __wjh_set_bpf_trace_point(bpf_prog_fd, op, attach_attr_p);
        break;

    default:
        WJH_LOG_ERR("Unsupported BPF program type: %u\n", prog_type);
        err = WJH_STATUS_UNSUPPORTED;
        break;
    }

out:
    return err;
}
