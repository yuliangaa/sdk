/*
 * Copyright © 2001-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_CALLBACKS_MLXSW_H_
#define WJH_CALLBACKS_MLXSW_H_

#include "wjh_callbacks.h"

static wjh_driver_specific_callback_t wjh_mlxsw_callbacks = {
    .wjh_init_cb = NULL,
    .wjh_deinit_cb = NULL,
    .wjh_policer_create_cb = NULL,
    .wjh_policer_destroy_cb = NULL,
    .wjh_user_channel_validate_cb = NULL,
    .wjh_user_channel_create_cb = NULL,
    .wjh_user_channel_destroy_cb = NULL,
    .wjh_user_channel_flush_cb = NULL,
    .wjh_drop_reason_group_validate_cb = NULL,
    .wjh_drop_reason_group_init_cb = NULL,
    .wjh_drop_reason_group_deinit_cb = NULL,
    .wjh_drop_reason_group_bind_cb = NULL,
    .wjh_drop_reason_group_unbind_cb = NULL,
    .wjh_drop_reason_group_enable_cb = NULL,
    .wjh_drop_reason_group_disable_cb = NULL,
    .wjh_counter_dropped_packets_get_cb = NULL,
    .wjh_resources_pre_init_clean_up_cb = NULL,
    .wjh_resources_post_init_clean_up_cb = NULL,
    .wjh_polling_thread_buf_create_cb = NULL,
    .wjh_polling_thread_buf_destroy_cb = NULL,
    .wjh_user_channel_process_cb = NULL,
    .wjh_user_channel_fd_get_cb = NULL,
    .wjh_get_chip_type_cb = NULL,
    .wjh_validate_shm_cb = NULL,
    .wjh_update_shm_cb = NULL,
    .wjh_user_channel_timestamp_source_set_cb = NULL,
    .wjh_user_channel_tac_set_cb = NULL,
#ifdef WJH_EBPF_PRESENT
    .wjh_set_debugfs_path_cb = NULL,
    .wjh_ebpf_prepare_cb = NULL,
    .wjh_ebpf_cleanup_cb = NULL,
    .wjh_aggregation_set_monitor_rdq_trace_points_cb = NULL,
#endif
};

#endif /* WJH_CALLBACKS_MLXSW_H_ */
