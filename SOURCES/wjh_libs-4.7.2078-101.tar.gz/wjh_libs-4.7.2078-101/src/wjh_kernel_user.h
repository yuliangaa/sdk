/*
 * Copyright © 2001-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_KERNEL_USER_H_
#define WJH_KERNEL_USER_H_

#ifdef __KERNEL__
#define ETHER_ADDR_LEN ETH_ALEN
#endif

#define WJH_BUF_DROP_HDR_COMMON_IS_INGRESS_LAG_OFFSET       (2)
#define WJH_BUF_DROP_HDR_COMMON_IS_EGRESS_LAG_OFFSET        (1)
#define WJH_BUF_DROP_HDR_COMMON_IS_EGRESS_PORT_VALID_OFFSET (4)
#define WJH_BUF_DROP_HDR_COMMON_SPLIT_PORT_MASK             (0xF)
#define WJH_BUF_DROP_HDR_COMMON_LABEL_PORT_OFFSET           (4)
#define WJH_BUF_DROP_HDR_COMMON_LABEL_PORT_MASK             (0x3FF)
#define WJH_BUF_DROP_HDR_MODULAR_LABEL_PORT_OFFSET          (4)
#define WJH_BUF_DROP_HDR_MODULAR_LABEL_PORT_MASK            (0x1F)
#define WJH_BUF_DROP_HDR_MODULAR_SLOT_OFFSET                (9)
#define WJH_BUF_DROP_HDR_MODULAR_SLOT_MASK                  (4)
#define WJH_BUF_DROP_HDR_COMMON_ETHER_TYPE                  (0x8949)
#define WJH_BUF_DROP_EGRESS_PORT_MULTI_PORT                 (0xFFFE)
#define MIRROR_HEADER_TLV_LONG_COUNT                        (4)
#define MIRROR_HEADER_TLV_SHORT_COUNT                       (4)
#define MIRROR_HEADER_TLV_LONG_EXT_COUNT                    (2)
#define WJH_BUF_DROP_HDR_EXTENDED_LAST_TLV_MASK_LONG        (1 << 31)
#define WJH_BUF_DROP_HDR_EXTENDED_TYPE_OFFSET_LONG          (24)
#define WJH_BUF_DROP_HDR_EXTENDED_TYPE_MASK_LONG            (0x7F << WJH_BUF_DROP_HDR_EXTENDED_TYPE_OFFSET_LONG)
#define WJH_BUF_DROP_HDR_EXTENDED_VALUE_MASK_LONG           (0xFFFFFF)
#define WJH_BUF_DROP_HDR_EXTENDED_LAST_TLV_MASK_SHORT       (1 << 15)
#define WJH_BUF_DROP_HDR_EXTENDED_TYPE_OFFSET_SHORT         (8)
#define WJH_BUF_DROP_HDR_EXTENDED_TYPE_MASK_SHORT           (0x7F << WJH_BUF_DROP_HDR_EXTENDED_TYPE_OFFSET_SHORT)
#define WJH_BUF_DROP_HDR_EXTENDED_VALUE_MASK_SHORT          (0xFF)
#define WJH_BUF_DROP_HDR_OPCODE_VER_0                       (0)
#define WJH_BUF_DROP_HDR_OPCODE_VER_1                       (1)
#define WJH_BUF_DROP_HDR_OPCODE_VER_2                       (2)
#define WJH_BUF_DROP_HDR_OPCODE_MASK_BYTE                   (0x7F)

/* The following macros are used to fit a switch priority value (assumed to be up to 15) and the drop
 * reason (assumed to be up to 4096) into a 16 bit trap with user id ACL action.
 */
#define WJH_ROCE_ACL_USER_ID_CREATE(drop_reason, switch_prio) (((switch_prio & 0xF) << 12) | (drop_reason & 0xFFF))
#define WJH_ROCE_ACL_USER_ID_SWITCH_PRIO(acl_user_id)         ((acl_user_id >> 12) & 0xF)
#define WJH_ROCE_ACL_USER_ID_DROP_REASON(acl_user_id)         ((acl_user_id) & 0xFFF)

/* The v2 & v1 header have the same common fields*/
typedef struct wjh_buf_drop_pkt_common_header {
    uint8_t  dmac[ETHER_ADDR_LEN];
    uint8_t  smac[ETHER_ADDR_LEN];
    uint16_t mirror_ethertype;
    uint16_t ingress_label_port;
    uint8_t  opcode;
    uint8_t  pad_count;
    uint8_t  flags;
    uint8_t  packet_type;
    uint32_t secs_msb;
    uint16_t secs_lsb;
    uint16_t nsecs_msb;
    uint16_t nsecs_lsb;
    uint16_t original_packet_size;
    uint16_t egress_label_port;
    uint16_t psn;
} __attribute__((packed)) wjh_buf_drop_pkt_common_header_t;

typedef struct wjh_buf_drop_pkt_hdr_ver2 {
    wjh_buf_drop_pkt_common_header_t hdr_common;
    uint32_t                         mirror_header_tlvs_long[MIRROR_HEADER_TLV_LONG_COUNT];
    uint16_t                         mirror_header_tlvs_short[MIRROR_HEADER_TLV_SHORT_COUNT];
} __attribute__((packed)) wjh_buf_drop_pkt_hdr_ver2_t;

typedef struct wjh_buf_drop_pkt_hdr_ver2_ext {
    wjh_buf_drop_pkt_hdr_ver2_t hdr_v2;
    uint32_t                    mirror_header_tlvs_long_ext[MIRROR_HEADER_TLV_LONG_EXT_COUNT];
} __attribute__((packed)) wjh_buf_drop_pkt_hdr_ver2_ext_t;

typedef enum wjh_span_mirror_reason {
    WJH_SPAN_MIRROR_REASON_INVALID                = 0,
    WJH_SPAN_MIRROR_REASON_ING_SHARED_BUFFER_DROP = 8,
    WJH_SPAN_MIRROR_REASON_ING_WRED               = 9,
    WJH_SPAN_MIRROR_REASON_ING_TC_CONGESTION      = 11,
    WJH_SPAN_MIRROR_REASON_EGR_TC_LATENCY         = 12
} wjh_span_mirror_reason_e;

#define WJH_SPAN_MIRROR_REASON_MIN WJH_SPAN_MIRROR_REASON_INVALID
#define WJH_SPAN_MIRROR_REASON_MAX WJH_SPAN_MIRROR_REASON_EGR_TC_LATENCY

#endif /* WJH_KERNEL_USER_H_ */
