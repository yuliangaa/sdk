/*
 * Copyright © 2001-2024 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_COMMON_H_
#define WJH_COMMON_H_

#include "wjh/wjh_lib.h"
#ifdef SDK_PRESENT
#include <sx/sxd/sxd_access_register.h>
#endif
/************************************************
 *  Macros
 ***********************************************/
#ifdef SDK_PRESENT
typedef sxd_chip_types_t wjh_chip_types_t;
#else
typedef uint32_t wjh_chip_types_t;
#endif

#define WJH_CHECK_NULL_PTR(ptr, ptr_name)                      \
    do {                                                       \
        if ((ptr) == NULL) {                                   \
            err = WJH_STATUS_PARAM_NULL;                       \
            WJH_LOG_ERR("Parameter %s is NULL.\n", #ptr_name); \
            goto out;                                          \
        }                                                      \
    } while (0)

#define WJH_CHECK_INITIALIZED(init_done)                    \
    do {                                                    \
        if (!(init_done)) {                                 \
            err = WJH_STATUS_NOT_INITIALIZED;               \
            WJH_LOG_ERR("WJH libs are not initialized.\n"); \
            goto out;                                       \
        }                                                   \
    } while (0)

#define WJH_DROP_REASON_GROUP_CHECK_RANGE(drop_reason_group)                       \
    do {                                                                           \
        if ((int)(drop_reason_group) < WJH_DROP_REASON_GROUP_MIN_E ||              \
            (int)(drop_reason_group) > WJH_DROP_REASON_GROUP_MAX_E) {              \
            err = WJH_STATUS_PARAM_ERROR;                                          \
            WJH_LOG_ERR("Invalid drop reason group (%d).\n", (drop_reason_group)); \
            goto out;                                                              \
        }                                                                          \
    } while (0)

#define WJH_USER_CHANNEL_TYPE_CHECK_RANGE(user_channel_type)                       \
    do {                                                                           \
        if ((int)(user_channel_type) < WJH_USER_CHANNEL_MIN_E ||                   \
            (int)(user_channel_type) > WJH_USER_CHANNEL_MAX_E) {                   \
            err = WJH_STATUS_PARAM_ERROR;                                          \
            WJH_LOG_ERR("Invalid user channel type (%d).\n", (user_channel_type)); \
            goto out;                                                              \
        }                                                                          \
    } while (0)

#define WJH_USER_CHANNEL_ID_CHECK_RANGE(user_channel_id)                       \
    do {                                                                       \
        if ((user_channel_id) >= WJH_USER_CHANNEL_MAX_NUM) {                   \
            err = WJH_STATUS_PARAM_ERROR;                                      \
            WJH_LOG_ERR("Invalid user channel id (%u).\n", (user_channel_id)); \
            goto out;                                                          \
        }                                                                      \
    } while (0)

#define WJH_CHECK_FAIL(STATUS) (WJH_STATUS_SUCCESS != (STATUS))

#define WJH_USER_CHANNEL_MODE_CHECK_RANGE(user_channel_mode)                       \
    do {                                                                           \
        if ((int)(user_channel_mode) < WJH_USER_CAHNNEL_MODE_MIN_E ||              \
            (int)(user_channel_mode) > WJH_USER_CAHNNEL_MODE_MAX_E) {              \
            err = WJH_STATUS_PARAM_ERROR;                                          \
            WJH_LOG_ERR("Invalid user channel mode (%d).\n", (user_channel_mode)); \
            goto out;                                                              \
        }                                                                          \
    } while (0)

#define WJH_USER_CHANNEL_TIMESTAMP_SOURCE_CHECK_RANGE(timestamp_source)                       \
    do {                                                                                      \
        if ((int)(timestamp_source) < WJH_USER_CHANNEL_TIMESTAMP_SOURCE_MIN_E ||              \
            (int)(timestamp_source) > WJH_USER_CHANNEL_TIMESTAMP_SOURCE_MAX_E) {              \
            err = WJH_STATUS_PARAM_ERROR;                                                     \
            WJH_LOG_ERR("Invalid user channel timestamp source (%d).\n", (timestamp_source)); \
            goto out;                                                                         \
        }                                                                                     \
    } while (0)

#define WJH_SEVERITY_CHECK_RANGE(severity)                       \
    do {                                                         \
        if ((int)(severity) < WJH_SEVERITY_MIN_E ||              \
            (int)(severity) > WJH_SEVERITY_MAX_E) {              \
            err = WJH_STATUS_PARAM_ERROR;                        \
            WJH_LOG_ERR("Invalid severity (%d).\n", (severity)); \
            goto out;                                            \
        }                                                        \
    } while (0)

#define WJH_SEVERITY_NUM         WJH_SEVERITY_MAX_E
#define WJH_SEVERITY_START       WJH_SEVERITY_NOTICE_E
#define WJH_SEVERITY_ENABLED_ALL ((1 << WJH_SEVERITY_NUM) - 1)

#define WJH_SEVERITY_ENABLED_SET(enabled, severity)            \
    do {                                                       \
        if (severity == WJH_SEVERITY_ALL_E) {                  \
            enabled = WJH_SEVERITY_ENABLED_ALL;                \
        } else {                                               \
            enabled |= (1 << (severity - WJH_SEVERITY_START)); \
        }                                                      \
    } while (0)                                                \

#define WJH_SEVERITY_ENABLED_CLEAR(enabled, severity)           \
    do {                                                        \
        if (severity == WJH_SEVERITY_ALL_E) {                   \
            enabled = 0;                                        \
        } else {                                                \
            enabled &= ~(1 << (severity - WJH_SEVERITY_START)); \
        }                                                       \
    } while (0)                                                 \

/* Check severity is set */
#define WJH_SEVERITY_CHECK(severity_bits, severity) ((severity_bits >> (severity - WJH_SEVERITY_START)) & 1)

#define WJH_SEVERITY_DISABLED_GET(enabled) ((~enabled) & WJH_SEVERITY_ENABLED_ALL)

#define WJH_AGGREGATION_READ_MODE_CHECK_RANGE(agg_read_mode)                       \
    do {                                                                           \
        if ((int)(agg_read_mode) < WJH_AGGREGATION_READ_MODE_MIN_E ||              \
            (int)(agg_read_mode) > WJH_AGGREGATION_READ_MODE_MAX_E) {              \
            err = WJH_STATUS_PARAM_ERROR;                                          \
            WJH_LOG_ERR("Invalid aggregation read mode (%d).\n", (agg_read_mode)); \
            goto out;                                                              \
        }                                                                          \
    } while (0)


/************************************************
 *  Type definitions
 ***********************************************/
typedef struct wjh_policer_limits {
    uint32_t policer_bs_min_value_bytes;
    uint32_t policer_bs_max_value_bytes;
    uint32_t policer_ir_max_value_bytes;
} wjh_policer_limits_t;

typedef struct wjh_policer_attrs {
    uint32_t burst_size;
    uint32_t information_rate;
} wjh_policer_attrs_t;

typedef struct wjh_dev_specific_cb {
    wjh_status_t (*wjh_buffer_drop_span_init_cb)(uint64_t handle, const wjh_drop_reason_group_attr_t *attr_p,
                                                 const wjh_policer_attrs_t *policer_attrs_p);
    wjh_status_t (*wjh_buffer_drop_span_session_set_cb)(uint64_t handle, boolean_t enable);
    wjh_status_t (*wjh_buffer_drop_span_session_bind_unbind_cb)(uint64_t handle, boolean_t bind);
    wjh_status_t (*wjh_buffer_drop_span_deinit_cb)(uint64_t handle);
    wjh_status_t (*wjh_buffer_drop_adviser_port_event_cb)(uint64_t handle, void *event, uint8_t reason_bits);
    wjh_status_t (*wjh_buffer_drop_acl_create_cb)(uint64_t handle, const wjh_drop_reason_group_attr_t *attr_p);
    wjh_status_t (*wjh_buffer_drop_acl_destroy_cb)(uint64_t handle);
    wjh_status_t (*wjh_roce_drop_acl_create_cb)(uint64_t handle, const wjh_drop_reason_group_attr_t *attr_p);
    wjh_status_t (*wjh_roce_drop_acl_destroy_cb)(uint64_t handle);
    wjh_status_t (*wjh_roce_drop_acl_rules_set_cb)(uint64_t  handle,
                                                   uint8_t   reason_bits,
                                                   boolean_t trap);
    wjh_status_t (*wjh_user_channel_timestamp_source_set_cb)(uint64_t                            handle,
                                                             wjh_user_channel_id_t               channel_id,
                                                             wjh_user_channel_timestamp_source_e timestamp_source);
    wjh_status_t (*wjh_policer_limits_get_cb)(wjh_policer_limits_t *limits_p);
    wjh_status_t (*wjh_mirror_header_v2_size_get_cb)(uint32_t *size_p);
    wjh_status_t (*wjh_buffer_drop_mirror_to_cpu_mode_set_cb)(boolean_t mode);
} wjh_dev_specific_cb_t;

/************************************************
 *  Function declarations
 ***********************************************/

wjh_status_t wjh_pci_link_status_get(uint16_t *speed_p, uint16_t *width_p);
wjh_status_t wjh_str_dup(char **dst, const char *src);
wjh_status_t wjh_system_boot_time_get(struct timespec *ts_p);

wjh_status_t wjh_get_chip_type(wjh_chip_types_t *chip_type);
wjh_status_t wjh_get_linux_kernel_version(int *version_p, int *major_p, int *minor_p);

#endif /* WJH_COMMON_H_ */
