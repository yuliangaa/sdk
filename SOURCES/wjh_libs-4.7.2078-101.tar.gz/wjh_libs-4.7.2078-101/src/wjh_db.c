/*
 * Copyright © 2001-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#include <string.h>
#ifdef SDK_PRESENT
#include <sx/sdk/sx_trap_id.h>
#include <sx/sdk/sx_strings.h>
#include "wjh_dev_sdk.h"
#endif
#include <complib/sx_xml.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_mem.h>
#include <complib/cl_dbg.h>
#include "wjh_db.h"
#include "wjh_common.h"
#include "wjh_log.h"

/************************************************
 *  Local Macros
 ***********************************************/
#define WJH_DB_L1_DROP_REASON_STR     "l1-drop-reason"
#define WJH_DB_L2_DROP_REASON_STR     "l2-drop-reason"
#define WJH_DB_ROUTER_DROP_REASON_STR "router-drop-reason"
#define WJH_DB_TUNNEL_DROP_REASON_STR "tunnel-drop-reason"
#define WJH_DB_BUFFER_DROP_REASON_STR "buffer-drop-reason"
#define WJH_DB_ACL_DROP_REASON_STR    "acl-drop-reason"
#define WJH_DB_ROCE_DROP_REASON_STR   "roce-drop-reason"
#define WJH_DB_REASON_INFO_STR        "reason-info"
#define WJH_DB_REASON_ID_STR          "reason-id"
#define WJH_DB_REASON_STR             "reason"
#define WJH_DB_DESCRIPTION_STR        "description"
#define WJH_DB_SEVERITY_STR           "severity"
#define WJH_DB_EVENT_TYPE_STR         "event-type"

#define WJH_DB_FILTER_POOL_MIN_SIZE       (16)
#define WJH_DB_FILTER_POOL_GROW_SIZE      (16)
#define WJH_DB_FILTER_RULE_POOL_MIN_SIZE  (16)
#define WJH_DB_FILTER_RULE_POOL_GROW_SIZE (16)
/************************************************
 *  Local Type definitions
 ***********************************************/

typedef struct wjh_drop_reason_group_trap_ids_item {
    wjh_trap_id_item_t *trap_ids;
    uint32_t            num;
    const char         *drop_reason_group_xml_name;
} wjh_drop_reason_group_trap_ids_item_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

static wjh_db_t           wjh_db_s;
static wjh_db_t           wjh_tmp_db_s;
static wjh_hw_db_t        wjh_hw_db_s;
static wjh_trap_id_item_t wjh_drop_reason_group_l2_trap_ids[] = {
#ifdef SDK_PRESENT
    {SX_TRAP_ID_DISCARD_ISOLATION, 201},
    {SX_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC, 202},
    {SX_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW, 203},
    {SX_TRAP_ID_DISCARD_ING_SWITCH_VLAN, 204},
    {SX_TRAP_ID_DISCARD_ING_SWITCH_STP, 205},
    {SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC, 206},
    {SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL, 207},
    {SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB, 208},
    {SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC, 209},
    {SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC, 210},
    {SX_TRAP_ID_FID_MISS, 211},
    {SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS, 212},
    {SX_TRAP_ID_DISCARD_ING_PACKET_SMAC0, 213},
#endif
};

static wjh_trap_id_item_t wjh_drop_reason_group_l2_trap_ids_spc[] = {
#ifdef SDK_PRESENT
    {SX_TRAP_ID_DISCARD_ISOLATION, 201},
    {SX_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC, 202},
    {SX_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW, 203},
    {SX_TRAP_ID_DISCARD_ING_SWITCH_VLAN, 204},
    {SX_TRAP_ID_DISCARD_ING_SWITCH_STP, 205},
    {SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC, 206},
    {SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL, 207},
    {SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB, 208},
    {SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC, 209},
    {SX_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC, 210},
    {SX_TRAP_ID_FID_MISS, 211},
    {SX_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS, 212},
#endif
};
static wjh_trap_id_item_t wjh_drop_reason_group_router_trap_ids[] = {
#ifdef SDK_PRESENT
    {SX_TRAP_ID_DISCARD_NON_ROUTED, 301},
    {SX_TRAP_ID_DISCARD_ROUTER2, 302},
    {SX_TRAP_ID_HOST_MISS_IPV4, 303},
    {SX_TRAP_ID_HOST_MISS_IPV6, 303},
    {SX_TRAP_ID_DISCARD_ROUTER3, 304},
    {SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0, 305},
    {SX_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1, 306},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR, 307},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC, 308},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB, 309},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC, 310},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E, 311},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB, 312},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP, 313},
    {SX_TRAP_ID_IPV6_UNSPECIFIED_SIP, 313},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR, 314},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC, 315},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP, 316},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC, 317},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET, 318},
    {SX_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL, 319},
    {SX_TRAP_ID_DISCARD_ROUTER_IRIF_EN, 320},
    {SX_TRAP_ID_DISCARD_ROUTER_ERIF_EN, 321},
    {SX_TRAP_ID_DISCARD_ROUTER_LPM4, 323},
    {SX_TRAP_ID_DISCARD_ROUTER_LPM6, 324},
    {SX_TRAP_ID_ETH_L3_LBERROR, 325},
    {SX_TRAP_ID_ETH_L3_MTUERROR, 326},
    {SX_TRAP_ID_ETH_L3_TTLERROR, 327},
    {SX_TRAP_ID_ETH_L3_URPF_PROTECTION, 329},
#endif
};
static const char       * wjh_severity_2str[WJH_SEVERITY_MAX_E + 2] = {
    [WJH_SEVERITY_NOTICE_E] = "Notice",
    [WJH_SEVERITY_WARNING_E] = "Warning",
    [WJH_SEVERITY_ERROR_E] = "Error",
    [WJH_SEVERITY_INVALID_E] = "Invalid",
};
static wjh_trap_id_item_t wjh_drop_reason_group_tunnel_trap_ids[] = {
#ifdef SDK_PRESENT
    {SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC, 402},
    {SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC, 403},
    {SX_TRAP_ID_DISCARD_DEC_PKT, 404},
    {SX_TRAP_ID_DISCARD_DEC_NVE_OPTIONS, 404},
    {SX_TRAP_ID_DECAP_ECN0, 404},
    {SX_TRAP_ID_IPIP_DECAP_ERROR, 404},
    {SX_TRAP_ID_DISCARD_ENC_ISOLATION, 405},
    {SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0, 406},
#endif
};

static wjh_trap_id_item_t wjh_drop_reason_group_tunnel_trap_ids_spc[] = {
#ifdef SDK_PRESENT
    {SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC, 402},
    {SX_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC, 403},
    {SX_TRAP_ID_DISCARD_DEC_PKT, 404},
    {SX_TRAP_ID_DISCARD_DEC_NVE_OPTIONS, 404},
    {SX_TRAP_ID_DECAP_ECN0, 404},
    {SX_TRAP_ID_IPIP_DECAP_ERROR, 404},
    {SX_TRAP_ID_DISCARD_ENC_ISOLATION, 405},
#endif
};
static wjh_trap_id_item_t wjh_drop_reason_group_acl_trap_ids[] = {
#ifdef SDK_PRESENT
    {SX_TRAP_ID_ACL_DROP, 601},
    {SX_TRAP_ID_SYS_ACL_DROP, 601},
/* All reasons using same trap
 *   {SX_TRAP_ID_ACL_DROP, 602},
 *   {SX_TRAP_ID_SYS_ACL_DROP, 602},
 *   {SX_TRAP_ID_ACL_DROP, 603},
 *   {SX_TRAP_ID_SYS_ACL_DROP, 603},
 *   {SX_TRAP_ID_ACL_DROP, 604},
 *   {SX_TRAP_ID_SYS_ACL_DROP, 605},
 */
#endif
};
static wjh_trap_id_item_t wjh_drop_reason_group_roce_trap_ids[] = {
#ifdef SDK_PRESENT
    {SX_TRAP_ID_ROCE_PRIO_MISMATCH, 701},
/* All reasons using same trap
 *  {SX_TRAP_ID_ROCE_PRIO_MISMATCH, 702},
 *  {SX_TRAP_ID_ROCE_PRIO_MISMATCH, 703},
 */
#endif
};
static wjh_trap_id_item_t wjh_drop_reason_group_buffer_trap_ids[] = {
#ifdef SDK_PRESENT
    {SX_TRAP_ID_ACL_MAX, 503},
/* All reasons using same trap
 *   {SX_TRAP_ID_ACL_MAX, 504},
 */
#endif
};

wjh_drop_reason_group_trap_ids_item_t wjh_drop_reason_group_l2_trap_ids_spc_item = {
    wjh_drop_reason_group_l2_trap_ids_spc,
    sizeof(wjh_drop_reason_group_l2_trap_ids_spc) / sizeof(wjh_drop_reason_group_l2_trap_ids_spc[0]),
    WJH_DB_L2_DROP_REASON_STR
};

wjh_drop_reason_group_trap_ids_item_t wjh_drop_reason_group_tunnel_trap_ids_spc_item = {
    wjh_drop_reason_group_tunnel_trap_ids_spc,
    sizeof(wjh_drop_reason_group_tunnel_trap_ids_spc) / sizeof(wjh_drop_reason_group_tunnel_trap_ids_spc[0]),
    WJH_DB_TUNNEL_DROP_REASON_STR
};


static wjh_drop_reason_group_trap_ids_item_t wjh_drop_reason_group_trap_ids[WJH_DROP_REASON_GROUP_NUM] = {
    {
        wjh_drop_reason_group_buffer_trap_ids,
        sizeof(wjh_drop_reason_group_buffer_trap_ids) / sizeof(wjh_drop_reason_group_buffer_trap_ids[0]),
        WJH_DB_BUFFER_DROP_REASON_STR
    },

    {
        wjh_drop_reason_group_acl_trap_ids,
        sizeof(wjh_drop_reason_group_acl_trap_ids) / sizeof(wjh_drop_reason_group_acl_trap_ids[0]),
        WJH_DB_ACL_DROP_REASON_STR,
    },

    {
        NULL,
        0,
        WJH_DB_L1_DROP_REASON_STR
    },

    {
        wjh_drop_reason_group_l2_trap_ids,
        sizeof(wjh_drop_reason_group_l2_trap_ids) / sizeof(wjh_drop_reason_group_l2_trap_ids[0]),
        WJH_DB_L2_DROP_REASON_STR,
    },

    {
        wjh_drop_reason_group_router_trap_ids,
        sizeof(wjh_drop_reason_group_router_trap_ids) / sizeof(wjh_drop_reason_group_router_trap_ids[0]),
        WJH_DB_ROUTER_DROP_REASON_STR
    },

    {
        wjh_drop_reason_group_tunnel_trap_ids,
        sizeof(wjh_drop_reason_group_tunnel_trap_ids) / sizeof(wjh_drop_reason_group_tunnel_trap_ids[0]),
        WJH_DB_TUNNEL_DROP_REASON_STR
    },

    {
        wjh_drop_reason_group_roce_trap_ids,
        sizeof(wjh_drop_reason_group_roce_trap_ids) / sizeof(wjh_drop_reason_group_roce_trap_ids[0]),
        WJH_DB_ROCE_DROP_REASON_STR
    }
};
static cl_plock_t                            wjh_db_rwlock_s = {
    .lock = PTHREAD_RWLOCK_INITIALIZER,
    .state = CL_INITIALIZED
};

static const char* wjh_channel_type_str_s[] = {
    [WJH_USER_CHANNEL_TAILDROP_E] = "Tail Drop",
    [WJH_USER_CHANNEL_CYCLIC_E] = "Cyclic",
    [WJH_USER_CHANNEL_AGGREGATE_E] = "Aggregate",
    [WJH_USER_CHANNEL_CYCLIC_AND_AGGREGATE_E] = "Cyclic and Aggregate",
};

static const char* wjh_drop_reason_group_str_s[] = {
    [WJH_DROP_REASON_GROUP_BUFFER_E] = "Buffer",
    [WJH_DROP_REASON_GROUP_ACL_E] = "ACL",
    [WJH_DROP_REASON_GROUP_L1_E] = "L1",
    [WJH_DROP_REASON_GROUP_L2_E] = "L2",
    [WJH_DROP_REASON_GROUP_ROUTER_E] = "Router",
    [WJH_DROP_REASON_GROUP_TUNNEL_E] = "Tunnel",
    [WJH_DROP_REASON_GROUP_ROCE_E] = "ROCE",
};

static const char* wjh_buffer_drop_reason_str_s[] = {
    [WJH_DROP_REASON_ID_TAIL_DROP_E - WJH_DROP_REASON_ID_TAIL_DROP_E] = "Tail drop",
    [WJH_DROP_REASON_ID_WRED_E - WJH_DROP_REASON_ID_TAIL_DROP_E] = "WRED",
    [WJH_DROP_REASON_ID_ING_TC_CONGESTION - WJH_DROP_REASON_ID_TAIL_DROP_E] = "Port TC Congestion Threshold Crossed",
    [WJH_DROP_REASON_ID_EGR_TC_LATENCY - WJH_DROP_REASON_ID_TAIL_DROP_E] = "Packet Latency Threshold Crossed",
};

static const char* wjh_roce_drop_reason_str_s[] = {
    [WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY -
     WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY] = "RoCE traffic with wrong priority",
    [WJH_DROP_REASON_ID_NON_ROCE_ON_ROCE_PRIORITY -
     WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY] = "Non RoCE traffic on RoCE priority",
    [WJH_DROP_REASON_ID_ROCE_FLOOD - WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY] = "RoCE flood traffic",
};

/************************************************
 *  Local function declarations
 ***********************************************/
static boolean_t __wjh_db_validate_drop_reason(const uint32_t drop_reason_group, const wjh_drop_reason_id_t reason_id);
static uint32_t __wjh_db_get_drop_reason_index(const uint32_t drop_reason_group, const wjh_drop_reason_id_t reason_id);
static wjh_status_t __wjh_db_configure_init(wjh_db_t *db_p);
static void __wjh_db_free_desc_strs(wjh_db_t *db_p);
static wjh_status_t __wjh_db_open_xml_file(const char       *xml_file_path,
                                           sx_xml_reader_t **reader_pp,
                                           sx_xml_parser_t **parser_pp,
                                           sx_xml_tree_t   **tree_pp);
static wjh_status_t __wjh_db_severity_str_to_enum(const char    * severity_str,
                                                  wjh_severity_e *severity_p);
static wjh_status_t __wjh_db_parse_reason_info(sx_xml_element_t     *elem,
                                               char const          **reason_str,
                                               char const          **description_str,
                                               wjh_drop_reason_id_t *reason_id_p,
                                               wjh_severity_e       *severity_p,
                                               wjh_event_type_e     *event_type_p);
static wjh_status_t __wjh_db_parse_drop_reasons(wjh_db_t      *db_p,
                                                sx_xml_tree_t *tree_p);
static wjh_status_t __wjh_db_set_drop_reason_str(wjh_db_t                  *db_p,
                                                 const wjh_drop_reason_id_t reason_id,
                                                 char const                *reason_str,
                                                 char const                *description_str,
                                                 wjh_severity_e             severity,
                                                 wjh_event_type_e           event_type,
                                                 const uint32_t             drop_reason_group);


/************************************************
 *  Function implementations
 ***********************************************/

static const char* __wjh_enum_to_str(int idx, int min, int max, const char** str_array)
{
    if ((idx >= min) && (idx <= max) && (str_array[idx] != NULL)) {
        return str_array[idx];
    }

    return "Unknown";
}

static void __wjh_bitmap_to_str(uint8_t      bits,
                                int          min,
                                int          max,
                                const char** str_array,
                                boolean_t    relative_idx,
                                int          ret_str_size,
                                char       * ret_str)
{
    int         i = 0;
    int         start = 0;
    int         str_len = 0;
    int         write_len = 0;
    const char* str = NULL;

    if (ret_str_size <= 1) {
        return;
    }

    ret_str[0] = 0;
    for (i = min; i <= max; i++) {
        if (start >= (ret_str_size - 1)) {
            break;
        }

        if (!((bits >> (i - min)) & 0x1)) {
            continue;
        }

        if (relative_idx) {
            str = str_array[i - min];
        } else {
            str = str_array[i];
        }

        if (str == NULL) {
            continue;
        }

        str_len = strlen(str);
        if (start != 0) {
            /* It's not the first string, need to insert comma at the beginning. */
            str_len += 1;
        }
        /* The bytes written by snprintf include the NULL terminator */
        write_len = str_len + 1;
        if (write_len > (ret_str_size - start)) {
            write_len = ret_str_size - start;
        }
        if (start == 0) {
            snprintf(ret_str, write_len, "%s", str);
        } else {
            snprintf(ret_str + start, write_len, ",%s", str);
        }
        start += (write_len - 1);
    }

    if (ret_str[0] == 0) {
        snprintf(ret_str, ret_str_size, "None");
    }
}

wjh_status_t __wjh_db_configure_init(wjh_db_t *db_p)
{
    wjh_status_t         err = WJH_STATUS_SUCCESS;
    uint32_t             i = 0;
    uint32_t             j = 0;
    wjh_trap_id_t        trap_id = 0;
    wjh_drop_reason_id_t reason_id = 0;
    uint32_t             index = 0;

    memset(db_p, 0, sizeof(*db_p));

    for (i = 0; i < WJH_DROP_REASON_GROUP_NUM; ++i) {
        db_p->drop_reason_groups[i].drop_reason_group = i;
        db_p->drop_reason_groups[i].trap_ids = wjh_drop_reason_group_trap_ids[i].trap_ids;
        db_p->drop_reason_groups[i].trap_id_num = wjh_drop_reason_group_trap_ids[i].num;
#ifdef WJH_EBPF_PRESENT
        db_p->drop_reason_groups[i].aggregation_ebpf_prog_fd = -1;
        db_p->drop_reason_groups[i].aggregation_ebpf_map_fd = -1;
        db_p->drop_reason_groups[i].aggregation_ebpf_prog_fd_attached = FALSE;
#endif
        for (j = 0; j < wjh_drop_reason_group_trap_ids[i].num; ++j) {
            trap_id = wjh_drop_reason_group_trap_ids[i].trap_ids[j].trap_id;
            reason_id = wjh_drop_reason_group_trap_ids[i].trap_ids[j].reason_id;
            if (!__wjh_db_validate_drop_reason(i, reason_id)) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Invalid drop reason ID %u for trap %u\n",
                            reason_id, trap_id);
                goto out;
            }
            db_p->trap_id_attrs[trap_id].drop_reason_group = i;
            index = __wjh_db_get_drop_reason_index(i, reason_id);
            if (index >= WJH_DROP_REASONS_NUM) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Invalid drop reason index %u for group %u reason_id %u\n",
                            index, i, reason_id);
                goto out;
            }
            db_p->trap_id_attrs[trap_id].drop_reason = &(db_p->drop_reasons[index]);
        }
    }

    for (i = 0; i < WJH_USER_CHANNEL_MAX_NUM; ++i) {
        db_p->user_channels[i].channel_id = i;
        cl_spinlock_construct(&(db_p->user_channels[i].lock));
        cl_thread_construct(&(db_p->user_channels[i].thread));
        db_p->user_channels[i].stop_thread = TRUE;
        db_p->user_channels[i].cmd_event_fd = -1;
    }

    /* init all entries by invalid index */
    for (i = 0; i < WJH_NETDEV_TYPE_NUM_OF_TYPES; i++) {
        for (j = 0; j <= MAX_PHYPORT_NUM; j++) {
            db_p->log_port_attr_db[i][j].if_index = WJH_INVALID_IF_INDEX;
        }
    }

#ifdef SDK_PRESENT
    db_p->buffer_drop_db.span_session_policer_id = SX_POLICER_ID_INVALID;
#endif

out:
    return err;
}

static void __wjh_db_free_desc_strs(wjh_db_t *db_p)
{
    uint32_t i = 0;

    for (i = 0; i < WJH_DROP_REASONS_NUM; ++i) {
        if (db_p->drop_reasons[i].reason) {
            CL_FREE_N_NULL(db_p->drop_reasons[i].reason);
        }
        if (db_p->drop_reasons[i].description) {
            CL_FREE_N_NULL(db_p->drop_reasons[i].description);
        }
        db_p->drop_reasons[i].id = 0;
        db_p->drop_reasons[i].severity = WJH_SEVERITY_MIN_E;
    }
}

static wjh_status_t __wjh_db_open_xml_file(const char       *xml_file_path,
                                           sx_xml_reader_t **reader_pp,
                                           sx_xml_parser_t **parser_pp,
                                           sx_xml_tree_t   **tree_pp)
{
    wjh_status_t     err = WJH_STATUS_SUCCESS;
    sx_xml_reader_t *reader_p = NULL;
    sx_xml_parser_t *parser_p = NULL;
    sx_xml_tree_t   *tree_p = NULL;

    parser_p = sx_xml_parser_create();
    if (parser_p == NULL) {
        WJH_LOG_ERR("Unable to create XML parser\n");
        err = WJH_STATUS_ERROR;
        goto err_out;
    }

    sx_xml_parser_ignore_whitespaces(parser_p);

    reader_p = sx_xml_reader_create(xml_file_path);
    if (reader_p == NULL) {
        WJH_LOG_ERR("Unable to load file %s (file not exists or corrupted )\n", xml_file_path);
        err = WJH_STATUS_ERROR;
        goto err_out;
    }

    tree_p = sx_xml_tree_create(parser_p, reader_p);
    if (tree_p == NULL) {
        WJH_LOG_ERR("Unable to parse file %s \n", xml_file_path);
        err = WJH_STATUS_ERROR;
        goto err_out;
    }

    *reader_pp = reader_p;
    *parser_pp = parser_p;
    *tree_pp = tree_p;
    goto out;

err_out:
    if (reader_p != NULL) {
        sx_xml_reader_free(reader_p);
    }

    if (parser_p != NULL) {
        sx_xml_parser_free(parser_p);
    }

out:
    return err;
}

static wjh_status_t __wjh_db_severity_str_to_enum(const char* severity_str, wjh_severity_e *severity_p)
{
    wjh_status_t   err = WJH_STATUS_SUCCESS;
    wjh_severity_e i = 0;

    for (i = WJH_SEVERITY_MIN_E + 1; i <= WJH_SEVERITY_MAX_E + 1; i++) {
        if (!strcmp(wjh_severity_2str[i], severity_str)) {
            *severity_p = i;
            goto out;
        }
    }

    err = WJH_STATUS_ERROR;

out:
    return err;
}

static wjh_status_t __wjh_db_parse_reason_info(sx_xml_element_t     *elem,
                                               char const          **reason_str,
                                               char const          **description_str,
                                               wjh_drop_reason_id_t *reason_id_p,
                                               wjh_severity_e       *severity_p,
                                               wjh_event_type_e     *event_type_p)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    sx_xml_element_t *reason_id_elem = NULL;
    sx_xml_element_t *reason_elem = NULL;
    sx_xml_element_t *description_elem = NULL;
    sx_xml_element_t *severity_elem = NULL;
    sx_xml_element_t *event_type_elem = NULL;
    char const       *id_contents = NULL;
    char const       *reason_contents = NULL;
    char const       *description_contents = NULL;
    char const       *severity_contents = NULL;
    char const       *event_type_contents = NULL;
    int               reason_id_value = 0;
    int               event_type_value = 0;

    reason_id_elem = sx_xml_element_by_name_get(elem, WJH_DB_REASON_ID_STR);
    if (reason_id_elem == NULL) {
        WJH_LOG_ERR("Could not find sub-element %s in element %s\n",
                    WJH_DB_REASON_ID_STR, WJH_DB_REASON_INFO_STR);
        err = WJH_STATUS_ERROR;
        goto out;
    }
    id_contents = sx_xml_element_content_get(reason_id_elem);
    if (id_contents == NULL) {
        WJH_LOG_ERR("Element %s contains empty value\n", WJH_DB_REASON_ID_STR);
        err = WJH_STATUS_ERROR;
        goto out;
    }
    reason_id_value = strtol(id_contents, NULL, 10);

    reason_elem = sx_xml_element_by_name_get(elem, WJH_DB_REASON_STR);
    if (reason_elem == NULL) {
        WJH_LOG_ERR("Could not find sub-element %s in element %s\n",
                    WJH_DB_REASON_STR, WJH_DB_REASON_INFO_STR);
        err = WJH_STATUS_ERROR;
        goto out;
    }
    reason_contents = sx_xml_element_content_get(reason_elem);

    description_elem = sx_xml_element_by_name_get(elem, WJH_DB_DESCRIPTION_STR);
    if (description_elem == NULL) {
        WJH_LOG_ERR("Could not find sub-element %s in element %s\n",
                    WJH_DB_DESCRIPTION_STR, WJH_DB_REASON_INFO_STR);
        err = WJH_STATUS_ERROR;
        goto out;
    }
    description_contents = sx_xml_element_content_get(description_elem);
    if (description_contents == NULL) {
        description_contents = WJH_DB_EMPTY_STR;
    }

    if (reason_id_value < WJH_L1_PORT_DOWN_REASON_ID_MIN) {
        severity_elem = sx_xml_element_by_name_get(elem, WJH_DB_SEVERITY_STR);
        if (severity_elem == NULL) {
            WJH_LOG_ERR("Could not find sub-element %s in element %s\n",
                        WJH_DB_SEVERITY_STR, WJH_DB_REASON_INFO_STR);
            err = WJH_STATUS_ERROR;
            goto out;
        }
        severity_contents = sx_xml_element_content_get(severity_elem);
        err = __wjh_db_severity_str_to_enum(severity_contents, severity_p);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("Severity string [%s] is invalid.\n", severity_contents);
            goto out;
        }

        event_type_elem = sx_xml_element_by_name_get(elem, WJH_DB_EVENT_TYPE_STR);
        if (event_type_elem == NULL) {
            WJH_LOG_NTC(
                "Could not find sub-element %s in element %s, reason_id %d. The XML configuration file is out of date.\n",
                WJH_DB_EVENT_TYPE_STR,
                WJH_DB_REASON_INFO_STR,
                reason_id_value);
        } else {
            event_type_contents = sx_xml_element_content_get(event_type_elem);
            if (event_type_contents == NULL) {
                WJH_LOG_ERR("Element %s contains empty value\n", WJH_DB_EVENT_TYPE_STR);
                err = WJH_STATUS_ERROR;
                goto out;
            }
            event_type_value = strtol(event_type_contents, NULL, 10);
            if ((event_type_value < WJH_EVENT_MIN_E) || (event_type_value > WJH_EVENT_MAX_E)) {
                WJH_LOG_ERR("Invalid event type %d.\n", event_type_value);
                err = WJH_STATUS_ERROR;
                goto out;
            }
            *event_type_p = (wjh_event_type_e)event_type_value;
        }
    }

    *reason_str = reason_contents;
    *description_str = description_contents;
    *reason_id_p = reason_id_value;

out:
    return err;
}

static boolean_t __wjh_db_validate_drop_reason(const uint32_t drop_reason_group, const wjh_drop_reason_id_t reason_id)
{
    boolean_t is_validated = FALSE;

    switch (drop_reason_group) {
    case WJH_DROP_REASON_GROUP_L1_E:
        is_validated = ((reason_id >= WJH_L1_PORT_DOWN_REASON_ID_MIN) &&
                        (reason_id < (WJH_L1_PORT_DOWN_REASON_ID_MIN + WJH_L1_PORT_DOWN_REASON_NUM))) ||
                       ((reason_id >= WJH_L1_DROP_REASON_ID_MIN) &&
                        (reason_id < (WJH_L1_DROP_REASON_ID_MIN + WJH_L1_DROP_REASON_NUM)));
        break;

    case WJH_DROP_REASON_GROUP_ACL_E:
        is_validated = (reason_id >= WJH_ACL_DROP_REASON_ID_MIN) &&
                       (reason_id < (WJH_ACL_DROP_REASON_ID_MIN + WJH_ACL_DROP_REASON_NUM));
        break;

    case WJH_DROP_REASON_GROUP_BUFFER_E:
        is_validated = (reason_id >= WJH_BUFFER_DROP_REASON_ID_MIN) &&
                       (reason_id < (WJH_BUFFER_DROP_REASON_ID_MIN + WJH_BUFFER_DROP_REASON_NUM));
        break;

    case WJH_DROP_REASON_GROUP_L2_E:
        is_validated = (reason_id >= WJH_L2_DROP_REASON_ID_MIN) &&
                       (reason_id < (WJH_L2_DROP_REASON_ID_MIN + WJH_L2_DROP_REASON_NUM));
        break;

    case WJH_DROP_REASON_GROUP_ROUTER_E:
        is_validated = (reason_id >= WJH_ROUTER_DROP_REASON_ID_MIN) &&
                       (reason_id < (WJH_ROUTER_DROP_REASON_ID_MIN + WJH_ROUTER_DROP_REASON_NUM));
        break;

    case WJH_DROP_REASON_GROUP_TUNNEL_E:
        is_validated = (reason_id >= WJH_TUNNEL_DROP_REASON_ID_MIN) &&
                       (reason_id < (WJH_TUNNEL_DROP_REASON_ID_MIN + WJH_TUNNEL_DROP_REASON_NUM));
        break;

    case WJH_DROP_REASON_GROUP_ROCE_E:
        is_validated = (reason_id >= WJH_ROCE_DROP_REASON_ID_MIN) &&
                       (reason_id < (WJH_ROCE_DROP_REASON_ID_MIN + WJH_ROCE_DROP_REASON_NUM));
        break;

    default:
        WJH_LOG_ERR("invalid drop reason group %u\n", drop_reason_group);
        break;
    }

    return is_validated;
}

static wjh_status_t __wjh_db_parse_drop_reasons(wjh_db_t *db_p, sx_xml_tree_t *tree_p)
{
    wjh_status_t                           err = WJH_STATUS_SUCCESS;
    sx_xml_element_t                      *drop_reason_elem = NULL;
    sx_xml_list_t                         *list = NULL;
    sx_xml_list_t                         *list_head = NULL;
    sx_xml_element_t                      *reason_info_elem = NULL;
    char const                            *reason_str = NULL;
    char const                            *description_str = NULL;
    wjh_drop_reason_id_t                   reason_id = 0;
    wjh_severity_e                         severity = WJH_SEVERITY_INVALID_E;
    wjh_event_type_e                       event_type = WJH_EVENT_INVALID_E;
    uint32_t                               i = 0;
    wjh_drop_reason_group_trap_ids_item_t *item_p = NULL;

    for (i = 0; i < WJH_DROP_REASON_GROUP_NUM; ++i) {
        item_p = &wjh_drop_reason_group_trap_ids[i];

        if (item_p->drop_reason_group_xml_name == NULL) {
            continue;
        }

        drop_reason_elem = sx_xml_element_by_name_get(sx_xml_tree_root_element_get(tree_p),
                                                      item_p->drop_reason_group_xml_name);

        if (drop_reason_elem == NULL) {
            WJH_LOG_ERR("XML element %s does not exist\n", item_p->drop_reason_group_xml_name);
            err = WJH_STATUS_ERROR;
            goto out;
        }

        list_head = sx_xml_element_shallow_list_by_name_get(drop_reason_elem, WJH_DB_REASON_INFO_STR);
        if (list_head == NULL) {
            WJH_LOG_ERR("Could not find %s sub-element list in element %s\n",
                        WJH_DB_REASON_INFO_STR, item_p->drop_reason_group_xml_name);
            err = WJH_STATUS_ERROR;
            goto out;
        }

        list = list_head;
        while (list != NULL) {
            reason_info_elem = sx_xml_element_list_data(list);
            err = __wjh_db_parse_reason_info(reason_info_elem,
                                             &reason_str,
                                             &description_str,
                                             &reason_id,
                                             &severity,
                                             &event_type);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_db_parse_reason_info failed, err: %d\n", err);
                goto out;
            }

            if (!__wjh_db_validate_drop_reason(i, reason_id)) {
                WJH_LOG_ERR("Invalid drop reason ID %u in element %s\n",
                            reason_id,
                            item_p->drop_reason_group_xml_name);
                err = WJH_STATUS_ERROR;
                goto out;
            }

            err = __wjh_db_set_drop_reason_str(db_p, reason_id, reason_str, description_str, severity, event_type, i);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("__wjh_db_set_drop_reason_str failed, err: %d\n", err);
                goto out;
            }

            list = sx_xml_element_list_next(list);
        }

        sx_xml_element_shallow_list_free(list_head);
        list_head = NULL;
    }

out:
    if (list_head != NULL) {
        sx_xml_element_shallow_list_free(list_head);
    }

    return err;
}

static uint32_t __wjh_db_get_drop_reason_index(const uint32_t drop_reason_group, const wjh_drop_reason_id_t reason_id)
{
    uint32_t index = WJH_DROP_REASONS_NUM;

    switch (drop_reason_group) {
    case WJH_DROP_REASON_GROUP_L1_E:
        if ((reason_id >= WJH_L1_PORT_DOWN_REASON_ID_MIN) &&
            (reason_id < (WJH_L1_PORT_DOWN_REASON_ID_MIN + WJH_L1_PORT_DOWN_REASON_NUM))) {
            index = reason_id - WJH_L1_PORT_DOWN_REASON_ID_MIN + WJH_L1_PORT_DOWN_REASON_INDEX_MIN;
        } else {
            index = reason_id - WJH_L1_DROP_REASON_ID_MIN + WJH_L1_DROP_REASON_INDEX_MIN;
        }
        break;

    case WJH_DROP_REASON_GROUP_ACL_E:
        index = reason_id - WJH_ACL_DROP_REASON_ID_MIN + WJH_ACL_DROP_REASON_INDEX_MIN;
        break;

    case WJH_DROP_REASON_GROUP_BUFFER_E:
        index = reason_id - WJH_BUFFER_DROP_REASON_ID_MIN + WJH_BUFFER_DROP_REASON_INDEX_MIN;
        break;

    case WJH_DROP_REASON_GROUP_L2_E:
        index = reason_id - WJH_L2_DROP_REASON_ID_MIN + WJH_L2_DROP_REASON_INDEX_MIN;
        break;

    case WJH_DROP_REASON_GROUP_ROUTER_E:
        index = reason_id - WJH_ROUTER_DROP_REASON_ID_MIN + WJH_ROUTER_DROP_REASON_INDEX_MIN;
        break;

    case WJH_DROP_REASON_GROUP_TUNNEL_E:
        index = reason_id - WJH_TUNNEL_DROP_REASON_ID_MIN + WJH_TUNNEL_DROP_REASON_INDEX_MIN;
        break;

    case WJH_DROP_REASON_GROUP_ROCE_E:
        index = reason_id - WJH_ROCE_DROP_REASON_ID_MIN + WJH_ROCE_DROP_REASON_INDEX_MIN;
        break;

    default:
        WJH_LOG_ERR("invalid drop reason group %u\n", drop_reason_group);
        break;
    }

    return index;
}

static wjh_status_t __wjh_db_set_drop_reason_str(wjh_db_t                  *db_p,
                                                 const wjh_drop_reason_id_t reason_id,
                                                 char const                *reason_str,
                                                 char const                *description_str,
                                                 wjh_severity_e             severity,
                                                 wjh_event_type_e           event_type,
                                                 const uint32_t             drop_reason_group)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    char        *tmp_reason_str = NULL;
    char        *tmp_description_str = NULL;
    uint32_t     index = 0;

    if (reason_str != NULL) {
        err = wjh_str_dup(&tmp_reason_str, reason_str);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_str_dup failed, err: %d\n", err);
            goto out;
        }
    }

    if (description_str != NULL) {
        err = wjh_str_dup(&tmp_description_str, description_str);
        if (WJH_CHECK_FAIL(err)) {
            WJH_LOG_ERR("wjh_str_dup failed, err: %d\n", err);
            goto out;
        }
    }

    index = __wjh_db_get_drop_reason_index(drop_reason_group, reason_id);
    if (index >= WJH_DROP_REASONS_NUM) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Invalid drop reason index %u for group %u reason_id %u\n",
                    index, drop_reason_group, reason_id);
        goto out;
    }
    if (tmp_reason_str != NULL) {
        db_p->drop_reasons[index].reason = tmp_reason_str;
    }
    if (tmp_description_str != NULL) {
        db_p->drop_reasons[index].description = tmp_description_str;
    }
    db_p->drop_reasons[index].id = reason_id;
    db_p->drop_reasons[index].severity = severity;
    db_p->drop_reasons[index].event_type = event_type;

out:
    if (WJH_CHECK_FAIL(err)) {
        if (tmp_reason_str != NULL) {
            cl_free(tmp_reason_str);
        }

        if (tmp_description_str != NULL) {
            cl_free(tmp_description_str);
        }
    }
    return err;
}

static wjh_status_t __wjh_db_drop_reasons_db_init()
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    #ifdef SDK_PRESENT
    wjh_hwd_info_db_t *hw_info_db_p = NULL;
    hw_info_db_p = &(wjh_hw_db_s.hw_info_db);

    if ((hw_info_db_p->chip_type == SXD_CHIP_TYPE_SPECTRUM) ||
        (hw_info_db_p->chip_type == SXD_CHIP_TYPE_SPECTRUM_A1) ||
        (hw_info_db_p->chip_type == SXD_CHIP_TYPE_SPECTRUM2) || (hw_info_db_p->chip_type == SXD_CHIP_TYPE_SPECTRUM3)) {
        wjh_drop_reason_group_trap_ids[WJH_DROP_REASON_GROUP_L2_E] = wjh_drop_reason_group_l2_trap_ids_spc_item;
        wjh_drop_reason_group_trap_ids[WJH_DROP_REASON_GROUP_TUNNEL_E] =
            wjh_drop_reason_group_tunnel_trap_ids_spc_item;
    }
    #endif
    return err;
}

wjh_status_t wjh_db_init(void)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    cl_status_t  cl_err = 0;

    err = __wjh_db_drop_reasons_db_init();
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_db_drop_reasons_db_init failed, err: %d\n", err);
        goto out;
    }

    err = __wjh_db_configure_init(&wjh_db_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_db_init failed, err: %d\n", err);
        goto out;
    }

    cl_err = id_allocator_init(WJH_FILTER_NUM_MAX, WJH_DB_FILTER_POOL_GROW_SIZE, 0, &(wjh_db_s.filter_id_allocator));
    if (cl_err != CL_SUCCESS) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to initialize id_allocator for filter pool, err = [%s]\n", CL_STATUS_MSG(cl_err));
        goto out;
    }

    cl_err = CL_QPOOL_INIT(&wjh_db_s.filter_pool,
                           WJH_DB_FILTER_POOL_MIN_SIZE,
                           WJH_FILTER_NUM_MAX,
                           WJH_DB_FILTER_POOL_GROW_SIZE,
                           sizeof(wjh_db_filter_record_t),
                           NULL,
                           NULL,
                           NULL);
    if (cl_err != CL_SUCCESS) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to create filter pool.\n");
        goto out;
    }

    cl_qmap_init(&wjh_db_s.filter_map);

    err = __wjh_db_configure_init(&wjh_tmp_db_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_db_init failed, err: %d\n", err);
        goto out;
    }

out:
    return err;
}

void wjh_db_deinit(void)
{
    wjh_db_filter_record_t *filter_record_p = NULL;
    cl_map_item_t          *filter_map_item_p = NULL;
    cl_status_t             cl_err = 0;

    __wjh_db_free_desc_strs(&wjh_db_s);

    filter_map_item_p = cl_qmap_head(&wjh_db_s.filter_map);
    while (filter_map_item_p != cl_qmap_end(&wjh_db_s.filter_map)) {
        filter_record_p = PARENT_STRUCT(filter_map_item_p, wjh_db_filter_record_t, map_item);
        filter_map_item_p = cl_qmap_next(filter_map_item_p);
        wjh_db_filter_destroy(filter_record_p);
    }

    cl_qmap_remove_all(&wjh_db_s.filter_map);

    cl_err = id_allocator_destroy(&(wjh_db_s.filter_id_allocator));
    if (cl_err != CL_SUCCESS) {
        WJH_LOG_ERR("Failed to deinit id_allocator in filter pool, err = [%s]\n",
                    CL_STATUS_MSG(cl_err));
    }
    CL_QPOOL_DESTROY(&wjh_db_s.filter_pool);
}

wjh_status_t wjh_db_deinit_resource_check(void)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    wjh_user_channel_id_t   channel_id = 0;
    wjh_db_filter_record_t *filter_record_p = NULL;
    cl_map_item_t          *filter_map_item_p = NULL;

    for (channel_id = 0; channel_id < WJH_USER_CHANNEL_MAX_NUM; ++channel_id) {
        if (wjh_db_s.user_channels[channel_id].created) {
            err = WJH_STATUS_ERROR;
            WJH_LOG_ERR("User channel %u is not destroyed, destroy it first.\n",
                        channel_id);
            goto out;
        }
    }

    filter_map_item_p = cl_qmap_head(&wjh_db_s.filter_map);
    if (filter_map_item_p != cl_qmap_end(&wjh_db_s.filter_map)) {
        filter_record_p = PARENT_STRUCT(filter_map_item_p, wjh_db_filter_record_t, map_item);
        WJH_LOG_ERR("Filter %d is not destroyed, destroy it first.\n", filter_record_p->filter_id);
        err = WJH_STATUS_ERROR;
        goto out;
    }

out:
    return err;
}

wjh_status_t wjh_db_init_hw_info()
{
    wjh_status_t       err = WJH_STATUS_SUCCESS;
    wjh_hwd_info_db_t *hw_info_db_p = NULL;

    memset(&wjh_hw_db_s, 0, sizeof(wjh_hw_db_s));

    hw_info_db_p = &(wjh_hw_db_s.hw_info_db);

    /* Read the MGIR register and set the chip type into the db*/
    err = wjh_get_chip_type(&hw_info_db_p->chip_type);
    if (err != WJH_STATUS_SUCCESS) {
        WJH_LOG_ERR("wjh db init hardware info failed, err: %u\n", err);
        goto out;
    }

#ifdef SDK_PRESENT
    if ((hw_info_db_p->chip_type == SXD_CHIP_TYPE_SPECTRUM) ||
        (hw_info_db_p->chip_type == SXD_CHIP_TYPE_SPECTRUM_A1)) {
        hw_info_db_p->wjh_dev_cb = wjh_dev_cb_sdk_spc;
    } else if ((hw_info_db_p->chip_type == SXD_CHIP_TYPE_SPECTRUM2) ||
               (hw_info_db_p->chip_type == SXD_CHIP_TYPE_SPECTRUM3)) {
        hw_info_db_p->wjh_dev_cb = wjh_dev_cb_sdk_spc2;
    } else {
        hw_info_db_p->wjh_dev_cb = wjh_dev_cb_sdk_spc4;
    }
#endif

out:
    return err;
}

static wjh_status_t __wjh_db_drop_reason_conf_check(wjh_db_t *db_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint32_t     i = 0;

    for (i = 1; i < WJH_ACL_DROP_REASON_NUM; i++) {
        if (db_p->drop_reasons[i + WJH_ACL_DROP_REASON_INDEX_MIN].severity !=
            db_p->drop_reasons[WJH_ACL_DROP_REASON_INDEX_MIN].severity) {
            WJH_LOG_WRN("WJH ACL Drop Reason[%s] severity does not equal to the first Reason[%s] severity,"
                        "Will take the first ACL Drop Reason severity to enable/disable the group,"
                        "Please make sure all ACL Drop Reason severity are the same\n",
                        db_p->drop_reasons[i + WJH_ACL_DROP_REASON_INDEX_MIN].reason,
                        db_p->drop_reasons[WJH_ACL_DROP_REASON_INDEX_MIN].reason);
        }
    }

    return err;
}

wjh_status_t wjh_db_drop_reason_descriptions_load(const char *xml_file_path)
{
    wjh_status_t     err = WJH_STATUS_SUCCESS;
    sx_xml_reader_t *reader_p = NULL;
    sx_xml_parser_t *parser_p = NULL;
    sx_xml_tree_t   *tree_p = NULL;
    uint32_t         i = 0;

    WJH_CHECK_NULL_PTR(xml_file_path, xml_file_path);

    err = __wjh_db_open_xml_file(xml_file_path, &reader_p, &parser_p, &tree_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_db_open_xml_file failed, err: %d\n", err);
        goto out;
    }

    err = __wjh_db_parse_drop_reasons(&wjh_tmp_db_s, tree_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_db_parse_drop_reasons failed, err: %d\n", err);
        goto out;
    }

    err = __wjh_db_drop_reason_conf_check(&wjh_tmp_db_s);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("__wjh_db_drop_reason_conf_check failed, err: %d\n", err);
        goto out;
    }

    cl_plock_excl_acquire(&wjh_db_rwlock_s);
    __wjh_db_free_desc_strs(&wjh_db_s);

    for (i = 0; i < WJH_DROP_REASONS_NUM; ++i) {
        wjh_db_s.drop_reasons[i].reason = wjh_tmp_db_s.drop_reasons[i].reason;
        wjh_tmp_db_s.drop_reasons[i].reason = NULL;

        wjh_db_s.drop_reasons[i].description = wjh_tmp_db_s.drop_reasons[i].description;
        wjh_tmp_db_s.drop_reasons[i].description = NULL;

        wjh_db_s.drop_reasons[i].severity = wjh_tmp_db_s.drop_reasons[i].severity;
        wjh_tmp_db_s.drop_reasons[i].severity = WJH_SEVERITY_MIN_E;

        wjh_db_s.drop_reasons[i].id = wjh_tmp_db_s.drop_reasons[i].id;
        wjh_tmp_db_s.drop_reasons[i].id = 0;

        if (wjh_tmp_db_s.drop_reasons[i].event_type != WJH_EVENT_INVALID_E) {
            wjh_db_s.drop_reasons[i].event_type = wjh_tmp_db_s.drop_reasons[i].event_type;
            wjh_tmp_db_s.drop_reasons[i].id = WJH_EVENT_INVALID_E;
        }
    }
    cl_plock_release(&wjh_db_rwlock_s);

out:
    if (WJH_CHECK_FAIL(err)) {
        __wjh_db_free_desc_strs(&wjh_tmp_db_s);
    }

    if (tree_p != NULL) {
        sx_xml_tree_free(tree_p);
    }

    if (reader_p != NULL) {
        sx_xml_reader_free(reader_p);
    }

    if (parser_p != NULL) {
        sx_xml_parser_free(parser_p);
    }

    return err;
}

void wjh_db_drop_reason_group_get(const wjh_drop_reason_group_e    drop_reason_group,
                                  wjh_drop_reason_group_record_t **item_pp)
{
    *item_pp = &wjh_db_s.drop_reason_groups[drop_reason_group];
}

#ifdef SDK_PRESENT
void wjh_db_buffer_drop_get(wjh_buffer_drop_db_t **db_pp)
{
    *db_pp = &wjh_db_s.buffer_drop_db;
}

void wjh_db_buffer_drop_set(wjh_buffer_drop_db_t *db_p)
{
    wjh_db_s.buffer_drop_db = *db_p;
}

wjh_status_t wjh_db_buffer_drop_map_shm_data_to_db(
    wjh_buffer_drop_reason_group_shm_data_t *buffer_drop_reason_shm_data_p,
    wjh_buffer_drop_db_t                    *db_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint32_t     idx = 0;

    if (buffer_drop_reason_shm_data_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("wjh shm data is null, err: %u\n", err);
        goto out;
    }

    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("wjh db is null, err: %u\n", err);
        goto out;
    }

    db_p->span_session_id = buffer_drop_reason_shm_data_p->span_session_id;
    db_p->recirculation_port = buffer_drop_reason_shm_data_p->recirculation_port;
    db_p->span_session_policer_id = buffer_drop_reason_shm_data_p->span_session_policer_id;

    for (idx = 0; idx < WJH_BUFFER_DROP_ACL_NUM; idx++) {
        db_p->acl_list[idx] = buffer_drop_reason_shm_data_p->acl_list[idx];
        db_p->acl_group_list[idx] = buffer_drop_reason_shm_data_p->acl_group_list[idx];
        db_p->acl_region_list[idx] = buffer_drop_reason_shm_data_p->acl_region_list[idx];
        db_p->rules_per_region[idx] = buffer_drop_reason_shm_data_p->rules_per_region[idx];
    }

    for (idx = 0; idx < WJH_BUFFER_DROP_RULE_NUM; idx++) {
        db_p->key_handle[idx] = buffer_drop_reason_shm_data_p->key_handle[idx];
        db_p->rule_offset[idx] = buffer_drop_reason_shm_data_p->rule_offset[idx];
    }

out:
    return err;
}

wjh_status_t wjh_db_map_buffer_drop_db_to_shm_data(wjh_buffer_drop_db_t                    *db_p,
                                                   wjh_buffer_drop_reason_group_shm_data_t *buffer_drop_reason_shm_data_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint32_t     idx = 0;

    if (db_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("wjh db is null, err: %u\n", err);
        goto out;
    }

    if (buffer_drop_reason_shm_data_p == NULL) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("wjh shm data is null, err: %u\n", err);
        goto out;
    }

    buffer_drop_reason_shm_data_p->span_session_id = db_p->span_session_id;
    buffer_drop_reason_shm_data_p->recirculation_port = db_p->recirculation_port;
    buffer_drop_reason_shm_data_p->span_session_policer_id = db_p->span_session_policer_id;

    for (idx = 0; idx < WJH_BUFFER_DROP_ACL_NUM; idx++) {
        buffer_drop_reason_shm_data_p->acl_list[idx] = db_p->acl_list[idx];
        buffer_drop_reason_shm_data_p->acl_group_list[idx] = db_p->acl_group_list[idx];
        buffer_drop_reason_shm_data_p->acl_region_list[idx] = db_p->acl_region_list[idx];
        buffer_drop_reason_shm_data_p->rules_per_region[idx] = db_p->rules_per_region[idx];
    }

    for (idx = 0; idx < WJH_BUFFER_DROP_RULE_NUM; idx++) {
        buffer_drop_reason_shm_data_p->key_handle[idx] = db_p->key_handle[idx];
        buffer_drop_reason_shm_data_p->rule_offset[idx] = db_p->rule_offset[idx];
    }

out:
    return err;
}

void wjh_db_roce_drop_get(wjh_roce_drop_db_t **db_pp)
{
    *db_pp = &wjh_db_s.roce_drop_db;
}
#endif /* ifdef SDK_PRESENT */

wjh_status_t wjh_db_set_drop_reason_db_with_shm_data(const wjh_drop_reason_group_e drop_reason_group,
                                                     void                         *drop_group_shm_data_p)
{
    wjh_drop_reason_group_record_t *group_item_p = NULL;
    wjh_status_t                    err = WJH_STATUS_SUCCESS;

#ifdef SDK_PRESENT
    wjh_buffer_drop_reason_group_shm_data_t *buffer_drop_shm_data_p = NULL;
    wjh_buffer_drop_db_t                     db;
#endif

    if (drop_group_shm_data_p == NULL) {
        err = WJH_STATUS_PARAM_NULL;
        WJH_LOG_ERR("wjh db set with  shm data failed, err: %u\n", err);
        goto out;
    }

    wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);
#ifdef SDK_PRESENT
    if (drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) {
        WJH_MEM_CLR(db);
        buffer_drop_shm_data_p = (wjh_buffer_drop_reason_group_shm_data_t*)drop_group_shm_data_p;
        err = wjh_db_buffer_drop_map_shm_data_to_db(buffer_drop_shm_data_p, &db);
        if (err != WJH_STATUS_SUCCESS) {
            WJH_LOG_ERR("wjh buffer cleanup failed to map shm data to db data, err: %u\n", err);
            goto out;
        }
        wjh_db_buffer_drop_set(&db);
        group_item_p->inited = buffer_drop_shm_data_p->inited;
        group_item_p->enabled_severity_bits = buffer_drop_shm_data_p->enabled_severity_bits;
        group_item_p->bound = buffer_drop_shm_data_p->bound;
    }
#endif
out:
    return err;
}

uint8_t wjh_db_buffer_drop_reason_bits_get(uint8_t severity_bits)
{
    uint32_t                i = 0;
    uint8_t                 reason_bits = 0;
    wjh_drop_reason_item_t *drop_reason_item_p = NULL;

    if (severity_bits == 0) {
        goto out;
    }

    for (i = WJH_BUFFER_DROP_REASON_INDEX_MIN;
         i < (WJH_BUFFER_DROP_REASON_INDEX_MIN + WJH_BUFFER_DROP_REASON_NUM);
         i++) {
        wjh_db_get_drop_reason_item(i, &drop_reason_item_p);
        if (WJH_SEVERITY_CHECK(severity_bits, drop_reason_item_p->severity)) {
            WJH_BUFFER_DROP_REASON_SET(reason_bits, drop_reason_item_p->id);
        }
    }

out:
    return reason_bits;
}

wjh_status_t wjh_db_get_drop_reason_group_shm_data(const wjh_drop_reason_group_e drop_reason_group,
                                                   boolean_t                     enabled,
                                                   void                         *shm_data)
{
    wjh_status_t                      err = WJH_STATUS_SUCCESS;
    wjh_drop_reason_group_shm_data_t *shm_data_p = (wjh_drop_reason_group_shm_data_t*)shm_data;
    wjh_drop_reason_group_record_t   *group_item_p = NULL;

#ifdef SDK_PRESENT
    wjh_buffer_drop_reason_group_shm_data_t *buffer_drop_reason_shm_data_p;
    wjh_buffer_drop_db_t                    *db_p;
#endif

    wjh_db_drop_reason_group_get(drop_reason_group, &group_item_p);
#ifdef SDK_PRESENT
    if (drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) {
        buffer_drop_reason_shm_data_p =
            (wjh_buffer_drop_reason_group_shm_data_t*)&shm_data_p->wjh_buffer_drop_shm_data;
        if (enabled) {
            buffer_drop_reason_shm_data_p->inited = group_item_p->inited;
            buffer_drop_reason_shm_data_p->enabled_severity_bits = group_item_p->enabled_severity_bits;
            buffer_drop_reason_shm_data_p->drop_reason_bits = wjh_db_buffer_drop_reason_bits_get(
                group_item_p->enabled_severity_bits);
            buffer_drop_reason_shm_data_p->bound = group_item_p->bound;
            wjh_db_buffer_drop_get(&db_p);
            if (db_p == NULL) {
                err = WJH_STATUS_ERROR;
                WJH_LOG_ERR("Wjh buffer drop reason db is not valid\n");
                goto out;
            }

            err = wjh_db_map_buffer_drop_db_to_shm_data(db_p, buffer_drop_reason_shm_data_p);
            if (WJH_CHECK_FAIL(err)) {
                WJH_LOG_ERR("Wjh buffer drop reason db map to shm failed\n");
                goto out;
            }
        } else {
            memset(buffer_drop_reason_shm_data_p, 0, sizeof(*buffer_drop_reason_shm_data_p));
        }
    }
#endif
out:
    return err;
}

wjh_status_t wjh_db_free_user_channel_get(wjh_user_channel_record_t **user_channel_pp)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    int          i = 0;

    for (i = 0; i < WJH_USER_CHANNEL_MAX_NUM; ++i) {
        if (!wjh_db_s.user_channels[i].created) {
            *user_channel_pp = &wjh_db_s.user_channels[i];
            return err;
        }
    }

    err = WJH_STATUS_ENTRY_NOT_FOUND;
    return err;
}

void wjh_db_user_channel_get(const wjh_user_channel_id_t id, wjh_user_channel_record_t **record_pp)
{
    *record_pp = &wjh_db_s.user_channels[id];
}

void wjh_db_trap_id_attr_get(const wjh_trap_id_t trap_id, wjh_trap_id_attr_t **trap_id_attr_pp)
{
    *trap_id_attr_pp = &wjh_db_s.trap_id_attrs[trap_id];
}

wjh_status_t wjh_db_get_chip_type(wjh_chip_types_t *chip_type)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (chip_type == NULL) {
        err = WJH_STATUS_PARAM_NULL;
        WJH_LOG_ERR("Chip type param is NULL, err:%u\n", err);
        goto out;
    }

    *chip_type = wjh_hw_db_s.hw_info_db.chip_type;
out:
    return err;
}

wjh_dev_specific_cb_t * wjh_db_get_dev_cb()
{
    return &(wjh_hw_db_s.hw_info_db.wjh_dev_cb);
}

boolean_t wjh_is_reason_group_db_inited(wjh_drop_reason_group_e reason_group)
{
    boolean_t                      is_db_valid = TRUE;
    wjh_drop_reason_group_record_t drop_reason_record = wjh_db_s.drop_reason_groups[reason_group];

    if (drop_reason_record.inited == FALSE) {
        is_db_valid = FALSE;
        goto out;
    }

out:
    return is_db_valid;
}

void wjh_db_get_drop_reason_item(const int index, wjh_drop_reason_item_t **drop_reason_item_pp)
{
    *drop_reason_item_pp = &wjh_db_s.drop_reasons[index];
}

static wjh_status_t __wjh_db_get_drop_reason_group_by_reason(wjh_drop_reason_id_t     reason_id,
                                                             wjh_drop_reason_group_e *reason_group)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;

    if (((reason_id >= WJH_L1_PORT_DOWN_REASON_ID_MIN) &&
         (reason_id < (WJH_L1_PORT_DOWN_REASON_ID_MIN + WJH_L1_PORT_DOWN_REASON_NUM))) ||
        ((reason_id >= WJH_L1_DROP_REASON_ID_MIN) &&
         (reason_id < (WJH_L1_DROP_REASON_ID_MIN + WJH_L1_DROP_REASON_NUM)))) {
        *reason_group = WJH_DROP_REASON_GROUP_L1_E;
        goto out;
    }

    if ((reason_id >= WJH_ACL_DROP_REASON_ID_MIN) &&
        (reason_id < (WJH_ACL_DROP_REASON_ID_MIN + WJH_ACL_DROP_REASON_NUM))) {
        *reason_group = WJH_DROP_REASON_GROUP_ACL_E;
        goto out;
    }

    if ((reason_id >= WJH_BUFFER_DROP_REASON_ID_MIN) &&
        (reason_id < (WJH_BUFFER_DROP_REASON_ID_MIN + WJH_BUFFER_DROP_REASON_NUM))) {
        *reason_group = WJH_DROP_REASON_GROUP_BUFFER_E;
        goto out;
    }

    if ((reason_id >= WJH_L2_DROP_REASON_ID_MIN) &&
        (reason_id < (WJH_L2_DROP_REASON_ID_MIN + WJH_L2_DROP_REASON_NUM))) {
        *reason_group = WJH_DROP_REASON_GROUP_L2_E;
        goto out;
    }

    if ((reason_id >= WJH_ROUTER_DROP_REASON_ID_MIN) &&
        (reason_id < (WJH_ROUTER_DROP_REASON_ID_MIN + WJH_ROUTER_DROP_REASON_NUM))) {
        *reason_group = WJH_DROP_REASON_GROUP_ROUTER_E;
        goto out;
    }

    if ((reason_id >= WJH_TUNNEL_DROP_REASON_ID_MIN) &&
        (reason_id < (WJH_TUNNEL_DROP_REASON_ID_MIN + WJH_TUNNEL_DROP_REASON_NUM))) {
        *reason_group = WJH_DROP_REASON_GROUP_TUNNEL_E;
        goto out;
    }

    if ((reason_id >= WJH_ROCE_DROP_REASON_ID_MIN) &&
        (reason_id < (WJH_ROCE_DROP_REASON_ID_MIN + WJH_ROCE_DROP_REASON_NUM))) {
        *reason_group = WJH_DROP_REASON_GROUP_ROCE_E;
        goto out;
    }

    err = WJH_STATUS_ENTRY_NOT_FOUND;
    WJH_LOG_WRN("Reason id %d is not exist.\n", reason_id);

out:
    return err;
}

wjh_status_t wjh_db_get_drop_reason_item_by_reason(wjh_drop_reason_id_t     reason_id,
                                                   wjh_drop_reason_item_t **drop_reason_item_pp)
{
    uint32_t                index = 0;
    wjh_drop_reason_group_e reason_group = WJH_DROP_REASON_GROUP_MIN_E;
    wjh_status_t            err = WJH_STATUS_SUCCESS;

    err = __wjh_db_get_drop_reason_group_by_reason(reason_id, &reason_group);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to get drop reason for reason id %d.\n", reason_id);
        goto out;
    }

    index = __wjh_db_get_drop_reason_index(reason_group, reason_id);
    *drop_reason_item_pp = &wjh_db_s.drop_reasons[index];
out:
    return err;
}

static int __wjh_db_filter_rule_map_compare(IN const void *const p_key1, IN const void *const p_key2)
{
    wjh_db_filter_rule_map_key_t *rule_key1_p = (wjh_db_filter_rule_map_key_t*)p_key1;
    wjh_db_filter_rule_map_key_t *rule_key2_p = (wjh_db_filter_rule_map_key_t*)p_key2;
    int                           cmp = 0;

    if (rule_key1_p->port != rule_key2_p->port) {
        cmp = -1;
        if (rule_key1_p->port > rule_key2_p->port) {
            cmp = 1;
        }
        goto out;
    }

    if (rule_key1_p->drop_reason != rule_key2_p->drop_reason) {
        cmp = -1;
        if (rule_key1_p->drop_reason > rule_key2_p->drop_reason) {
            cmp = 1;
        }
        goto out;
    }

    if (rule_key1_p->ip_proto != rule_key2_p->ip_proto) {
        cmp = -1;
        if (rule_key1_p->ip_proto > rule_key2_p->ip_proto) {
            cmp = 1;
        }
        goto out;
    }

    if (rule_key1_p->ether_type != rule_key2_p->ether_type) {
        cmp = -1;
        if (rule_key1_p->ether_type > rule_key2_p->ether_type) {
            cmp = 1;
        }
        goto out;
    }

    if (rule_key1_p->valid_mask != rule_key2_p->valid_mask) {
        cmp = -1;
        if (rule_key1_p->valid_mask > rule_key2_p->valid_mask) {
            cmp = 1;
        }
        goto out;
    }

out:
    return cmp;
}

wjh_status_t __wjh_db_allocate_filter_record(wjh_db_filter_record_t **filter_record_pp)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    cl_pool_item_t         *pool_item_p = NULL;
    wjh_db_filter_record_t *filter_record_p = NULL;
    cl_status_t             cl_err = CL_SUCCESS;

    WJH_CHECK_NULL_PTR(filter_record_pp, filter_record_pp);

    pool_item_p = cl_qpool_get(&wjh_db_s.filter_pool);

    if (pool_item_p == NULL) {
        err = WJH_STATUS_NO_RESOURCES;
        WJH_LOG_ERR("No more filter resource.\n");
        goto out;
    }

    filter_record_p = PARENT_STRUCT(pool_item_p, wjh_db_filter_record_t, pool_item);
    cl_err = id_allocator_get(&(wjh_db_s.filter_id_allocator), &(filter_record_p->filter_id));
    if (cl_err != CL_SUCCESS) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to get new index for filter pool_item, err = [%s]\n",
                    CL_STATUS_MSG(cl_err));
        goto out;
    }
    filter_record_p->counter = 0;
    filter_record_p->keys_num = 0;
    filter_record_p->rules_num = 0;
    filter_record_p->ebpf_map_fd = -1;
    filter_record_p->ebpf_prog_fd = -1;
    memset(filter_record_p->bound, 0, sizeof(boolean_t) * WJH_USER_CHANNEL_MAX_NUM);
    memset(filter_record_p->is_key_set, 0, sizeof(boolean_t) * WJH_FILTER_KEY_NUM);
    cl_err = CL_QPOOL_INIT(&filter_record_p->rules_pool,
                           WJH_DB_FILTER_RULE_POOL_MIN_SIZE,
                           WJH_FILTER_RULE_NUM_MAX,
                           WJH_DB_FILTER_RULE_POOL_GROW_SIZE,
                           sizeof(wjh_db_filter_rule_record_t),
                           NULL,
                           NULL,
                           NULL);
    if (cl_err != CL_SUCCESS) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to create filter rule pool.\n");
        goto out;
    }

    cl_fmap_init(&filter_record_p->rules_map, __wjh_db_filter_rule_map_compare);
    cl_qmap_insert(&wjh_db_s.filter_map, filter_record_p->filter_id, &filter_record_p->map_item);

    *filter_record_pp = filter_record_p;

out:
    return err;
}

wjh_status_t wjh_db_filter_create(wjh_filter_key_e        *key_list_p,
                                  uint32_t                 count,
                                  wjh_db_filter_record_t **filter_record_pp)
{
    wjh_status_t            err = WJH_STATUS_SUCCESS;
    wjh_db_filter_record_t *filter_record_p = NULL;
    uint32_t                i = 0;

    WJH_CHECK_NULL_PTR(key_list_p, key_list_p);
    WJH_CHECK_NULL_PTR(filter_record_pp, filter_record_pp);

    err = __wjh_db_allocate_filter_record(&filter_record_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to get filter resource.\n");
        goto out;
    }

    for (i = 0; i < count; i++) {
        filter_record_p->is_key_set[key_list_p[i]] = TRUE;
    }

    filter_record_p->keys_num = count;
    *filter_record_pp = filter_record_p;
out:
    return err;
}

wjh_status_t wjh_db_filter_destroy(wjh_db_filter_record_t *filter_record_p)
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    cl_status_t                  cl_err = CL_SUCCESS;
    wjh_db_filter_rule_record_t *filter_rule_record_p = NULL;
    cl_fmap_item_t              *filter_rule_map_item_p = NULL;

    WJH_CHECK_NULL_PTR(filter_record_p, filter_record_p);

    filter_rule_map_item_p = cl_fmap_head(&filter_record_p->rules_map);
    while (filter_rule_map_item_p != cl_fmap_end(&filter_record_p->rules_map)) {
        filter_rule_record_p = PARENT_STRUCT(filter_rule_map_item_p, wjh_db_filter_rule_record_t, map_item);
        cl_qpool_put(&filter_record_p->rules_pool, &filter_rule_record_p->pool_item);
        filter_rule_map_item_p = cl_fmap_next(filter_rule_map_item_p);
    }

    cl_fmap_remove_all(&filter_record_p->rules_map);
    CL_QPOOL_DESTROY(&filter_record_p->rules_pool);

    cl_qmap_remove(&wjh_db_s.filter_map, filter_record_p->filter_id);

    cl_err = id_allocator_put(&(wjh_db_s.filter_id_allocator), filter_record_p->filter_id);
    if (cl_err != CL_SUCCESS) {
        err = WJH_STATUS_ERROR;
        WJH_LOG_ERR("Failed to delete filter pool index %d, err = [%s]\n",
                    filter_record_p->filter_id, CL_STATUS_MSG(cl_err));
        goto out;
    }
    cl_qpool_put(&wjh_db_s.filter_pool, &filter_record_p->pool_item);

out:
    return err;
}

wjh_status_t wjh_db_filter_get(wjh_filter_id_t filter_id, wjh_db_filter_record_t **filter_record_pp)
{
    wjh_status_t   err = WJH_STATUS_SUCCESS;
    cl_map_item_t *map_item_p = NULL;

    map_item_p = cl_qmap_get(&wjh_db_s.filter_map, filter_id);
    if (map_item_p == cl_qmap_end(&wjh_db_s.filter_map)) {
        err = WJH_STATUS_ENTRY_NOT_FOUND;
        WJH_LOG_DBG("Failed to found the filter %d\n", filter_id);
        goto out;
    }

    *filter_record_pp = PARENT_STRUCT(map_item_p, wjh_db_filter_record_t, map_item);

out:
    return err;
}

static wjh_status_t __wjh_db_allocate_filter_rule_record(wjh_db_filter_record_t       *filter_record_p,
                                                         wjh_db_filter_rule_record_t **filter_rule_record_pp)
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    cl_pool_item_t              *pool_item_p = NULL;
    wjh_db_filter_rule_record_t *filter_rule_record_p = NULL;

    WJH_CHECK_NULL_PTR(filter_rule_record_pp, filter_rule_record_pp);

    pool_item_p = cl_qpool_get(&filter_record_p->rules_pool);

    if (pool_item_p == NULL) {
        err = WJH_STATUS_NO_RESOURCES;
        WJH_LOG_ERR("No more rule resource for filter %d.\n", filter_record_p->filter_id);
        goto out;
    }

    filter_rule_record_p = PARENT_STRUCT(pool_item_p, wjh_db_filter_rule_record_t, pool_item);
    filter_rule_record_p->counter = 0;
    filter_rule_record_p->key_desc_count = 0;
    memset(filter_rule_record_p->is_key_set, 0, sizeof(boolean_t) * WJH_FILTER_KEY_NUM);
    memset(filter_rule_record_p->key_field, 0, sizeof(wjh_filter_key_field_t) * WJH_FILTER_KEY_NUM);
    memset(&filter_rule_record_p->map_key, 0, sizeof(wjh_db_filter_rule_map_key_t));
    memset(&filter_rule_record_p->ebpf_key, 0, sizeof(wjh_filter_rule_ebpf_key_t));

    *filter_rule_record_pp = filter_rule_record_p;

out:
    return err;
}

static wjh_status_t __wjh_db_filter_rule_to_rule_record(wjh_filter_rule_t           *rule_p,
                                                        wjh_db_filter_rule_record_t *rule_record_p)
{
    wjh_status_t     err = WJH_STATUS_SUCCESS;
    wjh_filter_key_e key = WJH_FILTER_KEY_MIN_E;
    uint32_t         i = 0;

    memset(rule_record_p, 0, sizeof(wjh_db_filter_rule_record_t));

    for (i = 0; i < rule_p->key_desc_count; i++) {
        key = rule_p->key_desc_list_p[i].key;
        if (rule_record_p->is_key_set[key] == TRUE) {
            err = WJH_STATUS_PARAM_ERROR;
            WJH_LOG_ERR("Duplicated filter key in rule.\n");
            goto out;
        }
        rule_record_p->is_key_set[key] = TRUE;
        rule_record_p->key_field[key] = rule_p->key_desc_list_p[i].field;
        rule_record_p->map_key.valid_mask |= 1 << key;
        rule_record_p->key_desc_count++;
    }
    rule_record_p->map_key.port = rule_record_p->key_field[WJH_FILTER_KEY_PORT_E].port;
    rule_record_p->map_key.drop_reason = rule_record_p->key_field[WJH_FILTER_KEY_DROP_REASON_E].drop_reason;
    rule_record_p->map_key.ip_proto = rule_record_p->key_field[WJH_FILTER_KEY_IP_PROTO_E].ip_proto;
    rule_record_p->map_key.ether_type = rule_record_p->key_field[WJH_FILTER_KEY_ETHER_TYPE_E].ether_type;

    rule_record_p->ebpf_key.drop_reason = rule_record_p->map_key.drop_reason;
    rule_record_p->ebpf_key.ip_proto = rule_record_p->map_key.ip_proto;
    rule_record_p->ebpf_key.ether_type = rule_record_p->map_key.ether_type;
    rule_record_p->ebpf_key.valid_mask = rule_record_p->map_key.valid_mask;

out:
    return err;
}

wjh_status_t wjh_db_filter_rule_add(wjh_db_filter_record_t       *filter_record_p,
                                    wjh_filter_rule_t            *rule_p,
                                    wjh_db_filter_rule_record_t **rule_record_pp)
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    wjh_db_filter_rule_record_t *filter_rule_record_p = NULL;
    wjh_db_filter_rule_record_t  filter_rule_record;

    memset(&filter_rule_record, 0, sizeof(wjh_db_filter_rule_record_t));

    err = __wjh_db_filter_rule_to_rule_record(rule_p, &filter_rule_record);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to generate db record from filter rule\n");
        goto out;
    }

    if (cl_fmap_get(&filter_record_p->rules_map, &filter_rule_record.map_key) !=
        cl_fmap_end(&filter_record_p->rules_map)) {
        err = WJH_STATUS_ENTRY_ALREADY_EXIST;
        WJH_LOG_DBG("Rule already exist.\n");
        goto out;
    }

    /* Allocate and put to database */
    err = __wjh_db_allocate_filter_rule_record(filter_record_p, &filter_rule_record_p);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to get filter rule resource.\n");
        goto out;
    }

    memcpy(filter_rule_record_p->is_key_set, filter_rule_record.is_key_set, sizeof(boolean_t) * WJH_FILTER_KEY_NUM);
    memcpy(filter_rule_record_p->key_field,
           filter_rule_record.key_field,
           sizeof(wjh_filter_key_field_t) * WJH_FILTER_KEY_NUM);
    memcpy(&filter_rule_record_p->map_key, &filter_rule_record.map_key, sizeof(wjh_db_filter_rule_map_key_t));
    memcpy(&filter_rule_record_p->ebpf_key, &filter_rule_record.ebpf_key, sizeof(wjh_filter_rule_ebpf_key_t));

    filter_rule_record_p->key_desc_count = filter_rule_record.key_desc_count;

    cl_fmap_insert(&filter_record_p->rules_map, &filter_rule_record_p->map_key, &filter_rule_record_p->map_item);
    filter_record_p->rules_num++;
    if (rule_record_pp) {
        *rule_record_pp = filter_rule_record_p;
    }

out:
    return err;
}

wjh_status_t wjh_db_filter_rule_record_get(wjh_db_filter_record_t       *filter_record_p,
                                           wjh_filter_rule_t            *rule_p,
                                           wjh_db_filter_rule_record_t **rule_record_pp)
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    wjh_db_filter_rule_record_t  filter_rule_record;
    wjh_db_filter_rule_record_t *filter_rule_record_p = NULL;
    cl_fmap_item_t              *filter_rule_map_item_p = NULL;

    WJH_CHECK_NULL_PTR(rule_record_pp, rule_record_pp);

    memset(&filter_rule_record, 0, sizeof(wjh_db_filter_rule_record_t));

    err = __wjh_db_filter_rule_to_rule_record(rule_p, &filter_rule_record);
    if (WJH_CHECK_FAIL(err)) {
        WJH_LOG_ERR("Failed to generate db record from filter rule\n");
        goto out;
    }

    filter_rule_map_item_p = cl_fmap_get(&filter_record_p->rules_map, &filter_rule_record.map_key);

    if (filter_rule_map_item_p == cl_fmap_end(&filter_record_p->rules_map)) {
        err = WJH_STATUS_ENTRY_NOT_FOUND;
        WJH_LOG_DBG("Rule not exist.\n");
        goto out;
    }

    filter_rule_record_p = PARENT_STRUCT(filter_rule_map_item_p, wjh_db_filter_rule_record_t, map_item);

    *rule_record_pp = filter_rule_record_p;

out:
    return err;
}

wjh_status_t wjh_db_filter_rule_record_list_get(wjh_db_filter_record_t       *filter_record_p,
                                                wjh_db_filter_rule_record_t **rule_record_list_pp,
                                                uint32_t                     *list_count_p)
{
    wjh_status_t                 err = WJH_STATUS_SUCCESS;
    wjh_db_filter_rule_record_t *filter_rule_record_p = NULL;
    cl_fmap_item_t              *filter_rule_map_item_p = NULL;
    uint32_t                     count = 0;

    WJH_CHECK_NULL_PTR(rule_record_list_pp, rule_record_list_pp);

    filter_rule_map_item_p = cl_fmap_head(&filter_record_p->rules_map);

    while (filter_rule_map_item_p != cl_fmap_end(&filter_record_p->rules_map)) {
        if (count >= *list_count_p) {
            break;
        }
        filter_rule_record_p = PARENT_STRUCT(filter_rule_map_item_p, wjh_db_filter_rule_record_t, map_item);
        rule_record_list_pp[count] = filter_rule_record_p;
        count++;
        filter_rule_map_item_p = cl_fmap_next(filter_rule_map_item_p);
    }

    *list_count_p = count;

out:
    return err;
}

wjh_status_t wjh_db_filter_rule_record_remove(wjh_db_filter_record_t      *filter_record_p,
                                              wjh_db_filter_rule_record_t *filter_rule_record_p)
{
    wjh_status_t    err = WJH_STATUS_SUCCESS;
    cl_fmap_item_t *filter_rule_map_item_p = NULL;

    filter_rule_map_item_p = cl_fmap_remove(&filter_record_p->rules_map, &filter_rule_record_p->map_key);
    if (filter_rule_map_item_p == cl_fmap_end(&filter_record_p->rules_map)) {
        err = WJH_STATUS_ENTRY_NOT_FOUND;
        WJH_LOG_DBG("Rule not exist.\n");
        goto out;
    }

    cl_qpool_put(&filter_record_p->rules_pool, &filter_rule_record_p->pool_item);

    filter_record_p->rules_num--;

out:
    return err;
}

cl_plock_t* wjh_db_get_rwlock(void)
{
    return &wjh_db_rwlock_s;
}

wjh_status_t wjh_db_dbg_generate_dump(FILE* stream_p)
{
    wjh_status_t err = WJH_STATUS_SUCCESS;
    uint32_t     i = 0, j;
    char         channel_id_str[20];
    uint32_t     netdev_type, lid_local_port;
    char         enabled_severities[1024];
    char         enabled_drop_reasons[1024];


    fprintf(stream_p, "######## User Channel #########\n");
    for (i = 0; i < WJH_USER_CHANNEL_MAX_NUM; ++i) {
        if (wjh_db_s.user_channels[i].created) {
            fprintf(stream_p, "channel id[%d], channel type[%s], polling interval[%d ms].\n",
                    wjh_db_s.user_channels[i].channel_id,
                    __wjh_enum_to_str(wjh_db_s.user_channels[i].channel_type, WJH_USER_CHANNEL_MIN_E,
                                      WJH_USER_CHANNEL_MAX_E, wjh_channel_type_str_s),
                    wjh_db_s.user_channels[i].polling_interval);
        }
    }

    fprintf(stream_p, "######## Drop Reason Group #########\n");
    for (i = 0; i < WJH_DROP_REASON_GROUP_NUM; ++i) {
        if (wjh_db_s.drop_reason_groups[i].bound) {
            snprintf(channel_id_str, 20, "%u", wjh_db_s.drop_reason_groups[i].channel_id);
        } else {
            snprintf(channel_id_str, 20, "None");
        }

        __wjh_bitmap_to_str(wjh_db_s.drop_reason_groups[i].enabled_severity_bits,
                            WJH_SEVERITY_NOTICE_E,
                            WJH_SEVERITY_ERROR_E,
                            wjh_severity_2str,
                            FALSE,
                            1024,
                            enabled_severities);
        if (wjh_db_s.drop_reason_groups[i].drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) {
            __wjh_bitmap_to_str(wjh_db_s.drop_reason_groups[i].enabled_drop_reason_bits,
                                WJH_DROP_REASON_ID_TAIL_DROP_E,
                                WJH_DROP_REASON_ID_EGR_TC_LATENCY,
                                wjh_buffer_drop_reason_str_s,
                                TRUE,
                                1024,
                                enabled_drop_reasons);
        } else if (wjh_db_s.drop_reason_groups[i].drop_reason_group == WJH_DROP_REASON_GROUP_ROCE_E) {
            __wjh_bitmap_to_str(wjh_db_s.drop_reason_groups[i].enabled_drop_reason_bits,
                                WJH_DROP_REASON_ID_ROCE_WRONG_PRIORITY,
                                WJH_DROP_REASON_ID_ROCE_FLOOD,
                                wjh_roce_drop_reason_str_s,
                                TRUE,
                                1024,
                                enabled_drop_reasons);
        }

        if ((wjh_db_s.drop_reason_groups[i].drop_reason_group == WJH_DROP_REASON_GROUP_BUFFER_E) ||
            (wjh_db_s.drop_reason_groups[i].drop_reason_group == WJH_DROP_REASON_GROUP_ROCE_E)) {
            fprintf(stream_p,
                    "drop reason group[%s], initialized[%s], bound[%s], bound to channel[%s], enabled severities[%s], "
                    "enabled drop reasons[%s].\n",
                    __wjh_enum_to_str(wjh_db_s.drop_reason_groups[i].drop_reason_group, WJH_DROP_REASON_GROUP_MIN_E,
                                      WJH_DROP_REASON_GROUP_MAX_E, wjh_drop_reason_group_str_s),
                    wjh_db_s.drop_reason_groups[i].inited ? "True" : "False",
                    wjh_db_s.drop_reason_groups[i].bound ? "True" : "False",
                    channel_id_str,
                    enabled_severities,
                    enabled_drop_reasons);
        } else {
            fprintf(stream_p,
                    "drop reason group[%s], initialized[%s], bound[%s], bound to channel[%s], enabled severities[%s].\n",
                    __wjh_enum_to_str(wjh_db_s.drop_reason_groups[i].drop_reason_group, WJH_DROP_REASON_GROUP_MIN_E,
                                      WJH_DROP_REASON_GROUP_MAX_E, wjh_drop_reason_group_str_s),
                    wjh_db_s.drop_reason_groups[i].inited ? "True" : "False",
                    wjh_db_s.drop_reason_groups[i].bound ? "True" : "False",
                    channel_id_str,
                    enabled_severities);
        }
    }
#ifdef SDK_PRESENT
    /* Dump log_port to netdev db */
    fprintf(stream_p, "######## LOCAL PORT to IF_INDEX table #########\n");
    for (i = 0; i < WJH_NETDEV_TYPE_NUM_OF_TYPES; i++) {
        for (j = 0; j <= MAX_PHYPORT_NUM; j++) {
            netdev_type = i;
            lid_local_port = j;
            if (wjh_db_s.log_port_attr_db[netdev_type][lid_local_port].if_index !=
                WJH_INVALID_IF_INDEX) {
                fprintf(stream_p, "%s 0x%x (local/lid %u), if_index %u, if_name: %s  \n",
                        netdev_type == WJH_NETDEV_TYPE_PHY_PORT ? "port" : "lag",
                        wjh_db_s.log_port_attr_db[netdev_type][lid_local_port].log_port,
                        lid_local_port,
                        wjh_db_s.log_port_attr_db[netdev_type][lid_local_port].if_index,
                        wjh_db_s.log_port_attr_db[netdev_type][lid_local_port].netdev_name
                        );
            }
        }
    }

    fprintf(stream_p, "######## Buffer Drop Reason DB #########\n");
    fprintf(stream_p,
            "Span session ID [%u]\n", wjh_db_s.buffer_drop_db.span_session_id);
    fprintf(stream_p,
            "Span session policer ID [%" PRIu64 "]\n", wjh_db_s.buffer_drop_db.span_session_policer_id);
    fprintf(stream_p,
            "Recirculation port [0x%x]\n", wjh_db_s.buffer_drop_db.recirculation_port);
    for (i = 0; i < WJH_BUFFER_DROP_ACL_NUM; i++) {
        fprintf(stream_p, "ACL group #%u [0x%x]\n", i, wjh_db_s.buffer_drop_db.acl_group_list[i]);
    }
    for (i = 0; i < WJH_BUFFER_DROP_ACL_NUM; i++) {
        fprintf(stream_p, "ACL #%u [0x%x]\n", i, wjh_db_s.buffer_drop_db.acl_list[i]);
    }
    for (i = 0; i < WJH_BUFFER_DROP_ACL_NUM; i++) {
        fprintf(stream_p, "ACL region #%u [0x%x]\n", i, wjh_db_s.buffer_drop_db.acl_region_list[i]);
    }
    for (i = 0; i < WJH_BUFFER_DROP_ACL_NUM; i++) {
        fprintf(stream_p, "ACL rules per region #%u [%u]\n", i, wjh_db_s.buffer_drop_db.rules_per_region[i]);
    }
    for (i = 0; i < WJH_BUFFER_DROP_RULE_NUM; i++) {
        fprintf(stream_p, "ACL rule #%u offset [%u]\n", i, wjh_db_s.buffer_drop_db.rule_offset[i]);
    }
#endif
    fprintf(stream_p, "\n");

    return err;
}


wjh_status_t __wjh_db_log_port_type_get(uint32_t           log_port,
                                        wjh_netdev_type_e* log_port_type_p,
                                        uint32_t          *lid_local_port_p)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    wjh_netdev_type_e netdev_type;
    uint32_t          lid_local_port;

    if (SX_PORT_TYPE_LAG == SX_PORT_TYPE_ID_GET(log_port)) {
        netdev_type = WJH_NETDEV_TYPE_LAG;
        lid_local_port = SX_PORT_LAG_ID_GET(log_port);
    } else if (SX_PORT_TYPE_NETWORK == SX_PORT_TYPE_ID_GET(log_port)) {
        netdev_type = WJH_NETDEV_TYPE_PHY_PORT;
        lid_local_port = SX_PORT_PHY_ID_GET(log_port);
    } else {
        WJH_LOG_ERR("log_port 0x%x type is unsupported %d \n",
                    log_port, SX_PORT_TYPE_ID_GET(log_port));
        err = WJH_STATUS_ERROR;
        goto out;
    }

    if (lid_local_port > MAX_PHYPORT_NUM) {
        WJH_LOG_ERR("local port %d is too big, max : %d  \n",
                    lid_local_port, MAX_PHYPORT_NUM);
        err = WJH_STATUS_PARAM_ERROR;
        goto out;
    }

    *log_port_type_p = netdev_type;
    *lid_local_port_p = lid_local_port;

out:
    return err;
}

wjh_status_t wjh_db_log_port_attr_set(uint32_t log_port, wjh_log_port_attr_t* log_port_attr_p)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    wjh_netdev_type_e netdev_type;
    uint32_t          lid_local_port;

    if (log_port_attr_p == NULL) {
        WJH_LOG_ERR("log_port_attr_p is NULL\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    err = __wjh_db_log_port_type_get(log_port,
                                     &netdev_type, &lid_local_port);
    if (err) {
        WJH_LOG_ERR("__wjh_db_log_port_type_get failed with err: %d  \n", err);
        err = WJH_STATUS_PARAM_ERROR;
        goto out;
    }

    wjh_db_s.log_port_attr_db[netdev_type][lid_local_port] = *log_port_attr_p;

out:
    return err;
}

wjh_status_t wjh_db_log_port_attr_get(uint32_t log_port, wjh_log_port_attr_t* log_port_attr_p)
{
    wjh_status_t      err = WJH_STATUS_SUCCESS;
    wjh_netdev_type_e netdev_type;
    uint32_t          lid_local_port;

    if (log_port_attr_p == NULL) {
        WJH_LOG_ERR("log_port_attr_p is NULL\n");
        err = WJH_STATUS_ERROR;
        goto out;
    }

    err = __wjh_db_log_port_type_get(log_port,
                                     &netdev_type, &lid_local_port);
    if (err) {
        WJH_LOG_ERR("__wjh_db_log_port_type_get failed with err: %d  \n", err);
        err = WJH_STATUS_PARAM_ERROR;
        goto out;
    }

    *log_port_attr_p = wjh_db_s.log_port_attr_db[netdev_type][lid_local_port];

out:
    return err;
}
