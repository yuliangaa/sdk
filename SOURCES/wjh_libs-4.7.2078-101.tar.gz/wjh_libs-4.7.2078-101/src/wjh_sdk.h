/*
 * Copyright © 2001-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */


#ifndef WJH_SDK_H_
#define WJH_SDK_H_

#include "wjh/wjh_lib.h"
#include "wjh_db.h"
#include <sx/sdk/sx_cos.h>

/************************************************
 *  Macros
 ***********************************************/

#define WJH_DEFAULT_DEVICE_NUMBER             1 /* This device would be used for sxd access */
#define WJH_BUFFER_DROP_TRAP_ID_DEFAULT_VALUE (SX_TRAP_ID_ACL_MAX)
#define WJH_TRAP_GROUP_MIN                    59
/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

wjh_status_t wjh_init_sdk(void);
wjh_status_t wjh_deinit_sdk(void);
wjh_status_t wjh_policer_create_sdk(uint8_t percentage);
wjh_status_t wjh_policer_destroy_sdk(void);
wjh_status_t wjh_user_channel_create_sdk(wjh_user_channel_type_e    channel_type,
                                         wjh_user_channel_record_t *user_channel_p);
wjh_status_t wjh_user_channel_destroy_sdk(wjh_user_channel_record_t *user_channel_p);
wjh_status_t wjh_user_channel_flush_sdk(wjh_user_channel_record_t *user_channel_p);
wjh_status_t wjh_drop_reason_group_validate_sdk(wjh_drop_reason_group_e drop_reason_group);
wjh_status_t wjh_drop_reason_group_init_sdk(const wjh_drop_reason_group_e       drop_reason_group,
                                            const wjh_drop_reason_group_attr_t *attr_p);
wjh_status_t wjh_drop_reason_group_deinit_sdk(wjh_drop_reason_group_e drop_reason_group);
wjh_status_t wjh_drop_reason_group_bind_sdk(wjh_user_channel_record_t      *user_channel_p,
                                            wjh_drop_reason_group_record_t *group_item_p);
wjh_status_t wjh_drop_reason_group_unbind_sdk(wjh_user_channel_record_t      *user_channel_p,
                                              wjh_drop_reason_group_record_t *group_item_p);
wjh_status_t wjh_drop_reason_group_enable_sdk(wjh_user_channel_record_t      *user_channel_p,
                                              wjh_drop_reason_group_record_t *group_item_p,
                                              uint8_t                         severity_bits);
wjh_status_t wjh_drop_reason_group_disable_sdk(wjh_user_channel_record_t      *user_channel_p,
                                               wjh_drop_reason_group_record_t *group_item_p,
                                               uint8_t                         severity_bits);
wjh_status_t wjh_drop_reason_group_update_sdk(wjh_drop_reason_group_record_t *group_item_p);
wjh_status_t wjh_counter_dropped_packets_get_sdk(wjh_user_channel_record_t *user_channel_p,
                                                 uint64_t                  *dropped_packets_p,
                                                 uint8_t                    clear);
wjh_status_t wjh_filter_create_sdk(wjh_db_filter_record_t *filter_record_p);
wjh_status_t wjh_filter_destroy_sdk(wjh_db_filter_record_t *filter_record_p);
wjh_status_t wjh_filter_rule_add_sdk(wjh_db_filter_record_t      *filter_record_p,
                                     wjh_db_filter_rule_record_t *filter_rule_record_p);
wjh_status_t wjh_filter_rule_remove_sdk(wjh_db_filter_record_t      *filter_record_p,
                                        wjh_db_filter_rule_record_t *filter_rule_record_p);
wjh_status_t wjh_filter_rule_counter_get_sdk(wjh_db_filter_record_t      *filter_record_p,
                                             wjh_db_filter_rule_record_t *filter_rule_record_p,
                                             uint8_t                      clear);
wjh_status_t wjh_filter_bind_channel_sdk(wjh_db_filter_record_t    *filter_record_p,
                                         wjh_user_channel_record_t *channel_p);
wjh_status_t wjh_filter_unbind_channel_sdk(wjh_db_filter_record_t    *filter_record_p,
                                           wjh_user_channel_record_t *channel_p);
wjh_status_t wjh_get_hw_port_sdk(wjh_port_log_id_t port, uint32_t *hw_port_p, uint16_t *label_port_p);
wjh_status_t wjh_filter_rules_validate_sdk(wjh_filter_rule_t *rule_list_p, uint32_t rule_count);
wjh_status_t wjh_resources_pre_init_clean_up_sdk(wjh_drop_reason_group_shm_data_t *drop_reason_shm_data_p,
                                                 wjh_user_channel_shm_data_t      *user_channel_shm_data_p);
wjh_status_t wjh_resources_post_init_clean_up_sdk();
wjh_status_t wjh_polling_thread_buf_create_sdk(wjh_user_channel_record_t *user_channel_p, void **buf_pp);
wjh_status_t wjh_polling_thread_buf_destroy_sdk(wjh_user_channel_record_t *user_channel_p, void *buf_p);
wjh_status_t wjh_user_channel_process_sdk(wjh_user_channel_record_t *user_channel_p, void *buf_p,
                                          boolean_t is_pull_api);
wjh_status_t wjh_user_channel_fd_get_sdk(wjh_user_channel_record_t *user_channel_p, int *fd_p);
wjh_status_t wjh_drop_reason_group_init_sdk(const wjh_drop_reason_group_e       drop_reason_group,
                                            const wjh_drop_reason_group_attr_t *attr_p);
wjh_status_t wjh_drop_reason_group_deinit_sdk(const wjh_drop_reason_group_e drop_reason_group);
wjh_status_t wjh_get_chip_type_sdk(wjh_chip_types_t* chip_type);
wjh_status_t wjh_validate_shm_sdk(wjh_driver_shm_data_t *driver_data_p, boolean_t *is_valid_p);
wjh_status_t wjh_update_shm_sdk(wjh_driver_shm_data_t *driver_shm_data_p);
wjh_status_t wjh_user_channel_timestamp_source_set_sdk(wjh_user_channel_id_t               channel_id,
                                                       wjh_user_channel_timestamp_source_e timestamp_source);
wjh_status_t wjh_user_channel_tac_set_sdk(wjh_user_channel_record_t *user_channel_p,
                                          wjh_span_session_id_t      span_session_id);
wjh_status_t wjh_user_channel_validate_sdk(wjh_user_channel_type_e channel_type);
#ifdef WJH_EBPF_PRESENT
wjh_status_t wjh_set_debugfs_path_sdk(const wjh_init_param_t *param_p);
wjh_status_t wjh_ebpf_prepare_sdk(void);
wjh_status_t wjh_ebpf_cleanup_sdk(void);
wjh_status_t wjh_aggregation_set_monitor_rdq_trace_points_sdk(boolean_t enable);
#endif
#endif /* WJH_SDK_H_ */
