/*
 * Copyright © 2019-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <uapi/linux/bpf.h>
#include "bpf_helpers.h"

#define WJH_TRAP_ID_MIRROR_AGENT_MIN 0X220
#define WJH_TRAP_ID_MIRROR_AGENT_MAX 0X227

struct bpf_map_def SEC("maps") wjh_agg_buffer_map =
{
    .type = BPF_MAP_TYPE_HASH,
    .key_size = sizeof(wjh_agg_ebpf_key_t),
    .value_size = sizeof(wjh_agg_ebpf_value_t),
    .max_entries = 1024,
};

SEC("wjh_agg_buffer_bpf_prog")
int agg_buffer_prog(struct __sk_buff *skb)
{
    wjh_agg_ebpf_key_t          key = {0};
    wjh_agg_ebpf_value_t        value = {0};
    wjh_agg_ebpf_value_t       *val_p = NULL;
    uint32_t                    index = 0;
    uint32_t                   *trap_id_p = NULL;
    wjh_agg_ebpf_timestamp_t    timestamp;
    void                       *data = (void*)(long)skb->data;
    void                       *data_end = (void*)(long)skb->data_end;
    uint32_t                   *agg_key_mode_p = NULL;
    uint32_t                   *timestamp_source_p = NULL;
    int                         ret = 0;
    uint16_t                    trap_id = (skb->cb[0]) >> 16;
    uint32_t                    port = skb->cb[4];
    uint16_t                    mirror_cong = skb->cb[0] & 0xFFFF;
    uint8_t                     mirror_tclass = (skb->hash >> 24) & 0xFF;
    uint32_t                    mirror_latency = skb->hash & 0xFFFFFF;
    uint32_t                    egress_port = skb->ingress_ifindex;
    uint8_t                     egress_valid = 1;
    wjh_ebpf_buffer_drop_info_t buffer_drop_info = {0};

    buffer_drop_info.mirror_reason = ((skb->cb[1]) >> 1) & 0xff;
    buffer_drop_info.is_mirror_header_v2_ext = (skb->cb[1]) & 0x1;
    timestamp.tv_sec = skb->cb[2];
    timestamp.tv_nsec = skb->cb[3];

    index = 1;
    trap_id_p = bpf_map_lookup_elem(&wjh_agg_comm_map, &index);
    if ((trap_id_p == NULL) || (*trap_id_p != trap_id)) {
        return 0;
    }

    if (((*trap_id_p) >= WJH_TRAP_ID_MIRROR_AGENT_MIN) &&
        ((*trap_id_p) <= WJH_TRAP_ID_MIRROR_AGENT_MAX)) {
        buffer_drop_info.is_mirror_agent_trap = 1;
        if (buffer_drop_info.mirror_reason == WJH_SPAN_MIRROR_REASON_INVALID) {
            /* For mirror agent traps, we should ignore those packets carrying invalid mirror reason (0). */
            return 0;
        }
    }

    index = 0;
    agg_key_mode_p = bpf_map_lookup_elem(&wjh_agg_comm_map, &index);
    if (agg_key_mode_p == NULL) {
        return 0;
    }

    index = 2;
    timestamp_source_p = bpf_map_lookup_elem(&wjh_agg_comm_map, &index);
    if (timestamp_source_p == NULL) {
        return 0;
    }
    if (*timestamp_source_p == WJH_USER_CHANNEL_TIMESTAMP_SOURCE_HW_CLOCK_E) {
        buffer_drop_info.is_hw_clock = 1;
    }

    ret = flow_dissector(data, data_end, &key, &buffer_drop_info);
    if (ret == -1) {
        return 0;
    }

    if (ret == 0) {
        key.non_ip = 1;
    }

    if (*agg_key_mode_p == WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
        if (buffer_drop_info.is_mirror_agent_trap) {
            key.port = port;
        }
    } else {
        key.port = 0;
        key.vlan = 0;
        key.ether_type = 0;
        __builtin_memset(key.dmac, 0, ETH_ALEN);
        __builtin_memset(key.smac, 0, ETH_ALEN);
    }

    if (buffer_drop_info.mirror_reason != WJH_SPAN_MIRROR_REASON_INVALID) {
        switch (buffer_drop_info.mirror_reason) {
        case WJH_SPAN_MIRROR_REASON_ING_SHARED_BUFFER_DROP:
            key.reason_id = WJH_DROP_REASON_ID_TAIL_DROP_E;
            break;

        case WJH_SPAN_MIRROR_REASON_ING_WRED:
            key.reason_id = WJH_DROP_REASON_ID_WRED_E;
            break;

        case WJH_SPAN_MIRROR_REASON_ING_TC_CONGESTION:
            key.reason_id = WJH_DROP_REASON_ID_ING_TC_CONGESTION;
            break;

        case WJH_SPAN_MIRROR_REASON_EGR_TC_LATENCY:
            key.reason_id = WJH_DROP_REASON_ID_EGR_TC_LATENCY;
            break;

        default:
            return 0;
        }
    }

    if (!buffer_drop_info.is_mirror_agent_trap) {
        egress_valid = buffer_drop_info.egress_valid;
        mirror_cong = buffer_drop_info.cong;
        mirror_tclass = buffer_drop_info.tclass;
        mirror_latency = buffer_drop_info.latency;
        egress_port = buffer_drop_info.egress_port;
    }

    if (((egress_port & 0xFFFF) == 0xFFFF) || ((egress_port & 0xFFFF) == 0xFFFE)) {
        egress_valid = 0;
    }

    if (!buffer_drop_info.is_mirror_agent_trap && buffer_drop_info.is_hw_clock) {
        timestamp = buffer_drop_info.timestamp;
    }

    val_p = bpf_map_lookup_elem(&wjh_agg_buffer_map, &key);
    if (val_p != NULL) {
        __sync_fetch_and_add(&val_p->count, 1);
        val_p->last_timestamp.tv_sec = timestamp.tv_sec;
        val_p->last_timestamp.tv_nsec = timestamp.tv_nsec;
        if (val_p->egress_data_valid) {
            if ((egress_valid) && (egress_port == val_p->egress_data.egress_port) &&
                (val_p->egress_data.tc == mirror_tclass)) {
                if (val_p->egress_data.latency_watermark < mirror_latency) {
                    val_p->egress_data.latency_watermark = mirror_latency;
                }
                if (val_p->egress_data.port_tc_watermark < mirror_cong) {
                    val_p->egress_data.port_tc_watermark = mirror_cong;
                }
            } else {
                val_p->egress_data_valid = 0;
            }
        }
    } else {
        value.count = 1;
        value.first_timestamp.tv_sec = timestamp.tv_sec;
        value.first_timestamp.tv_nsec = timestamp.tv_nsec;
        value.last_timestamp.tv_sec = timestamp.tv_sec;
        value.last_timestamp.tv_nsec = timestamp.tv_nsec;

        if (egress_valid && (mirror_tclass != 0x1F)) {
            value.egress_data_valid = 1;
            value.egress_data.egress_port = egress_port;
            value.egress_data.tc = mirror_tclass;
            value.egress_data.latency_watermark = mirror_latency;
            value.egress_data.port_tc_watermark = mirror_cong;
        }

        bpf_map_update_elem(&wjh_agg_buffer_map, &key, &value, BPF_ANY);
    }

    return 0;
}

char _license[] SEC("license") = "GPL";
