/*
 * Copyright © 2019-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <uapi/linux/bpf.h>
#include "bpf_helpers.h"

#define WJH_TRAP_ID_DISCARD_NON_ROUTED                0x11a
#define WJH_TRAP_ID_DISCARD_ROUTER2                   0x130
#define WJH_TRAP_ID_HOST_MISS_IPV4                    0x90
#define WJH_TRAP_ID_HOST_MISS_IPV6                    0x92
#define WJH_TRAP_ID_DISCARD_ROUTER3                   0x131
#define WJH_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0           0x1b0
#define WJH_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1           0x1b1
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR         0x160
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC 0x161
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB         0x162
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC         0x163
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E    0x164
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB         0x165
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP       0x166
#define WJH_TRAP_ID_IPV6_UNSPECIFIED_SIP              0x7b
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR         0x167
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC        0x168
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP        0x169
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC         0x16a
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET  0x16b
#define WJH_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL 0x16c
#define WJH_TRAP_ID_DISCARD_ROUTER_IRIF_EN            0x178
#define WJH_TRAP_ID_DISCARD_ROUTER_ERIF_EN            0X179
#define WJH_TRAP_ID_DISCARD_ROUTER_LPM4               0x17b
#define WJH_TRAP_ID_DISCARD_ROUTER_LPM6               0x17c
#define WJH_TRAP_ID_ETH_L3_LBERROR                    0x54
#define WJH_TRAP_ID_ETH_L3_MTUERROR                   0x52
#define WJH_TRAP_ID_ETH_L3_TTLERROR                   0x53
#define WJH_TRAP_ID_ETH_URPF_PROTECTION               0x7f

struct bpf_map_def SEC("maps") wjh_agg_router_map =
{
    .type = BPF_MAP_TYPE_HASH,
    .key_size = sizeof(wjh_agg_ebpf_key_t),
    .value_size = sizeof(wjh_agg_ebpf_value_t),
    .max_entries = 1024,
};

static inline int is_router_drop_trap_id(uint32_t trap_id)
{
    switch (trap_id) {
    case WJH_TRAP_ID_DISCARD_NON_ROUTED:
    case WJH_TRAP_ID_DISCARD_ROUTER2:
    case WJH_TRAP_ID_HOST_MISS_IPV4:
    case WJH_TRAP_ID_HOST_MISS_IPV6:
    case WJH_TRAP_ID_DISCARD_ROUTER3:
    case WJH_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0:
    case WJH_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP:
    case WJH_TRAP_ID_IPV6_UNSPECIFIED_SIP:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET:
    case WJH_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL:
    case WJH_TRAP_ID_DISCARD_ROUTER_IRIF_EN:
    case WJH_TRAP_ID_DISCARD_ROUTER_ERIF_EN:
    case WJH_TRAP_ID_DISCARD_ROUTER_LPM4:
    case WJH_TRAP_ID_DISCARD_ROUTER_LPM6:
    case WJH_TRAP_ID_ETH_L3_LBERROR:
    case WJH_TRAP_ID_ETH_L3_MTUERROR:
    case WJH_TRAP_ID_ETH_L3_TTLERROR:
    case WJH_TRAP_ID_ETH_URPF_PROTECTION:
        return 1;

    default:
        return 0;
    }
}

static inline uint32_t router_drop_trap_id_to_reason_id(uint32_t trap_id)
{
    switch (trap_id) {
    case WJH_TRAP_ID_DISCARD_NON_ROUTED:
        return WJH_DROP_REASON_ID_NON_ROUTABLE_PACKET_E;

    case WJH_TRAP_ID_DISCARD_ROUTER2:
        return WJH_DROP_REASON_ID_BLACKHOLE_ROUTE_E;

    case WJH_TRAP_ID_HOST_MISS_IPV4:
        return WJH_DROP_REASON_ID_UNRESOLVED_NEIGHBOR_NEXT_HOP_E;

    case WJH_TRAP_ID_HOST_MISS_IPV6:
        return WJH_DROP_REASON_ID_UNRESOLVED_NEIGHBOR_NEXT_HOP_E;

    case WJH_TRAP_ID_DISCARD_ROUTER3:
        return WJH_DROP_REASON_ID_BLACKHOLE_ARP_NEIGHBOR_E;

    case WJH_TRAP_ID_DISCARD_MC_SCOPE_IPV6_0:
        return WJH_DROP_REASON_ID_IPV6_DESTINATION_IN_MULTICAST_SCOPE_FFX0_16_E;

    case WJH_TRAP_ID_DISCARD_MC_SCOPE_IPV6_1:
        return WJH_DROP_REASON_ID_IPV6_DESTINATION_IN_MULTICAST_SCOPE_FFX1_16_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_NO_HDR:
        return WJH_DROP_REASON_ID_NON_IP_PACKET_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_UC_DIP_MC_DMAC:
        return WJH_DROP_REASON_ID_UNICAST_DESTINATION_IP_BUT_MULTICAST_DESTINATION_MAC_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_DIP_LB:
        return WJH_DROP_REASON_ID_DESTINATION_IP_IS_LOOPBACK_ADDRESS_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_MC:
        return WJH_DROP_REASON_ID_SOURCE_IP_IS_MULTICAST_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_CLASS_E:
        return WJH_DROP_REASON_ID_SOURCE_IP_IS_IN_CLASS_E_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_LB:
        return WJH_DROP_REASON_ID_SOURCE_IP_IS_LOOPBACK_ADDRESS_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_UNSP:
        return WJH_DROP_REASON_ID_SOURCE_IP_IS_UNSPECIFIED_E;

    case WJH_TRAP_ID_IPV6_UNSPECIFIED_SIP:
        return WJH_DROP_REASON_ID_SOURCE_IP_IS_UNSPECIFIED_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_IP_HDR:
        return WJH_DROP_REASON_ID_CHECKSUM_OR_IPVER_OR_IPV4_IHL_TOO_SHORT_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_MC_DMAC:
        return WJH_DROP_REASON_ID_MULTICAST_MAC_MISMATCH_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_DIP:
        return WJH_DROP_REASON_ID_SOURCE_IP_EQUALS_DESTINATION_IP_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_SIP_BC:
        return WJH_DROP_REASON_ID_IPV4_SOURCE_IP_IS_LIMITED_BROADCAST_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_DIP_LOCAL_NET:
        return WJH_DROP_REASON_ID_IPV4_DESTINATION_IP_IS_LOCAL_NETWORK_E;

    case WJH_TRAP_ID_DISCARD_ING_ROUTER_DIP_LINK_LOCAL:
        return WJH_DROP_REASON_ID_IPV4_DESTINATION_IP_IS_LINK_LOCAL_E;

    case WJH_TRAP_ID_DISCARD_ROUTER_IRIF_EN:
        return WJH_DROP_REASON_ID_INGRESS_ROUTER_INTERFACE_IS_DISABLED_E;

    case WJH_TRAP_ID_DISCARD_ROUTER_ERIF_EN:
        return WJH_DROP_REASON_ID_EGRESS_ROUTER_INTERFACE_IS_DISABLED_E;

    case WJH_TRAP_ID_DISCARD_ROUTER_LPM4:
        return WJH_DROP_REASON_ID_IPV4_ROUTING_TABLE_LPM_UNICAST_MISS_E;

    case WJH_TRAP_ID_DISCARD_ROUTER_LPM6:
        return WJH_DROP_REASON_ID_IPV6_ROUTING_TABLE_LPM_UNICAST_MISS_E;

    case WJH_TRAP_ID_ETH_L3_LBERROR:
        return WJH_DROP_REASON_ID_ROUTER_INTERFACE_LOOPBACK_E;

    case WJH_TRAP_ID_ETH_L3_MTUERROR:
        return WJH_DROP_REASON_ID_PACKET_SIZE_IS_LARGER_THAN_ROUTER_INTERFACE_MTU_E;

    case WJH_TRAP_ID_ETH_L3_TTLERROR:
        return WJH_DROP_REASON_ID_TTL_VALUE_IS_TOO_SMALL_E;

    case WJH_TRAP_ID_ETH_URPF_PROTECTION:
        return WJH_DROP_REASON_ID_URPF_PROTECTION;

    default:
        return 0;
    }
}

SEC("wjh_agg_router_bpf_prog")
int agg_router_prog(struct __sk_buff *skb)
{
    wjh_agg_ebpf_key_t       key = {0};
    wjh_agg_ebpf_value_t     value = {0};
    wjh_agg_ebpf_value_t    *val_p = NULL;
    uint32_t                 index = 0;
    wjh_agg_ebpf_timestamp_t timestamp;
    void                    *data = (void*)(long)skb->data;
    void                    *data_end = (void*)(long)skb->data_end;
    uint32_t                *agg_key_mode_p = NULL;
    int                      ret = 0;
    uint16_t                 trap_id = (skb->cb[0]) >> 16;
    uint32_t                 port = skb->cb[4];

    timestamp.tv_sec = skb->cb[2];
    timestamp.tv_nsec = skb->cb[3];

    if (!is_router_drop_trap_id(trap_id)) {
        return 0;
    }

    agg_key_mode_p = bpf_map_lookup_elem(&wjh_agg_comm_map, &index);
    if (agg_key_mode_p == NULL) {
        return 0;
    }

    ret = flow_dissector(data, data_end, &key, NULL);
    if (ret == -1) {
        return 0;
    }

    if (ret == 0) {
        key.non_ip = 1;
    }

    if (*agg_key_mode_p != WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
        key.port = 0;
        key.vlan = 0;
        key.ether_type = 0;
        __builtin_memset(key.dmac, 0, ETH_ALEN);
        __builtin_memset(key.smac, 0, ETH_ALEN);
    } else {
        key.port = port;
    }

    key.reason_id = router_drop_trap_id_to_reason_id(trap_id);
    WJH_AGG_UPDATE_EBPF_MAP(wjh_agg_router_map);

    return 0;
}

char _license[] SEC("license") = "GPL";
