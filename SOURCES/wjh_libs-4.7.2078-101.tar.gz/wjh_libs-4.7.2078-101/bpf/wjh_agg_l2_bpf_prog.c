/*
 * Copyright © 2019-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <uapi/linux/bpf.h>
#include "bpf_helpers.h"
#include <uapi/linux/if_ether.h>

#define WJH_TRAP_ID_DISCARD_ISOLATION              0x119
#define WJH_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC     0x142
#define WJH_TRAP_ID_DISCARD_ING_PACKET_SMAC0       0x143
#define WJH_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW  0x148
#define WJH_TRAP_ID_DISCARD_ING_SWITCH_VLAN        0x149
#define WJH_TRAP_ID_DISCARD_ING_SWITCH_STP         0x14a
#define WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC       0x150
#define WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL  0x151
#define WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB       0x152
#define WJH_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC     0x140
#define WJH_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC   0x141
#define WJH_TRAP_ID_FID_MISS                       0x3d
#define WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS 0x153

struct bpf_map_def SEC("maps") wjh_agg_l2_map =
{
    .type = BPF_MAP_TYPE_HASH,
    .key_size = sizeof(wjh_agg_ebpf_key_t),
    .value_size = sizeof(wjh_agg_ebpf_value_t),
    .max_entries = 1024,
};

static inline int is_l2_drop_trap_id(uint32_t trap_id)
{
    switch (trap_id) {
    case WJH_TRAP_ID_DISCARD_ISOLATION:
    case WJH_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC:
    case WJH_TRAP_ID_DISCARD_ING_PACKET_SMAC0:
    case WJH_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW:
    case WJH_TRAP_ID_DISCARD_ING_SWITCH_VLAN:
    case WJH_TRAP_ID_DISCARD_ING_SWITCH_STP:
    case WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC:
    case WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL:
    case WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB:
    case WJH_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC:
    case WJH_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC:
    case WJH_TRAP_ID_FID_MISS:
    case WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS:
        return 1;

    default:
        return 0;
    }
}

static inline uint32_t l2_drop_trap_id_to_reason_id(uint32_t trap_id)
{
    switch (trap_id) {
    case WJH_TRAP_ID_DISCARD_ISOLATION:
        return WJH_DROP_REASON_ID_MLAG_PORT_ISOLATION_E;

    case WJH_TRAP_ID_DISCARD_ING_PACKET_RSV_MAC:
        return WJH_DROP_REASON_ID_DESTINATION_MAC_IS_RESERVED_DMAC_IS_01_80_C2_00_00_0X_E;

    case WJH_TRAP_ID_DISCARD_ING_PACKET_SMAC0:
        return WJH_DROP_REASON_ID_SOURCE_MAC_IS_ZERO_E;

    case WJH_TRAP_ID_DISCARD_ING_SWITCH_VTAG_ALLOW:
        return WJH_DROP_REASON_ID_VLAN_TAGGING_MISMATCH_E;

    case WJH_TRAP_ID_DISCARD_ING_SWITCH_VLAN:
        return WJH_DROP_REASON_ID_INGRESS_VLAN_FILTERING_E;

    case WJH_TRAP_ID_DISCARD_ING_SWITCH_STP:
        return WJH_DROP_REASON_ID_INGRESS_SPANNING_TREE_FILTER_E;

    case WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_UC:
        return WJH_DROP_REASON_ID_UNICAST_MAC_TABLE_ACTION_DISCARD_E;

    case WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_MC_NULL:
        return WJH_DROP_REASON_ID_MULTICAST_EGRESS_PORT_LIST_IS_EMPTY_E;

    case WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_LB:
        return WJH_DROP_REASON_ID_PORT_LOOPBACK_FILTER_E;

    case WJH_TRAP_ID_DISCARD_ING_PACKET_SMAC_MC:
        return WJH_DROP_REASON_ID_SOURCE_MAC_IS_MULTICAST_E;

    case WJH_TRAP_ID_DISCARD_ING_PACKET_SMAC_DMAC:
        return WJH_DROP_REASON_ID_SOURCE_MAC_EQUALS_DESTINATION_MAC_E;

    case WJH_TRAP_ID_FID_MISS:
        return WJH_DROP_REASON_ID_VLAN_OR_VNI_LOOKUP_FAILED_E;

    case WJH_TRAP_ID_DISCARD_LOOKUP_SWITCH_NO_PORTS:
        return WJH_DROP_REASON_ID_UNICAST_EGRESS_PORT_LIST_IS_EMPTY_E;

    default:
        return 0;
    }
}

SEC("wjh_agg_l2_bpf_prog")
int agg_l2_prog(struct __sk_buff *skb)
{
    wjh_agg_ebpf_key_t       key = {0};
    wjh_agg_ebpf_value_t     value = {0};
    wjh_agg_ebpf_value_t    *val_p = NULL;
    uint32_t                 index = 0;
    wjh_agg_ebpf_timestamp_t timestamp;
    void                    *data = (void*)(long)skb->data;
    void                    *data_end = (void*)(long)skb->data_end;
    uint32_t                *agg_key_mode_p = NULL;
    int                      ret = 0;
    uint16_t                 trap_id = (skb->cb[0]) >> 16;
    uint32_t                 port = skb->cb[4];

    timestamp.tv_sec = skb->cb[2];
    timestamp.tv_nsec = skb->cb[3];

    if (!is_l2_drop_trap_id(trap_id)) {
        return 0;
    }

    agg_key_mode_p = bpf_map_lookup_elem(&wjh_agg_comm_map, &index);
    if (agg_key_mode_p == NULL) {
        return 0;
    }

    ret = flow_dissector(data, data_end, &key, NULL);
    if (ret == -1) {
        return 0;
    }

    if (ret == 0) {
        key.non_ip = 1;
    }

    if (*agg_key_mode_p == WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
        key.port = port;
    } else {
        key.vlan = 0;
        key.ether_type = 0;
    }

    key.reason_id = l2_drop_trap_id_to_reason_id(trap_id);
    WJH_AGG_UPDATE_EBPF_MAP(wjh_agg_l2_map);

    return 0;
}

char _license[] SEC("license") = "GPL";
