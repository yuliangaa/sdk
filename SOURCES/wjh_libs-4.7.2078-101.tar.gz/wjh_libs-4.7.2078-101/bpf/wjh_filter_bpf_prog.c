/*
 * Copyright © 2019-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <uapi/linux/bpf.h>
#include "bpf_helpers.h"

#define WJH_ACL_DROP_REASON_ID_MIN    601
#define WJH_BUFFER_DROP_REASON_ID_MIN 503
#define WJH_ROCE_DROP_REASON_ID_MIN   701
#define WJH_TRAP_ID_MIRROR_AGENT_MIN  0X220
#define WJH_TRAP_ID_MIRROR_AGENT_MAX  0X227

#define WJH_ROCE_ACL_USER_ID_DROP_REASON(acl_user_id) ((acl_user_id) & 0xFFF)

#define ACL_DROP_DIRECTION_OFFSET 17        /* the offset to an ACL direction inside the user defined value */
#define ACL_DROP_DIRECTION_MASK   0x7       /* 3 bits that contain an ACL direction (sxd_acl_direction_t) */

typedef enum sxd_acl_direction {
    SXD_ACL_DIRECTION_INGRESS_E          = 0,
    SXD_ACL_DIRECTION_EGRESS_E           = 1,
    SXD_ACL_DIRECTION_RIF_INGRESS_E      = 2,
    SXD_ACL_DIRECTION_RIF_EGRESS_E       = 3,
    SXD_ACL_DIRECTION_TPORT_INGRESS_E    = 4,
    SXD_ACL_DIRECTION_TPORT_EGRESS_E     = 5,
    SXD_ACL_DIRECTION_SINGLE_POINT_MIN_E = SXD_ACL_DIRECTION_INGRESS_E,
    SXD_ACL_DIRECTION_SINGLE_POINT_MAX_E = SXD_ACL_DIRECTION_TPORT_EGRESS_E,
    SXD_ACL_DIRECTION_SINGLE_POINT_NUM_E = SXD_ACL_DIRECTION_SINGLE_POINT_MAX_E + 1,
    SXD_ACL_DIRECTION_MULTI_POINTS_E     = SXD_ACL_DIRECTION_SINGLE_POINT_MAX_E + 1
} sxd_acl_direction_t;

typedef struct wjh_ebpf_filter_drop_info {
    bool     is_buffer_drop;
    bool     is_mirror_agent_trap;
    uint8_t  mirror_reason;                 /* OUT */
    uint8_t  ip_proto;                      /* OUT */
    uint16_t ether_type;                    /* OUT */
    bool     is_ip;                         /* OUT */
    uint16_t label_port;                    /* OUT */
    uint8_t  is_mirror_header_v2_ext;
} wjh_ebpf_filter_drop_info_t;

static inline bool filter_parse_ip(void *data, void *data_end, __u64 nhoff, __u64 *ip_proto)
{
    struct iphdr *ip_hdr;

    if ((data + nhoff + sizeof(struct iphdr)) > data_end) {
        return false;
    }

    ip_hdr = data + nhoff;

    if (unlikely(ip_is_fragment(ip_hdr))) {
        *ip_proto = 0;
    } else {
        *ip_proto = ip_hdr->protocol;
    }

    return true;
}

static inline bool filter_parse_ipv6(void *data, void *data_end, __u64 nhoff, __u64 *ip_proto)
{
    struct ipv6hdr *ip6_hdr;

    if ((data + nhoff + sizeof(struct ipv6hdr)) > data_end) {
        return false;
    }

    ip6_hdr = data + nhoff;
    *ip_proto = ip6_hdr->nexthdr;

    return true;
}

static inline bool filter_flow_dissector(void                        *data,
                                         void                        *data_end,
                                         wjh_ebpf_filter_drop_info_t *drop_info_p)
{
    __u64                             nhoff = 0;
    __u64                             ip_proto = 0;
    __u16                             ether_type;
    int                               poff;
    __u8                              pad_count;
    __u8                              opcode;
    __u8                              mirror_reason = 0;
    struct ethhdr                    *eth = data;
    struct vlan_hdr                  *v_hdr;
    wjh_buf_drop_pkt_common_header_t *buffer_drop_common_header;
    wjh_buf_drop_pkt_hdr_ver2_t      *buffer_drop_header_v2;
    wjh_ebpf_buffer_drop_info_t       buffer_drop_info = {0};

    if ((data + sizeof(struct ethhdr)) > data_end) {
        return false;
    }

    ether_type = ntohs(eth->h_proto);

    if (drop_info_p->is_buffer_drop && (!drop_info_p->is_mirror_agent_trap)) {
        if (ether_type != WJH_BUF_DROP_HDR_COMMON_ETHER_TYPE) {
            return false;
        }

        if ((data + sizeof(wjh_buf_drop_pkt_common_header_t)) > data_end) {
            return false;
        }
        buffer_drop_common_header = data;

        drop_info_p->label_port = ntohs(buffer_drop_common_header->ingress_label_port);

        opcode = buffer_drop_common_header->opcode & WJH_BUF_DROP_HDR_OPCODE_MASK_BYTE;
        if (opcode == WJH_BUF_DROP_HDR_OPCODE_VER_1) {
            pad_count = buffer_drop_common_header->pad_count;
            nhoff += sizeof(wjh_buf_drop_pkt_common_header_t) + pad_count;
        } else {
            if (drop_info_p->is_mirror_header_v2_ext) {
                nhoff += sizeof(wjh_buf_drop_pkt_hdr_ver2_ext_t);
                if ((data + sizeof(wjh_buf_drop_pkt_hdr_ver2_ext_t)) > data_end) {
                    return -1;
                }
            } else {
                nhoff += sizeof(wjh_buf_drop_pkt_hdr_ver2_t);
                if ((data + sizeof(wjh_buf_drop_pkt_hdr_ver2_t)) > data_end) {
                    return -1;
                }
            }
            buffer_drop_header_v2 = data;
            parse_mirror_header_v2(buffer_drop_header_v2, &buffer_drop_info);
            drop_info_p->mirror_reason = buffer_drop_info.mirror_reason;
        }

        if ((data + nhoff + sizeof(struct ethhdr)) > data_end) {
            return false;
        }
        eth = data + nhoff;
        ether_type = ntohs(eth->h_proto);
    }

    nhoff += sizeof(struct ethhdr);

    if (ether_type == ETH_P_8021AD) {
        if ((data + nhoff + sizeof(struct vlan_hdr)) > data_end) {
            return false;
        }
        v_hdr = data + nhoff;
        ether_type = ntohs(v_hdr->h_vlan_encapsulated_proto);
        nhoff += sizeof(struct vlan_hdr);
    }

    if (ether_type == ETH_P_8021Q) {
        if ((data + nhoff + sizeof(struct vlan_hdr)) > data_end) {
            return false;
        }
        v_hdr = data + nhoff;
        ether_type = ntohs(v_hdr->h_vlan_encapsulated_proto);
        nhoff += sizeof(struct vlan_hdr);
    }

    drop_info_p->ether_type = ether_type;
    drop_info_p->is_ip = true;

    if (likely(ether_type == ETH_P_IP)) {
        if (!filter_parse_ip(data, data_end, nhoff, &ip_proto)) {
            return false;
        }
    } else if (ether_type == ETH_P_IPV6) {
        if (!filter_parse_ipv6(data, data_end, nhoff, &ip_proto)) {
            return false;
        }
    } else {
        drop_info_p->is_ip = false;
    }

    drop_info_p->ip_proto = ip_proto;

    return true;
}

struct bpf_map_def SEC("maps") wjh_filter_bpf_map =
{
    .type = BPF_MAP_TYPE_HASH,
    .key_size = sizeof(wjh_filter_rule_ebpf_key_t),
    .value_size = sizeof(uint64_t),
    .max_entries = 1024,
};

struct bpf_map_def SEC("maps") wjh_drop_reason_bpf_map =
{
    .type = BPF_MAP_TYPE_HASH,
    .key_size = sizeof(uint32_t),
    .value_size = sizeof(uint32_t),
    .max_entries = 1024,
};

struct bpf_map_def SEC("maps") wjh_port_bpf_map =
{
    .type = BPF_MAP_TYPE_HASH,
    .key_size = sizeof(uint16_t),
    .value_size = sizeof(uint32_t),
    .max_entries = 512,
};

SEC("wjh_filter_bpf_prog")
int filter_prog(struct __sk_buff *skb)
{
    wjh_filter_rule_ebpf_key_t  key = {0};
    uint64_t                    counter = 0;
    uint64_t                   *counter_p = NULL;
    uint32_t                    trap_id = skb->cb[1];
    uint32_t                    reason_id = 0;
    uint32_t                   *reason_id_p = NULL;
    wjh_ebpf_filter_drop_info_t drop_info = {0};
    uint8_t                     ip_proto = 0;
    uint16_t                    ether_type = 0;
    uint16_t                    label_port = 0;
    bool                        is_ip = false;
    bool                        is_buffer_drop = false;
    bool                        is_mirror_agent_trap = false;
    uint8_t                     mirror_reason = ((skb->cb[3]) >> 1) & 0xff;
    uint8_t                     acl_reason = 0;
    uint32_t                    hw_port = skb->cb[0];
    uint32_t                    acl_user_id = skb->cb[2];
    uint32_t                   *hw_port_p = NULL;
    void                       *data = (void*)(long)skb->data;
    void                       *data_end = (void*)(long)skb->data_end;

    reason_id_p = bpf_map_lookup_elem(&wjh_drop_reason_bpf_map, &trap_id);

    if (!reason_id_p) {
        return 0;
    }

    reason_id = *reason_id_p;

    if (reason_id == WJH_ACL_DROP_REASON_ID_MIN) {
        acl_reason = (acl_user_id >> ACL_DROP_DIRECTION_OFFSET) & ACL_DROP_DIRECTION_MASK;

        if (acl_reason == SXD_ACL_DIRECTION_EGRESS_E) {
            reason_id = WJH_DROP_REASON_ID_EGRESS_PORT_ACL_E;
        }
        if (acl_reason == SXD_ACL_DIRECTION_RIF_INGRESS_E) {
            reason_id = WJH_DROP_REASON_ID_INGRESS_ROUTER_ACL_E;
        }
        if (acl_reason == SXD_ACL_DIRECTION_RIF_EGRESS_E) {
            reason_id = WJH_DROP_REASON_ID_EGRESS_ROUTER_ACL_E;
        }
        if (acl_reason == SXD_ACL_DIRECTION_TPORT_INGRESS_E) {
            reason_id = WJH_DROP_REASON_ID_INGRESS_TPORT_ACL_E;
        }
        if (acl_reason == SXD_ACL_DIRECTION_TPORT_EGRESS_E) {
            reason_id = WJH_DROP_REASON_ID_EGRESS_TPORT_ACL_E;
        }
        if (acl_reason == SXD_ACL_DIRECTION_MULTI_POINTS_E) {
            reason_id = WJH_DROP_REASON_ID_MULTI_POINTS_ACL_E;
        }
    }

    if (reason_id == WJH_BUFFER_DROP_REASON_ID_MIN) {
        is_buffer_drop = true;
    }

    if ((trap_id >= WJH_TRAP_ID_MIRROR_AGENT_MIN) &&
        (trap_id <= WJH_TRAP_ID_MIRROR_AGENT_MAX)) {
        is_mirror_agent_trap = true;
    }

    if (reason_id == WJH_ROCE_DROP_REASON_ID_MIN) {
        reason_id = WJH_ROCE_ACL_USER_ID_DROP_REASON(acl_user_id);
    }

    drop_info.is_buffer_drop = is_buffer_drop;
    drop_info.is_mirror_agent_trap = is_mirror_agent_trap;
    drop_info.mirror_reason = mirror_reason;
    drop_info.is_mirror_header_v2_ext = (skb->cb[3]) & 0x1;

    if (!filter_flow_dissector(data, data_end, &drop_info)) {
        return -1;
    }

    is_ip = drop_info.is_ip;
    ether_type = drop_info.ether_type;
    ip_proto = drop_info.ip_proto;
    label_port = drop_info.label_port;

    if (is_buffer_drop && (!is_mirror_agent_trap)) {
        hw_port = 0;
        hw_port_p = bpf_map_lookup_elem(&wjh_port_bpf_map, &label_port);
        if (hw_port_p) {
            hw_port = *hw_port_p;
        }
    }

    if (drop_info.mirror_reason != WJH_SPAN_MIRROR_REASON_INVALID) {
        if (drop_info.mirror_reason == WJH_SPAN_MIRROR_REASON_ING_SHARED_BUFFER_DROP) {
            reason_id = WJH_DROP_REASON_ID_TAIL_DROP_E;
        } else if (drop_info.mirror_reason == WJH_SPAN_MIRROR_REASON_ING_WRED) {
            reason_id = WJH_DROP_REASON_ID_WRED_E;
        } else if (drop_info.mirror_reason == WJH_SPAN_MIRROR_REASON_ING_TC_CONGESTION) {
            reason_id = WJH_DROP_REASON_ID_ING_TC_CONGESTION;
        } else if (drop_info.mirror_reason == WJH_SPAN_MIRROR_REASON_EGR_TC_LATENCY) {
            reason_id = WJH_DROP_REASON_ID_EGR_TC_LATENCY;
        } else {
            return 0;
        }
    }

    /* one key only */
    /* port */
    key.hw_port = hw_port;
    key.drop_reason = 0;
    key.ip_proto = 0;
    key.ether_type = 0;
    key.valid_mask = 0x1;

    counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
    if (counter_p) {
        goto found;
    }

    /* drop reason */
    key.hw_port = 0;
    key.drop_reason = reason_id;
    key.ip_proto = 0;
    key.ether_type = 0;
    key.valid_mask = 0x2;
    counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
    if (counter_p) {
        goto found;
    }

    if (is_ip) {
        /* ip proto */
        key.hw_port = 0;
        key.drop_reason = 0;
        key.ip_proto = ip_proto;
        key.ether_type = 0;
        key.valid_mask = 0x4;
        counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
        if (counter_p) {
            goto found;
        }
    }

    /* ether type */
    key.hw_port = 0;
    key.drop_reason = 0;
    key.ip_proto = 0;
    key.ether_type = ether_type;
    key.valid_mask = 0x8;
    counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
    if (counter_p) {
        goto found;
    }

    /* 2 keys */
    /* port, drop reason */
    key.hw_port = hw_port;
    key.drop_reason = reason_id;
    key.ip_proto = 0;
    key.ether_type = 0;
    key.valid_mask = 0x3;
    counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
    if (counter_p) {
        goto found;
    }

    if (is_ip) {
        /* port, ip proto */
        key.hw_port = hw_port;
        key.drop_reason = 0;
        key.ip_proto = ip_proto;
        key.ether_type = 0;
        key.valid_mask = 0x5;
        counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
        if (counter_p) {
            goto found;
        }
    }

    /* port, ether type */
    key.hw_port = hw_port;
    key.ip_proto = 0;
    key.ether_type = ether_type;
    key.valid_mask = 0x9;
    counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
    if (counter_p) {
        goto found;
    }

    if (is_ip) {
        /* drop reason, ip proto */
        key.hw_port = 0;
        key.drop_reason = reason_id;
        key.ip_proto = ip_proto;
        key.ether_type = 0;
        key.valid_mask = 0x6;
        counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
        if (counter_p) {
            goto found;
        }
    }

    /* drop reason, ether type */
    key.hw_port = 0;
    key.ip_proto = 0;
    key.drop_reason = reason_id;
    key.ether_type = ether_type;
    key.valid_mask = 0xa;
    counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
    if (counter_p) {
        goto found;
    }

    if (is_ip) {
        /* ip proto, ether type */
        key.hw_port = 0;
        key.drop_reason = 0;
        key.ip_proto = ip_proto;
        key.ether_type = ether_type;
        key.valid_mask = 0xc;
        counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
        if (counter_p) {
            goto found;
        }
    }

    /* 3 keys */
    if (is_ip) {
        /* port, drop reason, ip proto */
        key.hw_port = hw_port;
        key.drop_reason = reason_id;
        key.ip_proto = ip_proto;
        key.ether_type = 0;
        key.valid_mask = 7;
        counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
        if (counter_p) {
            goto found;
        }
    }

    /* port, drop reason, ether type */
    key.hw_port = hw_port;
    key.drop_reason = reason_id;
    key.ip_proto = 0;
    key.ether_type = ether_type;
    key.valid_mask = 0xb;
    counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
    if (counter_p) {
        goto found;
    }

    if (is_ip) {
        /* port, ip proto, ether type */
        key.hw_port = hw_port;
        key.drop_reason = 0;
        key.ip_proto = ip_proto;
        key.ether_type = ether_type;
        key.valid_mask = 0xd;
        counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
        if (counter_p) {
            goto found;
        }

        /* drop reason, ip proto, ether type */
        key.hw_port = 0;
        key.drop_reason = reason_id;
        key.ip_proto = ip_proto;
        key.ether_type = ether_type;
        key.valid_mask = 0xe;
        counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
        if (counter_p) {
            goto found;
        }

        /* port, drop reason, ip proto, ether type */
        key.hw_port = hw_port;
        key.drop_reason = reason_id;
        key.ip_proto = ip_proto;
        key.ether_type = ether_type;
        key.valid_mask = 0xf;
        counter_p = bpf_map_lookup_elem(&wjh_filter_bpf_map, &key);
        if (counter_p) {
            goto found;
        }
    }

    return 0;

found:
    counter = *counter_p + 1;
    bpf_map_update_elem(&wjh_filter_bpf_map, &key, &counter, BPF_ANY);

    return -1;
}

char _license[] SEC("license") = "GPL";
