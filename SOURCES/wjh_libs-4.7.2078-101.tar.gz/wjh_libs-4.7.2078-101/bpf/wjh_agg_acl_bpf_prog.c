/*
 * Copyright © 2019-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <uapi/linux/bpf.h>
#include <uapi/linux/time.h>
#include "bpf_helpers.h"

#define WJH_TRAP_ID_ACL_DROP     0x1eb
#define WJH_TRAP_ID_SYS_ACL_DROP 0x1ea

struct bpf_map_def SEC("maps") wjh_agg_acl_map =
{
    .type = BPF_MAP_TYPE_HASH,
    .key_size = sizeof(wjh_agg_ebpf_key_t),
    .value_size = sizeof(wjh_agg_ebpf_value_t),
    .max_entries = 1024,
};

SEC("wjh_agg_acl_bpf_prog")
int agg_acl_prog(struct __sk_buff *skb)
{
    wjh_agg_ebpf_key_t       key = {0};
    wjh_agg_ebpf_value_t     value = {0};
    wjh_agg_ebpf_value_t    *val_p = NULL;
    wjh_agg_ebpf_timestamp_t timestamp;
    void                    *data = (void*)(long)skb->data;
    void                    *data_end = (void*)(long)skb->data_end;
    uint32_t                 index = 0;
    uint32_t                *agg_key_mode_p = NULL;
    int                      ret = 0;
    uint16_t                 trap_id = (skb->cb[0]) >> 16;
    uint32_t                 port = skb->cb[4];
    uint32_t                 acl_user_id = skb->cb[1] >> 9;

    timestamp.tv_sec = skb->cb[2];
    timestamp.tv_nsec = skb->cb[3];

    if ((trap_id != WJH_TRAP_ID_ACL_DROP) && (trap_id != WJH_TRAP_ID_SYS_ACL_DROP)) {
        return 0;
    }

    agg_key_mode_p = bpf_map_lookup_elem(&wjh_agg_comm_map, &index);
    if (agg_key_mode_p == NULL) {
        return 0;
    }

    if (*agg_key_mode_p == WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
        ret = flow_dissector(data, data_end, &key, NULL);
        if (ret == -1) {
            return 0;
        }

        if (ret == 0) {
            key.non_ip = 1;
        }
        key.port = port;
    }

    key.reason_id = acl_user_id;

    WJH_AGG_UPDATE_EBPF_MAP(wjh_agg_acl_map);

    return 0;
}

char _license[] SEC("license") = "GPL";
