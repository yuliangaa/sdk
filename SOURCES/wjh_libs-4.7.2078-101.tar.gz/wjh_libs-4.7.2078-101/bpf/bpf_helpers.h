/*
 * Copyright © 2019-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#ifndef __BPF_HELPERS_H
#define __BPF_HELPERS_H

/* Since the llvm doesn't support "asm goto", in newer kernels (4.19 or above), "asm goto" exists in some of the kernel header files.
 * Add the below defines to solve the compilation issue on newer kernels.
 */
#ifdef asm_volatile_goto
#undef asm_volatile_goto
#endif
#define asm_volatile_goto(x ...) asm volatile ("invalid use of asm_volatile_goto")

/* In Linux 5.4 asm_inline was introduced, but it's not supported by clang (version < 9).
 * Redefine it to just asm to enable successful compilation.
 * This redefinition doesn't affect the BPF functionality.
 */
#ifdef asm_inline
#undef asm_inline
#define asm_inline asm
#endif

#include <uapi/linux/in.h>
#include <uapi/linux/if.h>
#include <uapi/linux/if_ether.h>
#include <uapi/linux/ip.h>
#include <uapi/linux/ipv6.h>
#include <uapi/linux/if_tunnel.h>
#include "../src/wjh_ebpf_types.h"
#include "../include/wjh/wjh_lib_types.h"
#include "../src/wjh_kernel_user.h"

/* helper macro to place programs, maps, license in
 * different sections in elf_bpf file. Section names
 * are interpreted by elf_bpf loader
 */
#define SEC(NAME) __attribute__((section(NAME), used))

/* helper functions called from eBPF programs written in C */
static void *(*bpf_map_lookup_elem)(void *map, void *key) =
    (void*)BPF_FUNC_map_lookup_elem;
static int (*bpf_map_update_elem)(void *map, void *key, void *value,
                                  unsigned long long flags) =
    (void*)BPF_FUNC_map_update_elem;
static int (*bpf_map_delete_elem)(void *map, void *key) =
    (void*)BPF_FUNC_map_delete_elem;
static void (*bpf_tail_call)(void *ctx, void *map, int index) =
    (void*)BPF_FUNC_tail_call;
static int (*bpf_probe_read)(void *dst, int size, void *unsafe_ptr) =
    (void*)BPF_FUNC_probe_read;
static int (*bpf_trace_printk)(const char *fmt, int fmt_size, ...) =
    (void*)BPF_FUNC_trace_printk;
struct sk_buff;
unsigned long long load_byte(void              *skb,
                             unsigned long long off) asm ("llvm.bpf.load.byte");
unsigned long long load_half(void              *skb,
                             unsigned long long off) asm ("llvm.bpf.load.half");
unsigned long long load_word(void              *skb,
                             unsigned long long off) asm ("llvm.bpf.load.word");

/* a helper structure used by eBPF C program
 * to describe map attributes to elf_bpf loader
 */
struct bpf_map_def {
    unsigned int type;
    unsigned int key_size;
    unsigned int value_size;
    unsigned int max_entries;
    unsigned int map_flags;
};

/* This communication map is shared by all the drop reason groups to pass information between user space and eBPF programs.
 * It contains three entries - the first entry stores the aggregation key mode (streaming or detailed), the second entry stores
 * the trap ID used by buffer drop reason group, the third entry stores the timestamp source which is needed by buffer drop
 * reason group.
 */
struct bpf_map_def SEC("maps") wjh_agg_comm_map =
{
    .type = BPF_MAP_TYPE_ARRAY,
    .key_size = sizeof(uint32_t),
    .value_size = sizeof(uint32_t),
    .max_entries = 3,
};

static inline void wjh_agg_ebpf_prepare_value(wjh_agg_ebpf_value_t       *out,
                                              const wjh_agg_ebpf_value_t *in,
                                              const struct timespec      *timestamp)
{
    time_t tv_sec = timestamp->tv_sec;
    long   tv_nsec = timestamp->tv_nsec;

    if (in != NULL) {
        out->count = in->count + 1;
        out->first_timestamp.tv_sec = in->first_timestamp.tv_sec;
        out->first_timestamp.tv_nsec = in->first_timestamp.tv_nsec;
    } else {
        out->count = 1;
        out->first_timestamp.tv_sec = tv_sec;
        out->first_timestamp.tv_nsec = tv_nsec;
    }

    out->last_timestamp.tv_sec = tv_sec;
    out->last_timestamp.tv_nsec = tv_nsec;
}

#define WJH_AGG_UPDATE_EBPF_MAP(map)                       \
    val_p = bpf_map_lookup_elem(&map, &key);               \
    if (val_p != NULL) {                                   \
        __sync_fetch_and_add(&val_p->count, 1);            \
        val_p->last_timestamp.tv_sec = timestamp.tv_sec;   \
        val_p->last_timestamp.tv_nsec = timestamp.tv_nsec; \
    } else {                                               \
        value.count = 1;                                   \
        value.first_timestamp.tv_sec = timestamp.tv_sec;   \
        value.first_timestamp.tv_nsec = timestamp.tv_nsec; \
        value.last_timestamp.tv_sec = timestamp.tv_sec;    \
        value.last_timestamp.tv_nsec = timestamp.tv_nsec;  \
        bpf_map_update_elem(&map, &key, &value, BPF_ANY);  \
    }


#define IP_MF     0x2000
#define IP_OFFSET 0x1FFF

struct vlan_hdr {
    __be16 h_vlan_TCI;
    __be16 h_vlan_encapsulated_proto;
};

typedef struct wjh_ebpf_buffer_drop_info {
    int                      is_mirror_agent_trap;
    int                      is_hw_clock;
    uint8_t                  mirror_reason;         /* OUT */
    uint8_t                  egress_valid;          /* OUT */
    uint32_t                 egress_port;           /* OUT */
    uint8_t                  tclass;                /* OUT */
    uint32_t                 latency;               /* OUT */
    uint32_t                 cong;                  /* OUT */
    wjh_agg_ebpf_timestamp_t timestamp;
    uint8_t                  is_mirror_header_v2_ext;
} wjh_ebpf_buffer_drop_info_t;

static inline int proto_ports_offset(__u64 proto, __u64 *nhoff)
{
    switch (proto) {
    case IPPROTO_TCP:
    case IPPROTO_UDP:
    case IPPROTO_DCCP:
    case IPPROTO_ESP:
    case IPPROTO_SCTP:
    case IPPROTO_UDPLITE:
        return 0;

    case IPPROTO_AH:
        *nhoff += 4;
        return 0;

    default:
        return -1;
    }
}

static inline __u8 my_load_byte(void* addr, __u64 offset)
{
    return *((__u8*)addr + offset);
}

static inline __u16 my_load_half(void* addr, __u64 offset)
{
    return ntohs(*(__u16*)((__u8*)addr + offset));
}

static inline __u32 my_load_word(void* addr, __u64 offset)
{
    return *(__u32*)((__u8*)addr + offset);
}

static inline int ip_is_fragment(struct iphdr *ip_hdr)
{
    return ntohs(ip_hdr->frag_off) & (IP_MF | IP_OFFSET);
}

static inline int parse_ip(void *data, void *data_end, __u64 *nhoff, __u64 *ip_proto,  wjh_agg_ebpf_key_t *ebpf_key)
{
    struct iphdr *ip_hdr;

    if ((data + (*nhoff) + sizeof(struct iphdr)) > data_end) {
        return -1;
    }

    ip_hdr = data + (*nhoff);

    if (unlikely(ip_is_fragment(ip_hdr))) {
        *ip_proto = 0;
    } else {
        *ip_proto = ip_hdr->protocol;
    }

    ebpf_key->five_tuples.sip[0] = ip_hdr->saddr;
    ebpf_key->five_tuples.dip[0] = ip_hdr->daddr;

    *nhoff += ((ip_hdr->ihl) << 2);

    return 0;
}

static inline int parse_ipv6(void *data, void *data_end, __u64 *nhoff, __u64 *ip_proto, wjh_agg_ebpf_key_t *ebpf_key)
{
    struct ipv6hdr *ip6_hdr;

    if ((data + (*nhoff) + sizeof(struct ipv6hdr)) > data_end) {
        return -1;
    }

    ip6_hdr = data + (*nhoff);
    *ip_proto = ip6_hdr->nexthdr;
    __builtin_memcpy(ebpf_key->five_tuples.sip, &ip6_hdr->saddr, 16);
    __builtin_memcpy(ebpf_key->five_tuples.dip, &ip6_hdr->daddr, 16);

    *nhoff += sizeof(struct ipv6hdr);

    return 0;
}

static inline void parse_mirror_header_v2(wjh_buf_drop_pkt_hdr_ver2_t *header,
                                          wjh_ebpf_buffer_drop_info_t *buffer_drop_info)
{
    buffer_drop_info->cong = __constant_ntohl(header->mirror_header_tlvs_long[1]) &
                             WJH_BUF_DROP_HDR_EXTENDED_VALUE_MASK_LONG;
    buffer_drop_info->latency = __constant_ntohl(header->mirror_header_tlvs_long[2]) &
                                WJH_BUF_DROP_HDR_EXTENDED_VALUE_MASK_LONG;
    buffer_drop_info->mirror_reason = ntohs(header->mirror_header_tlvs_short[0]) &
                                      WJH_BUF_DROP_HDR_EXTENDED_VALUE_MASK_SHORT;
    buffer_drop_info->tclass = ntohs(header->mirror_header_tlvs_short[1]) & WJH_BUF_DROP_HDR_EXTENDED_VALUE_MASK_SHORT;

    return;
}

static inline int flow_dissector(void                        *data,
                                 void                        *data_end,
                                 wjh_agg_ebpf_key_t          *ebpf_key,
                                 wjh_ebpf_buffer_drop_info_t *buffer_drop_info)
{
    __u64                             nhoff = 0;
    __u64                             ip_proto;
    struct ethhdr                    *eth = data;
    struct vlan_hdr                  *v_hdr;
    __u16                             proto;
    int                               poff;
    __u8                              opcode;
    __u8                              pad_count;
    wjh_buf_drop_pkt_common_header_t *buffer_drop_common_header;
    wjh_buf_drop_pkt_hdr_ver2_t      *buffer_drop_header_v2;
    __u8                              is_lag;
    __u16                             ingress_label_port;
    __u8                              egress_is_lag;
    __u16                             egress_label_port;
    __u32                             secs_msb;
    __u32                             nsecs_msb;
    __u16                             secs_lsb;
    __u16                             nsecs_lsb;

    if ((data + sizeof(struct ethhdr)) > data_end) {
        return -1;
    }

    proto = ntohs(eth->h_proto);

    if ((buffer_drop_info != NULL) && !buffer_drop_info->is_mirror_agent_trap) {
        if (proto != WJH_BUF_DROP_HDR_COMMON_ETHER_TYPE) {
            return -1;
        }

        if ((data + sizeof(wjh_buf_drop_pkt_common_header_t)) > data_end) {
            return -1;
        }
        buffer_drop_common_header = data;
        opcode = buffer_drop_common_header->opcode & WJH_BUF_DROP_HDR_OPCODE_MASK_BYTE;
        if (opcode == WJH_BUF_DROP_HDR_OPCODE_VER_1) {
            pad_count = buffer_drop_common_header->pad_count;
            nhoff += sizeof(wjh_buf_drop_pkt_common_header_t) + pad_count;
        } else {
            if (buffer_drop_info->is_mirror_header_v2_ext) {
                nhoff += sizeof(wjh_buf_drop_pkt_hdr_ver2_ext_t);
                if ((data + sizeof(wjh_buf_drop_pkt_hdr_ver2_ext_t)) > data_end) {
                    return -1;
                }
            } else {
                nhoff += sizeof(wjh_buf_drop_pkt_hdr_ver2_t);
                if ((data + sizeof(wjh_buf_drop_pkt_hdr_ver2_t)) > data_end) {
                    return -1;
                }
            }
            buffer_drop_header_v2 = data;
            parse_mirror_header_v2(buffer_drop_header_v2, buffer_drop_info);
            if (buffer_drop_info->mirror_reason == WJH_SPAN_MIRROR_REASON_INVALID) {
                /* For mirror header V2, we should ignore the packets carrying invalid mirror reason (0). */
                return -1;
            }
        }

        is_lag = ((buffer_drop_common_header->flags) & (0x1 << WJH_BUF_DROP_HDR_COMMON_IS_INGRESS_LAG_OFFSET)) ? 1 : 0;
        ingress_label_port = ntohs(buffer_drop_common_header->ingress_label_port);
        /* Not like the port information we get from CQE, we don't have the LAG member port index here.
         * In case of LAG, we only have the LAG ID.
         * In case of port, we have the split number and label port number mixed in the lowest 16 bits.
         */
        ebpf_key->port = (((uint32_t)(is_lag)) << 24) | ((uint32_t)(ingress_label_port));

        buffer_drop_info->egress_valid =
            ((buffer_drop_common_header->flags) &
             (0x1 << WJH_BUF_DROP_HDR_COMMON_IS_EGRESS_PORT_VALID_OFFSET)) ? 1 : 0;
        if (buffer_drop_info->egress_valid) {
            egress_is_lag =
                ((buffer_drop_common_header->flags) & (0x1 << WJH_BUF_DROP_HDR_COMMON_IS_EGRESS_LAG_OFFSET)) ? 1 : 0;
            egress_label_port = ntohs(buffer_drop_common_header->egress_label_port);
            buffer_drop_info->egress_port = (((uint32_t)(egress_is_lag)) << 24) | ((uint32_t)(egress_label_port));
        }

        if (buffer_drop_info->is_hw_clock) {
            secs_msb = __constant_ntohl(buffer_drop_common_header->secs_msb);
            secs_lsb = ntohs(buffer_drop_common_header->secs_lsb);
            nsecs_msb = ntohs(buffer_drop_common_header->nsecs_msb);
            nsecs_lsb = ntohs(buffer_drop_common_header->nsecs_lsb);
            buffer_drop_info->timestamp.tv_sec |= (secs_msb << 16);
            buffer_drop_info->timestamp.tv_sec |= secs_lsb;
            buffer_drop_info->timestamp.tv_nsec |= (nsecs_msb << 16);
            buffer_drop_info->timestamp.tv_nsec |= nsecs_lsb;
        }

        if ((data + nhoff + sizeof(struct ethhdr)) > data_end) {
            return -1;
        }
        eth = data + nhoff;
        proto = ntohs(eth->h_proto);
    }

    nhoff += sizeof(struct ethhdr);

    __builtin_memcpy(ebpf_key->dmac, eth->h_dest, ETH_ALEN);
    __builtin_memcpy(ebpf_key->smac, eth->h_source, ETH_ALEN);

    if (proto == ETH_P_8021AD) {
        if ((data + nhoff + sizeof(struct vlan_hdr)) > data_end) {
            return -1;
        }
        v_hdr = data + nhoff;
        proto = ntohs(v_hdr->h_vlan_encapsulated_proto);
        nhoff += sizeof(struct vlan_hdr);
    }

    if (proto == ETH_P_8021Q) {
        if ((data + nhoff + sizeof(struct vlan_hdr)) > data_end) {
            return -1;
        }
        v_hdr = data + nhoff;
        proto = ntohs(v_hdr->h_vlan_encapsulated_proto);
        ebpf_key->vlan = ntohs(v_hdr->h_vlan_TCI) & 0xfff;
        nhoff += sizeof(struct vlan_hdr);
    }

    ebpf_key->ether_type = proto;

    if (likely(proto == ETH_P_IP)) {
        if (parse_ip(data, data_end, &nhoff, &ip_proto, ebpf_key) == -1) {
            return -1;
        }
    } else if (proto == ETH_P_IPV6) {
        ebpf_key->five_tuples.is_ipv6 = 1;
        if (parse_ipv6(data, data_end, &nhoff, &ip_proto, ebpf_key) == -1) {
            return -1;
        }
    } else {
        return 0;
    }

    ebpf_key->five_tuples.ip_proto = ip_proto;

    poff = proto_ports_offset(ip_proto, &nhoff);
    if (poff != -1) {
        if ((data + nhoff + 4) > data_end) {
            return -1;
        }

        ebpf_key->five_tuples.sport = ntohs(*(__u16*)(data + nhoff));
        ebpf_key->five_tuples.dport = ntohs(*(__u16*)(data + nhoff + 2));
    }

    return 1;
}

#endif /* ifndef __BPF_HELPERS_H */
