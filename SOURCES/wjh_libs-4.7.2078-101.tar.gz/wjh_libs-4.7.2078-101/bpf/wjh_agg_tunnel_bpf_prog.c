/*
 * Copyright © 2019-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <uapi/linux/bpf.h>
#include "bpf_helpers.h"

#define WJH_TRAP_ID_DECAP_ECN0                       0x40
#define WJH_TRAP_ID_IPIP_DECAP_ERROR                 0xb1
#define WJH_TRAP_ID_DISCARD_DEC_PKT                  0x188
#define WJH_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC   0x190
#define WJH_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC 0x191
#define WJH_TRAP_ID_DISCARD_ENC_ISOLATION            0x192
#define WJH_TRAP_ID_DISCARD_DEC_NVE_OPTIONS          0x193
#define WJH_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0     0x194

struct bpf_map_def SEC("maps") wjh_agg_tunnel_map =
{
    .type = BPF_MAP_TYPE_HASH,
    .key_size = sizeof(wjh_agg_ebpf_key_t),
    .value_size = sizeof(wjh_agg_ebpf_value_t),
    .max_entries = 1024,
};

static inline int is_tunnel_drop_trap_id(uint32_t trap_id)
{
    switch (trap_id) {
    case WJH_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC:
    case WJH_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC:
    case WJH_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0:
    case WJH_TRAP_ID_DISCARD_DEC_PKT:
    case WJH_TRAP_ID_DISCARD_DEC_NVE_OPTIONS:
    case WJH_TRAP_ID_DECAP_ECN0:
    case WJH_TRAP_ID_IPIP_DECAP_ERROR:
    case WJH_TRAP_ID_DISCARD_ENC_ISOLATION:
        return 1;

    default:
        return 0;
    }
}

static inline uint32_t tunnel_drop_trap_id_to_reason_id(uint32_t trap_id)
{
    switch (trap_id) {
    case WJH_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_MC:
        return WJH_DROP_REASON_ID_OVERLAY_SWITCH_SOURCE_MAC_IS_MULTICAST_E;

    case WJH_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC_DMAC:
        return WJH_DROP_REASON_ID_OVERLAY_SWITCH_SOURCE_MAC_EQAULS_DESTINATION_MAC_E;

    case WJH_TRAP_ID_DISCARD_OVERLAY_SWITCH_SMAC0:
        return WJH_DROP_REASON_ID_OVERLAY_SWITCH_SOURCE_MAC_IS_ZERO;

    case WJH_TRAP_ID_DISCARD_ENC_ISOLATION:
        return WJH_DROP_REASON_ID_ENCAPSULATION_ISOLATION_E;

    case WJH_TRAP_ID_DISCARD_DEC_PKT:
    case WJH_TRAP_ID_DISCARD_DEC_NVE_OPTIONS:
    case WJH_TRAP_ID_DECAP_ECN0:
    case WJH_TRAP_ID_IPIP_DECAP_ERROR:
        return WJH_DROP_REASON_ID_BAD_PACKET_WAS_RECEIVED_FROM_THE_PEER_E;

    default:
        return 0;
    }
}

SEC("wjh_agg_tunnel_bpf_prog")
int agg_tunnel_prog(struct __sk_buff *skb)
{
    wjh_agg_ebpf_key_t       key = {0};
    wjh_agg_ebpf_value_t     value = {0};
    wjh_agg_ebpf_value_t    *val_p = NULL;
    uint32_t                 index = 0;
    wjh_agg_ebpf_timestamp_t timestamp;
    void                    *data = (void*)(long)skb->data;
    void                    *data_end = (void*)(long)skb->data_end;
    uint32_t                *agg_key_mode_p = NULL;
    int                      ret = 0;
    uint16_t                 trap_id = (skb->cb[0]) >> 16;
    uint32_t                 port = skb->cb[4];

    timestamp.tv_sec = skb->cb[2];
    timestamp.tv_nsec = skb->cb[3];

    if (!is_tunnel_drop_trap_id(trap_id)) {
        return 0;
    }

    agg_key_mode_p = bpf_map_lookup_elem(&wjh_agg_comm_map, &index);
    if (agg_key_mode_p == NULL) {
        return 0;
    }

    ret = flow_dissector(data, data_end, &key, NULL);
    if (ret == -1) {
        return 0;
    }

    if (ret == 0) {
        key.non_ip = 1;
    }

    if (*agg_key_mode_p != WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
        key.port = 0;
        key.vlan = 0;
        key.ether_type = 0;
    } else {
        key.port = port;
    }

    key.reason_id = tunnel_drop_trap_id_to_reason_id(trap_id);
    WJH_AGG_UPDATE_EBPF_MAP(wjh_agg_tunnel_map);

    return 0;
}

char _license[] SEC("license") = "GPL";
