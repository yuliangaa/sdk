/*
 * Copyright © 2020-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of Nvidia Corporation and its affiliates
 * (the "Company") and all right, title, and interest in and to the software
 * product, including all associated intellectual property rights, are and
 * shall remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 */

#include <uapi/linux/bpf.h>
#include <uapi/linux/time.h>
#include "bpf_helpers.h"

#define WJH_TRAP_ID_ROCE_DROP 0x1e9

struct bpf_map_def SEC("maps") wjh_agg_roce_map =
{
    .type = BPF_MAP_TYPE_HASH,
    .key_size = sizeof(wjh_agg_ebpf_key_t),
    .value_size = sizeof(wjh_agg_ebpf_value_t),
    .max_entries = 1024,
};

SEC("wjh_agg_roce_bpf_prog")
int agg_roce_prog(struct __sk_buff *skb)
{
    wjh_agg_ebpf_key_t       key = {0};
    wjh_agg_ebpf_value_t     value = {0};
    wjh_agg_ebpf_value_t    *val_p = NULL;
    uint32_t                 index = 0;
    wjh_agg_ebpf_timestamp_t timestamp;
    void                    *data = (void*)(long)skb->data;
    void                    *data_end = (void*)(long)skb->data_end;
    uint32_t                *agg_key_mode_p = NULL;
    int                      ret = 0;
    uint16_t                 trap_id = (skb->cb[0]) >> 16;
    uint32_t                 port = skb->cb[4];
    uint32_t                 acl_user_id = skb->cb[1] >> 9;

    timestamp.tv_sec = skb->cb[2];
    timestamp.tv_nsec = skb->cb[3];

    if (trap_id != WJH_TRAP_ID_ROCE_DROP) {
        return 0;
    }

    agg_key_mode_p = bpf_map_lookup_elem(&wjh_agg_comm_map, &index);
    if (agg_key_mode_p == NULL) {
        return 0;
    }

    ret = flow_dissector(data, data_end, &key, NULL);
    if (ret == -1) {
        return 0;
    }

    if (ret == 0) {
        key.non_ip = 1;
    }

    if (*agg_key_mode_p != WJH_AGGREGATION_KEY_MODE_DETAILED_E) {
        key.port = 0;
        key.vlan = 0;
        key.ether_type = 0;
        __builtin_memset(key.dmac, 0, ETH_ALEN);
        __builtin_memset(key.smac, 0, ETH_ALEN);
    } else {
        key.port = port;
    }

    key.reason_id = WJH_ROCE_ACL_USER_ID_DROP_REASON(acl_user_id);

    WJH_AGG_UPDATE_EBPF_MAP(wjh_agg_roce_map);

    return 0;
}

char _license[] SEC("license") = "GPL";
