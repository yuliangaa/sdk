/*
 * SPDX-FileCopyrightText: Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __SX_API_ADAPTIVE_ROUTING_H__
#define __SX_API_ADAPTIVE_ROUTING_H__

#include <sx/sdk/sx_api.h>

/************************************************
 *  API Functions
 ***********************************************/
/**
 * This API sets the log verbosity level of ADAPTIVE ROUTING module.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle                   - SX-API handle
 * @param[in] verbosity_target         - Sets verbosity of API/MODULE/BOTH
 * @param[in] module_verbosity_level   - AR module verbosity level
 * @param[in] api_verbosity_level      - AR API verbosity level
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if an input parameter is invalid
 * @return SX_STATUS_ERROR for a general error
 */
sx_status_t sx_api_ar_log_verbosity_level_set(const sx_api_handle_t           handle,
                                              const sx_log_verbosity_target_t verbosity_target,
                                              const sx_verbosity_level_t      module_verbosity_level,
                                              const sx_verbosity_level_t      api_verbosity_level);


/**
 * This API gets the log verbosity level of ADAPTIVE ROUTING module.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in]  handle                   - SX-API handle
 * @param[in]  verbosity_target         - Get verbosity of API/MODULE/BOTH
 * @param[out] module_verbosity_level_p - AR module verbosity level
 * @param[out] api_verbosity_level_p    - AR API verbosity level
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_ERROR for a general error
 * @return SX_STATUS_PARAM_NULL if an input parameter is invalid
 */
sx_status_t sx_api_ar_log_verbosity_level_get(const sx_api_handle_t           handle,
                                              const sx_log_verbosity_target_t verbosity_target,
                                              sx_verbosity_level_t           *module_verbosity_level_p,
                                              sx_verbosity_level_t           *api_verbosity_level_p);


/**
 * This API initiates the adaptive routing (AR) module in SDK.
 * This function should be called before any use of the library.
 * The function will configure default AR values:
 *          Shapers rate: AR_SHAPER_RATE_DEFAULT us for both shapers
 *          Port congestion threshold:
 *              Low: AR_CONGESTION_THRESHOLD_DEFAULT_LOW cells
 *              Medium: AR_CONGESTION_THRESHOLD_DEFAULT_MEDIUM cells
 *              High: AR_CONGESTION_THRESHOLD_DEFAULT_HIGH cells
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle        - SX-API handle
 * @param[in] init_params_p - General AR parameters
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 *         successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_ALREADY_INITIALIZED if AR is already initialized.
 * @return SX_STATUS_MODULE_UNINITIALIZED if router module is not initialized.
 * @return SX_STATUS_UNSUPPORTED if device is not supporting adaptive routing.
 * @return SX_STATUS_NO_RESOURCES if the user has created more than RM_API_COS_TX_GROUPS_MAX
 *         of Switch priority -> Traffic class mapping, using sx_api_cos_port_tc_prio_map_set API.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_init_set(const sx_api_handle_t      handle,
                               const sx_ar_init_params_t *init_params_p);

/**
 * This API deinitializes the AR block in the SDK.
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_deinit_set(const sx_api_handle_t handle);

/**
 * This API sets the AR profile configuration parameters.
 * Only one of the profiles or both of the profiles can be configured.
 * Only elephant attribute can be configured with free mode profile only.
 *
 * Note: Only SET access commands are supported.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in]  handle                       - SX-API handle
 * @param[in]  cmd                          - SX access command - SET
 * @param[in]  profile_key_p                - Profile ID.
 * @param[in]  profile_attr_p               - Profile attributes.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR module was not initialized.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command is not supported.
 * @return SX_STATUS_ERROR for a general error
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_STATUS_PARAM_NULL if any input/output parameter is NULL.
 */
sx_status_t sx_api_ar_profile_set(const sx_api_handle_t       handle,
                                  const sx_access_cmd_t       cmd,
                                  const sx_ar_profile_key_t  *profile_key_p,
                                  const sx_ar_profile_attr_t *profile_attr_p);

/**
 *  This API gets AR profile configuration parameters.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle                         - SX-API handle
 * @param[in] profile_key_p                  - Profile key
 * @param[out] profile_attr_p                - Profile attributes
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_profile_get(const sx_api_handle_t      handle,
                                  const sx_ar_profile_key_t *profile_key_p,
                                  sx_ar_profile_attr_t      *profile_attr_p);

/**
 * This API sets the AR default classifier configuration parameters.
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in]  handle                       - SX-API handle
 * @param[in]  cmd                          - SET.
 * @param[in]  action_p                     - classifier action.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR module wasn't initialized.
 * @return SX_STATUS_PARAM_NULL if any input/output parameter is NULL.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_STATUS_ERROR for a general error
 */
sx_status_t sx_api_ar_default_classification_set(const sx_api_handle_t            handle,
                                                 const sx_access_cmd_t            cmd,
                                                 const sx_ar_classifier_action_t *action_p);

/**
 * This API gets the AR default classification configuration.
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in]  handle                       - SX-API handle
 * @param[in]  action_p                     - default classifier action.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_ERROR for a general error
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_STATUS_PARAM_NULL if any input/output parameter is NULL.
 */
sx_status_t sx_api_ar_default_classification_get(const sx_api_handle_t      handle,
                                                 sx_ar_classifier_action_t *action_p);

/**
 * This API sets the AR classifier configuration parameters.
 * When multi-match then classifier with lower value wins.
 * When no match the default classifier wins.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle            - SX-API handle.
 * @param[in] cmd               - SET / UNSET.
 * @param[in] classifier_id     - Classifier ID
 * @param[in] attr_p            - Classifier configuration attributes. Only for SET.
 * @param[in] action_p          - Classifier action. Only for SET.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_classifier_set(const sx_api_handle_t            handle,
                                     const sx_access_cmd_t            cmd,
                                     const sx_ar_classifier_id_e      classifier_id,
                                     const sx_ar_classifier_attr_t   *attr_p,
                                     const sx_ar_classifier_action_t *action_p);

/**
 *  This API gets AR classifier configuration parameters.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle            - SX-API handle.
 * @param[in] classifier_id     - Classifier ID
 * @param[out] attr_p           - Classifier configuration attributes.
 * @param[out] action_p         - Classifier action.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_PARAM_ERROR if error in parameter.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_classifier_get(const sx_api_handle_t       handle,
                                     const sx_ar_classifier_id_e classifier_id,
                                     sx_ar_classifier_attr_t    *attr_p,
                                     sx_ar_classifier_action_t  *action_p);

/**
 * This API sets the AR congestion threshold configuration.
 * This configuration will impact the port grade.
 * The grades are used by the AR engine to select the egress port.
 *
 * Buffer < thresh_lo  will get grade 0/1 depends on link utilization
 * thresh_lo  <= Buffer < thresh_med will get grade 2
 * thresh_med <= Buffer < thresh_hi  will get grade 3
 * thresh_hi  <= Buffer              will get grade 4
 *
 * Note: min threshold = 0, max threshold = 2^24
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in]  handle                       - SX-API handle
 * @param[in]  cmd                          - SET.
 * @param[in]  threshold_p                  - Congestion threshold in cells.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_ERROR for a general error
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_STATUS_PARAM_NULL if any input/output parameter is NULL.
 */
sx_status_t sx_api_ar_congestion_threshold_set(const sx_api_handle_t                    handle,
                                               const sx_access_cmd_t                    cmd,
                                               const sx_ar_congestion_threshold_attr_t *threshold_p);

/**
 * This API gets the AR congestion threshold configuration.
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in]  handle                       - SX-API handle
 * @param[out]  threshold_p                 - Congestion threshold pointer.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_ERROR for a general error
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid.
 * @return SX_STATUS_PARAM_NULL if any input/output parameter is NULL.
 */
sx_status_t sx_api_ar_congestion_threshold_get(const sx_api_handle_t              handle,
                                               sx_ar_congestion_threshold_attr_t *threshold_p);

/**
 *  This API sets the AR link utilization configuration parameters.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle                     - SX-API handle.
 * @param[in] cmd                        - SET / UNSET.
 * @param[in] log_port                   - SDK logical port
 * @param[in] link_util_attr_p           - Link utilization configuration attributes.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_link_utilization_threshold_set(const sx_api_handle_t                handle,
                                                     const sx_access_cmd_t                cmd,
                                                     const sx_port_log_id_t               log_port,
                                                     const sx_ar_link_utilization_attr_t *link_util_attr_p);

/**
 *  This API gets the AR link utilization configuration parameters.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle                           - SX-API handle.
 * @param[in] log_port                         - SDK logical port
 * @param[out] link_util_attr_p                - Link utilization configuration attributes.
 *
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_link_utilization_threshold_get(const sx_api_handle_t          handle,
                                                     const sx_port_log_id_t         log_port,
                                                     sx_ar_link_utilization_attr_t *link_util_attr_p);

/**
 * This API sets the AR shaper rate configuration parameters.
 * To prevent moving a large amount of flows moving from one output
 * to another output in a short period of time
 * two types of shapers per port are used:
 *
 * A shaper per output port for the number of flows that changed their destination to the output port
 * A shaper per output port for the number of flows that changed their destination from the output port
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle            - SX-API handle.
 * @param[in] cmd               - SET.
 * @param[in] shaper_attr_p     - Shaper configuration attributes.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter there is a bad parameter.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_shaper_rate_set(const sx_api_handle_t      handle,
                                      const sx_access_cmd_t      cmd,
                                      const sx_ar_shaper_attr_t *shaper_attr_p);

/**
 *  This API gets AR shaper rate configuration parameters.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle                    - SX-API handle.
 * @param[out] shaper_attr_p            - Shaper configuration attributes.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR module wasn't initialized.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_shaper_rate_get(const sx_api_handle_t handle,
                                      sx_ar_shaper_attr_t  *shaper_attr_p);

/**
 * This API retrieves adaptive routing global counters values.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle            - SX-API handle
 * @param[in] cmd               - READ/READ_CLEAR
 * @param[out] ar_counters_p    - Pointer to an AR global counter
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any other input error
 * @return SX_STATUS_ERROR general error
 */
sx_status_t sx_api_ar_counters_get(const sx_api_handle_t    handle,
                                   const sx_access_cmd_t    cmd,
                                   sx_ar_global_counters_t *ar_counters_p);

/**
 *  This API configures Adaptive Routing Notification (ARN) generation and consumption parameters.
 *  It will only enable the ARN consumption process.
 *  Generation process will be enabled only by calling sx_api_arn_router_gen_set API.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle            - SX-API handle.
 * @param[in] cmd               - SET - enables ARN in the system / UNSET - disables ARN in the system.
 * @param[in] general_params_p  - ARN required general parameters.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR module wasn't initialized.
 * @return SX_STATUS_ALREADY_INITIALIZED - When ARN is already initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_set(const sx_api_handle_t          handle,
                              const sx_access_cmd_t          cmd,
                              const sx_arn_general_params_t *general_params_p);

/**
 *  This API returns ARN general parameters.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle                - SX-API handle.
 * @param[in,out] general_params_p  - ARN required general parameters.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_get(const sx_api_handle_t    handle,
                              sx_arn_general_params_t *general_params_p);

/**
 *  This API sets ARN profile attributes per profile key.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle           - SX-API handle.
 * @param[in] cmd              - SET - updates ARN profile attributes.
 * @param[in] profile_key_p    - AR profile key
 * @param[in] profile_attr_p   - ARN profile attributes
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR/ARN module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_profile_set(const sx_api_handle_t        handle,
                                      const sx_access_cmd_t        cmd,
                                      const sx_ar_profile_key_t   *profile_key_p,
                                      const sx_arn_profile_attr_t *profile_attr_p);

/**
 *  This API returns ARN profile attributes per profile key.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle           - SX-API handle.
 * @param[in] profile_key_p    - AR profile key
 * @param[out] profile_attr_p  - ARN profile attributes
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR/ARN module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_profile_get(const sx_api_handle_t      handle,
                                      const sx_ar_profile_key_t *profile_key_p,
                                      sx_arn_profile_attr_t     *profile_attr_p);

/**
 *  This API sets ARN default parameters.
 *  Using this API is optional. The user can change the default parameters that
 *  configured by sx_api_arn_set API.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle           - SX-API handle.
 * @param[in] cmd              - SET - updates params. UNSET - return to default.
 * @param[in] default_params_p - ARN default params
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR/ARN module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_defaults_set(const sx_api_handle_t          handle,
                                       const sx_access_cmd_t          cmd,
                                       const sx_arn_default_params_t *default_params_p);

/**
 *  This API returns ARN default parameters.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle           - SX-API handle.
 * @param[out] default_params_p - ARN default params
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR/ARN module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_defaults_get(const sx_api_handle_t    handle,
                                       sx_arn_default_params_t *default_params_p);

/**
 * This API enables the generation of ARN packets in a given VRID.
 * ARN generation can be enabled only in VRF where fabric ports are connected.
 * This API should be called after VRID creation.
 * Both commands can be applied only when no active remote UC routes configuration exists on the given VRID.
 * When UC routes are configured on the given VRID, SDK will return SX_STATUS_RESOURCE_IN_USE.
 * UNSET command will disable ARN generation only.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle            - SX-API handle.
 * @param[in] cmd               - SET/UNSET - updates params.
 * @param[in] router_key_p      - ARN router key.
 * @param[in] router_attr_p     - ARN router attributes.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR/ARN module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_RESOURCE_IN_USE if remote UC routes are configured on the given VRID.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_router_gen_set(const sx_api_handle_t             handle,
                                         const sx_access_cmd_t             cmd,
                                         const sx_arn_router_key_t        *router_key_p,
                                         const sx_arn_router_attributes_t *router_attr_p);

/**
 *  This API returns ARN router generation parameters.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle            - SX-API handle.
 * @param[in] router_key_p      - ARN router key.
 * @param[out] router_attr_p    - ARN router attributes.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR/ARN module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_router_gen_get(const sx_api_handle_t       handle,
                                         const sx_arn_router_key_t  *router_key_p,
                                         sx_arn_router_attributes_t *router_attr_p);

/**
 *  This API returns ARN global counters.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle            - SX-API handle.
 * @param[in] cmd               - READ/READ_CLEAR - ARN global counters.
 * @param[out] arn_counters_p   - ARN counters
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR/ARN module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_counters_get(const sx_api_handle_t handle,
                                       const sx_access_cmd_t cmd,
                                       sx_arn_counters_t    *arn_counters_p);

/**
 *  This API returns ARN port counters.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4, Spectrum5.
 *
 * @param[in] handle            - SX-API handle.
 * @param[in] cmd               - READ/READ_CLEAR - ARN global counters.
 * @param[in] log_port          - Only physical port.
 * @param[out] port_counters_p  - ARN port counters.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR/ARN module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_port_counters_get(const sx_api_handle_t   handle,
                                            const sx_access_cmd_t   cmd,
                                            const sx_port_log_id_t  log_port,
                                            sx_arn_port_counters_t *port_counters_p);

/**
 * This API returns the content of AR flow table entries.
 *
 * Supported devices: Spectrum2, Spectrum3, Spectrum4.
 *
 * Note: flow_status_data_p contains the list count that should be configured
 * with the expected number of entries in the ARN flow table.
 * It will be updated with the actual number of entries there were read.
 *
 * @param[in] handle            - SX-API handle.
 * @param[in] cmd               - READ.
 * @param[in] flow_status_key_p - ECMP_ID , AR profile ID
 * @param[in,out] flow_status_data_p  - list of ARN status and egress ports and its counter
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 * @return SX_STATUS_INVALID_HANDLE if a NULL handle is received.
 * @return SX_STATUS_MODULE_UNINITIALIZED if AR/ARN module wasn't initialized.
 * @return SX_STATUS_PARAM_ERROR if parameter is wrong.
 * @return SX_STATUS_CMD_UNSUPPORTED if access command isn't supported.
 * @return SX_STATUS_PARAM_NULL if parameter is NULL.
 * @return SX_STATUS_ERROR general error.
 */
sx_status_t sx_api_ar_arn_flow_status_get(const sx_api_handle_t      handle,
                                          const sx_access_cmd_t      cmd,
                                          sx_arn_flow_status_key_t  *flow_status_key_p,
                                          sx_arn_flow_status_data_t *flow_status_data_p);


#endif /* ifndef __SX_API_ADAPTIVE_ROUTING_H__ */
