/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */

#ifndef     __SX_STRINGS_H__
#define     __SX_STRINGS_H__


#include <complib/sx_log.h>
#include <sx/sdk/sx_types.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

#define SX_GENERATE_STRING(ENUM, STR) STR,

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/* Backward compatible macros */

#define SX_ACCESS_CMD_STR(index)                   sx_access_cmd_str(index)
#define SX_ACL_SEARCH_TYPE(index)                  sx_acl_search_type_str(index)
#define SX_API_ARB_POLICY_STR(index)               sx_api_arb_policy_str(index)
#define SX_OBJECT_TYPE_STR(index)                  sx_object_type_str(index)
#define SX_BRIDGE_MODE_STR(index)                  sx_bridge_mode_str(index)
#define SX_BRIDGE_MULTIPLE_VLAN_MODE_STR(index)    sx_bridge_multiple_vlan_mode_str(index)
#define SX_BRIDGE_TUNNEL_COUNTER_TYPE_STR(index)   sx_bridge_tunnel_counter_type_str(index)
#define SX_COS_BUFFER_MAX_MODE_STR(index)          sx_cos_muffer_max_mode_str(index)
#define SX_COS_PORT_BUFF_POOL_DIRECTION_STR(index) sx_cos_port_buff_pool_direction_str(index)
#define SX_CHIP_TYPE_STR(index)                    sx_chip_types_str(index)
#define SX_CHIP_REV_STR(index)                     sx_chip_rev_str_arr(index)
#define SX_DEV_NODE_TYPE_STR(index)                sx_dev_node_type_str(index)
#define SX_EVENT_GENERATE_MODE_STR(index)          sx_event_generate_mode_str(index)
#define SX_LEARN_MODE_MSG(index)                   sx_fdb_learn_mode_str(index)
#define SX_FDB_FLOOD_FID_MODE_STR(index)           sx_fdb_flood_fid_mode_str(index)
#define SX_FDB_NOTIFY_TYPE_STR(index)              sx_fdb_notify_type_str(index)
#define SX_RECEIVE_DEST_PORT_STR(index)            sx_receive_dest_port_str(index)
#define SX_TCAM_OPT_MODE_STR(index)                sx_tcam_opt_mode_str(index)
#define SX_TCAM_OPT_MODE_PARAM_STR(index)          sx_tcam_opt_mode_param_str(index)
#define SX_IP_VERSION_DISP(index)                  Sx_ip_version_str(index)
#define SX_DEFAULT_LAG_HASH_STR(index)             sx_lag_hash_bit_number_str(index)
#define SX_MC_NEXT_HOP_TYPE_STR(index)             sx_mc_next_hop_type_str(index)
#define SX_MC_CONTAINER_TYPE_STR(index)            sx_mc_container_type_str(index)
#define SX_MSTP_INST_PORT_STATE_STR(index)         sx_mstp_inst_port_state_str(index)
#define SX_MSTP_EXCLUDE_PORT_STATE_STR(index)      sx_mstp_iexclude_port_state_str(index)
#define SX_MSTP_MODE_STR(index)                    sx_mstp_mode_str(index)
#define SX_NEXT_HOP_TYPE_STR(index)                sx_next_hop_type_str(index)
#define SX_POLICER_IR_UNITS_STR(index)             sx_policer_ir_units_str(index)
#define SX_POLICER_RATE_TYPE_STR(index)            sx_policer_rate_type_str(index)
#define SX_POLICER_METER_TYPE_STR(index)           sx_policer_meter_type_str(index)
#define SX_POLICER_ACTION_STR(index)               sx_policer_action_str(index)
#define SX_PORT_MODULE_STATUS_STR(index)           sx_port_module_state_str(index)
#define SX_PORT_MODULE_ERR_STATUS_STR(index)       sx_port_module_err_state_str(index)
#define SX_PORT_ADMIN_STATUS_STR(index)            sx_port_admin_state_str(index)
#define SX_PORT_OPER_STATUS_STR(index)             sx_port_oper_state_str(index)
#define SX_PORT_TYPE_STR(index)                    sx_port_type_str(index)
#define SX_PORT_PHY_SPEED_STR(index)               sx_port_phy_speed_str(index)
#define SX_PORT_MODE_STR(index)                    sx_port_mode_str(index)
#define SX_PORT_MAPPING_MODE_STR(index)            sx_port_mapping_mode_str(index)
#define SX_PORT_PHYS_LOOPBACK_STR(index)           sx_port_phys_loopback_str(index)
#define SX_PORT_PHYS_LINK_SIDE_STR(index)          sx_port_phys_link_side_str(index)
#define SX_PORT_PAUSE_POLICY_RX_STR(index)         sx_port_pause_policy_rx_str(index)
#define SX_PORT_PAUSE_POLICY_TX_STR(index)         sx_port_pause_policy_tx_str(index)
#define SX_PORT_FLOW_CTRL_MODE_STR(index)          sx_port_flow_ctrl_mode_str(index)
#define SX_PORT_FLOW_CTRL_PRIO_STR(index)          sx_port_flow_ctrl_prio_str(index)
#define SX_PORT_CNTR_PRIO_ID_STR(index)            sx_port_cntr_prio_tc_str(index)
#define SX_PORT_BER_FEC_PROFILE_STR(index)         sx_port_ber_fec_profile_str(index)
#define SX_PORT_RATE_STR(index)                    sx_port_rate_str(index)
#define SX_PORT_BER_ALARM_STATE_STR(index)         sx_port_ber_alarm_state_str(index)
#define SX_ROUTER_RIF_TYPE_STR(index)              sx_router_interface_type_str(index)
#define SX_ROUTER_ENABLE_STATE_STR(index)          sx_router_enable_state_str(index)
#define SX_ROUTER_RPF_ACTION_STR(index)            sx_router_rpf_action_str(index)
#define SX_ROUTER_ECMP_HASH_TYPE_STR(index)        sx_router_ecmp_hash_type_str(index)
#define SX_MC_ROUTER_TTL_CMD_STR(index)            sx_mc_router_ttl_cmd_str(index)
#define SX_ROUTER_VINTERFACE_TPYE_STR(index)       sx_router_vinterface_type_str(index)
#define SX_ROUTER_PRIO_TYPE_STR(index)             sx_router_prio_type_str(index)
#define SX_ECMP_TYPE_STR(index)                    sx_ecmp_type_str(index)
#define SX_ECMP_CONTAINER_STR(index)               sx_ecmp_container_type_e__str(index)
#define SX_ROUTER_ACTION_STR(index)                sx_router_action_str(index)
#define SX_SPAN_TYPE_STR(index)                    sx_span_type_str(index)
#define SX_SPAN_DROP_REASON_STR(index)             sx_span_drop_reason_str(index)
#define SX_STATUS_MSG(index)                       sx_status_str(index)
#define SX_SWID_INFO_FIELD_BIT_STR(index)          sx_swid_info_field_bit_str(index)
#define SX_TELE_HISTOGRAM_TYPE_STR(index)          sx_tele_histogram_type_str(index)
#define SX_TELE_THRESHOLD_KEY_TYPE_STR(index)      sx_port_threshold_type_str(index)
#define SX_TUNNEL_TYPE_STR(index)                  sx_tunnel_type_str(index)
#define SX_TUNNEL_DIRECTION_STR(index)             sx_tunnel_direction_str(index)
#define SX_TUNNEL_GRE_MODE_STR(index)              sx_tunnel_gre_mode_str(index)
#define SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_STR(index) sx_tunnel_decap_key_fields_type_str(index)
#define SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_STR(index)  sx_tunnel_underlay_domain_type_str(index)
#define SX_VLAN_QINQ_PRIO_TAG_MODE_STR(index)      SX_VLAN_QINQ_PRIO_TAG_MODE_str(index)
#define SX_FM_FID_TYPE_STR(index)                  sx_fm_fid_type_str(index)
#define SX_DBG_API_LOGGER_MODE_E_STR(index)        sx_dbg_api_logger_mode_e_str(index)
#define SX_DBG_API_LOGGER_FILTER_MODE_E_STR(index) sx_dbg_api_logger_filter_mode_e_str(index)
#define SX_MGMT_PHY_MOD_PWR_MODE_STR(index)        sx_mgmt_phy_mod_pwr_mode_str(index)
#define SX_MGMT_PHY_MOD_PWR_ATTR_TYPE_STR(index)   sx_mgmt_phy_mod_pwr_attr_type_str(index)
#define SX_MGMT_PHY_MODULE_CABLE_TYPE_STR(index)   sx_mgmt_phy_module_cable_type_str(index)
#define SX_MGMT_TEMP_SENSOR_OPS_STR(index)         sx_mgmt_temp_sensor_ops_str(index)
#define SX_MGMT_PHY_MODULE_TYPE_STR(index)         sx_mgmt_phy_module_type_str(index)
#define SX_MGMT_SLOT_CONTROL_OPS_STR(index)        sx_mgmt_slot_control_ops_str(index)
#define SX_MGMT_SLOT_INI_OPER_STATUS_STR(index)    sx_mgmt_slot_ini_oper_status_str(index)
#define SX_MGMT_SLOT_INI_STATUS_STR(index)         sx_mgmt_slot_ini_status_str(index)
#define SX_MGMT_SLOT_INI_OPER_STR(index)           sx_mgmt_slot_ini_oper_str(index)
#define SX_MGMT_SLOT_CARD_TYPE_STR(index)          sx_mgmt_slot_card_type_str(index)
#define SX_MGMT_SLOT_DEVICE_GB_TYPE_STR(index)     sx_mgmt_slot_device_gb_type_str(index)

/* Backward compatible string conversion functions */
#define sx_health_cause_str            sx_health_event_cause_str
#define sx_tele_threshold_type_str     sx_port_threshold_type_str
#define sx_chip_type_str               sx_chip_types_str
#define sx_policer_meter_type_str      sx_policer_meter_str
#define sx_vlan_qinq_prio_tag_mode_str SX_VLAN_QINQ_PRIO_TAG_MODE_str
#define sx_ecmp_container_type_str     sx_ecmp_container_type_e__str
#define sx_mstp_exclude_port_state_str sx_mstp_iexclude_port_state_str
#define sx_port_module_err_state_str   sx_port_module_error_type_str

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
#include "sx/sdk/auto_headers/sx_strings_auto.h"

const char * sx_lib_adviser_event_type_str(sx_lib_adviser_event_type_e index);
const char * sx_host_ifc_trap_id_str(sx_trap_id_t trap_id);

#endif  /*	__SX_STRINGS_H__	*/
