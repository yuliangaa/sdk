/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */


#ifndef OBSOLETE_H_
#define OBSOLETE_H_

#include "sx/sdk/auto_headers/obsolete_auto.h"


/* obsolete definitions of IPv6 trap IDs */
#define SX_TRAP_ID_IPV6_ROUTER_SOLICIATION   SX_TRAP_ID_IPV6_ROUTER_SOLICITATION
#define SX_TRAP_ID_IPV6_NEIGHBOR_SOLICIATION SX_TRAP_ID_IPV6_NEIGHBOR_SOLICITATION
#define SX_TRAP_ID_IPV6_NEIGHBOR_DIRECTION   SX_TRAP_ID_IPV6_REDIRECTION
/* obsolete definition of Router ARP Trap ID */
#define SX_TRAP_ID_ROUTER_APRUC SX_TRAP_ID_ROUTER_ARPUC
/* obsolete definition of MAC aging Trap ID */
#define  SX_TRAP_ID_MAC_LEARNING_EVENT 0x402
/* obsolete definition of MAC aging Trap ID */
#define  SX_TRAP_ID_MAC_AGING_EVENT 0x403

/* Obsolete definition of internal events */
#define SX_TRAP_ID_FW_SOS           0x3
#define SX_TRAP_ID_GENERAL_ETH_EMAD 0x5
#define SX_TRAP_ID_ACCU_FLOW_INC    0x27
#define SX_TRAP_ID_MOCS_DONE        0x106
#define SX_TRAP_ID_PPCNT            0x107
#define SX_TRAP_ID_MGPCB            0x108
#define SX_TRAP_ID_PBSR             0x109
#define SX_TRAP_ID_SBSRD            0x10A
#define SX_TRAP_ID_MAFBI            0x10C
#define SX_TRAP_ID_MAFRI            0x10E
#define SX_TRAP_ID_IPAC_DONE        0x10F
#define SX_TRAP_ID_MOPCE            0x1B2
#define SX_TRAP_ID_MECCC            0x1B3
#define SX_TRAP_ID_FSED             0x1B5
#define SX_TRAP_ID_USACN            0x231
#define SX_TRAP_ID_UTCC             0x232
#define SX_TRAP_ID_UPCNT            0x233
#define SX_TRAP_ID_MOFRB            0x235
#define SX_TRAP_ID_FSHE             0x281

/* Obsolete definition of events */
#define SX_TRAP_ID_FLAE  0xA
#define SX_TRAP_ID_FORE  0xB
#define SX_TRAP_ID_CPUWD 0xD

#endif /* OBSOLETE_H_ */
