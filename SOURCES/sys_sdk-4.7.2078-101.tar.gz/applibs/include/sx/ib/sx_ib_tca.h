/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License. You may obtain
 * a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *
 * THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
 * LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
 * FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
 *
 * See the Apache Version 2.0 License for specific language governing
 * permissions and limitations under the License.
 *
 */

#ifndef SX_IB_TCA_H_
#define SX_IB_TCA_H_

/**
 * sx_tca_log_port_state_type_t enumerated type is used to indicates the TCA logical port state type
 */
typedef enum sx_ib_tca_log_port_state_type {
    SX_IB_TCA_LOG_PORT_STATE_NOCHANGE = 0,      /**< TCA port Logical state no change, valid for set only */
    SX_IB_TCA_LOG_PORT_STATE_DOWN     = 1,      /**< TCA port Logical state down */
    SX_IB_TCA_LOG_PORT_STATE_INIT     = 2,      /**< TCA port logical state init */
    SX_IB_TCA_LOG_PORT_STATE_ARM      = 3,      /**< TCA port logical state arm */
    SX_IB_TCA_LOG_PORT_STATE_ACTIVE   = 4,      /**< TCA port logical state active */
    SX_IB_TCA_LOG_PORT_STATE_MIN      = SX_IB_TCA_LOG_PORT_STATE_NOCHANGE,     /**< used to note minimal allowed value */
    SX_IB_TCA_LOG_PORT_STATE_MAX      = SX_IB_TCA_LOG_PORT_STATE_ACTIVE,   /**< used to note maximal allowed value */
} sx_ib_tca_log_port_state_type_t;

/**
 * sx_tca_phy_port_state_type_t enumerated type is used to indicates the TCA physical port state type
 */
typedef enum sx_ib_tca_phy_port_state_type {
    SX_IB_TCA_PHY_PORT_STATE_NOCHANGE = 0,      /**< TCA port physical state no change, valid for set only  */
    SX_IB_TCA_PHY_PORT_STATE_DOWN     = 1,      /**< TCA port physical state down */
    SX_IB_TCA_PHY_PORT_STATE_POLLING  = 2,      /**< TCA port physical state polling */
    SX_IB_TCA_PHY_PORT_STATE_UP       = 3,      /**< TCA port physical state up */
    SX_IB_TCA_PHY_PORT_STATE_MIN      = SX_IB_TCA_PHY_PORT_STATE_NOCHANGE,     /**< used to note minimal allowed value */
    SX_IB_TCA_PHY_PORT_STATE_MAX      = SX_IB_TCA_PHY_PORT_STATE_UP,       /**< used to note maximal allowed value */
} sx_ib_tca_phy_port_state_type_t;

/**
 * sx_ib_tca_port_state_params_t structure is used to store the TCA logical and physical port state
 * TCA logical port state can be: DOWN, INIT, ARM, ACTIVE
 * TCA physical port state can be: DOWN, POLLING, UP.
 *
 */
typedef struct sx_ib_tca_port_state_params {
    sx_ib_tca_log_port_state_type_t tca_log_pstate;     /**< TCA port logical state */
    sx_ib_tca_phy_port_state_type_t tca_phy_pstate;     /**< TCA port physical state */
} sx_ib_tca_port_state_params_t;


#endif /* SX_IB_TCA_H_ */
