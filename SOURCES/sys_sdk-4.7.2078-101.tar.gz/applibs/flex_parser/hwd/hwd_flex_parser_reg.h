/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWD_FLEX_PARSER_REG_H_INCL__
#define __HWD_FLEX_PARSER_REG_H_INCL__


#include <sx/sdk/sx_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/
typedef uint16_t flex_parser_hw_entry_index_t;

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t hwd_flex_parser_reg_mprs_udp_dport_set(uint32_t value);

sx_status_t hwd_flex_parser_reg_log_verbosity_level_set(sx_verbosity_level_t verbosity_level);

sx_status_t hwd_flex_parser_reg_mprs_udp_dport_get(uint32_t *udp_dport);

sx_status_t hwd_flex_parser_reg_gp_register_ext_point_dev_set(sx_dev_id_t            dev_id,
                                                              sx_gp_register_key_t   gp_reg,
                                                              uint32_t               ext_point_cnt,
                                                              sx_extraction_point_t *ext_point_list_p);

sx_status_t hwd_flex_parser_reg_gp_register_ext_point_hw_set(sx_gp_register_key_t   gp_reg,
                                                             uint32_t               ext_point_cnt,
                                                             sx_extraction_point_t *ext_point_list_p);

/* Use the FPHTT register to set/unset a hard transition */
sx_status_t hwd_flex_parser_reg_fphtt_set(const sx_access_cmd_t cmd,
                                          const uint32_t        entry_index);

/* Use the FPFTT register to set/unset a flex transition */
sx_status_t hwd_flex_parser_reg_fpftt_set(const sx_access_cmd_t              cmd,
                                          const flex_parser_hw_entry_index_t hw_index,
                                          const flex_parser_hw_entry_index_t from,
                                          const flex_parser_hw_entry_index_t to,
                                          const uint16_t                     transition_value,
                                          const sx_flex_parser_encap_level_e encap_level);

/* Use the FPPC register to set/unset a flex header */
sx_status_t hwd_flex_parser_reg_fppc_set(const sx_flex_parser_header_fpp_e fpp,
                                         const sx_flex_parser_fpp_t       *fpp_cfg_p);

/* Set the TLV FPP that will be used on a specified fixed header */
sx_status_t hwd_flex_parser_reg_fphhc_set(const flex_parser_hw_entry_index_t hw_index,
                                          const boolean_t                    outer_tlv_set,
                                          const boolean_t                    inner_tlv_set,
                                          const sx_flex_parser_header_fpp_e  tlv_fpp);
/* Set the FPTS register that binds a FPP to a specific port */
sx_status_t hwd_flex_parser_reg_fpts_set(const sx_access_cmd_t              cmd,
                                         const boolean_t                    global,
                                         const sx_port_log_id_t             log_port,
                                         const flex_parser_hw_entry_index_t next_hw_index);


#endif /*__HWD_FLEX_PARSER_REG_H_INCL__*/
