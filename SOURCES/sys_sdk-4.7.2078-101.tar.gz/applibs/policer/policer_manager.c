/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>

#include <utils/utils.h>
#include <sx/sdk/sx_status_convertor.h>
#include "policer_lib/policer_common.h"
#include "policer_db.h"
#include "policer_manager.h"
#include "sx/utils/gbin_allocator.h"
#include "issu/issu.h"

#undef  __MODULE__
#define __MODULE__ POLICER

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

#define RELOCATION_THRESHOLD_SPECTRUM 80
#define RELOCATION_COUNT_SPECTRUM     30
#define POLICER_MANAGER_USER_ID       1

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static policer_manager_params_t policer_manager_s;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_utils_status_t __policer_manager_alloc(ba_handle_t        handle,
                                                 uint32_t           type,
                                                 const ba_group_t **group_p);
static sx_utils_status_t __policer_manager_free(ba_handle_t handle,
                                                ba_group_t *group_p);
static sx_utils_status_t __copy_policer_cb(ba_handle_t handle,
                                           ba_logical_id_t lid, uint32_t cntx,
                                           ba_index_t old_id, ba_index_t new_id, void*           relocate_cntx);

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t policer_manager_init(policer_manager_index_t     global_start_index,
                                 policer_manager_index_t     global_end_index,
                                 policer_manager_index_t     host_ifc_start_index,
                                 policer_manager_index_t     host_ifc_end_index,
                                 policer_manager_index_t     storm_control_start_index,
                                 policer_manager_index_t     storm_control_end_index,
                                 policer_manager_index_t     span_start_index,
                                 policer_manager_index_t     span_end_index,
                                 policer_block_copy_t        copy_callback,
                                 policer_increase_counters_t increase_counters_callback)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_param_t        global_bin_params, host_ifc_bin_params, storm_control_bin_params, span_bin_params;
    ba_phys_init_t    global_phys_init, host_ifc_phys_init, storm_control_phys_init, span_phys_init;

    SX_LOG_ENTER();

    SX_MEM_CLR(global_bin_params);
    SX_MEM_CLR(host_ifc_bin_params);
    SX_MEM_CLR(storm_control_bin_params);
    SX_MEM_CLR(span_bin_params);
    SX_MEM_CLR(global_phys_init);
    SX_MEM_CLR(host_ifc_phys_init);
    SX_MEM_CLR(storm_control_phys_init);
    SX_MEM_CLR(span_phys_init);

    if (policer_manager_s.is_initialized == TRUE) {
        SX_LOG(SX_LOG_ERROR, "Policer manager already initialized\n");
        err = SX_STATUS_DB_ALREADY_INITIALIZED;
        goto out;
    }

    if (global_end_index <= global_start_index) {
        SX_LOG(SX_LOG_ERROR, "Wrong param index : global_end_index:%d global_start_index:%d \n",
               global_end_index, global_start_index);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (host_ifc_end_index <= host_ifc_start_index) {
        SX_LOG(SX_LOG_ERROR, "Wrong param index : host_ifc_end_index:%d host_ifc_start_index:%d \n",
               host_ifc_end_index, host_ifc_start_index);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (global_start_index < host_ifc_end_index) {
        SX_LOG(SX_LOG_ERROR, "Wrong param index : global_start_index:%d host_ifc_end_index:%d \n",
               global_start_index, host_ifc_end_index);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (copy_callback == NULL) {
        SX_LOG(SX_LOG_ERROR, "copy callback is NULL \n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (increase_counters_callback == NULL) {
        SX_LOG(SX_LOG_ERROR, "increase_counters_callback is NULL \n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (storm_control_end_index <= storm_control_start_index) {
        SX_LOG(SX_LOG_ERROR, "Wrong param index : storm_control_end_index:%d "
               "storm_control_start_index:%d \n",
               storm_control_end_index, storm_control_start_index);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (span_end_index < span_start_index) {
        SX_LOG(SX_LOG_ERROR, "Wrong param index : span_end_index:%d "
               "span_start_index:%d \n",
               span_end_index, span_start_index);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    SX_MEM_CLR(policer_manager_s.user_params);

    policer_manager_s.global_table_size = global_end_index - global_start_index;
    policer_manager_s.host_ifc_table_size = host_ifc_end_index - host_ifc_start_index;
    policer_manager_s.storm_control_table_size = storm_control_end_index - storm_control_start_index;
    policer_manager_s.span_table_size = span_end_index - span_start_index;

    policer_manager_s.block_copy = copy_callback;
    policer_manager_s.increase_counters = increase_counters_callback;

    policer_manager_s.global_ba_group_used = FALSE;
    policer_manager_s.host_ifc_ba_group_used = FALSE;
    policer_manager_s.storm_control_ba_group_used = FALSE;
    policer_manager_s.span_ba_group_used = FALSE;

    policer_manager_s.global_ba_group.type = POLICER_MANAGER_TYPE_ACL_E;
    policer_manager_s.host_ifc_ba_group.type = POLICER_MANAGER_TYPE_HOST_IFC_E;
    policer_manager_s.storm_control_ba_group.type = POLICER_MANAGER_TYPE_STORM_CONTROL_E;
    policer_manager_s.span_ba_group.type = POLICER_MANAGER_TYPE_SPAN_E;
    policer_manager_s.global_ba_group.grp_index = 0;
    policer_manager_s.host_ifc_ba_group.grp_index = 0;
    policer_manager_s.storm_control_ba_group.grp_index = 0;
    policer_manager_s.span_ba_group.grp_index = 0;

    /*initialize global bin allocator client*/
    global_bin_params.version = BIN_ALLOC_VERSION;
    global_bin_params.group_cnt = 1;
    global_bin_params.array_size = policer_manager_s.global_table_size;
    global_bin_params.alignment = global_bin_params.array_size;
    global_bin_params.r_thresh = RELOCATION_THRESHOLD_SPECTRUM;
    global_bin_params.r_count = RELOCATION_COUNT_SPECTRUM;
    global_bin_params.gc_object_type = GC_OBJECT_TYPE_GLOBAL_POLICER;
    global_bin_params.gc_subtype = GC_OBJECT_SUBTYPE_NONE;
    global_bin_params.gc_attr.fence_type = GC_FENCE_TYPE_FAST;
    global_bin_params.gc_attr.free_objects_threshold = 200;
    global_bin_params.gc_attr.per_object_threshold = 100;
    global_bin_params.gc_attr.hw_operation_needed = FALSE;
    global_bin_params.gc_attr.immediate_fence_needed = FALSE;
    global_bin_params.gc_post_completion_cb = NULL;
    global_bin_params.free_object_cb = NULL;
    global_bin_params.templates[0].type = policer_manager_s.global_ba_group.type;
    global_bin_params.templates[0].length = global_bin_params.alignment;
    global_bin_params.templates[0].alloc_sizes[0] = 1;
    global_bin_params.templates[0].alloc_sizes[1] = 2;
    global_bin_params.templates[0].align = ALIGN_SIZE_E;
    global_bin_params.templates[0].cb_alloc = __policer_manager_alloc;
    global_bin_params.templates[0].cb_free = __policer_manager_free;
    global_bin_params.templates[0].cb_relocate = __copy_policer_cb;
    global_bin_params.options = RELOC_ASYNC_E;

    global_phys_init.phys_mem_size = global_bin_params.array_size;
    strncpy(global_phys_init.phys_mem_name, "POLICER_GLOBAL", sizeof(global_phys_init.phys_mem_name));
    global_bin_params.phys_init = &global_phys_init;

    utils_err = ba_client_init(&policer_manager_s.global_ba_handle, &global_bin_params);
    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to init acl policer bin allocator, error: %s\n",
               sx_status_str(err));
        goto out;
    }

    /*initialize host_ifc bin allocator client */
    host_ifc_bin_params.version = BIN_ALLOC_VERSION;
    host_ifc_bin_params.group_cnt = 1;
    host_ifc_bin_params.array_size = policer_manager_s.host_ifc_table_size;
    host_ifc_bin_params.alignment = host_ifc_bin_params.array_size;
    host_ifc_bin_params.r_thresh = 100;
    host_ifc_bin_params.r_count = 0;
    host_ifc_bin_params.gc_object_type = GC_OBJECT_TYPE_HOST_IFC_POLICER;
    host_ifc_bin_params.gc_subtype = GC_OBJECT_SUBTYPE_NONE;
    host_ifc_bin_params.gc_attr.fence_type = GC_FENCE_TYPE_FAST;
    host_ifc_bin_params.gc_attr.free_objects_threshold = policer_manager_s.host_ifc_table_size;
    host_ifc_bin_params.gc_attr.per_object_threshold = 0;
    host_ifc_bin_params.gc_attr.hw_operation_needed = FALSE;
    host_ifc_bin_params.gc_post_completion_cb = NULL;
    host_ifc_bin_params.free_object_cb = NULL;
    host_ifc_bin_params.templates[0].type = policer_manager_s.host_ifc_ba_group.type;
    host_ifc_bin_params.templates[0].length = host_ifc_bin_params.alignment;
    host_ifc_bin_params.templates[0].alloc_sizes[0] = 1;
    host_ifc_bin_params.templates[0].alloc_sizes[1] = 2;
    host_ifc_bin_params.templates[0].align = ALIGN_SIZE_E;
    host_ifc_bin_params.templates[0].cb_alloc = __policer_manager_alloc;
    host_ifc_bin_params.templates[0].cb_free = __policer_manager_free;
    host_ifc_bin_params.templates[0].cb_relocate = NULL;

    host_ifc_phys_init.phys_mem_size = host_ifc_bin_params.array_size;
    strncpy(host_ifc_phys_init.phys_mem_name, "POLICER_HOST_IFC", sizeof(host_ifc_phys_init.phys_mem_name));
    host_ifc_bin_params.phys_init = &host_ifc_phys_init;

    utils_err = ba_client_init(&policer_manager_s.host_ifc_ba_handle, &host_ifc_bin_params);
    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to init host_ifc bin allocator, error: %s\n",
               sx_status_str(err));
        goto rb_out;
    }

    /*initialize storm control bin allocator client */
    storm_control_bin_params.version = BIN_ALLOC_VERSION;
    storm_control_bin_params.group_cnt = 1;
    storm_control_bin_params.array_size = policer_manager_s.storm_control_table_size;
    storm_control_bin_params.alignment = storm_control_bin_params.array_size;
    storm_control_bin_params.r_thresh = 100;
    storm_control_bin_params.r_count = 0;
    storm_control_bin_params.gc_object_type = GC_OBJECT_TYPE_STORM_CTRL_POLICER;
    storm_control_bin_params.gc_subtype = GC_OBJECT_SUBTYPE_NONE;
    storm_control_bin_params.gc_attr.fence_type = GC_FENCE_TYPE_FAST;
    storm_control_bin_params.gc_attr.free_objects_threshold = 80;
    storm_control_bin_params.gc_attr.per_object_threshold = 150;
    storm_control_bin_params.gc_attr.hw_operation_needed = FALSE;
    storm_control_bin_params.gc_post_completion_cb = NULL;
    storm_control_bin_params.free_object_cb = NULL;
    storm_control_bin_params.templates[0].type = policer_manager_s.storm_control_ba_group.type;
    storm_control_bin_params.templates[0].length = storm_control_bin_params.alignment;
    storm_control_bin_params.templates[0].alloc_sizes[0] = 1;
    storm_control_bin_params.templates[0].alloc_sizes[1] = 2;
    storm_control_bin_params.templates[0].align = ALIGN_SIZE_E;
    storm_control_bin_params.templates[0].cb_alloc = __policer_manager_alloc;
    storm_control_bin_params.templates[0].cb_free = __policer_manager_free;
    storm_control_bin_params.templates[0].cb_relocate = NULL;

    storm_control_phys_init.phys_mem_size = storm_control_bin_params.array_size;
    strncpy(storm_control_phys_init.phys_mem_name, "POLICER_STORM_CONTROL",
            sizeof(storm_control_phys_init.phys_mem_name));
    storm_control_bin_params.phys_init = &storm_control_phys_init;

    utils_err = ba_client_init(&policer_manager_s.storm_control_ba_handle, &storm_control_bin_params);
    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to init storm control bin allocator, error: %s\n",
               sx_status_str(err));
        goto rb_out2;
    }

    /* initialize span bin allocator client */
    if (policer_manager_s.span_table_size > 0) {
        span_bin_params.version = BIN_ALLOC_VERSION;
        span_bin_params.group_cnt = 1;
        span_bin_params.array_size = policer_manager_s.span_table_size;
        span_bin_params.alignment = span_bin_params.array_size;
        span_bin_params.r_thresh = 100;
        span_bin_params.r_count = 0;
        span_bin_params.gc_object_type = GC_OBJECT_TYPE_SPAN_POLICER;
        span_bin_params.gc_subtype = GC_OBJECT_SUBTYPE_NONE;
        span_bin_params.gc_attr.fence_type = GC_FENCE_TYPE_FAST;
        span_bin_params.gc_attr.free_objects_threshold = policer_manager_s.span_table_size;
        span_bin_params.gc_attr.per_object_threshold = 0;
        span_bin_params.gc_attr.hw_operation_needed = FALSE;
        span_bin_params.gc_post_completion_cb = NULL;
        span_bin_params.free_object_cb = NULL;
        span_bin_params.templates[0].type = policer_manager_s.span_ba_group.type;
        span_bin_params.templates[0].length = span_bin_params.alignment;
        span_bin_params.templates[0].alloc_sizes[0] = 1;
        span_bin_params.templates[0].alloc_sizes[1] = 2;
        span_bin_params.templates[0].align = ALIGN_SIZE_E;
        span_bin_params.templates[0].cb_alloc = __policer_manager_alloc;
        span_bin_params.templates[0].cb_free = __policer_manager_free;
        span_bin_params.templates[0].cb_relocate = NULL;

        span_phys_init.phys_mem_size = span_bin_params.array_size;
        strncpy(span_phys_init.phys_mem_name, "POLICER_SPAN", sizeof(span_phys_init.phys_mem_name));
        span_bin_params.phys_init = &span_phys_init;

        utils_err = ba_client_init(&policer_manager_s.span_ba_handle, &span_bin_params);
        err = sx_utils_status_to_sx_status(utils_err);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR, "Failed to init span bin allocator, error: %s\n",
                   sx_status_str(err));
            goto rb_out3;
        }
    }

    policer_manager_s.is_initialized = TRUE;

    goto out;

rb_out3:
    utils_err = ba_client_deinit(policer_manager_s.storm_control_ba_handle);
    if (SX_CHECK_FAIL(sx_utils_status_to_sx_status(utils_err))) {
        SX_LOG(SX_LOG_ERROR, "Failed to deinit storm control bin allocator,error: %s\n",
               sx_status_str(sx_utils_status_to_sx_status(utils_err)));
    }

rb_out2:
    utils_err = ba_client_deinit(policer_manager_s.host_ifc_ba_handle);
    if (SX_CHECK_FAIL(sx_utils_status_to_sx_status(utils_err))) {
        SX_LOG(SX_LOG_ERROR, "Failed to deinit host_ifc bin allocator,error: %s\n",
               sx_status_str(sx_utils_status_to_sx_status(utils_err)));
    }

rb_out:
    utils_err = ba_client_deinit(policer_manager_s.global_ba_handle);
    if (SX_CHECK_FAIL(sx_utils_status_to_sx_status(utils_err))) {
        SX_LOG(SX_LOG_ERROR, "Failed to deinit global bin allocator,error: %s\n",
               sx_status_str(sx_utils_status_to_sx_status(utils_err)));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t policer_manager_deinit(void)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (policer_manager_s.user_params.is_initialized == TRUE) {
        SX_LOG(SX_LOG_ERROR, "Can't deinit policer manager,user of "
               "policer manager is still initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    /*deinit global bin allocator */
    utils_err = ba_client_deinit(policer_manager_s.global_ba_handle);
    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to deinit acl policer bin allocator,error: %s\n",
               sx_status_str(err));
        goto out;
    }

    /*deinit host_ifc bin allocator */
    utils_err = ba_client_deinit(policer_manager_s.host_ifc_ba_handle);
    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to deinit host_ifc bin allocator,error: %s\n",
               sx_status_str(err));
        goto out;
    }

    /*deinit storm control bin allocator */
    utils_err = ba_client_deinit(policer_manager_s.storm_control_ba_handle);
    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed to deinit storm control bin allocator,error: %s\n",
               sx_status_str(err));
        goto out;
    }

    if (rm_resource_global.policer_span_pool_size > 0) {
        /* deinit span bin allocator */
        utils_err = ba_client_deinit(policer_manager_s.span_ba_handle);
        err = sx_utils_status_to_sx_status(utils_err);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG(SX_LOG_ERROR, "Failed to deinit span bin allocator,error: %s\n",
                   sx_status_str(err));
            goto out;
        }
    }

    policer_manager_s.is_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t policer_manager_user_init(policer_change_refs_cb_t       change_refs_callback,
                                      policer_manager_user_handle_t *user_handle_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER()
    ;

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (change_refs_callback == NULL) {
        SX_LOG(SX_LOG_ERROR, "block_relocate_function = NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (user_handle_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "user_handle_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    policer_manager_s.user_params.change_refs_cb = change_refs_callback;
    policer_manager_s.user_params.is_initialized = TRUE;
    *user_handle_p = POLICER_MANAGER_USER_ID;

out:
    SX_LOG_EXIT()
    ;
    return err;
}

sx_status_t policer_manager_user_deinit(policer_manager_user_handle_t user_handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER()
    ;

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (user_handle != POLICER_MANAGER_USER_ID) {
        SX_LOG(SX_LOG_ERROR, "user_handle [%u] is not valid.\n", user_handle);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    policer_manager_s.user_params.change_refs_cb = NULL;
    policer_manager_s.user_params.is_initialized = FALSE;

out:
    SX_LOG_EXIT()
    ;
    return err;
}

sx_status_t policer_manager_block_add(policer_manager_block_length_t size,
                                      policer_manager_policer_type_e policer_type,
                                      sx_policer_id_t               *policer_id_p)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   policer_id = 0;
    sx_log_severity_t log_level = SX_LOG_ERROR;

    SX_LOG_ENTER();

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (policer_id_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "policer_id_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((size > SX_POLICER_RATE_TYPE_DUAL_RATE_E) || (size < SX_POLICER_RATE_TYPE_SINGLE_RATE_E)) {
        SX_LOG(SX_LOG_ERROR, "size [%u] range check failed.\n", size);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /*call bin allocator to get one block*/
    switch (policer_type) {
    case POLICER_MANAGER_TYPE_ACL_E:
        utils_err = ba_allocate(policer_manager_s.global_ba_handle,
                                POLICER_MANAGER_TYPE_ACL_E,
                                size, size, &policer_id);
        policer_id = POLICER_MANAGER_BA_INDEX_TO_GLOBAL_ID(policer_id);
        break;

    case POLICER_MANAGER_TYPE_HOST_IFC_E:
        utils_err = ba_allocate(policer_manager_s.host_ifc_ba_handle,
                                POLICER_MANAGER_TYPE_HOST_IFC_E,
                                size, size, &policer_id);
        break;

    case POLICER_MANAGER_TYPE_STORM_CONTROL_E:
        utils_err = ba_allocate(policer_manager_s.storm_control_ba_handle,
                                POLICER_MANAGER_TYPE_STORM_CONTROL_E,
                                size, size, &policer_id);
        break;

    case POLICER_MANAGER_TYPE_SPAN_E:
        utils_err = ba_allocate(policer_manager_s.span_ba_handle,
                                POLICER_MANAGER_TYPE_SPAN_E,
                                size, size, &policer_id);
        policer_id = POLICER_MANAGER_BA_INDEX_TO_SPAN_ID(policer_id);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "policer type invalid, error: %s\n",
               sx_status_str(err));
        break;
    }

    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        if (err == SX_STATUS_NO_RESOURCES) {
            log_level = SX_LOG_NOTICE;
        } else {
            log_level = SX_LOG_ERROR;
        }
        SX_LOG(log_level,
               "Bin allocator block allocation failed,error: %s\n",
               sx_status_str(err));
        goto out;
    }


    *policer_id_p = policer_id;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t policer_manager_block_delete(sx_policer_id_t policer_id, policer_manager_policer_type_e policer_type)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_logical_id = policer_id;

    SX_LOG_ENTER();

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    switch (policer_type) {
    case POLICER_MANAGER_TYPE_ACL_E:
        /*first places are for host_ifc policers*/
        ba_logical_id = POLICER_MANAGER_GLOBAL_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_free(policer_manager_s.global_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_HOST_IFC_E:
        utils_err = ba_free(policer_manager_s.host_ifc_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_STORM_CONTROL_E:
        utils_err = ba_free(policer_manager_s.storm_control_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_SPAN_E:
        ba_logical_id = POLICER_MANAGER_SPAN_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_free(policer_manager_s.span_ba_handle, ba_logical_id);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "policer type invalid, error: %s\n",
               sx_status_str(err));
        break;
    }

    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Failed to delete block from bin allocator, error: %s\n",
               sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t policer_manager_block_size_get(sx_policer_id_t                 policer_id,
                                           policer_manager_policer_type_e  policer_type,
                                           policer_manager_block_length_t *size_p)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_logical_id = policer_id;
    uint32_t          refs = 0;

    SX_LOG_ENTER();

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (size_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "size_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (policer_type) {
    case POLICER_MANAGER_TYPE_ACL_E:
        /*first places are for host_ifc policers*/
        ba_logical_id = POLICER_MANAGER_GLOBAL_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_client_cntx_get(policer_manager_s.global_ba_handle, ba_logical_id,
                                       size_p, &refs);
        break;

    case POLICER_MANAGER_TYPE_HOST_IFC_E:
        utils_err = ba_client_cntx_get(policer_manager_s.host_ifc_ba_handle, ba_logical_id,
                                       size_p, &refs);
        break;

    case POLICER_MANAGER_TYPE_STORM_CONTROL_E:
        utils_err = ba_client_cntx_get(policer_manager_s.storm_control_ba_handle, ba_logical_id,
                                       size_p, &refs);
        break;

    case POLICER_MANAGER_TYPE_SPAN_E:
        ba_logical_id = POLICER_MANAGER_SPAN_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_client_cntx_get(policer_manager_s.span_ba_handle, ba_logical_id,
                                       size_p, &refs);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "policer type invalid, error: %s\n",
               sx_status_str(err));
        break;
    }

    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Bin allocator failed to get context, error: %s\n",
               sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t policer_manager_handle_lock(sx_policer_id_t                 policer_id,
                                        policer_manager_policer_type_e  policer_type,
                                        policer_manager_index_t        *index_p,
                                        policer_manager_block_length_t *size_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_utils_status_t              utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t                ba_logical_id = policer_id;
    policer_manager_index_t        index = 0;
    policer_manager_block_length_t size = 0;
    sx_boot_mode_e                 issu_boot_mode = SX_BOOT_MODE_DISABLED_E;
    sx_issu_bank_e                 issu_bank = SX_ISSU_BANK_1_E;


    SX_LOG_ENTER();

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (index_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "index_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (size_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "size_p is NULL\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = issu_boot_mode_get(&issu_boot_mode);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR(" failed to issu_boot_mode_get sx_status = %s\n",
                   sx_status_str(err));
        goto out;
    }

    if (issu_boot_mode != SX_BOOT_MODE_DISABLED_E) {
        err = issu_bank_get(&issu_bank);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get ISSU bank, err: %s\n",
                       sx_status_str(err));
            goto out;
        }
    }

    switch (policer_type) {
    case POLICER_MANAGER_TYPE_ACL_E:
        /*first places are for host_ifc policers*/
        ba_logical_id = POLICER_MANAGER_GLOBAL_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_lock(policer_manager_s.global_ba_handle, ba_logical_id,
                            &index, &size);
        /* First deal with ISSU (use half resource according to bank) */
        index += (issu_bank * rm_resource_global.policer_pool_size / 2);
        /* Add host IFC offset */
        index = POLICER_MANAGER_BA_INDEX_TO_GLOBAL_ID(index);
        break;

    case POLICER_MANAGER_TYPE_HOST_IFC_E:
        utils_err = ba_lock(policer_manager_s.host_ifc_ba_handle, ba_logical_id,
                            &index, &size);
        break;

    case POLICER_MANAGER_TYPE_STORM_CONTROL_E:
        utils_err = ba_lock(policer_manager_s.storm_control_ba_handle, ba_logical_id,
                            &index, &size);
        break;

    case POLICER_MANAGER_TYPE_SPAN_E:
        ba_logical_id = POLICER_MANAGER_SPAN_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_lock(policer_manager_s.span_ba_handle, ba_logical_id,
                            &index, &size);
        index = POLICER_MANAGER_BA_INDEX_TO_SPAN_ID(index);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "policer type invalid, error: %s\n",
               sx_status_str(err));
        break;
    }

    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Bin allocator failed to lock block, error: %s\n",
               sx_status_str(err));
        goto out;
    }

    *index_p = index;
    *size_p = size;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t policer_manager_handle_release(sx_policer_id_t policer_id, policer_manager_policer_type_e policer_type)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_logical_id = policer_id;

    SX_LOG_ENTER();

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    switch (policer_type) {
    case POLICER_MANAGER_TYPE_ACL_E:
        /*first places are for host_ifc policers*/
        ba_logical_id = POLICER_MANAGER_GLOBAL_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_unlock(policer_manager_s.global_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_HOST_IFC_E:
        utils_err = ba_unlock(policer_manager_s.host_ifc_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_STORM_CONTROL_E:
        utils_err = ba_unlock(policer_manager_s.storm_control_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_SPAN_E:
        ba_logical_id = POLICER_MANAGER_SPAN_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_unlock(policer_manager_s.span_ba_handle, ba_logical_id);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "policer type invalid, error: %s\n",
               sx_status_str(err));
        break;
    }

    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Bin allocator failed to unlock block, error: %s\n",
               sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT()
    ;
    return err;
}

sx_status_t policer_manager_ref_add(sx_policer_id_t policer_id, policer_manager_policer_type_e policer_type)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_logical_id = policer_id;

    SX_LOG_ENTER();

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    switch (policer_type) {
    case POLICER_MANAGER_TYPE_ACL_E:
        /*first places are for host_ifc policers*/
        ba_logical_id = POLICER_MANAGER_GLOBAL_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_ref_inc(policer_manager_s.global_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_HOST_IFC_E:
        utils_err = ba_ref_inc(policer_manager_s.host_ifc_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_STORM_CONTROL_E:
        utils_err = ba_ref_inc(policer_manager_s.storm_control_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_SPAN_E:
        ba_logical_id = POLICER_MANAGER_SPAN_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_ref_inc(policer_manager_s.span_ba_handle, ba_logical_id);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "policer type invalid, error: %s\n",
               sx_status_str(err));
        break;
    }

    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Bin allocator failed to increase references, error: %s\n",
               sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t policer_manager_ref_delete(sx_policer_id_t policer_id, policer_manager_policer_type_e policer_type)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_SUCCESS;
    ba_logical_id_t   ba_logical_id = policer_id;

    SX_LOG_ENTER();

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    switch (policer_type) {
    case POLICER_MANAGER_TYPE_ACL_E:
        /*first places are for host_ifc policers*/
        ba_logical_id = POLICER_MANAGER_GLOBAL_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_ref_dec(policer_manager_s.global_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_HOST_IFC_E:
        utils_err = ba_ref_dec(policer_manager_s.host_ifc_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_STORM_CONTROL_E:
        utils_err = ba_ref_dec(policer_manager_s.storm_control_ba_handle, ba_logical_id);
        break;

    case POLICER_MANAGER_TYPE_SPAN_E:
        ba_logical_id = POLICER_MANAGER_SPAN_ID_TO_BA_INDEX(policer_id);
        utils_err = ba_ref_dec(policer_manager_s.span_ba_handle, ba_logical_id);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "policer type invalid, error: %s\n",
               sx_status_str(err));
        break;
    }

    err = sx_utils_status_to_sx_status(utils_err);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR,
               "Bin allocator failed to decrease references, error: %s\n",
               sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


/* This function is being used to global policers only */
static sx_utils_status_t __copy_policer_cb(ba_handle_t     handle,
                                           ba_logical_id_t lid,
                                           uint32_t        cntx,
                                           ba_index_t      old_id,
                                           ba_index_t      new_id,
                                           void          * relocate_cntx)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    sx_status_t rb_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(relocate_cntx);

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (handle != policer_manager_s.global_ba_handle) {
        SX_LOG(SX_LOG_ERROR, "bin allocator handle != registered handle.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (new_id == old_id) {
        goto out;
    }

    /*first places are for host_ifc policers*/
    lid = lid + rm_resource_global.policer_host_ifc_pool_size;
    old_id = old_id + rm_resource_global.policer_host_ifc_pool_size;
    new_id = new_id + rm_resource_global.policer_host_ifc_pool_size;

    SX_LOG_DBG("Copying policer from index (%u) to (%u)\n", old_id, new_id);

    err = policer_manager_s.block_copy((sx_policer_id_t)lid, cntx, old_id,
                                       new_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed in block copy callback, old index (%u),"
               " new index (%u), error: %s\n", old_id, new_id, sx_status_str(err));
        goto out;
    }

    SX_LOG_DBG("Changing refs of policer (%u) to (%u)\n", old_id, new_id);

    err = policer_manager_s.user_params.change_refs_cb((sx_policer_id_t)lid,
                                                       cntx, old_id, new_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed in block relocate callback , old index (%u),"
               " new index (%u), error: %s\n", old_id, new_id, sx_status_str(err));
        goto out;
    }

    SX_LOG_DBG("Increasing counters of policer (%u) to (%u)\n", old_id, new_id);

    err = policer_manager_s.increase_counters((sx_policer_id_t)lid, cntx,
                                              old_id, new_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG(SX_LOG_ERROR, "Failed in increase counters callback , old index (%u),"
               " new index (%u), error: %s\n", old_id, new_id, sx_status_str(err));
        goto rb_increase_counters;
    }

    goto out;

rb_increase_counters:
    rb_status = policer_manager_s.user_params.change_refs_cb(
        (sx_policer_id_t)lid, cntx, new_id, old_id);
    if (SX_CHECK_FAIL(rb_status)) {
        SX_LOG(SX_LOG_ERROR, "Failed in block relocate callback , "
               "error: %s\n",
               sx_status_str(rb_status));
    }

out:
    SX_LOG_EXIT();
    return sx_status_to_sx_utils_status(err);
}

static sx_utils_status_t __policer_manager_alloc(ba_handle_t handle, uint32_t type, const ba_group_t **group_p)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    policer_manager_policer_type_e policer_type = (policer_manager_policer_type_e)type;

    SX_LOG_ENTER();

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    if ((handle != policer_manager_s.global_ba_handle) &&
        (handle != policer_manager_s.host_ifc_ba_handle) &&
        (handle != policer_manager_s.storm_control_ba_handle) &&
        (handle != policer_manager_s.span_ba_handle)) {
        SX_LOG(SX_LOG_ERROR, "bin allocator handle != registered handle.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }


    if (group_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "group_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (policer_type) {
    case POLICER_MANAGER_TYPE_ACL_E:
        if (policer_manager_s.global_ba_group_used == TRUE) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator global group was already allocated.\n");
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }
        policer_manager_s.global_ba_group_used = TRUE;
        *group_p = &policer_manager_s.global_ba_group;
        break;

    case POLICER_MANAGER_TYPE_HOST_IFC_E:
        if (policer_manager_s.host_ifc_ba_group_used == TRUE) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator host_ifc group was already allocated.\n");
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }
        policer_manager_s.host_ifc_ba_group_used = TRUE;
        *group_p = &policer_manager_s.host_ifc_ba_group;
        break;

    case POLICER_MANAGER_TYPE_STORM_CONTROL_E:
        if (policer_manager_s.storm_control_ba_group_used == TRUE) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator storm control group was already allocated.\n");
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }
        policer_manager_s.storm_control_ba_group_used = TRUE;
        *group_p = &policer_manager_s.storm_control_ba_group;
        break;

    case POLICER_MANAGER_TYPE_SPAN_E:
        if (policer_manager_s.span_ba_group_used == TRUE) {
            SX_LOG(SX_LOG_ERROR, "Bin allocator span group was already allocated.\n");
            err = SX_STATUS_NO_RESOURCES;
            goto out;
        }
        policer_manager_s.span_ba_group_used = TRUE;
        *group_p = &policer_manager_s.span_ba_group;
        break;

    default:
        SX_LOG(SX_LOG_ERROR, "type [%u] is not legal.\n", type);
        err = SX_STATUS_PARAM_ERROR;
        break;
    }

out:
    SX_LOG_EXIT();
    return sx_status_to_sx_utils_status(err);
}

static sx_utils_status_t __policer_manager_free(ba_handle_t handle, ba_group_t *group_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (policer_manager_s.is_initialized == FALSE) {
        SX_LOG(SX_LOG_ERROR, "policer manager is not initialized.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    if ((handle != policer_manager_s.global_ba_handle) &&
        (handle != policer_manager_s.host_ifc_ba_handle) &&
        (handle != policer_manager_s.storm_control_ba_handle) &&
        (handle != policer_manager_s.span_ba_handle)) {
        SX_LOG(SX_LOG_ERROR, "bin allocator handle != registered handles.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (group_p == NULL) {
        SX_LOG(SX_LOG_ERROR, "group_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (((group_p->type == policer_manager_s.global_ba_group.type) &&
         (group_p->grp_index != policer_manager_s.global_ba_group.grp_index)) ||
        ((group_p->type == policer_manager_s.host_ifc_ba_group.type) &&
         (group_p->grp_index != policer_manager_s.host_ifc_ba_group.grp_index)) ||
        ((group_p->type == policer_manager_s.storm_control_ba_group.type) &&
         (group_p->grp_index != policer_manager_s.storm_control_ba_group.grp_index)) ||
        ((group_p->type == policer_manager_s.span_ba_group.type) &&
         (group_p->grp_index != policer_manager_s.span_ba_group.grp_index))) {
        SX_LOG(SX_LOG_ERROR,
               "group_p values are different policer_manager allocated group.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (((group_p->type == policer_manager_s.global_ba_group.type) &&
         (policer_manager_s.global_ba_group_used == FALSE)) ||
        ((group_p->type == policer_manager_s.host_ifc_ba_group.type) &&
         (policer_manager_s.host_ifc_ba_group_used == FALSE)) ||
        ((group_p->type == policer_manager_s.storm_control_ba_group.type) &&
         (policer_manager_s.storm_control_ba_group_used == FALSE)) ||
        ((group_p->type == policer_manager_s.span_ba_group.type) &&
         (policer_manager_s.span_ba_group_used == FALSE))) {
        SX_LOG(SX_LOG_ERROR, "Bin allocator group wasn't allocated.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    switch (group_p->type) {
    case POLICER_MANAGER_TYPE_ACL_E:
        policer_manager_s.global_ba_group_used = FALSE;
        break;

    case POLICER_MANAGER_TYPE_HOST_IFC_E:
        policer_manager_s.host_ifc_ba_group_used = FALSE;
        break;

    case POLICER_MANAGER_TYPE_STORM_CONTROL_E:
        policer_manager_s.storm_control_ba_group_used = FALSE;
        break;

    case POLICER_MANAGER_TYPE_SPAN_E:
        policer_manager_s.span_ba_group_used = FALSE;
        break;

    default:
        SX_LOG(SX_LOG_ERROR, "invalid group type.\n");
        err = SX_STATUS_ERROR;
        break;
    }

out:
    SX_LOG_EXIT();
    return sx_status_to_sx_utils_status(err);
}
