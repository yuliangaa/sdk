/*
 * Copyright (c) 2013-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __BRIDGE_COMMON_LIB_H
#define __BRIDGE_COMMON_LIB_H

#include <sx/sdk/sx_types.h>
#include <utils/utils.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef enum {
    BRIDGE_ENTRY_TYPE_EXTERNAL_E = 0,
    BRIDGE_ENTRY_TYPE_ALL_E
} bridge_entry_type_e;

/** A structure for notifying FID creation/deletion */
typedef struct vport_bridge_cb {
    sx_fid_t         fid_id;
    sx_port_log_id_t log_port;
    boolean_t        part_of_multi_vlans_set;
} vport_bridge_cb_t;

typedef struct bridge_specific_cb {
    sx_status_t (*bridge_log_verbosity_level_set)(const sx_verbosity_level_t verbosity_level);

    sx_status_t (*bridge_init)(sx_bridge_params_t *bridge_init_param);

    sx_status_t (*bridge_deinit)();

    sx_status_t (*bridge_set)(sx_access_cmd_t     cmd,
                              sx_bridge_id_t     *bridge_id,
                              bridge_entry_type_e entry_type);

    sx_status_t (*bridge_port_set)(sx_access_cmd_t            cmd,
                                   sx_bridge_id_t             bridge_id,
                                   sx_port_log_id_t           log_port,
                                   sx_vlan_id_t               vlan,
                                   sx_untagged_member_state_t egress_mode,
                                   bridge_entry_type_e        entry_type);

    sx_status_t (*bridge_port_get)(sx_bridge_id_t      bridge_id,
                                   sx_bridge_port_t   *bridge_port_list_p,
                                   uint32_t           *bridge_port_cnt_p,
                                   bridge_entry_type_e entry_type);

    sx_status_t (*bridge_vport_get)(sx_bridge_id_t    bridge_id,
                                    sx_port_log_id_t *bridge_vport_list,
                                    uint32_t         *bridge_vport_cnt);

    sx_status_t (*bridge_vport_fid_get)(sx_port_log_id_t log_port, sx_fid_t *fid);

    sx_status_t (*bridge_is_log_port_in_bridge)(sx_bridge_id_t *bridge_id, sx_port_log_id_t log_port);

    sx_status_t (*bridge_port_vport_get)(sx_bridge_id_t bridge_id, sx_port_log_id_t port, sx_port_log_id_t *vport);

    sx_status_t (*bridge_int_vlan_bridge_id_get)(sx_vlan_id_t    vid,
                                                 sx_bridge_id_t *bridge_id);

    sx_status_t (*bridge_ref_cnt_increase)(sx_bridge_id_t bridge_id);

    sx_status_t (*bridge_ref_cnt_decrease)(sx_bridge_id_t bridge_id);

    sx_status_t (*bridge_mode_get)(sx_bridge_mode_t *bridge_mode);

    sx_status_t (*bridge_redirect_lag_validate)(sx_port_log_id_t lag_port_log_id,
                                                sx_port_log_id_t redirect_lag_port_log_id);

    sx_status_t (*bridge_redirect_lag_set)(sx_access_cmd_t  access_cmd,
                                           sx_port_log_id_t lag_port);

    sx_status_t (*bridge_clear_port)(sx_port_id_t port_id,
                                     boolean_t    remove_port_from_db);

    sx_status_t (*bridge_clear_undo)(sx_port_id_t port_id,
                                     sx_swid_id_t swid);

    sx_status_t (*bridge_int_vlan_group_set)(sx_access_cmd_t      cmd,
                                             sx_bridge_id_t       bridge_id,
                                             sx_acl_direction_t   acl_direction,
                                             sx_acl_vlan_group_t *vlan_group);

    sx_status_t (*bridge_int_vlan_group_get)(sx_bridge_id_t       bridge_id,
                                             sx_acl_vlan_group_t *vlan_group);

    sx_status_t (*bridge_port_acl_binding_get)(sx_port_id_t port_id,
                                               sx_acl_id_t *ingress_acl_id_p,
                                               sx_acl_id_t *egress_acl_id_p);

    sx_status_t (*bridge_dbg_generate_dump)(dbg_dump_params_t *dbg_dump_params_p);

    sx_status_t (*bridge_remove_vport_from_gc_queue)(sx_port_log_id_t log_port);

    sx_status_t (*bridge_is_sync_fence_needed)(sx_bridge_id_t  *bridge_id,
                                               sx_port_log_id_t log_port,
                                               boolean_t       *is_sync_fence_needed);
    sx_status_t (*bridge_is_homogeneous)(sx_bridge_id_t bridge_id,
                                         boolean_t     *is_homogeneous);
} bridge_specific_cb_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t sdk_bridge_load_library(void              ** bridge_lib_handle,
                                    sx_verbosity_level_t default_verbosity,
                                    sxd_chip_types_t     asic_type);

sx_status_t bridge_common_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t bridge_common_cb_table_get(bridge_specific_cb_t** bridge_cb_api_p);

sx_status_t bridge_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t bridge_init(sx_bridge_params_t *bridge_init_param);

sx_status_t bridge_deinit();

sx_status_t bridge_set(sx_access_cmd_t     cmd,
                       sx_bridge_id_t     *bridge_id,
                       bridge_entry_type_e entry_type);

sx_status_t bridge_vport_get(sx_bridge_id_t    bridge_id,
                             sx_port_log_id_t *bridge_vport_list,
                             uint32_t         *bridge_vport_cnt);

sx_status_t bridge_vport_fid_get(sx_port_log_id_t log_port, sx_fid_t *fid);

/* If bridge_id == SX_BRIDGE_ID_INVALID and the port belongs to a bridge, the corresponding bridge_id is returned */
sx_status_t bridge_is_log_port_in_bridge(sx_bridge_id_t *bridge_id, sx_port_log_id_t log_port);

sx_status_t bridge_is_sync_fence_needed(sx_bridge_id_t  *bridge_id,
                                        sx_port_log_id_t log_port,
                                        boolean_t       *is_sync_fence_needed);

sx_status_t bridge_remove_vport_from_gc_queue(sx_port_log_id_t log_port);

sx_status_t bridge_port_vport_get(sx_bridge_id_t bridge_id, sx_port_log_id_t port, sx_port_log_id_t *vport);

sx_status_t bridge_int_vlan_bridge_id_get(sx_vlan_id_t    vid,
                                          sx_bridge_id_t *bridge_id);

sx_status_t bridge_int_vlan_bridge_id_get(sx_vlan_id_t    vid,
                                          sx_bridge_id_t *bridge_id);

sx_status_t bridge_ref_cnt_increase(sx_bridge_id_t bridge_id);

sx_status_t bridge_ref_cnt_decrease(sx_bridge_id_t bridge_id);

sx_status_t bridge_mode_get(sx_bridge_mode_t *bridge_mode);

sx_status_t bridge_redirect_lag_validate(sx_port_log_id_t lag_port_log_id,
                                         sx_port_log_id_t redirect_lag_port_log_id);

sx_status_t bridge_redirect_lag_set(sx_access_cmd_t  access_cmd,
                                    sx_port_log_id_t lag_port);

sx_status_t bridge_clear_port(sx_port_id_t port_id,
                              boolean_t    remove_port_from_db);

sx_status_t bridge_clear_undo(sx_port_id_t port_id,
                              sx_swid_id_t swid);

sx_status_t bridge_int_vlan_group_set(sx_access_cmd_t      cmd,
                                      sx_bridge_id_t       bridge_id,
                                      sx_acl_direction_t   acl_direction,
                                      sx_acl_vlan_group_t *vlan_group);

sx_status_t bridge_int_vlan_group_get(sx_bridge_id_t       bridge_id,
                                      sx_acl_vlan_group_t *vlan_group);

/* When in 802.1Q will return SX_STATUS_UNSUPPORTED.
 * If port does not exist in DB SX_STATUS_ENTRY_NOT_FOUND.
 * If port is not bound to eACL the egress_acl_id_p == SX_ACL_ID_INVALID*/
sx_status_t bridge_port_acl_binding_get(sx_port_id_t port_id,
                                        sx_acl_id_t *ingress_acl_id_p,
                                        sx_acl_id_t *egress_acl_id_p);

sx_status_t bridge_set_learn_by_limit(sx_bridge_id_t bridge_id, boolean_t learn_by_limit_enabled);

sx_status_t bridge_get_learn_by_limit(sx_bridge_id_t bridge_id, boolean_t *learn_by_limit_enabled);

sx_status_t bridge_uc_limit_set(sx_bridge_id_t bridge_id, uint32_t limit);

sx_status_t bridge_uc_limit_get(sx_bridge_id_t bridge_id, uint32_t *limit);

sx_status_t bridge_uc_is_limit_reached_get(sx_bridge_id_t bridge_id, uint16_t data_cnt, boolean_t *is_reached_p);

sx_status_t bridge_uc_dynamic_counter_set(sx_bridge_id_t bridge_id,
                                          int            value_to_add,
                                          uint32_t      *new_count,
                                          uint32_t      *limit);

sx_status_t bridge_uc_dynamic_counter_get(sx_bridge_id_t bridge_id, uint32_t *uc_dynamic_cnt);

sx_status_t bridge_uc_static_counter_set(sx_bridge_id_t bridge_id, int value_to_add);

sx_status_t bridge_uc_static_counter_get(sx_bridge_id_t bridge_id, uint32_t *uc_static_cnt);

sx_status_t bridge_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);

sx_status_t bridge_is_homogeneous(sx_bridge_id_t bridge_id, boolean_t *is_homogeneous);

#endif /* ifndef __BRIDGE_COMMON_LIB_H */
