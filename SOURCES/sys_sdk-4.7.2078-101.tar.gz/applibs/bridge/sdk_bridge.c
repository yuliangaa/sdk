/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sx_api/sx_api_internal.h"

#include "sdk_bridge.h"
#include "utils/sx_adviser.h"
#include "utils/port_type_validate.h"
#include "ethl2/port_db.h"
#include "ethl2/mstp.h"
#include "ethl2/vlan.h"
#include "ethl2/lag_sink.h"
#include "ethl2/la_db.h"
#include "ethl2/fdb_flood.h"
#include "ethl2/brg.h"
#include "ethl2/fdb_igmpv3_impl.h"
#include "ethl2/fid_manager.h"

#include "resource_manager/resource_manager.h"
#include "complib/cl_mem.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <sx/utils/id_allocator.h>
#include "ethl2/fdb.h"
#include <tunnel/hwi/tunnel_impl.h>
#include <counters/counter_manager/counter_manager.h>
#include "ethl2/fdb_mc_extended.h"
#include "mc_container/hwi/mc_container_impl.h"
#include "mc_container/hwd/hwd_mc_container.h"
#include "sx/sdk/sx_status_convertor.h"
#include "flow_counter/flow_counter.h"
#include "ethl3/router_common.h"
#include <complib/cl_dbg.h>


#undef  __MODULE__
#define __MODULE__ BRIDGE

/************************************************
 *  Defines
 ***********************************************/
#define MIN_BRIDGE_ID         0x1000            /* 4k */
#define MAX_STRING_LEN        512
#define RIF_TUN_MAP_GROW_STEP 10
#define INVALID_RIF_ID        0xFFFF
#define VPORT_STRING_LEN      11

#define QMAP_LAG_BIT_OFFSET (31)
#define BRIDGE_VPORT_KEY(id)  \
    (SX_PORT_PHY_ID_GET(id) | \
     (IS_LAG_OR_VLAG(id) << QMAP_LAG_BIT_OFFSET))
/* "min_size" of vport pool pushed to gc queue */
#define VPORT_CONTEXT_MIN_CNT (100 * rm_resource_global.port_system_ports_max)
#define INVALID_VLAN_ID       0xFFFF
/************************************************
 *  Type definitions
 ***********************************************/

typedef struct sdk_bridge_db {
    uint32_t       max_bridge_num;
    uint32_t       max_num_virtual_ports;
    cl_qpool_t     bridge_pool;
    cl_qmap_t      bridge_map; /**key <brg_id>*/
    cl_qpool_t     bridge_virtual_port_pool;
    cl_qmap_t      bridge_virtual_port_map; /**key < log_port>*/
    cl_qpool_t     bridge_lag_pool;
    cl_qmap_t      bridge_lag_map; /**key < LAG ID>*/
    cl_qpool_t     bridge_context_item_pool;
    id_allocator_t bridge_id_allocator;
} sdk_bridge_db_t;

typedef struct sdk_bridge {
    cl_pool_item_t       pool_item;
    cl_map_item_t        map_item;
    sx_bridge_id_t       bridge_id;
    uint32_t             bridge_ref_count;
    sx_mirror_mode_t     bridge_ingress_mirror_mode;
    sx_flow_counter_id_t bridge_flow_counter_id;
    cl_qmap_t            bridge_virtual_port_map; /**key <physical port>*/
    boolean_t            is_homogeneous;
    sx_vlan_id_t         homogeneous_vlan;
    uint32_t             redirect_count;
} sdk_bridge_t;

typedef struct sdk_bridge_virtual_port {
    cl_pool_item_t   pool_item;
    cl_map_item_t    map_item;
    cl_map_item_t    map_bridge_item;
    cl_map_item_t    map_lag_item;
    sx_bridge_id_t   bridge_id;
    sx_port_log_id_t log_port;
} sdk_bridge_virtual_port_t;

typedef struct sdk_lag_vport_id {
    cl_pool_item_t pool_item;
    cl_map_item_t  map_item;
    sx_lag_id_t    lag_id;
    cl_qmap_t      vport_map; /**key <log_port>*/
} sdk_lag_vport_id_t;

typedef struct sdk_bridge_context_item {
    cl_pool_item_t   pool_item;
    sx_port_log_id_t log_port;
    sx_bridge_id_t   bridge_id;
} sdk_bridge_context_item_t;

/************************************************
 *  Global variables
 ***********************************************/

static sdk_bridge_db_t *sdk_bridge_db_p = NULL;
static sx_bridge_mode_t bridge_init_mode = SX_MODE_802_1Q;
static boolean_t        bridge_initialized = FALSE;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static uint16_t sdk_global_bridge_id_max = 0;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __sdk_bridge_db_init();
static sx_status_t __sdk_bridge_db_clear_all_bridges();
static sx_status_t __sdk_bridge_db_deinit();
static sx_status_t __sdk_bridge_db_alloc_bridge(sdk_bridge_t **bridge_item);
static sx_status_t __sdk_bridge_db_free_bridge(sdk_bridge_t *bridge_item);
static sx_status_t __sdk_bridge_db_get_bridge(sx_bridge_id_t bridge_id, sdk_bridge_t **bridge_item);
static sx_status_t __sdk_bridge_db_verify_empty_bridge(sdk_bridge_t *bridge_item);
static sx_status_t __sdk_bridge_port_set_validate(sx_access_cmd_t     cmd,
                                                  const sdk_bridge_t *bridge_item,
                                                  sx_port_log_id_t    log_port,
                                                  sx_port_info_t     *port_info_p);
static sx_status_t __sdk_bridge_port_set_validate_redirect(sx_access_cmd_t     cmd,
                                                           const sdk_bridge_t *bridge_item,
                                                           sx_port_log_id_t    log_port);
static sx_status_t __sdk_bridge_port_set_update_bridge(sx_access_cmd_t  cmd,
                                                       sdk_bridge_t    *bridge_item,
                                                       sx_port_log_id_t log_port);
static sx_status_t __sdk_bridge_db_alloc_virtual_port(sx_port_log_id_t log_port,
                                                      sdk_bridge_t    *bridge_item,
                                                      boolean_t       *is_new_lag);
static sx_status_t __sdk_bridge_db_free_virtual_port(sx_port_log_id_t log_port,
                                                     sdk_bridge_t    *bridge_item,
                                                     boolean_t       *is_last_vport_lag);
static sx_status_t __sdk_bridge_lag_port_update(IN sx_port_id_t          lag_port_log_id,
                                                IN lag_sink_event_type_e event_type,
                                                IN sx_port_id_t          port_log_id,
                                                IN void                 *context_p);
static sx_status_t __sdk_bridge_port_added_to_lag(sx_port_id_t port_log_id, sx_port_id_t lag_port_log_id);
static sx_status_t __sdk_bridge_port_removed_from_lag(sx_port_id_t port_log_id, sx_port_id_t lag_port_log_id);
static sx_status_t __sdk_bridge_db_get_virtual_port(sdk_bridge_virtual_port_t **virtual_port,
                                                    sx_port_log_id_t            log_port,
                                                    boolean_t                  *is_sync_fence_needed);
static sx_status_t __sdk_bridge_hw_vport_add(sx_port_log_id_t      log_port,
                                             const sdk_bridge_t   *bridge_item,
                                             const sx_port_info_t *port_info_p);
static sx_status_t __sdk_bridge_vport_delete(sx_port_log_id_t log_port, sdk_bridge_t *bridge_item);
static sx_status_t __sdk_bridge_db_counter_bind_validate(const sdk_bridge_t *bridge_item);
static sx_status_t __sdk_bridge_hw_counter_bind(sdk_bridge_t *bridge_item, sx_flow_counter_obj_t flow_counter);
static sx_status_t __sdk_bridge_hw_counter_unbind(const sdk_bridge_t *bridge_item);
static sx_status_t __sdk_bridge_hw_vport_counter_update(sx_bridge_id_t        bridge_id,
                                                        sx_port_log_id_t      log_port,
                                                        sx_flow_counter_obj_t flow_counter);
static sx_status_t __sdk_bridge_hw_vport_rif_update(sdk_bridge_t *bridge_item_p,
                                                    boolean_t     irif_v,
                                                    hwd_rif_id_t  irif);
static sx_status_t __bridge_flood_port_set(sx_access_cmd_t cmd, sx_fid_t fid_id, sx_port_log_id_t port_id);
static sx_status_t __bridge_prepare_profile_callback(adviser_event_e event_type, void *param);
static sx_status_t __bridge_flood_control_port_set(sx_access_cmd_t  cmd,
                                                   sdk_bridge_t    *bridge_item,
                                                   sx_port_log_id_t port_id);
static sx_utils_status_t __sdk_bridge_gc_delete_cb(const void *gc_context);
static sx_status_t __sdk_bridge_context_item_pool_get(sdk_bridge_context_item_t **sdk_bridge_context_item_p);
static sx_status_t __sdk_bridge_put_context_item(sdk_bridge_context_item_t *sdk_bridge_context_item_p);
sx_status_t __sdk_bridge_return_vport_to_db(sdk_bridge_context_item_t *sdk_bridge_context_item_p);
static sx_status_t __sdk_bridge_push_vport_to_gc_queue(sx_port_log_id_t log_port, sx_bridge_id_t bridge_id);
static sx_status_t __bridge_validate_igmpv3_parameters(sx_port_log_id_t log_port,
                                                       sdk_bridge_t    *bridge_item,
                                                       sx_bridge_id_t   bridge_id,
                                                       sx_port_info_t  *port_info);
static sx_status_t __sdk_bridge_rif_adviser_cb(adviser_event_e event_type, void *param);
static sx_status_t __sdk_bridge_hw_rif_by_fid_get(sx_fid_t      fid,
                                                  boolean_t    *v_rif_p,
                                                  hwd_rif_id_t *hw_rif_id_p);

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t sdk_bridge_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

sx_status_t sdk_bridge_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

    return err;
}

static sx_status_t __sdk_bridge_rif_adviser_cb(adviser_event_e event_type, void *param)
{
    sx_status_t                 rc = SX_STATUS_SUCCESS;
    hwi_rif_state_event_data_t *rif_event_data_p = (hwi_rif_state_event_data_t*)param;
    sx_fid_t                    fid = SX_FID_ID_INVALID;
    boolean_t                   v_rif = FALSE;
    hwd_rif_id_t                hw_rif_id = 0;
    sdk_bridge_t               *bridge_item_p = NULL;

    SX_LOG_ENTER();

    /* Update SVFA mapping with proper RIF ID */
    switch (event_type) {
    case ADVISER_EVENT_POST_RIF_ENABLE_E:
        v_rif = TRUE;
        hw_rif_id = rif_event_data_p->hw_rif_id;
        break;

    case ADVISER_EVENT_PRE_RIF_DISABLE_E:
        v_rif = FALSE;
        hw_rif_id = 0;
        break;

    default:
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Received an unexpected event[%s]\n",
                   ADVISER_EVENT_STR(event_type));
        goto out;
    }

    switch (rif_event_data_p->ifc.type) {
    case SX_L2_INTERFACE_TYPE_BRIDGE:
        fid = rif_event_data_p->ifc.ifc.bridge.bridge;
        break;

    default:
        /* Nothing to do */
        goto out;
    }

    rc = __sdk_bridge_db_get_bridge(fid, &bridge_item_p);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find bridge_id(%d) in sdk_bridge_db.\n", fid);
        goto out;
    }

    rc = __sdk_bridge_hw_vport_rif_update(bridge_item_p, v_rif, hw_rif_id);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to update SVFA with HW RIF ID for FID [%u], err = %s\n",
                   fid, sx_status_str(rc));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __sdk_bridge_hw_rif_by_fid_get(sx_fid_t fid, boolean_t *v_rif_p, hwd_rif_id_t *hw_rif_id_p)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    sx_router_interface_t rif = rm_resource_global.router_rifs_dontcare;

    SX_LOG_ENTER();

    *v_rif_p = FALSE;
    *hw_rif_id_p = 0;

    status = sdk_fid_manager_rif_get(fid, &rif);
    if (status == SX_STATUS_SUCCESS) {
        status = sdk_router_cmn_rif_impl_is_enabled(rif, v_rif_p, hw_rif_id_p);
        if (status == SX_STATUS_ENTRY_NOT_FOUND) {
            status = SX_STATUS_SUCCESS;
            *v_rif_p = FALSE;
            *hw_rif_id_p = 0;
        } else if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to check a state of RIF[%u], error: %s \n", rif, sx_status_str(status));
            goto out;
        }
    } else if (status == SX_STATUS_ENTRY_NOT_FOUND) {
        /* In case we don't have a FID RIF on top of this FID */
        status = SX_STATUS_SUCCESS;
        *v_rif_p = FALSE;
        *hw_rif_id_p = 0;
    } else if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to get RIF ID for FID [%u], error: %s \n",
                   fid, sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}


static sx_status_t __sdk_bridge_hw_vport_rif_update(sdk_bridge_t *bridge_item_p, boolean_t irif_v, hwd_rif_id_t irif)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_bridge_virtual_port_t *vport_p = NULL;
    sx_port_info_t             port_info;
    cl_map_item_t             *brg_vport_mitem_p = NULL;
    const cl_map_item_t       *brg_vport_mend_p = NULL;
    sx_flow_counter_id_t       flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;
    sx_mirror_mode_t           mirror_mode = SX_MIRROR_MODE_DISABLED;
    uint32_t                   i = 0;
    sx_port_log_id_t           log_port = SX_INVALID_PORT;
    sx_port_log_id_t           lag_port = SX_INVALID_PORT;
    sx_port_log_id_t          *log_port_list_p = NULL;
    sx_port_log_id_t          *lag_port_list_p = NULL;
    uint32_t                   log_port_num = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(port_info);

    lag_port_list_p = (sx_port_log_id_t*)cl_malloc(sizeof(*log_port_list_p) *
                                                   rm_resource_global.lag_port_members_max);
    if (lag_port_list_p == NULL) {
        status = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for port list, err: %s\n", sx_status_str(status));
        goto out;
    }

    brg_vport_mitem_p = cl_qmap_head(&(bridge_item_p->bridge_virtual_port_map));
    brg_vport_mend_p = cl_qmap_end(&(bridge_item_p->bridge_virtual_port_map));

    while (brg_vport_mitem_p != brg_vport_mend_p) {
        vport_p = PARENT_STRUCT(brg_vport_mitem_p, sdk_bridge_virtual_port_t, map_bridge_item);
        brg_vport_mitem_p = cl_qmap_next(brg_vport_mitem_p);

        status = port_db_info_get(vport_p->log_port, &port_info);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", vport_p->log_port);
            goto out;
        }

        /*Indicate if port is in gc queue */
        if (port_info.gc_handle != NULL) {
            continue;
        }

        if (SX_PORT_ADMIN_STATUS_UP != port_info.admin_state) {
            continue;
        }

        flow_counter_id = (bridge_item_p->bridge_flow_counter_id != SX_FLOW_COUNTER_ID_INVALID) ?
                          bridge_item_p->bridge_flow_counter_id :
                          port_info.flow_counter.flow_counter_id;

        mirror_mode = (bridge_item_p->bridge_ingress_mirror_mode != SX_MIRROR_MODE_DISABLED) ?
                      bridge_item_p->bridge_ingress_mirror_mode :
                      port_info.mirror;

        if ((SX_PORT_TYPE_ID_GET(vport_p->log_port) == SX_PORT_TYPE_VPORT) ||
            (SX_PORT_TYPE_ID_GET(vport_p->log_port) == SX_PORT_TYPE_NETWORK)) {
            log_port = 0;
            SX_PORT_TYPE_ID_SET(log_port, SX_PORT_TYPE_NETWORK);
            SX_PORT_PHY_ID_SET(log_port, SX_PORT_PHY_ID_GET(vport_p->log_port));
            SX_PORT_DEV_ID_SET(log_port, port_info.device_id);
            log_port_list_p = &log_port;
            log_port_num = 1;
        } else {
            /* construct a lag to get a list of its local ports */
            lag_port = 0;
            log_port_num = rm_resource_global.lag_port_members_max;
            SX_PORT_TYPE_ID_SET(lag_port, SX_PORT_TYPE_LAG);
            SX_PORT_LAG_ID_SET(lag_port, SX_PORT_LAG_ID_GET(vport_p->log_port));

            status = sx_lag_port_group_get(lag_port, lag_port_list_p, &log_port_num);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to get a list of local ports for vlag[0x%x].\n", vport_p->log_port);
                goto out;
            }
            log_port_list_p = lag_port_list_p;
        }

        for (i = 0; i < log_port_num; i++) {
            /* Access SVFA via port module */
            status = port_vport_svfa_update(log_port_list_p[i],
                                            SX_PORT_VLAN_ID_GET(vport_p->log_port),
                                            bridge_item_p->bridge_id,
                                            flow_counter_id, mirror_mode,
                                            irif_v, irif);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("port_vport_svfa_update failed, vport(0x%x).\n", vport_p->log_port);
                goto out;
            }
        }
    } /* while */

out:
    if (lag_port_list_p != NULL) {
        CL_FREE_N_NULL(lag_port_list_p);
    }

    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_init(sx_bridge_params_t *bridge_init_param)
{
    sx_status_t                 status = SX_STATUS_SUCCESS;
    sx_utils_status_t           utils_err = SX_UTILS_STATUS_SUCCESS;
    uint32_t                    bridge_db_size = 0;
    gc_object_type_attributes_t object_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(object_attr);

    if (bridge_init_param == NULL) {
        SX_LOG_ERR("bridge_init_param parameter is NULL.\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    bridge_init_mode = bridge_init_param->sdk_mode;

    switch (bridge_init_param->sdk_mode) {
    case SX_MODE_802_1Q:
        bridge_init_param->sdk_mode = SX_MODE_HYBRID;
        bridge_init_param->sdk_mode_params.mode_hybrid.max_bridge_num = 0;
        break;

    case SX_MODE_802_1D:
        SX_LOG_ERR("SDK mode %s is not supported.\n", sx_bridge_mode_str(bridge_init_param->sdk_mode));
        status = SX_STATUS_UNSUPPORTED;
        goto out;

    case SX_MODE_HYBRID:
        break;

    default:
        SX_LOG_ERR("SDK mode in not supported.\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (bridge_init_param->sdk_mode_params.mode_hybrid.max_bridge_num == 0) {
        SX_LOG(SX_LOG_INFO, "Initializing bridge module with max_bridge_num == 0.\n");
        goto out;
    }

    if (bridge_init_param->sdk_mode_params.mode_hybrid.max_bridge_num > rm_resource_global.bridge_num_max) {
        SX_LOG(SX_LOG_ERROR, "Cannot initialize bridge module with max_bridge_num(%u) > %u.\n",
               bridge_init_param->sdk_mode_params.mode_hybrid.max_bridge_num,
               rm_resource_global.bridge_num_max);
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL != sdk_bridge_db_p) {
        SX_LOG(SX_LOG_ERROR, "Bridge DB already initialized.\n");
        status = SX_STATUS_DB_ALREADY_INITIALIZED;
        goto out;
    }

    status = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_RIF_ENABLE_E,
                                    __sdk_bridge_rif_adviser_cb);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up rif enable adviser, rc = %s\n", sx_status_str(status));
        goto out;
    }

    status = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_PRE_RIF_DISABLE_E,
                                    __sdk_bridge_rif_adviser_cb);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up rif disable adviser, rc = %s\n", sx_status_str(status));
        goto out;
    }

    status = adviser_register_event(SX_ACCESS_CMD_ADD,
                                    ADVISER_EVENT_PREPARE_PROFILE_E,
                                    __bridge_prepare_profile_callback);
    if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("Bridge failed to register on PREPARE_PROFILE event: %s\n", sx_status_str(status));
        goto out;
    }

    bridge_db_size = sizeof(sdk_bridge_db_t);
    sdk_bridge_db_p = cl_malloc(bridge_db_size);
    SX_MEM_CLR_BUF(sdk_bridge_db_p, bridge_db_size);

    if (NULL == sdk_bridge_db_p) {
        SX_LOG(SX_LOG_ERROR, "Failed to allocate memory for the bridge DB.\n");
        status = SX_STATUS_NO_MEMORY;
        adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PREPARE_PROFILE_E,
                               __bridge_prepare_profile_callback);
        goto out;
    }

    sdk_bridge_db_p->max_bridge_num = bridge_init_param->sdk_mode_params.mode_hybrid.max_bridge_num;

    status = __sdk_bridge_db_init();
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Unable to initialize sdk_bridge_db.\n");
        adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PREPARE_PROFILE_E,
                               __bridge_prepare_profile_callback);
        cl_free(sdk_bridge_db_p);
        sdk_bridge_db_p = NULL;
        goto out;
    }

    object_attr.free_objects_threshold = VLAN_ID_MAX / 10;
    object_attr.per_object_threshold = VLAN_ID_MAX / 2;
    object_attr.fence_type = GC_FENCE_TYPE_SLOW;
    object_attr.hw_operation_needed = TRUE;
    object_attr.immediate_fence_needed = FALSE;
    utils_err = gc_object_init(GC_OBJECT_TYPE_PORT, &object_attr, __sdk_bridge_gc_delete_cb, NULL);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        status = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to initialize PORT object type in GC, utils_err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_err));
    }


out:
    if (status == SX_STATUS_SUCCESS) {
        bridge_initialized = TRUE;
    }
    SX_LOG_EXIT();
    return status;
}

static sx_utils_status_t __sdk_bridge_gc_delete_cb(const void *gc_context)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_bridge_context_item_t *sdk_bridge_context_item_p = (sdk_bridge_context_item_t*)gc_context;

    status = __sdk_bridge_return_vport_to_db(sdk_bridge_context_item_p);
    if (SX_CHECK_FAIL(status)) {
        goto out;
    }

out:
    return SX_STATUS_TO_SX_UTILS_STATUS(status);
}

sx_status_t sdk_bridge_deinit()
{
    sx_status_t       status = SX_STATUS_SUCCESS;
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    cl_status_t       cl_err = CL_SUCCESS;

    SX_LOG_ENTER();

    if (bridge_initialized == FALSE) {
        SX_LOG_DBG("bridge module is not initialized.\n");
        goto out;
    }

    if ((bridge_initialized == TRUE) && (bridge_init_mode == SX_MODE_802_1Q)) {
        SX_LOG_DBG("sdk_bridge_deinit bridge with bride mode = SX_MODE_802_1Q.\n");
        goto out;
    }

    if (NULL == sdk_bridge_db_p) {
        status = SX_STATUS_ERROR;
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        goto out;
    }

    status = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_RIF_ENABLE_E,
                                    __sdk_bridge_rif_adviser_cb);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up rif enable adviser, rc = %s\n", sx_status_str(status));
        goto out;
    }

    status = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PRE_RIF_DISABLE_E,
                                    __sdk_bridge_rif_adviser_cb);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set up rif disable adviser, rc = %s\n", sx_status_str(status));
        goto out;
    }

    status = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                    ADVISER_EVENT_PREPARE_PROFILE_E,
                                    __bridge_prepare_profile_callback);
    if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("Bridge failed to unregister on PREPARE_PROFILE event: %s\n", sx_status_str(status));
    }

    /* deinit triggers GC completion callback that might need some
     * pool/map operations, so GC clean up for PORT needs to happen
     * before pool and map are destroyed.
     */
    sx_utils_status = gc_object_deinit(GC_OBJECT_TYPE_PORT);
    status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
    if (SX_UTILS_CHECK_FAIL(sx_utils_status)) {
        SX_LOG_ERR("Failed to deinitialize GC object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(GC_OBJECT_TYPE_PORT),
                   SX_UTILS_STATUS_MSG(sx_utils_status));
    }
    status = __sdk_bridge_db_clear_all_bridges();
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in sdk_bridge_db_clear_all_bridges error: %s \n", sx_status_str(status));
    }

    status = __sdk_bridge_db_deinit();
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Unable to de-initialize sdk_bridge_db.\n");
    }

    if (sdk_bridge_db_p) {
        cl_err = cl_free(sdk_bridge_db_p);
        if (cl_err != CL_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Failed to allocate memory for the sdk_bridge DB.\n");
            status = SX_STATUS_ERROR;
        }

        sdk_bridge_db_p = NULL;
    }

    bridge_init_mode = SX_MODE_802_1Q;


out:
    if (status == SX_STATUS_SUCCESS) {
        bridge_initialized = FALSE;
    }
    SX_LOG_EXIT();
    return status;
}


sx_status_t sdk_bridge_set(sx_access_cmd_t cmd, sx_bridge_id_t *bridge_id)
{
    sx_status_t   status = SX_STATUS_SUCCESS;
    sdk_bridge_t *bridge_item = NULL;

    SX_LOG_ENTER();

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (bridge_id == NULL) {
        SX_LOG_ERR("bridge_id parameter is NULL.\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        /* Allocate a bridge entry from DB */
        status = __sdk_bridge_db_alloc_bridge(&bridge_item);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__sdk_bridge_db_alloc_bridge failed (%s).\n", sx_status_str(status));
            goto out;
        }

        /* allocate fid in HW */
        status = vlan_fid_set(SX_ACCESS_CMD_ADD, 0, bridge_item->bridge_id, SX_FM_FID_TYPE_BRIDGE_REWRITE_E);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("vlan_fid_set failed (%s).\n", sx_status_str(status));
            /* Return bridge entry to DB */
            __sdk_bridge_db_free_bridge(bridge_item);

            goto out;
        }

        *bridge_id = bridge_item->bridge_id;

        break;

    case SX_ACCESS_CMD_DESTROY:
        /* Get bridge item from DB */
        status = __sdk_bridge_db_get_bridge(*bridge_id, &(bridge_item));
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__sdk_bridge_db_get_bridge failed (%s).\n", sx_status_str(status));
            goto out;
        }
        /* Verify bridge has no virtual ports and ref count of router interface is zero*/
        status = __sdk_bridge_db_verify_empty_bridge(bridge_item);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__sdk_bridge_db_verify_empty_bridge failed (%s).\n", sx_status_str(status));
            goto out;
        }

        /* Free fid in HW */
        status = vlan_fid_set(SX_ACCESS_CMD_DELETE, 0, bridge_item->bridge_id, SX_FM_FID_TYPE_BRIDGE_REWRITE_E);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("vlan_fid_set failed (%s).\n", sx_status_str(status));
            goto out;
        }

        /* Return bridge entry to DB */
        __sdk_bridge_db_free_bridge(bridge_item);
        break;

    default:
        SX_LOG_ERR("cmd unsupported (%s).\n", sx_access_cmd_str(cmd));
        status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_iter_get(const sx_access_cmd_t     cmd,
                                const sx_bridge_id_t      bridge_id,
                                const sx_bridge_filter_t *filter_p,
                                sx_bridge_id_t           *bridge_id_list_p,
                                uint32_t                 *bridge_id_cnt_p)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    length_t       size = 0;
    length_t       max_size = 0;
    cl_map_item_t *map_item_p = NULL;

    UNUSED_PARAM(filter_p);

    SX_LOG_ENTER();

    if (bridge_init_mode == SX_MODE_802_1Q) {
        SX_LOG_ERR("Bridge mode is 802.1Q.\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        err = SX_STATUS_DB_NOT_INITIALIZED;
        goto out;
    }

    if (NULL == bridge_id_cnt_p) {
        SX_LOG_ERR("bridge_id_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*bridge_id_cnt_p > 0) && (NULL == bridge_id_list_p)) {
        SX_LOG_ERR("*bridge_id_cnt_p is not 0 but bridge_id_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    size = 0;
    max_size = *bridge_id_cnt_p;

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (max_size == 0) {
            /* Get the total count of bridge IDs */
            size = cl_qmap_count(&(sdk_bridge_db_p->bridge_map));
        } else {
            /* GET single bridge ID matching key. (force count to 1) */
            map_item_p = cl_qmap_get(&(sdk_bridge_db_p->bridge_map), bridge_id);
            max_size = 1;
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        map_item_p = cl_qmap_head(&(sdk_bridge_db_p->bridge_map));
        break;

    case SX_ACCESS_CMD_GETNEXT:
        map_item_p = cl_qmap_get_next(&(sdk_bridge_db_p->bridge_map), bridge_id);
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd = %s not Supported\n", sx_access_cmd_str(cmd));
        goto out;
    }

    while ((size < max_size) && (map_item_p != cl_qmap_end(&(sdk_bridge_db_p->bridge_map)))) {
        bridge_id_list_p[size++] = (sx_bridge_id_t)cl_qmap_key(map_item_p);
        map_item_p = cl_qmap_next(map_item_p);
    }

    *bridge_id_cnt_p = size;

    SX_LOG_DBG("Retrieved %u bridge IDs.\n", (uint32_t)size);

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __bridge_flood_control_port_set(sx_access_cmd_t  cmd,
                                                   sdk_bridge_t    *bridge_item,
                                                   sx_port_log_id_t vport_id)
{
    sx_status_t             status = SX_STATUS_SUCCESS;
    sx_port_log_id_t       *port_list = NULL;
    sx_swid_t               swid = 0;
    uint32_t                i = 0, j = 0, vports_num = 0;
    uint16_t                blocked_ports_num = 0;
    sx_flood_control_type_t control_type[] = {SX_FLOOD_CONTROL_TYPE_UNICAST_E,
                                              SX_FLOOD_CONTROL_TYPE_BROADCAST_E};
    uint32_t                size = sizeof(control_type) / sizeof(sx_flood_control_type_t);

    SX_LOG_ENTER();

    /* Get the swid */
    status = port_db_swid_alloc_get(vport_id, &swid);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("port_db_swid_alloc_get Failed. status = (%s)\n", sx_status_str(status));
        goto out;
    }

    vports_num = cl_qmap_count(&bridge_item->bridge_virtual_port_map);

    if (vports_num == 0) {
        SX_LOG_DBG("No vports on bridge id (%u)\n", bridge_item->bridge_id);
        goto out;
    }

    port_list = (sx_port_log_id_t*)cl_calloc(vports_num, sizeof(sx_port_log_id_t));

    /* Get the list of (flood) blocked ports for the bridge for UNICAST, BROADCAST and PRUNE MC */
    /* First UNICAST/BROADCAST */
    for (j = 0; j < size; j++) {
        blocked_ports_num = (uint16_t)vports_num;
        status = fdb_flood_control_get(swid,
                                       bridge_item->bridge_id,
                                       control_type[j],
                                       &blocked_ports_num,
                                       port_list);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_DBG("fdb_flood_control_get - failed, fid (%u), type (%u), status - (%s)\n",
                       bridge_item->bridge_id, control_type[j], sx_status_str(status));
            goto out;
        }

        for (i = 0; i < blocked_ports_num; i++) {
            if (port_list[i] == vport_id) {
                status = fdb_flood_control_set(cmd,
                                               swid,
                                               bridge_item->bridge_id,
                                               control_type[j],
                                               1,
                                               &port_list[i]);

                if (status != SX_STATUS_SUCCESS) {
                    SX_LOG_DBG("fdb_flood_control_set - failed, fid (%u), type (%u), status - (%s)\n",
                               bridge_item->bridge_id, control_type[j], sx_status_str(status));
                    goto out;
                }

                break;
            }
        }
    }

    /* Now MC (prune) */
    status = fdb_urmc_control_port_set(cmd, swid, bridge_item->bridge_id,
                                       vports_num, vport_id);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("fdb_urmc_control_port_set - failed, fid (%u), status - (%s)\n",
                   bridge_item->bridge_id, sx_status_str(status));
        goto out;
    }

out:
    if (NULL != port_list) {
        cl_free(port_list);
    }
    SX_LOG_EXIT();

    return status;
}

static sx_status_t __bridge_flood_port_set(sx_access_cmd_t cmd, sx_fid_t fid_id, sx_port_log_id_t port_id)
{
    sx_status_t   status = SX_STATUS_SUCCESS, roll_back_status = SX_STATUS_SUCCESS;
    sx_port_id_t *port_list = NULL;
    uint32_t      port_num = rm_resource_global.lag_port_members_max;
    sx_swid_t     swid = 0;
    uint32_t      i = 0, rollback_idx = 0;

    SX_LOG_ENTER();

    port_list = (sx_port_id_t*)cl_calloc(rm_resource_global.lag_port_members_max, sizeof(sx_port_id_t));
    if (port_list == NULL) {
        status = SX_STATUS_NO_MEMORY;
        goto out;
    }

    if (IS_LAG_OR_VLAG(port_id)) {
        status = sx_lag_port_group_get(port_id, port_list, &port_num);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to retrieve lag members of lag %#08X (%s)\n",
                       port_id, sx_status_str(status));
            goto out;
        }
    } else { /* SX_PORT_TYPE_NETWORK */
        status = port_vport_base_port_get(port_id, &(port_list[0]));
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to retrieve base port for vport 0x%x, error: %s\n",
                       port_id, sx_status_str(status));
            goto out;
        }
        port_num = 1;
    }

    /* Get the swid */
    status = port_db_swid_alloc_get(port_id, &swid);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("port_db_swid_alloc_get Failed. status = (%s)\n", sx_status_str(status));
        goto out;
    }

    for (i = 0; i < port_num; i++) {
        status = fdb_flood_port_membership_set(cmd, swid, fid_id, port_list[i]);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("fdb_flood_port_membership_set failed for %#08X. (%s)\n", port_list[i], sx_status_str(status));

            cmd = (cmd == SX_ACCESS_CMD_ADD_PORTS) ? (SX_ACCESS_CMD_DELETE_PORTS) : (SX_ACCESS_CMD_ADD_PORTS);
            /* Roll back */
            for (rollback_idx = i; rollback_idx > 0; rollback_idx--) {
                roll_back_status = fdb_flood_port_membership_set(cmd, swid, fid_id, port_list[rollback_idx - 1]);
                if (roll_back_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Roll back fdb_flood_port_membership_set failed for %#08X. (%s)\n",
                               port_list[rollback_idx - 1], sx_status_str(roll_back_status));
                }
            }
            goto out;
        }
    }

out:
    if (port_list) {
        cl_free(port_list);
    }
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_vport_set_pre_adviser_validation(sx_access_cmd_t     cmd,
                                                                 const sdk_bridge_t *bridge_item,
                                                                 sx_port_log_id_t    log_port)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    vport_bridge_cb_t          vport_bridge_cb;
    cl_map_item_t             *vport_map_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    sdk_bridge_virtual_port_t *vport;

    SX_LOG_ENTER();

    SX_MEM_CLR(vport_bridge_cb);
    switch (cmd) {
    case SX_ACCESS_CMD_DELETE:
        vport_bridge_cb.fid_id = bridge_item->bridge_id;
        vport_bridge_cb.log_port = log_port;

        status = adviser_process_event(ADVISER_EVENT_PRE_VPORT_BRIDGE_DELETE_E, &(vport_bridge_cb));
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_DBG("Could not process Port Sink event '%s'.\n",
                       ADVISER_EVENT_STR(ADVISER_EVENT_PRE_VPORT_BRIDGE_DELETE_E));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));
        for (vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map)); vport_map_item != vport_map_end;
             vport_map_item = cl_qmap_next(vport_map_item)) {
            vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);

            vport_bridge_cb.fid_id = bridge_item->bridge_id;
            vport_bridge_cb.log_port = vport->log_port;
            status = adviser_process_event(ADVISER_EVENT_PRE_VPORT_BRIDGE_DELETE_E, &(vport_bridge_cb));
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_DBG("Could not process Port Sink event '%s'.\n",
                           ADVISER_EVENT_STR(ADVISER_EVENT_PRE_VPORT_BRIDGE_DELETE_E));
                goto out;
            }
        }
        break;

    default:
        break;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_vport_set(sx_access_cmd_t  cmd,
                                 sx_bridge_id_t   bridge_id,
                                 sx_port_log_id_t log_port,
                                 boolean_t        part_of_multi_vlans_set)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sx_utils_status_t          utils_status = SX_UTILS_STATUS_SUCCESS;
    sdk_bridge_t              *bridge_item = NULL;
    sx_port_info_t             port_info;
    boolean_t                  is_new_lag = FALSE, is_last_vport_lag = FALSE, first_fence = TRUE;
    cl_map_item_t             *vport_map_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    sdk_bridge_virtual_port_t *vport;
    sx_port_log_id_t           lag_log_port = 0;
    vport_bridge_cb_t          vport_bridge_cb;
    sx_flow_counter_obj_t      tmp_flow_counter;
    boolean_t                  approve_delete_flag = FALSE;
    uint32_t                   ref_count = 0;

    SX_LOG_ENTER();
    SX_MEM_CLR(vport_bridge_cb);

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /*Get bridge from DB*/
    status = __sdk_bridge_db_get_bridge(bridge_id, &bridge_item);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find bridge_id(%d) in sdk_bridge_db.\n", bridge_id);
        goto out;
    }

    /* Verify vport exists */
    if ((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_DELETE)) {
        status = port_db_info_get(log_port, &port_info);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", log_port);
            goto out;
        }
    }

    if ((cmd == SX_ACCESS_CMD_ADD) && (port_info.gc_handle != NULL)) {
        /* Sync fence */
        utils_status = gc_object_fence(GC_FENCE_TYPE_SLOW);
        status = sx_utils_status_to_sx_status(utils_status);
        if (SX_UTILS_CHECK_FAIL(utils_status)) {
            SX_LOG_ERR("Failed to process GC queue for object type PORT\n");
            goto out;
        }
        status = sdk_bridge_remove_vport_from_gc_queue(log_port);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed in sdk_bridge_remove_vport_from_gc_queue\n");
            goto out;
        }
    }

    /* Validate parameters */
    if ((cmd == SX_ACCESS_CMD_ADD) || (cmd == SX_ACCESS_CMD_DELETE)) {
        status = __sdk_bridge_port_set_validate(cmd, bridge_item, log_port, &port_info);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__bridge_validate_get_port_set failed (%s).\n", sx_status_str(status));
            goto out;
        }

        status = __sdk_bridge_port_set_validate_redirect(cmd, bridge_item, log_port);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__sdk_bridge_port_set_validate_redirect failed (%s).\n", sx_status_str(status));
            goto out;
        }

        if (cmd == SX_ACCESS_CMD_DELETE) {
            /* Check if IGMP v3 enabled before remove the last vPort from the Bridge */
            status = sdk_bridge_port_delete_validate_igmpv3_state(bridge_id, log_port, &approve_delete_flag);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("sdk_bridge_port_delete_validate_igmpv3_state failed (%s).\n", sx_status_str(status));
                goto out;
            }

            if (approve_delete_flag == FALSE) {
                status = SX_STATUS_RESOURCE_IN_USE;
                SX_LOG_ERR(
                    "Failed to delete last vPort (0x%x) on Bridge (%d) - igmpv3 state on this Vlan is enabled, err = %s\n",
                    log_port,
                    bridge_id,
                    sx_status_str(status));
                goto out;
            }

            /* Make sure the vPort is part of the bridge */
            status = bridge_is_log_port_in_bridge(&bridge_id, log_port);
            if (status == SX_STATUS_ENTRY_NOT_FOUND) {
                SX_LOG_ERR("vPort 0x%08X is not part of bridge (%u)\n",
                           log_port, bridge_id);
                goto out;
            } else if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error checking vPort 0x%08X in bridge (%u)\n",
                           log_port, bridge_id);
                goto out;
            }
        }
    }

    status = __sdk_bridge_vport_set_pre_adviser_validation(cmd, bridge_item, log_port);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in pre adviser validation (%s)\n", sx_status_str(status));
        goto out;
    }

    /* construct a lag type for the adviser */
    if (SX_PORT_TYPE_ID_GET(log_port) == SX_PORT_TYPE_VLAG) {
        SX_PORT_TYPE_ID_SET(lag_log_port, SX_PORT_TYPE_LAG);
        SX_PORT_LAG_ID_SET(lag_log_port, SX_PORT_LAG_ID_GET(log_port));
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        status = __bridge_validate_igmpv3_parameters(log_port, bridge_item, bridge_id, &port_info);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to validate IGMPv3 parameters\n");
            goto out;
        }

        /* allocate a virtual_port from DB */
        status = __sdk_bridge_db_alloc_virtual_port(log_port, bridge_item, &is_new_lag);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__sdk_bridge_db_alloc_virtual_port failed (%s).\n", sx_status_str(status));
            goto out;
        }

        status = port_ref_cnt_increase(log_port);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("port_ref_cnt_increase failed (%s).\n", sx_status_str(status));
            __sdk_bridge_db_free_virtual_port(log_port, bridge_item, NULL);
            goto out;
        }

        /* If vport is first for this LAG, register for port add call backs */
        if (is_new_lag) {
            status = lag_sink_lag_advise(lag_log_port, __sdk_bridge_lag_port_update, NULL, 0);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("lag_sink_lag_advise failed (%s) on LAG (0x%x).\n", sx_status_str(status), log_port);
                port_ref_cnt_decrease(log_port);
                __sdk_bridge_db_free_virtual_port(log_port, bridge_item, NULL);
                goto out;
            }
        }

        if (SX_PORT_ADMIN_STATUS_UP == port_info.admin_state) {
            status = __bridge_flood_port_set(SX_ACCESS_CMD_ADD_PORTS, bridge_item->bridge_id, log_port);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__bridge_flood_port_set ADD failed for vport (0x%x) bridge (%d).\n",
                           log_port,
                           bridge_item->bridge_id);
                /* Roll back */
                port_ref_cnt_decrease(log_port);
                __sdk_bridge_db_free_virtual_port(log_port, bridge_item, &is_last_vport_lag);
                if (is_last_vport_lag) {
                    lag_sink_lag_unadvise(lag_log_port, __sdk_bridge_lag_port_update);
                }
                goto out;
            }

            status = __sdk_bridge_hw_vport_add(log_port, bridge_item, &port_info);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__sdk_bridge_hw_vport_add failed (%s) on (0x%x).\n", sx_status_str(status), log_port);
                /* Roll back */
                __bridge_flood_port_set(SX_ACCESS_CMD_DELETE_PORTS, bridge_item->bridge_id, log_port);
                port_ref_cnt_decrease(log_port);
                __sdk_bridge_db_free_virtual_port(log_port, bridge_item, &is_last_vport_lag);
                if (is_last_vport_lag) {
                    lag_sink_lag_unadvise(lag_log_port, __sdk_bridge_lag_port_update);
                }
                goto out;
            }
        } else {
            tmp_flow_counter.flow_counter_bound_entity = SX_FLOW_COUNTER_BRIDGE_TYPE;
            tmp_flow_counter.flow_counter_id = bridge_item->bridge_flow_counter_id;

            if (SX_FLOW_COUNTER_ID_INVALID != bridge_item->bridge_flow_counter_id) {
                if (SX_FLOW_COUNTER_ID_INVALID != port_info.flow_counter.flow_counter_id) {
                    SX_LOG(SX_LOG_ERROR, "port (0x%x) bound to flow counter and cannot be bound again .\n", log_port);
                    status = SX_STATUS_ERROR;
                    port_ref_cnt_decrease(log_port);
                    goto out;
                }
                status = port_flow_counter_port_db_update(log_port, tmp_flow_counter);
                if (status != SX_STATUS_SUCCESS) {
                    SX_LOG(SX_LOG_ERROR, "Could not update port flow counter vport (0x%0x).\n", log_port);
                    port_ref_cnt_decrease(log_port);
                    goto out;
                }
            }
        }

        vport_bridge_cb.fid_id = bridge_item->bridge_id; /*fid_id == bridge_id*/
        vport_bridge_cb.log_port = log_port;
        vport_bridge_cb.part_of_multi_vlans_set = part_of_multi_vlans_set;

        status = adviser_process_event(ADVISER_EVENT_POST_VPORT_BRIDGE_ADD_E, &(vport_bridge_cb));
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_DBG("Could not process Port Sink event '%s' for cmd=%s.\n",
                       ADVISER_EVENT_STR(ADVISER_EVENT_POST_VPORT_BRIDGE_ADD_E), sx_access_cmd_str(cmd));
            port_ref_cnt_decrease(log_port);
            goto out;
        }

        break;

    case SX_ACCESS_CMD_DELETE:
        status = port_db_ref_cnt_get(log_port, &ref_count);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("port_db_ref_cnt_get failed (%s) on vport (0x%x).\n", sx_status_str(status), log_port);
            goto out;
        }

        /*when we add the vport to the bridge, we increased ref count to be 1. The actual decrease of ref count will happen when GC done. */
        if (ref_count > 1) {
            status = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR(
                "remove vport from the bridge id %d failed (%s) on vport (0x%x) ref_count %d. Please delete other reference first then try again\n",
                bridge_id,
                sx_status_str(status),
                log_port,
                ref_count);
            goto out;
        }

        status = __sdk_bridge_vport_delete(log_port, bridge_item);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__sdk_bridge_vport_delete failed (%s) on vport (0x%x).\n", sx_status_str(status), log_port);
            goto out;
        }

        vport_bridge_cb.fid_id = bridge_item->bridge_id; /*fid_id == bridge_id*/
        vport_bridge_cb.log_port = log_port;
        vport_bridge_cb.part_of_multi_vlans_set = part_of_multi_vlans_set;

        status = adviser_process_event(ADVISER_EVENT_POST_VPORT_BRIDGE_DELETE_E, &(vport_bridge_cb));
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_DBG("Could not process Port Sink event '%s' for cmd=%s.\n",
                       ADVISER_EVENT_STR(ADVISER_EVENT_POST_VPORT_BRIDGE_DELETE_E), sx_access_cmd_str(cmd));
            goto out;
        }

        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
        vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));
        while (vport_map_item != vport_map_end) {
            vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);
            vport_map_item = cl_qmap_next(vport_map_item);
            status = port_db_ref_cnt_get(vport->log_port, &ref_count);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("port_db_ref_cnt_get failed (%s) on vport (0x%x).\n", sx_status_str(status),
                           vport->log_port);
                goto out;
            }

            /*when we add the vport to the bridge, we increased ref count. The actual decrease of ref count will happen when GC done*/
            if (ref_count > 1) {
                status = SX_STATUS_RESOURCE_IN_USE;
                SX_LOG_ERR(
                    "remove vport from the bridge id %d failed (%s) on vport (0x%x) ref_count %d > 1. Please delete other reference first then try again\n",
                    bridge_id,
                    sx_status_str(status),
                    log_port,
                    ref_count);
                goto out;
            }
        }

        vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));

        while (vport_map_item != vport_map_end) {
            vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);
            vport_map_item = cl_qmap_next(vport_map_item);

            status = port_db_info_get(vport->log_port, &port_info);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", vport->log_port);
                goto out;
            }

            if (port_info.gc_handle != NULL) {
                /* Sync fence */
                if (first_fence) {
                    utils_status = gc_object_fence(GC_FENCE_TYPE_SLOW);
                    status = sx_utils_status_to_sx_status(utils_status);
                    if (SX_UTILS_CHECK_FAIL(utils_status)) {
                        SX_LOG_ERR("Failed to process GC queue for object type PORT\n");
                        goto out;
                    }
                    first_fence = FALSE;
                }
                status = sdk_bridge_remove_vport_from_gc_queue(vport->log_port);
                if (SX_CHECK_FAIL(status)) {
                    SX_LOG_ERR("Failed in sdk_bridge_remove_vport_from_gc_queue\n");
                    goto out;
                }
                continue;
            }

            status = __sdk_bridge_vport_delete(vport->log_port, bridge_item);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__sdk_bridge_vport_delete failed (%s) on vport (0x%x).\n", sx_status_str(status),
                           vport->log_port);
                goto out;
            }

            vport_bridge_cb.fid_id = bridge_item->bridge_id; /*fid_id == bridge_id*/
            vport_bridge_cb.log_port = vport->log_port;
            vport_bridge_cb.part_of_multi_vlans_set = part_of_multi_vlans_set;

            status = adviser_process_event(ADVISER_EVENT_POST_VPORT_BRIDGE_DELETE_E, &(vport_bridge_cb));
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_DBG("Could not process Port Sink event '%s' for cmd=%s.\n",
                           ADVISER_EVENT_STR(ADVISER_EVENT_POST_VPORT_BRIDGE_DELETE_E), sx_access_cmd_str(cmd));
                goto out;
            }
        }

        break;

    default:
        SX_LOG_ERR("cmd unsupported (%s).\n", sx_access_cmd_str(cmd));
        status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    status = __sdk_bridge_port_set_update_bridge(cmd, bridge_item, log_port);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__sdk_bridge_port_set_update_bridge failed (%s) on vport (0x%x).\n", sx_status_str(status),
                   log_port);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

/*
 * Tell ADVISER_EVENT_POST_VPORT_BRIDGE_ADD/DELETE advisers to push any pending HW updates.
 */
sx_status_t sdk_bridge_vport_pending_push_set(void)
{
    sx_status_t       status = SX_STATUS_SUCCESS;
    vport_bridge_cb_t vport_bridge_cb;

    SX_LOG_ENTER();

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    SX_MEM_CLR(vport_bridge_cb);
    status = adviser_process_event(ADVISER_EVENT_POST_VPORT_BRIDGE_PENDING_PUSH_E, &vport_bridge_cb);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Could not process event '%s'.\n",
                   ADVISER_EVENT_STR(ADVISER_EVENT_POST_VPORT_BRIDGE_PENDING_PUSH_E));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}


sx_status_t sdk_bridge_vport_get(sx_bridge_id_t    bridge_id,
                                 sx_port_log_id_t *bridge_vport_list_p,
                                 uint32_t         *bridge_vport_cnt_p)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_bridge_t              *bridge_item = NULL;
    sdk_bridge_virtual_port_t *vport = NULL;
    cl_map_item_t             *map_item = NULL;
    const cl_map_item_t       *map_end = NULL;
    sx_port_info_t             port_info;
    uint32_t                   i = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(port_info);

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    status = __sdk_bridge_db_get_bridge(bridge_id, &bridge_item);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find bridge_id(%d) in sdk_bridge_db.\n", bridge_id);
        goto out;
    }

    if (bridge_vport_cnt_p == NULL) {
        SX_LOG_ERR("bridge_vport_cnt_p parameter is NULL.\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*bridge_vport_cnt_p == 0) || (bridge_vport_list_p == NULL)) {
        *bridge_vport_cnt_p = cl_qmap_count(&(bridge_item->bridge_virtual_port_map));
        bridge_vport_list_p = NULL;
        goto out;
    }

    map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
    map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));

    while (map_item != map_end) {
        vport = PARENT_STRUCT(map_item, sdk_bridge_virtual_port_t, map_bridge_item);
        map_item = cl_qmap_next(map_item);
        status = port_db_info_get(vport->log_port, &port_info);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", vport->log_port);
            goto out;
        }
        if (port_info.gc_handle == NULL) {
            bridge_vport_list_p[i++] = vport->log_port;
            if (i >= *bridge_vport_cnt_p) {
                break;
            }
        }
    }

    *bridge_vport_cnt_p = i;

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_counter_bind_set(sx_access_cmd_t      cmd,
                                        sx_bridge_id_t       bridge_id,
                                        sx_flow_counter_id_t flow_counter_id)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    sdk_bridge_t         *bridge_item = NULL;
    sx_flow_counter_obj_t flow_counter_obj;

    SX_LOG_ENTER();

    /* If bridge is VLAN, go to VLAN counter flow */
    if (VLAN_ID_CHECK_RANGE(bridge_id)) {
        status = sdk_vlan_counter_bind_set(cmd, bridge_id, flow_counter_id);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to bind/unbind counter %u to VLAN %u (%s).\n",
                       flow_counter_id, bridge_id, sx_status_str(status));
        }
        goto out;
    }

    flow_counter_obj.flow_counter_id = flow_counter_id;
    flow_counter_obj.flow_counter_bound_entity = SX_FLOW_COUNTER_BRIDGE_TYPE;
    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    status = __sdk_bridge_db_get_bridge(bridge_id, &bridge_item);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find bridge_id(%d) in sdk_bridge_db.\n", bridge_id);
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:

        /* Verify bridge and all vport on bridge are not bound to a flow counter */
        status = __sdk_bridge_db_counter_bind_validate(bridge_item);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "__sdk_bridge_db_counter_bind_validate failed (%s).\n", sx_status_str(status));
            goto out;
        }

        status = __sdk_bridge_hw_counter_bind(bridge_item, flow_counter_obj);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "__sdk_bridge_hw_counter_bind failed (%s).\n", sx_status_str(status));
            goto out;
        }

        bridge_item->bridge_flow_counter_id = flow_counter_id;

        break;

    case SX_ACCESS_CMD_UNBIND:

        if (bridge_item->bridge_flow_counter_id == SX_FLOW_COUNTER_ID_INVALID) {
            SX_LOG(SX_LOG_ERROR, "bridge_id(%d) is not bound to a flow counter.\n", bridge_id);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        status = __sdk_bridge_hw_counter_unbind(bridge_item);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "__sdk_bridge_hw_counter_unbind failed (%s).\n", sx_status_str(status));
            goto out;
        }

        bridge_item->bridge_flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;

        break;

    default:
        SX_LOG_ERR("cmd unsupported (%s).\n", sx_access_cmd_str(cmd));
        status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_counter_bind_get(sx_bridge_id_t bridge_id, sx_flow_counter_id_t *flow_counter_id_p)
{
    sx_status_t   status = SX_STATUS_SUCCESS;
    sdk_bridge_t *bridge_item = NULL;

    SX_LOG_ENTER();

    /* If bridge is VLAN, go to VLAN counter flow */
    if (VLAN_ID_CHECK_RANGE(bridge_id)) {
        status = sdk_vlan_counter_bind_get(bridge_id, flow_counter_id_p);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to get flow counter bound to VLAN %u (%s).\n",
                       bridge_id, sx_status_str(status));
        }
        goto out;
    }

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (flow_counter_id_p == NULL) {
        SX_LOG_ERR("flow_counter_id_p parameter is NULL.\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    status = __sdk_bridge_db_get_bridge(bridge_id, &bridge_item);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find bridge_id(%d) in sdk_bridge_db.\n", bridge_id);
        goto out;
    }

    *flow_counter_id_p = bridge_item->bridge_flow_counter_id;
    if (bridge_item->bridge_flow_counter_id == SX_FLOW_COUNTER_ID_INVALID) {
        status = SX_STATUS_ENTRY_NOT_FOUND;
    }
out:
    SX_LOG_EXIT();
    return status;
}

/* checking that we don't have any FDB UC entry in FDB_DB for fid/tunnel*/
static sx_status_t __sdk_fdb_uc_check_fid_tunnel_entries(const sx_fid_t fid, const sx_tunnel_id_t tunnel_id)
{
    sx_status_t                 status = SX_STATUS_SUCCESS;
    sx_port_log_id_t            log_port = SX_INVALID_PORT;
    sx_fdb_uc_mac_addr_params_t key;
    sx_fdb_uc_key_filter_t      key_filter;
    sx_fdb_uc_mac_addr_params_t mac_list;
    uint32_t                    cnt = 0;
    uint32_t                    tunnel_port_bitmap = 0;

    SX_LOG_ENTER();
    SX_LOG_DBG("check fdb_uc entries for tunnel[0x%08x], fid[0x%08x]\n", tunnel_id, fid);

    SX_MEM_CLR(key);
    SX_MEM_CLR(key_filter);
    SX_MEM_CLR(mac_list);

    status = sdk_tunnel_impl_log_port_by_tunnel_id_get(tunnel_id, &log_port);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get nve_log_port for tunnel ID[0x%08x], err = %s\n",
                   tunnel_id,
                   sx_status_str(status));
        goto out;
    }

    key.log_port = log_port;
    key.fid_vid = fid;
    key.entry_type = SX_FDB_UC_ALL;

    key_filter.filter_by_fid = SX_FDB_KEY_FILTER_FIELD_VALID;
    key_filter.fid = fid;
    key_filter.filter_by_log_port = SX_FDB_KEY_FILTER_FIELD_VALID;
    key_filter.log_port = log_port;
    key_filter.filter_by_mac_addr = SX_FDB_KEY_FILTER_FIELD_NOT_VALID;

    cnt = 1;

    /**** Try to get UC MAC entry */
    status = fdb_uc_mac_addr_get(SX_ACCESS_CMD_GET_FIRST, 0, key.entry_type, key, key_filter, &mac_list, &cnt);
    if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("Failed to get mac from  FDB_UC, err= %s.\n",
                   sx_status_str(status));
        goto out;
    }

    if (cnt == 0) {
        status = SX_STATUS_SUCCESS;
        goto out;
    }

    do {
        if (mac_list.dest_type == SX_FDB_UC_MAC_ADDR_DEST_TYPE_NEXT_HOP) {
            /* we have at least one NVE entry in fdb for bridge/tunnel*/
            status = SX_STATUS_RESOURCE_IN_USE;
            SX_LOG_ERR("Found FDB UC MAC entry for the NVE tunnel[0x%08x], fid[0x%08x].\n",
                       tunnel_id, fid);
            goto out;
        } else if (mac_list.dest_type == SX_FDB_UC_MAC_ADDR_DEST_TYPE_ECMP_NEXT_HOP_CONTAINER) {
            status = sdk_router_cmn_ecmp_l2_tunnel_get(mac_list.dest.ecmp, &tunnel_port_bitmap);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed retrieving ECMP ID [%u] tunnel bitmap, %s .\n",
                           mac_list.dest.ecmp,
                           sx_status_str(status));
                goto out;
            }

            if (tunnel_port_bitmap == (1 << SX_PORT_TUNNEL_NVE)) {
                status = SX_STATUS_RESOURCE_IN_USE;
                SX_LOG_ERR("Found FDB UC MAC entry for the NVE tunnel[0x%08x], fid[0x%08x].\n",
                           tunnel_id, fid);
                goto out;
            }
        }

        cnt = 1;
        SX_MEM_CPY(key, mac_list);

        status = fdb_uc_mac_addr_get(SX_ACCESS_CMD_GETNEXT, 0, key.entry_type, key, key_filter, &mac_list, &cnt);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Failed to get mac from UC FDB, FID: %u, err= %s.\n", fid, sx_status_str(status));
            goto out;
        }
    } while (cnt > 0);

out:
    SX_LOG_EXIT();
    return status;
}

/* checking that we don't have any FDB MC entry in FDB_DB for fid */
static sx_status_t __sdk_fdb_mc_check_fid_tunnel_entries(const sx_fid_t fid)
{
    sx_status_t            status = SX_STATUS_SUCCESS;
    sx_fdb_mac_key_t       key;
    sx_fdb_mac_key_t       key_list;
    sx_fdb_mc_key_filter_t key_filter;
    sx_fdb_mac_data_t      data;
    uint32_t               data_cnt = 0;
    hw_mc_list_pointer_t   nve_mc_list_pointer;

    SX_LOG_ENTER();

    SX_MEM_CLR(key);
    SX_MEM_CLR(data);
    SX_MEM_CLR(key_list);
    SX_MEM_CLR(key_filter);
    SX_MEM_CLR(nve_mc_list_pointer);

    data_cnt = 1;
    key.fid = fid;
    key_filter.filter_by_fid = SX_FDB_KEY_FILTER_FIELD_VALID;
    key_filter.fid = fid;
    key_filter.filter_by_mac_addr = SX_FDB_KEY_FILTER_FIELD_NOT_VALID;

    status = fdb_mc_mac_addr_extended_iter_get(SX_ACCESS_CMD_GET_FIRST, &key, &key_filter, &key_list, &data_cnt);
    if (0 == data_cnt) {
        /* There are no entries configured in given fid.
         *  Returning success. */
        status = SX_STATUS_SUCCESS;
        goto out;
    } else if (SX_STATUS_SUCCESS != status) {
        SX_LOG_ERR("Failed to get first mac from MC FDB, FID: %u, err= %s.\n", fid, sx_status_str(status));
        goto out;
    }

    do {
        status = fdb_mc_mac_addr_extended_get(key_list, &data);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Failed to get mac from MC FDB, FID: %u, err= %s.\n", fid, sx_status_str(status));
            goto out;
        }

        status = hwd_mc_container_nve_mc_list_get_with_lock(data.mc_container_id,
                                                            &nve_mc_list_pointer,
                                                            NULL);
        if (status == SX_STATUS_SUCCESS) {
            status = hwd_mc_container_nve_mc_list_unlock(data.mc_container_id);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to unlock nve mc list of mc container %u\n",
                           data.mc_container_id);
                goto out;
            }

            if (nve_mc_list_pointer.data.tnumt_pointer.tunnel_bitmap == (1 << SX_PORT_TUNNEL_NVE)) {
                /* We found nve_next_hop entry in mc_container. Resource in use.*/
                status = SX_STATUS_RESOURCE_IN_USE;
                SX_LOG_ERR("Found FDB MC MAC entry for fid[0x%08x].\n", fid);
                goto out;
            }
        }

        data_cnt = 1;
        SX_MEM_CPY(key, key_list);

        status = fdb_mc_mac_addr_extended_iter_get(SX_ACCESS_CMD_GETNEXT, &key, &key_filter, &key_list, &data_cnt);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Failed to get mac from MC FDB, FID: %u, err= %s.\n", fid, sx_status_str(status));
            goto out;
        }
    } while (data_cnt > 0);


out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_tunnel_counter_bind_set(const sx_access_cmd_t                  cmd,
                                               const sx_fid_t                         fid,
                                               const sx_bridge_tunnel_counter_attr_t *attr_p,
                                               const sx_flow_counter_id_t             counter_id)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    sx_status_t           rb_status = SX_STATUS_SUCCESS;
    sx_tunnel_map_entry_t tunnel_map_entry;
    sx_fm_fid_type_t      fid_type = SX_FM_FID_TYPE_INVALID;
    sx_flow_counter_id_t  old_counter_id = SX_FLOW_COUNTER_ID_INVALID;
    boolean_t             decap_hw_rb = FALSE;
    boolean_t             set_db_rb = FALSE;
    cm_hw_type_t          counter_hw_type = 0;
    cm_index_t            counter_hw_index = 0;
    boolean_t             counter_locked = FALSE;
    boolean_t             v_rif = FALSE;
    boolean_t             pending_delete = FALSE;
    hwd_rif_id_t          hwd_rif_id = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_map_entry);

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (utils_check_pointer(attr_p, "attr_p")) {
        status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG_DBG("SDK bridge tunnel counter(%s) bind set cmd:%s for tunnel[0x%08x], fid[0x%08x]\n",
               sx_bridge_tunnel_counter_type_str(attr_p->type),
               sx_access_cmd_str(cmd),
               attr_p->tunnel_id,
               fid);

    if (cmd == SX_ACCESS_CMD_BIND) {
        status = sdk_tunnel_db_pending_delete_get(attr_p->tunnel_id, &pending_delete);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                       attr_p->tunnel_id, sx_status_str(status));
            goto out;
        }
        if (pending_delete) {
            status = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                       attr_p->tunnel_id, sx_status_str(status));
            goto out;
        }
    }

    switch (attr_p->type) {
    case SX_BRIDGE_COUNTER_TUNNEL_DECAP_E:
        status = sdk_tunnel_impl_capability_check(attr_p->tunnel_id, SX_TUNNEL_CAP_BRIDGE_DECAP_COUNTER_E);
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E:
        status = sdk_tunnel_impl_capability_check(attr_p->tunnel_id, SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E);
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E:
        status = sdk_tunnel_impl_capability_check(attr_p->tunnel_id, SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E);
        break;

    default:
        SX_LOG_ERR("invalid counter type\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Wrong type or direction for tunnel %d, err = %s\n",
                   attr_p->tunnel_id, sx_status_str(status));
        goto out;
    }

    status = sdk_fid_manager_get_fid_type(fid, &fid_type);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find fid[0x%08x] in the FID manager.\n", fid);
        goto out;
    }

    if ((fid_type != SX_FM_FID_TYPE_VLAN_REWRITE_E) &&
        (fid_type != SX_FM_FID_TYPE_BRIDGE_REWRITE_E)) {
        status = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "FID[0x%08x] has unsupported type[%s]. \n", fid, sx_fm_fid_type_str(fid_type));
        goto out;
    }

    status = sdk_tunnel_impl_mapping_get_by_fid(attr_p->tunnel_id, fid, &tunnel_map_entry);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to get mapping for tunnel[0x%08x], fid[0x%08x].\n",
               fid, attr_p->tunnel_id);
        goto out;
    }

    status = sdk_tunnel_impl_fid_counter_get(attr_p->tunnel_id,
                                             fid,
                                             attr_p->type,
                                             &old_counter_id);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get counter bound to tunnel[0x%08x], fid[0x%08x], err = %s\n",
                   attr_p->tunnel_id, fid,
                   sx_status_str(status));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        status = flow_counter_is_exists(counter_id);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("counter id %u is INVALID\n", counter_id);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (old_counter_id != SX_FLOW_COUNTER_ID_INVALID) {
            SX_LOG_ERR("Counter already bound\n");
            status = SX_STATUS_ENTRY_ALREADY_BOUND;
            goto out;
        }
        break;

    case SX_ACCESS_CMD_UNBIND:
        if (old_counter_id == SX_FLOW_COUNTER_ID_INVALID) {
            SX_LOG_ERR("Counter in not configured.\n");
            status = SX_STATUS_ENTRY_NOT_BOUND;
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("cmd unsupported (%s).\n", sx_access_cmd_str(cmd));
        status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    switch (attr_p->type) {
    case SX_BRIDGE_COUNTER_TUNNEL_DECAP_E:
        status = __sdk_bridge_hw_rif_by_fid_get(fid, &v_rif, &hwd_rif_id);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to get HW RIF ID by FID [%u], error: %s\n",
                       fid, sx_status_str(status));
            goto out;
        }

        if (cmd == SX_ACCESS_CMD_UNBIND) {
            counter_hw_type = SXD_COUNTER_SET_TYPE_NO_COUNT;
            counter_hw_index = 0;
        } else { /* bind */
            status = flow_counter_lock(counter_id, NULL, &counter_hw_type, &counter_hw_index);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to lock counter, counter_id %u [%s]\n",
                           counter_id, sx_status_str(status));
                goto out;
            }
            counter_locked = TRUE;
        }

        status = sdk_fid_manager_tunnel_decap_mapping_set(SX_ACCESS_CMD_EDIT,
                                                          fid, tunnel_map_entry.params.nve.vni,
                                                          counter_hw_type, counter_hw_index,
                                                          v_rif, hwd_rif_id);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to HW set(%s) decap counter for fid (%u), err = %s\n",
                       sx_access_cmd_str(cmd), fid, sx_status_str(status));
            goto out;
        }
        decap_hw_rb = TRUE;

        if (counter_locked == TRUE) {
            counter_locked = FALSE;
            status = flow_counter_unlock(counter_id);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to unlock counter, counter_id %u [%s]\n",
                           counter_id, sx_status_str(status));
                goto out;
            }
        }
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E:
        status = __sdk_fdb_uc_check_fid_tunnel_entries(fid, attr_p->tunnel_id);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set cmd (%s) encap_uc counter for tunnel[0x%08x], fid[0x%08x]), err = %s\n",
                       sx_access_cmd_str(cmd), attr_p->tunnel_id, fid, sx_status_str(status));
            goto out;
        }
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E:
        status = __sdk_fdb_mc_check_fid_tunnel_entries(fid);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set cmd (%s) encap_mc counter for fid[0x%08x], err = %s\n",
                       sx_access_cmd_str(cmd), fid, sx_status_str(status));
            goto out;
        }
        break;

    default:
        goto out;
        break;
    }

    status = sdk_tunnel_impl_fid_counter_set(cmd,
                                             attr_p->tunnel_id,
                                             fid,
                                             attr_p->type,
                                             counter_id);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set counter for tunnel[0x%08x], fid[0x%08x], err = %s\n",
                   attr_p->tunnel_id, fid, sx_status_str(status));
        goto out;
    }

    set_db_rb = TRUE;

    if (cmd == SX_ACCESS_CMD_BIND) {
        status = flow_counter_ref_inc(counter_id);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed increment reference for counter(%u), err = %s\n", counter_id, sx_status_str(status));
            goto out;
        }
    } else if (cmd == SX_ACCESS_CMD_UNBIND) {
        status = flow_counter_ref_dec(counter_id);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed decrement reference for counter(%u), err = %s\n", counter_id, sx_status_str(status));
            goto out;
        }
    }

out:
    if (status != SX_STATUS_SUCCESS) {
        if (decap_hw_rb) {
            if (cmd == SX_ACCESS_CMD_UNBIND) {
                rb_status = flow_counter_lock(old_counter_id, NULL, &counter_hw_type, &counter_hw_index);
                if (SX_CHECK_FAIL(rb_status)) {
                    SX_LOG_ERR("Failed to lock old counter, counter_id %u [%s]\n",
                               old_counter_id, sx_status_str(rb_status));
                }

                if (rb_status == SX_STATUS_SUCCESS) {
                    rb_status = sdk_fid_manager_tunnel_decap_mapping_set(SX_ACCESS_CMD_EDIT,
                                                                         fid, tunnel_map_entry.params.nve.vni,
                                                                         counter_hw_type, counter_hw_index,
                                                                         v_rif, hwd_rif_id);
                    if (rb_status != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Failed to rollback HW set decap counter for fid (%u), err = %s\n",
                                   fid, sx_status_str(rb_status));
                    }
                }

                if (rb_status == SX_STATUS_SUCCESS) {
                    rb_status = flow_counter_unlock(old_counter_id);
                    if (SX_CHECK_FAIL(rb_status)) {
                        SX_LOG_ERR("Failed to unlock old counter, counter_id %u [%s]\n",
                                   old_counter_id, sx_status_str(rb_status));
                    }
                }
            } else if (cmd == SX_ACCESS_CMD_BIND) {
                /* unbind */
                counter_hw_type = SXD_COUNTER_SET_TYPE_NO_COUNT;
                counter_hw_index = 0;
                rb_status = sdk_fid_manager_tunnel_decap_mapping_set(SX_ACCESS_CMD_EDIT,
                                                                     fid, tunnel_map_entry.params.nve.vni,
                                                                     counter_hw_type, counter_hw_index,
                                                                     v_rif, hwd_rif_id);
                if (rb_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to rollback HW set decap counter for fid (%u), err = %s\n",
                               fid, sx_status_str(rb_status));
                }
            }
        }

        if (counter_locked) {
            rb_status = flow_counter_unlock(counter_id);
            if (SX_CHECK_FAIL(rb_status)) {
                SX_LOG_ERR("Failed to unlock counter, ID %u [%s]\n",
                           counter_id, sx_status_str(rb_status));
            }
        }

        if (set_db_rb) {
            if (cmd == SX_ACCESS_CMD_UNBIND) {
                rb_status = sdk_tunnel_impl_fid_counter_set(SX_ACCESS_CMD_BIND,
                                                            attr_p->tunnel_id,
                                                            fid,
                                                            attr_p->type,
                                                            old_counter_id);
                if (rb_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to rollback set counter for tunnel[0x%08x], fid[0x%08x], err = %s\n",
                               attr_p->tunnel_id, fid, sx_status_str(rb_status));
                }
            } else if (cmd == SX_ACCESS_CMD_BIND) {
                rb_status = sdk_tunnel_impl_fid_counter_set(SX_ACCESS_CMD_UNBIND,
                                                            attr_p->tunnel_id,
                                                            fid,
                                                            attr_p->type,
                                                            old_counter_id);
                if (rb_status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to rollback set counter for tunnel[0x%08x], fid[0x%08x], err = %s\n",
                               attr_p->tunnel_id, fid, sx_status_str(rb_status));
                }
            }
        }
    }
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_tunnel_counter_bind_get(const sx_fid_t                         fid,
                                               const sx_bridge_tunnel_counter_attr_t *attr_p,
                                               sx_flow_counter_id_t                  *counter_id_p)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    sx_fm_fid_type_t      fid_type = SX_FM_FID_TYPE_INVALID;
    sx_tunnel_map_entry_t tunnel_map_entry;

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_map_entry);

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (utils_check_pointer(attr_p, "attr_p")) {
        status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(counter_id_p, "counter_id_p")) {
        status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (attr_p->type) {
    case SX_BRIDGE_COUNTER_TUNNEL_DECAP_E:
        status = sdk_tunnel_impl_capability_check(attr_p->tunnel_id, SX_TUNNEL_CAP_BRIDGE_DECAP_COUNTER_E);
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_UC_E:
        status = sdk_tunnel_impl_capability_check(attr_p->tunnel_id, SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E);
        break;

    case SX_BRIDGE_COUNTER_TUNNEL_ENCAP_MC_E:
        status = sdk_tunnel_impl_capability_check(attr_p->tunnel_id, SX_TUNNEL_CAP_BRIDGE_ENCAP_COUNTER_E);
        break;

    default:
        SX_LOG_ERR("invalid counter type\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Wrong type or direction for tunnel %d, err = %s\n",
                   attr_p->tunnel_id, sx_status_str(status));
        goto out;
    }

    status = sdk_fid_manager_get_fid_type(fid, &fid_type);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find fid[0x%08x] in the FID manager.\n", fid);
        goto out;
    }

    if ((fid_type != SX_FM_FID_TYPE_VLAN_REWRITE_E) &&
        (fid_type != SX_FM_FID_TYPE_BRIDGE_REWRITE_E)) {
        status = SX_STATUS_PARAM_ERROR;
        SX_LOG(SX_LOG_ERROR, "FID[0x%08x] has unsupported type[%s]. \n", fid, sx_fm_fid_type_str(fid_type));
        goto out;
    }

    status = sdk_tunnel_impl_mapping_get_by_fid(attr_p->tunnel_id, fid, &tunnel_map_entry);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Failed to get mapping for tunnel[0x%08x], fid[0x%08x].\n",
               fid, attr_p->tunnel_id);
        goto out;
    }

    status = sdk_tunnel_impl_fid_counter_get(attr_p->tunnel_id,
                                             fid,
                                             attr_p->type,
                                             counter_id_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get counter bound to tunnel[0x%08x], fid[0x%08x], err = %s\n",
                   attr_p->tunnel_id, fid,
                   sx_status_str(status));
        goto out;
    }

    if (*counter_id_p == SX_FLOW_COUNTER_ID_INVALID) {
        status = SX_STATUS_ENTRY_NOT_BOUND;
        SX_LOG_ERR("Counter not bound to tunnel[0x%08x], fid[0x%08x]s\n",
                   attr_p->tunnel_id, fid);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_ref_cnt_increase(sx_bridge_id_t bridge_id)
{
    sx_status_t   status = SX_STATUS_SUCCESS;
    sdk_bridge_t *bridge_item = NULL;

    SX_LOG_ENTER();
    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    status = __sdk_bridge_db_get_bridge(bridge_id, &bridge_item);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find bridge_id(%d) in sdk_bridge_db.\n", bridge_id);
        goto out;
    }

    bridge_item->bridge_ref_count++;

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_ref_cnt_decrease(sx_bridge_id_t bridge_id)
{
    sx_status_t   status = SX_STATUS_SUCCESS;
    sdk_bridge_t *bridge_item = NULL;

    SX_LOG_ENTER();

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    status = __sdk_bridge_db_get_bridge(bridge_id, &bridge_item);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find bridge_id(%d) in sdk_bridge_db.\n", bridge_id);
        goto out;
    }

    if (bridge_item->bridge_ref_count == 0) {
        SX_LOG_DBG("bridge %d) ref count is already zero.\n", bridge_id);
        goto out;
    }

    bridge_item->bridge_ref_count--;

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_vport_fid_get(sx_port_log_id_t log_port, sx_fid_t *fid)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_bridge_virtual_port_t *virtual_port_p;
    boolean_t                  is_sync_fence_needed = FALSE;

    SX_LOG_ENTER();

    if (bridge_init_mode == SX_MODE_802_1Q) {
        SX_LOG_ERR("Bridge mode is 802.1Q.\n");
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (fid == NULL) {
        SX_LOG_ERR("fid parameter is NULL.\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    status = __sdk_bridge_db_get_virtual_port(&virtual_port_p, log_port, &is_sync_fence_needed);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_DEBUG, "Could not find vport(%d) in sdk_bridge_db.\n", log_port);
        goto out;
    }

    /*fid == bridge_id*/
    *fid = virtual_port_p->bridge_id;
out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_is_vport_in_bridge(sx_bridge_id_t *bridge_id, sx_port_log_id_t log_port)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_bridge_virtual_port_t *virtual_port_p;
    boolean_t                  is_sync_fence_needed = FALSE;


    SX_LOG_ENTER();

    if (NULL == bridge_id) {
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == sdk_bridge_db_p) {
        /*Bridge module has not been initialized but we need to return NOT FOUND here */
        status = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_DBG("bridge_id %u does not exist. bridge module not initialized.\n", *bridge_id);
        goto out;
    }

    if (IS_VPORT_OR_VLAG(log_port) == FALSE) {
        SX_LOG_DBG("port (0x%8x) is not a vport.\n", log_port);
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    status = __sdk_bridge_db_get_virtual_port(&virtual_port_p, log_port, &is_sync_fence_needed);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Could not find vport(%d) in sdk_bridge_db.\n", log_port);
        goto out;
    }

    if ((virtual_port_p->bridge_id != *bridge_id) && (SX_BRIDGE_ID_INVALID != *bridge_id)) {
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (SX_BRIDGE_ID_INVALID == *bridge_id) {
        *bridge_id = virtual_port_p->bridge_id;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_is_sync_fence_needed(sx_bridge_id_t  *bridge_id,
                                            sx_port_log_id_t log_port,
                                            boolean_t       *is_sync_fence_needed)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_bridge_virtual_port_t *virtual_port_p;

    SX_LOG_ENTER();

    if (NULL == bridge_id) {
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == sdk_bridge_db_p) {
        status = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        goto out;
    }

    if (IS_VPORT_OR_VLAG(log_port) == FALSE) {
        SX_LOG_DBG("port (0x%8x) is not a vport.\n", log_port);
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    status = __sdk_bridge_db_get_virtual_port(&virtual_port_p, log_port, is_sync_fence_needed);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_DBG("Could not find vport(%d) in sdk_bridge_db.\n", log_port);
        goto out;
    }

    if ((virtual_port_p->bridge_id != *bridge_id) && (SX_BRIDGE_ID_INVALID != *bridge_id)) {
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    if (SX_BRIDGE_ID_INVALID == *bridge_id) {
        *bridge_id = virtual_port_p->bridge_id;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_remove_vport_from_gc_queue(sx_port_log_id_t log_port)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sx_utils_status_t          utils_status = SX_UTILS_STATUS_SUCCESS;
    sx_port_info_t             port_info;
    void                     * tmp = NULL;
    sdk_bridge_context_item_t* data = NULL;

    SX_LOG_ENTER();

    SX_MEM_CLR(port_info);

    status = port_db_info_get(log_port, &port_info);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", log_port);
        goto out;
    }


    utils_status = gc_context_get(port_info.gc_handle, &tmp);
    data = (sdk_bridge_context_item_t*)tmp;
    status = sx_utils_status_to_sx_status(utils_status);
    if (SX_UTILS_CHECK_FAIL(utils_status)) {
        SX_LOG_ERR("Failed to call gc_return_context_to_user\n");
        goto out;
    }

    utils_status = gc_object_remove(port_info.gc_handle);
    status = sx_utils_status_to_sx_status(utils_status);
    if (SX_UTILS_CHECK_FAIL(utils_status)) {
        SX_LOG_ERR("Failed to process GC queue for object type PORT\n");
        goto out;
    }

    status = __sdk_bridge_return_vport_to_db(data);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed in __sdk_bridge_return_vport_to_db (%s)\n", sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}


sx_status_t sdk_bridge_port_vport_get(sx_bridge_id_t bridge_id, sx_port_log_id_t port, sx_port_log_id_t *virtual_port)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_bridge_t              *bridge_item_p = NULL;
    sdk_bridge_virtual_port_t *vport = NULL;
    cl_map_item_t             *vport_map_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    sx_port_info_t             port_info;


    SX_LOG_ENTER();

    SX_MEM_CLR(port_info);

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    if (virtual_port == NULL) {
        SX_LOG_ERR("virtual_port parameter is NULL.\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    status = __sdk_bridge_db_get_bridge(bridge_id, &bridge_item_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not find bridge_id(%d) in sdk_bridge_db.\n", bridge_id);
        goto out;
    }

    vport_map_item = cl_qmap_get(&(bridge_item_p->bridge_virtual_port_map), BRIDGE_VPORT_KEY(port));
    vport_map_end = cl_qmap_end(&(bridge_item_p->bridge_virtual_port_map));

    if (vport_map_item == vport_map_end) {
        SX_LOG(SX_LOG_DEBUG, "Could not find port(0x%8x) in bridge_id(%d) .\n", port, bridge_id);
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);
    status = port_db_info_get(vport->log_port, &port_info);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", vport->log_port);
        goto out;
    }
    if (port_info.gc_handle != NULL) {
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    *virtual_port = vport->log_port;

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_redirect_lag_validate(sx_port_log_id_t lag_port_log_id,
                                             sx_port_log_id_t redirect_lag_port_log_id)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    cl_map_item_t             *lag_item = NULL;
    const cl_map_item_t       *lag_end = NULL;
    sdk_lag_vport_id_t        *lag_vport = NULL;
    cl_map_item_t             *vport_item = NULL;
    const cl_map_item_t       *vport_end = NULL;
    sdk_bridge_virtual_port_t *virtual_port = NULL;
    sdk_bridge_t              *bridge_item_p = NULL;

    SX_LOG_ENTER();

    if (bridge_init_mode == SX_MODE_802_1Q) {
        SX_LOG_DBG("Bridge mode is 802.1Q, no need to validate lag redirect for 802.1D\n");
        goto out;
    }

    if (NULL == sdk_bridge_db_p) {
        status = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("sdk_bridge_db is NULL.\n");
        goto out;
    }

    /* Get lag object */
    lag_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_lag_map));
    lag_item = cl_qmap_get(&(sdk_bridge_db_p->bridge_lag_map), SX_PORT_LAG_ID_GET(lag_port_log_id));

    if (lag_item == lag_end) {
        SX_LOG_DBG("No vport on lag 0x%08X info .\n", lag_port_log_id);
        goto out;
    }

    lag_vport = PARENT_STRUCT(lag_item, sdk_lag_vport_id_t, map_item);

    vport_end = cl_qmap_end(&(lag_vport->vport_map));
    vport_item = cl_qmap_head(&(lag_vport->vport_map));

    while (vport_item != vport_end) {
        virtual_port = PARENT_STRUCT(vport_item, sdk_bridge_virtual_port_t, map_lag_item);

        status = __sdk_bridge_db_get_bridge(virtual_port->bridge_id, &bridge_item_p);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Can't Retrieve bridge (%u) .\n", virtual_port->bridge_id);
            goto out;
        }

        if (bridge_item_p->is_homogeneous == FALSE) {
            SX_LOG_ERR("Bridge (%u) is not homogeneous\n", bridge_item_p->bridge_id);
            status = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        /* Verify redirect lag exists on the bridge */
        if (cl_qmap_get(&(bridge_item_p->bridge_virtual_port_map), BRIDGE_VPORT_KEY(redirect_lag_port_log_id)) ==
            cl_qmap_end(&(bridge_item_p->bridge_virtual_port_map))) {
            SX_LOG_ERR("Redirect lag (0x%08X) is not is not in the same bridge (%u) as lag(0x%08X)\n",
                       redirect_lag_port_log_id, bridge_item_p->bridge_id, lag_port_log_id);
            status = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        vport_item = cl_qmap_next(vport_item);
    }
out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_redirect_lag_set(sx_access_cmd_t access_cmd, sx_port_log_id_t lag_port)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    cl_map_item_t             *lag_item = NULL;
    const cl_map_item_t       *lag_end = NULL;
    sdk_lag_vport_id_t        *lag_vport = NULL;
    cl_map_item_t             *vport_item = NULL;
    const cl_map_item_t       *vport_end = NULL;
    sdk_bridge_virtual_port_t *virtual_port;
    sdk_bridge_t              *bridge_item_p = NULL;

    SX_LOG_ENTER();

    if (bridge_init_mode == SX_MODE_802_1Q) {
        SX_LOG_DBG("Bridge mode is 802.1Q, no need to update lag redirect for 802.1D\n");
        goto out;
    }

    if (NULL == sdk_bridge_db_p) {
        status = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("sdk_bridge_db is NULL.\n");
        goto out;
    }

    if ((access_cmd != SX_ACCESS_CMD_CREATE) &&
        (access_cmd != SX_ACCESS_CMD_DESTROY)) {
        status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported command.\n");
        goto out;
    }

    /* Get lag object */
    lag_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_lag_map));
    lag_item = cl_qmap_get(&(sdk_bridge_db_p->bridge_lag_map), SX_PORT_LAG_ID_GET(lag_port));

    if (lag_item == lag_end) {
        SX_LOG_DBG("No vport on lag 0x%08X info .\n", lag_port);
        goto out;
    }

    lag_vport = PARENT_STRUCT(lag_item, sdk_lag_vport_id_t, map_item);

    vport_end = cl_qmap_end(&(lag_vport->vport_map));
    vport_item = cl_qmap_head(&(lag_vport->vport_map));

    while (vport_item != vport_end) {
        virtual_port = PARENT_STRUCT(vport_item, sdk_bridge_virtual_port_t, map_lag_item);
        status = __sdk_bridge_db_get_bridge(virtual_port->bridge_id, &bridge_item_p);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Can't Retrieve bridge (%u) .\n", virtual_port->bridge_id);
            goto out;
        }

        if (access_cmd == SX_ACCESS_CMD_CREATE) {
            bridge_item_p->redirect_count++;
        } else if (access_cmd == SX_ACCESS_CMD_DESTROY) {
            if (bridge_item_p->redirect_count) {
                bridge_item_p->redirect_count--;
            }
        }

        vport_item = cl_qmap_next(vport_item);
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_db_init()
{
    sx_status_t status = SX_STATUS_SUCCESS;
    cl_status_t cl_err = CL_SUCCESS;

    SX_LOG_ENTER();

    /* Parameter check */
    sdk_global_bridge_id_max = sdk_bridge_db_p->max_bridge_num + MIN_BRIDGE_ID;

    /* Bridge pool and map initialization */
    cl_err = CL_QPOOL_INIT(&(sdk_bridge_db_p->bridge_pool),
                           sdk_bridge_db_p->max_bridge_num,
                           sdk_bridge_db_p->max_bridge_num, 0,
                           sizeof(sdk_bridge_t),
                           NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Bridge pool init Failure. Error: (%s).\n", CL_STATUS_MSG(cl_err));
        status = SX_STATUS_ERROR;
        goto out;
    }

    cl_qmap_init(&sdk_bridge_db_p->bridge_map);

    /* Bridge virtual_ports pool and map initialization */
    cl_err = CL_QPOOL_INIT(&(sdk_bridge_db_p->bridge_virtual_port_pool),
                           rm_resource_global.port_system_port_modules_max, CL_POOL_UNLIMITED_MAX_SIZE,
                           rm_resource_global.port_system_port_modules_max,
                           sizeof(sdk_bridge_virtual_port_t), NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Bridge virtual port pool init Failure. Error: (%s).\n", CL_STATUS_MSG(cl_err));
        status = SX_STATUS_ERROR;
        goto err_virtual_pool_init;
    }

    cl_qmap_init(&(sdk_bridge_db_p->bridge_virtual_port_map));

    /* Bridge lag pool and map initialization */
    cl_err = CL_QPOOL_INIT(&(sdk_bridge_db_p->bridge_lag_pool),
                           rm_resource_global.lag_num_max,
                           rm_resource_global.lag_num_max, 0,
                           sizeof(sdk_lag_vport_id_t), NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Bridge lag pool init Failure. Error: (%s).\n", CL_STATUS_MSG(cl_err));
        status = SX_STATUS_ERROR;
        goto err_lag_pool_init;
    }

    cl_qmap_init(&(sdk_bridge_db_p->bridge_lag_map));

    cl_err = CL_QPOOL_INIT(&(sdk_bridge_db_p->bridge_context_item_pool),
                           VPORT_CONTEXT_MIN_CNT,
                           CL_POOL_UNLIMITED_MAX_SIZE,
                           VPORT_CONTEXT_MIN_CNT,
                           sizeof(sdk_bridge_context_item_t),
                           NULL, NULL, NULL);
    if (cl_err != CL_SUCCESS) {
        SX_LOG_ERR("Bridge context item pool init failure. Error: (%s).\n", CL_STATUS_MSG(cl_err));
        status = SX_STATUS_ERROR;
        goto err_context_item_pool_init;
    }

    sx_utils_status_t utils_err = SX_UTILS_STATUS_ERROR;

    /* MIN_BRIDGE_ID is used by MCDB_EXT_MIDS_VID, we start offset from 1 then */
    utils_err = id_allocator_init(sdk_bridge_db_p->max_bridge_num,
                                  sdk_bridge_db_p->max_bridge_num,
                                  1,
                                  &sdk_bridge_db_p->bridge_id_allocator);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        status = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to init id allocator.\n");
        goto err_id_allocator_init;
    }

    goto out;
err_id_allocator_init:
    id_allocator_destroy(&sdk_bridge_db_p->bridge_id_allocator);
err_context_item_pool_init:
    CL_QPOOL_DESTROY(&(sdk_bridge_db_p->bridge_lag_pool));
err_lag_pool_init:
    CL_QPOOL_DESTROY(&(sdk_bridge_db_p->bridge_virtual_port_pool));
err_virtual_pool_init:
    CL_QPOOL_DESTROY(&(sdk_bridge_db_p->bridge_pool));
out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_db_clear_all_bridges()
{
    cl_map_item_t             *bridge_map_item = NULL;
    const cl_map_item_t       *bridge_map_end = NULL;
    cl_map_item_t             *vport_map_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    sdk_bridge_t              *bridge_item = NULL;
    sdk_bridge_virtual_port_t *vport = NULL;
    cl_map_item_t             *lag_item = NULL;
    const cl_map_item_t       *lag_end = NULL;
    sdk_lag_vport_id_t        *lag_vport = NULL;

    /* For every lag in the bridge_lag_map clear all vport_map */
    lag_item = cl_qmap_head(&(sdk_bridge_db_p->bridge_lag_map));
    lag_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_lag_map));

    while (lag_item != lag_end) {
        lag_vport = PARENT_STRUCT(lag_item, sdk_lag_vport_id_t, map_item);

        cl_qmap_remove_all(&(lag_vport->vport_map));

        /* Clear bridge_lag_map */
        cl_qmap_remove(&(sdk_bridge_db_p->bridge_lag_map), lag_vport->lag_id);
        cl_qpool_put(&(sdk_bridge_db_p->bridge_lag_pool), &(lag_vport->pool_item));

        lag_item = cl_qmap_head(&(sdk_bridge_db_p->bridge_lag_map));
    }

    /* For every bridge in bridge_map, clear bridge_virtual_port_map  */
    bridge_map_item = cl_qmap_head(&(sdk_bridge_db_p->bridge_map));
    bridge_map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_map));

    while (bridge_map_item != bridge_map_end) {
        bridge_item = PARENT_STRUCT(bridge_map_item, sdk_bridge_t, map_item);

        cl_qmap_remove_all(&(bridge_item->bridge_virtual_port_map));

        /* Clear bridge_map */
        cl_qmap_remove(&(sdk_bridge_db_p->bridge_map), bridge_item->bridge_id);
        cl_qpool_put(&(sdk_bridge_db_p->bridge_pool), &(bridge_item->pool_item));

        bridge_map_item = cl_qmap_head(&(sdk_bridge_db_p->bridge_map));
    }

    /* Clear bridge_virtual_port_map */
    vport_map_item = cl_qmap_head(&(sdk_bridge_db_p->bridge_virtual_port_map));
    vport_map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_virtual_port_map));

    while (vport_map_item != vport_map_end) {
        vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_item);
        cl_qmap_remove(&(sdk_bridge_db_p->bridge_virtual_port_map), vport->log_port);
        cl_qpool_put(&(sdk_bridge_db_p->bridge_virtual_port_pool), &(vport->pool_item));

        vport_map_item = cl_qmap_head(&(sdk_bridge_db_p->bridge_virtual_port_map));
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __sdk_bridge_db_deinit()
{
    SX_LOG_ENTER();

    CL_QPOOL_DESTROY(&(sdk_bridge_db_p->bridge_pool));

    CL_QPOOL_DESTROY(&(sdk_bridge_db_p->bridge_virtual_port_pool));

    CL_QPOOL_DESTROY(&(sdk_bridge_db_p->bridge_lag_pool));

    CL_QPOOL_DESTROY(&(sdk_bridge_db_p->bridge_context_item_pool));

    id_allocator_destroy(&sdk_bridge_db_p->bridge_id_allocator);

    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}

static sx_status_t __sdk_bridge_db_alloc_bridge_id(sx_bridge_id_t *bridge_id_p)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_ERROR;
    uint32_t          id = 0;

    utils_err = id_allocator_get(&sdk_bridge_db_p->bridge_id_allocator, &id);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to init id allocator.\n");
        goto out;
    }

    *bridge_id_p = MIN_BRIDGE_ID + id;

out:
    return err;
}

static sx_status_t __sdk_bridge_db_free_bridge_id(sx_bridge_id_t bridge_id)
{
    sx_status_t       err = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_err = SX_UTILS_STATUS_ERROR;
    uint32_t          id = bridge_id - MIN_BRIDGE_ID;

    utils_err = id_allocator_put(&sdk_bridge_db_p->bridge_id_allocator, id);
    if (SX_UTILS_CHECK_FAIL(utils_err)) {
        err = sx_utils_status_to_sx_status(utils_err);
        SX_LOG_ERR("Failed to init id allocator.\n");
        goto out;
    }

out:
    return err;
}

static sx_status_t __sdk_bridge_db_alloc_bridge(sdk_bridge_t **bridge_item)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    cl_pool_item_t *pool_item = NULL;

    SX_LOG_ENTER();

    pool_item = cl_qpool_get(&sdk_bridge_db_p->bridge_pool);
    if (pool_item == NULL) {
        SX_LOG(SX_LOG_ERROR, "Could not find free bridge entry in sdk_bridge_db.\n");
        err = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    *bridge_item = PARENT_STRUCT(pool_item, sdk_bridge_t, pool_item);
    bridge_item[0]->bridge_ref_count = 0;
    bridge_item[0]->bridge_ingress_mirror_mode = SX_MIRROR_MODE_DISABLED;
    bridge_item[0]->bridge_flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;
    bridge_item[0]->is_homogeneous = TRUE;
    bridge_item[0]->homogeneous_vlan = INVALID_VID;
    bridge_item[0]->redirect_count = 0;
    err = __sdk_bridge_db_alloc_bridge_id(&bridge_item[0]->bridge_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to allocate bridge id.\n");
        goto out;
    }

    cl_qmap_init(&(bridge_item[0]->bridge_virtual_port_map));

    cl_qmap_insert(&(sdk_bridge_db_p->bridge_map), bridge_item[0]->bridge_id, &(bridge_item[0]->map_item));

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_bridge_db_free_bridge(sdk_bridge_t *bridge_item)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Return bridge entry to DB */
    if (cl_qmap_count(&(bridge_item->bridge_virtual_port_map)) != 0) {
        SX_LOG(SX_LOG_ERROR, "Attempting to free bridge entry with active virtual ports.\n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    err = __sdk_bridge_db_free_bridge_id(bridge_item->bridge_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to free bridge id.\n");
        goto out;
    }
    cl_qmap_remove(&(sdk_bridge_db_p->bridge_map), bridge_item->bridge_id);
    cl_qpool_put(&(sdk_bridge_db_p->bridge_pool), &(bridge_item->pool_item));
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_bridge_db_get_bridge(sx_bridge_id_t bridge_id, sdk_bridge_t **bridge_item)
{
    sx_status_t          status = SX_STATUS_SUCCESS;
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *map_end = NULL;

    SX_LOG_ENTER();

    map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_map));
    map_item = cl_qmap_get(&(sdk_bridge_db_p->bridge_map), bridge_id);

    if (map_item == map_end) {
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *bridge_item = PARENT_STRUCT(map_item, sdk_bridge_t, map_item);

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_db_verify_empty_bridge(sdk_bridge_t *bridge_item)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sx_utils_status_t          utils_status = SX_UTILS_STATUS_SUCCESS;
    cl_map_item_t             *vport_map_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    sdk_bridge_virtual_port_t *vport = NULL;
    sx_port_info_t             port_info;
    boolean_t                  is_sync_fence_needed = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(port_info);

    vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
    vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));
    while (vport_map_item != vport_map_end) {
        vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);
        status = port_db_info_get(vport->log_port, &port_info);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", vport->log_port);
            goto out;
        }
        if (port_info.gc_handle == NULL) {
            status = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        } else {
            is_sync_fence_needed = TRUE;
        }
        vport_map_item = cl_qmap_next(vport_map_item);
    }

    if (bridge_item->bridge_ref_count != 0) {
        SX_LOG(SX_LOG_ERROR,
               "bridge (%d) ref count is (%d).\n",
               bridge_item->bridge_id,
               bridge_item->bridge_ref_count);
        status = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* We have items in the gc_queue - in this case we'll do a sync fence*/
    if (TRUE == is_sync_fence_needed) {
        utils_status = gc_object_fence(GC_FENCE_TYPE_SLOW);
        status = sx_utils_status_to_sx_status(utils_status);
        if (SX_UTILS_CHECK_FAIL(utils_status)) {
            SX_LOG_ERR("Failed to process GC queue for object type PORT\n");
            goto out;
        }
    } else {
        goto out;
    }
    vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
    while (vport_map_item != vport_map_end) {
        vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);
        vport_map_item = cl_qmap_next(vport_map_item);

        status = sdk_bridge_remove_vport_from_gc_queue(vport->log_port);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed in sdk_bridge_remove_vport_from_gc_queue\n");
            goto out;
        }

        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to set gc_handle for vport 0x%08X . status = %s\n", vport->log_port,
                       sx_status_str(status));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}


static sx_status_t __sdk_bridge_port_set_validate(sx_access_cmd_t     cmd,
                                                  const sdk_bridge_t *bridge_item,
                                                  sx_port_log_id_t    log_port,
                                                  sx_port_info_t     *port_info_p)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sx_utils_status_t          utils_status = SX_UTILS_STATUS_SUCCESS;
    cl_map_item_t             *map_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    sdk_bridge_virtual_port_t *vport;
    sx_port_info_t             vport_port_info;
    boolean_t                  first_fence = TRUE;

    SX_LOG_ENTER();

    /* Validate Port */
    VALIDATE_PORT(__sdk_bridge_port_set_validate, log_port);

    /* Verify vport exists */
    status = port_db_info_get(log_port, port_info_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", log_port);
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_ADD) {
        status = adviser_process_event(ADVISER_EVENT_PRE_VPORT_BRIDGE_ADD_E, &(log_port));
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_DBG("Could not process pre vport bridge add event '%s'.\n",
                       ADVISER_EVENT_STR(ADVISER_EVENT_PRE_VPORT_BRIDGE_ADD_E));
            goto out;
        }

        /*check that vport is not on rif*/
        status = port_db_check_port_mode_router_port(log_port);
        if (status != SX_STATUS_PARAM_ERROR) {
            if (status == SX_STATUS_SUCCESS) {
                SX_LOG_DBG("vport (0x%x) is bound to router interface and can't be bound to bridge.\n", log_port);
            } else {
                SX_LOG_ERR("port_db_check_port_mode_router_port failed - (%s) vport (0x%x) .\n", sx_status_str(
                               status), log_port);
            }
            status = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
        status = SX_STATUS_SUCCESS;

        /* Verify no counter is bound to the port if a counter is already bound to the bridge */
        if (bridge_item->bridge_flow_counter_id != SX_FLOW_COUNTER_ID_INVALID) {
            if (port_info_p->flow_counter.flow_counter_id != SX_FLOW_COUNTER_ID_INVALID) {
                SX_LOG(SX_LOG_ERROR, "Bridge (%u) is bound to counter (%u), cannot add vport (0x%08X).\n",
                       bridge_item->bridge_id,
                       bridge_item->bridge_flow_counter_id, log_port);
                status = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        /* Verify vport is unique across all bridges */
        map_item = cl_qmap_get(&(sdk_bridge_db_p->bridge_virtual_port_map), log_port);
        vport_map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_virtual_port_map));
        if (map_item != vport_map_end) {
            SX_LOG(SX_LOG_ERROR, "Port(0x%08X)) already added to a bridge.\n", log_port);
            status = SX_STATUS_ENTRY_ALREADY_EXISTS;
            goto out;
        }

        /* Verify no vport from the same physical port exists on the bridge */
        map_item = cl_qmap_get(&(bridge_item->bridge_virtual_port_map), BRIDGE_VPORT_KEY(log_port));
        vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));
        while (map_item != vport_map_end) {
            vport = PARENT_STRUCT(map_item, sdk_bridge_virtual_port_t, map_bridge_item);
            status = port_db_info_get(vport->log_port, &vport_port_info);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", vport->log_port);
                goto out;
            }
            if (vport_port_info.gc_handle) {
                if (first_fence) {
                    utils_status = gc_object_fence(GC_FENCE_TYPE_SLOW);
                    status = sx_utils_status_to_sx_status(utils_status);
                    if (SX_UTILS_CHECK_FAIL(utils_status)) {
                        SX_LOG_ERR("Failed to process GC queue for object type PORT\n");
                        goto out;
                    }
                    first_fence = FALSE;
                }

                status = sdk_bridge_remove_vport_from_gc_queue(vport->log_port);
                if (SX_CHECK_FAIL(status)) {
                    SX_LOG_ERR("Failed in sdk_bridge_remove_vport_from_gc_queue\n");
                    goto out;
                }
            } else {
                SX_LOG(SX_LOG_ERROR, "Physical Port(0x%08X)) already exists on  bridge (%u).\n",
                       BRIDGE_VPORT_KEY(log_port), bridge_item->bridge_id);
                status = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            map_item = cl_qmap_get(&(bridge_item->bridge_virtual_port_map), BRIDGE_VPORT_KEY(log_port));
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_port_delete_validate_igmpv3_state(sx_bridge_id_t   bridge_id,
                                                         sx_port_log_id_t vport,
                                                         boolean_t       *approve_delete_flag)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    uint32_t              vport_count = 0;
    sx_fdb_igmpv3_state_t igmpv3_state;
    sx_fid_t              fid;

    SX_LOG_ENTER();

    /* Check last vPort in Bridge */
    status = sx_bridge_vport_count_get(bridge_id, &vport_count);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to bridge_is_last_vport_get, err = %s\n",
                   sx_status_str(status));
        goto out;
    }

    if (vport_count > 1) {
        *approve_delete_flag = TRUE;
    } else {
        /* parse Vid from vPort */
        fid = SX_PORT_VLAN_ID_GET(vport);

        /* Check if IGMP v3 enabled before deleting the Bridge */
        fdb_igmpv3_fid_snooping_state_get(fid, NULL, &igmpv3_state);
        if (igmpv3_state == SX_FDB_IGMPV3_STATE_ENABLE_E) {
            *approve_delete_flag = FALSE;
        } else {
            *approve_delete_flag = TRUE;
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sx_bridge_vport_count_get(sx_bridge_id_t bridge_id, uint32_t *vport_count)
{
    sx_status_t       status = SX_STATUS_SUCCESS;
    sx_port_log_id_t *bridge_vport_list_p = NULL;
    uint32_t          bridge_vport_cnt = 0;

    SX_LOG_ENTER();

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized.\n");
        status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    status = sdk_bridge_vport_get(bridge_id, NULL, &bridge_vport_cnt);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Fail to sdk_bridge_vport_get(bridge id = %d).\n", bridge_id);
        goto out;
    }

    bridge_vport_list_p = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * bridge_vport_cnt);
    if (!bridge_vport_list_p) {
        status = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed alloc memory for bridge_vport_list_p.\n");
        goto out;
    }

    status = sdk_bridge_vport_get(bridge_id, bridge_vport_list_p, &bridge_vport_cnt);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Fail to sdk_bridge_vport_get(bridge id = %d).\n", bridge_id);
        goto out;
    }

    *vport_count = bridge_vport_cnt;

out:
    if (bridge_vport_list_p != NULL) {
        cl_free(bridge_vport_list_p);
    }
    SX_LOG_EXIT();
    return status;
}


static sx_status_t __sdk_bridge_port_set_validate_redirect(sx_access_cmd_t     cmd,
                                                           const sdk_bridge_t *bridge_item,
                                                           sx_port_log_id_t    log_port)
{
    sx_status_t          status = SX_STATUS_SUCCESS;
    cl_map_item_t       *map_item = NULL;
    const cl_map_item_t *vport_map_end = NULL;
    boolean_t            is_redirected = FALSE;
    sx_port_log_id_t     redirect_lag = 0;
    sx_port_log_id_t     lag_log_port = 0;
    sx_port_log_id_t    *src_lags = NULL;
    uint16_t             src_lags_count = 0;
    uint32_t             i = 0;

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        /* Verify it not break the homogeneous of bridge which has active LAG redirect */
        if ((bridge_item->redirect_count) &&
            (SX_PORT_VLAN_ID_GET(log_port) != bridge_item->homogeneous_vlan)) {
            SX_LOG(SX_LOG_ERROR,
                   "Port(0x%08X)) break the homogeneous of redirect active bridge (%u) with VLAN (%u).\n",
                   log_port,
                   bridge_item->bridge_id,
                   bridge_item->homogeneous_vlan);
            status = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        /* Verify the redirect lag is already in the bridge in case the log_port is redirected lag */
        if (IS_LAG_OR_VLAG(log_port)) {
            SX_PORT_TYPE_ID_SET(lag_log_port, SX_PORT_TYPE_LAG);
            SX_PORT_LAG_ID_SET(lag_log_port, SX_PORT_LAG_ID_GET(log_port));
            status = lag_redirect_get(lag_log_port, &is_redirected, &redirect_lag);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG(SX_LOG_ERROR, "lag_redirect_get failed on Port(0x%08X).\n", log_port);
                goto out;
            }
            if (is_redirected == TRUE) {
                map_item = cl_qmap_get(&(bridge_item->bridge_virtual_port_map), BRIDGE_VPORT_KEY(redirect_lag));
                vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));
                if (map_item == vport_map_end) {
                    SX_LOG(SX_LOG_ERROR, "redirect lag (0x%08X)) not exists on  bridge (%u).\n",
                           redirect_lag, bridge_item->bridge_id);
                    status = SX_STATUS_UNSUPPORTED;
                    goto out;
                }
                if ((bridge_item->is_homogeneous == FALSE) ||
                    (SX_PORT_VLAN_ID_GET(log_port) != bridge_item->homogeneous_vlan)) {
                    SX_LOG(SX_LOG_ERROR,
                           "redirected lag (0x%08X)) cannot be added to non-homogeneous bridge (%u)."
                           "is_homogeneous (%d), homogeneous_vlan (%u), log_port vid (%u)\n",
                           log_port, bridge_item->bridge_id, bridge_item->is_homogeneous,
                           bridge_item->homogeneous_vlan, SX_PORT_VLAN_ID_GET(log_port));
                    status = SX_STATUS_UNSUPPORTED;
                    goto out;
                }
            }
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        /* Verify the redirected lag is not in the same bridge in case the log_port is redirect lag */
        if ((bridge_item->redirect_count) &&
            IS_LAG_OR_VLAG(log_port)) {
            /* Verify if log_port is redirect lag */
            SX_PORT_TYPE_ID_SET(lag_log_port, SX_PORT_TYPE_LAG);
            SX_PORT_LAG_ID_SET(lag_log_port, SX_PORT_LAG_ID_GET(log_port));
            status = lag_redirected_lags_get(lag_log_port, SX_ACCESS_CMD_COUNT, NULL, &src_lags_count);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to get redirected LAGs information.\n");
                goto out;
            }
            if (src_lags_count == 0) {
                goto out;
            }

            src_lags = (sx_port_log_id_t*)cl_malloc(sizeof(sx_port_log_id_t) * src_lags_count);
            if (!src_lags) {
                status = SX_STATUS_NO_MEMORY;
                SX_LOG_ERR("Failed alloc memory for src_lags.\n");
                goto out;
            }

            status = lag_redirected_lags_get(lag_log_port, SX_ACCESS_CMD_GET, src_lags, &src_lags_count);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to get redirected LAGs.\n");
                goto out;
            }

            vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));
            for (i = 0; i < src_lags_count; i++) {
                map_item = cl_qmap_get(&(bridge_item->bridge_virtual_port_map), BRIDGE_VPORT_KEY(src_lags[i]));
                if (map_item != vport_map_end) {
                    SX_LOG(SX_LOG_ERROR, "redirected lag (0x%08X)) exists on  bridge (%u).\n",
                           src_lags[i], bridge_item->bridge_id);
                    status = SX_STATUS_UNSUPPORTED;
                    goto out;
                }
            }
        }
        break;

    default:
        break;
    }

out:
    if (NULL != src_lags) {
        CL_FREE_N_NULL(src_lags);
    }
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_port_set_update_bridge(sx_access_cmd_t  cmd,
                                                       sdk_bridge_t    *bridge_item,
                                                       sx_port_log_id_t log_port)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    cl_map_item_t             *map_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    boolean_t                  is_redirected = FALSE;
    sx_port_log_id_t           redirect_lag = 0;
    sx_port_log_id_t           lag_log_port = 0;
    sdk_bridge_virtual_port_t *virtual_port_p = NULL;
    sx_vlan_id_t               vid = INVALID_VID;

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        if (bridge_item->is_homogeneous == TRUE) {
            if (bridge_item->homogeneous_vlan == INVALID_VID) {
                bridge_item->homogeneous_vlan = SX_PORT_VLAN_ID_GET(log_port);
            } else if (bridge_item->homogeneous_vlan != SX_PORT_VLAN_ID_GET(log_port)) {
                bridge_item->is_homogeneous = FALSE;
            }
        }

        break;

    case SX_ACCESS_CMD_DELETE:
        if (cl_is_qmap_empty(&(bridge_item->bridge_virtual_port_map)) == TRUE) {
            bridge_item->is_homogeneous = TRUE;
            bridge_item->homogeneous_vlan = INVALID_VID;
            bridge_item->redirect_count = 0;
            goto out;
        }

        if (bridge_item->is_homogeneous == FALSE) {
            bridge_item->is_homogeneous = TRUE;
            map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
            vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));
            while (map_item != vport_map_end) {
                virtual_port_p = PARENT_STRUCT(map_item, sdk_bridge_virtual_port_t, map_bridge_item);
                if (vid == INVALID_VID) {
                    vid = SX_PORT_VLAN_ID_GET(virtual_port_p->log_port);
                    bridge_item->homogeneous_vlan = vid;
                } else if (vid != SX_PORT_VLAN_ID_GET(virtual_port_p->log_port)) {
                    bridge_item->is_homogeneous = FALSE;
                    break;
                }

                map_item = cl_qmap_next(map_item);
            }
        }

        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        bridge_item->redirect_count = 0;
        bridge_item->is_homogeneous = TRUE;
        bridge_item->homogeneous_vlan = INVALID_VID;
        goto out;
        break;

    default:
        status = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unexpected cmd\n");
        break;
    }

    if (IS_LAG_OR_VLAG(log_port)) {
        SX_PORT_TYPE_ID_SET(lag_log_port, SX_PORT_TYPE_LAG);
        SX_PORT_LAG_ID_SET(lag_log_port, SX_PORT_LAG_ID_GET(log_port));
        status = lag_redirect_get(lag_log_port, &is_redirected, &redirect_lag);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "lag_redirect_get failed on Port(0x%08X).\n", log_port);
            goto out;
        }
        if (is_redirected == TRUE) {
            if (cmd == SX_ACCESS_CMD_ADD) {
                bridge_item->redirect_count++;
            } else {
                bridge_item->redirect_count--;
            }
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_db_alloc_virtual_port(sx_port_log_id_t log_port,
                                                      sdk_bridge_t    *bridge_item,
                                                      boolean_t       *is_new_lag)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_bridge_virtual_port_t *virtual_port;
    cl_pool_item_t            *pool_item = NULL;
    sdk_lag_vport_id_t        *lag_vport_item = NULL;
    cl_map_item_t             *map_item = NULL;
    const cl_map_item_t       *lag_port_map_end = NULL;

    SX_LOG_ENTER();

    if (is_new_lag) {
        *is_new_lag = FALSE;
    }

    pool_item = cl_qpool_get(&sdk_bridge_db_p->bridge_virtual_port_pool);
    if (pool_item == NULL) {
        SX_LOG(SX_LOG_ERROR, "Could not find free virtual port entry in sdk_bridge_db.\n");
        status = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    virtual_port = PARENT_STRUCT(pool_item, sdk_bridge_virtual_port_t, pool_item);
    virtual_port->log_port = log_port;
    virtual_port->bridge_id = bridge_item->bridge_id;

    cl_qmap_insert(&(sdk_bridge_db_p->bridge_virtual_port_map), log_port, &(virtual_port->map_item));
    cl_qmap_insert(&(bridge_item->bridge_virtual_port_map), BRIDGE_VPORT_KEY(
                       log_port), &(virtual_port->map_bridge_item));

    /* allocate lag_vport_item if it is a new LAG */
    if (IS_LAG_OR_VLAG(log_port)) {
        map_item = cl_qmap_get(&(sdk_bridge_db_p->bridge_lag_map), SX_PORT_LAG_ID_GET(log_port));
        lag_port_map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_lag_map));
        if (map_item == lag_port_map_end) {
            /* Lag is not yet on any bridge, allocate it... */
            if (is_new_lag) {
                *is_new_lag = TRUE;
            }
            pool_item = cl_qpool_get(&sdk_bridge_db_p->bridge_lag_pool);

            if (pool_item == NULL) {
                SX_LOG(SX_LOG_ERROR, "Could not find free lag vport entry in sdk_bridge_db.\n");
                status = SX_STATUS_NO_RESOURCES;

                /* roll back */
                cl_qmap_remove(&(bridge_item->bridge_virtual_port_map), BRIDGE_VPORT_KEY(log_port));
                cl_qmap_remove(&(sdk_bridge_db_p->bridge_virtual_port_map), log_port);
                cl_qpool_put(&(sdk_bridge_db_p->bridge_virtual_port_pool), &(virtual_port->pool_item));
                goto out;
            }

            lag_vport_item = PARENT_STRUCT(pool_item, sdk_lag_vport_id_t, pool_item);

            lag_vport_item->lag_id = SX_PORT_LAG_ID_GET(log_port);
            cl_qmap_init(&(lag_vport_item->vport_map));
            cl_qmap_insert(&(sdk_bridge_db_p->bridge_lag_map), SX_PORT_LAG_ID_GET(log_port),
                           &(lag_vport_item->map_item));
        } else {
            lag_vport_item = PARENT_STRUCT(map_item, sdk_lag_vport_id_t, map_item);
        }

        cl_qmap_insert(&(lag_vport_item->vport_map), log_port, &(virtual_port->map_lag_item));
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_db_free_virtual_port(sx_port_log_id_t log_port,
                                                     sdk_bridge_t    *bridge_item,
                                                     boolean_t       *is_last_vport_lag)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_lag_vport_id_t        *lag_vport_item = NULL;
    cl_map_item_t             *map_item = NULL;
    const cl_map_item_t       *lag_port_map_end = NULL;
    sdk_bridge_virtual_port_t *vport_item;
    cl_map_item_t             *vport_map_item = NULL;
    const cl_map_item_t       *vpot_port_map_end = NULL;

    SX_LOG_ENTER();

    if (is_last_vport_lag) {
        *is_last_vport_lag = FALSE;
    }

    /* remove log_port from lag_vport map */
    if (IS_LAG_OR_VLAG(log_port)) {
        map_item = cl_qmap_get(&(sdk_bridge_db_p->bridge_lag_map), SX_PORT_LAG_ID_GET(log_port));
        lag_port_map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_lag_map));
        if (map_item != lag_port_map_end) {
            /* find vport in lag_vport map */
            lag_vport_item = PARENT_STRUCT(map_item, sdk_lag_vport_id_t, map_item);

            vport_map_item = cl_qmap_get(&(lag_vport_item->vport_map), log_port);
            vpot_port_map_end = cl_qmap_end(&(lag_vport_item->vport_map));

            if (vport_map_item != vpot_port_map_end) {
                cl_qmap_remove(&(lag_vport_item->vport_map), log_port);
            }
            /* If it is last in the map, remove the lag_vport_item and return to the pool*/
            if (cl_is_qmap_empty(&(lag_vport_item->vport_map))) {
                cl_qmap_remove(&(sdk_bridge_db_p->bridge_lag_map), SX_PORT_LAG_ID_GET(log_port));
                cl_qpool_put(&(sdk_bridge_db_p->bridge_lag_pool), &(lag_vport_item->pool_item));
                if (is_last_vport_lag) {
                    *is_last_vport_lag = TRUE;
                }
            }
        }
    }

    /* remove vport from bridge vport map */
    cl_qmap_remove(&(bridge_item->bridge_virtual_port_map), BRIDGE_VPORT_KEY(log_port));

    /* remove vport from DB and return to pool */
    vport_map_item = cl_qmap_get(&(sdk_bridge_db_p->bridge_virtual_port_map), log_port);
    vpot_port_map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_virtual_port_map));
    if (vport_map_item != vpot_port_map_end) {
        vport_item = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_item);
        cl_qmap_remove(&(sdk_bridge_db_p->bridge_virtual_port_map), log_port);
        cl_qpool_put(&(sdk_bridge_db_p->bridge_virtual_port_pool), &(vport_item->pool_item));
    }

    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_lag_port_update(IN sx_port_id_t          lag_port_log_id,
                                                IN lag_sink_event_type_e event_type,
                                                IN sx_port_id_t          port_log_id,
                                                IN void                 *context_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    UNUSED_PARAM(context_p);

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_POST_PORT_ADDED_E:
        /* Should bind the port */
        rc = __sdk_bridge_port_added_to_lag(port_log_id, lag_port_log_id);
        break;

    case LAG_SINK_EVENT_TYPE_LAG_PORT_REMOVED_E:
        /* Should Unbind port  */
        rc = __sdk_bridge_port_removed_from_lag(port_log_id,
                                                lag_port_log_id);
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        rc = SX_STATUS_SUCCESS;
        break;

    case LAG_SINK_EVENT_TYPE_LAG_PRE_PORT_ADDED_VALIDATIONS_E:
        rc = SX_STATUS_SUCCESS;
        break;

    default:
        SX_LOG_ERR("Wrong event type , event type: (%d)\n", event_type);
        return SX_STATUS_CMD_ERROR;
    }
    return rc;
}

static sx_status_t __sdk_bridge_db_get_virtual_port(sdk_bridge_virtual_port_t **virtual_port,
                                                    sx_port_log_id_t            log_port,
                                                    boolean_t                  *is_sync_fence_needed)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    cl_map_item_t             *map_item = NULL;
    const cl_map_item_t       *map_end = NULL;
    sdk_bridge_virtual_port_t *vport = NULL;
    sx_port_info_t             port_info;


    SX_LOG_ENTER();

    SX_MEM_CLR(port_info);

    map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_virtual_port_map));
    map_item = cl_qmap_get(&(sdk_bridge_db_p->bridge_virtual_port_map), log_port);
    if (map_item == map_end) {
        SX_LOG(SX_LOG_DEBUG, "Could not find port(0x%x).\n", log_port);
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    *virtual_port = PARENT_STRUCT(map_item, sdk_bridge_virtual_port_t, map_item);
    vport = PARENT_STRUCT(map_item, sdk_bridge_virtual_port_t, map_item);
    status = port_db_info_get(vport->log_port, &port_info);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", vport->log_port);
        goto out;
    }
    if (port_info.gc_handle != NULL) {
        *is_sync_fence_needed = TRUE;
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_hw_vport_add(sx_port_log_id_t      log_port,
                                             const sdk_bridge_t   *bridge_item,
                                             const sx_port_info_t *port_info_p)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    sx_flow_counter_obj_t tmp_flow_counter;
    boolean_t             v_rif = FALSE;
    hwd_rif_id_t          hw_rif_id = 0;

    SX_LOG_ENTER();

    status = __sdk_bridge_hw_rif_by_fid_get(bridge_item->bridge_id, &v_rif, &hw_rif_id);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to get HW RIF ID by FID [%u], error: %s\n",
                   bridge_item->bridge_id, sx_status_str(status));
        goto out;
    }

    tmp_flow_counter.flow_counter_id = bridge_item->bridge_flow_counter_id;
    tmp_flow_counter.flow_counter_bound_entity = SX_FLOW_COUNTER_BRIDGE_TYPE;
    if (SX_FLOW_COUNTER_ID_INVALID == bridge_item->bridge_flow_counter_id) {
        if (SX_FLOW_COUNTER_ID_INVALID == port_info_p->flow_counter.flow_counter_id) {
            tmp_flow_counter.flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;
            tmp_flow_counter.flow_counter_bound_entity = SX_FLOW_COUNTER_INVALID_TYPE;
        } else {
            tmp_flow_counter.flow_counter_id = port_info_p->flow_counter.flow_counter_id;
            tmp_flow_counter.flow_counter_bound_entity = SX_FLOW_COUNTER_VPORT_TYPE;
        }
    }

    /* Access SVFA via port module */
    status = port_vport_bind_set(log_port,
                                 SX_PORT_VLAN_ID_GET(log_port),
                                 bridge_item->bridge_id,
                                 tmp_flow_counter,
                                 VPORT_BIND_REF_CNT_UPDATE,
                                 port_info_p->mirror,
                                 v_rif, hw_rif_id);

    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "port_vport_bind_set failed, vport(0x%x).\n", log_port);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_hw_counter_bind(sdk_bridge_t *bridge_item, sx_flow_counter_obj_t flow_counter)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_bridge_virtual_port_t *vport = NULL;
    cl_map_item_t             *vport_map_item = NULL;
    cl_map_item_t             *vport_map_rollback_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    sx_flow_counter_obj_t      fail_flow_counter;

    SX_LOG_ENTER();

    fail_flow_counter.flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;
    fail_flow_counter.flow_counter_bound_entity = SX_FLOW_COUNTER_INVALID_TYPE;
    vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
    vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));

    while (vport_map_item != vport_map_end) {
        vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);

        status = __sdk_bridge_hw_vport_counter_update(bridge_item->bridge_id, vport->log_port, flow_counter);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "__sdk_bridge_hw_vport_counter_update failed, vport(0x%x).\n", vport->log_port);
            vport_map_rollback_item = vport_map_item;
            break;
        }

        vport_map_item = cl_qmap_next(vport_map_item);
    }

    /* rollback on failure */
    if (status != SX_STATUS_SUCCESS) {
        vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
        while (vport_map_item != vport_map_rollback_item) {
            vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);

            __sdk_bridge_hw_vport_counter_update(bridge_item->bridge_id, vport->log_port, fail_flow_counter);
            vport_map_item = cl_qmap_next(vport_map_item);
        }
    }

    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_hw_counter_unbind(const sdk_bridge_t *bridge_item)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sdk_bridge_virtual_port_t *vport = NULL;
    cl_map_item_t             *vport_map_item = NULL;
    cl_map_item_t             *vport_map_rollback_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    sx_flow_counter_obj_t      flow_counter;
    sx_flow_counter_obj_t      fail_flow_counter;

    SX_LOG_ENTER();

    flow_counter.flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;
    flow_counter.flow_counter_bound_entity = SX_FLOW_COUNTER_INVALID_TYPE;

    fail_flow_counter.flow_counter_id = bridge_item->bridge_flow_counter_id;
    fail_flow_counter.flow_counter_bound_entity = SX_FLOW_COUNTER_BRIDGE_TYPE;

    vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
    vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));

    while (vport_map_item != vport_map_end) {
        vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);

        status = __sdk_bridge_hw_vport_counter_update(bridge_item->bridge_id,
                                                      vport->log_port,
                                                      flow_counter);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "__sdk_bridge_hw_vport_counter_update failed, vport(0x%x).\n", vport->log_port);
            vport_map_rollback_item = vport_map_item;
            break;
        }

        vport_map_item = cl_qmap_next(vport_map_item);
    }

    /* rollback on failure */
    if (status != SX_STATUS_SUCCESS) {
        vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
        while (vport_map_item != vport_map_rollback_item) {
            vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);

            __sdk_bridge_hw_vport_counter_update(bridge_item->bridge_id,
                                                 vport->log_port,
                                                 fail_flow_counter);
            vport_map_item = cl_qmap_next(vport_map_item);
        }
    }

    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_hw_vport_counter_update(sx_bridge_id_t        bridge_id,
                                                        sx_port_log_id_t      log_port,
                                                        sx_flow_counter_obj_t flow_counter)
{
    sx_status_t    status = SX_STATUS_SUCCESS;
    sx_port_info_t port_info;
    boolean_t      v_rif = FALSE;
    hwd_rif_id_t   hw_rif_id = 0;

    SX_LOG_ENTER();

    status = port_db_info_get(log_port, &port_info);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, "Could not retrieve port info vport (0x%x).\n", log_port);
        goto out;
    }

    if (SX_PORT_ADMIN_STATUS_UP == port_info.admin_state) {
        status = __sdk_bridge_hw_rif_by_fid_get(bridge_id, &v_rif, &hw_rif_id);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to get HW RIF ID by FID [%u], error: %s\n",
                       bridge_id, sx_status_str(status));
            goto out;
        }

        /* Access SVFA via port module */
        status = port_vport_bind_set(log_port,
                                     SX_PORT_VLAN_ID_GET(log_port),
                                     bridge_id,
                                     flow_counter,
                                     VPORT_BIND_REF_CNT_UPDATE,
                                     port_info.mirror,
                                     v_rif, hw_rif_id);

        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("port_vport_bind_set failed (%s) on (0x%x).\n", sx_status_str(status), log_port);
            goto out;
        }
    } else {
        status = port_flow_counter_port_db_update(log_port, flow_counter);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not update port flow counter vport (0x%x).\n", log_port);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_vport_delete(sx_port_log_id_t log_port, sdk_bridge_t *bridge_item)
{
    sx_status_t           status = SX_STATUS_SUCCESS;
    sx_port_info_t        port_info;
    sx_flow_counter_obj_t flow_counter;

    SX_LOG_ENTER();

    flow_counter.flow_counter_bound_entity = SX_FLOW_COUNTER_INVALID_TYPE;
    flow_counter.flow_counter_id = SX_FLOW_COUNTER_ID_INVALID;

    status = port_db_info_get(log_port, &port_info);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", log_port);
        goto out;
    }

    if (SX_PORT_ADMIN_STATUS_UP == port_info.admin_state) {
        SX_LOG_ERR("Can't unbind vport 0x%08X while admin state is up .\n", log_port);
        status = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    status = __bridge_flood_control_port_set(SX_ACCESS_CMD_DELETE_PORTS, bridge_item, log_port);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__bridge_flood_control_port_set DELETE failed for vport (0x%x) bridge (%d).\n",
                   log_port,
                   bridge_item->bridge_id);
        goto out;
    }

    status = __bridge_flood_port_set(SX_ACCESS_CMD_DELETE_PORTS, bridge_item->bridge_id, log_port);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__bridge_flood_port_set DELETE failed for vport (0x%x) bridge (%d).\n",
                   log_port,
                   bridge_item->bridge_id);
        goto out;
    }
    if (port_info.flow_counter.flow_counter_bound_entity == SX_FLOW_COUNTER_VPORT_TYPE) {
        flow_counter.flow_counter_id = port_info.flow_counter.flow_counter_id;
        flow_counter.flow_counter_bound_entity = SX_FLOW_COUNTER_VPORT_TYPE;
    }

    if (port_info.flow_counter.flow_counter_bound_entity != SX_FLOW_COUNTER_VPORT_TYPE) {
        /*Update flow counter in port_db*/
        status = port_flow_counter_port_db_update(log_port, flow_counter);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG(SX_LOG_ERROR, "Could not update port flow counter vport (0x%x).\n", log_port);
            goto out;
        }
    }

    status = __sdk_bridge_push_vport_to_gc_queue(log_port, bridge_item->bridge_id);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to push vport to gc queue %s\n"
                   , sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_push_vport_to_gc_queue(sx_port_log_id_t log_port, sx_bridge_id_t bridge_id)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sx_utils_status_t          utils_status = SX_UTILS_STATUS_SUCCESS;
    sx_port_info_t             port_info;
    sdk_bridge_context_item_t *sdk_bridge_context_item_p = NULL;

    SX_LOG_ENTER();

    SX_MEM_CLR(port_info);

    status = port_db_info_get(log_port, &port_info);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Unable to retrieves vport 0x%08X from DB. status = %s\n", log_port, sx_status_str(status));
        goto out;
    }

    status = __sdk_bridge_context_item_pool_get(&sdk_bridge_context_item_p);
    if (SX_CHECK_FAIL(status)) {
        goto out;
    }

    sdk_bridge_context_item_p->bridge_id = bridge_id;
    sdk_bridge_context_item_p->log_port = log_port;
    utils_status = gc_object_push(GC_OBJECT_TYPE_PORT, sdk_bridge_context_item_p, GC_STATE_PENDING_FENCE,
                                  1, GC_OBJECT_SUBTYPE_NONE, 0, &(port_info.gc_handle));

    if (SX_UTILS_CHECK_FAIL(utils_status)) {
        status = sx_utils_status_to_sx_status(utils_status);
        SX_LOG_ERR("Failed to push object to GC queue, utils_err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_status));
        __sdk_bridge_put_context_item(sdk_bridge_context_item_p);
        sdk_bridge_context_item_p = NULL;
        goto out;
    }

    status = port_db_gc_handle_set(log_port, port_info.gc_handle);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to set gc_handle for vport 0x%08X . status = %s\n", log_port, sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}
sx_status_t __sdk_bridge_return_vport_to_db(sdk_bridge_context_item_t *sdk_bridge_context_item_p)
{
    sx_status_t      status = SX_STATUS_SUCCESS;
    boolean_t        is_last_vport_lag;
    sx_port_log_id_t lag_log_port = 0;
    sx_port_log_id_t log_port;
    sdk_bridge_t    *bridge_item = NULL;
    sx_bridge_id_t   bridge_id;


    SX_LOG_ENTER();

    if (sdk_bridge_context_item_p == NULL) {
        SX_LOG_ERR("sdk_bridge_context_item_p parameter is NULL.\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    log_port = sdk_bridge_context_item_p->log_port;
    bridge_id = sdk_bridge_context_item_p->bridge_id;
    status = __sdk_bridge_db_get_bridge(bridge_id, &(bridge_item));
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__sdk_bridge_db_get_bridge failed (%s).\n", sx_status_str(status));
        goto out;
    }

    /*Return virtual port to DB*/
    status = __sdk_bridge_db_free_virtual_port(log_port, bridge_item, &is_last_vport_lag);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__sdk_bridge_db_return_virtual_port failed (%s).\n", sx_status_str(status));
        goto out;
    }

    /* If vport is last for this LAG, un-register port add call backs */
    if (is_last_vport_lag) {
        SX_PORT_TYPE_ID_SET(lag_log_port, SX_PORT_TYPE_LAG);
        SX_PORT_LAG_ID_SET(lag_log_port, SX_PORT_LAG_ID_GET(log_port));

        status = lag_sink_lag_unadvise(lag_log_port, __sdk_bridge_lag_port_update);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("lag_sink_lag_unadvise failed (%s) on LAG (0x%x).\n", sx_status_str(status), log_port);
            goto out;
        }
    }

    status = port_ref_cnt_decrease(log_port);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("port_ref_cnt_decrease failed (%s).\n", sx_status_str(status));
        goto out;
    }

    status = port_db_gc_handle_set(log_port, NULL);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to set gc_handle for vport 0x%08X . status = %s\n", log_port, sx_status_str(status));
        goto out;
    }

out:
    if (sdk_bridge_context_item_p) {
        __sdk_bridge_put_context_item(sdk_bridge_context_item_p);
    }
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_db_counter_bind_validate(const sdk_bridge_t *bridge_item)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sx_utils_status_t          utils_status = SX_UTILS_STATUS_SUCCESS;
    sx_port_info_t             port_info;
    sdk_bridge_virtual_port_t *vport = NULL;
    cl_map_item_t             *vport_map_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    boolean_t                  first_fence = TRUE;

    SX_LOG_ENTER();
    /* First check if bridge is already bound to a counter */
    if (SX_FLOW_COUNTER_ID_INVALID != bridge_item->bridge_flow_counter_id) {
        SX_LOG(SX_LOG_ERROR,
               "bridge_id(%d) is already bound to flow counter(%u).\n",
               bridge_item->bridge_id,
               bridge_item->bridge_flow_counter_id);
        status = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    /* Check if any of the vports of the bridge are bound to a counter */
    vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
    vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));

    while (vport_map_item != vport_map_end) {
        vport = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);
        vport_map_item = cl_qmap_next(vport_map_item);
        status = port_db_info_get(vport->log_port, &port_info);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", vport->log_port);
            goto out;
        }

        if (port_info.gc_handle != NULL) {
            /* Sync fence */
            if (first_fence) {
                utils_status = gc_object_fence(GC_FENCE_TYPE_SLOW);
                status = sx_utils_status_to_sx_status(utils_status);
                if (SX_UTILS_CHECK_FAIL(utils_status)) {
                    SX_LOG_ERR("Failed to process GC queue for object type PORT\n");
                    goto out;
                }
                first_fence = FALSE;
            }
            status = sdk_bridge_remove_vport_from_gc_queue(vport->log_port);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed in sdk_bridge_remove_vport_from_gc_queue\n");
                goto out;
            }

            continue;
        }

        if ((SX_FLOW_COUNTER_ID_INVALID != port_info.flow_counter.flow_counter_id) ||
            (port_info.flow_counter.flow_counter_bound_entity != SX_FLOW_COUNTER_INVALID_TYPE)) {
            SX_LOG(SX_LOG_ERROR, "port(0x%8x) on bridge_id(%d) is already bound to flow counter(%u).\n",
                   vport->log_port, bridge_item->bridge_id,
                   port_info.flow_counter.flow_counter_id);
            status = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_port_added_to_lag(sx_port_id_t port_log_id, sx_port_id_t lag_port_log_id)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sx_port_info_t             port_info;
    cl_map_item_t             *lag_item = NULL;
    const cl_map_item_t       *lag_end = NULL;
    sdk_lag_vport_id_t        *lag_vport = NULL;
    cl_map_item_t             *vport_item = NULL;
    const cl_map_item_t       *vport_end = NULL;
    sdk_bridge_virtual_port_t *virtual_port;
    sdk_bridge_t              *bridge_item_p = NULL;
    sx_flow_counter_id_t       flow_counter_id;
    sx_mirror_mode_t           mirror_mode;
    boolean_t                  v_rif = FALSE;
    hwd_rif_id_t               hw_rif_id = 0;

    SX_LOG_ENTER();

    if (NULL == sdk_bridge_db_p) {
        status = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("sdk_bridge_db is NULL.\n");
        goto out;
    }

    /* Get lag object */
    lag_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_lag_map));
    lag_item = cl_qmap_get(&(sdk_bridge_db_p->bridge_lag_map), SX_PORT_LAG_ID_GET(lag_port_log_id));

    if (lag_item == lag_end) {
        SX_LOG_ERR("No vport on lag 0x%08X info .\n", lag_port_log_id);
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    lag_vport = PARENT_STRUCT(lag_item, sdk_lag_vport_id_t, map_item);
    /* for all vport on lag, configure vfid from the newly added port */
    vport_end = cl_qmap_end(&(lag_vport->vport_map));
    vport_item = cl_qmap_head(&(lag_vport->vport_map));

    while (vport_item != vport_end) {
        virtual_port = PARENT_STRUCT(vport_item, sdk_bridge_virtual_port_t, map_lag_item);
        vport_item = cl_qmap_next(vport_item);

        status = port_db_info_get(virtual_port->log_port, &port_info);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", lag_port_log_id);
            goto out;
        }

        if (port_info.gc_handle != NULL) {
            continue;
        }

        status = __sdk_bridge_db_get_bridge(virtual_port->bridge_id, &bridge_item_p);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Can't Retrieve bridge (%u) .\n", virtual_port->bridge_id);
            goto out;
        }

        if (SX_PORT_ADMIN_STATUS_UP == port_info.admin_state) {
            /* Update FW with new vport */
            status = __sdk_bridge_hw_rif_by_fid_get(virtual_port->bridge_id, &v_rif, &hw_rif_id);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to get HW RIF ID by FID [%u], error: %s\n",
                           virtual_port->bridge_id, sx_status_str(status));
                goto out;
            }

            flow_counter_id = (bridge_item_p->bridge_flow_counter_id != SX_FLOW_COUNTER_ID_INVALID) ?
                              bridge_item_p->bridge_flow_counter_id :
                              port_info.flow_counter.flow_counter_id;

            mirror_mode = (bridge_item_p->bridge_ingress_mirror_mode != SX_MIRROR_MODE_DISABLED) ?
                          bridge_item_p->bridge_ingress_mirror_mode :
                          port_info.mirror;

            status = port_vport_svfa_update(port_log_id,
                                            SX_PORT_VLAN_ID_GET(virtual_port->log_port),
                                            bridge_item_p->bridge_id,
                                            flow_counter_id,
                                            mirror_mode,
                                            v_rif, hw_rif_id);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("port_vport_svfa_update failed (%s) on (0x%x).\n", sx_status_str(
                               status), virtual_port->log_port);
                goto out;
            }
        }

        status = fdb_flood_port_membership_set(SX_ACCESS_CMD_ADD_PORTS,
                                               port_info.swid_id,
                                               bridge_item_p->bridge_id,
                                               port_log_id);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("bridge_flood_port_set ADD LAG cb failed (%s) on port (0x%x).\n",
                       sx_status_str(status), virtual_port->log_port);
            goto out;
        }
    }
out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_port_removed_from_lag(sx_port_id_t port_log_id, sx_port_id_t lag_port_log_id)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    sx_port_info_t             port_info;
    cl_map_item_t             *lag_item = NULL;
    const cl_map_item_t       *lag_end = NULL;
    sdk_lag_vport_id_t        *lag_vport = NULL;
    cl_map_item_t             *vport_item = NULL;
    const cl_map_item_t       *vport_end = NULL;
    sdk_bridge_virtual_port_t *virtual_port;
    sdk_bridge_t              *bridge_item_p = NULL;

    SX_LOG_ENTER();

    if (NULL == sdk_bridge_db_p) {
        status = SX_STATUS_MODULE_UNINITIALIZED;
        SX_LOG_ERR("sdk_bridge_db is NULL.\n");
        goto out;
    }

    /* Get lag object */
    lag_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_lag_map));
    lag_item = cl_qmap_get(&(sdk_bridge_db_p->bridge_lag_map), SX_PORT_LAG_ID_GET(lag_port_log_id));

    if (lag_item == lag_end) {
        SX_LOG_ERR("No vport on lag 0x%08X info .\n", lag_port_log_id);
        status = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    lag_vport = PARENT_STRUCT(lag_item, sdk_lag_vport_id_t, map_item);
    /* for all vport on lag, configure vfid for the newly added port */
    vport_end = cl_qmap_end(&(lag_vport->vport_map));
    vport_item = cl_qmap_head(&(lag_vport->vport_map));

    while (vport_item != vport_end) {
        virtual_port = PARENT_STRUCT(vport_item, sdk_bridge_virtual_port_t, map_lag_item);

        status = port_db_info_get(lag_port_log_id, &port_info);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", lag_port_log_id);
            goto out;
        }

        status = __sdk_bridge_db_get_bridge(virtual_port->bridge_id, &bridge_item_p);
        if (SX_STATUS_SUCCESS != status) {
            SX_LOG_ERR("Can't Retrieve bridge (%u) .\n", virtual_port->bridge_id);
            goto out;
        }

        if (SX_PORT_ADMIN_STATUS_UP == port_info.admin_state) {
            /* Update FW with new vport */
            status = port_vport_svfa_update(port_log_id,
                                            SX_PORT_VLAN_ID_GET(virtual_port->log_port),
                                            0,
                                            SX_FLOW_COUNTER_ID_INVALID,
                                            SX_MIRROR_MODE_DISABLED,
                                            FALSE, 0);
            if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("port_vport_svfa_update failed (%s) on (0x%x).\n", sx_status_str(
                               status), virtual_port->log_port);
                goto out;
            }
        }

        status = fdb_flood_port_membership_set(SX_ACCESS_CMD_DELETE_PORTS,
                                               port_info.swid_id,
                                               bridge_item_p->bridge_id,
                                               port_log_id);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("bridge_flood_port_set REMOVE LAG cb failed (%s) on port (0x%x).\n",
                       sx_status_str(status), virtual_port->log_port);
            goto out;
        }

        vport_item = cl_qmap_next(vport_item);
    }
out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t sdk_bridge_mode_get(sx_bridge_mode_t *bridge_mode)
{
    if (bridge_mode == NULL) {
        SX_LOG_ERR("bridge_mode parameter is NULL.\n");
        return SX_STATUS_PARAM_ERROR;
    }

    *bridge_mode = SX_MODE_HYBRID;

    return SX_STATUS_SUCCESS;
}

sx_status_t sdk_bridge_clear_port(sx_port_id_t port_id, boolean_t remove_port_from_db)
{
    UNUSED_PARAM(port_id);
    UNUSED_PARAM(remove_port_from_db);

    /*When in Spectrum port's are never a member of a bridge. */
    return SX_STATUS_SUCCESS;
}

sx_status_t sdk_bridge_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t                status = SX_STATUS_SUCCESS;
    cl_map_item_t             *bridge_map_item = NULL;
    const cl_map_item_t       *bridge_map_end = NULL;
    cl_map_item_t             *vport_map_item = NULL;
    const cl_map_item_t       *vport_map_end = NULL;
    sdk_bridge_t              *bridge_item = NULL;
    sdk_bridge_virtual_port_t *vport_item = NULL;
    char                       buffer[16];
    sx_bridge_id_t             bridge_id;
    char                       mirror_mode[MAX_STRING_LEN];
    sx_flow_counter_id_t       flow_counter_id;
    uint32_t                   ref_count;
    char                      *vports_p = NULL;
    uint16_t                   vports_num = 0;
    uint32_t                   vports_buff_left = 0;
    uint32_t                   buff_len = 0;
    uint32_t                   i = 0, j = 0;
    uint16_t                   port_num = 0;
    sx_port_log_id_t          *port_list_p = NULL, port = SX_INVALID_PORT;
    sx_mc_container_id_t       mc_container_id = 0;
    sx_swid_t                  swid = 0;
    dbg_utils_table_columns_t  bridge_dump_clmns[] = {
        { "Bridge ID",       9,    PARAM_UINT16_E,     &bridge_id},
        { "Mirror mode",     11,   PARAM_STRING_E,     mirror_mode},
        { "Flow counter ID", 15,   PARAM_UINT32_E,     &flow_counter_id},
        { "Ref count",       10,   PARAM_UINT32_E,     &ref_count},
        { "MC-Cont ID",      10,   PARAM_UINT16_E,     &mc_container_id},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t  vport_dump_clmns[] = {
        { "Bridge ID",   9,    PARAM_UINT16_E,      &bridge_id},
        { "VPorts num",  10,   PARAM_UINT16_E,      &vports_num},
        { "VPorts",      100,  PARAM_EXT_STRING_E,  vports_p},
        {NULL, 0, 0, NULL}
    };
    dbg_utils_table_columns_t  mc_unreg_port_list[] = {
        { "Index",        5,     PARAM_UINT32_E,     &i},
        { "Port",         10,    PARAM_PORT_ID_E,     &port},
        {NULL, 0, 0, NULL}
    };
    flood_type_e               flood_types_arr[] = {
        FLOOD_TYPE_MULTICAST_IPV4_E,
        FLOOD_TYPE_MULTICAST_IPV6_E
    };
    uint32_t                   flood_types_arr_len = sizeof(flood_types_arr) / sizeof(flood_types_arr[0]);
    FILE                      *stream = NULL;
    char                       buf[64] = {0};

    status = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(status)) {
        goto out;
    }
    stream = dbg_dump_params_p->stream;

    if (NULL == sdk_bridge_db_p) {
        dbg_utils_pprinter_module_header_print(stream, "SDK bridge Module is uninitialized");
        SX_LOG_INF("sdk_bridge_db is not initialized.\n");
        goto out;
    }

    dbg_utils_pprinter_module_header_print(stream, "SDK bridge Module");

    dbg_utils_pprinter_general_header_print(stream, "SDK bridge Dump");

    /* For each bridge item, print attributes */
    bridge_map_item = cl_qmap_head(&(sdk_bridge_db_p->bridge_map));
    bridge_map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_map));

    dbg_utils_pprinter_table_headline_print(stream, bridge_dump_clmns);

    while (bridge_map_item != bridge_map_end) {
        bridge_item = PARENT_STRUCT(bridge_map_item, sdk_bridge_t, map_item);
        bridge_map_item = cl_qmap_next(bridge_map_item);

        bridge_id = bridge_item->bridge_id;

        if (bridge_item->bridge_ingress_mirror_mode == SX_MIRROR_MODE_ENABLED) {
            strcpy(mirror_mode, "ENABLED");
        } else {
            strcpy(mirror_mode, "DISABLED");
        }

        flow_counter_id = bridge_item->bridge_flow_counter_id;

        ref_count = bridge_item->bridge_ref_count;

        status = fdb_flood_get(swid, (sx_fid_t)bridge_id, &mc_container_id);
        if (SX_STATUS_ENTRY_NOT_FOUND == status) {
            bridge_dump_clmns[4].type = PARAM_STRING_E;
            bridge_dump_clmns[4].data = "N/A";
        } else {
            bridge_dump_clmns[4].type = PARAM_UINT16_E;
            bridge_dump_clmns[4].data = &mc_container_id;
        }

        status = SX_STATUS_SUCCESS;
        /* print bridge attributes */
        dbg_utils_pprinter_table_data_line_print(stream, bridge_dump_clmns);
    }

    /* Now for each bridge item, print list of VPorts */
    bridge_map_item = cl_qmap_head(&(sdk_bridge_db_p->bridge_map));
    bridge_map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_map));

    dbg_utils_pprinter_table_headline_print(stream, vport_dump_clmns);

    while (bridge_map_item != bridge_map_end) {
        bridge_item = PARENT_STRUCT(bridge_map_item, sdk_bridge_t, map_item);
        vports_num = cl_qmap_count(&(bridge_item->bridge_virtual_port_map));
        bridge_map_item = cl_qmap_next(bridge_map_item);

        bridge_id = bridge_item->bridge_id;

        vport_map_item = cl_qmap_head(&(bridge_item->bridge_virtual_port_map));
        vport_map_end = cl_qmap_end(&(bridge_item->bridge_virtual_port_map));

        vports_p = (char*)cl_calloc(vports_num * VPORT_STRING_LEN + 1, sizeof(char));
        vports_buff_left = vports_num * VPORT_STRING_LEN;
        vport_dump_clmns[2].data = vports_p;

        while (vport_map_item != vport_map_end) {
            vport_item = PARENT_STRUCT(vport_map_item, sdk_bridge_virtual_port_t, map_bridge_item);
            vport_map_item = cl_qmap_next(vport_map_item);
            buff_len = snprintf(buffer, sizeof(buffer), "0x%08X ", vport_item->log_port);
            strncat(vports_p, buffer, vports_buff_left);
            if (buff_len > vports_buff_left) {
                /* Should never happen */
                SX_LOG_NTC("Couldn't dump all vports for bridge %d, no more space on the buffer\n", bridge_id);
                break; /* No more space on the buffer */
            }
            vports_buff_left -= buff_len;
        }

        /* print bridge attributes */
        dbg_utils_pprinter_table_data_line_print(stream, vport_dump_clmns);
        if (vports_p != NULL) {
            cl_free(vports_p);
            vports_p = NULL;
        }
    }

    /* For each bridge item, print unregistered MC ports */
    bridge_map_item = cl_qmap_head(&(sdk_bridge_db_p->bridge_map));
    bridge_map_end = cl_qmap_end(&(sdk_bridge_db_p->bridge_map));
    while (bridge_map_item != bridge_map_end) {
        bridge_item = PARENT_STRUCT(bridge_map_item, sdk_bridge_t, map_item);
        bridge_map_item = cl_qmap_next(bridge_map_item);
        bridge_id = bridge_item->bridge_id;
        for (j = 0; j < flood_types_arr_len; j++) {
            status = fdb_urmc_flood_ports_api_type_validate_get(0, bridge_id);
            if (status == SX_STATUS_CMD_UNPERMITTED) {
                SX_LOG_INF("FDB unregistered %s MC port API type for bridge ID %u, err %s:\n",
                           sx_flood_type_str(flood_types_arr[j]), bridge_id, sx_status_str(status));
                status = SX_STATUS_SUCCESS;
                continue;
            } else if (status != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to validate FDB unregistered %s MC port API type for bridge ID %u, err %s:\n",
                           sx_flood_type_str(flood_types_arr[j]), bridge_id, sx_status_str(status));
                goto out;
            }

            port_num = 0;
            status = fdb_urmc_flood_ports_get(0, bridge_id, flood_types_arr[j],
                                              &port_num, NULL);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to retrieve FDB unregistered %s MC port count for bridge ID %u, err %s:\n",
                           sx_flood_type_str(flood_types_arr[j]), bridge_id, sx_status_str(status));
                goto out;
            }

            if (port_num == 0) {
                continue;
            }

            dbg_utils_pprinter_secondary_header_print(stream, "Bridge ID %u", bridge_id);
            dbg_utils_pprinter_field_print(stream, "Bridge ID",  &bridge_id, PARAM_UINT16_E);
            snprintf(buf, sizeof(buf) - 1, "%s port list", sx_flood_type_str(flood_types_arr[j]));
            dbg_utils_pprinter_plain_text_secondary_header_print(stream, "%s", buf);
            dbg_utils_pprinter_json_table_name_set(stream, buf);
            dbg_utils_pprinter_table_headline_print(stream, mc_unreg_port_list);

            port_list_p = (sx_port_log_id_t*)cl_calloc(port_num, sizeof(port_list_p[0]));
            if (port_list_p == NULL) {
                SX_LOG_ERR("Failed to allocate memory for port list\n");
                goto out;
            }
            status = fdb_urmc_flood_ports_get(0, bridge_id, flood_types_arr[j],
                                              &port_num, port_list_p);
            if (SX_CHECK_FAIL(status)) {
                SX_LOG_ERR("Failed to retrieve FDB %s port list for bridge ID %u, err %s:\n",
                           sx_flood_type_str(flood_types_arr[j]), bridge_id, sx_status_str(status));
                goto out;
            }

            for (i = 0; i < port_num; i++) {
                port = port_list_p[i];
                dbg_utils_pprinter_table_data_line_print(stream, mc_unreg_port_list);
            }

            if (port_list_p != NULL) {
                CL_FREE_N_NULL(port_list_p);
            }
        } /* for(j=0; j<flood_types_arr_len; j++){ */
    }

out:
    return status;
}

static sx_status_t __bridge_prepare_profile_callback(adviser_event_e event_type, void *param)
{
    profile_prepare_event_t * prepare_event = (profile_prepare_event_t*)param;
    sx_status_t               sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (ADVISER_EVENT_PREPARE_PROFILE_E != event_type) {
        SX_LOG_ERR("Wrong event type, received event type : [%s].\n", ADVISER_EVENT_STR(event_type));
        sx_status = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

    if (NULL == sdk_bridge_db_p) {
        SX_LOG_ERR("sdk_bridge_db is not initialized during PREPARE_PROFILE event.\n");
        sx_status = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Overwrite max_fid field in profile */
    prepare_event->profile->max_fid = 0; /* Reserved for SPC/-2 && ubridge=1 */

out:
    return M_UTILS_SX_LOG_EXIT(sx_status);
}

static sx_status_t __sdk_bridge_context_item_pool_get(sdk_bridge_context_item_t **sdk_bridge_context_item_p)
{
    sx_status_t     status = SX_STATUS_SUCCESS;
    cl_pool_item_t *pool_item = NULL;

    SX_LOG_ENTER();

    pool_item = cl_qpool_get(&sdk_bridge_db_p->bridge_context_item_pool);
    if (!pool_item) {
        status = SX_STATUS_NO_RESOURCES;
        goto out;
    }

    *sdk_bridge_context_item_p = PARENT_STRUCT(pool_item, sdk_bridge_context_item_t, pool_item);

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __sdk_bridge_put_context_item(sdk_bridge_context_item_t *sdk_bridge_context_item_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    cl_qpool_put(&(sdk_bridge_db_p->bridge_context_item_pool), &sdk_bridge_context_item_p->pool_item);
    return status;
}

sx_status_t sdk_bridge_is_homogeneous(sx_bridge_id_t bridge_id, boolean_t *is_homogeneous)
{
    sdk_bridge_t *bridge_item = NULL;
    sx_status_t   status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (NULL == is_homogeneous) {
        SX_LOG_ERR("is_homogeneous received is NULL\n");
        status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    status = __sdk_bridge_db_get_bridge(bridge_id, &bridge_item);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Could not find bridge_id(%d) in sdk_bridge_db.\n", bridge_id);
        goto out;
    }

    *is_homogeneous = bridge_item->is_homogeneous;

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __bridge_validate_igmpv3_parameters(sx_port_log_id_t log_port,
                                                       sdk_bridge_t    *bridge_item,
                                                       sx_bridge_id_t   bridge_id,
                                                       sx_port_info_t  *port_info)
{
    boolean_t                     igmpv3_offense = FALSE;
    sx_fid_t                      calc_fid = 0;
    sx_fdb_igmp_fid_found_state_t found_fid_state;
    uint16_t                      vport_vlan = SX_PORT_VLAN_ID_GET(log_port);
    sx_fdb_igmpv3_state_t         vport_fid_igmpv3_state = SX_FDB_IGMPV3_STATE_DISABLE_E;
    sx_fdb_igmpv3_state_t         bridge_vlan_igmpv3_state = SX_FDB_IGMPV3_STATE_DISABLE_E;
    sx_fdb_unreg_flood_mode_t     bridge_vlan_flood_mode;
    sx_status_t                   status = SX_STATUS_SUCCESS;
    sx_fdb_igmp_offense_t         igmpv3_offense_params;

    SX_LOG_ENTER();

    status = igmp_v3_fdb_offense_flag_get(&igmpv3_offense);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to get igmp offense flag\n");
        goto out;
    }

    status = sdk_igmpv3_state_get(vport_vlan, &vport_fid_igmpv3_state);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to get igmp status for fid %d\n", vport_vlan);
        goto out;
    }
    status = SX_STATUS_SUCCESS;

    if ((bridge_item->is_homogeneous == TRUE) &&
        (bridge_item->homogeneous_vlan != INVALID_VLAN_ID)) {
        status = sdk_igmpv3_state_get(bridge_item->homogeneous_vlan, &bridge_vlan_igmpv3_state);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed to get igmp status for fid %d\n", vport_vlan);
            goto out;
        }

        status = fdb_urmc_mode_get(port_info->swid_id, bridge_id, &bridge_vlan_flood_mode);
        if (status != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to fdb_urmc_flood_mode_get (vid = %d) [Enable], err = %s\n",
                       vport_vlan, sx_status_str(status));
            goto out;
        }
    }

    if (!igmpv3_offense &&
        ((vport_fid_igmpv3_state == SX_FDB_IGMPV3_STATE_ENABLE_E) ||
         ((bridge_vlan_igmpv3_state == SX_FDB_IGMPV3_STATE_ENABLE_E) &&
          (bridge_vlan_flood_mode == SX_FDB_UNREG_MC_PRUNE)))) {
        /* no offense made */
        if (bridge_item->is_homogeneous == FALSE) {
            igmpv3_offense_params.offense_made = FDB_IGMPV3_OFFENCE_TYPE_VPORT_IN_NON_HOMOGENEOUS_BRIDGE;
            igmpv3_offense_params.message_vals[0].log_port = log_port;
            igmpv3_offense_params.message_vals[1].bridge_id = bridge_id;
            igmp_v3_fdb_offense_flag_set(igmpv3_offense_params);
        } else {
            if ((bridge_item->homogeneous_vlan != INVALID_VLAN_ID) &&
                (vport_vlan != bridge_item->homogeneous_vlan)) {
                igmpv3_offense_params.offense_made = FDB_IGMPV3_OFFENCE_TYPE_VPORT_VLAN_DOES_NOT_COMPLY;
                igmpv3_offense_params.message_vals[0].log_port = log_port;
                igmpv3_offense_params.message_vals[1].int_vlan_id = vport_vlan;
                igmpv3_offense_params.message_vals[2].bridge_id = bridge_id;
                igmpv3_offense_params.message_vals[3].vlan_id = bridge_item->homogeneous_vlan;
                igmp_v3_fdb_offense_flag_set(igmpv3_offense_params);
            } else if ((bridge_item->homogeneous_vlan == INVALID_VLAN_ID) || /* first vport in bridge or vlan complies with bridge vlan */
                       ((bridge_item->homogeneous_vlan != INVALID_VLAN_ID) &&
                        (SX_PORT_VLAN_ID_GET(log_port) == bridge_item->homogeneous_vlan))) {
                /* verify that no Vports exist with Vlan in question and that the vlan doesn't exist*/
                status = fdb_vlan_bridge_found_calculate_get(port_info->swid_id, SX_PORT_VLAN_ID_GET(
                                                                 log_port), &calc_fid, &found_fid_state, &bridge_id,
                                                             1);
                if (status != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to fdb_vlan_bridge_found_calculate_get (vid = %d), err = %s\n",
                               SX_PORT_VLAN_ID_GET(log_port), sx_status_str(status));
                    goto out;
                }

                if (found_fid_state != SX_FDB_IGMP_NONE_FOUND_STATE) {
                    igmpv3_offense_params.offense_made = FDB_IGMPV3_OFFENCE_TYPE_VPORT_VLAN_NOT_EXCLUSIVE;
                    igmpv3_offense_params.message_vals[0].fid = calc_fid;
                    igmpv3_offense_params.message_vals[1].int_vlan_id = SX_PORT_VLAN_ID_GET(log_port);
                    igmp_v3_fdb_offense_flag_set(igmpv3_offense_params);
                }
            }
        }
    }
out:
    SX_LOG_EXIT();
    return status;
}
