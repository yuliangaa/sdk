/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sdk_tunnel_impl.h"
#include <complib/cl_byteswap.h>
#include <complib/cl_qpool.h>
#include <complib/cl_qmap.h>
#include <complib/cl_mem.h>
#include <utils/utils.h>
#include <sx/sdk/sx_types.h>

#include <ethl3/hwi/sdk_router_vrid/sdk_router_vrid_impl.h>
#include <ethl3/hwi/rif/rif_db.h>
#include <ethl3/hwi/rif/rif_impl.h>
#include <ethl2/fdb.h>
#include <ethl3/hwi/neigh/router_neigh_impl.h>
#include <ethl3/hwi/sdk_router/sdk_router_impl.h>
#include <ethl2/vlan.h>
#include "ethl2/brg.h"
#include "tunnel_impl.h"
#include "decap_table_impl.h"
#include "mc_container/hwi/mc_container_impl.h"
#include "tunnel/hwd/hwd_tunnel.h"
#include "ipv6_mgr_impl.h"


#undef  __MODULE__
#define __MODULE__ SDK_TUNNEL


/************************************************
 *  Global variables
 ***********************************************/

extern rm_resources_t   rm_resource_global;
extern sx_brg_context_t brg_context;

/************************************************
 *  Local defines
 ***********************************************/

#define TUNNEL_VALID_ECMP_SIZE_CNT 8

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

static sx_status_t __sdk_tunnel_impl_prepare_create(sx_tunnel_attribute_t * tunnel_attr_p,
                                                    sx_tunnel_id_t        * tunnel_id_p);
static sx_status_t __sdk_tunnel_impl_prepare_create_rollback(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                             sx_tunnel_id_t              * tunnel_id_p);
static sx_status_t __sdk_tunnel_impl_edit_action(sx_tunnel_id_t              tunnel_id,
                                                 const sdk_db_tunnel_data_t *tunnel_params_p,
                                                 sx_tunnel_attribute_t      *old_tunnel_attr,
                                                 sx_tunnel_attribute_t     * new_tunnel_attr_p);
static sx_status_t __sdk_tunnel_impl_edit_action_rollback(sx_tunnel_id_t                tunnel_id,
                                                          const sdk_db_tunnel_data_t   *tunnel_params_p,
                                                          sx_tunnel_attribute_t        *old_tunnel_attr,
                                                          const sx_tunnel_attribute_t * new_tunnel_attr_p);
static sx_status_t __sdk_tunnel_impl_post_edit_action(sx_tunnel_id_t                tunnel_id,
                                                      sx_tunnel_attribute_t        *old_tunnel_attr,
                                                      const sx_tunnel_attribute_t * new_tunnel_attr_p);
static sx_status_t __sdk_tunnel_impl_delete_action(sx_tunnel_id_t              tunnel_id,
                                                   const sdk_db_tunnel_data_t *tunnel_params_p);
static sx_status_t __sdk_tunnel_impl_delete_action_rollback(sx_tunnel_id_t              tunnel_id,
                                                            const sdk_db_tunnel_data_t *tunnel_params_p);
static sx_status_t __sdk_tunnel_impl_check_learn_mode(sx_port_log_id_t    log_port,
                                                      sx_fdb_learn_mode_t learn_mode);
static sx_status_t __sdk_tunnel_impl_init_hwd(void);
static sx_status_t __sdk_tunnel_impl_counter_get(const sx_tunnel_id_t        tunnel_id,
                                                 const sdk_db_tunnel_data_t *tunnel_params_p,
                                                 boolean_t                   is_clear,
                                                 sx_tunnel_counter_t        *counter);
static sx_status_t __sdk_tunneL_impl_attr_validate(sx_tunnel_attribute_t *tunnel_attr_p);
static sx_status_t __sdk_tunnel_impl_check_init_params(sx_tunnel_general_params_t * params_p);
static boolean_t __sdk_tunnel_impl_l3_gw_supported(sx_tunnel_id_t tunnel_id);

/************************************************
 *  Local variables
 ***********************************************/

static tunnel_ops_t     sdk_tunnel_impl_ops = {
    .hwi_tunnel_impl_init_hwd_pfn = __sdk_tunnel_impl_init_hwd,
    .hwi_tunnel_impl_prepare_create_pfn = __sdk_tunnel_impl_prepare_create,
    .hwi_tunnel_impl_prepare_create_rollback_pfn = __sdk_tunnel_impl_prepare_create_rollback,
    .hwi_tunnel_impl_delete_action_pfn = __sdk_tunnel_impl_delete_action,
    .hwi_tunnel_impl_delete_action_rollback_pfn = __sdk_tunnel_impl_delete_action_rollback,
    .hwi_tunnel_impl_edit_action_pfn = __sdk_tunnel_impl_edit_action,
    .hwi_tunnel_impl_post_edit_action_pfn = __sdk_tunnel_impl_post_edit_action,
    .hwi_tunnel_impl_edit_action_rollback_pfn = __sdk_tunnel_impl_edit_action_rollback,
    .hwi_tunnel_impl_check_learn_mode_pfn = __sdk_tunnel_impl_check_learn_mode,
    .hwi_tunnel_impl_counter_get_pfn = __sdk_tunnel_impl_counter_get,
    .hwi_tunnel_impl_check_init_params_pfn = __sdk_tunnel_impl_check_init_params,
    .hwi_tunnel_impl_l3_gw_supported = __sdk_tunnel_impl_l3_gw_supported,
    .hwi_tunnel_impl_attr_validate_pfn = __sdk_tunneL_impl_attr_validate,
};
static hwd_tunnel_ops_t sdk_hwd_tunnel_ops = {
    hwd_tunnel_init,                       /* hwd_tunnel_init_pfn */
    hwd_tunnel_deinit,                     /* hwd_tunnel_deinit_pfn */
    hwd_tunnel_create,                     /* hwd_tunnel_create_pfn */
    hwd_tunnel_delete,                     /* hwd_tunnel_delete_pfn */
    hwd_tunnel_edit,                       /* hwd_tunnel_edit_pfn */
    hwd_tunnel_decap_block_lock,           /* hwd_tunnel_decap_block_lock_pfn */
    hwd_tunnel_decap_block_unlock,         /* hwd_tunnel_decap_block_unlock_pfn */
    hwd_tunnel_encap_block_lock,           /* hwd_tunnel_encap_block_lock_pfn */
    hwd_tunnel_encap_block_unlock,         /* hwd_tunnel_encap_block_unlock_pfn */
    hwd_tunnel_counter_get,                /* hwd_tunnel_counter_get_pfn */
    hwd_tunnel_tunnel_mapping_add,         /* hwd_tunnel_tunnel_mapping_add_pfn */
    hwd_tunnel_tunnel_mapping_update,      /* hwd_tunnel_tunnel_mapping_update_pfn */
    hwd_tunnel_tunnel_mapping_delete,      /* hwd_tunnel_tunnel_mapping_delete_pfn */
    hwd_tunnel_port_isolate_hw_set,        /* hwd_tunnel_port_isolate_hw_set_pfn */
    hwd_tunnel_ttl_set,                    /* hwd_tunnel_ttl_set_pfn */
    hwd_tunnel_ttl_get,                    /* hwd_tunnel_ttl_get_pfn */
    hwd_tunnel_hash_set,                   /* hwd_tunnel_hash_set_pfn */
    hwd_tunnel_hash_get,                   /* hwd_tunnel_hash_get_pfn */
    hwd_tunnel_cos_set,                    /* hwd_tunnel_cos_set_pfn */
    hwd_tunnel_cos_get,                    /* hwd_tunnel_cos_get_pfn */
    sdk_hwd_tunnel_debug_dump,             /* hwd_tunnel_debug_dump_pfn */
    sdk_hwd_tunnel_counter_clear,          /* hwd_tunnel_counter_clear_pfn */
    hwd_tunnel_nve_reg_deinit,             /* hwd_tunnel_nve_reg_deinit_pfn */
    hwd_tunnel_issu_vni_set,               /* hwd_tunnel_issu_vni_set_pfn */
    hwd_tunnel_nve_learn_set,              /* hwd_tunnel_nve_learn_set_pfn */
    NULL,                                  /* hwd_tunnel_nve_loopback_filter_set_pfn */
    NULL,                                  /* hwd_tunnel_nve_port_issu_end_set_pfn */
    hwd_tunnel_nve_group_size_flood_get,   /* hwd_tunnel_nve_group_size_flood_get_pfn */
    hwd_tunnel_nve_group_size_mc_get,      /* hwd_tunnel_nve_group_size_mc_get_pfn */
    NULL,                                  /* hwd_tunnel_zeroed_reserved_tngee_index_get_pfn */
};

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t sdk_tunnel_init_ops(void)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = sdk_tunnel_impl_register_tunnel_ops(&sdk_tunnel_impl_ops);
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register tunnel ops, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

    sx_status = hwd_tunnel_uvrid_internal_callbacks_register();
    if (sx_status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to register HWD tunnel ops, err = %s\n", sx_status_str(sx_status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __sdk_tunnel_impl_check_init_params(sx_tunnel_general_params_t * params_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    uint32_t                     valid_ecmp_size[TUNNEL_VALID_ECMP_SIZE_CNT] = {0, 1, 2, 4, 8, 16, 32, 64};
    uint32_t                     idx = 0;
    boolean_t                    is_valid_ecmp_size = FALSE;
    sx_router_resources_param_t *resources_param_p = NULL;
    uint32_t                     max_ecmp_block_sz = 0;
    uint32_t                     max_nve_ecmp_block_sz = 0;

    SX_LOG_ENTER();

    if (params_p->nve.flood_ecmp_enabled ||
        params_p->nve.mc_ecmp_enabled) {
        for (idx = 0; idx < TUNNEL_VALID_ECMP_SIZE_CNT; idx++) {
            if (params_p->nve.ecmp_max_size == valid_ecmp_size[idx]) {
                is_valid_ecmp_size = TRUE;
                break;
            }
        }

        if (is_valid_ecmp_size == FALSE) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Given ecmp size is invalid - %d \n", params_p->nve.ecmp_max_size);
            goto out;
        }

        /* Check if MAX ECMP size is not bigger than correspondent value in router params */
        err = sdk_router_impl_params_get(NULL, NULL, &resources_param_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get router resources params, err = %s\n", sx_status_str(err));
            goto out;
        }

        /* Check if user provided non-zero MAX ECMP block size */
        if (resources_param_p->max_ecmp_block_size != 0) {
            max_ecmp_block_sz = resources_param_p->max_ecmp_block_size;
        } else {
            /* MAX ECMP size 0 means it should be a default value */
            max_ecmp_block_sz = rm_resource_global.router_ecmp_container_tot_weight_max;
        }

        /* Check if user provided non-zero MAX NVE ECMP block size */
        if (params_p->nve.ecmp_max_size != 0) {
            max_nve_ecmp_block_sz = params_p->nve.ecmp_max_size;
        } else {
            /* MAX NVE ECMP size 0 means it should be a default value */
            max_nve_ecmp_block_sz = TUNNEL_NVE_GS_FLOOD_DEFAULT_ENABLED;
        }

        if (max_nve_ecmp_block_sz > max_ecmp_block_sz) {
            SX_LOG_ERR("Provided ecmp_max_size (%d) is too big. Maximum allowed %d.\n",
                       params_p->nve.ecmp_max_size, max_ecmp_block_sz);
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tunnel_impl_prepare_create(sx_tunnel_attribute_t * tunnel_attr_p,
                                             sx_tunnel_id_t        * tunnel_id_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_status_t           rollback_err = SX_STATUS_SUCCESS;
    sdk_ref_t             vrid_ref;
    sdk_ref_t             rif_ref;
    boolean_t             vrid_ref_cnt_increase_rollback = FALSE;
    boolean_t             rif_ref_increase_rollback = FALSE;
    boolean_t             rif_ref_tunnel_attach_rollback = FALSE;
    sdk_db_tunnel_data_t  tunnel_params;
    sx_tunnel_id_t        tmp_tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_router_interface_t ipinip_overlay_rif;
    rif_tunnel_t          rif_tunnel_data;
    sx_port_log_id_t      log_port = 0;
    sx_fdb_learn_mode_t   learn_mode_old;
    ref_name_data_t       ref_name_data = {.print_func_p = get_tunnel_ref_name,
                                           .ref_data_p = &tmp_tunnel_id,
                                           .data_size = sizeof(tmp_tunnel_id)};
    ref_name_data_t       tunnel_rif_name_data = {.print_func_p = get_tunnel_rif_ref_name,
                                                  .ref_data_p = &rif_tunnel_data,
                                                  .data_size = sizeof(rif_tunnel_data)};

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_params);
    SX_MEM_CLR(vrid_ref);
    SX_MEM_CLR(rif_ref);
    SX_MEM_CLR(ipinip_overlay_rif);
    SX_MEM_CLR(tmp_tunnel_id);

    tmp_tunnel_id = *tunnel_id_p;
    if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tmp_tunnel_id)) {
        err = sdk_router_vrid_impl_refcnt_inc(tunnel_impl_get_underlay_vrid(tunnel_attr_p),
                                              &ref_name_data, &vrid_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to increase VRID[%d] ref count, err = %s\n",
                       tunnel_impl_get_underlay_vrid(tunnel_attr_p),
                       sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_vrid_ref_set(tmp_tunnel_id, &vrid_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to set assign VRID[%d] to tunnel, err = %s\n",
                       tunnel_impl_get_underlay_vrid(tunnel_attr_p),
                       sx_status_str(err));
            goto out;
        }
        vrid_ref_cnt_increase_rollback = TRUE;
    }

    if (SX_TUNNEL_TYPE_IPINIP_CHECK(tmp_tunnel_id)) {
        err = tunnel_impl_get_ipinip_overlay_rif(tunnel_attr_p, &ipinip_overlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] overlay RIF, err = %s\n", tmp_tunnel_id, sx_status_str(err));
            goto out;
        }

        /*** Create ***/
        err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_ADD,
                                             ipinip_overlay_rif,
                                             tunnel_attr_p);

        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to attach tunnel to overlay_rif[%d], err = %s\n",
                       ipinip_overlay_rif, sx_status_str(err));
            goto out;
        }

        rif_tunnel_data.tunnel_id = tmp_tunnel_id;
        rif_tunnel_data.rif = ipinip_overlay_rif;
        rif_ref_tunnel_attach_rollback = TRUE;

        err = sdk_rif_impl_ref_increase(ipinip_overlay_rif, &tunnel_rif_name_data, &rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to increase RIF[%d] reference, err = %s\n",
                       ipinip_overlay_rif, sx_status_str(err));
            goto out;
        }
        rif_ref_increase_rollback = TRUE;

        err = sdk_tunnel_db_rif_ref_set(tmp_tunnel_id, &rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to assign RIF[%d] to tunnel, err = %s\n",
                       tmp_tunnel_id, sx_status_str(err));
            goto out;
        }
    }

    /* Disable learning if tunnel type is IPv6. */
    if ((SX_TUNNEL_TYPE_NVE_VXLAN_IPV6 == tunnel_attr_p->type) ||
        (SX_TUNNEL_TYPE_NVE_NVGRE_IPV6 == tunnel_attr_p->type)) {
        log_port = tunnel_impl_get_l2_log_port(tunnel_attr_p);

        /* Get current learn mode */
        err = fdb_port_learn_mode_get(log_port, &learn_mode_old);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to get learning mode for logical port %u\n", log_port);
            goto out;
        }

        if (learn_mode_old != SX_FDB_LEARN_MODE_DONT_LEARN) {
            SX_LOG_WRN("Disabling learning mode for logical port 0x%x\n", log_port);

            err = fdb_port_learn_mode_set(log_port, SX_FDB_LEARN_MODE_DONT_LEARN, FALSE);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to disable learning for logical port 0x%x in tunnel %u\n",
                           log_port, tmp_tunnel_id);
                goto out;
            }
        }
    }

out:
    if (SX_STATUS_SUCCESS != err) {
        if (rif_ref_increase_rollback) {
            rollback_err = sdk_rif_impl_ref_decrease(ipinip_overlay_rif,
                                                     &rif_ref);
            if (rollback_err) {
                SX_LOG_ERR("Failed to reference for RIF[%d], err = %s\n",
                           ipinip_overlay_rif, sx_status_str(rollback_err));
            }
        }

        if (rif_ref_tunnel_attach_rollback) {
            rollback_err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_DELETE,
                                                          ipinip_overlay_rif,
                                                          tunnel_attr_p);

            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to rollback attach overlay RIF[%d] for tunnel, err = %s\n",
                           ipinip_overlay_rif, sx_status_str(rollback_err));
            }
        }

        if (vrid_ref_cnt_increase_rollback) {
            rollback_err = sdk_router_vrid_impl_refcnt_dec(
                tunnel_impl_get_underlay_vrid(tunnel_attr_p),
                &vrid_ref);
            if (rollback_err) {
                SX_LOG_ERR("Failed to decrease reference for VRID[%d], err = %s\n",
                           tunnel_impl_get_underlay_vrid(tunnel_attr_p), sx_status_str(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tunnel_impl_prepare_create_rollback(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                      sx_tunnel_id_t              * tunnel_id_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sdk_ref_t             vrid_ref;
    sdk_ref_t             rif_ref;
    sdk_db_tunnel_data_t  tunnel_params;
    sx_tunnel_id_t        tmp_tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_router_interface_t ipinip_overlay_rif;

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_params);
    SX_MEM_CLR(vrid_ref);
    SX_MEM_CLR(rif_ref);
    SX_MEM_CLR(ipinip_overlay_rif);
    SX_MEM_CLR(tmp_tunnel_id);

    tmp_tunnel_id = *tunnel_id_p;
    if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tmp_tunnel_id)) {
        err = sdk_tunnel_db_vrid_ref_get(tmp_tunnel_id, &vrid_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get VRID[%d] reference, err = %s\n",
                       tunnel_impl_get_underlay_vrid(tunnel_attr_p), sx_status_str(err));
            goto out;
        }

        err = sdk_router_vrid_impl_refcnt_dec(tunnel_impl_get_underlay_vrid(tunnel_attr_p), &vrid_ref);
        if (err) {
            SX_LOG_ERR("Failed to decrease reference for VRID[%d], err = %s\n",
                       tunnel_impl_get_underlay_vrid(tunnel_attr_p),
                       sx_status_str(err));
            goto out;
        }
    }

    if (SX_TUNNEL_TYPE_IPINIP_CHECK(tmp_tunnel_id)) {
        err = tunnel_impl_get_ipinip_overlay_rif(tunnel_attr_p, &ipinip_overlay_rif);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] overlay RIF, err = %s\n", tmp_tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_rif_ref_get(tmp_tunnel_id, &rif_ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get RIF of tunnel [%d], err = %s\n",
                       tmp_tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_rif_impl_ref_decrease(ipinip_overlay_rif, &rif_ref);
        if (err) {
            SX_LOG_ERR("Failed to reference for RIF[%d], err = %s\n",
                       ipinip_overlay_rif, sx_status_str(err));
            goto out;
        }

        err = sdk_rif_impl_tunnel_attach_set(SX_ACCESS_CMD_DELETE, ipinip_overlay_rif, tunnel_attr_p);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to rollback attach overlay RIF[%d] for tunnel, err = %s\n",
                       ipinip_overlay_rif, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tunnel_impl_delete_action(sx_tunnel_id_t tunnel_id, const sdk_db_tunnel_data_t * tunnel_params_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t tunnel_attr;
    sdk_ref_t             ref;

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_attr);
    SX_MEM_CLR(ref);

    SX_MEM_CPY(tunnel_attr, tunnel_params_p->tun_attr);

    if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
        err = sdk_tunnel_db_vrid_ref_get(tunnel_id, &ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get VRID[%d] reference, err = %s\n",
                       tunnel_impl_get_underlay_vrid(&tunnel_attr), sx_status_str(err));
            goto out;
        }

        err = sdk_router_vrid_impl_refcnt_dec(tunnel_impl_get_underlay_vrid(&tunnel_attr), &ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to decrease VRID[%d] reference, err = %s\n",
                       tunnel_impl_get_underlay_vrid(&tunnel_attr), sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t __sdk_tunnel_impl_delete_action_rollback(sx_tunnel_id_t               tunnel_id,
                                                     const sdk_db_tunnel_data_t * tunnel_params_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t tunnel_attr;
    sdk_ref_t             ref;
    ref_name_data_t       ref_name_data = {.print_func_p = get_tunnel_ref_name,
                                           .ref_data_p = &tunnel_id,
                                           .data_size = sizeof(tunnel_id)};

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_attr);
    SX_MEM_CLR(ref);

    SX_MEM_CPY(tunnel_attr, tunnel_params_p->tun_attr);

    if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
        err = sdk_tunnel_db_vrid_ref_get(tunnel_id, &ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get VRID[%d] reference, err = %s\n",
                       tunnel_impl_get_underlay_vrid(&tunnel_attr), sx_status_str(err));
            goto out;
        }

        err = sdk_router_vrid_impl_refcnt_inc(tunnel_impl_get_underlay_vrid(&tunnel_attr), &ref_name_data, &ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to inc VRID[%d] reference, err = %s\n",
                       tunnel_impl_get_underlay_vrid(&tunnel_attr), sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_db_vrid_ref_set(tunnel_id, &ref);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to update DB VRID[%d] reference, err = %s\n",
                       tunnel_impl_get_underlay_vrid(&tunnel_attr), sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tunnel_impl_edit_action(sx_tunnel_id_t               tunnel_id,
                                          const sdk_db_tunnel_data_t * tunnel_params_p,
                                          sx_tunnel_attribute_t      * old_tunnel_attr,
                                          sx_tunnel_attribute_t      * new_tunnel_attr_p)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    sx_status_t     rollback_err = SX_STATUS_SUCCESS;
    sx_router_id_t  old_uvrid, new_uvrid;
    sdk_ref_t      *vrid_ref_p = NULL;
    boolean_t       router_vrid_impl_refcnt_dec_rollback = FALSE;
    ref_name_data_t ref_name_data = {.print_func_p = get_tunnel_ref_name,
                                     .ref_data_p = &tunnel_id,
                                     .data_size = sizeof(tunnel_id)};

    SX_LOG_ENTER();

    SX_MEM_CLR(old_uvrid);
    SX_MEM_CLR(new_uvrid);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_params_p, "tunnel_params_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_TUNNEL_DIRECTION_CHECK_ENCAP(tunnel_id)) {
        vrid_ref_p = (sdk_ref_t*)&tunnel_params_p->vrid_ref;

        old_uvrid = tunnel_impl_get_underlay_vrid(old_tunnel_attr);
        new_uvrid = tunnel_impl_get_underlay_vrid(new_tunnel_attr_p);

        if (old_uvrid != new_uvrid) {
            err = sdk_router_vrid_impl_refcnt_dec(old_uvrid, vrid_ref_p);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to decrease underlay VRID[%d] reference, err = %s\n",
                           old_uvrid, sx_status_str(err));
                goto out;
            }
            router_vrid_impl_refcnt_dec_rollback = TRUE;

            err = sdk_router_vrid_impl_refcnt_inc(new_uvrid, &ref_name_data, vrid_ref_p);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("Failed to increase VRID[%d] ref count, err = %s\n",
                           new_uvrid, sx_status_str(err));
                goto out;
            }
        }
    }

out:
    if (SX_STATUS_SUCCESS != err) {
        if (router_vrid_impl_refcnt_dec_rollback) {
            rollback_err = sdk_router_vrid_impl_refcnt_inc(old_uvrid, &ref_name_data, vrid_ref_p);
            if (SX_STATUS_SUCCESS != rollback_err) {
                SX_LOG_ERR("Failed to rollback edit tunnel on hardware, err = %s\n",
                           sx_status_str(rollback_err));
            }
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tunnel_impl_post_edit_action(sx_tunnel_id_t                tunnel_id,
                                               sx_tunnel_attribute_t       * old_tunnel_attr,
                                               const sx_tunnel_attribute_t * new_tunnel_attr_p)
{
    UNUSED_PARAM(tunnel_id);
    UNUSED_PARAM(old_tunnel_attr);
    UNUSED_PARAM(new_tunnel_attr_p);

    return SX_STATUS_SUCCESS;
}

sx_status_t __sdk_tunnel_impl_edit_action_rollback(sx_tunnel_id_t                tunnel_id,
                                                   const sdk_db_tunnel_data_t  * tunnel_params_p,
                                                   sx_tunnel_attribute_t       * old_tunnel_attr,
                                                   const sx_tunnel_attribute_t * new_tunnel_attr_p)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    sx_router_id_t  old_uvrid, new_uvrid;
    sdk_ref_t      *vrid_ref_p = NULL;
    ref_name_data_t ref_name_data = {.print_func_p = get_tunnel_ref_name,
                                     .ref_data_p = &tunnel_id,
                                     .data_size = sizeof(tunnel_id)};

    SX_LOG_ENTER();

    SX_MEM_CLR(old_uvrid);
    SX_MEM_CLR(new_uvrid);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_params_p, "tunnel_params_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    vrid_ref_p = (sdk_ref_t *)&tunnel_params_p->vrid_ref;
    old_uvrid = tunnel_impl_get_underlay_vrid(old_tunnel_attr);
    new_uvrid = tunnel_impl_get_underlay_vrid(new_tunnel_attr_p);

    err = sdk_router_vrid_impl_refcnt_dec(new_uvrid, vrid_ref_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to rollback edit tunnel on hardware, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_router_vrid_impl_refcnt_inc(old_uvrid, &ref_name_data, vrid_ref_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to rollback edit tunnel on hardware, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tunnel_impl_check_learn_mode(sx_port_log_id_t log_port, sx_fdb_learn_mode_t learn_mode)
{
    sx_tunnel_id_t tunnel_id = SX_TUNNEL_ID_INVALID;
    sx_status_t    sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_status = sdk_tunnel_db_tunnel_id_by_log_port_get(log_port, &tunnel_id);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_DBG("Tunnel is not bound to log_port: 0x%x\n", log_port);
        sx_status = SX_STATUS_SUCCESS;
        goto out;
    }

    if (((SX_TUNNEL_TYPE_NVE_VXLAN_IPV6 == SX_TUNNEL_TYPE_ID_GET(tunnel_id)) ||
         (SX_TUNNEL_TYPE_NVE_NVGRE_IPV6 == SX_TUNNEL_TYPE_ID_GET(tunnel_id))) &&
        (SX_FDB_LEARN_MODE_DONT_LEARN != learn_mode)) {
        SX_LOG_ERR("Unsupported learn mode (%s) for VXLAN IPv6 tunnel\n",
                   sx_fdb_learn_mode_str(learn_mode));
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return sx_status;
}

static sx_status_t __sdk_tunnel_impl_counter_get(const sx_tunnel_id_t         tunnel_id,
                                                 const sdk_db_tunnel_data_t * tunnel_params_p,
                                                 boolean_t                    is_clear,
                                                 sx_tunnel_counter_t        * counter)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(tunnel_id);
    UNUSED_PARAM(tunnel_params_p);
    UNUSED_PARAM(is_clear);
    UNUSED_PARAM(counter);

    SX_LOG_ENTER();

    /* Nothing to do */

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tunnel_impl_init_hwd(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_tunnel_impl_register_hwd_ops(&sdk_hwd_tunnel_ops);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init tunnel, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tunneL_impl_attr_validate(sx_tunnel_attribute_t * tunnel_attr_p)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    sx_ether_type_t ethertype = 0;

    SX_LOG_ENTER();

    if (utils_check_pointer(tunnel_attr_p, "tunnel_attr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        if (tunnel_attr_p->attributes.ipinip_p2p.underlay_rif != 0) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("uRIF configuration is not supported, err= %s.\n", sx_status_str(err));
        }
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        if (tunnel_attr_p->attributes.ipinip_p2p_gre.underlay_rif != 0) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("uRIF configuration is not supported, err= %s.\n", sx_status_str(err));
        }
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.vxlan.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            SX_LOG_ERR("The check mask mode is not supported on this device.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        tunnel_attr_p->attributes.vxlan.decap.reserved_bits_check.mask = 0;

        if (tunnel_attr_p->attributes.vxlan.decap.egress_et_set != FALSE) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Setting the Ethertype after decapsulation at the egress port is not supported, error= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        if (tunnel_attr_p->attributes.vxlan.decap.tag_mode == SX_VLAN_TAG_MODE_802_1AD_E) {
            err = sx_port_ethertype_get(VLAN_ETHER_TYPE_INDEX_1, &ethertype);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to verify the .1AD EtherType is configured, error: (%s)\n",
                           sx_status_str(err));
                goto out;
            }
        }

        if (tunnel_attr_p->attributes.vxlan.encap.underlay_rif != 0) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Encap uRIF configuration is not supported, err= %s.\n", sx_status_str(err));
        }

        if (tunnel_attr_p->attributes.vxlan.decap.underlay_rif != 0) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Decap uRIF configuration is not supported, err= %s.\n", sx_status_str(err));
        }
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.vxlan_gpe.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            SX_LOG_ERR("The check mask mode is not supported on this device.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        tunnel_attr_p->attributes.vxlan_gpe.decap.reserved_bits_check.mask = 0;

        if (tunnel_attr_p->attributes.vxlan_gpe.decap.egress_et_set != FALSE) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Setting the Ethertype after decapsulation at the egress port is not supported, error= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        if (tunnel_attr_p->attributes.vxlan_gpe.decap.tag_mode == SX_VLAN_TAG_MODE_802_1AD_E) {
            err = sx_port_ethertype_get(VLAN_ETHER_TYPE_INDEX_1, &ethertype);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to verify the .1AD EtherType is configured, error: (%s)\n",
                           sx_status_str(err));
                goto out;
            }
        }

        if (tunnel_attr_p->attributes.vxlan_gpe.encap.underlay_rif != 0) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Encap uRIF configuration is not supported, err= %s.\n", sx_status_str(err));
        }

        if (tunnel_attr_p->attributes.vxlan_gpe.decap.underlay_rif != 0) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Decap uRIF configuration is not supported, err= %s.\n", sx_status_str(err));
        }
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.geneve.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            SX_LOG_ERR("The check mask mode is not supported on this device.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        tunnel_attr_p->attributes.geneve.decap.reserved_bits_check.mask = 0;

        if (tunnel_attr_p->attributes.geneve.decap.egress_et_set != FALSE) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Setting the Ethertype after decapsulation at the egress port is not supported, error= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        if (tunnel_attr_p->attributes.geneve.decap.tag_mode == SX_VLAN_TAG_MODE_802_1AD_E) {
            err = sx_port_ethertype_get(VLAN_ETHER_TYPE_INDEX_1, &ethertype);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to verify the .1AD EtherType is configured, error: (%s)\n",
                           sx_status_str(err));
                goto out;
            }
        }

        if (tunnel_attr_p->attributes.geneve.encap.underlay_rif != 0) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Encap uRIF configuration is not supported, err= %s.\n", sx_status_str(err));
        }

        if (tunnel_attr_p->attributes.geneve.decap.underlay_rif != 0) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Decap uRIF configuration is not supported, err= %s.\n", sx_status_str(err));
        }
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        if (SX_TUNNEL_NVE_RESERVED_BITS_MODE_RANGE_CHECK(tunnel_attr_p->attributes.nvgre.decap.
                                                         reserved_bits_check.mode) != TRUE) {
            SX_LOG_ERR("Invalid an NVE reserved bits check mode [%u].\n",
                       tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mode);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mode ==
            SX_TUNNEL_NVE_RESERVED_BITS_MODE_CHECK_MASK_E) {
            SX_LOG_ERR("The check mask mode is not supported on this device.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        tunnel_attr_p->attributes.nvgre.decap.reserved_bits_check.mask = 0;

        if (tunnel_attr_p->attributes.nvgre.decap.egress_et_set != FALSE) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Setting the Ethertype after decapsulation at the egress port is not supported, error= %s.\n",
                       sx_status_str(err));
            goto out;
        }

        if (tunnel_attr_p->attributes.nvgre.decap.tag_mode == SX_VLAN_TAG_MODE_802_1AD_E) {
            err = sx_port_ethertype_get(VLAN_ETHER_TYPE_INDEX_1, &ethertype);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to verify the .1AD EtherType is configured, error: (%s)\n",
                           sx_status_str(err));
                goto out;
            }
        }

        if (tunnel_attr_p->attributes.nvgre.encap.underlay_rif != 0) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Encap uRIF configuration is not supported, err= %s.\n", sx_status_str(err));
        }

        if (tunnel_attr_p->attributes.nvgre.decap.underlay_rif != 0) {
            err = SX_STATUS_UNSUPPORTED;
            SX_LOG_ERR("Decap uRIF configuration is not supported, err= %s.\n", sx_status_str(err));
        }
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        err = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Flex tunnel is not supported on this chip type.\n");
        break;

    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Not expected %s type, err= %s.\n", sx_tunnel_type_str(tunnel_attr_p->type), sx_status_str(err));
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}
static boolean_t __sdk_tunnel_impl_l3_gw_supported(sx_tunnel_id_t tunnel_id)
{
    boolean_t        supported = TRUE;
    sx_tunnel_type_e tunnel_type;

    SX_LOG_ENTER();

    tunnel_type = SX_TUNNEL_TYPE_ID_GET(tunnel_id);

    /* On Spectrum A0/A1 devices IPv6 at the L3 gateway is not supported
     *  so such configuration should be disabled.( We should prevent RIF creation
     *  when ipv6 tunnel exists and has mapping configured and vice a versa). */
    if ((tunnel_type == SX_TUNNEL_TYPE_NVE_VXLAN_IPV6) ||
        (tunnel_type == SX_TUNNEL_TYPE_NVE_NVGRE_IPV6)) {
        supported = FALSE;
        SX_LOG_ERR("Routing is not supported for VXLAN_IPv6 tunnel[0x%08x].\n",
                   tunnel_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return supported;
}

sx_status_t sdk_tunnel_impl_orig_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return status;
}
