/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_types.h>
#include <utils/sx_mem.h>
#include <utils/utils.h>
#include <utils/port_type_validate.h>
#include <ethl3/hwi/rif/rif_db.h>
#include <ethl3/hwi/rif/rif_impl.h>
#include <ethl3/hwi/sdk_router_vrid/sdk_router_vrid_impl.h>
#include <span/span.h>
#include "ethl2/port_db.h"
#include "tunnel_impl.h"
#include "tunnel_be.h"
#include "sdk_tunnel_impl.h"
#include "ulay_default_rif_tunnel_impl.h"
#include "sx/sdk/sx_status.h"
#include "flow_counter/flow_counter.h"
#include "complib/sx_log.h"
#include "decap_table_impl.h"
#include "ethl2/brg.h"
#include "ethl3/router_common.h"
#include "flex_parser/hwi/flex_parser_impl.h"

#undef  __MODULE__
#define __MODULE__ TUNNEL

#define IS_VALID_FLEX_TQ_PROFILE(_profile_)       \
    (((_profile_) == SX_COS_TQ_PROFILE_ID_0_E) || \
     ((_profile_) == SX_COS_TQ_PROFILE_ID_1_E) || \
     ((_profile_) == SX_COS_TQ_PROFILE_ID_2_E) || \
     ((_profile_) == SX_COS_TQ_PROFILE_ID_3_E))


/************************************************
 *  Global variables
 ***********************************************/

extern sx_brg_context_t brg_context;

/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

static sx_status_t __sdk_tunnel_check_init_params(const sx_tunnel_general_params_t * params_p);
static sx_status_t __sdk_tunnel_check_attr(sx_tunnel_attribute_t * tunnel_attr_p);
static sx_status_t __sdk_tunnel_get_underlay_sip(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                 sx_ip_addr_t                * sx_ip_addr);
static sx_ip_version_t __sdk_tunnel_type_to_ip_version(sx_tunnel_type_e type);

/************************************************
*  Function implementations
************************************************/

sx_status_t sdk_tunnel_be_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    sdk_tunnel_impl_log_verbosity_level_set(verbosity_level);
    sdk_tunnel_db_log_verbosity_level_set(verbosity_level);
    sdk_decap_table_impl_log_verbosity_level_set(verbosity_level);
    sdk_tunnel_impl_orig_log_verbosity_level_set(verbosity_level);
    sdk_ulay_default_rif_tunnel_impl_log_verbosity_level_set(verbosity_level);

    return status;
}

sx_status_t sdk_tunnel_be_log_verbosity_level_get(sx_verbosity_level_t * verbosity_level_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    if (utils_check_pointer(verbosity_level_p, "verbosity_level_p")) {
        status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);
out:
    return status;
}

sx_status_t sdk_tunnel_init_tunnel_ops(void)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.tunnel_init_ops_cb != NULL) {
        rc = brg_context.spec_cb_g.tunnel_init_ops_cb();
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in tunnel_init_ops(), error: %s\n", sx_status_str(rc));
            goto out;
        }
    }

out:

    SX_LOG_EXIT();
    return rc;
}

sx_status_t sdk_tunnel_init_hwd_ops(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_tunnel_impl_assign_hwd_ops();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init tunnel. HWD ops assign error, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_init(sx_tunnel_general_params_t * params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   initialised = FALSE;
    boolean_t   router_initialized = FALSE;

    SX_LOG_ENTER();

    sdk_tunnel_impl_params_get(&initialised);

    if (TRUE == initialised) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        /* There is no way to check if tunnel is already initialized unless try to init it again.
         * Thus, do not throw error to the log. */
        SX_LOG(SX_LOG_NOTICE, "Tunnel module already initialized\n");
        goto out;
    }

    if (utils_check_pointer(params_p, "params_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __sdk_tunnel_check_init_params(params_p);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = sdk_router_cmn_router_impl_is_initialized(&router_initialized);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to check if the router module is initialized, error: %s \n",
                   sx_status_str(err));
        goto out;
    }

    if (!router_initialized) {
        SX_LOG_ERR("The router module is not initialized. \n");
        err = SX_STATUS_ERROR;
        goto out;
    }

    err = sdk_tunnel_init_tunnel_ops();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init tunnel. Tunnel ops assign error, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_init_hwd_ops();
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to init tunnel. HWD ops assign error, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_impl_init(params_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to initialize tunnel module, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_deinit(boolean_t is_forced)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG_DBG("Deinitializes tunnel module, is_forced [%d]\n", is_forced);

    if (is_forced == FALSE) {
        if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
            goto out;
        }
    }

    err = sdk_tunnel_impl_deinit(is_forced);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deinitialize tunnel module, err = %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tunnel_get_underlay_sip(const sx_tunnel_attribute_t * tunnel_attr_p,
                                                 sx_ip_addr_t                * sx_ip_addr)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        SX_MEM_CPY_P(sx_ip_addr, &tunnel_attr_p->attributes.ipinip_p2p.encap.underlay_sip);
        break;

    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        SX_MEM_CPY_P(sx_ip_addr, &tunnel_attr_p->attributes.ipinip_p2p_gre.encap.underlay_sip);
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
        SX_MEM_CPY_P(sx_ip_addr, &tunnel_attr_p->attributes.vxlan.encap.underlay_sip);
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:
        SX_MEM_CPY_P(sx_ip_addr, &tunnel_attr_p->attributes.vxlan_gpe.encap.underlay_sip);
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:
        SX_MEM_CPY_P(sx_ip_addr, &tunnel_attr_p->attributes.geneve.encap.underlay_sip);
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        SX_MEM_CPY_P(sx_ip_addr, &tunnel_attr_p->attributes.nvgre.encap.underlay_sip);
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        SX_MEM_CPY_P(sx_ip_addr, &tunnel_attr_p->attributes.l2_flex.encap.underlay_sip);
        break;
    }

    return err;
}

static sx_status_t __sdk_tunnel_check_init_params(const sx_tunnel_general_params_t * params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (TRUE == params_p->nve.fdb_resolution_valid) {
        if (!SX_CHECK_MAX(params_p->nve.fdb_resolution_action, SX_ROUTER_ACTION_MAX)) {
            SX_LOG_ERR("Invalid FDB resolution action[%u] received.\n",
                       params_p->nve.fdb_resolution_action);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}
static sx_status_t __sdk_tunnel_check_attr(sx_tunnel_attribute_t * tunnel_attr_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_router_attributes_t      router_attr;
    sx_router_interface_param_t ifc;
    sx_router_id_t              vrid;
    sx_interface_attributes_t   ifc_attr;
    sx_ip_addr_t                underlay_sip;
    sx_port_info_t              port_info;
    boolean_t                   is_vrid_exist = FALSE;
    boolean_t                   sw_pending_del = FALSE;
    gc_state_t                  gc_state = GC_STATE_FREE;
    boolean_t                   ignore_pending_delete = FALSE;
    sx_router_interface_t       u_rif_id = 0;
    tunnel_flex_header_entry_t *tunnel_flex_header_entry_p = NULL;

    SX_LOG_ENTER();

    SX_MEM_CLR(router_attr);
    SX_MEM_CLR(ifc);
    SX_MEM_CLR(vrid);
    SX_MEM_CLR(ifc_attr);
    SX_MEM_CLR(underlay_sip);

    if (!SX_TUNNEL_DIRECTION_CHECK_RANGE(tunnel_attr_p->direction)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid tunnel direction %u\n",
                   tunnel_attr_p->direction);
        goto out;
    }

    if (!SX_TUNNEL_TYPE_CHECK_RANGE(tunnel_attr_p->type)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid tunnel type %d\n", tunnel_attr_p->type);
        goto out;
    }

    if (tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_ENCAP) {
        if (tunnel_impl_get_underlay_domain_type(tunnel_attr_p) == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_VRID) {
            err = sdk_router_vrid_impl_params_get(tunnel_impl_get_underlay_vrid(tunnel_attr_p),
                                                  &is_vrid_exist, &router_attr,
                                                  &gc_state, &sw_pending_del);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get router underlay_vrid[%d] attributes, err = %s\n",
                           tunnel_impl_get_underlay_vrid(tunnel_attr_p), sx_status_str(err));
                goto out;
            }

            if (is_vrid_exist == FALSE) {
                err = SX_STATUS_ENTRY_NOT_FOUND;
                SX_LOG_ERR("Tunnel underlay_vrid[%d] not found\n",
                           tunnel_impl_get_underlay_vrid(tunnel_attr_p));
                goto out;
            }

            if (gc_state != GC_STATE_EXISTS) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("VRID %u is in %s state\n",
                           tunnel_impl_get_underlay_vrid(tunnel_attr_p),
                           GC_STATE_STR(gc_state));
                goto out;
            }

            if (sw_pending_del == TRUE) {
                err = SX_STATUS_ENTRY_NOT_FOUND;
                SX_LOG(SX_LOG_ERROR, "Tunnel underlay Vrid [%d] - not found. sx_status:%s\n", vrid,
                       sx_status_str(err));
                goto out;
            }
        } else { /* SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF */
            err = tunnel_impl_get_underlay_rif(tunnel_attr_p, &u_rif_id);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get underlay encap RIF for tunnel, err = %s\n", sx_status_str(err));
                goto out;
            }

            err = sdk_rif_impl_get(u_rif_id, &vrid, &ifc, &ifc_attr, FALSE);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to get underlay encap RIF[%d], err = %s\n", u_rif_id, sx_status_str(err));
                goto out;
            }
        }

        err = __sdk_tunnel_get_underlay_sip(tunnel_attr_p, &underlay_sip);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't extract underlay_sip from tunnel attributes (wrong tunnel type)\n");
            goto out;
        }

        if ((underlay_sip.version == SX_IP_VERSION_IPV4) ||
            (underlay_sip.version == SX_IP_VERSION_IPV6)) {
            if (!IS_IP_ADDR_UNICAST(underlay_sip)) {
                err = SX_STATUS_UNSUPPORTED;
                SX_LOG_ERR("Invalid tunnel underlay_sip. Source IP must be unicast\n");
                goto out;
            }
        } else {
            err = SX_STATUS_UNSUPPORTED;
            goto out;
        }

        /* Validate that encap is supported for this type */
        if (SX_CHECK_MAX(tunnel_attr_p->type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
            if ((tunnel_attr_p->type != SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4) &&
                (tunnel_attr_p->type != SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE)) {
                SX_LOG_ERR("%s tunnel doesn't support encapsulation\n",
                           sx_tunnel_type_str(tunnel_attr_p->type));
                err = SX_STATUS_UNSUPPORTED;
                goto out;
            }
        }


        /* Validate IP type compatibility with tunnel type */
        if ((tunnel_attr_p->type == SX_TUNNEL_TYPE_NVE_VXLAN_IPV6) ||
            (tunnel_attr_p->type == SX_TUNNEL_TYPE_NVE_NVGRE_IPV6) ||
            (tunnel_attr_p->type == SX_TUNNEL_TYPE_L2_FLEX_IPV6)) {
            if (underlay_sip.version != SX_IP_VERSION_IPV6) {
                SX_LOG_ERR("%s tunnel doesn't support underlay SIP version %s\n",
                           sx_tunnel_type_str(tunnel_attr_p->type),
                           sx_ip_version_str(underlay_sip.version));
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        } else {
            if (underlay_sip.version != SX_IP_VERSION_IPV4) {
                SX_LOG_ERR("%s tunnel doesn't support underlay SIP version %s\n",
                           sx_tunnel_type_str(tunnel_attr_p->type),
                           sx_ip_version_str(underlay_sip.version));
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
    }

    if ((tunnel_impl_get_underlay_domain_type(tunnel_attr_p) == SX_TUNNEL_UNDERLAY_DOMAIN_TYPE_RIF) &&
        (tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_DECAP)) {
        err = tunnel_impl_get_underlay_decap_rif(tunnel_attr_p, &u_rif_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get underlay decap RIF for tunnel, err = %s\n", sx_status_str(err));
            goto out;
        }

        err = sdk_rif_impl_get(u_rif_id, &vrid, &ifc, &ifc_attr, FALSE);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get underlay decap RIF[%d], err = %s\n", u_rif_id, sx_status_str(err));
            goto out;
        }
    }

    if ((SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, tunnel_attr_p->type, SX_TUNNEL_TYPE_NVE_MAX)) &&
        (tunnel_impl_get_l2_log_port(tunnel_attr_p) != (sx_port_log_id_t)SX_TUNNEL_PORT_ID_NVE)) {
        SX_LOG_ERR("Port [0x%08x] is incompatible with NVE tunnels\n",
                   tunnel_impl_get_l2_log_port(tunnel_attr_p));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (tunnel_attr_p->type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:      /**< IPinIP Point 2 Point over IPv4 with GRE. */
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        if (tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_ENCAP) {
            if (!SX_CHECK_MAX(tunnel_attr_p->attributes.ipinip_p2p.encap.gre_mode,
                              SX_TUNNEL_IPINIP_GRE_MODE_MAX)) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Invalid tunnel gre_mode %d\n",
                           tunnel_attr_p->attributes.ipinip_p2p.encap.gre_mode);
                goto out;
            }
        }

        if (!SX_CHECK_BOOLEAN(tunnel_attr_p->attributes.ipinip_p2p.decap.gre_check_key)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid tunnel gre_check_key %d (must be boolean)\n",
                       tunnel_attr_p->attributes.ipinip_p2p.decap.gre_check_key);
            goto out;
        }

    /* fall through */
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:     /*< IPinIP P2P connected using IPv4 Over IPv4. */
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
        err = sdk_rif_impl_get(tunnel_attr_p->attributes.ipinip_p2p.overlay_rif,
                               &vrid, &ifc, &ifc_attr, ignore_pending_delete);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get overlay RIF[%d], err = %s\n",
                       tunnel_attr_p->attributes.ipinip_p2p.overlay_rif,
                       sx_status_str(err));
            goto out;
        }

        if (ifc.type != SX_L2_INTERFACE_TYPE_LOOPBACK) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("overlay RIF[%d] has invalid type %s\n",
                       tunnel_attr_p->attributes.ipinip_p2p.overlay_rif,
                       sx_router_interface_type_str(ifc.type));
            goto out;
        }

        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN:                /**< NVE VxLan */
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:           /**< NVE VxLan-IPv6 */

        /* Validate Port */
        VALIDATE_PORT(__sdk_tunnel_check_attr, tunnel_attr_p->attributes.vxlan.nve_log_port);

        if (SX_CHECK_FAIL(err = port_db_info_get(tunnel_attr_p->attributes.vxlan.nve_log_port, &port_info))) {
            SX_LOG_ERR("Can't Get Port %u Info (%s).\n", tunnel_attr_p->attributes.vxlan.nve_log_port,
                       sx_status_str(err));
            goto out;
        }
        break;

    case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:            /**< NVE VxLan-GPE */
        break;

    case SX_TUNNEL_TYPE_NVE_GENEVE:               /**< NVE Geneve */
        break;

    case SX_TUNNEL_TYPE_NVE_NVGRE:                /**< NVE Nvgre */
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
        /* Validate Port */
        VALIDATE_PORT(__sdk_tunnel_check_attr, tunnel_attr_p->attributes.nvgre.nve_log_port);

        if (SX_CHECK_FAIL(err = port_db_info_get(tunnel_attr_p->attributes.nvgre.nve_log_port, &port_info))) {
            SX_LOG_ERR("Can't Get Port %u Info (%s).\n", tunnel_attr_p->attributes.nvgre.nve_log_port,
                       sx_status_str(err));
            return M_UTILS_SX_LOG_EXIT(err);
        }
        break;

    case SX_TUNNEL_TYPE_L2_FLEX:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
        /* Validate Port */
        VALIDATE_PORT(__sdk_tunnel_check_attr, tunnel_attr_p->attributes.l2_flex.log_port);

        if (SX_CHECK_FAIL(err = port_db_info_get(tunnel_attr_p->attributes.l2_flex.log_port, &port_info))) {
            SX_LOG_ERR("Can't Get Port %u Info (%s).\n", tunnel_attr_p->attributes.l2_flex.log_port,
                       sx_status_str(err));
            return M_UTILS_SX_LOG_EXIT(err);
        }
        /* Check we have the correct log ports for the flex tunnels */
        if ((tunnel_attr_p->attributes.l2_flex.log_port != (sx_port_log_id_t)SX_TUNNEL_PORT_ID_FLEX0) &&
            (tunnel_attr_p->attributes.l2_flex.log_port != (sx_port_log_id_t)SX_TUNNEL_PORT_ID_FLEX1)) {
            SX_LOG_ERR("Port [0x%08x] is incompatible with Flex tunnels\n",
                       tunnel_attr_p->attributes.l2_flex.log_port);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (!IS_VALID_FLEX_TQ_PROFILE(tunnel_attr_p->attributes.l2_flex.tunnel_qos_profile.profile_id)) {
            SX_LOG_ERR("Flex tunnel cannot be configured with QoS profile [%u].\n",
                       tunnel_attr_p->attributes.l2_flex.tunnel_qos_profile.profile_id);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if (tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_ENCAP) {
            err = sdk_tunnel_db_tunnel_flex_header_get(tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                                                       &tunnel_flex_header_entry_p);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to get flex tunnel header [%u] for tunnel, err = [%s] \n",
                           tunnel_attr_p->attributes.l2_flex.encap.tunnel_flex_header_id,
                           sx_status_str(err));
                goto out;
            }

            /* Check the IP version matched the flex header */
            if (((tunnel_flex_header_entry_p->header_cfg.ip_version == SX_IP_VERSION_IPV4) &&
                 (tunnel_attr_p->type == SX_TUNNEL_TYPE_L2_FLEX_IPV6)) ||
                ((tunnel_flex_header_entry_p->header_cfg.ip_version == SX_IP_VERSION_IPV6) &&
                 (tunnel_attr_p->type == SX_TUNNEL_TYPE_L2_FLEX))) {
                SX_LOG_ERR("Flex tunnel %s doesn't match IP version of flex header\n",
                           sx_tunnel_type_str(tunnel_attr_p->type));
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid tunnel type %d\n", tunnel_attr_p->type);
        goto out;
    }

    err = sdk_tunnel_impl_attr_validate(tunnel_attr_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to validate tunnel attributes, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}


static sx_status_t __sdk_tunnel_check_edit_compatible_attr(const sx_tunnel_attribute_t * old_tunnel_attr_p,
                                                           const sx_tunnel_attribute_t * new_tunnel_attr_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    sx_port_log_id_t new_nve_log_port, old_nve_log_port;

    SX_LOG_ENTER();

    SX_MEM_CLR(new_nve_log_port);
    SX_MEM_CLR(old_nve_log_port);

    if (old_tunnel_attr_p->direction != new_tunnel_attr_p->direction) {
        SX_LOG_ERR("Tunnel direction cannot be changed\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if (old_tunnel_attr_p->type != new_tunnel_attr_p->type) {
        SX_LOG_ERR("Tunnel type cannot be changed\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if (SX_CHECK_MAX(old_tunnel_attr_p->type, SX_TUNNEL_TYPE_IPINIP_MAX)) {
        /* If tunnel symmetric or decap */
        if (old_tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_DECAP) {
            switch (old_tunnel_attr_p->type) {
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:     /**< IPinIP Point 2 Point over IPv4 with GRE. */
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4_WITH_GRE:
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
                if (memcmp(&old_tunnel_attr_p->attributes.ipinip_p2p_gre.decap,
                           &new_tunnel_attr_p->attributes.ipinip_p2p_gre.decap,
                           sizeof(sx_tunnel_ipinip_p2p_decap_attributes_t)) != 0) {
                    SX_LOG_ERR("Tunnel decap parameters cannot be changed\n");
                    err = SX_STATUS_UNSUPPORTED;
                    goto out;
                }
                break;

            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:     /*< IPinIP P2P connected using IPv4 Over IPv4. */
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV4:
                if (memcmp(&old_tunnel_attr_p->attributes.ipinip_p2p.decap,
                           &new_tunnel_attr_p->attributes.ipinip_p2p.decap,
                           sizeof(sx_tunnel_ipinip_p2p_decap_attributes_t)) != 0) {
                    SX_LOG_ERR("Tunnel decap parameters cannot be changed\n");
                    err = SX_STATUS_UNSUPPORTED;
                    goto out;
                }
                break;

            default:
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Invalid tunnel type %d\n", old_tunnel_attr_p->type);
                goto out;
            }
        }

        /* If tunnel symmetric or encap */
        if (old_tunnel_attr_p->direction & SX_TUNNEL_DIRECTION_ENCAP) {
            switch (old_tunnel_attr_p->type) {
            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_GRE:     /**< IPinIP Point 2 Point over IPv4 with GRE. */
                if (old_tunnel_attr_p->attributes.ipinip_p2p_gre.overlay_rif !=
                    new_tunnel_attr_p->attributes.ipinip_p2p_gre.overlay_rif) {
                    SX_LOG_ERR("Tunnel overlay_rif cannot be changed\n");
                    err = SX_STATUS_UNSUPPORTED;
                    goto out;
                }

                if (old_tunnel_attr_p->attributes.ipinip_p2p_gre.underlay_rif !=
                    new_tunnel_attr_p->attributes.ipinip_p2p_gre.underlay_rif) {
                    SX_LOG_ERR("Tunnel underlay_rif cannot be changed\n");
                    err = SX_STATUS_UNSUPPORTED;
                    goto out;
                }

                break;

            case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV4:     /*< IPinIP P2P connected using IPv4 Over IPv4. */
                if (old_tunnel_attr_p->attributes.ipinip_p2p.overlay_rif !=
                    new_tunnel_attr_p->attributes.ipinip_p2p.overlay_rif) {
                    SX_LOG_ERR("Tunnel overlay_rif cannot be changed\n");
                    err = SX_STATUS_UNSUPPORTED;
                    goto out;
                }

                if (old_tunnel_attr_p->attributes.ipinip_p2p.underlay_rif !=
                    new_tunnel_attr_p->attributes.ipinip_p2p.underlay_rif) {
                    SX_LOG_ERR("Tunnel underlay_rif cannot be changed\n");
                    err = SX_STATUS_UNSUPPORTED;
                    goto out;
                }
                break;

            default:
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Invalid tunnel type %d\n", old_tunnel_attr_p->type);
                goto out;
            }
        }
    }

    if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_NVE_MIN, old_tunnel_attr_p->type,
                       SX_TUNNEL_TYPE_NVE_MAX)) {
        switch (old_tunnel_attr_p->type) {
        case SX_TUNNEL_TYPE_NVE_VXLAN:     /**< NVE VxLan */
        case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:     /**< NVE VxLan-IPv6 */
            new_nve_log_port = new_tunnel_attr_p->attributes.vxlan.nve_log_port;
            old_nve_log_port = old_tunnel_attr_p->attributes.vxlan.nve_log_port;
            break;

        case SX_TUNNEL_TYPE_NVE_VXLAN_GPE:     /**< NVE VxLan-GPE */
            new_nve_log_port = new_tunnel_attr_p->attributes.vxlan_gpe.nve_log_port;
            old_nve_log_port = old_tunnel_attr_p->attributes.vxlan_gpe.nve_log_port;
            break;

        case SX_TUNNEL_TYPE_NVE_GENEVE:     /**< NVE GENEVE */
            new_nve_log_port = new_tunnel_attr_p->attributes.geneve.nve_log_port;
            old_nve_log_port = old_tunnel_attr_p->attributes.geneve.nve_log_port;
            break;

        case SX_TUNNEL_TYPE_NVE_NVGRE:     /**< NVE NVGRE */
        case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:     /**< NVE NVGRE */
            new_nve_log_port = new_tunnel_attr_p->attributes.nvgre.nve_log_port;
            old_nve_log_port = old_tunnel_attr_p->attributes.nvgre.nve_log_port;
            break;

        default:
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid tunnel type %d\n", old_tunnel_attr_p->type);
            goto out;
        }

        if (new_nve_log_port != old_nve_log_port) {
            SX_LOG_ERR("Tunnel nve_log_port [0x%08x] cannot be changed to [0x%08x]\n",
                       old_nve_log_port, new_nve_log_port);
            err = SX_STATUS_UNSUPPORTED;
            goto out;
        }
    }

    if (SX_CHECK_RANGE(SX_TUNNEL_TYPE_L2_FLEX_MIN, old_tunnel_attr_p->type,
                       SX_TUNNEL_TYPE_L2_FLEX_MAX)) {
        new_nve_log_port = new_tunnel_attr_p->attributes.l2_flex.log_port;
        old_nve_log_port = old_tunnel_attr_p->attributes.l2_flex.log_port;

        if (new_nve_log_port != old_nve_log_port) {
            SX_LOG_ERR("Flex tunnel log_port [0x%08x] cannot be changed to tunnel [0x%08x]\n",
                       old_nve_log_port, new_nve_log_port);
            err = SX_STATUS_UNSUPPORTED;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_tunnel_be_cos_attribute_check(const sx_tunnel_id_t         tunnel_id,
                                                       const sx_tunnel_cos_data_t * cos_data_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    int                         i = 0, j = 0;
    sx_trap_priority_t          prio = 0;
    const sdk_db_tunnel_data_t *tunnel_params_p = NULL;


    err = sdk_tunnel_db_get(tunnel_id, &tunnel_params_p, FALSE);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x] from DB, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (!(SX_COS_PRIO_CHECK_RANGE(cos_data_p->prio_color.priority))) {
        SX_LOG_ERR("Priority [%u] is invalid, \n", cos_data_p->prio_color.priority);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!(SX_COS_COLOR_CHECK_RANGE(cos_data_p->prio_color.color))) {
        SX_LOG_ERR("Color [%u] is invalid\n", cos_data_p->prio_color.color);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!(SX_COS_DSCP_CHECK_RANGE(cos_data_p->dscp_value))) {
        SX_LOG_ERR("DSCP [%u] is invalid\n", cos_data_p->dscp_value);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cos_data_p->dscp_rewrite != SX_COS_DSCP_REWRITE_PRESERVE_E) &&
        (cos_data_p->dscp_rewrite != SX_COS_DSCP_REWRITE_DISABLE_E) &&
        (cos_data_p->dscp_rewrite != SX_COS_DSCP_REWRITE_ENABLE_E)) {
        SX_LOG_ERR("DSCP rewrite [%u] is invalid\n", cos_data_p->dscp_rewrite);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (cos_data_p->param_type == SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E) {
        if (tunnel_params_p->tun_attr.direction == SX_TUNNEL_DIRECTION_DECAP) {
            SX_LOG_ERR("CoS attributes direction SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E is "
                       "not compatible with tunnel support direction - SX_TUNNEL_DIRECTION_DECAP\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if ((cos_data_p->dscp_action != SX_COS_DSCP_ACTION_COPY_E) &&
            (cos_data_p->dscp_action != SX_COS_DSCP_ACTION_SET_E)) {
            SX_LOG_ERR("DSCP action [%u] is invalid\n", cos_data_p->dscp_action);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        for (i = 0; i < COS_ECN_MAX_NUM + 1; ++i) {
            if (cos_data_p->cos_ecn_params.ecn_encap.ecn_encap_map[i].valid) {
                if (!(SX_COS_ECN_CHECK_RANGE(cos_data_p->cos_ecn_params.ecn_encap.ecn_encap_map[i].egress_ecn))) {
                    SX_LOG_ERR("ECN [%u] is invalid, i=%u\n",
                               cos_data_p->cos_ecn_params.ecn_encap.ecn_encap_map[i].egress_ecn,
                               i);
                    err = SX_STATUS_PARAM_ERROR;
                    goto out;
                }
            }
        }
    } else if (cos_data_p->param_type == SX_TUNNEL_COS_PARAM_TYPE_DECAP_E) {
        if (tunnel_params_p->tun_attr.direction == SX_TUNNEL_DIRECTION_ENCAP) {
            SX_LOG_ERR("QoS attr direction SX_TUNNEL_COS_PARAM_TYPE_DECAP_E is "
                       "not compatible with tunnel support direction - SX_TUNNEL_DIRECTION_ENCAP\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if ((cos_data_p->dscp_action != SX_COS_DSCP_ACTION_PRESERVE_E) &&
            (cos_data_p->dscp_action != SX_COS_DSCP_ACTION_COPY_E)) {
            SX_LOG_ERR("DSCP action [%u] is invalid\n", cos_data_p->dscp_action);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        for (i = 0; i < COS_ECN_MAX_NUM + 1; ++i) {
            for (j = 0; j < COS_ECN_MAX_NUM + 1; ++j) {
                if (cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].valid) {
                    if (!(SX_COS_ECN_CHECK_RANGE(cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].egress_ecn)))
                    {
                        SX_LOG_ERR("ECN [%u] is invalid, overlay=%u underlay=%u\n",
                                   cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].egress_ecn, i, j);
                        err = SX_STATUS_PARAM_ERROR;
                        goto out;
                    }

                    if (cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_enable) {
                        prio = cos_data_p->cos_ecn_params.ecn_decap.ecn_decap_map[i][j].trap_attr.prio;
                        if ((SX_TRAP_PRIORITY_HIGH != prio) && (SX_TRAP_PRIORITY_LOW != prio)) {
                            SX_LOG_ERR("ECN trap prio [%u] is invalid, overlay=%u underlay=%u\n", prio, i, j);
                            err = SX_STATUS_PARAM_ERROR;
                            goto out;
                        }
                    }
                }
            }
        }
    } else {
        SX_LOG_ERR("CoS param type [%u] is invalid.\n", cos_data_p->param_type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }


out:
    return err;
}

sx_status_t tunnel_impl_vrid_by_tunnel_id_get(const sx_tunnel_id_t tunnel_id, sx_router_id_t * vrid_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t       tunnel_attr;
    sx_router_interface_t       ipinip_overlay_rif;
    sx_router_interface_param_t rif_ifc;
    boolean_t                   ignore_pending_delete = FALSE;

    SX_LOG_ENTER();

    if (utils_check_pointer(vrid_p, "vrid_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_MEM_CLR(tunnel_attr);
    SX_MEM_CLR(ipinip_overlay_rif);
    SX_MEM_CLR(rif_ifc);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_impl_get(tunnel_id, &tunnel_attr);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] attributes, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = tunnel_impl_get_ipinip_overlay_rif(&tunnel_attr, &ipinip_overlay_rif);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't get tunnel[0x%08x] overlay RIF, err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

    err = sdk_rif_impl_get(ipinip_overlay_rif, vrid_p, &rif_ifc, NULL, ignore_pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed on getting RIF VRID info, err = [%s] (%d).\n",
                   sx_status_str(err), err);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_set(const sx_access_cmd_t   cmd,
                           sx_tunnel_attribute_t * tunnel_attr_p,
                           sx_tunnel_id_t        * tunnel_id_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t old_tunnel_attr;
    boolean_t             pending_delete = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(old_tunnel_attr);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (utils_check_pointer(tunnel_id_p, "tunnel_id_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG_DBG("Tunnel set CMD:%s\n", sx_access_cmd_str(cmd));

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        if (utils_check_pointer(tunnel_attr_p, "tunnel_attr_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }

        err = __sdk_tunnel_check_attr(tunnel_attr_p);
        if (err) {
            goto out;
        }

        err = sdk_tunnel_impl_create(tunnel_attr_p, tunnel_id_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to create %s %s tunnel\n",
                       sx_tunnel_type_str(tunnel_attr_p->type),
                       sx_tunnel_direction_str(tunnel_attr_p->direction));
            goto out;
        }

        break;

    case SX_ACCESS_CMD_DESTROY:
        err = sdk_tunnel_impl_delete(*tunnel_id_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to destroy tunnel[0x%08x]\n", *tunnel_id_p);
            goto out;
        }

        break;

    case SX_ACCESS_CMD_EDIT:
        if (utils_check_pointer(tunnel_attr_p, "tunnel_attr_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }

        err = sdk_tunnel_db_pending_delete_get(*tunnel_id_p, &pending_delete);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                       *tunnel_id_p, sx_status_str(err));
            goto out;
        }
        if (pending_delete) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                       *tunnel_id_p, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_impl_get(*tunnel_id_p, &old_tunnel_attr);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't get tunnel[0x%08x] attributes, err = %s\n", *tunnel_id_p, sx_status_str(err));
            goto out;
        }

        err = __sdk_tunnel_check_edit_compatible_attr(&old_tunnel_attr, tunnel_attr_p);
        if (err != SX_STATUS_SUCCESS) {
            goto out;
        }

        err = __sdk_tunnel_check_attr(tunnel_attr_p);
        if (err != SX_STATUS_SUCCESS) {
            goto out;
        }
        err = sdk_tunnel_impl_edit(*tunnel_id_p, tunnel_attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to edit tunnel[0x%08x]\n", *tunnel_id_p);
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Failed tunnel set. Unsupported command (%s)\n", sx_access_cmd_str(cmd));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_get(const sx_tunnel_id_t tunnel_id, sx_tunnel_attribute_t * tunnel_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   pending_delete = FALSE;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(tunnel_attr_p, "tunnel_attr_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_impl_get(tunnel_id, tunnel_attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get tunnel[0x%08x], err = %s\n", tunnel_id, sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tunnel_decap_rules_check_key(const sx_access_cmd_t               cmd,
                                               const sx_tunnel_decap_entry_key_t * entry_key)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_router_attributes_t router_attr;
    boolean_t              is_vrid_exist = FALSE;
    boolean_t              sw_pending_del = FALSE;
    gc_state_t             gc_state = GC_STATE_FREE;
    sx_ip_version_t        ip_version = SX_IP_VERSION_NONE;
    sx_ip_prefix_t         prefix;
    char                   addr_str[FORMAT_BUFFER_SIZE] = {0};
    char                   mask_str[FORMAT_BUFFER_SIZE] = {0};

    SX_LOG_ENTER();

    SX_MEM_CLR(router_attr);

    if (SX_CHECK_FAIL(err = utils_check_pointer(entry_key, "entry_key"))) {
        SX_LOG(SX_LOG_ERROR, "decap entry key is NULL\n");
        goto out;
    }

    if (!SX_TUNNEL_TYPE_CHECK_RANGE(entry_key->tunnel_type)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid decap table key tunnel type %d\n", entry_key->tunnel_type);
        goto out;
    }

    if (!SX_CHECK_MAX(entry_key->type, SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_MAX)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid decap table key fields %d\n", entry_key->type);
        goto out;
    }

    if (entry_key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET) {
        if (((SX_TUNNEL_IPINIP_DECAP_RULE_USER_PRIO_MIN) > entry_key->priority) ||
            ((SX_TUNNEL_IPINIP_DECAP_RULE_USER_PRIO_MAX) < entry_key->priority)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid decap table key priority %d for key type %d\n", entry_key->priority, entry_key->type);
            goto out;
        }
    } else if (entry_key->priority != 0) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid decap table key priority %d for key type %d\n", entry_key->priority, entry_key->type);
        goto out;
    }

    err = sdk_router_vrid_impl_params_get(entry_key->underlay_vrid,
                                          &is_vrid_exist, &router_attr, &gc_state, &sw_pending_del);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get router underlay_vrid[%d] attributes, err = %s\n",
                   entry_key->underlay_vrid, sx_status_str(err));
        goto out;
    }

    if (is_vrid_exist == FALSE) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Tunnel underlay_vrid[%d] not found\n", entry_key->underlay_vrid);
        goto out;
    }

    if (gc_state != GC_STATE_EXISTS) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("VRID %u is in %s state\n", entry_key->underlay_vrid, GC_STATE_STR(gc_state));
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_DESTROY) && (sw_pending_del == TRUE)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG(SX_LOG_ERROR, "Tunnel underlay Vrid [%d] - not found. sx_status:%s\n", entry_key->underlay_vrid,
               sx_status_str(err));
        goto out;
    }

    ip_version = __sdk_tunnel_type_to_ip_version(entry_key->tunnel_type);

    if (entry_key->underlay_dip.version != ip_version) {
        SX_LOG_ERR("%s tunnel does not support underlay dip version %s\n",
                   sx_tunnel_type_str(entry_key->tunnel_type),
                   sx_ip_version_str(entry_key->underlay_dip.version));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((entry_key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP) ||
        (entry_key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET)) {
        if (entry_key->underlay_sip.version != ip_version) {
            SX_LOG_ERR("%s tunnel does not support underlay sip version %s\n",
                       sx_tunnel_type_str(entry_key->tunnel_type),
                       sx_ip_version_str(entry_key->underlay_sip.version));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    if (entry_key->type == SX_TUNNEL_DECAP_KEY_FIELDS_TYPE_DIP_SIP_SUBNET) {
        sdk_router_utils_make_prefix_with_mask(&entry_key->underlay_dip, &entry_key->underlay_dip_mask, &prefix);
        if (!sdk_router_utils_check_network_prefix(&prefix)) {
            SX_LOG_ERR("Invalid destination [%s] subnet addr [%s] with mask [%s]\n", sx_ip_version_str(ip_version),
                       format_prefix(&prefix, addr_str), format_prefix_mask(&prefix, mask_str));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        sdk_router_utils_make_prefix_with_mask(&entry_key->underlay_sip, &entry_key->underlay_sip_mask, &prefix);
        if (!sdk_router_utils_check_network_prefix(&prefix)) {
            SX_LOG_ERR("Invalid source [%s] subnet addr [%s] with mask [%s]\n", sx_ip_version_str(ip_version),
                       format_prefix(&prefix, addr_str), format_prefix_mask(&prefix, mask_str));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    /* For flex tunnels we need to check if the fpp is used */
    if ((entry_key->tunnel_type == SX_TUNNEL_TYPE_L2_FLEX) ||
        (entry_key->tunnel_type == SX_TUNNEL_TYPE_L2_FLEX_IPV6)) {
        err = sdk_flex_parser_fpp_get(SX_ACCESS_CMD_GET,
                                      entry_key->tunnel_attributes.l2_flex_decap_attributes.fpp_id,
                                      NULL);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Invalid FPP [%u] used in Flex tunnel decap rule\n",
                       entry_key->tunnel_attributes.l2_flex_decap_attributes.fpp_id.fpp_id);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __sdk_tunnel_decap_rules_check_entry(const sx_tunnel_decap_entry_data_t * entry_data)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t    tunnel_attr;
    sx_span_session_params_t span_session_params;
    boolean_t                pending_delete = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(tunnel_attr);

    if (SX_CHECK_FAIL(err = utils_check_pointer(entry_data, "entry_data"))) {
        SX_LOG(SX_LOG_ERROR, "decap entry key is NULL\n");
        goto out;
    }

    err = sdk_tunnel_db_pending_delete_get(entry_data->tunnel_id, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                   entry_data->tunnel_id, sx_status_str(err));
        goto out;
    }

    if (pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                   entry_data->tunnel_id, sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_impl_get(entry_data->tunnel_id, &tunnel_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Invalid tunnel ID: %u \n", entry_data->tunnel_id);
        goto out;
    }

    if ((tunnel_attr.direction & SX_TUNNEL_DIRECTION_DECAP) != SX_TUNNEL_DIRECTION_DECAP) {
        SX_LOG_ERR("Decap rule is not supported for encap tunnel!\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    if (entry_data->counter_id != SX_FLOW_COUNTER_ID_INVALID) {
        err = flow_counter_is_exists(entry_data->counter_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Bad flow counter %u specified: %s\n", entry_data->counter_id, sx_status_str(err));
            goto out;
        }
    }

    if (SX_ROUTER_ACTION_SPAN == entry_data->action) {
        err = span_session_get(entry_data->span_session_id, &span_session_params);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Session ID %u does not exist\n", entry_data->span_session_id);
            goto out;
        }
    }

    if (!SX_CHECK_MAX(entry_data->action, SX_ROUTER_ACTION_MAX)) {
        SX_LOG_ERR("Invalid decap rule action: %u\n", entry_data->action);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_decap_rules_set(const sx_access_cmd_t                cmd,
                                       const sx_tunnel_decap_entry_key_t  * entry_key,
                                       const sx_tunnel_decap_entry_data_t * entry_data)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_LOG_DBG("Decap Table set CMD:%s\n", sx_access_cmd_str(cmd));

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (SX_CHECK_FAIL(err = __sdk_tunnel_decap_rules_check_key(cmd, entry_key))) {
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        if (SX_CHECK_FAIL(err = __sdk_tunnel_decap_rules_check_entry(entry_data))) {
            goto out;
        }

        err = decap_table_impl_add_entry(entry_key, entry_data);
        break;

    case SX_ACCESS_CMD_DESTROY:
        err = decap_table_impl_delete_entry(entry_key);
        break;

    case SX_ACCESS_CMD_EDIT:
        if (SX_CHECK_FAIL(err = __sdk_tunnel_decap_rules_check_entry(entry_data))) {
            goto out;
        }

        err = decap_table_impl_edit_entry(entry_key, entry_data);
        break;

    default:
        SX_LOG_ERR("Unsupported command (%s)\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sx_api_tunnel_decap_rules_set: sdk_tunnel_decap_rules_set cmd: %s failed. err %s.\n",
                   sx_access_cmd_str(cmd), sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_decap_rules_get(const sx_tunnel_decap_entry_key_t * entry_key,
                                       sx_tunnel_decap_entry_data_t      * entry_data)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = decap_table_impl_get_entry(entry_key, entry_data);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sx_api_tunnel_decap_rules_get: decap_table_impl_get_entry failed. err %s.\n",
                   sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}

/* Validate the parameters combinations before fetching the data from DB */
sx_status_t sdk_tunnel_decap_rule_iter_get(const sx_access_cmd_t                  cmd,
                                           const sx_tunnel_decap_entry_key_t      key,
                                           const sx_tunnel_decap_entry_filter_t * filter_p,
                                           sx_tunnel_decap_entry_key_t          * rule_list_p,
                                           uint32_t                             * rule_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    decap_table_total_size = 0;

    SX_LOG_ENTER();

    /* Basic validation of tunnel init */
    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }
    /* Ensure count pointer is valid */
    if (utils_check_pointer(rule_cnt_p, "rule_cnt_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    /* If count is non-zero then we must ensure return pointer is valid */
    if (*rule_cnt_p) {
        if (utils_check_pointer(rule_list_p, "rule_list_p")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
    }

    /* Get the total DB size */
    err = decap_table_rule_total_count_get(&decap_table_total_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("decap_table_rule_total_count_get failed. err %s.\n", sx_status_str(err));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*rule_cnt_p > 0) {
            /* Get cmd only supports count of 0,1. So lets set it to 1 */
            *rule_cnt_p = 1;
        } else {
            /* Count of 0 with GET implies return total count provided filter is NULL */
            if (!filter_p) {
                *rule_cnt_p = decap_table_total_size;
                goto out;
            }
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*rule_cnt_p == 0) {
            /* Already checked in API level. This is additional safety check
             * Simply return success with empty list. */
            goto out;
        } else {
            /* Ensure count is within bounds */
            if (*rule_cnt_p > decap_table_total_size) {
                *rule_cnt_p = decap_table_total_size;
            }
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported cmd %s.\n", sx_access_cmd_str(cmd));
        goto out;
    }

    err = decap_table_impl_rule_iter_get(cmd, key, filter_p, rule_list_p, rule_cnt_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Tunnel Decap Rule Key Iter Get Failed \n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_counter_get(const sx_access_cmd_t cmd,
                                   const sx_tunnel_id_t  tunnel_id,
                                   sx_tunnel_counter_t * counter)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   is_clear = FALSE;
    boolean_t   pending_delete = FALSE;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(counter, "counter")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG_DBG("Tunnel counter get CMD: %s\n", sx_access_cmd_str(cmd));
    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Failed tunnel counter get. Unsupported command\n");
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        is_clear = TRUE;
    }

    err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }
    if (pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_impl_capability_check(tunnel_id, SX_TUNNEL_CAP_COUNTER_READ_E);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get counters for tunnel[0x%08x]\n", tunnel_id);
        goto out;
    }

    err = sdk_tunnel_impl_counter_get(tunnel_id, is_clear, counter);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed get counter tunnel[0x%08x], err = %s\n", tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

void sdk_tunnel_debug_dump(dbg_dump_params_t * dbg_dump_params_p)
{
    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_dbg_params(dbg_dump_params_p))) {
        goto out;
    }

    dbg_utils_pprinter_module_header_print(dbg_dump_params_p->stream, "TUNNEL");
    sdk_tunnel_impl_debug_dump(dbg_dump_params_p);

out:
    SX_LOG_EXIT();
}

sx_status_t sdk_tunnel_map_set(const sx_access_cmd_t         cmd,
                               const sx_tunnel_id_t          tunnel_id,
                               const sx_tunnel_map_entry_t * map_entries_p,
                               const uint32_t                map_entries_cnt)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   pending_delete = FALSE;

    SX_LOG_ENTER();
    SX_LOG_DBG("Map entry set CMD:%s\n", sx_access_cmd_str(cmd));

    if (utils_check_pointer(map_entries_p, "map_entries_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        SX_LOG_ERR("Map set cannot be used for Flex tunnels[0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        if (pending_delete) {
            err = SX_STATUS_ENTRY_NOT_FOUND;
            SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }

        err = sdk_tunnel_impl_mapping_add(tunnel_id, map_entries_p, map_entries_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("sx_api_tunnel_map_set: sdk_tunnel_map_set cmd: %s failed. err %s.\n",
                       sx_access_cmd_str(cmd), sx_status_str(err));
        }

        break;

    case SX_ACCESS_CMD_DELETE:
        err = sdk_tunnel_impl_mapping_delete(tunnel_id, map_entries_p, map_entries_cnt);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("sx_api_tunnel_map_set: sdk_tunnel_map_set cmd: %s failed. err %s.\n",
                       sx_access_cmd_str(cmd), sx_status_str(err));
        }

        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        err = sdk_tunnel_impl_mapping_delete_all(tunnel_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("sx_api_tunnel_map_set: sdk_tunnel_map_set cmd: %s failed. err %s.\n",
                       sx_access_cmd_str(cmd), sx_status_str(err));
        }

        break;

    default:
        SX_LOG_ERR("Unsupported command (%s)\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_map_get(const sx_access_cmd_t   cmd,
                               const sx_tunnel_id_t    tunnel_id,
                               sx_tunnel_map_entry_t   map_entry_key,
                               sx_tunnel_map_entry_t * map_entries_p,
                               uint32_t              * map_entries_cnt)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   pending_delete = FALSE;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel id [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(map_entries_cnt, "map_entries_cnt")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        SX_LOG_ERR("Map get cannot be used for Flex tunnels[0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (*map_entries_cnt == 0) {
        err = sdk_tunnel_db_map_entries_list_get(tunnel_id, NULL, map_entries_cnt, FALSE);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("Failed to get count of map list from tunnel[0x%08x], err = %s\n",
                       tunnel_id, sx_status_str(err));
            goto out;
        }
        goto out;
    } else if (*map_entries_cnt > TUNNEL_MAP_GET_MAX_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Number of entries to retrieve (%u) is greater than (%u), err = %s\n",
                   *map_entries_cnt, TUNNEL_MAP_GET_MAX_NUM, sx_status_str(err));
        goto out;
    }

    if (utils_check_pointer(map_entries_p, "map_entries_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET_FIRST:
        err = sdk_tunnel_impl_mapping_get_first(tunnel_id, map_entries_p, map_entries_cnt);
        break;

    case SX_ACCESS_CMD_GETNEXT:
        err = sdk_tunnel_impl_mapping_get_next(tunnel_id, map_entry_key, map_entries_p, map_entries_cnt);
        break;

    default:
        SX_LOG_ERR("Unsupported command (%s)\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sx_api_tunnel_map_get: sdk_tunnel_map_get cmd: %s failed. err %s.\n",
                   sx_access_cmd_str(cmd), sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_ttl_set(const sx_tunnel_id_t tunnel_id, const sx_tunnel_ttl_data_t * ttl_data_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t tunnel_attr;
    boolean_t             pending_delete = FALSE;

    SX_MEM_CLR(tunnel_attr);

    SX_LOG_ENTER();

    if (utils_check_pointer(ttl_data_p, "ttl_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG_DBG("Tunnel[0x%x] set TTL params [dir = %d, cmd = %d, value = %d]\n", tunnel_id,
               ttl_data_p->direction, ttl_data_p->ttl_cmd, ttl_data_p->ttl_value);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        SX_LOG_ERR("TTL set cannot be used for Flex tunnels[0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    /* Currently we support only global TTL configuration,
     * but at least check here that tunnel ID is valid.
     */
    err = sdk_tunnel_impl_get(tunnel_id, &tunnel_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Invalid tunnel ID [0x%x]\n", tunnel_id);
        goto out;
    }

    if (!SX_TUNNEL_DIRECTION_CHECK_RANGE(ttl_data_p->direction)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid TTL direction %u\n", ttl_data_p->direction);
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_TUNNEL_TTL_CMD_MIN, ttl_data_p->ttl_cmd, SX_TUNNEL_TTL_CMD_MAX)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid TTL cmd [%u]\n", ttl_data_p->ttl_cmd);
        goto out;
    }

    err = sdk_tunnel_impl_ttl_set(tunnel_id, ttl_data_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set TTL config for the tunnel 0x%x, err - %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_ttl_get(const sx_tunnel_id_t tunnel_id, sx_tunnel_ttl_data_t * ttl_data_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t tunnel_attr;
    boolean_t             pending_delete = FALSE;

    SX_MEM_CLR(tunnel_attr);

    SX_LOG_ENTER();

    if (utils_check_pointer(ttl_data_p, "ttl_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    SX_LOG_DBG("Tunnel[0x%x] get TTL params\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }
    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        SX_LOG_ERR("TTL get cannot be used for Flex tunnels[0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    /* Currently we support only global TTL configuration,
     * but at least check here that tunnel ID is valid.
     */
    err = sdk_tunnel_impl_get(tunnel_id, &tunnel_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Invalid tunnel ID [0x%x]\n", tunnel_id);
        goto out;
    }

    if (!SX_TUNNEL_DIRECTION_CHECK_RANGE(ttl_data_p->direction)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid TTL direction %u\n", ttl_data_p->direction);
        goto out;
    }

    err = sdk_tunnel_impl_ttl_get(tunnel_id, ttl_data_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get TTL config for the tunnel 0x%x, err - %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_hash_set(const sx_tunnel_id_t tunnel_id, const sx_tunnel_hash_data_t * hash_data_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t tunnel_attr;
    boolean_t             pending_delete = FALSE;

    SX_MEM_CLR(tunnel_attr);

    SX_LOG_ENTER();

    if (utils_check_pointer(hash_data_p, "hash_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG_DBG("Tunnel[0x%x] set hash params [field_type = %u cmd = %u]\n", tunnel_id,
               hash_data_p->hash_field_type, hash_data_p->hash_cmd);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        SX_LOG_ERR("Hash set cannot be used for Flex tunnels[0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    /* Currently we support only global HASH configuration,
     * but at least check here that tunnel ID is valid.
     */
    err = sdk_tunnel_impl_get(tunnel_id, &tunnel_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Invalid tunnel ID [0x%x]\n", tunnel_id);
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_TUNNEL_HASH_FIELD_TYPE_MIN, hash_data_p->hash_field_type,
                        SX_TUNNEL_HASH_FIELD_TYPE_MAX)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid hash field value %u\n", hash_data_p->hash_field_type);
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_TUNNEL_HASH_CMD_MIN, hash_data_p->hash_cmd, SX_TUNNEL_HASH_CMD_MAX)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid hash cmd [%u]\n", hash_data_p->hash_cmd);
        goto out;
    }

    err = sdk_tunnel_impl_hash_set(tunnel_id, hash_data_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set hash config for the tunnel 0x%x, err - %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_hash_get(const sx_tunnel_id_t tunnel_id, sx_tunnel_hash_data_t * hash_data_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_tunnel_attribute_t tunnel_attr;
    boolean_t             pending_delete = FALSE;

    SX_MEM_CLR(tunnel_attr);

    SX_LOG_ENTER();

    if (utils_check_pointer(hash_data_p, "hash_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    SX_LOG_DBG("Tunnel[0x%x] get hash params\n", tunnel_id);

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* Currently we support only global hash configuration,
     * but at least check here that tunnel ID is valid.
     */

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        SX_LOG_ERR("Hash get cannot be used for Flex tunnels[0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    if (pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_impl_get(tunnel_id, &tunnel_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Invalid tunnel ID [0x%x]\n", tunnel_id);
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_TUNNEL_HASH_FIELD_TYPE_MIN, hash_data_p->hash_field_type,
                        SX_TUNNEL_HASH_FIELD_TYPE_MAX)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid hash field value %u\n", hash_data_p->hash_field_type);
        goto out;
    }

    err = sdk_tunnel_impl_hash_get(tunnel_id, hash_data_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get hash config for the tunnel 0x%x, err - %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_cos_set(const sx_tunnel_id_t tunnel_id, const sx_tunnel_cos_data_t * cos_data_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    boolean_t   pending_delete = FALSE;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(cos_data_p, "cos_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        SX_LOG_ERR("CoS set cannot be used for Flex tunnels[0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_pending_delete_get(tunnel_id, &pending_delete);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get a state of the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }
    if (pending_delete) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("Failed to find the tunnel[0x%08x], err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = __sdk_tunnel_be_cos_attribute_check(tunnel_id, cos_data_p);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to set tunnel[0x%08x] CoS attribute in BE, attribute check failed. err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    err = sdk_tunnel_impl_cos_set(tunnel_id, cos_data_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sx_api_tunnel_cos_set: sdk_tunnel_cos_set failed. err %s.\n",
                   sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_cos_get(const sx_tunnel_id_t tunnel_id, sx_tunnel_cos_data_t * cos_data_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    const sdk_db_tunnel_data_t *tunnel_params_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* coverity[result_independent_of_operands] */
    if (!(SX_TUNNEL_ID_RANGE_CHECK(tunnel_id))) {
        SX_LOG_ERR("Invalid tunnel ID [0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (utils_check_pointer(cos_data_p, "cos_data_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_TUNNEL_TYPE_L2_FLEX_CHECK(tunnel_id)) {
        SX_LOG_ERR("CoS get cannot be used for Flex tunnels[0x%08x]\n", tunnel_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = sdk_tunnel_db_get(tunnel_id, &tunnel_params_p, FALSE);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("BE Failed to get tunnel[0x%08x] from DB, err = %s\n",
                   tunnel_id, sx_status_str(err));
        goto out;
    }

    switch (tunnel_params_p->tun_attr.direction) {
    case SX_TUNNEL_DIRECTION_ENCAP:
        if (cos_data_p->param_type == SX_TUNNEL_COS_PARAM_TYPE_DECAP_E) {
            SX_LOG_ERR("BE tunnel[0x%08x] direction is encap, decap CoS param type is not supported.\n",
                       tunnel_id);
            goto out;
        }
        break;

    case SX_TUNNEL_DIRECTION_DECAP:
        if (cos_data_p->param_type == SX_TUNNEL_COS_PARAM_TYPE_ENCAP_E) {
            SX_LOG_ERR("BE tunnel[0x%08x] direction is decap, encap CoS param type is not supported.\n",
                       tunnel_id);
            goto out;
        }
        break;

    case SX_TUNNEL_DIRECTION_SYMMETRIC:
        break;

    default:
        SX_LOG_ERR("Can't retrieve CoS attribute. Unsupported tunnel direction: %u.\n",
                   tunnel_params_p->tun_attr.direction);
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    err = sdk_tunnel_impl_cos_get(tunnel_id, cos_data_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("sx_api_tunnel_cos_get: sdk_tunnel_cos_get failed. err %s.\n",
                   sx_status_str(err));
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_iter_get(const sx_access_cmd_t      cmd,
                                const sx_tunnel_id_t       tunnel_id,
                                const sx_tunnel_filter_t * filter_p,
                                sx_tunnel_id_t           * tunnel_id_list_p,
                                uint32_t                 * tunnel_id_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(tunnel_id_cnt_p, "tunnel_id_cnt_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sdk_tunnel_db_iter_get(cmd, tunnel_id, filter_p, tunnel_id_list_p, tunnel_id_cnt_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get tunnel iterator\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_object_refcount_get(const sx_object_id_t * object_p, uint32_t * refcount_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (utils_check_pointer(object_p, "object_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (utils_check_pointer(refcount_p, "refcount_p")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = sdk_tunnel_impl_object_refcount_get(object_p, refcount_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get a value of ref count, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_flex_header_set(sx_access_cmd_t              cmd,
                                       sx_tunnel_flex_header_cfg_t *header_cfg,
                                       sx_tunnel_flex_header_id_t  *header_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    SX_LOG_DBG("Tunnel header set CMD:%s\n", sx_access_cmd_str(cmd));

    if (cmd != SX_ACCESS_CMD_DESTROY) {
        if ((header_cfg->ip_version != SX_IP_VERSION_IPV4) &&
            (header_cfg->ip_version != SX_IP_VERSION_IPV6)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid tunnel flex header IP version [%u]\n", header_cfg->ip_version);
            goto out;
        }
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        err = sdk_tunnel_impl_flex_header_create(header_cfg, header_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed flex tunnel header create EMT [%u]\n",
                       header_cfg->tunnel_header_emt_id.emt_id);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_EDIT:
        err = sdk_tunnel_impl_flex_header_edit(*header_id, header_cfg);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed flex tunnel header edit [%u]\n", *header_id);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        err = sdk_tunnel_impl_flex_header_destroy(*header_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed flex tunnel header destroy [%u]\n", *header_id);
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Failed tunnel set. Unsupported command (%s)\n", sx_access_cmd_str(cmd));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_tunnel_flex_header_get(const sx_tunnel_flex_header_id_t header_id,
                                       sx_tunnel_flex_header_cfg_t     *header_cfg)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    tunnel_flex_header_entry_t *tunnel_flex_header_entry_p = NULL;

    SX_LOG_ENTER();

    if ((err = sdk_tunnel_check_init()) != SX_STATUS_SUCCESS) {
        goto out;
    }

    err = sdk_tunnel_db_tunnel_flex_header_get(header_id, &tunnel_flex_header_entry_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get flex tunnel header [%u], err = [%s] \n",
                   header_id, sx_status_str(err));
        goto out;
    }

    *header_cfg = tunnel_flex_header_entry_p->header_cfg;

out:
    SX_LOG_EXIT();
    return err;
}


static sx_ip_version_t __sdk_tunnel_type_to_ip_version(sx_tunnel_type_e type)
{
    sx_ip_version_t ip_version = SX_IP_VERSION_NONE;

    switch (type) {
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_IPV6:
    case SX_TUNNEL_TYPE_NVE_VXLAN_IPV6:
    case SX_TUNNEL_TYPE_NVE_NVGRE_IPV6:
    case SX_TUNNEL_TYPE_L2_FLEX_IPV6:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV4_IN_IPV6_WITH_GRE:
    case SX_TUNNEL_TYPE_IPINIP_P2P_IPV6_IN_GRE:
        ip_version = SX_IP_VERSION_IPV6;
        break;

    default:
        ip_version = SX_IP_VERSION_IPV4;
        break;
    }

    return ip_version;
}
