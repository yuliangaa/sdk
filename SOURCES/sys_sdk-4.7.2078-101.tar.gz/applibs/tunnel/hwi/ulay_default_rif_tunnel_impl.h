/*
 * Copyright (C) 2011-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __HWI_ULAY_DEFAULT_RIF_TUNNEL_IMPL_H__
#define __HWI_ULAY_DEFAULT_RIF_TUNNEL_IMPL_H__

#include <sx/sdk/sx_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/*
 * Init tunneling module ops function callback structure.
 */
sx_status_t ulay_default_rif_tunnel_init_ops(void);
sx_status_t ulay_default_rif_tunnel_init_ops_spectrum4(void);

sx_status_t sdk_ulay_default_rif_tunnel_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

#endif      /* __HWI_ULAY_DEFAULT_RIF_TUNNEL_IMPL_H__ */
