/*
 * Copyright (C) 2011-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sx_reg_bulk/sx_reg_bulk.h"

#undef __MODULE__
#define __MODULE__ IPV6_MGR

#include "hwd_ipv6_mgr_reg.h"
#include "ethl2/fdb_common.h"

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/
sx_status_t hwd_ipv6_mgr_reg_log_verbosity_level_set(sx_verbosity_level_t verbosity)
{
    SX_LOG_ENTER();

    LOG_VAR_NAME(__MODULE__) = verbosity;

    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}

sx_status_t hwd_ipv6_mgr_rips_reg_write(sxd_access_cmd_t access_cmd, struct ku_rips_reg *ku_rips)
{
    SX_FDB_FOR_EACH_LEAF_DEV_VARS;
    sx_status_t        err = SX_STATUS_SUCCESS;
    sxd_status_t       sxd_status = SXD_STATUS_SUCCESS;
    sxd_reg_meta_t     reg_meta[SX_DEVICE_ID_COUNT];
    struct ku_rips_reg rips_reg_data[SX_DEVICE_ID_COUNT];

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(ku_rips, "ku_rips"))) {
        goto out;
    }

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Cannot retrieve device list [%s].\n", sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;
    SX_MEM_CLR(reg_meta[dev_idx]);
    reg_meta[dev_idx].dev_id = dev_info_arr[dev_idx].dev_id;
    reg_meta[dev_idx].access_cmd = access_cmd;
    /* no need to clear rips_reg_data[dev_idx] because it is fully overwritten */
    SX_MEM_CPY_P(&rips_reg_data[dev_idx], ku_rips);
    SX_FDB_FOR_EACH_LEAF_DEV_END;


    sxd_status = sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_RIPS_E,
                                                     rips_reg_data,
                                                     reg_meta,
                                                     dev_info_arr_size,
                                                     NULL,
                                                     NULL);
    if (SXD_CHECK_FAIL(sxd_status)) {
        SX_LOG_ERR("Failed to RIPS set: [%s].\n", SXD_STATUS_MSG(sxd_status));
        err = sxd_status_to_sx_status(sxd_status);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}
