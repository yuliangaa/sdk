/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "ethl2/lag.h"
#include "ethl2/vlan.h"
#include "ethl2/vlan_db.h"
#include "ethl2/la_db.h"
#include "ethl2/port.h"
#include "ethl2/port_db.h"
#include "ethl2/fdb.h"
#include "ethl2/fdb_common.h"
#include "../utils/utils.h"
#include "../utils/port_type_validate.h"
#include "ethl2/brg.h"
#include "ethl2/port_uc_route.h"
#include "policer/policer_manager.h"
#include "span.h"
#include "span_db.h"
#include <include/resource_manager/resource_manager.h>
#include "resource_manager/resource_manager_sdk_table.h"
#include <complib/cl_mem.h>
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include <sx/utils/sx_utils_status.h>
#include <sx/sdk/sx_status_convertor.h>
#include <sx/sxd/sxd_dpt.h>
#include "sx_core/sx_core_api.h"
#include "dbg_dump_modules/dbg_dump_modules.h"
#include "sx_reg_bulk/sx_reg_bulk.h"
#include "truncation_profile/truncation_profile.h"

#undef __MODULE__
#define __MODULE__ SPAN

/************************************************
 *  Local Type definitions
 ***********************************************/

/*
 *
 */
typedef enum span_module_init {
    SPAN_MODULE_INIT_ORIGINAL,  /* original state when neither span_init_set */
                                /* nor span_deinit_set has been called;      */
                                /* either of them may be called and SPAN     */
                                /* operations are permitted                  */
    SPAN_MODULE_INIT_YES,       /* span_init_set has been called, may not be */
                                /* called again in this state, SPAN          */
                                /* operations are permitted                  */
    SPAN_MODULE_INIT_NO,        /* span_deinit_set has been called, may not  */
                                /* be called again in this state, SPAN       */
                                /* operations are not permitted              */
} span_module_init_t;

/************************************************
 *  Local Macros
 ***********************************************/
#define VALIDIATE_MODULE_INITIALIZED()                  \
    if (FALSE == span_init_done) {                      \
        err = SX_STATUS_MODULE_UNINITIALIZED;           \
        SX_LOG_NTC("Module span is not initialized\n"); \
        goto out;                                       \
    }                                                   \

#define SPAN_BUILD_PORT_LABEL_INFO_1U(LABEL_PORT, SPLIT_NUM) \
    (((LABEL_PORT & 0x3FF) << 4) | SPLIT_NUM)
#define SPAN_BUILD_PORT_LABEL_INFO_MODULAR(SLOT_ID, LABEL_PORT, SPLIT_NUM) \
    (((SLOT_ID & 0xF) << 9) | ((LABEL_PORT & 0x1F) << 4) | SPLIT_NUM)
#define SPAN_ERSPAN_V2_DEVICE_UID_MASK 0x00FFFFFF
#define SPAN_ERSPAN_V2_DEVICE_UID_VALIDATE(x) \
    ((x &                                     \
      (~SPAN_ERSPAN_V2_DEVICE_UID_MASK)) ? SX_STATUS_PARAM_ERROR : SX_STATUS_SUCCESS)
/************************************************
 *  Global variables
 ***********************************************/

extern sx_brg_context_t brg_context;
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local variables
 ***********************************************/
boolean_t span_init_done;

/* This variable is used to enforce no consecutive calls to span_init_set or span_deinit_set */
static span_module_init_t g_init_set = SPAN_MODULE_INIT_ORIGINAL;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __dump_module_span_wrapper(dbg_dump_params_t *dbg_dump_params_p);

static sx_status_t __span_add(sx_span_session_id_t    * span_session_id_p,
                              sx_span_session_params_t *span_session_params);
static sx_status_t __span_modify_simple(const sx_span_session_id_t span_session_id,
                                        sx_span_session_params_t  *span_session_params);
static sx_status_t __span_modify_with_move(const sx_span_session_id_t       span_session_id,
                                           sx_span_session_params_t        *span_session_params,
                                           sx_port_log_id_t                *new_analyzer_port_p,
                                           span_analyzer_port_set_params_t *port_params_p);
static sx_status_t __span_modify(const sx_span_session_id_t       span_session_id,
                                 sx_span_session_params_t        *span_session_params,
                                 sx_port_log_id_t                *new_analyzer_port_p,
                                 span_analyzer_port_set_params_t *port_params_p);
static sx_status_t __span_delete(const sx_span_session_id_t span_session_id);
static sx_status_t __span_get(sx_span_session_id_t span_session_id,
                              span_session_info_t *span_session_info,
                              sx_port_log_id_t    *analyzer_port,
                              uint32_t            *mirrors_num,
                              span_mirror_t       *mirrors_arr,
                              uint32_t            *ref_cnt);

sx_status_t span_db_validate_mirror_port(const span_mirror_t *mirror_p, boolean_t *is_mirror_port_p);
static sx_status_t span_validate_mirror_header_padding_cb_wrapper(
    const sx_span_session_params_t *span_session_params_p);

sx_status_t span_db_mirror_port_add(const span_mirror_t       *mirror,
                                    const sx_span_session_id_t span_session_id,
                                    const boolean_t            enable);
static sx_utils_status_t __span_gc_delete_cb(const void *gc_context);
static sx_status_t __span_egress_mirror_alloc_buffer_cb_event(adviser_event_e event_type, void *param);
static sx_status_t __span_egress_mirror_alloc_buffer(const sx_access_cmd_t  cmd,
                                                     const sx_port_log_id_t mirror_port,
                                                     const sx_port_width_t  port_width);
static sx_status_t __span_port_mirror_label_update(sx_port_id_t log_port);
static sx_status_t __handle_molp(sx_port_id_t log_port, uint16_t label_port);
static sx_status_t __handle_pllp(sx_port_id_t log_port,
                                 uint8_t     *slot_num_p,
                                 uint16_t    *label_port_p,
                                 uint8_t     *split_num_p);
static sx_status_t __handle_mmgcr(sx_span_attrs_t *attr_p);
static sx_status_t __span_session_oper_state_from_port(const sx_port_log_id_t        analyzer_port,
                                                       sx_span_session_oper_state_t *session_oper_state);
static sx_status_t __validate_analyzer_port(const sx_port_log_id_t log_port);
static sx_status_t __span_get_lag_by_member(const sx_port_id_t port_log_id, sx_port_id_t *lag_port_log_id_p);
static sx_status_t __span_analyzer_oper_state_change_callback(adviser_event_e event_type, void *param_p);
static sx_status_t __span_analyzer_prio_mapping_change_callback(adviser_event_e event_type, void *param_p);
static sx_status_t __span_analyzer_multiport_update_job_scedule(const sx_port_oper_state_t oper_state,
                                                                const sx_port_id_t         port_log_id);
static sx_status_t __span_attributes_validate(sx_span_attrs_t *attr_p);

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t span_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return err;
}

sx_status_t span_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    VALIDATE_POINTER_NOT_NULL(verbosity_level_p);

    *verbosity_level_p = LOG_VAR_NAME(__MODULE__);

out:
    return err;
}

sx_status_t span_cnv_simple_to_full_mirror_direction(sx_mirror_direction_t simple_md, span_mirror_direction_t *full_md)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(full_md);

    switch (simple_md) {
    case SX_SPAN_MIRROR_INGRESS:
        *full_md = SPAN_MIRROR_DIRECTION_INGRESS;
        break;

    case SX_SPAN_MIRROR_EGRESS:
        *full_md = SPAN_MIRROR_DIRECTION_EGRESS;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_cnv_full_to_simple_mirror_direction(span_mirror_direction_t full_md,
                                                     sx_mirror_direction_t  *simple_md)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(simple_md);

    switch (full_md) {
    case SPAN_MIRROR_DIRECTION_INGRESS:
        *simple_md = SX_SPAN_MIRROR_INGRESS;
        break;

    case SPAN_MIRROR_DIRECTION_EGRESS:
        *simple_md = SX_SPAN_MIRROR_EGRESS;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __span_device_ready_callback(adviser_event_e event_type, void *param)
{
    sx_dev_info_t           *dev_info_p = NULL;
    uint32_t                 i;
    sx_span_session_id_t     span_session_id;
    sx_span_session_id_int_t span_session_id_int;
    span_session_info_t      span_session_info;
    sx_port_log_id_t         analyzer_port;
    uint32_t                 mirrors_num;
    span_mirror_t           *mirrors_arr = NULL;
    boolean_t                admin_state;
    uint32_t                 ref_cnt;
    boolean_t                is_mirror_port = FALSE;
    sx_status_t              err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(event_type);

    dev_info_p = (sx_dev_info_t*)(param);

    if ((dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE) ||
        (dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE_LOCAL)) {
        return SX_STATUS_SUCCESS;
    }

    for (span_session_id = 0;
         span_session_id <= rm_resource_global.span_session_id_max_external;
         span_session_id++) {
        mirrors_num = 0;
        err = __span_get(span_session_id,  &span_session_info, &analyzer_port,
                         &mirrors_num, NULL,
                         &ref_cnt);
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_DBG("__span_get for span_session_id %d not found.\n",
                       span_session_id);
            err = SX_STATUS_SUCCESS;
            continue;
        } else if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__span_get for span_session_id %d failed, err: %s. \n",
                       span_session_id, sx_status_str(err));
            goto out;
        }

        if (span_session_info.admin_state == FALSE) {
            continue;
        }

        /* config the SPAN in HW */
        err = __span_modify_simple(span_session_id, &(span_session_info.params));
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__span_modify_simple for span_session_id %d failed, err: %s. \n",
                       span_session_id, sx_status_str(err));
            goto out;
        }

        /* if no Mirror are attached continue */
        if (mirrors_num == 0) {
            continue;
        }

        M_UTILS_CLR_MEM_GET(&(mirrors_arr), 1, mirrors_num * sizeof(span_mirror_t),
                            UTILS_MEM_TYPE_ID_SPAN_E,   "Failed to allocate mirrors_arr memory\n", err);
        if (SX_CHECK_FAIL(err)) {
            err = SX_STATUS_NO_MEMORY;
            goto out;
        }

        err = __span_get(span_session_id,  &span_session_info, &analyzer_port,
                         &mirrors_num, mirrors_arr,
                         &ref_cnt);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__span_get for span_session_id %d failed, err: %s. \n",
                       span_session_id, sx_status_str(err));
            goto out;
        }

        /* Look up internal session */
        err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
        if (err) {
            goto out;
        }
        if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
            SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                       span_session_id, span_session_id_int);
            err = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }

        /* set the Mirrors */
        for (i = 0; i < mirrors_num; i++) {
            span_db_validate_mirror_port(&mirrors_arr[i], &is_mirror_port);
            if (is_mirror_port == FALSE) {
                err = span_db_mirror_bound_update(mirrors_arr[i].mirror_direction,
                                                  span_session_id_int,
                                                  span_session_id_int);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("span_db_mirror_bind_update(direction [%u], span %d, ...)  failed. err: %s\n",
                               mirrors_arr[i].mirror_direction, span_session_id_int, sx_status_str(err));
                    goto out;
                }
                continue;
            }
            err = span_db_mirror_get(&mirrors_arr[i], NULL, NULL, &admin_state);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("span_db_mirror_get(0x%x, %d) failed, err: %s. \n",
                           mirrors_arr[i].log_port, mirrors_arr[i].mirror_direction, sx_status_str(err));
                goto out;
            }
            err = span_db_mirror_port_add(&mirrors_arr[i], span_session_id_int, admin_state);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("__span_db_mirror_port_add(port [0x%x], span %d, ...)  failed. err: %s\n",
                           mirrors_arr[i].log_port, span_session_id_int, sx_status_str(err));
                goto out;
            }
        }

        if (mirrors_arr) {
            M_UTILS_MEM_PUT(mirrors_arr, UTILS_MEM_TYPE_ID_SPAN_E, "Deallocating mirrors_arr", err);
            mirrors_arr = NULL;
        }
    }

out:
    if (mirrors_arr) {
        M_UTILS_MEM_PUT(mirrors_arr, UTILS_MEM_TYPE_ID_SPAN_E, "Deallocating mirrors_arr", err);
    }
    SX_LOG_EXIT();
    return err;
}


sx_status_t __span_device_del_callback(adviser_event_e event_type, void *param)
{
    sx_dev_info_t *dev_info_p = NULL;

    SX_LOG_ENTER();

    UNUSED_PARAM(event_type);

    dev_info_p = (sx_dev_info_t*)(param);

    if ((dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE) ||
        (dev_info_p->node_type == SX_DEV_NODE_TYPE_SPINE_LOCAL)) {
        return SX_STATUS_SUCCESS;
    }

    SX_LOG_EXIT();
    return SX_STATUS_SUCCESS;
}

static sx_status_t __span_mirror_enable_type_to_mirror_direction(sx_span_mirror_enable_type_e enable_type,
                                                                 span_mirror_direction_t     *direction_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (!direction_p) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (enable_type) {
    case SX_SPAN_MIRROR_ENABLE_ING_WRED_E:
        *direction_p = SPAN_MIRROR_DIRECTION_INGRESS_WRED;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_UC_E:
        *direction_p = SPAN_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_MC_E:
        *direction_p = SPAN_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_PG_THRESHOLD_E:
        *direction_p = SPAN_MIRROR_DIRECTION_INGRESS_PG_CONGESTION;
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_TC_THRESHOLD_E:
        *direction_p = SPAN_MIRROR_DIRECTION_INGRESS_TC_CONGESTION;
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_ECN_E:
        *direction_p = SPAN_MIRROR_DIRECTION_EGRESS_ECN;
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_TC_LATENCY_E:
        *direction_p = SPAN_MIRROR_DIRECTION_EGRESS_TC_LATENCY;
        break;

    default:
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        break;
    }

out:
    return err;
}


static sx_status_t __span_port_add_callback(adviser_event_e event_type, void *param)
{
    sx_port_info_t *port_info_p = NULL;
    sx_status_t     err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    CL_ASSERT(event_type == ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E);

    port_info_p = (sx_port_info_t*)(param);

    if (SX_PORT_TYPE_ID_GET(port_info_p->id) != SX_PORT_TYPE_NETWORK) {
        /* for non network ports do nothing */
        goto out;
    }

    /* set mirroring port label */
    err = __span_port_mirror_label_update(port_info_p->id);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("fail __span_port_mirror_label_update port (0x%x) err(%s)\n",
                   port_info_p->id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __span_port_del_callback(adviser_event_e event_type, void *param)
{
    sx_port_info_t                 *port_info_p = NULL;
    sx_status_t                     err = SX_STATUS_SUCCESS;
    span_mirror_t                   mirror_port;
    sx_span_session_id_int_t        session_id = 0;
    boolean_t                       admin_state = FALSE;
    sx_span_probability_rate_t      rate = 0;
    span_mirror_direction_t         dir = SPAN_MIRROR_DIRECTION_MIN;
    uint32_t                        enable_type_tc_pg_en = 0;
    sx_span_mirror_enable_type_e    enable_type = SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E;
    sx_span_analyzer_port_params_t  sx_port_params;
    span_analyzer_port_set_params_t port_params;
    sx_span_session_id_t            session_id_arr[rm_resource_global.span_session_id_max_external + 1];
    uint32_t                        session_num = rm_resource_global.span_session_id_max_external + 1;
    uint32_t                        i = 0;

    SX_LOG_ENTER();

    UNUSED_PARAM(event_type);

    port_info_p = (sx_port_info_t*)param;

    if (SX_PORT_TYPE_ID_GET(port_info_p->id) != SX_PORT_TYPE_NETWORK) {
        goto out;
    }

    /* Skip unmapped ports */
    if (SX_SWID_ID_DISABLED == port_info_p->swid_id) {
        SX_LOG_DBG("Skipping Port 0x%08X because it's not mapped\n", port_info_p->id);
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    /* Remove all directions of port from SPAN session */
    for (dir = SPAN_MIRROR_DIRECTION_MIN; dir <= SPAN_MIRROR_DIRECTION_MAX; dir++) {
        mirror_port.log_port = port_info_p->id;
        mirror_port.mirror_direction = dir;

        err = span_db_mirror_get(&mirror_port,
                                 &session_id,
                                 &rate,
                                 &admin_state);

        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            err = SX_STATUS_SUCCESS;
            continue;
        } else if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in span_db_mirror_get, err: %s\n", sx_status_str(err));
            goto out;
        }

        err = span_mirror_set_common(SX_ACCESS_CMD_DELETE,
                                     port_info_p->id,
                                     dir,
                                     session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in span_mirror_set_common log_port [0x%x], err: %s\n",
                       port_info_p->id, sx_status_str(err));
            goto out;
        }
    }

    /* Remove port from mirror enabled */
    for (enable_type = SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E;
         enable_type <= SX_SPAN_MIRROR_ENABLE_TYPE_MAX_E;
         enable_type++) {
        err = span_db_mirror_enable_port_get(port_info_p->id, enable_type,
                                             &enable_type_tc_pg_en);
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            err = SX_STATUS_SUCCESS;
            continue;
        } else if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in span_db_mirror_enable_port_get, err: %s\n", sx_status_str(err));
            goto out;
        }

        err = span_db_mirror_enable_port_remove(port_info_p->id, enable_type);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set mirror enable type %u, port 0x%x to FW.\n", enable_type, port_info_p->id);
            goto out;
        }
    }

    /* Remove analyzer port */
    SX_MEM_CLR(sx_port_params);
    SX_MEM_CLR(port_params);
    port_params.sx_port_params = &sx_port_params;
    err = span_analyzer_get(port_info_p->id, &sx_port_params, session_id_arr, &session_num);
    if (err == SX_STATUS_ENTRY_NOT_FOUND) {
        err = SX_STATUS_SUCCESS;
        goto out;
    }
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get the session list of the port 0x%x .\n", port_info_p->id);
        goto out;
    }
    for (i = 0; i < session_num; i++) {
        err = span_analyzer_set(SX_ACCESS_CMD_DELETE, port_info_p->id, &port_params, session_id_arr[i]);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to remove analyzer port 0x%x from the session %d.\n", port_info_p->id,
                       session_id_arr[i]);
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_port_mirror_label_update(sx_port_id_t log_port)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_port_info_t port_info;
    uint16_t       label_port = 0;   /* label_port is module + 1 */
    uint8_t        split_num = 0;
    uint16_t       port_label;  /* port_label is a label that is assigned to port */
    sx_swid_type_t swid_type = KU_SWID_TYPE_DISABLED;

    if (SX_PORT_TYPE_ID_GET(log_port) != SX_PORT_TYPE_NETWORK) {
        /* skip for non physical ports */
        goto out;
    }

    err = port_db_info_get(log_port, &port_info);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", log_port);
        goto out;
    }

    err = port_db_swid_type_get(port_info.swid_id, &swid_type);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Unable to get swid type, err[%s]\n",
                   sx_status_str(err));
        goto out;
    }

    /* MOLP register is supported only for Ethernet switches. */
    if (swid_type != KU_SWID_TYPE_ETHERNET) {
        goto out;
    }

    if (port_info.part_of_lag_fl) {
        port_label = SX_PORT_LAG_ID_GET(port_info.lag_log_port);
    } else if (port_info.usr_port_label_info.port_label != 0) {
        port_label = port_info.usr_port_label_info.port_label;
    } else {
        err = __handle_pllp(log_port, NULL,
                            &label_port, &split_num);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("PLLP failed for port 0x%08X. err: %s .\n",
                       log_port, sx_status_str(err));
            goto out;
        }

        if (port_info.mapping.slot == 0) {
            port_label = SPAN_BUILD_PORT_LABEL_INFO_1U(label_port, split_num);
        } else {
            port_label = SPAN_BUILD_PORT_LABEL_INFO_MODULAR(port_info.mapping.slot,
                                                            label_port, split_num);
        }
    }

    err = __handle_molp(log_port, port_label);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in __handle_molp for port %x, err: %s\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    port_info.sdk_port_label_info.port_label = port_label;
    port_info.fields = SX_PORT_INFO_FIELD_BIT_PORT_LABEL;
    err = port_db_info_set(log_port, &port_info, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("port_db_info_set failed. (err = %s).\n", sx_status_str(err));
        goto out;
    }

out:
    return err;
}

/**
 * This function is a callback for the lag sink port change event
 *
 * @param[in]  lag_port_log_id  - notify on this lag log port
 * @param[in]  event_type    - new event type (CREATE/DESTORY)
 * @param[in]  port_log_id   - notify on this logical port id
 * @param[in]  context_p     - adviser context to be called from callback
 *
 * @return sx_status_t
 */
sx_status_t __span_lag_port_update(IN sx_port_id_t          lag_port_log_id,
                                   IN lag_sink_event_type_e event_type,
                                   IN sx_port_id_t          port_log_id,
                                   IN void                 *context_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    span_mirror_t                mirror_lag_port;
    sx_span_session_id_int_t     span_dir_session_id[SPAN_MIRROR_DIRECTION_MAX - SPAN_MIRROR_DIRECTION_MIN + 1];
    boolean_t                    span_dir_enable[SPAN_MIRROR_DIRECTION_MAX - SPAN_MIRROR_DIRECTION_MIN + 1];
    boolean_t                    span_dir_found[SPAN_MIRROR_DIRECTION_MAX - SPAN_MIRROR_DIRECTION_MIN + 1];
    sx_span_probability_rate_t   span_dir_rate[SPAN_MIRROR_DIRECTION_MAX - SPAN_MIRROR_DIRECTION_MIN + 1];
    span_mirror_direction_t      dir, mirror_direction = 0;
    boolean_t                    enable_type_found[SPAN_DB_MIRROR_ENABLE_TYPE_NUM];
    uint32_t                     enable_type_tc_pg_en[SPAN_DB_MIRROR_ENABLE_TYPE_NUM];
    sx_span_mirror_enable_type_e enable_type;
    boolean_t                    is_local_span = FALSE;

    UNUSED_PARAM(context_p);

    SX_LOG_ENTER();

    SX_MEM_CLR(span_dir_rate);

    /* Check what mirrors exist for this LAG port */
    for (dir = SPAN_MIRROR_DIRECTION_MIN; dir <= SPAN_MIRROR_DIRECTION_MAX; dir++) {
        /* Check if LAG is defined for this direction */
        mirror_lag_port.log_port = lag_port_log_id;
        mirror_lag_port.mirror_direction = dir;

        err = span_db_mirror_get(&mirror_lag_port,
                                 &span_dir_session_id[dir - SPAN_MIRROR_DIRECTION_MIN],
                                 &span_dir_rate[dir - SPAN_MIRROR_DIRECTION_MIN],
                                 &span_dir_enable[dir - SPAN_MIRROR_DIRECTION_MIN]);

        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            span_dir_found[dir - SPAN_MIRROR_DIRECTION_MIN] = FALSE;
        } else if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in span_db_mirror_get, err: %s\n", sx_status_str(err));
            goto out;
        } else {
            span_dir_found[dir - SPAN_MIRROR_DIRECTION_MIN] = TRUE;
        }
    }

    for (enable_type = SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E;
         enable_type <= SX_SPAN_MIRROR_ENABLE_TYPE_MAX_E;
         enable_type++) {
        err = span_db_mirror_enable_port_get(lag_port_log_id, enable_type,
                                             &enable_type_tc_pg_en[enable_type - SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E]);
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            enable_type_found[enable_type - SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E] = FALSE;
        } else if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in span_db_mirror_enable_get, err: %s\n", sx_status_str(err));
            goto out;
        } else {
            enable_type_found[enable_type - SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E] = TRUE;
        }
    }

    err = SX_STATUS_SUCCESS;

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_PRE_PORT_ADDED_VALIDATIONS_E:

        /* Analyzer port (cannot be LAG port, Network port only):
         * Local span: Cannot be LAG member
         * Remote span: Can be LAG member */
        err = span_db_port_analyzer_is_local_get(port_log_id, &is_local_span);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in span_db_port_analyzer_is_local_get log_port [0x%x], err: %s\n",
                       port_log_id, sx_status_str(err));
            goto out;
        }
        if (is_local_span) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Failed to add log_port [0x%x] to LAG: port is local analyzer, err: %s\n",
                       port_log_id, sx_status_str(err));
            goto out;
        }

        err = SX_STATUS_SUCCESS;
        break;

    case LAG_SINK_EVENT_TYPE_LAG_POST_PORT_ADDED_E:

        /* if LAG is mirror , add new port to mirror */
        for (dir = SPAN_MIRROR_DIRECTION_MIN; dir <= SPAN_MIRROR_DIRECTION_MAX; dir++) {
            if (span_dir_found[dir - SPAN_MIRROR_DIRECTION_MIN]) {
                /* Allocate shared buffer if device type and mirror direction require it */
                err = span_egress_mirror_alloc_buffer_cb_wrapper(SX_ACCESS_CMD_ADD,
                                                                 port_log_id,
                                                                 dir,
                                                                 SPAN_EGRESS_MIRROR_BUFF_TYPE_SPAN_MIRROR);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "span_egress_mirror_alloc_buffer_cb_wrapper [cmd= ADD, port [0x%x] failed. err: %s]\n",
                        port_log_id,
                        sx_status_str(err));
                    goto out;
                }

                err = span_db_mirror_phy_port_set(port_log_id,
                                                  dir,
                                                  span_dir_session_id[dir - SPAN_MIRROR_DIRECTION_MIN],
                                                  span_dir_rate[dir - SPAN_MIRROR_DIRECTION_MIN],
                                                  span_dir_enable[dir - SPAN_MIRROR_DIRECTION_MIN]);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed in span_db_mirror_phy_port_set log_port [0x%x], err: %s\n",
                               port_log_id, sx_status_str(err));
                    goto out;
                }
            }
        }

        /* if LAG is mirror enabled, enable mirror on new port */
        for (enable_type = SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E;
             enable_type <= SX_SPAN_MIRROR_ENABLE_TYPE_MAX_E;
             enable_type++) {
            if (enable_type_found[enable_type - SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E]) {
                err = __span_mirror_enable_type_to_mirror_direction(enable_type, &mirror_direction);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to get mirror direction from mirror enable type %u.\n", enable_type);
                    goto out;
                }
                /* Allocate shared buffer if device type and mirror direction require it */
                err = span_egress_mirror_alloc_buffer_cb_wrapper(SX_ACCESS_CMD_ADD,
                                                                 port_log_id,
                                                                 mirror_direction,
                                                                 SPAN_EGRESS_MIRROR_BUFF_TYPE_SPAN_MIRROR);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "span_egress_mirror_alloc_buffer_cb_wrapper [cmd= ADD, port [0x%x] failed. err: %s]\n",
                        port_log_id,
                        sx_status_str(err));
                    goto out;
                }

                err = span_db_mirror_enable_phy_port_set(port_log_id, enable_type,
                                                         enable_type_tc_pg_en[enable_type -
                                                                              SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E]);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to set mirror enable type %u, port 0x%x to FW.\n", enable_type, port_log_id);
                    goto out;
                }
            }
        }

        /* set mirroring port label */
        err = __span_port_mirror_label_update(port_log_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("fail lag_port_mirror_label_set for lag (%x) port (0x%x) CMD=ADD error (%s)\n",
                       lag_port_log_id, port_log_id, sx_status_str(err));
            goto out;
        }

        break;

    case LAG_SINK_EVENT_TYPE_LAG_PORT_REMOVED_E:

        /* if LAG is mirror , delete the port from mirror */
        for (dir = SPAN_MIRROR_DIRECTION_MIN; dir <= SPAN_MIRROR_DIRECTION_MAX; dir++) {
            if (span_dir_found[dir - SPAN_MIRROR_DIRECTION_MIN]) {
                /* Free shared buffer if allocated */
                err = span_egress_mirror_alloc_buffer_cb_wrapper(SX_ACCESS_CMD_DELETE,
                                                                 port_log_id,
                                                                 dir,
                                                                 SPAN_EGRESS_MIRROR_BUFF_TYPE_SPAN_MIRROR);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "span_egress_mirror_alloc_buffer_cb_wrapper [cmd=DELETE, port [0x%x] failed. err: %s]\n",
                        port_log_id,
                        sx_status_str(err));
                    goto out;
                }

                err = span_db_mirror_phy_port_set(port_log_id,
                                                  dir,
                                                  span_dir_session_id[dir - SPAN_MIRROR_DIRECTION_MIN],
                                                  span_dir_rate[dir - SPAN_MIRROR_DIRECTION_MIN],
                                                  FALSE);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed in span_db_mirror_phy_port_set log_port [0x%x], err: %s\n",
                               port_log_id, sx_status_str(err));
                    goto out;
                }
            }
        }

        /* if LAG is mirror enabled, remove mirror enable on the port */
        for (enable_type = SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E;
             enable_type <= SX_SPAN_MIRROR_ENABLE_TYPE_MAX_E;
             enable_type++) {
            if (enable_type_found[enable_type - SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E]) {
                err = __span_mirror_enable_type_to_mirror_direction(enable_type, &mirror_direction);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to get mirror direction from mirror enable type %u.\n", enable_type);
                    goto out;
                }
                /* Free shared buffer if allocated */
                err = span_egress_mirror_alloc_buffer_cb_wrapper(SX_ACCESS_CMD_DELETE,
                                                                 port_log_id,
                                                                 mirror_direction,
                                                                 SPAN_EGRESS_MIRROR_BUFF_TYPE_SPAN_MIRROR);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR(
                        "span_egress_mirror_alloc_buffer_cb_wrapper [cmd=DELETE, port [0x%x] failed. err: %s]\n",
                        port_log_id,
                        sx_status_str(err));
                    goto out;
                }
                err = span_db_mirror_enable_phy_port_set(port_log_id, enable_type, 0);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to set mirror enable type %u, port 0x%x to FW.\n", enable_type, port_log_id);
                    goto out;
                }
            }
        }

        /* set mirroring port label */
        err = __span_port_mirror_label_update(port_log_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("fail lag_port_mirror_label_set for lag (%x) port (0x%x) CMD=ADD error (%s)\n",
                       lag_port_log_id, port_log_id, sx_status_str(err));
            goto out;
        }

        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:

        /* Remove all directions of LAG port from SPAN session */
        for (dir = SPAN_MIRROR_DIRECTION_MIN; dir <= SPAN_MIRROR_DIRECTION_MAX; dir++) {
            if (span_dir_found[dir - SPAN_MIRROR_DIRECTION_MIN]) {
                err = span_mirror_set_common(SX_ACCESS_CMD_DELETE,
                                             lag_port_log_id,
                                             dir,
                                             span_dir_session_id[dir - SPAN_MIRROR_DIRECTION_MIN]);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("Failed in span_mirror_set_common lag_port [0x%x], err: %s\n",
                               lag_port_log_id, sx_status_str(err));
                    goto out;
                }
            }
        }

        /* Remove LAG port from mirror enabled */
        for (enable_type = SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E;
             enable_type <= SX_SPAN_MIRROR_ENABLE_TYPE_MAX_E;
             enable_type++) {
            if (enable_type_found[enable_type - SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E]) {
                err = span_db_mirror_enable_port_remove(lag_port_log_id, enable_type);
                if (err != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to set mirror enable type %u, port 0x%x to FW.\n", enable_type, port_log_id);
                    goto out;
                }
            }
        }
        /* Unadvise destroyed lag id */
        err = lag_sink_lag_unadvise(lag_port_log_id, __span_lag_port_update);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in lag_sink_lag_unadvise, err: %s\n", sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Wrong event type , event type: (%d)\n", event_type);
        err = SX_STATUS_CMD_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t __span_lag_global_update(IN sx_port_id_t          lag_port_log_id,
                                     IN lag_sink_event_type_e event_type,
                                     IN void                 *context_p)
{
    sx_status_t rc;

    UNUSED_PARAM(context_p);

    switch (event_type) {
    case LAG_SINK_EVENT_TYPE_LAG_CREATED_E:
        /* advise for the new lag */
        rc = lag_sink_lag_advise(lag_port_log_id, __span_lag_port_update,
                                 NULL, 0);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in lag_sink_lag_advise, err: %s\n", sx_status_str(rc));
            return rc;
        }
        break;

    case LAG_SINK_EVENT_TYPE_LAG_DESTROYED_E:
        break;

    default:
        SX_LOG_ERR(
            "Wrong event type, event type: (%d)\n",
            event_type);
        return SX_STATUS_CMD_ERROR;
    }

    return SX_STATUS_SUCCESS;
}

/**
 * This function initializes SPAN module.
 *
 */
sx_status_t span_init(sx_api_sx_sdk_init_t *init_params)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(init_params);

    SX_LOG_ENTER();

    if (TRUE == span_init_done) {
        SX_LOG_ERR("SPAN already  initialized !!!  %s \n",
                   sx_status_str(SX_STATUS_DB_ALREADY_INITIALIZED));
        err = SX_STATUS_DB_ALREADY_INITIALIZED;
        goto out;
    }

    DBG_DUMP_MODULES_REGISTER(err, SPAN, SPAN, span, FALSE, FALSE, FALSE);

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_READY_E,
                                 __span_device_ready_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_DEVICE_DEL_E,
                                 __span_device_del_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E,
                                 __span_port_add_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_PRE_PORT_DEL_FROM_SWID_E,
                                 __span_port_del_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD,
                                 ADVISER_EVENT_POST_PORT_ADMIN_STATE_CHANGE_E,
                                 __span_egress_mirror_alloc_buffer_cb_event);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to set up port admin state change adviser, rc = %s\n", sx_status_str(err));
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_PORT_OPER_DOWN_E,
                                 __span_analyzer_oper_state_change_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - POST_PORT_OPER_DOWN, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_PORT_OPER_UP_E,
                                 __span_analyzer_oper_state_change_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - POST_PORT_OPER_UP, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_ADD, ADVISER_EVENT_POST_PORT_TC_PRIO_MAP_CHANGE_E,
                                 __span_analyzer_prio_mapping_change_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - POST_PORT_TC_PRIO_MAP_CHANGE, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = lag_sink_global_advise(__span_lag_global_update, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in lag_sink_global_advise, err: %s \n", sx_status_str(err));
        goto out;
    }

    /*RM SPAN sessions management */
    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_SPAN_E].is_initialized = TRUE;
    err = rm_sdk_table_init_resource(RM_SDK_TABLE_TYPE_SPAN_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to init RM for %s\n",
                   SX_RESOURCE_MSG(RM_SDK_TABLE_TYPE_SPAN_E));
        goto out;
    }

    err = span_db_init();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in span_db_init, err: %s \n", sx_status_str(err));
        goto out;
    }

    if (brg_context.spec_cb_g.span_init_cb != NULL) {
        err = brg_context.spec_cb_g.span_init_cb();
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("span_init_cb not supported for this chip type.\n");
            goto out;
        }
    }

    span_init_done = TRUE;
    g_init_set = SPAN_MODULE_INIT_ORIGINAL;

out:
    return err;
}

/**
 * This function deinitializes brg.
 *
 */
sx_status_t span_deinit()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == span_init_done) {
        SX_LOG_ERR("span_deinit called when span isn't initialized!!!  %s \n",
                   sx_status_str(SX_STATUS_DB_NOT_INITIALIZED));
        err = SX_STATUS_MODULE_UNINITIALIZED;
        goto out;
    }

    /* Call the appropriate "span_deinit_set_cb" function for our current chip type */
    if (brg_context.spec_cb_g.span_deinit_set_cb != NULL) {
        err = brg_context.spec_cb_g.span_deinit_set_cb();
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in span_deinit_set_cb on chip type %s .\n",
                       sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
            goto out;
        }
    }

    err = adviser_register_event(SX_ACCESS_CMD_DELETE,
                                 ADVISER_EVENT_POST_PORT_ADMIN_STATE_CHANGE_E,
                                 __span_egress_mirror_alloc_buffer_cb_event);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to set up port admin state change adviser, rc = %s\n", sx_status_str(err));
    }

    err = span_db_deinit();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in span_db_init, err: %s \n", sx_status_str(err));
        goto out;
    }

    rm_resource_global.rm_sdk_tables_db[RM_SDK_TABLE_TYPE_SPAN_E].is_initialized = FALSE;
    err = rm_sdk_table_deinit_resource(RM_SDK_TABLE_TYPE_SPAN_E, TRUE);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinit span sessions in rm, err = %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = lag_sink_global_unadvise(__span_lag_global_update);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in lag_sink_global_unadvise, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_PRE_PORT_DEL_FROM_SWID_E,
                                 __span_port_del_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - remove advise, err: %s \n", sx_status_str(err));
        goto out;
    }

    err = adviser_register_event(SX_ACCESS_CMD_DELETE, ADVISER_EVENT_POST_PORT_ADD_INTO_SWID_E,
                                 __span_port_add_callback);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in adviser_register_event - advise, err: %s \n", sx_status_str(err));
        goto out;
    }


    g_init_set = SPAN_MODULE_INIT_ORIGINAL;
    span_init_done = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_is_initialized_get(boolean_t *is_initialized)
{
    if (is_initialized == NULL) {
        SX_LOG_ERR("is_initialized is NULL.\n");
        return SX_STATUS_PARAM_NULL;
    }

    *is_initialized = (g_init_set == SPAN_MODULE_INIT_YES);

    return SX_STATUS_SUCCESS;
}

sx_status_t span_session_set(sx_access_cmd_t           cmd,
                             sx_span_session_id_t     *span_session_id_p,
                             sx_span_session_params_t *span_session_params)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_status_t                     rb_err = SX_STATUS_SUCCESS;
    boolean_t                       rm_rollback = FALSE;
    span_analyzer_port_set_params_t port_params;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(span_session_id_p);
    VALIDATE_POINTER_NOT_NULL(span_session_params);

    VALIDIATE_MODULE_INITIALIZED();

    SX_MEM_CLR(port_params);

    /* Fail if module has been deinitialized - OK if neither init or deinit */
    /* was ever called                                                      */
    if (SPAN_MODULE_INIT_NO == g_init_set) {
        err = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("SPAN module not initialized\n");
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_DESTROY) || (cmd == SX_ACCESS_CMD_EDIT)) {
        if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(*span_session_id_p)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("span_session_id_p [%d] exceeds range [%d]\n",
                       *span_session_id_p,
                       rm_resource_global.span_session_id_max_external);
            goto out;
        }
    }
    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
        err = rm_entries_set(RM_SDK_TABLE_TYPE_SPAN_E, SX_ACCESS_CMD_ADD, 1, NULL);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR_RESOURCE_COND(err, "%s: rm_entries_set failed \n", __func__);
            goto out;
        }
        rm_rollback = TRUE;

        err = __span_add(span_session_id_p, span_session_params);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__span_add failed, err: %s. \n", sx_status_str(err));
            goto out;
        }

        break;

    case SX_ACCESS_CMD_EDIT:
        err = __span_modify(*span_session_id_p, span_session_params, NULL, &port_params);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__span_modify for span_session_id %d failed, err: %s. \n",
                       *span_session_id_p, sx_status_str(err));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
        err = __span_delete(*span_session_id_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__span_delete for span_session_id %d failed, err: %s. \n",
                       *span_session_id_p, sx_status_str(err));
            goto out;
        }

        err = rm_entries_set(RM_SDK_TABLE_TYPE_SPAN_E, SX_ACCESS_CMD_DELETE, 1, NULL);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR_RESOURCE_COND(err, "%s: rm_entries_set failed \n", __func__);
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d failed, err: %s. \n", cmd, sx_status_str(err));
        break;
    }

out:

    if (err && rm_rollback) {
        rb_err = rm_entries_set(RM_SDK_TABLE_TYPE_SPAN_E, SX_ACCESS_CMD_DELETE, 1, NULL);
        if (SX_STATUS_SUCCESS != rb_err) {
            SX_LOG_ERR("%s rollback: rm_entries_set failed, error: [%s] (%d) \n",
                       __func__, sx_status_str(rb_err), rb_err);
        }
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t span_session_get(sx_span_session_id_t span_session_id, sx_span_session_params_t    *span_session_params)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    span_session_info_t span_session_info;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(span_session_params);

    VALIDIATE_MODULE_INITIALIZED();

    if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("span_session_id [%d] exceeds range [%d]\n",
                   span_session_id,
                   rm_resource_global.span_session_id_max_external);
        goto out;
    }

    SX_MEM_CLR(span_session_info);

    err = __span_get(span_session_id,  &span_session_info,
                     NULL, NULL, NULL, NULL);
    if (span_session_info.gc_handle != NULL) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
    }
    if (err == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_DBG("__span_get for span_session_id %d not found. \n",
                   span_session_id);
        goto out;
    } else if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("__span_get for span_session_id %d failed, err: %s. \n",
                   span_session_id, sx_status_str(err));
        goto out;
    }

    *span_session_params = span_session_info.params;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_session_iter_get(const sx_access_cmd_t       cmd,
                                  const sx_span_session_id_t *span_session_key_p,
                                  const sx_span_filter_t     *filter_p,
                                  sx_span_session_id_t       *span_session_list_p,
                                  uint32_t                   *span_session_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    db_count = 0;

    SX_LOG_ENTER();
    VALIDATE_POINTER_NOT_NULL(span_session_cnt_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* First lets get the total number of active sessions in db */
    err = span_db_total_session_get(&db_count);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to get number of spans sessions from db, err = [%s]\n",
                   sx_status_str(err));
        goto out;
    }
    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*span_session_cnt_p == 0) {
            /* count of 0 with GET implies return the total count of sessions
             *  from the db count. we are done */
            *span_session_cnt_p = db_count;
            goto out;
        } else {
            /* Validate pointer params */
            VALIDATE_POINTER_NOT_NULL(span_session_key_p);
            VALIDATE_POINTER_NOT_NULL(span_session_list_p);

            /* Validate key is in valid range */
            if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(*span_session_key_p)) {
                SX_LOG_ERR("invalid external span session key %u\n", *span_session_key_p);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }

            /* GET cmd can only fetch a single session */
            *span_session_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
    case SX_ACCESS_CMD_GETNEXT:
        if (*span_session_cnt_p == 0) {
            /* return empty list. */
            SX_LOG(SX_LOG_INFO, "[%s] Cmd = %s; but count is 0 return Empty List\n",
                   __func__, sx_access_cmd_str(cmd));
            goto out;
        } else {
            /* Ensure count is within limits */
            if (*span_session_cnt_p > db_count) {
                *span_session_cnt_p = db_count;
                SX_LOG(SX_LOG_INFO, "[%s] Req count[%d] > db total [%d] "
                       "Overwrite with db total\n",
                       __func__, *span_session_cnt_p, db_count);
            }
        }

        VALIDATE_POINTER_NOT_NULL(span_session_list_p);

        /* if we get here, count is >0. check one final special case */
        if (cmd == SX_ACCESS_CMD_GETNEXT) {
            VALIDATE_POINTER_NOT_NULL(span_session_key_p);

            if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(*span_session_key_p)) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("span_session_id [%d] exceeds range [0 - %d]\n",
                           *span_session_key_p,
                           rm_resource_global.span_session_id_max_external);
                goto out;
            }
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Cmd [%s] is not Supported\n", sx_access_cmd_str(cmd));
        goto out;
        break;
    }

    err = span_db_session_iter_get(cmd, span_session_key_p, filter_p,
                                   span_session_list_p, span_session_cnt_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("%s Failed to get %d span session ids; session key = (%d), err = %s",
                   sx_access_cmd_str(cmd), *span_session_cnt_p,
                   *span_session_key_p, sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}
sx_status_t span_session_state_set(const sx_span_session_id_t span_session_id, const boolean_t admin_state)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;
    span_session_info_t      span_session_info;
    uint32_t                 mirrors_num = 0;
    sx_port_log_id_t         analyzer_port;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    SX_MEM_CLR(span_session_info);

    err = span_db_session_get(span_session_id_int, &span_session_info,
                              &analyzer_port, &mirrors_num, NULL, NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    if ((span_session_info.admin_state == TRUE) &&
        (admin_state == FALSE) && (mirrors_num > 0)) {
        SX_LOG_ERR("SPAN session %d can't DISABLED (still have %d mirrors).\n",
                   span_session_id_int, mirrors_num);
        err = SX_STATUS_RESOURCE_IN_USE;
        goto out;
    }

    if ((span_session_info.admin_state == FALSE) &&
        (admin_state == TRUE) && (analyzer_port == SX_SPAN_INVALID_LOG_PORT)) {
        SX_LOG_ERR("SPAN session %d can't ENABLED (AN port isn't configured).\n",
                   span_session_id_int);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    span_session_info.admin_state = admin_state ? TRUE : FALSE;

    if (span_session_info.truncate == TRUE) {
        /* [Spectrum 4] Unbind/Bind truncation-Profile from/to SPAN session */
        err = span_mirror_truncation_profile_validate_cb_wrapper(&span_session_info);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SPAN external ID [%d], internal ID [%d] - Truncation-Profile validation failed. err: %s \n",
                       span_session_id, span_session_id_int, sx_status_str(err));
            goto out;
        }

        err =
            span_mirror_truncation_profile_refcount_cb_wrapper((span_session_info.admin_state ==
                                                                TRUE ? SX_ACCESS_CMD_ADD : SX_ACCESS_CMD_DELETE),
                                                               span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed span_mirror_truncation_profile_refcount_cb_wrapper session id [%d], err: %s\n",
                       span_session_info.session_id, sx_status_str(err));
            goto out;
        }
    }

    /* HW configuration */
    err = span_db_session_set(span_session_id_int, &span_session_info);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session %d set failed. err: %s \n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    /*	add/remove the analyzer port from flooding group if SPAN is LOCAL_ETH */
    err = span_db_session_flooding_set(span_session_id_int);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_session_state_get(const sx_span_session_id_t span_session_id, boolean_t             *admin_state_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;
    span_session_info_t      span_session_info;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(admin_state_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    SX_MEM_CLR(span_session_info);

    err = span_db_session_get(span_session_id_int, &span_session_info,
                              NULL, NULL, NULL, NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    *admin_state_p = span_session_info.admin_state;

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t span_session_state_ext_get(const sx_span_session_id_t   span_session_id,
                                       sx_span_session_state_ext_t *span_session_state_ext_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t     span_session_id_int;
    span_session_info_t          span_session_info;
    sx_port_log_id_t             analyzer_port = SX_SPAN_INVALID_LOG_PORT;
    sx_port_log_id_t             analyzer_multiport[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX];
    uint8_t                      multiport_num = SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX;
    sx_span_session_oper_state_t oper_state = SX_SPAN_SESSION_OPER_STATE_DOWN_E;
    uint8_t                      i = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(span_session_id_int);
    SX_MEM_CLR(span_session_info);
    SX_MEM_CLR_ARRAY(analyzer_multiport, SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX, sx_port_log_id_t);

    VALIDATE_POINTER_NOT_NULL(span_session_state_ext_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fail to convert external session id (%d) to internal, err %s.\n", span_session_id,
                   sx_status_str(err));
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    err = span_db_session_get(span_session_id_int, &span_session_info, &analyzer_port,
                              NULL, NULL, NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    /* Return admin state as is */
    span_session_state_ext_p->admin_state = span_session_info.admin_state;

    if (!span_session_state_ext_p->admin_state) {
        span_session_state_ext_p->oper_state = SX_SPAN_SESSION_OPER_STATE_DOWN_E;
        goto out; /* SPAN session admin state is DOWN */
    }

    if (analyzer_port == SX_SPAN_INVALID_LOG_PORT) {
        span_session_state_ext_p->oper_state = SX_SPAN_SESSION_OPER_STATE_DOWN_E;
        goto out; /* Analyzer port is not set */
    }

    err = __span_session_oper_state_from_port(analyzer_port, &span_session_state_ext_p->oper_state);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fail to get operational state of port (0x%x)\n", analyzer_port);
        goto out;
    }
    if ((span_session_state_ext_p->oper_state == SX_SPAN_SESSION_OPER_STATE_DOWN_E) ||
        (SX_PORT_TYPE_ID_GET(analyzer_port) != SX_PORT_TYPE_LAG)) {
        goto out;
    }

    err = span_db_analyzer_multiport_get(span_session_id_int, analyzer_multiport, &multiport_num);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get SPAN analyzer multiport. err %s \n", sx_status_str(err));
        goto out;
    }
    if (multiport_num == 0) {
        span_session_state_ext_p->oper_state = SX_SPAN_SESSION_OPER_STATE_DOWN_E;
        goto out; /* LAG is empty */
    }

    for (i = 0; i < multiport_num; ++i) {
        err = __span_session_oper_state_from_port(analyzer_multiport[i], &oper_state);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Fail to get operational state of port (0x%x)\n", analyzer_multiport[i]);
            goto out;
        }
        if (oper_state == SX_SPAN_SESSION_OPER_STATE_UP_E) {
            span_session_state_ext_p->oper_state = SX_SPAN_SESSION_OPER_STATE_UP_E;
            goto out; /* One of the selected analyzer ports is a UP */
        }
    }
    span_session_state_ext_p->oper_state = SX_SPAN_SESSION_OPER_STATE_DOWN_E;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_session_oper_state_from_port(const sx_port_log_id_t        analyzer_port,
                                                       sx_span_session_oper_state_t *session_oper_state)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_port_oper_state_t port_oper_state;

    err = port_state_get(SX_ACCESS_CMD_GET, analyzer_port, &port_oper_state, NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Fail to GET port (0x%x) oper state. error (%s)\n",
                   analyzer_port, sx_status_str(err));
        goto out;
    }

    switch (port_oper_state) {
    case SX_PORT_OPER_STATUS_UP:
        *session_oper_state = SX_SPAN_SESSION_OPER_STATE_UP_E;
        break;

    case SX_PORT_OPER_STATUS_DOWN:
    case SX_PORT_OPER_STATUS_INVALID:
    case SX_PORT_OPER_STATUS_DOWN_BY_FAIL:
    case SX_PORT_OPER_STATUS_NONE:
        *session_oper_state = SX_SPAN_SESSION_OPER_STATE_DOWN_E;
        break;

    default:
        SX_LOG_ERR("Got an invalid port (0x%x) state (%d).\n", analyzer_port, port_oper_state);
        err = SX_STATUS_ERROR;
        break;
    }

out:
    return err;
}

sx_status_t span_session_analyzer_get(const sx_span_session_id_t span_session_id,
                                      sx_port_log_id_t          *analyzer_port_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(analyzer_port_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    err = span_db_session_get(span_session_id_int, NULL, analyzer_port_p,
                              NULL, NULL, NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    if (*analyzer_port_p == 0) {
        SX_LOG(SX_LOG_NOTICE, "analyzer_port was not set for span session %d.\n",
               span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

/*
 * Get all mirrored ports and directions for a session, including directions
 * not exposed in API
 */
sx_status_t span_session_mirror_get_all(const sx_span_session_id_t span_session_id,
                                        span_mirror_t             *mirror_ports_list_p,
                                        uint32_t                  *mirror_ports_cnt_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(mirror_ports_cnt_p);

    if (*mirror_ports_cnt_p > 0) {
        VALIDATE_POINTER_NOT_NULL(mirror_ports_list_p);
    }

    VALIDIATE_MODULE_INITIALIZED();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Get list of mirrored ports with all directions */
    err = span_db_session_get(span_session_id_int, NULL, NULL,
                              mirror_ports_cnt_p, mirror_ports_list_p,
                              NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

/*
 * Get all mirrored ports and directions for a session, excluding directions
 * not exposed in API
 */
sx_status_t span_session_mirror_get(const sx_span_session_id_t span_session_id,
                                    sx_span_mirror_t          *mirror_ports_list_p,
                                    uint32_t                  *mirror_ports_cnt_p)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_status_t    cnv_err = SX_STATUS_SUCCESS;
    span_mirror_t *full_mirror_ports_list_p = NULL;
    uint32_t       int_idx;
    uint32_t       ext_idx;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(mirror_ports_cnt_p);
    VALIDIATE_MODULE_INITIALIZED();

    if (*mirror_ports_cnt_p > 0) {
        VALIDATE_POINTER_NOT_NULL(mirror_ports_list_p);
        /* Allocate temporary storage for list of mirror ports with full direction */
        full_mirror_ports_list_p = (span_mirror_t*)cl_malloc(
            sizeof(span_mirror_t) * (*mirror_ports_cnt_p));
        if (!full_mirror_ports_list_p) {
            err = SX_STATUS_NO_MEMORY;
            goto out;
        }

        /* Get list of mirrored ports with all directions */
        err = span_session_mirror_get_all(span_session_id,
                                          full_mirror_ports_list_p,
                                          mirror_ports_cnt_p);
        if (err != SX_STATUS_SUCCESS) {
            goto out;
        }

        /* Convert mirror directions to the restricted type known at API, */
        /* excluding those with other mirror directions                   */
        for (int_idx = 0, ext_idx = 0; int_idx < *mirror_ports_cnt_p; int_idx++) {
            mirror_ports_list_p[ext_idx].log_port = full_mirror_ports_list_p[int_idx].log_port;
            cnv_err = span_cnv_full_to_simple_mirror_direction(full_mirror_ports_list_p[int_idx].mirror_direction,
                                                               &mirror_ports_list_p[ext_idx].mirror_direction);
            if (!cnv_err) {
                ext_idx++;
            }
        }
        *mirror_ports_cnt_p = ext_idx;
    } else { /* *mirror_ports_cnt_p = 0 */
             /* Get list of mirrored ports with all directions */
        err = span_session_mirror_get_all(span_session_id,
                                          NULL,
                                          mirror_ports_cnt_p);
        if (err != SX_STATUS_SUCCESS) {
            goto out;
        }
    }

out:
    if (full_mirror_ports_list_p) {
        CL_FREE_N_NULL(full_mirror_ports_list_p);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_qos_mode(sx_span_qos_mode_t qos_mode)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows 1 bit for qos_mode */
    if (qos_mode > SX_SPAN_QOS_MAX) {
        SX_LOG_ERR("QOS_MODE %u is outside valid range %u-%u.\n",
                   qos_mode, SX_SPAN_QOS_MIN, SX_SPAN_QOS_MAX);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_switch_prio(uint8_t switch_prio)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows 4 bits for switch-prio, but 15 is for internal use */
    if (switch_prio > SX_SPAN_SWITCH_PRIO_MAX) {
        SX_LOG_ERR("SWITCH_PRIO %u is outside valid range 0-%u.\n",
                   switch_prio, SX_SPAN_SWITCH_PRIO_MAX);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_vid(sx_vlan_id_t vid)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows 12 bits for vid */
    if (!VLAN_ID_CHECK_RANGE(vid)) {
        SX_LOG_ERR("VID %u is outside valid range %u-%u.\n",
                   vid, VLAN_ID_MIN, VLAN_ID_MAX);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_vlan_ethertype_id(uint8_t vlan_ethertype_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows values 0-2 for vlan_ethertype_id */
    if (vlan_ethertype_id > 2) {
        SX_LOG_ERR("vlan_ethertype_id %u is outside valid range 0-2.\n",
                   vlan_ethertype_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_pcp(sx_cos_pcp_t pcp)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows 3 bits for pcp */
    if (pcp > COS_PCP_MAX_NUM) {
        SX_LOG_ERR("PCP %u is outside valid range %u-%u.\n",
                   pcp, 0, COS_PCP_MAX_NUM);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_dei(sx_cos_dei_t dei)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows 1 bit for dei */
    if (dei > 1) {
        SX_LOG_ERR("DEI %u is outside valid range 0-1.\n", dei);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_tp(uint8_t tp)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows 1 bit for tp */
    if (tp > 1) {
        SX_LOG_ERR("TP %u is outside valid range 0-1.\n", tp);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_dscp(uint8_t dscp)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows 6 bits for dscp */
    if (dscp > SX_COS_PORT_DSCP_MAX) {
        SX_LOG_ERR("DSCP %u is outside valid range %u-%u.\n",
                   dscp, SX_COS_PORT_DSCP_MIN, SX_COS_PORT_DSCP_MAX);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_ecn(sx_cos_ecn_t ecn)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows 2 bits for ecn */
    if (ecn > COS_ECN_MAX_NUM) {
        SX_LOG_ERR("ECN %u is outside valid range %u-%u.\n",
                   ecn, 0, COS_ECN_MAX_NUM);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_ttl(uint8_t ttl)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(ttl);

    SX_LOG_ENTER();

    /* PRM allows 8 bits for ttl, therefore always valid */

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_truncate(boolean_t truncate)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows 1 bit for truncate */
    if (truncate > 1) {
        SX_LOG_ERR("TRUNCATE %u is outside valid range 0-1.\n", truncate);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_truncate_size(uint16_t truncate_size)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if ((truncate_size < rm_resource_global.span_truncation_size_min) ||
        (truncate_size > rm_resource_global.span_truncation_size_max) ||
        (truncate_size % rm_resource_global.span_truncation_size_granularity)) {
        SX_LOG_ERR("Truncate size must be a multiple of %u between %u and %u, not %u.\n",
                   rm_resource_global.span_truncation_size_granularity,
                   rm_resource_global.span_truncation_size_min,
                   rm_resource_global.span_truncation_size_max,
                   truncate_size);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_validate_span_type_format_spectrum(const sx_span_session_params_t *span_session_params)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_span_mirror_header_version_t header_version;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(span_session_params);

    VALIDIATE_MODULE_INITIALIZED();

    /* Check formats that are valid for Spectrum */
    switch (span_session_params->span_type) {
    case SX_SPAN_TYPE_LOCAL_ETH_TYPE1:
        err = __validate_qos_mode(span_session_params->span_type_format.local_eth_type1.qos_mode);
        if (err) {
            goto out;
        }
        err = __validate_switch_prio(span_session_params->span_type_format.local_eth_type1.switch_prio);
        if (err) {
            goto out;
        }
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1:
        err = __validate_qos_mode(span_session_params->span_type_format.remote_eth_vlan_type1.qos_mode);
        if (err) {
            goto out;
        }
        err = __validate_switch_prio(span_session_params->span_type_format.remote_eth_vlan_type1.switch_prio);
        if (err) {
            goto out;
        }
        err = __validate_vid(span_session_params->span_type_format.remote_eth_vlan_type1.vid);
        if (err) {
            goto out;
        }
        err = __validate_vlan_ethertype_id(
            span_session_params->span_type_format.remote_eth_vlan_type1.vlan_ethertype_id);
        if (err) {
            goto out;
        }
        err = __validate_pcp(span_session_params->span_type_format.remote_eth_vlan_type1.pcp);
        if (err) {
            goto out;
        }
        err = __validate_dei(span_session_params->span_type_format.remote_eth_vlan_type1.dei);
        if (err) {
            goto out;
        }
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1:
        if (span_session_params->version != SX_SPAN_MIRROR_HEADER_VERSION_INVALID) {
            header_version = span_session_params->version;
        } else {
            header_version = span_db_header_version_get();
        }
        switch (header_version) {
        case SX_SPAN_MIRROR_HEADER_VERSION_0:
        case SX_SPAN_MIRROR_HEADER_VERSION_1:
        case SX_SPAN_MIRROR_HEADER_NONE:
            break;

        default:
            SX_LOG_ERR("Remote Eth L2 format requires header version v0, v1 or none.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        err = __validate_qos_mode(span_session_params->span_type_format.remote_eth_l2_type1.qos_mode);
        if (err) {
            goto out;
        }
        err = __validate_switch_prio(span_session_params->span_type_format.remote_eth_l2_type1.switch_prio);
        if (err) {
            goto out;
        }
        if (span_session_params->span_type_format.remote_eth_l2_type1.tp) {
            err = __validate_vid(span_session_params->span_type_format.remote_eth_l2_type1.vid);
            if (err) {
                goto out;
            }
        }
        err =
            __validate_vlan_ethertype_id(span_session_params->span_type_format.remote_eth_l2_type1.vlan_ethertype_id);
        if (err) {
            goto out;
        }
        err = __validate_pcp(span_session_params->span_type_format.remote_eth_l2_type1.pcp);
        if (err) {
            goto out;
        }
        err = __validate_dei(span_session_params->span_type_format.remote_eth_l2_type1.dei);
        if (err) {
            goto out;
        }
        err = __validate_tp(span_session_params->span_type_format.remote_eth_l2_type1.tp);
        if (err) {
            goto out;
        }
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1:
        if (span_session_params->version != SX_SPAN_MIRROR_HEADER_VERSION_INVALID) {
            header_version = span_session_params->version;
        } else {
            header_version = span_db_header_version_get();
        }
        switch (header_version) {
        case SX_SPAN_MIRROR_HEADER_VERSION_1:
        case SX_SPAN_MIRROR_HEADER_NONE:
            break;

        default:
            SX_LOG_ERR("Remote Eth L3 format requires header version v1 or none.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        err = __validate_qos_mode(span_session_params->span_type_format.remote_eth_l3_type1.qos_mode);
        if (err) {
            goto out;
        }
        err = __validate_switch_prio(span_session_params->span_type_format.remote_eth_l3_type1.switch_prio);
        if (err) {
            goto out;
        }
        if (span_session_params->span_type_format.remote_eth_l3_type1.tp) {
            err = __validate_vid(span_session_params->span_type_format.remote_eth_l3_type1.vid);
            if (err) {
                goto out;
            }
        }
        err =
            __validate_vlan_ethertype_id(span_session_params->span_type_format.remote_eth_l3_type1.vlan_ethertype_id);
        if (err) {
            goto out;
        }
        err = __validate_pcp(span_session_params->span_type_format.remote_eth_l3_type1.pcp);
        if (err) {
            goto out;
        }
        err = __validate_dei(span_session_params->span_type_format.remote_eth_l3_type1.dei);
        if (err) {
            goto out;
        }
        err = __validate_tp(span_session_params->span_type_format.remote_eth_l3_type1.tp);
        if (err) {
            goto out;
        }
        err = __validate_dscp(span_session_params->span_type_format.remote_eth_l3_type1.dscp);
        if (err) {
            goto out;
        }
        err = __validate_ecn(span_session_params->span_type_format.remote_eth_l3_type1.ecn);
        if (err) {
            goto out;
        }
        err = __validate_ttl(span_session_params->span_type_format.remote_eth_l3_type1.ttl);
        if (err) {
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("SPAN format type %u not supported for Spectrum.\n",
                   span_session_params->span_type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Verify truncation fields within range */
    err = __validate_truncate(span_session_params->truncate);
    if (err) {
        goto out;
    }
    if (span_session_params->truncate) {
        err = __validate_truncate_size(span_session_params->truncate_size);
        if (err) {
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_validate_mirror_header_padding_spectrum4(const sx_span_session_params_t *span_session_params)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /**
     * Mirror header padding supported only for:
     *  - Header version: V1 & V2
     *  - span types: Encapsulated L2 and L3-GRE (ERSPAN)
     *
     * All other cases return an error
     */
    if (SX_SPAN_HEADER_PADDING_NO_PADDING_E != span_session_params->padding) {
        if (((SX_SPAN_MIRROR_HEADER_VERSION_1 != span_session_params->version) &&
             (SX_SPAN_MIRROR_HEADER_VERSION_2 != span_session_params->version)) ||
            ((SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1 != span_session_params->span_type) &&
             (SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1 != span_session_params->span_type))) {
            SX_LOG_ERR("Mirror header padding isn't supported with session params: ver[%d], span_type[%d]\n",
                       span_session_params->version, span_session_params->span_type);
            status = SX_STATUS_PARAM_ERROR;
        }
    }

    SX_LOG_EXIT();
    return status;
}

sx_status_t span_validate_span_type_format_spectrum2(const sx_span_session_params_t *span_session_params)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_span_mirror_header_version_t header_version;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(span_session_params);

    VALIDIATE_MODULE_INITIALIZED();

    /* Check formats that are valid for Spectrum */
    switch (span_session_params->span_type) {
    case SX_SPAN_TYPE_LOCAL_ETH_TYPE1:
        err = __validate_qos_mode(span_session_params->span_type_format.local_eth_type1.qos_mode);
        if (err) {
            goto out;
        }
        err = __validate_switch_prio(span_session_params->span_type_format.local_eth_type1.switch_prio);
        if (err) {
            goto out;
        }
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_VLAN_TYPE1:
        err = __validate_qos_mode(span_session_params->span_type_format.remote_eth_vlan_type1.qos_mode);
        if (err) {
            goto out;
        }
        err = __validate_switch_prio(span_session_params->span_type_format.remote_eth_vlan_type1.switch_prio);
        if (err) {
            goto out;
        }
        err = __validate_vid(span_session_params->span_type_format.remote_eth_vlan_type1.vid);
        if (err) {
            goto out;
        }
        err = __validate_vlan_ethertype_id(
            span_session_params->span_type_format.remote_eth_vlan_type1.vlan_ethertype_id);
        if (err) {
            goto out;
        }
        err = __validate_pcp(span_session_params->span_type_format.remote_eth_vlan_type1.pcp);
        if (err) {
            goto out;
        }
        err = __validate_dei(span_session_params->span_type_format.remote_eth_vlan_type1.dei);
        if (err) {
            goto out;
        }
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_L2_TYPE1:
        if (span_session_params->version != SX_SPAN_MIRROR_HEADER_VERSION_INVALID) {
            header_version = span_session_params->version;
        } else {
            header_version = span_db_header_version_get();
        }
        switch (header_version) {
        case SX_SPAN_MIRROR_HEADER_VERSION_0:
        case SX_SPAN_MIRROR_HEADER_VERSION_1:
        case SX_SPAN_MIRROR_HEADER_VERSION_2:
        case SX_SPAN_MIRROR_HEADER_NONE:
            break;

        default:
            SX_LOG_ERR("Remote Eth L2 format requires header version v0, v1, v2 or none.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        err = __validate_qos_mode(span_session_params->span_type_format.remote_eth_l2_type1.qos_mode);
        if (err) {
            goto out;
        }
        err = __validate_switch_prio(span_session_params->span_type_format.remote_eth_l2_type1.switch_prio);
        if (err) {
            goto out;
        }
        if (span_session_params->span_type_format.remote_eth_l2_type1.tp) {
            err = __validate_vid(span_session_params->span_type_format.remote_eth_l2_type1.vid);
            if (err) {
                goto out;
            }
        }
        err =
            __validate_vlan_ethertype_id(span_session_params->span_type_format.remote_eth_l2_type1.vlan_ethertype_id);
        if (err) {
            goto out;
        }
        err = __validate_pcp(span_session_params->span_type_format.remote_eth_l2_type1.pcp);
        if (err) {
            goto out;
        }
        err = __validate_dei(span_session_params->span_type_format.remote_eth_l2_type1.dei);
        if (err) {
            goto out;
        }
        err = __validate_tp(span_session_params->span_type_format.remote_eth_l2_type1.tp);
        if (err) {
            goto out;
        }
        break;

    case SX_SPAN_TYPE_REMOTE_ETH_L3_TYPE1:
        if (span_session_params->version != SX_SPAN_MIRROR_HEADER_VERSION_INVALID) {
            header_version = span_session_params->version;
        } else {
            header_version = span_db_header_version_get();
        }
        switch (header_version) {
        case SX_SPAN_MIRROR_HEADER_VERSION_1:
        case SX_SPAN_MIRROR_HEADER_VERSION_2:
        case SX_SPAN_MIRROR_HEADER_NONE:
            break;

        default:
            SX_LOG_ERR("Remote Eth L3 format requires header version v1, v2 or none.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        err = __validate_qos_mode(span_session_params->span_type_format.remote_eth_l3_type1.qos_mode);
        if (err) {
            goto out;
        }
        err = __validate_switch_prio(span_session_params->span_type_format.remote_eth_l3_type1.switch_prio);
        if (err) {
            goto out;
        }
        if (span_session_params->span_type_format.remote_eth_l3_type1.tp) {
            err = __validate_vid(span_session_params->span_type_format.remote_eth_l3_type1.vid);
            if (err) {
                goto out;
            }
        }
        err =
            __validate_vlan_ethertype_id(span_session_params->span_type_format.remote_eth_l3_type1.vlan_ethertype_id);
        if (err) {
            goto out;
        }
        err = __validate_pcp(span_session_params->span_type_format.remote_eth_l3_type1.pcp);
        if (err) {
            goto out;
        }
        err = __validate_dei(span_session_params->span_type_format.remote_eth_l3_type1.dei);
        if (err) {
            goto out;
        }
        err = __validate_tp(span_session_params->span_type_format.remote_eth_l3_type1.tp);
        if (err) {
            goto out;
        }
        err = __validate_dscp(span_session_params->span_type_format.remote_eth_l3_type1.dscp);
        if (err) {
            goto out;
        }
        err = __validate_ecn(span_session_params->span_type_format.remote_eth_l3_type1.ecn);
        if (err) {
            goto out;
        }
        err = __validate_ttl(span_session_params->span_type_format.remote_eth_l3_type1.ttl);
        if (err) {
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("SPAN format type %u not supported for Spectrum.\n",
                   span_session_params->span_type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Verify truncation fields within range */
    err = __validate_truncate(span_session_params->truncate);
    if (err) {
        goto out;
    }
    if (span_session_params->truncate) {
        err = __validate_truncate_size(span_session_params->truncate_size);
        if (err) {
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_span_type_format(const sx_span_session_params_t *span_session_params)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Call device-specific code */
    if (brg_context.spec_cb_g.span_validate_span_type_format_cb) {
        err = brg_context.spec_cb_g.span_validate_span_type_format_cb(span_session_params);
        if (err) {
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_cng_mng(sx_span_cng_mng_t cng_mng)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* PRM allows 1 bit for best effort field */
    if (cng_mng > SX_SPAN_CNG_MNG_MAX) {
        SX_LOG_ERR("CNG_MNG %u is outside valid range %u-%u.\n",
                   cng_mng, SX_SPAN_CNG_MNG_MIN, SX_SPAN_CNG_MNG_MAX);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __validate_analyzer_port_params(const sx_span_analyzer_port_params_t *analyzer_port_params)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Check each field */
    err = __validate_cng_mng(analyzer_port_params->cng_mng);
    if (err) {
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_add(sx_span_session_id_t *span_session_id_p, sx_span_session_params_t *span_session_params)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    span_session_info_t span_session_info;

    SX_LOG_ENTER();

    /* Allocate a SPAN session ID*/
    err = span_db_session_id_alloc(span_session_id_p);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* init dbs */
    err = __span_modify_simple(*span_session_id_p, span_session_params);
    if (err != SX_STATUS_SUCCESS) {
        span_db_session_id_free(*span_session_id_p);
        goto out;
    }

    if (span_session_params->truncate == TRUE) {
        SX_MEM_CLR(span_session_info);

        err = span_db_session_get(*span_session_id_p, &span_session_info,
                                  NULL, NULL, NULL, NULL, NULL);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                       *span_session_id_p, sx_status_str(err));
            goto out;
        }

        err = span_mirror_truncation_profile_set_cb_wrapper(SX_ACCESS_CMD_ADD,
                                                            *span_session_id_p, &span_session_info);

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR(
                "Failure in span_mirror_truncation_profile_set_cb_wrapper ADD of SPAN session id %hu. err: %s.\n",
                *span_session_id_p,
                sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_modify_simple(const sx_span_session_id_t span_session_id,
                                        sx_span_session_params_t  *span_session_params)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;
    span_session_info_t      span_session_info;
    uint32_t                 mirrors_num = 0;
    sx_port_log_id_t         analyzer_port;

    SX_LOG_ENTER();

    SX_MEM_CLR(span_session_info);

    /* Validate span type for the device type */
    err = __validate_span_type_format(span_session_params);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    /* Validate span header padding for the device-specific */
    err = span_validate_mirror_header_padding_cb_wrapper(span_session_params);
    if (err) {
        goto out;
    }

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    err = span_db_session_get(span_session_id_int, &span_session_info,
                              &analyzer_port, &mirrors_num, NULL, NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    span_session_info.span_type = span_session_params->span_type;
    span_session_info.span_type_format = span_session_params->span_type_format;
    span_session_info.truncate = span_session_params->truncate ? TRUE : FALSE;
    span_session_info.truncation_size = span_session_params->truncate_size;
    span_session_info.session_id = span_session_id;

    span_session_info.params = *span_session_params;

    err = span_mirror_truncation_profile_validate_cb_wrapper(&span_session_info);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN external ID [%d], internal ID [%d] - Truncation-Profile validation failed. err: %s \n",
                   span_session_id, span_session_id_int, sx_status_str(err));
        goto out;
    }

    /* HW configuration */
    err = span_db_session_set(span_session_id_int, &span_session_info);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session %d set failed. err: %s \n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    /* Analyzer port should be removed from flooding group if SPAN is        */
    /* LOCAL_ETH and session is enabled, so check this since SPAN format may */
    /* have changed                                                          */
    err = span_db_session_flooding_set(span_session_id_int);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session %d set failed. err: %s \n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_modify_sx(const sx_span_session_id_t       span_session_id,
                           sx_span_session_params_t        *span_session_params,
                           sx_port_log_id_t                *new_analyzer_port_p,
                           span_analyzer_port_set_params_t *port_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    UNUSED_PARAM(new_analyzer_port_p);
    UNUSED_PARAM(port_params_p);

    VALIDIATE_MODULE_INITIALIZED();

    err = __span_modify_simple(span_session_id, span_session_params);
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_modify_with_move(const sx_span_session_id_t       span_session_id,
                                           sx_span_session_params_t        *span_session_params,
                                           sx_port_log_id_t                *new_analyzer_port_p,
                                           span_analyzer_port_set_params_t *port_params_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_status_t                     err2 = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t        old_span_session_id_int;
    sx_span_session_id_int_t        new_span_session_id_int;
    span_session_info_t             span_session_info;
    span_session_info_t             changed_span_session_info;
    span_session_info_t             old_span_session_info;
    sx_port_log_id_t                analyzer_port, analyzer_port_to_update;
    uint32_t                        mirrors_num = 0;
    span_mirror_t                  *mirrors_arr = NULL;
    uint32_t                        ref_cnt = 0;
    boolean_t                       table_mirror;
    sx_span_analyzer_port_params_t  analyzer_port_params;
    span_analyzer_port_set_params_t analyzer_port_params_to_update;
    span_analyzer_port_set_params_t old_analyzer_port_params;
    sx_span_session_id_t            junk_session_id;
    uint32_t                        span_sessions_cnt;
    uint32_t                        mirror_idx;
    uint32_t                        last_mirror_idx_moved = 0;
    boolean_t                       session_allocated = FALSE;
    boolean_t                       analyzer_added = FALSE;
    boolean_t                       analyzer_deleted = FALSE;
    boolean_t                       mirrors_moved = FALSE;
    boolean_t                       new_session_set = FALSE;
    boolean_t                       advised = FALSE;
    boolean_t                       table_moved = FALSE;
    boolean_t                       old_session_disabled = FALSE;
    boolean_t                       is_mirror_port = FALSE;
    boolean_t                       locked = FALSE;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(port_params_p);

    SX_MEM_CLR(span_session_info);
    SX_MEM_CLR(old_analyzer_port_params);

    /* Reject if session is locked */
    err = span_db_session_is_locked(span_session_id, &locked);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d err: %s.\n",
                   span_session_id, sx_status_str(err));
        goto out;
    }
    if (locked) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("SPAN session id %d is locked.\n", span_session_id);
        goto out;
    }

    /* Validate span type for the device type ,
     *  if only analyzer_port will be updated span_session_params is NULL */
    if (span_session_params != NULL) {
        err = __validate_span_type_format(span_session_params);
        if (err != SX_STATUS_SUCCESS) {
            goto out;
        }

        /* Validate span header padding for the device-specific */
        err = span_validate_mirror_header_padding_cb_wrapper(span_session_params);
        if (err) {
            goto out;
        }
    }

    /* Allocate an internal SPAN session ID*/
    err = span_db_session_id_int_alloc(&new_span_session_id_int);
    if (err == SX_STATUS_NO_RESOURCES) {
        SX_LOG_ERR("No session resource, one extra session resource is needed to perform EDIT."
                   "Please reserve one session to perform EDIT\n");
    }
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_session_id_int_alloc failed, err: %s.\n", sx_status_str(err));
        goto out;
    }
    session_allocated = TRUE;

    /* Look up old internal session */
    err = span_db_session_ext_to_int(span_session_id, &old_span_session_id_int);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_session_ext_to_int %u failed, err: %s.\n",
                   span_session_id, sx_status_str(err));
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(old_span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, old_span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }
    err = span_db_session_get(old_span_session_id_int, &span_session_info,
                              &analyzer_port, &mirrors_num, NULL,
                              &ref_cnt, &table_mirror);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   old_span_session_id_int, sx_status_str(err));
        goto out;
    }

    /* [Spectrum4 and above] Get old session's truncation-profile configuration (if exists only) */
    err = span_mirror_truncation_profile_get_cb_wrapper(old_span_session_id_int, &span_session_info);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failure in truncation_profile cb of internal session ID %hu. err: %s.\n",
                   old_span_session_id_int, sx_status_str(err));
        goto out;
    }

    /* Apply updated session parameters to session info,
     *  if only analyzer_port will be updated span_session_params is NULL */
    if (span_session_params != NULL) {
        span_session_info.span_type = span_session_params->span_type;
        span_session_info.span_type_format = span_session_params->span_type_format;
        span_session_info.truncate = span_session_params->truncate ? TRUE : FALSE;
        span_session_info.truncation_size = span_session_params->truncate_size;
        span_session_info.params = *span_session_params;
    }

    /* HW configuration - disabled for now */
    changed_span_session_info = span_session_info;
    changed_span_session_info.admin_state = FALSE;
    err = span_db_session_set(new_span_session_id_int, &changed_span_session_info);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session %d set failed. err: %s \n",
                   new_span_session_id_int, sx_status_str(err));
        goto out;
    }

    /* Allocate space for lists */
    if (mirrors_num > 0) {
        mirrors_arr = cl_malloc(mirrors_num * sizeof(*mirrors_arr));
        if (!mirrors_arr) {
            SX_LOG_ERR("Failed to allocate memory for list of %u mirror ports.\n",
                       mirrors_num);
            err = SX_STATUS_NO_MEMORY;
            goto out;
        }
    }

    /* Get session again with lists */
    err = span_db_session_get(old_span_session_id_int, &old_span_session_info,
                              &analyzer_port, &mirrors_num, mirrors_arr,
                              &ref_cnt, &table_mirror);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   old_span_session_id_int, sx_status_str(err));
        goto out;
    }

    /* Move analyzer port to new session if it is defined */
    if (analyzer_port != SX_SPAN_INVALID_LOG_PORT) {
        /* Get parameters of analyzer port */
        span_sessions_cnt = 1;
        err = span_db_port_analyzer_get(analyzer_port,
                                        &analyzer_port_params,
                                        &junk_session_id,
                                        &span_sessions_cnt);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_db_port_analyzer_get(0x%x) failed, err: %s. \n",
                       analyzer_port, sx_status_str(err));
            goto out;
        }

        if (new_analyzer_port_p != NULL) {
            analyzer_port_to_update = *new_analyzer_port_p;
        } else {
            analyzer_port_to_update = analyzer_port;
        }

        old_analyzer_port_params.sx_port_params = &analyzer_port_params;
        analyzer_port_params_to_update = *port_params_p;
        if (port_params_p->sx_port_params == NULL) {
            analyzer_port_params_to_update.sx_port_params = &analyzer_port_params;
        }

        /* Assign analyzer port to new session in addition to old session */
        err = span_db_port_analyzer_set(SX_ACCESS_CMD_ADD,
                                        analyzer_port_to_update,
                                        &analyzer_port_params_to_update,
                                        new_span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_db_port_analyzer_set(span %d, 0x%x) failed, err: %s. \n",
                       new_span_session_id_int, analyzer_port_to_update, sx_status_str(err));
            goto out;
        }
        analyzer_added = TRUE;

        /* update span session_info local variable with changed analyzer port
         *  needed for next operation. */
        err = span_db_session_get(new_span_session_id_int, &span_session_info,
                                  NULL, NULL, NULL, NULL, NULL);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                       new_span_session_id_int, sx_status_str(err));
            goto out;
        }
        /* Restore original admin state of the session */
        span_session_info.admin_state = old_span_session_info.admin_state;
    }

    /* Assign mirrored ports to the new session, which automatically deletes */
    /* their association with the old session                                */
    for (mirror_idx = 0; mirror_idx < mirrors_num; mirror_idx++) {
        span_db_validate_mirror_port(mirrors_arr + mirror_idx, &is_mirror_port);
        if (is_mirror_port == FALSE) {
            /* bind mirror to new span session */
            err = span_db_mirror_bound_update(mirrors_arr[mirror_idx].mirror_direction,
                                              old_span_session_id_int,
                                              new_span_session_id_int);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("span_db_mirror_bind_update(direction [%u], old span %d, new span %d)  failed. err: %s\n",
                           mirrors_arr[mirror_idx].mirror_direction,
                           old_span_session_id_int,
                           new_span_session_id_int,
                           sx_status_str(err));
                goto out;
            }
            continue;
        }
        err = span_db_mirror_get(mirrors_arr + mirror_idx, &junk_session_id, NULL, NULL);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_db_mirror_get(0x%x,%d) failed, err: %s. \n",
                       mirrors_arr[mirror_idx].log_port,
                       mirrors_arr[mirror_idx].mirror_direction,
                       sx_status_str(err));
            goto out;
        }
        err = span_db_mirror_set(SX_ACCESS_CMD_EDIT,
                                 mirrors_arr + mirror_idx,
                                 old_span_session_id_int,
                                 new_span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_db_mirror_set(%d, 0x%x,%d) failed, err: %s. \n",
                       new_span_session_id_int,
                       mirrors_arr[mirror_idx].log_port,
                       mirrors_arr[mirror_idx].mirror_direction,
                       sx_status_str(err));
            goto out;
        }

        /* Flag need for rollback on subsequent failure if any mirror ports */
        /* were moved to new session, and note which would need rollback    */
        mirrors_moved = TRUE;
        last_mirror_idx_moved = mirror_idx;
    }

    /* HW configuration with correct admin state */
    err = span_db_session_set(new_span_session_id_int, &span_session_info);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session %d set failed. err: %s \n",
                   new_span_session_id_int, sx_status_str(err));
        goto out;
    }
    new_session_set = TRUE;

    /* [Spectrum 4] Create and Bind truncation-Profile to new SPAN session */
    if (span_session_info.truncate == TRUE) {
        err = span_mirror_truncation_profile_set_cb_wrapper(SX_ACCESS_CMD_ADD,
                                                            new_span_session_id_int,
                                                            &span_session_info);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed span_mirror_truncation_profile_set_cb_wrapper ADD to session id [%d], err: %s\n",
                       new_span_session_id_int, sx_status_str(err));
            goto out;
        }

        if (span_session_info.admin_state == TRUE) {
            err = span_mirror_truncation_profile_refcount_cb_wrapper(SX_ACCESS_CMD_ADD, new_span_session_id_int);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR(
                    "Failed span_mirror_truncation_profile_refcount_cb_wrapper INC of session id [%d], err: %s\n",
                    new_span_session_id_int,
                    sx_status_str(err));
                goto out;
            }
        }
    }

    /* Record advised now to trigger rollback in case any callbacks fail */
    advised = TRUE;

    /* Notify other modules using this session */
    err = span_db_advise_relocate(span_session_id,
                                  old_span_session_id_int,
                                  new_span_session_id_int);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to advise external SPAN session %u uses internal session %u, err: %s\n",
                   span_session_id, new_span_session_id_int, sx_status_str(err));
        goto out;
    }

    /* Move table mirroring to new session if it used the old one */
    if (table_mirror) {
        err = span_db_mirroring_move(old_span_session_id_int, new_span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_db_mirroring_move %d failed, err: %s\n",
                       new_span_session_id_int, sx_status_str(err));
            goto out;
        }
        table_moved = TRUE;
    }

    /* Disable old session */

    /* [Spectrum 4] Unbind and Delete Truncation-Profile from old SPAN session */
    if (old_span_session_info.truncate == TRUE) {
        err = span_mirror_truncation_profile_refcount_cb_wrapper(SX_ACCESS_CMD_DELETE, old_span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed span_mirror_truncation_profile_refcount_cb_wrapper DEL session id [%d], err: %s\n",
                       old_span_session_id_int, sx_status_str(err));
            goto out;
        }

        err = span_mirror_truncation_profile_set_cb_wrapper(SX_ACCESS_CMD_DELETE,
                                                            old_span_session_id_int,
                                                            &old_span_session_info);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed span_mirror_truncation_profile_set_cb_wrapper DELETE to session id [%d], err: %s\n",
                       old_span_session_id_int, sx_status_str(err));
            goto out;
        }
    }

    changed_span_session_info = old_span_session_info;
    changed_span_session_info.admin_state = FALSE;
    changed_span_session_info.drop_mirror.trap_group_valid = FALSE;
    err = span_db_session_set(old_span_session_id_int, &changed_span_session_info);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_session_set session %d set failed, err: %s\n",
                   old_span_session_id_int, sx_status_str(err));
        goto out;
    }
    old_session_disabled = TRUE;

    /* if new analyzer port was provided return the old one back to flooding */
    if (new_analyzer_port_p != NULL) {
        err = span_db_session_flooding_set(old_span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_db_session_flooding_set for session %d failed, err: %s\n",
                       old_span_session_id_int, sx_status_str(err));
            goto out;
        }
    }

    /* Delete analyzer port from old session if it is defined */
    if (SX_SPAN_INVALID_LOG_PORT != analyzer_port) {
        err = span_db_port_analyzer_set(SX_ACCESS_CMD_DELETE,
                                        analyzer_port,
                                        NULL,
                                        old_span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_db_port_analyzer_set(span %d, 0x%x) failed, err: %s. \n",
                       old_span_session_id_int, analyzer_port, sx_status_str(err));
            goto out;
        }
        analyzer_deleted = TRUE;
    }

    /* Delete old internal session */
    err = span_db_session_id_int_free(old_span_session_id_int);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN internal session id %d isn't found, err: %s.\n",
                   old_span_session_id_int, sx_status_str(err));
        goto out;
    }

    /* Map external session to new internal session */
    err = span_db_session_id_remap(span_session_id, new_span_session_id_int);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_session_id_remap external %u internal %u failed, err: %s.\n",
                   span_session_id, new_span_session_id_int, sx_status_str(err));
        goto out;
    }

    /* Analyzer port should be removed from flooding group if SPAN is        */
    /* LOCAL_ETH and session is enabled, so check this since SPAN format may */
    /* have changed                                                          */
    err = span_db_session_flooding_set(new_span_session_id_int);

out:
    /* Try to roll back on error */
    if (err != SX_STATUS_SUCCESS) {
        if (analyzer_deleted) {
            err2 = span_db_port_analyzer_set(SX_ACCESS_CMD_ADD,
                                             analyzer_port,
                                             &old_analyzer_port_params,
                                             old_span_session_id_int);
            if (err2 != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("span_db_port_analyzer_set(span %d, 0x%x) failed in rollback, err: %s. \n",
                           old_span_session_id_int, analyzer_port, sx_status_str(err2));
            }
        }
        if (old_session_disabled) {
            err2 = span_db_session_set(old_span_session_id_int, &old_span_session_info);
            if (err2 != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to restore session %u state in rollback, err: %s\n",
                           old_span_session_id_int, sx_status_str(err2));
            }
        }
        if (table_moved) {
            err2 = span_db_mirroring_move(new_span_session_id_int, old_span_session_id_int);
            if (err2 != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("span_db_mirror_tables_set session %d failed in rollback, err: %s\n",
                           old_span_session_id_int, sx_status_str(err2));
            }
        }
        if (advised) {
            err2 = span_db_advise_relocate(span_session_id,
                                           new_span_session_id_int,
                                           old_span_session_id_int);
            if (err2 != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to rollback advise external SPAN session %u uses internal session %u, err: %s\n",
                           span_session_id, old_span_session_id_int, sx_status_str(err2));
            }
        }
        if (mirrors_moved) {
            for (mirror_idx = 0; mirror_idx <= last_mirror_idx_moved; mirror_idx++) {
                err2 = span_db_mirror_set(SX_ACCESS_CMD_EDIT,
                                          mirrors_arr + mirror_idx,
                                          new_span_session_id_int,
                                          old_span_session_id_int);
                if (err2 != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed to move mirror %u to old session in rollback, err: %s\n",
                               mirrors_arr[mirror_idx].log_port, sx_status_str(err2));
                }
            }
        }
        if (new_session_set) {
            changed_span_session_info = span_session_info;
            changed_span_session_info.admin_state = FALSE;
            err2 = span_db_session_set(new_span_session_id_int, &changed_span_session_info);
            if (err2 != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("span_db_session_set session %d set failed in rollback, err: %s \n",
                           new_span_session_id_int, sx_status_str(err2));
            }
        }
        if (analyzer_added) {
            err2 = span_db_port_analyzer_set(SX_ACCESS_CMD_DELETE,
                                             analyzer_port,
                                             NULL,
                                             new_span_session_id_int);
            if (err2 != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("span_db_port_analyzer_set delete port %u from session %u failed in rollback, err: %s\n",
                           analyzer_port, new_span_session_id_int, sx_status_str(err2));
            }
        }
        if (session_allocated) {
            err2 = span_db_session_id_int_free(new_span_session_id_int);
            if (err2 != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("span_db_session_id_int_free %d failed in rollback, err: %s.\n",
                           new_span_session_id_int, sx_status_str(err2));
            }
        }
    }

    /* Clean up */
    if (mirrors_arr) {
        CL_FREE_N_NULL(mirrors_arr);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_modify_spectrum(const sx_span_session_id_t       span_session_id,
                                 sx_span_session_params_t        *span_session_params,
                                 sx_port_log_id_t                *new_analyzer_port_p,
                                 span_analyzer_port_set_params_t *port_params_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;
    sx_port_log_id_t         analyzer_port;

    SX_LOG_ENTER();

    if (port_params_p->multiport_on_the_fly_update) {
        /* Look up internal session */
        err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Fail to resolve SPAN id (span %d), err: %s. \n",
                       span_session_id, sx_status_str(err));
            goto out;
        }
        if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
            SX_LOG_ERR("External SPAN session id %d maps to not exist internal %d.\n",
                       span_session_id, span_session_id_int);
            err = SX_STATUS_ENTRY_NOT_FOUND;
            goto out;
        }
        if (new_analyzer_port_p == NULL) {
            err = span_db_session_get(span_session_id_int, NULL,
                                      &analyzer_port, NULL, NULL,
                                      NULL, NULL);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                           span_session_id_int, sx_status_str(err));
                goto out;
            }
        } else {
            analyzer_port = *new_analyzer_port_p;
        }
        err = span_db_port_analyzer_set(SX_ACCESS_CMD_ADD, analyzer_port, port_params_p, span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Fail to modify SPAN analyzer on the fly(span %d, port 0x%x), err: %s. \n",
                       span_session_id, analyzer_port, sx_status_str(err));
            goto out;
        }
    } else {
        err = __span_modify_with_move(span_session_id, span_session_params,
                                      new_analyzer_port_p, port_params_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Fail to modify SPAN analyzer (span %d), err: %s. \n",
                       span_session_id, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_modify(const sx_span_session_id_t       span_session_id,
                                 sx_span_session_params_t        *span_session_params,
                                 sx_port_log_id_t                *new_analyzer_port_p,
                                 span_analyzer_port_set_params_t *port_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Call device-specific code */
    if (brg_context.spec_cb_g.span_modify_cb) {
        err = brg_context.spec_cb_g.span_modify_cb(span_session_id,
                                                   span_session_params,
                                                   new_analyzer_port_p,
                                                   port_params_p);
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_delete(const sx_span_session_id_t span_session_id)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;
    span_session_info_t      span_session_info;
    sx_port_log_id_t         analyzer_port = 0;
    uint32_t                 mirrors_num = 0;
    uint32_t                 ref_cnt = 0;
    boolean_t                table_mirror = FALSE;
    boolean_t                locked = FALSE;

    SX_LOG_ENTER();

    /* Reject if session is locked */
    err = span_db_session_is_locked(span_session_id, &locked);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d err: %s.\n",
                   span_session_id, sx_status_str(err));
        goto out;
    }
    if (locked) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("SPAN session id %d is locked.\n", span_session_id);
        goto out;
    }

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    SX_MEM_CLR(span_session_info);

    err = span_db_session_get(span_session_id_int, &span_session_info,
                              &analyzer_port, &mirrors_num, NULL, &ref_cnt,
                              &table_mirror);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    if (mirrors_num > 0) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("SPAN session %d still have %d mirrors, so can't be destroyed.\n",
                   span_session_id_int, mirrors_num);
        goto out;
    }

    if (analyzer_port != SX_SPAN_INVALID_LOG_PORT) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("SPAN session %d still used on_port 0x%x, so can't be destroyed.\n",
                   span_session_id_int, analyzer_port);
        goto out;
    }

    if (table_mirror) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("SPAN session %d still used for drop/table mirroring, so can't be destroyed.\n",
                   span_session_id_int);
        goto out;
    }

    if (ref_cnt > 0) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("SPAN session %d still has %d references, so can't be destroyed.\n",
                   span_session_id_int, ref_cnt);
        goto out;
    }

    if (span_session_info.policer_enable) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("SPAN session %d still has policer ID %" PRIu64 " bound, so can't be destroyed.\n",
                   span_session_id_int, span_session_info.policer_id);
        goto out;
    }

    if (span_session_info.truncate == TRUE) {
        err = span_mirror_truncation_profile_set_cb_wrapper(SX_ACCESS_CMD_DELETE,
                                                            span_session_id_int,
                                                            &span_session_info);

        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR(
                "Failure in span_mirror_truncation_profile_set_cb_wrapper DEL of SPAN session id %hu. err: %s.\n",
                span_session_info.session_id,
                sx_status_str(err));
            goto out;
        }
    }


    /* Call the appropriate "span_db_session_id_free_cb" function for our current chip type */
    if (brg_context.spec_cb_g.span_db_session_id_free_cb != NULL) {
        err = brg_context.spec_cb_g.span_db_session_id_free_cb(&span_session_info, span_session_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in span_db_session_id_free_cb on chip type %s .\n",
                       sx_chip_type_str((int)brg_context.spec_cb_g.dev_type));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_session_id_free_sx(span_session_info_t *span_session_info_p, sx_span_session_id_t span_session_id)
{
    sx_status_t              status = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;


    SX_LOG_ENTER();

    /* Look up internal session */
    status = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (status) {
        goto out;
    }

    /* HW configuration */
    status = span_db_session_set(span_session_id_int, span_session_info_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session %d set failed. err: %s \n",
                   span_session_id_int, sx_status_str(status));
        goto out;
    }

    status = span_db_session_id_free(span_session_id);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id, sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t span_session_id_free_spectrum(span_session_info_t *span_session_info_p,
                                          sx_span_session_id_t span_session_id)
{
    sx_status_t       status = SX_STATUS_SUCCESS;
    sx_utils_status_t utils_status = SX_UTILS_STATUS_SUCCESS;

    SX_LOG_ENTER();

    span_session_info_p->span_gc_context_item.span_session_id = span_session_id;

    /* Push the SPAN to the GC queue. It will be deleted asynchronously after
     * a fence is performed.
     */
    utils_status = gc_object_push(GC_OBJECT_TYPE_SPAN, (void*)(intptr_t)span_session_id,
                                  GC_STATE_PENDING_FENCE, 1,
                                  GC_OBJECT_SUBTYPE_NONE, 0,
                                  &(span_session_info_p->gc_handle));
    status = SX_UTILS_STATUS_TO_SX_STATUS(utils_status);
    if (SX_UTILS_CHECK_FAIL(utils_status)) {
        SX_LOG_ERR("Failed to push span %u object to GC queue, utils_err = [%s]\n",
                   span_session_id, SX_UTILS_STATUS_MSG(utils_status));
        goto out;
    }

    /* This line added to update gc info */
    /* status = span_db_gc_context_set(span_session_info_p->gc_handle , span_session_info_p->span_gc_context_item); */
    status = span_db_gc_context_set(span_session_info_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session %d set failed. err: %s \n",
                   span_session_id, sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __span_get(sx_span_session_id_t span_session_id,
                              span_session_info_t *span_session_info,
                              sx_port_log_id_t    *analyzer_port,
                              uint32_t            *mirrors_num,
                              span_mirror_t       *mirrors_arr,
                              uint32_t            *ref_cnt)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    /* Invalid internal session is not necessarily a bug; it could just mean */
    /* this session is not defined                                           */
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_DBG("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    err = span_db_session_get(span_session_id_int, span_session_info,
                              analyzer_port, mirrors_num, mirrors_arr,
                              ref_cnt, NULL);
    if (err == SX_STATUS_ENTRY_NOT_FOUND) {
        SX_LOG_DBG("SPAN session id %d isn't found.\n", span_session_id_int);
        goto out;
    } else if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d get failed, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_set_common(const sx_access_cmd_t         cmd,
                                   const sx_port_log_id_t        mirror_port,
                                   const span_mirror_direction_t mirror_direction,
                                   const sx_span_session_id_t    span_session_id)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;
    span_mirror_t            mirror;
    sx_swid_id_t             swid;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Validate Port */
    VALIDATE_PORT(span_mirror_set_common, mirror_port);

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* getting swid where log_port mapped */
    err = port_swid_alloc_get(SX_ACCESS_CMD_GET,
                              mirror_port, &swid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("span_an_set: log_port 0x%x does not exist, err: %s.\n",
                   mirror_port, sx_status_str(err));
        goto out;
    }

    /* set mirror param */
    mirror.log_port = mirror_port;
    mirror.mirror_direction = mirror_direction;

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_EDIT:
    case SX_ACCESS_CMD_DELETE:
        err = span_db_mirror_set(cmd, &mirror, span_session_id_int, span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_db_mirror_set(cmd %d, %d, 0x%x,%d) failed, err: %s. \n",
                       cmd, span_session_id_int, mirror_port, mirror_direction, sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d failed, err: %s. \n", cmd, sx_status_str(err));
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_set(sx_access_cmd_t       cmd,
                            sx_port_log_id_t      mirror_port,
                            sx_mirror_direction_t mirror_direction,
                            sx_span_session_id_t  span_session_id)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    span_mirror_direction_t full_direction;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Convert mirror direction from restricted type exposing only ingress  */
    /* and egress to SDK user, to full type with additional values          */
    err = span_cnv_simple_to_full_mirror_direction(mirror_direction,
                                                   &full_direction);
    if (err) {
        SX_LOG_ERR("Unsupported mirror direction %u, err: %s.\n",
                   mirror_direction, sx_status_str(err));
        goto out;
    }

    /* Proceed using full direction type */
    err = span_mirror_set_common(cmd, mirror_port, full_direction, span_session_id);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_get_common(const sx_port_log_id_t        mirror_port,
                                   const span_mirror_direction_t mirror_direction,
                                   sx_span_session_id_t         *span_session_id_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;
    span_mirror_t            mirror;
    sx_swid_id_t             swid;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(span_session_id_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Validate Port */
    VALIDATE_PORT(span_mirror_get_common, mirror_port);

    /* getting swid where log_port mapped */
    err = port_swid_alloc_get(SX_ACCESS_CMD_GET,
                              mirror_port, &swid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("span_an_set: log_port 0x%x does not exist, err: %s.\n",
                   mirror_port, sx_status_str(err));
        goto out;
    }

    /* Validate mirror direction */
    if (mirror_direction > SPAN_MIRROR_DIRECTION_MAX) {
        SX_LOG_ERR("Invalid mirror direction %u\n", mirror_direction);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* set mirror param */
    mirror.log_port = mirror_port;
    mirror.mirror_direction = mirror_direction;

    err = span_db_mirror_get(&mirror, &span_session_id_int, NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        if (err != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("span_db_mirror_get(0x%x, %d) failed, err: %s. \n",
                       mirror_port, mirror_direction, sx_status_str(err));
        }
        goto out;
    }
    err = span_db_session_int_to_ext(span_session_id_int,
                                     span_session_id_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_session_int_to_ext(%d) failed, err: %s. \n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_get(sx_port_log_id_t      mirror_port,
                            sx_mirror_direction_t mirror_direction,
                            sx_span_session_id_t *span_session_id)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    span_mirror_direction_t full_direction;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(span_session_id);

    VALIDIATE_MODULE_INITIALIZED();

    /* Convert mirror direction from restricted type exposing only ingress  */
    /* and egress to SDK user, to full type with additional values          */
    err = span_cnv_simple_to_full_mirror_direction(mirror_direction,
                                                   &full_direction);
    if (err) {
        SX_LOG_ERR("Unsupported mirror direction %u, err: %s.\n",
                   mirror_direction, sx_status_str(err));
        goto out;
    }

    /* Proceed using full direction type */
    err = span_mirror_get_common(mirror_port, full_direction, span_session_id);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_state_set_common(const sx_port_log_id_t        mirror_port,
                                         const span_mirror_direction_t mirror_direction,
                                         const boolean_t               admin_state)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    span_mirror_t            mirror;
    sx_swid_id_t             swid;
    sx_span_session_id_int_t span_session_id_int;
    sx_access_cmd_t          cmd;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Validate Port */
    VALIDATE_PORT(span_mirror_state_set_common, mirror_port);

    /* getting swid where log_port mapped */
    err = port_swid_alloc_get(SX_ACCESS_CMD_GET,
                              mirror_port, &swid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("port_swid_alloc_get: log_port 0x%x does not exist, err: %s.\n",
                   mirror_port, sx_status_str(err));
        goto out;
    }

    /* set mirror param */
    mirror.log_port = mirror_port;
    mirror.mirror_direction = mirror_direction;

    err = span_db_mirror_get(&mirror, &span_session_id_int, NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_mirror_get(0x%x, %d) failed, err: %s. \n",
                   mirror_port, mirror_direction, sx_status_str(err));
        goto out;
    }

    cmd = admin_state == TRUE ? SX_ACCESS_CMD_ENABLE : SX_ACCESS_CMD_DISABLE;

    err = span_db_mirror_set(cmd, &mirror, span_session_id_int, span_session_id_int);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_mirror_set(cmd %d, %d, 0x%x,%d) failed, err: %s. \n",
                   cmd, span_session_id_int, mirror_port, mirror_direction, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_state_set(const sx_port_log_id_t      mirror_port,
                                  const sx_mirror_direction_t mirror_direction,
                                  const boolean_t             admin_state)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    span_mirror_direction_t full_direction;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Convert mirror direction from restricted type exposing only ingress  */
    /* and egress to SDK user, to full type with additional values          */
    err = span_cnv_simple_to_full_mirror_direction(mirror_direction,
                                                   &full_direction);
    if (err) {
        SX_LOG_ERR("Unsupported mirror direction %u, err: %s.\n",
                   mirror_direction, sx_status_str(err));
        goto out;
    }

    /* Proceed using full direction type */
    err = span_mirror_state_set_common(mirror_port, full_direction, admin_state);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_state_get_common(const sx_port_log_id_t        mirror_port,
                                         const span_mirror_direction_t mirror_direction,
                                         boolean_t                    *admin_state_p)
{
    sx_status_t   err = SX_STATUS_SUCCESS;
    span_mirror_t mirror;
    sx_swid_id_t  swid;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(admin_state_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Validate Port */
    VALIDATE_PORT(span_mirror_state_get_common, mirror_port);

    /* getting swid where log_port mapped */
    err = port_swid_alloc_get(SX_ACCESS_CMD_GET,
                              mirror_port, &swid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("port_swid_alloc_get: log_port 0x%x does not exist, err: %s.\n",
                   mirror_port, sx_status_str(err));
        goto out;
    }

    /* set mirror param */
    mirror.log_port = mirror_port;
    mirror.mirror_direction = mirror_direction;

    err = span_db_mirror_get(&mirror, NULL, NULL, admin_state_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_mirror_get(0x%x, %d) failed, err: %s. \n",
                   mirror_port, mirror_direction, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_state_get(const sx_port_log_id_t      mirror_port,
                                  const sx_mirror_direction_t mirror_direction,
                                  boolean_t                  *admin_state_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    span_mirror_direction_t full_direction;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(admin_state_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Convert mirror direction from restricted type exposing only ingress  */
    /* and egress to SDK user, to full type with additional values          */
    err = span_cnv_simple_to_full_mirror_direction(mirror_direction,
                                                   &full_direction);
    if (err) {
        SX_LOG_ERR("Unsupported mirror direction %u, err: %s.\n",
                   mirror_direction, sx_status_str(err));
        goto out;
    }

    /* Proceed using full direction type */
    err = span_mirror_state_get_common(mirror_port, full_direction, admin_state_p);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_analyzer_validation_spectrum(const sx_port_log_id_t log_port)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sx_swid_id_t swid = 0;
    uint32_t     port_type = 0;

    port_type = SX_PORT_TYPE_ID_GET(log_port);
    if (port_type == SX_PORT_TYPE_CPU) {
        SX_LOG_ERR("Analyzer port can't be CPU\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* getting swid where log_port mapped */
    err = port_swid_alloc_get(SX_ACCESS_CMD_GET, log_port, &swid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("port_swid_alloc_get: log_port 0x%x does not exist, err: %s.\n",
                   log_port, sx_status_str(err));
        goto out;
    }

    err = swid_validation_func_ptr(swid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SWID(%d) type mismatch, err: %s\n", swid, sx_status_str(err));
        return M_UTILS_SX_LOG_EXIT(err);
    }

out:
    return err;
}

sx_status_t span_analyzer_validation_spectrum2(const sx_port_log_id_t log_port)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sx_swid_id_t swid = 0;
    uint32_t     port_type = 0;

    port_type = SX_PORT_TYPE_ID_GET(log_port);
    if (port_type != SX_PORT_TYPE_CPU) {
        /* getting swid where log_port mapped */
        err = port_swid_alloc_get(SX_ACCESS_CMD_GET, log_port, &swid);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("port_swid_alloc_get: log_port 0x%x does not exist, err: %s.\n",
                       log_port, sx_status_str(err));
            goto out;
        }

        err = swid_validation_func_ptr(swid);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("SWID(%d) type mismatch, err: %s\n", swid, sx_status_str(err));
            return M_UTILS_SX_LOG_EXIT(err);
        }
    }

out:
    return err;
}

sx_status_t span_analyzer_validation_cb_wrap(const sx_port_log_id_t log_port)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.span_analyzer_validation_cb != NULL) {
        rc = brg_context.spec_cb_g.span_analyzer_validation_cb(log_port);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_analyzer_validation_cb(), error: %s\n", sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_analyzer_set_sx(const sx_access_cmd_t                  cmd,
                                 const sx_port_log_id_t                 log_port,
                                 const span_analyzer_port_set_params_t *port_params_p,
                                 const sx_span_session_id_t             span_session_id)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_span_session_id_t span_session_id_int;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(port_params_p);
    VALIDATE_POINTER_NOT_NULL(port_params_p->sx_port_params);

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }

    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_WRN("External SPAN session id %d maps to not exist internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        err = span_db_port_analyzer_set(cmd, log_port, port_params_p, span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__span_analyzer_set(span %d, 0x%x) failed, err: %s. \n",
                       span_session_id_int, log_port, sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d failed, err: %s. \n", cmd, sx_status_str(err));
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_analyzer_set_sdk(const sx_access_cmd_t                  cmd,
                                  const sx_port_log_id_t                 log_port,
                                  const span_analyzer_port_set_params_t *port_params_p,
                                  const sx_span_session_id_t             span_session_id)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;
    span_session_info_t      span_session_info;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(port_params_p);
    VALIDATE_POINTER_NOT_NULL(port_params_p->sx_port_params);

    VALIDIATE_MODULE_INITIALIZED();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_WRN("External SPAN session id %d maps to not exist internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    err = span_db_session_get(span_session_id_int, &span_session_info,
                              NULL, NULL, NULL, NULL, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_DELETE:
        if (span_session_info.admin_state == TRUE) {
            SX_LOG_ERR("Error: analyzer port can't be deleted when span in use\n");
            err = SX_STATUS_RESOURCE_IN_USE;
            goto out;
        }

    /* fallthrough */

    case SX_ACCESS_CMD_ADD:

        /* if the session admin state is up use __span_modify else use the old function */
        if (span_session_info.admin_state == FALSE) {
            err = span_db_port_analyzer_set(cmd, log_port, port_params_p, span_session_id_int);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__span_analyzer_set(span %d, 0x%x) failed, err: %s. \n",
                           span_session_id_int, log_port, sx_status_str(err));
                goto out;
            }
        } else {
            err = __span_modify(span_session_id, NULL, (sx_port_log_id_t*)&log_port,
                                (span_analyzer_port_set_params_t*)port_params_p);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("modify(span %d, 0x%x) failed, err: %s. \n",
                           span_session_id, log_port, sx_status_str(err));
                goto out;
            }
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d failed, err: %s. \n", cmd, sx_status_str(err));
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_analyzer_set_cb_wrap(const sx_access_cmd_t                  cmd,
                                      const sx_port_log_id_t                 log_port,
                                      const span_analyzer_port_set_params_t *port_params_p,
                                      const sx_span_session_id_t             span_session_id)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.span_analyzer_set_cb != NULL) {
        rc = brg_context.spec_cb_g.span_analyzer_set_cb(cmd, log_port, port_params_p, span_session_id);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_analyzer_set_cb() , error: %s\n", sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t span_analyzer_set(const sx_access_cmd_t                  cmd,
                              const sx_port_log_id_t                 log_port,
                              const span_analyzer_port_set_params_t *port_params_p,
                              const sx_span_session_id_t             span_session_id)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int = 0;
    boolean_t                is_type_equal = FALSE;
    length_t                 span_sessions_count = 0;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(port_params_p);
    VALIDATE_POINTER_NOT_NULL(port_params_p->sx_port_params);

    VALIDIATE_MODULE_INITIALIZED();

    /* Validate Port */
    VALIDATE_PORT(span_analyzer_set, log_port);

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Validate analyzer port parameters */
    if (cmd != SX_ACCESS_CMD_DELETE) {
        err = __validate_analyzer_port_params(port_params_p->sx_port_params);
        if (err != SX_STATUS_SUCCESS) {
            goto out;
        }
    }

    err = span_analyzer_validation_cb_wrap(log_port);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to validate log port 0x%x, err: %s.\n", log_port, sx_status_str(err));
        goto out;
    }

    err = span_db_analyzer_active_sessions_get(log_port, NULL, &span_sessions_count);
    if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Failed to find SPAN sessions for analyzer port (0x%08X). err %s \n",
                   log_port, sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_ADD) {
        err = __validate_analyzer_port(log_port);
        if (err != SX_STATUS_SUCCESS) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Validation for new SPAN analyzer port (0x%x) failed, err: %s. \n",
                       log_port,
                       sx_status_str(err));
        }

        err = span_analyzer_port_multi_session_use(span_session_id, log_port, &is_type_equal);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_analyzer_port_multi_session_use(Session id %d, Port 0x%x) failed, err: %s. \n",
                       span_session_id, log_port, sx_status_str(err));
            goto out;
        }

        /* If Span type is not equal, current session cant set the same port as analyzer port */
        if (is_type_equal != TRUE) {
            SX_LOG_ERR("current session type is not the same as other session type that used the same analyzer port \n");
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        err = span_analyzer_set_cb_wrap(cmd, log_port, port_params_p, span_session_id);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__span_analyzer_set(span %d, 0x%x) failed, err: %s. \n",
                       span_session_id_int, log_port, sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d failed, err: %s. \n", cmd, sx_status_str(err));
        break;
    }

    if ((cmd == SX_ACCESS_CMD_ADD) && (span_sessions_count == 0)) {
        /* Adding port as analyzer to the first SPAN session */
        err = port_span_mode_local_analyzer_set(log_port, TRUE);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("port_span_mode_local_analyzer_set 0x%x failed: (%s).\n",
                       log_port, sx_status_str(err));
            goto out;
        }
    } else if ((cmd == SX_ACCESS_CMD_DELETE) && (span_sessions_count == 1)) {
        /* Removing analyzer port from the last SPAN session */
        err = port_span_mode_local_analyzer_set(log_port, FALSE);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("port_span_mode_local_analyzer_set 0x%x failed: (%s).\n",
                       log_port, sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_analyzer_port_multi_session_use(sx_span_session_id_t curr_span_session_id,
                                                 sx_port_log_id_t     log_port,
                                                 boolean_t           *is_type_equal)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_span_analyzer_port_params_t port_params;
    sx_span_session_id_t           span_session_id_list;
    sx_span_session_id_int_t       span_session_id_internal_list;
    uint32_t                       span_sessions_cnt = 1;
    sx_span_session_params_t       span_session_params;
    sx_span_session_params_t       curr_span_session_params;

    /* Get list of sessions (in size of 1) */
    /* Need only 1 session in order to find the session type to be compared with the current session type */
    err = span_db_port_analyzer_get(log_port, &port_params, &span_session_id_internal_list, &span_sessions_cnt);
    if ((err != SX_STATUS_SUCCESS) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("span_db_port_analyzer_get(span int id = %d, Port = 0x%x) failed, err: (%d) %s. \n",
                   span_session_id_internal_list, log_port, err, sx_status_str(err));
        goto out;
    }

    if (err == SX_STATUS_ENTRY_NOT_FOUND) {
        err = SX_STATUS_SUCCESS;
        *is_type_equal = TRUE;
        goto out;
    }

    /* Convert internal to external session IDs */
    err = span_db_session_int_to_ext(span_session_id_internal_list, &span_session_id_list);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_session_int_to_ext( Int session = %d, Ext session = %d) failed, err: %s. \n",
                   span_session_id_internal_list,
                   span_session_id_list,
                   sx_status_str(err));
        goto out;
    }

    /* Get session type */
    err = span_session_get(span_session_id_list, &span_session_params);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_session_get(span %d, 0x%x) failed, err: %s. \n",
                   span_session_id_list, log_port, sx_status_str(err));
        goto out;
    }

    /* Get session type for the current session*/
    err = span_session_get(curr_span_session_id, &curr_span_session_params);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("*span_session_get(span %d, 0x%x) failed, err: %s. \n",
                   curr_span_session_id, log_port, sx_status_str(err));
        goto out;
    }

    /* Compare current used session type with DB session that use the same analyzer port */
    if (((curr_span_session_params.span_type == SX_SPAN_TYPE_LOCAL_ETH_TYPE1) &&
         (span_session_params.span_type != SX_SPAN_TYPE_LOCAL_ETH_TYPE1)) ||
        ((span_session_params.span_type == SX_SPAN_TYPE_LOCAL_ETH_TYPE1) &&
         (curr_span_session_params.span_type != SX_SPAN_TYPE_LOCAL_ETH_TYPE1))) {
        SX_LOG_ERR("current session = %d, Session type = %d \n",
                   curr_span_session_id,
                   curr_span_session_params.span_type);
        SX_LOG_ERR("DB session = %d, DB Session type = %d \n", span_session_id_list, span_session_params.span_type);
        *is_type_equal = FALSE;
    } else {
        *is_type_equal = TRUE;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_analyzer_get(const sx_port_log_id_t          log_port,
                              sx_span_analyzer_port_params_t *port_params_p,
                              sx_span_session_id_t           *span_session_id_list_p,
                              uint32_t                       *span_sessions_cnt_p)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    uint32_t                  idx;
    sx_span_session_id_int_t *span_session_id_int_list_p = NULL;
    uint32_t                  span_session_id_list_size;
    uint32_t                  sessions_cnt = 0;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(port_params_p);
    VALIDATE_POINTER_NOT_NULL(span_session_id_list_p);
    VALIDATE_POINTER_NOT_NULL(span_sessions_cnt_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Validate Port */
    VALIDATE_PORT(span_analyzer_get, log_port);

    err = span_analyzer_validation_cb_wrap(log_port);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to validate log port 0x%x, err: %s.\n", log_port, sx_status_str(err));
        goto out;
    }

    /* Allocate temporary storage for list of internal session IDs */
    span_session_id_int_list_p = (sx_span_session_id_int_t*)cl_malloc(
        sizeof(sx_span_session_id_int_t) * (*span_sessions_cnt_p));
    if (!span_session_id_int_list_p) {
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    span_session_id_list_size = *span_sessions_cnt_p;

    err = span_db_port_analyzer_get(log_port, port_params_p, span_session_id_int_list_p, span_sessions_cnt_p);
    if (err != SX_STATUS_SUCCESS) {
        if (err != SX_STATUS_ENTRY_NOT_FOUND) {
            SX_LOG_ERR("span_db_port_analyzer_get(0x%x) failed, err: %s. \n",
                       log_port,  sx_status_str(err));
        }
        goto out;
    }

    /* Convert internal to external session IDs */
    sessions_cnt = MIN(*span_sessions_cnt_p, span_session_id_list_size);
    for (idx = 0; idx < sessions_cnt; idx++) {
        err = span_db_session_int_to_ext(span_session_id_int_list_p[idx],
                                         &span_session_id_list_p[idx]);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__span_analyzer_get(0x%x) failed, err: %s. \n",
                       log_port,  sx_status_str(err));
            goto out;
        }
    }

out:
    if (span_session_id_int_list_p) {
        CL_FREE_N_NULL(span_session_id_int_list_p);
    }
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_analyzer_port_test(const sx_port_log_id_t log_port, boolean_t *port_is_analyzer)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_span_analyzer_port_params_t port_params;
    sx_span_session_id_t           span_session_id_list;
    uint32_t                       span_sessions_cnt = 1;

    SX_MEM_CLR(port_params);
    SX_MEM_CLR(span_session_id_list);

    VALIDATE_POINTER_NOT_NULL(port_is_analyzer);

    *port_is_analyzer = FALSE;
    err = span_analyzer_get(log_port, &port_params, &span_session_id_list, &span_sessions_cnt);
    if (err != SX_STATUS_SUCCESS) {
        if (err == SX_STATUS_ENTRY_NOT_FOUND) {
            err = SX_STATUS_SUCCESS;
        } else {
            SX_LOG_ERR("Fail to get SPAN info for port (0x%x), err: %s.\n",
                       log_port,  sx_status_str(err));
        }
        goto out;
    }
    *port_is_analyzer = TRUE;

out:
    return err;
}

sx_status_t span_init_set_sx(const sx_span_init_params_t *port_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(port_params_p);

    /* Save configuration data if valid */
    switch (port_params_p->version) {
    case SX_SPAN_MIRROR_HEADER_VERSION_0:
        span_db_header_version_set(port_params_p->version);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("invalid mirror header version %u\n", port_params_p->version);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_init_set_spectrum(const sx_span_init_params_t *port_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(port_params_p);

    /* Save configuration data if valid */
    switch (port_params_p->version) {
    case SX_SPAN_MIRROR_HEADER_VERSION_0:
    case SX_SPAN_MIRROR_HEADER_VERSION_1:
    case SX_SPAN_MIRROR_HEADER_NONE:
        span_db_header_version_set(port_params_p->version);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("invalid mirror header version %u\n", port_params_p->version);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_init_set_spectrum2(const sx_span_init_params_t *port_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(port_params_p);

    /* Save configuration data if valid */
    switch (port_params_p->version) {
    case SX_SPAN_MIRROR_HEADER_VERSION_0:
    case SX_SPAN_MIRROR_HEADER_VERSION_1:
    case SX_SPAN_MIRROR_HEADER_VERSION_2:
    case SX_SPAN_MIRROR_HEADER_NONE:
        span_db_header_version_set(port_params_p->version);
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("invalid mirror header version %u\n", port_params_p->version);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_init_set(const sx_span_init_params_t *port_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(port_params_p);

    /* Reject if this function was already called without intervening deinit */
    if (SPAN_MODULE_INIT_YES == g_init_set) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("SPAN module already initialized\n");
        goto out;
    }

    /* Reject if any mirroring resources are in use */
    if (span_db_any_sessions_used()) {
        err = SX_STATUS_ALREADY_INITIALIZED;
        SX_LOG_ERR("cannot init while span session exists\n");
        goto out;
    }

    /* Call device-specific code */
    if (brg_context.spec_cb_g.span_init_set_cb) {
        err = brg_context.spec_cb_g.span_init_set_cb(port_params_p);
        if (err) {
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    /* Note init function called */
    g_init_set = SPAN_MODULE_INIT_YES;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_deinit_set(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Reject if deinit was already called */
    if (SPAN_MODULE_INIT_NO == g_init_set) {
        err = SX_STATUS_DB_NOT_INITIALIZED;
        SX_LOG_ERR("SPAN module not initialized\n");
        goto out;
    }

    /* Reject if any mirroring resources are in use */
    if (span_db_any_sessions_used()) {
        err = SX_STATUS_RESOURCE_IN_USE;
        SX_LOG_ERR("cannot deinit while span session exists\n");
        goto out;
    }

    /* Set configuration data to default */
    span_db_header_version_set(SX_SPAN_MIRROR_HEADER_VERSION_0);

    /* Note deinit function called */
    g_init_set = SPAN_MODULE_INIT_NO;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_init_spectrum(void)
{
    sx_utils_status_t           utils_status = SX_UTILS_STATUS_SUCCESS;
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    gc_object_type_attributes_t object_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(object_attr);

    object_attr.free_objects_threshold = 0;
    object_attr.per_object_threshold = rm_resource_global.span_session_id_max_internal;
    object_attr.fence_type = GC_FENCE_TYPE_SLOW;
    object_attr.hw_operation_needed = TRUE;
    object_attr.immediate_fence_needed = FALSE;
    object_attr.max_object_count = rm_resource_global.span_session_id_max_internal;
    utils_status = gc_object_init(GC_OBJECT_TYPE_SPAN, &object_attr, __span_gc_delete_cb, NULL);
    /* coverity[unchecked_value] */
    sx_status = sx_utils_status_to_sx_status(utils_status);
    if (SX_UTILS_CHECK_FAIL(utils_status)) {
        SX_LOG_ERR("Failed to initialize SPAN object type in GC, utils_err = [%s]\n",
                   SX_UTILS_STATUS_MSG(utils_status));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t span_deinit_set_spectrum(void)
{
    sx_utils_status_t sx_utils_status = SX_UTILS_STATUS_SUCCESS;
    sx_status_t       sx_status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    sx_utils_status = gc_object_deinit(GC_OBJECT_TYPE_SPAN);
    sx_status = SX_UTILS_STATUS_TO_SX_STATUS(sx_utils_status);
    if (SX_UTILS_CHECK_FAIL(sx_utils_status)) {
        SX_LOG_ERR("Failed to deinitialize GC object type %s, err = [%s]\n",
                   GC_OBJECT_TYPE_STR(GC_OBJECT_TYPE_SPAN),
                   SX_UTILS_STATUS_MSG(sx_utils_status));
    }

    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t span_session_counter_get_spectrum(const sx_access_cmd_t      cmd,
                                              const sx_span_session_id_t span_session_id,
                                              sx_span_counter_set_t     *counter_set_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(counter_set_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Get the data */
    err = span_db_session_counter_get(cmd, span_session_id_int, counter_set_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_session_counter_get(cmd %d, session %d) failed, err: %s. \n",
                   cmd, span_session_id_int, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_session_counter_get(const sx_access_cmd_t      cmd,
                                     const sx_span_session_id_t span_session_id,
                                     sx_span_counter_set_t     *counter_set_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(counter_set_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Call device-specific code */
    if (brg_context.spec_cb_g.span_session_counter_get_cb) {
        err = brg_context.spec_cb_g.span_session_counter_get_cb(cmd,
                                                                span_session_id,
                                                                counter_set_p);
        if (err) {
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_tables_set_spectrum(const sx_access_cmd_t cmd, const sx_span_session_id_t span_session_id)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        err = span_db_mirror_tables_set(cmd, span_session_id_int);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("span_db_mirror_tables_set(cmd %d, session %d) failed, err: %s. \n",
                       cmd, span_session_id_int, sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d failed, err: %s. \n", cmd, sx_status_str(err));
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_tables_set(const sx_access_cmd_t cmd, const sx_span_session_id_t span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Call device-specific code */
    if (brg_context.spec_cb_g.span_mirror_tables_set_cb) {
        err = brg_context.spec_cb_g.span_mirror_tables_set_cb(cmd,
                                                              span_session_id);
        if (err) {
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_tables_get_spectrum(sx_span_session_id_t *span_session_id_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(span_session_id_p);

    VALIDIATE_MODULE_INITIALIZED();

    err = span_db_mirror_tables_get(&span_session_id_int);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_mirror_tables_get failed, err: %s. \n",
                   sx_status_str(err));
        goto out;
    }
    err = span_db_session_int_to_ext(span_session_id_int,
                                     span_session_id_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_db_session_int_to_ext(%d) failed, err: %s. \n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_tables_get(sx_span_session_id_t *span_session_id_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(span_session_id_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Call device-specific code */
    if (brg_context.spec_cb_g.span_mirror_tables_get_cb) {
        err = brg_context.spec_cb_g.span_mirror_tables_get_cb(span_session_id_p);
        if (err) {
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_drops_set_spectrum(const sx_access_cmd_t                cmd,
                                           const sx_span_session_id_t           span_session_id,
                                           const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                           const sx_span_drop_reason_t         *drop_reason_list_p,
                                           uint32_t                             drop_reason_cnt)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("span_session_id [%d] exceeds range [0 - %d]\n",
                   span_session_id, rm_resource_global.span_session_id_max_external);
        goto out;
    }

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        goto out;
    }

    err = span_db_mirror_drops_set(cmd, span_session_id_int, drop_mirroring_attr_p,
                                   drop_reason_list_p, drop_reason_cnt);
    if (err) {
        SX_LOG_ERR("Drop-Mirror set failed for %d, err: %s. \n", span_session_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_drops_set(const sx_access_cmd_t                cmd,
                                  const sx_span_session_id_t           span_session_id,
                                  const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                  const sx_span_drop_reason_t         *drop_reason_list_p,
                                  uint32_t                             drop_reason_cnt)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Call device-specific code */
    if (brg_context.spec_cb_g.span_mirror_drops_set_cb) {
        err = brg_context.spec_cb_g.span_mirror_drops_set_cb(cmd,
                                                             span_session_id,
                                                             drop_mirroring_attr_p,
                                                             drop_reason_list_p,
                                                             drop_reason_cnt);
        if (err) {
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_drops_get_spectrum(const sx_span_session_id_t           span_session_id,
                                           const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                           sx_span_drop_reason_t               *drop_reason_list_p,
                                           uint32_t                            *drop_reason_cnt_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    if (!RM_SPAN_SESSION_ID_CHECK_MAX_EXTERNAL(span_session_id)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("span_session_id [%d] exceeds range [0 - %d]\n",
                   span_session_id, rm_resource_global.span_session_id_max_external);
        goto out;
    }

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        err = SX_STATUS_ENTRY_NOT_FOUND;
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        goto out;
    }

    err = span_db_mirror_drops_get(span_session_id_int, drop_mirroring_attr_p,
                                   drop_reason_list_p, drop_reason_cnt_p);
    if (err) {
        SX_LOG_ERR("Drop-Mirror get failed for %d, err: %s. \n", span_session_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_drops_get(const sx_span_session_id_t           span_session_id,
                                  const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                  sx_span_drop_reason_t               *drop_reason_list_p,
                                  uint32_t                            *drop_reason_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(drop_reason_cnt_p);

    VALIDIATE_MODULE_INITIALIZED();

    /* Call device-specific code */
    if (brg_context.spec_cb_g.span_mirror_drops_get_cb) {
        err = brg_context.spec_cb_g.span_mirror_drops_get_cb(span_session_id,
                                                             drop_mirroring_attr_p,
                                                             drop_reason_list_p,
                                                             drop_reason_cnt_p);
        if (err) {
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_session_ref_cnt_inc(span_client_handle_t user_handle, const sx_span_session_id_t span_session_id)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Increment session reference count */
    err = span_db_session_ref_cnt_inc(user_handle, span_session_id_int);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_session_ref_cnt_dec(span_client_handle_t user_handle, const sx_span_session_id_t span_session_id)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    /* Decrement session reference count */
    err = span_db_session_ref_cnt_dec(user_handle, span_session_id_int);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_session_lock(span_client_handle_t       user_handle,
                              const sx_span_session_id_t span_session_id,
                              sx_span_session_id_int_t  *span_session_id_int)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(span_session_id_int);

    VALIDIATE_MODULE_INITIALIZED();

    /* Lock session if it exists */
    err = span_db_session_lock(user_handle, span_session_id, span_session_id_int);
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_session_unlock(span_client_handle_t user_handle, const sx_span_session_id_t span_session_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    /* Unlock session if it exists */
    err = span_db_session_unlock(user_handle, span_session_id);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_user_init(span_cb_relocate_t cb_relocate, span_client_handle_t  *user_handle_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(user_handle_p);

    /* Allocate user */
    err = span_db_user_init(cb_relocate, user_handle_p);

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_user_deinit(span_client_handle_t user_handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* Deallocate user */
    err = span_db_user_deinit(user_handle);

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __dump_module_span_wrapper(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = span_dbg_generate_dump(dbg_dump_params_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("dbg_dump failed to generate SPAN module dump.\n");
    }

    return err;
}


sx_status_t span_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (FALSE == span_init_done) {
        goto out;
    }

    dbg_utils_pprinter_module_header_print(dbg_dump_params_p->stream, "SPAN Mirroring Module");

    err = span_db_dbg_generate_dump(dbg_dump_params_p);
    CL_ASSERT(SX_STATUS_SUCCESS == err);

    err = SX_STATUS_SUCCESS;

out:
    return M_UTILS_SX_LOG_EXIT(err);
}

sx_status_t __handle_sbib(IN sx_access_cmd_t cmd,                            /* SET/GET */
                          IN sx_port_id_t port_log_id, INOUT uint32_t                         *buff_size,  /* buffer size */
                          OUT span_mirror_egress_buff_status_t   *status,     /* 0-buff size not reach requested size
                                                                               *  1-buff size do reach requested size*/
                          IN uint8_t type,                                     /* Supported values = 0 */
                          IN uint8_t int_buff_index)                            /* Supported values = 0 */
{
    struct ku_sbib_reg sbib_reg_data;
    sxd_reg_meta_t     sbib_reg_meta;
    sx_status_t        rc = SX_STATUS_SUCCESS;
    sx_swid_id_t       swid;
    sx_port_info_t     port_info;

    if (buff_size == NULL) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Fail: buff_size = NULL\n");
        return rc;
    }

    if (status == NULL) {
        rc = SX_STATUS_ERROR;
        SX_LOG_ERR("Fail: status = NULL\n");
        return rc;
    }

    if (CPU_PORT_PHY_ID == SX_PORT_PHY_ID_GET(port_log_id)) {
        swid = 0;
    } else {
        rc = port_db_info_get(port_log_id, &port_info);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", port_log_id);
            return rc;
        }
        swid = port_info.swid_id;
    }


    SX_MEM_CLR_TYPE(&sbib_reg_data, struct ku_sbib_reg);
    SX_MEM_CLR(sbib_reg_meta);
    sbib_reg_meta.swid = swid;
    sbib_reg_meta.dev_id = SX_PORT_DEV_ID_GET(port_log_id);
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(sbib_reg_data.local_port, sbib_reg_data.lp_msb,
                                        SX_PORT_PHY_ID_GET(port_log_id));
    sbib_reg_data.buff_size = *buff_size;
    sbib_reg_data.status = *status;
    sbib_reg_data.type = type;
    sbib_reg_data.int_buff_index = int_buff_index;

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        sbib_reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
        break;

    case SX_ACCESS_CMD_GET:
        sbib_reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
        break;

    default:
        SX_LOG_ERR("Unsupported command in __handle_sbib() cmd-(%d). (%s)\n", cmd, sx_status_str(rc));
        return SX_STATUS_CMD_UNSUPPORTED;
        break;
    }

    rc =
        sxd_status_to_sx_status(sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_SBIB_E, &sbib_reg_data,
                                                                    &sbib_reg_meta, 1,
                                                                    NULL, NULL));

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Can't send SET-SBIB EMAD (%s)\n", sx_status_str(rc));
        return rc;
    }

    SX_LOG_DBG(
        "[%s] SBIB, [dev id=%d],[swid=%d], [local_port=0x%x], [buff_size=%d], [status=%d], [type=%d], [index=%d]\n",
        sx_access_cmd_str(cmd),
        sbib_reg_meta.dev_id,
        sbib_reg_meta.swid,
        SX_PORT_PHY_ID_GET(port_log_id),
        sbib_reg_data.buff_size,
        sbib_reg_data.status,
        sbib_reg_data.type,
        sbib_reg_data.int_buff_index);

    if (cmd == SX_ACCESS_CMD_GET) {
        *status = sbib_reg_data.status;
        *buff_size = sbib_reg_data.buff_size;
    }

    return rc;
}

sx_status_t span_egress_mirror_handle_buffer(const sx_access_cmd_t cmd, const sx_port_log_id_t log_port_id)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    err = span_egress_mirror_alloc_buffer_cb_wrapper(cmd,
                                                     log_port_id,
                                                     SPAN_MIRROR_DIRECTION_EGRESS,
                                                     SPAN_EGRESS_MIRROR_BUFF_TYPE_FLEX_ACL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR_OR_WRN(err,
                          "Failed in span_egress_mirror_alloc_buffer_cb_wrapper() , cmd=%d, port=0x%x, error: %s\n",
                          cmd, log_port_id, sx_status_str(err));
        goto out;
    }

out:
    return err;
}

static sx_status_t __span_egress_mirror_alloc_buffer(const sx_access_cmd_t  cmd,
                                                     const sx_port_log_id_t mirror_port,
                                                     const sx_port_width_t  port_width)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    span_mirror_egress_buff_status_t status = SPAN_MIRROR_EGRESS_BUFF_SIZE_NOT_COMPLETE;
    buffer_units_t                   port_buff_size = 0;
    buffer_units_t                   sbib_buff_size = 0;

    /* Get correct port buffer size needed */
    port_buff_size = cos_headroom_egress_buffer_size_get(port_width);
    if (cmd == SX_ACCESS_CMD_ADD) {
        sbib_buff_size = port_buff_size;
        /* Validate we have enough headroom space for egress mirroring */
        rc = port_pg_headroom_consumption_check(mirror_port, sbib_buff_size);
        if (rc != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Not enough headroom space for egress mirroring on port 0x%x\n", mirror_port);
            goto out;
        }
    } else { /* SX_ACCESS_CMD_DELETE */
        sbib_buff_size = 0;
    }

    /* Config SBIB */
    rc = __handle_sbib(SX_ACCESS_CMD_SET,
                       mirror_port,
                       &sbib_buff_size,
                       &status,
                       SPAN_EGRESS_MIRROR_SBIB_TYPE,    /* Supported values = 0 */
                       SPAN_EGRESS_MIRROR_SBIB_INDEX);   /* Supported values = 0 */
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Error: __handle_sbib failed. [cmd=SET, port=0x%x, buff_size=%d]\n",
                   mirror_port, sbib_buff_size);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* Consume buff from free buff counting */
    if (cmd == SX_ACCESS_CMD_ADD) {
        sx_cos_db_reserve_buffers_space(port_buff_size,
                                        SX_COS_PORT_BUFF_POOL_DIRECTION_EGRESS_E);
    } else { /* SX_ACCESS_CMD_DELETE */
        sx_cos_db_release_buffers_space(port_buff_size,
                                        SX_COS_PORT_BUFF_POOL_DIRECTION_EGRESS_E);
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __span_egress_mirror_alloc_buffer_cb_event(adviser_event_e event_type, void *param)
{
    sx_status_t                           err = SX_STATUS_SUCCESS;
    sx_port_info_t                        port_info;
    port_admin_state_change_event_data_t *data;

    SX_LOG_ENTER();

    VALIDATE_POINTER_NOT_NULL(param);

    data = (port_admin_state_change_event_data_t*)param;

    if (event_type != ADVISER_EVENT_POST_PORT_ADMIN_STATE_CHANGE_E) {
        SX_LOG_ERR("Unexpected event %u = %s in  span egress mirror alloc buffer event\n",
                   event_type,
                   ADVISER_EVENT_STR(event_type));
        err = SX_STATUS_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(err = port_db_info_get(data->log_port, &port_info))) {
        SX_LOG_ERR_OR_WRN(err,
                          "Failed in __span_db_egress_mirror_alloc_buffer_cb_event() , error: %s\n",
                          sx_status_str(err));
        goto out;
    }

    if (port_info.port_mirror_egress_ref_count > 0) {
        err = __span_egress_mirror_alloc_buffer(data->cmd, data->log_port, port_info.mapping.width);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR_OR_WRN(err,
                              "Failed in __span_egress_mirror_alloc_buffer() , error: %s\n",
                              sx_status_str(err));
            err = SX_STATUS_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_egress_mirror_alloc_buffer_cb_wrapper(const sx_access_cmd_t                cmd,
                                                       const sx_port_log_id_t               mirror_port,
                                                       const span_mirror_direction_t        mirror_direction,
                                                       const span_egress_mirror_buff_type_e type)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    if (brg_context.spec_cb_g.span_egress_mirror_alloc_buffer_cb != NULL) {
        rc = brg_context.spec_cb_g.span_egress_mirror_alloc_buffer_cb(mirror_port,
                                                                      mirror_direction,
                                                                      cmd,
                                                                      type);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_egress_mirror_alloc_buffer_cb() , error: %s\n", sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_SUCCESS;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static boolean_t __is_mirror_direction_egress(const span_mirror_direction_t mirror_direction)
{
    return ((SPAN_MIRROR_DIRECTION_EGRESS == mirror_direction) ||
            (SPAN_MIRROR_DIRECTION_EGRESS_ECN == mirror_direction) ||
            (SPAN_MIRROR_DIRECTION_EGRESS_TC_LATENCY == mirror_direction));
}

sx_status_t span_egress_mirror_alloc_buffer_spectrum(const sx_port_log_id_t               mirror_port,
                                                     const span_mirror_direction_t        mirror_direction,
                                                     const sx_access_cmd_t                cmd,
                                                     const span_egress_mirror_buff_type_e type)
{
    sx_status_t           rc = SX_STATUS_SUCCESS;
    buffer_units_t        egress_buff_size = 0;
    uint32_t              ref_count;
    sx_port_info_t        port_info;
    sx_port_admin_state_t port_admin_state;

    SX_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = port_db_info_get(mirror_port, &port_info))) {
        SX_LOG_ERR("Can't Get Port %u Info (%s).\n", mirror_port, sx_status_str(rc));
        return M_UTILS_SX_LOG_EXIT(rc);
    }

    /* Allocate shared buffer for egress direction */
    if (__is_mirror_direction_egress(mirror_direction)) {
        switch (cmd) {
        case SX_ACCESS_CMD_ADD:
        case SX_ACCESS_CMD_DELETE:
            rc = span_db_egress_mirror_ref_count_set(cmd, mirror_port, &ref_count, type);
            if (rc != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Error: span_db_egress_mirror_ref_count_set failed. [port=0x%x]\n", mirror_port);
                goto out;
            }

            if (cmd == SX_ACCESS_CMD_ADD) {
                egress_buff_size = cos_headroom_egress_buffer_size_get(port_info.mapping.width);
            } else {  /* SX_ACCESS_CMD_DELETE */
                egress_buff_size = 0;
            }

            /* Config SBIB */
            if (((cmd == SX_ACCESS_CMD_ADD) &&
                 (ref_count == 1)) || ((cmd == SX_ACCESS_CMD_DELETE) && (ref_count == 0))) {
                rc = port_state_get(SX_ACCESS_CMD_GET,
                                    mirror_port,
                                    NULL,
                                    &port_admin_state,
                                    NULL);
                if (SX_CHECK_FAIL(rc)) {
                    SX_LOG_ERR("port_state_get failed. Error: (%s).\n",
                               sx_status_str(rc));
                    goto rb_ref_count;
                }

                if (port_admin_state == SX_PORT_ADMIN_STATUS_UP) {
                    rc = __span_egress_mirror_alloc_buffer(cmd, mirror_port, port_info.mapping.width);
                    if (rc != SX_STATUS_SUCCESS) {
                        SX_LOG_ERR("Error: __span_egress_mirror_alloc_buffer failed. [port=0x%x]\n", mirror_port);
                        goto rb_ref_count;
                    }
                }
            }

            /* Set size (SBIB) to port DB */
            if (type == SPAN_EGRESS_MIRROR_BUFF_TYPE_SPAN_MIRROR) {
                rc = port_db_egress_mirror_buff_set(mirror_port, egress_buff_size);
                if (rc != SX_STATUS_SUCCESS) {
                    SX_LOG_ERR("Error: port_db_egress_buff_set failed. [port=0x%x, buff_size=%d]\n",
                               mirror_port, egress_buff_size);
                    goto out;
                }
            }

            break;

        default:
            SX_LOG_ERR("Error: Command not supported : %d.\n", cmd);
            rc = SX_STATUS_CMD_UNSUPPORTED;
            break;
        }
    }

    goto out;

rb_ref_count:
    if (cmd == SX_ACCESS_CMD_ADD) {
        span_db_egress_mirror_ref_count_set(SX_ACCESS_CMD_DELETE, mirror_port, &ref_count, type);
    } else { /* SX_ACCESS_CMD_DELETE */
        span_db_egress_mirror_ref_count_set(SX_ACCESS_CMD_ADD, mirror_port, &ref_count, type);
    }
out:
    SX_LOG_EXIT();
    return rc;
}

static sx_utils_status_t __span_gc_delete_cb(const void *gc_context)
{
    sx_status_t          status = SX_STATUS_SUCCESS;
    sx_span_session_id_t span_session_id = (sx_span_session_id_t)(intptr_t)gc_context;

    SX_LOG_ENTER();

    status = span_free_session_id_free_spectrum(span_session_id);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("span_remove_from_gc_queue failed for SPAN session id %d, err: %s.\n",
                   span_session_id, sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return SX_STATUS_TO_SX_UTILS_STATUS(status);
}

sx_status_t span_free_session_id_free_spectrum(sx_span_session_id_t span_session_id)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    status = span_db_session_id_free(span_session_id);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("SPAN session id %d isn't found, err: %s.\n",
                   span_session_id, sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t span_mirror_bind_set(const sx_access_cmd_t             cmd,
                                 const sx_span_mirror_bind_key_t  *key_p,
                                 const sx_span_mirror_bind_attr_t *attr_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_bind_set_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_bind_set_cb(cmd, key_p, attr_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_mirror_bind_set_cb() , error: %s\n", sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_mirror_bind_get(const sx_span_mirror_bind_key_t *key_p, sx_span_mirror_bind_attr_t      *attr_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_bind_get_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_bind_get_cb(key_p, attr_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_mirror_bind_get_cb() , error: %s\n", sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_mirror_bind_set_spectrum(const sx_access_cmd_t             cmd,
                                          const sx_span_mirror_bind_key_t  *key_p,
                                          const sx_span_mirror_bind_attr_t *attr_p)
{
    sx_status_t     sx_status = SX_STATUS_SUCCESS;
    sx_access_cmd_t access_cmd;

    if (key_p == NULL) {
        SX_LOG_ERR("key_p is NULL.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (key_p->type != SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E) {
        SX_LOG_ERR("Unsupported bind type.\n");
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        access_cmd = SX_ACCESS_CMD_ADD;
        break;

    case SX_ACCESS_CMD_UNBIND:
        access_cmd = SX_ACCESS_CMD_DELETE;
        break;

    default:
        SX_LOG_ERR("Unsupported cmd.\n");
        sx_status = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    sx_status = span_mirror_set_common(access_cmd,
                                       key_p->key.ing_sb_drop.log_port,
                                       SPAN_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER,
                                       attr_p->span_session_id);
    if (sx_status == SX_STATUS_ENTRY_ALREADY_EXISTS) {
        sx_status = SX_STATUS_ENTRY_ALREADY_BOUND;
    }

out:
    return sx_status;
}

sx_status_t span_mirror_bind_get_spectrum(const sx_span_mirror_bind_key_t *key_p,
                                          sx_span_mirror_bind_attr_t      *attr_p)
{
    sx_status_t sx_status = SX_STATUS_SUCCESS;

    if (key_p == NULL) {
        SX_LOG_ERR("key_p is NULL.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        sx_status = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (key_p->type != SX_SPAN_MIRROR_BIND_ING_SHARED_BUFFER_DROP_E) {
        SX_LOG_ERR("Unsupported bind type.\n");
        sx_status = SX_STATUS_UNSUPPORTED;
        goto out;
    }

    sx_status = span_mirror_get_common(key_p->key.ing_sb_drop.log_port,
                                       SPAN_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER,
                                       &(attr_p->span_session_id));
    if (sx_status == SX_STATUS_ENTRY_NOT_FOUND) {
        sx_status = SX_STATUS_ENTRY_NOT_BOUND;
    }

out:
    return sx_status;
}

sx_status_t span_mirror_bind_set_spectrum2(const sx_access_cmd_t             cmd,
                                           const sx_span_mirror_bind_key_t  *key_p,
                                           const sx_span_mirror_bind_attr_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (key_p == NULL) {
        SX_LOG_ERR("key_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!SX_SPAN_MIRROR_BIND_TYPE_CHECK_RANGE(key_p->type)) {
        SX_LOG_ERR("Invalid bind type [%u]\n", key_p->type);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        err = span_db_mirror_bind(key_p, attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Bind type [%u] to session %d failed\n", key_p->type, attr_p->span_session_id);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_UNBIND:
        err = span_db_mirror_unbind(key_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Unbind type [%u] failed\n", key_p->type);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported cmd.\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    return err;
}

sx_status_t span_mirror_bind_get_spectrum2(const sx_span_mirror_bind_key_t *key_p,
                                           sx_span_mirror_bind_attr_t      *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (key_p == NULL) {
        SX_LOG_ERR("key_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!SX_SPAN_MIRROR_BIND_TYPE_CHECK_RANGE(key_p->type)) {
        SX_LOG_ERR("Invalid bind type [%u]\n", key_p->type);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = span_db_mirror_bind_get(key_p, attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Find to get bind type [%u]\n", key_p->type);
        goto out;
    }

out:
    return err;
}

sx_status_t span_session_mirror_bound_get(const sx_span_session_id_t span_session_id,
                                          sx_span_mirror_bind_key_t *mirror_bind_key_list_p,
                                          uint32_t                  *mirror_bind_key_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_session_mirror_bound_get_cb != NULL) {
        rc = brg_context.spec_cb_g.span_session_mirror_bound_get_cb(span_session_id,
                                                                    mirror_bind_key_list_p,
                                                                    mirror_bind_key_cnt_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_session_mirror_bound_get_cb() , error: %s\n",
                              sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_session_mirror_bound_get_spectrum2(const sx_span_session_id_t span_session_id,
                                                    sx_span_mirror_bind_key_t *mirror_bind_key_list_p,
                                                    uint32_t                  *mirror_bind_key_cnt_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;

    SX_LOG_ENTER();

    if (mirror_bind_key_cnt_p == NULL) {
        SX_LOG_ERR("mirror_bind_key_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*mirror_bind_key_cnt_p > 0) && (mirror_bind_key_list_p == NULL)) {
        SX_LOG_ERR("mirror_bind_key_list_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (err) {
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    err = span_db_session_mirror_bound_get(span_session_id_int, mirror_bind_key_list_p, mirror_bind_key_cnt_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Find to get mirror bound list for session [%u]\n", span_session_id);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_enable_set(const sx_access_cmd_t                 cmd,
                                   const sx_span_mirror_enable_object_t *object_p,
                                   const sx_span_mirror_enable_attr_t   *attr_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_enable_set_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_enable_set_cb(cmd, object_p, attr_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_mirror_enable_set_cb() , error: %s\n", sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_mirror_enable_get(const sx_span_mirror_enable_object_t *object_p,
                                   sx_span_mirror_enable_attr_t         *attr_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_enable_get_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_enable_get_cb(object_p, attr_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_mirror_enable_get_cb() , error: %s\n", sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_mirror_enable_iter_get(const sx_access_cmd_t                cmd,
                                        sx_span_mirror_enable_object_t      *object_key_p,
                                        sx_span_mirror_enable_iter_filter_t *filter_p,
                                        sx_span_mirror_enable_object_t      *object_list_p,
                                        uint32_t                            *object_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_enable_iter_get_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_enable_iter_get_cb(cmd,
                                                                  object_key_p,
                                                                  filter_p,
                                                                  object_list_p,
                                                                  object_cnt_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_mirror_enable_iter_get_cb() , error: %s\n", sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}
sx_status_t span_mirror_enable_port_set(const sx_access_cmd_t                   cmd,
                                        const uint32_t                          mirror_enable_cnt,
                                        const sx_span_mirror_enable_port_set_t *mirror_enable_cfg_list_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_enable_port_set_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_enable_port_set_cb(cmd, mirror_enable_cnt, mirror_enable_cfg_list_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_mirror_enable_port_set_cb() , error: %s\n", sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_mirror_enable_port_iter_get(const sx_access_cmd_t                     cmd,
                                             sx_port_log_id_t                          log_port,
                                             sx_span_mirror_enable_port_iter_filter_t *filter_p,
                                             sx_span_mirror_enable_port_set_t         *mirror_enable_cfg_list_p,
                                             uint32_t                                 *mirror_enable_cnt_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_enable_port_iter_get_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_enable_port_iter_get_cb(cmd,
                                                                       log_port,
                                                                       filter_p,
                                                                       mirror_enable_cfg_list_p,
                                                                       mirror_enable_cnt_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR_OR_WRN(rc, "Failed in span_mirror_enable_port_iter_get_cb() , error: %s\n", sx_status_str(rc));
            goto out;
        }
    } else {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_mirror_enable_port_set_spectrum4(const sx_access_cmd_t                   cmd,
                                                  const uint32_t                          mirror_enable_cnt,
                                                  const sx_span_mirror_enable_port_set_t *mirror_enable_cfg_list_p)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    unsigned int i, j;

    SX_LOG_ENTER();
    VALIDIATE_MODULE_INITIALIZED();

    if (mirror_enable_cnt == 0) {
        SX_LOG_ERR("input list count is ZERO.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (mirror_enable_cfg_list_p == NULL) {
        SX_LOG_ERR("mirror_enable_cfg_list_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    for (i = 0; i < mirror_enable_cnt; i++) {
        /* Validate Port */
        VALIDATE_PORT(span_mirror_enable_port_set_spectrum4, mirror_enable_cfg_list_p[i].ingress_log_port);

        for (j = 0; j < mirror_enable_cfg_list_p[i].mirror_disallow_elephant.mirror_trigger_disallow_cnt; j++) {
            if (!SX_SPAN_MIRROR_BIND_TYPE_CHECK_RANGE(mirror_enable_cfg_list_p[i].mirror_disallow_elephant.
                                                      mirror_trigger_disallow[j].type)) {
                SX_LOG_ERR("Invalid mirror bind type [%u] to set mirror enable port of elephant packets\n",
                           mirror_enable_cfg_list_p[i].mirror_disallow_elephant.mirror_trigger_disallow[j].type);
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
        }

        for (j = 0; j < mirror_enable_cfg_list_p[i].mirror_disallow_non_elephant.mirror_trigger_disallow_cnt; j++) {
            if (!SX_SPAN_MIRROR_BIND_TYPE_CHECK_RANGE(mirror_enable_cfg_list_p[i].mirror_disallow_non_elephant.
                                                      mirror_trigger_disallow[j].type)) {
                SX_LOG_ERR("Invalid mirror bind type [%u] to set mirror enable port of none-elephant packets)\n",
                           mirror_enable_cfg_list_p[i].mirror_disallow_non_elephant.mirror_trigger_disallow[j].type);
                err = SX_STATUS_PARAM_EXCEEDS_RANGE;
                goto out;
            }
        }
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        for (i = 0; i < mirror_enable_cnt; i++) {
            err = span_db_mirror_enable_port_set(mirror_enable_cfg_list_p[i].ingress_log_port,
                                                 &mirror_enable_cfg_list_p[i].mirror_disallow_elephant,
                                                 &mirror_enable_cfg_list_p[i].mirror_disallow_non_elephant);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to enable mirror for port 0x%x.\n", mirror_enable_cfg_list_p[i].ingress_log_port);
                goto out;
            }
        }
        break;

    case SX_ACCESS_CMD_UNSET:
        for (i = 0; i < mirror_enable_cnt; i++) {
            err = span_db_mirror_enable_port_unset(mirror_enable_cfg_list_p[i].ingress_log_port,
                                                   &mirror_enable_cfg_list_p[i].mirror_disallow_elephant,
                                                   &mirror_enable_cfg_list_p[i].mirror_disallow_non_elephant);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("Failed to enable mirror for port 0x%x.\n", mirror_enable_cfg_list_p[i].ingress_log_port);
                goto out;
            }
        }
        break;

    default:
        SX_LOG_ERR("Unsupported cmd.\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_enable_port_iter_get_spectrum4(const sx_access_cmd_t                     cmd,
                                                       sx_port_log_id_t                          log_port,
                                                       sx_span_mirror_enable_port_iter_filter_t *filter_p,
                                                       sx_span_mirror_enable_port_set_t         *mirror_enable_cfg_list_p,
                                                       uint32_t                                 *mirror_enable_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    UNUSED_PARAM(filter_p);
    VALIDIATE_MODULE_INITIALIZED();

    if (log_port != 0) {
        /* Validate Port if user specify non-zero log_port */
        VALIDATE_PORT(span_mirror_enable_port_iter_get_spectrum4, log_port);
    }

    if (mirror_enable_cnt_p == NULL) {
        SX_LOG_ERR("mirror_enable_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*mirror_enable_cnt_p > 0) && (mirror_enable_cfg_list_p == NULL)) {
        SX_LOG_ERR("mirror_enable_cfg_list_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = span_db_mirror_enable_port_iter_get(cmd, log_port, filter_p, mirror_enable_cfg_list_p, mirror_enable_cnt_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("%s Failed to get %d span mirror enable port config, err = %s",
                   sx_access_cmd_str(cmd), *mirror_enable_cnt_p, sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_enable_set_spectrum2(const sx_access_cmd_t                 cmd,
                                             const sx_span_mirror_enable_object_t *object_p,
                                             const sx_span_mirror_enable_attr_t   *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (object_p == NULL) {
        SX_LOG_ERR("object_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!SX_SPAN_MIRROR_ENABLE_TYPE_CHECK_RANGE(object_p->type)) {
        SX_LOG_ERR("Invalid enable type [%u]\n", object_p->type);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = span_db_mirror_enable_add(object_p, attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to enable mirror for type %d.\n", object_p->type);
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        err = span_db_mirror_enable_remove(object_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to disable mirror for type %d.\n", object_p->type);
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported cmd.\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_enable_get_spectrum2(const sx_span_mirror_enable_object_t *object_p,
                                             sx_span_mirror_enable_attr_t         *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (object_p == NULL) {
        SX_LOG_ERR("object_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!SX_SPAN_MIRROR_ENABLE_TYPE_CHECK_RANGE(object_p->type)) {
        SX_LOG_ERR("Invalid enable type [%u]\n", object_p->type);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = span_db_mirror_enable_get(object_p, attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get mirror enable for type %d.\n", object_p->type);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_mirror_enable_iter_filter_validate(sx_span_mirror_enable_object_t      *object_key_p,
                                                             sx_span_mirror_enable_iter_filter_t *filter_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    switch (object_key_p->type) {
    case SX_SPAN_MIRROR_ENABLE_ING_WRED_E:
        if (filter_p->pg_filter == SX_SPAN_MIRROR_ENABLE_KEY_PG_FILTER_VALID_E) {
            err = SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_UC_E:
        if (filter_p->pg_filter == SX_SPAN_MIRROR_ENABLE_KEY_PG_FILTER_VALID_E) {
            err = SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_SHARED_BUFFER_DROP_MC_E:
        if (filter_p->pg_filter == SX_SPAN_MIRROR_ENABLE_KEY_PG_FILTER_VALID_E) {
            err = SX_STATUS_PARAM_ERROR;
        }
        if (filter_p->tc_filter == SX_SPAN_MIRROR_ENABLE_KEY_TC_FILTER_VALID_E) {
            err = SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_PG_THRESHOLD_E:
        if (filter_p->tc_filter == SX_SPAN_MIRROR_ENABLE_KEY_TC_FILTER_VALID_E) {
            err = SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_SPAN_MIRROR_ENABLE_ING_TC_THRESHOLD_E:
        if (filter_p->pg_filter == SX_SPAN_MIRROR_ENABLE_KEY_PG_FILTER_VALID_E) {
            err = SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_ECN_E:
        if (filter_p->pg_filter == SX_SPAN_MIRROR_ENABLE_KEY_PG_FILTER_VALID_E) {
            err = SX_STATUS_PARAM_ERROR;
        }
        break;

    case SX_SPAN_MIRROR_ENABLE_EGR_TC_LATENCY_E:
        if (filter_p->pg_filter == SX_SPAN_MIRROR_ENABLE_KEY_PG_FILTER_VALID_E) {
            err = SX_STATUS_PARAM_ERROR;
        }
        break;

    default:
        SX_LOG_ERR("Mirror enable object %u is invalid.\n", object_key_p->type);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        break;
    }

    return err;
}

sx_status_t span_mirror_enable_iter_get_spectrum2(const sx_access_cmd_t                cmd,
                                                  sx_span_mirror_enable_object_t      *object_key_p,
                                                  sx_span_mirror_enable_iter_filter_t *filter_p,
                                                  sx_span_mirror_enable_object_t      *object_list_p,
                                                  uint32_t                            *object_cnt_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (object_key_p == NULL) {
        SX_LOG_ERR("object_key_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (object_cnt_p == NULL) {
        SX_LOG_ERR("object_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!SX_SPAN_MIRROR_ENABLE_TYPE_CHECK_RANGE(object_key_p->type)) {
        SX_LOG_ERR("Invalid enable type [%u]\n", object_key_p->type);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (filter_p != NULL) {
        err = __span_mirror_enable_iter_filter_validate(object_key_p, filter_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Validation failed on enable object and filter.\n");
            goto out;
        }
    }

    VALIDIATE_MODULE_INITIALIZED();

    err = span_db_mirror_enable_iter_get(cmd, object_key_p, filter_p, object_list_p, object_cnt_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("%s Failed to get %d span mirror enable objects; object type = (%u), err = %s",
                   sx_access_cmd_str(cmd), *object_cnt_p,
                   object_key_p->type, sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_tables_attr_set(const sx_access_cmd_t cmd, const sx_span_mirror_tables_attr_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    VALIDIATE_MODULE_INITIALIZED();

    if (brg_context.spec_cb_g.span_mirror_tables_attr_set_cb != NULL) {
        err = brg_context.spec_cb_g.span_mirror_tables_attr_set_cb(cmd, attr_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR_OR_WRN(err, "Failed in span_mirror_tables_attr_set_cb() , error: %s\n", sx_status_str(err));
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_tables_attr_set_spectrum2(const sx_access_cmd_t               cmd,
                                                  const sx_span_mirror_tables_attr_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (attr_p->rate > SX_SPAN_PROBABILITY_RATE_MAX) {
        SX_LOG_ERR("probability rate larger than max valid value.\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
    case SX_ACCESS_CMD_DELETE:
        err = span_db_mirror_tables_attr_set(cmd, attr_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to set mirror tables. \n");
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported cmd.\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_tables_attr_get(sx_span_mirror_tables_attr_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    VALIDIATE_MODULE_INITIALIZED();

    if (brg_context.spec_cb_g.span_mirror_tables_attr_get_cb != NULL) {
        err = brg_context.spec_cb_g.span_mirror_tables_attr_get_cb(attr_p);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR_OR_WRN(err, "Failed in span_mirror_tables_attr_get_cb() , error: %s\n", sx_status_str(err));
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_tables_attr_get_spectrum2(sx_span_mirror_tables_attr_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (attr_p == NULL) {
        SX_LOG_ERR("attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = span_db_mirror_tables_attr_get(attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get mirror tables.\n");
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_header_time_stamp_set(sx_span_hdr_ts_config_t span_ts)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    VALIDIATE_MODULE_INITIALIZED();

    if (brg_context.spec_cb_g.span_header_time_stamp_set_cb != NULL) {
        err = brg_context.spec_cb_g.span_header_time_stamp_set_cb(span_ts);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR_OR_WRN(err, "Failed in span_header_time_stamp_set_cb(), error: %s\n", sx_status_str(err));
            goto out;
        }
    } else {
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_header_time_stamp_set_spectrum(sx_span_hdr_ts_config_t span_ts)
{
    sxd_status_t        sxd_err = SXD_STATUS_SUCCESS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_mtutc_reg mtutc_reg;
    sxd_reg_meta_t      reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mtutc_reg);

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Cannot retrieve device list for MTUTC update [%s].\n", sx_status_str(err));
        goto out;
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.swid = 0;
    mtutc_reg.operation = (sxd_mtutc_operation_t)SX_MTUTC_OP_SET_TIME_NEXT_SEC_E;
    mtutc_reg.utc_sec = span_ts.span_hdr_time_stamp.tv_sec;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    sxd_err = sxd_access_reg_mtutc(&mtutc_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed in MTUTC set, error: %s\n", SXD_STATUS_MSG(sxd_err));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_header_time_stamp_set_spectrum2(sx_span_hdr_ts_config_t span_ts)
{
    sxd_status_t        sxd_err = SXD_STATUS_SUCCESS;
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_mtutc_reg mtutc_reg;
    sxd_reg_meta_t      reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mtutc_reg);

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Cannot retrieve device list for MTUTC update [%s].\n", sx_status_str(err));
        goto out;
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.swid = 0;
    mtutc_reg.operation = (sxd_mtutc_operation_t)SX_MTUTC_OP_SET_TIME_IMMEDIATE_E;
    mtutc_reg.utc_sec = span_ts.span_hdr_time_stamp.tv_sec;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    sxd_err = sxd_access_reg_mtutc(&mtutc_reg, &reg_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Failed in MTUTC set, error: %s\n", SXD_STATUS_MSG(sxd_err));
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __handle_mmgcr(sx_span_attrs_t *attr_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    struct ku_mmgcr_reg mmgcr_reg;
    sxd_reg_meta_t      reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(mmgcr_reg);

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Cannot retrieve device list for MOLP update [%s].\n", sx_status_str(err));
        goto out;
    }

    if (SX_FDB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        SX_LOG_DBG("__handle_mmgcr: device list is empty. [%s].\n", sx_status_str(err));
        goto out;
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.swid = 0;

    mmgcr_reg.device_uid = attr_p->device_uid;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    err = sxd_status_to_sx_status(
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MMGCR_E,
                                            &mmgcr_reg,
                                            &reg_meta, 1,
                                            NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't send SET-MMGCR EMAD (%s)\n", sx_status_str(err));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __handle_molp(sx_port_id_t log_port, uint16_t label_port)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    struct ku_molp_reg molp_reg;
    sxd_reg_meta_t     reg_meta;
    sxd_port_phy_id_t  local_port = 0;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(molp_reg);

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Cannot retrieve device list for MOLP update [%s].\n", sx_status_str(err));
        goto out;
    }

    if (SX_FDB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        SX_LOG_DBG("__handle_molp: device list is empty. [%s].\n", sx_status_str(err));
        goto out;
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_SET;
    reg_meta.swid = 0;
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(molp_reg.local_port,
                                        molp_reg.lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));
    molp_reg.label_port = label_port;

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    err = sxd_status_to_sx_status(
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_MOLP_E,
                                            &molp_reg,
                                            &reg_meta, 1,
                                            NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't send SET-MOLP EMAD (%s)\n", sx_status_str(err));
        goto out;
    }

    local_port = SX_PORT_PHY_ID_GET(log_port);

    err = sxd_status_to_sx_status(sxd_dpt_mirror_label_port_map_set(reg_meta.dev_id, local_port, label_port));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set mirror label port mapping (%s)\n", sx_status_str(err));
        goto out;
    }

    SX_FDB_FOR_EACH_LEAF_DEV_END;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __handle_pllp(sx_port_id_t log_port,
                                 uint8_t     *slot_num_p,
                                 uint16_t    *label_port_p,
                                 uint8_t     *split_num_p)
{
    sx_status_t        err = SX_STATUS_SUCCESS;
    struct ku_pllp_reg pllp_reg;
    sxd_reg_meta_t     reg_meta;

    SX_FDB_FOR_EACH_LEAF_DEV_VARS;

    SX_LOG_ENTER();

    SX_MEM_CLR(reg_meta);
    SX_MEM_CLR(pllp_reg);

    err = SX_FDB_GET_LIST_OF_LEAF_DEV;
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Cannot retrieve device list for MOLP update [%s].\n", sx_status_str(err));
        goto out;
    }

    if (SX_FDB_LIST_OF_LEAF_DEV_IS_EMPTY) {
        SX_LOG_DBG("__handle_pllp: device list is empty. [%s].\n", sx_status_str(err));
        goto out;
    }

    reg_meta.access_cmd = SXD_ACCESS_CMD_GET;
    reg_meta.swid = 0;
    SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pllp_reg.local_port,
                                        pllp_reg.lp_msb,
                                        SX_PORT_PHY_ID_GET(log_port));

    SX_FDB_FOR_EACH_LEAF_DEV_BEGIN;

    reg_meta.dev_id = dev_info_arr[dev_idx].dev_id;

    err = sxd_status_to_sx_status(
        sx_reg_layer_sxd_access_reg_wrapper(SXD_REG_ID_PLLP_E,
                                            &pllp_reg,
                                            &reg_meta, 1,
                                            NULL, NULL));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't send GET-PLLP EMAD (%s)\n", sx_status_str(err));
        goto out;
    }
    SX_FDB_FOR_EACH_LEAF_DEV_END;

    if (slot_num_p != NULL) {
        *slot_num_p = pllp_reg.slot_num;
    }

    if (label_port_p != NULL) {
        *label_port_p = pllp_reg.label_port;
    }

    if (split_num_p != NULL) {
        *split_num_p = pllp_reg.split_num;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_policer_bind_set(const sx_access_cmd_t      cmd,
                                  const sx_span_session_id_t span_session_id,
                                  const sx_policer_id_t      policer_id)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int = 0;
    sx_policer_id_t          int_policer_id = policer_id;
    span_session_info_t      span_session_info;
    sx_policer_db_attrib_t   policer_attr;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    SX_MEM_CLR(span_session_info);
    SX_MEM_CLR(policer_attr);

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Fail to get internal session id from external session id %d.\n",
                   span_session_id);
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = span_db_session_get(span_session_id_int, &span_session_info,
                              NULL, NULL, NULL,
                              NULL, NULL);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Fail to get session info for SPAN session id %d, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
        if (span_session_info.policer_enable) {
            SX_LOG_ERR("SPAN session already bound to policer id %" PRIu64 ".\n",
                       span_session_info.policer_id);
            err = SX_STATUS_ENTRY_ALREADY_BOUND;
            goto out;
        }

        if (SX_POLICER_TYPE_GET(int_policer_id) != SX_POLICER_TYPE_GLOBAL_E) {
            SX_LOG_ERR("SPAN session can only be bound to a global policer\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        err = policer_db_attrib_get(int_policer_id, &policer_attr);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Error in receiving current policer attributes, [policer_id = %" PRIu64 "], error: %s\n",
                       int_policer_id,
                       sx_status_str(err));
            goto out;
        }

        if (policer_attr.is_span_session_policer == FALSE) {
            SX_LOG_ERR("Given policer is not an SPAN policer.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        err = policer_manager_ref_add(int_policer_id,
                                      POLICER_MANAGER_TYPE_SPAN_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Error in policer_manager_ref_add, [policer_id = %" PRIu64 "], error: %s\n",
                       int_policer_id,
                       sx_status_str(err));
            goto out;
        }
        span_session_info.policer_id = int_policer_id;
        span_session_info.policer_enable = TRUE;
        break;

    case SX_ACCESS_CMD_UNBIND:
        if (span_session_info.policer_enable == FALSE) {
            SX_LOG_DBG("SPAN session already unbound.\n");
            err = SX_STATUS_SUCCESS;
            goto out;
        }

        if (span_session_info.policer_id != int_policer_id) {
            SX_LOG_ERR("SPAN session bound to policer id %" PRIu64 ", but given policer was %" PRIu64 ".\n",
                       span_session_info.policer_id, int_policer_id);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        span_session_info.policer_id = 0;
        span_session_info.policer_enable = FALSE;

        err = policer_manager_ref_delete(int_policer_id,
                                         POLICER_MANAGER_TYPE_SPAN_E);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Error in policer_manager_ref_add, [policer_id = %" PRIu64 "], error: %s\n",
                       int_policer_id,
                       sx_status_str(err));
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Unsupported access command (%s)\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = span_db_session_set(span_session_id_int, &span_session_info);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("SPAN session %d set failed. err: %s \n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    err = policer_db_bind_set(cmd, int_policer_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set bind number in policer DB, [policer_id = %" PRIu64 "], error: %s.\n",
                   int_policer_id,
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_policer_bind_get(const sx_span_session_id_t span_session_id, sx_policer_id_t           *policer_id_p)
{
    sx_status_t              err = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int = 0;
    span_session_info_t      span_session_info;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    err = utils_check_pointer(policer_id_p, "policer_id_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_MEM_CLR(span_session_info);

    /* Look up internal session */
    err = span_db_session_ext_to_int(span_session_id, &span_session_id_int);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Fail to get internal session id from external session id %d.\n",
                   span_session_id);
        goto out;
    }
    if (!RM_SPAN_SESSION_ID_CHECK_MAX_INTERNAL(span_session_id_int)) {
        SX_LOG_ERR("External SPAN session id %d maps to invalid internal %d.\n",
                   span_session_id, span_session_id_int);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = span_db_session_get(span_session_id_int, &span_session_info,
                              NULL, NULL, NULL,
                              NULL, NULL);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Fail to get session info for SPAN session id %d, err: %s.\n",
                   span_session_id_int, sx_status_str(err));
        goto out;
    }

    if (span_session_info.policer_enable == FALSE) {
        SX_LOG_INF("policer_id is not enabled for SPAN session [%u].\n", span_session_id);
        err = SX_STATUS_ENTRY_NOT_FOUND;
        goto out;
    }

    *policer_id_p = span_session_info.policer_id;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_attributes_get(sx_span_attrs_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    err = utils_check_pointer(attr_p, "attr_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = span_db_attributes_get(attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Fail to get SPAN attributes, err: %s.\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_attributes_set_spc4(sx_span_attrs_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    err = utils_check_pointer(attr_p, "attr_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = __span_attributes_validate(attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to validate span_attrs_t");
        goto out;
    }

    err = __handle_mmgcr(attr_p);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set MMGCR register err: %s .\n",
                   sx_status_str(err));
        goto out;
    }

    /* update span_db */
    err = span_db_attributes_set(attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Fail to set SPAN attributes, err: %s.\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}
sx_status_t span_policer_bind_set_wrapper(const sx_access_cmd_t      cmd,
                                          const sx_span_session_id_t span_session_id,
                                          const sx_policer_id_t      policer_id)
{
    if (brg_context.spec_cb_g.span_policer_bind_set_cb == NULL) {
        return SX_STATUS_CMD_UNSUPPORTED;
    }
    return brg_context.spec_cb_g.span_policer_bind_set_cb(cmd, span_session_id, policer_id);
}

sx_status_t span_policer_bind_get_wrapper(const sx_span_session_id_t span_session_id,
                                          sx_policer_id_t           *policer_id_p)
{
    if (brg_context.spec_cb_g.span_policer_bind_get_cb == NULL) {
        return SX_STATUS_CMD_UNSUPPORTED;
    }
    return brg_context.spec_cb_g.span_policer_bind_get_cb(span_session_id, policer_id_p);
}

sx_status_t span_attributes_set_wrapper(sx_span_attrs_t *attr_p)
{
    if (brg_context.spec_cb_g.span_attributes_set_cb == NULL) {
        return SX_STATUS_UNSUPPORTED;
    }
    return brg_context.spec_cb_g.span_attributes_set_cb(attr_p);
}

sx_status_t span_attributes_get_wrapper(sx_span_attrs_t *attr_p)
{
    if (brg_context.spec_cb_g.span_attributes_get_cb == NULL) {
        return SX_STATUS_UNSUPPORTED;
    }
    return brg_context.spec_cb_g.span_attributes_get_cb(attr_p);
}

sx_status_t span_mirror_port_prob_rate_set_spc2(sx_port_log_id_t                      log_port,
                                                const sx_port_usr_probability_rate_t *usr_probability_rate_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    uint8_t     is_lag_member = 0;

    SX_LOG_ENTER();

    if (!SX_CHECK_RANGE(SX_SPAN_MIRROR_DIRECTION_MIN, usr_probability_rate_p->key.mirror_direction,
                        SX_SPAN_MIRROR_DIRECTION_MAX)) {
        SX_LOG_ERR("Cannot set probability rate for port 0x%08X, Invalid key %d.\n",
                   log_port,
                   usr_probability_rate_p->key.mirror_direction);
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Can’t be applied to port that it is a part of LAG.
     *  Reject if port is part of a LAG */
    status = port_lag_member_state_get(SX_ACCESS_CMD_GET, log_port, &is_lag_member);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed to retrieve if port (0x%08X) is a lag member, err: (%s)\n",
                   log_port, sx_status_str(status));
        goto out;
    }

    if (is_lag_member) {
        status = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failure - port (0x%08X) is LAG member (%s)\n",
                   log_port, sx_status_str(status));
        goto out;
    }

    status = span_db_mirror_port_prob_rate_set(log_port, usr_probability_rate_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed set port 0x%08X mirroring probability rate\n", log_port);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

sx_status_t span_mirror_port_prob_rate_get_spc2(sx_port_log_id_t                log_port,
                                                sx_port_usr_probability_rate_t *usr_probability_rate_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (!SX_CHECK_RANGE(SX_SPAN_MIRROR_DIRECTION_MIN, usr_probability_rate_p->key.mirror_direction,
                        SX_SPAN_MIRROR_DIRECTION_MAX)) {
        SX_LOG_ERR("Can't retrieve probability rate for port 0x%08X, Invalid key %d.\n",
                   log_port,
                   usr_probability_rate_p->key.mirror_direction);
        status = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    status = span_db_mirror_port_prob_rate_get(log_port, usr_probability_rate_p);
    if (status != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed retrieve port 0x%08X mirroring probability rate\n", log_port);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}

static sx_status_t __span_port_single_attr_set(sx_port_log_id_t log_port, sx_span_port_attr_t     *span_port_attr_p)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_port_info_t port_info;

    SX_LOG_ENTER();

    err = utils_check_pointer(span_port_attr_p, "span_port_attr_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    switch (span_port_attr_p->type) {
    case SX_SPAN_PORT_ATTR_LABEL_INFO_E:
        err = port_db_info_get(log_port, &port_info);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", log_port);
            goto out;
        }

        port_info.usr_port_label_info.port_label =
            span_port_attr_p->attr.label_info.port_label;
        port_info.fields = SX_PORT_INFO_FIELD_BIT_PORT_LABEL;
        err = port_db_info_set(log_port, &port_info, NULL);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("port_db_info_set failed. (err = %s).\n", sx_status_str(err));
            goto out;
        }

        /* set mirroring port label */
        err = __span_port_mirror_label_update(log_port);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("fail lag_port_mirror_label_set for port (0x%x) err(%s)\n",
                       log_port, sx_status_str(err));
        }

        break;

    case SX_SPAN_PORT_ATTR_PROBABILITY_RATE_E:
        if (brg_context.spec_cb_g.span_mirror_port_prob_rate_set_cb != NULL) {
            err = brg_context.spec_cb_g.span_mirror_port_prob_rate_set_cb(log_port,
                                                                          &span_port_attr_p->attr.probability_rate);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed set mirroring port 0x%08X probability rate %d, err: %s\n",
                           log_port,
                           span_port_attr_p->attr.probability_rate.attr.rate,
                           sx_status_str(err));
                goto out;
            }
        } else {
            err = SX_STATUS_CMD_UNSUPPORTED;
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("__span_port_single_attr_set failed, wrong attr type %d "
                   ", err: %s.\n", span_port_attr_p->type, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_port_single_attr_get(sx_port_log_id_t         log_port,
                                               sx_span_port_attr_type_e type,
                                               sx_span_port_attr_t     *span_port_attr_p)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_port_info_t port_info;

    SX_LOG_ENTER();

    switch (type) {
    case SX_SPAN_PORT_ATTR_LABEL_INFO_E:
        err = port_db_info_get(log_port, &port_info);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't Retrieve port 0x%08X info .\n", log_port);
            goto out;
        }

        span_port_attr_p->type = type;
        span_port_attr_p->attr.label_info =
            port_info.sdk_port_label_info;

        break;

    case SX_SPAN_PORT_ATTR_PROBABILITY_RATE_E:
        span_port_attr_p->type = type;

        if (brg_context.spec_cb_g.span_mirror_port_prob_rate_get_cb != NULL) {
            err = brg_context.spec_cb_g.span_mirror_port_prob_rate_get_cb(log_port,
                                                                          &span_port_attr_p->attr.probability_rate);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed in span_mirror_port_prob_rate_get_cb() , err: %s\n", sx_status_str(err));
                goto out;
            }
        } else {
            err = SX_STATUS_CMD_UNSUPPORTED;
            goto out;
        }
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("__span_port_single_attr_set failed, wrong attr type %d "
                   ", err: %s.\n", span_port_attr_p->type, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_port_attr_set(sx_port_log_id_t     log_port,
                               sx_span_port_attr_t *span_port_attr_list_p,
                               uint32_t             span_port_attr_list_size)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    unsigned int i;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    err = utils_check_pointer(span_port_attr_list_p, "span_port_attr_list_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    /* Validate Port is phy or LAG */
    VALIDATE_PORT(span_port_attr_set, log_port);

    for (i = 0; i < span_port_attr_list_size; i++) {
        if ((SX_PORT_TYPE_ID_GET(log_port) != SX_PORT_TYPE_NETWORK) &&
            (span_port_attr_list_p[i].type == SX_SPAN_PORT_ATTR_LABEL_INFO_E)) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Cannot set LABEL_INFO attr: log_port 0x%x isn't a physical port, err: %s.\n",
                       log_port,
                       sx_status_str(err));
            goto out;
        }

        err = __span_port_single_attr_set(log_port, &span_port_attr_list_p[i]);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Fail to set SPAN attributes, err: %s.\n", sx_status_str(err));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_port_attr_get(sx_port_log_id_t         log_port,
                               sx_span_port_attr_type_e attr_type,
                               sx_span_port_attr_t     *span_port_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    VALIDIATE_MODULE_INITIALIZED();

    err = utils_check_pointer(span_port_attr_p, "span_port_attr_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    /* Validate Port is phy or LAG */
    VALIDATE_PORT(span_port_attr_get, log_port);

    if ((SX_PORT_TYPE_ID_GET(log_port) != SX_PORT_TYPE_NETWORK) && (attr_type == SX_SPAN_PORT_ATTR_LABEL_INFO_E)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Cannot get LABEL_INFO attr: log_port 0x%x isn't a physical port, err: %s.\n",
                   log_port,
                   sx_status_str(err));
        goto out;
    }

    err = __span_port_single_attr_get(log_port,
                                      attr_type,
                                      span_port_attr_p);
    if (SX_CHECK_FAIL(err) && (err != SX_STATUS_CMD_UNSUPPORTED)) {
        SX_LOG_ERR("Fail to get SPAN attributes, err: %s.\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_header_padding_spectrum4(const sx_span_mirror_header_version_t header_version,
                                                 const sx_span_session_params_t       *sx_span_session_params_p,
                                                 uint8_t                              *padding_p)
{
    if ((SX_SPAN_MIRROR_HEADER_VERSION_1 == header_version) ||
        (SX_SPAN_MIRROR_HEADER_VERSION_2 == header_version)) {
        *padding_p = sx_span_session_params_p->padding;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t span_validate_mirror_header_padding_cb_wrapper(
    const sx_span_session_params_t *span_session_params_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SX_SPAN_HEADER_PADDING_NO_PADDING_E != span_session_params_p->padding) {
        if (brg_context.spec_cb_g.span_validate_mirror_header_padding_cb) {
            rc = brg_context.spec_cb_g.span_validate_mirror_header_padding_cb(span_session_params_p);
            if (SX_CHECK_FAIL(rc)) {
                goto out;
            }
        } else {
            SX_LOG_ERR("Mirror header padding isn't supported for this device\n");
            rc = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

static sx_status_t __validate_analyzer_port(const sx_port_log_id_t log_port)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    boolean_t                  is_lag_redirected = FALSE;
    sx_lag_fine_grain_params_t lag_distributor_params;
    uint32_t                   lag_distributor_cnt;

    if (SX_PORT_TYPE_ID_GET(log_port) != SX_PORT_TYPE_LAG) {
        /* validation passed */
        goto out;
    }

    err = lag_redirect_get(log_port, &is_lag_redirected, NULL);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("LAG redirection info get for port 0x%x failed, err: %s. \n", log_port, sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }
    if (is_lag_redirected) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Redirected LAG port (0x%x) cannot be configured as a SPAN analyzer, err: %s. \n",
                   log_port,
                   sx_status_str(err));
        goto out;
    }

    err = lag_distributor_list_get(log_port, &lag_distributor_params, NULL, &lag_distributor_cnt);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("LAG fine grain configuration get for port 0x%x failed, err: %s. \n",
                   log_port,
                   sx_status_str(err));
        err = SX_STATUS_ERROR;
        goto out;
    }
    if (lag_distributor_cnt > 0) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Fine grain LAG port (0x%x) cannot be configured as a SPAN analyzer, err: %s. \n",
                   log_port,
                   sx_status_str(err));
        goto out;
    }

out:
    return err;
}

sx_status_t span_analyzer_lag_port_become_inactive(const sx_port_id_t lag_port_log_id, const sx_port_id_t port_log_id)
{
    return span_db_analyzer_lag_port_become_inactive(lag_port_log_id, port_log_id);
}

sx_status_t span_analyzer_lag_port_become_active(const sx_port_id_t lag_port_log_id)
{
    return span_db_analyzer_lag_port_become_active(lag_port_log_id);
}

static sx_status_t __span_get_lag_by_member(const sx_port_id_t port_log_id, sx_port_id_t *lag_port_log_id_p)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sx_port_id_t lag_log_port = 0;
    sx_lag_id_t  lid = 0;

    SX_LOG_ENTER();

    err = sx_la_db_lag_get(port_log_id, &lid);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Port [0x%08x] is not a member of a LAG\n", port_log_id);
        goto out;
    }
    SX_PORT_TYPE_ID_SET(lag_log_port, SX_PORT_TYPE_LAG);
    SX_PORT_LAG_ID_SET(lag_log_port, lid);

    *lag_port_log_id_p = lag_log_port;

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_analyzer_multiport_update_job_scedule(const sx_port_oper_state_t oper_state,
                                                                const sx_port_id_t         port_log_id)
{
    sx_status_t                                    err = SX_STATUS_SUCCESS;
    sx_span_analyzer_multiport_update_job_params_t params;

    SX_LOG_ENTER();

    params.new_oper_state = oper_state;
    params.log_port_id = port_log_id;

    err = sx_core_api_add_internal_job(SX_API_INT_CMD_SPAN_ANALYZER_MULTIPORT_UPDATE_INT_E, (uint8_t*)&params,
                                       sizeof(sx_span_analyzer_multiport_update_job_params_t), SX_CORE_MED_PRIO_BUF_E);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Can't send internal job, [opcode = %u, buf_idx = %u], error: %s.\n",
                   SX_API_INT_CMD_SPAN_ANALYZER_MULTIPORT_UPDATE_INT_E,
                   SX_CORE_MED_PRIO_BUF_E,
                   sx_status_str(err));
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t span_analyzer_multiport_update_job_hadnle(const sx_port_oper_state_t oper_state,
                                                      const sx_port_id_t         port_log_id)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sx_port_id_t lag_port_log_id = SX_SPAN_INVALID_LOG_PORT;
    boolean_t    port_is_span_analyzer = FALSE;
    uint8_t      port_is_lag_member = 0;

    SX_LOG_ENTER();


    err = port_lag_member_state_get(SX_ACCESS_CMD_GET, port_log_id, &port_is_lag_member);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve if port (0x%08X) is lag member (%s)\n",
                   port_log_id, sx_status_str(err));
        goto out;
    }
    if (!port_is_lag_member) {
        err = SX_STATUS_SUCCESS;
        goto out;
    }
    err = __span_get_lag_by_member(port_log_id, &lag_port_log_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get parent LAG for port (0x%08X). err %s \n",
                   port_log_id, sx_status_str(err));
        goto out;
    }
    err = span_analyzer_port_test(lag_port_log_id, &port_is_span_analyzer);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to check if the port (0x%x) is set as SPAN analyzer, err: %s. \n",
                   lag_port_log_id,
                   sx_status_str(err));
        goto out;
    }
    if (!port_is_span_analyzer) {
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    switch (oper_state) {
    case SX_PORT_OPER_STATUS_UP:
        err = span_db_analyzer_lag_port_become_active(lag_port_log_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to handle port (0x%08X) operational state change. err %s \n",
                       port_log_id, sx_status_str(err));
        }
        break;

    case SX_PORT_OPER_STATUS_DOWN:
        err = span_db_analyzer_lag_port_become_inactive(lag_port_log_id, port_log_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to handle port (0x%08X) operational state change. err %s \n",
                       port_log_id, sx_status_str(err));
        }
        break;

    default:
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Unsupported operational state (%d) to handle. err %s \n",
                   oper_state, sx_status_str(err));
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_analyzer_oper_state_change_callback(adviser_event_e event_type, void *param_p)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sx_port_id_t port_log_id = SX_SPAN_INVALID_LOG_PORT;

    SX_LOG_ENTER();
    VALIDATE_POINTER_NOT_NULL(param_p);
    port_log_id = *((sx_port_id_t *)param_p);

    switch (event_type) {
    case ADVISER_EVENT_POST_PORT_OPER_UP_E:
        err = __span_analyzer_multiport_update_job_scedule(SX_PORT_OPER_STATUS_UP, port_log_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to schedule port (0x%08X) operational state change UP handling. err %s \n",
                       port_log_id, sx_status_str(err));
            goto out;
        }
        break;

    case ADVISER_EVENT_POST_PORT_OPER_DOWN_E:
        err = __span_analyzer_multiport_update_job_scedule(SX_PORT_OPER_STATUS_DOWN, port_log_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to schedule port (0x%08X) operational state change DOWN handling. err %s \n",
                       port_log_id, sx_status_str(err));
            goto out;
        }
        break;

    default:
        err = SX_STATUS_SUCCESS;
        break;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_attributes_validate(sx_span_attrs_t *attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (SPAN_ERSPAN_V2_DEVICE_UID_VALIDATE(attr_p->device_uid) != SX_STATUS_SUCCESS) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("device_uid validation failure, value exceeds allowed bit range [0x%x]  err: %s. \n",
                   SPAN_ERSPAN_V2_DEVICE_UID_MASK,
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __span_analyzer_prio_mapping_change_callback(adviser_event_e event_type, void *param_p)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sx_port_id_t lag_port_log_id = SX_SPAN_INVALID_LOG_PORT;
    boolean_t    port_is_span_analyzer = FALSE;

    SX_LOG_ENTER();
    VALIDATE_POINTER_NOT_NULL(param_p);

    lag_port_log_id = *((sx_port_id_t *)param_p);

    if (event_type != ADVISER_EVENT_POST_PORT_TC_PRIO_MAP_CHANGE_E) {
        /* Wrong event type */
        err = SX_STATUS_SUCCESS;
        goto out;
    }
    if (SX_PORT_TYPE_ID_GET(lag_port_log_id) != SX_PORT_TYPE_LAG) {
        /* Not a LAG */
        err = SX_STATUS_SUCCESS;
        goto out;
    }
    err = span_analyzer_port_test(lag_port_log_id, &port_is_span_analyzer);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to check if the port (0x%x) is set as SPAN analyzer, err: %s. \n",
                   lag_port_log_id,
                   sx_status_str(err));
        goto out;
    }
    if (!port_is_span_analyzer) {
        /* LAG is not a SPAN analyzer */
        err = SX_STATUS_SUCCESS;
        goto out;
    }

    err = span_db_analyzer_lag_port_force_refresh(lag_port_log_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to update SPAN session of analyzer port (0x%08X), err %s \n",
                   lag_port_log_id, sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t span_mirror_truncation_profile_refcount_cb_wrapper(const sx_access_cmd_t    cmd,
                                                               sx_span_session_id_int_t span_session_id_int)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_truncation_profile_refcount_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_truncation_profile_refcount_cb(cmd,
                                                                              span_session_id_int);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in span_mirror_truncation_profile_refcount_cb for cmd[%d] session ID [%d], err: %s\n",
                       cmd,
                       span_session_id_int,
                       sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_mirror_truncation_profile_set_cb_wrapper(const sx_access_cmd_t    cmd,
                                                          sx_span_session_id_int_t span_session_id_int,
                                                          span_session_info_t     *span_session_info_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_truncation_profile_set_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_truncation_profile_set_cb(cmd,
                                                                         span_session_id_int,
                                                                         span_session_info_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in span_mirror_truncation_profile_cb for session %d, err: %s\n",
                       span_session_info_p->session_id,
                       sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_mirror_truncation_profile_get_cb_wrapper(sx_span_session_id_int_t span_session_id_int,
                                                          span_session_info_t     *span_session_info_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_truncation_profile_get_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_truncation_profile_get_cb(span_session_id_int, span_session_info_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in span_mirror_truncation_profile_get_cb for session %d, err: %s\n",
                       span_session_info_p->session_id,
                       sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_mirror_truncation_profile_validate_cb_wrapper(const span_session_info_t *span_session_info_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_truncation_profile_validate_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_truncation_profile_validate_cb(span_session_info_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in span_mirror_truncation_profile_validate_cb for session %d, err: %s\n",
                       span_session_info_p->session_id,
                       sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}

sx_status_t span_mirror_truncation_profile_set_spectrum4(const sx_access_cmd_t    cmd,
                                                         sx_span_session_id_int_t span_session_id_int,
                                                         span_session_info_t     *span_session_info_p)
{
    sx_status_t                 status = SX_STATUS_SUCCESS;
    sx_truncation_profile_key_t trunc_profile_key;
    sx_truncation_profile_cfg_t trunc_profile_cfg;

    SX_LOG_ENTER();

    SX_MEM_CLR(trunc_profile_key);
    SX_MEM_CLR(trunc_profile_cfg);

    /* Set the related Truncation-Profile key */
    trunc_profile_key.trunc_profile_type = SX_TRUNCATION_PROFILE_TYPE_MIRROR_E;
    trunc_profile_key.trunc_profile_id.span_session_id = span_session_id_int;

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:

        span_session_info_p->truncate_cgf.truncate_size = span_session_info_p->truncation_size;
        SX_MEM_CPY_P(&trunc_profile_cfg.mirror_trunc_profile, &span_session_info_p->truncate_cgf);

        status = truncation_profile_set(SX_ACCESS_CMD_CREATE, &trunc_profile_key, &trunc_profile_cfg);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed add Truncation-Profile, err: %s\n", sx_status_str(status));
            goto out;
        }

        break;

    case SX_ACCESS_CMD_DELETE:

        status = truncation_profile_set(SX_ACCESS_CMD_DESTROY, &trunc_profile_key, NULL);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed in truncation_profile_set. err: %s\n", sx_status_str(status));
            goto out;
        }
        break;

    default:
        status = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Unsupported mirror truncation command (%d). err: %s.\n", cmd, sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}


sx_status_t span_mirror_truncation_profile_get_spectrum4(sx_span_session_id_int_t span_session_id_int,
                                                         span_session_info_t     *span_session_info_p)
{
    sx_status_t                 status = SX_STATUS_SUCCESS;
    sx_truncation_profile_key_t trunc_profile_key;
    sx_truncation_profile_cfg_t trunc_profile_cfg;
    boolean_t                   is_exists = FALSE;

    SX_LOG_ENTER();

    /* Skip if Truncation is disabled */
    if (span_session_info_p->truncate == FALSE) {
        goto out;
    }

    SX_MEM_CLR(trunc_profile_key);
    SX_MEM_CLR(trunc_profile_cfg);

    /* Set the related Truncation-Profile key */
    trunc_profile_key.trunc_profile_type = SX_TRUNCATION_PROFILE_TYPE_MIRROR_E;
    trunc_profile_key.trunc_profile_id.span_session_id = span_session_id_int;

    status = truncation_profile_is_exists(&trunc_profile_key, &is_exists);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed in truncation_profile_is_exists, err: %s\n", sx_status_str(status));
        goto out;
    }

    if (FALSE == is_exists) {
        goto out;
    }

    status = truncation_profile_get(&trunc_profile_key, &trunc_profile_cfg);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed retrieve Truncation-Profile, err: %s\n", sx_status_str(status));
        goto out;
    }

    SX_MEM_CPY_P(&span_session_info_p->truncate_cgf, &trunc_profile_cfg.mirror_trunc_profile);

out:
    SX_LOG_EXIT();
    return status;
}


sx_status_t span_mirror_truncation_profile_validate_spectrum4(const span_session_info_t *span_session_info_p)
{
    sx_status_t                 status = SX_STATUS_SUCCESS;
    sx_truncation_profile_key_t trunc_profile_key;

    SX_LOG_ENTER();

    /* Skip if Truncation is disabled */
    if (span_session_info_p->truncate == FALSE) {
        goto out;
    }

    SX_MEM_CLR(trunc_profile_key);

    /* Set the related Truncation-Profile key */
    trunc_profile_key.trunc_profile_type = SX_TRUNCATION_PROFILE_TYPE_MIRROR_E;
    trunc_profile_key.trunc_profile_id.span_session_id = span_session_info_p->pa_id;

    status = truncation_profile_validate(&trunc_profile_key);
    if (SX_CHECK_FAIL(status)) {
        SX_LOG_ERR("Failed validate SPAN Truncation-Profile ID %d, err: %s\n",
                   span_session_info_p->session_id,
                   sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}


sx_status_t span_mirror_truncation_profile_refcount_spectrum4(const sx_access_cmd_t    cmd,
                                                              sx_span_session_id_int_t span_session_id_int)
{
    sx_status_t                 status = SX_STATUS_SUCCESS;
    sx_truncation_profile_key_t trunc_profile_key;
    sx_truncation_profile_cfg_t trunc_profile_cfg;

    SX_LOG_ENTER();

    SX_MEM_CLR(trunc_profile_key);
    SX_MEM_CLR(trunc_profile_cfg);

    /* Set the related Truncation-Profile key */
    trunc_profile_key.trunc_profile_type = SX_TRUNCATION_PROFILE_TYPE_MIRROR_E;
    trunc_profile_key.trunc_profile_id.span_session_id = span_session_id_int;

    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
        status = truncation_profile_refcount_inc(&trunc_profile_key);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed in truncation_profile_refcount_inc, err: %s\n", sx_status_str(status));
            goto out;
        }
        break;

    case SX_ACCESS_CMD_DELETE:
        status = truncation_profile_refcount_dec(&trunc_profile_key);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("Failed in truncation_profile_refcount_dec, err: %s\n", sx_status_str(status));
            goto out;
        }

        break;

    default:
        status = SX_STATUS_UNSUPPORTED;
        SX_LOG_ERR("Unsupported SPAN Mirror Truncation-Profile refcount command (%d). err: %s.\n", cmd,
                   sx_status_str(status));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return status;
}


sx_status_t span_mirror_truncation_hw_set_cb_wrapper(struct ku_mpat_reg *mpat_reg_data_p)
{
    sx_status_t rc = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.span_mirror_truncation_hw_set_cb != NULL) {
        rc = brg_context.spec_cb_g.span_mirror_truncation_hw_set_cb(mpat_reg_data_p);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed in span_mirror_truncation_hw_set_cb for SPAN session ID [%hu], err: %s\n",
                       mpat_reg_data_p->pa_id, sx_status_str(rc));
            goto out;
        }
    }

out:
    SX_LOG_EXIT();
    return rc;
}


sx_status_t span_mirror_truncation_hw_set_spectrum4(struct ku_mpat_reg *mpat_reg_data_p)
{
    /* Set itc (=Ignore Truncation Configuration) field to ignore the truncation configuration and use instead the Truncation-Profile (ITPR).*/
    mpat_reg_data_p->itc = 1;
    return SX_STATUS_SUCCESS;
}


/* Check for enabled SPAN sessions
 * Span session are not supported during ISSU and can cause many failures */
sx_status_t span_issu_sessions_check(void)
{
    sx_status_t              rc = SX_STATUS_SUCCESS;
    sx_span_session_id_int_t span_session_id_int;
    span_session_info_t      span_session_info;

    SX_LOG_ENTER();
    SX_MEM_CLR(span_session_info);

    /* Iterate over all internal session ID's and disable the sessions */
    for (span_session_id_int = 0;
         span_session_id_int <= rm_resource_global.span_session_id_max_internal;
         span_session_id_int++) {
        rc = span_db_session_get(span_session_id_int, &span_session_info,
                                 NULL, NULL, NULL, NULL, NULL);

        if ((rc == SX_STATUS_ENTRY_NOT_FOUND) ||
            (span_session_info.admin_state == FALSE) ||
            (span_session_info.gc_handle != NULL)) {
            rc = SX_STATUS_SUCCESS;
            continue;
        }

        SX_LOG_INF("Span session id %u is running during ISSU flow - this is an invalid flow",
                   span_session_info.session_id);
    }

    SX_LOG_EXIT();
    return rc;
}
