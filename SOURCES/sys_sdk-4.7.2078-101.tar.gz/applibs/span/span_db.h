/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __SPAN_DB_H_INCL__
#define __SPAN_DB_H_INCL__

#include <complib/cl_types.h>
#include <complib/cl_qlist.h>
#include <complib/cl_qmap.h>


#include <sx/sdk/sx_types.h>

#include <utils/utils.h>
#include <sx/sdk/sx_port.h>
#include <sx/sdk/sx_lag.h>

#include <sx/sdk/sx_port_id.h>
#include <sx/sdk/sx_check.h>
#include <sx/sdk/sx_swid.h>

#include <sx/utils/gc.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

#define SPAN_DB_MIRROR_BIND_TYPE_NUM   (SX_SPAN_MIRROR_BIND_TYPE_MAX_E - SX_SPAN_MIRROR_BIND_TYPE_MIN_E + 1)
#define SPAN_DB_MIRROR_ENABLE_TYPE_NUM (SX_SPAN_MIRROR_ENABLE_TYPE_MAX_E - SX_SPAN_MIRROR_ENABLE_TYPE_MIN_E + 1)

#define SPAN_DB_MIRROR_POOL_MAX_SIZE  (rm_resource_global.port_log_num_max + SPAN_DB_MIRROR_BIND_TYPE_NUM)
#define SPAN_DB_MIRROR_POOL_MIN_SIZE  (64)
#define SPAN_DB_MIRROR_POOL_GROW_SIZE (SPAN_DB_MIRROR_POOL_MIN_SIZE >> 1)

#define SPAN_DB_MIRROR_ENABLE_POOL_MAX_SIZE  (rm_resource_global.port_log_num_max * SPAN_DB_MIRROR_ENABLE_TYPE_NUM)
#define SPAN_DB_MIRROR_ENABLE_POOL_MIN_SIZE  (64)
#define SPAN_DB_MIRROR_ENABLE_POOL_GROW_SIZE (SPAN_DB_MIRROR_POOL_MIN_SIZE >> 1)

#define SPAN_DB_MIRROR_ENABLE_PORT_POOL_MAX_SIZE (rm_resource_global.port_log_num_max)
#define SPAN_DB_MIRROR_ENABLE_PORT_POOL_MIN_SIZE (rm_resource_global.port_log_num_max)

#define SPAN_DB_MIRROR_ENABLE_TC_PG_MAX_VALUE MAX(rm_resource_global.cos_port_ets_traffic_class_max, 8)
#define SPAN_DB_MIRROR_ENABLE_OBJECT_POOL_MAX_SIZE \
    (rm_resource_global.port_log_num_max *         \
     SPAN_DB_MIRROR_ENABLE_TC_PG_MAX_VALUE *       \
     SPAN_DB_MIRROR_ENABLE_TYPE_NUM)
#define SPAN_DB_MIRROR_ENABLE_OBJECT_POOL_MIN_SIZE  (64)
#define SPAN_DB_MIRROR_ENABLE_OBJECT_POOL_GROW_SIZE (SPAN_DB_MIRROR_ENABLE_OBJECT_POOL_MIN_SIZE >> 1)

#define BUILD_SPAN_MIRROR_KEY(log_port, direction) \
    (((uint64_t)(direction) << 32ULL) | (log_port))

#define SPAN_INVALID_SYSTEM_PORT 0xffff

#define SPAN_EGRESS_MIRROR_SBIB_TYPE  0
#define SPAN_EGRESS_MIRROR_SBIB_INDEX 0

#define SPAN_NO_SESSION               0xff
#define SPAN_DEFAULT_PROBABILITY_RATE 0

#define SPAN_DB_MAX_USERS 5     /* modules using SPAN requiring relocation notification */

#define SPAN_DB_DEFAULT_BUFFER_OCCUPANCY_UNITS (8 * 1024) /* According to PRM, it's 8KB, no register to configure it yet. */
#define SPAN_DB_DEFAULT_LATENCY_UNITS          (64) /* According to PRM, it's 64 nanoseconds by default, can be configured by MOGCR.mirror_latency_units. */

#define DYN_MIRROR_TRIGGER_TYPE_OFFSET (2)
#define MIRROR_BIND_TYPE_BITS_TO_MIRROR_TRIGGER_BITS(trigger_bits) (trigger_bits << DYN_MIRROR_TRIGGER_TYPE_OFFSET)

#define SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX (SXD_MPAT_MULTI_PORT_NUM)     /* Maximum number of ports active in SPAN multi port mode */
/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/*
 * Complete list of mirror directions supported in PRM.  This list is not
 * exposed in API, because SPAN API uses only egress and ingress, and other
 * values are implicit for the modules that call SPAN for specific mirroring.
 * Numerical values are not significant, but are chosen to have no overlap with
 * sx_mirror_direction_t, so that any accidental use of the wrong type will be
 * detected easily.
 */
typedef enum span_mirror_direction {
    SPAN_MIRROR_DIRECTION_EGRESS = 11,
    SPAN_MIRROR_DIRECTION_INGRESS,
    SPAN_MIRROR_DIRECTION_INGRESS_WRED,
    SPAN_MIRROR_DIRECTION_INGRESS_SHARED_BUFFER,
    SPAN_MIRROR_DIRECTION_INGRESS_PG_CONGESTION,
    SPAN_MIRROR_DIRECTION_INGRESS_TC_CONGESTION,
    SPAN_MIRROR_DIRECTION_EGRESS_ECN,
    SPAN_MIRROR_DIRECTION_EGRESS_TC_LATENCY,
    SPAN_MIRROR_DIRECTION_MIN = SPAN_MIRROR_DIRECTION_EGRESS,
    SPAN_MIRROR_DIRECTION_MAX = SPAN_MIRROR_DIRECTION_EGRESS_TC_LATENCY,
} span_mirror_direction_t;

typedef enum span_mirror_egress_buff_status {
    SPAN_MIRROR_EGRESS_BUFF_SIZE_NOT_COMPLETE = 0,
    SPAN_MIRROR_EGRESS_BUFF_SIZE_COMPLETE     = 1,
    SPAN_MIRROR_EGRESS_BUFF_SIZE_STATUS_MIN   = SPAN_MIRROR_EGRESS_BUFF_SIZE_NOT_COMPLETE,
    SPAN_MIRROR_EGRESS_BUFF_SIZE_STATUS_MAX   = SPAN_MIRROR_EGRESS_BUFF_SIZE_COMPLETE,
} span_mirror_egress_buff_status_t;

typedef struct span_mirror {
    sx_port_log_id_t        log_port;
    span_mirror_direction_t mirror_direction;
} span_mirror_t;

typedef struct span_drop_mirror {
    boolean_t             trap_group_valid;
    sx_trap_group_t       trap_group;
    sx_span_drop_reason_t drop_reasons[SX_SPAN_DROP_REASON_COUNT];
    uint32_t              drop_reasons_count;
} span_drop_mirror_t;

typedef enum span_egress_mirror_buff_type {
    SPAN_EGRESS_MIRROR_BUFF_TYPE_FLEX_ACL,
    SPAN_EGRESS_MIRROR_BUFF_TYPE_SPAN_MIRROR
} span_egress_mirror_buff_type_e;

typedef enum span_multiport_number {
    SPAN_MULTIPORT_NUMBER_RESERVED_E = 0,
    SPAN_MULTIPORT_NUMBER_ONE_E      = 0,
    SPAN_MULTIPORT_NUMBER_TWO_E      = 1,
    SPAN_MULTIPORT_NUMBER_FOUR_E     = 2
} span_multiport_number_e;

/**
 *                      SPAN MIRROR map definition
 */
typedef struct span_mirror_db_record {
    sx_port_log_id_t           log_port;
    span_mirror_direction_t    mirror_direction;
    boolean_t                  enable;   /**< Mirroring Enable */
    uint8_t                    pa_id;    /**< Port Analyzer ID */
    boolean_t                  bound;
    sx_span_probability_rate_t rate;     /**< Global probability rate */
} span_mirror_db_record_t;

typedef struct span_mirror_map_item {
    cl_pool_item_t          pool_item;
    cl_map_item_t           map_item;
    span_mirror_db_record_t span_mirror_record;
} span_mirror_map_item_t;


/**
 *                      SPAN Analyzer map definition
 */
typedef struct span_analyzer_db_record {
    uint8_t pa_id;                          /**< Port Analyzer ID */
} span_analyzer_db_record_t;

typedef struct span_context_item {
    sx_span_session_id_t span_session_id;
} span_context_item_t;

typedef struct span_alalyzer_map_item {
    cl_pool_item_t            pool_item;
    cl_map_item_t             analyzer_map_item;
    span_analyzer_db_record_t span_analyzer_record;
} span_alalyzer_map_item_t;

/**
 *                      SPAN session definitions
 */
typedef struct span_session_info {
    uint8_t                            pa_id;            /**< Port Analyzer ID */
    uint8_t                            mngr_type;        /**< Hypervisor / Local Network Manager  */
    uint16_t                           system_port;
    uint8_t                            be;           /**< Discard / Don't discard */
    uint8_t                            stclass;      /**< Stacking TClass */
    sx_span_type_t                     span_type;
    sx_span_type_format_t              span_type_format;
    boolean_t                          truncate;         /**< Truncate the packet to 64 byte size */
    uint16_t                           truncation_size;  /**<Truncation size if enabled - Spectrum only */
    sx_truncation_profile_mirror_cfg_t truncate_cgf;  /* [Spectrum4 and above] Truncation configuration. */
    sx_span_session_params_t           params;
    boolean_t                          admin_state;
    sx_span_analyzer_port_params_t     port_params;
    span_drop_mirror_t                 drop_mirror;
    uint32_t                           ref_cnt;
    span_context_item_t                span_gc_context_item;
    gc_handle_t                        gc_handle;        /**< Indicate if span is in gc queue */
    boolean_t                          policer_enable;
    sx_policer_id_t                    policer_id;
    uint8_t                            session_id;  /**< External session ID, used for mirror trap */
    boolean_t                          is_multiport;
    uint16_t                           multiport[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX]; /**< System ports selected as SPAN Multiport analyzer */
    span_multiport_number_e            multiport_nmp; /**< SPAN multiport number selector */
    uint8_t                            switch_prio; /**< Switch priority for SPAN Multiport analyzer */
    uint8_t                            tclass; /**< TClass for SPAN Multiport analyzer */
} span_session_info_t;

typedef struct span_session {
    boolean_t           used;
    span_session_info_t span_session_info;
    cl_qmap_t           mirror_ports_db;
    sx_port_log_id_t    analyzer_port;
    sx_port_log_id_t    analyzer_multiport[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX];
    uint8_t             multiport_num;
} span_session_t;

/* Distinguish between session IDs exposed to user, and possibly larger */
/* number of sessions supported internally by firmware                  */
typedef sx_span_session_id_t sx_span_session_id_int_t;

/*
 * Callback function implemented by modules that wish to be informed when the
 * internal SPAN session associated with a given external session is changed by
 * SPAN, e.g. as part of a session edit.
 */
typedef sx_status_t (*span_cb_relocate_t)(sx_span_session_id_t     span_session_id,
                                          sx_span_session_id_int_t old_span_session_id_int,
                                          sx_span_session_id_int_t new_span_session_id_int);

/*
 * Data maintained for an external module that registers as a user of SPAN
 */
typedef struct span_user {
    boolean_t          used;            /* this slot contains valid user          */
    span_cb_relocate_t cb_relocate;     /* function to call on session relocation */
} span_user_t;

/*
 * Handle for data stored about external modules that register as users of SPAN
 * Internal type is span_user_t*
 */
typedef void *span_client_handle_t;

typedef struct span_mirror_bind_entry {
    sx_span_mirror_bind_type_e type;
    boolean_t                  bound;
    sx_span_mirror_bind_key_t  key;
    sx_span_mirror_bind_attr_t attr;
} span_mirror_bind_entry_t;

typedef struct span_mirror_enable_item {
    cl_pool_item_t               pool_item;
    cl_map_item_t                map_item;
    sx_port_log_id_t             log_port;
    uint32_t                     tc_pg_en;           /**< bitmap of tc/pg */
    sx_span_mirror_enable_attr_t attr;
} span_mirror_enable_item_t;

typedef struct span_mirror_enable_object_item {
    cl_pool_item_t                 pool_item;
    cl_map_item_t                  map_item;
    sx_span_mirror_enable_object_t object;
    sx_span_mirror_enable_attr_t   attr;
} span_mirror_enable_object_item_t;

typedef struct span_mirror_enable_entry {
    sx_span_mirror_enable_type_e type;
    cl_qmap_t                    mirror_enable_map;           /**< map of enable item per port per type */
    cl_qmap_t                    mirror_enable_object_lookup; /**< lookup for enable object item per type */
} span_mirror_enable_entry_t;

typedef struct span_mirror_enable_port_item {
    cl_pool_item_t   pool_item;
    cl_map_item_t    map_item;
    sx_port_log_id_t log_port;
    uint16_t         mirror_trigger_disallow_nelp;             /**< bitmap of conditional mirror trigger for non-elephant packets */
    uint16_t         mirror_trigger_disallow_nelp_sets;        /**< bitmap of whether conditional mirror trigger for non-elephant packets is set*/
    uint16_t         mirror_trigger_disallow_elp;              /**< bitmap of conditional mirror trigger for elephant packets */
    uint16_t         mirror_trigger_disallow_elp_sets;         /**< bitmap of whether conditional mirror trigger for elephant packets is set*/
} span_mirror_enable_port_item_t;

typedef struct span_db {
    cl_qpool_t                  mirror_ports_pool;
    cl_qpool_t                  mirror_enable_pool;
    cl_qpool_t                  mirror_enable_object_pool;
    cl_qpool_t                  mirror_enable_port_pool;
    span_mirror_bind_entry_t   *mirror_bind_entries;   /* [SX_SPAN_MIRROR_BIND_TYPE_NUM]; */
    span_mirror_enable_entry_t *mirror_enable_entries; /* [SX_SPAN_MIRROR_ENABLE_TYPE_NUM]; */
    span_session_t             *sx_span_sessions;      /* [SX_SPAN_SESSION_ID_COUNT]; */
    sx_span_session_id_int_t   *ext_to_int_id;         /* [SX_SPAN_SESSION_ID_COUNT]; */
    sx_span_session_id_t       *int_to_ext_id;         /* [SX_SPAN_SESSION_ID_COUNT]; */
    boolean_t                  *locked;                /* [SX_SPAN_SESSION_ID_COUNT]; */
    span_user_t                 user[SPAN_DB_MAX_USERS];
    sx_span_attrs_t             span_attrs;
    cl_qmap_t                   mirror_disallow_map;   /**< NEW: map of sx_span_mirror_enable_port_set_t per port */
} span_db_t;

/*
 * This structure is intended to pass additional port parameters for internal use
 * of the span_analyzer_set flow.
 */
typedef struct span_analyzer_port_set_params {
    sx_span_analyzer_port_params_t *sx_port_params;
    boolean_t                       multiport_apply;
    sx_port_log_id_t                analyzer_multiport[SPAN_DB_ANALYZER_MULTI_PORT_NUM_MAX];
    length_t                        multiport_num;
    boolean_t                       multiport_on_the_fly_update;
} span_analyzer_port_set_params_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


/**
 * This function sets the log verbosity level of SPAN DB MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sx_status_t span_db_log_verbosity_level(IN sx_access_cmd_t       cmd,
                                        IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function initializes the SPAN module DB.
 *
 * @param[in] cmd - APPLY/TEST
 * "APPLY"- Actually initialize the cos library DB
 * "TEST" - Simply check the feasibility to initialize the cos library DB (enough resources)
 * @param[in] max_policers_per_port - maximum policers bound to a port
 * @param[in] max_policers_global - maximum number of global policers
 *
 * @return SX_STATUS_SUCCESS
 *         SX_STATUS_NO_MEMORY - memory can not be allocated for DB.
 *
 */
sx_status_t span_db_init(void);

/**
 *  This function deletes the SPAN module DB.
 *
 * @return SX_STATUS_SUCCESS
 */
sx_status_t span_db_deinit(void);

/**
 *  This function bind/unbind a SPAN from/to a log port
 */
sx_status_t span_db_mirror_set(const sx_access_cmd_t          cmd,
                               const span_mirror_t           *mirror_p,
                               const sx_span_session_id_int_t old_span_session_id,
                               const sx_span_session_id_int_t new_span_session_id);

sx_status_t span_db_mirror_get(const span_mirror_t        *mirror_p,
                               sx_span_session_id_int_t   *span_session_id,
                               sx_span_probability_rate_t *rate_p,
                               boolean_t                  *admin_state_p);

sx_status_t span_db_mirror_port_find(IN sx_port_log_id_t        port_log_id,
                                     IN span_mirror_direction_t mirror_direction,
                                     OUT cl_map_item_t       ** mirror_port_map_item_p);

boolean_t span_db_any_sessions_used(void);

sx_status_t span_db_session_int_to_ext(sx_span_session_id_int_t span_session_id_int,
                                       sx_span_session_id_t    *span_session_id);
sx_status_t span_db_session_ext_to_int(sx_span_session_id_t      span_session_id,
                                       sx_span_session_id_int_t *span_session_id_int);

sx_status_t span_db_cnv_span_to_sxd_mirror_direction(const span_mirror_direction_t     span_dir,
                                                     sxd_span_mirror_port_direction_t *sxd_dir_p);
sx_status_t span_db_cnv_sxd_to_span_mirror_direction(const sxd_span_mirror_port_direction_t sxd_dir,
                                                     span_mirror_direction_t               *span_dir_p);

/*
 * Most of the functions in span_db operate on the internal session ID, except
 * for id_alloc, id_free and id_remap, which make and break the association between
 * external and internal sessions ID.
 */
sx_status_t span_db_session_id_int_alloc(sx_span_session_id_int_t* span_session_id_p);
sx_status_t span_db_session_id_alloc(sx_span_session_id_t* span_session_id_p);
sx_status_t span_db_session_id_int_free(sx_span_session_id_int_t span_session_id);
sx_status_t span_db_session_id_free(sx_span_session_id_t span_session_id);
sx_status_t span_db_session_id_remap(sx_span_session_id_t     span_session_id,
                                     sx_span_session_id_int_t span_session_id_int);

sx_status_t span_db_session_get(sx_span_session_id_int_t span_session_id,
                                span_session_info_t     *span_session_info,
                                sx_port_log_id_t        *analyzer_port,
                                uint32_t                *mirrors_num,
                                span_mirror_t           *mirrors_arr,
                                uint32_t                *ref_cnt,
                                boolean_t               *table_mirror);

/*
 * Get ports selected for SPAN analyzer multiport fields.
 * Return an error if the analyzer is not a LAG port.
 * Return an error if the multiport_num_p does not point to max multiport number value.
 */
sx_status_t span_db_analyzer_multiport_get(sx_span_session_id_int_t span_session_id_int,
                                           sx_port_log_id_t        *analyzer_multiport_p,
                                           uint8_t                 *multiport_num_p);
sx_status_t span_db_session_find(sx_span_session_id_int_t span_session_id);

sx_status_t span_db_gc_context_set(span_session_info_t *span_session_info_p);

sx_status_t span_db_session_set(sx_span_session_id_int_t span_session_id,
                                span_session_info_t     *span_session_info);

sx_status_t span_db_port_analyzer_set(sx_access_cmd_t                        cmd,
                                      sx_port_log_id_t                       port_log_id,
                                      const span_analyzer_port_set_params_t *port_params_p,
                                      sx_span_session_id_int_t               span_session_id);

sx_status_t span_db_port_analyzer_get(sx_port_log_id_t                port_log_id,
                                      sx_span_analyzer_port_params_t *port_params_p,
                                      sx_span_session_id_int_t       *span_session_id_list_p,
                                      uint32_t                       *span_sessions_cnt_p);

sx_status_t span_db_port_analyzer_is_local_get(sx_port_log_id_t port_log_id,
                                               boolean_t       *is_local_span_p);

sx_status_t span_db_mirror_phy_port_set(IN sx_port_log_id_t           log_port,
                                        IN span_mirror_direction_t    mirror_direction,
                                        IN sx_span_session_id_int_t   span_session_id,
                                        IN sx_span_probability_rate_t rate,
                                        IN boolean_t                  enable);

sx_status_t span_db_session_flooding_set(const sx_span_session_id_int_t span_session_id);

sx_status_t span_db_session_counter_get(const sx_access_cmd_t          cmd,
                                        const sx_span_session_id_int_t span_session_id,
                                        sx_span_counter_set_t         *counter_set_p);

sx_status_t span_db_mirror_tables_set(const sx_access_cmd_t          cmd,
                                      const sx_span_session_id_int_t span_session_id);

sx_status_t span_db_mirror_tables_get(sx_span_session_id_int_t *span_session_id);

sx_status_t span_db_mirroring_move(const sx_span_session_id_int_t old_span_session_id,
                                   const sx_span_session_id_int_t new_span_session_id);
sx_status_t span_db_drop_reason_in_list(const sx_span_drop_reason_t  drop_reason,
                                        const sx_span_drop_reason_t *drop_reason_list_p,
                                        const uint32_t               drop_reason_count,
                                        boolean_t                   *has_drop_reason);
sx_status_t span_db_mirror_drops_set(const sx_access_cmd_t                cmd,
                                     const sx_span_session_id_int_t       span_session_id,
                                     const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                     const sx_span_drop_reason_t         *drop_reason_list_p,
                                     uint32_t                             drop_reason_count);
sx_status_t span_db_mirror_drops_get(const sx_span_session_id_int_t       span_session_id,
                                     const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                     sx_span_drop_reason_t               *drop_reason_list_p,
                                     uint32_t                            *drop_reason_count);

sx_status_t port_db_egress_mirror_buff_set(sx_port_log_id_t port_id, buffer_units_t egress_buff_size);

sx_status_t span_db_egress_mirror_ref_count_set(const sx_access_cmd_t                cmd,
                                                sx_port_log_id_t                     port_id,
                                                uint32_t                            *ref_count_p,
                                                const span_egress_mirror_buff_type_e type);

/**
 * Add a reference to an existing session.  Session cannot be destroyed while
 * any references exist.
 *
 * @param[in]  user_handle          handle to user module's data
 * @param[in]  span_session_id      internal session ID
 *
 * @return SX_STATUS_SUCCESS            - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR        - handle or session ID is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND    - no session with that ID
 */
sx_status_t span_db_session_ref_cnt_inc(span_client_handle_t           user_handle,
                                        const sx_span_session_id_int_t span_session_id);

/**
 * Delete a reference to an existing session.  Session cannot be destroyed while
 * any references exist.
 *
 * @param[in]  user_handle          handle to user module's data
 * @param[in]  span_session_id      internal session ID
 *
 * @return SX_STATUS_SUCCESS            - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR        - handle or session ID is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND    - no session with that ID
 * @return SX_STATUS_ERROR              - reference count already zero
 */
sx_status_t span_db_session_ref_cnt_dec(span_client_handle_t           user_handle,
                                        const sx_span_session_id_int_t span_session_id);

/**
 * Lock a session in order to perform HW operations
 *
 * @param[in]  user_handle          handle to user module's data
 * @param[in]  span_session_id      external ID of session to lock
 * @param[out] span_session_id_int  internal ID of this session
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - handle or span_session_id is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND - session not active
 * @return SX_STATUS_RESOURCE_IN_USE - Lock already active on session
 */
sx_status_t span_db_session_lock(span_client_handle_t       user_handle,
                                 const sx_span_session_id_t span_session_id,
                                 sx_span_session_id_int_t  *span_session_id_int);

/**
 * Unlock a session after performing HW operations
 *
 * @param[in]  user_handle          handle to user module's data
 * @param[in]  span_session_id      external ID of session to lock
 * @param[out] span_session_id_int  internal ID of this session
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - handle or span_session_id is invalid
 * @return SX_STATUS_NO_RESOURCES - lock not held for this session
 */
sx_status_t span_db_session_unlock(span_client_handle_t       user_handle,
                                   const sx_span_session_id_t span_session_id);

/**
 * Returns whether a session is locked
 *
 * @param[in]  user_handle          handle to user module's data
 * @param[in]  span_session_id      external ID of session to lock
 * @param[out] locked               TRUE if locked
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - handle or span_session_id is invalid
 */
sx_status_t span_db_session_is_locked(const sx_span_session_id_t span_session_id,
                                      boolean_t                 *locked);

/**
 * Register a callback function to be called when SPAN changes the internal
 * session mapped to an external session.
 *
 * @param[in]  cb_relocate      callback to be called on session relocation
 * @param[out] user_handle_p    handle to user module's data
 *
 * @return SX_STATUS_SUCCESS        - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR    - null pointer passed
 * @return SX_STATUS_NO_RESOURCES   - maximum users exceeded
 */
sx_status_t span_db_user_init(span_cb_relocate_t    cb_relocate,
                              span_client_handle_t *user_handle_p);

/**
 * Deregister a module using SPAN.
 *
 * @param[in]  user_handle    handle to user module's data
 *
 * @return SX_STATUS_SUCCESS        - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR    - invalid pointer passed
 */
sx_status_t span_db_user_deinit(span_client_handle_t user_handle);

/**
 * Inform all registered modules that a mapping between external and internal
 * session has changed.
 *
 * @param[in] span_session_id           external ID of session
 * @param[in] old_span_session_id_int   old internal ID of this session
 * @param[in] new_span_session_id_int   new internal ID of this session
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 */
sx_status_t span_db_advise_relocate(const sx_span_session_id_t     span_session_id,
                                    const sx_span_session_id_int_t old_span_session_id_int,
                                    const sx_span_session_id_int_t new_span_session_id_int);

/**
 * Set the header version to be requested in all MPAT configurations.
 *
 * @param[in] version       V0, V1 or none
 *
 * @return    none
 */
void span_db_header_version_set(const sx_span_mirror_header_version_t version);

/**
 * Get the header version requested in all MPAT configurations.
 *
 * @return    V0, V1 or none
 */
sx_span_mirror_header_version_t span_db_header_version_get(void);

/**
 * This function is used to generate debug dump for SPAN DB
 *
 * @param[in] stream - file stream for debug dump
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_UNSUPPORTED if debug dump is not supported
 * @return SX_STATUS_ERROR for a general error
 */
sx_status_t span_db_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);
sx_status_t port_db_headroom_buff_size_get(sx_port_log_id_t port_id, buffer_units_t* headroom_buff_size);

sx_status_t span_db_do_sync_fence(void);
/**
 * This function  returns the total number of used sessions in the SPAN database
 *
 * @param[out] count - return the count of active sessions
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_NULL if a null parameter is passed.
 */
sx_status_t span_db_total_session_get(OUT uint32_t *count_p);

/**
 * This function is used to retrieve session ids from the SPAN database.
 * @param [in] cmd                  - GET/GET_FIRST/GET_NEXT
 * @param [in] span_session_key_p   - A span session id as key to start retrieval from
 * @param [in] filter_p             - Parameters to filter the retrieved span sessions
 * @param [out] span_session_list_p - return list of span sessions
 * @param [in,out] span_session_cnt - [in]  number of sessions to retrieve
 *                                    [out] number of sessions retrieved
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_PARAM_ERROR if any input parameter is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND if requested element is not found in DB
 * @return SX_STATUS_ERROR if unexpected behavior occurs
 * @return SX_STATUS_CMD_UNSUPPORTED - if invalid cmd is passed
 * @return SX_STATUS_DB_NOT_INITIALIZED - if internal DB is not initialized
 *
 */
sx_status_t span_db_session_iter_get(IN const sx_access_cmd_t       cmd,
                                     IN const sx_span_session_id_t *span_session_key_p,
                                     IN const sx_span_filter_t     *filter_p,
                                     OUT sx_span_session_id_t      *span_session_list_p,
                                     INOUT uint32_t                *span_session_cnt_p);

sx_status_t span_db_mirror_bind(const sx_span_mirror_bind_key_t  *key_p,
                                const sx_span_mirror_bind_attr_t *attr_p);

sx_status_t span_db_mirror_unbind(const sx_span_mirror_bind_key_t *key_p);

sx_status_t span_db_mirror_bind_get(const sx_span_mirror_bind_key_t *key_p,
                                    sx_span_mirror_bind_attr_t      *attr_p);

sx_status_t span_db_session_mirror_bound_get(const sx_span_session_id_int_t span_session_id,
                                             sx_span_mirror_bind_key_t     *mirror_bind_key_list_p,
                                             uint32_t                      *mirror_bind_key_cnt_p);

sx_status_t span_db_mirror_bound_update(span_mirror_direction_t  direction,
                                        sx_span_session_id_int_t old_span_session_id,
                                        sx_span_session_id_int_t new_span_session_id);

sx_status_t span_db_mirror_enable_phy_port_set(sx_port_log_id_t             log_port,
                                               sx_span_mirror_enable_type_e mirror_enable_type,
                                               uint32_t                     tc_pg_en);

sx_status_t span_db_mirror_enable_add(const sx_span_mirror_enable_object_t *object_p,
                                      const sx_span_mirror_enable_attr_t   *attr_p);

sx_status_t span_db_mirror_enable_remove(const sx_span_mirror_enable_object_t *object_p);

sx_status_t span_db_mirror_enable_get(const sx_span_mirror_enable_object_t *object_p,
                                      sx_span_mirror_enable_attr_t         *attr_p);

sx_status_t span_db_mirror_enable_port_remove(sx_port_log_id_t             log_port,
                                              sx_span_mirror_enable_type_e type);

sx_status_t span_db_mirror_enable_port_get(sx_port_log_id_t             log_port,
                                           sx_span_mirror_enable_type_e type,
                                           uint32_t                    *tc_pg_en_p);

sx_status_t span_db_mirror_enable_iter_get(const sx_access_cmd_t                cmd,
                                           sx_span_mirror_enable_object_t      *object_key_p,
                                           sx_span_mirror_enable_iter_filter_t *filter_p,
                                           sx_span_mirror_enable_object_t      *object_list_p,
                                           uint32_t                            *object_cnt_p);

sx_status_t span_db_mirror_enable_port_set(sx_port_log_id_t                              log_port,
                                           const sx_span_mirror_trigger_disallow_list_t *disallow_elephant,
                                           const sx_span_mirror_trigger_disallow_list_t *disallow_none_elephant);

sx_status_t span_db_mirror_enable_port_unset(sx_port_log_id_t                              log_port,
                                             const sx_span_mirror_trigger_disallow_list_t *disallow_elephant,
                                             const sx_span_mirror_trigger_disallow_list_t *disallow_none_elephant);

sx_status_t span_db_mirror_enable_port_iter_get(const sx_access_cmd_t                     cmd,
                                                sx_port_log_id_t                          log_port,
                                                sx_span_mirror_enable_port_iter_filter_t *filter_p,
                                                sx_span_mirror_enable_port_set_t         *mirror_enable_cfg_list_p,
                                                uint32_t                                 *mirror_enable_cnt_p);

sx_status_t span_db_mirror_tables_attr_set(const sx_access_cmd_t               cmd,
                                           const sx_span_mirror_tables_attr_t *attr_p);

sx_status_t span_db_mirror_tables_attr_get(sx_span_mirror_tables_attr_t *attr_p);


sx_status_t span_db_port_mirror_prob_rate_get(sx_port_log_id_t                log_port,
                                              sx_port_usr_probability_rate_t *usr_probability_rate_p);
sx_status_t span_db_port_mirror_prob_rate_set(sx_port_log_id_t                log_port,
                                              sx_port_usr_probability_rate_t *usr_probability_rate_p);

sx_status_t span_db_mirror_port_prob_rate_set(sx_port_log_id_t                      log_port,
                                              const sx_port_usr_probability_rate_t *usr_probability_rate_p);
sx_status_t span_db_mirror_port_prob_rate_get(sx_port_log_id_t                log_port,
                                              sx_port_usr_probability_rate_t *usr_probability_rate_p);

sx_status_t span_db_attributes_get(sx_span_attrs_t *attr_p);

sx_status_t span_db_attributes_set(sx_span_attrs_t *attr_p);

sx_status_t span_db_analyzer_lag_port_become_active(const sx_port_id_t lag_port_log_id);

sx_status_t span_db_analyzer_lag_port_become_inactive(const sx_port_id_t lag_port_log_id,
                                                      const sx_port_id_t port_log_id);

sx_status_t span_db_analyzer_lag_port_force_refresh(const sx_port_id_t lag_port_log_id);

sx_status_t span_db_analyzer_active_sessions_get(const sx_port_id_t        analyzer_port_log_id,
                                                 sx_span_session_id_int_t *span_sessions_id_int_arr,
                                                 length_t                 *span_sessions_count_p);

#endif /* __SPAN_DB_H_INCL__ */
