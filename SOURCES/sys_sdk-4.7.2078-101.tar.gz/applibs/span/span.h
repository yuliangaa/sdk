/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __SPAN_H__
#define __SPAN_H__

#include <sx/sdk/sx_types.h>
#include <sx/sdk/sx_api.h>
#include "span_db.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/*
 * Data passed via adviser on change of internal session ID due to editing.
 * A module receiving this should reprogram any registers using external
 * mirroring session ext_session_id to use internal int_session_id.
 */
typedef struct span_session_update {
    sx_span_session_id_t     ext_session_id;
    sx_span_session_id_int_t int_session_id;
} span_session_update_t;


/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sx_status_t span_init(sx_api_sx_sdk_init_t *init_params);

sx_status_t span_deinit();

sx_status_t span_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);

sx_status_t span_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level_p);

sx_status_t span_cnv_simple_to_full_mirror_direction(sx_mirror_direction_t    simple_md,
                                                     span_mirror_direction_t *full_md);
sx_status_t span_cnv_full_to_simple_mirror_direction(span_mirror_direction_t full_md,
                                                     sx_mirror_direction_t  *simple_md);

sx_status_t span_is_initialized_get(boolean_t *is_initialized);

sx_status_t span_session_set(const sx_access_cmd_t     cmd,
                             sx_span_session_id_t     *span_session_id_p,
                             sx_span_session_params_t *span_session_params);

sx_status_t span_session_get(const sx_span_session_id_t span_session_id,
                             sx_span_session_params_t  *span_session_params);
sx_status_t span_session_iter_get(const sx_access_cmd_t       cmd,
                                  const sx_span_session_id_t *span_session_key_p,
                                  const sx_span_filter_t     *filter_p,
                                  sx_span_session_id_t       *span_session_list_p,
                                  uint32_t                   *span_session_cnt_p);
sx_status_t span_session_state_set(const sx_span_session_id_t span_session_id,
                                   const boolean_t            admin_state);

sx_status_t span_session_state_get(const sx_span_session_id_t span_session_id,
                                   boolean_t                 *admin_state_p);

sx_status_t span_session_state_ext_get(const sx_span_session_id_t   span_session_id,
                                       sx_span_session_state_ext_t *span_session_state_ext_p);

sx_status_t span_session_analyzer_get(const sx_span_session_id_t span_session_id,
                                      sx_port_log_id_t          *analyzer_port_p);

sx_status_t span_session_mirror_get_all(const sx_span_session_id_t span_session_id,
                                        span_mirror_t             *mirror_ports_list_p,
                                        uint32_t                  *mirror_ports_cnt_p);

sx_status_t span_session_mirror_get(const sx_span_session_id_t span_session_id,
                                    sx_span_mirror_t          *mirror_ports_list_p,
                                    uint32_t                  *mirror_ports_cnt_p);

sx_status_t span_mirror_set_common(const sx_access_cmd_t         cmd,
                                   const sx_port_log_id_t        mirror_port,
                                   const span_mirror_direction_t mirror_direction,
                                   const sx_span_session_id_t    span_session_id);

sx_status_t span_mirror_set(const sx_access_cmd_t       cmd,
                            const sx_port_log_id_t      mirror_port,
                            const sx_mirror_direction_t mirror_direction,
                            const sx_span_session_id_t  span_session_id);

sx_status_t span_mirror_get_common(const sx_port_log_id_t        mirror_port,
                                   const span_mirror_direction_t mirror_direction,
                                   sx_span_session_id_t         *span_session_id_p);

sx_status_t span_mirror_get(const sx_port_log_id_t      mirror_port,
                            const sx_mirror_direction_t mirror_direction,
                            sx_span_session_id_t       *span_session_id_p);

sx_status_t span_mirror_state_set_common(const sx_port_log_id_t        mirror_port,
                                         const span_mirror_direction_t mirror_direction,
                                         const boolean_t               admin_state);

sx_status_t span_mirror_state_set(const sx_port_log_id_t      mirror_port,
                                  const sx_mirror_direction_t mirror_direction,
                                  const boolean_t             admin_state);

sx_status_t span_mirror_state_get_common(const sx_port_log_id_t        mirror_port,
                                         const span_mirror_direction_t mirror_direction,
                                         boolean_t                    *admin_state_p);

sx_status_t span_mirror_state_get(const sx_port_log_id_t      mirror_port,
                                  const sx_mirror_direction_t mirror_direction,
                                  boolean_t                  *admin_state_p);

sx_status_t span_analyzer_set(const sx_access_cmd_t                  cmd,
                              const sx_port_log_id_t                 log_port,
                              const span_analyzer_port_set_params_t *port_params_p,
                              const sx_span_session_id_t             span_session_id);

sx_status_t span_analyzer_get(const sx_port_log_id_t          log_port,
                              sx_span_analyzer_port_params_t *port_params_p,
                              sx_span_session_id_t           *span_session_id_list_p,
                              uint32_t                       *span_sessions_cnt_p);

sx_status_t span_analyzer_port_test(const sx_port_log_id_t log_port,
                                    boolean_t             *port_is_analyzer);

sx_status_t span_init_set_sx(const sx_span_init_params_t *init_params_p);

sx_status_t span_init_set_spectrum(const sx_span_init_params_t *init_params_p);

sx_status_t span_init_set_spectrum2(const sx_span_init_params_t *init_params_p);

sx_status_t span_init_set(const sx_span_init_params_t *init_params_p);

sx_status_t span_deinit_set(void);

sx_status_t span_session_counter_get_spectrum(const sx_access_cmd_t      cmd,
                                              const sx_span_session_id_t span_session_id,
                                              sx_span_counter_set_t     *counter_set_p);

sx_status_t span_session_counter_get(const sx_access_cmd_t      cmd,
                                     const sx_span_session_id_t span_session_id,
                                     sx_span_counter_set_t     *counter_set_p);

sx_status_t span_mirror_tables_set_spectrum(const sx_access_cmd_t      cmd,
                                            const sx_span_session_id_t span_session_id);

sx_status_t span_mirror_tables_set(const sx_access_cmd_t      cmd,
                                   const sx_span_session_id_t span_session_id);

sx_status_t span_mirror_tables_get_spectrum(sx_span_session_id_t *span_session_id_p);

sx_status_t span_mirror_tables_get(sx_span_session_id_t *span_session_id_p);

sx_status_t span_mirror_drops_set_spectrum(const sx_access_cmd_t                cmd,
                                           const sx_span_session_id_t           span_session_id,
                                           const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                           const sx_span_drop_reason_t         *drop_reason_list_p,
                                           uint32_t                             drop_reason_cnt);
sx_status_t span_mirror_drops_set(const sx_access_cmd_t                cmd,
                                  const sx_span_session_id_t           span_session_id,
                                  const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                  const sx_span_drop_reason_t         *drop_reason_list_p,
                                  uint32_t                             drop_reason_cnt);
sx_status_t span_mirror_drops_get_spectrum(const sx_span_session_id_t           span_session_id,
                                           const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                           sx_span_drop_reason_t               *drop_reason_list_p,
                                           uint32_t                            *drop_reason_cnt);
sx_status_t span_mirror_drops_get(const sx_span_session_id_t           span_session_id,
                                  const sx_span_drop_mirroring_attr_t *drop_mirroring_attr_p,
                                  sx_span_drop_reason_t               *drop_reason_list_p,
                                  uint32_t                            *drop_reason_cnt);

sx_status_t span_validate_mirror_header_padding_spectrum4(const sx_span_session_params_t *span_session_params);

sx_status_t span_validate_span_type_format_spectrum(const sx_span_session_params_t *span_session_params);

sx_status_t span_validate_span_type_format_spectrum2(const sx_span_session_params_t *span_session_params);

sx_status_t span_modify_sx(const sx_span_session_id_t       span_session_id,
                           sx_span_session_params_t        *span_session_params,
                           sx_port_log_id_t                *new_analyzer_port_p,
                           span_analyzer_port_set_params_t *port_params_p);

sx_status_t span_modify_spectrum(const sx_span_session_id_t       span_session_id,
                                 sx_span_session_params_t        *span_session_params,
                                 sx_port_log_id_t                *new_analyzer_port_p,
                                 span_analyzer_port_set_params_t *port_params_p);

sx_status_t span_analyzer_set_sx(const sx_access_cmd_t                  cmd,
                                 const sx_port_log_id_t                 log_port,
                                 const span_analyzer_port_set_params_t *port_params_p,
                                 const sx_span_session_id_t             span_session_id);

sx_status_t span_analyzer_set_sdk(const sx_access_cmd_t                  cmd,
                                  const sx_port_log_id_t                 log_port,
                                  const span_analyzer_port_set_params_t *port_params_p,
                                  const sx_span_session_id_t             span_session_id);

sx_status_t span_analyzer_validation_spectrum(const sx_port_log_id_t log_port);

sx_status_t span_analyzer_validation_spectrum2(const sx_port_log_id_t log_port);

sx_status_t span_analyzer_port_multi_session_use(sx_span_session_id_t curr_span_session_id,
                                                 sx_port_log_id_t     log_port,
                                                 boolean_t           *is_type_equal);

/**
 * Add a reference to an existing session.  Session cannot be destroyed while
 * any references exist.
 *
 * @param[in]  user_handle          handle to user module's data
 * @param[in]  span_session_id      External session ID
 *
 * @return SX_STATUS_SUCCESS            - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR        - handle or session ID is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND    - no session with that ID
 */
sx_status_t span_session_ref_cnt_inc(span_client_handle_t       user_handle,
                                     const sx_span_session_id_t span_session_id);

/**
 * Delete a reference to an existing session.  Session cannot be destroyed while
 * any references exist.
 *
 * @param[in]  user_handle          handle to user module's data
 * @param[in]  span_session_id      External session ID
 *
 * @return SX_STATUS_SUCCESS            - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR        - handle or session ID is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND    - no session with that ID
 * @return SX_STATUS_ERROR              - reference count already zero
 */
sx_status_t span_session_ref_cnt_dec(span_client_handle_t       user_handle,
                                     const sx_span_session_id_t span_session_id);

/**
 * Lock a session in order to perform HW operations
 *
 * @param[in]  user_handle          handle to user module's data
 * @param[in]  span_session_id      external ID of session to lock
 * @param[out] span_session_id_int  internal ID of this session
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - handle or span_session_id is invalid
 * @return SX_STATUS_ENTRY_NOT_FOUND - session not active
 * @return SX_STATUS_RESOURCE_IN_USE - Lock already active on session
 */
sx_status_t span_session_lock(span_client_handle_t       user_handle,
                              const sx_span_session_id_t span_session_id,
                              sx_span_session_id_int_t  *span_session_id_int);

/**
 * Unlock a session after performing HW operations
 *
 * @param[in]  user_handle          handle to user module's data
 * @param[in]  span_session_id      external ID of session to lock
 * @param[out] span_session_id_int  internal ID of this session
 *
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR - handle or span_session_id is invalid
 * @return SX_STATUS_NO_RESOURCES - lock not held for this session
 */
sx_status_t span_session_unlock(span_client_handle_t       user_handle,
                                const sx_span_session_id_t span_session_id);

/**
 * Register a callback function to be called when SPAN changes the internal
 * session mapped to an external session.
 *
 * @param[in]  cb_relocate      callback to be called on session relocation
 * @param[out] user_handle_p    handle to user module's data
 *
 * @return SX_STATUS_SUCCESS        - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR    - null pointer passed
 * @return SX_STATUS_NO_RESOURCES   - maximum users exceeded
 */
sx_status_t span_user_init(span_cb_relocate_t    cb_relocate,
                           span_client_handle_t *user_handle_p);

/**
 * Deregister a module using SPAN.
 *
 * @param[in]  user_handle    handle to user module's data
 *
 * @return SX_STATUS_SUCCESS        - operation completes successfully
 * @return SX_STATUS_PARAM_ERROR    - invalid pointer passed
 */
sx_status_t span_user_deinit(span_client_handle_t user_handle);

/**
 * This function is used to generate debug dump for SPAN
 *
 * @param[in] stream - file stream for debug dump
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_UNSUPPORTED if debug dump is not supported
 * @return SX_STATUS_ERROR for a general error
 */
sx_status_t span_dbg_generate_dump(dbg_dump_params_t *dbg_dump_params_p);

/**
 * This function is used to set the SBIB mirroring register
 *
 * @param[in] cmd - Command (ADD/ DELETE)
 * @param[in] port_log_id - logical port ID
 * @param[inout] buff_size - Pointer to SBIB buffer size
 * @param[out] status - hold the buff status (0 size was not reached, 1-Size reached)
 * @param[in] type - always 0
 * @param[in] int_buff_index - always 0
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 * @return SX_STATUS_UNSUPPORTED if debug dump is not supported
 * @return SX_STATUS_ERROR for a general error
 */
sx_status_t __handle_sbib(IN sx_access_cmd_t                    cmd, /* SET/GET */
                          IN sx_port_id_t                       port_log_id,
                          INOUT uint32_t                       *buff_size, /* buffer size (Should not be NULL)*/
                          OUT span_mirror_egress_buff_status_t *status,  /*(Should not be NULL)
                                                                          *  0-buff size not reach requested size
                                                                          *  1-buff size do reach requested size*/
                          IN uint8_t                            type, /* Supported values = 0 */
                          IN uint8_t                            int_buff_index); /* Supported values = 0 */


sx_status_t span_egress_mirror_handle_buffer(const sx_access_cmd_t cmd, const sx_port_log_id_t log_port_id);
sx_status_t span_init_spectrum(void);
sx_status_t span_deinit_set_spectrum(void);
sx_status_t span_session_id_free_sx(span_session_info_t *span_session_info_p, sx_span_session_id_t span_session_id);
sx_status_t span_session_id_free_spectrum(span_session_info_t *span_session_info_p,
                                          sx_span_session_id_t span_session_id);
sx_status_t span_free_session_id_free_spectrum(sx_span_session_id_t span_session_id);


sx_status_t span_egress_mirror_alloc_buffer_spectrum(const sx_port_log_id_t               mirror_port,
                                                     const span_mirror_direction_t        mirror_direction,
                                                     const sx_access_cmd_t                cmd,
                                                     const span_egress_mirror_buff_type_e type);

sx_status_t span_egress_mirror_alloc_buffer_cb_wrapper(const sx_access_cmd_t                cmd,
                                                       const sx_port_log_id_t               mirror_port,
                                                       const span_mirror_direction_t        mirror_direction,
                                                       const span_egress_mirror_buff_type_e type);

sx_status_t span_mirror_bind_set(const sx_access_cmd_t             cmd,
                                 const sx_span_mirror_bind_key_t  *key_p,
                                 const sx_span_mirror_bind_attr_t *attr_p);

sx_status_t span_mirror_bind_get(const sx_span_mirror_bind_key_t *key_p,
                                 sx_span_mirror_bind_attr_t      *attr_p);

sx_status_t span_mirror_bind_set_spectrum(const sx_access_cmd_t             cmd,
                                          const sx_span_mirror_bind_key_t  *key_p,
                                          const sx_span_mirror_bind_attr_t *attr_p);

sx_status_t span_mirror_bind_get_spectrum(const sx_span_mirror_bind_key_t *key_p,
                                          sx_span_mirror_bind_attr_t      *attr_p);

sx_status_t span_mirror_bind_set_spectrum2(const sx_access_cmd_t             cmd,
                                           const sx_span_mirror_bind_key_t  *key_p,
                                           const sx_span_mirror_bind_attr_t *attr_p);

sx_status_t span_mirror_bind_get_spectrum2(const sx_span_mirror_bind_key_t *key_p,
                                           sx_span_mirror_bind_attr_t      *attr_p);

sx_status_t span_session_mirror_bound_get(const sx_span_session_id_t span_session_id,
                                          sx_span_mirror_bind_key_t *mirror_bind_key_list_p,
                                          uint32_t                  *mirror_bind_key_cnt_p);

sx_status_t span_session_mirror_bound_get_spectrum2(const sx_span_session_id_t span_session_id,
                                                    sx_span_mirror_bind_key_t *mirror_bind_key_list_p,
                                                    uint32_t                  *mirror_bind_key_cnt_p);

sx_status_t span_mirror_enable_set(const sx_access_cmd_t                 cmd,
                                   const sx_span_mirror_enable_object_t *object_p,
                                   const sx_span_mirror_enable_attr_t   *attr_p);

sx_status_t span_mirror_enable_get(const sx_span_mirror_enable_object_t *object_p,
                                   sx_span_mirror_enable_attr_t         *attr_p);

sx_status_t span_mirror_enable_iter_get(const sx_access_cmd_t                cmd,
                                        sx_span_mirror_enable_object_t      *object_key_p,
                                        sx_span_mirror_enable_iter_filter_t *filter_p,
                                        sx_span_mirror_enable_object_t      *object_list_p,
                                        uint32_t                            *object_cnt_p);

sx_status_t span_mirror_enable_set_spectrum2(const sx_access_cmd_t                 cmd,
                                             const sx_span_mirror_enable_object_t *object_p,
                                             const sx_span_mirror_enable_attr_t   *attr_p);

sx_status_t span_mirror_enable_get_spectrum2(const sx_span_mirror_enable_object_t *object_p,
                                             sx_span_mirror_enable_attr_t         *attr_p);

sx_status_t span_mirror_enable_iter_get_spectrum2(const sx_access_cmd_t                cmd,
                                                  sx_span_mirror_enable_object_t      *object_key_p,
                                                  sx_span_mirror_enable_iter_filter_t *filter_p,
                                                  sx_span_mirror_enable_object_t      *object_list_p,
                                                  uint32_t                            *object_cnt_p);
sx_status_t span_mirror_enable_port_set(const sx_access_cmd_t                   cmd,
                                        const uint32_t                          mirror_enable_cnt,
                                        const sx_span_mirror_enable_port_set_t *mirror_enable_cfg_list_p);
sx_status_t span_mirror_enable_port_iter_get(const sx_access_cmd_t                     cmd,
                                             sx_port_log_id_t                          log_port,
                                             sx_span_mirror_enable_port_iter_filter_t *filter_p,
                                             sx_span_mirror_enable_port_set_t         *mirror_enable_cfg_list_p,
                                             uint32_t                                 *mirror_enable_cnt_p);

sx_status_t span_mirror_enable_port_set_spectrum4(const sx_access_cmd_t                   cmd,
                                                  const uint32_t                          mirror_enable_cnt,
                                                  const sx_span_mirror_enable_port_set_t *mirror_enable_cfg_list_p);

sx_status_t span_mirror_enable_port_iter_get_spectrum4(const sx_access_cmd_t                     cmd,
                                                       sx_port_log_id_t                          log_port,
                                                       sx_span_mirror_enable_port_iter_filter_t *filter_p,
                                                       sx_span_mirror_enable_port_set_t         *mirror_enable_cfg_list_p,
                                                       uint32_t                                 *mirror_enable_cnt_p);

sx_status_t span_mirror_tables_attr_set(const sx_access_cmd_t               cmd,
                                        const sx_span_mirror_tables_attr_t *attr_p);

sx_status_t span_mirror_tables_attr_get(sx_span_mirror_tables_attr_t *attr_p);

sx_status_t span_mirror_tables_attr_set_spectrum2(const sx_access_cmd_t               cmd,
                                                  const sx_span_mirror_tables_attr_t *attr_p);

sx_status_t span_mirror_tables_attr_get_spectrum2(sx_span_mirror_tables_attr_t *attr_p);


sx_status_t span_header_time_stamp_set(sx_span_hdr_ts_config_t span_ts);

sx_status_t span_header_time_stamp_set_spectrum(sx_span_hdr_ts_config_t span_ts);

sx_status_t span_header_time_stamp_set_spectrum2(sx_span_hdr_ts_config_t span_ts);

inline static sx_status_t __span_spectrum2_feature_supported(sx_chip_types_t chip_type)
{
    switch (chip_type) {
    case SX_CHIP_TYPE_SPECTRUM2:
    case SX_CHIP_TYPE_SPECTRUM3:
    case SX_CHIP_TYPE_SPECTRUM4:
    case SX_CHIP_TYPE_SPECTRUM5:
        return SX_STATUS_SUCCESS;

    default:
        return SX_STATUS_UNSUPPORTED;
    }
}

sx_status_t span_policer_bind_set(const sx_access_cmd_t      cmd,
                                  const sx_span_session_id_t span_session_id,
                                  const sx_policer_id_t      policer_id);

sx_status_t span_policer_bind_get(const sx_span_session_id_t span_session_id,
                                  sx_policer_id_t           *policer_id_p);

sx_status_t span_policer_bind_set_wrapper(const sx_access_cmd_t      cmd,
                                          const sx_span_session_id_t span_session_id,
                                          const sx_policer_id_t      policer_id);

sx_status_t span_policer_bind_get_wrapper(const sx_span_session_id_t span_session_id,
                                          sx_policer_id_t           *policer_id_p);

sx_status_t span_attributes_get(sx_span_attrs_t *attr_p);
sx_status_t span_attributes_set_spc4(sx_span_attrs_t *attr_p);
sx_status_t span_attributes_get_wrapper(sx_span_attrs_t *attr_p);
sx_status_t span_attributes_set_wrapper(sx_span_attrs_t *attr_p);
sx_status_t span_port_attr_set(sx_port_log_id_t     log_port,
                               sx_span_port_attr_t *span_port_attr_list_p,
                               uint32_t             span_port_attr_list_size);

sx_status_t span_port_attr_get(sx_port_log_id_t         log_port,
                               sx_span_port_attr_type_e attr_type,
                               sx_span_port_attr_t     *span_port_attr_p);


/**
 * [Spectrum-4 and above] Set the mirror header padding bytes if supported by ASIC.
 *
 * Adding padding to Mirror header V1 & V2 to change the alignment of starting the encapsulated original packet.
 * Relevant only for encapsulated L2 and L3-GRE span types (ERSPAN) .
 * e.g:
 *   - no padding(default) - Original packet start on 2Byte alignment.
 *   - 2Bytes padding - will align the start of the original packet to 4Bytes.
 *
 * @param[in] header_version - ERSPAN mirror header version        -
 * @param[in] sx_span_session_params_p - mirror session parameters
 * @param[out] padding_p - Pad count. 0: No_padding; 1: 2Bytes_padding
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully
 */
sx_status_t span_mirror_header_padding_spectrum4(const sx_span_mirror_header_version_t header_version,
                                                 const sx_span_session_params_t       *sx_span_session_params_p,
                                                 uint8_t                              *padding_p);

sx_status_t span_mirror_truncation_profile_set_cb_wrapper(const sx_access_cmd_t    cmd,
                                                          sx_span_session_id_int_t span_session_id_int,
                                                          span_session_info_t     *span_session_info_p);

sx_status_t span_mirror_truncation_profile_get_cb_wrapper(sx_span_session_id_int_t span_session_id_int,
                                                          span_session_info_t     *span_session_info_p);

sx_status_t span_mirror_truncation_profile_validate_cb_wrapper(const span_session_info_t *span_session_info_p);

sx_status_t span_mirror_truncation_profile_refcount_cb_wrapper(const sx_access_cmd_t    cmd,
                                                               sx_span_session_id_int_t span_session_id_int);

/**
 * [Spectrum-4 and above] Configure fixed-offset truncation using Truncation-Profile.
 *
 * @param[in] cmd - ADD, DELETE
 * @param[in] span_session_id_int - Mirror agent (=Port analyzer) ID
 * @param[in] span_session_info_p - SPAN session data.
 * @return SX_STATUS_SUCCESS if operation completes successfully
 */
sx_status_t span_mirror_truncation_profile_set_spectrum4(const sx_access_cmd_t    cmd,
                                                         sx_span_session_id_int_t span_session_id_int,
                                                         span_session_info_t     *span_session_info_p);

/**
 * [Spectrum-4 and above] Get Truncation-Profile configuration
 * @param[in] span_session_id_int - Mirror agent (=Port analyzer) ID
 * @param[in,out] span_session_info_p - SPAN session data.
 * @return SX_STATUS_SUCCESS if operation completes successfully
 */
sx_status_t span_mirror_truncation_profile_get_spectrum4(sx_span_session_id_int_t span_session_id_int,
                                                         span_session_info_t     *span_session_info_p);

/**
 * [Spectrum-4 and above] Truncation-Profile validations
 * @param[in] span_session_info_p - SPAN session data.
 * @return SX_STATUS_SUCCESS if operation completes successfully
 */
sx_status_t span_mirror_truncation_profile_validate_spectrum4(const span_session_info_t *span_session_info_p);

sx_status_t span_mirror_truncation_profile_refcount_spectrum4(const sx_access_cmd_t    cmd,
                                                              sx_span_session_id_int_t span_session_id_int);

sx_status_t span_mirror_truncation_hw_set_cb_wrapper(struct ku_mpat_reg *mpat_reg_data_p);

sx_status_t span_mirror_truncation_hw_set_spectrum4(struct ku_mpat_reg *mpat_reg_data_p);

sx_status_t span_analyzer_lag_port_become_inactive(const sx_port_id_t lag_port_log_id,
                                                   const sx_port_id_t port_log_id);

sx_status_t span_analyzer_lag_port_become_active(const sx_port_id_t lag_port_log_id);

sx_status_t span_analyzer_multiport_update_job_hadnle(const sx_port_oper_state_t oper_state,
                                                      const sx_port_id_t         port_log_id);

sx_status_t span_issu_sessions_check(void);

sx_status_t span_mirror_port_prob_rate_set_spc2(sx_port_log_id_t                      log_port,
                                                const sx_port_usr_probability_rate_t *usr_probability_rate_p);
sx_status_t span_mirror_port_prob_rate_get_spc2(sx_port_log_id_t                log_port,
                                                sx_port_usr_probability_rate_t *usr_probability_rate_p);

#endif /* __SPAN_H__ */
