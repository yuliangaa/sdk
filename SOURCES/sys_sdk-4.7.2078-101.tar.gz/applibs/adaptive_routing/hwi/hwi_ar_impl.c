/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "utils/sx_mem.h"
#include "sx/sdk/sx_status.h"
#include "complib/sx_log.h"
#include "sx/sdk/sx_ar.h"
#include "hwi_ar_be.h"
#include "hwi_ar_impl.h"
#include "adaptive_routing/hwd/hwd_ar.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include <sx/utils/dbg_utils.h>
#include <sx/utils/dbg_utils_pretty_printer.h>
#include "ethl2/brg.h"
#include "ethl2/port_db.h"
#include "ethl2/lag.h"
#include "ethl3/hwi/rif/rif_impl.h"
#include <ethl3/hwi/sdk_router_vrid/sdk_router_vrid_impl.h>
#include "counters/counter_manager/counter_manager.h"
#include "ethl3/hwi/ecmp/router_ecmp_impl.h"

#undef  __MODULE__
#define __MODULE__ ADAPTIVE_ROUTING

/************************************************
 *  Defines
 ***********************************************/
#define SHAPER_RATE_VAL  (AR_SHAPER_RATE_DEFAULT * 10)
#define ARN_TIME_DEFAULT 12
/************************************************
 *  Global variables
 ***********************************************/
extern sx_brg_context_t brg_context;
extern hwd_ar_ops_t     g_hwd_ar_ops;

/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
boolean_t                   g_hwi_ar_impl_initialized = FALSE;
boolean_t                   g_hwi_arn_impl_initialized = FALSE;
static cntr_client_handle_t g_cm_handle = 0;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_status_t __sdk_ar_set_hwd_init_ops();
static sx_status_t __sdk_ar_deinit_classification();
static sx_status_t __sdk_ar_deinit_profile();
static sx_status_t __sdk_ar_deinit_arn_profile();
static sx_status_t __sdk_ar_init_shaper_rate();
static sx_status_t __sdk_ar_deinit_link_utilization();
static sx_status_t __sdk_ar_init_congestion_threshold();
static sx_status_t __sdk_ar_impl_arn_deinit_router_generation(void);
static sx_status_t __sdk_ar_impl_arn_counters_set(const sx_access_cmd_t cmd);
static sx_status_t __sdk_ar_impl_arn_port_generation_ingress_set(const sx_access_cmd_t cmd);
static sx_status_t __sdk_ar_impl_arn_general_params_set(const sx_access_cmd_t          cmd,
                                                        const sx_arn_general_params_t *general_params_p);
static sx_status_t __hwi_arn_counter_relocate_cb(const cm_logical_id_t lid,
                                                 const uint32_t        offset,
                                                 const cm_type_e       type,
                                                 const cm_hw_type_t    hw_type,
                                                 const cm_index_t      old_index,
                                                 const cm_index_t      new_index);

/************************************************
 *  Function implementations
 ***********************************************/

sx_status_t sdk_ar_impl_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;
    hwd_ar_log_verbosity_level_set(verbosity_level);
    return err;
}

static sx_status_t __sdk_ar_tc_mapping_init()
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    cos_ar_tc_mapping_t ar_tc_mapping[RM_API_COS_TRAFFIC_CLASS_NUM];

    if (g_hwd_ar_ops.hwd_ar_tc_mapping_init_pfn == NULL) {
        SX_LOG_ERR("Setting AR TC mapping is an unsupported operation.\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    SX_MEM_CLR(ar_tc_mapping);

    /* Generate TC -> AR TC mapping per chip type, and configure HW. */
    err = g_hwd_ar_ops.hwd_ar_tc_mapping_init_pfn(&ar_tc_mapping[0]);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set AR TC mapping, err (%s).\n", sx_status_str(err));
        goto out;
    }

    /* Forward TC -> AR TC mapping to CoS module. */
    err = cos_tc_ar_mapping_init(&ar_tc_mapping[0]);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to init AR TC mapping in COS module, err (%s).\n", sx_status_str(err));
        goto out;
    }

out:
    return err;
}

static sx_status_t __sdk_ar_tc_mapping_deinit(void)
{
    return cos_tc_ar_mapping_deinit();
}

sx_status_t sdk_ar_init(const sx_ar_init_params_t *init_params_p)
{
    sx_status_t    sx_status = SX_STATUS_SUCCESS;
    sx_boot_mode_e boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_LOG_ENTER();

    /* Set the hwd operations */
    sx_status = __sdk_ar_set_hwd_init_ops();
    if (sx_status == SX_STATUS_UNSUPPORTED) {
        SX_LOG_ERR("Adaptive Routing is not supported.\n");
        goto out;
    }
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Adaptive Routing hw init ops failed.\n");
        goto out;
    }

    /* Initialize AR TC mapping */
    sx_status = __sdk_ar_tc_mapping_init();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Adaptive Routing init failed on COS AR TC mapping init, "
                   "err: %s.\n", sx_status_str(sx_status));
        goto out;
    }

    /* initialize COS port map group */
    sx_status = cos_port_group_map_calculate();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Adaptive Routing init failed on COS port group map calculation.\n");
        goto out;
    }

    /* initialize the DB */
    sx_status = sdk_ar_db_init();
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Adaptive Routing DB init failed.\n");
        goto out;
    }

    sx_status = sdk_ar_db_init_params_set(init_params_p);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("Failed to set AR init params.\n");
        goto out;
    }

    sx_status = utils_boot_mode_get(&boot_mode);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_LOG_ERR("failed to get utils boot mode sx_status = %s\n", sx_status_str(sx_status));
        goto out;
    }

    if (boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
        sx_status = __sdk_ar_init_shaper_rate();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Adaptive Routing shaper rate init failed.\n");
            goto out;
        }

        sx_status = __sdk_ar_init_congestion_threshold();
        if (SX_CHECK_FAIL(sx_status)) {
            SX_LOG_ERR("Adaptive Routing congestion threshold init failed.\n");
            goto out;
        }
    }

    g_hwi_ar_impl_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return sx_status;
}

sx_status_t sdk_ar_deinit(boolean_t is_forced)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    UNUSED_PARAM(is_forced);

    if (g_hwi_ar_impl_initialized != TRUE) {
        SX_LOG_INF("Adaptive Routing module is not initialized\n");
        goto out;
    }

    err = cos_port_group_map_clear_all();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinit COS port group map.\n");
        goto out;
    }

    err = __sdk_ar_tc_mapping_deinit();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinit COS AR TC mapping, err: %s.\n", sx_status_str(err));
        goto out;
    }

    err = __sdk_ar_deinit_classification();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Adaptive Routing classification deinit failed.\n");
        goto out;
    }

    err = __sdk_ar_deinit_profile();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Adaptive Routing profile deinit failed.\n");
        goto out;
    }


    err = __sdk_ar_deinit_link_utilization();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Adaptive Routing link utilization deinit failed.\n");
        goto out;
    }

    if (g_hwi_arn_impl_initialized) {
        err = sdk_ar_impl_arn_deinit();
        SX_CHECK_RC_OUT_ERR(err, "Failed to deinit ARN DB");
    }

    g_hwi_ar_impl_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_init()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        err = SX_STATUS_MODULE_UNINITIALIZED;
        SX_CHECK_RC_OUT_ERR(err, "AR module is not initialized.");
    }

    /* initialize the DB */
    err = sdk_ar_db_arn_init();
    SX_CHECK_RC_OUT_ERR(err, "ARN DB init failed.");

    /* Register as CM client (for ARN counters) */
    err = cm_user_init(__hwi_arn_counter_relocate_cb, NULL, NULL, &g_cm_handle);
    if (SX_STATUS_SUCCESS != err) {
        SX_LOG_ERR("Failed to register to Counter Manager, err= %s.\n", sx_status_str(err));
        goto out;
    }
    g_hwi_arn_impl_initialized = TRUE;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_deinit()
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();
    if (g_hwi_arn_impl_initialized == FALSE) {
        goto out;
    }

    err = cm_user_deinit(g_cm_handle);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to deinit ARN's counter manager user.\n");
        goto out;
    }

    err = __sdk_ar_impl_arn_deinit_router_generation();
    SX_CHECK_RC_OUT_ERR(err, "Failed to deinit ARN generation");

    err = __sdk_ar_deinit_arn_profile();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Adaptive Routing ARN profile deinit failed.\n");
        goto out;
    }


    err = sdk_ar_db_arn_deinit();
    SX_CHECK_RC_OUT_ERR(err, "Failed to deinit ARN DB");


    g_hwi_arn_impl_initialized = FALSE;

out:
    SX_LOG_EXIT();
    return err;
}

boolean_t sdk_ar_impl_is_module_initialized(void)
{
    return g_hwi_ar_impl_initialized;
}

boolean_t sdk_arn_impl_is_module_initialized(void)
{
    return g_hwi_arn_impl_initialized;
}

boolean_t sdk_arn_impl_is_arn_generation_enabled(sx_router_id_t vrid)
{
    sx_status_t                err = SX_STATUS_SUCCESS;
    sx_arn_router_key_t        arn_router_key;
    sx_arn_router_attributes_t arn_router_attributes;
    boolean_t                  is_arn_generation_en = FALSE;

    SX_LOG_ENTER();

    SX_MEM_CLR(arn_router_key);
    SX_MEM_CLR(arn_router_attributes);

    if (FALSE == sdk_arn_impl_is_module_initialized()) {
        goto out;
    }

    arn_router_key.vrid = vrid;

    err = sdk_ar_db_arn_router_attr_get(&arn_router_key, &arn_router_attributes);
    if (err == SX_STATUS_ENTRY_NOT_FOUND) {
        goto out;
    } else if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get ARN router attributes.\n");
        goto out;
    }

    is_arn_generation_en = TRUE;

out:
    SX_LOG_EXIT();
    return is_arn_generation_en;
}

sx_status_t sdk_ar_init_ops_spc2(void)
{
    hwd_router_ar_set_impl_ops_spc2();
    return SX_STATUS_SUCCESS;
}

sx_status_t sdk_ar_init_ops_spc4(void)
{
    hwd_router_ar_set_impl_ops_spc4();
    return SX_STATUS_SUCCESS;
}

sx_status_t sdk_ar_init_ops_spc5(void)
{
    hwd_router_ar_set_impl_ops_spc5();
    return SX_STATUS_SUCCESS;
}

static sx_status_t __sdk_ar_set_hwd_init_ops()
{
    sx_status_t err = SX_STATUS_SUCCESS;


    if (TRUE == g_hwi_ar_impl_initialized) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("router ar module is already initialized. err: %s.\n", sx_status_str(err));
        goto out;
    }

    /* Set the hardware operations */
    if (brg_context.spec_cb_g.hwd_ar_assign_ops_cb == NULL) {
        SX_LOG_INF("Adaptive Routing init ops cb is undefined\n");
        err = SX_STATUS_UNSUPPORTED;
        goto out;
    }


    err = brg_context.spec_cb_g.hwd_ar_assign_ops_cb();
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Adaptive Routing init ops failed.\n");
        goto out;
    }

    /* Check that counter relocation cb is valid  */
    if (g_hwd_ar_ops.hwd_arn_counter_relocate_pfn == NULL) {
        err = SX_STATUS_UNSUPPORTED;
        SX_CHECK_RC_OUT_ERR(err, "ARN counters relocation is unsupported.");
    }
out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_profile_set(const sx_access_cmd_t       cmd,
                                    const sx_ar_profile_key_t  *profile_key_p,
                                    const sx_ar_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_ar_profile_set_pfn == NULL) {
        SX_LOG_ERR("Setting AR profile is an unsupported operation\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_db_profile_set(profile_key_p, profile_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in to write AR profile attributes to DB, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = g_hwd_ar_ops.hwd_ar_profile_set_pfn(cmd, profile_key_p, profile_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in HWD profile set, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_profile_set(const sx_access_cmd_t        cmd,
                                        const sx_ar_profile_key_t   *profile_key_p,
                                        const sx_arn_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_arn_profile_set_pfn == NULL) {
        SX_LOG_ERR("Setting ARN profile is an unsupported operation\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_db_arn_profile_set(profile_key_p, profile_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in to write ARN profile attributes to DB, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = g_hwd_ar_ops.hwd_arn_profile_set_pfn(cmd, profile_key_p, profile_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in HWD profile set, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}
sx_status_t sdk_ar_impl_arn_profile_deinit(const sx_ar_profile_key_t *profile_key_p)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_arn_profile_attr_t profile_attr;

    SX_LOG_ENTER();
    SX_MEM_CLR(profile_attr);

    profile_attr.arn_enable = FALSE;
    profile_attr.arn_aging_time = ARN_TIME_DEFAULT;
    profile_attr.arn_hold_time = ARN_TIME_DEFAULT;

    if (g_hwd_ar_ops.hwd_arn_profile_set_pfn == NULL) {
        SX_LOG_ERR("Setting ARN profile is an unsupported operation\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = g_hwd_ar_ops.hwd_arn_profile_set_pfn(SX_ACCESS_CMD_SET, profile_key_p, &profile_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in HWD profile set, error: %s\n", sx_status_str(err));
        goto out;
    }

    err = sdk_ar_db_arn_profile_set(profile_key_p, &profile_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to clear ARN profile attributes to DB, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}
sx_status_t sdk_ar_impl_default_classification_get(sx_ar_classifier_action_t *classifier_action_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_ar_db_classification_get(SX_AR_CLASSIFIER_INDEX_DEFAULT_E, classifier_action_p, NULL);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get AR default classification from DB, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_profile_get(const sx_ar_profile_key_t *profile_key_p, sx_ar_profile_attr_t *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_ar_db_profile_get(profile_key_p, profile_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in to read AR profile attributes from DB, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_profile_get(const sx_ar_profile_key_t *profile_key_p,
                                        sx_arn_profile_attr_t     *profile_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_ar_db_arn_profile_get(profile_key_p, profile_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in to read AR profile attributes from DB, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_default_classification_set(const sx_access_cmd_t            cmd,
                                                   const sx_ar_classifier_action_t *classifier_action_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_ar_classification_set_pfn == NULL) {
        SX_LOG_ERR("Setting AR default classification is an unsupported operation\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_db_classification_set(cmd, SX_AR_CLASSIFIER_INDEX_DEFAULT_E, classifier_action_p, NULL);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in to write AR default classification to DB, error: %s\n", sx_status_str(err));
        goto out;
    }

    err = g_hwd_ar_ops.hwd_ar_classification_set_pfn(cmd,
                                                     SX_AR_CLASSIFIER_TYPE_DEFAULT_E,
                                                     0,
                                                     classifier_action_p,
                                                     NULL);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in HWD default classification set, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_classification_set(const sx_access_cmd_t            cmd,
                                           const sx_ar_classifier_id_e      classifier_id,
                                           const sx_ar_classifier_attr_t   *attr_p,
                                           const sx_ar_classifier_action_t *action_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_ar_classification_set_pfn == NULL) {
        SX_LOG_ERR("Setting AR default classification is an unsupported operation\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_db_classification_set(cmd, classifier_id, action_p, attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to write AR classifier ID [%u] configuration to DB, error: %s\n",
                   classifier_id, sx_status_str(err));
        goto out;
    }

    err = g_hwd_ar_ops.hwd_ar_classification_set_pfn(cmd,
                                                     SX_AR_CLASSIFIER_TYPE_USER_DEFINED_E,
                                                     classifier_id,
                                                     action_p,
                                                     attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in HWD default classification set, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_classification_get(const sx_ar_classifier_id_e classifier_id,
                                           sx_ar_classifier_attr_t    *attr_p,
                                           sx_ar_classifier_action_t  *action_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_ar_db_classification_get(classifier_id, action_p, attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get AR classifier %s from DB, error: %s\n",
                   sx_ar_classifier_id_str(classifier_id), sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_congestion_threshold_set(const sx_access_cmd_t                    cmd,
                                                 const sx_ar_congestion_threshold_attr_t *congestion_thresh)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_ar_congestion_threshold_set_pfn == NULL) {
        SX_LOG_ERR("Setting AR congestion threshold is an unsupported operation\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_db_congestion_threshold_set(congestion_thresh);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to write AR congestion threshold to DB, error: %s\n", sx_status_str(err));
        goto out;
    }

    err = g_hwd_ar_ops.hwd_ar_congestion_threshold_set_pfn(cmd, congestion_thresh);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in HWD congestion threshold set, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_congestion_threshold_get(sx_ar_congestion_threshold_attr_t *congestion_thresh)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_ar_db_congestion_threshold_get(congestion_thresh);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get AR congestion threshold from DB, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_link_utilization_threshold_set(const sx_access_cmd_t                cmd,
                                                       const sx_port_log_id_t               log_port,
                                                       const sx_ar_link_utilization_attr_t *link_util_attr_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_ar_link_utilization_attr_t link_util_attr;

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_ar_link_utilization_threshold_set_pfn == NULL) {
        SX_LOG_ERR("Setting AR link utilization threshold is an unsupported operation\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (brg_context.spec_cb_g.ar_link_utilization_threshold_set_cb == NULL) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Adaptive routing isn't supported on this HW, err= (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    /*Update threshold in port DB*/
    if (cmd == SX_ACCESS_CMD_SET) {
        err = brg_context.spec_cb_g.ar_link_utilization_threshold_set_cb(log_port, link_util_attr_p);
    } else if (cmd == SX_ACCESS_CMD_UNSET) {
        SX_MEM_CLR(link_util_attr);
        err = brg_context.spec_cb_g.ar_link_utilization_threshold_set_cb(log_port, &link_util_attr);
    }
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to write AR link utilization threshold to port DB, error: %s\n", sx_status_str(err));
        goto out;
    }

    err = g_hwd_ar_ops.hwd_ar_link_utilization_threshold_set_pfn(cmd, log_port, link_util_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in HWD link utilization threshold set, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}
sx_status_t sdk_ar_impl_link_utilization_threshold_get(const sx_port_log_id_t         log_port,
                                                       sx_ar_link_utilization_attr_t *link_util_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (brg_context.spec_cb_g.ar_link_utilization_threshold_get_cb == NULL) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("Adaptive routing isn't supported on this HW, err= (%s).\n",
                   sx_status_str(err));
        goto out;
    }

    err = brg_context.spec_cb_g.ar_link_utilization_threshold_get_cb(log_port, link_util_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve AR link utilization threshold date from port DB, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

void sdk_ar_impl_debug_dump(dbg_dump_params_t *dbg_dump_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    FILE       *stream = NULL;

    err = utils_check_dbg_params(dbg_dump_params_p);
    if (SX_CHECK_FAIL(err)) {
        return;
    }

    stream = dbg_dump_params_p->stream;

    dbg_utils_pprinter_sub_module_header_print(stream, "HWI Adaptive Routing Tables");
    dbg_utils_pprinter_field_print(stream, "Module initialized", &g_hwi_ar_impl_initialized, PARAM_BOOL_E);
    dbg_utils_pprinter_field_print(stream, "ARN module initialized", &g_hwi_arn_impl_initialized, PARAM_BOOL_E);

    dbg_utils_pprinter_print(stream, "\nThe following tables dumps Adaptive Routing general configuration. "
                             "For Adaptive ECMP related configuration refer to Adaptive Routing ECMP Module Tables.\n");

    if (g_hwi_ar_impl_initialized) {
        err = sdk_ar_db_dump(dbg_dump_params_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("sdk_ar_db_dump failed: %s\n", sx_status_str(err));
        }
    }

    if (g_hwi_arn_impl_initialized) {
        err = sdk_ar_arn_db_dump(dbg_dump_params_p);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("sdk_ar_db_dump failed: %s\n", sx_status_str(err));
        }
    }
}

sx_status_t sdk_ar_impl_shaper_rate_set(const sx_access_cmd_t cmd, const sx_ar_shaper_attr_t    *shaper_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_ar_shaper_rate_set_pfn == NULL) {
        SX_LOG_ERR("Setting AR shaper rate is an unsupported operation\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = sdk_ar_db_shaper_rate_set(shaper_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in to write AR shaper rate to DB, error: %s\n", sx_status_str(err));
        goto out;
    }

    err = g_hwd_ar_ops.hwd_ar_shaper_rate_set_pfn(cmd, shaper_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in HWD shaper rate set, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_shaper_rate_get(sx_ar_shaper_attr_t *shaper_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_ar_db_shaper_rate_get(shaper_attr_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get AR shaper rate from DB, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_init_shaper_rate()
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sx_ar_shaper_attr_t shaper_attr;

    SX_LOG_ENTER();
    SX_MEM_CLR(shaper_attr);

    shaper_attr.shaper_rate_from = SHAPER_RATE_VAL;
    shaper_attr.shaper_rate_to = SHAPER_RATE_VAL;

    err = sdk_ar_impl_shaper_rate_set(SX_ACCESS_CMD_SET, &shaper_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in to write AR shaper rate to DB, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_deinit_classification()
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    uint32_t                  classifier_id = 0;
    sx_ar_classifier_action_t action;

    SX_LOG_ENTER();

    SX_MEM_CLR(action);

    action.ar_flow_classification = SX_AR_CLASSIFIER_ACTION_STATIC_E;

    for (classifier_id = SX_AR_CLASSIFIER_INDEX_MIN_E; classifier_id <= SX_AR_CLASSIFIER_INDEX_MAX_E;
         classifier_id++) {
        err = sdk_ar_impl_classification_set(SX_ACCESS_CMD_UNSET, classifier_id, NULL, NULL);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in classifier: %u deinit, error: %s\n",
                       classifier_id, sx_status_str(err));
            goto out;
        }
    }
    err = sdk_ar_impl_default_classification_set(SX_ACCESS_CMD_SET, &action);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in default classifier deinit, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_deinit_profile()
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_ar_profile_key_t  profile_key;
    sx_ar_profile_attr_t profile_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(profile_key);
    SX_MEM_CLR(profile_attr);

    profile_key.profile = SX_AR_PROFILE_0_E;
    profile_attr.mode = SX_AR_PROFILE_MODE_FREE_E;

    err = sdk_ar_impl_profile_set(SX_ACCESS_CMD_SET, &profile_key, &profile_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in profile 0 deinit, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

    profile_key.profile = SX_AR_PROFILE_1_E;
    err = sdk_ar_impl_profile_set(SX_ACCESS_CMD_SET, &profile_key, &profile_attr);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in profile 1 deinit, error: %s\n",
                   sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_deinit_arn_profile()
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_ar_profile_key_t   profile_key;
    sx_arn_profile_attr_t profile_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(profile_key);
    SX_MEM_CLR(profile_attr);

    profile_key.profile = SX_AR_PROFILE_0_E;


    err = sdk_ar_impl_arn_profile_deinit(&profile_key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in arn profile 0 deinit, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

    profile_key.profile = SX_AR_PROFILE_1_E;
    err = sdk_ar_impl_arn_profile_deinit(&profile_key);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in arn profile 1 deinit, error: %s\n",
                   sx_status_str(err));
        goto out;
    }
out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_ar_impl_counters_get(const sx_access_cmd_t cmd, sx_ar_global_counters_t *ar_counters_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_ar_counters_get_pfn == NULL) {
        SX_LOG_ERR("Reading AR counters get is an unsupported operation\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    err = g_hwd_ar_ops.hwd_ar_counters_get_pfn(cmd, ar_counters_p);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in HWD counter get, error: %s\n", sx_status_str(err));
    }
out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_deinit_link_utilization()
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    const sx_access_cmd_t         cmd = SX_ACCESS_CMD_SET;
    sx_ar_link_utilization_attr_t link_utilization_attr;
    sx_port_log_id_t             *log_ports_p = NULL;
    uint32_t                      log_ports_cnt = rm_resource_global.port_lcl_num_max * 2;
    uint32_t                      i = 0;
    sx_port_info_t                port_info;

    SX_LOG_ENTER();

    log_ports_p = (sx_port_log_id_t*)cl_calloc(log_ports_cnt, sizeof(sx_port_log_id_t));
    if (!log_ports_p) {
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    if (SX_CHECK_FAIL(err = port_db_swid_get(rm_resource_global.swid_id_max,
                                             log_ports_p,
                                             &log_ports_cnt))) {
        SX_LOG_ERR("port_swid_get failed. Swid:%d  err=(%s)\n",
                   rm_resource_global.swid_id_max, sx_status_str(err));
        goto out;
    }

    link_utilization_attr.link_utilization_threshold = 0;
    for (i = 0; i < log_ports_cnt; i++) {
        SX_MEM_CLR(port_info);
        if (SX_CHECK_FAIL(err = port_db_info_get(log_ports_p[i], &port_info))) {
            SX_LOG_ERR("port_db_info_get failed. port: [0x%x] err=(%s)\n",
                       log_ports_p[i], sx_status_str(err));
            goto out;
        }

        if (port_info.ar_link_utilization.link_utilization_threshold) {
            if (SX_CHECK_FAIL(err = sdk_ar_be_link_utilization_threshold_set(cmd,
                                                                             log_ports_p[i],
                                                                             &link_utilization_attr))) {
                SX_LOG_ERR(
                    "sdk_ar_be_link_utilization_threshold_set failed. port: [0x%x] link_utilization_attr: [%d] err=(%s)\n",
                    log_ports_p[i],
                    link_utilization_attr.link_utilization_threshold,
                    sx_status_str(err));
                goto out;
            }
        }
    }


out:
    if (log_ports_p != NULL) {
        CL_FREE_N_NULL(log_ports_p);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_init_congestion_threshold()
{
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sx_ar_congestion_threshold_attr_t congestion_thresh;

    SX_LOG_ENTER();

    SX_MEM_CLR(congestion_thresh);

    congestion_thresh.port_threshold.congestion_thresh_lo = AR_CONGESTION_THRESHOLD_DEFAULT_LOW;
    congestion_thresh.port_threshold.congestion_thresh_med = AR_CONGESTION_THRESHOLD_DEFAULT_MEDIUM;
    congestion_thresh.port_threshold.congestion_thresh_hi = AR_CONGESTION_THRESHOLD_DEFAULT_HIGH;

    err = sdk_ar_impl_congestion_threshold_set(SX_ACCESS_CMD_SET, &congestion_thresh);
    SX_CHECK_RC_OUT_ERR(err, "Failed to init congestion threshold");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_port_buffer_mode_get(sx_ar_buffer_mode_e *port_buffer_mode_p)
{
    sx_status_t         err = SX_STATUS_SUCCESS;
    sx_ar_init_params_t init_params;

    SX_LOG_ENTER();

    SX_MEM_CLR(init_params);

    err = sdk_ar_db_init_params_get(&init_params);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get AR init params");

    *port_buffer_mode_p = init_params.buffer_mode;

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_port_counters_get(const sx_access_cmd_t   cmd,
                                              const sx_port_log_id_t  log_port,
                                              sx_arn_port_counters_t *port_counters_p)
{
    sx_status_t            err = SX_STATUS_SUCCESS;
    sx_port_id_t           port_list[MAX_LAG_MEMBERS_NUM];
    uint32_t               port_num = 0;
    uint32_t               iii = 0;
    sx_arn_port_counters_t port_counters = {0};

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_arn_port_counters_get_pfn == NULL) {
        SX_LOG_ERR("Reading ARN Port counters get is an unsupported operation\n");
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    /* If the port is LAG we get the sum of all ports' counters */
    if (IS_LAG_OR_VLAG(log_port)) {
        port_num = MAX_LAG_MEMBERS_NUM;
        err = sx_lag_port_group_get(log_port, port_list, &port_num);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve ports of LAG [0x%08X] for ARN port counters\n", log_port);
            goto out;
        }
    } else {
        port_list[0] = log_port;
        port_num = 1;
    }

    SX_MEM_CLR_P(port_counters_p);
    for (iii = 0; iii < port_num; iii++) {
        err = g_hwd_ar_ops.hwd_arn_port_counters_get_pfn(cmd, port_list[iii], &port_counters);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in HWD port counter get, error: %s\n", sx_status_str(err));
            goto out;
        }
        port_counters_p->arn_port_tx += port_counters.arn_port_tx;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_counters_get(const sx_access_cmd_t cmd, sx_arn_counters_t *arn_counters)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_flow_counter_set_t     cntr_val;
    sx_arn_counters_indices_t counters_indices;

    SX_LOG_ENTER();

    SX_MEM_CLR(counters_indices);
    err = sdk_ar_db_arn_counters_indices_get(&counters_indices);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN counters indices");

    if (counters_indices.arn_rcv_drop_index != SX_FLOW_COUNTER_ID_INVALID) {
        SX_MEM_CLR(cntr_val);
        err = flow_counter_get(counters_indices.arn_rcv_drop_index, &cntr_val);
        SX_CHECK_RC_OUT_ERR(err, "Failed to read ARN receive drop counter");
        arn_counters->arn_rcv_drop = cntr_val.flow_counter_packets;
    }

    if (counters_indices.arn_rcv_ok_index != SX_FLOW_COUNTER_ID_INVALID) {
        SX_MEM_CLR(cntr_val);
        err = flow_counter_get(counters_indices.arn_rcv_ok_index, &cntr_val);
        SX_CHECK_RC_OUT_ERR(err, "Failed to read ARN receive ok counter");
        arn_counters->arn_rcv_ok = cntr_val.flow_counter_packets;
    }

    if (counters_indices.gen_drop_ip_miss_index != SX_FLOW_COUNTER_ID_INVALID) {
        SX_MEM_CLR(cntr_val);
        err = flow_counter_get(counters_indices.gen_drop_ip_miss_index, &cntr_val);
        SX_CHECK_RC_OUT_ERR(err, "Failed to read ARN IP miss counter");
        arn_counters->gen_drop_ip_miss = cntr_val.flow_counter_packets;
    }

    if (counters_indices.gen_drop_no_nexthop_index != SX_FLOW_COUNTER_ID_INVALID) {
        SX_MEM_CLR(cntr_val);
        err = flow_counter_get(counters_indices.gen_drop_no_nexthop_index, &cntr_val);
        SX_CHECK_RC_OUT_ERR(err, "Failed to read ARN drop no nexthop counter");
        arn_counters->gen_drop_no_nexthop = cntr_val.flow_counter_packets;
    }

    if (cmd == SX_ACCESS_CMD_READ_CLEAR) {
        if (counters_indices.arn_rcv_drop_index != SX_FLOW_COUNTER_ID_INVALID) {
            err = flow_counter_clear(counters_indices.arn_rcv_drop_index);
            SX_CHECK_RC_OUT_ERR(err, "Failed to clear ARN receive drop counter");
        }
        if (counters_indices.arn_rcv_ok_index != SX_FLOW_COUNTER_ID_INVALID) {
            err = flow_counter_clear(counters_indices.arn_rcv_ok_index);
            SX_CHECK_RC_OUT_ERR(err, "Failed to clear ARN receive ok counter");
        }

        if (counters_indices.gen_drop_ip_miss_index != SX_FLOW_COUNTER_ID_INVALID) {
            err = flow_counter_clear(counters_indices.gen_drop_ip_miss_index);
            SX_CHECK_RC_OUT_ERR(err, "Failed to clear ARN IP miss counter");
        }

        if (counters_indices.gen_drop_no_nexthop_index != SX_FLOW_COUNTER_ID_INVALID) {
            err = flow_counter_clear(counters_indices.gen_drop_no_nexthop_index);
            SX_CHECK_RC_OUT_ERR(err, "Failed to clear ARN drop no nexthop counter");
        }
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_flow_status_get(sx_arn_flow_status_key_t  *flow_status_key_p,
                                            sx_arn_flow_status_data_t *flow_status_data_p)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sx_ecmp_id_t ecmp_id = 0;
    uint16_t     num_rec = 0;
    uint16_t     actual_num_rec = 0;
    uint32_t     arft_index = 0;
    uint32_t     table_base_index = 0;


    SX_LOG_ENTER();

    if (flow_status_key_p->type != SX_ARN_FLOW_STATUS_KEY_ECMP_E) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported key type [%u]\n", flow_status_key_p->type);
        goto out;
    }

    if ((flow_status_key_p->key.ecmp_key.profile_id > SX_AR_PROFILE_1_E) ||
        (flow_status_key_p->key.ecmp_key.profile_id < SX_AR_PROFILE_0_E)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unsupported profile ID [%u].\n", flow_status_key_p->key.ecmp_key.profile_id);
        goto out;
    }


    ecmp_id = flow_status_key_p->key.ecmp_key.ecmp_id;
    err = sdk_router_ecmp_impl_get_arft_size_and_index(ecmp_id, &num_rec, &arft_index);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to read AR flow table index and size, error: %s\n", sx_status_str(err));
        goto out;
    }
    /*ARFT is divided to 2 parts. First part is for AR profile 0,second - for profile 1.
     * Each part is the size of the ECMP container.
     * arft_index is the index of HW table that holds (rm_resource_global.router_cap_max_arft_entries_in_row) entries in a row
     */
    table_base_index = arft_index + (num_rec / rm_resource_global.router_cap_max_arft_entries_in_row) *
                       (flow_status_key_p->key.ecmp_key.profile_id - 1);
    err = hwd_ar_flow_table_read(flow_status_data_p->flow_status_list_p,
                                 table_base_index, num_rec, &actual_num_rec);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to read AR flow table, error: %s\n", sx_status_str(err));
        goto out;
    }
    flow_status_data_p->flow_status_cnt = actual_num_rec;

out:
    SX_LOG_EXIT();
    return err;
}


sx_status_t sdk_ar_impl_arn_general_params_get(sx_arn_general_params_t *arn_general_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_CHECK_NULL_OUT(arn_general_params_p, err, "ARN general params get failed");

    err = sdk_ar_db_arn_general_params_get(arn_general_params_p);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN general params from DB");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_router_attr_get(sx_arn_router_key_t        *arn_router_key_p,
                                            sx_arn_router_attributes_t *arn_router_attributes_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    SX_CHECK_NULL_OUT(arn_router_key_p, err, "ARN router attr get failed - NULL key");
    SX_CHECK_NULL_OUT(arn_router_attributes_p, err, "ARN router attr get failed - NULL attributes");

    err = sdk_ar_db_arn_router_attr_get(arn_router_key_p, arn_router_attributes_p);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN router attr from DB");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_defaults_set(const sx_access_cmd_t cmd, const sx_arn_default_params_t *default_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        err = sdk_ar_db_arn_default_params_set(default_params_p);
        SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN defaults.");
        break;

    case SX_ACCESS_CMD_UNSET:
        err = sdk_ar_db_arn_default_params_reset();
        SX_CHECK_RC_OUT_ERR(err, "Failed to reset ARN defaults.");
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_params_hwd_set(void)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_arn_default_params_t   arn_default_params;
    sx_arn_general_params_t   arn_general_params;
    sx_arn_counters_indices_t counters_indices;

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_arn_params_set_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_CHECK_RC_OUT_ERR(err, "ARN defaults set is unsupported.");
    }

    SX_MEM_CLR(arn_default_params);
    SX_MEM_CLR(arn_general_params);
    SX_MEM_CLR(counters_indices);

    err = sdk_ar_db_arn_default_params_get(&arn_default_params);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN defaults.");

    err = sdk_ar_db_arn_general_params_get(&arn_general_params);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN general params.");

    err = sdk_ar_db_arn_counters_indices_get(&counters_indices);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN flow counters.");

    err = g_hwd_ar_ops.hwd_arn_params_set_pfn(&arn_default_params,
                                              &arn_general_params,
                                              &counters_indices);
    SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN defaults to FW.");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_issu_end(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (FALSE == sdk_ar_impl_is_module_initialized()) {
        goto out;
    }

    if (FALSE == sdk_arn_impl_is_module_initialized()) {
        goto out;
    }

    err = sdk_ar_impl_arn_params_hwd_set();
    SX_CHECK_RC_OUT_ERR(err, "ARN ISSU end failed writing parameters to FW.");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_defaults_get(sx_arn_default_params_t *default_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_ar_db_arn_default_params_get(default_params_p);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN defaults.");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_ar_port_consume_params_set(const sx_access_cmd_t  cmd,
                                                       const sx_port_log_id_t log_port,
                                                       const sx_mac_addr_t    mac_addr)
{
    sx_status_t  err = SX_STATUS_SUCCESS;
    sx_port_id_t port_list[MAX_LAG_MEMBERS_NUM];
    uint32_t     port_num = 0;
    uint32_t     iii = 0;


    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_arn_ar_port_params_set_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_CHECK_RC_OUT_ERR(err, "ARN AR port parameters set is unsupported.");
    }

    /* For the HWD we configure the network port and not the LAG so we get the port from the LAG */
    if (IS_LAG_OR_VLAG(log_port)) {
        port_num = MAX_LAG_MEMBERS_NUM;
        err = sx_lag_port_group_get(log_port, port_list, &port_num);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve ports of LAG [0x%08X] for ARN port gen params \n", log_port);
            goto out;
        }
    } else {
        port_list[0] = log_port;
        port_num = 1;
    }

    for (iii = 0; iii < port_num; iii++) {
        err = g_hwd_ar_ops.hwd_arn_ar_port_params_set_pfn(cmd,
                                                          port_list[iii],
                                                          mac_addr,
                                                          HWD_ARN_PORT_CONF_TYPE_CONSUMPTION_E);
        SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN AR port consumption parameters.");
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __hwi_arn_counter_relocate_cb(const cm_logical_id_t lid,
                                                 const uint32_t        offset,
                                                 const cm_type_e       type,
                                                 const cm_hw_type_t    hw_type,
                                                 const cm_index_t      old_index,
                                                 const cm_index_t      new_index)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    /* This callback should return an error only if relocation of counter fails.
     *  Error stops bin allocator from relocating  all counters for all users.
     *  Check of relocation callback is done in init*/

    if (g_hwd_ar_ops.hwd_arn_counter_relocate_pfn != NULL) {
        err = g_hwd_ar_ops.hwd_arn_counter_relocate_pfn(lid, offset, type, hw_type, old_index, new_index);
        SX_CHECK_RC_OUT_ERR(err, "Failed to relocate ARN counters.");
    }


out:
    SX_LOG_EXIT();
    return err;
}
sx_status_t sdk_ar_impl_arn_ar_port_gen_params_set(const sx_access_cmd_t cmd, const sx_port_log_id_t log_port)
{
    sx_status_t   err = SX_STATUS_SUCCESS;
    sx_mac_addr_t mac_addr;
    sx_port_id_t  port_list[MAX_LAG_MEMBERS_NUM];
    uint32_t      port_num = 0;
    uint32_t      iii = 0;

    SX_LOG_ENTER();

    SX_MEM_CLR(mac_addr);

    if (g_hwd_ar_ops.hwd_arn_ar_port_params_set_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_CHECK_RC_OUT_ERR(err, "ARN AR port parameters set is unsupported.");
    }

    /* For the HWD we configure the network port and not the LAG so we get the port from the LAG */
    if (IS_LAG_OR_VLAG(log_port)) {
        port_num = MAX_LAG_MEMBERS_NUM;
        err = sx_lag_port_group_get(log_port, port_list, &port_num);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve ports of LAG [0x%08X] for ARN port gen params \n", log_port);
            goto out;
        }
    } else {
        port_list[0] = log_port;
        port_num = 1;
    }

    for (iii = 0; iii < port_num; iii++) {
        if (cmd == SX_ACCESS_CMD_SET) {
            if (!IS_NETWORK_PORT(log_port)) {
                err = SX_STATUS_PARAM_ERROR;
                SX_LOG_ERR("Log port [0x%08X] is not a network port . err=[%s]\n",
                           log_port, sx_status_str(err));
            }
        }
        err = g_hwd_ar_ops.hwd_arn_ar_port_params_set_pfn(cmd,
                                                          port_list[iii],
                                                          mac_addr,
                                                          HWD_ARN_PORT_CONF_TYPE_GENERATION_E);
        SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN AR port generation parameters.");
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_router_gen_set(const sx_access_cmd_t             cmd,
                                           const sx_arn_router_key_t        *router_key_p,
                                           const sx_arn_router_attributes_t *router_attr_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_router_loopback_arn_attr_t rif_loopback_attr;
    sx_arn_general_params_t       arn_general_params;
    sx_arn_router_attributes_t    router_attr;

    SX_LOG_ENTER();

    SX_MEM_CLR(router_attr);
    SX_MEM_CLR(rif_loopback_attr);

    /* Check if there are remote UC routes configured on this VRID.
    * If there are, ARN generation configuration is not allowed. */
    err = sdk_router_vrid_impl_check_uc_route_refcnt_zero(router_key_p->vrid);
    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to set ARN generation on VRID %d - existing UC routes on this VRID.\n",
                   router_key_p->vrid);
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_SET:
        if (sdk_ar_db_arn_router_attr_map_count() == 1) {
            err = SX_STATUS_ERROR;
            SX_LOG_ERR("Failed to set ARN generation on VRID %d - ARN generation is permitted only on "
                       "single VRID on the system.\n",
                       router_key_p->vrid);
            goto out;
        }

        /* Save router attributes parameters in the DB.
         * ARN generation components (ARN lists per ECMP) will be set to HW (per ECMP) only after the
         * first UC route will be added to the given VRID.*/
        err = sdk_ar_db_arn_router_attr_set(router_key_p, router_attr_p);
        SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN router generation attributes.");

        err = sdk_ar_db_arn_general_params_get(&arn_general_params);
        SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN general params.");

        SX_MEM_CPY(rif_loopback_attr.source_ip, arn_general_params.source_ip);

        err = sdk_rif_impl_arn_attach_set(SX_ACCESS_CMD_ADD,
                                          router_attr_p->erif,
                                          &rif_loopback_attr);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed attach ARN attributes to loopback RIF. Command: ADD, RIF: %u",
                       router_attr_p->erif);
        }
        break;

    case SX_ACCESS_CMD_UNSET:
        err = sdk_ar_db_arn_router_attr_get(router_key_p, &router_attr);
        SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN router generation attributes.");

        err = sdk_rif_impl_arn_attach_set(SX_ACCESS_CMD_DELETE,
                                          router_attr.erif,
                                          &rif_loopback_attr);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed attach ARN attributes to loopback RIF. Command: DELETE, RIF: %u",
                       router_attr.erif);
        }

        /* ARN lists already been removed since there are no UC routes configured on this VRID.
         * Can remove ARN router attributes from the DB. */
        err = sdk_ar_db_arn_router_attr_delete(router_key_p);
        SX_CHECK_RC_OUT_ERR(err, "Failed to delete ARN router generation attributes for VRID.");
        break;

    default:
        SX_LOG_ERR("Unsupported command %s given.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_router_gen_get(const sx_arn_router_key_t  *router_key_p,
                                           sx_arn_router_attributes_t *router_attr_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_ar_db_arn_router_attr_get(router_key_p, router_attr_p);
    SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN router generation attributes.");

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_impl_arn_deinit_router_generation(void)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (sdk_ar_db_check_arn_router_attr_map_empty() == FALSE) {
        err = SX_STATUS_ERROR;
        SX_LOG_ERR("ARN deinit failed - ARN generation is not disabled on all VRIDs, error: %s\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_get(sx_arn_general_params_t *general_params_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    err = sdk_ar_db_arn_general_params_get(general_params_p);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN general params.");

out:
    SX_LOG_EXIT();
    return err;
}

sx_status_t sdk_ar_impl_arn_set(const sx_access_cmd_t cmd, const sx_arn_general_params_t *general_params_p)
{
    sx_status_t    err = SX_STATUS_SUCCESS;
    sx_boot_mode_e boot_mode = SX_BOOT_MODE_DISABLED_E;

    SX_LOG_ENTER();

    if (cmd == SX_ACCESS_CMD_SET) {
        err = sdk_ar_impl_arn_init();
        SX_CHECK_RC_OUT_ERR(err, "Failed to init ARN module.");
    }

    /*These 3 functions only updating the ARN DB.
     * We are downloading the data to the FW using sdk_ar_impl_arn_params_hwd_set function.*/
    err = __sdk_ar_impl_arn_general_params_set(cmd, general_params_p);
    SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN general params.");

    /* This call will set the flow counters for ARN use*/
    err = __sdk_ar_impl_arn_counters_set(cmd);
    SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN flow counters.");

    err = sdk_ar_impl_arn_defaults_set(SX_ACCESS_CMD_UNSET, NULL);
    SX_CHECK_RC_OUT_ERR(err, "ARN parameters init failed.");

    if (cmd == SX_ACCESS_CMD_SET) {
        err = utils_boot_mode_get(&boot_mode);
        SX_CHECK_RC_OUT_ERR(err, "Failed to get utils boot mode.");

        /* On ISSU mode we will send the default params on ISSU end*/
        if (boot_mode != SX_BOOT_MODE_ISSU_STARTED_E) {
            err = sdk_ar_impl_arn_params_hwd_set();
            SX_CHECK_RC_OUT_ERR(err, "ARN parameters init failed writing to FW.");
        }
    }

    /* This function iterates over all system ports and configures ARN generation ingress port.*/
    err = __sdk_ar_impl_arn_port_generation_ingress_set(cmd);
    SX_CHECK_RC_OUT_ERR(err, "Failed to enable ARN port generation ingress.");

    /* This function configures consumption parameters on all AR RIFs'*/
    err = sdk_rif_impl_arn_port_consume_params_set(cmd);
    SX_CHECK_RC_OUT_ERR(err, "Failed to enable ARN consume ports.");

    /* This function configures generation parameters on all AR RIFs'*/
    err = sdk_rif_impl_arn_port_gen_params_set(cmd);
    SX_CHECK_RC_OUT_ERR(err, "Failed to enable ARN generation on AR ports.");

    if (cmd == SX_ACCESS_CMD_UNSET) {
        err = sdk_ar_impl_arn_deinit();
        SX_CHECK_RC_OUT_ERR(err, "Failed to deinit ARN module.");
    }

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_impl_arn_counters_set(const sx_access_cmd_t cmd)
{
    sx_status_t               err = SX_STATUS_SUCCESS;
    sx_access_cmd_t           flow_counter_cmd = SX_ACCESS_CMD_CREATE;
    sx_arn_counters_indices_t counters_indices;

    SX_LOG_ENTER();

    SX_MEM_CLR(counters_indices);

    if (cmd == SX_ACCESS_CMD_UNSET) {
        err = sdk_ar_db_arn_counters_indices_get(&counters_indices);
        SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN counters indices");

        flow_counter_cmd = SX_ACCESS_CMD_DESTROY;
    }

    err = flow_counter_set(flow_counter_cmd, SX_FLOW_COUNTER_TYPE_PACKETS, &counters_indices.arn_rcv_drop_index);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN receive drop counter index");

    err = flow_counter_set(flow_counter_cmd, SX_FLOW_COUNTER_TYPE_PACKETS, &counters_indices.arn_rcv_ok_index);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN receive ok counter index");

    err = flow_counter_set(flow_counter_cmd, SX_FLOW_COUNTER_TYPE_PACKETS, &counters_indices.gen_drop_ip_miss_index);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN drop IP miss counter index");

    err =
        flow_counter_set(flow_counter_cmd, SX_FLOW_COUNTER_TYPE_PACKETS, &counters_indices.gen_drop_no_nexthop_index);
    SX_CHECK_RC_OUT_ERR(err, "Failed to get ARN drop no nexthop counter index");

    if (cmd == SX_ACCESS_CMD_UNSET) {
        SX_MEM_CLR(counters_indices);
    }

    err = sdk_ar_db_arn_counters_indices_set(&counters_indices);
    SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN counters indices");

out:
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_impl_arn_port_generation_ingress_set(const sx_access_cmd_t cmd)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_device_info_t      device_list_arr[SX_DEV_ID_MAX];
    uint32_t              device_index = 0, dev_num = 0, port_index = 0, port_num = 0;
    sx_device_id_t        device_id = 1;
    sx_swid_id_t          swid = 0;
    sx_port_attributes_t *port_attributes_p = NULL;
    sx_swid_type_t        swid_type = SX_SWID_TYPE_DISABLED;

    SX_LOG_ENTER();

    if (g_hwd_ar_ops.hwd_arn_system_port_param_set_pfn == NULL) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_CHECK_RC_OUT_ERR(err, "ARN set is unsupported.");
    }

    dev_num = SX_DEV_ID_MAX;
    err = port_device_list_get(SX_ACCESS_CMD_GET, device_list_arr, &dev_num);
    SX_CHECK_RC_OUT_ERR(err, "Failed to retrieve device info");

    for (device_index = 0; device_index < dev_num; device_index++) {
        device_id = device_list_arr[device_index].dev_id;

        /*get device's number of ports*/
        err = port_device_get(SX_ACCESS_CMD_COUNT, device_id, swid, NULL, &port_num);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve number of ports on device: (%u)"
                       "and swid: (%u). Error: (%s).\n",
                       device_id, swid, sx_status_str(err));
            goto out;
        }

        if (port_num == 0) {
            continue;
        }

        port_attributes_p = (sx_port_attributes_t*)cl_malloc(port_num * sizeof(sx_port_attributes_t));
        if (port_attributes_p == NULL) {
            err = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Failed in memory allocation (%s).\n", sx_status_str(err));
            goto out;
        }

        /*Get device logical ports list*/
        err = port_device_get(SX_ACCESS_CMD_GET, device_id, swid, port_attributes_p, &port_num);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve ports info on device (%u) and swid (%u). Error: (%s).\n",
                       device_id, swid, sx_status_str(err));
            goto out;
        }

        err = port_swid_type_get(swid, &swid_type);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to retrieve SWID (%u) type, Error: (%s).\n",
                       swid, sx_status_str(err));
            goto out;
        }

        if (swid_type != SX_SWID_TYPE_ETHERNET) {
            if (port_attributes_p) {
                CL_FREE_N_NULL(port_attributes_p);
            }
            continue;
        }

        for (port_index = 0; port_index < port_num; port_index++) {
            if (IS_PORT_TYPE_NETWORK(port_attributes_p[port_index].log_port) == FALSE) {
                continue;
            }

            err = g_hwd_ar_ops.hwd_arn_system_port_param_set_pfn(cmd, port_attributes_p[port_index].log_port);
            SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN port generation parameters.");
        }
    }

out:
    if (port_attributes_p) {
        CL_FREE_N_NULL(port_attributes_p);
    }
    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sdk_ar_impl_arn_general_params_set(const sx_access_cmd_t          cmd,
                                                        const sx_arn_general_params_t *general_params_p)
{
    sx_status_t             err = SX_STATUS_SUCCESS;
    sx_arn_general_params_t general_params;

    SX_LOG_ENTER();

    if (cmd == SX_ACCESS_CMD_UNSET) {
        SX_MEM_CLR(general_params);
    } else {
        SX_MEM_CPY(general_params, *general_params_p);
    }

    err = sdk_ar_db_arn_general_params_set(&general_params);
    SX_CHECK_RC_OUT_ERR(err, "Failed to set ARN general params.");

out:
    SX_LOG_EXIT();
    return err;
}
