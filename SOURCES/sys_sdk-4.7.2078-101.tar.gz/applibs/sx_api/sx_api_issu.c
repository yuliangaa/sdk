/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_issu.h>
#include "sx_api_internal.h"
#include <complib/cl_mem.h>
#include <include/resource_manager/resource_manager.h>

#undef  __MODULE__
#define __MODULE__ SX_API_ISSU

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  DEFINES
 ***********************************************/

/************************************************
 *  DECLARATIONS
 ***********************************************/

/************************************************
 *  LOCAL FUNCTIONS
 ***********************************************/

/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_issu_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                const sx_verbosity_level_t      module_verbosity_level,
                                                const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_ISSU_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_issu_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                const sx_log_verbosity_target_t verbosity_target,
                                                sx_verbosity_level_t           *module_verbosity_level_p,
                                                sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_ISSU_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_issu_start_set(const sx_api_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ISSU_START_SET_E,
                                      NULL, 0);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to start ISSU process, error: %s\n", sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_issu_end_set(const sx_api_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_ISSU_END_SET_E,
                                      NULL, 0);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to end ISSU process, error: %s\n", sx_status_str(err));
        goto out;
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_issu_pause_set(const sx_api_handle_t handle, const sx_issu_pause_t *pause_params_p)
{
    sx_api_command_head_t           cmd_head;
    sx_api_command_issu_pause_set_t cmd_body;
    sx_api_reply_head_t             reply_head;
    sx_status_t                     err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    cmd_head.opcode = SX_API_INT_CMD_ISSU_PAUSE_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_command_issu_pause_set_t);

    if (pause_params_p) {
        cmd_body.pause_params = *pause_params_p;
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_issu_resume_set(const sx_api_handle_t handle, const sx_issu_resume_t *resume_params_p)
{
    sx_api_command_head_t            cmd_head;
    sx_api_command_issu_resume_set_t cmd_body;
    sx_api_reply_head_t              reply_head;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    cmd_head.opcode = SX_API_INT_CMD_ISSU_RESUME_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_command_issu_resume_set_t);

    if (resume_params_p) {
        cmd_body.resume_params = *resume_params_p;
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}
