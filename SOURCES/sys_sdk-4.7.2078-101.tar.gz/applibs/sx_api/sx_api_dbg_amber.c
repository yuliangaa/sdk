/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <sx/sxd/sxd_fw_dbg.h>
#include <sx/sxd/cr_access.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/sxd_emad.h>
#include <sx/sxd/sxd_emad_reg.h>
#include <sx/sdk/sx_api_dbg.h>
#include "sx_api_internal.h"
#include "config.h"

/*
 *   AMBER Dump: List of registers to dump
 *   ==========================================================================================================================
 *
 *   PDDR
 *
 *   local_port  [1..max]
 *   port_type   [0..5]
 *   page_select [Operational_Info_Page (0x0),
 *                Troubleshooting_Info_Page (0x1),
 *                Phy_Info_Page (0x2),
 *                Link_Down_Info (0x6),
 *                Link_Up_Info (0x8)]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   PTYS
 *
 *   local_port [1..max]
 *   port_type  [0..3]
 *   proto_mask [0, 2]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   PPCNT
 *
 *   local_port [1..max]
 *   port_type  [0..5]
 *   grp        [Ethernet_Discard_Counters (0x6),
 *               Physical_Layer_Counters (0x12),
 *               Physical_Layer_Statistical_Counters (0x16),
 *               InfiniBand_Port_Counters (0x20),
 *               InfiniBand_Extended_Port_Counters (0x21),
 *               PLR_counters_group (0x22),
 *               RS_FEC_Histogram_group (0x23),
 *               InfiniBand_pkts_counters (0x25)]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   MTMP
 *
 *   slot_index   [0]
 *   i            [0..1]
 *   sensor_index [64..127, 256..263]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   SLRG
 *
 *   local_port [1..max]
 *   port_type  [0..5]
 *   lane       [0..15]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   SLTP
 *
 *   local_port [1..max]
 *   port_type  [0..3]
 *   lane       [0..15]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   SLRIP
 *
 *   * Implemented manually only in driver, will use RAW register
 *   * Temporarily disabled as it always returns INVALID_PARAM
 *
 *   local_port [1..max]
 *   port_type  [0..5]
 *   lane       [0..15]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   SLRP
 *
 *   * Implemented manually only in driver, will use RAW register
 *   * Temporarily disabled as it always returns INVALID_PARAM
 *
 *   local_port [1..max]
 *   port_type  [0..5]
 *   lane       [0..15]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   PPLL    ppl_group [1..3]
 *
 *   * Implemented manually only in driver, will use RAW register
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   PPHCR
 *
 *   hist_type  [0]
 *   local_port [1..max]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   MPEIN
 *
 *   * Does not exist in ADABE and not implemented in FW
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   MPCNT
 *
 *   * Does not exist in ADABE and not implemented in FW
 *
 *   grp [PCIE_Performance_Counters (0x0),
 *        PCIE_Lane_Counters (0x1),
 *        PCIE_Timers_and_States (0x2)]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   MVCR
 *
 *   slot_index   [0]
 *   sensor_index [64..127, 256..263]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   SLSIR
 *
 *   * Currently not implemented in FW
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   SLLM
 *
 *   local_port [1..max]
 *   port_type  [0..5]
 *   lane       [0..15]
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   PMPT
 *
 *   * Currently not implemented in FW
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 *
 *   PMPD
 *
 *   * Currently not implemented in FW
 *
 *   --------------------------------------------------------------------------------------------------------------------------
 */

#undef  __MODULE__
#define __MODULE__ SX_API_DBG_AMBER
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

#define AMBER_EMAD_TIMEOUT_USEC (5000000) /* 5 sec */

#define FOR_EACH_LOCAL_PORT_START(reg, local_ports_arr, local_ports_arr_size) \
    do {                                                                      \
        uint32_t idx;                                                         \
                                                                              \
        for (idx = 0; idx < (local_ports_arr_size); idx++) {                  \
            SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID((reg)->local_port, (reg)->lp_msb, (local_ports_arr)[idx]);

#define FOR_EACH_LOCAL_PORT_END \
}                               \
}while (0);

#define SXD_ACCESS_REG(reg_name, reg, meta)                            \
    do {                                                               \
        typeof(*(reg)) tmp = *reg;                                     \
        sxd_status_t rc;                                               \
        rc = sxd_access_reg_ ## reg_name(&tmp, (meta), 1, NULL, NULL); \
        if (rc == SXD_STATUS_TIMEOUT) {                                \
            return FALSE;                                              \
        }                                                              \
    } while (0)

#define SXD_ACCESS_REG_RAW(reg_id, reg, meta)                           \
    do {                                                                \
        struct ku_raw_reg tmp = *reg;                                   \
        sxd_status_t rc;                                                \
        rc = sxd_access_reg_raw(&tmp, (meta), 1, (reg_id), NULL, NULL); \
        if (rc == SXD_STATUS_TIMEOUT) {                                 \
            return FALSE;                                               \
        }                                                               \
    } while (0)

static sxd_status_t __get_chip_max_ports(sxd_chip_types_t chip_type, uint32_t *max_ports)
{
    sxd_status_t sxd_rc = SXD_STATUS_SUCCESS;

    switch (chip_type) {
    case SXD_CHIP_TYPE_SPECTRUM:
    case SXD_CHIP_TYPE_SPECTRUM_A1:
        *max_ports = 64;
        break;

    case SXD_CHIP_TYPE_SPECTRUM2:
    case SXD_CHIP_TYPE_SPECTRUM3:
        *max_ports = 128;
        break;

    case SXD_CHIP_TYPE_SPECTRUM4:
    case SXD_CHIP_TYPE_SPECTRUM5:
        *max_ports = 256;
        break;

    case SXD_CHIP_TYPE_QUANTUM:
        *max_ports = 80;
        break;

    case SXD_CHIP_TYPE_QUANTUM2:
        *max_ports = 128;
        break;

    case SXD_CHIP_TYPE_QUANTUM3:
        *max_ports = 144;
        break;

    default:
        sxd_rc = SXD_STATUS_PARAM_ERROR;
        break;
    }

    return sxd_rc;
}

static void __init_meta_and_reg(sxd_dev_id_t dev_id, sxd_reg_meta_t *meta, void *reg, uint32_t reg_size)
{
    memset(meta, 0, sizeof(*meta));
    memset(reg, 0, reg_size);

    meta->dev_id = dev_id;
    meta->access_cmd = SXD_ACCESS_CMD_GET;
}

static boolean_t __dump_pddr(sxd_dev_id_t dev_id, const uint32_t *local_ports_arr, uint32_t local_ports_arr_size)
{
    struct ku_pddr_reg reg;
    sxd_reg_meta_t meta;
    uint8_t page_select_arr[] = { 0, 1, 2, 6, 8 };
    uint8_t page_select_arr_size = sizeof(page_select_arr) / sizeof(page_select_arr[0]);
    int i;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    FOR_EACH_LOCAL_PORT_START(&reg, local_ports_arr, local_ports_arr_size)
    for (reg.port_type = 0; reg.port_type <= 5; reg.port_type++) {
        for (i = 0; i < page_select_arr_size; i++) {
            reg.page_select = page_select_arr[i];

            SXD_ACCESS_REG(pddr, &reg, &meta);
        }
    }
    FOR_EACH_LOCAL_PORT_END;

    return TRUE;
}

static boolean_t __dump_ptys(sxd_dev_id_t dev_id, const uint32_t *local_ports_arr, uint32_t local_ports_arr_size)
{
    struct ku_ptys_reg reg;
    sxd_reg_meta_t meta;
    uint8_t proto_mask_arr[] = { 0, 2 };
    uint8_t proto_mask_arr_size = sizeof(proto_mask_arr) / sizeof(proto_mask_arr[0]);
    int i;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    FOR_EACH_LOCAL_PORT_START(&reg, local_ports_arr, local_ports_arr_size)
    for (reg.port_type = 0; reg.port_type <= 3; reg.port_type++) {
        for (i = 0; i < proto_mask_arr_size; i++) {
            reg.proto_mask = proto_mask_arr[i];

            SXD_ACCESS_REG(ptys, &reg, &meta);
        }
    }
    FOR_EACH_LOCAL_PORT_END;

    return TRUE;
}

static boolean_t __dump_ppcnt(sxd_dev_id_t     dev_id,
                              sxd_chip_types_t chip_type,
                              const uint32_t  *local_ports_arr,
                              uint32_t         local_ports_arr_size)
{
    static const uint8_t eth_grp_arr[] = { 0x6,  0x12, 0x16, 0x22, 0x23 };
    static const uint8_t ib_grp_arr[] = { 0x12, 0x16, 0x20, 0x21, 0x22, 0x23, 0x25 };
    static const uint8_t port_type_arr[] = { 2 /* MUST BE FIRST! */, 4, 5 };
    struct ku_ppcnt_reg reg;
    sxd_reg_meta_t meta;
    const uint8_t *grp_arr = NULL;
    uint8_t grp_arr_size = 0;
    uint8_t port_type_arr_size = 0;
    int grp_idx, port_type_idx;

    switch (chip_type) {
    case SXD_CHIP_TYPE_SPECTRUM:
    case SXD_CHIP_TYPE_SPECTRUM_A1:
    case SXD_CHIP_TYPE_SPECTRUM2:
        grp_arr = eth_grp_arr;
        grp_arr_size = sizeof(eth_grp_arr) / sizeof(eth_grp_arr[0]);
        port_type_arr_size = 1; /* only port_type=2 is valid */
        break;

    case SXD_CHIP_TYPE_SPECTRUM3:
    case SXD_CHIP_TYPE_SPECTRUM4:
    case SXD_CHIP_TYPE_SPECTRUM5:
        grp_arr = eth_grp_arr;
        grp_arr_size = sizeof(eth_grp_arr) / sizeof(eth_grp_arr[0]);
        port_type_arr_size = sizeof(port_type_arr) / sizeof(port_type_arr[0]);
        break;

    case SXD_CHIP_TYPE_QUANTUM:
    case SXD_CHIP_TYPE_QUANTUM2:
    case SXD_CHIP_TYPE_QUANTUM3:
        grp_arr = ib_grp_arr;
        grp_arr_size = sizeof(ib_grp_arr) / sizeof(ib_grp_arr[0]);
        port_type_arr_size = 1; /* only port_type=2 is valid */
        break;

    default:
        return TRUE; /* we have nothing to do here */
    }

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    FOR_EACH_LOCAL_PORT_START(&reg, local_ports_arr, local_ports_arr_size)
    for (port_type_idx = 0; port_type_idx < port_type_arr_size; port_type_idx++) {
        for (grp_idx = 0; grp_idx < grp_arr_size; grp_idx++) {
            reg.port_type = port_type_arr[port_type_idx];
            reg.grp = grp_arr[grp_idx];
            if (reg.local_port == 255) {
                reg.lp_gl = 1; /*       lp_gl = 0 will get all local ports */
            }
            SXD_ACCESS_REG(ppcnt, &reg, &meta);
            if (reg.local_port == 255) {
                reg.lp_gl = 0;
            }
        }
    }
    FOR_EACH_LOCAL_PORT_END;

    return TRUE;
}

static boolean_t __dump_mtmp(sxd_dev_id_t dev_id)
{
    struct ku_mtmp_reg reg;
    sxd_reg_meta_t meta;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    for (reg.i = 0; reg.i <= 1; reg.i++) {
        for (reg.sensor_index = 64; reg.sensor_index <= 127; reg.sensor_index++) {
            SXD_ACCESS_REG(mtmp, &reg, &meta);
        }
        for (reg.sensor_index = 256; reg.sensor_index <= 263; reg.sensor_index++) {
            SXD_ACCESS_REG(mtmp, &reg, &meta);
        }
    }

    return TRUE;
}

static boolean_t __dump_slrg(sxd_dev_id_t dev_id, const uint32_t *local_ports_arr, uint32_t local_ports_arr_size)
{
    uint8_t slrg_reg[40] = { 0 };
    uint8_t *local_port = &slrg_reg[1];
    uint8_t *lp_msb_lane = &slrg_reg[2];
    uint8_t *port_type = &slrg_reg[3];
    uint8_t _lane, _port_type;
    struct ku_raw_reg reg;
    sxd_reg_meta_t meta;
    uint32_t idx;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));
    reg.buff = slrg_reg;
    reg.size = sizeof(slrg_reg);

    for (idx = 0; idx < local_ports_arr_size; idx++) {
        *local_port = local_ports_arr[idx] & 0xff;
        for (_lane = 0; _lane <= 15; _lane++) {
            *lp_msb_lane = ((local_ports_arr[idx] >> 8) << 4) | _lane;
            for (_port_type = 0; _port_type <= 5; _port_type++) {
                *port_type = _port_type << 1;

                SXD_ACCESS_REG_RAW(0x5028, &reg, &meta);
            }
        }
    }

    return TRUE;
}

static boolean_t __dump_sltp(sxd_dev_id_t dev_id, const uint32_t *local_ports_arr, uint32_t local_ports_arr_size)
{
    struct ku_sltp_reg reg;
    sxd_reg_meta_t meta;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    FOR_EACH_LOCAL_PORT_START(&reg, local_ports_arr, local_ports_arr_size)
    for (reg.port_type = 0; reg.port_type <= 3; reg.port_type++) {
        for (reg.lane = 0; reg.lane <= 15; reg.lane++) {
            SXD_ACCESS_REG(sltp, &reg, &meta);
        }
    }
    FOR_EACH_LOCAL_PORT_END;

    return TRUE;
}

static boolean_t __dump_ppll(sxd_dev_id_t dev_id)
{
    uint8_t ppll_reg[80] = { 0 };
    uint8_t *pll_group = &ppll_reg[1];
    uint8_t tmp;
    struct ku_raw_reg reg;
    sxd_reg_meta_t meta;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));
    reg.buff = ppll_reg;
    reg.size = sizeof(ppll_reg);

    for (*pll_group = 1; *pll_group <= 3; (*pll_group)++) {
        tmp = *pll_group; /* FW overrides this field in the register. need to save it */
        SXD_ACCESS_REG_RAW(0x5030, &reg, &meta);
        *pll_group = tmp;
    }

    return TRUE;
}

static boolean_t __dump_pphcr(sxd_dev_id_t dev_id, const uint32_t *local_ports_arr, uint32_t local_ports_arr_size)
{
    struct ku_pphcr_reg reg;
    sxd_reg_meta_t meta;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    FOR_EACH_LOCAL_PORT_START(&reg, local_ports_arr, local_ports_arr_size)
    SXD_ACCESS_REG(pphcr, &reg, &meta);
    FOR_EACH_LOCAL_PORT_END;

    return TRUE;
}

static boolean_t __dump_mvcr(sxd_dev_id_t dev_id)
{
    struct ku_mvcr_reg reg;
    sxd_reg_meta_t meta;
    uint32_t sensor_index;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    for (sensor_index = 0; sensor_index <= 127; sensor_index++) {
        reg.sensor_index = (uint8_t)sensor_index;
        SXD_ACCESS_REG(mvcr, &reg, &meta);
    }

    return TRUE;
}

static boolean_t __dump_sllm(sxd_dev_id_t dev_id, const uint32_t *local_ports_arr, uint32_t local_ports_arr_size)
{
    struct ku_sllm_reg reg;
    sxd_reg_meta_t meta;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    FOR_EACH_LOCAL_PORT_START(&reg, local_ports_arr, local_ports_arr_size)
    for (reg.port_type = 0; reg.port_type <= 5; reg.port_type++) {
        for (reg.lane = 0; reg.lane <= 15; reg.lane++) {
            SXD_ACCESS_REG(sllm, &reg, &meta);
        }
    }
    FOR_EACH_LOCAL_PORT_END;

    return TRUE;
}

static boolean_t __dump_slrip(sxd_dev_id_t dev_id, const uint32_t *local_ports_arr, uint32_t local_ports_arr_size)
{
    uint8_t slrip_reg[96] = { 0 };
    uint8_t *local_port = &slrip_reg[1];
    uint8_t *lp_msb_lane = &slrip_reg[2];
    uint8_t *port_type = &slrip_reg[3];
    uint8_t _lane, _port_type;
    struct ku_raw_reg reg;
    sxd_reg_meta_t meta;
    uint32_t idx;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));
    reg.buff = slrip_reg;
    reg.size = sizeof(slrip_reg);

    for (idx = 0; idx < local_ports_arr_size; idx++) {
        *local_port = local_ports_arr[idx] & 0xff;
        for (_lane = 0; _lane <= 15; _lane++) {
            *lp_msb_lane = ((local_ports_arr[idx] >> 8) << 4) | _lane;
            for (_port_type = 0; _port_type <= 5; _port_type++) {
                *port_type = _port_type << 4;
                SXD_ACCESS_REG_RAW(0x5057, &reg, &meta);
            }
        }
    }

    return TRUE;
}

static boolean_t __dump_slrp(sxd_dev_id_t dev_id, const uint32_t *local_ports_arr, uint32_t local_ports_arr_size)
{
    uint8_t slrp_reg[160] = {0 };
    uint8_t *local_port = &slrp_reg[1];
    uint8_t *lp_msb_lane = &slrp_reg[2];
    uint8_t *port_type = &slrp_reg[3];
    uint8_t _lane, _port_type;
    struct ku_raw_reg reg;
    sxd_reg_meta_t meta;
    uint32_t idx;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));
    reg.buff = slrp_reg;
    reg.size = sizeof(slrp_reg);

    for (idx = 0; idx < local_ports_arr_size; idx++) {
        *local_port = local_ports_arr[idx] & 0xff;
        for (_lane = 0; _lane <= 15; _lane++) {
            *lp_msb_lane = ((local_ports_arr[idx] >> 8) << 4) | _lane;
            for (_port_type = 0; _port_type <= 5; _port_type++) {
                *port_type = _port_type << 4;
                SXD_ACCESS_REG_RAW(0x5026, &reg, &meta);
            }
        }
    }

    return TRUE;
}

static boolean_t __dump_mpein(sxd_dev_id_t dev_id)
{
    uint8_t mpein_reg[48] = { 0 };
    uint8_t *depth = &mpein_reg[0];
    uint8_t *node = &mpein_reg[2];
    uint32_t n;
    struct ku_raw_reg reg;
    sxd_reg_meta_t meta;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));
    reg.buff = mpein_reg;
    reg.size = sizeof(mpein_reg);

    for (*depth = 0; *depth <= 63; (*depth)++) {
        for (n = 0; n <= 255; n++) {
            *node = (uint8_t)n;
            SXD_ACCESS_REG_RAW(0x9050, &reg, &meta);
        }
    }

    return TRUE;
}

static boolean_t __dump_mpcnt(sxd_dev_id_t dev_id)
{
    uint8_t mpcnt_reg[256] = { 0 };
    struct ku_raw_reg reg;
    sxd_reg_meta_t meta;
    uint8_t *depth = &mpcnt_reg[0];
    uint8_t *node = &mpcnt_reg[2];
    uint8_t *grp = &mpcnt_reg[3];
    uint8_t grp_arr[] = { 0, 1, 2 };
    uint8_t grp_arr_size = sizeof(grp_arr) / sizeof(grp_arr[0]);
    uint32_t n;
    int i;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));
    reg.buff = mpcnt_reg;
    reg.size = sizeof(mpcnt_reg);

    for (*depth = 0; *depth <= 63; (*depth)++) {
        for (n = 0; n <= 255; n++) {
            *node = (uint8_t)n;
            for (i = 0; i < grp_arr_size; i++) {
                *grp = grp_arr[i];
                SXD_ACCESS_REG_RAW(0x9051, &reg, &meta);
            }
        }
    }

    return TRUE;
}

static boolean_t __dump_slsir(sxd_dev_id_t dev_id, const uint32_t *local_ports_arr, uint32_t local_ports_arr_size)
{
    struct ku_slsir_reg reg;
    sxd_reg_meta_t meta;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    FOR_EACH_LOCAL_PORT_START(&reg, local_ports_arr, local_ports_arr_size)
    for (reg.port_type = 0; reg.port_type <= 5; reg.port_type++) {
        for (reg.lane = 0; reg.lane <= 15; reg.lane++) {
            SXD_ACCESS_REG(slsir, &reg, &meta);
        }
    }
    FOR_EACH_LOCAL_PORT_END;

    return TRUE;
}

static boolean_t __dump_pmpt(sxd_dev_id_t dev_id)
{
    struct ku_pmpt_reg reg;
    sxd_reg_meta_t meta;
    uint32_t module;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    for (module = 0; module <= 255; module++) {
        reg.module = (uint8_t)module;

        for (reg.host_media = 0; reg.host_media <= 1; reg.host_media++) {
            for (reg.lane_mask = 1; reg.lane_mask <= 128; reg.lane_mask <<= 1) {
                SXD_ACCESS_REG(pmpt, &reg, &meta);
            }
        }
    }

    return TRUE;
}

static boolean_t __dump_pmpd(sxd_dev_id_t dev_id)
{
    struct ku_pmpd_reg reg;
    sxd_reg_meta_t meta;
    uint32_t module;

    __init_meta_and_reg(dev_id, &meta, &reg, sizeof(reg));

    for (module = 0; module <= 255; module++) {
        reg.module = (uint8_t)module;

        for (reg.host_media = 0; reg.host_media <= 1; reg.host_media++) {
            for (reg.lane = 0; reg.lane <= 15; reg.lane++) {
                SXD_ACCESS_REG(pmpd, &reg, &meta);
            }
        }
    }

    return TRUE;
}

static void __dump_amber_registers(sxd_dev_id_t     dev_id,
                                   sxd_chip_types_t chip_type,
                                   const uint32_t  *local_ports_arr,
                                   uint32_t         local_ports_arr_size)
{
#define AMBER_ASSERT(dump_reg)              \
    do { if (!(dump_reg)) { goto timeout; } \
    } while (0)

    AMBER_ASSERT(__dump_pddr(dev_id, local_ports_arr, local_ports_arr_size));
    AMBER_ASSERT(__dump_ptys(dev_id, local_ports_arr, local_ports_arr_size));
    AMBER_ASSERT(__dump_ppcnt(dev_id, chip_type, local_ports_arr, local_ports_arr_size));
    AMBER_ASSERT(__dump_mtmp(dev_id));
    AMBER_ASSERT(__dump_sltp(dev_id, local_ports_arr, local_ports_arr_size));
    AMBER_ASSERT(__dump_ppll(dev_id));
    AMBER_ASSERT(__dump_pphcr(dev_id, local_ports_arr, local_ports_arr_size));
    AMBER_ASSERT(__dump_mvcr(dev_id));

    /* following registers are temporarily disabled. see comments at the top of the file */
    if (FALSE) {
        AMBER_ASSERT(__dump_sllm(dev_id, local_ports_arr, local_ports_arr_size));
        AMBER_ASSERT(__dump_slrg(dev_id, local_ports_arr, local_ports_arr_size));
        AMBER_ASSERT(__dump_slrip(dev_id, local_ports_arr, local_ports_arr_size));
        AMBER_ASSERT(__dump_slrp(dev_id, local_ports_arr, local_ports_arr_size));
        AMBER_ASSERT(__dump_mpein(dev_id));
        AMBER_ASSERT(__dump_mpcnt(dev_id));
        AMBER_ASSERT(__dump_slsir(dev_id, local_ports_arr, local_ports_arr_size));
        AMBER_ASSERT(__dump_pmpt(dev_id));
        AMBER_ASSERT(__dump_pmpd(dev_id));
    }

    return;

timeout:
    /* failure may be because FW is not accessible (this is why dump was requested in the first place).
     * just ignore this, put a nice log message (not in error level) and go out */

    SX_LOG_NTC("AMBER Dump: Stopping dump due to FW EMAD timeout\n");
}

#define HEX_DIGIT_TO_CHAR(n) (((n) <= 9) ? ('0' + (n)) : ('a' + (n) - 10))
static int __dump_tlv_header(const uint8_t *tlv_header, char *hex_buff)
{
    int tlv_len = EMAD_TLV_LEN(tlv_header) * 4;
    int len = 0;
    int i;

    for (i = 0; i < tlv_len; i++) {
        /* DON'T use sprintf/fprintf or any other format-string functions
         * as their overhead is enormous
         */

        hex_buff[len++] = HEX_DIGIT_TO_CHAR(tlv_header[i] >> 4);
        hex_buff[len++] = HEX_DIGIT_TO_CHAR(tlv_header[i] & 0xf);
        hex_buff[len++] = ' ';
    }

    return len;
}

struct amber_emad_hook_ctx {
    FILE *fp;
    uint32_t total_fw_time_usec;
};

static void __get_fw_time(sxd_dev_id_t                dev_id,
                          sxd_reg_id_e                reg_id,
                          uint8_t                     fw_status,
                          const void                 *reg_data,
                          const sxd_emad_operation_t *operation_tlv,
                          const sxd_emad_reg_t       *reg_tlv,
                          const sxd_emad_latency_t   *latency_tlv,
                          void                       *context)
{
    struct amber_emad_hook_ctx *ctx = (struct amber_emad_hook_ctx*)context;

    UNUSED_PARAM(dev_id);
    UNUSED_PARAM(reg_id);
    UNUSED_PARAM(fw_status);
    UNUSED_PARAM(reg_data);
    UNUSED_PARAM(operation_tlv);
    UNUSED_PARAM(reg_tlv);

    if (latency_tlv) {
        ctx->total_fw_time_usec += cl_ntoh32(latency_tlv->latency_time);
    }
}


static void __amber_emad_hook(sxd_dev_id_t                dev_id,
                              sxd_reg_id_e                reg_id,
                              uint8_t                     fw_status,
                              const void                 *reg_data,
                              const sxd_emad_operation_t *operation_tlv,
                              const sxd_emad_reg_t       *reg_tlv,
                              const sxd_emad_latency_t   *latency_tlv,
                              void                       *context)
{
    static char hex_buff[64 * 1024]; /* enough space for 12K maximum EMAD frame * (2 hex chars + 1 space) */
    struct amber_emad_hook_ctx *ctx = (struct amber_emad_hook_ctx*)context;
    char *curr = hex_buff;
    int len = 0;

    UNUSED_PARAM(dev_id);
    UNUSED_PARAM(reg_id);
    UNUSED_PARAM(reg_data);
    UNUSED_PARAM(latency_tlv);

    if (fw_status != 0) { /* on EMAD error, we just skip writing the register dump */
        return;
    }

    len = __dump_tlv_header((const uint8_t*)operation_tlv, curr);
    curr += len;
    len = __dump_tlv_header((const uint8_t*)reg_tlv, curr);
    curr += len;
    *curr = '\0';

    fprintf(ctx->fp, "%s\n", hex_buff);

    if (latency_tlv) {
        ctx->total_fw_time_usec += cl_ntoh32(latency_tlv->latency_time);
    }
}

static boolean_t __get_valid_ports(sx_dev_id_t dev_id,
                                   uint32_t    max_ports,
                                   uint32_t   *valid_local_ports_arr,
                                   uint32_t   *num_valid_local_ports)
{
    struct ku_pspa_reg pspa;
    sxd_reg_meta_t meta;
    sxd_status_t st;
    uint32_t local_port;
    uint32_t idx = 0;

    memset(&meta, 0, sizeof(meta));

    meta.dev_id = dev_id;
    meta.access_cmd = SXD_ACCESS_CMD_GET;

    for (local_port = 1; local_port <= max_ports; local_port++) {
        memset(&pspa, 0, sizeof(pspa));
        SX_PORT_EXTRACT_LSB_MSB_FROM_PHY_ID(pspa.local_port, pspa.lp_msb, local_port);

        st = sxd_access_reg_pspa(&pspa, &meta, 1, NULL, NULL);
        if (st != SXD_STATUS_SUCCESS) {
            if (st == SXD_STATUS_TIMEOUT) {
                return FALSE;
            }

            SX_LOG_WRN("failed to check if local port %u is valid, this port will not be dumped.", local_port);
            continue;
        }

        if (SX_SWID_CHECK_RANGE(pspa.swid)) {
            valid_local_ports_arr[idx++] = local_port;
        }
    }

    *num_valid_local_ports = idx;
    return TRUE;
}

sx_status_t dbg_generate_amber_dump(const char               *path,
                                    sx_dev_id_t               dev_id,
                                    const struct ku_dev_info *dev_info,
                                    uint32_t                 *total_fw_time_msec)
{
    sx_status_t rc = SX_STATUS_SUCCESS;
    sxd_status_t sxd_rc = SXD_STATUS_SUCCESS;
    uint32_t emad_timeout = 0;
    sxd_chip_types_t chip_type = SXD_CHIP_TYPE_UNKNOWN;
    uint32_t valid_local_ports_arr[MAX_PHYPORT_NUM] = { 0 };
    uint32_t num_valid_local_ports = 0;
    uint32_t max_ports = 0;
    boolean_t is_emad_used = FALSE;
    sx_verbosity_level_t emad_rx_log_level = SX_VERBOSITY_LEVEL_NONE,
                         emad_tx_log_level = SX_VERBOSITY_LEVEL_NONE,
                         access_reg_infra_log_level = SX_VERBOSITY_LEVEL_NONE,
                         access_reg_log_level = SX_VERBOSITY_LEVEL_NONE,
                         emad_log_level = SX_VERBOSITY_LEVEL_NONE,
                         emad_system_log_level = SX_VERBOSITY_LEVEL_NONE,
                         log_level_none = SX_VERBOSITY_LEVEL_NONE;
    struct amber_emad_hook_ctx hook_ctx = {
        .fp = NULL,
        .total_fw_time_usec = 0
    };

    SX_LOG_NTC("Starting AMBER dump\n");

    sxd_rc = sxd_dpt_get_device_type(dev_id, &chip_type);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("AMBER Dump: Failed to get chip type (err=%u)\n", sxd_rc);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    sxd_rc = __get_chip_max_ports(chip_type, &max_ports);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("AMBER Dump: Unsupported chip type (%u)\n", chip_type);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    /* make sure that registers are accessed through EMAD */
    sxd_rc = sxd_dpt_is_emad_used(dev_id, &is_emad_used);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("AMBER Dump: Failed to check if device is using EMAD (err=%u)\n", sxd_rc);
        goto out;
    }

    if (!is_emad_used) {
        SX_LOG_NTC("AMBER Dump: Device is not using EMAD, dump will not be taken\n");
        goto out;
    }

    if (!(dev_info->dev_info.dev_info_ro.flags & SX_DEV_INFO_F_DEV_PROFILE_SET)) {
        SX_LOG_NTC("AMBER Dump: Device profile is not set\n");
        goto out;
    }

    if (!(dev_info->dev_info.dev_info_ro.flags & SX_DEV_INFO_F_PCI_PROFILE_SET)) {
        SX_LOG_NTC("AMBER Dump: PCI profile is not set\n");
        goto out;
    }

    /* create the file name and the full path */
    rc = generate_dump_file(path, dev_id,  "amber", "hex", &hook_ctx.fp);
    if (rc != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("AMBER dump: Failed to generate amber dump file name");
        goto out;
    }

    /* save the current EMAD timeout */
    sxd_emad_timeout_get(&emad_timeout);

    /* set EMAD timeout for the AMBER dump */
    sxd_emad_timeout_set(AMBER_EMAD_TIMEOUT_USEC);

    /* get current EMAD log level settings */
    emad_rx_thread_log_verbosity_level_get(&emad_rx_log_level);
    emad_tx_thread_log_verbosity_level_get(&emad_tx_log_level);
    sxd_access_register_log_verbosity_level_get(&access_reg_log_level);
    emad_access_reg_infra_log_verbosity_level_get(&access_reg_infra_log_level);
    sxd_emad_system_log_verbosity_level(SXD_ACCESS_CMD_GET, &emad_system_log_level);
    emad_log_verbosity_level(SXD_ACCESS_CMD_GET, &emad_log_level);

    /* set EMAD log level to total silence */
    emad_rx_thread_log_verbosity_level_set(SX_VERBOSITY_LEVEL_NONE);
    emad_tx_thread_log_verbosity_level_set(SX_VERBOSITY_LEVEL_NONE);
    sxd_access_register_log_verbosity_level_set(SX_VERBOSITY_LEVEL_NONE);
    emad_access_reg_infra_log_verbosity_level_set(SX_VERBOSITY_LEVEL_NONE);
    sxd_emad_system_log_verbosity_level(SXD_ACCESS_CMD_SET, &log_level_none);
    emad_log_verbosity_level(SXD_ACCESS_CMD_SET, &log_level_none);

    /* this hook is just to measure FW time, it is not mandatory */
    sxd_rc = sxd_emad_hook_register(0, __get_fw_time, &hook_ctx);

    if (!__get_valid_ports(dev_id, max_ports, valid_local_ports_arr, &num_valid_local_ports)) {
        /* failure may be because FW is not accessible (this is why dump was requested in the first place).
         * just ignore this, put a nice log message (not in error level) and go out */
        SX_LOG_NTC("AMBER Dump: failed to get valid port list\n");
        goto out;
    }

    if (sxd_rc == SXD_STATUS_SUCCESS) {
        sxd_emad_hook_unregister(0);
    }

    sxd_rc = sxd_emad_hook_register(0, __amber_emad_hook, &hook_ctx);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("AMBER Dump: failed to register EMAD hook (err=%u)\n", sxd_rc);
        rc = SX_STATUS_ERROR;
        goto out;
    }

    __dump_amber_registers(dev_id, chip_type, valid_local_ports_arr, num_valid_local_ports);

    /* restore the old EMAD log level settings */
    emad_rx_thread_log_verbosity_level_set(emad_rx_log_level);
    emad_tx_thread_log_verbosity_level_set(emad_tx_log_level);
    sxd_access_register_log_verbosity_level_set(access_reg_log_level);
    emad_access_reg_infra_log_verbosity_level_set(access_reg_infra_log_level);
    sxd_emad_system_log_verbosity_level(SXD_ACCESS_CMD_SET, &emad_system_log_level);
    emad_log_verbosity_level(SXD_ACCESS_CMD_SET, &emad_log_level);

    sxd_emad_hook_unregister(0);

    /* restore the old EMAD timeout */
    sxd_emad_timeout_set(emad_timeout);

out:

    *total_fw_time_msec = hook_ctx.total_fw_time_usec / 1000;

    SX_LOG_NTC("Finished AMBER dump\n");
    return rc;
}
