/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_macsec.h>
#include "sx_api_internal.h"

#undef __MODULE__
#define __MODULE__ SX_API_MACSEC

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

sx_status_t sx_api_macsec_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  const sx_verbosity_level_t      module_verbosity_level,
                                                  const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_MACSEC_VERBOSITY_SET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head,
                                            (uint8_t*)&cmd_body, &reply_head,
                                            NULL, 0);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set verbosity level\n");
            goto out;
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                  const sx_log_verbosity_target_t verbosity_target,
                                                  sx_verbosity_level_t           *module_verbosity_level_p,
                                                  sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p,
                                  "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_MACSEC_VERBOSITY_GET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(
            handle, cmd_head.opcode, (uint8_t*)&cmd_body,
            sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_init(const sx_api_handle_t handle, sx_macsec_init_params_t *macsec_init_params_p)
{
    sx_macsec_init_set_params_t cmd_body;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(macsec_init_params_p, "macsec_init_params")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_INIT_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_init_set_params_t));
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_deinit(const sx_api_handle_t handle)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_DEINIT_E,
                                      NULL,
                                      0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_init_params_get(const sx_api_handle_t handle, sx_macsec_init_params_t *macsec_init_params_p)
{
    sx_macsec_init_get_params_t cmd_body;
    sx_status_t                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(macsec_init_params_p, "macsec_init_params")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_INIT_PARAMS_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_init_get_params_t));
    if (SX_CHECK_PASS(err)) {
        macsec_init_params_p->reserved = cmd_body.reserved;
    }
out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_macsec_port_init(const sx_api_handle_t            handle,
                                    const sx_port_log_id_t           log_port,
                                    const sx_access_cmd_t            cmd,
                                    sx_macsec_port_init_attribute_t *macsec_port_init_attr_p)
{
    sx_macsec_port_init_attribute_set_params_t cmd_body;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    UNUSED_PARAM(cmd);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(macsec_port_init_attr_p, "macsec_port_init_attr")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.log_port = log_port;
    cmd_body.port_attr = *macsec_port_init_attr_p;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_PORT_INIT_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_port_init_attribute_set_params_t));


out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_port_deinit(const sx_api_handle_t handle, const sx_port_log_id_t log_port)
{
    sx_macsec_port_deinit_attribute_set_params_t cmd_body;
    sx_status_t                                  err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.log_port = log_port;


    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_PORT_DEINIT_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_port_deinit_attribute_set_params_t));

    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_macsec_port_capability_get(const sx_api_handle_t        handle,
                                              const sx_port_log_id_t       log_port,
                                              sx_macsec_port_capability_t *capability_p)
{
    sx_macsec_port_capability_get_params_t cmd_body;
    sx_status_t                            err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(capability_p, "capability")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.log_port = log_port;
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_PORT_CAP_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_port_capability_get_params_t));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve MACSec capability for port [0x%08x], error[%s]\n",
                   log_port, SX_STATUS_MSG(err));
        goto out;
    }

    SX_MEM_CPY_P(capability_p, &cmd_body.capability);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_flow_obj_set(const sx_api_handle_t       handle,
                                       const sx_access_cmd_t       cmd,
                                       sx_macsec_flow_attribute_t *macsec_flow_attr_p,
                                       sx_macsec_flow_obj_id_t    *macsec_flow_obj_id_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_macsec_flow_obj_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (cmd == SX_ACCESS_CMD_CREATE) {
        if (utils_check_pointer(macsec_flow_attr_p, "macsec_flow_attr")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        cmd_body.flow_attr = *macsec_flow_attr_p;
    } else {
        cmd_body.flow_obj_id = *macsec_flow_obj_id_p;
    }

    cmd_body.cmd = cmd;
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_FLOW_OBJ_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_flow_obj_set_params_t));


    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set flow object, error[%s]\n", SX_STATUS_MSG(err));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_CREATE) {
        SX_MEM_CPY_P(macsec_flow_obj_id_p, &cmd_body.flow_obj_id);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_macsec_flow_obj_get(const sx_api_handle_t       handle,
                                       const sx_access_cmd_t       cmd,
                                       sx_macsec_flow_obj_id_t     macsec_flow_obj_id,
                                       sx_macsec_flow_attribute_t *macsec_flow_attr_p)
{
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_macsec_flow_obj_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(macsec_flow_attr_p, "macsec_flow_attr")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.flow_obj_id = macsec_flow_obj_id;
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_FLOW_OBJ_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_flow_obj_get_params_t));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve flow object 0x%" PRIx64 ", error[%s]\n",
                   macsec_flow_obj_id, SX_STATUS_MSG(err));
        goto out;
    }

    SX_MEM_CPY_P(macsec_flow_attr_p, &cmd_body.flow_attr);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_flow_obj_iter_get(const sx_api_handle_t          handle,
                                            const sx_access_cmd_t          cmd,
                                            const sx_macsec_flow_obj_id_t  macsec_flow_obj_id,
                                            const sx_macsec_flow_filter_t *filter_p,
                                            sx_macsec_flow_attribute_t    *macsec_flow_attr_list_p,
                                            uint32_t                      *macsec_flow_cnt_p)
{
    sx_api_command_head_t                 cmd_head;
    sx_macsec_flow_obj_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                   reply_head;
    sx_macsec_flow_obj_iter_get_params_t *reply_body = NULL;
    uint32_t                              reply_body_size;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (utils_check_pointer(macsec_flow_cnt_p, "macsec_flow_cnt_p")) {
        SX_LOG_ERR("macsec_flow_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*macsec_flow_cnt_p > 0) && (macsec_flow_attr_list_p == NULL)) {
        SX_LOG_ERR("*macsec_flow_cnt_p is not 0 but macsec_flow_attr_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*macsec_flow_cnt_p == 0) {
            macsec_flow_attr_list_p = NULL;
        } else {
            *macsec_flow_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*macsec_flow_cnt_p == 0) {
            SX_LOG_DBG("MACSec flow ID count is 0\n");
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_macsec_flow_obj_iter_get_params_t) +
                      (*macsec_flow_cnt_p * sizeof(sx_macsec_flow_attribute_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_MACSEC_FLOW_OBJ_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_macsec_flow_obj_iter_get_params_t);
    cmd_head.list_size = *macsec_flow_cnt_p * sizeof(sx_macsec_flow_attribute_t);

    cmd_body.cmd = cmd;
    cmd_body.macsec_flow_obj_key = macsec_flow_obj_id;
    cmd_body.macsec_flow_obj_list_cnt = *macsec_flow_cnt_p;
    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), filter_p, sx_macsec_flow_filter_t);
    }

    *macsec_flow_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->macsec_flow_obj_list_cnt != 0) {
        *macsec_flow_cnt_p = reply_body->macsec_flow_obj_list_cnt;
        if (macsec_flow_attr_list_p != NULL) {
            SX_MEM_CPY_ARRAY(macsec_flow_attr_list_p, reply_body->macsec_flow_obj_list,
                             reply_body->macsec_flow_obj_list_cnt, sx_macsec_flow_attribute_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_sc_obj_set(const sx_api_handle_t     handle,
                                     const sx_access_cmd_t     cmd,
                                     sx_macsec_sc_attribute_t *macsec_sc_attr_p,
                                     sx_macsec_sc_obj_id_t    *macsec_sc_obj_id_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_macsec_sc_obj_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (cmd == SX_ACCESS_CMD_CREATE) {
        if (utils_check_pointer(macsec_sc_attr_p, "macsec_sc_attr")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        cmd_body.sc_attr = *macsec_sc_attr_p;
    } else {
        cmd_body.sc_obj_id = *macsec_sc_obj_id_p;
    }

    cmd_body.cmd = cmd;
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_SC_OBJ_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_sc_obj_set_params_t));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set SC object, error[%s]\n", SX_STATUS_MSG(err));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_CREATE) {
        SX_MEM_CPY_P(macsec_sc_obj_id_p, &cmd_body.sc_obj_id);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_macsec_sc_obj_get(const sx_api_handle_t     handle,
                                     const sx_access_cmd_t     cmd,
                                     sx_macsec_sc_obj_id_t     macsec_sc_obj_id,
                                     sx_macsec_sc_attribute_t *macsec_sc_attr_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_macsec_sc_obj_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(macsec_sc_attr_p, "macsec_sc_attr")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.sc_obj_id = macsec_sc_obj_id;
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_SC_OBJ_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_sc_obj_get_params_t));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve SC object 0x%" PRIx64 ", error[%s]\n",
                   macsec_sc_obj_id, SX_STATUS_MSG(err));
        goto out;
    }

    SX_MEM_CPY_P(macsec_sc_attr_p, &cmd_body.sc_attr);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_sc_obj_iter_get(const sx_api_handle_t        handle,
                                          const sx_access_cmd_t        cmd,
                                          const sx_macsec_sc_obj_id_t  macsec_sc_obj_id,
                                          const sx_macsec_sc_filter_t *filter_p,
                                          sx_macsec_sc_attribute_t    *macsec_sc_attr_list_p,
                                          uint32_t                    *macsec_sc_cnt_p)
{
    sx_api_command_head_t               cmd_head;
    sx_macsec_sc_obj_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                 reply_head;
    sx_macsec_sc_obj_iter_get_params_t *reply_body = NULL;
    uint32_t                            reply_body_size;
    sx_status_t                         err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (utils_check_pointer(macsec_sc_cnt_p, "macsec_sc_cnt_p")) {
        SX_LOG_ERR("macsec_sc_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*macsec_sc_cnt_p > 0) && (macsec_sc_attr_list_p == NULL)) {
        SX_LOG_ERR("*macsec_sc_cnt_p is not 0 but macsec_sc_attr_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*macsec_sc_cnt_p == 0) {
            macsec_sc_attr_list_p = NULL;
        } else {
            *macsec_sc_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*macsec_sc_cnt_p == 0) {
            SX_LOG_DBG("MACSec SC ID count is 0\n");
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_macsec_sc_obj_iter_get_params_t) +
                      (*macsec_sc_cnt_p * sizeof(sx_macsec_sc_attribute_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_MACSEC_SC_OBJ_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_macsec_sc_obj_iter_get_params_t);
    cmd_head.list_size = *macsec_sc_cnt_p * sizeof(sx_macsec_sc_attribute_t);

    cmd_body.cmd = cmd;
    cmd_body.macsec_sc_obj_key = macsec_sc_obj_id;
    cmd_body.macsec_sc_obj_list_cnt = *macsec_sc_cnt_p;
    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), filter_p, sx_macsec_flow_filter_t);
    }

    *macsec_sc_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->macsec_sc_obj_list_cnt != 0) {
        *macsec_sc_cnt_p = reply_body->macsec_sc_obj_list_cnt;
        if (macsec_sc_attr_list_p != NULL) {
            SX_MEM_CPY_ARRAY(macsec_sc_attr_list_p, reply_body->macsec_sc_obj_list,
                             reply_body->macsec_sc_obj_list_cnt, sx_macsec_sc_attribute_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_sa_obj_set(const sx_api_handle_t     handle,
                                     const sx_access_cmd_t     cmd,
                                     sx_macsec_sa_attribute_t *macsec_sa_attr_p,
                                     sx_macsec_sa_obj_id_t    *macsec_sa_obj_id_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_macsec_sa_obj_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (cmd == SX_ACCESS_CMD_CREATE) {
        if (utils_check_pointer(macsec_sa_attr_p, "macsec_sa_attr")) {
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }
        cmd_body.sa_attr = *macsec_sa_attr_p;
    } else {
        cmd_body.sa_obj_id = *macsec_sa_obj_id_p;
    }

    cmd_body.cmd = cmd;
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_SA_OBJ_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_sa_obj_set_params_t));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set SA object, error[%s]\n", SX_STATUS_MSG(err));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_CREATE) {
        SX_MEM_CPY_P(macsec_sa_obj_id_p, &cmd_body.sa_obj_id);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_sa_obj_get(const sx_api_handle_t     handle,
                                     const sx_access_cmd_t     cmd,
                                     sx_macsec_sa_obj_id_t     macsec_sa_obj_id,
                                     sx_macsec_sa_attribute_t *macsec_sa_attr_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_macsec_sa_obj_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (utils_check_pointer(macsec_sa_attr_p, "macsec_sa_attr")) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.sa_obj_id = macsec_sa_obj_id;
    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_SA_OBJ_GET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_sa_obj_get_params_t));

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to retrieve SA object 0x%" PRIx64 ", error[%s]\n",
                   macsec_sa_obj_id, SX_STATUS_MSG(err));
        goto out;
    }

    SX_MEM_CPY_P(macsec_sa_attr_p, &cmd_body.sa_attr);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_sa_obj_iter_get(const sx_api_handle_t        handle,
                                          const sx_access_cmd_t        cmd,
                                          const sx_macsec_sa_obj_id_t  macsec_sa_obj_id,
                                          const sx_macsec_sa_filter_t *filter_p,
                                          sx_macsec_sa_attribute_t    *macsec_sa_attr_list_p,
                                          uint32_t                    *macsec_sa_cnt_p)
{
    sx_api_command_head_t               cmd_head;
    sx_macsec_sa_obj_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                 reply_head;
    sx_macsec_sa_obj_iter_get_params_t *reply_body = NULL;
    uint32_t                            reply_body_size;
    sx_status_t                         err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (utils_check_pointer(macsec_sa_cnt_p, "macsec_sa_cnt_p")) {
        SX_LOG_ERR("macsec_sa_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*macsec_sa_cnt_p > 0) && (macsec_sa_attr_list_p == NULL)) {
        SX_LOG_ERR("*macsec_sa_cnt_p is not 0 but macsec_sa_attr_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*macsec_sa_cnt_p == 0) {
            macsec_sa_attr_list_p = NULL;
        } else {
            *macsec_sa_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*macsec_sa_cnt_p == 0) {
            SX_LOG_DBG("MACSec SA ID count is 0\n");
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_macsec_sa_obj_iter_get_params_t) +
                      (*macsec_sa_cnt_p * sizeof(sx_macsec_sa_attribute_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_MACSEC_SA_OBJ_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_macsec_sa_obj_iter_get_params_t);
    cmd_head.list_size = *macsec_sa_cnt_p * sizeof(sx_macsec_sa_attribute_t);

    cmd_body.cmd = cmd;
    cmd_body.macsec_sa_obj_key = macsec_sa_obj_id;
    cmd_body.macsec_sa_obj_list_cnt = *macsec_sa_cnt_p;
    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), filter_p, sx_macsec_flow_filter_t);
    }

    *macsec_sa_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->macsec_sa_obj_list_cnt != 0) {
        *macsec_sa_cnt_p = reply_body->macsec_sa_obj_list_cnt;
        if (macsec_sa_attr_list_p != NULL) {
            SX_MEM_CPY_ARRAY(macsec_sa_attr_list_p, reply_body->macsec_sa_obj_list,
                             reply_body->macsec_sa_obj_list_cnt, sx_macsec_sa_attribute_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_counters_get(const sx_api_handle_t          handle,
                                       const sx_access_cmd_t          cmd,
                                       const sx_macsec_counter_key_t *macsec_cntr_key_list_p,
                                       uint32_t                       cntr_list_len,
                                       sx_macsec_counter_t           *macsec_cntr_val_list_p)
{
    sx_macsec_counter_get_params_t *cmd_body_p = NULL;
    uint32_t                        cmd_body_size = 0;
    sx_status_t                     err = SX_STATUS_SUCCESS;
    uint32_t                        i = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body_p);

    if (utils_check_pointer(macsec_cntr_key_list_p, "macsec_cntr_key_list_p")) {
        SX_LOG_ERR("macsec_cntr_key_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(macsec_cntr_val_list_p, "macsec_cntr_val_list_p")) {
        SX_LOG_ERR("macsec_cntr_val_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!cntr_list_len) {
        SX_LOG(SX_LOG_NOTICE, "Counter List Length is 0. Nothing to Read\n");
        goto out;
    } else if (cntr_list_len > SX_MACSEC_API_CNTR_REQ_MAX) {
        SX_LOG_ERR("cntr_list_len > SX_MACSEC_API_CNTR_REQ_MAX (%u)\n", SX_MACSEC_API_CNTR_REQ_MAX);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_READ_CLEAR:
    case SX_ACCESS_CMD_READ:

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access-command %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    cmd_body_size = sizeof(sx_macsec_counter_get_params_t) +
                    (cntr_list_len * sizeof(sx_macsec_counter_t));
    if (sizeof(sx_api_command_head_t) + cmd_body_size >= SX_API_MESSAGE_SIZE_LIMIT) {
        err = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        SX_LOG_ERR("Too many Counter keys requested. Max API size (%u) exceeded. Reduce and retry. err: %s.\n",
                   SX_API_MESSAGE_SIZE_LIMIT, sx_status_str(err));
        goto out;
    }
    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }


    cmd_body_p->cmd = cmd;
    cmd_body_p->macsec_cntr_list_cnt = cntr_list_len;
    /* fill in the keys into the cmd_body_p */
    for (i = 0; i < cntr_list_len; i++) {
        cmd_body_p->macsec_cntr_key_val_list[i].type = macsec_cntr_key_list_p[i].type;
        macsec_cntr_val_list_p[i].type = macsec_cntr_key_list_p[i].type;

        switch (macsec_cntr_key_list_p[i].type) {
        case SX_MACSEC_CNTR_SA_GROUP_E:
            SX_MEM_CPY_TYPE(&(cmd_body_p->macsec_cntr_key_val_list[i].data.sa_grp.key),
                            &(macsec_cntr_key_list_p[i].key.sa_grp),
                            sx_macsec_cntr_sa_group_key_t);

            break;

        case SX_MACSEC_CNTR_PORT_GROUP0_E:
            SX_MEM_CPY_TYPE(&(cmd_body_p->macsec_cntr_key_val_list[i].data.port_grp0.key),
                            &(macsec_cntr_key_list_p[i].key.port_grp0),
                            sx_macsec_cntr_port_group0_key_t);

            break;

        case SX_MACSEC_CNTR_PORT_GROUP1_E:
            SX_MEM_CPY_TYPE(&(cmd_body_p->macsec_cntr_key_val_list[i].data.port_grp1.key),
                            &(macsec_cntr_key_list_p[i].key.port_grp1),
                            sx_macsec_cntr_port_group1_key_t);

            break;

        case SX_MACSEC_CNTR_UTRAP_GROUP_E:
            SX_MEM_CPY_TYPE(&(cmd_body_p->macsec_cntr_key_val_list[i].data.utrap_grp.key),
                            &(macsec_cntr_key_list_p[i].key.utrap_grp),
                            sx_macsec_cntr_utrap_group_key_t);

            break;

        default:
            SX_LOG_ERR("Unknown Counter Key type param (%u) in Key list at index [%d].\n",
                       macsec_cntr_key_list_p[i].type, i);
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        } /* end switch */
    }/* end cntr_list_len */

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MACSEC_COUNTER_GET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to read MACSec Counters. error[%s]\n",
                   SX_STATUS_MSG(err));
        goto out;
    }

    for (i = 0; i < cmd_body_p->macsec_cntr_list_cnt; i++) {
        switch (cmd_body_p->macsec_cntr_key_val_list[i].type) {
        case SX_MACSEC_CNTR_SA_GROUP_E:
            /* copy the key */
            SX_MEM_CPY_TYPE(&(macsec_cntr_val_list_p[i].data.sa_grp.key),
                            &(cmd_body_p->macsec_cntr_key_val_list[i].data.sa_grp.key),
                            sx_macsec_cntr_sa_group_key_t);
            /* copy the stats */
            SX_MEM_CPY_TYPE(&(macsec_cntr_val_list_p[i].data.sa_grp.stats),
                            &(cmd_body_p->macsec_cntr_key_val_list[i].data.sa_grp.stats),
                            sx_macsec_cntr_sa_stats_t);
            break;

        case SX_MACSEC_CNTR_PORT_GROUP0_E:
            /* copy the key */
            SX_MEM_CPY_TYPE(&(macsec_cntr_val_list_p[i].data.port_grp0.key),
                            &(cmd_body_p->macsec_cntr_key_val_list[i].data.port_grp0.key),
                            sx_macsec_cntr_port_group0_key_t);
            /* copy the stats */
            SX_MEM_CPY_TYPE(&(macsec_cntr_val_list_p[i].data.port_grp0.stats),
                            &(cmd_body_p->macsec_cntr_key_val_list[i].data.port_grp0.stats),
                            sx_macsec_cntr_port_group0_stats_t);
            break;

        case SX_MACSEC_CNTR_PORT_GROUP1_E:
            /* copy the key */
            SX_MEM_CPY_TYPE(&(macsec_cntr_val_list_p[i].data.port_grp1.key),
                            &(cmd_body_p->macsec_cntr_key_val_list[i].data.port_grp1.key),
                            sx_macsec_cntr_port_group1_key_t);
            /* copy the stats */
            SX_MEM_CPY_TYPE(&(macsec_cntr_val_list_p[i].data.port_grp1.stats),
                            &(cmd_body_p->macsec_cntr_key_val_list[i].data.port_grp1.stats),
                            sx_macsec_cntr_port_group1_stats_t);
            break;

        case SX_MACSEC_CNTR_UTRAP_GROUP_E:
            /* copy the key */
            SX_MEM_CPY_TYPE(&(macsec_cntr_val_list_p[i].data.utrap_grp.key),
                            &(cmd_body_p->macsec_cntr_key_val_list[i].data.utrap_grp.key),
                            sx_macsec_cntr_utrap_group_key_t);
            /* copy the stats */
            SX_MEM_CPY_TYPE(&(macsec_cntr_val_list_p[i].data.utrap_grp.stats),
                            &(cmd_body_p->macsec_cntr_key_val_list[i].data.utrap_grp.stats),
                            sx_macsec_cntr_utrap_stats_t);
            break;
        }
    }

out:
    if (cmd_body_p != NULL) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_events_set(const sx_api_handle_t         handle,
                                     const uint32_t                macsec_event_list_len,
                                     const sx_macsec_event_key_t  *macsec_event_key_list_p,
                                     const sx_macsec_event_attr_t *macsec_event_attr_list_p)
{
    sx_macsec_events_set_params_t *cmd_body_p = NULL;
    uint32_t                       cmd_body_size = 0;
    sx_status_t                    err = SX_STATUS_SUCCESS;
    uint32_t                       i = 0;

    SX_API_LOG_ENTER();

    if (utils_check_pointer(macsec_event_key_list_p, "macsec_event_key_list_p")) {
        SX_LOG_ERR("macsec_event_key_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(macsec_event_attr_list_p, "macsec_event_attr_list_p")) {
        SX_LOG_ERR("macsec_event_attr_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!macsec_event_list_len) {
        SX_LOG(SX_LOG_NOTICE, "Events List Length is 0. Nothing to SET\n");
        goto out;
    }

    cmd_body_size = sizeof(sx_macsec_events_get_params_t) +
                    (macsec_event_list_len * sizeof(sx_macsec_event_info_t));
    if (sizeof(sx_api_command_head_t) + cmd_body_size >= SX_API_MESSAGE_SIZE_LIMIT) {
        err = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        SX_LOG_ERR("Too many events set requested. Max API size (%u) exceeded. Reduce and retry. err: %s.\n",
                   SX_API_MESSAGE_SIZE_LIMIT, sx_status_str(err));
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_body_p->macsec_events_info_list_cnt = macsec_event_list_len;
    /* fill in the keys into the cmd_body_p */
    for (i = 0; i < macsec_event_list_len; i++) {
        cmd_body_p->macsec_events_info_list[i].event_id = macsec_event_key_list_p[i].event_id;
        cmd_body_p->macsec_events_info_list[i].direction = macsec_event_key_list_p[i].direction;
        cmd_body_p->macsec_events_info_list[i].action = macsec_event_attr_list_p[i].action;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MACSEC_EVENTS_SET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set MACSec events attribute, error[%s]\n",
                   SX_STATUS_MSG(err));
        goto out;
    }
out:
    if (cmd_body_p != NULL) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_events_get(const sx_api_handle_t        handle,
                                     const uint32_t               macsec_event_list_len,
                                     const sx_macsec_event_key_t *macsec_event_key_list_p,
                                     sx_macsec_event_attr_t      *macsec_event_attr_list_p)
{
    sx_macsec_events_get_params_t *cmd_body_p = NULL;
    uint32_t                       cmd_body_size = 0;
    sx_status_t                    err = SX_STATUS_SUCCESS;
    uint32_t                       i = 0;

    SX_API_LOG_ENTER();

    if (utils_check_pointer(macsec_event_key_list_p, "macsec_event_key_list_p")) {
        SX_LOG_ERR("macsec_event_key_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(macsec_event_attr_list_p, "macsec_event_attr_list_p")) {
        SX_LOG_ERR("macsec_event_attr_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!macsec_event_list_len) {
        SX_LOG(SX_LOG_NOTICE, "Event List Length is 0. Nothing to GET\n");
        goto out;
    }

    cmd_body_size = sizeof(sx_macsec_events_get_params_t) +
                    (macsec_event_list_len * sizeof(sx_macsec_event_info_t));
    if (sizeof(sx_api_command_head_t) + cmd_body_size >= SX_API_MESSAGE_SIZE_LIMIT) {
        err = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        SX_LOG_ERR("Too many events get requested. Max API size (%u) exceeded. Reduce and retry. err: %s.\n",
                   SX_API_MESSAGE_SIZE_LIMIT, sx_status_str(err));
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_body_p->macsec_events_info_list_cnt = macsec_event_list_len;
    /* fill in the keys into the cmd_body_p */
    for (i = 0; i < macsec_event_list_len; i++) {
        cmd_body_p->macsec_events_info_list[i].event_id = macsec_event_key_list_p[i].event_id;
        cmd_body_p->macsec_events_info_list[i].direction = macsec_event_key_list_p[i].direction;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MACSEC_EVENTS_GET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get MACSec events attribute, error[%s]\n",
                   SX_STATUS_MSG(err));
        goto out;
    }

    for (i = 0; i < cmd_body_p->macsec_events_info_list_cnt; i++) {
        macsec_event_attr_list_p[i].action = cmd_body_p->macsec_events_info_list[i].action;
    }

out:
    if (cmd_body_p != NULL) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_acl_counter_set(const sx_api_handle_t       handle,
                                          const sx_access_cmd_t       cmd,
                                          const sx_port_log_id_t      log_port,
                                          const sx_macsec_direction_e direction,
                                          sx_macsec_acl_counter_id_t *macsec_acl_counter_id_p)
{
    sx_macsec_acl_counter_set_params_t cmd_body;
    sx_status_t                        err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if ((cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Only Create and Destroy commands are supported, err(%s)\n", sx_status_str(err));
        goto out;
    }

    if (utils_check_pointer(macsec_acl_counter_id_p, "macsec_acl_counter_id_p")) {
        SX_LOG_ERR("macsec_acl_counter_id_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.cmd = cmd;
    if (cmd == SX_ACCESS_CMD_CREATE) {
        cmd_body.log_port = log_port;
        cmd_body.direction = direction;
    } else {
        cmd_body.counter_obj_id = *macsec_acl_counter_id_p;
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_MACSEC_ACL_COUNTER_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_macsec_acl_counter_set_params_t));
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set acl counter object, error[%s]\n", SX_STATUS_MSG(err));
        goto out;
    }

    if (cmd == SX_ACCESS_CMD_CREATE) {
        SX_MEM_CPY_P(macsec_acl_counter_id_p, &cmd_body.counter_obj_id);
    }
out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_macsec_acl_counter_get(const sx_api_handle_t             handle,
                                          const sx_access_cmd_t             cmd,
                                          const sx_macsec_acl_counter_id_t *macsec_acl_counter_id_list_p,
                                          sx_macsec_acl_counter_set_t      *macsec_acl_counter_set_list_p,
                                          uint32_t                          counter_list_len)
{
    sx_macsec_acl_counter_get_params_t *cmd_body_p = NULL;
    uint32_t                            cmd_body_size = 0;
    sx_status_t                         err = SX_STATUS_SUCCESS;
    uint32_t                            i = 0;

    SX_API_LOG_ENTER();

    if (utils_check_pointer(macsec_acl_counter_id_list_p, "macsec_acl_counter_id_list_p")) {
        SX_LOG_ERR("macsec_acl_counter_id_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    if (utils_check_pointer(macsec_acl_counter_set_list_p, "macsec_acl_counter_set_list_p")) {
        SX_LOG_ERR("macsec_acl_counter_set_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Only Read and Read Clear commands are supported, err(%s)\n", sx_status_str(err));
        goto out;
    }

    if (!counter_list_len) {
        SX_LOG(SX_LOG_NOTICE, "Event List Length is 0. Nothing to GET\n");
        goto out;
    } else if (counter_list_len > SX_MACSEC_API_CNTR_REQ_MAX) {
        SX_LOG_ERR("counter_list_len > SX_MACSEC_API_CNTR_REQ_MAX (%u)\n", SX_MACSEC_API_CNTR_REQ_MAX);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_size = sizeof(sx_macsec_acl_counter_get_params_t) +
                    (counter_list_len * sizeof(sx_macsec_acl_counter_info_t));
    if (cmd_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&cmd_body_p), 1, cmd_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->macsec_acl_cntr_list_cnt = counter_list_len;
    /* fill in the keys into the cmd_body_p */
    for (i = 0; i < counter_list_len; i++) {
        cmd_body_p->macsec_acl_cntr_key_val_list[i].counter_obj_id = macsec_acl_counter_id_list_p[i];
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MACSEC_ACL_COUNTER_GET_E,
                                      (uint8_t*)cmd_body_p,
                                      cmd_body_size);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get MACSec counter values, error[%s]\n",
                   SX_STATUS_MSG(err));
        goto out;
    }

    for (i = 0; i < cmd_body_p->macsec_acl_cntr_list_cnt; i++) {
        macsec_acl_counter_set_list_p[i].packets_counter = cmd_body_p->macsec_acl_cntr_key_val_list[i].packets_counter;
    }

out:
    if (cmd_body_p != NULL) {
        utils_memory_put(cmd_body_p, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}
