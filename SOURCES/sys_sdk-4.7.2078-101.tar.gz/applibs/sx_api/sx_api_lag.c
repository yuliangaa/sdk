/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/sx_log.h>
#include <sx/sdk/sx_api_vlan.h>
#include <complib/cl_shared_memory.h>
#include "sx_api_internal.h"
#include "ethl2/lag.h"

#undef __MODULE__
#define __MODULE__ SX_API_LAG

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

sx_status_t sx_api_lag_log_verbosity_level_set(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               const sx_verbosity_level_t      module_verbosity_level,
                                               const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_LAG_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_log_verbosity_level_get(const sx_api_handle_t           handle,
                                               const sx_log_verbosity_target_t verbosity_target,
                                               sx_verbosity_level_t           *module_verbosity_level_p,
                                               sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_LAG_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_port_group_set(const sx_api_handle_t   handle,
                                      const sx_access_cmd_t   cmd,
                                      const sx_swid_t         swid,
                                      sx_port_log_id_t       *lag_log_port_p,
                                      const sx_port_log_id_t *log_port_list_p,
                                      const uint32_t          log_port_cnt)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_api_lag_port_group_set_params_t *cmd_body_p = NULL;
    uint32_t                            cmd_size = sizeof(sx_api_lag_port_group_set_params_t);


    SX_API_LOG_ENTER();

    /* O/W: */
    if (NULL == lag_log_port_p) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }
    /* O/W: */
    switch (cmd) {
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        if (NULL == log_port_list_p) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_NULL;
        }
        /* O/W: */
        if (0 == log_port_cnt) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
        /* O/W: */
        cmd_size += (log_port_cnt) * sizeof(sx_port_log_id_t);
        if (cmd_size > MAX_CMD_SIZE) {
            SX_LOG_ERR("Command size exceeds range\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }

        M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                            "Failed to allocate cmd_body_p memory\n", rc);
        if (SX_CHECK_FAIL(rc)) {
            SX_API_LOG_EXIT();
            return rc;
        }
        /* O/W: */
        cmd_body_p->log_port_num = log_port_cnt;
        SX_MEM_CPY_ARRAY(cmd_body_p->log_port_list, log_port_list_p, log_port_cnt, sx_port_log_id_t);
        break;

    case SX_ACCESS_CMD_CREATE:
        /* Create + Add ports */
        if ((NULL != log_port_list_p) && (0 != log_port_cnt)) {
            cmd_size += (log_port_cnt) * sizeof(sx_port_log_id_t);
            if (cmd_size > MAX_CMD_SIZE) {
                SX_LOG_ERR("Command size exceeds range\n");
                SX_API_LOG_EXIT();
                return SX_STATUS_PARAM_EXCEEDS_RANGE;
            }

            M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                                "Failed to allocate cmd_body_p memory\n", rc);
            if (SX_CHECK_FAIL(rc)) {
                SX_API_LOG_EXIT();
                return rc;
            }
            /* O/W: */
            cmd_body_p->log_port_num = log_port_cnt;
            SX_MEM_CPY_ARRAY(cmd_body_p->log_port_list, log_port_list_p, log_port_cnt, sx_port_log_id_t);
        } else { /* Create LAG without ports */
            *lag_log_port_p = INVALID_LAG_ID;
            M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                                "Failed to allocate cmd_body_p memory\n", rc);
            if (SX_CHECK_FAIL(rc)) {
                SX_API_LOG_EXIT();
                return rc;
            }
        }
        break;

    case SX_ACCESS_CMD_DESTROY:

        M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                            "Failed to allocate cmd_body_p memory\n", rc);
        if (SX_CHECK_FAIL(rc)) {
            SX_API_LOG_EXIT();
            return rc;
        }

        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->swid = swid;
    cmd_body_p->lag_port = *lag_log_port_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_LAG_PORT_GROUP_SET_E, (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        lag_log_port_p[0] = cmd_body_p->lag_port;
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        rc = mem_rc;
    }

    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_lag_port_group_get(const sx_api_handle_t  handle,
                                      const sx_swid_t        swid,
                                      const sx_port_log_id_t lag_log_port,
                                      sx_port_log_id_t      *log_port_list_p,
                                      uint32_t              *log_port_cnt_p)
{
    sx_status_t                         rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_access_cmd_t                     cmd;
    sx_api_lag_port_group_get_params_t *cmd_body_p = NULL;
    uint32_t                            cmd_size = sizeof(sx_api_lag_port_group_get_params_t);

    SX_API_LOG_ENTER();

    /* O/W: */
    if (NULL == log_port_cnt_p) {
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }
    /* O/W: */
    if (NULL == log_port_list_p) {
        cmd = SX_ACCESS_CMD_COUNT;
        *log_port_cnt_p = 0;
    } else {
        if (0 == *log_port_cnt_p) {
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_EXCEEDS_RANGE;
        }
        /* O/W: */
        cmd = SX_ACCESS_CMD_GET;
        cmd_size += (*log_port_cnt_p) * sizeof(sx_port_log_id_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        SX_API_LOG_EXIT();
        return rc;
    }
    /* O/W: */
    cmd_body_p->lag_port = lag_log_port;
    cmd_body_p->cmd = cmd;
    cmd_body_p->swid = swid;
    cmd_body_p->log_port_num = *log_port_cnt_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_LAG_PORT_GROUP_GET_E, (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *log_port_cnt_p = cmd_body_p->log_port_num;
        if (NULL != log_port_list_p) {
            SX_MEM_CPY_ARRAY(log_port_list_p, cmd_body_p->log_port_list, *log_port_cnt_p, sx_port_log_id_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        SX_API_LOG_EXIT();
        return mem_rc;
    }

    /* O/W: */
    SX_API_LOG_EXIT();

    return rc;
}

sx_status_t sx_api_lag_port_group_iter_get(const sx_api_handle_t  handle,
                                           const sx_access_cmd_t  cmd,
                                           const sx_swid_t        swid,
                                           const sx_port_log_id_t lag_id,
                                           const sx_lag_filter_t *filter_p,
                                           sx_port_log_id_t      *lag_id_list_p,
                                           uint32_t              *lag_id_cnt_p)
{
    sx_api_command_head_t                    cmd_head;
    sx_api_lag_port_group_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                      reply_head;
    sx_api_lag_port_group_iter_get_params_t *reply_body = NULL;
    uint32_t                                 reply_body_size;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (lag_id_cnt_p == NULL) {
        SX_LOG_ERR("lag_id_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*lag_id_cnt_p > 0) && (lag_id_list_p == NULL)) {
        SX_LOG_ERR("*lag_id_cnt_p is not 0 but lag_id_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*lag_id_cnt_p == 0) {
            lag_id_list_p = NULL;
        } else {
            *lag_id_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*lag_id_cnt_p == 0) {
            SX_LOG_DBG("LAG ID count is 0\n");
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_lag_port_group_iter_get_params_t) +
                      (*lag_id_cnt_p * sizeof(sx_port_log_id_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_LAG_PORT_GROUP_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_lag_port_group_iter_get_params_t);
    cmd_head.list_size = *lag_id_cnt_p * sizeof(sx_port_log_id_t);

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.lag_id = lag_id;
    cmd_body.lag_id_cnt = *lag_id_cnt_p;
    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), filter_p, sx_lag_filter_t);
    }

    *lag_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->lag_id_cnt != 0) {
        *lag_id_cnt_p = reply_body->lag_id_cnt;
        if (lag_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(lag_id_list_p, reply_body->lag_id_list,
                             reply_body->lag_id_cnt, sx_port_log_id_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_port_collector_set(const sx_api_handle_t     handle,
                                          const sx_port_log_id_t    lag_log_port,
                                          const sx_port_log_id_t    log_port,
                                          const sx_collector_mode_t collector_mode)
{
    sx_api_command_head_t           cmd_head;
    sx_api_lag_port_collector_set_t cmd_body;
    sx_status_t                     err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t             reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    cmd_head.opcode = SX_API_INT_CMD_LAG_PORT_COLLECTOR_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_lag_port_collector_set_t);
    cmd_body.lag_log_port = lag_log_port;
    cmd_body.log_port = log_port;
    switch (collector_mode) {
    case COLLECTOR_ENABLE:
        cmd_body.access_cmd = SX_ACCESS_CMD_ENABLE;
        break;

    case COLLECTOR_DISABLE:
        cmd_body.access_cmd = SX_ACCESS_CMD_DISABLE;
        break;
    }
    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_port_collector_get(const sx_api_handle_t  handle,
                                          const sx_port_log_id_t lag_log_port,
                                          const sx_port_log_id_t log_port,
                                          sx_collector_mode_t   *collector_mode_p)
{
    sx_api_lag_port_collector_get_t cmd_body;
    sx_status_t                     err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (collector_mode_p == NULL) {
        SX_LOG_ERR("<collector_mode_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    cmd_body.lag_log_port = lag_log_port;
    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_LAG_PORT_COLLECTOR_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(sx_api_lag_port_collector_get_t));

    if (SX_CHECK_PASS(err)) {
        *collector_mode_p = cmd_body.collector_mode;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_port_distributor_set(const sx_api_handle_t       handle,
                                            const sx_port_log_id_t      lag_log_port,
                                            const sx_port_log_id_t      log_port,
                                            const sx_distributor_mode_t distributor_mode)
{
    sx_api_command_head_t             cmd_head;
    sx_api_lag_port_distributor_set_t cmd_body;
    sx_status_t                       err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t               reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    cmd_head.opcode = SX_API_INT_CMD_LAG_PORT_DISTRIBUTOR_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_lag_port_distributor_set_t);
    switch (distributor_mode) {
    case DISTRIBUTOR_ENABLE:
        cmd_body.access_cmd = SX_ACCESS_CMD_ENABLE;
        break;

    case DISTRIBUTOR_DISABLE:
        cmd_body.access_cmd = SX_ACCESS_CMD_DISABLE;
        break;
    }
    cmd_body.lag_log_port = lag_log_port;
    cmd_body.log_port = log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_port_distributor_get(const sx_api_handle_t  handle,
                                            const sx_port_log_id_t lag_log_port,
                                            const sx_port_log_id_t log_port,
                                            sx_distributor_mode_t *distributor_mode_p)
{
    sx_api_lag_port_distributor_get_t cmd_body;
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (distributor_mode_p == NULL) {
        SX_LOG_ERR("<distributor_mode_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }
    cmd_body.lag_log_port = lag_log_port;
    cmd_body.log_port = log_port;

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_LAG_PORT_DISTRIBUTOR_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(sx_api_lag_port_distributor_get_t));

    if (SX_CHECK_PASS(err)) {
        *distributor_mode_p = cmd_body.distributor_mode;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_hash_flow_params_set(const sx_api_handle_t handle, const sx_lag_hash_param_t *lag_hash_param_p)
{
    sx_api_command_head_t         cmd_head;
    sx_api_lag_hash_flow_params_t cmd_body;
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t           reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (lag_hash_param_p == NULL) {
        SX_LOG_ERR("<lag_hash_param_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_LAG_HASH_FLOW_PARAMS_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_lag_hash_flow_params_t);

    cmd_body.access_cmd = SX_ACCESS_CMD_SET;
    cmd_body.lag_hash_type = lag_hash_param_p->lag_hash_type;
    cmd_body.lag_hash = lag_hash_param_p->lag_hash;
    cmd_body.lag_seed = lag_hash_param_p->lag_seed;
    cmd_body.is_lag_hash_symmetric = lag_hash_param_p->is_lag_hash_symmetric;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_port_hash_flow_params_set(const sx_api_handle_t             handle,
                                                 const sx_access_cmd_t             cmd,
                                                 const sx_port_log_id_t            log_port,
                                                 const sx_lag_port_hash_params_t  *hash_params_p,
                                                 const sx_lag_hash_field_enable_t *hash_field_enable_list_p,
                                                 const uint32_t                    hash_field_enable_list_cnt,
                                                 const sx_lag_hash_field_t        *hash_field_list_p,
                                                 const uint32_t                    hash_field_list_cnt)
{
    sx_api_lag_port_hash_params_t *cmd_body = NULL;
    sx_api_command_head_t          cmd_head;
    uint32_t                       cmd_body_size = 0;
    uint32_t                       dynamic_size = 0;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    out_err = SX_STATUS_SUCCESS;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if ((hash_field_list_cnt > 0) && (NULL == hash_field_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("LAG port hash_field_list_p param is NULL while hash_field_list_cnt (=%d) > 0\n",
                   hash_field_list_cnt);
        goto out;
    }

    if ((hash_field_enable_list_cnt > 0) && (NULL == hash_field_enable_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("LAG port hash_field_enable_list_p param is NULL while hash_field_enable_list_cnt (=%d) > 0\n",
                   hash_field_enable_list_cnt);
        goto out;
    }
    if (hash_field_enable_list_cnt > SX_LAG_HASH_FIELD_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("LAG port hash_field_enable_list_cnt (=%d) exceeds range (=%d)\n",
                   hash_field_enable_list_cnt,
                   SX_LAG_HASH_FIELD_ENABLES_NUM);
        goto out;
    }
    if (hash_field_list_cnt > SX_LAG_HASH_FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("LAG port hash_field_list_cnt (=%d) exceeds range (=%d)\n",
                   hash_field_list_cnt,
                   SX_LAG_HASH_FIELDS_NUM);
        goto out;
    }

    dynamic_size = hash_field_list_cnt * sizeof(sx_lag_hash_field_t);
    if (dynamic_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body,
                        1,
                        sizeof(sx_api_lag_port_hash_params_t) + dynamic_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for LAG port hash params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    /* Allocate the field list and field list arrays in the command body */
    if (hash_field_list_cnt > 0) {
        SX_MEM_CPY_ARRAY(cmd_body->hash_field_list_p,
                         hash_field_list_p,
                         hash_field_list_cnt,
                         sx_lag_hash_field_t);
    }

    if (hash_field_enable_list_cnt > 0) {
        SX_MEM_CPY_ARRAY(cmd_body->hash_field_enable_list_p,
                         hash_field_enable_list_p,
                         hash_field_enable_list_cnt,
                         sx_lag_hash_field_enable_t);
    }

    cmd_body->cmd = cmd;
    cmd_body->log_port = log_port;
    cmd_body->hash_params = *hash_params_p;
    cmd_body->hash_field_enable_list_cnt = hash_field_enable_list_cnt;
    cmd_body->hash_field_list_cnt = hash_field_list_cnt;
    cmd_body_size = sizeof(*cmd_body) + dynamic_size;

    cmd_head.opcode = SX_API_INT_CMD_LAG_PORT_HASH_FLOW_PARAMS_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + cmd_body_size;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)cmd_body,
                                        &reply_head, NULL, 0);

out:
    if (NULL != cmd_body) {
        M_UTILS_MEM_PUT(cmd_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free LAG port hash API params",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_lag_hash_flow_params_get(const sx_api_handle_t handle, sx_lag_hash_param_t   *lag_hash_param_p)
{
    sx_api_lag_hash_flow_params_t cmd_body;
    sx_status_t                   err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (lag_hash_param_p == NULL) {
        SX_LOG_ERR("<lag_hash_param_p> param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    cmd_body.access_cmd = SX_ACCESS_CMD_GET;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_LAG_HASH_FLOW_PARAMS_GET_E, (uint8_t*)&cmd_body,
                                      sizeof(sx_api_lag_hash_flow_params_t));

    if (SX_CHECK_PASS(err)) {
        lag_hash_param_p->lag_hash_type = cmd_body.lag_hash_type;
        lag_hash_param_p->lag_hash = cmd_body.lag_hash;
        lag_hash_param_p->lag_seed = cmd_body.lag_seed;
        lag_hash_param_p->is_lag_hash_symmetric = cmd_body.is_lag_hash_symmetric;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_port_hash_flow_params_get(const sx_api_handle_t       handle,
                                                 const sx_port_log_id_t      log_port,
                                                 sx_lag_port_hash_params_t  *hash_params_p,
                                                 sx_lag_hash_field_enable_t *hash_field_enable_list_p,
                                                 uint32_t                   *hash_field_enable_list_cnt_p,
                                                 sx_lag_hash_field_t        *hash_field_list_p,
                                                 uint32_t                   *hash_field_list_cnt_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_lag_port_hash_params_t  cmd_body;
    sx_api_lag_port_hash_params_t *reply_body = NULL;
    sx_api_reply_head_t            reply_head;
    uint32_t                       reply_body_size = 0;
    sx_status_t                    out_err = SX_STATUS_SUCCESS;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (NULL == hash_field_list_cnt_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hash_field_list_cnt param is NULL\n");
        goto out;
    }

    if ((*hash_field_list_cnt_p > 0) && (NULL == hash_field_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hash_field_list_p param is NULL\n");
        goto out;
    }

    if (NULL == hash_field_enable_list_cnt_p) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hash_field_enable_list_cnt param is NULL\n");
        goto out;
    }

    if ((*hash_field_enable_list_cnt_p > 0) && (NULL == hash_field_enable_list_p)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("hash_field_enable_list_p param is NULL\n");
        goto out;
    }

    if (*hash_field_enable_list_cnt_p > SX_LAG_HASH_FIELD_ENABLES_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hash_field_enable_list_cnt_p (=%d) exceeds range(=%d)\n",
                   *hash_field_enable_list_cnt_p,
                   SX_LAG_HASH_FIELD_ENABLES_NUM);
        goto out;
    }

    if (*hash_field_list_cnt_p > SX_LAG_HASH_FIELDS_NUM) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("hash_field_list_cnt_p (=%d) exceeds range(=%d)\n", *hash_field_list_cnt_p, SX_LAG_HASH_FIELDS_NUM);
        goto out;
    }

    reply_body_size = sizeof(sx_api_lag_port_hash_params_t) +
                      ((*hash_field_list_cnt_p) * sizeof(sx_lag_hash_field_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /* Allocate the field list and field list arrays in the command body */
    M_UTILS_CLR_MEM_GET(&reply_body,
                        1,
                        reply_body_size,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate memory for LAG port hash params.\n",
                        err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    cmd_body.log_port = log_port;
    cmd_body.hash_field_enable_list_cnt = *hash_field_enable_list_cnt_p;
    cmd_body.hash_field_list_cnt = *hash_field_list_cnt_p;

    cmd_head.opcode = SX_API_INT_CMD_LAG_PORT_HASH_FLOW_PARAMS_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_lag_port_hash_params_t);
    cmd_head.list_size = (*hash_field_list_cnt_p) * sizeof(sx_lag_hash_field_t);

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body, reply_body_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    *hash_params_p = reply_body->hash_params;
    *hash_field_list_cnt_p = reply_body->hash_field_list_cnt;
    if (*hash_field_list_cnt_p > 0) {
        if (hash_field_list_p != NULL) {
            SX_MEM_CPY_ARRAY(hash_field_list_p,
                             reply_body->hash_field_list_p,
                             *hash_field_list_cnt_p,
                             sx_lag_hash_field_t);
        }
    }
    *hash_field_enable_list_cnt_p = reply_body->hash_field_enable_list_cnt;
    if (*hash_field_enable_list_cnt_p > 0) {
        if (hash_field_enable_list_p != NULL) {
            SX_MEM_CPY_ARRAY(hash_field_enable_list_p,
                             reply_body->hash_field_enable_list_p,
                             *hash_field_enable_list_cnt_p,
                             sx_lag_hash_field_enable_t);
        }
    }

out:
    if (NULL != reply_body) {
        M_UTILS_MEM_PUT(reply_body,
                        UTILS_MEM_TYPE_ID_API_E,
                        "Failed to free LAG port hash API params",
                        out_err);
        if ((!SX_CHECK_FAIL(err)) && SX_CHECK_FAIL(out_err)) {
            err = out_err;
        }
    }

    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_lag_redirect_set(const sx_api_handle_t  handle,
                                    const sx_access_cmd_t  cmd,
                                    const sx_port_log_id_t lag_log_port,
                                    const sx_port_log_id_t redirect_lag_log_port)
{
    sx_api_command_head_t            cmd_head;
    sx_api_lag_redirect_set_params_t cmd_body;
    sx_status_t                      err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t              reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_LAG_REDIRECT_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_lag_redirect_set_params_t);

    cmd_body.access_cmd = cmd;
    cmd_body.lag_port = lag_log_port;
    cmd_body.redirect_lag_port = redirect_lag_log_port;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_redirect_get(const sx_api_handle_t  handle,
                                    const sx_port_log_id_t lag_log_port,
                                    boolean_t             *is_redirected_p,
                                    sx_port_log_id_t      *redirected_lag_log_port_p)
{
    sx_api_lag_redirect_get_params_t cmd_body;
    sx_status_t                      err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (is_redirected_p == NULL) {
        SX_LOG_ERR("is_redirected_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (redirected_lag_log_port_p == NULL) {
        SX_LOG_ERR("redirected_lag_log_port_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    cmd_body.lag_port = lag_log_port;

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_LAG_REDIRECT_GET_E, (uint8_t*)&cmd_body,
                                      sizeof(sx_api_lag_redirect_get_params_t));

    if (SX_CHECK_PASS(err)) {
        *is_redirected_p = cmd_body.is_redirected;
        *redirected_lag_log_port_p = cmd_body.redirected_lag_port;
    }

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_lag_redirected_lags_get(const sx_api_handle_t  handle,
                                           const sx_port_log_id_t lag_log_port,
                                           sx_port_log_id_t      *lag_log_port_list_p,
                                           uint32_t              *lag_log_port_cnt_p)
{
    sx_status_t                              sx_status = SX_STATUS_SUCCESS;
    sx_status_t                              sx_status_mem = SX_STATUS_SUCCESS;
    sx_api_lag_redirected_lags_get_params_t *cmd_body_p = NULL;
    uint32_t                                 cmd_size = sizeof(sx_api_lag_redirected_lags_get_params_t);
    sx_access_cmd_t                          access_cmd;

    SX_API_LOG_ENTER();

    if (lag_log_port_cnt_p == NULL) {
        SX_LOG_ERR("lag_log_port_cnt_p is NULL.\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_NULL;
    }

    if (lag_log_port_list_p == NULL) {
        access_cmd = SX_ACCESS_CMD_COUNT;
        *lag_log_port_cnt_p = 0;
    } else {
        if (0 == *lag_log_port_cnt_p) {
            SX_LOG_ERR("Requested number of LAGs is 0.\n");
            SX_API_LOG_EXIT();
            return SX_STATUS_PARAM_ERROR;
        }
        access_cmd = SX_ACCESS_CMD_GET;

        cmd_size += (*lag_log_port_cnt_p) * sizeof(sx_port_log_id_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_EXCEEDS_RANGE;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory.\n", sx_status);
    if (SX_CHECK_FAIL(sx_status)) {
        SX_API_LOG_EXIT();
        return sx_status;
    }

    cmd_body_p->lag_port = lag_log_port;
    cmd_body_p->lag_num = *lag_log_port_cnt_p;
    cmd_body_p->access_cmd = access_cmd;

    sx_status = sx_api_send_command_wrapper(handle,
                                            SX_API_INT_CMD_LAG_REDIRECTED_LAGS_GET_E,
                                            (uint8_t*)cmd_body_p,
                                            cmd_size);

    if (SX_CHECK_PASS(sx_status)) {
        *lag_log_port_cnt_p = cmd_body_p->lag_num;
        if (lag_log_port_list_p != NULL) {
            SX_MEM_CPY_ARRAY(lag_log_port_list_p, cmd_body_p->lag_list, *lag_log_port_cnt_p, sx_port_log_id_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free.", sx_status_mem);
    if (SX_CHECK_FAIL(sx_status_mem)) {
        SX_API_LOG_EXIT();
        return sx_status_mem;
    }

    SX_API_LOG_EXIT();
    return sx_status;
}

sx_status_t sx_api_lag_distributer_list_set(const sx_api_handle_t             handle,
                                            const sx_access_cmd_t             access_cmd,
                                            const sx_port_log_id_t            lag_log_port,
                                            const sx_lag_fine_grain_params_t *params_p,
                                            const sx_lag_fine_grain_member_t *port_list_p,
                                            const uint32_t                    port_cnt)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_api_lag_distributor_list_set_params_t *cmd_body_p = NULL;
    uint32_t                                  cmd_size = sizeof(sx_api_lag_distributor_list_set_params_t);
    uint32_t                                  cmd_port_cnt = 0;

    SX_API_LOG_ENTER();

    switch (access_cmd) {
    case SX_ACCESS_CMD_SET:
        if (params_p == NULL) {
            SX_LOG_ERR("params_p is NULL.\n");
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }

    /* fall through */
    case SX_ACCESS_CMD_ADD:
    case SX_ACCESS_CMD_DELETE:
        if (port_list_p == NULL) {
            SX_LOG_ERR("port_list_p is NULL.\n");
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }
        cmd_size += (port_cnt) * sizeof(sx_lag_fine_grain_member_t);
        cmd_port_cnt = port_cnt;
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        cmd_port_cnt = 0;
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(access_cmd));
        rc = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    cmd_body_p->port_cnt = cmd_port_cnt;
    cmd_body_p->access_cmd = access_cmd;
    cmd_body_p->lag_port = lag_log_port;
    if (access_cmd == SX_ACCESS_CMD_SET) {
        SX_MEM_CPY(cmd_body_p->params, *params_p);
    }
    SX_MEM_CPY_ARRAY(cmd_body_p->port_list_p, port_list_p, cmd_body_p->port_cnt, sx_lag_fine_grain_member_t);

    rc =
        sx_api_send_command_wrapper(handle, SX_API_INT_CMD_LAG_DISTRIBUTER_LIST_SET_E, (uint8_t*)cmd_body_p, cmd_size);


out:
    if (cmd_body_p != NULL) {
        M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", mem_rc);
    }
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_api_lag_distributer_list_get(const sx_api_handle_t       handle,
                                            const sx_port_log_id_t      lag_log_port,
                                            sx_lag_fine_grain_params_t *params_p,
                                            sx_lag_fine_grain_member_t *port_list_p,
                                            uint32_t                   *port_cnt_p)
{
    sx_status_t                               rc = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_api_lag_distributor_list_get_params_t *cmd_body_p = NULL;
    uint32_t                                  cmd_size = sizeof(sx_api_lag_distributor_list_get_params_t);

    SX_API_LOG_ENTER();

    if (port_cnt_p == NULL) {
        SX_LOG_ERR("port_cnt_p is NULL.\n");
        rc = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (*port_cnt_p == 0) {
        port_list_p = NULL;
    } else {
        if (port_list_p == NULL) {
            SX_LOG_ERR("port_list_p is NULL.\n");
            rc = SX_STATUS_PARAM_NULL;
            goto out;
        }
    }

    cmd_size += (*port_cnt_p) * sizeof(sx_lag_fine_grain_member_t);
    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory.\n", rc);
    if (SX_CHECK_FAIL(rc)) {
        goto out;
    }

    cmd_body_p->lag_port = lag_log_port;
    cmd_body_p->port_cnt = *port_cnt_p;

    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_LAG_DISTRIBUTER_LIST_GET_E,
                                     (uint8_t*)cmd_body_p,
                                     cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *port_cnt_p = cmd_body_p->port_cnt;
        if (port_list_p != NULL) {
            SX_MEM_CPY_ARRAY(port_list_p, cmd_body_p->port_list_p, *port_cnt_p, sx_lag_fine_grain_member_t);
        }
        if (params_p != NULL) {
            SX_MEM_CPY(*params_p, cmd_body_p->params);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free.", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        rc = mem_rc;
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}
