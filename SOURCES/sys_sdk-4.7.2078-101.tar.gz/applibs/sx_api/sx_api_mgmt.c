/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include <complib/sx_log.h>
#include <sx/sdk/sx_api_mgmt.h>
#include "sx_api_internal.h"
#include <complib/cl_mem.h>

#undef __MODULE__
#define __MODULE__ SX_API_MGMT

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

sx_status_t sx_mgmt_log_verbosity_level_set(const sx_api_handle_t           handle,
                                            const sx_log_verbosity_target_t verbosity_target,
                                            const sx_verbosity_level_t      module_verbosity_level,
                                            const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        rc = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        rc = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_MGMT_LIB_VERBOSITY_SET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        rc = sx_api_send_command_decoupled(handle, &cmd_head,
                                           (uint8_t*)&cmd_body, &reply_head,
                                           NULL, 0);
        if (SX_CHECK_FAIL(rc)) {
            SX_LOG_ERR("Failed to set verbosity level\n");
            goto out;
        }
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_mgmt_log_verbosity_level_get(const sx_api_handle_t           handle,
                                            const sx_log_verbosity_target_t verbosity_target,
                                            sx_verbosity_level_t           *module_verbosity_level_p,
                                            sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    rc = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) || (verbosity_target
                                                              == SX_LOG_VERBOSITY_BOTH)) {
        rc = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) || (verbosity_target
                                                                 == SX_LOG_VERBOSITY_BOTH)) {
        rc = utils_check_pointer(module_verbosity_level_p,
                                 "module_verbosity_level");
        if (SX_CHECK_FAIL(rc)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_MGMT_LIB_VERBOSITY_GET_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t)
                            + sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        rc = sx_api_send_command_wrapper(
            handle, cmd_head.opcode, (uint8_t*)&cmd_body,
            sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_mgmt_slot_info_get(const sx_api_handle_t handle,
                                  const sx_slot_id_t   *slot_id_list_p,
                                  sx_mgmt_slot_info_t  *slot_info_list_p,
                                  uint32_t             *slot_list_size_p)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_mgmt_slot_info_get_params_t cmd_body;
    uint8_t                       *cmd_body_buffer_p = NULL;
    uint32_t                       cmd_body_buffer_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR_TYPE(&cmd_body, sx_mgmt_slot_info_get_params_t);

    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Failed to retrieve slot info, Invalid handle\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(slot_list_size_p, "slot_list_size_p"))) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Failed to retrieve slot info, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (*slot_list_size_p > RM_API_SLOT_MAX_NUM) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to retrieve slot info, slot id list exceeds max allowed slots, error[%s]\n",
                   SX_STATUS_MSG(rc));
        goto out;
    }

    cmd_body.slot_list_size = *slot_list_size_p;

    if (*slot_list_size_p != 0) {
        if (SX_CHECK_FAIL(rc = utils_check_pointer(slot_id_list_p, "slot_id_list_p"))) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Failed to retrieve slot info, error[%s]\n", SX_STATUS_MSG(rc));
            goto out;
        }

        if (SX_CHECK_FAIL(rc = utils_check_pointer(slot_info_list_p, "slot_info_list_p"))) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Failed to retrieve slot info, error[%s]\n", SX_STATUS_MSG(rc));
            goto out;
        }

        /* Allocate buffer for slot id list */
        cmd_body.slot_id_list_p = (sx_slot_id_t*)cl_calloc(*slot_list_size_p, sizeof(sx_slot_id_t));
        if (!cmd_body.slot_id_list_p) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Retrieve slot info, failed to allocate memory for slot id list array.\n");
            goto out;
        }
        /* Allocate buffer for slot info list */
        cmd_body.slot_info_list_p = (sx_mgmt_slot_info_t*)cl_calloc(*slot_list_size_p, sizeof(sx_mgmt_slot_info_t));
        if (!cmd_body.slot_info_list_p) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Retrieve slot info, failed to allocate memory for slot info list array.\n");
            goto out;
        }

        SX_MEM_CPY_ARRAY(cmd_body.slot_id_list_p, slot_id_list_p, *slot_list_size_p, sx_slot_id_t);
    }

    /* Buffer size
     * sx_mgmt_slot_info_get_params_t                : get params size
     * slot_list_size * sizeof(sx_slot_id_t)         : slot_id_list
     * slot_list_size * sizeof(sx_mgmt_slot_info_t)  : slot_info_list
     */
    cmd_body_buffer_size = sizeof(sx_mgmt_slot_info_get_params_t) +
                           cmd_body.slot_list_size * sizeof(sx_slot_id_t) +
                           cmd_body.slot_list_size * sizeof(sx_mgmt_slot_info_t);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_buffer_p = (uint8_t*)cl_malloc(cmd_body_buffer_size);
    if (!cmd_body_buffer_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Retrieve slot info, failed to allocate memory for the command body buffer.\n");
        goto out;
    }

    rc = sx_api_serialize_slot_info_get_params(&cmd_body, cmd_body_buffer_p, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Retrieve slot info, failed to serialize slot information get params.\n");
        goto out;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MGMT_LIB_SLOT_INFO_GET_E,
                                     (uint8_t*)cmd_body_buffer_p, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed sx management slot information get API, err[%s]\n", sx_status_str(rc));
        goto out;
    }

    rc = sx_api_deserialize_slot_info_get_params(cmd_body_buffer_p, &cmd_body);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deserialize slot information get params.\n");
        goto out;
    }

    if (*slot_list_size_p) {
        SX_MEM_CPY_ARRAY(slot_info_list_p, cmd_body.slot_info_list_p,
                         cmd_body.slot_list_size, sx_mgmt_slot_info_t);
    }

    *slot_list_size_p = cmd_body.slot_count;

out:
    if (cmd_body.slot_info_list_p) {
        CL_FREE_N_NULL(cmd_body.slot_info_list_p);
    }

    if (cmd_body.slot_id_list_p) {
        CL_FREE_N_NULL(cmd_body.slot_id_list_p);
    }

    if (cmd_body_buffer_p) {
        CL_FREE_N_NULL(cmd_body_buffer_p);
    }

    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_mgmt_slot_ini_operation_set(const sx_api_handle_t                handle,
                                           const sx_slot_id_t                   slot_id,
                                           const sx_mgmt_slot_ini_operation_e   operation,
                                           sx_mgmt_slot_ini_operation_result_t *ini_operation_result_p)
{
    sx_status_t                             rc = SX_STATUS_SUCCESS;
    sx_mgmt_slot_ini_operation_set_params_t cmd_body;
    uint8_t                                *cmd_body_buffer_p = NULL;
    uint32_t                                cmd_body_buffer_size = 0;
    uint32_t                                port_count = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR_TYPE(&cmd_body, sx_mgmt_slot_ini_operation_set_params_t);

    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Failed slot[%u] ini operation set, Invalid handle\n", slot_id);
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(ini_operation_result_p, "ini_operation_result_p"))) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Failed slot[%u] ini operation set, error[%s]\n", slot_id, SX_STATUS_MSG(rc));
        goto out;
    }

    port_count = ini_operation_result_p->port_info.port_attr_list_size;
    if (port_count > RM_API_LOCAL_PORT_MAX) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR(
            "Failed slot[%u] ini operation set, port mapping changes list size exceeds max allowed size, error[%s]\n",
            slot_id, SX_STATUS_MSG(rc));
        goto out;
    }

    if (port_count != 0) {
        /* Non zero port count, validate attribute list */
        if (SX_CHECK_FAIL(rc =
                              utils_check_pointer(ini_operation_result_p->port_info.port_attr_list_p,
                                                  "port_attr_list_p"))) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Failed slot[%u] ini operation, error[%s]\n", slot_id, SX_STATUS_MSG(rc));
            goto out;
        }

        cmd_body.ini_operation_result.port_info.port_attr_list_p = cl_calloc(port_count, sizeof(sx_port_attributes_t));
        if (!cmd_body.ini_operation_result.port_info.port_attr_list_p) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Slot[%u] ini operation, failed to allocate memory for the port mapping list array.\n",
                       slot_id);
            goto out;
        }
    }

    /* Buffer size
     * set params                                : sx_mgmt_slot_ini_operation_set_params_t
     * port_count * sizeof(sx_port_attributes_t) : port_mapping_list
     */
    cmd_body_buffer_size = sizeof(sx_mgmt_slot_ini_operation_set_params_t)
                           + port_count * sizeof(sx_port_attributes_t);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_buffer_p = (uint8_t*)cl_malloc(cmd_body_buffer_size);
    if (!cmd_body_buffer_p) {
        SX_LOG_ERR("Slot[%u] ini operation, failed to allocate memory for the command body buffer.\n", slot_id);
        rc = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_body.slot_id = slot_id;
    cmd_body.operation = operation;
    cmd_body.ini_operation_result.port_info.port_attr_list_size = port_count;

    /* Serialize the information */
    rc = sx_api_serialize_slot_ini_oper_set_params(&cmd_body, cmd_body_buffer_p, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Slot[%u] ini operation, failed to serialize ini oper set params.\n", slot_id);
        goto out;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MGMT_LIB_INI_OPERATION_SET_E,
                                     (uint8_t*)cmd_body_buffer_p, cmd_body_buffer_size);

    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to set INI oper slot[%u], error [%s]\n", slot_id, sx_status_str(rc));
        goto out;
    }

    rc = sx_api_deserialize_slot_ini_oper_set_params(cmd_body_buffer_p, &cmd_body);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Slot[%u] ini operation, failed to deserialize ini oper set params.\n", slot_id);
        goto out;
    }

    ini_operation_result_p->ini_status = cmd_body.ini_operation_result.ini_status;
    ini_operation_result_p->slot_state_info = cmd_body.ini_operation_result.slot_state_info;
    ini_operation_result_p->port_info.port_attr_list_size =
        cmd_body.ini_operation_result.port_info.port_attr_list_size;
    ini_operation_result_p->port_info.port_count = cmd_body.ini_operation_result.port_info.port_count;

    if (ini_operation_result_p->port_info.port_attr_list_p != NULL) {
        /* copy port attributes as per buffer size given */
        SX_MEM_CPY_ARRAY(ini_operation_result_p->port_info.port_attr_list_p,
                         cmd_body.ini_operation_result.port_info.port_attr_list_p,
                         cmd_body.ini_operation_result.port_info.port_attr_list_size,
                         sx_port_attributes_t);
    }
out:
    if (port_count != 0) {
        if (cmd_body.ini_operation_result.port_info.port_attr_list_p) {
            CL_FREE_N_NULL(cmd_body.ini_operation_result.port_info.port_attr_list_p);
        }
    }

    if (cmd_body_buffer_p) {
        CL_FREE_N_NULL(cmd_body_buffer_p);
    }
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_mgmt_slot_ini_data_set(const sx_api_handle_t               handle,
                                      const sx_slot_id_t                  slot_id,
                                      const sx_mgmt_slot_ini_data_t      *data_p,
                                      sx_mgmt_slot_ini_transfer_result_t *ini_transfer_result_p)
{
    sx_status_t                        rc = SX_STATUS_SUCCESS;
    sx_mgmt_slot_ini_data_set_params_t cmd_body;
    uint32_t                           cmd_size = sizeof(sx_mgmt_slot_ini_data_set_params_t);

    SX_API_LOG_ENTER();

    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Slot[%u], failed ini data transfer, Invalid handle\n", slot_id);
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(data_p, "data_p"))) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Slot[%u], failed ini data transfer, error[%s]\n", slot_id, SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(ini_transfer_result_p, "ini_transfer_result_p"))) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Slot[%u], failed ini data transfer, error[%s]\n", slot_id, SX_STATUS_MSG(rc));
        goto out;
    }

    if (data_p->ini_data_size > SX_MGMT_MAX_INI_DATA_SIZE) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Slot[%u], failed ini data transfer, ini data size exceeds max allowed size, error[%s]\n",
                   slot_id, SX_STATUS_MSG(rc));
        goto out;
    }

    SX_MEM_CLR(cmd_body);
    cmd_body.slot_id = slot_id;
    cmd_body.data = *data_p;

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MGMT_LIB_INI_DATA_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Slot[%u], failed to set ini data, error[%s]\n", slot_id, SX_STATUS_MSG(rc));
        goto out;
    }

    SX_MEM_CPY_P(ini_transfer_result_p, &cmd_body.ini_transfer_result);

out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_mgmt_slot_state_info_get(const sx_api_handle_t      handle,
                                        const sx_slot_id_t        *slot_id_list_p,
                                        sx_mgmt_slot_state_info_t *slot_state_info_list_p,
                                        uint32_t                  *slot_list_size_p)
{
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    sx_mgmt_slot_state_info_get_params_t cmd_body;
    uint8_t                             *cmd_body_buffer_p = NULL;
    uint32_t                             cmd_body_buffer_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR_TYPE(&cmd_body, sx_mgmt_slot_state_info_get_params_t);
    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Failed to retrieve slot info, Invalid handle\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(slot_list_size_p, "slot_list_size_p"))) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Failed to retrieve slot info, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (*slot_list_size_p > RM_API_SLOT_MAX_NUM) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to retrieve slot state info, slot id list exceeds max allowed slots, error[%s]\n",
                   SX_STATUS_MSG(rc));
        goto out;
    }

    if (*slot_list_size_p != 0) {
        if (SX_CHECK_FAIL(rc = utils_check_pointer(slot_id_list_p, "slot_id_list_p"))) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Failed to retrieve slot info, error[%s]\n", SX_STATUS_MSG(rc));
            goto out;
        }

        if (SX_CHECK_FAIL(rc = utils_check_pointer(slot_state_info_list_p, "slot_state_info_list_p"))) {
            rc = SX_STATUS_PARAM_NULL;
            SX_LOG_ERR("Failed to retrieve slot info, error[%s]\n", SX_STATUS_MSG(rc));
            goto out;
        }
    }

    cmd_body.slot_list_size = *slot_list_size_p;

    if (*slot_list_size_p != 0) {
        /* Allocate buffer for slot id list */
        cmd_body.slot_id_list_p = (sx_slot_id_t*)cl_calloc(*slot_list_size_p, sizeof(sx_slot_id_t));
        if (!cmd_body.slot_id_list_p) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Retrieve slot info, failed to allocate memory for slot id list array.\n");
            goto out;
        }
        /* Allocate buffer for slot info list */
        cmd_body.slot_state_info_list_p =
            (sx_mgmt_slot_state_info_t*)cl_calloc(*slot_list_size_p, sizeof(sx_mgmt_slot_state_info_t));
        if (!cmd_body.slot_state_info_list_p) {
            rc = SX_STATUS_NO_MEMORY;
            SX_LOG_ERR("Retrieve slot info, failed to allocate memory for slot info list array.\n");
            goto out;
        }
        SX_MEM_CPY_ARRAY(cmd_body.slot_id_list_p, slot_id_list_p, *slot_list_size_p, sx_slot_id_t);
    }

    /* Buffer size =
     * 4 bytes                                              : slot_count
     * 4 bytes                                              : slot_list_size
     * sx_mgmt_slot_state_info_get_params_t                 : get params size
     * slot_list_size * sizeof(sx_slot_id_t)                : slot_id_list
     * slot_list_size * sizeof(sx_mgmt_slot_state_info_t)   : slot_state_info_list
     */
    cmd_body_buffer_size = sizeof(sx_mgmt_slot_state_info_get_params_t) +
                           cmd_body.slot_list_size * sizeof(sx_slot_id_t) +
                           cmd_body.slot_list_size * sizeof(sx_mgmt_slot_state_info_t);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_buffer_p = (uint8_t*)cl_malloc(cmd_body_buffer_size);
    if (!cmd_body_buffer_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Retrieve slot info, failed to allocate memory for the command body buffer.\n");
        goto out;
    }

    rc = sx_api_serialize_slot_state_info_get_params(&cmd_body, cmd_body_buffer_p, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Retrieve slot info, failed to serialize slot state information get params.\n");
        goto out;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MGMT_LIB_SLOT_STATE_INFO_GET_E,
                                     (uint8_t*)cmd_body_buffer_p, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Retrieve slot info, failed to send slot state information get command.\n");
        goto out;
    }

    rc = sx_api_deserialize_slot_state_info_get_params(cmd_body_buffer_p, &cmd_body);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Retrieve slot info, failed to deserialize slot state information get params.\n");
        goto out;
    }

    if (*slot_list_size_p) {
        SX_MEM_CPY_ARRAY(slot_state_info_list_p, cmd_body.slot_state_info_list_p,
                         cmd_body.slot_list_size, sx_mgmt_slot_state_info_t);
    }

    *slot_list_size_p = cmd_body.slot_count;


out:
    if (cmd_body.slot_state_info_list_p) {
        CL_FREE_N_NULL(cmd_body.slot_state_info_list_p);
    }

    if (cmd_body.slot_id_list_p) {
        CL_FREE_N_NULL(cmd_body.slot_id_list_p);
    }

    if (cmd_body_buffer_p) {
        CL_FREE_N_NULL(cmd_body_buffer_p);
    }


    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_mgmt_slot_control_set(const sx_api_handle_t              handle,
                                     const sx_slot_id_t                 slot_id,
                                     const sx_mgmt_slot_control_info_t *slot_control_info_p)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_mgmt_slot_control_set_params_t cmd_body;
    uint32_t                          cmd_size = sizeof(sx_mgmt_slot_control_set_params_t);

    SX_API_LOG_ENTER();

    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Failed to set slot[%u] control state,Invalid handle\n", slot_id);
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(slot_control_info_p, "slot_control_info_p"))) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Slot[%u], failed to set slot control state, error[%s]\n", slot_id, SX_STATUS_MSG(rc));
        goto out;
    }

    SX_MEM_CLR(cmd_body);
    cmd_body.slot_id = slot_id;
    cmd_body.slot_control_info = *slot_control_info_p;
    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_MGMT_LIB_SLOT_CONTROL_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Slot[%u], failed to set slot control state, error[%s]\n", slot_id, SX_STATUS_MSG(rc));
    }

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_mgmt_phy_module_split_get(const sx_api_handle_t                    handle,
                                         const sx_mgmt_module_id_info_t          *module_id_info_p,
                                         const sx_mgmt_phy_module_split_params_t *split_params_p,
                                         sx_mgmt_phy_module_split_info_t         *split_info_p)
{
    sx_status_t                                rc = SX_STATUS_SUCCESS;
    sx_mgmt_phy_module_split_info_get_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Failed to retrieve module split information, Invalid handle\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(module_id_info_p, "module_id_info_p"))) {
        SX_LOG_ERR("Failed to retrieve module split information, param module_id_info_p error[%s]\n",
                   SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(split_params_p, "split_params_p"))) {
        SX_LOG_ERR("Failed to retrieve module split information, param split_params_p error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(split_info_p, "split_info_p"))) {
        SX_LOG_ERR("Failed to retrieve module split information, param split_info_p error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    SX_MEM_CLR(cmd_body);
    cmd_body.module_id_info = *module_id_info_p;
    cmd_body.split_params = *split_params_p;
    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_MGMT_LIB_PHY_MODULE_SPLIT_INFO_GET_E,
                                     (uint8_t*)&cmd_body, sizeof(cmd_body));
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to retrieve module split information error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    SX_MEM_CPY_P(split_info_p, &(cmd_body.split_info));
out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_mgmt_phy_module_info_get(const sx_api_handle_t           handle,
                                        const sx_mgmt_module_id_info_t *module_id_info_list_p,
                                        const uint32_t                  list_size,
                                        sx_mgmt_phy_module_info_t      *module_info_list_p)
{
    sx_status_t                          rc = SX_STATUS_SUCCESS;
    sx_mgmt_phy_module_info_get_params_t cmd_body;
    uint8_t                             *cmd_body_buffer = NULL;
    uint32_t                             cmd_body_buffer_size = 0;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_body);

    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Failed to retrieve module information, Invalid handle\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (list_size == 0) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to retrieve module information, incorrect list size error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }


    if (SX_CHECK_FAIL(rc = utils_check_pointer(module_id_info_list_p, "module_id_info_list_p"))) {
        SX_LOG_ERR("Failed to retrieve module information, module_id_info_list_p error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(module_info_list_p, "module_info_list_p"))) {
        SX_LOG_ERR("Failed to get module information, module_info_list_p error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    SX_MEM_CLR_TYPE(&cmd_body, sx_mgmt_phy_module_info_get_params_t);
    cmd_body.list_size = list_size;

    cmd_body.module_id_info_list_p = (sx_mgmt_module_id_info_t*)cl_calloc(list_size, sizeof(sx_mgmt_module_id_info_t));
    if (!cmd_body.module_id_info_list_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for module id info list array.\n");
        goto out;
    }

    SX_MEM_CPY_ARRAY(cmd_body.module_id_info_list_p, module_id_info_list_p, list_size, sx_mgmt_module_id_info_t);

    cmd_body.module_info_list_p = (sx_mgmt_phy_module_info_t*)cl_calloc(list_size, sizeof(sx_mgmt_phy_module_info_t));
    if (!cmd_body.module_info_list_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for module info list array.\n");
        goto out;
    }

    /* Buffer size
     * sx_mgmt_phy_module_info_get_params_t                 : module_info_get_params
     * list_size * sizeof(sx_mgmt_module_id_info_t)         : module_id_info list
     * list_size * sizeof(sx_mgmt_phy_module_info_t)        : module_info_list
     */
    cmd_body_buffer_size = sizeof(sx_mgmt_phy_module_info_get_params_t) +
                           cmd_body.list_size * sizeof(sx_mgmt_module_id_info_t) +
                           cmd_body.list_size * sizeof(sx_mgmt_phy_module_info_t);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_buffer = (uint8_t*)cl_malloc(cmd_body_buffer_size);
    if (!cmd_body_buffer) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for the command body buffer.\n");
        goto out;
    }

    rc = sx_api_serialize_phy_module_info_get_params(&cmd_body, cmd_body_buffer, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to serialize phy module information get params.\n");
        goto out;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MGMT_LIB_PHY_MODULE_INFO_GET_E,
                                     (uint8_t*)cmd_body_buffer, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed sx management phy module information get API, err;%s\n", sx_status_str(rc));
        goto out;
    }

    rc = sx_api_deserialize_phy_module_info_get_params(cmd_body_buffer, &cmd_body);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deserialize phy module information get params.\n");
        goto out;
    }

    SX_MEM_CPY_ARRAY(module_info_list_p, cmd_body.module_info_list_p,
                     cmd_body.list_size, sx_mgmt_phy_module_info_t);

out:
    if (cmd_body_buffer) {
        CL_FREE_N_NULL(cmd_body_buffer);
    }

    if (cmd_body.module_id_info_list_p) {
        CL_FREE_N_NULL(cmd_body.module_id_info_list_p);
    }

    if (cmd_body.module_info_list_p) {
        CL_FREE_N_NULL(cmd_body.module_info_list_p);
    }
    SX_API_LOG_EXIT();

    return rc;
}


sx_status_t sx_mgmt_port_info_get(const sx_api_handle_t   handle,
                                  const sx_port_log_id_t *log_port_list_p,
                                  const uint8_t           list_size,
                                  sx_mgmt_port_info_t    *port_info_list_p)
{
    sx_status_t                    rc = SX_STATUS_SUCCESS;
    sx_mgmt_port_info_get_params_t cmd_body;
    uint8_t                       *cmd_body_buffer = NULL;
    uint32_t                       cmd_body_buffer_size = 0;

    SX_API_LOG_ENTER();
    SX_MEM_CLR_TYPE(&cmd_body, sx_mgmt_port_info_get_params_t);


    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Failed to get port information, invalid handle\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (list_size == 0) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to get port information, incorrect list size error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(log_port_list_p, "log_port_list_p"))) {
        SX_LOG_ERR("Failed to get port information, log_port_list_p error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(port_info_list_p, "port_info_list_p"))) {
        SX_LOG_ERR("Failed to get port information, port_info_list_p error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    cmd_body.list_size = list_size;

    cmd_body.log_port_list_p = (sx_port_log_id_t*)cl_calloc(list_size, sizeof(sx_port_log_id_t));
    if (!cmd_body.log_port_list_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for logport list array.\n");
        goto out;
    }

    SX_MEM_CPY_ARRAY(cmd_body.log_port_list_p, log_port_list_p, list_size, sx_port_log_id_t);

    cmd_body.log_port_info_list_p = (sx_mgmt_port_info_t*)cl_calloc(list_size, sizeof(sx_mgmt_port_info_t));
    if (!cmd_body.log_port_info_list_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for logport info list array.\n");
        goto out;
    }

    /* Buffer size
     * sx_mgmt_port_info_get_params_t                   : params struct
     * list_size * sizeof(sx_port_log_id_t)             : log_port_list
     * list_size * sizeof(sx_mgmt_port_info_t)          : log_port_info_list
     */
    cmd_body_buffer_size = sizeof(sx_mgmt_port_info_get_params_t) +
                           cmd_body.list_size * sizeof(sx_port_log_id_t) +
                           cmd_body.list_size * sizeof(sx_mgmt_port_info_t);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_buffer = (uint8_t*)cl_malloc(cmd_body_buffer_size);
    if (!cmd_body_buffer) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for the command body buffer.\n");
        goto out;
    }

    rc = sx_api_serialize_log_port_info_get_params(&cmd_body, cmd_body_buffer, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to serialize logport information get params.\n");
        goto out;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MGMT_LIB_LOG_PORT_INFO_GET_E,
                                     (uint8_t*)cmd_body_buffer, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed sx management logport information get API, err;%s\n", sx_status_str(rc));
        goto out;
    }

    rc = sx_api_deserialize_log_port_info_get_params(cmd_body_buffer, &cmd_body);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deserialize logport information get params.\n");
        goto out;
    }

    SX_MEM_CPY_ARRAY(port_info_list_p, cmd_body.log_port_info_list_p,
                     cmd_body.list_size, sx_mgmt_port_info_t);

out:
    if (cmd_body_buffer) {
        CL_FREE_N_NULL(cmd_body_buffer);
    }

    if (cmd_body.log_port_list_p) {
        CL_FREE_N_NULL(cmd_body.log_port_list_p);
    }

    if (cmd_body.log_port_info_list_p) {
        CL_FREE_N_NULL(cmd_body.log_port_info_list_p);
    }
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_mgmt_system_info_get(const sx_api_handle_t handle, sx_mgmt_slot_system_info_t *system_info_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_mgmt_system_info_get_params_t cmd_body;
    uint32_t                         cmd_size = sizeof(sx_mgmt_system_info_get_params_t);

    SX_API_LOG_ENTER();

    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Failed to retrieve system information, invalid handle\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(system_info_p, "system_info_p"))) {
        rc = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Failed to retrieve system information, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    SX_MEM_CLR(cmd_body);
    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_MGMT_LIB_SYSTEM_INFO_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to retrieve system information, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    SX_MEM_CPY_P(system_info_p, &(cmd_body.system_info));

out:
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_mgmt_temp_sensor_get(const sx_api_handle_t       handle,
                                    const sx_access_cmd_t       cmd,
                                    const sx_slot_id_t          slot_id,
                                    const sx_sensor_id_t       *sensor_id_list_p,
                                    const uint32_t              sensor_list_size,
                                    sx_mgmt_temp_sensor_info_t *temp_sensor_info_list_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_mgmt_temp_sensor_get_params_t cmd_body;
    uint8_t                         *cmd_body_buffer = NULL;
    uint32_t                         cmd_body_buffer_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Failed to get temp sensor information, invalid handle\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (sensor_list_size == 0) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to get temp sensor information, incorrect list size error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(sensor_id_list_p, "sensor_id_list_p"))) {
        SX_LOG_ERR("Failed to get temp sensor information, sensor_id_list_p error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(temp_sensor_info_list_p, "temp_sensor_info_list_p"))) {
        SX_LOG_ERR("Failed to get temp sensor information, temp_sensor_info_list_p error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.slot_id = slot_id;
    cmd_body.list_size = sensor_list_size;

    cmd_body.sensor_id_list_p = (sx_sensor_id_t*)cl_calloc(sensor_list_size,
                                                           sizeof(cmd_body.sensor_id_list_p[0]));
    if (!cmd_body.sensor_id_list_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for sensor id list array.\n");
        goto out;
    }

    SX_MEM_CPY_ARRAY(cmd_body.sensor_id_list_p, sensor_id_list_p, sensor_list_size, sx_sensor_id_t);

    cmd_body.temp_sensor_info_list_p = (sx_mgmt_temp_sensor_info_t*)cl_calloc(sensor_list_size,
                                                                              sizeof(cmd_body.temp_sensor_info_list_p[0
                                                                                     ]));
    if (!cmd_body.temp_sensor_info_list_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for temp sensor info list array.\n");
        goto out;
    }

    /* Buffer size
     * sx_mgmt_temp_sensor_get_params_t                   : params struct
     * list_size * sizeof(sx_sensor_id_t)               : sensor id list
     * list_size * sizeof(sx_mgmt_temp_sensor_info_t)   : temp sensor info list
     */
    cmd_body_buffer_size = sizeof(sx_mgmt_temp_sensor_get_params_t) +
                           cmd_body.list_size * sizeof(sx_sensor_id_t) +
                           cmd_body.list_size * sizeof(sx_mgmt_temp_sensor_info_t);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_buffer = (uint8_t*)cl_malloc(cmd_body_buffer_size);
    if (!cmd_body_buffer) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for the command body buffer.\n");
        goto out;
    }

    rc = sx_api_serialize_temp_sensor_get_params(&cmd_body, cmd_body_buffer, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to serialize temp sensor information get params.\n");
        goto out;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MGMT_LIB_TEMP_SENSOR_GET_E,
                                     (uint8_t*)cmd_body_buffer, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed sx management temp sensor information get API, err;%s\n",
                   sx_status_str(rc));
        goto out;
    }

    rc = sx_api_deserialize_temp_sensor_get_params(cmd_body_buffer, &cmd_body);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to deserialize temp sensor info get params.\n");
        goto out;
    }

    SX_MEM_CPY_ARRAY(temp_sensor_info_list_p, cmd_body.temp_sensor_info_list_p,
                     cmd_body.list_size, sx_mgmt_temp_sensor_info_t);

out:
    if (cmd_body_buffer) {
        CL_FREE_N_NULL(cmd_body_buffer);
    }

    if (cmd_body.sensor_id_list_p) {
        CL_FREE_N_NULL(cmd_body.sensor_id_list_p);
    }

    if (cmd_body.temp_sensor_info_list_p) {
        CL_FREE_N_NULL(cmd_body.temp_sensor_info_list_p);
    }
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_mgmt_temp_sensor_set(const sx_api_handle_t handle,
                                    const sx_access_cmd_t cmd,
                                    const sx_slot_id_t    slot_id,
                                    const sx_sensor_id_t *sensor_id_list_p,
                                    uint32_t              sensor_list_size,
                                    const sx_mgmt_temp_sensor_ctrl_info_t
                                                         *temp_sensor_ctrl_info_list_p)
{
    sx_status_t                      rc = SX_STATUS_SUCCESS;
    sx_mgmt_temp_sensor_set_params_t cmd_body;
    uint8_t                         *cmd_body_buffer = NULL;
    uint32_t                         cmd_body_buffer_size = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (handle == SX_API_INVALID_HANDLE) {
        SX_LOG_ERR("Failed to set temp sensor information, invalid handle\n");
        rc = SX_STATUS_INVALID_HANDLE;
        goto out;
    }

    if (sensor_list_size == 0) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to set temp sensor information, incorrect list size error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(sensor_id_list_p, "sensor_id_list_p"))) {
        SX_LOG_ERR("Failed to set temp sensor information, sensor_id_list_p error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(temp_sensor_ctrl_info_list_p, "temp_sensor_ctrl_info_list_p"))) {
        SX_LOG_ERR("Failed to set temp sensor information, temp_sensor_ctrl_info_list_p error[%s]\n",
                   SX_STATUS_MSG(rc));
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.slot_id = slot_id;
    cmd_body.list_size = sensor_list_size;

    cmd_body.sensor_id_list_p = (sx_sensor_id_t*)cl_calloc(sensor_list_size,
                                                           sizeof(cmd_body.sensor_id_list_p[0]));
    if (!cmd_body.sensor_id_list_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for sensor id list array.\n");
        goto out;
    }

    SX_MEM_CPY_ARRAY(cmd_body.sensor_id_list_p, sensor_id_list_p, sensor_list_size, sx_sensor_id_t);

    cmd_body.temp_sensor_ctrl_info_list_p = (sx_mgmt_temp_sensor_ctrl_info_t*)cl_calloc(sensor_list_size,
                                                                                        sizeof(cmd_body.
                                                                                               temp_sensor_ctrl_info_list_p
                                                                                               [0]));
    if (!cmd_body.temp_sensor_ctrl_info_list_p) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for temp sensor ctrl info list array.\n");
        goto out;
    }

    SX_MEM_CPY_ARRAY(cmd_body.temp_sensor_ctrl_info_list_p,
                     temp_sensor_ctrl_info_list_p, sensor_list_size, sx_mgmt_temp_sensor_ctrl_info_t);

    /* Buffer size
     * sx_mgmt_temp_sensor_set_params_t                      : params struct
     * list_size * sizeof(sx_sensor_id_t)                    : sensor id list
     * list_size * sizeof(sx_mgmt_temp_sensor_ctrl_info_t)   : temp sensor ctrl info list
     */
    cmd_body_buffer_size = sizeof(sx_mgmt_temp_sensor_set_params_t) +
                           cmd_body.list_size * sizeof(sx_sensor_id_t) +
                           cmd_body.list_size * sizeof(sx_mgmt_temp_sensor_ctrl_info_t);
    if (cmd_body_buffer_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        rc = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_body_buffer = (uint8_t*)cl_malloc(cmd_body_buffer_size);
    if (!cmd_body_buffer) {
        rc = SX_STATUS_NO_MEMORY;
        SX_LOG_ERR("Failed to allocate memory for the command body buffer.\n");
        goto out;
    }

    rc = sx_api_serialize_temp_sensor_set_params(&cmd_body, cmd_body_buffer, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed to serialize temp sensor information set params.\n");
        goto out;
    }

    rc = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_MGMT_LIB_TEMP_SENSOR_SET_E,
                                     (uint8_t*)cmd_body_buffer, cmd_body_buffer_size);
    if (SX_CHECK_FAIL(rc)) {
        SX_LOG_ERR("Failed sx management temp sensor information set API, err;%s\n",
                   sx_status_str(rc));
        goto out;
    }

out:
    if (cmd_body_buffer) {
        CL_FREE_N_NULL(cmd_body_buffer);
    }

    if (cmd_body.sensor_id_list_p) {
        CL_FREE_N_NULL(cmd_body.sensor_id_list_p);
    }

    if (cmd_body.temp_sensor_ctrl_info_list_p) {
        CL_FREE_N_NULL(cmd_body.temp_sensor_ctrl_info_list_p);
    }
    SX_API_LOG_EXIT();
    return rc;
}


sx_status_t sx_mgmt_phy_module_admin_type_set(const sx_api_handle_t                       handle,
                                              const sx_mgmt_module_id_info_t             *module_id_info_p,
                                              const sx_port_phy_module_type_capability_t *types_p)
{
    sx_status_t                      api_rc = SX_STATUS_SUCCESS;
    sx_mgmt_phy_module_type_params_t cmd_body;
    uint32_t                         cmd_size = sizeof(sx_mgmt_phy_module_type_params_t);

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(module_id_info_p, "module id info"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(types_p, "PMD Module type"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    cmd_body.cmd = SX_ACCESS_CMD_SET;
    cmd_body.module_id_info = *module_id_info_p;
    cmd_body.admin_module_type = *types_p;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_MGMT_LIB_PMD_TYPE_SET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_mgmt_phy_module_oper_type_get(const sx_api_handle_t           handle,
                                             const sx_mgmt_module_id_info_t *module_id_info_p,
                                             sx_port_phy_module_type_e      *oper_type_p)
{
    sx_status_t                      api_rc = SX_STATUS_SUCCESS;
    sx_mgmt_phy_module_type_params_t cmd_body;
    uint32_t                         cmd_size = sizeof(sx_mgmt_phy_module_type_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(module_id_info_p, "module id info"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(oper_type_p, "Port Operational PMD Type"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.module_id_info = *module_id_info_p;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_MGMT_LIB_PMD_TYPE_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *oper_type_p = cmd_body.oper_type;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_mgmt_phy_module_capability_get(const sx_api_handle_t                 handle,
                                              const sx_mgmt_module_id_info_t       *module_id_info_p,
                                              sx_port_rate_bitmask_t               *capab_port_rate_p,
                                              sx_port_phy_module_type_capability_t *admin_types_p,
                                              sx_port_phy_module_type_capability_t *capab_types_p)
{
    sx_status_t                      api_rc = SX_STATUS_SUCCESS;
    sx_mgmt_phy_module_type_params_t cmd_body;
    uint32_t                         cmd_size = sizeof(sx_mgmt_phy_module_type_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(capab_port_rate_p, "Capability Rate"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(admin_types_p, "Admin PDM Type"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(capab_types_p, "Capability PMD Type"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    if (SX_CHECK_FAIL(api_rc = utils_check_pointer(module_id_info_p, "module id info"))) {
        SX_API_LOG_EXIT();
        return api_rc;
    }

    cmd_body.cmd = SX_ACCESS_CMD_GET;
    cmd_body.module_id_info = *module_id_info_p;

    api_rc = sx_api_send_command_wrapper(handle,
                                         SX_API_INT_CMD_MGMT_LIB_PMD_TYPE_CAPAB_GET_E,
                                         (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(api_rc)) {
        *capab_port_rate_p = cmd_body.capab_rate;
        *admin_types_p = cmd_body.admin_module_type;
        *capab_types_p = cmd_body.capab_module_type;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_mgmt_phy_module_reset(const sx_api_handle_t handle, const sx_mgmt_module_id_info_t  *module_id_info_p)
{
    sx_status_t                       rc = SX_STATUS_SUCCESS;
    sx_mgmt_phy_module_reset_params_t cmd_body;
    uint32_t                          cmd_size = sizeof(sx_mgmt_phy_module_reset_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(module_id_info_p, "module_id_info_p"))) {
        SX_LOG_ERR("Failed module reset, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    SX_MEM_CLR(cmd_body);

    cmd_body.module_id_info.module_id = module_id_info_p->module_id;
    cmd_body.module_id_info.slot_id = module_id_info_p->slot_id;
    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_MGMT_LIB_PHY_MODULE_RESET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    SX_API_LOG_EXIT();

out:
    return rc;
}


sx_status_t sx_mgmt_phy_module_pwr_attr_set(const sx_api_handle_t             handle,
                                            const sx_access_cmd_t             cmd,
                                            const sx_mgmt_module_id_info_t   *module_id_info_p,
                                            const sx_mgmt_phy_mod_pwr_attr_t *pwr_attr_p)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    sx_mgmt_phy_module_pwr_attr_set_params_t cmd_body;
    uint32_t                                 cmd_size = sizeof(sx_mgmt_phy_module_pwr_attr_set_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(pwr_attr_p, "pwr_attr_p"))) {
        SX_LOG_ERR("Failed module power attribute set, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(module_id_info_p, "module_id_info_p"))) {
        SX_LOG_ERR("Failed module power attribute set, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_SET) {
        rc = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Unsupported access-command [%s]\n", sx_access_cmd_str(cmd));
        goto out;
    }

    if (pwr_attr_p->power_attr_type == 0) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid Power attribute [%s]\n", SX_MGMT_PHY_MOD_PWR_ATTR_TYPE_STR(pwr_attr_p->power_attr_type));
        goto out;
    }

    if ((pwr_attr_p->power_attr_type & SX_MGMT_PHY_MOD_PWR_ATTR_PWR_MODE_E) &&
        ((pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e == SX_MGMT_PHY_MOD_PWR_MODE_INVALID_E) ||
         (pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e == SX_MGMT_PHY_MOD_PWR_MODE_HIGH_E))) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid Power mode [%s]\n", SX_MGMT_PHY_MOD_PWR_MODE_STR(
                       pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e));
        goto out;
    }

    SX_MEM_CLR(cmd_body);

    cmd_body.cmd = cmd;
    cmd_body.module_id_info.module_id = module_id_info_p->module_id;
    cmd_body.module_id_info.slot_id = module_id_info_p->slot_id;
    cmd_body.pwr_attr.power_attr_type = pwr_attr_p->power_attr_type;
    cmd_body.pwr_attr.pwr_mode_attr.admin_pwr_mode_e = pwr_attr_p->pwr_mode_attr.admin_pwr_mode_e;
    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_MGMT_LIB_PHY_MODULE_PWR_ATTR_SET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

out:
    SX_API_LOG_EXIT();
    return rc;
}

sx_status_t sx_mgmt_phy_module_pwr_attr_get(const sx_api_handle_t           handle,
                                            const sx_mgmt_module_id_info_t *module_id_info_p,
                                            sx_mgmt_phy_mod_pwr_attr_t     *pwr_attr_p)
{
    sx_status_t                              rc = SX_STATUS_SUCCESS;
    sx_mgmt_phy_module_pwr_attr_get_params_t cmd_body;
    uint32_t                                 cmd_size = sizeof(sx_mgmt_phy_module_pwr_attr_get_params_t);

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(rc = utils_check_pointer(module_id_info_p, "module_id_info_p"))) {
        SX_LOG_ERR("Failed to retrieve power attribute, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (SX_CHECK_FAIL(rc = utils_check_pointer(pwr_attr_p, "pwr_attr_p"))) {
        SX_LOG_ERR("Failed to retrieve power attribute, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_MGMT_PHY_MOD_PWR_ATTR_MIN_E, pwr_attr_p->power_attr_type,
                        SX_MGMT_PHY_MOD_PWR_ATTR_MAX_E)) {
        rc = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Failed to retrieve power attribute, error[%s]\n", SX_STATUS_MSG(rc));
        goto out;
    }

    SX_MEM_CLR(cmd_body);

    cmd_body.module_id_info.module_id = module_id_info_p->module_id;
    cmd_body.module_id_info.slot_id = module_id_info_p->slot_id;
    cmd_body.pwr_attr.power_attr_type = pwr_attr_p->power_attr_type;

    rc = sx_api_send_command_wrapper(handle,
                                     SX_API_INT_CMD_MGMT_LIB_PHY_MODULE_PWR_ATTR_GET_E,
                                     (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(rc)) {
        *pwr_attr_p = cmd_body.pwr_attr;
    }
out:
    SX_API_LOG_EXIT();
    return rc;
}
