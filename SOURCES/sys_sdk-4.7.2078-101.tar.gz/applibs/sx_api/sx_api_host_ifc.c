/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <fcntl.h>
#include <complib/cl_spinlock.h>
#include <complib/cl_dbg.h>
#include <complib/cl_shared_memory.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_emad_parser.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sdk/sx_api_host_ifc.h>
#include <sx/sdk/sx_lib_host_ifc.h>
#include "sx_api_internal.h"
#include "utils/utils.h"
#include "dbg/dbg_dump/dbg_dump_common.h"
#include "ethl2/port_uc_route.h"
#include "ethl2/la_db.h"
#include "include/sx/sdk/sx_port.h"
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/sxd_access_register_init.h>

#undef  __MODULE__
#define __MODULE__ SX_API_HOST_IFC

/************************************************
 *  MACROS
 ***********************************************/

#define EMAD_PACKET_MAX_SIZE (sizeof(struct ku_read) + (SXD_EMAD_BUFFER_MAX_SIZE))

#define TRAP_ID_NUM            (SX_TRAP_ID_MAX + 1)
#define USER_CHANNEL_FD_NUM    512
#define USER_CHANNEL_OTHER_NUM SX_USER_CHANNEL_TYPE_L2_TUNNEL
#define USER_CHANNEL_NUM       (USER_CHANNEL_FD_NUM + USER_CHANNEL_OTHER_NUM + 1)

/************************************************
 *  GLOBAL VARIABLES
 ***********************************************/

/************************************************
 *  LOCAL VARIABLES
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static sx_ladb_port_indices_t *port_indices_db_p = NULL;

typedef struct sx_host_ifc_vtrap_registration_item {
    cl_pool_item_t __pool_item;
    cl_map_item_t  __map_item;
} sx_host_ifc_vtrap_registration_item_t;

/* DB KEY:
 *    6         5         4         3         2         1
 * 3210987654321098765432109876543210987654321098765432109876543210
 * #################################
 * |                                ###############################
 * |                                |
 * |                                +--------------------------------- vtrap
 * +------------------------------------------------------------------ trap_id
 */
#define __TRAP_VTRAP_2_KEY(trap_id, vtrap) ((((uint64_t)(trap_id)) << 32) | (vtrap))
#define __KEY_2_TRAP_VTRAP(key, trap_id_p, vtrap_p) \
    do {                                            \
        *(trap_id_p) = (key) >> 32;                 \
        *(vtrap_p) = (key) & 0xFFFFFFFF;            \
    } while (0)

#define __TRAP_VTRAP_DB_MIN_SIZE  (16)
#define __TRAP_VTRAP_DB_GROW_SIZE (16)

struct user_channel_reg_db {
    cl_qmap_t  db_map;
    cl_qpool_t db_mem_pool;
};
static struct user_channel_reg_db __trap_vtrap_reg_db[USER_CHANNEL_NUM];
static uint32_t                   __trap_vtrap_reg_db_ref_cnt = 0;
static char                       recv_buf_g[READ_MULTI_BUFFS_MAX][SX_ETH_RDQ_MAX_MSG_SIZE +
                                                                   sizeof(struct ku_read)];
static void         *recv_buf_list_g[READ_MULTI_BUFFS_MAX];
static uint32_t      recv_size_list_g[READ_MULTI_BUFFS_MAX];
static cl_spinlock_t recv_buf_lock_g = CL_SPINLOCK_INITIALIZER;
static cl_spinlock_t __trap_vtrap_ref_cnt_lock_g = CL_SPINLOCK_INITIALIZER;


typedef enum SX_FILE_OP sx_file_op_t;

/************************************************
 *  LOCAL FUNCTIONS DECLARATION
 ***********************************************/
static void __set_isx_meta(sxd_swid_t            swid,
                           sx_packet_type_t      packet_type,
                           sx_port_ucroute_id_t  port_ucroute_id,
                           sx_cos_priority_t     prio,
                           sx_stclass_t          stclass,
                           sx_rdq_t              rdq,
                           uint8_t               to_cpu,
                           uint8_t               lp,
                           sx_dev_id_t           dev_id,
                           struct loopback_data *loopback_data,
                           struct span_oob_data *span_oob_data_p,
                           struct isx_meta      *meta);
static uint32_t __is_event(uint16_t syndrome_id);
static uint32_t __is_trap(uint16_t syndrome_id);
static sx_status_t __parse_event(IN uint16_t            syndrome_id,
                                 IN char               *recv_buff_p,
                                 IN uint16_t            recv_buff_size,
                                 OUT sx_receive_info_t *receive_info_p);
static sx_status_t __parse_trap(char              *buffer_p,
                                void              *packet_p,
                                uint32_t          *packet_size_p,
                                sx_receive_info_t *receive_info_p);
static void __parse_mirror_info(struct ku_read    *ku_read,
                                sx_receive_info_t *receive_info_p);
static sx_status_t __parse_sb_snapshot_trigger_info(const sxd_snapshot_trigger_id_t       sxd_trigger_id,
                                                    sx_sb_snapshot_trigger_enable_type_e *sx_trigger_type_p);
static sx_status_t __sb_snapshot_information_get(const sx_sb_snapshot_trigger_enable_type_e sx_trigger_type,
                                                 const sxd_emad_sbsns_data_t                sbsns_data,
                                                 sx_sb_snapshot_information_t              *snapshot_info_p);
static sx_status_t __lcl_port_uc_route_get(IN sx_port_id_t           port_id,
                                           OUT sx_port_ucroute_id_t *ucroute_id_p);
static sx_status_t __span_hw_session_id_get(IN sx_span_session_id_t span_session_id,
                                            OUT uint8_t            *hw_span_session_id_p);
static sx_status_t __host_ifc_send(const sx_fd_t          *fd,
                                   const void             *packet,
                                   const uint32_t          packet_size,
                                   const sx_swid_t         swid,
                                   sx_packet_type_t        packet_type,
                                   sx_port_ucroute_id_t    port_ucroute_id,
                                   const sx_cos_priority_t prio,
                                   sx_dev_id_t             dev_id,
                                   struct loopback_data   *loopback_data,
                                   struct span_oob_data   *span_oob_attr_p);
static sx_status_t __host_ifc_trap_group_set(sx_api_handle_t                   handle,
                                             sx_swid_id_t                      swid,
                                             const sx_trap_group_t             trap_group,
                                             const sx_trap_group_attributes_t *trap_group_attributes_p,
                                             uint32_t                         *hw_trap_group);
static sx_status_t __host_ifc_trap_group_ext_set(sx_api_handle_t             handle,
                                                 sx_swid_id_t                swid,
                                                 sx_access_cmd_t             cmd,
                                                 const sx_trap_group_t       trap_group,
                                                 sx_trap_group_attributes_t *trap_group_attributes_p,
                                                 uint32_t                   *hw_trap_group);
static sx_status_t __host_ifc_trap_group_get(sx_api_handle_t             handle,
                                             sx_trap_group_t             trap_group,
                                             sx_swid_id_t                swid,
                                             sx_trap_group_attributes_t *trap_group_attributes_p);
static sx_status_t __host_ifc_user_defined_trap_id_set(const sx_api_handle_t                 handle,
                                                       const sx_access_cmd_t                 cmd,
                                                       const sx_swid_t                       swid,
                                                       const sx_trap_id_t                    trap_id,
                                                       sx_trap_id_user_defined_attributes_t *trap_attributes_p);
static sx_status_t __host_ifc_trap_group_set_wrapper(const sx_api_handle_t             handle,
                                                     const sx_swid_id_t                swid,
                                                     const sx_trap_group_t             trap_group,
                                                     const sx_trap_group_attributes_t *trap_group_attributes);
static sx_status_t __user_channel_filter_key_validate(const sx_access_cmd_t           cmd,
                                                      const sx_user_channel_t        *user_channel_p,
                                                      const sx_host_ifc_filter_key_t *filter_key_p);


/************************************************
 *  LOCAL FUNCTIONS IMPLEMENTATION
 ***********************************************/
static boolean_t __trap_vtrap_reg_db_lookup(int uc_index, uint32_t trap_id, uint32_t vtrap)
{
    struct user_channel_reg_db *reg_db = &__trap_vtrap_reg_db[uc_index];
    uint64_t                    key = __TRAP_VTRAP_2_KEY(trap_id, vtrap);
    cl_map_item_t              *map_item = cl_qmap_get(&reg_db->db_map, key);
    const cl_map_item_t        *end = cl_qmap_end(&reg_db->db_map);

    return map_item != end;
}

static boolean_t __trap_vtrap_reg_db_lookup_trap(int uc_index, uint32_t trap_id)
{
    struct user_channel_reg_db *reg_db = &__trap_vtrap_reg_db[uc_index];
    uint64_t                    key = __TRAP_VTRAP_2_KEY(trap_id, 0); /* first possible key with this trap_id */
    uint32_t                    curr_trap_id = 0;
    uint32_t                    curr_vtrap = 0;
    cl_map_item_t              *map_item = cl_qmap_get_next(&reg_db->db_map, key);
    const cl_map_item_t        *end = cl_qmap_end(&reg_db->db_map);

    if (map_item != end) {
        key = cl_qmap_key(map_item);
        __KEY_2_TRAP_VTRAP(key, &curr_trap_id, &curr_vtrap);
    }

    return (map_item != end && curr_trap_id == trap_id);
}

static sx_status_t __trap_vtrap_reg_db_add(int uc_index, uint32_t trap_id, uint32_t vtrap)
{
    struct user_channel_reg_db            *reg_db = &__trap_vtrap_reg_db[uc_index];
    sx_host_ifc_vtrap_registration_item_t *entry = NULL;
    cl_pool_item_t                        *pool_item = NULL;
    uint64_t                               key = 0;
    sx_status_t                            status = SX_STATUS_SUCCESS;

    pool_item = cl_qpool_get(&reg_db->db_mem_pool);
    if (!pool_item) {
        SX_LOG_ERR("TRAP-VTRAP [%d, %u/%u] entry allocation error!\n", uc_index, trap_id, vtrap);
        status = SX_STATUS_NO_MEMORY;
        goto out;
    }

    entry = PARENT_STRUCT(pool_item, sx_host_ifc_vtrap_registration_item_t, __pool_item);
    key = __TRAP_VTRAP_2_KEY(trap_id, vtrap);
    cl_qmap_insert(&reg_db->db_map, key, &entry->__map_item);

out:
    return status;
}

static sx_status_t __trap_vtrap_reg_db_del(int uc_index, uint32_t trap_id, uint32_t vtrap)
{
    struct user_channel_reg_db            *reg_db = &__trap_vtrap_reg_db[uc_index];
    uint64_t                               key = __TRAP_VTRAP_2_KEY(trap_id, vtrap);
    cl_map_item_t                         *map_item = cl_qmap_get(&reg_db->db_map, key);
    const cl_map_item_t                   *end = cl_qmap_end(&reg_db->db_map);
    sx_host_ifc_vtrap_registration_item_t *entry = NULL;

    if (map_item == end) {
        SX_LOG_ERR("TRAP-VTRAP [%d, %u/%u] entry not found on vtrap delete\n", uc_index, trap_id, vtrap);
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    entry = PARENT_STRUCT(map_item, sx_host_ifc_vtrap_registration_item_t, __map_item);
    cl_qmap_remove_item(&reg_db->db_map, map_item);
    cl_qpool_put(&reg_db->db_mem_pool, &entry->__pool_item);
    return SX_STATUS_SUCCESS;
}

static void __trap_vtrap_reg_db_reset(int uc_index)
{
    struct user_channel_reg_db            *reg_db = &__trap_vtrap_reg_db[uc_index];
    cl_map_item_t                         *map_item = NULL;
    sx_host_ifc_vtrap_registration_item_t *entry = NULL;

    while (!cl_is_qmap_empty(&reg_db->db_map)) {
        map_item = cl_qmap_head(&reg_db->db_map);
        entry = PARENT_STRUCT(map_item, sx_host_ifc_vtrap_registration_item_t, __map_item);
        cl_qmap_remove_item(&reg_db->db_map, &entry->__map_item);
        cl_qpool_put(&reg_db->db_mem_pool, &entry->__pool_item);
    }
}

sx_status_t host_ifc_user_channel_init(void)
{
    struct user_channel_reg_db *reg_db = NULL;
    sx_status_t                 sx_status = SX_STATUS_SUCCESS;
    cl_status_t                 cl_status = CL_SUCCESS;
    int                         uc_index = 0;

    /* Acquire lock before reading the global counter,
     *  race can happen if multiple threads are spawned by same process doing api_open*/
    cl_spinlock_acquire(&__trap_vtrap_ref_cnt_lock_g);
    if (__trap_vtrap_reg_db_ref_cnt++ > 0) { /* not the first call */
        goto out;
    }

    for (uc_index = 0; uc_index < USER_CHANNEL_NUM; uc_index++) {
        reg_db = &__trap_vtrap_reg_db[uc_index];
        cl_status = cl_qpool_init(&reg_db->db_mem_pool,
                                  __TRAP_VTRAP_DB_MIN_SIZE,
                                  0,
                                  __TRAP_VTRAP_DB_GROW_SIZE,
                                  sizeof(sx_host_ifc_vtrap_registration_item_t),
                                  NULL,
                                  NULL,
                                  NULL);
        if (cl_status != CL_SUCCESS) {
            SX_LOG_ERR("failed to initialize TRAP_VTRAP map item\n");
            sx_status = SX_STATUS_NO_MEMORY;
            goto out;
        }

        cl_qmap_init(&reg_db->db_map);
    }

out:
    cl_spinlock_release(&__trap_vtrap_ref_cnt_lock_g);
    return sx_status;
}

void host_ifc_user_channel_deinit(void)
{
    struct user_channel_reg_db *reg_db = NULL;
    int                         uc_index = 0;

    cl_spinlock_acquire(&__trap_vtrap_ref_cnt_lock_g);
    if (--__trap_vtrap_reg_db_ref_cnt > 0) { /* not the last call */
        cl_spinlock_release(&__trap_vtrap_ref_cnt_lock_g);
        return;
    }

    for (uc_index = 0; uc_index < USER_CHANNEL_NUM; uc_index++) {
        reg_db = &__trap_vtrap_reg_db[uc_index];

        __trap_vtrap_reg_db_reset(uc_index);
        cl_qpool_destroy(&reg_db->db_mem_pool);
    }
    cl_spinlock_release(&__trap_vtrap_ref_cnt_lock_g);
}

static sx_status_t __init_sxd_handle(sxd_handle *handle, int fd)
{
    sxd_ctrl_pack_t ctrl_pack;
    int             sxd_err = 0;
    sx_status_t     err = SX_STATUS_SUCCESS;
    boolean_t       new_handle_retrieved = FALSE;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(ctrl_pack);

    if (handle == NULL) {
        SX_LOG_ERR("NULL handle.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    sxd_err = sxd_get_new_handle(fd, handle);
    if (SXD_CHECK_FAIL(sxd_err)) {
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        SX_LOG_ERR("Failed to get new SXD handle for FD %d, sxd_err = [%d], errno = [%s]\n",
                   fd, sxd_err, strerror(errno));
        goto out;
    }
    new_handle_retrieved = TRUE;

    /* set receive multiple packets = false */
    ctrl_pack.cmd_body = (void*)FALSE;
    ctrl_pack.ctrl_cmd = CTRL_CMD_MULTI_PACKET_ENABLE;
    sxd_err = sxd_ioctl(*handle, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("sxd_ioctl (set MULTI_PACKET_ENABLE = FALSE) error %s.\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    /* set blocking on read */
    ctrl_pack.cmd_body = (void*)TRUE;
    ctrl_pack.ctrl_cmd = CTRL_CMD_BLOCKING_ENABLE;
    sxd_err = sxd_ioctl(*handle, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("sxd_ioctl (set BLOCKING_ENABLE = TRUE) error %s.\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    /* get ownership on the FD (so fd will be displayed in fd_dump with the current process and not under SDK process) */
    ctrl_pack.cmd_body = NULL;
    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_OWNER;
    sxd_err = sxd_ioctl(*handle, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("sxd_ioctl (set CTRL_CMD_SET_OWNER) error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

out:
    if (SX_CHECK_FAIL(err)) {
        if (new_handle_retrieved) {
            sxd_put_handle(*handle);
        }
    }
    SX_API_LOG_EXIT();
    return err;
}

static sx_status_t __deinit_sxd_handle(sxd_handle handle)
{
    int         ret = 0;
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    ret = sxd_close_device(handle);
    if (ret) {
        SX_LOG_ERR("sxd_close_device error: %s\n", strerror(errno));
        err = SXD_STATUS_TO_SX_STATUS(SXD_STATUS_DEVICE_CLOSE_ERROR);
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

static void __set_isx_meta(sx_swid_t             swid,
                           sx_packet_type_t      packet_type,
                           sx_port_ucroute_id_t  port_ucroute_id,
                           sx_cos_priority_t     prio,
                           sx_stclass_t          stclass,
                           sx_rdq_t              rdq,
                           uint8_t               to_cpu,
                           uint8_t               lp,
                           sx_dev_id_t           dev_id,
                           struct loopback_data *loopback_data,
                           struct span_oob_data *span_oob_data_p,
                           struct isx_meta      *meta)
{
    UNUSED_PARAM(stclass);

    meta->swid = swid;
    meta->system_port_mid = port_ucroute_id;
    meta->to_cpu = to_cpu;
    meta->type = packet_type;
    meta->rdq = rdq;
    meta->lp = lp;
    meta->dev_id = dev_id;
    switch (prio) {
    case SX_TRAP_PRIORITY_BEST_EFFORT:
        meta->etclass = 0;
        break;

    case SX_TRAP_PRIORITY_LOW:
        meta->etclass = 1;
        break;

    case SX_TRAP_PRIORITY_MED:
        meta->etclass = 2;
        break;

    case SX_TRAP_PRIORITY_HIGH:
    case SX_TRAP_PRIORITY_CRITICAL:
        meta->etclass = 6;
        break;

    default:
        meta->etclass = 0;
        break;
    }

    if ((packet_type == SX_PKT_TYPE_LOOPBACK_CTL) && loopback_data) {
        meta->loopback_data = *loopback_data;
    }

    if ((packet_type == SX_PKT_TYPE_ETH_DATA) && span_oob_data_p) {
        meta->span_oob_data_valid = 1;
        meta->span_oob_data = *span_oob_data_p;
    }
}

static int __vtrap_db_register_index_get(const sx_user_channel_t *user_channel)
{
    int index = -1;

    switch (user_channel->type) {
    case SX_USER_CHANNEL_TYPE_FD:
        index = user_channel->channel.fd.driver_handle;
        break;

    case SX_USER_CHANNEL_TYPE_L2_TUNNEL:
    case SX_USER_CHANNEL_TYPE_L3_NETDEV:
    case SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV:
    case SX_USER_CHANNEL_TYPE_PHY_PORT_NETDEV:
        index = USER_CHANNEL_FD_NUM + user_channel->type;
        break;

    default:
        index = -1;
        break;
    }

    if (index >= USER_CHANNEL_NUM) {
        SX_LOG_ERR("user channel index is out of bound\n");
        index = -1;
    }

    return index;
}

static sx_status_t __vtrap_db_register_set(const sx_access_cmd_t    cmd,
                                           const uint32_t           trap_id,
                                           const uint32_t           vtrap,
                                           const sx_user_channel_t *user_channel)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    int         uc_index = -1;
    boolean_t   trap_found = FALSE, vtrap_found = FALSE;

    SX_API_LOG_ENTER();

    uc_index = __vtrap_db_register_index_get(user_channel);
    if (uc_index == -1) {
        err = SX_STATUS_ERROR;
        goto out;
    }

    trap_found = __trap_vtrap_reg_db_lookup_trap(uc_index, trap_id);
    if (trap_found) {
        vtrap_found = __trap_vtrap_reg_db_lookup(uc_index, trap_id, vtrap);
    }

    if (cmd == SX_ACCESS_CMD_REGISTER) {
        if (!trap_found) {
            err = __trap_vtrap_reg_db_add(uc_index, trap_id, vtrap);
        } else {
            if (!vtrap_found) {
                err = __trap_vtrap_reg_db_add(uc_index, trap_id, vtrap);
                if (SX_CHECK_FAIL(err)) {
                    SX_LOG_ERR("TRAP-VTRAP [%d, %u, %u] trap_id was not configured\n", uc_index, trap_id, vtrap);
                    goto out;
                }
            }

            err = SX_STATUS_ENTRY_ALREADY_EXISTS;
        }
    } else if (cmd == SX_ACCESS_CMD_DEREGISTER) {
        if (!vtrap_found) {
            /* try to remove unconfigured trap_id, return error */
            SX_LOG_ERR("TRAP-VTRAP [%d, %u, %u] trap_id was not configured\n", uc_index, trap_id, vtrap);
            err = SX_STATUS_ENTRY_NOT_FOUND;
        } else {
            /* remove configured vtrap in db */
            err = __trap_vtrap_reg_db_del(uc_index, trap_id, vtrap);
            if (SX_CHECK_FAIL(err)) {
                goto out;
            }

            /* check if there are more vtrap on this trap_id entry */
            if (__trap_vtrap_reg_db_lookup_trap(uc_index, trap_id)) {
                /* there are other vtrap configured, don't update driver */
                err = SX_STATUS_ENTRY_ALREADY_EXISTS;
            }
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

static sx_status_t __configure_driver(sx_access_cmd_t                   cmd,
                                      sxd_handle                        user_dev,
                                      uint32_t                          trap_id,
                                      uint32_t                          vtrap,
                                      sx_swid_t                         swid,
                                      const sx_host_ifc_register_key_t *register_key_p,
                                      const sx_user_channel_t          *user_channel,
                                      sx_port_ucroute_id_t              sysport,
                                      uint8_t                           is_register)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    int                  sxd_err = 0;
    struct ku_synd_ioctl synd_ioctl;
    sxd_ctrl_pack_t      ctrl_pack;
    sxd_handle           dev;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(synd_ioctl);
    SX_MEM_CLR(ctrl_pack);

    SX_API_GET_RELEVANT_PACKET_TYPE(trap_id, synd_ioctl.type);
    SX_API_GET_DROP_ENABLED(trap_id, synd_ioctl.critireas.dont_care.drop_enable);
    synd_ioctl.channel_type = (enum ku_user_channel_type)(user_channel->type);
    synd_ioctl.is_register = is_register;
    /****** general configuration of ctrl_pack ******/
    switch (user_channel->type) {
    case SX_USER_CHANNEL_TYPE_FD:
        dev = user_channel->channel.fd.driver_handle;
        break;

    case SX_USER_CHANNEL_TYPE_L2_TUNNEL:
        synd_ioctl.l2_tunnel_params.dmac = user_channel->channel.l2_tunnel_params.dmac;
        synd_ioctl.l2_tunnel_params.prio = user_channel->channel.l2_tunnel_params.prio;
        synd_ioctl.l2_tunnel_params.vid = user_channel->channel.l2_tunnel_params.vid;
        dev = user_dev;
        break;

    case SX_USER_CHANNEL_TYPE_L3_NETDEV:
    case SX_USER_CHANNEL_TYPE_LOG_PORT_NETDEV:
    case SX_USER_CHANNEL_TYPE_PHY_PORT_NETDEV:
    case SX_USER_CHANNEL_TYPE_DROP_MONITOR:
        dev = user_dev;
        break;

    case SX_USER_CHANNEL_TYPE_PSAMPLE:
        memcpy(&synd_ioctl.psample_params, &user_channel->channel.psample_params, sizeof(synd_ioctl.psample_params));
        dev = user_dev;
        break;

    default:
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_REGISTER:
        ctrl_pack.ctrl_cmd = CTRL_CMD_ADD_SYND;
        break;

    case SX_ACCESS_CMD_DEREGISTER:
        ctrl_pack.ctrl_cmd = CTRL_CMD_REMOVE_SYND;
        break;

    case SX_ACCESS_CMD_ADD:
        ctrl_pack.ctrl_cmd = CTRL_CMD_ADD_SYND;
        break;

    case SX_ACCESS_CMD_DELETE:
        ctrl_pack.ctrl_cmd = CTRL_CMD_REMOVE_SYND;
        break;

    case SX_ACCESS_CMD_DELETE_ALL:
        ctrl_pack.ctrl_cmd = CTRL_CMD_REMOVE_SYND;
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }
    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        switch (register_key_p->key_type) {
        case SX_HOST_IFC_REGISTER_KEY_TYPE_GLOBAL:
            synd_ioctl.port_vlan_params.port_vlan_type = KU_PORT_VLAN_PARAMS_TYPE_GLOBAL;
            break;

        case SX_HOST_IFC_REGISTER_KEY_TYPE_PORT:
            if (SX_PORT_TYPE_ID_GET(register_key_p->key_value.port_id) != SX_PORT_TYPE_LAG) {
                synd_ioctl.port_vlan_params.port_vlan_type = KU_PORT_VLAN_PARAMS_TYPE_PORT;
                synd_ioctl.port_vlan_params.sysport = sysport;
            } else {
                synd_ioctl.port_vlan_params.port_vlan_type = KU_PORT_VLAN_PARAMS_TYPE_LAG;
                synd_ioctl.port_vlan_params.lag_id =
                    SX_PORT_LAG_ID_GET(register_key_p->key_value.port_id);
            }
            break;

        case SX_HOST_IFC_REGISTER_KEY_TYPE_VLAN:
            synd_ioctl.port_vlan_params.port_vlan_type = KU_PORT_VLAN_PARAMS_TYPE_VLAN;
            synd_ioctl.port_vlan_params.vlan = register_key_p->key_value.vlan_id;
            break;

        default:
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("__configure driver register_key_p->key type val.\n");
            goto out;
        }
    } else {
        synd_ioctl.port_vlan_params.port_vlan_type = KU_PORT_VLAN_PARAMS_TYPE_NONE;
    }
    if (vtrap != trap_id) {
        /* in case of vtrap, verify the configuration is valid */
        err = __vtrap_db_register_set(cmd, trap_id, vtrap, user_channel);
        if (err == SX_STATUS_ENTRY_ALREADY_EXISTS) {
            /* vtrap updated in db. trap_id stay configured in driver */
            err = SX_STATUS_SUCCESS;
            goto out;
        } else if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__vtrap_db_register_set failed.\n");
            goto out;
        }
    }

    synd_ioctl.swid = swid;
    synd_ioctl.is_default = FALSE;
    synd_ioctl.syndrome_num = trap_id;

    ctrl_pack.cmd_body = (void*)&synd_ioctl;

    sxd_err = sxd_ioctl(dev, &ctrl_pack);
    if (sxd_err != 0) {
        SX_LOG_ERR("Failed in sxd_ioctl add/remove syndrome, err = [%s]\n",
                   strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    SX_LOG_DBG("Configured trap id [%u] successfully in driver, return value: %s\n",
               trap_id, strerror(errno));

out:
    SX_API_LOG_EXIT();
    return err;
}


static sx_status_t __user_channel_filter_key_validate(const sx_access_cmd_t           cmd,
                                                      const sx_user_channel_t        *user_channel_p,
                                                      const sx_host_ifc_filter_key_t *filter_key_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    if (user_channel_p == NULL) {
        SX_LOG_ERR("user channel is NULL .\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((user_channel_p->type == SX_USER_CHANNEL_TYPE_FD) &&
        (user_channel_p->channel.fd.valid == FALSE)) {
        SX_LOG_ERR("type SX_USER_CHANNEL_TYPE_FD is invalid.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        if (filter_key_p == NULL) {
            SX_LOG_ERR("filter key is NULL.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if ((filter_key_p->key_type) > SX_HOST_IFC_REGISTER_KEY_TYPE_MAX) {
            SX_LOG_ERR("Invalid key_type range.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }
out:
    return err;
}

static uint32_t __is_event(uint16_t syndrome_id)
{
    uint32_t is_event = 0;

    switch (syndrome_id) {
    case SX_TRAP_ID_PUDE: /* port up/down*/
    case SX_TRAP_ID_PMPE: /* port module plug / unplug */
    case SX_TRAP_ID_TMPW: /* Temperature warning event */
    case SX_TRAP_ID_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP:
    case SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY:
    case SX_TRAP_ID_ROUTER_MC_ACTIVITY:
    case SX_TRAP_ID_FDB_IP_ADDR_ACTIVITY:
    case SX_TRAP_ID_OBJECT_DELETED_EVENT:
    case SX_TRAP_ID_API_LOGGER_EVENT:
    case SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT:
    case SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED:
    case SX_TRAP_ID_BER_MONITOR:
    case SX_TRAP_ID_BFD_TIMEOUT_EVENT:
    case SX_TRAP_ID_INFINIBAND_IB_FMAD_RCV:
    case SX_TRAP_ID_PORT_ADDED:
    case SX_TRAP_ID_PORT_DELETED:
    case SX_TRAP_ID_PORT_ADDED_TO_LAG:
    case SX_TRAP_ID_PORT_REMOVED_FROM_LAG:
    case SX_TRAP_ID_SDK_HEALTH_EVENT:
    case SX_TRAP_ID_BULK_REFRESH_COUNTER_DONE_EVENT:
    case SX_TRAP_ID_BULK_COUNTER_DONE_EVENT:
    case SX_TRAP_ID_ACL_ACTIVITY:
    case SX_TRAP_ID_SYSFS_SNIFFER:
    case SX_TRAP_ID_TSDE: /* Temperature shutdown event. */
    case SX_TRAP_ID_DSDSC: /* Down stream device status change event. */
    case SX_TRAP_ID_PMLPE: /* Port module lane mapping event. */
    case SX_TRAP_ID_BCTOE: /* Binary code transfer operation executed. */
    case SXD_TRAP_ID_SB_SNAPSHOT:
    case SX_TRAP_ID_UTFD:
    case SX_TRAP_ID_STATEFUL_DB_PARTITION_THRESHOLD_CROSSED:
    case SX_TRAP_ID_TAC_ACTION_DONE:
    case SX_TRAP_ID_PLLP:
    case SX_TRAP_ID_PORT_TX_READY:
    case SX_TRAP_ID_MFRI:
    case SX_TRAP_ID_PPIR:
    case SX_TRAP_ID_MFCDR:
    case SX_TRAP_ID_IBISSU:
        is_event = 1;
        break;

    default:
        is_event = 0;
    }
    return is_event;
}

static uint32_t __is_trap(uint16_t syndrome_id)
{
    return SX_TRAP_ID_CHECK_RANGE(syndrome_id);
}

static sx_status_t __parse_event(uint16_t           syndrome_id,
                                 char              *recv_buff_p,
                                 uint16_t           recv_buff_size,
                                 sx_receive_info_t *receive_info_p)
{
    sx_event_info_t                            *event_info_p = &receive_info_p->event_info;
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sxd_status_t                                sxd_err = SXD_STATUS_SUCCESS;
    sxd_emad_data_t                             data;
    sxd_reg_id_e                                reg_id;
    uint8_t                                     emad_buff[SXD_EMAD_BUFFER_MAX_SIZE];
    struct ku_pude_reg                          pude_reg_data;
    struct ku_pmpe_reg                          pmpe_reg_data;
    struct ku_sbctr_reg                         sbctr_reg_data;
    struct ku_ppbme_reg                         ppbme_reg_data;
    struct ku_ibfmr_reg                         ibfmr_reg_data;
    struct ku_mtewe_reg                         mtewe_reg_data;
    struct ku_mtsde_reg                         mtsde_reg_data;
    struct ku_pmlpe_reg                         pmlpe_reg_data;
    struct ku_mddq_reg                          mddq_reg_data;
    struct ku_mbct_reg                          mbct_reg_data;
    struct ku_sbsns_reg                         sbsns_reg_data;
    struct ku_utfd_reg                          utfd_reg_data;
    struct ku_fsps_reg                          fsps_reg_data;
    struct ku_pllp_reg                          pllp_reg_data;
    struct ku_htacg_reg                         htacg_reg_data;
    struct ku_ptse_reg                          ptse_reg_data;
    struct ku_mfri_reg                          mfri_reg_data;
    struct ku_ppir_reg                          ppir_reg_data;
    struct ku_mfcdr_reg                         mfcdr_reg_data;
    struct ku_ibissu_reg                        ibissu_reg_data;
    struct ku_spzr_reg                          spzr_reg_data;
    int                                         buf_len_to_copy;
    sx_event_need_to_resolve_arp_t             *need_to_resolve_data;
    sx_event_no_need_to_resolve_arp_t          *no_need_to_resolve_data;
    sx_rm_sdk_table_notification_t             *rm_sdk_table_notification;
    sx_rm_hw_table_notification_t              *rm_hw_table_notification;
    sx_router_neigh_activity_notification_t    *router_neigh_activity_notification;
    sx_router_mc_route_activity_notification_t *router_mc_route_activity_notification;
    sx_fdb_mc_ip_addr_activity_notification_t  *fdb_mc_ip_addr_activity_notification;
    sx_event_bfd_timeout_t                     *bfd_timeout;
    sx_event_port_lag_changes_t                *port_lag_changes_p;
    sx_event_port_added_deleted_t              *port_added_or_deleted_p;
    sxd_port_phy_id_t                           port_list[RM_API_HOST_IFC_LANE_TO_MODULE_NUM_MAX];
    uint32_t                                    i = 0;
    sx_cos_traffic_class_t                      tc;
    int                                         count;
    uint32_t                                    tc_vec_mask = 0, tc_vec = 0;
    sx_port_id_t                                log_port = 0;
    sx_port_phy_id_t                            local_port = 0;
    struct ku_read                             *ku_read_p = NULL;
    uint8_t                                     tx_lane;
    sxd_snapshot_trigger_id_t                   sxd_trigger_id = SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SW_COMMAND;
    sx_sb_snapshot_trigger_enable_type_e        trigger_type = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_WRED_E;
    sx_macsec_flow_obj_id_t                     flow_obj_id;
    sx_macsec_sa_obj_id_t                       sa_obj_id;

    SX_API_LOG_ENTER();

    /* since ku_read is the start of the buffer */
    ku_read_p = (struct ku_read *)recv_buff_p;

    recv_buff_p += sizeof(struct ku_read);

    buf_len_to_copy = recv_buff_size > EMAD_PACKET_MAX_SIZE ?
                      SXD_EMAD_BUFFER_MAX_SIZE : recv_buff_size - sizeof(struct ku_read);
    memcpy(emad_buff,  recv_buff_p, buf_len_to_copy);

    switch (syndrome_id) {
    case SX_TRAP_ID_PUDE:
        SX_LOG_DBG("Parsing Event ID : PUDE\n");
        data.pude.reg_data = &pude_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing PUDE Emad , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        if (data.pude.reg_data->oper_status == SXD_PORT_OPER_STATUS_UP) {
            event_info_p->pude.oper_state = SX_PORT_OPER_STATUS_UP;
        } else {
            event_info_p->pude.oper_state = SX_PORT_OPER_STATUS_DOWN;
        }
        event_info_p->pude.logical_state = data.pude.reg_data->logical_state_status;

        data.pude.common.dev_id = ku_read_p->dev_id;
        /* build logical port */
        event_info_p->pude.log_port = 0;
        SX_PORT_DEV_ID_SET(event_info_p->pude.log_port, data.pude.common.dev_id);
        SX_PORT_TYPE_ID_SET(event_info_p->pude.log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          data.pude.reg_data->local_port,
                                          data.pude.reg_data->lp_msb);
        SX_PORT_PHY_ID_SET(event_info_p->pude.log_port, local_port);
        receive_info_p->event_info.pude.swid = data.pude.reg_data->swid;

        receive_info_p->source_log_port = event_info_p->pude.log_port;
        receive_info_p->is_lag = 0;
        receive_info_p->source_lag_port = 0;
        SX_LOG_DBG("PUDE parsing info : Oper state: [%s] , Logical state: [%s] , Logical port: 0x%x\n",
                   sx_port_oper_state_str(event_info_p->pude.oper_state),
                   sx_port_logical_state_status_str(event_info_p->pude.logical_state),
                   receive_info_p->source_log_port);
        M_PRINT_PORT_LOG_ID_MEMBERS(receive_info_p->source_log_port);
        break;

    case SX_TRAP_ID_PMPE:
        SX_LOG_DBG("Parsing Event ID : PMPE\n");
        data.pmpe.reg_data = &pmpe_reg_data;
        data.pmpe.common.dev_id = ku_read_p->dev_id;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing PMPE Emad , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        if (data.pmpe.reg_data->module_status == SXD_PMPE_MODULE_STATUS_PLUGGED_ENABLED_E) {
            event_info_p->pmpe.module_state = (sx_port_module_state_t)SX_PORT_OPER_STATUS_UP;
        } else {
            event_info_p->pmpe.module_state = (sx_port_module_state_t)SX_PORT_OPER_STATUS_DOWN;
        }

        err = sxd_status_to_sx_status(
            sxd_dpt_port_module_map_port_get(data.pmpe.common.dev_id,
                                             data.pmpe.reg_data->slot_index,
                                             data.pmpe.reg_data->module,
                                             port_list,
                                             &event_info_p->pmpe.list_size));
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("sxd_dpt_port_module_map_port_get returned error , return value: %s\n", sx_status_str(err));
            goto out;
        }

        for (i = 0; i < event_info_p->pmpe.list_size; i++) {
            event_info_p->pmpe.log_port_list[i] = 0;
            SX_PORT_DEV_ID_SET(event_info_p->pmpe.log_port_list[i], data.pmpe.common.dev_id);
            SX_PORT_TYPE_ID_SET(event_info_p->pmpe.log_port_list[i], SX_PORT_TYPE_NETWORK);
            SX_PORT_PHY_ID_SET(event_info_p->pmpe.log_port_list[i], port_list[i]);

            port_list[i] = SX_PORT_PHY_ID_GET(event_info_p->pmpe.log_port_list[i]);
        }

        event_info_p->pmpe.module_state = (sx_port_module_state_t)data.pmpe.reg_data->module_status;
        event_info_p->pmpe.slot_id = data.pmpe.reg_data->slot_index;
        event_info_p->pmpe.module_id = data.pmpe.reg_data->module;
        if (event_info_p->pmpe.module_state == SX_PORT_MODULE_STATUS_PLUGGED_WITH_ERROR) {
            event_info_p->pmpe.error_type = (uint8_t)data.pmpe.reg_data->error_type;
        } else {
            event_info_p->pmpe.error_type = SX_PORT_MODULE_ERROR_TYPE_RESERVED_E;
        }
        event_info_p->pmpe.device_id = data.pmpe.common.dev_id;
        break;

    case SX_TRAP_ID_NEED_TO_RESOLVE_ARP:
        need_to_resolve_data = (sx_event_need_to_resolve_arp_t*)recv_buff_p;
        SX_LOG_DBG("Got trap NEED_TO_RESOLVE_ARP (%d) for IP %x \n", syndrome_id,
                   need_to_resolve_data->ip_addr.addr.ipv4.s_addr);
        event_info_p->need_to_resolve_arp = *need_to_resolve_data;
        break;

    case SX_TRAP_ID_NO_NEED_TO_RESOLVE_ARP:
        no_need_to_resolve_data = (sx_event_no_need_to_resolve_arp_t*)recv_buff_p;
        SX_LOG_DBG("Got trap NO_NEED_TO_RESOLVE_ARP (%d) for IP %x \n", syndrome_id,
                   no_need_to_resolve_data->ip_addr.addr.ipv4.s_addr);
        event_info_p->no_need_to_resolve_arp = *no_need_to_resolve_data;
        break;

    case SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT:
        rm_sdk_table_notification = (sx_rm_sdk_table_notification_t*)recv_buff_p;
        SX_LOG_DBG("Got trap SX_TRAP_ID_RM_SDK_TABLE_THRESHOLD_EVENT for resource "
                   "%s, threshold full (%u), threshold empty (%u)\n",
                   SX_RESOURCE_MSG(rm_sdk_table_notification->sdk_table_type),
                   rm_sdk_table_notification->is_full,
                   rm_sdk_table_notification->is_empty);
        event_info_p->rm_sdk_table_notification = *rm_sdk_table_notification;
        break;

    case SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT:
        rm_hw_table_notification = (sx_rm_hw_table_notification_t*)recv_buff_p;
        SX_LOG_DBG("Got trap SX_TRAP_ID_RM_HW_TABLE_THRESHOLD_EVENT for resource "
                   "%s, threshold high (%u), threshold low (%u)\n",
                   SX_RESOURCE_MSG(rm_hw_table_notification->hw_table_type),
                   rm_hw_table_notification->is_high,
                   rm_hw_table_notification->is_low);
        event_info_p->rm_hw_table_notification = *rm_hw_table_notification;
        break;

    case SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY:
        router_neigh_activity_notification = (sx_router_neigh_activity_notification_t*)recv_buff_p;
        SX_LOG_DBG("Got trap SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY.\n");
        event_info_p->router_neigh_activity_notification = *router_neigh_activity_notification;
        break;

    case SX_TRAP_ID_ROUTER_MC_ACTIVITY:
        router_mc_route_activity_notification = (sx_router_mc_route_activity_notification_t*)recv_buff_p;
        SX_LOG_DBG("Got trap SX_TRAP_ID_ROUTER_MC_ACTIVITY.\n");
        event_info_p->router_mc_route_activity_notification = *router_mc_route_activity_notification;
        break;

    case SX_TRAP_ID_FDB_IP_ADDR_ACTIVITY:
        fdb_mc_ip_addr_activity_notification = (sx_fdb_mc_ip_addr_activity_notification_t*)recv_buff_p;
        SX_LOG_DBG("Got trap SX_TRAP_ID_FDB_IP_ADDR_ACTIVITY.\n");
        event_info_p->fdb_mc_ip_addr_activity_notification = *fdb_mc_ip_addr_activity_notification;
        break;

    case SX_TRAP_ID_OBJECT_DELETED_EVENT:
        SX_LOG_DBG("Got trap SX_TRAP_ID_OBJECT_DELETED_EVENT.\n");
        event_info_p->deleted_object = *((sx_event_deleted_object_t*)recv_buff_p);
        break;

    case SX_TRAP_ID_API_LOGGER_EVENT:
        SX_LOG_DBG("Got trap SX_TRAP_ID_API_LOGGER_EVENT.\n");
        event_info_p->api_logger_info = *((sx_event_api_logger_t*)recv_buff_p);
        break;

    case SX_TRAP_ID_SDK_HEALTH_EVENT:
        SX_LOG_DBG("Got SX_TRAP_ID_SDK_HEALTH_EVENT.\n");
        event_info_p->sdk_health = *((sx_event_health_notification_t*)recv_buff_p);
        break;

    case SX_TRAP_ID_BULK_REFRESH_COUNTER_DONE_EVENT:
        SX_LOG_DBG("Got SX_TRAP_ID_BULK_REFRESH_COUNTER_DONE_EVENT.\n");
        event_info_p->bulk_cntr_refresh_done_info = *((sx_bulk_cntr_refresh_done_notification_t*)recv_buff_p);
        break;

    case SX_TRAP_ID_BULK_COUNTER_DONE_EVENT:
        SX_LOG_DBG("Got SX_TRAP_ID_BULK_COUNTER_DONE_EVENT.\n");
        event_info_p->bulk_cntr_done_info = *((sx_bulk_cntr_done_notification_t*)recv_buff_p);
        break;

    case SX_TRAP_ID_QUEUE_THRESHOLD_CROSSED:
        SX_LOG_DBG("Parsing Event ID : QUEUE_THRESHOLD_CROSSED\n");
        data.sbctr.reg_data = &sbctr_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing SBCTR EMAD, rc:%s\n", SXD_STATUS_MSG(sxd_err));
            err = SXD_STATUS_TO_SX_STATUS(sxd_err);
            goto out;
        }

        /* tmp patch */
        data.sbctr.common.dev_id = 1;

        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          data.sbctr.reg_data->local_port,
                                          data.sbctr.reg_data->lp_msb);

        SX_LOG(SX_LOG_DEBUG,
               "QUEUE_THRESHOLD_CROSSED: local_port:%#x dir_ing:%u entity:%u fp:%u tclass_vec:%" PRIx64 "\n",
               local_port,
               data.sbctr.reg_data->dir_ing,
               data.sbctr.reg_data->entity,
               data.sbctr.reg_data->fp,
               ((uint64_t)data.sbctr.reg_data->tclass_vector_high << 32) + data.sbctr.reg_data->tclass_vector_low);

        /* Set log port */
        log_port = 0;
        SX_PORT_DEV_ID_SET(log_port, data.sbctr.common.dev_id);
        SX_PORT_TYPE_ID_SET(log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_PHY_ID_SET(log_port, local_port);

        receive_info_p->source_log_port = log_port;
        receive_info_p->is_lag = 0;
        receive_info_p->source_lag_port = 0;

        if (data.sbctr.reg_data->entity == SX_TELE_THRESHOLD_ENTITY_PORT_TC_E) {
            count = 0;

            /* When entity is port_tc: driver re-writes tclass_vec in sbctr
            * High 32 bits masks for the changed TCs
            * Low 32 bits indicates TC value below / above.
            * Valid bits [0..15].
            * Case tclass_vec is zero - no change and all TCs below:
            * We change the event to indicate "port not congested" event */

            if ((data.sbctr.reg_data->tclass_vector_high == 0) && (data.sbctr.reg_data->tclass_vector_low == 0)) {
                event_info_p->queue_threshold_crossed.cnt = 1;
                event_info_p->queue_threshold_crossed.key[0].key_type = SX_TELE_THRESHOLD_TYPE_PORT_E;
                event_info_p->queue_threshold_crossed.key[0].key.port.log_port = log_port;
                event_info_p->queue_threshold_crossed.data[0].type = SX_TELE_THRESHOLD_TYPE_PORT_E;
                event_info_p->queue_threshold_crossed.data[0].data.port = SX_TELE_THRESHOLD_NOT_CONGESTED_E;
            } else {
                tc_vec_mask = data.sbctr.reg_data->tclass_vector_high;
                tc_vec = data.sbctr.reg_data->tclass_vector_low;
                for (tc = 0; tc < SX_EVENT_QUEUE_THRESHOLD_CROSSED_MAX; tc++) {
                    if (tc_vec_mask & 0x1) {
                        if (data.sbctr.reg_data->dir_ing == 0) {
                            event_info_p->queue_threshold_crossed.key[count].key_type =
                                SX_TELE_THRESHOLD_TYPE_PORT_TC_E;
                            event_info_p->queue_threshold_crossed.key[count].key.port_tc.log_port = log_port;
                            event_info_p->queue_threshold_crossed.key[count].key.port_tc.tc = tc;
                            event_info_p->queue_threshold_crossed.data[count].type = SX_TELE_THRESHOLD_TYPE_PORT_TC_E;
                            event_info_p->queue_threshold_crossed.data[count].data.port_tc =
                                (tc_vec & 0x1) ? SX_TELE_ABOVE_THRESHOLD_E : SX_TELE_BELOW_THRESHOLD_E;
                        } else {
                            event_info_p->queue_threshold_crossed.key[count].key_type =
                                SX_TELE_THRESHOLD_TYPE_PORT_PG_E;
                            event_info_p->queue_threshold_crossed.key[count].key.port_pg.log_port = log_port;
                            event_info_p->queue_threshold_crossed.key[count].key.port_pg.pg = tc; /* tc is the running index. */
                            event_info_p->queue_threshold_crossed.data[count].type = SX_TELE_THRESHOLD_TYPE_PORT_PG_E;
                            event_info_p->queue_threshold_crossed.data[count].data.port_pg =
                                (tc_vec & 0x1) ? SX_TELE_ABOVE_THRESHOLD_E : SX_TELE_BELOW_THRESHOLD_E;
                        }

                        count++;
                    }

                    tc_vec_mask = tc_vec_mask >> 1;
                    tc_vec = tc_vec >> 1;
                }
                event_info_p->queue_threshold_crossed.cnt = count;
            }
        } else if (data.sbctr.reg_data->entity == SX_TELE_THRESHOLD_ENTITY_PORT_E) {
            event_info_p->queue_threshold_crossed.cnt = 1;
            event_info_p->queue_threshold_crossed.key[0].key_type = SX_TELE_THRESHOLD_TYPE_PORT_E;
            event_info_p->queue_threshold_crossed.key[0].key.port.log_port = log_port;
            event_info_p->queue_threshold_crossed.data[0].type = SX_TELE_THRESHOLD_TYPE_PORT_E;
            if (data.sbctr.reg_data->fp == SX_TELE_THRESHOLD_CONGESTION_FP_DISABLED_E) {
                if ((data.sbctr.reg_data->tclass_vector_high != 0) || (data.sbctr.reg_data->tclass_vector_low != 0)) { /* Above port threshold */
                    event_info_p->queue_threshold_crossed.data[0].data.port = SX_TELE_THRESHOLD_CONGESTED_E;
                } else { /* Below port threshold */
                    event_info_p->queue_threshold_crossed.data[0].data.port = SX_TELE_THRESHOLD_NOT_CONGESTED_E;
                }
            } else { /* False positive - maybe congested */
                event_info_p->queue_threshold_crossed.data[0].data.port = SX_TELE_THRESHOLD_MAYBE_CONGESTED_E;
            }
        } else {
            SX_LOG_ERR("Wrong value for entity in SBCTR.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_TRAP_ID_BER_MONITOR:
        SX_LOG_DBG("Parsing Event ID : BER_MONITOR\n");
        data.ppbme.reg_data = &ppbme_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparse PPBME EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }
        data.ppbme.common.dev_id = ku_read_p->dev_id;

        /* build logical port */
        log_port = 0;
        SX_PORT_DEV_ID_SET(log_port, data.ppbme.common.dev_id);
        SX_PORT_TYPE_ID_SET(log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          data.ppbme.reg_data->local_port,
                                          data.ppbme.reg_data->lp_msb);
        SX_PORT_PHY_ID_SET(log_port, local_port);
        receive_info_p->event_info.ber_monitor.log_port = log_port;
        receive_info_p->source_log_port = log_port;
        receive_info_p->is_lag = 0;
        receive_info_p->source_lag_port = 0;

        receive_info_p->event_info.ber_monitor.ber_monitor_data.alarm_state =
            data.ppbme.reg_data->monitor_state;
        receive_info_p->event_info.ber_monitor.ber_monitor_data.pre_fec =
            (data.ppbme.reg_data->monitor_type) & 0x01;
        SX_LOG_DBG("PPBME parsing info : alarm state: %u, pre FEC %u , Logical port: 0x%x\n",
                   receive_info_p->event_info.ber_monitor.ber_monitor_data.alarm_state,
                   receive_info_p->event_info.ber_monitor.ber_monitor_data.pre_fec,
                   receive_info_p->event_info.ber_monitor.log_port);

        break;

    case SX_TRAP_ID_BFD_TIMEOUT_EVENT:
        bfd_timeout = (sx_event_bfd_timeout_t*)recv_buff_p;
        SX_LOG_DBG("Got trap SX_TRAP_ID_ROUTER_NEIGH_ACTIVITY.\n");
        event_info_p->bfd_timeout = *bfd_timeout;
        break;

    case SX_TRAP_ID_INFINIBAND_IB_FMAD_RCV:
        SX_LOG_DBG("Parsing Event ID : IB_FMAD_RCV\n");
        data.ibfmr.reg_data = &ibfmr_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing IBFMR Emad , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        event_info_p->ibfmr.attribute_is_valid = data.ibfmr.reg_data->atm_v;
        event_info_p->ibfmr.attribute_id = data.ibfmr.reg_data->attribute_id;
        event_info_p->ibfmr.attribute_modifier = data.ibfmr.reg_data->attribute_modifier;

        SX_LOG_DBG("IBFMR parsing info : Attribute Valid: [%d], Attribute ID: 0x%x, Attribute Modifier: 0x%x\n",
                   event_info_p->ibfmr.attribute_is_valid, event_info_p->ibfmr.attribute_id,
                   event_info_p->ibfmr.attribute_modifier);
        break;

    case SX_TRAP_ID_PORT_ADDED:
    /* fall through */
    case SX_TRAP_ID_PORT_DELETED:
        port_added_or_deleted_p = (sx_event_port_added_deleted_t*)recv_buff_p;
        event_info_p->port_added_or_deleted = *port_added_or_deleted_p;
        break;

    case SX_TRAP_ID_PORT_ADDED_TO_LAG:
    /* fall through */
    case SX_TRAP_ID_PORT_REMOVED_FROM_LAG:
        port_lag_changes_p = (sx_event_port_lag_changes_t*)recv_buff_p;
        event_info_p->port_lag_changes = *port_lag_changes_p;
        break;

    case SX_TRAP_ID_TMPW:
        SX_LOG_DBG("Parsing Event ID : TMPW \n");

        data.mtewe.reg_data = &mtewe_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing MTEWE Emad , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        event_info_p->tmpw.slot_id = data.mtewe.reg_data->slot_index;
        event_info_p->tmpw.sensor_count = data.mtewe.reg_data->sensor_count;
        event_info_p->tmpw.sensor_id_max = data.mtewe.reg_data->last_sensor;
        event_info_p->tmpw.sensors_id_mask =
            data.mtewe.reg_data->sensor_warning[(SX_EVENT_TEMP_WARNING_SENSOR_MAP_MAX - 1)];
        /* Copy data from last index as sensor map is written in reverse order by FW */
        for (i = 0; i < SX_EVENT_TEMP_WARNING_SENSOR_MAP_MAX; i++) {
            event_info_p->tmpw.sensors_id_map[i] =
                data.mtewe.reg_data->sensor_warning[SX_EVENT_TEMP_WARNING_SENSOR_MAP_MAX - (i + 1)];
        }
        event_info_p->tmpw.device_id = ku_read_p->dev_id;
        SX_LOG_DBG("TMPW parsing info : event_info_p->tmpw.slot_id: %d\n",
                   event_info_p->tmpw.slot_id);

        break;

    case SX_TRAP_ID_TSDE:
        SX_LOG_DBG("Parsing Event ID : TSDE \n");

        data.mtsde.reg_data = &mtsde_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing MTSDE Emad , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        event_info_p->tsde.slot_id = mtsde_reg_data.slot_index;
        event_info_p->tsde.sensor_count = mtsde_reg_data.sensor_count;
        event_info_p->tsde.sensor_id_max = mtsde_reg_data.last_sensor;
        event_info_p->tsde.sensors_id_mask =
            mtsde_reg_data.sensor_shut_down_map[(SX_EVENT_TEMP_SHUT_DOWN_SENSOR_MAP_MAX - 1)];
        /* Copy data from last index as sensor map is written in reverse order by FW */
        for (i = 0; i < SX_EVENT_TEMP_SHUT_DOWN_SENSOR_MAP_MAX; i++) {
            event_info_p->tsde.sensors_id_map[i] =
                mtsde_reg_data.sensor_shut_down_map[SX_EVENT_TEMP_SHUT_DOWN_SENSOR_MAP_MAX - (i + 1)];
        }

        SX_LOG_DBG("TSDE parsing info : slot_id: %d\n",
                   event_info_p->tsde.slot_id);

        break;

    case SX_TRAP_ID_DSDSC:
        SX_LOG_DBG("Parsing Event ID : DSDSC \n");

        data.mddq.reg_data = &mddq_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing MDDQ Emad , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        event_info_p->dsdsc.slot_id = mddq_reg_data.slot_index;
        event_info_p->dsdsc.slot_description.slot_card_ini_info.slot_card_hw_revision =
            mddq_reg_data.data.mddq_slot_info.hw_revision;
        event_info_p->dsdsc.slot_description.slot_card_ini_info.slot_card_minor_ini_version =
            mddq_reg_data.data.mddq_slot_info.ini_file_version;

        event_info_p->dsdsc.slot_description.slot_card_type =
            mddq_reg_data.data.mddq_slot_info.card_type;

        event_info_p->dsdsc.slot_description.slot_state_info.is_slot_card_provisioned =
            mddq_reg_data.data.mddq_slot_info.provisioned;
        event_info_p->dsdsc.slot_description.slot_state_info.is_slot_card_valid =
            mddq_reg_data.data.mddq_slot_info.sr_valid;
        event_info_p->dsdsc.slot_description.slot_state_info.is_slot_card_ready =
            mddq_reg_data.data.mddq_slot_info.lc_ready;
        event_info_p->dsdsc.slot_description.slot_state_info.is_slot_card_active =
            mddq_reg_data.data.mddq_slot_info.active;
        event_info_p->dsdsc.slot_description.slot_state_info.slot_id =
            mddq_reg_data.slot_index;

        SX_LOG_DBG("DSDSC parsing info : slot_id: %d\n",
                   event_info_p->dsdsc.slot_id);

        break;

    case SX_TRAP_ID_BCTOE:
        SX_LOG_DBG("Parsing Event ID : BCTOE \n");
        data.mbct.reg_data = &mbct_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing MBCT Emad , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        event_info_p->bctoe.slot_id = mbct_reg_data.slot_index;
        event_info_p->bctoe.ini_status = (sx_mgmt_slot_ini_status_e)mbct_reg_data.ini_status;
        event_info_p->bctoe.ini_oper_status = (sx_mgmt_slot_ini_oper_status_e)mbct_reg_data.status;

        SX_LOG_DBG("BCTOE parsing info : slot_id: %d, ini_status [%d], ini_oper_status[%d]\n",
                   event_info_p->bctoe.slot_id, event_info_p->bctoe.ini_status,
                   event_info_p->bctoe.ini_oper_status);
        break;

    case SX_TRAP_ID_PMLPE:
        SX_LOG_DBG("Parsing Event ID : PMLPE \n");
        data.pmlpe.reg_data = &pmlpe_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing PMLPE Emad , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }
        data.pmlpe.common.dev_id = ku_read_p->dev_id;

        /* Set log port */

        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          data.pmlpe.reg_data->local_port,
                                          data.pmlpe.reg_data->lp_msb);

        log_port = 0;
        SX_PORT_DEV_ID_SET(log_port, data.pmlpe.common.dev_id);
        SX_PORT_TYPE_ID_SET(log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_PHY_ID_SET(log_port, local_port);

        event_info_p->pmlpe.log_port = log_port;
        event_info_p->pmlpe.port_mapping.local_port = local_port;
        event_info_p->pmlpe.port_mapping.width = data.pmlpe.reg_data->width;
        if (event_info_p->pmlpe.port_mapping.width > 0) {
            event_info_p->pmlpe.port_mapping.mapping_mode = SX_PORT_MAPPING_MODE_ENABLE;
        } else {
            event_info_p->pmlpe.port_mapping.mapping_mode = SX_PORT_MAPPING_MODE_DISABLE;
        }
        event_info_p->pmlpe.port_mapping.slot = data.pmlpe.reg_data->lane_module_mapping[0].slot_index;
        event_info_p->pmlpe.port_mapping.module_port = data.pmlpe.reg_data->lane_module_mapping[0].module;

        event_info_p->pmlpe.port_mapping.lane_bmap = 0;
        for (i = 0; i < event_info_p->pmlpe.port_mapping.width; i++) {
            tx_lane = data.pmlpe.reg_data->lane_module_mapping[i].tx_lane;
            event_info_p->pmlpe.port_mapping.lane_bmap = (1 << tx_lane);
        }

        SX_LOG_DBG("PMLPE parsing info : log_port: 0x%x\n",
                   event_info_p->pmlpe.log_port);

        break;

    case SX_TRAP_ID_QUEUE_SNAPSHOT_TRIGGER_EVENT:
        SX_LOG_DBG("Parsing Event ID : QUEUE_SNAPSHOT_TRIGGER\n");
        data.sbsns.reg_data = &sbsns_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing SBSNS EMAD, rc:%s\n", SXD_STATUS_MSG(sxd_err));
            err = SXD_STATUS_TO_SX_STATUS(sxd_err);
            goto out;
        }

        event_info_p->sb_snapshot.snapshot_information.sb_snapshot_status = data.sbsns.reg_data->status;
        event_info_p->sb_snapshot.snapshot_information.sb_last_snapshot_trigger.type = data.sbsns.reg_data->trigger_id;

        sxd_trigger_id = (sxd_snapshot_trigger_id_t)data.sbsns.reg_data->trigger_id;
        err = __parse_sb_snapshot_trigger_info(sxd_trigger_id, &trigger_type);
        if (err) {
            SX_LOG_ERR("Error parsing trigger type, rc:%s\n", SX_STATUS_MSG(err));
            goto out;
        }
        err = __sb_snapshot_information_get(trigger_type, data.sbsns,
                                            &event_info_p->sb_snapshot.snapshot_information);
        if (err) {
            SX_LOG_ERR("Error getting snapshot information, rc:%s\n", SX_STATUS_MSG(err));
            goto out;
        }
        break;

    case SX_TRAP_ID_ACL_ACTIVITY:
        SX_LOG_DBG("Got SX_TRAP_ID_ACL_ACTIVITY.\n");
        event_info_p->acl_activity_notification = *((sx_acl_activity_notification_t*)recv_buff_p);
        break;

    case SX_TRAP_ID_UTFD:
        SX_LOG_DBG("Parsing Event ID : UTFD \n");
        data.utfd.reg_data = &utfd_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error deparsing UTFD Emad , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }

        event_info_p->utfd.event_id = (sx_macsec_event_id_e)utfd_reg_data.ucheck_id;
        SX_PORT_DEV_ID_SET(event_info_p->utfd.log_port, data.utfd.common.dev_id);
        SX_PORT_TYPE_ID_SET(event_info_p->utfd.log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          utfd_reg_data.local_port,
                                          utfd_reg_data.lp_msb);
        SX_PORT_PHY_ID_SET(event_info_p->utfd.log_port, local_port);
        if (utfd_reg_data.side == SXD_UTFD_SIDE_HOST_SIDE_E) {
            event_info_p->utfd.direction = SX_MACSEC_DIR_EGRESS_E;
        } else {
            event_info_p->utfd.direction = SX_MACSEC_DIR_INGRESS_E;
        }

        event_info_p->utfd.flow_obj_id_valid = utfd_reg_data.secy_v;
        if (utfd_reg_data.secy_v) {
            SX_MACSEC_BUILD_OBJ_ID_FROM_PORT_DIR(flow_obj_id,
                                                 SX_MACSEC_ENTITY_FLOW_E,
                                                 utfd_reg_data.secy,
                                                 event_info_p->utfd.log_port,
                                                 event_info_p->utfd.direction);
            event_info_p->utfd.flow_obj_id = flow_obj_id;
        }
        event_info_p->utfd.sa_obj_id_valid = utfd_reg_data.sadb_v;
        if (utfd_reg_data.sadb_v) {
            SX_MACSEC_BUILD_OBJ_ID_FROM_PORT_DIR(sa_obj_id,
                                                 SX_MACSEC_ENTITY_SA_E,
                                                 utfd_reg_data.sadb_entry_index,
                                                 event_info_p->utfd.log_port,
                                                 event_info_p->utfd.direction);
            event_info_p->utfd.sa_obj_id = sa_obj_id;
        }
        break;

    case SX_TRAP_ID_STATEFUL_DB_PARTITION_THRESHOLD_CROSSED:
        SX_LOG_DBG("Parsing Event ID: Stateful DB partition threshold cross event.\n");
        data.fsps.reg_data = &fsps_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed to deparse FSPS EMAD, return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SXD_STATUS_TO_SX_STATUS(sxd_err);
            goto out;
        }

        event_info_p->partition_threshold.max_threshold = fsps_reg_data.max_threshold;
        event_info_p->partition_threshold.warning_threshold = fsps_reg_data.warning_threshold;
        event_info_p->partition_threshold.occupancy = fsps_reg_data.occupancy;
        event_info_p->partition_threshold.partition_id = fsps_reg_data.partition_id;
        if (fsps_reg_data.tbm) {
            event_info_p->partition_threshold.threshold_type = SX_STATEFUL_DB_PARTITION_MAX_THRESHOLD_E;
        } else if (fsps_reg_data.tbw) {
            event_info_p->partition_threshold.threshold_type = SX_STATEFUL_DB_PARTITION_WARNING_THRESHOLD_E;
        } else {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Both max and warning triggers are down.\n");
            goto out;
        }
        break;

    case SX_TRAP_ID_PLLP:
        SX_LOG_DBG("Parsing Event : PLLP \n");
        data.pllp.reg_data = &pllp_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing PLLP EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }
        event_info_p->pllp.local_port = data.pllp.reg_data->local_port;
        event_info_p->pllp.lp_msb = data.pllp.reg_data->lp_msb;
        event_info_p->pllp.label_port = data.pllp.reg_data->label_port;
        event_info_p->pllp.maf = data.pllp.reg_data->maf;
        event_info_p->pllp.is_fnm = data.pllp.reg_data->is_fnm;
        SX_LOG_DBG("PLLP event parsing info : label_port: 0x%x, maf 0x%x\n",
                   event_info_p->pllp.label_port, event_info_p->pllp.maf);
        break;

    case SX_TRAP_ID_TAC_ACTION_DONE:
        SX_LOG_DBG("Parsing Event : TAC action done event \n");
        data.htacg.reg_data = &htacg_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing HTACG EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }
        event_info_p->tac_action_done.action_done =
            (data.htacg.reg_data->status == SXD_HTACG_STATUS_DONE) ? TRUE : FALSE;
        SX_LOG_DBG("TAC_ACTION_DONE event parsing info : tac_action_done: %d\n",
                   event_info_p->tac_action_done.action_done);
        break;

    case SX_TRAP_ID_PORT_TX_READY:
        SX_LOG_DBG("Parsing Event: PTSE.\n");
        data.ptse.reg_data = &ptse_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Error de-parsing PTSE EMAD, return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SXD_STATUS_TO_SX_STATUS(sxd_err);
            goto out;
        }
        event_info_p->tx_ready.log_port = 0;
        SX_PORT_DEV_ID_SET(event_info_p->tx_ready.log_port, ku_read_p->dev_id);
        SX_PORT_TYPE_ID_SET(event_info_p->tx_ready.log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          data.ptse.reg_data->local_port,
                                          data.ptse.reg_data->lp_msb);
        SX_PORT_PHY_ID_SET(event_info_p->tx_ready.log_port, local_port);
        event_info_p->tx_ready.state = (sx_port_tx_ready_state_e)ptse_reg_data.tx_ready;
        SX_LOG_DBG("PTSE event parsing info: log_port: 0x%x, tx_ready %d (%s).\n",
                   event_info_p->tx_ready.log_port, event_info_p->tx_ready.state,
                   sx_port_tx_ready_state_str(event_info_p->tx_ready.state));
        break;

    case SX_TRAP_ID_MFRI:
        SX_LOG_DBG("Parsing Event : MFRI \n");
        data.mfri.reg_data = &mfri_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing MFRI EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }
        data.mfri.common.dev_id = ku_read_p->dev_id;
        /* build logical port */
        event_info_p->mfri.log_port = 0;
        SX_PORT_DEV_ID_SET(event_info_p->mfri.log_port, data.mfri.common.dev_id);
        SX_PORT_TYPE_ID_SET(event_info_p->mfri.log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_PHY_ID_SET(event_info_p->mfri.log_port, data.mfri.reg_data->port);
        event_info_p->mfri.trigger = data.mfri.reg_data->trigger;
        event_info_p->mfri.thr_type = data.mfri.reg_data->thr_type;
        event_info_p->mfri.field_select = data.mfri.reg_data->field_select;
        event_info_p->mfri.fields_overflow = data.mfri.reg_data->fields_overflow;
        event_info_p->mfri.num_errors = data.mfri.reg_data->num_errors;
        event_info_p->mfri.num_warnings = data.mfri.reg_data->num_warnings;
        event_info_p->mfri.min_value = data.mfri.reg_data->min_value;
        event_info_p->mfri.max_value = data.mfri.reg_data->max_value;
        event_info_p->mfri.consecutive_normal = data.mfri.reg_data->consecutive_normal;
        event_info_p->mfri.last_value_0 = data.mfri.reg_data->last_value[0];
        event_info_p->mfri.last_value_1 = data.mfri.reg_data->last_value[1];
        event_info_p->mfri.last_value_2 = data.mfri.reg_data->last_value[2];

        SX_LOG_DBG("MFRI event parsing info : log_port: 0x%x, trigger 0x%x\n",
                   event_info_p->mfri.log_port, event_info_p->mfri.trigger);
        break;

    case SX_TRAP_ID_PPIR:
        SX_LOG_DBG("Parsing Event : PPIR \n");
        data.ppir.reg_data = &ppir_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing PPIR EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }
        /* build logical port */
        event_info_p->ppir.log_port = 0;
        SX_PORT_DEV_ID_SET(event_info_p->ppir.log_port, data.ppir.common.dev_id);
        SX_PORT_TYPE_ID_SET(event_info_p->ppir.log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          ppir_reg_data.local_port,
                                          ppir_reg_data.lp_msb);
        SX_PORT_PHY_ID_SET(event_info_p->ppir.log_port, local_port);

        event_info_p->ppir.lcnf_pln = data.ppir.reg_data->lcnf_pln;
        event_info_p->ppir.lpnf_phy = data.ppir.reg_data->lpnf_phy;
        event_info_p->ppir.lpnf_no_hcd = data.ppir.reg_data->lpnf_no_hcd;
        event_info_p->ppir.peer_p_type = data.ppir.reg_data->peer_p_type;
        event_info_p->ppir.peer_num_of_planes = data.ppir.reg_data->peer_num_of_planes;

        SX_LOG_DBG(
            "PPIR event parsing info : log_port: 0x%x, lcnf_pln 0x%x, lpnf_phy 0x%x, lpnf_no_hcd 0x%x, peer_p_type 0x%x, peer_num_of_planes 0x%x\n",
            event_info_p->ppir.log_port,
            event_info_p->ppir.lcnf_pln,
            event_info_p->ppir.lpnf_phy,
            event_info_p->ppir.lpnf_no_hcd,
            event_info_p->ppir.peer_p_type,
            event_info_p->ppir.peer_num_of_planes);
        break;

    case SX_TRAP_ID_MFCDR:
        SX_LOG_DBG("Parsing Event : MFCDR \n");
        data.mfcdr.common.dev_id = ku_read_p->dev_id;
        data.mfcdr.reg_data = &mfcdr_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing MFCDR EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }
        /* build logical port */
        event_info_p->mfcdr.log_port = 0;
        SX_PORT_DEV_ID_SET(event_info_p->mfcdr.log_port, data.mfcdr.common.dev_id);
        SX_PORT_TYPE_ID_SET(event_info_p->mfcdr.log_port, SX_PORT_TYPE_NETWORK);
        SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port,
                                          mfcdr_reg_data.local_port,
                                          mfcdr_reg_data.lp_msb);
        SX_PORT_PHY_ID_SET(event_info_p->mfcdr.log_port, local_port);

        event_info_p->mfcdr.status = data.mfcdr.reg_data->status;

        SX_LOG_DBG(
            "MFCDR event parsing info : log_port: 0x%x, status 0x%x\n",
            event_info_p->mfcdr.log_port,
            event_info_p->mfcdr.status);
        break;

    case SX_TRAP_ID_IBISSU:
        SX_LOG_DBG("Parsing Event : IBISSU \n");
        data.ibissu.reg_data = &ibissu_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing IBISSU EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }
        event_info_p->ibissu.sm_approve = data.ibissu.reg_data->sm_approve;

        SX_LOG_DBG(
            "IBISSU event parsing info : sm_approve: 0x%x\n",
            event_info_p->ibissu.sm_approve);
        break;

    case SX_TRAP_ID_SPZR:
        SX_LOG_DBG("Parsing Event : SPZR \n");
        data.spzr.reg_data = &spzr_reg_data;
        sxd_err = sxd_emad_deparse(&data, emad_buff, buf_len_to_copy, &reg_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG(SX_LOG_ERROR, "Error de-parsing SPZR EMAD , return value: %s\n", SXD_STATUS_MSG(sxd_err));
            err = SX_STATUS_CMD_ERROR;
            goto out;
        }
        event_info_p->spzr.infrastructure_ip_type = data.spzr.reg_data->infrastructure_ip_type;
        event_info_p->spzr.infrastructure_ip = data.spzr.reg_data->infrastructure_ip;

        SX_LOG_DBG(
            "SPZR event parsing info : infrastructure_ip_type: 0x%x, infrastructure_ip 0x%x\n",
            event_info_p->spzr.infrastructure_ip_type,
            event_info_p->spzr.infrastructure_ip);
        break;

    default:
        SX_LOG_ERR("Syndrome id [%u] is not supported yet\n", syndrome_id);
        err = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

static sx_status_t __lag_port_index_get(sx_port_log_id_t lag_port,
                                        sx_port_log_id_t log_port,
                                        uint16_t        *port_index)
{
    static int    err, shmid = -1;
    static size_t size;
    sx_lag_id_t   lid;
    uint16_t      i = 0;

    if (port_index == NULL) {
        return SX_STATUS_PARAM_NULL;
    }
    /* On first call to this function, open shared memory for mapping DB.
     * The shared memory can be stale since the SDK has closed it.
     * We check that it's valid and map it again if not.
     */
    if ((port_indices_db_p == NULL) || (port_indices_db_p->valid == FALSE)) {
        err = cl_shm_open(LAG_SHM_PATH, &shmid);
        if (err) {
            SX_LOG_ERR("Failed to open the LAG shared memory\n");
            port_indices_db_p = NULL;
            return SX_STATUS_ERROR;
        }

        port_indices_db_p = mmap(NULL, sizeof(sx_ladb_port_indices_t), PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
        if (port_indices_db_p == MAP_FAILED) {
            SX_LOG_ERR("Failed to map the LAG shared memory\n");
            port_indices_db_p = NULL;
            close(shmid);
            return SX_STATUS_ERROR;
        }

        size = sizeof(sx_ladb_port_indices_t) +
               port_indices_db_p->max_lag_ports * port_indices_db_p->max_lid * sizeof(sx_ladb_port_data_t);

        err = munmap(port_indices_db_p, sizeof(sx_ladb_port_indices_t));
        if (err == -1) {
            SX_LOG_ERR("Failed to unmap the LAG shared memory\n");
            return SX_STATUS_ERROR;
        }

        port_indices_db_p = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
        close(shmid);
        if (port_indices_db_p == MAP_FAILED) {
            SX_LOG_ERR("Failed to map the LAG shared memory\n");
            port_indices_db_p = NULL;
            return SX_STATUS_ERROR;
        }
    }

    lid = SX_PORT_LAG_ID_GET(lag_port);
    /* locate the log port according to parameters */
    if (lid > port_indices_db_p->max_lid) {
        SX_LOG_ERR("LAG : Bad parameter for function __lag_port_index_get\n");
        return SX_STATUS_PARAM_ERROR;
    }

    cl_plock_acquire(&port_indices_db_p->p_lock);

    for (i = 0; i < port_indices_db_p->max_lag_ports; i++) {
        /* If log port is invalid, return the first valid lag port member */
        if (log_port == SX_INVALID_PORT) {
            if (port_indices_db_p->lag_ports[GET_LAG_PORTS_INDEX(port_indices_db_p, lid,
                                                                 i)].port != SX_INVALID_PORT) {
                break;
            }
        } else if (log_port == port_indices_db_p->lag_ports[GET_LAG_PORTS_INDEX(port_indices_db_p, lid, i)].port) {
            break;
        }
    }

    cl_plock_release(&port_indices_db_p->p_lock);
    if ((log_port != SX_INVALID_PORT) && (i == port_indices_db_p->max_lag_ports)) {
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    *port_index = i;

    return SX_STATUS_SUCCESS;
}

static sx_status_t __lag_port_index_to_log_port(sx_access_cmd_t   access_cmd,
                                                sx_port_log_id_t  lag_port,
                                                uint16_t          port_index,
                                                sx_port_log_id_t *log_port)
{
    static int              err, shmid = -1;
    static size_t           size;
    sx_lag_id_t             lid;
    sx_ladb_port_indices_t *tmp_port_indices_db_p = NULL;

    if (log_port == NULL) {
        return SX_STATUS_PARAM_NULL;
    }

    *log_port = 0;

    if (access_cmd == SX_ACCESS_CMD_DESTROY) {
        if (port_indices_db_p == NULL) {
            return SX_STATUS_SUCCESS;
        }

        err = munmap(port_indices_db_p, size);
        port_indices_db_p = NULL;
        size = 0;
        if (err) {
            SX_LOG_ERR("Failed to unmap the LAG shared memory\n");
            return SX_STATUS_ERROR;
        }
        err = close(shmid);
        if (err) {
            SX_LOG_ERR("Failed to close the LAG shared memory FD\n");
            return SX_STATUS_ERROR;
        }
        return SX_STATUS_SUCCESS;
    }

    if (access_cmd != SX_ACCESS_CMD_GET) {
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    /* On first call to this function, open shared memory for mapping DB.
     * The shared memory can be stale since the SDK has closed it.
     * We check that it's valid and map it again if not.
     * <lid, port_index> -> <log_port> */
    if ((port_indices_db_p == NULL) || (port_indices_db_p->valid == FALSE)) {
        err = cl_shm_open(LAG_SHM_PATH, &shmid);
        if (err) {
            SX_LOG_ERR("Failed to open the LAG shared memory\n");
            port_indices_db_p = NULL;
            return SX_STATUS_ERROR;
        }

        /* Use map shared memory to a temporary pointer
         * in order to extract actual DB size */
        tmp_port_indices_db_p =
            mmap(NULL, sizeof(sx_ladb_port_indices_t), PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
        if (tmp_port_indices_db_p == MAP_FAILED) {
            close(shmid);
            SX_LOG_ERR("Failed to map the LAG shared memory\n");
            /* coverity[memory_leak] */
            return SX_STATUS_ERROR;
        }

        size = sizeof(sx_ladb_port_indices_t) +
               tmp_port_indices_db_p->max_lag_ports * tmp_port_indices_db_p->max_lid * sizeof(sx_ladb_port_data_t);

        /* Use lock in order to prevent multi threading environment from
         * map the global port_indices_db_p pointer more than once  */
        cl_plock_acquire(&tmp_port_indices_db_p->p_lock);
        port_indices_db_p = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
        close(shmid);
        if (port_indices_db_p == MAP_FAILED) {
            port_indices_db_p = NULL;
            cl_plock_release(&tmp_port_indices_db_p->p_lock);
            SX_LOG_ERR("Failed to map the LAG shared memory\n");
            err = munmap(tmp_port_indices_db_p, sizeof(sx_ladb_port_indices_t));
            if (err == -1) {
                SX_LOG_ERR("Failed to unmap the LAG shared memory\n");
            }
            tmp_port_indices_db_p = NULL;
            return SX_STATUS_ERROR;
        }
        cl_plock_release(&tmp_port_indices_db_p->p_lock);

        /* Unmap the temporary pointer */
        err = munmap(tmp_port_indices_db_p, sizeof(sx_ladb_port_indices_t));
        if (err == -1) {
            SX_LOG_ERR("Failed to unmap the LAG shared memory\n");
            return SX_STATUS_ERROR;
        }
    }

    lid = SX_PORT_LAG_ID_GET(lag_port);
    /* locate the log port according to parameters */
    if ((lid > port_indices_db_p->max_lid) || (log_port == NULL) || (port_index > port_indices_db_p->max_lag_ports)) {
        SX_LOG_ERR("LAG : Bad parameters for function sx_api_lag_port_index_to_log_port\n");
        return SX_STATUS_PARAM_ERROR;
    }

    cl_plock_acquire(&port_indices_db_p->p_lock);
    *log_port = port_indices_db_p->lag_ports[GET_LAG_PORTS_INDEX(port_indices_db_p, lid, port_index)].port;
    cl_plock_release(&port_indices_db_p->p_lock);
    if (*log_port == INVALID_LAG_LOG_PORT) {
        return SX_STATUS_ENTRY_NOT_FOUND;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __port_lag_reverse_get(uint16_t          lag_id,
                                          uint16_t          lag_port_index,
                                          sx_port_log_id_t *port_id_p,
                                          sx_port_log_id_t *lag_port)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_PORT_TYPE_ID_SET(*lag_port, SX_PORT_TYPE_LAG);

    SX_PORT_LAG_ID_SET(*lag_port, lag_id);

    err = __lag_port_index_to_log_port(SX_ACCESS_CMD_GET, *lag_port,
                                       lag_port_index, port_id_p);
    if (err == SX_STATUS_ENTRY_NOT_FOUND) {
        /* If a packet was received from a port which is no longer part of a lag
         *  SX_INVALID_PORT will be returned in the receive info */
        err = SX_STATUS_SUCCESS;
        *port_id_p = SX_INVALID_PORT;
    }

    return err;
}

static sx_status_t __port_uc_route_reverse_get(IN sx_access_cmd_t      cmd,
                                               IN sx_port_ucroute_id_t ucroute_id,
                                               OUT sx_port_id_t       *port_id_p)
{
    sxd_status_t     sxd_rc = SXD_STATUS_SUCCESS;
    sx_status_t      rc = SX_STATUS_SUCCESS;
    sxd_dev_id_t     dev_id;
    sx_port_phy_id_t local_port;

    SX_API_LOG_ENTER();

    SX_LOG_DBG("Attempt to Retrieve Port-ID of UC-Route 0x%04X\n", ucroute_id);

    *port_id_p = 0;

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if ((UCROUTE_PREFIX_MASK & ucroute_id) == UCROUTE_CPU_PORT_PREFIX) {
            SX_PORT_DEV_ID_SET(*port_id_p,
                               ((ucroute_id & UCROUTE_CPU_PORT_DEV_MASK) >> UCROUTE_CPU_DEV_BIT_OFFSET));
            SX_PORT_PHY_ID_SET(*port_id_p, CPU_PORT_PHY_ID);
        } else {
            /* UCroute phy ID is zero based - adjust it */
            sxd_rc = sxd_dpt_get_local_port_by_uc_route(ucroute_id, &dev_id, &local_port);
            if (sxd_rc != SXD_STATUS_SUCCESS) {
                rc = SXD_STATUS_TO_SX_STATUS(sxd_rc);
                SX_LOG_ERR("__port_lag_reverse_get error %s\n", sx_status_str(rc));
                goto out;
            }

            SX_PORT_PHY_ID_SET(*port_id_p, local_port);
            SX_PORT_DEV_ID_SET(*port_id_p, dev_id);
        }

        SX_PORT_TYPE_ID_SET(*port_id_p, SX_PORT_TYPE_NETWORK);
        break;

    default:
        SX_LOG_ERR("Unsupported access-command (%s)\n", sx_access_cmd_str(cmd));
        SX_API_LOG_EXIT();
        return SX_STATUS_CMD_UNSUPPORTED;
    }

    SX_LOG_DBG("Success in Retrieve Port-ID of UC-Route 0x%04X = 0x%08X\n", ucroute_id, *port_id_p);

out:
    SX_API_LOG_EXIT();
    return rc;
}

static sx_status_t __parse_trap(char              *buffer_p,
                                void              *packet_p,
                                uint32_t          *packet_size_p,
                                sx_receive_info_t *receive_info_p)
{
    sx_status_t     err = SX_STATUS_SUCCESS;
    struct ku_read *ku_read_p = NULL;

    /* parse received data */
    ku_read_p = (struct ku_read *)buffer_p;
    if (packet_size_p[0] < ku_read_p->length) {
        SX_LOG_ERR("Allocated RX buffer size is not big enough, "
                   "allocated buffer size: %" PRIu32 "\n"
                   "received buffer size:%" PRIu64 "\n",
                   packet_size_p[0],
                   ku_read_p->length);
        err = SX_STATUS_MESSAGE_SIZE_EXCEEDS_LIMIT;
        goto free_out;
    }
    packet_size_p[0] = ku_read_p->length;

    if (ku_read_p->is_lag) {
        err = __port_lag_reverse_get(ku_read_p->system_port,
                                     ku_read_p->lag_subport,
                                     &(receive_info_p->source_log_port),
                                     &receive_info_p->source_lag_port);
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__port_lag_reverse_get error %u\n", err);
            goto free_out;
        }

        receive_info_p->is_lag = 1;
    } else {
        /* translate uc route to log port */
        err = __port_uc_route_reverse_get(SX_ACCESS_CMD_GET,
                                          ku_read_p->system_port,
                                          &(receive_info_p->source_log_port));
        if (err != SX_STATUS_SUCCESS) {
            SX_LOG_ERR("__port_uc_route_reverse_get error %u\n", err);
            goto free_out;
        }

        receive_info_p->is_lag = 0;
        receive_info_p->source_lag_port = 0;
    }

    if (ku_read_p->dest_sysport == 0xFFFF) {
        receive_info_p->dest_port_type = SX_RECEIVE_DEST_PORT_INVALID_E;
        receive_info_p->dest_log_port = SX_INVALID_PORT;
        receive_info_p->dest_lag_port = SX_INVALID_PORT;
    } else if (ku_read_p->dest_sysport == 0xFFFE) {
        receive_info_p->dest_port_type = SX_RECEIVE_DEST_PORT_MULTI_PORT_E;
        receive_info_p->dest_log_port = SX_INVALID_PORT;
        receive_info_p->dest_lag_port = SX_INVALID_PORT;
    } else {
        if (ku_read_p->dest_is_lag) {
            receive_info_p->dest_port_type = SX_RECEIVE_DEST_PORT_LAG_PORT_E;
            err = __port_lag_reverse_get(ku_read_p->dest_sysport,
                                         ku_read_p->dest_lag_subport,
                                         &receive_info_p->dest_log_port,
                                         &receive_info_p->dest_lag_port);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__port_lag_reverse_get error %u\n", err);
                goto free_out;
            }
        } else {
            receive_info_p->dest_port_type = SX_RECEIVE_DEST_PORT_NETWORK_PORT_E;
            /* translate uc route to log port */
            err = __port_uc_route_reverse_get(SX_ACCESS_CMD_GET,
                                              ku_read_p->dest_sysport,
                                              &receive_info_p->dest_log_port);
            if (err != SX_STATUS_SUCCESS) {
                SX_LOG_ERR("__port_uc_route_reverse_get error %u\n", err);
                goto free_out;
            }
            receive_info_p->dest_lag_port = SX_INVALID_PORT;
        }
    }

    /*copy to packet_p*/
    SX_MEM_CPY_BUF(packet_p, ku_read_p + 1, ku_read_p->length);
    SX_LOG_DBG("Received packet from device successfully! , packet size %" PRIu64 "\n", ku_read_p->length);

free_out:
    return err;
}

static sx_status_t __lcl_port_uc_route_get(IN sx_port_id_t port_id, OUT sx_port_ucroute_id_t *ucroute_id_p)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    sxd_status_t sxd_rc;

    SX_API_LOG_ENTER();

    SX_LOG_DBG("Attempt to Retrieve UC-Route of Port 0x%08X\n", port_id);

    if (SX_PORT_PHY_ID_GET(port_id) == CPU_PORT_PHY_ID) {
        /* Build CPU port route*/
        *ucroute_id_p = UCROUTE_CPU_PORT_PREFIX;
        *ucroute_id_p |= SX_PORT_DEV_ID_GET(port_id) << UCROUTE_CPU_DEV_BIT_OFFSET;
    } else {
        sxd_rc = sxd_dpt_get_uc_route_by_local_port(SX_PORT_DEV_ID_GET(port_id),
                                                    SX_PORT_PHY_ID_GET(port_id), ucroute_id_p);
        if (sxd_rc != SXD_STATUS_SUCCESS) {
            rc = SXD_STATUS_TO_SX_STATUS(sxd_rc);
            SX_LOG_ERR("sxd_dpt_get_uc_route_by_local_port error %s\n", sx_status_str(rc));
            goto out;
        }
    }

    SX_LOG_DBG("Success in Retrieve UC-Route of Port 0x%08X = 0x%04X\n", port_id, *ucroute_id_p);

out:
    SX_API_LOG_EXIT();

    return rc;
}

static sx_status_t __span_hw_session_id_get(IN sx_span_session_id_t span_session_id, OUT uint8_t *hw_span_session_id_p)
{
    sx_status_t  rc = SX_STATUS_SUCCESS;
    sxd_status_t sxd_rc;

    SX_API_LOG_ENTER();

    SX_LOG_DBG("Attempt to Retrieve HW Span session id of SPAN session %d\n",
               span_session_id);

    sxd_rc = sxd_dpt_span_session_map_get(span_session_id,
                                          hw_span_session_id_p);
    if (sxd_rc != SXD_STATUS_SUCCESS) {
        rc = SXD_STATUS_TO_SX_STATUS(sxd_rc);
        SX_LOG_ERR("sxd_dpt_span_session_map_get error %s\n", sx_status_str(rc));
        goto out;
    }

    SX_LOG_DBG("Success in Retrieve HW Span session id %d of SPAN session %d\n",
               *hw_span_session_id_p, span_session_id);

out:
    SX_API_LOG_EXIT();

    return rc;
}

static sx_status_t __host_ifc_send(const sx_fd_t          *fd,
                                   const void             *packet,
                                   const uint32_t          packet_size,
                                   const sx_swid_t         swid,
                                   sx_packet_type_t        packet_type,
                                   sx_port_ucroute_id_t    port_ucroute_id,
                                   const sx_cos_priority_t prio,
                                   sx_dev_id_t             dev_id,
                                   struct loopback_data   *loopback_data,
                                   struct span_oob_data   *span_oob_data_p)
{
    struct ku_write ku_write;
    int             sizeof_ku_write = sizeof(struct ku_write);
    struct ku_iovec iov;
    int             sxd_ret = -1;
    sx_status_t     err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(iov);
    SX_MEM_CLR(ku_write);

    /* validate inputs */
    if (SX_CHECK_FAIL(utils_check_pointer(packet, "packet buffer pointer"))) {
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (packet_size == 0) {
        SX_LOG_ERR("packet size is 0.\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if ((SX_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("Invalid swid %d.\n", swid);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if ((SX_PACKET_TYPE_CHECK_RANGE(packet_type)) == FALSE) {
        SX_LOG_ERR("Invalid packet type %d.\n", packet_type);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SXD_COS_PORT_PRIO_MAX < prio) {
        SX_LOG_ERR("Priority (%u) out of range [%u,%u]\n",
                   prio, SXD_COS_PORT_PRIO_MIN, SXD_COS_PORT_PRIO_MAX);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    SX_LOG_DBG("Packet type: %s\n", SX_PACKET_TYPE_STR(packet_type));

    switch (packet_type) {
    case SX_PKT_TYPE_ETH_CTL_UC:
    case SX_PKT_TYPE_LOOPBACK_CTL:
    case SX_PKT_TYPE_ETH_DATA:
        __set_isx_meta(swid, packet_type, port_ucroute_id, prio, 0,
                       0, 0, 0, dev_id, loopback_data, span_oob_data_p, &(ku_write.meta));

        break;

    case SX_PKT_TYPE_EMAD_CTL:
    case SX_PKT_TYPE_ETH_CTL_MC:
    case SX_PKT_TYPE_DROUTE_EMAD_CTL:
    case SX_PKT_TYPE_FC_CTL_UC:
    case SX_PKT_TYPE_FC_CTL_MC:
    case SX_PKT_TYPE_FCOE_CTL_UC:
    case SX_PKT_TYPE_FCOE_CTL_MC:
    case SX_PKT_TYPE_IB_RAW_CTL:
    case SX_PKT_TYPE_IB_TRANSPORT_CTL:
    case SX_PKT_TYPE_IB_RAW_DATA:
    case SX_PKT_TYPE_IB_TRANSPORT_DATA:
    case SX_PKT_TYPE_EOIB_CTL:
    case SX_PKT_TYPE_FCOIB_CTL:
    case SX_PKT_TYPE_IB_CTL_2:
    case SX_PKT_TYPE_IB_NVLINK:
    default:
        SX_LOG_ERR("Packet type [%s] is not supported yet\n", SX_PACKET_TYPE_STR(packet_type));
        break;
    }

    ku_write.vec_entries = 1;
    ku_write.iov = &iov;
    ku_write.iov->iov_base = (void*)packet;
    ku_write.iov->iov_len = packet_size;
    SX_LOG_DBG("Going to send a packet to the device, packet size: %u, swid: %d\n",
               packet_size, ku_write.meta.swid);
    sxd_ret = sxd_send(fd->driver_handle, &ku_write, sizeof(struct ku_write));
    if (sxd_ret != sizeof_ku_write) {
        SX_LOG_ERR("sxd_send error , number of bytes written %d , ku_write size: %d , packet size: %u\n",
                   sxd_ret, sizeof_ku_write, packet_size);
        switch (errno) {
        case ERANGE:
            err = SX_STATUS_PARAM_EXCEEDS_RANGE;
            break;

        case EINVAL:
            err = SX_STATUS_PARAM_ERROR;
            break;

        case ENXIO:
            err = SX_STATUS_ENTRY_NOT_FOUND;
            break;

        default:
            err = SX_STATUS_SXD_RETURNED_NON_ZERO;
            break;
        }
        goto out;
    }

    SX_LOG_DBG("Sent a packet to successfully! packet size %d\n", packet_size);

out:
    SX_API_LOG_EXIT();
    return err;
}


static sx_status_t __set_monitor_rdq_in_driver(sxd_handle                        handle,
                                               uint32_t                          hw_trap_group,
                                               const sx_trap_group_attributes_t *trap_group_attributes_p)
{
    sxd_ctrl_pack_t                  ctrl_pack;
    int                              sxd_err = SXD_STATUS_SUCCESS;
    struct ku_set_monitor_rdq_params ku_monitor_rdq_params;

    memset(&ku_monitor_rdq_params, 0, sizeof(ku_monitor_rdq_params));
    ku_monitor_rdq_params.dev_id = 1;
    ku_monitor_rdq_params.rdq = hw_trap_group;
    ku_monitor_rdq_params.is_monitor = trap_group_attributes_p->is_monitor;
    ku_monitor_rdq_params.cpu_tclass = trap_group_attributes_p->prio;

    ctrl_pack.cmd_body = (void*)&ku_monitor_rdq_params;
    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_MONITOR_RDQ;
    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("sxd_ioctl (set CTRL_CMD_SET_MONITOR_RDQ = FALSE) error %s\n", strerror(errno));
        return SX_STATUS_SXD_RETURNED_NON_ZERO;
    }

    return SX_STATUS_SUCCESS;
}

static sx_status_t __rdq_read_multi_from_driver(sxd_handle   handle,
                                                sx_file_op_t file_op,
                                                void       **buffer_list_pp,
                                                uint32_t    *buffer_size_list_p,
                                                uint32_t    *buffer_list_count_p)
{
    sxd_ctrl_pack_t             ctrl_pack;
    int                         sxd_err = SXD_STATUS_SUCCESS;
    struct ku_read_multi_params read_multi_params;
    uint32_t                    i;

    if ((file_op != SX_FILE_OP_FLUSH) && (buffer_list_count_p == NULL)) {
        SX_LOG_ERR("buffer_list_count_p is NULL\n");
        return SX_STATUS_PARAM_ERROR;
    }

    read_multi_params.file_op = file_op;
    read_multi_params.buffer_count = *buffer_list_count_p;
    for (i = 0; i < *buffer_list_count_p && buffer_list_pp != NULL; i++) {
        read_multi_params.buffer_list[i] = buffer_list_pp[i];
        read_multi_params.buffer_size_list[i] = buffer_size_list_p[i];
    }

    ctrl_pack.cmd_body = (void*)&read_multi_params;
    ctrl_pack.ctrl_cmd = CTRL_CMD_READ_MULTI;
    sxd_err = sxd_ioctl(handle, &ctrl_pack);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("sxd_ioctl CTRL_CMD_READ_MULTI error %s\n", strerror(errno));
        return SX_STATUS_SXD_RETURNED_NON_ZERO;
    }

    for (i = 0; i < *buffer_list_count_p && buffer_list_pp != NULL; i++) {
        buffer_size_list_p[i] = read_multi_params.buffer_size_list[i];
    }


    *buffer_list_count_p = read_multi_params.buffer_count;

    return SX_STATUS_SUCCESS;
}


static sx_status_t __host_ifc_trap_group_set(sx_api_handle_t                   handle,
                                             sx_swid_id_t                      swid,
                                             const sx_trap_group_t             trap_group,
                                             const sx_trap_group_attributes_t *trap_group_attributes_p,
                                             uint32_t                         *hw_trap_group)
{
    sx_api_command_head_t                   cmd_head;
    sx_api_host_ifc_trap_group_set_params_t cmd_body;
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t                     reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_TRAP_GROUP_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_host_ifc_trap_group_set_params_t);


    cmd_body.swid = swid;
    cmd_body.trap_group = trap_group;
    cmd_body.trap_group_attributes = *trap_group_attributes_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head, (uint8_t*)&cmd_body,
                                        sizeof(sx_api_host_ifc_trap_group_set_params_t));
    if (!err) {
        *hw_trap_group = cmd_body.hw_trap_group;
    }


    SX_API_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_trap_group_ext_set(sx_api_handle_t             handle,
                                                 sx_swid_id_t                swid,
                                                 sx_access_cmd_t             cmd,
                                                 const sx_trap_group_t       trap_group,
                                                 sx_trap_group_attributes_t *trap_group_attributes_p,
                                                 uint32_t                   *hw_trap_group)
{
    sx_api_command_head_t                       cmd_head;
    sx_api_host_ifc_trap_group_ext_set_params_t cmd_body;
    sx_status_t                                 err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t                         reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_TRAP_GROUP_EXT_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_host_ifc_trap_group_ext_set_params_t);


    cmd_body.swid = swid;
    cmd_body.cmd = cmd;
    cmd_body.trap_group = trap_group;
    cmd_body.trap_group_attributes = *trap_group_attributes_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head, (uint8_t*)&cmd_body,
                                        sizeof(sx_api_host_ifc_trap_group_ext_set_params_t));
    if (err == SX_STATUS_SUCCESS) {
        SX_MEM_CPY_P(trap_group_attributes_p, &(cmd_body.trap_group_attributes));
        *hw_trap_group = cmd_body.hw_trap_group;
    }


    SX_API_LOG_EXIT();
    return err;
}


static sx_status_t __host_ifc_trap_group_get(sx_api_handle_t             handle,
                                             sx_trap_group_t             trap_group,
                                             sx_swid_id_t                swid,
                                             sx_trap_group_attributes_t *trap_group_attributes_p)
{
    sx_api_command_head_t                   cmd_head;
    sx_api_host_ifc_trap_group_get_params_t cmd_body;
    sx_api_host_ifc_trap_group_get_params_t reply_body;
    sx_status_t                             err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t                     reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_TRAP_GROUP_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_host_ifc_trap_group_get_params_t);

    cmd_body.trap_group = trap_group;
    cmd_body.swid = swid;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head, (uint8_t*)&reply_body,
                                        sizeof(sx_api_host_ifc_trap_group_get_params_t));

    *trap_group_attributes_p = reply_body.trap_group_attributes;

    SX_API_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_user_conf_trap_attr_validate(const sx_trap_id_t                    trap_id,
                                                           sx_trap_id_user_defined_attributes_t *user_defined_attributes_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    boolean_t   is_tunnel_id_valid;
    uint32_t    key_list_cnt =
        user_defined_attributes_p ? user_defined_attributes_p->key_list_cnt : 0;
    sx_trap_id_user_defined_key_data_t key;
    sx_trap_id_user_defined_key_type_t key_type;
    uint32_t                           min = 0;
    uint32_t                           max = 0;

    if ((key_list_cnt > 1) || (key_list_cnt == 0)) {
        SX_LOG_ERR("Given key_list_cnt = %d but max allowed = 1\n", key_list_cnt);
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    key = user_defined_attributes_p->key_list[0].key;
    key_type = user_defined_attributes_p->key_list[0].type;

    switch (key_type) {
    case SX_TRAP_ID_USER_DEFINED_KEY_ETH_TYPE_E:
        is_tunnel_id_valid = key.nve_decap_eth_attr.tunnel_id != SX_TUNNEL_ID_INVALID ? TRUE : FALSE;
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_NEXT_PROTO_E:
        is_tunnel_id_valid = key.next_proto_key_type_attr.tunnel_id != SX_TUNNEL_ID_INVALID ? TRUE : FALSE;
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_L4_PORT_E:
        is_tunnel_id_valid = key.l4_port_key_type_attr.tunnel_id != SX_TUNNEL_ID_INVALID ? TRUE : FALSE;
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_ICMP_E:
        is_tunnel_id_valid = key.icmp_key_type_attr.tunnel_id != SX_TUNNEL_ID_INVALID ? TRUE : FALSE;
        min = key.icmp_key_type_attr.min_icmp_type;
        max = key.icmp_key_type_attr.max_icmp_type;
        if (min > max) {
            SX_LOG_ERR("Given icmp min is greater than icmp max in key.\n");
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_TRAP_ID_USER_DEFINED_KEY_IGMP_E:
        is_tunnel_id_valid = key.igmp_key_type_attr.tunnel_id != SX_TUNNEL_ID_INVALID ? TRUE : FALSE;
        min = key.igmp_key_type_attr.min_igmp_type;
        max = key.igmp_key_type_attr.max_igmp_type;
        if (min > max) {
            SX_LOG_ERR("Given igmp min greater than igmp max in key.\n");
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Invalid trap key type %d \n", user_defined_attributes_p->key_list[0].type);
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (trap_id) {
    case SX_TRAP_ID_USER_CONF_SWITCH0:
    case SX_TRAP_ID_USER_CONF_SWITCH1:
    case SX_TRAP_ID_USER_CONF_SWITCH2:
    case SX_TRAP_ID_USER_CONF_SWITCH3:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC0:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC1:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC2:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC3:
        if (is_tunnel_id_valid) {
            SX_LOG_ERR("TunnelId cannot be valid for trap_id %d \n", trap_id);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_TRAP_ID_USER_CONF_ROUTER0:
    case SX_TRAP_ID_USER_CONF_ROUTER1:
    case SX_TRAP_ID_USER_CONF_ROUTER2:
    case SX_TRAP_ID_USER_CONF_ROUTER3:
        if (key_type == SX_TRAP_ID_USER_DEFINED_KEY_ETH_TYPE_E) {
            SX_LOG_ERR("Ether type Key is not valid for trap_id %d \n", trap_id);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        if (is_tunnel_id_valid) {
            SX_LOG_ERR("TunnelId cannot be valid for trap_id %d \n", trap_id);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_TRAP_ID_USER_CONF_SWITCH_ENC0:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC1:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC2:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC3:
        if (is_tunnel_id_valid == FALSE) {
            SX_LOG_ERR("A valid tunnelId is needed for trap_id %d \n", trap_id);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Invalid user trap_id %d \n", trap_id);
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return status;
}

static sx_status_t __host_ifc_user_trap_attr_validate(const sx_trap_id_t                    trap_id,
                                                      sx_trap_id_user_defined_attributes_t *user_defined_attributes_p)
{
    sx_status_t status = SX_STATUS_SUCCESS;
    uint32_t    key_list_cnt = user_defined_attributes_p ? user_defined_attributes_p->key_list_cnt : 0;

    if (SX_CHECK_FAIL(status = utils_check_pointer(user_defined_attributes_p, "user_defined_attributes_p"))) {
        goto out;
    }

    if (key_list_cnt == 0) {
        SX_LOG_ERR("key_list_count = 0 is not allowed\n");
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (trap_id) {
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE0:
    case SX_TRAP_ID_USER_ICMPV6_CONF_TYPE1:
    case SX_TRAP_ID_USER_OVERLAY_ICMPV6_CONF_TYPE:
        if (user_defined_attributes_p->key_list[0].type != SX_TRAP_ID_USER_DEFINED_KEY_IPV6_ICMP_TYPE_E) {
            SX_LOG_ERR("unsupported attr type %d for trap ICMPv6\n", user_defined_attributes_p->key_list[0].type);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_TRAP_ID_USER_NVE_DECAP_ETH:
        if ((key_list_cnt > 0) &&
            (user_defined_attributes_p->key_list[0].type != SX_TRAP_ID_USER_DEFINED_KEY_NVE_DECAP_ETH_TYPE_E)) {
            SX_LOG_ERR("unsupported attr type %d for trap NVE_ETH_TYPE\n",
                       user_defined_attributes_p->key_list[0].type);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }

        if ((key_list_cnt > 1) &&
            (user_defined_attributes_p->key_list[1].type != SX_TRAP_ID_USER_DEFINED_KEY_NVE_DECAP_ETH_TYPE_E)) {
            SX_LOG_ERR("unsupported attr type %d for trap NVE_ETH_TYPE\n",
                       user_defined_attributes_p->key_list[1].type);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_TRAP_ID_USER_ETH_CONF_TYPE0:
    case SX_TRAP_ID_USER_ETH_CONF_TYPE1:
        if ((key_list_cnt > 0) &&
            (user_defined_attributes_p->key_list[0].type != SX_TRAP_ID_USER_DEFINED_KEY_ETH_TYPE_E)) {
            SX_LOG_ERR("unsupported attr type %d for trap ETH_TYPE\n",
                       user_defined_attributes_p->key_list[0].type);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_TRAP_ID_USER_CONF_SWITCH0:
    case SX_TRAP_ID_USER_CONF_SWITCH1:
    case SX_TRAP_ID_USER_CONF_SWITCH2:
    case SX_TRAP_ID_USER_CONF_SWITCH3:
    case SX_TRAP_ID_USER_CONF_ROUTER0:
    case SX_TRAP_ID_USER_CONF_ROUTER1:
    case SX_TRAP_ID_USER_CONF_ROUTER2:
    case SX_TRAP_ID_USER_CONF_ROUTER3:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC0:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC1:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC2:
    case SX_TRAP_ID_USER_CONF_SWITCH_DEC3:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC0:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC1:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC2:
    case SX_TRAP_ID_USER_CONF_SWITCH_ENC3:
        status = __host_ifc_user_conf_trap_attr_validate(trap_id, user_defined_attributes_p);
        if (SX_CHECK_FAIL(status)) {
            SX_LOG_ERR("attribute validation for trap:%s failed, key type: %d\n",
                       sx_host_ifc_trap_id_str(trap_id), user_defined_attributes_p->key_list[0].type);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    case SX_TRAP_ID_IP2ME_CUSTOM0:
    case SX_TRAP_ID_IP2ME_CUSTOM1:
        if ((user_defined_attributes_p->key_list_cnt > RM_API_HOST_IFC_USER_DEFINE_KEY_MAX) ||
            (user_defined_attributes_p->key_list_cnt == 0)) {
            SX_LOG_ERR("the key_list_cnt exceeds the allowed range [1-%d]. key_list_cnt (%d).\n",
                       RM_API_HOST_IFC_USER_DEFINE_KEY_MAX, user_defined_attributes_p->key_list_cnt);
            status = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        break;

    default:
        SX_LOG_ERR("Invalid user trap_id %s \n", sx_host_ifc_trap_id_str(trap_id));
        status = SX_STATUS_PARAM_ERROR;
        goto out;
    }

out:
    return status;
}
static sx_status_t __host_ifc_user_defined_trap_id_set(const sx_api_handle_t                 handle,
                                                       const sx_access_cmd_t                 cmd,
                                                       const sx_swid_t                       swid,
                                                       const sx_trap_id_t                    trap_id,
                                                       sx_trap_id_user_defined_attributes_t *trap_attributes_p)
{
    sx_api_command_head_t                             cmd_head;
    sx_api_host_ifc_user_defined_trap_id_set_params_t cmd_body;
    sx_status_t                                       err = SX_STATUS_SUCCESS;
    sx_api_reply_head_t                               reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);


    if (cmd == SX_ACCESS_CMD_ADD) {
        err = __host_ifc_user_trap_attr_validate(trap_id, trap_attributes_p);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
    }
    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_USER_DEFINED_TRAP_ID_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_host_ifc_user_defined_trap_id_set_params_t);

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.trap_id = trap_id;
    if (trap_attributes_p != NULL) {
        cmd_body.user_defined_attributes = *trap_attributes_p;
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

static sx_status_t __host_ifc_trap_group_set_wrapper(const sx_api_handle_t             handle,
                                                     const sx_swid_id_t                swid,
                                                     const sx_trap_group_t             trap_group,
                                                     const sx_trap_group_attributes_t *trap_group_attributes)
{
    sx_status_t err = SX_STATUS_SUCCESS;
    uint32_t    hw_trap_group = 0;

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(trap_group_attributes, "trap_group_attributes"))) {
        goto out;
    }

    if (trap_group_attributes->is_monitor &&
        ((trap_group_attributes->monitor_fd.valid == FALSE) ||
         (trap_group_attributes->monitor_fd.driver_handle < 0) ||
         (fcntl(trap_group_attributes->monitor_fd.fd, F_GETFL) == -1))) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Invalid file params : fd_valid:%d, driver_handle:0x%x, fd%d: [%s]\n",
                   trap_group_attributes->monitor_fd.valid,
                   trap_group_attributes->monitor_fd.driver_handle,
                   trap_group_attributes->monitor_fd.fd, sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_group_set(handle,
                                    swid,
                                    trap_group,
                                    trap_group_attributes,
                                    &hw_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in __host_ifc_trap_group_set. return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    if (trap_group_attributes->is_monitor) {
        err = __set_monitor_rdq_in_driver(trap_group_attributes->monitor_fd.driver_handle,
                                          hw_trap_group,
                                          trap_group_attributes);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed in __set_monitor_rdq_in_driver. return value: [%s]\n",
                       sx_status_str(err));
            goto out;
        }
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


/************************************************
 *  API functions
 ***********************************************/

sx_status_t sx_api_host_ifc_log_verbosity_level_set(const sx_api_handle_t           handle,
                                                    const sx_log_verbosity_target_t verbosity_target,
                                                    const sx_verbosity_level_t      module_verbosity_level,
                                                    const sx_verbosity_level_t      api_verbosity_level)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(api_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        LOG_VAR_NAME(__MODULE__) = api_verbosity_level;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_verbosity_level(module_verbosity_level);
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_SET;
        cmd_body.verbosity_level = module_verbosity_level;

        err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                            &reply_head, NULL, 0);
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_log_verbosity_level_get(const sx_api_handle_t           handle,
                                                    const sx_log_verbosity_target_t verbosity_target,
                                                    sx_verbosity_level_t           *module_verbosity_level_p,
                                                    sx_verbosity_level_t           *api_verbosity_level_p)
{
    sx_api_command_head_t          cmd_head;
    sx_api_command_log_verbosity_t cmd_body;
    sx_api_reply_head_t            reply_head;
    sx_status_t                    err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (verbosity_target > SX_LOG_VERBOSITY_MAX) {
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        SX_LOG_ERR("Verbosity target exceeds range.\n");
        goto out;
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_API) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(api_verbosity_level_p, "api_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("verbosity level is NULL.\n");
            goto out;
        }

        *api_verbosity_level_p = LOG_VAR_NAME(__MODULE__);
    }

    if ((verbosity_target == SX_LOG_VERBOSITY_TARGET_MODULE) ||
        (verbosity_target == SX_LOG_VERBOSITY_BOTH)) {
        err = utils_check_pointer(module_verbosity_level_p, "module_verbosity_level");
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }

        cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_VERBOSITY_E;
        cmd_head.version = SX_API_INT_VERSION;
        cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                            sizeof(sx_api_command_log_verbosity_t);
        cmd_body.cmd = SX_ACCESS_CMD_GET;

        err = sx_api_send_command_wrapper(handle, cmd_head.opcode, (uint8_t*)&cmd_body,
                                          sizeof(sx_api_command_log_verbosity_t));

        *module_verbosity_level_p = cmd_body.verbosity_level;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_open(const sx_api_handle_t handle, sx_fd_t         *fd)
{
    sx_status_t           err = SX_STATUS_SUCCESS;
    sx_api_command_head_t cmd_head;
    sx_api_reply_head_t   reply_head;
    boolean_t             fd_opened = FALSE;
    int                   device_fd = -1;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(reply_head);

    if (fd == NULL) {
        SX_LOG_ERR("file descriptor is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

/*    sx_api_sdk_get_capabilities */

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_OPEN_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t);

    err = sx_api_send_command_decoupled_fd(handle,
                                           &cmd_head,
                                           NULL,
                                           &reply_head,
                                           NULL,
                                           0,
                                           &device_fd);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }
    fd_opened = TRUE;

    err = __init_sxd_handle(&fd->driver_handle, device_fd);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to initialize SXD handle with FD %d, err = [%s]\n",
                   device_fd, sx_status_str(err));
        goto out;
    }
    fd->fd = device_fd;
    fd->valid = TRUE;

    /* init vtrap db for this fd */
    __trap_vtrap_reg_db_reset(fd->driver_handle);

    sxd_access_register_infra_init();

out:
    if (SX_CHECK_FAIL(err)) {
        if (fd_opened) {
            sxd_close_device_ext(device_fd);
        }
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_host_ifc_close(const sx_api_handle_t handle, sx_fd_t         *fd)
{
    sx_status_t                    err = SX_STATUS_SUCCESS;
    sx_api_command_head_t          cmd_head;
    sx_api_host_ifc_close_params_t cmd_body;
    sx_api_reply_head_t            reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (fd == NULL) {
        SX_LOG_ERR("file descriptor is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (fd->valid == FALSE) {
        SX_LOG_ERR("Invalid file descriptor.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_CLOSE_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_host_ifc_close_params_t);
    cmd_body.fd = *fd;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, NULL, 0);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = __deinit_sxd_handle(fd->driver_handle);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    fd->valid = FALSE;

    sxd_access_register_infra_deinit();

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_group_get(const sx_api_handle_t       handle,
                                           const sx_swid_id_t          swid,
                                           const sx_trap_group_t       trap_group,
                                           sx_trap_group_attributes_t *trap_group_attributes)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(err = utils_check_pointer(trap_group_attributes, "trap_group_attributes"))) {
        goto out;
    }

    err = __host_ifc_trap_group_get(handle,
                                    trap_group,
                                    swid,
                                    trap_group_attributes);
    if (SX_CHECK_FAIL(err) && (err != SX_STATUS_ENTRY_NOT_FOUND)) {
        SX_LOG_ERR("Failed in __host_ifc_trap_group_get. return value: [%s]\n",
                   sx_status_str(err));
    }

out:
    SX_API_LOG_EXIT();

    return err;
}

sx_status_t sx_api_host_ifc_trap_group_iter_get(const sx_api_handle_t         handle,
                                                const sx_access_cmd_t         cmd,
                                                const sx_swid_id_t            swid,
                                                const sx_trap_group_t         trap_group_id,
                                                const sx_trap_group_filter_t *filter_p,
                                                sx_trap_group_t              *trap_group_id_list_p,
                                                uint32_t                     *trap_group_id_cnt_p)
{
    sx_api_command_head_t                         cmd_head;
    sx_api_host_ifc_trap_group_iter_get_params_t  cmd_body;
    sx_api_reply_head_t                           reply_head;
    sx_api_host_ifc_trap_group_iter_get_params_t *reply_body = NULL;
    uint32_t                                      reply_body_size;
    sx_status_t                                   err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (SX_SWID_CHECK_RANGE(swid) == FALSE) {
        SX_LOG_ERR("Invalid  swid  %d.\n", swid);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (trap_group_id_cnt_p == NULL) {
        SX_LOG_ERR("trap_group_id_cnt_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((*trap_group_id_cnt_p > 0) && (trap_group_id_list_p == NULL)) {
        SX_LOG_ERR("*trap_group_id_cnt_p is not 0 but trap_group_id_list_p param is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*trap_group_id_cnt_p == 0) {
            trap_group_id_list_p = NULL;
        } else {
            *trap_group_id_cnt_p = 1;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*trap_group_id_cnt_p == 0) {
            SX_LOG_DBG("Trap group ID count is 0\n");
            goto out;
        }

        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_host_ifc_trap_group_iter_get_params_t) +
                      (*trap_group_id_cnt_p * sizeof(sx_trap_group_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_TRAP_GROUP_ITER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_host_ifc_trap_group_iter_get_params_t);
    cmd_head.list_size = *trap_group_id_cnt_p * sizeof(sx_trap_group_t);

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.trap_group_id = trap_group_id;
    cmd_body.trap_group_id_cnt = *trap_group_id_cnt_p;
    if (filter_p != NULL) {
        SX_MEM_CPY_TYPE(&(cmd_body.filter), filter_p, sx_trap_group_filter_t);
    }

    *trap_group_id_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->trap_group_id_cnt != 0) {
        *trap_group_id_cnt_p = reply_body->trap_group_id_cnt;
        if (trap_group_id_list_p != NULL) {
            SX_MEM_CPY_ARRAY(trap_group_id_list_p, reply_body->trap_group_id_list,
                             reply_body->trap_group_id_cnt, sx_trap_group_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_group_set(const sx_api_handle_t             handle,
                                           const sx_swid_id_t                swid,
                                           const sx_trap_group_t             trap_group,
                                           const sx_trap_group_attributes_t *trap_group_attributes)
{
    return __host_ifc_trap_group_set_wrapper(handle, swid, trap_group, trap_group_attributes);
}

sx_status_t sx_api_host_ifc_trap_group_ext_set(const sx_api_handle_t       handle,
                                               const sx_access_cmd_t       cmd,
                                               const sx_swid_id_t          swid,
                                               const sx_trap_group_t       trap_group,
                                               sx_trap_group_attributes_t* trap_group_attributes_p)
{
    sx_status_t                 err = SX_STATUS_SUCCESS;
    uint32_t                    hw_trap_group = 0;
    sx_trap_group_attributes_t  trap_group_attributes;
    sx_trap_group_attributes_t* attributes_p = NULL;

    SX_API_LOG_ENTER();

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
    /* Fall through */
    case SX_ACCESS_CMD_EDIT:
    /* Fall through */
    case SX_ACCESS_CMD_SET:
        if (SX_CHECK_FAIL(err = utils_check_pointer(trap_group_attributes_p, "trap_group_attributes"))) {
            goto out;
        }

        if (trap_group_attributes_p->is_monitor &&
            ((trap_group_attributes_p->monitor_fd.valid == FALSE) ||
             (trap_group_attributes_p->monitor_fd.driver_handle < 0) ||
             (fcntl(trap_group_attributes_p->monitor_fd.fd, F_GETFL) == -1))) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Invalid file params : fd_valid:%d, driver_handle:0x%x, fd%d: [%s]\n",
                       trap_group_attributes_p->monitor_fd.valid,
                       trap_group_attributes_p->monitor_fd.driver_handle,
                       trap_group_attributes_p->monitor_fd.fd, sx_status_str(err));
            goto out;
        }
        attributes_p = trap_group_attributes_p;
        break;

    case SX_ACCESS_CMD_DESTROY:
    /* Fall through */
    case SX_ACCESS_CMD_UNSET:
        SX_MEM_CLR(trap_group_attributes);
        attributes_p = &trap_group_attributes;
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    err = __host_ifc_trap_group_ext_set(handle,
                                        swid,
                                        cmd,
                                        trap_group,
                                        attributes_p,
                                        &hw_trap_group);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in __host_ifc_trap_group_ext_set. return value: [%s]\n",
                   sx_status_str(err));
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_CREATE:
    /* Fall through */
    case SX_ACCESS_CMD_EDIT:
    /* Fall through */
    case SX_ACCESS_CMD_SET:
        if (attributes_p->is_monitor) {
            err = __set_monitor_rdq_in_driver(attributes_p->monitor_fd.driver_handle,
                                              hw_trap_group,
                                              attributes_p);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed in __set_monitor_rdq_in_driver. return value: [%s]\n",
                           sx_status_str(err));
                goto out;
            }
        }
        break;

    case SX_ACCESS_CMD_DESTROY:
    /* Fall through */
    case SX_ACCESS_CMD_UNSET:
        if (attributes_p->is_monitor) {
            attributes_p->is_monitor = FALSE;
            err = __set_monitor_rdq_in_driver(((sx_api_user_ctxt_t*)(uintptr_t)handle)->dev,
                                              hw_trap_group,
                                              attributes_p);
            if (SX_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed in __set_monitor_rdq_in_driver. return value: [%s]\n",
                           sx_status_str(err));
                goto out;
            }
        }
        break;

    /* coverity[dead_error_begin] */
    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_id_ext_set(const sx_api_handle_t          handle,
                                            const sx_access_cmd_t          cmd,
                                            const sx_host_ifc_trap_key_t  *trap_key_p,
                                            const sx_host_ifc_trap_attr_t *trap_attr_p)
{
    sx_status_t                              err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                    cmd_head;
    sx_api_host_ifc_trap_id_ext_set_params_t cmd_body;
    sx_api_reply_head_t                      reply_head;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (trap_key_p == NULL) {
        SX_LOG_ERR("Specified trap_key_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (trap_attr_p == NULL) {
        SX_LOG_ERR("Specified trap_attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_ACCESS_CMD_CHECK_RANGE(cmd) == FALSE) {
        SX_LOG_ERR("Invalid command %s.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_TRAP_ID_EXT_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_host_ifc_trap_id_ext_set_params_t);

    cmd_body.cmd = cmd;
    cmd_body.trap_key.type = trap_key_p->type;
    cmd_body.trap_key.trap_key_attr.trap_id = trap_key_p->trap_key_attr.trap_id;
    cmd_body.trap_attr.attr.trap_id_attr.trap_action = trap_attr_p->attr.trap_id_attr.trap_action;
    cmd_body.trap_attr.attr.trap_id_attr.trap_group = trap_attr_p->attr.trap_id_attr.trap_group;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_id_ext_get(const sx_api_handle_t         handle,
                                            const sx_access_cmd_t         cmd,
                                            const sx_host_ifc_trap_key_t *trap_key_p,
                                            sx_host_ifc_trap_attr_t      *trap_attr_p,
                                            uint32_t                     *attr_cnt_p)
{
    sx_api_command_head_t                    cmd_head;
    sx_api_host_ifc_trap_id_ext_get_params_t cmd_body;
    sx_api_reply_head_t                      reply_head;
    sx_status_t                              err = SX_STATUS_SUCCESS;

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_API_LOG_ENTER();

    if (!trap_key_p) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("trap_key_p is NULL.\n");
        goto out;
    }

    if (!attr_cnt_p) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("attr_cnt_p is NULL.\n");
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_TRAP_ID_EXT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_host_ifc_trap_id_ext_get_params_t);

    cmd_body.cmd = cmd;
    cmd_body.trap_key.type = trap_key_p->type;
    cmd_body.trap_key.trap_key_attr.trap_id = trap_key_p->trap_key_attr.trap_id;
    cmd_body.attr_cnt = *attr_cnt_p;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)trap_attr_p,
                                        (*attr_cnt_p) * sizeof(sx_host_ifc_trap_attr_t));

    if (SX_STATUS_SUCCESS == err) {
        *attr_cnt_p = reply_head.list_size;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_group_stat_get(const sx_api_handle_t               handle,
                                                const sx_access_cmd_t               cmd,
                                                const sx_host_ifc_trap_group_key_t *group_key_p,
                                                sx_host_ifc_trap_group_stat_t      *group_stat_p)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_status_t                               mem_rc = SX_STATUS_SUCCESS;
    sx_api_host_ifc_trap_group_stat_params_t *cmd_body_p = NULL;
    uint32_t                                  cmd_size = sizeof(sx_api_host_ifc_trap_group_stat_params_t);

    SX_API_LOG_ENTER();

    if (group_key_p == NULL) {
        SX_LOG_ERR("Specified group_key_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (group_stat_p == NULL) {
        SX_LOG_ERR("Specified group_stat_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_ACCESS_CMD_CHECK_RANGE(cmd) == FALSE) {
        SX_LOG_ERR("Invalid command %s.\n", sx_access_cmd_str(cmd));
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body_p->cmd = cmd;
    memcpy(&cmd_body_p->group_key, group_key_p, sizeof(sx_host_ifc_trap_group_key_t));

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_HOST_IFC_TRAP_GROUP_STAT_GET_E,
                                      (uint8_t*)cmd_body_p, cmd_size);

    if (SX_CHECK_PASS(err)) {
        SX_MEM_CPY_P(group_stat_p, &cmd_body_p->group_stat);
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E,
                    "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        err = mem_rc;
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_user_defined_trap_id_set(const sx_api_handle_t                 handle,
                                                     const sx_access_cmd_t                 cmd,
                                                     const sx_swid_t                       swid,
                                                     const sx_trap_id_t                    trap_id,
                                                     sx_trap_id_user_defined_attributes_t *trap_attributes_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    if (SX_SWID_CHECK_RANGE(swid) == FALSE) {
        SX_LOG_ERR("Invalid  swid  %d.\n", swid);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE)) {
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("Invalid command error:[%s]\n", sx_status_str(err));
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_ADD) && (trap_attributes_p == NULL)) {
        SX_LOG_ERR("trap_attributes_pis NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = __host_ifc_user_defined_trap_id_set(
        handle, cmd, swid, trap_id, trap_attributes_p);

    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed in __host_ifc_user_defined_trap_id_set , cmd: [%u] , return value: [%s]\n",
                   cmd,
                   sx_status_str(err));
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_id_register_set(const sx_api_handle_t    handle,
                                                 const sx_access_cmd_t    cmd,
                                                 const sx_swid_t          swid,
                                                 const sx_trap_id_t       trap_id,
                                                 const sx_user_channel_t *user_channel)
{
    sx_status_t                                   err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                         cmd_head;
    sx_api_host_ifc_trap_id_register_set_params_t cmd_body;
    sx_api_reply_head_t                           reply_head;
    sx_api_host_ifc_trap_id_register_set_params_t reply_body;
    sx_host_ifc_register_key_t                    register_key;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);
    SX_MEM_CLR(register_key);

    /******** validate inputs ********/
    if (SX_ACCESS_CMD_CHECK_RANGE(cmd) == FALSE) {
        SX_LOG_ERR("Invalid command  %d.\n", cmd);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("Invalid trap id  %d.\n", trap_id);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (user_channel == NULL) {
        SX_LOG_ERR("user channel is NULL .\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((user_channel->type == SX_USER_CHANNEL_TYPE_FD) &&
        (user_channel->channel.fd.valid == FALSE)) {
        SX_LOG_ERR("type SX_USER_CHANNEL_TYPE_FD is invalid.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    /* Allow all traps except discard traps to be register with channel PSAMPLE */
    if ((user_channel->type == SX_USER_CHANNEL_TYPE_PSAMPLE) &&
        ((SX_TRAP_ID_DISCARD_CHECK_RANGE(trap_id) == TRUE) ||
         (SX_TRAP_ID_EXTENDED_DISCARD_CHECK_RANGE(trap_id) == TRUE))) {
        SX_LOG_ERR("PSAMPLE channel is valid for all traps except discard traps (%s) \n",
                   sx_host_ifc_trap_id_str(trap_id));
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }


    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_TRAP_ID_REGISTER_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_host_ifc_trap_id_register_set_params_t);

    cmd_body.cmd = cmd;
    cmd_body.vtrap = trap_id;
    cmd_body.swid = swid;
    cmd_body.user_channel = *user_channel;

    /* SDK process will perform validations that require access to shared
     * memory, since shared memory shouldn't be accessed from client-side in
     * SX-APIs. Registration itself to trap ID is performed after RPC call to
     * SDK process returns.
     */
    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)&reply_body,
                                        sizeof(sx_api_host_ifc_trap_id_register_set_params_t));
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    register_key.key_type = SX_HOST_IFC_REGISTER_KEY_TYPE_GLOBAL;
    err = __configure_driver(cmd, ((sx_api_user_ctxt_t*)(uintptr_t)handle)->dev,
                             reply_body.trap_id, trap_id, swid, &register_key,
                             user_channel, 0, 1);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to configure driver, err = [%s]\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_id_register_get(const sx_api_handle_t    handle,
                                                 const sx_access_cmd_t    cmd,
                                                 const sx_swid_t          swid,
                                                 const sx_trap_id_t       trap_id,
                                                 const sx_user_channel_t *user_channel,
                                                 sx_user_channel_t       *user_channel_list_p,
                                                 uint32_t                *user_channel_cnt_p)
{
    sx_status_t                                    err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                          cmd_head;
    sx_api_host_ifc_trap_id_register_get_params_t  cmd_body;
    sx_api_reply_head_t                            reply_head;
    sx_api_host_ifc_trap_id_register_get_params_t *reply_body = NULL;
    uint32_t                                       reply_body_size;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((SX_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("sx_api_host_ifc_trap_id_register_get: swid range error\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("Invalid trap id  %d.\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (user_channel_cnt_p == NULL) {
        SX_LOG_ERR("user_channel_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*user_channel_cnt_p != 0) && (user_channel_list_p == NULL)) {
        SX_LOG_ERR("*user_channel_cnt_p is not 0 but user_channel_list_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*user_channel_cnt_p == 0) {
            user_channel_list_p = NULL;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*user_channel_cnt_p == 0) {
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_GETNEXT) && (user_channel == NULL)) {
        SX_LOG_ERR("user_channel is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    reply_body_size = sizeof(sx_api_host_ifc_trap_id_register_get_params_t) +
                      (*user_channel_cnt_p * sizeof(sx_user_channel_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_TRAP_ID_REGISTER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_host_ifc_trap_id_register_get_params_t);
    cmd_head.list_size = *user_channel_cnt_p * sizeof(sx_user_channel_t);

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.trap_id = trap_id;
    cmd_body.user_channel_cnt = *user_channel_cnt_p;
    if ((cmd == SX_ACCESS_CMD_GETNEXT) && (user_channel != NULL)) {
        SX_MEM_CPY_TYPE(&(cmd_body.user_channel), user_channel, sx_user_channel_t);
    }

    *user_channel_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->user_channel_cnt != 0) {
        *user_channel_cnt_p = reply_body->user_channel_cnt;
        if (user_channel_list_p != NULL) {
            SX_MEM_CPY_ARRAY(user_channel_list_p, reply_body->user_channel_list,
                             reply_body->user_channel_cnt, sx_user_channel_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_port_vlan_trap_id_register_set(const sx_api_handle_t             handle,
                                                           const sx_access_cmd_t             cmd,
                                                           const sx_swid_t                   swid,
                                                           const sx_trap_id_t                trap_id,
                                                           const sx_host_ifc_register_key_t *register_key_p,
                                                           const sx_user_channel_t          *user_channel)
{
    sx_status_t                                             err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                                   cmd_head;
    sx_api_host_ifc_port_vlan_trap_id_register_set_params_t cmd_body;
    sx_api_reply_head_t                                     reply_head;
    sx_api_host_ifc_port_vlan_trap_id_register_set_params_t reply_body;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);
    SX_MEM_CLR(reply_body);

    /******** validate inputs ********/
    if (SX_ACCESS_CMD_CHECK_RANGE(cmd) == FALSE) {
        SX_LOG_ERR("Invalid command  %d.\n", cmd);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("Invalid trap id  %d.\n", trap_id);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    /*Validate register key*/
    if (register_key_p == NULL) {
        SX_LOG_ERR("register key is NULL .\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((register_key_p->key_type) > SX_HOST_IFC_REGISTER_KEY_TYPE_MAX) {
        SX_LOG_ERR("key_type exceeds range.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (register_key_p->key_type == SX_HOST_IFC_REGISTER_KEY_TYPE_PORT) {
        if ((SX_PORT_TYPE_ID_GET(register_key_p->key_value.port_id) == SX_PORT_TYPE_VPORT) ||
            (SX_PORT_TYPE_ID_GET(register_key_p->key_value.port_id) == SX_PORT_TYPE_VLAG)) {
            SX_LOG_ERR("Vports are not supported in the register key.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    /*Validate user channel*/
    if (user_channel == NULL) {
        SX_LOG_ERR("user channel is NULL .\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((user_channel->type == SX_USER_CHANNEL_TYPE_FD) &&
        (user_channel->channel.fd.valid == FALSE)) {
        SX_LOG_ERR("type SX_USER_CHANNEL_TYPE_FD is invalid.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_PORT_VLAN_TRAP_ID_REGISTER_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_host_ifc_port_vlan_trap_id_register_set_params_t);

    cmd_body.cmd = cmd;
    cmd_body.trap_id = trap_id;
    cmd_body.swid = swid;
    cmd_body.register_key = *register_key_p;
    cmd_body.user_channel = *user_channel;

    /* SDK process will perform validations that require access to shared
     * memory, since shared memory shouldn't be accessed from client-side in
     * SX-APIs. Registration itself to trap ID is performed after RPC call to
     * SDK process returns.
     */
    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head,
                                        (uint8_t*)&reply_body,
                                        sizeof(sx_api_host_ifc_port_vlan_trap_id_register_set_params_t));
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    err = __configure_driver(cmd, ((sx_api_user_ctxt_t*)(uintptr_t)handle)->dev,
                             reply_body.trap_id, trap_id, swid, register_key_p,
                             user_channel, reply_body.sys_port, 1);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to configure driver, err = [%s]\n",
                   sx_status_str(err));
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_port_vlan_trap_id_register_get(const sx_api_handle_t                   handle,
                                                           const sx_access_cmd_t                   cmd,
                                                           const sx_swid_t                         swid,
                                                           const sx_trap_id_t                      trap_id,
                                                           const sx_host_ifc_register_get_entry_t *register_entry,
                                                           sx_host_ifc_register_get_entry_t       *register_entry_list_p,
                                                           uint32_t                               *register_entry_cnt_p)
{
    sx_status_t                                              err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                                    cmd_head;
    sx_api_host_ifc_port_vlan_trap_id_register_get_params_t  cmd_body;
    sx_api_reply_head_t                                      reply_head;
    sx_api_host_ifc_port_vlan_trap_id_register_get_params_t *reply_body = NULL;
    uint32_t                                                 reply_body_size;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((SX_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("sx_api_host_ifc_port_vlan_trap_id_register_get: swid range error\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("Invalid trap id %d.\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (register_entry_cnt_p == NULL) {
        SX_LOG_ERR("register_entry_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*register_entry_cnt_p != 0) && (register_entry_list_p == NULL)) {
        SX_LOG_ERR("*register_entry_cnt_p is not 0 but register_entry_list_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*register_entry_cnt_p == 0) {
            register_entry_list_p = NULL;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*register_entry_cnt_p == 0) {
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    if ((cmd == SX_ACCESS_CMD_GETNEXT) && (register_entry == NULL)) {
        SX_LOG_ERR("register_entry is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    reply_body_size = sizeof(sx_api_host_ifc_port_vlan_trap_id_register_get_params_t) +
                      (*register_entry_cnt_p * sizeof(sx_host_ifc_register_get_entry_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }
    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_PORT_VLAN_TRAP_ID_REGISTER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_host_ifc_port_vlan_trap_id_register_get_params_t);
    cmd_head.list_size = *register_entry_cnt_p * sizeof(sx_host_ifc_register_get_entry_t);

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.trap_id = trap_id;
    cmd_body.register_entry_cnt = *register_entry_cnt_p;
    if ((cmd == SX_ACCESS_CMD_GETNEXT) && (register_entry != NULL)) {
        SX_MEM_CPY_TYPE(&(cmd_body.register_entry), register_entry, sx_host_ifc_register_get_entry_t);
    }

    *register_entry_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->register_entry_cnt != 0) {
        *register_entry_cnt_p = reply_body->register_entry_cnt;
        if (register_entry_list_p != NULL) {
            SX_MEM_CPY_ARRAY(register_entry_list_p, reply_body->register_entry_list,
                             reply_body->register_entry_cnt, sx_host_ifc_register_get_entry_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_filter_set(const sx_api_handle_t handle,
                                            const sx_access_cmd_t cmd,
                                            const sx_swid_t       swid,
                                            const sx_trap_id_t    trap_id,
                                            sx_port_log_id_t      log_port_list[],
                                            uint32_t             *log_port_num)
{
    sx_status_t                               err = SX_STATUS_SUCCESS, mem_rc = SX_STATUS_SUCCESS;
    sx_api_host_ifc_trap_filter_set_params_t *cmd_body_p = NULL;
    uint32_t                                  cmd_size = sizeof(sx_api_host_ifc_trap_filter_set_params_t);
    uint32_t                                  i;

    SX_API_LOG_ENTER();

    /******** validate inputs ********/
    if (SX_ACCESS_CMD_CHECK_RANGE(cmd) == FALSE) {
        SX_LOG_ERR("Invalid cmd  %d.\n", cmd);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("Invalid trap id  %d.\n", trap_id);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE) &&
        (cmd != SX_ACCESS_CMD_DELETE_ALL)) {
        SX_LOG_ERR("Invalid command  %d.\n", cmd);
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        if ((log_port_list == NULL) || (log_port_num == NULL)) {
            SX_LOG_ERR("log_port_list is NULL  .\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }

        for (i = 0; i < *log_port_num; i++) {
            if (log_port_list[i] == SX_INVALID_PORT) {
                SX_LOG_ERR("Invalid port in log_port_list[i], i= %d.\n", i);
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }

        cmd_size += (*log_port_num) * sizeof(sx_port_log_id_t);
    }

    if (cmd_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    M_UTILS_CLR_MEM_GET(&cmd_body_p, 1, cmd_size, UTILS_MEM_TYPE_ID_API_E,
                        "Failed to allocate cmd_body_p memory\n", err);
    if (SX_CHECK_FAIL(err)) {
        SX_API_LOG_EXIT();
        return err;
    }

    cmd_body_p->cmd = cmd;
    cmd_body_p->swid = swid;
    cmd_body_p->trap_id = trap_id;

    if (cmd != SX_ACCESS_CMD_DELETE_ALL) {
        cmd_body_p->log_port_num = *log_port_num;

        SX_MEM_CPY_ARRAY(cmd_body_p->log_port_list, log_port_list, *log_port_num,
                         sx_port_log_id_t);
    }

    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_HOST_IFC_TRAP_FILTER_SET_E,
                                      (uint8_t*)cmd_body_p, cmd_size);
    if (SX_CHECK_FAIL(err)) {
        if (NULL != log_port_num) {
            *log_port_num = cmd_body_p->log_port_num;
        }

        if (NULL != log_port_list) {
            SX_MEM_CPY_ARRAY(log_port_list, cmd_body_p->log_port_list, cmd_body_p->log_port_num, sx_port_log_id_t);
        }
    }

    M_UTILS_MEM_PUT(cmd_body_p, UTILS_MEM_TYPE_ID_API_E, "Error on cmd_body_p memory free", mem_rc);
    if (SX_CHECK_FAIL(mem_rc)) {
        err = mem_rc;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_filter_get(const sx_api_handle_t  handle,
                                            const sx_access_cmd_t  cmd,
                                            const sx_swid_t        swid,
                                            const sx_trap_id_t     trap_id,
                                            const sx_port_log_id_t log_port_id,
                                            sx_port_log_id_t      *log_port_list_p,
                                            uint32_t              *log_port_cnt_p)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                     cmd_head;
    sx_api_host_ifc_trap_filter_get_params_t  cmd_body;
    sx_api_reply_head_t                       reply_head;
    sx_api_host_ifc_trap_filter_get_params_t *reply_body = NULL;
    uint32_t                                  reply_body_size;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((SX_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("sx_api_host_ifc_trap_filter_get: swid range error\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("Invalid trap id  %d.\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (log_port_cnt_p == NULL) {
        SX_LOG_ERR("log_port_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*log_port_cnt_p != 0) && (log_port_list_p == NULL)) {
        SX_LOG_ERR("*log_port_cnt_p is not 0 but log_port_list_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        if (*log_port_cnt_p == 0) {
            log_port_list_p = NULL;
        }
        break;

    case SX_ACCESS_CMD_GETNEXT:
    case SX_ACCESS_CMD_GET_FIRST:
        if (*log_port_cnt_p == 0) {
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_host_ifc_trap_filter_get_params_t) +
                      (*log_port_cnt_p * sizeof(sx_port_log_id_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_TRAP_FILTER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_host_ifc_trap_filter_get_params_t);
    cmd_head.list_size = *log_port_cnt_p * sizeof(sx_port_log_id_t);

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.trap_id = trap_id;
    cmd_body.log_port_cnt = *log_port_cnt_p;
    if (cmd == SX_ACCESS_CMD_GETNEXT) {
        cmd_body.log_port_id = log_port_id;
    }

    *log_port_cnt_p = 0;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->log_port_cnt != 0) {
        *log_port_cnt_p = reply_body->log_port_cnt;
        if (log_port_list_p != NULL) {
            SX_MEM_CPY_ARRAY(log_port_list_p, reply_body->log_port_list,
                             reply_body->log_port_cnt, sx_port_log_id_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_policer_bind_set(const sx_api_handle_t handle,
                                             const sx_access_cmd_t cmd,
                                             const sx_swid_t       swid,
                                             const sx_trap_group_t trap_group,
                                             const sx_policer_id_t policer_id)
{
    sx_api_command_head_t                     cmd_head;
    sx_api_host_ifc_policer_bind_set_params_t cmd_body;
    sx_api_reply_head_t                       reply_head;
    sx_status_t                               err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if (SX_ACCESS_CMD_CHECK_RANGE(cmd) == FALSE) {
        SX_LOG_ERR("Invalid cmd  %d.\n", cmd);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    switch (cmd) {
    case SX_ACCESS_CMD_BIND:
    case SX_ACCESS_CMD_UNBIND:
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_POLICER_BIND_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_host_ifc_policer_bind_set_params_t);

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.trap_group = trap_group;
    cmd_body.policer_id = policer_id;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_policer_bind_get(const sx_api_handle_t handle,
                                             const sx_swid_t       swid,
                                             const sx_trap_group_t trap_group,
                                             sx_policer_id_t      *policer_id_p)
{
    sx_status_t                               err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                     cmd_head;
    sx_api_host_ifc_policer_bind_get_params_t cmd_body;
    sx_api_reply_head_t                       reply_head;
    sx_api_host_ifc_policer_bind_get_params_t reply_body;

    if (SX_CHECK_FAIL(err = utils_check_pointer(policer_id_p, "policer_id_p"))) {
        goto out;
    }

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_POLICER_BIND_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t)
                        + sizeof(sx_api_host_ifc_policer_bind_get_params_t);

    cmd_body.trap_group = trap_group;
    cmd_body.swid = swid;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head, (uint8_t*)&reply_body,
                                        sizeof(sx_api_host_ifc_policer_bind_get_params_t));

    if (err == SX_STATUS_SUCCESS) {
        *policer_id_p = reply_body.policer_id;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

/************************************************
 *  Library functions
 ***********************************************/

sx_status_t sx_lib_host_ifc_unicast_ctrl_send(const sx_fd_t          *fd,
                                              const void             *packet,
                                              const uint32_t          packet_size,
                                              const sx_swid_t         swid,
                                              const sx_port_log_id_t  egress_log_port,
                                              const sx_cos_priority_t prio)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_packet_type_t     packet_type = SX_PKT_TYPE_ETH_CTL_UC;
    sx_dev_id_t          dev_id = SX_PORT_DEV_ID_GET(egress_log_port);
    sx_port_ucroute_id_t port_ucroute_id = { 0 };

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(fd, "file descriptor pointer"))) {
        SX_LOG_ERR("file descriptor is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (fd->valid == FALSE) {
        SX_LOG_ERR("Invalid file descriptor \n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(packet, "packet pointer"))) {
        SX_LOG_ERR("packet is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((SX_PORT_LOG_ID_CHECK_RANGE(egress_log_port)) == FALSE) {
        SX_LOG_ERR("Invalid egress_log_port  %d.\n", egress_log_port);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = __lcl_port_uc_route_get(egress_log_port, &port_ucroute_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("local port ucroute get error: %s\n", sx_status_str(err));
        goto out;
    }

    err = __host_ifc_send(
        fd,
        packet,
        packet_size,
        swid,
        packet_type,
        port_ucroute_id,
        prio,
        dev_id,
        NULL, NULL);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_lib_host_ifc_data_send(const sx_fd_t          *fd,
                                      const void             *packet,
                                      const uint32_t          packet_size,
                                      const sx_swid_t         swid,
                                      const sx_cos_priority_t prio)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    sx_packet_type_t packet_type = SX_PKT_TYPE_ETH_DATA;
    sx_dev_id_t      dev_id = 1;

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(fd, "file descriptor pointer"))) {
        SX_LOG_ERR("file descriptor is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (fd->valid == FALSE) {
        SX_LOG_ERR("Invalid file descriptor .\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(packet, "packet pointer"))) {
        SX_LOG_ERR("packet is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    err = __host_ifc_send(
        fd,
        packet,
        packet_size,
        swid,
        packet_type,
        SX_INVALID_PORT,
        prio,
        dev_id,
        NULL, NULL);

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_lib_host_ifc_data_to_span_send(const sx_fd_t            *fd,
                                              const sx_swid_t           swid,
                                              const sx_packet_attr_t   *packet_attr_p,
                                              const sx_span_oob_attr_t *span_oob_attr_p)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_packet_type_t     packet_type = SX_PKT_TYPE_ETH_DATA;
    sx_dev_id_t          dev_id = 1;
    struct span_oob_data sxd_span_oob_data;

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(fd, "file descriptor pointer"))) {
        SX_LOG_ERR("file descriptor is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (fd->valid == FALSE) {
        SX_LOG_ERR("Invalid file descriptor .\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(packet_attr_p, "packet_attr_p pointer"))) {
        SX_LOG_ERR("packet_attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(packet_attr_p->packet, "packet_attr_p pointer"))) {
        SX_LOG_ERR("packet_attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(span_oob_attr_p, "span_oob_attr_p pointer"))) {
        SX_LOG_ERR("span_oob_attr_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_HOST_IFC_EXT_FWD_MODE_MIN_E,
                        span_oob_attr_p->ext_fwd_mode,
                        SX_HOST_IFC_EXT_FWD_MODE_MAX_E)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("ext_fwd_mode %d is out of range.err: %s\n",
                   span_oob_attr_p->ext_fwd_mode, sx_status_str(err));
        goto out;
    }

    if (!SX_CHECK_RANGE(SX_HOST_BASED_MIRROR_REASON_ID_MIN_E,
                        span_oob_attr_p->mirror_reason_id,
                        SX_HOST_BASED_MIRROR_REASON_ID_MAX_E)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("mirror_reason_id %d is out of range. err: %s\n",
                   span_oob_attr_p->mirror_reason_id, sx_status_str(err));
        goto out;
    }

    sxd_span_oob_data.ext_fwd_mode = span_oob_attr_p->ext_fwd_mode;
    sxd_span_oob_data.mirror_reason_id = span_oob_attr_p->mirror_reason_id;

    sxd_span_oob_data.span_session_id = span_oob_attr_p->span_session_id;

    err = __span_hw_session_id_get(span_oob_attr_p->span_session_id,
                                   &sxd_span_oob_data.span_session_id);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__span_hw_session_id_get failed with error: %s\n",
                   sx_status_str(err));
        goto out;
    }

    err = __host_ifc_send(
        fd,
        packet_attr_p->packet,
        packet_attr_p->packet_size,
        swid,
        packet_type,
        SX_INVALID_PORT,
        0,
        dev_id,
        NULL,
        &sxd_span_oob_data);

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_lib_host_ifc_loopback_ctrl_send(const sx_fd_t         *fd,
                                               const void            *packet,
                                               const uint32_t         packet_size,
                                               const sx_swid_t        swid,
                                               const sx_trap_id_t     trap_id,
                                               const sx_port_log_id_t ingress_log_port,
                                               const boolean_t        is_lag,
                                               const sx_port_log_id_t ingress_lag_port)
{
    sx_status_t          err = SX_STATUS_SUCCESS;
    sx_dev_id_t          dev_id = 0;
    sx_port_ucroute_id_t port_ucroute_id = { 0 };
    struct loopback_data loopback_data;
    sx_packet_type_t     packet_type = SX_PKT_TYPE_LOOPBACK_CTL;
    sx_trap_priority_t   prio = SX_TRAP_PRIORITY_HIGH;

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(fd, "file descriptor pointer"))) {
        SX_LOG_ERR("file descriptor is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (fd->valid == FALSE) {
        SX_LOG_ERR("file packet NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(packet, "packet pointer"))) {
        SX_LOG_ERR("packet NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("Invalid trap id %d.\n", trap_id);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (is_lag && (ingress_lag_port == SX_INVALID_PORT)) {
        SX_LOG_ERR("Invalid ingress_lag_port %d.\n", ingress_lag_port);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!is_lag && (ingress_log_port == SX_INVALID_PORT)) {
        SX_LOG_ERR("Invalid ingress_log_port %d.\n", ingress_log_port);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    loopback_data.is_lag = is_lag;
    if (is_lag) {
        dev_id = 1;
        port_ucroute_id = (sx_port_ucroute_id_t)(SX_PORT_LAG_ID_GET(ingress_lag_port));
        err = __lag_port_index_get(ingress_lag_port, ingress_log_port,
                                   &loopback_data.lag_subport);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed retrieving logical port 0x%x index in lag port 0x%x\n",
                       ingress_log_port, ingress_lag_port);
            goto out;
        } else if ((ingress_log_port == SX_INVALID_PORT) &&
                   (loopback_data.lag_subport == port_indices_db_p->max_lag_ports)) {
            SX_LOG_DBG("Silently dropping the loopback packet since none of the LAG ports "
                       "has collector state enabled\n");
            goto out;
        }
    } else { /* we were given the port but not the LAG */
        dev_id = SX_PORT_DEV_ID_GET(ingress_log_port);
        err = __lcl_port_uc_route_get(ingress_log_port, &port_ucroute_id);
        if (SX_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed translating logical port 0x%x to "
                       "system port\n", ingress_log_port);
            goto out;
        }
    }

    loopback_data.trap_id = trap_id;
    err = __host_ifc_send(
        fd,
        packet,
        packet_size,
        swid,
        packet_type,
        port_ucroute_id,
        prio,
        dev_id,
        &loopback_data,
        NULL);

out:
    SX_API_LOG_EXIT();
    return err;
}

static void __parse_mirror_info(struct ku_read *ku_read, sx_receive_info_t *receive_info_p)
{
    uint8_t trap_group_reason_base = SX_SPAN_MIRROR_REASON_TRAP_GROUP_E;

    if (ku_read->mirror_elephant == SXD_MIRROR_ELPH_ELEPHANT_E) {
        receive_info_p->mirror_info.original_elephant = SX_COS_ELEPHANT_STATE_ELEPHANT_E;
    } else {
        receive_info_p->mirror_info.original_elephant = SX_COS_ELEPHANT_STATE_NON_ELEPHANT_E;
    }
    receive_info_p->mirror_info.original_latency = ku_read->mirror_lantency;
    receive_info_p->mirror_info.original_occupancy = ku_read->mirror_cong;
    receive_info_p->mirror_info.original_packet_tclass = ku_read->mirror_tclass;
    receive_info_p->mirror_info.mirror_reason = ku_read->mirror_reason;
    if (receive_info_p->mirror_info.mirror_reason >= trap_group_reason_base) {
        receive_info_p->mirror_info.original_trap_group =
            receive_info_p->mirror_info.mirror_reason - trap_group_reason_base;
        receive_info_p->mirror_info.mirror_reason = trap_group_reason_base;
    }
    switch (receive_info_p->mirror_info.mirror_reason) {
    case SX_SPAN_MIRROR_REASON_ING_PORT_E:
    case SX_SPAN_MIRROR_REASON_ING_SHARED_BUFFER_DROP_E:
    case SX_SPAN_MIRROR_REASON_ING_WRED_E:
    case SX_SPAN_MIRROR_REASON_ING_PG_CONGESTION_E:
    case SX_SPAN_MIRROR_REASON_ING_TC_CONGESTION_E:
    case SX_SPAN_MIRROR_REASON_ACL_E:
    case SX_SPAN_MIRROR_REASON_TRAP_GROUP_E:
        receive_info_p->mirror_info.original_direction = SX_SPAN_MIRROR_INGRESS;
        break;

    case SX_SPAN_MIRROR_REASON_EGR_TC_LATENCY_E:
    case SX_SPAN_MIRROR_REASON_EGR_ECN_E:
    case SX_SPAN_MIRROR_REASON_EGR_PORT_E:
        receive_info_p->mirror_info.original_direction = SX_SPAN_MIRROR_EGRESS;
        break;

    default:
        receive_info_p->mirror_info.original_direction = 0;
        break;
    }
}

static sx_status_t __parse_sb_snapshot_trigger_info(const sxd_snapshot_trigger_id_t       sxd_trigger_id,
                                                    sx_sb_snapshot_trigger_enable_type_e *sx_trigger_type_p)
{
    sx_status_t err = SX_STATUS_SUCCESS;

    SX_LOG_ENTER();

    switch (sxd_trigger_id) {
    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SW_COMMAND:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_SW_COMMAND_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_WRED:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_WRED_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_TAIL_DROP:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_SHARED_BUFFER_DROP_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_ING_CONG:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_PG_THRESHOLD_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_EGR_CONG:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_TC_THRESHOLD_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_LATENCY:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_EGR_TC_LATENCY_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_0:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_0_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_1:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_1_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_2:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_2_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_3:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_3_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_4:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_4_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_5:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_5_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_6:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_6_E;
        break;

    case SXD_SBSNS_SNAPSHOT_TRIGGER_ID_SNAP_ID_7:
        *sx_trigger_type_p = SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_7_E;
        break;

    default:
        err = SX_STATUS_PARAM_ERROR;
        break;
    }

    SX_LOG_EXIT();
    return err;
}

static sx_status_t __sb_snapshot_information_get(const sx_sb_snapshot_trigger_enable_type_e sx_trigger_type,
                                                 const sxd_emad_sbsns_data_t                sbsns_data,
                                                 sx_sb_snapshot_information_t              *snapshot_info_p)
{
    sx_status_t      err = SX_STATUS_SUCCESS;
    sx_port_phy_id_t local_port = 0;
    uint32_t         tc_pg = 0;
    sx_port_phy_id_t lp_lsb = 0;
    sx_port_phy_id_t lp_msb = 0;
    sx_port_log_id_t log_port = 0;

    SX_LOG_ENTER();

    lp_lsb = (sbsns_data.reg_data->trigger_parameters >> 8) & 0xff;
    lp_msb = (sbsns_data.reg_data->trigger_parameters >> 16) & 0x3;
    SX_PORT_BUILD_PHY_ID_FROM_LSB_MSB(local_port, lp_lsb, lp_msb);
    tc_pg = sbsns_data.reg_data->trigger_parameters & 0xff;

    SX_PORT_DEV_ID_SET(log_port, sbsns_data.common.dev_id);
    SX_PORT_TYPE_ID_SET(log_port, SX_PORT_TYPE_NETWORK);
    SX_PORT_PHY_ID_SET(log_port, local_port);

    snapshot_info_p->sb_last_snapshot_trigger.type = sx_trigger_type;

    switch (sx_trigger_type) {
    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_SW_COMMAND_E:
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_WRED_E:
        snapshot_info_p->sb_last_snapshot_trigger.object.ing_wred.port = log_port;
        snapshot_info_p->sb_last_snapshot_trigger.object.ing_wred.tc = tc_pg;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_SHARED_BUFFER_DROP_E:
        snapshot_info_p->sb_last_snapshot_trigger.object.ing_sb_drop.port = log_port;
        snapshot_info_p->sb_last_snapshot_trigger.object.ing_sb_drop.tc = tc_pg;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_PG_THRESHOLD_E:
        snapshot_info_p->sb_last_snapshot_trigger.object.ing_pg_threshold.port = local_port;
        snapshot_info_p->sb_last_snapshot_trigger.object.ing_pg_threshold.pg = tc_pg;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ING_TC_THRESHOLD_E:
        snapshot_info_p->sb_last_snapshot_trigger.object.ing_tc_threshold.port = local_port;
        snapshot_info_p->sb_last_snapshot_trigger.object.ing_tc_threshold.tc = tc_pg;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_EGR_TC_LATENCY_E:
        snapshot_info_p->sb_last_snapshot_trigger.object.egr_latency.port = local_port;
        snapshot_info_p->sb_last_snapshot_trigger.object.egr_latency.tc = tc_pg;
        break;

    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_0_E:
    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_1_E:
    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_2_E:
    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_3_E:
    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_4_E:
    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_5_E:
    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_6_E:
    case SX_SB_SNAPSHOT_TRIGGER_ENABLE_ACL_7_E:
        break;

    default:
        SX_LOG_ERR("Snapshot trigger enable object %u is invalid.\n", sx_trigger_type);
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        break;
    }

    SX_LOG_EXIT();
    return err;
}

sx_status_t sx_lib_host_ifc_recv(const sx_fd_t     *fd,
                                 void              *packet,
                                 uint32_t          *packet_size,
                                 sx_receive_info_t *receive_info)
{
    struct ku_read *ku_read = NULL;
    void           *buffer = NULL;
    int             buffer_size = 0;
    int             sxd_err = SXD_STATUS_SUCCESS;
    sx_status_t     err = SX_STATUS_SUCCESS;
    uint32_t        hw_trap_id, vtrap_id;

    SX_API_LOG_ENTER();

    /* validate inputs */
    if (SX_CHECK_FAIL(utils_check_pointer(fd, "file descriptor pointer"))) {
        SX_LOG_ERR("file descriptor is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(packet, "packet buffer pointer"))) {
        SX_LOG_ERR("packet NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(packet_size, "packet size pointer"))) {
        SX_LOG_ERR("packet size is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(receive_info, "receive info pointer"))) {
        SX_LOG_ERR("info pointer is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (fd->valid == FALSE) {
        SX_LOG_ERR("file descriptor is invalid.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (packet_size[0] == 0) {
        SX_LOG_ERR("packet size is 0.\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    memset(receive_info, 0, sizeof(sx_receive_info_t));

    /* get memory for 1 packet */
    buffer_size = sizeof(struct ku_read) + packet_size[0];

    err = utils_clr_memory_get((void*)&buffer, 1, buffer_size, UTILS_MEM_TYPE_ID_API_E);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    /* get packet */
    POSIX_EINTR_RETRY(sxd_err, sxd_recv(fd->driver_handle, buffer, &buffer_size));
    if (sxd_err < 0) {
        if (errno != EAGAIN) {
            SX_LOG_ERR("sxd_recv error %s\n", strerror(errno));
        }
        err = SX_STATUS_ERROR;
        goto out_buffer;
    }

    ku_read = (struct ku_read *)buffer;

    if (buffer_size == 0) {
        SX_LOG_ERR("received buffer size is 0, probably because packet_size is too small for the received buffer\n");
        packet_size[0] = ku_read->length - sizeof(struct ku_read);
        err = SX_STATUS_NO_MEMORY;
        goto out_buffer;
    }

    hw_trap_id = ku_read->trap_id;
    sxd_err = sxd_dpt_vtrap_hw_to_virt_mapping_get(hw_trap_id, &vtrap_id);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("Failed in sxd_dpt_vtrap_hw_to_virt_mapping_get, trap id: [%u] , return value: [%s]\n",
                   ku_read->trap_id,
                   SXD_STATUS_MSG(sxd_err));
        err = SX_STATUS_PARAM_ERROR;
        goto out_buffer;
    }
    receive_info->trap_id = vtrap_id;

    receive_info->original_packet_size = ku_read->original_packet_size;
    receive_info->channel_experienced_drop = ku_read->channel_experienced_drop;
    receive_info->has_timestamp = ku_read->has_timestamp;
    if (receive_info->has_timestamp) {
        receive_info->timestamp.tv_sec = ku_read->timestamp.tv_sec;
        receive_info->timestamp.tv_nsec = ku_read->timestamp.tv_nsec;
        receive_info->timestamp_source = ku_read->timestamp_type ==
                                         SXD_TS_TYPE_LINUX ? SX_PACKET_TIMESTAMP_SOURCE_LINUX_E :
                                         SX_PACKET_TIMESTAMP_SOURCE_HW_UTC_E;
    }

    if (__is_event(vtrap_id)) {
        err = __parse_event(vtrap_id,
                            buffer,
                            buffer_size,
                            receive_info);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("__parse_event failed. err = %d\n", err);
            goto out_buffer;
        }
    } else if (__is_trap(vtrap_id)) {
        memset(&receive_info->event_info, 0, sizeof(receive_info->event_info));
        err = __parse_trap(buffer,
                           packet,
                           packet_size,
                           receive_info);
        if (SX_STATUS_SUCCESS != err) {
            SX_LOG_ERR("__parse_trap failed. err = %d\n", err);
            goto out_buffer;
        }
    } else {
        SX_LOG_ERR("Unknown trap %d\n", vtrap_id);
        err = SX_STATUS_UNEXPECTED_EVENT_TYPE;
        goto out_buffer;
    }

    receive_info->acl_user_id =
        (SX_TRAP_ID_ACL_CHECK_RANGE(vtrap_id)) ? ku_read->user_def_val : SX_ACL_USER_ID_INVALID;

    __parse_mirror_info(ku_read, receive_info);

out_buffer:
    (void)utils_memory_put((void*)buffer, UTILS_MEM_TYPE_ID_API_E);

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_lib_host_ifc_recv_list(const sx_fd_t    *fd,
                                      sx_packet_info_t *packet_info_list_p,
                                      uint32_t         *packet_info_list_size_p)
{
    struct ku_read    *ku_read = NULL;
    void             **buffer_list_pp = NULL;
    uint32_t          *buffer_list_size_p = NULL;
    void              *single_buffer = NULL;
    int                single_buffer_size = 0;
    int                sxd_err = SXD_STATUS_SUCCESS;
    sx_status_t        err = SX_STATUS_SUCCESS;
    uint32_t           hw_trap_id, vtrap_id;
    void             * packet = NULL;
    uint32_t          *packet_size = NULL;
    sx_receive_info_t *receive_info = NULL;
    uint32_t           i;
    uint32_t           packet_info_list_size = 0;
    enum SX_FILE_OP    file_op;
    boolean_t          buf_lock_acquired = FALSE;

    SX_API_LOG_ENTER();

    /* validate inputs */
    if (SX_CHECK_FAIL(utils_check_pointer(fd, "file descriptor pointer"))) {
        SX_LOG_ERR("file descriptor is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (fd->valid == FALSE) {
        SX_LOG_ERR("file descriptor is invalid.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (packet_info_list_size_p == NULL) {
        file_op = SX_FILE_OP_FLUSH;
    } else {
        packet_info_list_size = *packet_info_list_size_p;
        if (packet_info_list_size == 0) {
            file_op = SX_FILE_OP_COUNT;
        } else {
            file_op = SX_FILE_OP_READ;
        }
    }

    if ((packet_info_list_size != 0) &&
        SX_CHECK_FAIL(utils_check_pointer(packet_info_list_p, "packet_info_list_p pointer"))) {
        SX_LOG_ERR("packet_info_list_p is NULL when packet_info_list_size %d \n",
                   packet_info_list_size);
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if ((file_op == SX_FILE_OP_READ) && (READ_MULTI_BUFFS_MAX < packet_info_list_size)) {
        SX_LOG_ERR("READ_MULTI_BUFFS_MAX (%d) < *packet_info_list_size_p (%d)\n",
                   READ_MULTI_BUFFS_MAX, packet_info_list_size);
        SX_API_LOG_EXIT();
        return SX_STATUS_PARAM_ERROR;
    }

    for (i = 0; i < packet_info_list_size; i++) {
        if (SX_CHECK_FAIL(utils_check_pointer(packet_info_list_p[i].packet_p,
                                              "packet buffer pointer"))) {
            SX_LOG_ERR("packet NULL.\n");
            err = SX_STATUS_PARAM_NULL;
            goto out;
        }

        memset(&packet_info_list_p[i].receive_info, 0, sizeof(packet_info_list_p[i].receive_info));
    }

    if (file_op == SX_FILE_OP_READ) {
        cl_spinlock_acquire(&recv_buf_lock_g);
        buf_lock_acquired = TRUE;

        for (i = 0; i < packet_info_list_size; i++) {
            recv_buf_list_g[i] = &(recv_buf_g[i][0]);

            /* driver will validate if packet size is within range because it depends
             * on the switch type this code is running on. SPC1 has maximum RDQ packet size
             * of 10K and SPC2 or later has maximum RDQ size of 12K
             * see __monitor_file_read() in driver code */
            recv_size_list_g[i] = packet_info_list_p[i].packet_size + sizeof(struct ku_read);
        }
        buffer_list_pp = recv_buf_list_g;
        buffer_list_size_p = recv_size_list_g;
    }

    /* get packets */
    err = __rdq_read_multi_from_driver(fd->driver_handle,
                                       file_op,
                                       buffer_list_pp,
                                       buffer_list_size_p,
                                       &packet_info_list_size);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("__rdq_read_multi_from_driver failed . err: %d \n", err);
        goto out;
    }

    for (i = 0; i < packet_info_list_size && file_op == SX_FILE_OP_READ; i++) {
        ku_read = (struct ku_read *)buffer_list_pp[i];
        single_buffer = buffer_list_pp[i];
        single_buffer_size = buffer_list_size_p[i];

        /* local shortcut for out params */
        receive_info = &packet_info_list_p[i].receive_info;
        packet = packet_info_list_p[i].packet_p;
        packet_size = &packet_info_list_p[i].packet_size;

        if (ku_read->length == 0) {
            SX_LOG_ERR("Error : multi_recv received packet with size 0. i = %d \n", i);
            goto out;
        }

        hw_trap_id = ku_read->trap_id;
        sxd_err = sxd_dpt_vtrap_hw_to_virt_mapping_get(hw_trap_id, &vtrap_id);
        if (SXD_CHECK_FAIL(sxd_err)) {
            SX_LOG_ERR("Failed in sxd_dpt_vtrap_hw_to_virt_mapping_get, trap id: [%u] , return value: [%s]\n",
                       ku_read->trap_id,
                       SX_STATUS_MSG(err));
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        receive_info->trap_id = vtrap_id;

        receive_info->original_packet_size = ku_read->original_packet_size;
        receive_info->channel_experienced_drop = ku_read->channel_experienced_drop;
        receive_info->has_timestamp = ku_read->has_timestamp;
        if (receive_info->has_timestamp) {
            receive_info->timestamp.tv_sec = ku_read->timestamp.tv_sec;
            receive_info->timestamp.tv_nsec = ku_read->timestamp.tv_nsec;
            receive_info->timestamp_source = ku_read->timestamp_type ==
                                             SXD_TS_TYPE_LINUX ? SX_PACKET_TIMESTAMP_SOURCE_LINUX_E :
                                             SX_PACKET_TIMESTAMP_SOURCE_HW_UTC_E;
        }

        if (__is_event(vtrap_id)) {
            err = __parse_event(vtrap_id,
                                single_buffer,
                                single_buffer_size,
                                receive_info);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("__parse_event failed. err = %d\n", err);
                goto out;
            }
        } else if (__is_trap(vtrap_id)) {
            err = __parse_trap(single_buffer,
                               packet,
                               packet_size,
                               receive_info);
            if (SX_STATUS_SUCCESS != err) {
                SX_LOG_ERR("__parse_trap failed. err = %d\n", err);
                goto out;
            }
        } else {
            SX_LOG_ERR("Unknown trap %d\n", vtrap_id);
            err = SX_STATUS_UNEXPECTED_EVENT_TYPE;
            goto out;
        }

        receive_info->acl_user_id =
            (SX_TRAP_ID_ACL_CHECK_RANGE(vtrap_id)) ? ku_read->user_def_val : SX_ACL_USER_ID_INVALID;

        __parse_mirror_info(ku_read, receive_info);
    }

    if (packet_info_list_size_p != NULL) {
        *packet_info_list_size_p = packet_info_list_size;
    }

out:
    if (buf_lock_acquired) {
        cl_spinlock_release(&recv_buf_lock_g);
    }
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_host_ifc_counters_get(const sx_api_handle_t                handle,
                                         const sx_access_cmd_t                cmd,
                                         const sx_host_ifc_counters_filter_t *filter_p,
                                         sx_host_ifc_counters_t              *host_ifc_cnt_p)
{
    sx_api_command_head_t                 cmd_head;
    sx_api_host_ifc_counters_get_params_t cmd_body;
    sx_api_reply_head_t                   reply_head;
    sx_api_host_ifc_counters_get_params_t reply_body;
    sx_status_t                           err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    /* validate inputs */
    if ((cmd != SX_ACCESS_CMD_READ) && (cmd != SX_ACCESS_CMD_READ_CLEAR)) {
        SX_LOG_ERR("invalid access command\n");
        err = SX_STATUS_CMD_UNPERMITTED;
        goto out;
    }

    if (host_ifc_cnt_p == NULL) {
        SX_LOG_ERR("host_ifc_cnt_p is NULL\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (host_ifc_cnt_p->trap_group_counters_cnt > SX_TRAP_GROUP_MAX) {
        SX_LOG_ERR("number of group counters is out of range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    if (host_ifc_cnt_p->trap_id_counters_cnt > SX_TRAP_ID_MAX) {
        SX_LOG_ERR("number of trap id counters is out of range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_COUNTERS_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_host_ifc_counters_get_params_t);

    cmd_body.cmd = cmd;
    cmd_body.filter_valid = (filter_p != NULL);
    if (cmd_body.filter_valid) {
        memcpy(&cmd_body.filter, filter_p, sizeof(cmd_body.filter));
    }
    cmd_body.host_ifc_cnt.trap_group_counters_cnt = host_ifc_cnt_p->trap_group_counters_cnt;
    cmd_body.host_ifc_cnt.trap_id_counters_cnt = host_ifc_cnt_p->trap_id_counters_cnt;

    err = sx_api_send_command_decoupled(handle, &cmd_head,
                                        (uint8_t*)&cmd_body, &reply_head, (uint8_t*)&reply_body,
                                        sizeof(sx_api_host_ifc_counters_get_params_t));

    if (err == SX_STATUS_SUCCESS) {
        memcpy(host_ifc_cnt_p, &reply_body.host_ifc_cnt, sizeof(*host_ifc_cnt_p));
    }

out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_host_ifc_trap_id_channel_filter_set(const sx_api_handle_t           handle,
                                                       const sx_access_cmd_t           cmd,
                                                       const sx_swid_t                 swid,
                                                       const sx_trap_id_t              trap_id,
                                                       const sx_user_channel_t        *user_channel_p,
                                                       const sx_host_ifc_filter_key_t *filter_key_p)
{
    sx_status_t                                         err = SX_STATUS_SUCCESS;
    sx_api_host_ifc_trap_id_channel_filter_set_params_t cmd_body;
    sx_host_ifc_register_key_t                          register_key;

    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(register_key);

    SX_API_LOG_ENTER();

    if ((SX_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("Invalid swid range.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("Invalid trap id  %d.\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    err = __user_channel_filter_key_validate(cmd, user_channel_p, filter_key_p);
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if ((cmd != SX_ACCESS_CMD_ADD) && (cmd != SX_ACCESS_CMD_DELETE) && (cmd != SX_ACCESS_CMD_DELETE_ALL)) {
        SX_LOG_ERR("Invalid command  %d.\n", cmd);
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.trap_id = trap_id;
    cmd_body.swid = swid;
    cmd_body.user_channel = *user_channel_p;
    if (filter_key_p != NULL) {
        cmd_body.filter_key = *filter_key_p;
    }

    err = sx_api_send_command_wrapper(handle,
                                      SX_API_INT_CMD_HOST_IFC_TRAP_ID_CHANNEL_FILTER_SET_E,
                                      (uint8_t*)&cmd_body,
                                      sizeof(sx_api_host_ifc_trap_id_channel_filter_set_params_t));
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (filter_key_p != NULL) {
        register_key.key_type = filter_key_p->key_type;
        register_key.key_value = filter_key_p->key_value;
    }

    err = __configure_driver(cmd, ((sx_api_user_ctxt_t*)(uintptr_t)handle)->dev,
                             cmd_body.trap_id, trap_id, swid, &(register_key),
                             user_channel_p, cmd_body.sys_port, 0);
    if (SX_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to configure driver, err = [%s]\n",
                   sx_status_str(err));
        goto out;
    }
out:
    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_host_ifc_trap_id_channel_filter_get(const sx_api_handle_t                         handle,
                                                       const sx_access_cmd_t                         cmd,
                                                       const sx_swid_t                               swid,
                                                       const sx_trap_id_t                            trap_id,
                                                       const sx_host_ifc_channel_filter_get_entry_t *channel_filter_entry,
                                                       sx_host_ifc_channel_filter_get_entry_t       *channel_filter_entry_list_p,
                                                       uint32_t                                     *channel_filter_entry_cnt_p)
{
    sx_status_t                                          err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                                cmd_head;
    sx_api_host_ifc_trap_id_channel_filter_get_params_t  cmd_body;
    sx_api_reply_head_t                                  reply_head;
    sx_api_host_ifc_trap_id_channel_filter_get_params_t *reply_body_p = NULL;
    uint32_t                                             reply_body_size;

    SX_API_LOG_ENTER();
    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((SX_SWID_CHECK_RANGE(swid)) == FALSE) {
        SX_LOG_ERR("Invalid swid range.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_TRAP_ID_CHECK_RANGE(trap_id) == FALSE) {
        SX_LOG_ERR("Invalid trap id %d.\n", trap_id);
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (channel_filter_entry_cnt_p == NULL) {
        SX_LOG_ERR("channel_filter_entry_cnt_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if ((*channel_filter_entry_cnt_p != 0) && (channel_filter_entry_list_p == NULL)) {
        SX_LOG_ERR("*channel_filter_entry_cnt_p is not 0 but channel_filter_entry_list_p is NULL.\n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }
    switch (cmd) {
    case SX_ACCESS_CMD_GET:
        break;

    case SX_ACCESS_CMD_GETNEXT:
        if (channel_filter_entry == NULL) {
            SX_LOG_ERR("channel_filter_entry is NULL.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
        err =
            __user_channel_filter_key_validate(cmd,
                                               &(channel_filter_entry->user_channel),
                                               &(channel_filter_entry->filter_key));
        if (SX_CHECK_FAIL(err)) {
            goto out;
        }
        break;

    case SX_ACCESS_CMD_GET_FIRST:
        if (*channel_filter_entry_cnt_p == 0) {
            goto out;
        }
        break;

    default:
        err = SX_STATUS_CMD_UNSUPPORTED;
        SX_LOG_ERR("cmd %d (%s) failed, err: %s.\n",
                   cmd, sx_access_cmd_str(cmd), sx_status_str(err));
        goto out;
    }

    reply_body_size = sizeof(sx_api_host_ifc_trap_id_channel_filter_get_params_t) +
                      (*channel_filter_entry_cnt_p * sizeof(sx_host_ifc_channel_filter_get_entry_t));

    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body_p), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }
    cmd_head.opcode = SX_API_INT_CMD_HOST_IFC_TRAP_ID_CHANNEL_FILTER_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_host_ifc_trap_id_channel_filter_get_params_t);
    cmd_head.list_size = *channel_filter_entry_cnt_p * sizeof(sx_host_ifc_channel_filter_get_entry_t);

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.trap_id = trap_id;
    cmd_body.channel_filter_entry_cnt = *channel_filter_entry_cnt_p;
    if (cmd == SX_ACCESS_CMD_GETNEXT) {
        SX_MEM_CPY_TYPE(&(cmd_body.channel_filter_entry), channel_filter_entry,
                        sx_host_ifc_channel_filter_get_entry_t);
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body_p,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if ((*channel_filter_entry_cnt_p != 0) && (reply_body_p->channel_filter_entry_cnt != 0)) {
        if (channel_filter_entry_list_p != NULL) {
            SX_MEM_CPY_ARRAY(channel_filter_entry_list_p, reply_body_p->channel_filter_entry_list,
                             reply_body_p->channel_filter_entry_cnt, sx_host_ifc_channel_filter_get_entry_t);
        }
    }
    *channel_filter_entry_cnt_p = reply_body_p->channel_filter_entry_cnt;

out:
    if (reply_body_p != NULL) {
        utils_memory_put(reply_body_p, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_lib_host_ifc_fd_attributes_set(const sx_fd_t* fd_p, sx_fd_t_attributes_t *fd_attrs_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    struct ku_fd_attributes_data fd_attributes_data;
    sxd_ctrl_pack_t              ctrl_pack;
    int                          sxd_err = SXD_STATUS_SUCCESS;

    memset(&fd_attributes_data, 0, sizeof(fd_attributes_data));
    memset(&ctrl_pack, 0, sizeof(ctrl_pack));

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(fd_p, "file descriptor pointer"))) {
        SX_LOG_ERR("file descriptor is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (fd_p->valid == FALSE) {
        SX_LOG_ERR("Invalid file descriptor \n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(fd_attrs_p, "Attributes pointer"))) {
        SX_LOG_ERR("Attributes pointer is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    fd_attributes_data.queue_type = (enum ku_queue_type)(fd_attrs_p->queue_type);

    ctrl_pack.ctrl_cmd = CTRL_CMD_SET_FD_ATTRIBUTES;
    ctrl_pack.cmd_body = (void*)(&fd_attributes_data);

    sxd_err = sxd_ioctl(fd_p->driver_handle, &ctrl_pack);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("sxd_ioctl (set CTRL_CMD_SET_FD_ATTRIBUTES ) error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_lib_host_ifc_fd_attributes_get(const sx_fd_t* fd_p, sx_fd_t_attributes_t *fd_attrs_p)
{
    sx_status_t                  err = SX_STATUS_SUCCESS;
    struct ku_fd_attributes_data fd_attributes_data;
    sxd_ctrl_pack_t              ctrl_pack;
    int                          sxd_err = SXD_STATUS_SUCCESS;

    memset(&fd_attributes_data, 0, sizeof(fd_attributes_data));
    memset(&ctrl_pack, 0, sizeof(ctrl_pack));

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(fd_p, "file descriptor pointer"))) {
        SX_LOG_ERR("file descriptor is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (fd_p->valid == FALSE) {
        SX_LOG_ERR("Invalid file descriptor \n");
        err = SX_STATUS_PARAM_ERROR;
        goto out;
    }

    if (SX_CHECK_FAIL(utils_check_pointer(fd_attrs_p, "Attributes pointer"))) {
        SX_LOG_ERR("Attributes pointer is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    ctrl_pack.ctrl_cmd = CTRL_CMD_GET_FD_ATTRIBUTES;
    ctrl_pack.cmd_body = (void*)(&fd_attributes_data);

    sxd_err = sxd_ioctl(fd_p->driver_handle, &ctrl_pack);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG_ERR("sxd_ioctl (set CTRL_CMD_SET_FD_ATTRIBUTES ) error %s\n", strerror(errno));
        err = SX_STATUS_SXD_RETURNED_NON_ZERO;
        goto out;
    }

    fd_attrs_p->queue_type = (sx_fd_queue_type_e)(fd_attributes_data.queue_type);

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_truncate_profile_set(const sx_api_handle_t                 handle,
                                                      const sx_access_cmd_t                 cmd,
                                                      const sx_swid_t                       swid,
                                                      const sx_trap_truncate_profile_id_t   trunc_profile_id,
                                                      const sx_trap_truncate_profile_cfg_t *trunc_profile_cfg_p)
{
    sx_status_t                                        err = SX_STATUS_SUCCESS;
    sx_api_host_ifc_trap_truncate_profile_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(trunc_profile_cfg_p, "trunc profile cfg pointer"))) {
        SX_LOG_ERR("trunc_profile_cfg_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }


    if ((cmd != SX_ACCESS_CMD_EDIT) && (cmd != SX_ACCESS_CMD_CREATE) && (cmd != SX_ACCESS_CMD_DESTROY)) {
        SX_LOG_ERR("Invalid command  %d.\n", cmd);
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.trunc_profile_id = trunc_profile_id;
    cmd_body.trunc_profile_cfg = *trunc_profile_cfg_p;
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_HOST_IFC_TRAP_TRUNCATE_PROFILE_SET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_host_ifc_trap_truncate_profile_get(const sx_api_handle_t               handle,
                                                      const sx_access_cmd_t               cmd,
                                                      const sx_swid_t                     swid,
                                                      const sx_trap_truncate_profile_id_t trunc_profile_id,
                                                      sx_trap_truncate_profile_cfg_t     *trunc_profile_cfg_p)
{
    sx_status_t                                        err = SX_STATUS_SUCCESS;
    sx_api_host_ifc_trap_truncate_profile_set_params_t cmd_body;

    SX_API_LOG_ENTER();

    if (SX_CHECK_FAIL(utils_check_pointer(trunc_profile_cfg_p, "trunc profile cfg pointer"))) {
        SX_LOG_ERR("trunc_profile_cfg_p is NULL.\n");
        err = SX_STATUS_PARAM_NULL;
        goto out;
    }

    if (cmd != SX_ACCESS_CMD_GET) {
        SX_LOG_ERR("Invalid command  %d.\n", cmd);
        err = SX_STATUS_CMD_UNSUPPORTED;
        goto out;
    }

    cmd_body.cmd = cmd;
    cmd_body.swid = swid;
    cmd_body.trunc_profile_id = trunc_profile_id;
    err = sx_api_send_command_wrapper(handle, SX_API_INT_CMD_HOST_IFC_TRAP_TRUNCATE_PROFILE_GET_E,
                                      (uint8_t*)&cmd_body, sizeof(cmd_body));
    if (SX_STATUS_SUCCESS == err) {
        SX_MEM_CPY_P(trunc_profile_cfg_p, &cmd_body.trunc_profile_cfg);
    }
out:
    SX_API_LOG_EXIT();
    return err;
}
