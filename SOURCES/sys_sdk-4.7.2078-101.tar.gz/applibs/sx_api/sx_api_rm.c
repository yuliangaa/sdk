/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sdk/sx_api_rm.h>
#include "sx_api_internal.h"

#undef  __MODULE__
#define __MODULE__ SX_API_RM

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;


/************************************************
 *  API Functions Implementation
 ***********************************************/

sx_status_t sx_api_rm_sdk_table_thresholds_set(const sx_api_handle_t             handle,
                                               const sx_access_cmd_t             access_cmd,
                                               const rm_sdk_table_type_e         resource,
                                               const sx_notification_threshold_t threshold_full,
                                               const sx_notification_threshold_t threshold_empty)
{
    sx_api_command_head_t                       cmd_head;
    sx_api_rm_sdk_table_thresholds_set_params_t cmd_body;
    sx_api_reply_head_t                         reply_head;
    sx_status_t                                 err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_LOG_DEPRECATED_FUNC_ERR(NULL);

    cmd_head.opcode = SX_API_RM_SDK_TABLE_THRESHOLDS_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_rm_sdk_table_thresholds_set_params_t);

    cmd_body.access_cmd = access_cmd;
    cmd_body.resource = resource;
    cmd_body.threshold_full = threshold_full;
    cmd_body.threshold_empty = threshold_empty;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_rm_sdk_table_thresholds_get(const sx_api_handle_t        handle,
                                               const rm_sdk_table_type_e    resource,
                                               sx_notification_threshold_t *threshold_full,
                                               sx_notification_threshold_t *threshold_empty)
{
    sx_api_rm_sdk_table_thresholds_get_params_t cmd_body;
    sx_status_t                                 rc = SX_STATUS_SUCCESS;
    sx_status_t                                 api_rc = SX_STATUS_SUCCESS;
    uint32_t                                    cmd_size = sizeof(sx_api_rm_sdk_table_thresholds_get_params_t);

    SX_API_LOG_ENTER();

    SX_LOG_DEPRECATED_FUNC_ERR(NULL);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(threshold_full, "Threshold full"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(threshold_empty, "Threshold empty"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    SX_MEM_CLR(cmd_body);


    cmd_body.resource = resource;

    api_rc = sx_api_send_command_wrapper(handle, SX_API_RM_SDK_TABLE_THRESHOLDS_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(api_rc)) {
        *threshold_full = cmd_body.threshold_full;
        *threshold_empty = cmd_body.threshold_empty;
    }


    SX_API_LOG_EXIT();
    return api_rc;
}


sx_status_t sx_api_rm_hw_table_thresholds_set(const sx_api_handle_t             handle,
                                              const sx_access_cmd_t             access_cmd,
                                              const rm_hw_table_type_e          resource,
                                              const sx_notification_threshold_t threshold_full,
                                              const sx_notification_threshold_t threshold_empty)
{
    sx_api_command_head_t                      cmd_head;
    sx_api_rm_hw_table_thresholds_set_params_t cmd_body;
    sx_api_reply_head_t                        reply_head;
    sx_status_t                                err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    SX_LOG_DEPRECATED_FUNC_ERR(NULL);

    cmd_head.opcode = SX_API_RM_HW_TABLE_THRESHOLDS_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_rm_hw_table_thresholds_set_params_t);

    cmd_body.access_cmd = access_cmd;
    cmd_body.resource = resource;
    cmd_body.threshold_full = threshold_full;
    cmd_body.threshold_empty = threshold_empty;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_rm_hw_table_thresholds_get(const sx_api_handle_t        handle,
                                              const rm_hw_table_type_e     resource,
                                              sx_notification_threshold_t *threshold_full,
                                              sx_notification_threshold_t *threshold_empty)
{
    sx_api_rm_hw_table_thresholds_get_params_t cmd_body;
    sx_status_t                                rc = SX_STATUS_SUCCESS;
    sx_status_t                                api_rc = SX_STATUS_SUCCESS;
    uint32_t                                   cmd_size = sizeof(sx_api_rm_hw_table_thresholds_get_params_t);

    SX_API_LOG_ENTER();

    SX_LOG_DEPRECATED_FUNC_ERR(NULL);

    if (SX_CHECK_FAIL(rc = utils_check_pointer(threshold_full, "Threshold full"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    if (SX_CHECK_FAIL(rc = utils_check_pointer(threshold_empty, "Threshold empty"))) {
        SX_API_LOG_EXIT();
        return rc;
    }
    SX_MEM_CLR(cmd_body);


    cmd_body.resource = resource;

    api_rc = sx_api_send_command_wrapper(handle, SX_API_RM_HW_TABLE_THRESHOLDS_GET_E, (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(api_rc)) {
        *threshold_full = cmd_body.threshold_full;
        *threshold_empty = cmd_body.threshold_empty;
    }

    SX_API_LOG_EXIT();
    return api_rc;
}

sx_status_t sx_api_rm_entries_duplication_set(const sx_api_handle_t                   handle,
                                              const sx_api_table_type_t               resource,
                                              const sx_sdk_table_duplication_param_t *param_p)
{
    sx_api_command_head_t                   cmd_head;
    sx_api_rm_table_duplication_set_param_t cmd_body;
    sx_api_reply_head_t                     reply_head;
    sx_status_t                             err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();
    err = utils_check_pointer(param_p, "param_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    cmd_head.opcode = SX_API_RM_CMD_ENTRIES_DUPLICATION_PARAM_SET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) + sizeof(sx_api_rm_table_duplication_set_param_t);

    cmd_body.resource = resource;
    cmd_body.params.num_of_duplication = param_p->num_of_duplication;
    cmd_body.params.sub_type = param_p->sub_type;
    cmd_body.params.threshold = param_p->threshold;

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body, &reply_head, NULL, 0);

out:

    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_rm_entries_duplication_get(const sx_api_handle_t             handle,
                                              const sx_api_table_type_t         resource,
                                              sx_sdk_table_duplication_param_t *param_p)
{
    sx_api_rm_table_duplication_get_param_t cmd_body;
    uint32_t                                cmd_size = sizeof(sx_api_rm_table_duplication_get_param_t);
    sx_status_t                             err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    err = utils_check_pointer(param_p, "param_p");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    cmd_body.resource = resource;
    cmd_body.params.sub_type = param_p->sub_type;

    err = sx_api_send_command_wrapper(handle, SX_API_RM_CMD_ENTRIES_DUPLICATION_PARAM_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    param_p->num_of_duplication = cmd_body.params.num_of_duplication;
    param_p->threshold = cmd_body.params.threshold;

out:

    SX_API_LOG_EXIT();
    return err;
}


sx_status_t sx_api_rm_sdk_table_utilization_get(const sx_api_handle_t          handle,
                                                sx_api_table_type_t           *resource_list_p,
                                                uint32_t                      *list_count_p,
                                                sx_api_rm_table_utilization_t *utilization_list_p)
{
    sx_status_t                   err = SX_STATUS_SUCCESS;
    sx_api_command_head_t         cmd_head;
    sx_api_rm_sdk_table_params_t  cmd_body;
    sx_api_reply_head_t           reply_head;
    sx_api_rm_sdk_table_params_t* reply_body = NULL;
    uint32_t                      reply_body_size;
    uint32_t                      resource_count = 0;
    uint32_t                      i = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((resource_list_p == NULL) || (utilization_list_p == NULL) || (list_count_p == NULL)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Unexpected NULL in input parameters\n");
        goto out;
    }

    for (i = 0; i < *list_count_p; i++) {
        if (RM_SDK_TABLE_TYPE_IS_PORT_RSRC(resource_list_p[i])) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Port resources are not supported by this API.\n");
            goto out;
        }
    }

    resource_count = *list_count_p;
    reply_body_size = sizeof(sx_api_rm_sdk_table_params_t) +
                      (resource_count * sizeof(sx_api_rm_table_utilization_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_RM_SDK_TABLE_UTILIZATION_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_rm_sdk_table_params_t);
    cmd_head.list_size = resource_count * sizeof(sx_api_rm_table_utilization_t);

    cmd_body.access_cmd = SX_ACCESS_CMD_GET;
    cmd_body.list_count = resource_count;

    for (i = 0; i < resource_count; i++) {
        cmd_body.resource_list[i] = resource_list_p[i];
    }


    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);

    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }


    if (reply_body->list_count) {
        *list_count_p = reply_body->list_count;
        if (utilization_list_p != NULL) {
            SX_MEM_CPY_ARRAY(utilization_list_p, reply_body->utilization_list,
                             reply_body->list_count, sx_api_rm_table_utilization_t);
        }
    }


out:

    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_rm_hw_utilization_get(const sx_api_handle_t  handle,
                                         sx_api_hw_table_type_t hw_type,
                                         uint32_t             * utilization_p)
{
    sx_api_rm_hw_utilization_get_param_t cmd_body;
    uint32_t                             cmd_size = sizeof(sx_api_rm_hw_utilization_get_param_t);
    sx_status_t                          err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    err = utils_check_pointer(utilization_p, "utilization");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (RM_HW_TABLE_TYPE_IS_PORT_RSRC(hw_type)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Port resources are not supported by this API.\n");
        goto out;
    }

    cmd_body.resource = hw_type;

    err = sx_api_send_command_wrapper(handle, SX_API_RM_HW_TABLE_UTILIZATION_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(err)) {
        *utilization_p = cmd_body.utilization;
    }


out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_rm_free_entries_by_type_get(const sx_api_handle_t     handle,
                                               const sx_api_table_type_t resource,
                                               uint32_t                 *free_cnt_p)
{
    sx_api_rm_sdk_table_free_entries_get_param_t cmd_body;
    uint32_t                                     cmd_size = sizeof(sx_api_rm_sdk_table_free_entries_get_param_t);
    sx_status_t                                  err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    cmd_body.resource = resource;

    err = utils_check_pointer(free_cnt_p, "free_cnt");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (RM_SDK_TABLE_TYPE_IS_PORT_RSRC(resource)) {
        err = SX_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Port resources are not supported by this API.\n");
        goto out;
    }

    err = sx_api_send_command_wrapper(handle, SX_API_RM_SDK_TABLE_FREE_ENTRY_COUNT_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(err)) {
        *free_cnt_p = cmd_body.free_count;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_rm_sdk_table_utilization_ext_get(const sx_api_handle_t             handle,
                                                    sx_api_rm_sdk_logical_resource_t *resource_list_p,
                                                    uint32_t                         *list_count_p,
                                                    sx_api_rm_table_utilization_t    *utilization_list_p)
{
    sx_status_t                                   err = SX_STATUS_SUCCESS;
    sx_api_command_head_t                         cmd_head;
    sx_api_rm_sdk_log_rsrc_util_ext_get_params_t  cmd_body;
    sx_api_reply_head_t                           reply_head;
    sx_api_rm_sdk_log_rsrc_util_ext_get_params_t* reply_body = NULL;
    uint32_t                                      reply_body_size;
    uint32_t                                      resource_count = 0;
    uint32_t                                      i = 0;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_head);
    SX_MEM_CLR(cmd_body);
    SX_MEM_CLR(reply_head);

    if ((resource_list_p == NULL) || (utilization_list_p == NULL) || (list_count_p == NULL)) {
        err = SX_STATUS_PARAM_NULL;
        SX_LOG_ERR("Unexpected NULL in input parameters\n");
        goto out;
    }

    for (i = 0; i < *list_count_p; i++) {
        if (RM_SDK_TABLE_TYPE_IS_PORT_RSRC(resource_list_p[i].rsrc_type)) {
            if (!resource_list_p[i].key_valid) {
                SX_LOG_ERR("Non System wide Port resources require a valid key.\n");
                err = SX_STATUS_PARAM_ERROR;
                goto out;
            }
        }
    }

    resource_count = *list_count_p;
    reply_body_size = sizeof(sx_api_rm_sdk_log_rsrc_util_ext_get_params_t) +
                      (resource_count * sizeof(sx_api_rm_table_utilization_t));
    if (reply_body_size > MAX_CMD_SIZE) {
        SX_LOG_ERR("Command size exceeds range\n");
        err = SX_STATUS_PARAM_EXCEEDS_RANGE;
        goto out;
    }

    err = utils_clr_memory_get((void**)(&reply_body), 1, reply_body_size,
                               UTILS_MEM_TYPE_ID_API_E);

    if (err != SX_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to allocate memory for command params\n");
        err = SX_STATUS_NO_MEMORY;
        goto out;
    }

    cmd_head.opcode = SX_API_RM_SDK_TABLE_UTILIZATION_EXT_GET_E;
    cmd_head.version = SX_API_INT_VERSION;
    cmd_head.msg_size = sizeof(sx_api_command_head_t) +
                        sizeof(sx_api_rm_sdk_log_rsrc_util_ext_get_params_t);
    cmd_head.list_size = resource_count * sizeof(sx_api_rm_table_utilization_t);

    cmd_body.access_cmd = SX_ACCESS_CMD_GET;
    cmd_body.list_count = resource_count;

    for (i = 0; i < resource_count; i++) {
        SX_MEM_CPY_TYPE(&(cmd_body.resource_list[i]), &(resource_list_p[i]), sx_api_rm_sdk_logical_resource_t);
    }

    err = sx_api_send_command_decoupled(handle, &cmd_head, (uint8_t*)&cmd_body,
                                        &reply_head, (uint8_t*)reply_body,
                                        reply_body_size);
    if (err != SX_STATUS_SUCCESS) {
        goto out;
    }

    if (reply_body->list_count) {
        *list_count_p = reply_body->list_count;
        if (utilization_list_p != NULL) {
            SX_MEM_CPY_ARRAY(utilization_list_p, reply_body->utilization_list,
                             reply_body->list_count, sx_api_rm_table_utilization_t);
        }
    }

out:
    if (reply_body != NULL) {
        utils_memory_put(reply_body, UTILS_MEM_TYPE_ID_API_E);
    }
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_rm_hw_utilization_ext_get(const sx_api_handle_t   handle,
                                             sx_api_rm_hw_resource_t hw_type,
                                             uint32_t              * utilization_p)
{
    sx_api_rm_hw_util_ext_get_param_t cmd_body;
    uint32_t                          cmd_size = sizeof(sx_api_rm_hw_util_ext_get_param_t);
    sx_status_t                       err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    err = utils_check_pointer(utilization_p, "utilization");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (RM_HW_TABLE_TYPE_IS_PORT_RSRC(hw_type.rsrc_type)) {
        if (!hw_type.key_valid) {
            SX_LOG_ERR("Non System wide Port HW resources requires a valid key.\n");
            err = SX_STATUS_PARAM_ERROR;
            goto out;
        }
    }

    cmd_body.hw_resource = hw_type.rsrc_type;
    cmd_body.key_valid = hw_type.key_valid;
    SX_MEM_CPY_TYPE(&cmd_body.hw_key, &hw_type.rsrc_key, sx_rm_hw_rsrc_key_t);

    err = sx_api_send_command_wrapper(handle, SX_API_RM_HW_TABLE_UTILIZATION_EXT_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);
    if (SX_CHECK_PASS(err)) {
        *utilization_p = cmd_body.hw_utilization;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}

sx_status_t sx_api_rm_free_entries_by_type_ext_get(const sx_api_handle_t            handle,
                                                   sx_api_rm_sdk_logical_resource_t resource,
                                                   uint32_t                        *free_cnt_p)
{
    sx_api_rm_sdk_log_rsrc_free_cnt_ext_get_param_t cmd_body;
    uint32_t                                        cmd_size = sizeof(sx_api_rm_sdk_log_rsrc_free_cnt_ext_get_param_t);
    sx_status_t                                     err = SX_STATUS_SUCCESS;

    SX_API_LOG_ENTER();

    SX_MEM_CLR(cmd_body);

    err = utils_check_pointer(free_cnt_p, "free_cnt");
    if (SX_CHECK_FAIL(err)) {
        goto out;
    }

    if (RM_SDK_TABLE_TYPE_IS_PORT_RSRC(resource.rsrc_type)) {
        if (!resource.key_valid) {
            err = SX_STATUS_PARAM_ERROR;
            SX_LOG_ERR("Non System wide Port resources requires a valid key to query free entries.\n");
            goto out;
        }
    }

    cmd_body.sdk_resource.rsrc_type = resource.rsrc_type;
    cmd_body.sdk_resource.key_valid = resource.key_valid;
    SX_MEM_CPY_TYPE(&cmd_body.sdk_resource.rsrc_key, &resource.rsrc_key, sx_rm_sdk_rsrc_key_t);

    err = sx_api_send_command_wrapper(handle, SX_API_RM_SDK_TABLE_FREE_ENTRY_COUNT_EXT_GET_E,
                                      (uint8_t*)&cmd_body, cmd_size);

    if (SX_CHECK_PASS(err)) {
        *free_cnt_p = cmd_body.free_count;
    }

out:
    SX_API_LOG_EXIT();
    return err;
}
