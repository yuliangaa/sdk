/*
 * SPDX-FileCopyrightText: Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


#ifndef ISSU_H_
#define ISSU_H_

#include <sx/sdk/sx_types.h>
#include <sx/sxd/sxd_dpt.h>
#include <utils/utils.h>
/************************************************
 *  Defines
 ***********************************************/
#define ISSU_PERSISTENT_DEFAULT_PATH "/var/"
#define ISSU_PERSISTENT_PATH_LEN_MAX (SX_ISSU_PATH_LEN_MAX * 2)

typedef enum sx_issu_bank {
    SX_ISSU_BANK_1_E = 0,
    SX_ISSU_BANK_2_E,
    SX_ISSU_BANK_MAX_E = SX_ISSU_BANK_2_E,
} sx_issu_bank_e;

typedef struct sx_issu_params {
    sx_issu_bank_e issu_bank;
} sx_issu_params_t;

typedef struct sx_issu_resume_params {
    uint32_t             app_id;
    sx_log_cb_t          logging_cb;
    sx_verbosity_level_t verbosity_level;
    boolean_t            sdk_transaction_mode;
} sx_issu_resume_params_t;

typedef struct sx_issu_cfg_pdb_params {
    boolean_t acl_default_actions_en;
    boolean_t acl_pagt_v2_support;
} sx_issu_cfg_pdb_params;

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/
sx_status_t issu_init(const sx_boot_mode_init_params_t* issu_init_param_p, sx_api_profile_t *profile_p);
sx_status_t ib_issu_init(const sx_boot_mode_init_params_t* issu_init_param_p, sx_api_profile_t *profile_p);
sx_status_t issu_boot_mode_get(sx_boot_mode_e *boot_mode_p);
sx_status_t issu_bank_get(sx_issu_bank_e *issu_bank_p);
sx_status_t issu_start_set();
sx_status_t issu_end_set();
sx_status_t ib_issu_start_set();
sx_status_t ib_issu_end_set();
sx_status_t issu_pause_set();
sx_status_t issu_resume_set(sx_issu_resume_params_t resume_params);
sx_status_t issu_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sx_status_t issu_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level);
void issu_debug_dump(dbg_dump_params_t* dbg_dump_params_p);
sx_status_t issu_dpt_access_control_set(dpt_access_control_t access_control);
sx_status_t issu_lag_port_list_get(sx_lag_id_t lid, sx_port_log_id_t *log_port_list, uint32_t *port_list_cnt);
sx_status_t issu_lag_id_get(sx_port_log_id_t log_port, sx_lag_id_t *lag_port_p);
sx_status_t issu_lag_with_no_ports_get(sx_lag_id_t *lag_id_p);
sx_status_t issu_lag_port_count_get(sx_lag_id_t lid, uint32_t *lag_port_count);
sx_status_t issu_lag_exist_get(sx_lag_id_t lid, boolean_t *lag_exists_p);
sx_status_t issu_lag_max_exist_get(sx_lag_id_t *lid);
sx_status_t issu_db_lag_destroy(sx_lag_id_t lid);
sx_status_t issu_lag_config_restore_flag_get(boolean_t *issu_lag_config_restore_flag);
sx_status_t issu_lag_fdb_recovery_flag_get(boolean_t *lag_fdb_not_recoverable);
sx_status_t issu_lag_fdb_recovery_flag_set(boolean_t lag_fdb_not_recoverable);
sx_status_t issu_port_map_restore_flag_get(boolean_t *issu_port_map_restore_flag_p);
sx_status_t issu_port_map_list_get(sx_port_mapping_t** port_mapping_list_pp, uint32_t* size_p);
sx_status_t issu_port_map_by_id_get(sx_port_phy_id_t local_port, sx_port_mapping_t* port_mapping_p);
sx_status_t issu_ports_map_is_persistent_get(boolean_t* persistent_map_exists);
sx_status_t issu_mapping_done(sx_port_phy_id_t local_port);
sx_status_t issu_db_lag_port_list_clear(sx_lag_id_t lid);
sx_status_t issu_port_post_init(sx_port_log_id_t log_port);
sx_status_t issu_disable_mocs_transactions_spc();
sx_status_t issu_disable_mocs_transactions_spc2();
sx_status_t issu_disable_mocs_transactions_spc4();
sx_status_t issu_handle_mocs_done(uint64_t event_id);
boolean_t issu_mocs_session_status_check();
boolean_t is_infiniband_issu();
sx_status_t issu_infiniband_set(sx_api_profile_t* profile);

#endif /* ISSU_H_ */
