/*
 * SPDX-FileCopyrightText: Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "sxd_fw_trace_int.h"
#include <sx/sxd/sxd_fw_trace.h>
#include <unistd.h>
#include <stdio.h>
#include <sx/sxd/sxd_access_register.h>
#include <complib/cl_mem.h>
#include <complib/cl_fleximap.h>
#include <complib/cl_fcntl.h>
#include <complib/cl_byteswap.h>
#include <complib/cl_math.h>
#include <sx/utils/dbg_utils.h>
#include <sx/sxd/sxd_fw_trace.h>
#include <sx/sxd/sxd_dpt.h>
#include <errno.h>

#undef  __MODULE__
#define __MODULE__ SXD_FW_TRACE_DB


sxd_fw_trace_common_db_t fw_trace_db;

/************************************************
 *  Local function declarations
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

static uint32_t __sxd_fw_trace_db_get_num_of_params(char *str);

/*Get number of argument in string, change "%llx" to "x%x"*/
static const char *VAL_PARM = "%llx";
static const char *REPLACE_64_VAL_PARM = "%x%x";
static const char *PARAM_CHAR = "%";

/*Store and read string.db sections in JSON file*/
static const char *SECTION_DATA_STR = "string_db_section_data";
static const char *SECTION_BASE_OFFSET_STR = "section_base_offset";
static const char *SECTION_SIZE_STR = "section_size";
static const char *SECTION_ARR_STR = "string_db_sections_arr";
static const char *SECTION_NUM_STR = "string_db_sections_num";
static const char *FW_VER_STR = "fw_version_str";

/*Store and read FW tracer attributes in JSON file*/
static const char *HOST_MEM_PAGE_NUM_STR = "host_mem_page_num";
static const char *DWSN_MSB_BOOL_STR = "is_msb_dwsn_supported";
static const char *EVENT_ID_NUM_STR = "event_id_num";
static const char *FIRST_EVENT_ID_STR = "first_fw_event_id";
static const char *EVENT_ID_MAP_TILE_NUM_STR = "tile_num";
static const char *EVENT_ID_MAP_PROC_TILE_NUM_STR = "proc_tile_num";
static const char *EVENT_ID_MAP_PROC_MAIN_NUM_STR = "proc_main_num";
static const char *EVENT_ID_MAP_MAIN_FIRST_EVENT_ID_STR = "main_first_event_id";
static const char *EVENT_ID_MAP_TILE_FIRST_EVENT_ID_ARR_STR = "tile_first_event_id_arr";
static const char *EVENT_ID_MAP_PHY_MC_STR = "phy_mc_sup";
static const char *EVENT_ID_MAP_STR = "event_id_mapping_info";

/************************************************
 *  Function implementations
 ***********************************************/

void sxd_fw_trace_db_sdk_folder_path_set(char *sdk_folder_path)
{
    strncpy(fw_trace_db.sdk_folder_path, sdk_folder_path, SDK_FOLDER_PATH_LEN);
}

void sxd_fw_trace_db_sdk_folder_path_get(char *sdk_folder_path)
{
    if (strlen(fw_trace_db.sdk_folder_path) > 0) {
        strcpy(sdk_folder_path, fw_trace_db.sdk_folder_path);
    } else {
        sdk_folder_path[0] = '\0';
    }
}

void sxd_fw_trace_db_event_msg_db_set(sxd_fw_trace_event_id_msg_t *event_id_msg_db)
{
    fw_trace_db.event_id_msg_db_arr = event_id_msg_db;

    return;
}

void sxd_fw_trace_db_event_msg_db_get(sxd_fw_trace_event_id_msg_t *event_id_msg_db)
{
    memcpy(event_id_msg_db, fw_trace_db.event_id_msg_db_arr, sizeof(sxd_fw_trace_event_id_msg_t));
    return;
}

void sxd_fw_trace_db_max_event_id_set(uint32_t max_event_id)
{
    fw_trace_db.max_event_id = max_event_id;
}

uint32_t sxd_fw_trace_db_max_event_id_get(void)
{
    return fw_trace_db.max_event_id;
}

void sxd_fw_trace_db_event_id_msg_db_set(sxd_fw_trace_event_id_msg_t *event_id_msg_db, uint32_t event_id)
{
    memcpy(&(fw_trace_db.event_id_msg_db_arr[event_id]), event_id_msg_db, sizeof(sxd_fw_trace_event_id_msg_t));
    return;
}

sxd_fw_trace_event_id_msg_t * sxd_fw_trace_db_event_id_msg_db_get(uint32_t event_id)
{
    return &(fw_trace_db.event_id_msg_db_arr[event_id]);
}

void sxd_fw_trace_db_string_db_set(sxd_fw_trace_string_db_t *string_db)
{
    memcpy(&(fw_trace_db.string_db), string_db, sizeof(sxd_fw_trace_string_db_t));
    return;
}

void sxd_fw_trace_db_string_db_get(sxd_fw_trace_string_db_t *string_db)
{
    memcpy(string_db, &(fw_trace_db.string_db), sizeof(sxd_fw_trace_string_db_t));
    return;
}
#define MAX_STRING_DB_SECTION_SIZE     1024000 /*1MB*/
#define BYTES_IN_UINT32                4
#define SXD_MTRC_STDB_V2_MAX_BYTES_NUM (BYTES_IN_UINT32 * SXD_MTRC_STDB_V2_STRING_DB_DATA_NUM) /* 358*4 = 1432 */
#define SXD_MTRC_STDB_V2_CIF_BYTES_NUM (BYTES_IN_UINT32 * 56) /* 56*4 = 224 */

sxd_status_t sxd_fw_trace_db_extract_string_db_sections(sxd_dev_id_t                    dev_id,
                                                        sxd_mtrc_cap_string_db_param_t *string_db_sections_param_arr,
                                                        uint32_t                        sections_num)
{
    sxd_status_t               st = SXD_STATUS_SUCCESS;
    uint32_t                   i = 0, j = 0;
    uint32_t                   bytes_offset = 0, num_of_reads = 0, leftover = 0; /* in Bytes */
    struct ku_mtrc_stdb_v2_reg mtrc_stdb_data;
    sxd_reg_meta_t             mtrc_meta;
    sxd_swid_t                 swid = 0;
    boolean_t                  is_emad_used = FALSE;
    uint32_t                   bytes_in_mtrc = SXD_MTRC_STDB_V2_MAX_BYTES_NUM;

    /* make sure that registers are accessed through EMAD */
    sxd_dpt_is_emad_used(dev_id, &is_emad_used);

    if (!is_emad_used) {
        /* Command interface mailboxes are smaller, so we'll need to have more register calls in order to
         * get all the string DB. */
        bytes_in_mtrc = SXD_MTRC_STDB_V2_CIF_BYTES_NUM;
    }

    memset(&mtrc_stdb_data, 0, sizeof(mtrc_stdb_data));
    memset(&mtrc_meta, 0, sizeof(mtrc_meta));

    mtrc_meta.dev_id = dev_id;
    mtrc_meta.swid = swid;
    mtrc_meta.access_cmd = SXD_ACCESS_CMD_GET;

    fw_trace_db.string_db.string_db_sections_num = sections_num;

    for (i = 0; i < fw_trace_db.string_db.string_db_sections_num; i++) {
        fw_trace_db.string_db.string_db_section_arr[i].section_start_base_addr =
            string_db_sections_param_arr[i].string_db_base_address;
        fw_trace_db.string_db.string_db_section_arr[i].section_size = string_db_sections_param_arr[i].string_db_size;
        if (string_db_sections_param_arr[i].string_db_size > MAX_STRING_DB_SECTION_SIZE) {
            SX_LOG_ERR("String.db sections[%d] size is 0x%x Bytes. Max size supported is 0x%x Bytes.\n",
                       i, string_db_sections_param_arr[i].string_db_size, MAX_STRING_DB_SECTION_SIZE);
            goto out;
        }
        if ((string_db_sections_param_arr[i].string_db_size % 4) != 0) {
            SX_LOG_ERR("String.db sections size should be multiple of 4, but section[%d] has size of 0x%x\n",
                       i, string_db_sections_param_arr[i].string_db_size);
            goto out;
        }
        fw_trace_db.string_db.string_db_section_arr[i].raw_section_ptr =
            (uint32_t*)cl_malloc(
                ((fw_trace_db.string_db.string_db_section_arr[i].section_size) / BYTES_IN_UINT32) *
                sizeof(uint32_t));
        if (fw_trace_db.string_db.string_db_section_arr[i].raw_section_ptr == NULL) {
            st = SXD_STATUS_NO_MEMORY;
            goto out;
        }

        memset(fw_trace_db.string_db.string_db_section_arr[i].raw_section_ptr, 0,
               (((fw_trace_db.string_db.string_db_section_arr[i].section_size) / BYTES_IN_UINT32) *
                sizeof(uint32_t)));

        /* Get the string db section*/
        num_of_reads = fw_trace_db.string_db.string_db_section_arr[i].section_size / bytes_in_mtrc;
        leftover = fw_trace_db.string_db.string_db_section_arr[i].section_size % bytes_in_mtrc;
        bytes_offset = 0;
        mtrc_stdb_data.string_db_index = i;


        for (j = 0; j < num_of_reads; j++) {
            mtrc_stdb_data.start_offset =
                (fw_trace_db.string_db.string_db_section_arr[i].section_start_base_addr + bytes_offset);
            mtrc_stdb_data.read_size = bytes_in_mtrc;

            st = sxd_access_reg_mtrc_stdb_v2(&mtrc_stdb_data, &mtrc_meta, 1, NULL, NULL);
            if (SXD_CHECK_FAIL(st)) {
                goto out;
            }

            memcpy((fw_trace_db.string_db.string_db_section_arr[i].raw_section_ptr + (bytes_offset / BYTES_IN_UINT32)),
                   mtrc_stdb_data.string_db_data, bytes_in_mtrc);

            bytes_offset += bytes_in_mtrc;
        }

        if (leftover) {
            mtrc_stdb_data.start_offset =
                (fw_trace_db.string_db.string_db_section_arr[i].section_start_base_addr + bytes_offset);
            mtrc_stdb_data.read_size = leftover;
            mtrc_stdb_data.string_db_index = i;

            st = sxd_access_reg_mtrc_stdb_v2(&mtrc_stdb_data, &mtrc_meta, 1, NULL, NULL);
            if (SXD_CHECK_FAIL(st)) {
                goto out;
            }

            memcpy((fw_trace_db.string_db.string_db_section_arr[i].raw_section_ptr + (bytes_offset / BYTES_IN_UINT32)),
                   &mtrc_stdb_data.string_db_data, leftover);
        }

        SX_LOG_DBG(
            "Read string.db section [%d], size 0x%x, base addr 0x%x\n",
            i,
            fw_trace_db.string_db.string_db_section_arr[i].section_size,
            fw_trace_db.string_db.string_db_section_arr[i].section_start_base_addr);
    }

out:
    return st;
}


sxd_status_t sxd_fw_trace_db_store_fw_trace_string_db_in_json_file(FILE *string_db_file_stream, char* fw_version_str)
{
    sxd_status_t st = SXD_STATUS_SUCCESS;
    uint32_t     i = 0, j = 0;
    cJSON       *root = NULL;
    cJSON       *sections_db = cJSON_CreateArray();
    uint32_t     section_size_in_int = 0;
    char        *out_str = NULL;


    if (string_db_file_stream == NULL) {
        st = SXD_STATUS_ERROR;
        SX_LOG_ERR("Error cannot write string db attributes to JSON file\n");
        goto out;
    }

    root = cJSON_CreateObject();
    if (!root) {
        st = SXD_STATUS_ERROR;
        SX_LOG_ERR("Fails to create json object.\n");
        goto out;
    }

    cJSON *fw_ver_str_obj = cJSON_CreateString(fw_version_str);

    cJSON_AddItemToObject(root, FW_VER_STR, fw_ver_str_obj);

    cJSON *sections_num_obj = cJSON_CreateNumber(fw_trace_db.string_db.string_db_sections_num);

    cJSON_AddItemToObject(root, SECTION_NUM_STR, sections_num_obj);

    for (i = 0; i < fw_trace_db.string_db.string_db_sections_num; i++) {
        cJSON *section = cJSON_CreateObject();
        cJSON *base_offset =
            cJSON_CreateNumber(fw_trace_db.string_db.string_db_section_arr[i].section_start_base_addr);
        cJSON *section_size = cJSON_CreateNumber(fw_trace_db.string_db.string_db_section_arr[i].section_size);

        cJSON_AddItemToObject(section, SECTION_BASE_OFFSET_STR, base_offset);
        cJSON_AddItemToObject(section, SECTION_SIZE_STR, section_size);

        cJSON *section_arr = cJSON_CreateArray();

        section_size_in_int = fw_trace_db.string_db.string_db_section_arr[i].section_size / BYTES_IN_UINT32;

        for (j = 0; j < section_size_in_int; j++) {
            cJSON *section_data_int = cJSON_CreateNumber(
                fw_trace_db.string_db.string_db_section_arr[i].raw_section_ptr[j]);
            cJSON_AddItemToArray(section_arr, section_data_int);
        }

        cJSON_AddItemToObject(section, SECTION_DATA_STR, section_arr);

        /* add the section to the sections array */
        cJSON_AddItemToArray(sections_db, section);
    }
    cJSON_AddItemToObject(root, SECTION_ARR_STR, sections_db);

    out_str = cJSON_Print(root);
    if (!out_str) {
        st = SXD_STATUS_ERROR;
        SX_LOG_ERR("Fails to generate json content.\n");
        goto out;
    }

    fprintf(string_db_file_stream, "%s", out_str);

    if (root) {
        cJSON_Delete(root);
    }

    if (out_str) {
        cJSON_free(out_str);
    }
out:
    return st;
}


sxd_status_t sxd_fw_trace_db_restore_fw_trace_string_db_from_json_file(FILE *string_db_file_stream,
                                                                       char* fw_version_str)
{
    sxd_status_t sxd_status = SXD_STATUS_SUCCESS;
    size_t       length = 0;
    cl_status_t  cl_status;
    char       * buffer = NULL;
    const char  *error_ptr = NULL;
    cJSON       *json_obj = NULL, *section_obj = NULL,
                *sections_db_arr_obj = NULL, *tmp_obj = NULL, *section_data_arr_obj = NULL;
    uint32_t i = 0, offset = 0, section_data_int;
    uint8_t  bytes[4] = {"0"};

    if (string_db_file_stream == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_ERR("Error cannot read string_db JSON file\n");
        goto out;
    }

    fseek(string_db_file_stream, 0, SEEK_SET);
    cl_status = cl_file_size(string_db_file_stream, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sxd_status = SXD_STATUS_ERROR;
        goto out;
    }

    buffer = cl_malloc(length + 1);
    if (!buffer) {
        sxd_status = SXD_STATUS_NO_MEMORY;
        goto out;
    }

    if (cl_fread(buffer, 1, length, string_db_file_stream) != length) {
        sxd_status = SXD_STATUS_ERROR;
        goto out;
    }

    buffer[length] = 0;

    json_obj = cJSON_Parse(buffer);
    if (json_obj == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("FW trace restore - Error before: %s\n", error_ptr);
        }
        sxd_status = SXD_STATUS_ERROR;
        goto out;
    }

    sections_db_arr_obj = cJSON_GetObjectItemCaseSensitive(json_obj, SECTION_ARR_STR);
    if (sections_db_arr_obj == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("failed to get string db sections from JSON\n");
        goto out;
    }

    tmp_obj = cJSON_GetObjectItemCaseSensitive(json_obj, FW_VER_STR);
    if (tmp_obj == NULL) {
        SX_LOG_NTC("failed to get FW version JSON\n");
        sxd_status = SXD_STATUS_ERROR;
        goto out;
    }
    strncpy(fw_version_str, cJSON_GetStringValue(tmp_obj), FW_VERSION_EXTENDED_STR_LEN);

    tmp_obj = cJSON_GetObjectItemCaseSensitive(json_obj, SECTION_NUM_STR);
    if (tmp_obj == NULL) {
        SX_LOG_NTC("failed to get sections number base address from JSON\n");
        sxd_status = SXD_STATUS_ERROR;
        goto out;
    }
    fw_trace_db.string_db.string_db_sections_num = (uint32_t)cJSON_GetNumberValue(tmp_obj);

    i = 0;
    cJSON_ArrayForEach(section_obj, sections_db_arr_obj) {
        tmp_obj = cJSON_GetObjectItemCaseSensitive(section_obj, SECTION_BASE_OFFSET_STR);
        if (tmp_obj == NULL) {
            SX_LOG_NTC("failed to get section[%d] base address from JSON\n", i);
            goto out;
        }
        fw_trace_db.string_db.string_db_section_arr[i].section_start_base_addr =
            (uint32_t)cJSON_GetNumberValue(tmp_obj);

        tmp_obj = cJSON_GetObjectItemCaseSensitive(section_obj, SECTION_SIZE_STR);
        if (tmp_obj == NULL) {
            sxd_status = SXD_STATUS_ERROR;
            SX_LOG_NTC("failed to get section[%d] size from JSON\n", i);
            goto out;
        }
        fw_trace_db.string_db.string_db_section_arr[i].section_size = (uint32_t)cJSON_GetNumberValue(tmp_obj);

        fw_trace_db.string_db.string_db_section_arr[i].section_ptr =
            (uint8_t*)cl_malloc(fw_trace_db.string_db.string_db_section_arr[i].section_size * sizeof(uint8_t));
        if (fw_trace_db.string_db.string_db_section_arr[i].section_ptr == NULL) {
            sxd_status = SXD_STATUS_NO_MEMORY;
            goto out;
        }

        section_data_arr_obj = cJSON_GetObjectItemCaseSensitive(section_obj, SECTION_DATA_STR);
        if (section_data_arr_obj == NULL) {
            sxd_status = SXD_STATUS_ERROR;
            SX_LOG_NTC("Get section data from JSON failed\n");
            goto out;
        }

        offset = 0;
        cJSON_ArrayForEach(tmp_obj, section_data_arr_obj) {
            section_data_int = (uint32_t)cJSON_GetNumberValue(tmp_obj);

            /*go over mtrc_stdb_data.string_db_data which is array of integers and convert each integer to 4 byte.
             * copy the bytes to the section buffer*/
            bytes[0] = (section_data_int >> 24) & 0xFF;
            bytes[1] = (section_data_int >> 16) & 0xFF;
            bytes[2] = (section_data_int >> 8) & 0xFF;
            bytes[3] = section_data_int & 0xFF;

            memcpy((fw_trace_db.string_db.string_db_section_arr[i].section_ptr + offset),
                   bytes, BYTES_IN_UINT32);

            offset += BYTES_IN_UINT32;
        }

        i++;
    }
    if (i != fw_trace_db.string_db.string_db_sections_num) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("number of string_db sections in JSON [%d] is not equal to number of sections parameter[%d]\n"
                   , i, fw_trace_db.string_db.string_db_sections_num);
    }

out:
    if (buffer) {
        cl_free(buffer);
    }
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    return sxd_status;
}


sxd_status_t sxd_fw_trace_db_store_fw_trace_init_attr_in_json_file(sxd_fw_trace_event_id_map_t *event_id_info,
                                                                   uint32_t                     mlx_buf_pg_num,
                                                                   uint32_t                     events_id_num,
                                                                   uint32_t                     first_fw_event_id,
                                                                   boolean_t                    is_dwsn_msb_supported,
                                                                   FILE                        *fw_trace_init_attr_file_stream)
{
    uint32_t     i;
    cJSON       *root = NULL;
    sxd_status_t sxd_status = SXD_STATUS_SUCCESS;
    char        *out_str = NULL;

    if (fw_trace_init_attr_file_stream == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_ERR("Error cannot write init attributes to JSON file\n");
        goto out;
    }

    root = cJSON_CreateObject();
    if (!root) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_ERR("Fails to create json object.\n");
        goto out;
    }


    cJSON *is_msb_dwsn_supported = cJSON_CreateBool(is_dwsn_msb_supported);
    cJSON *first_event_id = cJSON_CreateNumber(first_fw_event_id);
    cJSON *host_mem_page_num = cJSON_CreateNumber(mlx_buf_pg_num);
    cJSON *event_id_num = cJSON_CreateNumber(events_id_num);

    cJSON_AddItemToObject(root, DWSN_MSB_BOOL_STR, is_msb_dwsn_supported);
    cJSON_AddItemToObject(root, HOST_MEM_PAGE_NUM_STR, host_mem_page_num);
    cJSON_AddItemToObject(root, EVENT_ID_NUM_STR, event_id_num);
    cJSON_AddItemToObject(root, FIRST_EVENT_ID_STR, first_event_id);

    /*event_id_mapping_info*/
    cJSON *event_id_mapping = cJSON_CreateObject();
    cJSON *tile_num = cJSON_CreateNumber(event_id_info->tile_num);
    cJSON *proc_tile_num = cJSON_CreateNumber(event_id_info->proc_tile_num);
    cJSON *proc_main_num = cJSON_CreateNumber(event_id_info->proc_main_num);
    cJSON *main_first_event_id = cJSON_CreateNumber(event_id_info->main_first_event_id);
    cJSON *phy_mc_sup = cJSON_CreateNumber(event_id_info->phy_mc_supported);

    cJSON_AddItemToObject(event_id_mapping, EVENT_ID_MAP_TILE_NUM_STR, tile_num);
    cJSON_AddItemToObject(event_id_mapping, EVENT_ID_MAP_PROC_TILE_NUM_STR, proc_tile_num);
    cJSON_AddItemToObject(event_id_mapping, EVENT_ID_MAP_PROC_MAIN_NUM_STR, proc_main_num);
    cJSON_AddItemToObject(event_id_mapping, EVENT_ID_MAP_MAIN_FIRST_EVENT_ID_STR, main_first_event_id);
    cJSON_AddItemToObject(event_id_mapping, EVENT_ID_MAP_PHY_MC_STR, phy_mc_sup);

    cJSON *tile_first_event_id_arr = cJSON_CreateArray();

    for (i = 0; i < event_id_info->tile_num; i++) {
        cJSON *tile_first_event_id = cJSON_CreateNumber(event_id_info->tile_first_event_id[i]);
        cJSON_AddItemToArray(tile_first_event_id_arr, tile_first_event_id);
    }
    cJSON_AddItemToObject(event_id_mapping, EVENT_ID_MAP_TILE_FIRST_EVENT_ID_ARR_STR, tile_first_event_id_arr);
    cJSON_AddItemToObject(root, EVENT_ID_MAP_STR, event_id_mapping);

    out_str = cJSON_Print(root);
    if (!out_str) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_ERR("Fails to generate json content.\n");
        goto out;
    }
    fprintf(fw_trace_init_attr_file_stream, "%s", out_str);

out:

    if (root) {
        cJSON_Delete(root);
    }

    if (out_str) {
        cJSON_free(out_str);
    }

    return sxd_status;
}


sxd_status_t sxd_fw_trace_db_restore_fw_trace_init_attr_from_json_file(sxd_fw_trace_event_id_map_t *event_id_info,
                                                                       uint32_t                    *mlx_buf_pg_num,
                                                                       uint32_t                    *events_id_num,
                                                                       uint32_t                    *first_fw_event_id,
                                                                       boolean_t                   *is_dwsn_msb_supported,
                                                                       FILE                        *fw_trace_init_attr_file_stream)
{
    sxd_status_t sxd_status = SXD_STATUS_SUCCESS;
    size_t       length = 0;
    cl_status_t  cl_status;
    char       * buffer = NULL;
    const char  *error_ptr = NULL;
    cJSON       *json_obj = NULL, *event_id_mapping_obj = NULL,
                *tile_first_event_id_arr_obj = NULL, *tmp_obj = NULL;
    uint32_t i = 0;

    if (fw_trace_init_attr_file_stream == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_ERR("Error cannot read init attributes from JSON file\n");
        goto out;
    }

    fseek(fw_trace_init_attr_file_stream, 0, SEEK_SET);
    cl_status = cl_file_size(fw_trace_init_attr_file_stream, &length);
    if (cl_status != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, err - %s \n", CL_STATUS_MSG(cl_status));
        sxd_status = SXD_STATUS_ERROR;
        goto out;
    }

    buffer = cl_malloc(length + 1);
    if (!buffer) {
        sxd_status = SXD_STATUS_NO_MEMORY;
        goto out;
    }

    if (cl_fread(buffer, 1, length, fw_trace_init_attr_file_stream) != length) {
        sxd_status = SXD_STATUS_ERROR;
        goto out;
    }

    buffer[length] = 0;

    json_obj = cJSON_Parse(buffer);
    if (json_obj == NULL) {
        error_ptr = cJSON_GetErrorPtr();
        if (error_ptr != NULL) {
            SX_LOG_ERR("FW trace restore - Error before: %s\n", error_ptr);
        }
        sxd_status = SXD_STATUS_ERROR;
        goto out;
    }

    tmp_obj = cJSON_GetObjectItemCaseSensitive(json_obj, FIRST_EVENT_ID_STR);
    if (tmp_obj == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("main first_event_id get from JSON failed\n");
        goto out;
    }
    *first_fw_event_id = (uint32_t)cJSON_GetNumberValue(tmp_obj);

    tmp_obj = cJSON_GetObjectItemCaseSensitive(json_obj, DWSN_MSB_BOOL_STR);
    if (tmp_obj == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("is_msb_dwsn_supported get from JSON failed\n");
        goto out;
    }
    if ((boolean_t)cJSON_GetNumberValue(tmp_obj) == TRUE) {
        *is_dwsn_msb_supported = TRUE;
    } else {
        *is_dwsn_msb_supported = FALSE;
    }
    tmp_obj = cJSON_GetObjectItemCaseSensitive(json_obj, HOST_MEM_PAGE_NUM_STR);
    if (tmp_obj == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("host_mem_pages_num get from JSON failed\n");
        goto out;
    }
    *mlx_buf_pg_num = (uint32_t)cJSON_GetNumberValue(tmp_obj);

    tmp_obj = cJSON_GetObjectItemCaseSensitive(json_obj, EVENT_ID_NUM_STR);
    if (tmp_obj == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("event_id_num get from JSON failed\n");
        goto out;
    }
    *events_id_num = (uint32_t)cJSON_GetNumberValue(tmp_obj);

    event_id_mapping_obj = cJSON_GetObjectItemCaseSensitive(json_obj, EVENT_ID_MAP_STR);

    tmp_obj = cJSON_GetObjectItemCaseSensitive(event_id_mapping_obj, EVENT_ID_MAP_TILE_NUM_STR);
    if (tmp_obj == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("tiles number get from JSON failed\n");
        goto out;
    }
    event_id_info->tile_num = (uint32_t)cJSON_GetNumberValue(tmp_obj);

    tmp_obj = cJSON_GetObjectItemCaseSensitive(event_id_mapping_obj, EVENT_ID_MAP_PROC_TILE_NUM_STR);
    if (tmp_obj == NULL) {
        SX_LOG_NTC("tile proc number get from JSON failed\n");
        goto out;
    }
    event_id_info->proc_tile_num = (uint32_t)cJSON_GetNumberValue(tmp_obj);

    tmp_obj = cJSON_GetObjectItemCaseSensitive(event_id_mapping_obj, EVENT_ID_MAP_PROC_MAIN_NUM_STR);
    if (tmp_obj == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("main proc number get from JSON failed\n");
        goto out;
    }
    event_id_info->proc_main_num = (uint32_t)cJSON_GetNumberValue(tmp_obj);

    tmp_obj = cJSON_GetObjectItemCaseSensitive(event_id_mapping_obj, EVENT_ID_MAP_MAIN_FIRST_EVENT_ID_STR);
    if (tmp_obj == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("main first_event_id get from JSON failed\n");
        goto out;
    }
    event_id_info->main_first_event_id = (uint32_t)cJSON_GetNumberValue(tmp_obj);

    tmp_obj = cJSON_GetObjectItemCaseSensitive(event_id_mapping_obj, EVENT_ID_MAP_PHY_MC_STR);
    if (tmp_obj == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("is phy mc supported get from JSON failed\n");
        goto out;
    }
    event_id_info->phy_mc_supported = (uint32_t)cJSON_GetNumberValue(tmp_obj);

    tile_first_event_id_arr_obj = cJSON_GetObjectItemCaseSensitive(event_id_mapping_obj,
                                                                   EVENT_ID_MAP_TILE_FIRST_EVENT_ID_ARR_STR);
    if (tile_first_event_id_arr_obj == NULL) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("tile first_event_id arr get from JSON failed\n");
        goto out;
    }
    i = 0;
    cJSON_ArrayForEach(tmp_obj, tile_first_event_id_arr_obj) {
        event_id_info->tile_first_event_id[i] = (uint32_t)cJSON_GetNumberValue(tmp_obj);
        i++;
    }
    if (i != event_id_info->tile_num) {
        sxd_status = SXD_STATUS_ERROR;
        SX_LOG_NTC("tile first_event_id arr in JSON file length is %d but number of tiles is %d \n",
                   i,
                   event_id_info->tile_num);
        goto out;
    }

out:
    if (buffer) {
        cl_free(buffer);
    }
    if (json_obj != NULL) {
        cJSON_Delete(json_obj);
    }
    return sxd_status;
}

void sxd_fw_trace_db_init_string_db(void)
{
    uint32_t i;

    for (i = 0; i < SXD_MTRC_CAP_STRING_DB_PARAM_NUM; i++) {
        fw_trace_db.string_db.string_db_section_arr[i].section_ptr = NULL;
        fw_trace_db.string_db.string_db_section_arr[i].raw_section_ptr = NULL;
    }
    return;
}

void sxd_fw_trace_db_free_raw_string_db(void)
{
    uint32_t i;

    for (i = 0; i < fw_trace_db.string_db.string_db_sections_num; i++) {
        if (fw_trace_db.string_db.string_db_section_arr[i].raw_section_ptr != NULL) {
            cl_free(fw_trace_db.string_db.string_db_section_arr[i].raw_section_ptr);
        }
    }
    return;
}


void sxd_fw_trace_db_free_string_db(void)
{
    uint32_t i;

    for (i = 0; i < fw_trace_db.string_db.string_db_sections_num; i++) {
        if (fw_trace_db.string_db.string_db_section_arr[i].section_ptr != NULL) {
            cl_free(fw_trace_db.string_db.string_db_section_arr[i].section_ptr);
        }
    }
    return;
}

boolean_t sxd_fw_trace_db_get_msg_str(uint32_t str_ptr, char* str, FILE *stream)
{
    boolean_t found = FALSE;
    uint32_t  i = 0;
    char    * string_p = NULL;
    uint32_t  offset = 0;
    uint32_t  string_len;

    /*
     * There are maximum 8 string db sections.
     * Each sections stores the FW trace strings templates( with %d, %x, %llx).
     * Each section belongs to different image ( Main, Tile, Iron..).
     * SDK reads the String.db sections from the ASIC flash and store each section in the string_db DB in a char buffer.
     * Each section has a virtual base address, size and data.
     * For every FW trace message, the first event (in tracer LSB) stores the message virtual string pointer.
     * This pointer should be in the virtual address range of one of the sections, and points to the message string template.
     * We can look at the section base address as kind of a section ID.
     */
    for (i = 0; i < fw_trace_db.string_db.string_db_sections_num; i++) {
        if ((str_ptr >= fw_trace_db.string_db.string_db_section_arr[i].section_start_base_addr) &&
            (str_ptr < (fw_trace_db.string_db.string_db_section_arr[i].section_start_base_addr +
                        fw_trace_db.string_db.string_db_section_arr[i].section_size))) {
            offset = str_ptr - fw_trace_db.string_db.string_db_section_arr[i].section_start_base_addr;
            string_p = (char*)(fw_trace_db.string_db.string_db_section_arr[i].section_ptr + offset);
            string_len = strlen(string_p);
            if (string_len >= FW_TRACE_STRING_SIZE) {
                /* We should never get here as today the longest FW_LOG message is about 128 Bytes. */
                dbg_utils_print(stream, " >> Parsing Error: string size %d is too long. max size: %d\n",
                                string_len, FW_TRACE_STRING_SIZE - 1);
                goto out;
            }
            if (string_len == 0) {
                dbg_utils_print(stream, " >> Parsing Error: string size is %d \n", string_len);
                goto out;
            }
            strncpy(str, string_p, FW_TRACE_STRING_SIZE - 1);
            found = TRUE;
            break;
        }
    }

out:
    return found;
}


boolean_t sxd_fw_trace_db_add_new_msg(sxd_fw_trace_event_t *trc_event_p, char* str, FILE *stream)
{
    boolean_t msg_ready = FALSE;
    uint32_t  event_id = trc_event_p->event_id;

    if (fw_trace_db.event_id_msg_db_arr[event_id].msg_valid) {
        dbg_utils_print(stream, " >> Parsing Error event_id %d: gathering message for msn %d string %s,"
                        " but new message with msn %d with string pointer ( dwsn= 0), string %s is coming."
                        " Clear current msn %d and start collecting info for msn %d\n",
                        event_id,
                        fw_trace_db.event_id_msg_db_arr[event_id].trc_event.msn,
                        fw_trace_db.event_id_msg_db_arr[event_id].str,
                        trc_event_p->msn,
                        str,
                        fw_trace_db.event_id_msg_db_arr[event_id].trc_event.msn,
                        trc_event_p->msn);
    }
    sxd_fw_trace_db_clear_msg(event_id);
    fw_trace_db.event_id_msg_db_arr[event_id].string_args_num = __sxd_fw_trace_db_get_num_of_params(str);
    strncpy(fw_trace_db.event_id_msg_db_arr[event_id].str, str, FW_TRACE_STRING_SIZE);
    memcpy(&(fw_trace_db.event_id_msg_db_arr[event_id].trc_event), trc_event_p, sizeof(*trc_event_p));
    fw_trace_db.event_id_msg_db_arr[event_id].msg_valid = TRUE;

    if (fw_trace_db.event_id_msg_db_arr[event_id].string_args_num == 0) {
        msg_ready = TRUE;
    }

    return msg_ready;
}


boolean_t sxd_fw_trace_db_add_event_to_msg(sxd_fw_trace_event_t *trc_event_p, FILE* stream)
{
    boolean_t msg_ready = FALSE;
    uint32_t  event_id = trc_event_p->event_id;
    uint32_t  arg_index = 0;

    if (fw_trace_db.event_id_msg_db_arr[event_id].msg_valid == FALSE) {
        dbg_utils_print(stream,
                        " >> Parsing Error event_id %d: msn %d, dwsn %d , without a string pointer (dwsn = 0), event argument [%d]\n",
                        event_id,
                        trc_event_p->msn,
                        trc_event_p->dwsn,
                        trc_event_p->tracer_lsb);
        goto out;
    }
    if (trc_event_p->msn != fw_trace_db.event_id_msg_db_arr[event_id].trc_event.msn) {
        dbg_utils_print(stream,
                        " >> Parsing Error event_id %d: send msn %d with string %s and msn %d with dwsn %d at the same time. Clear message..\n",
                        event_id,
                        fw_trace_db.event_id_msg_db_arr[event_id].trc_event.msn,
                        fw_trace_db.event_id_msg_db_arr[event_id].str,
                        trc_event_p->msn,
                        trc_event_p->dwsn);
        sxd_fw_trace_db_clear_msg(event_id);
        goto out;
    }

    arg_index = fw_trace_db.event_id_msg_db_arr[event_id].found_args_num;
    fw_trace_db.event_id_msg_db_arr[event_id].args_arr[arg_index] = trc_event_p->tracer_lsb;

    fw_trace_db.event_id_msg_db_arr[event_id].found_args_num++;

    if (fw_trace_db.event_id_msg_db_arr[event_id].found_args_num ==
        fw_trace_db.event_id_msg_db_arr[event_id].string_args_num) {
        msg_ready = TRUE;
    }

out:
    return msg_ready;
}


void sxd_fw_trace_db_clear_msg(uint32_t event_id)
{
    memset(&(fw_trace_db.event_id_msg_db_arr[event_id].trc_event), 0, sizeof(sxd_fw_trace_event_t));
    memset(fw_trace_db.event_id_msg_db_arr[event_id].args_arr, 0, (FW_TRACE_MAX_MESSAGE_ARGS_NUM * sizeof(uint32_t)));
    fw_trace_db.event_id_msg_db_arr[event_id].string_args_num = 0;
    fw_trace_db.event_id_msg_db_arr[event_id].found_args_num = 0;
    fw_trace_db.event_id_msg_db_arr[event_id].msg_valid = FALSE;
    strncpy(fw_trace_db.event_id_msg_db_arr[event_id].str, "", FW_TRACE_STRING_SIZE);
}

static uint32_t __sxd_fw_trace_db_get_num_of_params(char *str)
{
    char *substr, *pstr = str;
    int   num_of_params = 0;

    /* replace %llx with %x%x */
    substr = strstr(pstr, VAL_PARM);
    while (substr) {
        memcpy(substr, REPLACE_64_VAL_PARM, 4);
        pstr = substr;
        substr = strstr(pstr, VAL_PARM);
    }

    /* count all the % characters */
    substr = strstr(str, PARAM_CHAR);
    while (substr) {
        num_of_params += 1;
        str = substr + 1;
        substr = strstr(str, PARAM_CHAR);
    }

    return num_of_params;
}
