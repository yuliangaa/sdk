/*
 * Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */
#include "sxd_fw_trace_int.h"
#include <stdio.h>
#include <sys/types.h>
#include <stdint.h>
#include <endian.h>
#include <unistd.h>
#include <errno.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/kernel_user.h>
#include "../common/sxd_utils.h"
#include <complib/cl_map.h>
#include <complib/cl_mem.h>
#include <complib/cl_fleximap.h>
#include <complib/cl_fcntl.h>
#include <complib/cl_byteswap.h>
#include <complib/cl_math.h>
#include <sx/utils/dbg_utils.h>
#include <sx/sxd/sxd_fw_trace.h>
#include <sx/sxd/sxd_dpt.h>
#undef  __MODULE__
#define __MODULE__ SXD_FW_TRACE


/* to do - support multiple device */
/************************************************
 *  Local variables
 ***********************************************/
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local Defines
 ***********************************************/
#define FW_TRACE_EVENT_SIZE_IN_BYTES             8
#define EVENT_ID_PREFIX_LEN                      40
#define  JSON_FILE_FULL_PATH_NAME_LEN            (SDK_FOLDER_PATH_LEN + 128)
#define UINT64_IN_PAGE                           (PAGE_SIZE / EVENT_SIZE_IN_BYTES)
#define MLX_TRACE_OFFSET_IN_ALLOC_MAP_FA_PAGES   5
#define MLX_TRACE_FIRST_CHUNK_SIZE               512
#define MLX_TRACE_FIRST_CHUNK_MAX_TRACE_PAGE_NUM (MLX_TRACE_FIRST_CHUNK_SIZE - MLX_TRACE_OFFSET_IN_ALLOC_MAP_FA_PAGES)

typedef enum sxd_fw_trace_event_id_source {
    SXD_FW_TRACE_EVENT_TYPE_NONE_E,
    SXD_FW_TRACE_EVENT_TYPE_MAIN_E,
    SXD_FW_TRACE_EVENT_TYPE_TILE_E,
    SXD_FW_TRACE_EVENT_TYPE_PHY_MC_MAIN_E,
    SXD_FW_TRACE_EVENT_TYPE_PHY_MC_TILE_E
} sxd_fw_trace_event_id_source_e;

typedef enum {
    SXD_FW_TRACE_FIFO_MODE_E,
    SXD_FW_TRACE_MEM_MODE
} fw_trace_mem_mode_e;

typedef struct fw_fw_trace_event_id_info {
    sxd_fw_trace_event_id_source_e event_source;
    uint32_t                       tile_num;
    uint32_t                       ir_num;
} sxd_fw_trace_event_id_info_t;


/************************************************
 *  Global variables
 ***********************************************/
/************************************************
 *  Local function declarations
 ***********************************************/
static sxd_status_t __sxd_fw_trace_read_mlx_trace_buf_from_host_memory(sxd_dev_id_t dev_id,
                                                                       uint64_t    *mlx_trace_buffer,
                                                                       uint32_t     mlx_buf_pg_num);

static void __sxd_fw_trace_get_event_id_prefix(char                        * event_id_prefix,
                                               uint32_t                      event_id,
                                               sxd_fw_trace_event_id_info_t *sxd_fw_trace_event_id_map_p);

static void __sxd_fw_trace_print_msg(const sxd_fw_trace_event_id_msg_t *msg,
                                     FILE                              *stream,
                                     sxd_fw_trace_event_id_info_t      *sxd_fw_trace_event_id_map_p);

static void __sxd_fw_trace_print_msg_and_clean(uint32_t                      event_id,
                                               FILE                         *stream,
                                               sxd_fw_trace_event_id_info_t *sxd_fw_trace_event_id_map_p);

static sxd_status_t __sxd_fw_trace_parse_and_print(FILE                       *stream,
                                                   uint64_t                   *mlx_trace_buffer,
                                                   sxd_fw_trace_event_id_map_t event_id_info,
                                                   uint32_t                    host_mem_pages_num,
                                                   uint32_t                    event_id_num,
                                                   uint32_t                    first_fw_event_id,
                                                   boolean_t                   is_dwsn_msb_supported,
                                                   sxd_chip_types_t            chip_type);


static boolean_t __sxd_fw_trace_parse_event(uint64_t              raw_event,
                                            sxd_fw_trace_event_t *event_data_p,
                                            uint32_t              first_fw_event_id,
                                            uint32_t              event_id_num,
                                            boolean_t             is_dwsn_msb_supported,
                                            sxd_chip_types_t      chip_type,
                                            FILE                 *stream);

static sxd_status_t __sxd_fw_trace_get_dev_info(sxd_dev_id_t dev_id, sxd_chip_types_t *chip_type_p,
                                                char* fw_ver_str, char* sdk_folder_path_str);

static sxd_status_t __sxd_fw_trace_dev_info_set(sxd_dev_id_t dev_id, char* sdk_folder_path_str);
sxd_status_t __sxd_fw_trace_generate_json_files(sxd_dev_id_t      dev_id,
                                                boolean_t         write_to_file,
                                                char             *fw_version_str,
                                                sxd_chip_types_t *chip_type_p,
                                                FILE            **string_db_file_stream,
                                                FILE            **fw_trace_init_attr_file_stream);

static sxd_status_t __sxd_fw_trace_build_event_id_mapping(sxd_fw_trace_event_id_info_t *sxd_fw_trace_event_id_map_p,
                                                          sxd_fw_trace_event_id_map_t  *event_id_mapping,
                                                          uint32_t                      event_id_num);
/************************************************
 *  Function implementations
 ***********************************************/
sxd_status_t sxd_fw_trace_sdk_folder_path_set(char *sdk_path_name)
{
    if (sdk_path_name != NULL) {
        sxd_fw_trace_db_sdk_folder_path_set(sdk_path_name);
    }
    return SXD_STATUS_SUCCESS;
}

void sxd_fw_trace_sdk_folder_path_get(char *sdk_path_name)
{
    sxd_fw_trace_db_sdk_folder_path_get(sdk_path_name);
    return;
}


sxd_status_t sxd_fw_trace_store_sdk_path_in_driver(sxd_dev_id_t dev_id)
{
    sxd_status_t st = SXD_STATUS_SUCCESS;
    char         sdk_path_name[SDK_FOLDER_PATH_LEN] = {'\0'};

    /* store sdk_folder_path in driver*/
    sxd_fw_trace_db_sdk_folder_path_get(sdk_path_name);
    if (sdk_path_name[0] != '\0') {
        st = __sxd_fw_trace_dev_info_set(dev_id, sdk_path_name);
        if (SXD_CHECK_FAIL(st)) {
            SX_LOG_ERR("Failed to store SDK folder path in dev_info \n");
        }
    } else {
        SX_LOG_NTC("SDK folder path does not exist, can't initialize FW trace.\n");
        st = SXD_STATUS_ERROR;
    }

    return st;
}

/* We don't fail in SDK init because of error in the FW trace init*/
sxd_status_t sxd_fw_trace_init(sxd_dev_id_t dev_id, char *sdk_path_name)
{
    sxd_status_t                st = SXD_STATUS_SUCCESS;
    struct ku_mtrc_cap_reg      mtrc_cap_data;
    struct ku_mteim_reg         mteim_data;
    sxd_reg_meta_t              mtrc_meta;
    sxd_swid_t                  swid = 0;
    sxd_chip_types_t            chip_type = SXD_CHIP_TYPE_UNKNOWN;
    uint32_t                    i;
    sxd_fw_trace_event_id_map_t event_id_map_info;
    uint32_t                    mlx_buf_pg_num = 0;
    uint32_t                    events_id_num;
    uint32_t                    first_fw_event_id;
    boolean_t                   is_dwsn_msb_supported;
    FILE                       *string_db_file_stream = NULL;
    FILE                       *fw_trace_init_attr_file_stream = NULL;
    char                        fw_version_str[FW_VERSION_EXTENDED_STR_LEN] = {'\0'};

    memset(&mtrc_cap_data, 0, sizeof(mtrc_cap_data));
    memset(&mteim_data, 0, sizeof(mteim_data));
    memset(&mtrc_meta, 0, sizeof(mtrc_meta));
    memset(&event_id_map_info, 0, sizeof(event_id_map_info));

    /* On IB devices this function is called by the user via sxd API. In that case,
     * the user will provide the folder path when this function is called (vs via sdk init API). */
    if (sdk_path_name != NULL) {
        sxd_fw_trace_sdk_folder_path_set(sdk_path_name);
    }

    if (!SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        SX_LOG_ERR("SXD: Bad parameter on device-ready event\n");
        return SXD_STATUS_PARAM_ERROR;
    }

    st = sxd_fw_trace_store_sdk_path_in_driver(dev_id);
    if (SXD_CHECK_FAIL(st)) {
        st = SXD_STATUS_SUCCESS;
        goto out;
    }

    mtrc_meta.dev_id = dev_id;
    mtrc_meta.swid = swid;
    mtrc_meta.access_cmd = SXD_ACCESS_CMD_GET;

    /*MTRC_CAP*/
    st = sxd_access_reg_mtrc_cap(&mtrc_cap_data, &mtrc_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(st)) {
        st = SXD_STATUS_SUCCESS;
        goto out;
    }

    if (mtrc_cap_data.trace_to_memory != SXD_FW_TRACE_MEM_MODE) {
        SX_LOG_NTC("FW tracer mode is not MEM mode, Cannot Generate FW trace.\n");
        return SXD_STATUS_SUCCESS;
    }

    if (mtrc_cap_data.num_string_db > SXD_MTRC_CAP_STRING_DB_PARAM_NUM) {
        SX_LOG_ERR("invalid strings sections size. max valid size is : [%d]\n", SXD_MTRC_CAP_STRING_DB_PARAM_NUM);
        return SXD_STATUS_SUCCESS;
    }
    mlx_buf_pg_num = 1 << mtrc_cap_data.log_max_trace_buffer_size;
    first_fw_event_id = mtrc_cap_data.first_string_trace;
    events_id_num = mtrc_cap_data.num_string_trace;

    /* MTEIM*/
    st = sxd_access_reg_mteim(&mteim_data, &mtrc_meta, 1, NULL, NULL);
    if (SXD_CHECK_FAIL(st)) {
        st = SXD_STATUS_SUCCESS;
        goto out;
    }

    is_dwsn_msb_supported = mteim_data.is_dwsn_msb_supported;

    event_id_map_info.proc_main_num = mteim_data.cap_core_main;
    event_id_map_info.proc_tile_num = mteim_data.cap_core_tile;

    event_id_map_info.main_first_event_id = mteim_data.first_main_core_event_id;
    event_id_map_info.tile_num = mteim_data.cap_num_of_tile;

    for (i = 0; i < event_id_map_info.tile_num; i++) {
        event_id_map_info.tile_first_event_id[i] = mteim_data.first_tile_core_event_id[i];
    }
    event_id_map_info.phy_mc_supported = mteim_data.is_phy_uc_supported;

    sxd_fw_trace_db_init_string_db();
    /* Call MTRC_STDB and fill the string_db and FW tracer attributes in files in sdk_sys_info folder*/
    st = sxd_fw_trace_db_extract_string_db_sections(dev_id,
                                                    mtrc_cap_data.string_db_param,
                                                    mtrc_cap_data.num_string_db);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("Failed to extract string.db from Flash, err: [%d, %s]\n", st, SXD_STATUS_MSG(st));
        st = SXD_STATUS_SUCCESS;
        goto out;
    }

    st = __sxd_fw_trace_generate_json_files(dev_id,
                                            TRUE,
                                            fw_version_str,
                                            &chip_type,
                                            &string_db_file_stream,
                                            &fw_trace_init_attr_file_stream);
    if (SXD_CHECK_FAIL(st)) {
        st = SXD_STATUS_SUCCESS;
        goto out;
    }


    st = sxd_fw_trace_db_store_fw_trace_string_db_in_json_file(string_db_file_stream, fw_version_str);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("Failed to store FW trace string db in a file, err: [%d, %s]\n", st, SXD_STATUS_MSG(st));
        st = SXD_STATUS_SUCCESS;
        goto out;
    }

    st = sxd_fw_trace_db_store_fw_trace_init_attr_in_json_file(&event_id_map_info,
                                                               mlx_buf_pg_num,
                                                               events_id_num,
                                                               first_fw_event_id,
                                                               is_dwsn_msb_supported,
                                                               fw_trace_init_attr_file_stream);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("Failed to store the FW trace init parameters in a file, err: [%d, %s]\n", st, SXD_STATUS_MSG(st));
        st = SXD_STATUS_SUCCESS;
        goto out;
    }


out:
    sxd_fw_trace_db_free_raw_string_db();

    if (fw_trace_init_attr_file_stream != NULL) {
        fclose(fw_trace_init_attr_file_stream);
    }

    if (string_db_file_stream != NULL) {
        fclose(string_db_file_stream);
    }
    return st;
}

sxd_status_t sxd_fw_trace_extract(sxd_dev_id_t dev_id, FILE *stream)
{
    sxd_status_t                st = SXD_STATUS_SUCCESS;
    uint32_t                    mlx_buf_pg_num = 0;
    uint32_t                    events_id_num;
    uint32_t                    first_fw_event_id;
    boolean_t                   is_dwsn_msb_supported;
    uint64_t                   *mlx_trace_buffer = NULL;
    sxd_chip_types_t            chip_type = SXD_CHIP_TYPE_UNKNOWN;
    sxd_fw_trace_event_id_map_t event_id_info;
    FILE                       *string_db_file_stream = NULL;
    FILE                       *fw_trace_init_attr_file_stream = NULL;
    char                        fw_version_str[FW_VERSION_EXTENDED_STR_LEN] = {'\0'};
    char                        fw_version_str_from_string_db[FW_VERSION_EXTENDED_STR_LEN] = {'\0'};

    sxd_fw_trace_db_init_string_db();

    st = __sxd_fw_trace_generate_json_files(dev_id,
                                            FALSE,
                                            fw_version_str,
                                            &chip_type,
                                            &string_db_file_stream,
                                            &fw_trace_init_attr_file_stream);
    if (SXD_CHECK_FAIL(st)) {
        goto out;
    }

    if ((string_db_file_stream == NULL) || (fw_trace_init_attr_file_stream == NULL)) {
        SX_LOG_NTC("Failed to open JSON files to restore string.db and FW trace attributes, return\n");
        st = SXD_STATUS_ERROR;
        goto out;
    }

    st =
        sxd_fw_trace_db_restore_fw_trace_string_db_from_json_file(string_db_file_stream,
                                                                  fw_version_str_from_string_db);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("Failed to restore FW trace string db from JSON file, err: [%d, %s]\n", st, SXD_STATUS_MSG(st));
        goto out;
    }

    if (strncmp(fw_version_str_from_string_db, fw_version_str, FW_VERSION_EXTENDED_STR_LEN) != 0) {
        SX_LOG_ERR("Failed to restore FW trace string db."
                   " the FW version in string.db file [%s] is differ from the FW version installed [%s]",
                   fw_version_str_from_string_db, fw_version_str);

        goto out;
    }


    st = sxd_fw_trace_db_restore_fw_trace_init_attr_from_json_file(&event_id_info,
                                                                   &mlx_buf_pg_num,
                                                                   &events_id_num,
                                                                   &first_fw_event_id,
                                                                   &is_dwsn_msb_supported,
                                                                   fw_trace_init_attr_file_stream);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("Failed to restore FW trace init attributes from JSON file, err: [%d, %s]\n", st,
                   SXD_STATUS_MSG(st));
        goto out;
    }

    mlx_trace_buffer =
        (uint64_t*)cl_malloc((mlx_buf_pg_num * UINT64_IN_PAGE) * sizeof(uint64_t));
    if (mlx_trace_buffer == NULL) {
        st = SXD_STATUS_NO_MEMORY;
        goto out;
    }

    memset(mlx_trace_buffer, 0, (mlx_buf_pg_num * UINT64_IN_PAGE) * sizeof(uint64_t));

    /* Read the 2M MLX tracer cyclic buffer in host memory (take a snapshot)
     * MLX tracer buffer contains events from the HW tracer, FW tracer, PHY tracer and PHY uc.*/
    st = __sxd_fw_trace_read_mlx_trace_buf_from_host_memory(dev_id, mlx_trace_buffer, mlx_buf_pg_num);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("Failed to copy MLX trace buff from host memory, err: [%d, %s]\n", st, SXD_STATUS_MSG(st));
        goto out;
    }

    /* Read the MLX tracer buffer event by event and parse the FW tracer events.
     * Collect the arguments for each event_id message and print the complete message to the stream
     */
    st = __sxd_fw_trace_parse_and_print(stream,
                                        mlx_trace_buffer,
                                        event_id_info,
                                        mlx_buf_pg_num,
                                        events_id_num,
                                        first_fw_event_id,
                                        is_dwsn_msb_supported,
                                        chip_type);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("Failed parse and print FW trace, err: [%d, %s]\n", st, SXD_STATUS_MSG(st));
        goto out;
    }

out:
    if (fw_trace_init_attr_file_stream != NULL) {
        fclose(fw_trace_init_attr_file_stream);
    }

    if (string_db_file_stream != NULL) {
        fclose(string_db_file_stream);
    }

    sxd_fw_trace_db_free_string_db();

    if (mlx_trace_buffer != NULL) {
        cl_free(mlx_trace_buffer);
    }

    return st;
}

static sxd_status_t __sxd_fw_trace_read_mlx_trace_buf_from_host_memory(sxd_dev_id_t dev_id,
                                                                       uint64_t    *mlx_trace_buffer,
                                                                       uint32_t     mlx_buf_pg_num)
{
    sxd_status_t                 st = SXD_STATUS_SUCCESS;
    struct ku_host_mem_read_page host_mem_pg;
    uint32_t                     pg_inx;

    host_mem_pg.dev_id = dev_id;
    if (mlx_trace_buffer == NULL) {
        SX_LOG_ERR("MLX trace buffer is NULL\n");
        st = SXD_STATUS_ERROR;
        goto out;
    }
    /* 1 chunk allocated. The chunk has mem[] array that points to arrays of pages allocated by the host memory.
     * The 2M MLX trace buffer takes by default 512 pages from that allocated memory.
     * This function ignorant to the MLX trace pages allocation layout.
     */
    for (pg_inx = 0; pg_inx < mlx_buf_pg_num; pg_inx++) {
        host_mem_pg.page_index = pg_inx;
        st = sxd_host_mem_page_get(&host_mem_pg);
        if (SXD_CHECK_FAIL(st)) {
            SX_LOG_ERR("Failed to read MLX buffer page index [%d] from host memory, for device id [%u]\n",
                       pg_inx,
                       dev_id);
            goto out;
        }

        memcpy(&mlx_trace_buffer[(pg_inx * UINT64_IN_PAGE)], host_mem_pg.pg_data_arr, PAGE_SIZE);
    }

out:
    return st;
}


sxd_status_t sxd_fw_trace_log_verbosity_level(sxd_access_cmd_t cmd, sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t st = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Get an unsupported access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        st = SXD_STATUS_CMD_UNSUPPORTED;
        break;
    }

    return st;
}

sxd_status_t __sxd_fw_trace_generate_json_files(sxd_dev_id_t      dev_id,
                                                boolean_t         write_to_file,
                                                char             *fw_version_str,
                                                sxd_chip_types_t *chip_type_p,
                                                FILE            **string_db_file_stream,
                                                FILE            **fw_trace_init_attr_file_stream)
{
    sxd_status_t st = SXD_STATUS_SUCCESS;
    char         sdk_folder_path_name[SDK_FOLDER_PATH_LEN] = {'\0'};
    char         string_db_file_path[JSON_FILE_FULL_PATH_NAME_LEN] = {'\0'};
    char         fw_trace_init_attr_file_path[JSON_FILE_FULL_PATH_NAME_LEN] = {'\0'};


    st = __sxd_fw_trace_get_dev_info(dev_id, chip_type_p, fw_version_str, sdk_folder_path_name);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("Failed to get chip type \n");
        goto out;
    }

    if (*chip_type_p > SXD_CHIP_TYPES_MAX) {
        SX_LOG_ERR("chip unknown and  not supported : [%d]\n", *chip_type_p);
        st = SXD_STATUS_ERROR;
        goto out;
    }

    if (sdk_folder_path_name[0] == '\0') {
        SX_LOG_ERR("SDK_sys info dir is empty, cannot find string.db and FW trace attributes files. \n");
        st = SXD_STATUS_ERROR;
        goto out;
    }
    sprintf(string_db_file_path,
            "%s/fw_trace_string_db.json",
            sdk_folder_path_name);
    if (write_to_file == TRUE) {
        *string_db_file_stream = fopen(string_db_file_path, "w");
        if (*string_db_file_stream == NULL) {
            SX_LOG_ERR("Error while opening fw_trace_string_db file for writing, fopen(%s, 'w') returned NULL \n",
                       string_db_file_path);
            st = SXD_STATUS_ERROR;
            goto out;
        }
    } else {
        *string_db_file_stream = fopen(string_db_file_path, "r");
        if (*string_db_file_stream == NULL) {
            SX_LOG_NTC("Error while opening fw_trace_string_db file [%s] for reading."
                       " File does not exist, FW trace mode should be MEM mode. \n"
                       , string_db_file_path);
            st = SXD_STATUS_ERROR;
            /*Try to open the attribute file. */
        }
    }

    sprintf(fw_trace_init_attr_file_path,
            "%s/fw_trace_attr.json",
            sdk_folder_path_name);
    if (write_to_file == TRUE) {
        *fw_trace_init_attr_file_stream = fopen(fw_trace_init_attr_file_path, "w");
        if (*fw_trace_init_attr_file_stream == NULL) {
            SX_LOG_ERR("Error while opening fw_trace_init_attr file for writing, fopen( %s, 'w') returned NULL\n",
                       fw_trace_init_attr_file_path);
            st = SXD_STATUS_ERROR;
            goto out;
        }
    } else {
        *fw_trace_init_attr_file_stream = fopen(fw_trace_init_attr_file_path, "r");
        if (*fw_trace_init_attr_file_stream == NULL) {
            SX_LOG_NTC("Error while opening fw_trace_attributes file [%s] for reading."
                       " File does not exist, FW trace mode should be MEM mode. \n"
                       , fw_trace_init_attr_file_path);
            st = SXD_STATUS_ERROR;
            goto out;
        }
    }

    if (write_to_file == TRUE) {
        SX_LOG_NTC("Writing string.db file to [%s] and attribute file to [%s].\n"
                   , string_db_file_path, fw_trace_init_attr_file_path);
    }
out:
    return st;
}


static sxd_status_t __sxd_fw_trace_build_event_id_mapping(sxd_fw_trace_event_id_info_t *sxd_fw_trace_event_id_map_p,
                                                          sxd_fw_trace_event_id_map_t  *event_id_mapping,
                                                          uint32_t                      event_id_num)
{
    sxd_status_t st = SXD_STATUS_SUCCESS;
    uint32_t     i, j;

    if (sxd_fw_trace_event_id_map_p == NULL) {
        SX_LOG_ERR("event_id_map is NULL\n");
        st = SXD_STATUS_ERROR;
        goto out;
    }

    if (event_id_mapping->proc_main_num > event_id_num) {
        SX_LOG_ERR("proc_main_num %d > event_id_num %d\n", event_id_mapping->proc_main_num, event_id_num);
        st = SXD_STATUS_ERROR;
        goto out;
    }

    if (event_id_mapping->tile_num > 0) {
        if ((event_id_mapping->proc_tile_num + event_id_mapping->tile_first_event_id[event_id_mapping->tile_num - 1]) >
            event_id_num) {
            SX_LOG_ERR("(proc_tile_num + tile_first_event_id[%d] > event_id_num. (%d + %d) > %d\n",
                       (event_id_mapping->tile_num - 1),
                       event_id_mapping->proc_tile_num,
                       event_id_mapping->tile_first_event_id[event_id_mapping->tile_num - 1],
                       event_id_num);

            st = SXD_STATUS_ERROR;
            goto out;
        }
    }

    for (i = 0; i < event_id_num; i++) {
        sxd_fw_trace_event_id_map_p[i].event_source = SXD_FW_TRACE_EVENT_TYPE_NONE_E;
    }
    /*sxd_fw_trace_event_id_map_p[] index is the event_id. the content is the source and the matching IRISC in FW. */
    /*set the MAIN event_ids mapping */
    for (i = event_id_mapping->main_first_event_id; i < event_id_mapping->proc_main_num; i++) {
        sxd_fw_trace_event_id_map_p[i].event_source = SXD_FW_TRACE_EVENT_TYPE_MAIN_E;
        sxd_fw_trace_event_id_map_p[i].ir_num = i - event_id_mapping->main_first_event_id;
    }

    /* if there are tiles, add the tiles mapping */
    for (i = 0; i < event_id_mapping->tile_num; i++) {
        for (j = event_id_mapping->tile_first_event_id[i];
             j < (event_id_mapping->proc_tile_num + event_id_mapping->tile_first_event_id[i]);
             j++) {
            sxd_fw_trace_event_id_map_p[j].event_source = SXD_FW_TRACE_EVENT_TYPE_TILE_E;
            sxd_fw_trace_event_id_map_p[j].ir_num = j - event_id_mapping->tile_first_event_id[i];
            sxd_fw_trace_event_id_map_p[j].tile_num = i;
        }
    }

    if (event_id_mapping->phy_mc_supported) { /*In SPC4 the PHY mc trace events are at the end of each tile events */
        j = event_id_mapping->main_first_event_id + event_id_mapping->proc_main_num;
        sxd_fw_trace_event_id_map_p[j].event_source = SXD_FW_TRACE_EVENT_TYPE_PHY_MC_MAIN_E;

        for (i = 0; i < event_id_mapping->tile_num; i++) {
            j = event_id_mapping->tile_first_event_id[i] + event_id_mapping->proc_tile_num;
            sxd_fw_trace_event_id_map_p[j].event_source = SXD_FW_TRACE_EVENT_TYPE_PHY_MC_TILE_E;
            sxd_fw_trace_event_id_map_p[j].tile_num = i;
        }
    }
out:
    return st;
}

static sxd_status_t __sxd_fw_trace_dev_info_set(sxd_dev_id_t dev_id, char* sdk_folder_path_str)
{
    sxd_status_t       st = SXD_STATUS_SUCCESS;
    struct ku_dev_info dev_info;

    if (sdk_folder_path_str == NULL) {
        st = SXD_STATUS_ERROR;
        SX_LOG_ERR("__sxd_fw_trace_dev_info_set: sdk_folder_path is NULL for device id [%u]\n", dev_id);
        goto out;
    }

    memset(&dev_info, 0, sizeof(dev_info));
    dev_info.dev_id = dev_id;
    strncpy((char*)dev_info.dev_info.dev_info_set.sdk_folder_path, sdk_folder_path_str, SDK_FOLDER_PATH_LEN);

    st = sxd_set_device_info(&dev_info);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("Failed to retrieve chip_type for device id [%u]\n", dev_id);
        goto out;
    }

out:
    return st;
}

static sxd_status_t __sxd_fw_trace_get_dev_info(sxd_dev_id_t      dev_id,
                                                sxd_chip_types_t *chip_type_p,
                                                char            * fw_ver_str,
                                                char            * sdk_folder_path)
{
    sxd_status_t       st = SXD_STATUS_SUCCESS;
    struct ku_dev_info dev_info;
    char               fw_version_str[FW_VERSION_EXTENDED_STR_LEN] = {'\0'};

    if (chip_type_p == NULL) {
        st = SXD_STATUS_ERROR;
        SX_LOG_ERR("__sxd_fw_trace_get_dev_info: chip_type_p is NULL for device id [%u]\n", dev_id);
        goto out;
    }

    if (fw_ver_str == NULL) {
        st = SXD_STATUS_ERROR;
        SX_LOG_ERR("__sxd_fw_trace_get_dev_info: fw_ver_str is NULL for device id [%u]\n", dev_id);
        goto out;
    }

    if (sdk_folder_path == NULL) {
        st = SXD_STATUS_ERROR;
        SX_LOG_ERR("__sxd_fw_trace_get_dev_info: sdk_folder_path is NULL for device id [%u]\n", dev_id);
        goto out;
    }

    memset(&dev_info, 0, sizeof(dev_info));
    dev_info.dev_id = dev_id;

    st = sxd_get_device_info(&dev_info);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("__sxd_fw_trace_get_dev_info: Failed to retrieve chip_type for device id [%u]\n", dev_id);
        goto out;
    }

    *chip_type_p = dev_info.dev_info.dev_info_ro.chip_type;

    snprintf(fw_version_str,
             FW_VERSION_EXTENDED_STR_LEN,
             "%u_%u_%u",
             dev_info.dev_info.dev_info_ro.mgir.fw_info.extended_major,
             dev_info.dev_info.dev_info_ro.mgir.fw_info.extended_minor,
             dev_info.dev_info.dev_info_ro.mgir.fw_info.extended_sub_minor);
    fw_version_str[strlen(fw_version_str)] = '\0';
    strcpy(fw_ver_str, fw_version_str);

    strcpy(sdk_folder_path, (char*)dev_info.dev_info.dev_info_set.sdk_folder_path);

out:
    return st;
}

static boolean_t __sxd_fw_trace_parse_event(uint64_t              raw_event,
                                            sxd_fw_trace_event_t *event_data_p,
                                            uint32_t              first_fw_event_id,
                                            uint32_t              event_id_num,
                                            boolean_t             is_dwsn_msb_supported,
                                            sxd_chip_types_t      chip_type,
                                            FILE                 *stream)
{
    boolean_t fw_event = FALSE;
    uint32_t  tracer_msb_and_hw_data;
    uint64_t  event_vec;

    memset(event_data_p, 0, sizeof(*event_data_p));
    UNUSED_PARAM(stream);

    event_vec = cl_ntoh64(raw_event);

    tracer_msb_and_hw_data = (uint32_t)((event_vec >> 32) & 0x00000000FFFFFFFF);
    event_data_p->tracer_lsb = (uint32_t)(event_vec & 0x00000000FFFFFFFF);
    event_data_p->lost = ((tracer_msb_and_hw_data & 0x80000000) >> 31);
    event_data_p->timestamp = (tracer_msb_and_hw_data & 0x7F000000) >> 24;

    if ((chip_type == SXD_CHIP_TYPE_SPECTRUM) || (chip_type == SXD_CHIP_TYPE_SPECTRUM_A1)) {
        event_data_p->event_id = (tracer_msb_and_hw_data & 0x1E000) >> 13; /* In SPC1 the event id offset is 45, size 4 */
    } else {
        event_data_p->event_id = (tracer_msb_and_hw_data & 0xFF0000) >> 16; /* In SPC2 and above the event_id offset is 48, size 8 */
    }

    if ((event_data_p->event_id >= first_fw_event_id) &&
        (event_data_p->event_id < (first_fw_event_id + event_id_num))) {
        fw_event = TRUE;
    }

    if (fw_event == FALSE) {
        goto out;
    }
    if (first_fw_event_id > 0) {
        event_data_p->event_id -= first_fw_event_id; /* so the event_id index in the event_is message DB will start from 0 . */
    }
    event_data_p->msn = (tracer_msb_and_hw_data & 0x1FF8) >> 3;
    event_data_p->dwsn = tracer_msb_and_hw_data & 0x7;

    if (is_dwsn_msb_supported == TRUE) {
        uint8_t dwsn_msb = (tracer_msb_and_hw_data & 0x2000) >> 13;
        event_data_p->dwsn |= (dwsn_msb << 3);
    }
#ifdef PRINT_RAW
    dbg_utils_print(stream,
                    " Event_id: %d    EVENT 0x%x%x:   Msn: 0x%x  Dwsn: 0x%x  Data 0x%x, \n",
                    event_data_p->event_id,
                    tracer_msb_and_hw_data,
                    event_data_p->tracer_lsb,
                    event_data_p->msn,
                    event_data_p->dwsn,
                    event_data_p->tracer_lsb);
#endif
out:

    return fw_event;
}


static sxd_status_t __sxd_fw_trace_parse_and_print(FILE                       *stream,
                                                   uint64_t                   *mlx_trace_buffer,
                                                   sxd_fw_trace_event_id_map_t event_id_info,
                                                   uint32_t                    host_mem_pages_num,
                                                   uint32_t                    event_id_num,
                                                   uint32_t                    first_fw_event_id,
                                                   boolean_t                   is_dwsn_msb_supported,
                                                   sxd_chip_types_t            chip_type)
{
    sxd_status_t                  st = SXD_STATUS_SUCCESS;
    uint64_t                      next_event;
    uint32_t                      num_of_mlx_events;
    uint32_t                      event_index = 0;
    sxd_fw_trace_event_t          event_data;
    boolean_t                     is_fw_event = FALSE;
    boolean_t                     msg_ready = FALSE;
    boolean_t                     str_found = FALSE;
    char                          str[FW_TRACE_STRING_SIZE];
    sxd_fw_trace_event_id_msg_t  *event_msg_db_p = NULL;
    sxd_fw_trace_event_id_info_t *sxd_fw_trace_event_id_map_p = NULL;

    memset(&event_data, 0, sizeof(event_data));
    memset(str, 0, FW_TRACE_STRING_SIZE);

    /* Calculate events number in the MLX buffer*/
    num_of_mlx_events = (host_mem_pages_num * UINT64_IN_PAGE);

    /* Allocate the event_id messages DB according to the number of different FW event_id(s).
     * Each IRISC has event_id
     * Each event_id DB includes the first message event (each message builds from up to 16 events),
     * the matching template string from string.db and array to store the message arguments
     */
    if (event_id_info.phy_mc_supported == TRUE) {
        event_id_num++;
    }
    event_msg_db_p =
        (sxd_fw_trace_event_id_msg_t*)cl_malloc(event_id_num * sizeof(sxd_fw_trace_event_id_msg_t));
    if (event_msg_db_p == NULL) {
        st = SXD_STATUS_NO_MEMORY;
        goto out1;
    }
    memset(event_msg_db_p, 0, (event_id_num * sizeof(sxd_fw_trace_event_id_msg_t)));
    sxd_fw_trace_db_event_msg_db_set(event_msg_db_p);
    sxd_fw_trace_db_max_event_id_set(event_id_num);

    /*Build the event_id mapping to associate each event_id with MAIN/TILE and IRISC*/
    sxd_fw_trace_event_id_map_p =
        (sxd_fw_trace_event_id_info_t*)cl_malloc(event_id_num * sizeof(sxd_fw_trace_event_id_info_t));
    if (sxd_fw_trace_event_id_map_p == NULL) {
        st = SXD_STATUS_NO_MEMORY;
        goto out;
    }
    memset(sxd_fw_trace_event_id_map_p, 0, (event_id_num * sizeof(sxd_fw_trace_event_id_info_t)));

    st = __sxd_fw_trace_build_event_id_mapping(sxd_fw_trace_event_id_map_p, &event_id_info, event_id_num);
    if (SXD_CHECK_FAIL(st)) {
        SX_LOG_ERR("__sxd_fw_trace_parse_and_print: Failed to build event_id mapping\n");
    }

    for (event_index = 0; event_index < num_of_mlx_events; event_index++) {
        memcpy(&next_event, (mlx_trace_buffer + event_index),
               sizeof(uint64_t));

        is_fw_event = __sxd_fw_trace_parse_event(next_event,
                                                 &event_data,
                                                 first_fw_event_id,
                                                 event_id_num,
                                                 is_dwsn_msb_supported,
                                                 chip_type,
                                                 stream);
        if (!is_fw_event) {
            continue;
        }
        if (event_data.lost == TRUE) {
            dbg_utils_print(stream,
                            " >> Parsing Error: event_id %d, timestamp %d, msn %d, got message with lost = %d.\n",
                            event_data.event_id,
                            event_data.timestamp,
                            event_data.msn,
                            event_data.lost);
            continue;
        }

        if (event_data.event_id >= sxd_fw_trace_db_max_event_id_get()) {
            dbg_utils_print(stream,
                            " >> Parsing Error: event_id is larger than max value! event_id = (%u), max_event_id = (%u)\n",
                            event_data.event_id,
                            sxd_fw_trace_db_max_event_id_get());
            continue;
        }

        /* If it is the first message event, the event LSB stores the pointer to the string.db*/
        if (event_data.dwsn == 0) {
            /*MLX Buffer is filled with 0 at the beginning*/
            if ((event_data.tracer_lsb == 0) && (event_data.event_id == 0)) {
                continue;
            }
            str_found = sxd_fw_trace_db_get_msg_str(event_data.tracer_lsb, str, stream);
            if (str_found == FALSE) {
                dbg_utils_print(stream,
                                " >> Parsing Error: event_id %d, timestamp %d, msn %d, string pointer 0x%x:  couldn't find matching string.\n",
                                event_data.event_id,
                                event_data.timestamp,
                                event_data.msn,
                                event_data.tracer_lsb);
                continue;
            }
            /* check that there is no on-going parsing for the event id
             * and add the new message parameter to the event_id DB
             */
            msg_ready = sxd_fw_trace_db_add_new_msg(&event_data, str, stream);
        } else {
            msg_ready = sxd_fw_trace_db_add_event_to_msg(&event_data, stream);
        }
        /* If we found all the message arguments, print the completed message*/
        if (msg_ready) {
            __sxd_fw_trace_print_msg_and_clean(event_data.event_id, stream, sxd_fw_trace_event_id_map_p);
            msg_ready = FALSE;
        }
    }

out:
    if (sxd_fw_trace_event_id_map_p) {
        cl_free(sxd_fw_trace_event_id_map_p);
    }

out1:
    if (event_msg_db_p) {
        cl_free(event_msg_db_p);
    }

    return st;
}

static void __sxd_fw_trace_print_msg_and_clean(uint32_t                      event_id,
                                               FILE                         *stream,
                                               sxd_fw_trace_event_id_info_t *sxd_fw_trace_event_id_map_p)
{
    const sxd_fw_trace_event_id_msg_t *msg;

    /* Get the completed message from DB and print it to the stream*/
    msg = sxd_fw_trace_db_event_id_msg_db_get(event_id);
    __sxd_fw_trace_print_msg(msg, stream, sxd_fw_trace_event_id_map_p);
    sxd_fw_trace_db_clear_msg(event_id);

    return;
}


static void __sxd_fw_trace_print_msg(const sxd_fw_trace_event_id_msg_t *msg,
                                     FILE                              *stream,
                                     sxd_fw_trace_event_id_info_t      *sxd_fw_trace_event_id_map_p)
{
    char        event_id_prefix[EVENT_ID_PREFIX_LEN];
    char        msg_str[FW_TRACE_STRING_SIZE] = {'\0'};
    uint32_t    arg_index = 0, cn = 0; /*Character num */
    const char *tsp;
    char       *msp;

    tsp = msg->str;
    msp = &msg_str[0];

    while (*tsp != '\0') {
        if (*tsp != '%') {
            *msp = *tsp;
            msp++;
            tsp++;
        } else {
            tsp++; /* skip the "%" */
            if (*tsp == 'x') {
                cn = sprintf(msp, "%x", msg->args_arr[arg_index]);
            } else {
                cn = sprintf(msp, "%d", msg->args_arr[arg_index]);
            }
            arg_index++;
            tsp++;
            msp += cn;
        }
    }
    __sxd_fw_trace_get_event_id_prefix(event_id_prefix, msg->trc_event.event_id, sxd_fw_trace_event_id_map_p);

    dbg_utils_print(stream, "%-22s : [%4d] %s \n", event_id_prefix, msg->trc_event.timestamp, msg_str);
    return;
}


static void __sxd_fw_trace_get_event_id_prefix(char                        * event_id_prefix,
                                               uint32_t                      event_id,
                                               sxd_fw_trace_event_id_info_t *sxd_fw_trace_event_id_map_p)
{
    if (sxd_fw_trace_event_id_map_p[event_id].event_source == SXD_FW_TRACE_EVENT_TYPE_MAIN_E) {
        sprintf(event_id_prefix, "MAIN_IR_%d", sxd_fw_trace_event_id_map_p[event_id].ir_num);
    } else if (sxd_fw_trace_event_id_map_p[event_id].event_source == SXD_FW_TRACE_EVENT_TYPE_TILE_E) {
        sprintf(event_id_prefix, "TILE_%d_IR_%d", sxd_fw_trace_event_id_map_p[event_id].tile_num,
                sxd_fw_trace_event_id_map_p[event_id].ir_num);
    } else if (sxd_fw_trace_event_id_map_p[event_id].event_source == SXD_FW_TRACE_EVENT_TYPE_PHY_MC_MAIN_E) {
        sprintf(event_id_prefix, "MAIN_PHY_MC");
    } else if (sxd_fw_trace_event_id_map_p[event_id].event_source == SXD_FW_TRACE_EVENT_TYPE_PHY_MC_TILE_E) {
        sprintf(event_id_prefix, "TILE_%d_PHY_MC", sxd_fw_trace_event_id_map_p[event_id].tile_num);
    } else {
        /*We don't want to fail, just let the user know that the event_id is not supported. It might be PHY uc message.*/
        sprintf(event_id_prefix, "Unsupported event_id %d", event_id);
    }
    return;
}
