/*
 * Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef SXD_FW_TRACE_INIT_H_
#define SXD_FW_TRACE_INIT_H_


#include <sx/sxd/sxd_status.h>
#include "sx/sxd/sxdev.h"
#include <sx/sxd/kernel_user.h>
#include "sx/sxd/sxd_fw_trace.h"
#include <complib/sx_log.h>
#include <time.h>
#include <sys/time.h>
/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
#define FW_TRACE_MAX_MESSAGE_ARGS_NUM 15
#define FW_TRACE_STRING_SIZE          256
#define MAX_TILE_NUM                  8
#define SDK_FOLDER_PATH_LEN           128
#define FW_VERSION_EXTENDED_STR_LEN   (16)            /*extended_major+extended_minor+extended_sub_minor */

/*#define PRINT_RAW */
/*#define PRINT_STRING_DB_TIME */


typedef struct timeval timeval_t;
typedef struct sxd_fw_trace_event_id_map {
    uint32_t  tile_num;
    uint32_t  proc_tile_num;
    uint32_t  proc_main_num;
    uint32_t  main_first_event_id;
    uint32_t  tile_first_event_id[MAX_TILE_NUM];
    boolean_t phy_mc_supported;
} sxd_fw_trace_event_id_map_t;

typedef struct sxd_fw_trace_string_db_section {
    uint32_t  section_start_base_addr;
    uint32_t  section_size;
    uint32_t *raw_section_ptr;
    uint8_t  *section_ptr;
} sxd_fw_trace_string_db_section_t;

typedef struct sxd_fw_trace_string_db {
    uint32_t                         string_db_sections_num;
    sxd_fw_trace_string_db_section_t string_db_section_arr[SXD_MTRC_CAP_STRING_DB_PARAM_NUM];
} sxd_fw_trace_string_db_t;

/* event layout */
typedef struct sxd_fw_trace_event {
    boolean_t lost;
    uint8_t   timestamp;
    uint8_t   event_id;
    uint8_t   dwsn;
    uint32_t  msn;
    uint32_t  tracer_lsb;
} sxd_fw_trace_event_t;


typedef struct sxd_fw_trace_event_id_msg {
    sxd_fw_trace_event_t trc_event;   /*message first event */
    char                 str[FW_TRACE_STRING_SIZE + 1];
    uint32_t             string_args_num;
    uint32_t             found_args_num;
    uint32_t             args_arr[FW_TRACE_MAX_MESSAGE_ARGS_NUM];
    boolean_t            msg_valid;
} sxd_fw_trace_event_id_msg_t;

typedef struct sxd_fw_trace_common_db {
    char                         sdk_folder_path[SDK_FOLDER_PATH_LEN + 1];
    sxd_fw_trace_string_db_t     string_db;
    sxd_fw_trace_event_id_msg_t *event_id_msg_db_arr;
    uint32_t                     max_event_id;
} sxd_fw_trace_common_db_t;


/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/


sxd_status_t sxd_fw_trace_db_extract_string_db_sections(sxd_dev_id_t                    dev_id,
                                                        sxd_mtrc_cap_string_db_param_t *string_db_sections_param_arr,
                                                        uint32_t                        sections_num);
boolean_t sxd_fw_trace_db_get_msg_str(uint32_t str_ptr, char* str,  FILE *stream);
void sxd_fw_trace_db_clear_msg_db(uint32_t event_id);
boolean_t sxd_fw_trace_db_add_event_to_msg(sxd_fw_trace_event_t *trc_event_p, FILE *stream);
boolean_t sxd_fw_trace_db_add_new_msg(sxd_fw_trace_event_t *trc_event_p, char* str, FILE *stream);
void sxd_fw_trace_db_free_string_db(void);
void sxd_fw_trace_db_free_raw_string_db(void);
sxd_status_t sxd_fw_trace_db_store_fw_trace_init_attr_in_json_file(sxd_fw_trace_event_id_map_t *event_id_info,
                                                                   uint32_t                     mlx_buf_pg_num,
                                                                   uint32_t                     events_id_num,
                                                                   uint32_t                     first_fw_event_id,
                                                                   boolean_t                    is_dwsn_msb_supported,
                                                                   FILE                        *fw_trace_init_attr_file_stream);

sxd_status_t sxd_fw_trace_db_restore_fw_trace_init_attr_from_json_file(sxd_fw_trace_event_id_map_t *event_id_info,
                                                                       uint32_t                    *mlx_buf_pg_num,
                                                                       uint32_t                    *events_id_num,
                                                                       uint32_t                    *first_fw_event_id,
                                                                       boolean_t                   *is_dwsn_msb_supported,
                                                                       FILE                        *fw_trace_init_attr_file_stream);
sxd_status_t sxd_fw_trace_db_store_fw_trace_string_db_in_json_file(FILE *string_db_file_stream, char* fw_version_str);
sxd_status_t sxd_fw_trace_db_restore_fw_trace_string_db_from_json_file(FILE *string_db_file_stream,
                                                                       char* fw_version_str);

void sxd_fw_trace_db_init_string_db(void);
void sxd_fw_trace_db_clear_msg(uint32_t event_id);

void sxd_fw_trace_db_sdk_folder_path_set(char *sdk_folder_path);
void sxd_fw_trace_db_sdk_folder_path_get(char *sdk_folder_path);

void sxd_fw_trace_db_event_msg_db_set(sxd_fw_trace_event_id_msg_t *event_id_msg_db);
void sxd_fw_trace_db_event_msg_db_get(sxd_fw_trace_event_id_msg_t *event_id_msg_db);

void sxd_fw_trace_db_max_event_id_set(uint32_t max_event_id);
uint32_t sxd_fw_trace_db_max_event_id_get(void);

void sxd_fw_trace_db_event_id_msg_db_set(sxd_fw_trace_event_id_msg_t *event_id_msg_db, uint32_t event_id);
sxd_fw_trace_event_id_msg_t* sxd_fw_trace_db_event_id_msg_db_get(uint32_t event_id);

void sxd_fw_trace_db_string_db_set(sxd_fw_trace_string_db_t *string_db);
void sxd_fw_trace_db_string_db_get(sxd_fw_trace_string_db_t *string_db);


#endif /* SXD_FW_TRACE_INIT_H_ */
