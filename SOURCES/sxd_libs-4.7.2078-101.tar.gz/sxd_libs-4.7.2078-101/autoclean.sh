#
# Copyright © 2010-2023 NVIDIA CORPORATION & AFFILIATES. ALL RIGHTS RESERVED.
#
# This software product is a proprietary product of Nvidia Corporation and its affiliates
# (the "Company") and all right, title, and interest in and to the software
# product, including all associated intellectual property rights, are and
# shall remain exclusively with the Company.
#
# This software product is governed by the End User License Agreement
# provided with the software product.
#

rm -rf aclocal.m4 autom4te.cache stamp-h1 libtool configure config.* Makefile.in Makefile
rm -rf config/*

for a in sxd_sniffer/common sxd_sniffer/sniffer sxdev sxd_sniffer/player emad auto_registers command reg_access cr_access sxd_fw_dbg sxd_fw_trace; do
	rm -rf $a/Makefile 2>&1
	rm -rf $a/Makefile.in 2>&1
done
