/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/cl_mem.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/ioctl.h>

#include "sx/sxd/sxdev.h"
#include "sx/sxd/sxd_command_ifc.h"
#include "sx/sxd/sxd_registers.h"
#include "../common/sxd_utils.h"
#include "sx/sxd/sxd_emad_status.h"
#include "sx/sxd/sxd_emad_reg.h"

#include <reg_access/sxd_access_reg_infra.h>

#undef  __MODULE__
#define __MODULE__ COMMAND_IFC

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/
static uint64_t __transaction_id = 0;

static sxd_fw_information_t __fw_information = {0};


/************************************************
 *  Local function declarations
 ***********************************************/
static sxd_status_t __set_operation(struct ku_operation_tlv *operation_tlv_p,
                                    uint16_t                 register_id,
                                    sxd_access_cmd_t         access_cmd);
/************************************************
 *  MACROS
 ***********************************************/
#define PRINT_DONE_LOG(access_cmd, str)                     \
    {                                                       \
        switch (access_cmd) {                               \
        case SXD_ACCESS_CMD_SET:                            \
            SX_LOG_DBG("COMMAND IFC:  SET %s DONE\n", str); \
            break;                                          \
        case SXD_ACCESS_CMD_GET:                            \
            SX_LOG_DBG("COMMAND IFC:  GET %s DONE\n", str); \
            break;                                          \
        default:                                            \
            break;                                          \
        }                                                   \
    }                                                       \

#define SXD_COMMAND_IFC_ACCESS_REG(REG_NAME, reg_name)                         \
    struct access_reg_ifc_params ifc_params = {                                \
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_ ## REG_NAME                           \
    };                                                                         \
                                                                               \
    return (sxd_command_ifc_access_reg(hw_p,                                   \
                                       access_cmd,                             \
                                       dev_id,                                 \
                                       SXD_REG_ID_ ## REG_NAME ## _E,          \
                                       reg_name ## _reg_p,                     \
                                       sizeof(struct ku_ ## reg_name ## _reg), \
                                       &ifc_params));                          \

/************************************************
 *      Local Function implementations
 ***********************************************/
static sxd_status_t __set_operation(struct ku_operation_tlv *operation_tlv_p,
                                    uint16_t                 register_id,
                                    sxd_access_cmd_t         access_cmd)
{
    operation_tlv_p->type = 1; /* operation tlv type is 1*/
    operation_tlv_p->length = 4; /* operation tlv length is 4 (dwords) */
    operation_tlv_p->dr = 0; /* not a direct route */
    operation_tlv_p->status = 0; /* this is a query -> status is 0 */
    operation_tlv_p->register_id = register_id; /* register id */
    operation_tlv_p->op_class = 1; /*  REG_ACCESS class*/
    operation_tlv_p->r = 0; /* request = 0 */
    operation_tlv_p->tid = __transaction_id++; /* transaction id */

    switch (access_cmd) {
    case SXD_ACCESS_CMD_GET:
        operation_tlv_p->method = 1;     /* query = 1 */
        break;

    case SXD_ACCESS_CMD_SET:
    case SXD_ACCESS_CMD_ADD:
    case SXD_ACCESS_CMD_DELETE:
        operation_tlv_p->method = 2;     /* set = 2 */
        break;

    default:
        SX_LOG_ERR("Reached default case on access command\n");
        return SXD_STATUS_INVALID_ACCESS_CMD;
    }

    return SXD_STATUS_SUCCESS;
}

/************************************************
 *	Global Function implementations
 ***********************************************/

sxd_status_t sxd_command_ifc_log_verbosity_level(sxd_access_cmd_t cmd, sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_command_ifc_init(sx_log_cb_t                logging_cb,
                                  const sx_verbosity_level_t verbosity_level,
                                  sxd_command_ifc_hw_t     **hw_p)
{
    char     dev_name[1][MAX_NAME_LEN];
    char    *dev[1];
    uint32_t dev_num = 1;
    int      sxd_err = SXD_STATUS_SUCCESS;

    sx_log_init(TRUE, NULL, logging_cb);

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    SX_LOG_ENTER();

    /* allocate space for handle */
    if (hw_p != NULL) {
        hw_p[0] = (sxd_command_ifc_hw_t*)cl_calloc(1, sizeof(sxd_command_ifc_hw_t));
    } else {
        SX_LOG(SX_LOG_ERROR, "handle pointer is null\n");
        sxd_err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    /*check mutex init*/
    if (M_SXD_UTILS_MUTEX_IS_INITIALIZED(&(hw_p[0]->mtx)) == FALSE) {
        M_SXD_UTILS_MUTEX_INIT(&(hw_p[0]->mtx));
    }

    /******** LOCK ********/
    M_SXD_UTILS_MUTEX_LOCK(&(hw_p[0]->mtx));

    dev[0] = dev_name[0];

    /* get device list from the devices directory */
    sxd_err = sxd_get_dev_list(dev, &dev_num);
    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG(SX_LOG_ERROR, "sxd_get_dev_list error: [%s]\n", strerror(errno));
        sxd_err = SXD_STATUS_DEVICE_GET_ERROR;
        goto unlock_out;
    }

    /* open the first device */
    sxd_err = sxd_open_device(dev_name[0], &(hw_p[0]->dev));

    if (SXD_CHECK_FAIL(sxd_err)) {
        SX_LOG(SX_LOG_ERROR, "sxd_open_device error: [%s]\n", strerror(errno));
        sxd_err = SXD_STATUS_DEVICE_OPEN_ERROR;
        goto unlock_out;
    }

    SX_LOG_DBG("Device %s opened successfully!\n", dev_name[0]);

    hw_p[0]->is_initalized = TRUE;

unlock_out:

    M_SXD_UTILS_MUTEX_UNLOCK(&(hw_p[0]->mtx));
out:
    SX_LOG_NTC("COMMAND IFC:   COMMAND IFC INIT DONE\n");
    SX_LOG_EXIT();
    return sxd_err;
}

sxd_status_t sxd_command_ifc_deinit(sxd_command_ifc_hw_t *hw_p)
{
    sxd_status_t sxd_err = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_HANDLE_ERROR;
    }

    if (hw_p->is_initalized == FALSE) {
        SX_LOG_ERR("Command interface is not initialized , "
                   "please call sxd_command_ifc_init before using this API\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (M_SXD_UTILS_MUTEX_IS_INITIALIZED(&(hw_p->mtx)) == FALSE) {
        SX_LOG_ERR("Command IFC mutex is not initialized (have you initialized the lib ?)\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    /******** LOCK ********/
    M_SXD_UTILS_MUTEX_LOCK(&(hw_p->mtx));

    sxd_err = sxd_close_device(hw_p->dev);
    if (sxd_err != 0) {
        SX_LOG(SX_LOG_ERROR, "Failed to close device , error: %s\n", strerror(errno));
        sxd_err = SXD_STATUS_DEVICE_CLOSE_ERROR;
        M_SXD_UTILS_MUTEX_UNLOCK(&(hw_p->mtx));
        goto out;
    }

    M_SXD_UTILS_MUTEX_UNLOCK(&(hw_p->mtx));
    M_SXD_UTILS_MUTEX_DEINIT(&(hw_p->mtx));

    /* free handle */
    cl_free(hw_p);

    SX_LOG_DBG("Device was closed successfully!\n");

out:
    /******** UNLOCK ********/
    SX_LOG_NTC("COMMAND IFC:   COMMAND IFC DEINIT DONE\n");
    SX_LOG_EXIT();
    sx_log_close();

    return sxd_err;
}

sxd_status_t sxd_command_ifc_access_general(sxd_command_ifc_hw_t           *hw_p,
                                            void                           *ku_ifc_buff,
                                            const struct access_ifc_params *ifc_params)
{
    int             dev_ret = 0;
    sxd_status_t    sxd_err = SXD_STATUS_SUCCESS;
    sxd_ctrl_pack_t ctrl_pack;

    SX_LOG_ENTER();

    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_HANDLE_ERROR;
    }

    if (hw_p->is_initalized == FALSE) {
        SX_LOG_ERR("Command interface is not initialized , "
                   "please call sxd_command_ifc_init before using this API\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (M_SXD_UTILS_MUTEX_IS_INITIALIZED(&(hw_p->mtx)) == FALSE) {
        SX_LOG_ERR("Command IFC mutex is not initialized (have you initialized the lib ?)\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    /******** INPUTS CHECK ********/

    if (ku_ifc_buff == NULL) {
        SX_LOG_ERR("ku_ifc_buff is NULL cntrl_cmd - [%d] \n", ifc_params->ctrl_cmd);
        SX_LOG_EXIT();
        return SXD_STATUS_PARAM_ERROR;
    }

    /******** LOCK ********/
    M_SXD_UTILS_MUTEX_LOCK(&(hw_p->mtx));

    /* send query to sx_core */
    ctrl_pack.cmd_body = (void*)ku_ifc_buff;
    ctrl_pack.ctrl_cmd = ifc_params->ctrl_cmd;
    ;

    dev_ret = sxd_ioctl(hw_p->dev, &ctrl_pack);
    if (dev_ret != 0) {
        SX_LOG(SX_LOG_ERROR, "sxd_ioctl ctrl_cmd : [%d] "
               "error:  %s\n", ifc_params->ctrl_cmd, strerror(errno));
        sxd_err = SXD_STATUS_DEVICE_IOCTL_ERROR;
        goto out;
    }

out:
    /******** UNLOCK ********/
    M_SXD_UTILS_MUTEX_UNLOCK(&(hw_p->mtx));
    SX_LOG_DBG("COMMAND IFC: CNTR_CMD: %d EXECUTED \n", ifc_params->ctrl_cmd);
    SX_LOG_EXIT();

    return sxd_err;
}

sxd_status_t sxd_command_ifc_access_reg(sxd_command_ifc_hw_t               *hw_p,
                                        sxd_access_cmd_t                    access_cmd,
                                        sxd_dev_id_t                        dev_id,
                                        sxd_reg_id_e                        reg_id,
                                        void                               *ku_reg_buff,
                                        uint32_t                            ku_reg_size,
                                        const struct access_reg_ifc_params* ifc_params)
{
    int                      dev_ret = 0;
    sxd_status_t             sxd_err = SXD_STATUS_SUCCESS;
    sxd_ctrl_pack_t          ctrl_pack;
    uint8_t                * buff = NULL;
    const char             * reg_name = REG_ID_TO_NAME(reg_id);
    struct ku_access_common *comm_reg = NULL;

    SX_LOG_ENTER();

    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_HANDLE_ERROR;
    }

    if (hw_p->is_initalized == FALSE) {
        SX_LOG_ERR("Command interface is not initialized , "
                   "please call sxd_command_ifc_init before using this API\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (M_SXD_UTILS_MUTEX_IS_INITIALIZED(&(hw_p->mtx)) == FALSE) {
        SX_LOG_ERR("Command IFC mutex is not initialized (have you initialized the lib ?)\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    /******** INPUTS CHECK ********/

    if (ku_reg_buff == NULL) {
        SX_LOG_ERR("%s - ku_reg_buff is NULL\n", reg_name);
        SX_LOG_EXIT();
        return SXD_STATUS_PARAM_ERROR;
    }

    if (ku_reg_size == 0) {
        SX_LOG_ERR("%s - ku_reg_size is 0\n", reg_name);
        SX_LOG_EXIT();
        return SXD_STATUS_PARAM_ERROR;
    }

    /* allocate a dynamic buffer ON THE STACK (no need to free) */
    buff = cl_malloc(sizeof(struct ku_access_common) + ku_reg_size);
    if (buff == NULL) {
        SX_LOG_ERR("cannot allocate local buffer\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NO_MEMORY;
    }

    comm_reg = (struct ku_access_common *)buff;

    /******** LOCK ********/
    M_SXD_UTILS_MUTEX_LOCK(&(hw_p->mtx));

    sxd_err = __set_operation(&comm_reg->op_tlv, reg_id, access_cmd);
    if (SXD_CHECK_FAIL(sxd_err)) {
        goto out;
    }

    /* set target device id */
    comm_reg->dev_id = dev_id;

    memcpy(&comm_reg->comm_reg, ku_reg_buff, ku_reg_size);

    /* send query to sx_core */
    ctrl_pack.cmd_body = (void*)buff;
    ctrl_pack.ctrl_cmd = ifc_params->ctrl_cmd;
    dev_ret = sxd_ioctl(hw_p->dev, &ctrl_pack);
    if (dev_ret != 0) {
        SX_LOG(SX_LOG_ERROR, "sxd_ioctl (CTRL_CMD_ACCESS_REG - %s) "
               "error: [%s]\n", reg_name, strerror(errno));
        sxd_err = SXD_STATUS_DEVICE_IOCTL_ERROR;
        goto out;
    }

    if (SXD_EMAD_CHECK_FAIL(comm_reg->op_tlv.status)) {
        /* For most registers, convert status to SXD_STATUS_FW_ERROR */
        sxd_err = SXD_STATUS_FW_ERROR;

        /* For MCIA register, if status is BUSY return BUSY and no error log. All other RC convert to SXD_STATUS_FW_ERROR*/
        switch (reg_id) {
        case SXD_REG_ID_MCIA_E:
            if (comm_reg->op_tlv.status == SXD_EMAD_STATUS_DEVICE_IS_BUSY) {
                sxd_err = SXD_STATUS_FW_BUSY;
                goto out;
            }

        /* FALLTHROUGH */
        default:
            SX_LOG(SX_LOG_ERROR, "sxd_ioctl (CTRL_CMD_ACCESS_REG - %s) FW error: [%s]\n",
                   reg_name, SXD_EMAD_STATUS_MSG(comm_reg->op_tlv.status));
            goto out;
        }
    }


    if (access_cmd == SXD_ACCESS_CMD_GET) {
        memcpy(ku_reg_buff, &comm_reg->comm_reg, ku_reg_size);
    }

    SX_LOG_DBG("Accessed %s register successfully\n", reg_name);
out:
    /******** UNLOCK ********/
    M_SXD_UTILS_MUTEX_UNLOCK(&(hw_p->mtx));
    PRINT_DONE_LOG(access_cmd, reg_name);
    SX_LOG_EXIT();

    cl_free(buff);

    return sxd_err;
}

/*******************************************************************/
/*******************************************************************/
/*              cntrl cmd wrappers (ku_ctrl_cmd)                               */
/*******************************************************************/
/*******************************************************************/

sxd_status_t sxd_command_ifc_set_default_vid(sxd_command_ifc_hw_t *hw_p,
                                             sxd_dev_id_t          dev_id,
                                             uint8_t               is_lag,
                                             sxd_port_sys_id_t     sysport,
                                             uint16_t              lag_id,
                                             sxd_vid_t             default_vid)
{
    struct ku_default_vid_data default_vid_data;
    struct access_ifc_params   ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_DEFAULT_VID
    };

    memset(&default_vid_data, 0, sizeof(default_vid_data));
    default_vid_data.dev_id = dev_id;
    default_vid_data.is_lag = is_lag;
    default_vid_data.lag_id = lag_id;
    default_vid_data.sysport = sysport;
    default_vid_data.default_vid = default_vid;

    return (sxd_command_ifc_access_general(hw_p, &default_vid_data, &ifc_params));
}

#ifdef SW_PUDE_EMULATION
/* PUDE WA for NOS (PUDE events are handled by SDK). Needed for BU. */
sxd_status_t sxd_command_ifc_set_admin_status(sxd_command_ifc_hw_t   *hw_p,
                                              sxd_dev_id_t            dev_id,
                                              sxd_port_sys_id_t       sysport,
                                              sxd_paos_admin_status_t admin_status)
{
    struct ku_admin_status_data admin_status_data;
    struct access_ifc_params    ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_PORT_ADMIN_STATUS
    };

    memset(&admin_status_data, 0, sizeof(admin_status_data));
    admin_status_data.dev_id = dev_id;
    admin_status_data.sysport = sysport;
    admin_status_data.admin_status = admin_status;

    return (sxd_command_ifc_access_general(hw_p, &admin_status_data, &ifc_params));
}
#endif /* SW_PUDE_EMULATION */

sxd_status_t sxd_command_ifc_set_vid_membership(sxd_command_ifc_hw_t *hw_p,
                                                sxd_dev_id_t          dev_id,
                                                uint8_t               is_lag,
                                                sxd_port_phy_id_t     phy_port,
                                                uint16_t              lag_id,
                                                sxd_vid_t             vid,
                                                uint8_t               is_tagged)
{
    struct ku_vid_membership_data vid_membership_data;
    struct access_ifc_params      ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_VID_MEMBERSHIP
    };

    memset(&vid_membership_data, 0, sizeof(vid_membership_data));
    vid_membership_data.dev_id = dev_id;
    vid_membership_data.is_lag = is_lag;
    vid_membership_data.lag_id = lag_id;
    vid_membership_data.phy_port = phy_port;
    vid_membership_data.vid = vid;
    vid_membership_data.is_tagged = is_tagged;

    return (sxd_command_ifc_access_general(hw_p, &vid_membership_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_set_prio_tagging(sxd_command_ifc_hw_t *hw_p,
                                              sxd_dev_id_t          dev_id,
                                              uint8_t               is_lag,
                                              sxd_port_phy_id_t     phy_port,
                                              uint16_t              lag_id,
                                              uint8_t               is_prio_tagged)
{
    struct ku_prio_tagging_data prio_tagging_data;
    struct access_ifc_params    ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_PRIO_TAGGING
    };

    memset(&prio_tagging_data, 0, sizeof(prio_tagging_data));
    prio_tagging_data.dev_id = dev_id;
    prio_tagging_data.is_lag = is_lag;
    prio_tagging_data.lag_id = lag_id;
    prio_tagging_data.phy_port = phy_port;
    /* prio_tagging_data.vid = vid; */
    prio_tagging_data.is_prio_tagged = is_prio_tagged;

    return (sxd_command_ifc_access_general(hw_p, &prio_tagging_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_set_prio_to_tc(sxd_command_ifc_hw_t   *hw_p,
                                            sxd_dev_id_t            dev_id,
                                            uint8_t                 is_lag,
                                            sxd_port_phy_id_t       phy_port,
                                            uint16_t                lag_id,
                                            sxd_cos_port_priority_t priority,
                                            sxd_cos_traffic_class_t traffic_class)
{
    struct ku_prio_to_tc_data prio_to_tc_data;
    struct access_ifc_params  ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_PRIO_TO_TC
    };

    memset(&prio_to_tc_data, 0, sizeof(prio_to_tc_data));
    prio_to_tc_data.dev_id = dev_id;
    prio_to_tc_data.is_lag = is_lag;
    prio_to_tc_data.lag_id = lag_id;
    prio_to_tc_data.phy_port = phy_port;
    prio_to_tc_data.priority = priority;
    prio_to_tc_data.traffic_class = traffic_class;

    return (sxd_command_ifc_access_general(hw_p, &prio_to_tc_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_set_local_to_swid(sxd_command_ifc_hw_t *hw_p,
                                               sxd_dev_id_t          dev_id,
                                               sxd_port_phy_id_t     local_port,
                                               sxd_swid_t            swid)
{
    struct ku_local_port_swid_data local_port_swid_data;
    struct access_ifc_params       ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_LOCAL_PORT_TO_SWID
    };

    memset(&local_port_swid_data, 0, sizeof(local_port_swid_data));
    local_port_swid_data.dev_id = dev_id;
    local_port_swid_data.local_port = local_port;
    local_port_swid_data.swid = swid;


    return (sxd_command_ifc_access_general(hw_p, &local_port_swid_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_set_ib_to_local_port(sxd_command_ifc_hw_t *hw_p,
                                                  sxd_dev_id_t          dev_id,
                                                  uint16_t              ib_port,
                                                  sxd_port_phy_id_t     local_port)
{
    struct ku_ib_local_port_data ib_local_port_data;
    struct access_ifc_params     ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_IB_TO_LOCAL_PORT
    };

    memset(&ib_local_port_data, 0, sizeof(ib_local_port_data));
    ib_local_port_data.dev_id = dev_id;
    ib_local_port_data.ib_port = ib_port;
    ib_local_port_data.local_port = local_port;

    return (sxd_command_ifc_access_general(hw_p, &ib_local_port_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_set_system_to_local_port(sxd_command_ifc_hw_t *hw_p,
                                                      sxd_dev_id_t          dev_id,
                                                      uint16_t              system_port,
                                                      sxd_port_phy_id_t     local_port)
{
    struct ku_system_local_port_data system_local_port_data;
    struct access_ifc_params         ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_SYSTEM_TO_LOCAL_PORT
    };

    memset(&system_local_port_data, 0, sizeof(system_local_port_data));
    system_local_port_data.dev_id = dev_id;
    system_local_port_data.system_port = system_port;
    system_local_port_data.local_port = local_port;

    return (sxd_command_ifc_access_general(hw_p, &system_local_port_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_set_port_rp_mode(sxd_command_ifc_hw_t *hw_p,
                                              sxd_dev_id_t          dev_id,
                                              uint8_t               is_lag,
                                              uint16_t              lag_id_system_port,
                                              uint16_t              vlan_id,
                                              uint8_t               is_rp,
                                              sxd_access_cmd_t      access_cmd,
                                              uint16_t              rif_id,
                                              uint16_t              hw_efid)
{
    struct ku_port_rp_mode_data port_rp_mode_data;
    struct access_ifc_params    ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_PORT_RP_MODE
    };

    memset(&port_rp_mode_data, 0, sizeof(port_rp_mode_data));
    port_rp_mode_data.dev_id = dev_id;
    port_rp_mode_data.is_lag = is_lag;
    port_rp_mode_data.is_rp = is_rp;
    port_rp_mode_data.vlan_id = vlan_id;
    port_rp_mode_data.rif_id = rif_id;
    port_rp_mode_data.hw_efid = (access_cmd != SXD_ACCESS_CMD_DELETE) ? hw_efid : INVALID_HW_FID_ID;
    port_rp_mode_data.is_valid = (access_cmd != SXD_ACCESS_CMD_DELETE);

    if (is_lag) {
        port_rp_mode_data.lag_id = lag_id_system_port;
    } else {
        port_rp_mode_data.sysport = lag_id_system_port;
    }

    return (sxd_command_ifc_access_general(hw_p, &port_rp_mode_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_set_local_port_to_lag(sxd_command_ifc_hw_t *hw_p,
                                                   sxd_dev_id_t          dev_id,
                                                   uint16_t              is_lag,
                                                   uint16_t              lag_id,
                                                   uint16_t              lag_port_index,
                                                   uint16_t              local_port)
{
    struct ku_local_port_to_lag_data local_port_to_lag_data;
    struct access_ifc_params         ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_LOCAL_PORT_TO_LAG
    };

    memset(&local_port_to_lag_data, 0, sizeof(local_port_to_lag_data));
    local_port_to_lag_data.dev_id = dev_id;
    local_port_to_lag_data.is_lag = is_lag;
    local_port_to_lag_data.lag_id = lag_id;
    local_port_to_lag_data.lag_port_index = lag_port_index;
    local_port_to_lag_data.local_port = local_port;

    return (sxd_command_ifc_access_general(hw_p, &local_port_to_lag_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_lag_oper_state_set(sxd_command_ifc_hw_t *hw_p, uint16_t lag_id, uint8_t oper_state)
{
    struct ku_lag_oper_state_data lag_oper_state_data;
    struct access_ifc_params      ifc_params = {
        .ctrl_cmd = CTRL_CMD_LAG_OPER_STATE_SET
    };

    memset(&lag_oper_state_data, 0, sizeof(lag_oper_state_data));
    lag_oper_state_data.lag_id = lag_id;
    lag_oper_state_data.oper_state = (oper_state == SXD_PORT_OPER_STATUS_UP);

    return (sxd_command_ifc_access_general(hw_p, &lag_oper_state_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_port_ber_monitor_state_set(sxd_command_ifc_hw_t *hw_p,
                                                        sxd_dev_id_t          dev_id,
                                                        sxd_port_phy_id_t     local_port,
                                                        uint8_t               ber_monitor_state)
{
    struct ku_ber_monitor_state_data ber_monitor_state_data;
    struct access_ifc_params         ifc_params = {
        .ctrl_cmd = CTRL_CMD_PORT_BER_MONITOR_STATE_SET
    };

    memset(&ber_monitor_state_data, 0, sizeof(ber_monitor_state_data));
    ber_monitor_state_data.dev_id = dev_id;
    ber_monitor_state_data.local_port = local_port;
    ber_monitor_state_data.ber_monitor_state = ber_monitor_state;

    return (sxd_command_ifc_access_general(hw_p, &ber_monitor_state_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_port_sample_rate_update(sxd_command_ifc_hw_t *hw_p,
                                                     sxd_port_phy_id_t     local_port,
                                                     uint32_t              sample_rate)
{
    struct ku_psample_port_sample_rate port_sample_rate;
    struct access_ifc_params           ifc_params = {
        .ctrl_cmd = CTRL_CMD_PSAMPLE_PORT_SAMPLE_RATE_UPDATE
    };

    memset(&port_sample_rate, 0, sizeof(port_sample_rate));
    port_sample_rate.local_port = local_port;
    port_sample_rate.rate = sample_rate;

    return (sxd_command_ifc_access_general(hw_p, &port_sample_rate, &ifc_params));
}

sxd_status_t sxd_command_ifc_port_ber_monitor_bitmask_set(sxd_command_ifc_hw_t *hw_p,
                                                          sxd_dev_id_t          dev_id,
                                                          uint16_t              local_port,
                                                          uint8_t               bitmask)
{
    struct ku_ber_monitor_bitmask_data ber_monitor_bitmask_data;
    struct access_ifc_params           ifc_params = {
        .ctrl_cmd = CTRL_CMD_PORT_BER_MONITOR_BITMASK_SET
    };

    memset(&ber_monitor_bitmask_data, 0, sizeof(ber_monitor_bitmask_data));
    ber_monitor_bitmask_data.dev_id = dev_id;
    ber_monitor_bitmask_data.local_port = local_port;
    ber_monitor_bitmask_data.bitmask = bitmask;

    return (sxd_command_ifc_access_general(hw_p, &ber_monitor_bitmask_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_tele_threshold_set(sxd_command_ifc_hw_t *hw_p,
                                                sxd_port_phy_id_t     local_port,
                                                uint8_t               dir_ing,
                                                uint64_t              tc_vec)
{
    struct ku_tele_threshold_data tele_thrs_data;
    struct access_ifc_params      ifc_params = {
        .ctrl_cmd = CTRL_CMD_TELE_THRESHOLD_SET
    };

    memset(&tele_thrs_data, 0, sizeof(tele_thrs_data));
    tele_thrs_data.local_port = local_port;
    tele_thrs_data.dir_ing = dir_ing;
    tele_thrs_data.tc_vec = tc_vec;

    return (sxd_command_ifc_access_general(hw_p, &tele_thrs_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_query_rsrc_info(sxd_command_ifc_hw_t *hw_p, struct ku_query_rsrc *rsrc_info_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_QUERY_RSRC
    };

    return (sxd_command_ifc_access_general(hw_p, rsrc_info_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_query_fw_info(sxd_command_ifc_hw_t *hw_p, query_fw_t   *fw_info_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_QUERY_FW
    };

    return (sxd_command_ifc_access_general(hw_p, fw_info_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_issu_fw(sxd_command_ifc_hw_t *hw_p, sxd_dev_id_t dev_id)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_ISSU_FW
    };

    return (sxd_command_ifc_access_general(hw_p, (unsigned long *)&dev_id, &ifc_params));
}

sxd_status_t sxd_command_ifc_send_issu_notification(sxd_command_ifc_hw_t *hw_p, boolean_t is_issu_start)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_SEND_ISSU_NOTIFICATION
    };

    return (sxd_command_ifc_access_general(hw_p, (unsigned long *)&is_issu_start, &ifc_params));
}

sxd_status_t sxd_command_ifc_pci_device_restart(sxd_command_ifc_hw_t *hw_p, sxd_dev_id_t dev_id)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_PCI_DEVICE_RESTART
    };

    return (sxd_command_ifc_access_general(hw_p, (unsigned long *)&dev_id, &ifc_params));
}

sxd_status_t sxd_command_ifc_query_board_info(sxd_command_ifc_hw_t *hw_p, struct ku_query_board_info *board_info_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_QUERY_BOARD_INFO
    };

    return (sxd_command_ifc_access_general(hw_p, board_info_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_system_m_key_access(sxd_command_ifc_hw_t   *hw_p,
                                                 sxd_access_cmd_t        access_cmd,
                                                 struct ku_system_m_key *system_m_key_p)
{
    sxd_status_t             sxd_err = SXD_STATUS_SUCCESS;
    struct access_ifc_params ifc_params;

    switch (access_cmd) {
    case SXD_ACCESS_CMD_SET:
        SX_LOG_INF("COMMAND IFC: SET SYSTEM M_KEY\n");
        ifc_params.ctrl_cmd = CTRL_CMD_SET_SYSTEM_MKEY;
        break;

    case SXD_ACCESS_CMD_GET:
        SX_LOG_INF("COMMAND IFC: GET SYSTEM M_KEY\n");
        ifc_params.ctrl_cmd = CTRL_CMD_GET_SYSTEM_MKEY;
        break;

    default:
        SX_LOG_ERR("Reached default case on access command , command: [%d]\n",
                   access_cmd);
        sxd_err = SXD_STATUS_INVALID_ACCESS_CMD;
        return (sxd_err);
    }

    return (sxd_command_ifc_access_general(hw_p, system_m_key_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_truncate_size_set(sxd_command_ifc_hw_t          *hw_p,
                                               struct ku_set_truncate_params *truncate_params_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_TRUNCATE_PARAMS
    };

    return (sxd_command_ifc_access_general(hw_p, truncate_params_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_pci_profile_get(sxd_command_ifc_hw_t *hw_p, struct sx_pci_profile *pci_profile_p)
{
    sxd_status_t              sxd_err = SXD_STATUS_SUCCESS;
    struct ku_get_pci_profile pci_prof;
    struct access_ifc_params  ifc_params = {
        .ctrl_cmd = CTRL_CMD_GET_PCI_PROFILE
    };

    SX_LOG_ENTER();
    memset(&pci_prof, 0, sizeof(pci_prof));

    if (pci_profile_p == NULL) {
        SX_LOG_ERR("pci_profile_p is NULL \n");
        sxd_err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    sxd_err = sxd_command_ifc_access_general(hw_p, &pci_prof, &ifc_params);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, " %s Failed - (CTRL_CMD_GET_PCI_PROFILE) \n", __func__);
        goto out;
    }

    *pci_profile_p = pci_prof.profile;

out:
    SX_LOG_EXIT();
    return (sxd_err);
}

sxd_status_t sxd_command_ifc_device_profile_access(sxd_command_ifc_hw_t *hw_p,
                                                   sxd_access_cmd_t      access_cmd,
                                                   struct ku_profile    *profile_p)
{
    sxd_status_t             sxd_err = SXD_STATUS_SUCCESS;
    struct access_ifc_params ifc_params;

    switch (access_cmd) {
    case SXD_ACCESS_CMD_SET:
        SX_LOG_INF("COMMAND IFC: SET DEVICE PROFILE\n");
        ifc_params.ctrl_cmd = CTRL_CMD_SET_DEVICE_PROFILE;
        break;

    case SXD_ACCESS_CMD_GET:
        SX_LOG_INF("COMMAND IFC: GET DEVICE PROFILE\n");
        ifc_params.ctrl_cmd = CTRL_CMD_GET_DEVICE_PROFILE;
        break;

    default:
        SX_LOG_ERR("Reached default case on access command , command: [%d]\n",
                   access_cmd);
        sxd_err = SXD_STATUS_INVALID_ACCESS_CMD;
        return (sxd_err);
    }

    return (sxd_command_ifc_access_general(hw_p, profile_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_cpu_memory_access(sxd_command_ifc_hw_t *hw_p,
                                               sxd_access_cmd_t      access_cmd,
                                               struct ku_map_memory *map_memory_p)
{
    sxd_status_t             sxd_err = SXD_STATUS_SUCCESS;
    struct access_ifc_params ifc_params;

    switch (access_cmd) {
    case SXD_ACCESS_CMD_ADD:
        SX_LOG_INF("COMMAND IFC: MAP FW MEMORY\n");
        ifc_params.ctrl_cmd = CTRL_CMD_FW_MEMORY_TO_CPU_MAP;
        break;

    default:
        SX_LOG_ERR("Reached default case on access command , command: [%d]\n",
                   access_cmd);
        sxd_err = SXD_STATUS_INVALID_ACCESS_CMD;
        return (sxd_err);
    }

    return (sxd_command_ifc_access_general(hw_p, map_memory_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_kvh_cache_params_access(sxd_command_ifc_hw_t      *hw_p,
                                                     sxd_access_cmd_t           access_cmd,
                                                     struct profile_kvh_params *kvh_params_p)
{
    sxd_status_t             sxd_err = SXD_STATUS_SUCCESS;
    struct access_ifc_params ifc_params;

    switch (access_cmd) {
    case SXD_ACCESS_CMD_SET:
        SX_LOG_INF("COMMAND IFC: SET KVH PARAMETERS\n");
        ifc_params.ctrl_cmd = CTRL_CMD_SET_KVH_CACHE_PARAMS;
        break;

    case SXD_ACCESS_CMD_GET:
        SX_LOG_INF("COMMAND IFC: GET KVH PARAMETERS\n");
        ifc_params.ctrl_cmd = CTRL_CMD_GET_KVH_CACHE_PARAMS;
        break;

    default:
        SX_LOG_ERR("Reached default case on access command , command: [%d]\n",
                   access_cmd);
        sxd_err = SXD_STATUS_INVALID_ACCESS_CMD;
        return (sxd_err);
    }

    return (sxd_command_ifc_access_general(hw_p, kvh_params_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_swid_to_rdq(sxd_command_ifc_hw_t *hw_p, sxd_swid_t swid, uint8_t   *rdq_p)
{
    sxd_status_t               sxd_err = SXD_STATUS_SUCCESS;
    struct ku_swid_2_rdq_query swid_2_rdq_query;
    struct access_ifc_params   ifc_params = {
        .ctrl_cmd = CTRL_CMD_GET_SWID_2_RDQ
    };

    SX_LOG_ENTER();
    memset(&swid_2_rdq_query, 0, sizeof(swid_2_rdq_query));

    if (rdq_p == NULL) {
        SX_LOG_ERR("rdq_p is NULL \n");
        sxd_err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }
    if (SXD_SWID_CHECK_RANGE(swid) == FALSE) {
        SX_LOG_ERR("SWID [%d] is out of range [%d-%d]\n", swid, SXD_SWID_ID_MIN, SXD_SWID_ID_MAX);
        sxd_err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    swid_2_rdq_query.swid = swid;

    sxd_err = sxd_command_ifc_access_general(hw_p, &swid_2_rdq_query, &ifc_params);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, " %s Failed - (CTRL_CMD_GET_SWID_2_RDQ) \n", __func__);
        goto out;
    }

    *rdq_p = swid_2_rdq_query.rdq;
    ;

out:
    SX_LOG_EXIT();
    return (sxd_err);
}

sxd_status_t sxd_command_ifc_sx_core_db_restore_allowed(sxd_command_ifc_hw_t *hw_p,
                                                        sxd_boolean_t        *is_restore_allowed_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_GET_SX_CORE_DB_RESTORE_ALLOWED
    };

    return (sxd_command_ifc_access_general(hw_p, is_restore_allowed_p, &ifc_params));
}

sxd_status_t sxd_fatal_failure_detection_info_set(sxd_command_ifc_hw_t         *hw_p,
                                                  ku_dbg_health_check_params_t* ku_dbg_health_check_params_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_SEND_FATAL_FAILURE_DETECT_INFO_SET
    };

    return (sxd_command_ifc_access_general(hw_p, ku_dbg_health_check_params_p, &ifc_params));
}


sxd_status_t sxd_sysfs_sniffer_mode_set(sxd_command_ifc_hw_t      *hw_p,
                                        ku_sysfs_sniffer_params_t* ku_sysfs_sniffer_params_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_SYSFS_SNIFFER
    };

    return (sxd_command_ifc_access_general(hw_p, ku_sysfs_sniffer_params_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_sx_core_db_access(sxd_command_ifc_hw_t *hw_p,
                                               sxd_access_cmd_t      access_cmd,
                                               struct ku_sx_core_db *sx_core_db_p)
{
    sxd_status_t             sxd_err = SXD_STATUS_SUCCESS;
    struct access_ifc_params ifc_params;

    switch (access_cmd) {
    case SXD_ACCESS_CMD_SET:
        SX_LOG_INF("COMMAND IFC: RESTORE SX_CORE DRIVER DB\n");
        ifc_params.ctrl_cmd = CTRL_CMD_RESTORE_SX_CORE_DB;
        break;

    case SXD_ACCESS_CMD_GET:
        SX_LOG_INF("COMMAND IFC: SAVE SX_CORE DRIVER DB\n");
        ifc_params.ctrl_cmd = CTRL_CMD_SAVE_SX_CORE_DB;
        break;

    default:
        SX_LOG_ERR("Reached default case on access command , command: [%d]\n",
                   access_cmd);
        sxd_err = SXD_STATUS_INVALID_ACCESS_CMD;
        return (sxd_err);
    }

    return (sxd_command_ifc_access_general(hw_p, sx_core_db_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_set_port_vid_to_fid_map(sxd_command_ifc_hw_t *hw_p,
                                                     sxd_dev_id_t          dev_id,
                                                     sxd_port_phy_id_t     local_port,
                                                     uint16_t              vid,
                                                     uint8_t               is_mapped_to_fid,
                                                     uint16_t              fid)
{
    struct ku_port_vlan_to_fid_map_data port_vlan_to_fid_map_data;
    struct access_ifc_params            ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_PORT_VID_TO_FID_MAP
    };

    memset(&port_vlan_to_fid_map_data, 0, sizeof(port_vlan_to_fid_map_data));
    port_vlan_to_fid_map_data.dev_id = dev_id;
    port_vlan_to_fid_map_data.local_port = local_port;
    port_vlan_to_fid_map_data.vid = vid;
    port_vlan_to_fid_map_data.is_mapped_to_fid = is_mapped_to_fid;
    port_vlan_to_fid_map_data.fid = fid;

    return (sxd_command_ifc_access_general(hw_p, &port_vlan_to_fid_map_data, &ifc_params));
}

sxd_status_t sxd_command_ifc_set_device_info(sxd_command_ifc_hw_t *hw_p, struct ku_dev_info *dev_info_set_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_DEV_INFO
    };

    return (sxd_command_ifc_access_general(hw_p, dev_info_set_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_get_device_info(sxd_command_ifc_hw_t *hw_p, struct ku_dev_info *dev_info_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_GET_DEV_INFO
    };

    return (sxd_command_ifc_access_general(hw_p, dev_info_p, &ifc_params));
}

sxd_status_t sxd_command_ifc_host_mem_page_get(sxd_command_ifc_hw_t         *hw_p,
                                               struct ku_host_mem_read_page *host_mem_page_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_READ_HOST_MEM_PAGE
    };

    return (sxd_command_ifc_access_general(hw_p, host_mem_page_p, &ifc_params));
}
sxd_status_t sxd_command_ifc_set_mad_demux(sxd_command_ifc_hw_t *hw_p, sxd_dev_id_t dev_id, uint8_t enable)
{
    struct ku_mad_demux      mad_demux;
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_MAD_DEMUX
    };

    memset(&mad_demux, 0, sizeof(mad_demux));
    mad_demux.dev_id = dev_id;
    mad_demux.enable = enable;

    return (sxd_command_ifc_access_general(hw_p, &mad_demux, &ifc_params));
}

sxd_status_t sxd_command_ifc_set_sw_ib_node_description(sxd_command_ifc_hw_t          *hw_p,
                                                        struct ku_ib_node_description *node_desc)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_SET_SW_IB_NODE_DESC
    };

    return (sxd_command_ifc_access_general(hw_p, node_desc, &ifc_params));
}

void sxd_set_last_fw_status(uint8_t fw_status, uint16_t register_id, uint8_t method, const char *emad_str)
{
    __fw_information.fw_status = fw_status;

    __fw_information.register_id = register_id;

    __fw_information.access_cmd = (1 == method) ? SXD_ACCESS_CMD_GET : SXD_ACCESS_CMD_SET;

    if (emad_str) {
        memcpy(__fw_information.emad_str, emad_str, sizeof(__fw_information.emad_str));
    } else {
        strcpy(__fw_information.emad_str, "N/A");
    }
}

sxd_status_t sxd_get_last_fw_status(sxd_fw_information_t *fw_information_p)
{
    sxd_status_t sxd_err = SXD_STATUS_SUCCESS;

    if (fw_information_p == NULL) {
        SX_LOG_ERR("fw_information is NULL\n");
        return SXD_STATUS_PARAM_ERROR;
    }

    memcpy(fw_information_p, &__fw_information, sizeof(*fw_information_p));

    return sxd_err;
}

sxd_status_t sxd_command_ifc_sdk_health_state_set(sxd_command_ifc_hw_t *hw_p,
                                                  uint8_t               dev_id,
                                                  boolean_t             sdk_health_state)
{
    struct ku_sdk_health_event_control sdk_health_ctl;
    struct access_ifc_params           ifc_params = {
        .ctrl_cmd = CTRL_CMD_SDK_HEALTH_SET
    };

    memset(&sdk_health_ctl, 0, sizeof(sdk_health_ctl));

    sdk_health_ctl.dev_id = dev_id;
    sdk_health_ctl.enable = sdk_health_state;

    return (sxd_command_ifc_access_general(hw_p, &sdk_health_ctl, &ifc_params));
}

sxd_status_t sxd_command_ifc_sdk_health_state_get(sxd_command_ifc_hw_t *hw_p,
                                                  uint8_t               dev_id,
                                                  boolean_t             get_and_disable,
                                                  boolean_t            *sdk_health_state_p)
{
    sxd_status_t                       sxd_err = SXD_STATUS_SUCCESS;
    struct ku_sdk_health_event_control sdk_health_ctl;
    struct access_ifc_params           ifc_params = {
        .ctrl_cmd = CTRL_CMD_SDK_HEALTH_GET
    };

    SX_LOG_ENTER();
    memset(&sdk_health_ctl, 0, sizeof(sdk_health_ctl));

    /******** INPUTS CHECK ********/

    if (sdk_health_state_p == NULL) {
        SX_LOG_ERR("boot_status is NULL \n");
        sxd_err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    sdk_health_ctl.dev_id = dev_id;
    sdk_health_ctl.get_and_disable = get_and_disable;

    sxd_err = sxd_command_ifc_access_general(hw_p, &sdk_health_ctl, &ifc_params);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, " %s Failed - (CTRL_CMD_SDK_HEALTH_GET) \n", __func__);
        goto out;
    }

    *sdk_health_state_p = sdk_health_ctl.enable;

out:
    SX_LOG_EXIT();
    return (sxd_err);
}

sxd_status_t sxd_command_ifc_bulk_stateful_db_keys_set(sxd_command_ifc_hw_t              *hw_p,
                                                       ku_stateful_db_translated_entry_t *translated_entry_p)
{
    struct access_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_BULK_STATEFUL_DB_KEYS_WRITE
    };

    return (sxd_command_ifc_access_general(hw_p, translated_entry_p, &ifc_params));
}

/*******************************************************************/
/*******************************************************************/
/*      cntrl cmd access reg wrappers (ku_ctrl_cmd_access_reg)     */
/*******************************************************************/
/*******************************************************************/

sxd_status_t sxd_command_ifc_access_ptys_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_ptys_reg   *ptys_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PTYS, ptys)
}

sxd_status_t sxd_command_ifc_access_pspa_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pspa_reg   *pspa_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PSPA, pspa)
}

sxd_status_t sxd_command_ifc_access_pmlp_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pmlp_reg   *pmlp_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PMLP, pmlp)
}

sxd_status_t sxd_command_ifc_access_plib_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_plib_reg   *plib_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PLIB, plib)
}

sxd_status_t sxd_command_ifc_access_pplm_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pplm_reg   *pplm_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PPLM, pplm)
}


sxd_status_t sxd_command_ifc_access_plpc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_plpc_reg   *plpc_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PLPC, plpc)
}

sxd_status_t sxd_command_ifc_access_pmpc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pmpc_reg   *pmpc_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PMPC, pmpc)
}

sxd_status_t sxd_command_ifc_access_pfsc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pfsc_reg   *pfsc_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PFSC, pfsc)
}

sxd_status_t sxd_command_ifc_access_pmmp_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pmmp_reg   *pmmp_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PMMP, pmmp)
}

sxd_status_t sxd_command_ifc_access_mjtag_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_mjtag_reg  *mjtag_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MJTAG, mjtag)
}

sxd_status_t sxd_command_ifc_access_pmpr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pmpr_reg   *pmpr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PMPR, pmpr)
}

sxd_status_t sxd_command_ifc_access_hcap_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_hcap_reg   *hcap_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(HCAP, hcap)
}

sxd_status_t sxd_command_ifc_access_hdrt_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_hdrt_reg   *hdrt_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(HDRT, hdrt)
}

sxd_status_t sxd_command_ifc_access_hctr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_hctr_reg   *hctr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(HCTR, hctr)
}

sxd_status_t sxd_command_ifc_access_pelc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pelc_reg   *pelc_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PELC, pelc)
}

sxd_status_t sxd_command_ifc_access_spad_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_spad_reg   *spad_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SPAD, spad)
}

sxd_status_t sxd_command_ifc_access_mcia_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mcia_reg   *mcia_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MCIA, mcia)
}

sxd_status_t sxd_command_ifc_access_mmdio_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_mmdio_reg  *mmdio_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MMDIO, mmdio)
}

sxd_status_t sxd_command_ifc_access_mmia_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mmia_reg   *mmia_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MMIA, mmia)
}

sxd_status_t sxd_command_ifc_access_mfcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mfcr_reg   *mfcr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MFCR, mfcr)
}

sxd_status_t sxd_command_ifc_access_mfsl_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mfsl_reg   *mfsl_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MFSL, mfsl)
}

sxd_status_t sxd_command_ifc_access_fore_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_fore_reg   *fore_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(FORE, fore)
}

sxd_status_t sxd_command_ifc_access_mtcap_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_mtcap_reg  *mtcap_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MTCAP, mtcap)
}

sxd_status_t sxd_command_ifc_access_mtbr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mtbr_reg   *mtbr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MTBR, mtbr)
}

sxd_status_t sxd_command_ifc_access_mfpa_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mfpa_reg   *mfpa_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MFPA, mfpa)
}

sxd_status_t sxd_command_ifc_access_mfbe_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mfbe_reg   *mfbe_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MFBE, mfbe)
}

sxd_status_t sxd_command_ifc_access_mfba_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mfba_reg   *mfba_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MFBA, mfba)
}

sxd_status_t sxd_command_ifc_access_raw_reg(sxd_command_ifc_hw_t *hw_p,
                                            sxd_access_cmd_t      access_cmd,
                                            sxd_dev_id_t          dev_id,
                                            uint16_t              register_id,
                                            struct ku_raw_reg    *raw_reg_p)
{
    struct access_reg_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_RAW
    };

    return (sxd_command_ifc_access_reg(hw_p,
                                       access_cmd,
                                       dev_id,
                                       register_id,
                                       raw_reg_p,
                                       sizeof(struct ku_raw_reg),
                                       &ifc_params));
}

sxd_status_t sxd_command_ifc_access_reg_raw_buff(sxd_command_ifc_hw_t *hw_p,
                                                 sxd_dev_id_t          dev_id,
                                                 struct ku_raw_reg    *raw_buff_p)
{
    sxd_status_t                  sxd_err = SXD_STATUS_SUCCESS;
    struct ku_access_reg_raw_buff access_reg_buff;
    struct access_reg_ifc_params  ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_RAW_BUFF
    };

    SX_LOG_ENTER();
    memset(&access_reg_buff, 0, sizeof(access_reg_buff));

    /******** INPUTS CHECK ********/
    if (raw_buff_p == NULL) {
        SX_LOG_ERR("raw_buff_p is NULL \n");
        sxd_err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    /* set target device id */
    access_reg_buff.dev_id = dev_id;
    access_reg_buff.raw_buff.size = raw_buff_p->size;
    access_reg_buff.raw_buff.buff = raw_buff_p->buff;

    sxd_err = sxd_command_ifc_access_general(hw_p, &access_reg_buff, (struct access_ifc_params *)&ifc_params);
    if (sxd_err != SXD_STATUS_SUCCESS) {
        SX_LOG(SX_LOG_ERROR, " %s Failed - (CTRL_CMD_ACCESS_REG_RAW_BUFF) \n", __func__);
        goto out;
    }

out:
    SX_LOG_EXIT();
    return (sxd_err);
}

sxd_status_t sxd_command_ifc_access_pmaos_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_pmaos_reg  *pmaos_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PMAOS, pmaos)
}


sxd_status_t sxd_command_ifc_access_ppsc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_ppsc_reg   *ppsc_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PPSC, ppsc)
}

sxd_status_t sxd_command_ifc_access_slcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_slcr_reg   *slcr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SLCR, slcr)
}

sxd_status_t sxd_command_ifc_access_sspr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_sspr_reg   *sspr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SSPR, sspr)
}


sxd_status_t sxd_command_ifc_access_spmcr_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_spmcr_reg  *spmcr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SPMCR, spmcr)
}

sxd_status_t sxd_command_ifc_access_sbmm_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_sbmm_reg   *sbmm_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SBMM, sbmm)
}

sxd_status_t sxd_command_ifc_access_smid_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_smid_reg   *smid_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SMID, smid)
}


sxd_status_t sxd_command_ifc_access_spms_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_spms_reg   *spms_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SPMS, spms)
}

sxd_status_t sxd_command_ifc_access_qpbr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_qpbr_reg   *qpbr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(QPBR, qpbr)
}

sxd_status_t sxd_command_ifc_access_qpem_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_qpem_reg   *qpem_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(QPEM, qpem)
}

sxd_status_t sxd_command_ifc_access_plbf_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_plbf_reg   *plbf_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PLBF, plbf)
}

sxd_status_t sxd_command_ifc_access_sgcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_sgcr_reg   *sgcr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SGCR, sgcr)
}

sxd_status_t sxd_command_ifc_access_msci_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_msci_reg   *msci_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MSCI, msci)
}

sxd_status_t sxd_command_ifc_access_mrsr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mrsr_reg   *mrsr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MRSR, mrsr)
}

sxd_status_t sxd_command_ifc_access_mpsc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mpsc_reg   *mpsc_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MPSC, mpsc)
}

sxd_status_t sxd_command_ifc_access_rgcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_rgcr_reg   *rgcr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(RGCR, rgcr)
}

sxd_status_t sxd_command_ifc_access_rtps_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_rtps_reg   *rtps_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(RTPS, rtps)
}

sxd_status_t sxd_command_ifc_access_rtca_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_rtca_reg   *rtca_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(RTCA, rtca)
}

sxd_status_t sxd_command_ifc_access_ruft_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_ruft_reg   *ruft_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(RUFT, ruft)
}

sxd_status_t sxd_command_ifc_access_rdpm_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_rdpm_reg   *rdpm_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(RDPM, rdpm)
}

sxd_status_t sxd_command_ifc_access_mlcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mlcr_reg   *mlcr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MLCR, mlcr)
}

sxd_status_t sxd_command_ifc_access_mdri_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_mdri_reg   *mdri_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MDRI, mdri)
}

sxd_status_t sxd_command_ifc_access_mpgcr_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_mpgcr_reg  *mpgcr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MPGCR, mpgcr)
}

sxd_status_t sxd_command_ifc_access_mpilm_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_mpilm_reg  *mpilm_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MPILM, mpilm)
}

sxd_status_t sxd_command_ifc_access_mcion_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_mcion_reg  *mcion_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(MCION, mcion)
}

sxd_status_t sxd_command_ifc_access_qpcr_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_qpcr_reg   *qpcr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(QPCR, qpcr)
}

sxd_status_t sxd_command_ifc_access_sfn_reg(sxd_command_ifc_hw_t *hw_p,
                                            sxd_access_cmd_t      access_cmd,
                                            sxd_dev_id_t          dev_id,
                                            struct ku_sfn_reg    *sfn_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SFN, sfn)
}

sxd_status_t sxd_command_ifc_access_spvtr_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_spvtr_reg  *spvtr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SPVTR, spvtr)
}

sxd_status_t sxd_command_ifc_access_cwtp_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_cwtp_reg   *cwtp_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(CWTP, cwtp)
}

sxd_status_t sxd_command_ifc_access_pfcc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_pfcc_reg   *pfcc_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(PFCC, pfcc)
}

sxd_status_t sxd_command_ifc_access_qppm_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_qppm_reg   *qppm_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(QPPM, qppm)
}

sxd_status_t sxd_command_ifc_access_slecr_reg(sxd_command_ifc_hw_t *hw_p,
                                              sxd_access_cmd_t      access_cmd,
                                              sxd_dev_id_t          dev_id,
                                              struct ku_slecr_reg  *slecr_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SLECR, slecr)
}

sxd_status_t sxd_command_ifc_access_spvc_reg(sxd_command_ifc_hw_t *hw_p,
                                             sxd_access_cmd_t      access_cmd,
                                             sxd_dev_id_t          dev_id,
                                             struct ku_spvc_reg   *spvc_reg_p)
{
    SXD_COMMAND_IFC_ACCESS_REG(SPVC, spvc)
}
