/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#define _GNU_SOURCE /* unistd.h --> TEMP_FAILURE_RETRY */

#include <complib/cl_map.h>
#include <complib/cl_mem.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <signal.h>
#include "sx/sxd/sxdev.h"
#include "sx/sxd/kernel_user.h"
#include "sx/sxd/sxd_emad_status.h"
#ifdef SNIFFER_PRESENT
#include "sniffer/sxd_sniffer.h"
#endif

/**********************************************
 *  Type definitions
 ***********************************************/

typedef struct sxd_dev_data {
    int fd; /*<! file descriptor */
} sxd_dev_data_t;

/**********************************************
 *  Local Defines
 ***********************************************/

#define MAX_DEVS              512
#define FOREVER               1
#define FULL_PATH_EXTRA_CHARS 2

/**********************************************
 *  Local variables
 ***********************************************/

/**********************************************
 *  Global variables
 ***********************************************/

static sxd_dev_data_t *dev_arr[MAX_DEVS];
static pthread_mutex_t mtx_s = PTHREAD_MUTEX_INITIALIZER;
static const char     *sysfs_devs_path = "/dev/sxdevs";
static const char     *sysfs_sx_mod_path_s = "/sys/module/sx_core/version";
static char            sxd_driver_version[MAX_NAME_LEN] = "";

/**********************************************
 *  Local Macros
 ***********************************************/

#define MUTEX_LOCK                                 \
    if (pthread_mutex_lock(&mtx_s)) {              \
        fprintf(stderr, "failed to lock mutex\n"); \
        return -errno;                             \
    }

#define MUTEX_UNLOCK                                 \
    if (pthread_mutex_unlock(&mtx_s)) {              \
        fprintf(stderr, "failed to unlock mutex\n"); \
        return -errno;                               \
    }

#define MUTEX_UNLOCK_NO_RETURN                       \
    if (pthread_mutex_unlock(&mtx_s)) {              \
        fprintf(stderr, "failed to unlock mutex\n"); \
    }


/**********************************************
 *  Function implementations
 ***********************************************/

/**********************************************
 *  Local function declarations
 ***********************************************/

static int find_free_entry(void)
{
    int i;

    for (i = 0; i < MAX_DEVS; ++i) {
        if (!dev_arr[i]) {
            return i;
        }
    }

    return -1;
}

/**********************************************
 *  API IMPLEMENTATION
 ***********************************************/
/*
 * sxd_get_dev_list - get list of available devices
 * @param[output] devs_p - array of char pointers to contain the list of available devices by their names
 * @param[output] num_p  - size of the array. On successful return the actual number of devices it holds
 * Note the caller must provide room for device names up to MAX_NAME_LEN.
 *
 * @return: 0 success
 *          >0 array was too small. The returned value denotes the required size.
 *          <0 error
 */
int sxd_get_dev_list(char *devs_p[], uint32_t *num_p)
{
    /*check inputs*/
    if ((devs_p == NULL) || (num_p == NULL) || (*num_p == 0)) {
        return -EINVAL;
    }

    strncpy(devs_p[0], SYSFS_CDEV_CORE, strlen(SYSFS_CDEV_CORE) + 1);
    *num_p = 1;
    return 0;

#if 0 /* when removed #if 0, need to remove #if 0  also from sort_entries function and strswap function */
    DIR           *dirl = NULL;
    struct dirent *dirent = NULL;
    uint32_t       files_counter = 0;
    int            ret = 0;
    int            size = 0;
    uint32_t       i = 0;

    /*check inputs*/
    if ((devs_p == NULL) || (num_p == NULL)) {
        return -EINVAL;
    }

    /* open the devices directory */
    dirl = opendir(sysfs_devs_path);
    if (!dirl) {
        return -ENOENT;
    }

    files_counter = 0;
    while (FOREVER) {
        dirent = readdir(dirl); /* read next file in devices directory */
        if (!dirent) {
            break;
        } else if (!strcmp(".", dirent->d_name)) {
            continue;
        } else if (!strcmp("..", dirent->d_name)) {
            continue;
        } else if (files_counter < *num_p) {
            size = strlen(dirent->d_name);
            strncpy(devs_p[files_counter], dirent->d_name, size);
            devs_p[files_counter][size] = '\0';
        }
        files_counter++;
    }

    /* update files number variable*/
    if (num_p[0] < files_counter) {
        ret = files_counter;
    } else {
        num_p[0] = files_counter;
        sort_entries(devs_p, files_counter);

        for (i = 0; i < num_p[0]; i++) {
            if (strcmp(devs_p[i], SYSFS_CDEV_CORE) == 0) {
                strncpy(devs_p[i], devs_p[0], MAX_NAME_LEN);
                strncpy(devs_p[0], SYSFS_CDEV_CORE, MAX_NAME_LEN);
                break;
            }
        }
    }

    /* close devices directory */
    closedir(dirl);
    return ret;
#endif /* if 0 */
}
/*
 * sxd_open_device - open a device and get a handle for it
 * @param[input]  dev_p    - name of the device to be opened
 * @param[output] handle_p - pointer to handle to the device
 *
 * Only one application can open the handle for a device and it can do it only
 * once.
 *
 * returns: 0      - success
 *	        ENOENT - file not found
 *		    EBUSY  - device already used
 *	        EINVAL - invalid parameter
 */
int sxd_open_device(const char * dev_p, sxd_handle *handle_p)
{
    int       fd = -1;
    int       err = 0;
    boolean_t device_opened = FALSE;

    if ((handle_p == NULL) || (dev_p == NULL)) {
        err = -EINVAL;
        goto out;
    }

    err = sxd_open_device_ext(dev_p, &fd);
    if (err != 0) {
        goto out;
    }
    if (fd == -1) {
        err = ENOENT;
        goto out;
    }
    device_opened = TRUE;

    err = sxd_get_new_handle(fd, handle_p);
    if (err != 0) {
        goto out;
    }

out:
    if (err != 0) {
        if (device_opened) {
            sxd_close_device_ext(fd);
        }
    }
    return err;
}

/*
 *
 * sxd_close_device - close the handle to the device
 * @param[input] handle - handle to the device that should be closed
 *
 * returns: EINVAL - device not found
 *          EBUSY  - device is in use and cannot be closed
 */
int sxd_close_device(sxd_handle handle)
{
    int err = -1;

    MUTEX_LOCK;

    if (dev_arr[handle]) {
        /* close the fd */
        err = close(dev_arr[handle]->fd);

        if (err == -1) {
            err = -errno;
            goto out;
        }

        /* free the memory of the device info */
        cl_free(dev_arr[handle]);
        dev_arr[handle] = NULL;
        err = 0;
    } else {
        err = -EINVAL;
    }

out:
    MUTEX_UNLOCK;
    return err;
}

/*
 * sxd_send - send a packet to the network
 * @param[input] handle    - handle to the device that should send the packet
 * @param[input] pack_p    - a pointer to a struct containing the packet and control information
 * @param[input] pack_size - pack size
 *
 * returns: 0>       - number of packets transmitted
 *          EAGAIN  - packet could not be queued, try again
 *          EACCESS - cannot send packet due to e.g. link is down
 */
int sxd_send(sxd_handle handle, struct ku_write *pack_p, uint32_t pack_size)
{
    int err = -1;
    int fd = -1;

    if (pack_p == NULL) {
        return -EINVAL;
    }

    MUTEX_LOCK;
    /* get file descriptor from the devices array */
    fd = dev_arr[handle] != 0 ? dev_arr[handle]->fd : -1;
    MUTEX_UNLOCK;

    if (fd != -1) {
        err = write(fd, pack_p, pack_size);
        if (err < 0) {
            fprintf(stderr, "write failed: %s.\n", strerror(errno));
        }
    } else {
        err = -ENODEV;
    }

    return err;
}

/*
 * sxd_recv - receive a packet form the network
 * @param[input]  handle        -  handle to the device which should receive a packet
 * @param[in/out] size_read_p   -  sizeof buffer / number of bytes read
 * @param[output] buffer_p      -  pointer to a buffer containing one/multiple packets
 * dev_name
 * returns: > 0 packet received - buffer_p field contains the packet/s.
 *	        EAGAIN - no packet received - can happen when the BX_FLAG_RCV_NBLOCK was set
 *                   in the flags field of pack and no packet was pending
 *          ENOMEM - buffer size was too small
 *          EINTR  - signal delivered
 *          EBUSY  - another call to receive is pending
 */
int sxd_recv(sxd_handle handle, char *buffer_p, int *size_read_p)
{
    int err = -1;
    int fd = -1;

    if ((buffer_p == NULL) || (size_read_p == NULL)) {
        return -EINVAL;
    }

    MUTEX_LOCK;
    /* get file descriptor from the devices array */
    fd = dev_arr[handle] != 0 ? dev_arr[handle]->fd : -1;
    MUTEX_UNLOCK;

    if (fd != -1) {
        err = read(fd, buffer_p, (size_t)size_read_p[0]);

        if (err >= 0) {
            *size_read_p = err;
        }
    } else {
        err = -ENODEV;
    }

    return err;
}

/*
 * sxd_ioctl - configure the device and retrieve information from the driver
 * @param[input] handle - handle to the device which should send/receive the packet
 * @param[input] pack_p - information packed for configuring or retrieved from the device
 *
 * returns: 0      - success
 *          EINVAL - invalid operation
 */
static int __sxd_ioctl(sxd_handle handle, sxd_ctrl_pack_t *pack_p)
{
    int     err = -1;
    int     fd = -1;
    uint8_t status = 0;
    int     retry_count = 0;

    if (pack_p == NULL) {
        return -EINVAL;
    }

    MUTEX_LOCK;
    /* get file descriptor from the devices array */
    fd = dev_arr[handle] != 0 ? dev_arr[handle]->fd : -1;
    MUTEX_UNLOCK;

    if (fd != -1) {
        err = TEMP_FAILURE_RETRY(ioctl(fd, pack_p->ctrl_cmd, pack_p->cmd_body));
        if (err) {
            return err;
        } else {
            if (CTRL_CMD_ACCESS_REG_CHECK_RANGE(pack_p->ctrl_cmd)) {
                status = ((struct ku_operation_tlv*)(pack_p->cmd_body))->status;
                while (retry_count < NUM_OF_RETRIES && SXD_EMAD_STATUS_DEVICE_IS_BUSY == status) {
                    usleep(RETRY_WAIT_TIME);
                    err = TEMP_FAILURE_RETRY(ioctl(fd, pack_p->ctrl_cmd, pack_p->cmd_body));
                    if (!err) {
                        status = ((struct ku_operation_tlv*)(pack_p->cmd_body))->status;
                        retry_count++;
                    } else {
                        break;
                    }
                }
            }
        }
    } else {
        err = -ENODEV;
    }

    return err;
}

int sxd_ioctl(sxd_handle handle, sxd_ctrl_pack_t *pack_p)
{
#ifdef SNIFFER_PRESENT
    return sxd_sniffer_sxd_ioctl(handle, pack_p, __sxd_ioctl);
#else
    return __sxd_ioctl(handle, pack_p);
#endif
}


int sxd_memory_map(sxd_handle handle, size_t length, void **ret)
{
    int fd, rc = 0;

    MUTEX_LOCK;
    /* get file descriptor from the devices array */
    fd = dev_arr[handle] != 0 ? dev_arr[handle]->fd : -1;
    MUTEX_UNLOCK;

    if (fd != -1) {
        *ret = mmap(NULL, length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
        if (*ret == MAP_FAILED) {
            rc = -errno;
        }
    } else {
        rc = -ENODEV;
    }

    return rc;
}


int sxd_memory_unmap(void *addr, size_t length)
{
    return munmap(addr, length);
}

/*
 * sxd_fd_get - retrieve the file descriptor used by 'handle'
 * @param[input] handle - handle to the device which should send/receive the packet
 * @param[input] fd_p   - file descriptor
 *
 * returns: 0      - success
 *          ENODEV - can't retrieve file descriptor
 */
int sxd_fd_get(sxd_handle handle, int *fd_p)
{
    int err = -1;
    int fd = -1;

    if (fd_p == NULL) {
        return -EINVAL;
    }

    MUTEX_LOCK;
    /* get file descriptor from the devices array */
    fd = dev_arr[handle] != 0 ? dev_arr[handle]->fd : -1;
    MUTEX_UNLOCK;

    if (fd != -1) {
        fd_p[0] = fd;
        err = 0;
    } else {
        err = -ENODEV;
    }
    return err;
}

const char * sxd_get_driver_version()
{
    char  sx_core_mod_version[MAX_NAME_LEN];
    FILE *f = NULL;

    if (sxd_driver_version[0]) {
        goto out;
    }

    f = fopen(sysfs_sx_mod_path_s, "r");
    if (!f) {
        printf("Failed opening module sx_core version sysfs file (%s)\n",
               sysfs_sx_mod_path_s);
        goto out;
    }

    if (!fgets(sx_core_mod_version, sizeof(sx_core_mod_version), f)) {
        printf("failed to get module sx_core version (%s)\n",
               strerror(errno));
        goto out;
    }

    snprintf(sxd_driver_version, sizeof(sx_core_mod_version) <
             sizeof(sxd_driver_version) ? sizeof(sx_core_mod_version) : sizeof(sxd_driver_version),
             "%s", sx_core_mod_version);
    /* coverity[overflow] */

out:
    if (f) {
        if (fclose(f)) {
            printf("Failed closing module sx_core version sysfs file (%s), (%s)\n",
                   sysfs_sx_mod_path_s, strerror(errno));
        }
    }
    return sxd_driver_version;
}

int sxd_get_new_handle(int fd, sxd_handle *handle_p)
{
    int       err = 0;
    int       device_entry = 0;
    boolean_t mutex_locked = FALSE;

    if (handle_p == NULL) {
        printf("handle_p is NULL!\n");
        err = -EINVAL;
        goto out;
    }

    if (pthread_mutex_lock(&mtx_s)) {
        printf("Failed to lock mutex, errno = [%s]\n", strerror(errno));
        err = -errno;
        goto out;
    }
    mutex_locked = TRUE;

    device_entry = find_free_entry();
    if (device_entry == -1) {
        printf("Failed to find free entry in device array!\n");
        err = -ENOMEM;
        goto out;
    }

    /* allocate memory for device info */
    dev_arr[device_entry] = cl_malloc(sizeof(sxd_dev_data_t));
    if (dev_arr[device_entry] == NULL) {
        printf("Failed to allocate memory in device array!\n");
        err = -ENOMEM;
        goto out;
    }

    dev_arr[device_entry]->fd = fd;
    *handle_p = device_entry;

out:
    if (mutex_locked) {
        MUTEX_UNLOCK;
    }
    return err;
}

int sxd_put_handle(sxd_handle handle)
{
    int err = -1;

    MUTEX_LOCK;

    if (dev_arr[handle]) {
        /* free the memory of the device info */
        cl_free(dev_arr[handle]);
        dev_arr[handle] = NULL;
        err = 0;
    } else {
        err = -EINVAL;
    }

    MUTEX_UNLOCK;
    return err;
}

int sxd_open_device_ext(const char *dev_p, int *fd_p)
{
    char *fullpath = NULL;
    int   fd = -1;

    if ((fd_p == NULL) || (dev_p == NULL)) {
        return -EINVAL;
    }

    /* allocate memory for the full path string */
    fullpath = cl_malloc(strlen(sysfs_devs_path) + strlen(dev_p) + FULL_PATH_EXTRA_CHARS);
    if (fullpath == NULL) {
        printf("no memory for device path!\n");
        return -ENOMEM;
    }

    /* prepare full path string */
    sprintf(fullpath, "%s/%s", sysfs_devs_path, dev_p);

    /* open device */
    fd = open(fullpath, O_RDWR);

    cl_free(fullpath);
    if (fd == -1) {
        printf("error: %s\n", strerror(errno));
        return -errno;
    }

    *fd_p = fd;
    return 0;
}

int sxd_close_device_ext(int fd)
{
    int err = 0;

    err = close(fd);
    if (err == -1) {
        err = -errno;
        return err;
    }

    return err;
}

#ifdef SNIFFER_PRESENT
boolean_t sxd_prm_sniffer_exists(void)
{
    return TRUE;
}
#else
boolean_t sxd_prm_sniffer_exists(void)
{
    return FALSE;
}
void sxd_prm_sniffer_activate(FILE* stream, char *file_path_p)
{
    fprintf(stream, "The PRM sniffer cannot be activated at %s \nas it is not included in this version!\n",
            file_path_p);
    return;
}
void sxd_prm_sniffer_deactivate(FILE* stream)
{
    fprintf(stream, "The PRM sniffer cannot be deactivated as it is not included in this version!\n");
    return;
}
#endif
