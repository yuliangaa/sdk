/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_ROUTER_H__
#define __SXD_ROUTER_H__

#include <complib/cl_types.h>
#include <sx/sxd/sxd_check.h>

/************************************************
 *  Local Defines
 ***********************************************/


/************************************************
 *  Local Macros
 ***********************************************/


/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/

/**
 * Virtual Router ID minimum/maximum values.
 */
#define SXD_VRID_MIN (0x00)
#define SXD_VRID_MAX (0x07)

#define SXD_VRID_CHECK_RANGE(VRID) SXD_CHECK_MAX(VRID, SXD_VRID_MAX)

/**
 * Router Interface minimum/maximum values.
 */
#define SXD_RIF_MIN (0x0000)
#define SXD_RIF_MAX (0x00FE)

#define SXD_RIF_CHECK_RANGE(RIF) SXD_CHECK_MAX(RIF, SXD_RIF_MAX)

/**
 * Router Interface minimum/maximum values.
 */
#define SXD_RIF_GROUP_MIN (0x0000)
#define SXD_RIF_GROUP_MAX (0x1FFF)

#define SXD_RIF_GROUP_CHECK_RANGE(RIF_GROUP) \
    SXD_CHECK_MAX(RIF_GROUP, SXD_RIF_GROUP_MAX)

/**
 * RIGR Router Interface maximum number.
 */
#define SXD_RIGR_RIF_MAX (0x0080)

/**
 * ECMP Hash minimum/maximum values.
 */
#define SXD_ROUTER_ECMP_HASH_MIN (0x0000)
#define SXD_ROUTER_ECMP_HASH_MAX (0x007F)

#define SXD_ROUTER_ECMP_HASH_CHECK_RANGE(ECMP_HASH) \
    SXD_CHECK_MAX(ECMP_HASH, SXD_ROUTER_ECMP_HASH_MAX)

/**
 * ARP ID minimum/maximum values.
 */
#define SXD_ARP_ID_MIN (0x0000)
#define SXD_ARP_ID_MAX (0x1F3F)          /*ARP table size is 8k, fw use 192 entries for isx*/

#define SXD_ARP_ID_CHECK_RANGE(ARP_ID) SXD_CHECK_MAX(ARP_ID, SXD_ARP_ID_MAX)

/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_router_ecmp_hash_e enumerated type is used to store router ECMP hashing
 * configuration.
 */
typedef enum sxd_router_ecmp_hash {
    SXD_ROUTER_ECMP_HASH_SRC_IP_E           = (1 << 0),
    SXD_ROUTER_ECMP_HASH_DST_IP_E           = (1 << 1),
    SXD_ROUTER_ECMP_HASH_TCLASS_E           = (1 << 2),
    SXD_ROUTER_ECMP_HASH_FLOW_LABEL_E       = (1 << 3),
    SXD_ROUTER_ECMP_HASH_TCP_UDP_E          = (1 << 4),
    SXD_ROUTER_ECMP_HASH_TCP_UDP_SRC_PORT_E = (1 << 5),
    SXD_ROUTER_ECMP_HASH_TCP_UDP_DST_PORT_E = (1 << 6),
} sxd_router_ecmp_hash_e;

typedef enum sxd_global_counters {
    SXD_ROUTER_INTERFACE_COUNTERS_E = 0,
    SXD_ROUTER_INGRESS_COUNTERS_E,
    SXD_ROUTER_EGRESS_COUNTERS_E,
} sxd_global_counters_e;

/**
 * sxd_router_ecmp_pp_type_t enumerated type is used to store the per-port
 * configuration type.
 */
typedef enum sxd_router_ecmp_pp_type {
    SXD_ROUTER_ECMP_PP_TYPE_GLOBAL   = 0,
    SXD_ROUTER_ECMP_PP_TYPE_PER_PORT = 1,
} sxd_router_ecmp_pp_type_t;

/**
 * sxd_router_ecmp_general_fields_t enumerated type is a bitmap in which each bit
 * enables a specific field to be included in the hash calculation.
 */
typedef enum sxd_router_ecmp_general_fields {
    SXD_ROUTER_ECMP_GENERAL_FIELDS_INGRESS_PORT_NUMBER = 1 << 0,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_0       = 1 << 2,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_1       = 1 << 3,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_2       = 1 << 4,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_3       = 1 << 5,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_4       = 1 << 6,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_5       = 1 << 7,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_6       = 1 << 8,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_7       = 1 << 9,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_8       = 1 << 10,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_9       = 1 << 11,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_10      = 1 << 12,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_11      = 1 << 13,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_12      = 1 << 14,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_13      = 1 << 15,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_14      = 1 << 16,
    SXD_ROUTER_ECMP_GENERAL_FIELDS_CUSTOM_BYTE_15      = 1 << 17,
} sxd_router_ecmp_general_fields_t;

/**
 * sxd_router_ecmp_outer_header_enables_t enumerated type is a bitmap in which
 * each bit enables a specific layer field to be included in the hash calculation.
 * A field is included in the hash only if both its header is enabled and its
 * specific field is enabled.
 */
typedef enum sxd_router_ecmp_outer_header_enables {
    SXD_ROUTER_ECMP_OHE_L2_NON_IP        = 1 << 0,
    SXD_ROUTER_ECMP_OHE_L2_IPV4          = 1 << 1,
    SXD_ROUTER_ECMP_OHE_L2_IPV6          = 1 << 2,
    SXD_ROUTER_ECMP_OHE_IPV4_NON_TCP_UDP = 1 << 3,
    SXD_ROUTER_ECMP_OHE_IPV4_TCP_UDP     = 1 << 4,
    SXD_ROUTER_ECMP_OHE_IPV6_NON_TCP_UDP = 1 << 5,
    SXD_ROUTER_ECMP_OHE_IPV6_TCP_UDP     = 1 << 6,
    SXD_ROUTER_ECMP_OHE_L4_IPV4_ENABLE   = 1 << 7,
    SXD_ROUTER_ECMP_OHE_L4_IPV6_ENABLE   = 1 << 8,
} sxd_router_ecmp_outer_header_enables_t;

/**
 * sxd_router_ecmp_inner_header_enables_t enumerated type is a bitmap in which
 * each bit enables a specific layer field to be included in the hash calculation.
 * A field is included in the hash only if both its header is enabled and its
 * specific field is enabled.
 */
typedef enum sxd_router_ecmp_inner_header_enables {
    SXD_ROUTER_ECMP_IHE_L2_NON_IP        = 1 << 0,
    SXD_ROUTER_ECMP_IHE_L2_IPV4          = 1 << 1,
    SXD_ROUTER_ECMP_IHE_L2_IPV6          = 1 << 2,
    SXD_ROUTER_ECMP_IHE_IPV4_NON_TCP_UDP = 1 << 3,
    SXD_ROUTER_ECMP_IHE_IPV4_TCP_UDP     = 1 << 4,
    SXD_ROUTER_ECMP_IHE_IPV6_NON_TCP_UDP = 1 << 5,
    SXD_ROUTER_ECMP_IHE_IPV6_TCP_UDP     = 1 << 6,
    SXD_ROUTER_ECMP_IHE_L4_IPV4_ENABLE   = 1 << 7,
    SXD_ROUTER_ECMP_IHE_L4_IPV6_ENABLE   = 1 << 8,
} sxd_router_ecmp_inner_header_enables_t;

/**
 * sxd_router_ecmp_outer_header_field_enables_t enumerated type is a bitmap in which
 * each bit enables a specific field to be included in the hash calculation.
 * A field is included in the hash only if both its header is enabled and its
 * specific field is enabled.
 */
typedef enum sxd_router_ecmp_outer_header_field_enables {
    /** Bits of first DWORD */
    SXD_ROUTER_ECMP_OHFE_SMAC                  = 1 << 0,
    SXD_ROUTER_ECMP_OHFE_DMAC                  = 1 << 1,
    SXD_ROUTER_ECMP_OHFE_ETHERTYPE             = 1 << 2,
    SXD_ROUTER_ECMP_OHFE_OUTER_VID             = 1 << 3,
    SXD_ROUTER_ECMP_OHFE_OUTER_PCP             = 1 << 4,
    SXD_ROUTER_ECMP_OHFE_OUTER_CFI             = 1 << 5,
    SXD_ROUTER_ECMP_OHFE_INNER_VID             = 1 << 6,
    SXD_ROUTER_ECMP_OHFE_INNER_PCP             = 1 << 7,
    SXD_ROUTER_ECMP_OHFE_INNER_CFI             = 1 << 8,
    SXD_ROUTER_ECMP_OHFE_IPV4_SIP_BYTE_0       = 1 << 9,
    SXD_ROUTER_ECMP_OHFE_IPV4_SIP_BYTE_1       = 1 << 10,
    SXD_ROUTER_ECMP_OHFE_IPV4_SIP_BYTE_2       = 1 << 11,
    SXD_ROUTER_ECMP_OHFE_IPV4_SIP_BYTE_3       = 1 << 12,
    SXD_ROUTER_ECMP_OHFE_IPV4_DIP_BYTE_0       = 1 << 13,
    SXD_ROUTER_ECMP_OHFE_IPV4_DIP_BYTE_1       = 1 << 14,
    SXD_ROUTER_ECMP_OHFE_IPV4_DIP_BYTE_2       = 1 << 15,
    SXD_ROUTER_ECMP_OHFE_IPV4_DIP_BYTE_3       = 1 << 16,
    SXD_ROUTER_ECMP_OHFE_IPV4_PROTOCOL         = 1 << 17,
    SXD_ROUTER_ECMP_OHFE_IPV4_DSCP             = 1 << 18,
    SXD_ROUTER_ECMP_OHFE_IPV4_ECN              = 1 << 19,
    SXD_ROUTER_ECMP_OHFE_IPV4_IP_L3_LENGTH     = 1 << 20,
    SXD_ROUTER_ECMP_OHFE_IPV6_SIP_BYTES_0_TO_7 = 1 << 21,
    SXD_ROUTER_ECMP_OHFE_IPV6_SIP_BYTE_8       = 1 << 29,
    SXD_ROUTER_ECMP_OHFE_IPV6_SIP_BYTE_9       = 1 << 30,
    SXD_ROUTER_ECMP_OHFE_IPV6_SIP_BYTE_10      = 1 << 31,

    /** Bits of second DWORD */
    SXD_ROUTER_ECMP_OHFE_IPV6_SIP_BYTE_11       = 1 << 0,
    SXD_ROUTER_ECMP_OHFE_IPV6_SIP_BYTE_12       = 1 << 1,
    SXD_ROUTER_ECMP_OHFE_IPV6_SIP_BYTE_13       = 1 << 2,
    SXD_ROUTER_ECMP_OHFE_IPV6_SIP_BYTE_14       = 1 << 3,
    SXD_ROUTER_ECMP_OHFE_IPV6_SIP_BYTE_15       = 1 << 4,
    SXD_ROUTER_ECMP_OHFE_IPV6_DIP_BYTES_0_TO_7  = 1 << 5,
    SXD_ROUTER_ECMP_OHFE_IPV6_DIP_BYTE_8        = 1 << 13,
    SXD_ROUTER_ECMP_OHFE_IPV6_DIP_BYTE_9        = 1 << 14,
    SXD_ROUTER_ECMP_OHFE_IPV6_DIP_BYTE_10       = 1 << 15,
    SXD_ROUTER_ECMP_OHFE_IPV6_DIP_BYTE_11       = 1 << 16,
    SXD_ROUTER_ECMP_OHFE_IPV6_DIP_BYTE_12       = 1 << 17,
    SXD_ROUTER_ECMP_OHFE_IPV6_DIP_BYTE_13       = 1 << 18,
    SXD_ROUTER_ECMP_OHFE_IPV6_DIP_BYTE_14       = 1 << 19,
    SXD_ROUTER_ECMP_OHFE_IPV6_DIP_BYTE_15       = 1 << 20,
    SXD_ROUTER_ECMP_OHFE_IPV6_NEXT_HEADER       = 1 << 21,
    SXD_ROUTER_ECMP_OHFE_IPV6_DSCP              = 1 << 22,
    SXD_ROUTER_ECMP_OHFE_IPV6_ECN               = 1 << 23,
    SXD_ROUTER_ECMP_OHFE_IPV6_IP_L3_LENGTH      = 1 << 24,
    SXD_ROUTER_ECMP_OHFE_IPV6_FLOW_LABEL        = 1 << 25,
    SXD_ROUTER_ECMP_OHFE_ROCE_GRH_SIP           = 1 << 26,
    SXD_ROUTER_ECMP_OHFE_ROCE_GRH_DIP           = 1 << 27,
    SXD_ROUTER_ECMP_OHFE_ROCE_GRH_NEXT_PROTOCOL = 1 << 28,
    SXD_ROUTER_ECMP_OHFE_ROCE_GRH_DSCP          = 1 << 29,
    SXD_ROUTER_ECMP_OHFE_ROCE_GRH_ECN           = 1 << 30,
    SXD_ROUTER_ECMP_OHFE_ROCE_GRH_L3_LENGTH     = 1 << 31,

    /** Bits of third DWORD */
    SXD_ROUTER_ECMP_OHFE_ROCE_GRH_FLOW_LABEL = 1 << 0,
    SXD_ROUTER_ECMP_OHFE_FCOE_SID            = 1 << 1,
    SXD_ROUTER_ECMP_OHFE_FCOE_DID            = 1 << 2,
    SXD_ROUTER_ECMP_OHFE_FCOE_OXID           = 1 << 3,
    SXD_ROUTER_ECMP_OHFE_MPLS_LABEL_0        = 1 << 4,
    SXD_ROUTER_ECMP_OHFE_MPLS_LABEL_1        = 1 << 5,
    SXD_ROUTER_ECMP_OHFE_MPLS_LABEL_2        = 1 << 6,
    SXD_ROUTER_ECMP_OHFE_MPLS_LABEL_3        = 1 << 7,
    SXD_ROUTER_ECMP_OHFE_MPLS_LABEL_4        = 1 << 8,
    SXD_ROUTER_ECMP_OHFE_MPLS_LABEL_5        = 1 << 9,
    SXD_ROUTER_ECMP_OHFE_TCP_UDP_SPORT       = 1 << 10,
    SXD_ROUTER_ECMP_OHFE_TCP_UDP_DPORT       = 1 << 11,
    SXD_ROUTER_ECMP_OHFE_BTH_DQPN            = 1 << 12,
    SXD_ROUTER_ECMP_OHFE_BTH_PKEY            = 1 << 13,
    SXD_ROUTER_ECMP_OHFE_BTH_OPCODE          = 1 << 14,
    SXD_ROUTER_ECMP_OHFE_DETH_QKEY           = 1 << 15,
    SXD_ROUTER_ECMP_OHFE_DETH_SQPN           = 1 << 16,
    SXD_ROUTER_ECMP_OHFE_VNI                 = 1 << 17,
    SXD_ROUTER_ECMP_OHFE_NVGRE_FLOW          = 1 << 18,
    SXD_ROUTER_ECMP_OHFE_NVGRE_PROTOCOL      = 1 << 19,
} sxd_router_ecmp_outer_header_field_enables_t;

/**
 * sxd_router_ecmp_inner_header_field_enables_t enumerated type is a bitmap in which
 * each bit enables a specific field to be included in the hash calculation.
 * A field is included in the hash only if both its header is enabled and its
 * specific field is enabled.
 */
typedef enum sxd_router_ecmp_inner_header_field_enables {
    SXD_ROUTER_ECMP_IHFE_SMAC                  = 1ULL << 0,
    SXD_ROUTER_ECMP_IHFE_DMAC                  = 1ULL << 1,
    SXD_ROUTER_ECMP_IHFE_ETHERTYPE             = 1ULL << 2,
    SXD_ROUTER_ECMP_IHFE_IPV4_SIP_BYTE_0       = 1ULL << 3,
    SXD_ROUTER_ECMP_IHFE_IPV4_SIP_BYTE_1       = 1ULL << 4,
    SXD_ROUTER_ECMP_IHFE_IPV4_SIP_BYTE_2       = 1ULL << 5,
    SXD_ROUTER_ECMP_IHFE_IPV4_SIP_BYTE_3       = 1ULL << 6,
    SXD_ROUTER_ECMP_IHFE_IPV4_DIP_BYTE_0       = 1ULL << 7,
    SXD_ROUTER_ECMP_IHFE_IPV4_DIP_BYTE_1       = 1ULL << 8,
    SXD_ROUTER_ECMP_IHFE_IPV4_DIP_BYTE_2       = 1ULL << 9,
    SXD_ROUTER_ECMP_IHFE_IPV4_DIP_BYTE_3       = 1ULL << 10,
    SXD_ROUTER_ECMP_IHFE_IPV4_PROTOCOL         = 1ULL << 11,
    SXD_ROUTER_ECMP_IHFE_IPV6_SIP_BYTES_0_TO_7 = 1ULL << 12,
    SXD_ROUTER_ECMP_IHFE_IPV6_SIP_BYTE_8       = 1ULL << 20,
    SXD_ROUTER_ECMP_IHFE_IPV6_SIP_BYTE_9       = 1ULL << 21,
    SXD_ROUTER_ECMP_IHFE_IPV6_SIP_BYTE_10      = 1ULL << 22,
    SXD_ROUTER_ECMP_IHFE_IPV6_SIP_BYTE_11      = 1ULL << 23,
    SXD_ROUTER_ECMP_IHFE_IPV6_SIP_BYTE_12      = 1ULL << 24,
    SXD_ROUTER_ECMP_IHFE_IPV6_SIP_BYTE_13      = 1ULL << 25,
    SXD_ROUTER_ECMP_IHFE_IPV6_SIP_BYTE_14      = 1ULL << 26,
    SXD_ROUTER_ECMP_IHFE_IPV6_SIP_BYTE_15      = 1ULL << 27,
    SXD_ROUTER_ECMP_IHFE_IPV6_DIP_BYTES_0_TO_7 = 1ULL << 28,
    SXD_ROUTER_ECMP_IHFE_IPV6_DIP_BYTE_8       = 1ULL << 36,
    SXD_ROUTER_ECMP_IHFE_IPV6_DIP_BYTE_9       = 1ULL << 37,
    SXD_ROUTER_ECMP_IHFE_IPV6_DIP_BYTE_10      = 1ULL << 38,
    SXD_ROUTER_ECMP_IHFE_IPV6_DIP_BYTE_11      = 1ULL << 39,
    SXD_ROUTER_ECMP_IHFE_IPV6_DIP_BYTE_12      = 1ULL << 40,
    SXD_ROUTER_ECMP_IHFE_IPV6_DIP_BYTE_13      = 1ULL << 41,
    SXD_ROUTER_ECMP_IHFE_IPV6_DIP_BYTE_14      = 1ULL << 42,
    SXD_ROUTER_ECMP_IHFE_IPV6_DIP_BYTE_15      = 1ULL << 43,
    SXD_ROUTER_ECMP_IHFE_IPV6_NEXT_HEADER      = 1ULL << 44,
    SXD_ROUTER_ECMP_IHFE_IPV6_FLOW_LABEL       = 1ULL << 45,
    SXD_ROUTER_ECMP_IHFE_TCP_UDP_SPORT         = 1ULL << 46,
    SXD_ROUTER_ECMP_IHFE_TCP_UDP_DPORT         = 1ULL << 47,
    SXD_ROUTER_ECMP_IHFE_ROCE_BTH_DQPN         = 1ULL << 48,
    SXD_ROUTER_ECMP_IHFE_ROCE_BTH_PKEY         = 1ULL << 49,
    SXD_ROUTER_ECMP_IHFE_ROCE_BTH_OPCODE       = 1ULL << 50,
    SXD_ROUTER_ECMP_IHFE_ROCE_DETH_QKEY        = 1ULL << 51,
    SXD_ROUTER_ECMP_IHFE_ROCE_DETH_SQPN        = 1ULL << 52,
} sxd_router_ecmp_inner_header_field_enables_t;

/************************************************
 *  Global variables
 ***********************************************/


/************************************************
 *  Function declarations
 ***********************************************/


#endif /* __SXD_ROUTER_H__ */
