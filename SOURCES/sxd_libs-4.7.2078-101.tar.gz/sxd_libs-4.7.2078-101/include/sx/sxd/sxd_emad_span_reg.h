/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_SPAN_REG_H__
#define __SXD_EMAD_SPAN_REG_H__

#include <sx/sxd/sxd_types.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#include <complib/cl_packon.h>

/**
 * sxd_emad_mpar_reg_t structure is used to store MPAR register
 * layout.
 */
typedef struct sxd_emad_mpar_reg {
    uint8_t  mngr_type;
    uint8_t  local_port;
    uint8_t  sub_port;
    uint8_t  i_e_lp_msb;
    uint8_t  enable;
    net16_t  reserved1;
    uint8_t  pa_id;
    uint32_t probability_rate;
} PACK_SUFFIX sxd_emad_mpar_reg_t;

/**
 * sxd_emad_sbib_reg_t structure is used to store SBIB register
 * layout.
 */
typedef struct sxd_emad_sbib_reg {
    uint8_t  type;
    uint8_t  local_port;
    uint8_t  lp_msb;
    uint8_t  int_buff_index;
    uint8_t  status;
    uint8_t  reserved2[3];
    uint32_t buff_size;
    uint8_t  reserved3[4];
} PACK_SUFFIX sxd_emad_sbib_reg_t;

#include <complib/cl_packoff.h>

#endif /* __SXD_EMAD_SPAN_REG_H__ */
