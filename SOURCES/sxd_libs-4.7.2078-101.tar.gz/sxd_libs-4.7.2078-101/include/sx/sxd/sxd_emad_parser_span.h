/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_SPAN_H__
#define __SXD_EMAD_PARSER_SPAN_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_span_data.h>
#include <sx/sxd/sxd_emad_span_reg.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_span_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                  IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_mpar(sxd_emad_mpar_data_t *mpar_data,
                                 sxd_emad_mpar_reg_t  *mpar_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_mpar(sxd_emad_mpar_data_t *mpar_data,
                                   sxd_emad_mpar_reg_t  *mpar_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sbib(sxd_emad_sbib_data_t *sbib_data,
                                 sxd_emad_sbib_reg_t  *sbib_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sbib(sxd_emad_sbib_data_t *sbib_data,
                                   sxd_emad_sbib_reg_t  *sbib_reg);

#endif /* __SXD_EMAD_PARSER_SPAN_H__ */
