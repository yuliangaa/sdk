/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_ACCESS_REGISTER_INIT_H__
#define __SXD_ACCESS_REGISTER_INIT_H__

#include <sx/sxd/sxd_emad.h>
#include <sx/sxd/sxd_emad_policer.h>
#include <sx/sxd/sxd_emad_port.h>
#include <sx/sxd/sxd_emad_mpls.h>
#include <sx/sxd/sxd_emad_redecn.h>
#include <sx/sxd/sxd_emad_cos.h>
#include <sx/sxd/sxd_emad_host.h>
#include <sx/sxd/sxd_emad_lag.h>
#include <sx/sxd/sxd_emad_fdb.h>
#include <sx/sxd/sxd_emad_mstp.h>
#include <sx/sxd/sxd_emad_system.h>
#include <sx/sxd/sxd_emad_vlan.h>
#include <sx/sxd/sxd_emad_acl.h>
#include <sx/sxd/sxd_emad_router.h>
#include <sx/sxd/sxd_emad_tunnel.h>
#include <sx/sxd/sxd_emad_rm.h>
#include <sx/sxd/sxd_emad_common_data.h>
#include <complib/sx_log.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_command_ifc.h>


/**
 * This function sets the log verbosity level of the REG ACCESS MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS operation completes successfully
 * @return SXD_STATUS_ERROR   general error
 */
sxd_status_t sxd_access_reg_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                IN sx_verbosity_level_t *verbosity_level_p);

/**
 * This function init the inner access registers infrastructure.
 * For full sxd access functionality use sxd_access_reg_init.
 */
void sxd_access_register_infra_init(void);

/**
 * This function de-init the registers infrastructure.
 * Should be called after sxd_access_register_infra_init.
 */
void sxd_access_register_infra_deinit(void);

/* use this function only when the calling process is a fork() of a parent process */
sxd_status_t sxd_access_reg_init_after_fork(uint32_t             app_id,
                                            sx_log_cb_t          logging_cb,
                                            sx_verbosity_level_t verbosity_level);

/* same as sxd_access_reg_init() but returns error if already initialized */
sxd_status_t sxd_access_reg_init_strict(uint32_t             app_id,
                                        sx_log_cb_t          logging_cb,
                                        sx_verbosity_level_t verbosity_level);

/**
 * THIS FUNCTION IS USED BY MST/MFT TOOLS! DON'T CHANGE BINARY COMPATIBILITY
 * OF THIS FUNCTION BEFORE COORDINATING IT WITH THEM!
 *
 *  This function initializes the SXD ACCESS REG library and should be
 *  called before any use of the it.
 *
 * @param[in] app_id - Calling application ID
 * @param[in] logging_cb - Call back function for log prints
 * @param[in] verbosity_level - the desired verbosity level
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - Local device initialization failed
 * @return SXD_STATUS_NO_MEMORY - EMAD pool/ transaction queue initialization failed
 */

sxd_status_t sxd_access_reg_init(uint32_t                   app_id,
                                 sx_log_cb_t                logging_cb,
                                 const sx_verbosity_level_t verbosity_level);

/**
 * THIS FUNCTION IS USED BY MST/MFT TOOLS! DON'T CHANGE BINARY COMPATIBILITY
 * OF THIS FUNCTION BEFORE COORDINATING IT WITH THEM!
 *
 *  This function deinitializes the SXD ACCESS REG library. Further
 *  use of the library should not be made after it called.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_deinit(void);

/**
 * THIS FUNCTION IS USED BY MST/MFT TOOLS! DON'T CHANGE BINARY COMPATIBILITY
 * OF THIS FUNCTION BEFORE COORDINATING IT WITH THEM!
 *
 *  This function returns the maximum register size in dwords for a device.
 *  (it depends on UDPT)
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_max_size(sxd_dev_id_t dev_id, uint32_t *max_reg_size_in_dwords);

/**
 *  This function starts/stops EMAD transaction mode
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR -   setting failed
 *
 * @param[in]  enable         - enable/disable transaction mode
 */
sxd_status_t sxd_transaction_mode_set(boolean_t enable);

/**
 *  This function retrieve the EMAD transaction mode
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR -   setting failed
 *
 * @param[out]  *enable         - transaction mode state (enable/disable)
 */
sxd_status_t sxd_transaction_mode_get(boolean_t *enable);

/**
 *  This function run a device restart on a local PCI device
 *
 * @param[in] dev_id - the device to restart.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_pci_device_restart(sxd_dev_id_t dev_id);


/**
 *  This function run forcibly a device restart on a local PCI device
 *  forcibly means that there is no validation whether the device DPT is read-only.
 *
 * @param[in] dev_id - the device to restart.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 */
sxd_status_t sxd_access_reg_pci_device_restart_force(sxd_dev_id_t dev_id);


/**
 *  This function retrieve the RDQ that was allocated for SWID. if there are
 *  multiple RDQs allocated , the function returns the first one. it there are
 *  no RDQs allocated for this SWID the return value will be SXD_STATUS_RDQ_NOT_ALLOCATED
 *
 * @param[in]  swid         - switch ID
 * @param[out] rdq_p	    - RDQ number
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_NOT_INITIALIZED - library was not initialized
 * @return SXD_STATUS_RDQ_NOT_ALLOCATED - if RDQ was not allocated for this SWID
 */
sxd_status_t sxd_access_reg_swid_to_rdq(sxd_swid_t swid,
                                        uint8_t   *rdq_p);


#endif /* __SXD_ACCESS_REGISTER_INIT_H__ */
