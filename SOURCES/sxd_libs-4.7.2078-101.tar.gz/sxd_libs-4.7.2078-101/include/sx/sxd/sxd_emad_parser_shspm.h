/*
 * Copyright (C) 2015-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_SHSPM_H__
#define __SXD_EMAD_PARSER_SHSPM_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_shspm_data.h>
#include <sx/sxd/sxd_emad_shspm_reg.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t emad_parser_shspm_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                   IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function formats RALUE register layout from RALUE register data.
 *
 * @param[in] ralue_data - RALUE register data.
 * @param[out] ralue_reg - RALUE register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ralue(sxd_emad_ralue_data_t *ralue_data,
                                  sxd_emad_ralue_reg_t  *ralue_reg);

/**
 *  This function formats RALUE register data from RALUE register layout.
 *
 * @param[out] ralue_data - RALUE register data.
 * @param[in] ralue_reg - RALUE register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ralue(sxd_emad_ralue_data_t *ralue_data,
                                    sxd_emad_ralue_reg_t  *ralue_reg);

/**
 *  This function formats RALBU register layout from RALBU register data.
 *
 * @param[in] ralbu_data - RALBU register data.
 * @param[out] ralbu_reg - RALBU register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_parse_ralbu(sxd_emad_ralbu_data_t *ralbu_data,
                                  sxd_emad_ralbu_reg_t  *ralbu_reg);

/**
 *  This function formats RALBU register data from RALBU register layout.
 *
 * @param[out] ralbu_data - RALBU register data.
 * @param[in] ralbu_reg - RALBU register layout.
 *
 * @return SX_STATUS_SUCCESS if operation completes successfully.
 */
sxd_status_t sxd_emad_deparse_ralbu(sxd_emad_ralbu_data_t *ralbu_data,
                                    sxd_emad_ralbu_reg_t  *ralbu_reg);


#endif /* __SXD_EMAD_PARSER_SHSPM_H__ */
