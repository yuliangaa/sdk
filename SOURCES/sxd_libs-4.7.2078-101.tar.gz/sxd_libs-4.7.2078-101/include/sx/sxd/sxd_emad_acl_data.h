/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_ACL_DATA_H__
#define __SXD_EMAD_ACL_DATA_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_port.h>
#include <sx/sxd/sxd_emad_common_data.h>

#ifdef SXD_EMAD_ACL_DATA_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#endif

/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/**
 * sxd_emad_ptar_data_t structure is used to store PTAR register
 * data.
 */
typedef struct sxd_emad_ptar_data {
    sxd_emad_common_data_t common;
    struct ku_ptar_reg    *reg_data;
} sxd_emad_ptar_data_t;


/**
 * sxd_emad_pacl_data_t structure is used to store PACL register
 * data.
 */
typedef struct sxd_emad_pacl_data {
    sxd_emad_common_data_t common;
    struct ku_pacl_reg    *reg_data;
} sxd_emad_pacl_data_t;


/**
 * sxd_emad_ptce_ipv4_full_flags_bits enumerated type is used to
 * note Bit location for IPv4 key flags fields
 */
typedef enum sxd_emad_ptce_ipv4_full_flags_bits {
    SXD_EMAD_PTCE_IPV4_FULL_SLAG_BIT_OFFSET_E    = 6,
    SXD_EMAD_PTCE_IPV4_FULL_ARP_BIT_OFFSET_E     = 7,
    SXD_EMAD_PTCE_IPV4_FULL_UDP_BIT_OFFSET_E     = 8,
    SXD_EMAD_PTCE_IPV4_FULL_TCP_BIT_OFFSET_E     = 9,
    SXD_EMAD_PTCE_IPV4_FULL_IP_FRG_BIT_OFFSET_E  = 10,
    SXD_EMAD_PTCE_IPV4_FULL_IP_OPT_BIT_OFFSET_E  = 11,
    SXD_EMAD_PTCE_IPV4_FULL_IS_IPV6_BIT_OFFSET_E = 12,
    SXD_EMAD_PTCE_IPV4_FULL_IS_IPV4_BIT_OFFSET_E = 13,
    SXD_EMAD_PTCE_IPV4_FULL_L4_OK_BIT_OFFSET_E   = 14,
    SXD_EMAD_PTCE_IPV4_FULL_IP_OK_BIT_OFFSET_E   = 15
} sxd_emad_ptce_ipv4_full_flags_bits_e;


/**
 * sxd_emad_ptce_mac_ipv4_full_flags_bits enumerated type is
 * used to note Bit location for MAC IPv4 key flags fields
 */
typedef enum sxd_emad_ptce_mac_ipv4_full_flags_bits {
    SXD_EMAD_PTCE_MAC_IPV4_FULL_IP_FRG_BIT_OFFSET_E  = 2,
    SXD_EMAD_PTCE_MAC_IPV4_FULL_IP_OPT_BIT_OFFSET_E  = 3,
    SXD_EMAD_PTCE_MAC_IPV4_FULL_IS_IPV4_BIT_OFFSET_E = 5,
    SXD_EMAD_PTCE_MAC_IPV4_FULL_L4_OK_BIT_OFFSET_E   = 6,
    SXD_EMAD_PTCE_MAC_IPV4_FULL_IP_OK_BIT_OFFSET_E   = 7
} sxd_emad_ptce_mac_ipv4_full_flags_bits_e;

/**
 * sxd_emad_ptce_data_t structure is used to store PTCE register
 * data.
 */
typedef struct sxd_emad_ptce_data {
    sxd_emad_common_data_t common;
    struct ku_ptce_reg    *reg_data;
} sxd_emad_ptce_data_t;

/**
 * sxd_emad_ptce2_data_t structure is used to store PTCE register
 * data.
 */
typedef struct sxd_emad_ptce2_data {
    sxd_emad_common_data_t common;
    struct ku_ptce2_reg   *reg_data;
} sxd_emad_ptce2_data_t;

/**
 * sxd_emad_ptce3_data_t structure is used to store PTCE_V3 register
 * data.
 */
typedef struct sxd_emad_ptce3_data {
    sxd_emad_common_data_t common;
    struct ku_ptce3_reg   *reg_data;
} sxd_emad_ptce3_data_t;

/**
 * sxd_emad_prbt_data_t structure is used to store PTCE register
 * data.
 */
typedef struct sxd_emad_prbt_data {
    sxd_emad_common_data_t common;
    struct ku_prbt_reg    *reg_data;
} sxd_emad_prbt_data_t;

/**
 * sxd_emad_pefa_data_t structure is used to store PTCE register
 * data.
 */
typedef struct sxd_emad_pefa_data {
    sxd_emad_common_data_t common;
    struct ku_pefa_reg    *reg_data;
} sxd_emad_pefa_data_t;

/**
 * sxd_emad_pecb_data_t structure is used to store PECB register
 * data.
 */
typedef struct sxd_emad_pecb_data {
    sxd_emad_common_data_t common;
    struct ku_pecb_reg    *reg_data;
} sxd_emad_pecb_data_t;

typedef struct sxd_emad_pemb_data {
    sxd_emad_common_data_t common;
    struct ku_pemb_reg    *reg_data;
} sxd_emad_pemb_data_t;


/**
 * sxd_emad_prcr_data_t structure is used to store PRCR register
 * data.
 */
typedef struct sxd_emad_prcr_data {
    sxd_emad_common_data_t common;
    struct ku_prcr_reg    *reg_data;
} sxd_emad_prcr_data_t;

/* sxd_emad_pagt_data_t structure is used to store PAGT register
 * data.
 */
typedef struct sxd_emad_pagt_data {
    sxd_emad_common_data_t common;
    struct ku_pagt_reg    *reg_data;
} sxd_emad_pagt_data_t;

/**
 * sxd_emad_puet_data_t structure is used to store PUET register
 * data.
 */
typedef struct sxd_emad_puet_data {
    sxd_emad_common_data_t common;
    struct ku_puet_reg    *reg_data;
} sxd_emad_puet_data_t;

/**
 * sxd_emad_perpt_data_t structure is used to store PERPT register
 * data.
 */
typedef struct sxd_emad_perpt_data {
    sxd_emad_common_data_t common;
    struct ku_perpt_reg   *reg_data;
} sxd_emad_perpt_data_t;

/**
 * sxd_emad_percr_data_t structure is used to store PERCR register
 * data.
 */
typedef struct sxd_emad_percr_data {
    sxd_emad_common_data_t common;
    struct ku_percr_reg   *reg_data;
} sxd_emad_percr_data_t;

/**
 * sxd_emad_pererp_data_t structure is used to store PERERP register
 * data.
 */
typedef struct sxd_emad_pererp_data {
    sxd_emad_common_data_t common;
    struct ku_pererp_reg  *reg_data;
} sxd_emad_pererp_data_t;

/**
 * sxd_emad_peabfe_data_t structure is used to store PEABFE register
 * data.
 */
typedef struct sxd_emad_peabfe_data {
    sxd_emad_common_data_t common;
    struct ku_peabfe_reg  *reg_data;
} sxd_emad_peabfe_data_t;
/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* ifndef __SXD_EMAD_ACL_DATA_H__ */
