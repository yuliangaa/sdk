/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_EMAD_PARSER_LAG_H__
#define __SXD_EMAD_PARSER_LAG_H__

#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_lag_data.h>
#include <sx/sxd/sxd_emad_lag_reg.h>

/************************************************
 *  API functions
 ***********************************************/

sxd_status_t emad_parser_lag_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                                 IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_sldr(sxd_emad_sldr_data_t *sldr_data,
                                 sxd_emad_sldr_reg_t  *sldr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_sldr(sxd_emad_sldr_data_t *sldr_data,
                                   sxd_emad_sldr_reg_t  *sldr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_sldr_reg_ports_size(sxd_emad_sldr_data_t *sldr_data,
                                          uint32_t             *sldr_reg_ports_size);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_slcr(sxd_emad_slcr_data_t *slcr_data,
                                 sxd_emad_slcr_reg_t  *slcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_slcr(sxd_emad_slcr_data_t *slcr_data,
                                   sxd_emad_slcr_reg_t  *slcr_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_parse_slcor(sxd_emad_slcor_data_t *slcor_data,
                                  sxd_emad_slcor_reg_t  *slcor_reg);

/**
 *  This function closes channel to SX-API operations.
 *
 * @param[in] handle - SX-API handle.
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_deparse_slcor(sxd_emad_slcor_data_t *slcor_data,
                                    sxd_emad_slcor_reg_t  *slcor_reg);

#endif /* __SXD_EMAD_PARSER_LAG_H__ */
