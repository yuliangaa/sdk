/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __SXD_EMAD_H__
#define __SXD_EMAD_H__

#include <complib/sx_log.h>
#include <sx/sxd/sxd_types.h>
#include <sx/sxd/sxd_emad_data.h>
#include <sx/sxd/sxdev.h>

/************************************************
 *  Local Defines
 ***********************************************/
#if defined(PD_BU)
#define SXD_MAX_EMAD_TIMEOUT_USEC (3000000000U) /* 3000 seconds (50 minutes) */
#else
#define SXD_MAX_EMAD_TIMEOUT_USEC (60000000U)   /* 60 seconds (1 minute) */
#endif

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/
typedef struct emad_transport_failure_data {
    uint64_t tid; /** transaction id */
    uint32_t fw_status; /** fw ret status */
    uint32_t emad_id;   /** EMAD id*/
} emad_transport_failure_data_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/************************************************
 *  API functions
 ***********************************************/

/**
 * This function sets the log verbosity level of EMAD MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_CMD_UNSUPPORTED - unsupported command
 */
sxd_status_t sxd_emad_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                          IN sx_verbosity_level_t *verbosity_level_p);

/**
 *  This function initializes the SXD EMAD library and should be
 *  called before any use of the it.
 *
 *  @param[in] app_id - Calling application ID
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - Local device initialization failed
 * @return SXD_STATUS_NO_MEMORY - EMAD pool/ transaction queue initialization failed
 */

sxd_status_t sxd_emad_init(uint32_t app_id);

/**
 *  This function deinitializes the SXD EMAD library. Further
 *  use of the library should not be made after it called.
 *
 * @return sxd_status_t:
 * @return SX_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR - de-initialization failed
 */
sxd_status_t sxd_emad_deinit(void);

/**
 *  This function sets EMAD transaction mode
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR -   setting failed
 *
 * @param[in]  enable         - enable/disable transaction mode
 */
sxd_status_t sxd_emad_transaction_mode_set(boolean_t enable);

/**
 *  This function get EMAD transaction mode state
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR -   setting failed
 *
 * @param[out]  *enable         - enable/disable transaction mode state
 */
sxd_status_t sxd_emad_transaction_mode_get(boolean_t *enable);

/**
 *  This function sets new timeout value for EMAD transactions.
 *
 * @param[in] timeout_usec - New timeout value, 0 is ignored.
 *
 * @return sxd_status_t:
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR -   setting failed
 */
sxd_status_t sxd_emad_timeout_set(uint32_t timeout_usec);

/**
 *  This function gets the current EMAD timeout.
 *
 * @param[out] timeout_usec - gets the current timeout.
 *
 * @return void
 */
void sxd_emad_timeout_get(uint32_t *timeout_usec);

/* callback to notify on latest EMAD tid that will be sent*/
typedef sxd_status_t (*sxd_emad_notify_latest_tx_tid_cb)(const uint64_t* emad_tid, void *context);

/* callback to notify on latest received emad tid */
typedef sxd_status_t (*sxd_emad_notify_latest_rx_tid_cb)(const uint64_t* emad_tid, void *context);

/**
 *  This function register callback for latest tid notification.
 *
 * @param[in] tx_cb - emad notify latest tx tid.
 * @param[in] rx_cb - emad notify latest rx tid.
 * @param[in] context - context to pass to cb function
 *
 * @return sxd_status_t
 */
sxd_status_t sxd_emad_register_notify_latest_tx_rx_tid_cb(sxd_emad_notify_latest_tx_tid_cb tx_cb,
                                                          sxd_emad_notify_latest_rx_tid_cb rx_cb,
                                                          void                            *context);

/**
 *  This function marks the beginning of debug-dump process.
 *  If a timeout occurs during this period, no more EMADs will be
 *  send to the problematic device (until sxd_emad_debug_dump_stop())
 *  is called.
 *
 * @param[in] timeout_usec - EMAD timeout during debug-dump process.
 *
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR -   starting debug-dump failed
 */
sxd_status_t sxd_emad_debug_dump_start(uint32_t timeout_usec);

/**
 *  This function marks the end of debug-dump process.
 *  If during the debug-dump period there was a TIMEOUT in an EMAD call
 *  to a device, this device was temporarily stopped from getting EMAD
 *  calls. This call will re-enable EMAD calls to the device.
 *
 * @return SXD_STATUS_SUCCESS - operation completes successfully
 * @return SXD_STATUS_ERROR -   starting debug-dump failed
 */
sxd_status_t sxd_emad_debug_dump_stop(void);

/**
 * This function sets the log verbosity level of EMAD MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t emad_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                      IN sx_verbosity_level_t *verbosity_level_p);

sxd_status_t emad_rx_thread_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sxd_status_t emad_rx_thread_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level);

sxd_status_t emad_tx_thread_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sxd_status_t emad_tx_thread_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level);

sxd_status_t emad_access_reg_infra_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level);
sxd_status_t emad_access_reg_infra_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level);

#endif /* __SXD_EMAD_H__ */
