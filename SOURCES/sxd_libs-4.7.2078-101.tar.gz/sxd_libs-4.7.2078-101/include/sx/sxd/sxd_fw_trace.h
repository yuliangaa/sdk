/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef SXD_FW_TRACE_H_
#define SXD_FW_TRACE_H_


/************************************************
 *  Defines
 ***********************************************/
#include <sx/sxd/sxd_status.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_access_cmd.h>
#include <complib/sx_log.h>

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * Initialize the FW trace sdk folder path, the sxd_fw_trace_init extract the string_db and other attributes of FW trace
 * and save it to files located inside that path.
 * at run time, the FW trace read the string db and FW trace attributes from the files and use it.
 *
 * @param sdk_path_name
 * @return
 */
sxd_status_t sxd_fw_trace_sdk_folder_path_set(char *sdk_path_name);

/**
 * return  the FW trace sdk folder path, the sxd_fw_trace_init extract the string_db and other attributes of FW trace
 * and save it to files located inside that path.
 *
 * @param sdk_path_name
 * @return
 */
void sxd_fw_trace_sdk_folder_path_get(char *sdk_path_name);


/**
 * Store the SDK FW trace path in driver.
 *
 * @return
 */
sxd_status_t sxd_fw_trace_store_sdk_path_in_driver(sxd_dev_id_t dev_id);


/**
 * Initialize the the FW trace module, get the FW trace configuration,
 * the string.db sections and allocate the different databases
 *
 * @param dev_id
 * @return
 */
sxd_status_t sxd_fw_trace_init(sxd_dev_id_t dev_id, char *sdk_path_name);

/**
 *  Extract the FW and PHY traces from the host memory and print into file.
 *
 * @param dev_id
 * @param stream
 * @return
 */
sxd_status_t sxd_fw_trace_extract(sxd_dev_id_t dev_id, FILE *stream);


sxd_status_t sxd_fw_trace_log_verbosity_level(sxd_access_cmd_t cmd, sx_verbosity_level_t *verbosity_level_p);

#endif /* SXD_FW_TRACE_H_ */
