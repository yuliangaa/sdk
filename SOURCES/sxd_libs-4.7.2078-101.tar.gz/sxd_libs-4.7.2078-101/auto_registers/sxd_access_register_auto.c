/*
 * SPDX-FileCopyrightText: Copyright (c) 2018-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */


/*
 * THIS FILE IS AUTO GENERATED.
 * DO NOT MAKE ANY CHANGES!
 * They will be erased with next update.
 *
 */

#include "reg_access/sxd_access_reg_infra.h"

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_access_reg_hgcr(struct ku_hgcr_reg      *hgcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(hgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HGCR_E);
}

sxd_status_t sxd_access_reg_hmon(struct ku_hmon_reg      *hmon_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(hmon_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HMON_E);
}

sxd_status_t sxd_access_reg_hcot(struct ku_hcot_reg      *hcot_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(hcot_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HCOT_E);
}

sxd_status_t sxd_access_reg_hrdqt(struct ku_hrdqt_reg     *hrdqt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(hrdqt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HRDQT_E);
}

sxd_status_t sxd_access_reg_htacg(struct ku_htacg_reg     *htacg_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(htacg_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HTACG_E);
}

sxd_status_t sxd_access_reg_hett(struct ku_hett_reg      *hett_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(hett_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HETT_E);
}

sxd_status_t sxd_access_reg_hccr(struct ku_hccr_reg      *hccr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(hccr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HCCR_E);
}

sxd_status_t sxd_access_reg_htec(struct ku_htec_reg      *htec_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(htec_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HTEC_E);
}

sxd_status_t sxd_access_reg_htcr(struct ku_htcr_reg      *htcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(htcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HTCR_E);
}

sxd_status_t sxd_access_reg_hcpnc(struct ku_hcpnc_reg     *hcpnc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(hcpnc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HCPNC_E);
}

sxd_status_t sxd_access_reg_hthm(struct ku_hthm_reg      *hthm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(hthm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HTHM_E);
}

sxd_status_t sxd_access_reg_htgt(struct ku_htgt_reg      *htgt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(htgt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HTGT_E);
}

sxd_status_t sxd_access_reg_hpkt(struct ku_hpkt_reg      *hpkt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(hpkt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_HPKT_E);
}

sxd_status_t sxd_access_reg_mtpps(struct ku_mtpps_reg     *mtpps_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mtpps_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTPPS_E);
}

sxd_status_t sxd_access_reg_mtppse(struct ku_mtppse_reg    *mtppse_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(mtppse_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTPPSE_E);
}

sxd_status_t sxd_access_reg_mtutc(struct ku_mtutc_reg     *mtutc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mtutc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTUTC_E);
}

sxd_status_t sxd_access_reg_mtppst(struct ku_mtppst_reg    *mtppst_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(mtppst_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTPPST_E);
}

sxd_status_t sxd_access_reg_msecq(struct ku_msecq_reg     *msecq_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(msecq_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MSECQ_E);
}

sxd_status_t sxd_access_reg_msees(struct ku_msees_reg     *msees_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(msees_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MSEES_E);
}

sxd_status_t sxd_access_reg_mspi(struct ku_mspi_reg      *mspi_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mspi_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MSPI_E);
}

sxd_status_t sxd_access_reg_mgpcb(struct ku_mgpcb_reg     *mgpcb_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mgpcb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MGPCB_E);
}

sxd_status_t sxd_access_reg_mcion(struct ku_mcion_reg     *mcion_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mcion_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MCION_E);
}

sxd_status_t sxd_access_reg_mcfs(struct ku_mcfs_reg      *mcfs_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mcfs_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MCFS_E);
}

sxd_status_t sxd_access_reg_mddt(struct ku_mddt_reg      *mddt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mddt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MDDT_E);
}

sxd_status_t sxd_access_reg_mddq(struct ku_mddq_reg      *mddq_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mddq_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MDDQ_E);
}

sxd_status_t sxd_access_reg_mddc(struct ku_mddc_reg      *mddc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mddc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MDDC_E);
}

sxd_status_t sxd_access_reg_mgpir(struct ku_mgpir_reg     *mgpir_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mgpir_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MGPIR_E);
}

sxd_status_t sxd_access_reg_mdfcr(struct ku_mdfcr_reg     *mdfcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mdfcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MDFCR_E);
}

sxd_status_t sxd_access_reg_mtecr(struct ku_mtecr_reg     *mtecr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mtecr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTECR_E);
}

sxd_status_t sxd_access_reg_mtcap(struct ku_mtcap_reg     *mtcap_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mtcap_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTCAP_E);
}

sxd_status_t sxd_access_reg_mtwe(struct ku_mtwe_reg      *mtwe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mtwe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTWE_E);
}

sxd_status_t sxd_access_reg_mtewe(struct ku_mtewe_reg     *mtewe_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mtewe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTEWE_E);
}

sxd_status_t sxd_access_reg_mtsde(struct ku_mtsde_reg     *mtsde_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mtsde_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTSDE_E);
}

sxd_status_t sxd_access_reg_mvcap(struct ku_mvcap_reg     *mvcap_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mvcap_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MVCAP_E);
}

sxd_status_t sxd_access_reg_mtmp(struct ku_mtmp_reg      *mtmp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mtmp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTMP_E);
}

sxd_status_t sxd_access_reg_mvcr(struct ku_mvcr_reg      *mvcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mvcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MVCR_E);
}

sxd_status_t sxd_access_reg_mcqi(struct ku_mcqi_reg      *mcqi_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mcqi_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MCQI_E);
}

sxd_status_t sxd_access_reg_mcc(struct ku_mcc_reg       *mcc_reg_data,
                                sxd_reg_meta_t          *reg_meta,
                                uint32_t                 data_num,
                                sxd_completion_handler_t handler,
                                void                    *context)
{
    return sxd_access_reg_common(mcc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MCC_E);
}

sxd_status_t sxd_access_reg_mcda(struct ku_mcda_reg      *mcda_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mcda_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MCDA_E);
}

sxd_status_t sxd_access_reg_mgir(struct ku_mgir_reg      *mgir_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mgir_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MGIR_E);
}

sxd_status_t sxd_access_reg_msgi(struct ku_msgi_reg      *msgi_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(msgi_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MSGI_E);
}

sxd_status_t sxd_access_reg_mdir(struct ku_mdir_reg      *mdir_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mdir_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MDIR_E);
}

sxd_status_t sxd_access_reg_mini(struct ku_mini_reg      *mini_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mini_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MINI_E);
}

sxd_status_t sxd_access_reg_mcam(struct ku_mcam_reg      *mcam_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mcam_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MCAM_E);
}

sxd_status_t sxd_access_reg_meccc(struct ku_meccc_reg     *meccc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(meccc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MECCC_E);
}

sxd_status_t sxd_access_reg_mmam(struct ku_mmam_reg      *mmam_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mmam_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MMAM_E);
}

sxd_status_t sxd_access_reg_mcgi(struct ku_mcgi_reg      *mcgi_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mcgi_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MCGI_E);
}

sxd_status_t sxd_access_reg_mbct(struct ku_mbct_reg      *mbct_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mbct_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MBCT_E);
}

sxd_status_t sxd_access_reg_mtcq(struct ku_mtcq_reg      *mtcq_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mtcq_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTCQ_E);
}

sxd_status_t sxd_access_reg_mfcdr(struct ku_mfcdr_reg     *mfcdr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mfcdr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MFCDR_E);
}

sxd_status_t sxd_access_reg_msgcr(struct ku_msgcr_reg     *msgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(msgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MSGCR_E);
}

sxd_status_t sxd_access_reg_mtrc_cap(struct ku_mtrc_cap_reg  *mtrc_cap_reg_data,
                                     sxd_reg_meta_t          *reg_meta,
                                     uint32_t                 data_num,
                                     sxd_completion_handler_t handler,
                                     void                    *context)
{
    return sxd_access_reg_common(mtrc_cap_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTRC_CAP_E);
}

sxd_status_t sxd_access_reg_mtrc_stdb_v2(struct ku_mtrc_stdb_v2_reg*mtrc_stdb_v2_reg_data,
                                         sxd_reg_meta_t          *reg_meta,
                                         uint32_t                 data_num,
                                         sxd_completion_handler_t handler,
                                         void                    *context)
{
    return sxd_access_reg_common(mtrc_stdb_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTRC_STDB_V2_E);
}

sxd_status_t sxd_access_reg_mteim(struct ku_mteim_reg     *mteim_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mteim_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTEIM_E);
}

sxd_status_t sxd_access_reg_mpcir(struct ku_mpcir_reg     *mpcir_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mpcir_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MPCIR_E);
}

sxd_status_t sxd_access_reg_mfrc(struct ku_mfrc_reg      *mfrc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mfrc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MFRC_E);
}

sxd_status_t sxd_access_reg_mmcr(struct ku_mmcr_reg      *mmcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mmcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MMCR_E);
}

sxd_status_t sxd_access_reg_mfri(struct ku_mfri_reg      *mfri_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mfri_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MFRI_E);
}

sxd_status_t sxd_access_reg_mfrp(struct ku_mfrp_reg      *mfrp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mfrp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MFRP_E);
}

sxd_status_t sxd_access_reg_mogcr(struct ku_mogcr_reg     *mogcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mogcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOGCR_E);
}

sxd_status_t sxd_access_reg_molp(struct ku_molp_reg      *molp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(molp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOLP_E);
}

sxd_status_t sxd_access_reg_mprs(struct ku_mprs_reg      *mprs_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mprs_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MPRS_E);
}

sxd_status_t sxd_access_reg_mmgcr(struct ku_mmgcr_reg     *mmgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mmgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MMGCR_E);
}

sxd_status_t sxd_access_reg_mpat(struct ku_mpat_reg      *mpat_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mpat_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MPAT_E);
}

sxd_status_t sxd_access_reg_mpagr(struct ku_mpagr_reg     *mpagr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mpagr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MPAGR_E);
}

sxd_status_t sxd_access_reg_momte(struct ku_momte_reg     *momte_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(momte_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOMTE_E);
}

sxd_status_t sxd_access_reg_mocmi(struct ku_mocmi_reg     *mocmi_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mocmi_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOCMI_E);
}

sxd_status_t sxd_access_reg_moni(struct ku_moni_reg      *moni_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(moni_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MONI_E);
}

sxd_status_t sxd_access_reg_mocs(struct ku_mocs_reg      *mocs_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mocs_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOCS_E);
}

sxd_status_t sxd_access_reg_mafcr(struct ku_mafcr_reg     *mafcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mafcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MAFCR_E);
}

sxd_status_t sxd_access_reg_mafti(struct ku_mafti_reg     *mafti_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mafti_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MAFTI_E);
}

sxd_status_t sxd_access_reg_mafbi(struct ku_mafbi_reg     *mafbi_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mafbi_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MAFBI_E);
}

sxd_status_t sxd_access_reg_mafri(struct ku_mafri_reg     *mafri_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mafri_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MAFRI_E);
}

sxd_status_t sxd_access_reg_mopce(struct ku_mopce_reg     *mopce_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mopce_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOPCE_E);
}

sxd_status_t sxd_access_reg_moca(struct ku_moca_reg      *moca_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(moca_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOCA_E);
}

sxd_status_t sxd_access_reg_mofrb(struct ku_mofrb_reg     *mofrb_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mofrb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOFRB_E);
}

sxd_status_t sxd_access_reg_mofph(struct ku_mofph_reg     *mofph_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mofph_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOFPH_E);
}

sxd_status_t sxd_access_reg_mofpc(struct ku_mofpc_reg     *mofpc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mofpc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOFPC_E);
}

sxd_status_t sxd_access_reg_mocbr(struct ku_mocbr_reg     *mocbr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mocbr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOCBR_E);
}

sxd_status_t sxd_access_reg_mocbs(struct ku_mocbs_reg     *mocbs_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mocbs_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOCBS_E);
}

sxd_status_t sxd_access_reg_mopct(struct ku_mopct_reg     *mopct_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mopct_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOPCT_E);
}

sxd_status_t sxd_access_reg_mopcs(struct ku_mopcs_reg     *mopcs_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mopcs_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOPCS_E);
}

sxd_status_t sxd_access_reg_mopgcr(struct ku_mopgcr_reg    *mopgcr_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(mopgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOPGCR_E);
}

sxd_status_t sxd_access_reg_moftc(struct ku_moftc_reg     *moftc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(moftc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOFTC_E);
}

sxd_status_t sxd_access_reg_moftd(struct ku_moftd_reg     *moftd_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(moftd_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOFTD_E);
}

sxd_status_t sxd_access_reg_mtpspu(struct ku_mtpspu_reg    *mtpspu_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(mtpspu_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTPSPU_E);
}

sxd_status_t sxd_access_reg_mtpcpc(struct ku_mtpcpc_reg    *mtpcpc_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(mtpcpc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MTPCPC_E);
}

sxd_status_t sxd_access_reg_mfgd(struct ku_mfgd_reg      *mfgd_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mfgd_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MFGD_E);
}

sxd_status_t sxd_access_reg_mifgd(struct ku_mifgd_reg     *mifgd_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mifgd_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MIFGD_E);
}

sxd_status_t sxd_access_reg_modcr(struct ku_modcr_reg     *modcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(modcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MODCR_E);
}

sxd_status_t sxd_access_reg_mofs(struct ku_mofs_reg      *mofs_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mofs_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOFS_E);
}

sxd_status_t sxd_access_reg_mfde(struct ku_mfde_reg      *mfde_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mfde_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MFDE_E);
}

sxd_status_t sxd_access_reg_mdif(struct ku_mdif_reg      *mdif_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(mdif_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MDIF_E);
}

sxd_status_t sxd_access_reg_mofrd(struct ku_mofrd_reg     *mofrd_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(mofrd_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MOFRD_E);
}

sxd_status_t sxd_access_reg_igcr(struct ku_igcr_reg      *igcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(igcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IGCR_E);
}

sxd_status_t sxd_access_reg_iddd(struct ku_iddd_reg      *iddd_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(iddd_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IDDD_E);
}

sxd_status_t sxd_access_reg_iedr(struct ku_iedr_reg      *iedr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(iedr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IEDR_E);
}

sxd_status_t sxd_access_reg_ieds(struct ku_ieds_reg      *ieds_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ieds_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IEDS_E);
}

sxd_status_t sxd_access_reg_ifbo(struct ku_ifbo_reg      *ifbo_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ifbo_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IFBO_E);
}

sxd_status_t sxd_access_reg_iicr(struct ku_iicr_reg      *iicr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(iicr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IICR_E);
}

sxd_status_t sxd_access_reg_ipac(struct ku_ipac_reg      *ipac_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ipac_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IPAC_E);
}

sxd_status_t sxd_access_reg_ihsr(struct ku_ihsr_reg      *ihsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ihsr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IHSR_E);
}

sxd_status_t sxd_access_reg_ihscr(struct ku_ihscr_reg     *ihscr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ihscr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IHSCR_E);
}

sxd_status_t sxd_access_reg_ipsr(struct ku_ipsr_reg      *ipsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ipsr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IPSR_E);
}

sxd_status_t sxd_access_reg_icsr(struct ku_icsr_reg      *icsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(icsr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_ICSR_E);
}

sxd_status_t sxd_access_reg_ipfr(struct ku_ipfr_reg      *ipfr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ipfr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IPFR_E);
}

sxd_status_t sxd_access_reg_itgcr(struct ku_itgcr_reg     *itgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(itgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_ITGCR_E);
}

sxd_status_t sxd_access_reg_itpr(struct ku_itpr_reg      *itpr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(itpr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_ITPR_E);
}

sxd_status_t sxd_access_reg_sgcr(struct ku_sgcr_reg      *sgcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(sgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SGCR_E);
}

sxd_status_t sxd_access_reg_spad(struct ku_spad_reg      *spad_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(spad_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SPAD_E);
}

sxd_status_t sxd_access_reg_sfdb(struct ku_sfdb_reg      *sfdb_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(sfdb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SFDB_E);
}

sxd_status_t sxd_access_reg_sfdb_v2(struct ku_sfdb_v2_reg   *sfdb_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(sfdb_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SFDB_V2_E);
}

sxd_status_t sxd_access_reg_smid_v2(struct ku_smid_v2_reg   *smid_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(smid_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SMID_V2_E);
}

sxd_status_t sxd_access_reg_smpu(struct ku_smpu_reg      *smpu_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(smpu_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SMPU_E);
}

sxd_status_t sxd_access_reg_spms_v2(struct ku_spms_v2_reg   *spms_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(spms_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SPMS_V2_E);
}

sxd_status_t sxd_access_reg_spevet(struct ku_spevet_reg    *spevet_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(spevet_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SPEVET_E);
}

sxd_status_t sxd_access_reg_spaft(struct ku_spaft_reg     *spaft_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(spaft_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SPAFT_E);
}

sxd_status_t sxd_access_reg_sfgc(struct ku_sfgc_reg      *sfgc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(sfgc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SFGC_E);
}

sxd_status_t sxd_access_reg_sftr_v2(struct ku_sftr_v2_reg   *sftr_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(sftr_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SFTR_V2_E);
}

sxd_status_t sxd_access_reg_svfa(struct ku_svfa_reg      *svfa_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(svfa_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SVFA_E);
}

sxd_status_t sxd_access_reg_sfdf(struct ku_sfdf_reg      *sfdf_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(sfdf_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SFDF_E);
}

sxd_status_t sxd_access_reg_sfmr(struct ku_sfmr_reg      *sfmr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(sfmr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SFMR_E);
}

sxd_status_t sxd_access_reg_spfsr(struct ku_spfsr_reg     *spfsr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(spfsr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SPFSR_E);
}

sxd_status_t sxd_access_reg_sffp(struct ku_sffp_reg      *sffp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(sffp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SFFP_E);
}

sxd_status_t sxd_access_reg_smpe(struct ku_smpe_reg      *smpe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(smpe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SMPE_E);
}

sxd_status_t sxd_access_reg_smpeb(struct ku_smpeb_reg     *smpeb_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(smpeb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SMPEB_E);
}

sxd_status_t sxd_access_reg_slmt(struct ku_slmt_reg      *slmt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(slmt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SLMT_E);
}

sxd_status_t sxd_access_reg_sfdt_v2(struct ku_sfdt_v2_reg   *sfdt_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(sfdt_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SFDT_V2_E);
}

sxd_status_t sxd_access_reg_sfdat(struct ku_sfdat_reg     *sfdat_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sfdat_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SFDAT_E);
}

sxd_status_t sxd_access_reg_spzr(struct ku_spzr_reg      *spzr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(spzr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SPZR_E);
}

sxd_status_t sxd_access_reg_ibfmr(struct ku_ibfmr_reg     *ibfmr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ibfmr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IBFMR_E);
}

sxd_status_t sxd_access_reg_ibfmrc(struct ku_ibfmrc_reg    *ibfmrc_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(ibfmrc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IBFMRC_E);
}

sxd_status_t sxd_access_reg_ibissu(struct ku_ibissu_reg    *ibissu_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(ibissu_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_IBISSU_E);
}

sxd_status_t sxd_access_reg_pcam(struct ku_pcam_reg      *pcam_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pcam_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PCAM_E);
}

sxd_status_t sxd_access_reg_ptys(struct ku_ptys_reg      *ptys_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ptys_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PTYS_E);
}

sxd_status_t sxd_access_reg_paos(struct ku_paos_reg      *paos_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(paos_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PAOS_E);
}

sxd_status_t sxd_access_reg_pltc(struct ku_pltc_reg      *pltc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pltc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PLTC_E);
}

sxd_status_t sxd_access_reg_ppcnt(struct ku_ppcnt_reg     *ppcnt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ppcnt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPCNT_E);
}

sxd_status_t sxd_access_reg_ptse(struct ku_ptse_reg      *ptse_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ptse_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PTSE_E);
}

sxd_status_t sxd_access_reg_pter(struct ku_pter_reg      *pter_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pter_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PTER_E);
}

sxd_status_t sxd_access_reg_prei(struct ku_prei_reg      *prei_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(prei_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PREI_E);
}

sxd_status_t sxd_access_reg_plar(struct ku_plar_reg      *plar_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(plar_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PLAR_E);
}

sxd_status_t sxd_access_reg_pude(struct ku_pude_reg      *pude_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pude_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PUDE_E);
}

sxd_status_t sxd_access_reg_pmaos(struct ku_pmaos_reg     *pmaos_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(pmaos_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMAOS_E);
}

sxd_status_t sxd_access_reg_pmtdb(struct ku_pmtdb_reg     *pmtdb_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(pmtdb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMTDB_E);
}

sxd_status_t sxd_access_reg_pmecr(struct ku_pmecr_reg     *pmecr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(pmecr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMECR_E);
}

sxd_status_t sxd_access_reg_pmlpe(struct ku_pmlpe_reg     *pmlpe_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(pmlpe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMLPE_E);
}

sxd_status_t sxd_access_reg_pmsc(struct ku_pmsc_reg      *pmsc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pmsc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMSC_E);
}

sxd_status_t sxd_access_reg_pmpe(struct ku_pmpe_reg      *pmpe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pmpe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMPE_E);
}

sxd_status_t sxd_access_reg_pmmp(struct ku_pmmp_reg      *pmmp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pmmp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMMP_E);
}

sxd_status_t sxd_access_reg_pmcr(struct ku_pmcr_reg      *pmcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pmcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMCR_E);
}

sxd_status_t sxd_access_reg_pmtps(struct ku_pmtps_reg     *pmtps_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(pmtps_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMTPS_E);
}

sxd_status_t sxd_access_reg_pmpt(struct ku_pmpt_reg      *pmpt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pmpt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMPT_E);
}

sxd_status_t sxd_access_reg_pmpd(struct ku_pmpd_reg      *pmpd_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pmpd_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMPD_E);
}

sxd_status_t sxd_access_reg_pmtm(struct ku_pmtm_reg      *pmtm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pmtm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMTM_E);
}

sxd_status_t sxd_access_reg_pplr(struct ku_pplr_reg      *pplr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pplr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPLR_E);
}

sxd_status_t sxd_access_reg_sltp(struct ku_sltp_reg      *sltp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(sltp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SLTP_E);
}

sxd_status_t sxd_access_reg_ptasv2(struct ku_ptasv2_reg    *ptasv2_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(ptasv2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PTASV2_E);
}

sxd_status_t sxd_access_reg_slsir(struct ku_slsir_reg     *slsir_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(slsir_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SLSIR_E);
}

sxd_status_t sxd_access_reg_pddr(struct ku_pddr_reg      *pddr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pddr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PDDR_E);
}

sxd_status_t sxd_access_reg_pptt(struct ku_pptt_reg      *pptt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pptt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPTT_E);
}

sxd_status_t sxd_access_reg_pnlpnr(struct ku_pnlpnr_reg    *pnlpnr_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(pnlpnr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PNLPNR_E);
}

sxd_status_t sxd_access_reg_pprt(struct ku_pprt_reg      *pprt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pprt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPRT_E);
}

sxd_status_t sxd_access_reg_pmdr(struct ku_pmdr_reg      *pmdr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pmdr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMDR_E);
}

sxd_status_t sxd_access_reg_pphcr(struct ku_pphcr_reg     *pphcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(pphcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPHCR_E);
}

sxd_status_t sxd_access_reg_sllm(struct ku_sllm_reg      *sllm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(sllm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SLLM_E);
}

sxd_status_t sxd_access_reg_ppcgp(struct ku_ppcgp_reg     *ppcgp_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ppcgp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPCGP_E);
}

sxd_status_t sxd_access_reg_pcsr(struct ku_pcsr_reg      *pcsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pcsr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PCSR_E);
}

sxd_status_t sxd_access_reg_ppbme(struct ku_ppbme_reg     *ppbme_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ppbme_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPBME_E);
}

sxd_status_t sxd_access_reg_prtl(struct ku_prtl_reg      *prtl_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(prtl_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PRTL_E);
}

sxd_status_t sxd_access_reg_pemi(struct ku_pemi_reg      *pemi_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pemi_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PEMI_E);
}

sxd_status_t sxd_access_reg_pmtu(struct ku_pmtu_reg      *pmtu_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pmtu_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PMTU_E);
}

sxd_status_t sxd_access_reg_ppad(struct ku_ppad_reg      *ppad_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ppad_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPAD_E);
}

sxd_status_t sxd_access_reg_pifr_v2(struct ku_pifr_v2_reg   *pifr_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(pifr_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PIFR_V2_E);
}

sxd_status_t sxd_access_reg_pbsr(struct ku_pbsr_reg      *pbsr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pbsr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PBSR_E);
}

sxd_status_t sxd_access_reg_pllp(struct ku_pllp_reg      *pllp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pllp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PLLP_E);
}

sxd_status_t sxd_access_reg_ppcr(struct ku_ppcr_reg      *ppcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ppcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPCR_E);
}

sxd_status_t sxd_access_reg_pldt(struct ku_pldt_reg      *pldt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pldt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PLDT_E);
}

sxd_status_t sxd_access_reg_pldc(struct ku_pldc_reg      *pldc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pldc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PLDC_E);
}

sxd_status_t sxd_access_reg_plibdb(struct ku_plibdb_reg    *plibdb_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(plibdb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PLIBDB_E);
}

sxd_status_t sxd_access_reg_pbgcr(struct ku_pbgcr_reg     *pbgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(pbgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PBGCR_E);
}

sxd_status_t sxd_access_reg_ppir(struct ku_ppir_reg      *ppir_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ppir_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPIR_E);
}

sxd_status_t sxd_access_reg_phbr(struct ku_phbr_reg      *phbr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(phbr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PHBR_E);
}

sxd_status_t sxd_access_reg_phrr(struct ku_phrr_reg      *phrr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(phrr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PHRR_E);
}

sxd_status_t sxd_access_reg_pbwc(struct ku_pbwc_reg      *pbwc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pbwc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PBWC_E);
}

sxd_status_t sxd_access_reg_pbwr(struct ku_pbwr_reg      *pbwr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pbwr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PBWR_E);
}

sxd_status_t sxd_access_reg_pcmr(struct ku_pcmr_reg      *pcmr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pcmr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PCMR_E);
}

sxd_status_t sxd_access_reg_sbgcr(struct ku_sbgcr_reg     *sbgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sbgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBGCR_E);
}

sxd_status_t sxd_access_reg_sbsrd(struct ku_sbsrd_reg     *sbsrd_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sbsrd_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBSRD_E);
}

sxd_status_t sxd_access_reg_sbhbr_v2(struct ku_sbhbr_v2_reg  *sbhbr_v2_reg_data,
                                     sxd_reg_meta_t          *reg_meta,
                                     uint32_t                 data_num,
                                     sxd_completion_handler_t handler,
                                     void                    *context)
{
    return sxd_access_reg_common(sbhbr_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBHBR_V2_E);
}

sxd_status_t sxd_access_reg_sbhrr_v2(struct ku_sbhrr_v2_reg  *sbhrr_v2_reg_data,
                                     sxd_reg_meta_t          *reg_meta,
                                     uint32_t                 data_num,
                                     sxd_completion_handler_t handler,
                                     void                    *context)
{
    return sxd_access_reg_common(sbhrr_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBHRR_V2_E);
}

sxd_status_t sxd_access_reg_sbctr(struct ku_sbctr_reg     *sbctr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sbctr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBCTR_E);
}

sxd_status_t sxd_access_reg_sbhpc(struct ku_sbhpc_reg     *sbhpc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sbhpc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBHPC_E);
}

sxd_status_t sxd_access_reg_sbsnt(struct ku_sbsnt_reg     *sbsnt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sbsnt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBSNT_E);
}

sxd_status_t sxd_access_reg_sbsns(struct ku_sbsns_reg     *sbsns_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(sbsns_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBSNS_E);
}

sxd_status_t sxd_access_reg_sbsnte(struct ku_sbsnte_reg    *sbsnte_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(sbsnte_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_SBSNTE_E);
}

sxd_status_t sxd_access_reg_pgcr(struct ku_pgcr_reg      *pgcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PGCR_E);
}

sxd_status_t sxd_access_reg_ppbt(struct ku_ppbt_reg      *ppbt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ppbt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPBT_E);
}

sxd_status_t sxd_access_reg_pevpb(struct ku_pevpb_reg     *pevpb_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(pevpb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PEVPB_E);
}

sxd_status_t sxd_access_reg_pvgt(struct ku_pvgt_reg      *pvgt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pvgt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PVGT_E);
}

sxd_status_t sxd_access_reg_pvbt(struct ku_pvbt_reg      *pvbt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pvbt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PVBT_E);
}

sxd_status_t sxd_access_reg_pemrbt(struct ku_pemrbt_reg    *pemrbt_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(pemrbt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PEMRBT_E);
}

sxd_status_t sxd_access_reg_perb(struct ku_perb_reg      *perb_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(perb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PERB_E);
}

sxd_status_t sxd_access_reg_perbrg(struct ku_perbrg_reg    *perbrg_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(perbrg_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PERBRG_E);
}

sxd_status_t sxd_access_reg_perbeg(struct ku_perbeg_reg    *perbeg_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(perbeg_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PERBEG_E);
}

sxd_status_t sxd_access_reg_pagt_v2(struct ku_pagt_v2_reg   *pagt_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(pagt_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PAGT_V2_E);
}

sxd_status_t sxd_access_reg_pagtq(struct ku_pagtq_reg     *pagtq_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(pagtq_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PAGTQ_E);
}

sxd_status_t sxd_access_reg_perla(struct ku_perla_reg     *perla_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(perla_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PERLA_E);
}

sxd_status_t sxd_access_reg_perar(struct ku_perar_reg     *perar_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(perar_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PERAR_E);
}

sxd_status_t sxd_access_reg_pefaad(struct ku_pefaad_reg    *pefaad_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(pefaad_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PEFAAD_E);
}

sxd_status_t sxd_access_reg_pprr(struct ku_pprr_reg      *pprr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(pprr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPRR_E);
}

sxd_status_t sxd_access_reg_ppbs(struct ku_ppbs_reg      *ppbs_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ppbs_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PPBS_E);
}

sxd_status_t sxd_access_reg_peaps(struct ku_peaps_reg     *peaps_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(peaps_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PEAPS_E);
}

sxd_status_t sxd_access_reg_pecnre(struct ku_pecnre_reg    *pecnre_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(pecnre_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PECNRE_E);
}

sxd_status_t sxd_access_reg_pecnrr(struct ku_pecnrr_reg    *pecnrr_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(pecnrr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PECNRR_E);
}

sxd_status_t sxd_access_reg_pecnee(struct ku_pecnee_reg    *pecnee_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(pecnee_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PECNEE_E);
}

sxd_status_t sxd_access_reg_pecner(struct ku_pecner_reg    *pecner_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(pecner_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_PECNER_E);
}

sxd_status_t sxd_access_reg_qcap(struct ku_qcap_reg      *qcap_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(qcap_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QCAP_E);
}

sxd_status_t sxd_access_reg_qeec(struct ku_qeec_reg      *qeec_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(qeec_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QEEC_E);
}

sxd_status_t sxd_access_reg_qtct(struct ku_qtct_reg      *qtct_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(qtct_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QTCT_E);
}

sxd_status_t sxd_access_reg_qtctm(struct ku_qtctm_reg     *qtctm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qtctm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QTCTM_E);
}

sxd_status_t sxd_access_reg_qstct(struct ku_qstct_reg     *qstct_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qstct_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QSTCT_E);
}

sxd_status_t sxd_access_reg_qspip(struct ku_qspip_reg     *qspip_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qspip_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QSPIP_E);
}

sxd_status_t sxd_access_reg_qspcp(struct ku_qspcp_reg     *qspcp_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qspcp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QSPCP_E);
}

sxd_status_t sxd_access_reg_qtttl(struct ku_qtttl_reg     *qtttl_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qtttl_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QTTTL_E);
}

sxd_status_t sxd_access_reg_qtqcr(struct ku_qtqcr_reg     *qtqcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qtqcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QTQCR_E);
}

sxd_status_t sxd_access_reg_qtqdr(struct ku_qtqdr_reg     *qtqdr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qtqdr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QTQDR_E);
}

sxd_status_t sxd_access_reg_qteem(struct ku_qteem_reg     *qteem_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qteem_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QTEEM_E);
}

sxd_status_t sxd_access_reg_qtdem(struct ku_qtdem_reg     *qtdem_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qtdem_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QTDEM_E);
}

sxd_status_t sxd_access_reg_qpdpc(struct ku_qpdpc_reg     *qpdpc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qpdpc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QPDPC_E);
}

sxd_status_t sxd_access_reg_qsll(struct ku_qsll_reg      *qsll_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(qsll_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QSLL_E);
}

sxd_status_t sxd_access_reg_qptg(struct ku_qptg_reg      *qptg_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(qptg_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QPTG_E);
}

sxd_status_t sxd_access_reg_qtgtc(struct ku_qtgtc_reg     *qtgtc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(qtgtc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_QTGTC_E);
}

sxd_status_t sxd_access_reg_cpqe(struct ku_cpqe_reg      *cpqe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(cpqe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_CPQE_E);
}

sxd_status_t sxd_access_reg_chltr(struct ku_chltr_reg     *chltr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(chltr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_CHLTR_E);
}

sxd_status_t sxd_access_reg_chltm(struct ku_chltm_reg     *chltm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(chltm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_CHLTM_E);
}

sxd_status_t sxd_access_reg_chlmm(struct ku_chlmm_reg     *chlmm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(chlmm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_CHLMM_E);
}

sxd_status_t sxd_access_reg_cegcr(struct ku_cegcr_reg     *cegcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(cegcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_CEGCR_E);
}

sxd_status_t sxd_access_reg_cepc(struct ku_cepc_reg      *cepc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(cepc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_CEPC_E);
}

sxd_status_t sxd_access_reg_cedr(struct ku_cedr_reg      *cedr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(cedr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_CEDR_E);
}

sxd_status_t sxd_access_reg_ceer(struct ku_ceer_reg      *ceer_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ceer_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_CEER_E);
}

sxd_status_t sxd_access_reg_cwgcr(struct ku_cwgcr_reg     *cwgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(cwgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_CWGCR_E);
}

sxd_status_t sxd_access_reg_cwtpm(struct ku_cwtpm_reg     *cwtpm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(cwtpm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_CWTPM_E);
}

sxd_status_t sxd_access_reg_rigr_v2(struct ku_rigr_v2_reg   *rigr_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(rigr_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RIGR_V2_E);
}

sxd_status_t sxd_access_reg_ratrb(struct ku_ratrb_reg     *ratrb_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ratrb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RATRB_E);
}

sxd_status_t sxd_access_reg_rtdp(struct ku_rtdp_reg      *rtdp_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(rtdp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RTDP_E);
}

sxd_status_t sxd_access_reg_rips(struct ku_rips_reg      *rips_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(rips_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RIPS_E);
}

sxd_status_t sxd_access_reg_ralta(struct ku_ralta_reg     *ralta_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ralta_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RALTA_E);
}

sxd_status_t sxd_access_reg_ralst(struct ku_ralst_reg     *ralst_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ralst_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RALST_E);
}

sxd_status_t sxd_access_reg_raltb(struct ku_raltb_reg     *raltb_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(raltb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RALTB_E);
}

sxd_status_t sxd_access_reg_raleu(struct ku_raleu_reg     *raleu_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(raleu_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RALEU_E);
}

sxd_status_t sxd_access_reg_ralcm(struct ku_ralcm_reg     *ralcm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ralcm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RALCM_E);
}

sxd_status_t sxd_access_reg_rmid_v2(struct ku_rmid_v2_reg   *rmid_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(rmid_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RMID_V2_E);
}

sxd_status_t sxd_access_reg_rmpe(struct ku_rmpe_reg      *rmpe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(rmpe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RMPE_E);
}

sxd_status_t sxd_access_reg_reiv(struct ku_reiv_reg      *reiv_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(reiv_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_REIV_E);
}

sxd_status_t sxd_access_reg_rngcr(struct ku_rngcr_reg     *rngcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rngcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RNGCR_E);
}

sxd_status_t sxd_access_reg_rxlte(struct ku_rxlte_reg     *rxlte_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rxlte_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RXLTE_E);
}

sxd_status_t sxd_access_reg_rxltm(struct ku_rxltm_reg     *rxltm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rxltm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RXLTM_E);
}

sxd_status_t sxd_access_reg_rxltcc(struct ku_rxltcc_reg    *rxltcc_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rxltcc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RXLTCC_E);
}

sxd_status_t sxd_access_reg_rlcme(struct ku_rlcme_reg     *rlcme_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rlcme_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RLCME_E);
}

sxd_status_t sxd_access_reg_rlcmle(struct ku_rlcmle_reg    *rlcmle_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rlcmle_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RLCMLE_E);
}

sxd_status_t sxd_access_reg_rlcmld(struct ku_rlcmld_reg    *rlcmld_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rlcmld_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RLCMLD_E);
}

sxd_status_t sxd_access_reg_rargcr(struct ku_rargcr_reg    *rargcr_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rargcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARGCR_E);
}

sxd_status_t sxd_access_reg_rarpc(struct ku_rarpc_reg     *rarpc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rarpc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARPC_E);
}

sxd_status_t sxd_access_reg_rarsr(struct ku_rarsr_reg     *rarsr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rarsr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARSR_E);
}

sxd_status_t sxd_access_reg_rarpr(struct ku_rarpr_reg     *rarpr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rarpr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARPR_E);
}

sxd_status_t sxd_access_reg_rarcl(struct ku_rarcl_reg     *rarcl_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rarcl_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARCL_E);
}

sxd_status_t sxd_access_reg_rarppm(struct ku_rarppm_reg    *rarppm_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rarppm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARPPM_E);
}

sxd_status_t sxd_access_reg_rarlu(struct ku_rarlu_reg     *rarlu_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rarlu_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARLU_E);
}

sxd_status_t sxd_access_reg_rarft(struct ku_rarft_reg     *rarft_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rarft_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARFT_E);
}

sxd_status_t sxd_access_reg_rarftb(struct ku_rarftb_reg    *rarftb_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rarftb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARFTB_E);
}

sxd_status_t sxd_access_reg_rarftbr(struct ku_rarftbr_reg   *rarftbr_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(rarftbr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARFTBR_E);
}

sxd_status_t sxd_access_reg_rarlpgt(struct ku_rarlpgt_reg   *rarlpgt_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(rarlpgt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARLPGT_E);
}

sxd_status_t sxd_access_reg_rarcc(struct ku_rarcc_reg     *rarcc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rarcc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARCC_E);
}

sxd_status_t sxd_access_reg_rartm(struct ku_rartm_reg     *rartm_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rartm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARTM_E);
}

sxd_status_t sxd_access_reg_rsnh(struct ku_rsnh_reg      *rsnh_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(rsnh_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RSNH_E);
}

sxd_status_t sxd_access_reg_rarngc(struct ku_rarngc_reg    *rarngc_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rarngc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARNGC_E);
}

sxd_status_t sxd_access_reg_rarnpc(struct ku_rarnpc_reg    *rarnpc_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rarnpc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARNPC_E);
}

sxd_status_t sxd_access_reg_rarns(struct ku_rarns_reg     *rarns_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(rarns_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARNS_E);
}

sxd_status_t sxd_access_reg_rarnpr(struct ku_rarnpr_reg    *rarnpr_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rarnpr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARNPR_E);
}

sxd_status_t sxd_access_reg_rarncp(struct ku_rarncp_reg    *rarncp_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rarncp_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARNCP_E);
}

sxd_status_t sxd_access_reg_rarncg(struct ku_rarncg_reg    *rarncg_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(rarncg_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RARNCG_E);
}

sxd_status_t sxd_access_reg_rirt(struct ku_rirt_reg      *rirt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(rirt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_RIRT_E);
}

sxd_status_t sxd_access_reg_mpnhlfe(struct ku_mpnhlfe_reg   *mpnhlfe_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(mpnhlfe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_MPNHLFE_E);
}

sxd_status_t sxd_access_reg_tnqcr(struct ku_tnqcr_reg     *tnqcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tnqcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNQCR_E);
}

sxd_status_t sxd_access_reg_tnpc(struct ku_tnpc_reg      *tnpc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(tnpc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNPC_E);
}

sxd_status_t sxd_access_reg_tngee(struct ku_tngee_reg     *tngee_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tngee_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNGEE_E);
}

sxd_status_t sxd_access_reg_tncr(struct ku_tncr_reg      *tncr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(tncr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNCR_E);
}

sxd_status_t sxd_access_reg_tncr_v2(struct ku_tncr_v2_reg   *tncr_v2_reg_data,
                                    sxd_reg_meta_t          *reg_meta,
                                    uint32_t                 data_num,
                                    sxd_completion_handler_t handler,
                                    void                    *context)
{
    return sxd_access_reg_common(tncr_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNCR_V2_E);
}

sxd_status_t sxd_access_reg_tnumt(struct ku_tnumt_reg     *tnumt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tnumt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNUMT_E);
}

sxd_status_t sxd_access_reg_tngcr(struct ku_tngcr_reg     *tngcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tngcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNGCR_E);
}

sxd_status_t sxd_access_reg_tnqdr(struct ku_tnqdr_reg     *tnqdr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tnqdr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNQDR_E);
}

sxd_status_t sxd_access_reg_tneem(struct ku_tneem_reg     *tneem_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tneem_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNEEM_E);
}

sxd_status_t sxd_access_reg_tndem(struct ku_tndem_reg     *tndem_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tndem_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNDEM_E);
}

sxd_status_t sxd_access_reg_tnifr(struct ku_tnifr_reg     *tnifr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tnifr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNIFR_E);
}

sxd_status_t sxd_access_reg_tnifr_v2(struct ku_tnifr_v2_reg  *tnifr_v2_reg_data,
                                     sxd_reg_meta_t          *reg_meta,
                                     uint32_t                 data_num,
                                     sxd_completion_handler_t handler,
                                     void                    *context)
{
    return sxd_access_reg_common(tnifr_v2_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TNIFR_V2_E);
}

sxd_status_t sxd_access_reg_tigcr(struct ku_tigcr_reg     *tigcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tigcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TIGCR_E);
}

sxd_status_t sxd_access_reg_tiqcr(struct ku_tiqcr_reg     *tiqcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tiqcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TIQCR_E);
}

sxd_status_t sxd_access_reg_tiqdr(struct ku_tiqdr_reg     *tiqdr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tiqdr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TIQDR_E);
}

sxd_status_t sxd_access_reg_tieem(struct ku_tieem_reg     *tieem_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tieem_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TIEEM_E);
}

sxd_status_t sxd_access_reg_tidem(struct ku_tidem_reg     *tidem_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(tidem_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_TIDEM_E);
}

sxd_status_t sxd_access_reg_fgcr(struct ku_fgcr_reg      *fgcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FGCR_E);
}

sxd_status_t sxd_access_reg_fpums(struct ku_fpums_reg     *fpums_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(fpums_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FPUMS_E);
}

sxd_status_t sxd_access_reg_fphhc(struct ku_fphhc_reg     *fphhc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(fphhc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FPHHC_E);
}

sxd_status_t sxd_access_reg_fppc(struct ku_fppc_reg      *fppc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fppc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FPPC_E);
}

sxd_status_t sxd_access_reg_fpftt(struct ku_fpftt_reg     *fpftt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(fpftt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FPFTT_E);
}

sxd_status_t sxd_access_reg_fphtt(struct ku_fphtt_reg     *fphtt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(fphtt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FPHTT_E);
}

sxd_status_t sxd_access_reg_fpts(struct ku_fpts_reg      *fpts_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fpts_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FPTS_E);
}

sxd_status_t sxd_access_reg_fmqc(struct ku_fmqc_reg      *fmqc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fmqc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FMQC_E);
}

sxd_status_t sxd_access_reg_fmtpc(struct ku_fmtpc_reg     *fmtpc_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(fmtpc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FMTPC_E);
}

sxd_status_t sxd_access_reg_fmtpa(struct ku_fmtpa_reg     *fmtpa_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(fmtpa_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FMTPA_E);
}

sxd_status_t sxd_access_reg_fmtb(struct ku_fmtb_reg      *fmtb_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fmtb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FMTB_E);
}

sxd_status_t sxd_access_reg_fmtc(struct ku_fmtc_reg      *fmtc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fmtc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FMTC_E);
}

sxd_status_t sxd_access_reg_fmte(struct ku_fmte_reg      *fmte_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fmte_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FMTE_E);
}

sxd_status_t sxd_access_reg_fmtm(struct ku_fmtm_reg      *fmtm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fmtm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FMTM_E);
}

sxd_status_t sxd_access_reg_fmep(struct ku_fmep_reg      *fmep_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fmep_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FMEP_E);
}

sxd_status_t sxd_access_reg_fsgcr(struct ku_fsgcr_reg     *fsgcr_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(fsgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FSGCR_E);
}

sxd_status_t sxd_access_reg_fsdb(struct ku_fsdb_reg      *fsdb_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fsdb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FSDB_E);
}

sxd_status_t sxd_access_reg_fspt(struct ku_fspt_reg      *fspt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fspt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FSPT_E);
}

sxd_status_t sxd_access_reg_fsdc(struct ku_fsdc_reg      *fsdc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fsdc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FSDC_E);
}

sxd_status_t sxd_access_reg_fsps(struct ku_fsps_reg      *fsps_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fsps_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FSPS_E);
}

sxd_status_t sxd_access_reg_fstm(struct ku_fstm_reg      *fstm_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fstm_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FSTM_E);
}

sxd_status_t sxd_access_reg_fsed(struct ku_fsed_reg      *fsed_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fsed_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FSED_E);
}

sxd_status_t sxd_access_reg_fshe(struct ku_fshe_reg      *fshe_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fshe_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FSHE_E);
}

sxd_status_t sxd_access_reg_fsfh(struct ku_fsfh_reg      *fsfh_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(fsfh_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_FSFH_E);
}

sxd_status_t sxd_access_reg_xgcr(struct ku_xgcr_reg      *xgcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(xgcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_XGCR_E);
}

sxd_status_t sxd_access_reg_xltq(struct ku_xltq_reg      *xltq_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(xltq_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_XLTQ_E);
}

sxd_status_t sxd_access_reg_xmdr(struct ku_xmdr_reg      *xmdr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(xmdr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_XMDR_E);
}

sxd_status_t sxd_access_reg_xlkbu(struct ku_xlkbu_reg     *xlkbu_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(xlkbu_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_XLKBU_E);
}

sxd_status_t sxd_access_reg_xrmt(struct ku_xrmt_reg      *xrmt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(xrmt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_XRMT_E);
}

sxd_status_t sxd_access_reg_xralta(struct ku_xralta_reg    *xralta_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(xralta_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_XRALTA_E);
}

sxd_status_t sxd_access_reg_xralst(struct ku_xralst_reg    *xralst_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(xralst_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_XRALST_E);
}

sxd_status_t sxd_access_reg_xraltb(struct ku_xraltb_reg    *xraltb_reg_data,
                                   sxd_reg_meta_t          *reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                    *context)
{
    return sxd_access_reg_common(xraltb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_XRALTB_E);
}

sxd_status_t sxd_access_reg_ugcap(struct ku_ugcap_reg     *ugcap_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(ugcap_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UGCAP_E);
}

sxd_status_t sxd_access_reg_upcap(struct ku_upcap_reg     *upcap_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(upcap_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UPCAP_E);
}

sxd_status_t sxd_access_reg_ugcr(struct ku_ugcr_reg      *ugcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(ugcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UGCR_E);
}

sxd_status_t sxd_access_reg_upcon(struct ku_upcon_reg     *upcon_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(upcon_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UPCON_E);
}

sxd_status_t sxd_access_reg_umtu(struct ku_umtu_reg      *umtu_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(umtu_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UMTU_E);
}

sxd_status_t sxd_access_reg_uver(struct ku_uver_reg      *uver_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(uver_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UVER_E);
}

sxd_status_t sxd_access_reg_upvc(struct ku_upvc_reg      *upvc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(upvc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UPVC_E);
}

sxd_status_t sxd_access_reg_upaft(struct ku_upaft_reg     *upaft_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(upaft_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UPAFT_E);
}

sxd_status_t sxd_access_reg_utar(struct ku_utar_reg      *utar_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(utar_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UTAR_E);
}

sxd_status_t sxd_access_reg_upbt(struct ku_upbt_reg      *upbt_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(upbt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UPBT_E);
}

sxd_status_t sxd_access_reg_utce(struct ku_utce_reg      *utce_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(utce_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UTCE_E);
}

sxd_status_t sxd_access_reg_urcr(struct ku_urcr_reg      *urcr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(urcr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_URCR_E);
}

sxd_status_t sxd_access_reg_usadb(struct ku_usadb_reg     *usadb_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(usadb_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_USADB_E);
}

sxd_status_t sxd_access_reg_usak(struct ku_usak_reg      *usak_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(usak_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_USAK_E);
}

sxd_status_t sxd_access_reg_usacn(struct ku_usacn_reg     *usacn_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(usacn_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_USACN_E);
}

sxd_status_t sxd_access_reg_utcc(struct ku_utcc_reg      *utcc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(utcc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UTCC_E);
}

sxd_status_t sxd_access_reg_upcnt(struct ku_upcnt_reg     *upcnt_reg_data,
                                  sxd_reg_meta_t          *reg_meta,
                                  uint32_t                 data_num,
                                  sxd_completion_handler_t handler,
                                  void                    *context)
{
    return sxd_access_reg_common(upcnt_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UPCNT_E);
}

sxd_status_t sxd_access_reg_uccr(struct ku_uccr_reg      *uccr_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(uccr_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UCCR_E);
}

sxd_status_t sxd_access_reg_utfd(struct ku_utfd_reg      *utfd_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(utfd_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UTFD_E);
}

sxd_status_t sxd_access_reg_utfc(struct ku_utfc_reg      *utfc_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(utfc_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UTFC_E);
}

sxd_status_t sxd_access_reg_uter(struct ku_uter_reg      *uter_reg_data,
                                 sxd_reg_meta_t          *reg_meta,
                                 uint32_t                 data_num,
                                 sxd_completion_handler_t handler,
                                 void                    *context)
{
    return sxd_access_reg_common(uter_reg_data,
                                 reg_meta,
                                 data_num,
                                 handler,
                                 context,
                                 SXD_REG_ID_UTER_E);
}
