/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <stdio.h>
#include <limits.h>
#include <time.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/sxd_emad_reg.h>
#include <sx/sxd/sxd_emad_parser.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_access_register_init.h>
#include <sys/time.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <getopt.h>

#include "../../emad/emad.h"
#include "../common/sniffer_common.h"
#include "../../reg_access/sxd_access_reg_infra.h"

#undef  __MODULE__
#define __MODULE__ SXD_PLAYER

#define SMALLER_THAN \
    <
#define CHECK_RC if (rc) {return 1; }

#define READ_AND_CHECK(ptr, size, stream) if (read_and_check(ptr, size, stream)) {goto cleanup; }

#define HEXDUMP_LINE (0x10)
/*
 * Characters              = HEXDUMP
 * \n\0                    = 1
 * */
#define CHARDUMP_LINE (HEXDUMP_LINE + 1)

/* Line start is '\t%04X:' = 6
 * BYTES with spaces       = 3 * HEXDUMP_LINE
 * Space                   = 1
 * Char Dump               = HEXDUMP
 * \n\0                    = 2
 */
#define HEXDUMP_PRINT_LINE (6 + (3 * HEXDUMP_LINE) + 1 + CHARDUMP_LINE + 2)

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;


sxd_status_t sxd_sniffer_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    SX_LOG_EXIT();
    return err;
}

typedef struct timespec timespec_t;
typedef struct timeval timeval_t;

typedef enum {
    CMD_EMAD_E,
    CMD_IOCTRL_E
} cmd_type_e;

typedef enum {
    SLEEP_TIME_DIFF_E,
    SLEEP_REAL_TIME_E,
    NO_SLEEP_E
} sniffer_times_type_e;

typedef struct times {
    sniffer_times_type_e type;
    timeval_t            before_real_cmd; /* time before running the command here in the sniffer runner */
    timeval_t            after_real_cmd; /* time after running the command here in the sniffer runner */
    timeval_t            real_cmd_diff; /* time between the two above */
    timeval_t            old_cmd_start_time; /* the time that the previous command started in the recorder */
    timeval_t            old_cmd_end_time; /* the time that the previous command ended in the recorder */
    timeval_t            new_cmd_start_time; /* the time that the current command started in the recorder */
    timeval_t            new_cmd_end_time; /* the time that the current command ended in the recorder */
    timeval_t            time_to_sync; /* time left over from previous commands. */
} sniffer_times_t;

typedef struct sniffer_config {
    boolean_t debug_mode;
    boolean_t dry_run;
} sniffer_config_t;

/*
 * fread wrapper, calling fread with count = 1.
 */
static int read_and_check(void * ptr, size_t size, FILE * stream)
{
    size_t rc;

    if (size > 0) {
        rc = fread(ptr, size, 1, stream);
        if (rc != 1) {
            perror("The following error occurred");
            SX_LOG_ERR("Failed to read from file. \n");
            return 1;
        }
    }
    return 0;
}

void svl_log_cb(IN sx_log_severity_t severity, IN const char *module_name, IN char *msg)
{
    sx_verbosity_level_t verbosity = 0;

    SEVERITY_LEVEL_TO_VERBOSITY_LEVEL(severity, verbosity);
    printf("[%-20s][%s] : %s", module_name, SX_VERBOSITY_LEVEL_STR(verbosity), msg);

    return;
}

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/*
 * using this function when ioctl was called with raw_buff cmd, since raw_buff structure has a pointer in his
 * struct the data that is been pointed to must be read as well.
 */
static int __read_reg_raw_buff(FILE *ioctl_file_p, struct ku_access_reg_raw_buff *reg_raw, void **raw_buff)
{
    READ_AND_CHECK(&reg_raw->raw_buff.size, sizeof(uint16_t), ioctl_file_p);
    /* coverity[tainted_data] */
    *raw_buff = malloc(reg_raw->raw_buff.size);
    if (*raw_buff == NULL) {
        goto cleanup;
    }
    READ_AND_CHECK(*raw_buff, reg_raw->raw_buff.size, ioctl_file_p);
    reg_raw->raw_buff.buff = *raw_buff;

    return 0;
cleanup:
    return 1;
}

/*
 * using this function when ioctl was called with raw cmd, since raw structure has a pointer in his
 * struct the data that is been pointed to must be read as well.
 */
static int __read_reg_raw(FILE *ioctl_file_p, struct ku_access_raw_reg *reg_raw, void **raw_buff)
{
    READ_AND_CHECK(&reg_raw->raw_reg.size, sizeof(uint16_t), ioctl_file_p);
    /* coverity[tainted_data] */
    *raw_buff = malloc(reg_raw->raw_reg.size);
    if (*raw_buff == NULL) {
        goto cleanup;
    }
    READ_AND_CHECK(*raw_buff, reg_raw->raw_reg.size, ioctl_file_p);
    reg_raw->raw_reg.buff = *raw_buff;

    return 0;
cleanup:
    return 1;
}

/*
 * read the times the command was made at and when it ended.
 */
static int __read_time(sniffer_times_t *times, FILE *file_stream)
{
    int rc;

    rc = fread(&times->new_cmd_start_time, sizeof(timeval_t), 1, file_stream);
    if (rc != 1) {
        SX_LOG_ERR("Failed to read from file. \n");
        return 1;
    }
    rc = fread(&times->new_cmd_end_time, sizeof(timeval_t), 1, file_stream);
    if (rc != 1) {
        SX_LOG_ERR("Failed to read from file. \n");
        return 1;
    }
    return 0;
}

/*
 * print the position in the file.
 */
static int __print_pos(FILE *file_stream, boolean_t debug_mode)
{
    long int        pos = 0;
    static long int iteration_s = 1;

    if (debug_mode == FALSE) {
        return 0;
    }

    pos = ftell(file_stream);
    if (pos == -1) {
        printf("could not get the file position");
        return 1;
    }

    printf("\niteration: %ld. file position is 0X%lX bytes.\n", iteration_s, pos);
    iteration_s += 1;
    return 0;
}

/*
 * getting next call, is it ioctl or emad
 */
static int __get_next_call(cmd_type_e *is_ioctl_next, FILE *file_stream, sniffer_config_t *sniffer_conf)
{
    int rc;

    rc = __print_pos(file_stream, sniffer_conf->debug_mode);
    if (rc != 0) {
        return 1;
    }

    /*
     * ioctl = 1
     * emad = 0
     */
    rc = fread(is_ioctl_next, sizeof(int), 1, file_stream);
    if (rc != 1) {
        if (feof(file_stream) != 0) {
            printf("reached EOF. \n");
        } else {
            SX_LOG_ERR("Failed to read from file. \n");
            return 1;
        }
    }
    return 0;
}

static void __emad_malloc_clean_up(char    *emad_data,
                                   uint32_t emad_data_num,
                                   uint32_t emad_size_of_data_sturct,
                                   uint32_t offset_to_reg)
{
    void *emad_pointer_to_reg = 0;
    int   i = 0;

    for (i = 0; i < (int)emad_data_num; i++) {
        emad_pointer_to_reg = emad_data + emad_size_of_data_sturct * i;
        /* Jump over the header. */
        /* the last variable of the structure is a pointer to the the register. */
        emad_pointer_to_reg += offset_to_reg;
        free(*(char**)emad_pointer_to_reg);
    }
    free(emad_data);
}

static int __nano_sleep(timeval_t *time_diff, char *desc)
{
    int        rc;
    timespec_t timespec_s;

    memset(&timespec_s, 0, sizeof(timespec_t));

    timespec_s.tv_sec = time_diff->tv_sec;
    timespec_s.tv_nsec = time_diff->tv_usec * 1000;
    /* This print is a continuous print, started at __recreate_ioctl_cmd or recreate_emad_cmd */
    /* Before calling to nano_sleep */
    if (desc != NULL) {
        printf("%s for %ld seconds and %ld nanoseconds seconds.\n", desc, timespec_s.tv_sec, timespec_s.tv_nsec);
    }
    rc = nanosleep(&timespec_s, &timespec_s);
    if (rc == -1) {
        SX_LOG_ERR("failed to sleep, time left is:\n");
        SX_LOG_ERR("sec %ld.\n", timespec_s.tv_sec);
        SX_LOG_ERR("nanoseconds sec %ld.\n", timespec_s.tv_nsec);
        return 1;
    }
    return 0;
}
/* sleep according to sleep type */
static int __sleep_according_type(sniffer_times_t *times, FILE *file_p, char *desc)
{
    timeval_t time_diff;
    timeval_t end_time;
    int       rc;

    memset(&time_diff, 0, sizeof(timeval_t));
    memset(&end_time, 0, sizeof(timeval_t));

    rc = __read_time(times, file_p);
    if (rc != 0) {
        return 1;
    }

    /*
     * this is special case for the first iteration.
     * does not sleep, just save the timing so we know the time different for next command
     */
    if ((times->old_cmd_start_time.tv_sec == 0) && (times->old_cmd_start_time.tv_usec == 0)) {
        times->old_cmd_start_time = times->new_cmd_start_time;
        times->old_cmd_end_time = times->new_cmd_end_time;
        return 0;
    }

    switch (times->type) {
    /*
     * go to sleep the time between the end of last command to the start of this command.
     */
    case SLEEP_TIME_DIFF_E:
        if (timercmp(&times->old_cmd_end_time, &times->new_cmd_start_time, SMALLER_THAN)) {
            timersub(&times->new_cmd_start_time, &times->old_cmd_end_time, &time_diff);

            __nano_sleep(&time_diff, desc);
        }
        times->old_cmd_end_time = times->new_cmd_end_time;
        times->old_cmd_start_time = times->new_cmd_start_time;
        break;

    /* try to run so the timing will be as close as possible to the recorded timing */
    case SLEEP_REAL_TIME_E:
        timeradd(&times->old_cmd_start_time, &times->real_cmd_diff, &end_time);
        /* adding the left over from previous run. */
        timeradd(&end_time, &times->time_to_sync, &end_time);
        /* if performing the command in the sniffer runner took more time than */
        /* it took when recorded + waiting for the next command + left over from previous command. */
        if (timercmp(&times->new_cmd_start_time, &end_time, SMALLER_THAN)) {
            timersub(&end_time, &times->new_cmd_start_time, &time_diff);
            times->time_to_sync = time_diff;
        } else {
            timersub(&times->new_cmd_start_time, &end_time, &time_diff);
            memset(&times->time_to_sync, 0, sizeof(timeval_t));
            __nano_sleep(&time_diff, desc);
        }
        times->old_cmd_end_time = times->new_cmd_end_time;
        times->old_cmd_start_time = times->new_cmd_start_time;
        break;

    case NO_SLEEP_E:
        return 0;
        break;
    }
    return 0;
}

/*
 * read and print(if debug mode) the pid of the process that made the call(the ioctl or emad call).
 */
static int __print_pid(FILE *file_stream, boolean_t debug_mode)
{
    pid_t process_id = 0;

    READ_AND_CHECK(&process_id,  sizeof(pid_t), file_stream);

    if (debug_mode == TRUE) {
        /* read process id */
        printf("PID is %d.\n", process_id);
    }

    return 0;

cleanup:
    return 1;
}

/*
 * print the buffer just like linux hex dump.
 */
static void __hex_dump(char *desc, void *addr, unsigned int len)
{
    unsigned int   i = 0;
    unsigned int   print_len = 0;
    unsigned char  line_dump[HEXDUMP_PRINT_LINE];
    unsigned char  char_dump[CHARDUMP_LINE];
    unsigned char *pc = (unsigned char*)addr;
    char          *pLine = NULL;

    memset(line_dump, 0, sizeof(line_dump));
    memset(char_dump, 0, sizeof(char_dump));

    /* Output the description string */
    if (desc != NULL) {
        printf("%s (len=%d):\n", desc, len);
    }

    if (len == 0) {
        return;
    }

    /* Align the output */
    print_len = len;
    if ((print_len % HEXDUMP_LINE) != 0) {
        print_len += (HEXDUMP_LINE - (print_len % HEXDUMP_LINE));
    }

    /* Processes the data */
    for (i = 0; TRUE; i++) {
        /* Is this a new line ? */
        if ((i % HEXDUMP_LINE) == 0) {
            /* Append and print (Only after first cycle is done) */
            if (i != 0) {
                sprintf(pLine, "  %s\n", char_dump);
                printf("%s", line_dump);

                /* Stop the loop */
                if (i == print_len) {
                    break;
                }
            }

            /* Output the offset. */
            pLine = (char*)&line_dump[0];
            pLine += sprintf(pLine, "\t%04x:", i);
        }

        /* In case we are out of boundaries, just append spaces and continue. */
        if (i >= len) {
            pLine += sprintf(pLine, "   ");
            continue;
        }

        /* Now the hex code for the specific character. */
        pLine += sprintf(pLine, " %02x", pc[i]);

        /* And store a printable ASCII character for later. */
        if ((pc[i] < ' ') || (pc[i] > '~')) {
            char_dump[i % HEXDUMP_LINE] = '.';
        } else {
            char_dump[i % HEXDUMP_LINE] = pc[i];
        }
        char_dump[(i % HEXDUMP_LINE) + 1] = '\0';
    }
}

/*
 * using this function when ioctl was called with raw cmd, since raw structure has a pointer in his
 * struct the data that is been pointed to must be read as well.
 */
static int __handle_reg_raw(FILE *ioctl_file_p, sxd_ctrl_pack_t *pack_p, void **raw_reg_buffer, boolean_t debug_mode)
{
    int rc;

    if (pack_p->ctrl_cmd == CTRL_CMD_ACCESS_REG_RAW_BUFF) {
        rc = __read_reg_raw_buff(ioctl_file_p, (struct ku_access_reg_raw_buff *)pack_p->cmd_body, raw_reg_buffer);
        if (rc != 0) {
            return 1;
        }
        if (debug_mode == TRUE) {
            __hex_dump("ioctl reg_raw_buff", (unsigned char*)*raw_reg_buffer,
                       ((struct ku_access_reg_raw_buff *)pack_p->cmd_body)->raw_buff.size);
        }
    } else if (pack_p->ctrl_cmd == CTRL_CMD_ACCESS_REG_RAW) {
        rc = __read_reg_raw(ioctl_file_p, (struct ku_access_raw_reg *)pack_p->cmd_body, raw_reg_buffer);
        if (rc != 0) {
            return 1;
        }
        if (debug_mode == TRUE) {
            __hex_dump("ioctl reg_raw",
                       (unsigned char*)*raw_reg_buffer,
                       ((struct ku_access_raw_reg *)pack_p->cmd_body)->raw_reg.size);
        }
    }
    return 0;
}

/*
 * calculate the time it took to make the real command, in this runner.
 */
static void __calc_real_time_diff(sniffer_times_t *times)
{
    timersub(&times->after_real_cmd, &times->before_real_cmd, &times->real_cmd_diff);
    timeradd(&times->old_cmd_start_time, &times->real_cmd_diff, &times->old_cmd_end_time);
}

/*
 * recreating the ioctl recorded cmd.
 */
static int __recreate_ioctl_cmd(FILE             *ioctl_file_p,
                                sxd_handle        my_handle,
                                sniffer_times_t  *times,
                                sniffer_config_t *sniffer_conf)
{
    sxd_ctrl_pack_t   pack_p;
    sxd_handle        handle = 0;
    ioctl_data_type_e type = 0;
    sxd_status_t      command_rc = SXD_STATUS_SUCCESS;
    const char       *cmd_name = NULL;
    int               rc = 0;
    int               ioctl_cmd = 0;
    int               size = 0;
    void             *ioctl_buffer = NULL;
    void             *raw_reg_buffer = NULL;
    int               ret_code = 1;

    memset(&pack_p, 0, sizeof(sxd_ctrl_pack_t));

    printf("ioctl: recreating ioctl command.\n");

    rc = __print_pid(ioctl_file_p, sniffer_conf->debug_mode);
    CHECK_RC;

    /* read cmd */
    READ_AND_CHECK(&ioctl_cmd, sizeof(int), ioctl_file_p);

    /* read handle */
    READ_AND_CHECK(&handle, sizeof(sxd_handle), ioctl_file_p);
    if (sniffer_conf->debug_mode == TRUE) {
        /* since handle is not used print it only on debug mode */
        printf("ioctl: handle = %d.\n", handle);
    }

    /*
     * the handle received from the recording was the handle used to talk to the driver
     * when the recording was done, this handle have been destroyed when the program stopped recording.
     * so we created a new handle to talk to the driver with, and we are going to use this handle
     * instead.
     */
    handle = my_handle;

    rc = ioctl_cmd_info_get(ioctl_cmd, &size, &type, &cmd_name);
    CHECK_RC;
    printf("ioctl: ctrl_cmd = %s.\n", cmd_name);

    printf("ioctl: size = %d.\n", size);
    if (size > 0) {
        ioctl_buffer = malloc(size);

        if (ioctl_buffer == NULL) {
            SX_LOG_ERR("ioctl: malloc failed.\n");
            goto cleanup;
        }
    }

    /* read buff */
    READ_AND_CHECK(ioctl_buffer, size, ioctl_file_p);

    /* creating the cmd. */
    pack_p.ctrl_cmd = ioctl_cmd;

    switch (type) {
    case IOCTL_DATA_IS_POINTER_E:
        printf("ioctl: data sent by pointer.\n");
        pack_p.cmd_body = ioctl_buffer;
        break;

    case IOCTL_DATA_IS_AS_IS_E:
        printf("ioctl: data sent as is.\n");
        if (size > (int)sizeof(pack_p.cmd_body)) {
            SX_LOG_ERR("ioctl_buffer does not fit inside pack_p.cmd_body\n");
            goto cleanup;
        }
        if (size > 0) {
            memcpy(&pack_p.cmd_body, ioctl_buffer, size);
        }
        break;
    }

    if (sniffer_conf->debug_mode == TRUE) {
        __hex_dump("ioctl buffer", (unsigned char*)ioctl_buffer, size);
    }

    /* read and print the raw register(reg_raw and raw_buff registers). */
    /* coverity[var_deref_model] */
    __handle_reg_raw(ioctl_file_p, &pack_p, &raw_reg_buffer, sniffer_conf->debug_mode);

    rc = __sleep_according_type(times, ioctl_file_p, "ioctl: go to sleep");
    if (rc != 0) {
        SX_LOG_ERR("ioctl: sleep failed\n");
        goto cleanup;
    }

    READ_AND_CHECK(&command_rc, sizeof(sxd_status_t), ioctl_file_p);
    printf("ioctl: expecting rc %s .\n", SXD_STATUS_MSG(command_rc));

    rc = gettimeofday(&times->before_real_cmd, NULL);
    if (rc != 0) {
        SX_LOG_ERR("gettimeofday failed, return code: %d\n", rc);
        goto cleanup;
    }

    if (sniffer_conf->dry_run == FALSE) {
        /* call the real command */
        rc = sxd_ioctl(handle, &pack_p);

        if ((sxd_status_t)rc != command_rc) {
            SX_LOG_ERR("ioctl: sxd_ioctl call failed %s, errno=%d\n", SXD_STATUS_MSG(rc), errno);
            SX_LOG_ERR("Expected rc %s (%d), received %s (%d)\n",
                       SXD_STATUS_MSG(command_rc), command_rc, SXD_STATUS_MSG(rc), rc);
            goto cleanup;
        }
    }

    rc = gettimeofday(&times->after_real_cmd, NULL);
    if (rc != 0) {
        SX_LOG_ERR("gettimeofday failed, return code: %d\n", rc);
        goto cleanup;
    }

    __calc_real_time_diff(times);

    ret_code = 0;
cleanup:
    if (ioctl_buffer != NULL) {
        free(ioctl_buffer);
        ioctl_buffer = NULL;
    }
    if (raw_reg_buffer != NULL) {
        free(raw_reg_buffer);
        raw_reg_buffer = NULL;
    }
    return ret_code;
}

/*
 * recreating the emad recorded cmd.
 */
static int __recreating_emad_cmd(FILE *emad_file_p, sniffer_times_t    *times, sniffer_config_t   *sniffer_conf)
{
    sxd_emad_data_t                     *emad_data = NULL;
    sxd_reg_id_e                         emad_reg_id = 0;
    sxd_status_t                         command_rc = SXD_STATUS_SUCCESS;
    uint32_t                             emad_data_num = 0;
    int                                  emad_size_of_data_sturct = 0;
    int                                  emad_size_of_reg_sturct = 0;
    int                                  rc = 1, i = 0;
    int                                  ret_code = 1;
    unsigned int                         emad_ptr_offset = 0;
    unsigned int                         emad_reg_offset = 0;
    const char                          *cmd_name = NULL;
    void                                *emad_pointer_to_reg = NULL;
    void                                *emad_pointer_to_new_reg = NULL;
    const struct access_reg_emad_params *reg_emad_params_p = NULL;

    printf("emad: recreating emad command.\n");

    rc = __print_pid(emad_file_p, sniffer_conf->debug_mode);
    CHECK_RC;

    /* get reg_id */
    READ_AND_CHECK(&emad_reg_id, sizeof(sxd_reg_id_e), emad_file_p);

    /* get data_num */
    READ_AND_CHECK(&emad_data_num, sizeof(uint32_t), emad_file_p);

    /* get data_sturct_size */
    rc = get_emad_data_struct_size(emad_reg_id, &emad_size_of_data_sturct, NULL, &cmd_name, FETCH_EMAD_STRUCT_SIZE_E);
    CHECK_RC;

    /* get reg sturct_size */
    rc =
        get_emad_data_struct_size(emad_reg_id, &emad_size_of_reg_sturct, &emad_reg_offset, NULL,
                                  FETCH_EMAD_REG_SIZE_E);
    CHECK_RC;

    printf("emad: reg name: %s.\n", cmd_name);
    printf("emad: data num %d.\n", (uint32_t)emad_data_num);
    printf("emad: size of the struct is %d.\n", (uint32_t)emad_size_of_data_sturct);
    printf("emad: size of the register is %d.\n", (uint32_t)emad_size_of_reg_sturct);

    emad_data = (sxd_emad_data_t*)malloc(emad_size_of_data_sturct * emad_data_num);
    if (emad_data == NULL) {
        SX_LOG_ERR("emad: malloc failed.\n");
        goto cleanup;
    }

    for (i = 0; i < (int)emad_data_num; i++) {
        emad_ptr_offset = emad_size_of_data_sturct * i;

        READ_AND_CHECK(((char*)emad_data + emad_ptr_offset), emad_size_of_data_sturct, emad_file_p);

        if (sniffer_conf->debug_mode == TRUE) {
            __hex_dump("emad struct buffer",
                       (unsigned char*)((char*)emad_data + emad_ptr_offset),
                       emad_size_of_data_sturct);
        }

        /* Jump over the header. */
        /* the last variable of the structure is a pointer to the the register. */
        emad_ptr_offset += emad_reg_offset;

        emad_pointer_to_reg = (((char*)emad_data) + emad_ptr_offset);

        emad_pointer_to_new_reg = malloc(emad_size_of_reg_sturct);
        if (emad_pointer_to_new_reg == NULL) {
            SX_LOG_ERR("emad: malloc failed.\n");
            goto cleanup;
        }

        if (read_and_check(emad_pointer_to_new_reg,  emad_size_of_reg_sturct, emad_file_p)) {
            if (emad_pointer_to_new_reg != NULL) {
                free(emad_pointer_to_new_reg);
                emad_pointer_to_new_reg = NULL;
            }
            goto cleanup;
        }

        if (sniffer_conf->debug_mode == TRUE) {
            __hex_dump("emad reg buffer:", (unsigned char*)emad_pointer_to_new_reg, emad_size_of_reg_sturct);
        }

        *(char**)emad_pointer_to_reg = (char*)emad_pointer_to_new_reg;
    }

    rc = __sleep_according_type(times, emad_file_p, "emad: go to sleep");
    if (rc != 0) {
        SX_LOG_ERR("emad: sleep failed\n");
        goto cleanup;
    }

    READ_AND_CHECK(&command_rc, sizeof(sxd_status_t), emad_file_p);
    printf("emad: expecting rc %s.\n", SXD_STATUS_MSG(command_rc));

    rc = gettimeofday(&times->before_real_cmd, NULL);
    if (rc != 0) {
        SX_LOG_ERR("gettimeofday failed, return code: %d\n", rc);
        goto cleanup;
    }

    if (sniffer_conf->dry_run == FALSE) {
        /* call the real command */
        reg_emad_params_p = sxd_register_get_emad_params(emad_reg_id);
        if (reg_emad_params_p == NULL) {
            rc = emad_common_set(emad_data, emad_data_num,
                                 emad_reg_id, NULL, NULL);
        } else {
            rc = emad_common_set_ex((struct sxd_emad_general_reg_data *)emad_data,
                                    emad_data_num,
                                    emad_reg_id,
                                    NULL,
                                    NULL,
                                    reg_emad_params_p);
        }


        if ((sxd_status_t)rc != command_rc) {
            SX_LOG_ERR("emad: calling emad_common_set failed, rc = %s.\n", SXD_STATUS_MSG(rc));
            SX_LOG_ERR("Expected rc %s (%d), received %s (%d)\n",
                       SXD_STATUS_MSG(command_rc), command_rc, SXD_STATUS_MSG(rc), rc);
            goto cleanup;
        }
    }

    rc = gettimeofday(&times->after_real_cmd, NULL);
    if (rc != 0) {
        SX_LOG_ERR("gettimeofday failed, return code: %d\n", rc);
        goto cleanup;
    }

    __calc_real_time_diff(times);

    ret_code = 0;
cleanup:
    if (emad_data != NULL) {
        __emad_malloc_clean_up((char*)emad_data, i,
                               emad_size_of_data_sturct, emad_reg_offset);
    }
    return ret_code;
}


static int __create_handle(sxd_handle *my_handle)
{
    uint32_t dev_num = 1;
    char     dev_name[1][100];
    char    *dev[1];
    int      rc;

    dev[0] = dev_name[0];

    /* get device list from the devices directory */
    rc = sxd_get_dev_list(dev, &dev_num);
    if (rc != 0) {
        SX_LOG_ERR("sxd_get_dev_list error %s\n", strerror(errno));
        return 1;
    }

    if (0 == dev_num) {
        SX_LOG_ERR("dev list is empty, check if driver is down\n");
        return 1;
    }

    /* open the first device */
    rc = sxd_open_device(dev_name[0], my_handle);
    if (rc != 0) {
        SX_LOG_ERR("sxd_open_device error %s\n", strerror(errno));
        return 1;
    }
    return 0;
}


static int __parse_arg(int argc, char* argv[], FILE **file_p, sniffer_times_t *times, sniffer_config_t *sniffer_conf)
{
    int                  c = 0;
    int                  option_index = 0;
    static struct option long_options[] = {
        /* These options set a flag. */
        {"sxd_recording", required_argument,   0, 'r'},
        {"dry_run", no_argument,               0, 'd'},
        {"debug_mode", no_argument,            0, 'b'},
        {"sleep_mode", required_argument,      0, 's'},
        {0, 0, 0, 0}
    };

    sniffer_conf->dry_run = FALSE;
    sniffer_conf->debug_mode = FALSE;
    times->type = SLEEP_TIME_DIFF_E;
    while (1) {
        c = getopt_long(argc, argv, "", long_options, &option_index);
        /* Detect the end of the options. */
        if (c == -1) {
            break;
        }
        switch (c) {
        case 'r':
            *file_p = fopen(optarg, "r");
            if (*file_p == NULL) {
                SX_LOG_ERR("Failed to open ioctl sniffed file %s. \n", optarg);
                return 1;
            }
            break;

        case 'd':
            sniffer_conf->dry_run = TRUE;
            break;

        case 'b':
            sniffer_conf->debug_mode = TRUE;
            break;

        case 's':
            if (strcmp(optarg, "real") == 0) {
                times->type = SLEEP_REAL_TIME_E;
            } else if (strcmp(optarg, "diff") == 0) {
                times->type = SLEEP_TIME_DIFF_E;
            } else if (strcmp(optarg, "no_sleep") == 0) {
                times->type = NO_SLEEP_E;
            } else {
                SX_LOG_ERR("please provide one of the following for sleep mode: \"real\", \"diff\" or \"no_sleep\".\n");
                return 1;
            }
            break;

        default:
            SX_LOG_ERR("invalid argument.\n");
            return 1;
        }
    }

    if (*file_p == NULL) {
        SX_LOG_ERR("please provide path to sxd_recording.\n");
        return 1;
    }

    return 0;
}

/************************************************
 *  Function implementations
 ***********************************************/


int main(int argc, char* argv[])
{
    FILE            *file_p = NULL;
    int              rc = 0;
    cmd_type_e       run_cmd = CMD_IOCTRL_E;
    int              main_ret = 1;
    sxd_handle       ioctl_dev_handle = -1;
    sniffer_times_t  times;
    sniffer_config_t sniffer_conf;

    memset(&times, 0, sizeof(sniffer_times_t));
    memset(&sniffer_conf, 0, sizeof(sniffer_config_t));

    rc = sxd_access_reg_init(0, svl_log_cb, SX_VERBOSITY_LEVEL_INFO);
    if (rc != 0) {
        SX_LOG_ERR("Init error.\n");
        goto cleanup;
    }

    rc = __parse_arg(argc, argv, &file_p, &times, &sniffer_conf);
    if (rc != 0) {
        goto cleanup;
    }
    printf("SDK sniffer runner starting. \n");


    /* we created a new handle to talk to the driver with when doing ioctl commands. */
    rc = __create_handle(&ioctl_dev_handle);
    if (rc != 0) {
        return -1;
    }

    /* getting next call, is it ioctl or emad */
    rc = __get_next_call(&run_cmd, file_p, &sniffer_conf);
    if (rc != 0) {
        goto cleanup;
    }

    /* run until file ends. */
    while (feof(file_p) == 0) {
        /* run ioctl */
        if (run_cmd == CMD_IOCTRL_E) {
            rc = __recreate_ioctl_cmd(file_p, ioctl_dev_handle, &times, &sniffer_conf);
            if (rc != 0) {
                goto cleanup;
            }
        } else { /* run emad */
            rc = __recreating_emad_cmd(file_p, &times, &sniffer_conf);
            if (rc != 0) {
                goto cleanup;
            }
        }
        /* getting next call, is it ioctl or emad */
        rc = __get_next_call(&run_cmd, file_p, &sniffer_conf);
        if (rc != 0) {
            goto cleanup;
        }
    }

    main_ret = 0;
cleanup:
    if (NULL != file_p) {
        fclose(file_p);
        file_p = NULL;
    }

    if (-1 != ioctl_dev_handle) {
        sxd_close_device(ioctl_dev_handle);
        ioctl_dev_handle = -1;
    }

    if (0 == main_ret) {
        printf("SDK sniffer runner done.\n");
    } else {
        SX_LOG_ERR("SDK sniffer runner FAILED.\n");
    }
    return main_ret;
}
