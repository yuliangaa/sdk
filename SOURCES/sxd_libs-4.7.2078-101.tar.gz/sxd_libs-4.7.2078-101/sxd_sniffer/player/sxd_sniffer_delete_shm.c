/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sys/mman.h>
#include <sys/stat.h> /* For mode constants */
#include <fcntl.h> /* For O_* constants */
#include <complib/cl_shared_memory.h>
#include <errno.h>
#include <semaphore.h>
#define SXD_SNIFFER_SHM_FILE "/sxd_recording"
#define SXD_SNIFFER_SEM      "/sxd_sniffer_sem"

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

int main()
{
    int rc;

    rc = cl_shm_destroy(SXD_SNIFFER_SHM_FILE);
    /* errno == 2 -> No such file or directory */
    if ((CL_ERROR == rc) && (errno != 2)) {
        printf("Failed to shm_destory sxd_sniffer shared memory. errno is %s\n", strerror(errno));
    }

    rc = sem_unlink(SXD_SNIFFER_SEM);
    /* errno == 2 -> No such file or directory */
    if ((-1 == rc) && (errno != 2)) {
        printf("Failed to sem_unlink sxd_sniffer semaphore. errno is %s\n", strerror(errno));
    }

    return 0;
}
