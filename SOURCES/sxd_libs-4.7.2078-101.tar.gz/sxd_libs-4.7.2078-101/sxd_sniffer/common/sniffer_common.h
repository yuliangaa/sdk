/*
 * Copyright (C) 2010-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_emad_reg.h>
#include <sx/sxd/sxd_emad.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Defines
 ***********************************************/


/************************************************
 *  Macros
 ***********************************************/

#define GET_REG_STRUCT_SIZE(reg_name, fetch_type) \
    ((fetch_type) ==                              \
     FETCH_EMAD_STRUCT_SIZE_E ? (sizeof(sxd_emad_ ## reg_name ## _data_t)) : (sizeof(struct ku_ ## reg_name ## _reg)))

#define GET_REG_DATA_OFFSET(reg_name) (offsetof(sxd_emad_ ## reg_name ## _data_t, reg_data))

#define GET_VAR_NAME(name) (#name)

#define GET_EMAD_INFO(struct_name_upper, struct_name_lower)    \
case SXD_REG_ID_ ## struct_name_upper ## _E:                   \
    size = GET_REG_STRUCT_SIZE(struct_name_lower, fetch_type); \
    offset = GET_REG_DATA_OFFSET(struct_name_lower);           \
    name = GET_VAR_NAME(struct_name_lower);                    \
    break;

#define IOCTL_INFO_GET(cmd, struct_name) \
case ((int)cmd):                         \
    name = #cmd;                         \
    size = sizeof(struct struct_name);   \
    break;

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum {
    IOCTL_SNIFFER_E,
    EMAD_SNIFFER_E,
    SNIFFER_RUNNER_E
} sniffer_type_e;

typedef enum {
    IOCTL_DATA_IS_POINTER_E,
    IOCTL_DATA_IS_AS_IS_E
} ioctl_data_type_e;

typedef enum {
    FETCH_EMAD_STRUCT_SIZE_E,
    FETCH_EMAD_REG_SIZE_E
} emad_fetch_type_e;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

int write_and_check(const void* ptr, size_t size, size_t count, FILE * stream, sniffer_type_e sniffer_type);

int get_emad_data_struct_size(sxd_reg_id_e reg_id, int * emad_size,
                              unsigned int *reg_offset, const char ** cmd_name, emad_fetch_type_e fetch_type);

int ioctl_cmd_info_get(int cmd, int *res, ioctl_data_type_e *type, const char **cmd_name);
