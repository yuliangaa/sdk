/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "reg_access/sxd_access_reg_infra.h"
#include "sniffer_common.h"

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/


int write_and_check(const void* ptr, size_t size, size_t count, FILE * stream, sniffer_type_e sniffer_type)
{
    int rc;

    if (size > 0) {
        rc = fwrite(ptr, size, count, stream);
        if ((size_t)rc != count) {
            perror("The following error occurred");
            if (sniffer_type == IOCTL_SNIFFER_E) {
                printf("ioctl sniffer failed writing to file. size = %d count = %d rc = %d \n",
                       (int)size,
                       (int)count,
                       rc);
            }
            if (sniffer_type == EMAD_SNIFFER_E) {
                printf("emad sniffer failed writing to file. size = %d count = %d rc = %d \n",
                       (int)size,
                       (int)count,
                       rc);
            }
            return 1;
        }
    }
    return 0;
}


int get_emad_data_struct_size(sxd_reg_id_e      reg_id,
                              int             * emad_size,
                              unsigned int     *reg_offset,
                              const char     ** cmd_name,
                              emad_fetch_type_e fetch_type)
{
    int                             rc = 0;
    int                             size = 0;
    int                             offset = 0;
    const struct sxd_register_info* reg_info;
    const char                     *name = NULL;

    reg_info = sxd_register_get_info(reg_id);
    if (reg_info) {
        size = (fetch_type == FETCH_EMAD_STRUCT_SIZE_E) ? reg_info->emad_struct_size : reg_info->reg_struct_size;
        name = reg_info->name;
        offset = offsetof(struct sxd_emad_general_reg_data, reg_data);
        goto after_reg_resolve;
    }

    switch (reg_id) {
        GET_EMAD_INFO(SBIB, sbib);
        GET_EMAD_INFO(MPAR, mpar);
        GET_EMAD_INFO(MFBA, mfba);
        GET_EMAD_INFO(MFBE, mfbe);
        GET_EMAD_INFO(MFPA, mfpa);
        GET_EMAD_INFO(SGCR, sgcr);
        GET_EMAD_INFO(SCAR, scar);
        GET_EMAD_INFO(PSPA, pspa);
        GET_EMAD_INFO(QPDP, qpdp);
        GET_EMAD_INFO(QPRT, qprt);
        GET_EMAD_INFO(QTCT, qtct);
        GET_EMAD_INFO(SSPR, sspr);
        GET_EMAD_INFO(SFD, sfd);
        GET_EMAD_INFO(SFN, sfn);
        GET_EMAD_INFO(SPGT, spgt);
        GET_EMAD_INFO(SMID, smid);
        GET_EMAD_INFO(SPMS, spms);
        GET_EMAD_INFO(SPVID, spvid);
        GET_EMAD_INFO(SPVM, spvm);
        GET_EMAD_INFO(SPVTR, spvtr);
        GET_EMAD_INFO(SPVC, spvc);
        GET_EMAD_INFO(SVER, sver);
        GET_EMAD_INFO(SFTR, sftr);
        GET_EMAD_INFO(SVPE, svpe);
        GET_EMAD_INFO(SLDR, sldr);
        GET_EMAD_INFO(SLCR, slcr);
        GET_EMAD_INFO(SLCOR, slcor);
        GET_EMAD_INFO(SLECR, slecr);
        GET_EMAD_INFO(SPMLR, spmlr);
        GET_EMAD_INFO(SVMLR, svmlr);
        GET_EMAD_INFO(SPVMLR, spvmlr);
        GET_EMAD_INFO(SPMCR, spmcr);
        GET_EMAD_INFO(SPAD, spad);
        GET_EMAD_INFO(PPSC, ppsc);
        GET_EMAD_INFO(MJTAG, mjtag);
        GET_EMAD_INFO(QPTS, qpts);
        GET_EMAD_INFO(QPCR, qpcr);
        GET_EMAD_INFO(QPBR, qpbr);
        GET_EMAD_INFO(PCAP, pcap);
        GET_EMAD_INFO(PELC, pelc);
        GET_EMAD_INFO(PMLP, pmlp);
        GET_EMAD_INFO(PFCC, pfcc);
        GET_EMAD_INFO(PMPE, pmpe);
        GET_EMAD_INFO(PLIB, plib);
        GET_EMAD_INFO(PTYS, ptys);
        GET_EMAD_INFO(PPLM, pplm);
        GET_EMAD_INFO(PLPC, plpc);
        GET_EMAD_INFO(PMAOS, pmaos);
        GET_EMAD_INFO(PPTB, pptb);
        GET_EMAD_INFO(PBMC, pbmc);
        GET_EMAD_INFO(PMPC, pmpc);
        GET_EMAD_INFO(PMCR, pmcr);
        GET_EMAD_INFO(PFSC, pfsc);
        GET_EMAD_INFO(PMMP, pmmp);
        GET_EMAD_INFO(RCAP, rcap);
        GET_EMAD_INFO(RGCR, rgcr);
        GET_EMAD_INFO(RITR, ritr);
        GET_EMAD_INFO(RIGR, rigr);
        GET_EMAD_INFO(RTAR, rtar);
        GET_EMAD_INFO(RECR, recr);
        GET_EMAD_INFO(RUFT, ruft);
        GET_EMAD_INFO(RUHT, ruht);
        GET_EMAD_INFO(RMFT, rmft);
        GET_EMAD_INFO(RATR, ratr);
        GET_EMAD_INFO(RATRAD, ratrad);
        GET_EMAD_INFO(RDPM, rdpm);
        GET_EMAD_INFO(RRCR, rrcr);
        GET_EMAD_INFO(RICA, rica);
        GET_EMAD_INFO(RICNT, ricnt);
        GET_EMAD_INFO(RTCA, rtca);
        GET_EMAD_INFO(RTPS, rtps);
        GET_EMAD_INFO(RALUE, ralue);
        GET_EMAD_INFO(HCAP, hcap);
        GET_EMAD_INFO(HDRT, hdrt);
        GET_EMAD_INFO(HCTR, hctr);
        GET_EMAD_INFO(HESPR, hespr);
        GET_EMAD_INFO(PTAR, ptar);
        GET_EMAD_INFO(PACL, pacl);
        GET_EMAD_INFO(PTCE, ptce);
        GET_EMAD_INFO(PTCE2, ptce2);
        GET_EMAD_INFO(PEFA, pefa);
        GET_EMAD_INFO(PRBT, prbt);
        GET_EMAD_INFO(PRCR, prcr);
        GET_EMAD_INFO(PFCA, pfca);
        GET_EMAD_INFO(PFCNT, pfcnt);
        GET_EMAD_INFO(MGPC, mgpc);
        GET_EMAD_INFO(PPBT, ppbt);
        GET_EMAD_INFO(PVBT, pvbt);
        GET_EMAD_INFO(PAGT, pagt);
        GET_EMAD_INFO(PVGT, pvgt);
        GET_EMAD_INFO(PLBF, plbf);
        GET_EMAD_INFO(PUET, puet);
        GET_EMAD_INFO(PGCR, pgcr);
        GET_EMAD_INFO(PECB, pecb);
        GET_EMAD_INFO(PEMB, pemb);
        GET_EMAD_INFO(PIFR, pifr);
        GET_EMAD_INFO(TNIFR, tnifr);
        GET_EMAD_INFO(MSCI, msci);
        GET_EMAD_INFO(QSPIP, qspip);
        GET_EMAD_INFO(QSPCP, qspcp);
        GET_EMAD_INFO(QRWE, qrwe);
        GET_EMAD_INFO(QPEM, qpem);
        GET_EMAD_INFO(QPDSM, qpdsm);
        GET_EMAD_INFO(QPPM, qppm);
        GET_EMAD_INFO(QPDPM, qpdpm);
        GET_EMAD_INFO(QEPM, qepm);
        GET_EMAD_INFO(QTCTM, qtctm);
        GET_EMAD_INFO(MPSC, mpsc);
        GET_EMAD_INFO(RAW, raw);
        GET_EMAD_INFO(SBPR, sbpr);
        GET_EMAD_INFO(SBPM, sbpm);
        GET_EMAD_INFO(SBCM, sbcm);
        GET_EMAD_INFO(SBMM, sbmm);
        GET_EMAD_INFO(SBSR, sbsr);
        GET_EMAD_INFO(CWTP, cwtp);
        GET_EMAD_INFO(CWPP, cwpp);
        GET_EMAD_INFO(CWPPM, cwppm);
        GET_EMAD_INFO(RAUHT, rauht);
        GET_EMAD_INFO(RAUHTD, rauhtd);
        GET_EMAD_INFO(RECRV2, recr_v2);
        GET_EMAD_INFO(TIQCR, tiqcr);
        GET_EMAD_INFO(MLCR, mlcr);
        GET_EMAD_INFO(MDRI, mdri);
        GET_EMAD_INFO(RMFTV2, rmft_v2);
        GET_EMAD_INFO(RMEIR, rmeir);
        GET_EMAD_INFO(RMID, rmid);
        GET_EMAD_INFO(RMPU, rmpu);
        GET_EMAD_INFO(MPGCR, mpgcr);
        GET_EMAD_INFO(MPILM, mpilm);
        GET_EMAD_INFO(PMPR, pmpr);
        GET_EMAD_INFO(MCION, mcion);
        GET_EMAD_INFO(PPBME, ppbme)

    /*
     * The following doesn't have a struct "sxd_emad_ ## reg_name ## _data_t"
     * therefore they are also not supported in emad_common_set
     */
    case SXD_REG_ID_SPZR_E:
    case SXD_REG_ID_FCAP_E:
    case SXD_REG_ID_MFCR_E:
    case SXD_REG_ID_MFSC_E:
    case SXD_REG_ID_MFSL_E:
    case SXD_REG_ID_FORE_E:
    case SXD_REG_ID_MCAS_E:
    case SXD_REG_ID_MTCAP_E:
    case SXD_REG_ID_MCIA_E:
    case SXD_REG_ID_MMIA_E:
    case SXD_REG_ID_MMDIO_E:
    case SXD_REG_ID_MFM_E:
    case SXD_REG_ID_MGIR_E:
    case SXD_REG_ID_MHSR_E:
    case SXD_REG_ID_MRSR_E:
    default:
        rc = 1;
        break;
    }

after_reg_resolve:

    if (NULL == name) {
        printf("emad_sniffer failed no such case.\n");
        return 1;
    }

    if (NULL != emad_size) {
        *emad_size = size;
    }
    if (NULL != cmd_name) {
        *cmd_name = name;
    }
    if (NULL != reg_offset) {
        *reg_offset = offset;
    }
    return rc;
}

int ioctl_cmd_info_get(int cmd, int *res, ioctl_data_type_e *type, const char **cmd_name)
{
    int                                     size = 0;
    const char                             *name = NULL;
    const struct sxd_register_sniffer_info* sniffer_info;
    ioctl_data_type_e                       data_type = IOCTL_DATA_IS_POINTER_E;

    sniffer_info = sxd_register_get_sniffer_info(cmd);
    if (sniffer_info) {
        name = sniffer_info->ctrl_cmd_name;
        size = sniffer_info->ctrl_cmd_size;
        goto after_reg_resolve;
    }

    switch (cmd) {
    /* data is not a pointer*/
    case ((int)CTRL_CMD_MULTI_PACKET_ENABLE):
        name = "CTRL_CMD_MULTI_PACKET_ENABLE";
        size = sizeof(unsigned long);
        data_type = IOCTL_DATA_IS_AS_IS_E;
        break;

    /* data is not a pointer*/
    case ((int)CTRL_CMD_BLOCKING_ENABLE):
        name = "CTRL_CMD_BLOCKING_ENABLE";
        size = sizeof(unsigned long);
        data_type = IOCTL_DATA_IS_AS_IS_E;
        break;

    /* data is not a pointer*/
    case ((int)CTRL_CMD_RESET):
        name = "CTRL_CMD_RESET";
        size = 0;
        data_type = IOCTL_DATA_IS_AS_IS_E;
        break;

    /* data is not a pointer*/
    case ((int)CTRL_CMD_PCI_DEVICE_RESTART):
        name = "CTRL_CMD_PCI_DEVICE_RESTART";
        size = sizeof(unsigned long);
        data_type = IOCTL_DATA_IS_AS_IS_E;
        break;

    /* data is not a pointer*/
    case ((int)CTRL_CMD_RAISE_EVENT):
        name = "CTRL_CMD_RAISE_EVENT";
        size = sizeof(unsigned long);
        data_type = IOCTL_DATA_IS_AS_IS_E;
        break;

    /* data is a pointer of uint8_t*/
    case ((int)CTRL_CMD_GET_SX_CORE_DB_RESTORE_ALLOWED):
        name = "CTRL_CMD_GET_SX_CORE_DB_RESTORE_ALLOWED";
        size = sizeof(uint8_t);
        break;

        IOCTL_INFO_GET(CTRL_CMD_GET_CAPABILITIES, sx_dev_cap);
        IOCTL_INFO_GET(CTRL_CMD_SET_PCI_PROFILE, sx_pci_profile);
        /* CTRL_CMD_INVALID unused */
        IOCTL_INFO_GET(CTRL_CMD_GET_DEVICE_PROFILE, ku_profile);
        IOCTL_INFO_GET(CTRL_CMD_ADD_SYND, ku_synd_ioctl);
        IOCTL_INFO_GET(CTRL_CMD_REMOVE_SYND, ku_synd_ioctl);
        IOCTL_INFO_GET(CTRL_CMD_ENABLE_SWID, ku_swid_details);
        IOCTL_INFO_GET(CTRL_CMD_DISABLE_SWID, ku_swid_details);
        IOCTL_INFO_GET(CTRL_CMD_GET_SYNDROME_STATUS, ku_synd_query_ioctl);
        IOCTL_INFO_GET(CTRL_CMD_QUERY_FW, ku_query_fw);
        IOCTL_INFO_GET(CTRL_CMD_QUERY_RSRC, ku_query_rsrc);
        IOCTL_INFO_GET(CTRL_CMD_QUERY_BOARD_INFO, ku_query_board_info);
        IOCTL_INFO_GET(CTRL_CMD_ADD_DEV_PATH, ku_dpt_path_add);
        IOCTL_INFO_GET(CTRL_CMD_REMOVE_DEV_PATH, ku_dpt_path_add);
        IOCTL_INFO_GET(CTRL_CMD_REMOVE_DEV, ku_dpt_path_add);
        IOCTL_INFO_GET(CTRL_CMD_SET_CMD_PATH, ku_dpt_path_modify);
        IOCTL_INFO_GET(CTRL_CMD_SET_EMAD_PATH, ku_dpt_path_modify);
        IOCTL_INFO_GET(CTRL_CMD_SET_MAD_PATH, ku_dpt_path_modify);
        IOCTL_INFO_GET(CTRL_CMD_SET_CR_ACCESS_PATH, ku_dpt_path_modify);
        IOCTL_INFO_GET(CTRL_CMD_GET_PCI_PROFILE, ku_get_pci_profile);
        IOCTL_INFO_GET(CTRL_CMD_GET_SWID_2_RDQ, ku_swid_2_rdq_query);
        IOCTL_INFO_GET(CTRL_CMD_SET_DEFAULT_VID, ku_default_vid_data);
        IOCTL_INFO_GET(CTRL_CMD_SET_VID_MEMBERSHIP, ku_vid_membership_data);
        IOCTL_INFO_GET(CTRL_CMD_SET_PRIO_TAGGING, ku_prio_tagging_data);
        IOCTL_INFO_GET(CTRL_CMD_SET_PRIO_TO_TC, ku_prio_to_tc_data);
        IOCTL_INFO_GET(CTRL_CMD_SET_DEVICE_PROFILE, ku_profile);
        IOCTL_INFO_GET(CTRL_CMD_SET_RDQ_RATE_LIMITER, ku_set_rdq_rate_limiter);
        IOCTL_INFO_GET(CTRL_CMD_SET_TRUNCATE_PARAMS, ku_set_truncate_params);
        IOCTL_INFO_GET(CTRL_CMD_CR_SPACE_READ, ku_cr_space_read);
        IOCTL_INFO_GET(CTRL_CMD_CR_SPACE_WRITE, ku_cr_space_write);
        IOCTL_INFO_GET(CTRL_CMD_SET_LOCAL_PORT_TO_SWID, ku_local_port_swid_data);
        IOCTL_INFO_GET(CTRL_CMD_SET_IB_TO_LOCAL_PORT, ku_ib_local_port_data);
        IOCTL_INFO_GET(CTRL_CMD_SET_SYSTEM_TO_LOCAL_PORT, ku_system_local_port_data);
        IOCTL_INFO_GET(CTRL_CMD_SET_PORT_RP_MODE, ku_port_rp_mode_data);
        IOCTL_INFO_GET(CTRL_CMD_SET_LOCAL_PORT_TO_LAG, ku_local_port_to_lag_data);
        IOCTL_INFO_GET(CTRL_CMD_TRAP_FILTER_ADD, ku_trap_filter_data);
        IOCTL_INFO_GET(CTRL_CMD_TRAP_FILTER_REMOVE, ku_trap_filter_data);
        IOCTL_INFO_GET(CTRL_CMD_TRAP_FILTER_REMOVE_ALL, ku_trap_filter_data);
        IOCTL_INFO_GET(CTRL_CMD_SET_VID_2_IP, ku_vid2ip_data);
        IOCTL_INFO_GET(CTRL_CMD_SAVE_SX_CORE_DB, ku_sx_core_db);
        IOCTL_INFO_GET(CTRL_CMD_RESTORE_SX_CORE_DB, ku_sx_core_db);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PSPA, ku_access_pspa_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PTYS, ku_access_ptys_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PMLP, ku_access_pmlp_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PLIB, ku_access_plib_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_SPZR, ku_access_spzr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PPLM, ku_access_pplm_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PLPC, ku_access_plpc_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PMPC, ku_access_pmpc_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PMPR, ku_access_pmpr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PELC, ku_access_pelc_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PMCR, ku_access_pmcr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PFSC, ku_access_pfsc_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PMMP, ku_access_pmmp_reg);
        /* CTRL_CMD_ACCESS_REG_PFCA unused
         *  CTRL_CMD_ACCESS_REG_PFCNT unused */
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MFSC, ku_access_mfsc_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MFSL, ku_access_mfsl_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MJTAG, ku_access_mjtag_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PPSC, ku_access_ppsc_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MCIA, ku_access_mcia_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_HCAP, ku_access_hcap_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_HDRT, ku_access_hdrt_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MFCR, ku_access_mfcr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_FORE, ku_access_fore_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MTCAP, ku_access_mtcap_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PMAOS, ku_access_pmaos_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MMDIO, ku_access_mmdio_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MMIA, ku_access_mmia_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MFPA, ku_access_mfpa_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MFBE, ku_access_mfbe_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MFBA, ku_access_mfba_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_RAW, ku_access_raw_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_RAW_BUFF, ku_access_reg_raw_buff);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MFM, ku_access_mfm_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_SPAD, ku_access_spad_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_SSPR, ku_access_sspr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_SPMCR, ku_access_spmcr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_SMID, ku_access_smid_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_SPMS, ku_access_spms_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_QPBR, ku_access_qpbr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_PLBF, ku_access_plbf_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MHSR, ku_access_mhsr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_SGCR, ku_access_sgcr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MSCI, ku_access_msci_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MRSR, ku_access_mrsr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_CWTP, ku_cwtp_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_CWPP, ku_cwpp_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_CWPPM, ku_cwppm_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MPSC, ku_access_mpsc_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MLCR, ku_access_mlcr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MPGCR, ku_access_mpgcr_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MPILM, ku_access_mpilm_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MDRI, ku_access_mdri_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_MCION, ku_access_mcion_reg);
        IOCTL_INFO_GET(CTRL_CMD_ACCESS_REG_QPCR, ku_access_qpcr_reg);
        IOCTL_INFO_GET(CTRL_CMD_GET_DEV_INFO, ku_dev_info);
        IOCTL_INFO_GET(CTRL_CMD_MAD_DEMUX, ku_mad_demux);
        IOCTL_INFO_GET(CTRL_CMD_SET_RDQ_TIMESTAMP_STATE, ku_rdq_timestamp_state);
        IOCTL_INFO_GET(CTRL_CMD_SET_RDQ_CPU_PRIORITY, ku_rdq_cpu_priority);
        IOCTL_INFO_GET(CTRL_CMD_PORT_MODULE_MAP_SET, ku_port_module_map_set_params);
        IOCTL_INFO_GET(CTRL_CMD_PORT_MODULE_UPDATE, ku_port_module_update_params);
#ifdef SW_PUDE_EMULATION
        /* PUDE WA for NOS (PUDE events are handled by SDK). Needed for BU. */
        IOCTL_INFO_GET(CTRL_CMD_SET_PORT_ADMIN_STATUS, ku_admin_status_data);
#endif /* SW_PUDE_EMULATION */
    }

after_reg_resolve:

    if (name == NULL) {
        printf("ioctl_sniffer failed no such case.\n");
        return 1;
    }

    if (res != NULL) {
        *res = size;
    }
    if (type != NULL) {
        *type = data_type;
    }
    if (cmd_name != NULL) {
        *cmd_name = name;
    }
    return 0;
}
