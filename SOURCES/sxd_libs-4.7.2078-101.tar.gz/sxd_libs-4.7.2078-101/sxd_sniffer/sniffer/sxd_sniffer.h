/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_SNIFFER_H__
#define __SXD_SNIFFER_H__

#include <sys/types.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/sxd_emad_status.h>
#include <sx/sxd/sxd_emad_reg.h>
#include <sx/sxd/sxd_emad.h>

#include <emad/emad.h>
#include <reg_access/sxd_access_reg_infra.h>

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/


/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef sxd_status_t (*original_emad)(struct sxd_emad_general_reg_data *data_arr,
                                      uint32_t                          data_num,
                                      sxd_reg_id_e                      reg_id,
                                      sxd_emad_completion_handler_t     handler,
                                      void                             *context,
                                      boolean_t                         is_raw_reg,
                                      sxd_emad_parse_cb_t               parse_cb,
                                      void                             *parse_context);

typedef int (*original_sxd_ioctl_t)(sxd_handle handle, sxd_ctrl_pack_t *pack_p);

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/


sxd_status_t sxd_sniffer_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                             IN sx_verbosity_level_t *verbosity_level_p);

sxd_status_t sxd_sniffer_emad_prm_record_rx(void                         *emad_buff,
                                            uint32_t                      size,
                                            uint8_t                       method,
                                            const sxd_emad_tlv_markers_t *tlv_markers);

sxd_status_t sxd_sniffer_emad_prm_record_tx(const struct ku_iovec *iov,
                                            uint32_t               iov_entries,
                                            sxd_access_cmd_t       access_cmd,
                                            sxd_reg_id_e           reg_id);

sxd_status_t sxd_sniffer_access_cmd_to_emad_method(sxd_access_cmd_t access_cmd,
                                                   uint8_t         *method);

sxd_status_t sxd_sniffer_emad_common_set(struct sxd_emad_general_reg_data *data_arr,
                                         uint32_t                          data_num,
                                         sxd_reg_id_e                      reg_id,
                                         sxd_emad_completion_handler_t     handler,
                                         void                             *context,
                                         boolean_t                         is_raw_reg,
                                         sxd_emad_parse_cb_t               parse_cb,
                                         void                             *parse_context,
                                         original_emad                     original_emad_common_set);

int sxd_sniffer_sxd_ioctl(sxd_handle handle, sxd_ctrl_pack_t *pack_p,
                          original_sxd_ioctl_t original_sxd_ioctl);

void register_debug_cmd_prm_sniffer_activation(void);
void unregister_debug_cmd_prm_sniffer_activation(void);

void sxd_sniffer_print_data(const char *data, sxd_reg_id_e reg_id, sxd_emad_send_receive_e emad_state);

boolean_t sxd_sniffer_is_activated(sxd_reg_id_e reg_id);

#endif /* ifndef __SXD_SNIFFER_H__ */
