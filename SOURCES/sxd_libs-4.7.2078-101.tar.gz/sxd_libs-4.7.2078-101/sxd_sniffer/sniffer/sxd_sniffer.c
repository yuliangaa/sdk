/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <complib/cl_passivelock.h>
#include <complib/cl_mem.h>
#include <complib/cl_shared_memory.h>
#include <complib/cl_byteswap_osd.h>
#include <complib/sx_log.h>
#include <errno.h>
#include <inttypes.h>
#include <math.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <sys/file.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h> /* For mode constants */
#include <fcntl.h> /* For O_* constants */
#include <dirent.h>
#include <semaphore.h>
#include "../common/sniffer_common.h"
#include <complib/cl_packon.h>
#include "sxd_sniffer.h"
#include <sx/utils/debug_cmd.h>
#include "sx/utils/dbg_utils.h"
#include <sx/sxd/sxdev.h>

#define SXD_SNIFFER_SEM "/sxd_sniffer_sem"

#undef  __MODULE__
#define __MODULE__ SXD_SNIFFER

#define DATA_ARR_MAX_SIZE        ((SXD_DEV_ID_MAX + 1) * sizeof(sxd_emad_data_t))
#define SXD_SNIFFER_SHM_FILE     "/sxd_recording"
#define SXD_SNIFFER_DEFAULT_PATH "/var/log/sdk_dbg/sxd_recording.bin" /*sniffer may start before sx_api_sx_sdk_init*/
#define PRM_SNIFFER_DEFAULT_PATH "/var/log/sdk_dbg/prm_recording.log"
#define PRM_SNIFFER_MAX_SIZE     (300 * 1024 * 1024)
#define EMAD_WRITE_AND_CHECK(ptr, size, stream, \
                             cleanup)  if (write_and_check(ptr, size, 1, stream, EMAD_SNIFFER_E)) {goto cleanup; }
#define IOCTL_WRITE_AND_CHECK(ptr, size, stream, \
                              cleanup) if (write_and_check(ptr, size, 1, stream, IOCTL_SNIFFER_E)) {goto cleanup; }

#define REG_TLV_SWITCH_REG_OFFSET_IN_BYTES 4

typedef struct sniffer_shared_memory {
    boolean_t  record; /* to record or not to record */
    boolean_t  prm_record; /* to record or not to record */
    boolean_t  qsll_record; /* to record QSLL or not to record; default: enabled */
    boolean_t  is_parse_prm_record; /* to record or not to record */
    char       path_to_file[FILENAME_MAX];
    char       path_to_emad_prm_file[FILENAME_MAX];
    cl_plock_t p_lock;
    uint32_t   prm_file_number; /*current prm log file number*/
    int        process_cnt; /* amount of process that loaded the library. */
    uint32_t   prm_reg_ary[SXD_MAX_REGISTERS + 1][RECEIVED_EMAD_E + 1]; /* histogram information */
} sniffer_shared_memory_t;

typedef struct timeval timeval_t;

typedef struct sfn_head {
    uint8_t swid;
    uint8_t rec_type;
    uint8_t reserved1[3];
    uint8_t end;
    uint8_t reserved2;
    uint8_t num_rec;
    net32_t reserved3[2];
    /* records data */
} PACK_SUFFIX sfn_head_t;

#include <complib/cl_packoff.h>

/************************************************
 *  Global variables
 ***********************************************/
static char* TLV_OP_METHOD_STR_ARR[] = {
    "RESERVED",
    "TLV_OP_METHOD_QUERY",
    "TLV_OP_METHOD_WRITE",
    "TLV_OP_METHOD_SEND",
    "RESERVED",
    "TLV_OP_METHOD_EVENT",
};

#define TLV_OP_METHOD_STR_ARR_LEN (sizeof(TLV_OP_METHOD_STR_ARR) / sizeof(char*))
#define TLV_OP_METHOD_STR(TLV_OP_METHOD)         \
    (TLV_OP_METHOD < TLV_OP_METHOD_STR_ARR_LEN ? \
     TLV_OP_METHOD_STR_ARR[TLV_OP_METHOD] : "UNKNOWN")
#define EMAD_SIZE_TO_STR_BUFF_SIZE(SIZE) (SIZE * 16)
/************************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
static int                      shm_fd_s = -1;
static sniffer_shared_memory_t *shm_p_s = NULL;
static pid_t                    process_id_s = 0;

/************************************************
 *  Local function declarations
 ***********************************************/
static int __add_reg_raw_buff(FILE *ioctl_file_p, struct ku_access_reg_raw_buff *reg_raw)
{
    IOCTL_WRITE_AND_CHECK(&reg_raw->raw_buff.size, sizeof(reg_raw->raw_buff.size), ioctl_file_p, cleanup);

    IOCTL_WRITE_AND_CHECK(reg_raw->raw_buff.buff, reg_raw->raw_buff.size, ioctl_file_p, cleanup);

    return 0;
cleanup:
    return 1;
}

static int __add_reg_raw(FILE *ioctl_file_p, struct ku_access_raw_reg *reg_raw)
{
    IOCTL_WRITE_AND_CHECK(&reg_raw->raw_reg.size, sizeof(reg_raw->raw_reg.size), ioctl_file_p, cleanup);

    IOCTL_WRITE_AND_CHECK(reg_raw->raw_reg.buff, reg_raw->raw_reg.size, ioctl_file_p, cleanup);

    return 0;
cleanup:
    return 1;
}

static const char *month_str[] = {
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec"
};
static uint32_t get_time_stamp_sec(void)
{
    struct timeval tv;

    tv.tv_sec = (time_t)0;
    tv.tv_usec = 0L;
    gettimeofday(&tv, NULL);
    return tv.tv_sec;
}

/*
 *  When threads are created from C, they don't have the global python interpreter lock, nor is there a thread state data structure for them.
 *  In thread emadTx/Rx can't call a python log callback.
 *  sxd will log to syslog, user specified log file or stdout depend on sx_log configuration.
 */
void sxd_sniffer_log(const sx_log_severity_t severity, const char *p_str, ...)
{
    va_list     args;
    boolean_t   flush;
    FILE       *log_file;
    sx_log_cb_t log_cb;
    uint32_t    __verbosity_level = 0;
    char        buffer[LOG_ENTRY_SIZE_MAX];
    struct tm   result;
    time_t      tim;
    boolean_t   use_syslog = FALSE;

    SEVERITY_LEVEL_TO_VERBOSITY_LEVEL(severity, __verbosity_level);
    if (LOG_VAR_NAME(__MODULE__) < __verbosity_level) {
        return;
    }

    va_start(args, p_str);
    sx_log_params_get(&flush, &log_file, &log_cb);
    vsnprintf(buffer, LOG_ENTRY_SIZE_MAX, p_str, args);

    tim = get_time_stamp_sec();
    localtime_r(&tim, &result);
    int verbosity_level = 0;

    if (log_file == NULL) {
        log_file = stdout;
    }

    sx_log_g_use_syslog_get(&use_syslog);
    if (use_syslog) {
        log_cb(severity, QUOTEME(__MODULE__), buffer);
    } else {
        fprintf(log_file,
                "%s[%d]- %s: %s %02d %02d:%02d:%02d %s %s: %s",
                __FILE__, __LINE__, __FUNCTION__,
                (result.tm_mon < 12 ? month_str[result.tm_mon] : "???"),
                result.tm_mday, result.tm_hour, result.tm_min,
                result.tm_sec,
                SX_VERBOSITY_LEVEL_STR(verbosity_level),
                QUOTEME(__MODULE__),
                buffer);
        /* flush log on errors too */
        if (flush || (severity == SX_LOG_ERROR)) {
            fflush(log_file);
        }
    }
    va_end(args);
}

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_sniffer_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        sxd_sniffer_log(SX_LOG_ERROR, "Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}


static void __sxd_hex_dump(char* buff, uint32_t buff_size, const void* ptr, uint32_t len)
{
    char           __buff[LOG_ENTRY_SIZE_MAX];
    const uint8_t *__data = (uint8_t*)(ptr);
    uint32_t       __i = 0, __pos = 0, n = 0;

    if (buff_size < len) {
        return;
    }
    for (__i = 0; __i < len; ++__i) {
        if ((__i % 4) == 0) {
            if (__pos) {
                n = sprintf(buff, "%s\n", __buff);
                buff += n;
                __pos = 0;
            }
            snprintf(__buff + __pos, 9, "0x%04X: ", __i);
            __pos += 8;
        }
        snprintf(__buff + __pos, 4, "%02hhX ", __data[__i]);
        __pos += 3;
    }
    if (__pos) {
        n = sprintf(buff, "%s\n", __buff);
        buff += n;
    }

    buff[0] = '\0';
}

sxd_status_t sxd_sniffer_access_cmd_to_emad_method(sxd_access_cmd_t access_cmd, uint8_t *method)
{
    *method = (access_cmd == SXD_ACCESS_CMD_GET ||
               access_cmd == SXD_ACCESS_CMD_GET_ALL) ? 0x01 : 0x02;
    return SXD_STATUS_SUCCESS;
}

void calc_diff_time(timeval_t *tv_start_p, timeval_t *tv_curr_p, timeval_t *tv_diff_p)
{
    if (tv_curr_p->tv_usec >= tv_start_p->tv_usec) {
        tv_diff_p->tv_sec = tv_curr_p->tv_sec - tv_start_p->tv_sec;
        tv_diff_p->tv_usec = tv_curr_p->tv_usec - tv_start_p->tv_usec;
    } else {
        tv_diff_p->tv_sec = tv_curr_p->tv_sec - tv_start_p->tv_sec - 1;
        tv_diff_p->tv_usec = tv_curr_p->tv_usec + 1000000 - tv_start_p->tv_usec;
    }
}

static void __sxd_sniffer_save_histogram(void)
{
    uint32_t i;
    FILE    *emad_histogram_file_p = NULL;
    char     prm_file_buf[FILENAME_MAX + 64] = {0};

    if (shm_p_s->prm_file_number == 1) {
        snprintf(prm_file_buf, sizeof(prm_file_buf), "%s.hist", shm_p_s->path_to_emad_prm_file);
    } else {
        snprintf(prm_file_buf,
                 sizeof(prm_file_buf),
                 "%s%d.hist",
                 shm_p_s->path_to_emad_prm_file,
                 shm_p_s->prm_file_number - 1);
    }

    emad_histogram_file_p = fopen(prm_file_buf, "w");
    if (NULL == emad_histogram_file_p) {
        sxd_sniffer_log(SX_LOG_ERROR, "Histogram file (%s) failed to open, errno=%d\n", prm_file_buf, errno);
        goto out;
    }
    fprintf(emad_histogram_file_p, "%6s %18s %10s %10s\n", "Reg ID", "Name", "TX", "RX");

    for (i = 0; i < sizeof(shm_p_s->prm_reg_ary) / (sizeof(uint32_t) * (RECEIVED_EMAD_E + 1)); i++) {
        if (shm_p_s->prm_reg_ary[i][SEND_EMAD_E] || shm_p_s->prm_reg_ary[i][RECEIVED_EMAD_E]) {
            if (strcmp("<unknown>", REG_ID_TO_NAME(i))) {
                fprintf(emad_histogram_file_p, "0x%4x %18s %10d %10d\n", i, REG_ID_TO_NAME(i),
                        shm_p_s->prm_reg_ary[i][SEND_EMAD_E], shm_p_s->prm_reg_ary[i][RECEIVED_EMAD_E]);
            } else {
                fprintf(emad_histogram_file_p, "0x%4x %18s %10d %10d\n", i, "",
                        shm_p_s->prm_reg_ary[i][SEND_EMAD_E], shm_p_s->prm_reg_ary[i][RECEIVED_EMAD_E]);
            }
        }
    }
    fclose(emad_histogram_file_p);
    memset(shm_p_s->prm_reg_ary, 0, sizeof(shm_p_s->prm_reg_ary));
out:
    return;
}

/*
 * this function record the emad call as it looks in the prm
 */
static sxd_status_t __sxd_sniffer_emad_prm_record(const void                   *emad_buff,
                                                  uint32_t                      size,
                                                  sxd_emad_send_receive_e       emad_state,
                                                  uint8_t                       method,
                                                  const sxd_emad_tlv_markers_t *tlv_markers_p,
                                                  sxd_reg_id_e                  reg_id)
{
    FILE                           *emad_prm_file_p = NULL;
    uint32_t                        reg_id_32 = 0;
    char                          * str_buff = NULL;
    uint32_t                        str_buff_size;
    uint8_t                         status;
    uint32_t                        reg_tlv_len;
    uint64_t                        tid;
    static timeval_t                tv_start = {0, 0};
    timeval_t                       tv;
    timeval_t                       tv_diff = {0, 0};
    sfn_head_t                     *sfn_p = NULL;
    const struct sxd_register_info* reg_info = NULL;
    char                            prm_file_buf[FILENAME_MAX + 1] = {0};
    uint32_t                        prm_file_size;

    /*
     * EMAD Packet Layout:
     * ===================
     * Mandatory ----> EMAD Header: 16 bytes (4 dwords)
     * Mandatory ----> Operation TLV: 16 bytes (4 dwords)
     * Optional  ----> String TLV: 132 bytes (33 dwords)
     * Optional  ----> Latency TLV: 28 bytes (7 dwords)
     * Mandatory ----> Reg TLV: variable length
     * Mandatory ----> End TLV: 4 bytes (1 dword)
     */
    if (reg_id == SXD_REG_ID_QSLL_E) {
        if (!shm_p_s->qsll_record) {
            goto out;
        }
    }

    if (reg_id == SXD_REG_ID_SFN_E) {
        if (emad_state != RECEIVED_EMAD_E) {
            goto out;
        }

        /* reg tlv:
         * 00h: type len
         * 04h: switch register */
        sfn_p = (sfn_head_t*)((uint8_t*)tlv_markers_p->reg_tlv + REG_TLV_SWITCH_REG_OFFSET_IN_BYTES);
        if (sfn_p->num_rec == 0) {
            goto out;
        }
    }

    reg_id_32 = reg_id;
    status = tlv_markers_p->operation_tlv->dr_status & 0x7f;
    tid = cl_ntoh64(tlv_markers_p->operation_tlv->tid);
    if (tv_start.tv_sec == 0) {
        gettimeofday(&tv_start, NULL);
    }
    gettimeofday(&tv, NULL);
    calc_diff_time(&tv_start, &tv, &tv_diff);

    /*
     * lock so file wont be written by more than one thread.
     */
    cl_plock_excl_acquire(&shm_p_s->p_lock);
    if (shm_p_s->prm_file_number == 0) {
        emad_prm_file_p = fopen(shm_p_s->path_to_emad_prm_file, "ab+"); /*backward compatible, no number appended*/
    } else {
        snprintf(prm_file_buf, sizeof(prm_file_buf), "%s%d", shm_p_s->path_to_emad_prm_file, shm_p_s->prm_file_number);
        emad_prm_file_p = fopen(prm_file_buf, "ab+");
    }

    if (NULL == emad_prm_file_p) {
        sxd_sniffer_log(SX_LOG_ERROR, "File (%s) failed to open, errno=%d\n", shm_p_s->path_to_emad_prm_file, errno);
        goto cleanup;
    }

    fseek(emad_prm_file_p, 0, SEEK_END);
    prm_file_size = ftell(emad_prm_file_p);

    if (prm_file_size > PRM_SNIFFER_MAX_SIZE) {
        fclose(emad_prm_file_p);
        shm_p_s->prm_file_number++;
        snprintf(prm_file_buf, sizeof(prm_file_buf), "%s%d", shm_p_s->path_to_emad_prm_file, shm_p_s->prm_file_number);
        emad_prm_file_p = fopen(prm_file_buf, "ab+");
        if (NULL == emad_prm_file_p) {
            sxd_sniffer_log(SX_LOG_ERROR, "File (%s) failed to open, errno=%d\n", shm_p_s->path_to_emad_prm_file,
                            errno);
            goto cleanup;
        }
        __sxd_sniffer_save_histogram();
    }
    if ((reg_id >= 0) && (reg_id < SXD_MAX_REGISTERS)) {
        shm_p_s->prm_reg_ary[reg_id][emad_state]++;
    }

    reg_info = sxd_register_get_info(reg_id);

    /* No delimiter between hexdump and parsed data */
    if (((emad_state == SEND_EMAD_E) && (reg_info != NULL)) == FALSE) {
        fprintf(emad_prm_file_p, "==============================\n");
    }

    fprintf(emad_prm_file_p, "pid:%d, %s: reg_id:0x%x, reg_name:%s, size:%d, method:%s, status:%d "
            "str_tlv:%s latency_tlv:%s tid:0x%" PRIx64 " t:%lu.%03lu fw_latency_usec:%u, fw_cache_read_usec:%u\n",
            getpid(),
            emad_state == SEND_EMAD_E ? "TX" : "RX",
            reg_id_32,
            ((reg_info) ? reg_info->name : "N/A"),
            size,
            TLV_OP_METHOD_STR(method),
            status,
            ((tlv_markers_p->string_tlv != NULL) ? "TRUE" : "FALSE"),
            ((tlv_markers_p->latency_tlv != NULL) ? "TRUE" : "FALSE"),
            tid,
            tv_diff.tv_sec, (tv_diff.tv_usec / 1000),
            ((tlv_markers_p->latency_tlv != NULL) ? cl_ntoh32(tlv_markers_p->latency_tlv->latency_time) : 0),
            ((tlv_markers_p->latency_tlv != NULL) ? cl_ntoh32(tlv_markers_p->latency_tlv->code_cache_read_time) : 0));

    str_buff_size = EMAD_SIZE_TO_STR_BUFF_SIZE(size);
    str_buff = cl_malloc(str_buff_size);
    if (str_buff == NULL) {
        goto cleanup;
    }

    fprintf(emad_prm_file_p, "EMAD header:\n");
    memset(str_buff, 0, size);
    __sxd_hex_dump(str_buff, str_buff_size, emad_buff, sizeof(sxd_emad_header_t));
    fprintf(emad_prm_file_p, "%s\n", str_buff);

    fprintf(emad_prm_file_p, "Operation TLV:\n");
    memset(str_buff, 0, size);
    __sxd_hex_dump(str_buff, str_buff_size, tlv_markers_p->operation_tlv, sizeof(sxd_emad_operation_t));
    fprintf(emad_prm_file_p, "%s\n", str_buff);

    if (tlv_markers_p->reg_tlv) {
        reg_tlv_len = EMAD_TLV_LEN(tlv_markers_p->reg_tlv) * 4;

        fprintf(emad_prm_file_p, "Reg TLV (Header):\n");
        memset(str_buff, 0, size);
        __sxd_hex_dump(str_buff, str_buff_size, tlv_markers_p->reg_tlv, 4);
        fprintf(emad_prm_file_p, "%s\n", str_buff);

        fprintf(emad_prm_file_p, "Reg TLV (Register layout):\n");
        memset(str_buff, 0, size);
        __sxd_hex_dump(str_buff, str_buff_size, (uint8_t*)tlv_markers_p->reg_tlv->data, reg_tlv_len - 4);
        fprintf(emad_prm_file_p, "%s\n", str_buff);
    }

    fprintf(emad_prm_file_p, "End TLV:\n");
    memset(str_buff, 0, size);
    __sxd_hex_dump(str_buff, str_buff_size, tlv_markers_p->end_tlv, sizeof(sxd_emad_end_t));
    fprintf(emad_prm_file_p, "%s\n", str_buff);

    /* there is a string-TLV and string is not empty */
    if (tlv_markers_p->string_tlv && (tlv_markers_p->string_tlv->string[0] != '\0')) {
        fprintf(emad_prm_file_p, "String TLV:\n");
        memset(str_buff, 0, size);
        __sxd_hex_dump(str_buff, str_buff_size, tlv_markers_p->string_tlv, sizeof(sxd_emad_string_t));
        fprintf(emad_prm_file_p, "%s\n", str_buff);

        /* just making sure it is null-terminated string */
        tlv_markers_p->string_tlv->string[sizeof(tlv_markers_p->string_tlv->string) - 1] = '\0';
        fprintf(emad_prm_file_p, "Error string: %s\n", tlv_markers_p->string_tlv->string);
    }

    /* No delimiter between hexdump and parsed data */
    if ((emad_state == RECEIVED_EMAD_E) && (reg_info == NULL)) {
        fprintf(emad_prm_file_p, "==============================\n");
    }

cleanup:

    if (NULL != str_buff) {
        cl_free(str_buff);
    }

    if (NULL != emad_prm_file_p) {
        fflush(emad_prm_file_p);
        fclose(emad_prm_file_p);
    }

    cl_plock_release(&shm_p_s->p_lock);

out:
    return 0;
}


sxd_status_t sxd_sniffer_emad_prm_record_rx(void                         *emad_buff,
                                            uint32_t                      size,
                                            uint8_t                       method,
                                            const sxd_emad_tlv_markers_t *tlv_markers)
{
    sxd_status_t st = SXD_STATUS_SUCCESS;
    sxd_reg_id_e reg_id;

    if (!shm_p_s || !shm_p_s->prm_record) {
        goto out;
    }

    reg_id = (sxd_reg_id_e)cl_ntoh16(tlv_markers->operation_tlv->register_id);
    st = __sxd_sniffer_emad_prm_record(emad_buff,
                                       size,
                                       RECEIVED_EMAD_E,
                                       method,
                                       tlv_markers,
                                       reg_id);

out:
    return st;
}

sxd_status_t sxd_sniffer_emad_prm_record_tx(const struct ku_iovec *iov,
                                            uint32_t               iov_entries,
                                            sxd_access_cmd_t       access_cmd,
                                            sxd_reg_id_e           reg_id)
{
    static uint8_t linear_buff[SXD_EMAD_BUFFER_MAX_SIZE]; /* it is safe to be static variable because this function
                                                           *  is running only in the context of EMAD TX thread */
    uint32_t               size = 0;
    uint32_t               i;
    uint8_t                method;
    sxd_emad_tlv_markers_t tlv_markers;
    sxd_status_t           st = SXD_STATUS_SUCCESS;

    if (!shm_p_s || !shm_p_s->prm_record) {
        goto out;
    }

    for (i = 0; i < iov_entries; i++) {
        if (size + iov[i].iov_len > sizeof(linear_buff)) {
            sxd_sniffer_log(SX_LOG_ERROR, "sniffer buffer is too long!\n");
            st = SXD_STATUS_PARAM_ERROR;
            goto out;
        }

        memcpy(linear_buff + size, iov[i].iov_base, iov[i].iov_len);
        size += iov[i].iov_len;
    }

    st = emad_get_tlv_headers(linear_buff, size, &tlv_markers);
    if (st != SXD_STATUS_SUCCESS) {
        goto out;
    }

    sxd_sniffer_access_cmd_to_emad_method(access_cmd, &method);
    st = __sxd_sniffer_emad_prm_record(linear_buff,
                                       size,
                                       SEND_EMAD_E,
                                       method,
                                       &tlv_markers,
                                       reg_id);

out:
    return st;
}


/* the function we want to record. */
/* data_arr is a pointer to array of struct, each represent a emad call. */
sxd_status_t sxd_sniffer_emad_common_set(struct sxd_emad_general_reg_data *data_arr,
                                         uint32_t                          data_num,
                                         sxd_reg_id_e                      reg_id,
                                         sxd_emad_completion_handler_t     handler,
                                         void                             *context,
                                         boolean_t                         is_raw_reg,
                                         sxd_emad_parse_cb_t               parse_cb,
                                         void                             *parse_context,
                                         original_emad                     original_emad_common_set)
{
    FILE        *emad_file_p = NULL;
    timeval_t    tv_before;
    timeval_t    tv_after;
    sxd_status_t command_rc = SXD_STATUS_SUCCESS;
    unsigned int offset_p = 0;
    unsigned int reg_data_offset = 0;
    int          size_of_data_struct = 0;
    int          size_of_reg_sturct = 0;
    int          rc = 0;
    int          i = 0;
    int          id = 0;
    char        *data_p = NULL;
    const char  *reg_p = NULL;
    const char  *cmd_name = NULL;
    boolean_t    success = FALSE;
    boolean_t    record = FALSE;
    boolean_t    was_call_made = FALSE;
    boolean_t    was_lock_acquire = FALSE;

    memset(&tv_before, 0, sizeof(timeval_t));
    memset(&tv_after, 0, sizeof(timeval_t));

    if (original_emad_common_set == NULL) {
        sxd_sniffer_log(SX_LOG_ERROR, "original function is null.\n");
        return SXD_STATUS_ERROR;
    }

    if (NULL != shm_p_s) {
        cl_plock_excl_acquire(&shm_p_s->p_lock);
        record = shm_p_s->record;
        cl_plock_release(&shm_p_s->p_lock);
    }

    /*
     * if no recording is necessary then call the original command and exit.
     */
    if (FALSE == record) {
        return original_emad_common_set(data_arr, data_num, reg_id, handler,
                                        context, is_raw_reg, parse_cb, parse_context);
    }

    /* get data_sturct_size */
    rc = get_emad_data_struct_size(reg_id, &size_of_data_struct, NULL,
                                   &cmd_name, FETCH_EMAD_STRUCT_SIZE_E);
    if (rc != 0) {
        /*calling the real command will be performed in the clean up*/
        goto cleanup;
    }

    /* get reg sturct_size */
    rc = get_emad_data_struct_size(reg_id, &size_of_reg_sturct,
                                   &reg_data_offset, NULL,
                                   FETCH_EMAD_REG_SIZE_E);
    if (rc != 0) {
        /*calling the real command will be performed in the clean up*/
        goto cleanup;
    }

    if (DATA_ARR_MAX_SIZE < data_num * size_of_data_struct) {
        sxd_sniffer_log(SX_LOG_ERROR, "data_num * size_of_data_struct is larger than DATA_ARR_MAX_SIZE\n");
        /*calling the real command will be performed in the clean up*/
        goto cleanup;
    }

    /*
     * lock so file wont be written by more than one thread.
     */
    cl_plock_excl_acquire(&shm_p_s->p_lock);
    was_lock_acquire = TRUE;

    emad_file_p = fopen(shm_p_s->path_to_file, "ab+");
    if (NULL == emad_file_p) {
        sxd_sniffer_log(SX_LOG_ERROR, "File (%s) failed to open, errno=%d\n", shm_p_s->path_to_file, errno);
        goto cleanup;
    }

    /* write id */
    EMAD_WRITE_AND_CHECK(&id, sizeof(int), emad_file_p, cleanup);

    /* write process id */
    EMAD_WRITE_AND_CHECK(&process_id_s, sizeof(pid_t), emad_file_p, cleanup);

    /* write reg_id */
    EMAD_WRITE_AND_CHECK(&reg_id, sizeof(sxd_reg_id_e), emad_file_p, cleanup);

    /* write data_num */
    EMAD_WRITE_AND_CHECK(&data_num, sizeof(uint32_t), emad_file_p, cleanup);

    data_p = (char*)data_arr;

    for (i = 0; i < (int)data_num; i++) {
        /* get to the emad struct */
        offset_p = size_of_data_struct * i;
        /* copy the emad struct */
        EMAD_WRITE_AND_CHECK(&data_p[offset_p], size_of_data_struct,
                             emad_file_p, cleanup);

        /* Jump over the header. */
        /* the last variable of the structure is a pointer to the the register. */
        offset_p += reg_data_offset;

        /* point to the register in the struct */
        reg_p = *(void**)&data_p[offset_p];

        /* write the reg */
        EMAD_WRITE_AND_CHECK(reg_p, size_of_reg_sturct,
                             emad_file_p, cleanup);
    }


    /* checking the rc after the call to original */
    rc = gettimeofday(&tv_before, NULL);

    /* rc call of gettimeofday - in case of recording fail, still let the sdk call go throw */
    if (rc) {
        sxd_sniffer_log(SX_LOG_ERROR, "gettimeofday failed, return code: %d\n", rc);
        /*calling the real command will be performed in the clean up*/
        goto cleanup;
    }

    /*
     * calling the original emad command.
     */
    command_rc = original_emad_common_set(data_arr, data_num, reg_id,
                                          handler, context, is_raw_reg, parse_cb, parse_context);
    was_call_made = TRUE;

    rc = gettimeofday(&tv_after, NULL);

    /* rc call of gettimeofday - in case of recording fail, still let the sdk call go throw */
    if (rc) {
        sxd_sniffer_log(SX_LOG_ERROR, "gettimeofday failed, return code: %d\n", rc);
        goto cleanup;
    }

    /* write time */
    EMAD_WRITE_AND_CHECK(&tv_before, sizeof(struct timeval), emad_file_p,
                         cleanup);

    /* write time */
    EMAD_WRITE_AND_CHECK(&tv_after, sizeof(struct timeval), emad_file_p,
                         cleanup);

    EMAD_WRITE_AND_CHECK(&command_rc, sizeof(sxd_status_t), emad_file_p,
                         cleanup);

    success = TRUE;

cleanup:
    if (FALSE == success) {
        if (FALSE == was_lock_acquire) {
            cl_plock_excl_acquire(&shm_p_s->p_lock);
            was_lock_acquire = TRUE;
        }
        shm_p_s->record = FALSE;

        sxd_sniffer_log(SX_LOG_ERROR, "emad_sniffer failed! all process will now stop recording\n");
    }

    if (emad_file_p != NULL) {
        fflush(emad_file_p);
        fclose(emad_file_p);
    }

    if (TRUE == was_lock_acquire) {
        cl_plock_release(&shm_p_s->p_lock);
    }

    /* If call was not made. */
    if (FALSE == was_call_made) {
        command_rc = original_emad_common_set(data_arr, data_num, reg_id, handler,
                                              context, is_raw_reg, parse_cb, parse_context);
    }

    return command_rc;
}


int sxd_sniffer_sxd_ioctl(sxd_handle handle, sxd_ctrl_pack_t *pack_p, original_sxd_ioctl_t original_sxd_ioctl)
{
    FILE             *ioctl_file_p = NULL;
    timeval_t         tv_before;
    timeval_t         tv_after;
    ioctl_data_type_e data_type = IOCTL_DATA_IS_POINTER_E;
    sxd_status_t      command_rc = SXD_STATUS_SUCCESS;
    int               rc = 0;
    int               size = 0;
    int               id = 1;
    boolean_t         record = FALSE;
    boolean_t         success = FALSE;
    boolean_t         was_call_made = FALSE;
    boolean_t         was_lock_acquire = FALSE;

    memset(&tv_before, 0, sizeof(timeval_t));
    memset(&tv_after, 0, sizeof(timeval_t));

    if (NULL == original_sxd_ioctl) {
        sxd_sniffer_log(SX_LOG_ERROR, "original function is null.\n");
        return SXD_STATUS_ERROR;
    }

    if (NULL != shm_p_s) {
        cl_plock_excl_acquire(&shm_p_s->p_lock);
        record = shm_p_s->record;
        cl_plock_release(&shm_p_s->p_lock);
    }

    if (FALSE == record) {
        return original_sxd_ioctl(handle, pack_p);
    }

    rc = ioctl_cmd_info_get(pack_p->ctrl_cmd, &size, &data_type, NULL);
    if (rc != 0) {
        /*calling the real command will be performed in the clean up*/
        goto cleanup;
    }

    /*
     * lock so file wont be written by more than one thread.
     */
    cl_plock_excl_acquire(&shm_p_s->p_lock);
    was_lock_acquire = TRUE;

    ioctl_file_p = fopen(shm_p_s->path_to_file, "ab+");
    if (ioctl_file_p == NULL) {
        sxd_sniffer_log(SX_LOG_ERROR, "file (%s) failed to open!\n", shm_p_s->path_to_file);
        sxd_sniffer_log(SX_LOG_ERROR, "Error %d \n", errno);
        goto cleanup;
    }

    /* write id */
    IOCTL_WRITE_AND_CHECK(&id, sizeof(int), ioctl_file_p, cleanup);

    /* write process id */
    IOCTL_WRITE_AND_CHECK(&process_id_s, sizeof(pid_t), ioctl_file_p, cleanup);

    IOCTL_WRITE_AND_CHECK(&pack_p->ctrl_cmd, sizeof(int), ioctl_file_p,
                          cleanup);

    IOCTL_WRITE_AND_CHECK(&handle, sizeof(sxd_handle), ioctl_file_p, cleanup);

    switch (data_type) {
    case IOCTL_DATA_IS_POINTER_E:
        IOCTL_WRITE_AND_CHECK(pack_p->cmd_body, size, ioctl_file_p,
                              cleanup);
        if (pack_p->ctrl_cmd == CTRL_CMD_ACCESS_REG_RAW_BUFF) {
            rc = __add_reg_raw_buff(ioctl_file_p, (struct ku_access_reg_raw_buff *)pack_p->cmd_body);
            if (rc) {
                goto cleanup;
            }
        } else if (pack_p->ctrl_cmd == CTRL_CMD_ACCESS_REG_RAW) {
            rc = __add_reg_raw(ioctl_file_p, (struct ku_access_raw_reg *)pack_p->cmd_body);
            if (rc) {
                goto cleanup;
            }
        }
        break;

    case IOCTL_DATA_IS_AS_IS_E:
        IOCTL_WRITE_AND_CHECK(&pack_p->cmd_body, size, ioctl_file_p,
                              cleanup);
        break;
    }

    rc = gettimeofday(&tv_before, NULL);
    if (rc != 0) {
        /*calling the real command will be performed in the clean up*/
        sxd_sniffer_log(SX_LOG_ERROR, "gettimeofday failed, return code: %d\n", rc);
        goto cleanup;
    }

    command_rc = original_sxd_ioctl(handle, pack_p);
    was_call_made = TRUE;

    rc = gettimeofday(&tv_after, NULL);
    if (rc != 0) {
        sxd_sniffer_log(SX_LOG_ERROR, "gettimeofday failed, return code: %d\n", rc);
        goto cleanup;
    }

    /* write dates */
    IOCTL_WRITE_AND_CHECK(&tv_before, sizeof(timeval_t), ioctl_file_p,
                          cleanup);

    /* write dates */
    IOCTL_WRITE_AND_CHECK(&tv_after, sizeof(timeval_t), ioctl_file_p,
                          cleanup);

    IOCTL_WRITE_AND_CHECK(&command_rc, sizeof(sxd_status_t), ioctl_file_p,
                          cleanup);

    success = TRUE;

cleanup:
    if (FALSE == success) {
        if (FALSE == was_lock_acquire) {
            cl_plock_excl_acquire(&shm_p_s->p_lock);
            was_lock_acquire = TRUE;
        }
        shm_p_s->record = FALSE;

        sxd_sniffer_log(SX_LOG_ERROR, "emad_sniffer failed! all process will now stop recording\n");
    }

    if (TRUE == was_lock_acquire) {
        cl_plock_release(&shm_p_s->p_lock);
    }

    if (ioctl_file_p != NULL) {
        fflush(ioctl_file_p);
        fclose(ioctl_file_p);
    }

    /* If call was not made. */
    if (FALSE == was_call_made) {
        command_rc = original_sxd_ioctl(handle, pack_p);
    }

    return command_rc;
}

void prm_log_cleanup(void)
{
    DIR           *dir;
    struct dirent *entry;
    char           path[FILENAME_MAX];
    char          *file_name;
    char           full_path[2 * FILENAME_MAX];


    snprintf(path, sizeof(path), "%s", shm_p_s->path_to_emad_prm_file);
    file_name = strrchr(path, '/');
    if (!file_name) {
        sxd_sniffer_log(SX_LOG_ERROR, "prm sniffer path should contain directory %s\n", path);
        goto out;
    }

    *file_name = 0;
    file_name++;
    if ((dir = opendir(path)) == NULL) {
        SX_LOG_INF("prm sniffer path %s doesn't exist\n", path);
        goto out;
    }

    cl_plock_excl_acquire(&shm_p_s->p_lock);
    while ((entry = readdir(dir)) != NULL) {
        if (strncmp(entry->d_name, file_name, strlen(file_name)) == 0) {
            snprintf(full_path, sizeof(full_path), "%s/%s", path, entry->d_name);
            if (remove(full_path) != 0) {
                sxd_sniffer_log(SX_LOG_ERROR, "Error deleting file %s\n", full_path);
            } else {
                sxd_sniffer_log(SX_LOG_INFO, "deleted file %s\n", full_path);
            }
        }
    }
    shm_p_s->prm_file_number = 0;
    cl_plock_release(&shm_p_s->p_lock);
    closedir(dir);

out:
    return;
}

static void __debug_cmd_activate_prm_sniffer(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    const char* const param_error_message =
        "Invalid parameters. Possible values: <activate [file_path]|deactivate [prm_parse]>\n";

    UNUSED_PARAM(handler_context);

    if ((argc != 1) && (argc != 2)) {
        dbg_utils_print(stream, "%s", param_error_message);
        return;
    }

    if (strcmp(argv[0], "activate") == 0) {
        if (shm_p_s->prm_record && shm_p_s->is_parse_prm_record) {
            dbg_utils_print(stream, "PRM sniffer is already active. Recording path: %s\n",
                            shm_p_s->path_to_emad_prm_file);
        } else {
            if (argc == 2) {
                snprintf(shm_p_s->path_to_emad_prm_file, sizeof(shm_p_s->path_to_emad_prm_file), "%s", argv[1]);
            }
            dbg_utils_print(stream, "PRM sniffer has been activated. Recording path: %s\n",
                            shm_p_s->path_to_emad_prm_file);
            shm_p_s->prm_record = 1;
            shm_p_s->qsll_record = 1;
            shm_p_s->is_parse_prm_record = 1;
        }
    } else if (strcmp(argv[0], "deactivate") == 0) {
        if (!shm_p_s->prm_record) {
            dbg_utils_print(stream, "PRM sniffer is already not active\n");
        } else {
            if (argc == 1) {
                shm_p_s->prm_record = 0;
                dbg_utils_print(stream, "PRM sniffer has been deactivated. Record path was: %s\n",
                                shm_p_s->path_to_emad_prm_file);
            } else {
                if (strcmp(argv[1], "prm_parse") == 0) {
                    shm_p_s->is_parse_prm_record = 0;
                    dbg_utils_print(stream, "PRM parse sniffer has been deactivated. Record path was: %s\n",
                                    shm_p_s->path_to_emad_prm_file);
                } else {
                    dbg_utils_print(stream, "%s:[%s]\n", "Invalid param ", argv[1]);
                    dbg_utils_print(stream, "%s", param_error_message);
                    return;
                }
            }
        }
    } else if (strcmp(argv[0], "reset") == 0) {
        prm_log_cleanup();
    } else {
        dbg_utils_print(stream, "%s", param_error_message);
        return;
    }
}

void sxd_prm_sniffer_activate(FILE* stream, char *file_path_p)
{
    int         argc = 2;
    const char *argv[2] = { "activate", NULL};

    argv[1] = file_path_p;

    __debug_cmd_activate_prm_sniffer(stream, argc, argv, NULL);
}

void sxd_prm_sniffer_deactivate(FILE* stream)
{
    int         argc = 1;
    const char *argv[2] = { "deactivate", NULL};

    __debug_cmd_activate_prm_sniffer(stream, argc, argv, NULL);
}

static void __debug_cmd_activate_prm_sniffer_qsll(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    const char* const param_error_message =
        "Invalid parameters. Possible values: <activate|deactivate>\n";

    UNUSED_PARAM(handler_context);

    if (argc != 1) {
        dbg_utils_print(stream, "%s", param_error_message);
        return;
    }

    if (shm_p_s->prm_record == 0) {
        dbg_utils_print(stream, "%s", "Please, enable the PRM sniffer first.\n");
        return;
    }

    if (strcmp(argv[0], "activate") == 0) {
        if (shm_p_s->qsll_record) {
            dbg_utils_print(stream, "QSLL sniffing is already active.\n");
        } else {
            dbg_utils_print(stream, "QSLL sniffing has been activated.\n");
            shm_p_s->qsll_record = 1;
        }
    } else if (strcmp(argv[0], "deactivate") == 0) {
        if (!shm_p_s->qsll_record) {
            dbg_utils_print(stream, "QSLL sniffing is already not active\n");
        } else {
            shm_p_s->qsll_record = 0;
            dbg_utils_print(stream, "QSLL sniffing has been deactivated.\n");
        }
    } else {
        dbg_utils_print(stream, "%s", param_error_message);
        return;
    }
}

void register_debug_cmd_prm_sniffer_activation(void)
{
    sx_utils_debug_cmd_register_path("prm sniffer <activate|deactivate>",
                                     __debug_cmd_activate_prm_sniffer,
                                     NULL);
    sx_utils_debug_cmd_register_path("prm sniffer record QSLL <activate|deactivate>",
                                     __debug_cmd_activate_prm_sniffer_qsll,
                                     NULL);
}

void unregister_debug_cmd_prm_sniffer_activation(void)
{
    sx_utils_debug_cmd_unregister_path("prm sniffer <activate|deactivate>");
    sx_utils_debug_cmd_unregister_path("prm sniffer record QSLL <activate|deactivate>");
}

__attribute__((destructor)) static void __attribute_sxd_sniffer_deinit(void)
{
    int process_cnt = 0;
    int rc = 0;

    if (shm_p_s == NULL) {
        goto out;
    }

    /* when a process that has loaded this lib forks, the constructor will be called
     * only once (when the lib was first loaded)
     * This destructor however, will be invoked on each unload of the library -
     * when the parent & all child processes die.
     * Therefore only the process that incremented the count, should decrement it.
     */

    if (process_id_s != getpid()) {
        munmap(shm_p_s, sizeof(*shm_p_s));
        shm_p_s = NULL;

        goto out;
    }

    cl_plock_excl_acquire(&shm_p_s->p_lock);
    shm_p_s->process_cnt--;
    process_cnt = shm_p_s->process_cnt;
    cl_plock_release(&shm_p_s->p_lock);

    if (process_cnt == 0) {
        cl_plock_destroy(&shm_p_s->p_lock);
        munmap(shm_p_s, sizeof(*shm_p_s));
        shm_p_s = NULL;

        rc = cl_shm_destroy(SXD_SNIFFER_SHM_FILE);
        if (rc != 0) {
            sxd_sniffer_log(SX_LOG_ERROR, "cl_shm_destroy failed, errno=(%d).\n", errno);
        }

        rc = sem_unlink(SXD_SNIFFER_SEM);
        if (rc != 0) {
            sxd_sniffer_log(SX_LOG_ERROR, "sem_unlink for sxd_sniffer_semaphore failed, errno=(%d).\n", errno);
        }
    }

out:
    /* Close the SHARED MEMORY file descriptor */
    if (shm_fd_s != -1) {
        close(shm_fd_s);
        shm_fd_s = -1;
    }
}

__attribute__((constructor)) static void __attribute_sxd_sniffer_init(void)
{
    sem_t    *sxd_sem = NULL;
    boolean_t first_process = FALSE;
    int       err = 1;
    char     *file_path_p = NULL;

    shm_p_s = NULL;
    shm_fd_s = -1;

    process_id_s = getpid();

    /* this semaphore act as a critical section(multi processes lock) */
    sxd_sem = sem_open(SXD_SNIFFER_SEM,
                       O_CREAT, S_IRWXG | S_IRWXO | S_IRWXU, 1);
    if (SEM_FAILED == sxd_sem) {
        goto no_resource_allocated;
    }

    /* Enter Critical section. */
    err = sem_wait(sxd_sem);
    if (0 != err) {
        goto critical_code_lock_was_init;
    }

    /* open shared memory */
    err = cl_shm_create(SXD_SNIFFER_SHM_FILE, &shm_fd_s);
    if (CL_SUCCESS == err) {
        first_process = TRUE;

        /* set memory size */
        err = ftruncate(shm_fd_s, sizeof(sniffer_shared_memory_t));
        if (err) {
            goto shared_memory_opened;
        }
    } else {
        /* Free Critical section - we are not first. */
        err = sem_post(sxd_sem);
        if (-1 == err) {
            goto no_resource_allocated;
        }
        err = sem_close(sxd_sem);
        if (-1 == err) {
            goto no_resource_allocated;
        }

        err = cl_shm_open(SXD_SNIFFER_SHM_FILE, &shm_fd_s);
        if (CL_SUCCESS != err) {
            goto no_resource_allocated;
        }
    }

    shm_p_s = mmap(NULL, sizeof(*shm_p_s), PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd_s, 0);

    if (MAP_FAILED == shm_p_s) {
        shm_p_s = NULL;
        goto shared_memory_opened;
    }

    /* if first process */
    if (TRUE == first_process) {
        /* clean the memory */
        memset(shm_p_s, 0, sizeof(*shm_p_s));

        /* init the lock */
        err = cl_plock_init_pshared(&shm_p_s->p_lock);
        if (err) {
            goto shared_memory_maped;
        }
        /* lock the memory */
        cl_plock_excl_acquire(&shm_p_s->p_lock);

        /* Free Critical section. */
        err = sem_post(sxd_sem);
        if (-1 == err) {
            cl_plock_release(&shm_p_s->p_lock);
            goto no_resource_allocated;
        }
        err = sem_close(sxd_sem);
        if (-1 == err) {
            cl_plock_release(&shm_p_s->p_lock);
            goto no_resource_allocated;
        }

        if (getenv("SXD_SNIFFER") != NULL) {
            shm_p_s->record = !!atoi(getenv("SXD_SNIFFER"));
        } else {
            shm_p_s->record = 0;
        }
        shm_p_s->process_cnt = 1;

        if (getenv("PRM_SNIFFER") != NULL) {
            shm_p_s->prm_record = !!atoi(getenv("PRM_SNIFFER"));
            shm_p_s->qsll_record = shm_p_s->prm_record;
            shm_p_s->is_parse_prm_record = shm_p_s->prm_record;
        } else {
            shm_p_s->prm_record = 0;
        }

        file_path_p = getenv("SDK_SYS_INFO_PATH");
        if ((file_path_p == NULL) || (strcmp(file_path_p, "") == 0)) {
            snprintf(shm_p_s->path_to_file, sizeof(shm_p_s->path_to_file), "%s", SXD_SNIFFER_DEFAULT_PATH);
            snprintf(shm_p_s->path_to_emad_prm_file,
                     sizeof(shm_p_s->path_to_emad_prm_file),
                     "%s",
                     PRM_SNIFFER_DEFAULT_PATH);
        } else {
            snprintf(shm_p_s->path_to_file, sizeof(shm_p_s->path_to_file), "%s/sxd_recording.bin", file_path_p);
            snprintf(shm_p_s->path_to_emad_prm_file,
                     sizeof(shm_p_s->path_to_emad_prm_file),
                     "%s/prm_recording.log",
                     file_path_p);
        }

        /* release memory */
        cl_plock_release(&shm_p_s->p_lock);
        prm_log_cleanup();
    } else {
        cl_plock_excl_acquire(&shm_p_s->p_lock);

        shm_p_s->process_cnt++;
        if (getenv("PRM_SNIFFER") != NULL) {
            shm_p_s->prm_record = !!atoi(getenv("PRM_SNIFFER"));
            shm_p_s->qsll_record = shm_p_s->prm_record;
            shm_p_s->is_parse_prm_record = shm_p_s->prm_record;
        }

        cl_plock_release(&shm_p_s->p_lock);
    }

    return;
    /* Error Handling: */

shared_memory_maped:
    munmap(shm_p_s, sizeof(sniffer_shared_memory_t));
shared_memory_opened:
    close(shm_fd_s);
    shm_fd_s = -1;
    if (FALSE == first_process) {
        /* At this point, critical section was already destroyed*/
        goto no_resource_allocated;
    }
    cl_shm_destroy(SXD_SNIFFER_SHM_FILE);
    sem_post(sxd_sem);
critical_code_lock_was_init:
    sem_close(sxd_sem);
no_resource_allocated:
    return;
}

void sxd_sniffer_print_data(const char *data, sxd_reg_id_e reg_id, sxd_emad_send_receive_e emad_state)
{
    FILE    *emad_prm_file_p = NULL;
    char     prm_file_buf[FILENAME_MAX + 1] = {0};
    uint32_t prm_file_size;

    UNUSED_PARAM(reg_id);
    UNUSED_PARAM(emad_state);
    if (!shm_p_s || !shm_p_s->prm_record || !shm_p_s->is_parse_prm_record) {
        return;
    }
    /*
     * lock so file wont be written by more than one thread.
     */
    cl_plock_excl_acquire(&shm_p_s->p_lock);

    if (shm_p_s->prm_file_number == 0) {
        emad_prm_file_p = fopen(shm_p_s->path_to_emad_prm_file, "ab+"); /*backward compatible, no number appended*/
    } else {
        snprintf(prm_file_buf, sizeof(prm_file_buf), "%s%d", shm_p_s->path_to_emad_prm_file, shm_p_s->prm_file_number);
        emad_prm_file_p = fopen(prm_file_buf, "ab+");
    }
    if (NULL == emad_prm_file_p) {
        sxd_sniffer_log(SX_LOG_ERROR, "File (%s) failed to open, errno=%d\n", shm_p_s->path_to_emad_prm_file, errno);
        goto out;
    }
    fseek(emad_prm_file_p, 0, SEEK_END);
    prm_file_size = ftell(emad_prm_file_p);
    if (prm_file_size > PRM_SNIFFER_MAX_SIZE) {
        fclose(emad_prm_file_p);
        shm_p_s->prm_file_number++;
        snprintf(prm_file_buf, sizeof(prm_file_buf), "%s%d", shm_p_s->path_to_emad_prm_file, shm_p_s->prm_file_number);
        emad_prm_file_p = fopen(prm_file_buf, "ab+");
        if (NULL == emad_prm_file_p) {
            sxd_sniffer_log(SX_LOG_ERROR, "File (%s) failed to open, errno=%d\n", shm_p_s->path_to_emad_prm_file,
                            errno);
            goto out;
        }
        __sxd_sniffer_save_histogram();
    }

    if ((reg_id >= 0) && (reg_id < SXD_MAX_REGISTERS)) {
        shm_p_s->prm_reg_ary[reg_id][emad_state]++;
    }

    fflush(emad_prm_file_p);
    fprintf(emad_prm_file_p, "%s\n", data);

out:
    if (NULL != emad_prm_file_p) {
        fflush(emad_prm_file_p);
        fclose(emad_prm_file_p);
    }
    cl_plock_release(&shm_p_s->p_lock);
}

boolean_t sxd_sniffer_is_activated(sxd_reg_id_e reg_id)
{
    boolean_t is_activated = FALSE;

    is_activated = (shm_p_s->prm_record && shm_p_s->is_parse_prm_record);
    if (reg_id == SXD_REG_ID_QSLL_E) {
        is_activated = is_activated && shm_p_s->qsll_record;
    }
    return is_activated;
}

void sxd_prm_sniffer_folder_path_set(char *file_path_p)
{
    if (strcmp(shm_p_s->path_to_emad_prm_file, file_path_p)) {
        cl_plock_excl_acquire(&shm_p_s->p_lock);
        snprintf(shm_p_s->path_to_file, sizeof(shm_p_s->path_to_file), "%s/sxd_recording.bin", file_path_p);
        snprintf(shm_p_s->path_to_emad_prm_file,
                 sizeof(shm_p_s->path_to_emad_prm_file),
                 "%s/prm_recording.log",
                 file_path_p);
        shm_p_s->prm_file_number = 0;
        cl_plock_release(&shm_p_s->p_lock);
    }
    return;
}
