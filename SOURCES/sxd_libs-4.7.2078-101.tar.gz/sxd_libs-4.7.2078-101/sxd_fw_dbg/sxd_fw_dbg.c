/*
 * SPDX-FileCopyrightText: Copyright (c) 2001-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include "sxd_fw_dbg_int.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <dirent.h>
#include <complib/cl_map.h>
#include <complib/cl_mem.h>
#include <complib/cl_fleximap.h>
#include <complib/cl_fcntl.h>
#include <complib/cl_byteswap.h>
#include <complib/cl_math.h>
#include <sx/utils/dbg_utils.h>
#include <sx/sxd/cr_access.h>
#include <sx/sxd/sxd_fw_dbg.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/sxd_access_register.h>
#include <errno.h>

#undef  __MODULE__
#define __MODULE__ SXD_FW_DBG

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Local Defines
 ***********************************************/

#define DBG_DMP_BYTES_IN_DWORD (4)
#define DBG_DMP_MAX_DWORDS     (1024)
#define DBG_DMP_MAX_LEN        (15)
#ifdef PD_BU
#define SXD_CR_DUMP_LAYER2_TIMEOUT (100000000) /*very big timeout value, ~no timeout */
#else
#define SXD_CR_DUMP_LAYER2_TIMEOUT (3)
#endif
#define DBG_DMP_MAP_PATH "/usr/share/sx_fw_dump/"

#define DBG_DMP_TILES_BASE_ADDR    (0x2000000)
#define DBG_DMP_TILES_OFFSET       (0x200000)
#define DBG_DMP_TILES_NUM          (8)
#define DBG_DMP_BYTES_PER_LINE     (8) /* 4 bytes for CR-Space offset, 4 bytes for value */
#define MAX_FAILED_READS_ALLOWED   (30)
#define DUMPFILE_FULL_PATH_BUF_LEN (200)
#define SX_SDK_CUSTOM_PREFIX       ("SX_SDK_CUSTOM_PREFIX")
#define FULL_FILE_PATH_LENGTH      256 /* Leaves room for the prefix string too. */

typedef struct sxd_fw_dbg_inst_info {
    boolean_t                 is_inited;
    sxd_chip_types_t          chip_type;
    uint32_t                  num_of_inst;
    sxd_fw_dbg_instruction_t *sxd_fw_dbg_instructions;
} sxd_fw_dbg_inst_info_t;

typedef struct sxd_fw_dbg_hold_info {
    cl_map_item_t map_item;
    unsigned char data[DBG_DMP_BYTES_IN_DWORD * DBG_DMP_MAX_DWORDS];
    int64_t       num_of_dwords;    /* how many dwords we want to read / write */
} sxd_fw_dbg_hold_info_t;

typedef struct sxd_fw_dbg_tiles_info {
    boolean_t is_inited;
    uint8_t   num_of_tiles;
    uint16_t  disabled_tiles_bitmap;
} sxd_fw_dbg_tiles_info_t;

static const char *const sxd_fw_instruction_type_str_s[] = {
    SXD_FOREACH_INSTRUCTION_TYPE(SXD_GENERATE_STRING)
};

#define SXD_FW_INSTRUCTION_TYPE_STR_LEN \
    (sizeof(sxd_fw_instruction_type_str_s) / sizeof(sxd_fw_instruction_type_str_s[0]))

#define SXD_FW_DBG_TYPE_TO_FILE(ENTRY)                 \
    ENTRY(SXD_CHIP_TYPE_SWITCH_IB, , "SwitchIB.csv")   \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM, , "Spectrum.csv")    \
    ENTRY(SXD_CHIP_TYPE_SWITCH_IB2, , "SwitchIB2.csv") \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM_A1, , "Spectrum.csv") \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM2, , "Spectrum2.csv")  \
    ENTRY(SXD_CHIP_TYPE_QUANTUM, , "Quantum.csv")      \
    ENTRY(SXD_CHIP_TYPE_QUANTUM2, , "Quantum2.csv")    \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM3, , "Spectrum3.csv")  \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM4, , "Spectrum4.csv")  \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM5, , "Spectrum5.csv")

static const char *const sxd_fw_dbg_type_to_file_str_s[] = {
    SXD_FW_DBG_TYPE_TO_FILE(SXD_GENERATE_STRING)
};

#define SXD_FW_DBG_TYPE_TO_FILE_STR_LEN \
    (sizeof(sxd_fw_dbg_type_to_file_str_s) / sizeof(sxd_fw_dbg_type_to_file_str_s[0]))

#define SXD_FW_DBG_TYPE_TO_TILE_FILE(ENTRY)                 \
    ENTRY(SXD_CHIP_TYPE_SWITCH_IB, , "")                    \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM, , "")                     \
    ENTRY(SXD_CHIP_TYPE_SWITCH_IB2, , "")                   \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM_A1, , "")                  \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM2, , "")                    \
    ENTRY(SXD_CHIP_TYPE_QUANTUM, , "")                      \
    ENTRY(SXD_CHIP_TYPE_QUANTUM2, , "")                     \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM3, , "Spectrum3_tiles.csv") \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM4, , "")                    \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM5, , "")

static const char *const sxd_fw_dbg_type_to_tile_file_str_s[] = {
    SXD_FW_DBG_TYPE_TO_TILE_FILE(SXD_GENERATE_STRING)
};

#define SXD_FW_DBG_TYPE_TO_TILE_FILE_STR_LEN \
    (sizeof(sxd_fw_dbg_type_to_tile_file_str_s) / sizeof(sxd_fw_dbg_type_to_tile_file_str_s[0]))

/* MST device name as should be in the CR space dump header*/
#define SXD_FW_DBG_TYPE_TO_MST_DEV(ENTRY)          \
    ENTRY(SXD_CHIP_TYPE_SWITCH_IB, , "SwitchIB")   \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM, , "Spectrum")    \
    ENTRY(SXD_CHIP_TYPE_SWITCH_IB2, , "SwitchIB2") \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM_A1, , "Spectrum") \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM2, , "Spectrum2")  \
    ENTRY(SXD_CHIP_TYPE_QUANTUM, , "Quantum")      \
    ENTRY(SXD_CHIP_TYPE_QUANTUM2, , "Quantum2")    \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM3, , "Spectrum3")  \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM4, , "Spectrum4")  \
    ENTRY(SXD_CHIP_TYPE_SPECTRUM5, , "Spectrum5")

static const char *const sxd_fw_dbg_type_to_mst_dev_str_s[] = {
    SXD_FW_DBG_TYPE_TO_MST_DEV(SXD_GENERATE_STRING)
};

#define SXD_FW_DBG_TYPE_TO_MST_DEV_STR_LEN \
    (sizeof(sxd_fw_dbg_type_to_mst_dev_str_s) / sizeof(sxd_fw_dbg_type_to_mst_dev_str_s[0]))

#define IS_VALID_START_OPCODE(start_opcode)                \
    ((start_opcode == SX_CR_DUMP_OP_START_FLAT) ||         \
     (start_opcode == SX_CR_DUMP_OP_START_REDUCED_FLAT) || \
     (start_opcode == SX_CR_DUMP_OP_START_GDB) ||          \
     (start_opcode == SX_CR_DUMP_OP_START_GW))

/* Quantum2 GDB dump does not support transaction mode, and Spectrum4 will be confirmed by FW after they finish the final design. */
#define IS_SINGLE_DUMP_MODE(opcode,                                                                                  \
                            chip_type) (opcode == SX_CR_DUMP_OP_START_GDB &&                                         \
                                        (chip_type == SXD_CHIP_TYPE_QUANTUM2 || chip_type == SXD_CHIP_TYPE_SPECTRUM4 \
                                         || chip_type == SXD_CHIP_TYPE_SPECTRUM5))

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/
/* Local conversions from enum to string */
static inline const char* sxd_fw_dbg_chip_type2file(sxd_chip_types_t type);

/************************************************
 *  Global variables
 ***********************************************/
static sxd_fw_dbg_inst_info_t sxd_global_fw_dbg_per_type[SXD_CHIP_TYPES_MAX + 1] =
{[0 ... SXD_CHIP_TYPES_MAX] = {FALSE, 0, 0, NULL}
};
static uint32_t __secure_fw_dump_dma_memblk_size = SX_CR_DUMP_MEMBLK_SIZE;

static sxd_fw_dbg_inst_info_t sxd_global_fw_dbg_tiles_offsets = {FALSE, 0, 0, NULL};

static sxd_fw_dbg_tiles_info_t sxd_global_fw_dbg_tiles_info_g = {FALSE, 0, 0};

static boolean_t __secure_fw_gdb_dump = FALSE;

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/
static sxd_status_t __sxd_dbg_dealloc_fw_dbg_info_per_asic_type(sxd_chip_types_t chip_type);
static sxd_status_t __sxd_dbg_alloc_fw_dbg_info_per_asic_type(sxd_chip_types_t chip_type,
                                                              uint32_t         num_of_inst);
static sxd_status_t __sxd_dbg_dealloc_fw_dbg_tiles_info(void);
static sxd_status_t __sxd_dbg_alloc_fw_dbg_tiles_info(uint32_t num_of_inst);
static sxd_status_t __sxd_dbg_utils_get_instruction_ops(const int64_t fw_inst_num_of_dwords,
                                                        int          *ret_ops_num,
                                                        int          *ret_last_op_bytes);
static sxd_status_t __sxd_dbg_utils_perform_fw_instruction(const sxd_dev_id_t dev_id,
                                                           sxd_chip_types_t   chip_type,
                                                           FILE              *stream,
                                                           uint32_t           instruction_idx,
                                                           unsigned char     *data,
                                                           cl_qmap_t         *fw_vars_map,
                                                           uint32_t          *addr_count);
static sxd_status_t __sxd_dbg_utils_perform_fw_tile_instruction(const sxd_dev_id_t dev_id,
                                                                FILE             * stream,
                                                                uint32_t           instruction_idx,
                                                                unsigned char     *data,
                                                                uint8_t            tile_idx,
                                                                uint32_t          *addr_count);
static sxd_status_t __sxd_dbg_get_fw_dbg_instruction(const sxd_chip_types_t           chip_type,
                                                     uint32_t                         instruction_idx,
                                                     const sxd_fw_dbg_instruction_t **ret_instruction);

static sxd_status_t __sxd_fw_dbg_init_info_per_asic_type(sxd_chip_types_t                  chip_type,
                                                         sxd_fw_instruction_segment_type_t segment_type);

static sxd_dev_id_t __sxd_dbg_utils_get_predefined_dev(void);

/************************************************
 *  Function implementations
 ***********************************************/
const char * sxd_fw_dbg_chip_type2file(sxd_chip_types_t index)
{
    return (SXD_CHECK_MAX(index, SXD_FW_DBG_TYPE_TO_FILE_STR_LEN - 1) ?
            sxd_fw_dbg_type_to_file_str_s[index] : NULL);
}

const char * sxd_dbg_fw_instruction_type_str(sxd_chip_types_t index)
{
    return (SXD_CHECK_MAX(index, SXD_FW_INSTRUCTION_TYPE_STR_LEN - 1) ?
            sxd_fw_instruction_type_str_s[index] : "Unknown");
}

const char * sxd_fw_dbg_chip_type2_tiles_file(sxd_chip_types_t index)
{
    return (SXD_CHECK_MAX(index, SXD_FW_DBG_TYPE_TO_FILE_STR_LEN - 1) ?
            sxd_fw_dbg_type_to_tile_file_str_s[index] : NULL);
}

const char * sxd_fw_dbg_chip_type2mst_dev(sxd_chip_types_t index)
{
    return (SXD_CHECK_MAX(index, SXD_FW_DBG_TYPE_TO_MST_DEV_STR_LEN - 1) ?
            sxd_fw_dbg_type_to_mst_dev_str_s[index] : NULL);
}
/*
 *
 */
static sxd_status_t __sxd_dbg_dealloc_fw_dbg_info_per_asic_type(sxd_chip_types_t chip_type)
{
    sxd_status_t err = 0;

    /* check type validity */

    /* free memory for the full path string */
    if (NULL != sxd_global_fw_dbg_per_type[chip_type].sxd_fw_dbg_instructions) {
        if (CL_SUCCESS != cl_free(sxd_global_fw_dbg_per_type[chip_type].sxd_fw_dbg_instructions)) {
            SX_LOG_ERR("could not free instruction memory of type:[%d]\n", chip_type);
        }
        sxd_global_fw_dbg_per_type[chip_type].sxd_fw_dbg_instructions = NULL;
    }

    sxd_global_fw_dbg_per_type[chip_type].chip_type = SXD_CHIP_TYPE_UNKNOWN;
    sxd_global_fw_dbg_per_type[chip_type].num_of_inst = 0;
    sxd_global_fw_dbg_per_type[chip_type].is_inited = FALSE;

    return err;
}


/*
 * this function will create a "large" memory (~1m) to hold the FW instruction
 * on how to extract FW debug info. this info is per ASIC type encountered.
 *
 * I.E usually there will be only one,
 * in director systems maybe more depending on ASIC types in the chassis
 *
 * in order to allocate the buffer we need to read the "fw debug header" and allocate according to "number of instructions"
 */
static sxd_status_t __sxd_dbg_alloc_fw_dbg_info_per_asic_type(sxd_chip_types_t chip_type, uint32_t num_of_inst)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    /* check type validity */
    if ((chip_type > SXD_CHIP_TYPES_MAX) || (chip_type == SXD_CHIP_TYPE_UNKNOWN)) {
        SX_LOG_ERR("Chip type is not valid");
        return SXD_STATUS_ERROR;
    }
    /* check num_of_inst range validity */
    /* check inst_file is not NULL ... */

    /* singleton object do not reallocate */
    if (FALSE == sxd_global_fw_dbg_per_type[chip_type].is_inited) {
        /* allocate memory for the full path string */
        sxd_global_fw_dbg_per_type[chip_type].sxd_fw_dbg_instructions =
            (sxd_fw_dbg_instruction_t*)cl_malloc(sizeof(sxd_fw_dbg_instruction_t) * num_of_inst);

        if (NULL == sxd_global_fw_dbg_per_type[chip_type].sxd_fw_dbg_instructions) {
            SX_LOG_ERR("no memory for FW debug instructions for type:[%d]\n",
                       chip_type);
            return SXD_STATUS_NO_MEMORY;
        }
        sxd_global_fw_dbg_per_type[chip_type].chip_type = chip_type;
        sxd_global_fw_dbg_per_type[chip_type].num_of_inst = num_of_inst;
        sxd_global_fw_dbg_per_type[chip_type].is_inited = TRUE;
    }

    return err;
}

static sxd_status_t __sxd_dbg_dealloc_fw_dbg_tiles_info(void)
{
    sxd_status_t err = 0;

    /* free memory for the full path string */
    if (NULL != sxd_global_fw_dbg_tiles_offsets.sxd_fw_dbg_instructions) {
        if (CL_SUCCESS != cl_free(sxd_global_fw_dbg_tiles_offsets.sxd_fw_dbg_instructions)) {
            SX_LOG_ERR("could not free tiles instruction memory \n");
        }
        sxd_global_fw_dbg_tiles_offsets.sxd_fw_dbg_instructions = NULL;
    }

    sxd_global_fw_dbg_tiles_offsets.chip_type = SXD_CHIP_TYPE_UNKNOWN;
    sxd_global_fw_dbg_tiles_offsets.num_of_inst = 0;
    sxd_global_fw_dbg_tiles_offsets.is_inited = FALSE;

    return err;
}

static sxd_status_t __sxd_dbg_alloc_fw_dbg_tiles_info(uint32_t num_of_inst)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    /* singleton object do not reallocate */
    if (FALSE == sxd_global_fw_dbg_tiles_offsets.is_inited) {
        /* allocate memory for the full path string */
        sxd_global_fw_dbg_tiles_offsets.sxd_fw_dbg_instructions =
            (sxd_fw_dbg_instruction_t*)cl_malloc(sizeof(sxd_fw_dbg_instruction_t) * num_of_inst);

        if (NULL == sxd_global_fw_dbg_tiles_offsets.sxd_fw_dbg_instructions) {
            SX_LOG_ERR("no memory for FW debug tiles instructions\n");
            return SXD_STATUS_NO_MEMORY;
        }
        sxd_global_fw_dbg_tiles_offsets.chip_type = SXD_CHIP_TYPE_UNKNOWN;
        sxd_global_fw_dbg_tiles_offsets.num_of_inst = num_of_inst;
        sxd_global_fw_dbg_tiles_offsets.is_inited = TRUE;
    }

    return err;
}


static sxd_status_t __sxd_dbg_utils_get_instruction_ops(const int64_t fw_inst_num_of_dwords,
                                                        int          *ret_ops_num,
                                                        int          *ret_last_op_bytes)
{
    sxd_status_t rc = SXD_STATUS_SUCCESS;
    int          ops_num = 0;
    int          last_op_bytes = 0;

    ops_num = 1;
    last_op_bytes = DBG_DMP_BYTES_IN_DWORD * fw_inst_num_of_dwords;
    /* we might be requested to "read" more than DBG_DMP_MAX_DWORDS,
     * in this case we will perform several "reads" in the DBG_DMP_MAX_DWORDS and the last for the remainder
     * so we will update" the ops_num & op_bytes
     * "last_op_bytes" will only hold the value for the last read, since all bug last are for sure of "max_size" */
    if (fw_inst_num_of_dwords > DBG_DMP_MAX_DWORDS) {
        /* example1: num_of_dwords=2572, DBG_DMP_MAX_DWORDS=1024 => need 2 reads of 1024[dwords] + 1 read of 524[dwords]
         * number_of_reads = 2572/1024=2
         * example2: num_of_dwords=2048, DBG_DMP_MAX_DWORDS=1024 => need 2 reads of 1024
         * number_of_reads = 2048/1024=2
         * */
        ops_num = (fw_inst_num_of_dwords / DBG_DMP_MAX_DWORDS);
        /* the maximal allowed number of bytes to read is:(4 * ctx.max_dwords) */
        /* last read we will need the remainder bytes
         * example1: number_of_reads =2, record_bytes = 4*(2572%1024)= 4B (524 Dwords) = 2096B
         * example2: number_of_reads =2, record_bytes = 4*(2048%1024)= 0B */
        last_op_bytes = (DBG_DMP_BYTES_IN_DWORD * (fw_inst_num_of_dwords % DBG_DMP_MAX_DWORDS));
        /* there is no carry (record_bytes), the last read should be of full size
         * example1: add another read to get the "carry" of the modulo operator
         * example2: make the last read a "full" read  */
        if (last_op_bytes == 0) {
            last_op_bytes = DBG_DMP_BYTES_IN_DWORD * DBG_DMP_MAX_DWORDS;
        } else {
            ops_num++; /* if there is a carry (for the modulo operation), increase the number of reads by 1 */
        }
    }

    /* if the user requested, return the calculated values */
    if (ret_ops_num) {
        *ret_ops_num = ops_num;
    }
    if (ret_last_op_bytes) {
        *ret_last_op_bytes = last_op_bytes;
    }

    return rc;
}


static sxd_status_t __sxd_dbg_utils_perform_fw_instruction(const sxd_dev_id_t dev_id,
                                                           sxd_chip_types_t   chip_type,
                                                           FILE             * stream,
                                                           uint32_t           instruction_idx,
                                                           unsigned char     *data,
                                                           cl_qmap_t         *fw_vars_map,
                                                           uint32_t          *addr_count)
{
    sxd_status_t                    rc = SXD_STATUS_SUCCESS;
    int                             ops_num = 0;
    int                             last_op_bytes = 0;
    int                             tmp_bytes = 0;
    int                             tmp_addr = 0;
    int                             i = 0;
    int                             j = 0;
    const sxd_fw_dbg_instruction_t *fw_instruction = NULL;
    sxd_fw_dbg_hold_info_t         *hold_info = NULL;
    cl_map_item_t                  *hold_map_item = NULL;
    unsigned char                  *w_data = NULL;
    int64_t                         w_data_dwords = 0;
    uint32_t                        address_count = 0;

    rc = __sxd_dbg_get_fw_dbg_instruction(chip_type, instruction_idx, &fw_instruction);
    if (rc || (NULL == fw_instruction)) {
        rc = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("could not get FW instruction at index:[%d]\n", instruction_idx); /* not sure if needed, we could silently skip*/
        goto out;
    }
    if ((fw_instruction->type == SXD_FW_INSTRUCTION_TYPE_UNKNOWN) ||
        (fw_instruction->type >= SXD_FW_INSTRUCTION_TYPE_READ_MAX)) {
        rc = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR(" FW instruction is not valid at index:[%d] instruction :[%d]\n",
                   instruction_idx,
                   fw_instruction->type);
        goto out;
    }

    switch (fw_instruction->type) {
    case SXD_FW_INSTRUCTION_TYPE_READ:
        rc = __sxd_dbg_utils_get_instruction_ops(fw_instruction->num_of_dwords, &ops_num, &last_op_bytes);
        if (rc) {
            goto out;
        }
        for (i = 0; i < ops_num; i++) {
            /* by default we will read the max, if this is the last read we will only read "last_op_bytes"*/
            tmp_bytes = DBG_DMP_BYTES_IN_DWORD * DBG_DMP_MAX_DWORDS;
            /* read from the address at record start + the number of bytes already read */
            tmp_addr = fw_instruction->address + (i * DBG_DMP_MAX_DWORDS * DBG_DMP_BYTES_IN_DWORD);
            /* if this is the last read (also valid for only 1 read), use "last_op_bytes"
             * else use the maximal value (4 * ctx.max_dwords) */
            if (i == (ops_num - 1)) {
                tmp_bytes = last_op_bytes;
            }

            rc = sx_cr_access_read(dev_id, tmp_addr, data, tmp_bytes);
            if (rc) {
                SX_LOG_ERR("device:[%d], could not read:[%d] bytes from address:[0x%06x] code:[%d, %s]\n",
                           dev_id, tmp_bytes, tmp_addr, rc, SXD_STATUS_MSG(rc));
                rc = SXD_STATUS_ERROR;     /* After MAX_FAILED_READS_ALLOWED failures to read, dump generation will stop */
            }

            /* write the data to the file */
            for (j = 0; j < (tmp_bytes / DBG_DMP_BYTES_IN_DWORD); j++) {
                /* print the address and Process every byte in the data, do 4 at a time to save I/O */
                dbg_utils_print(stream, "0x%08x 0x%02x%02x%02x%02x\n",
                                tmp_addr, data[(j * 4) + 0], data[(j * 4) + 1], data[(j * 4) + 2], data[(j * 4) + 3]);
                tmp_addr += DBG_DMP_BYTES_IN_DWORD;
                address_count++;
            }
        }
        break;

    case SXD_FW_INSTRUCTION_TYPE_WRITE:

        /* for "hold" implementation: we might want to write info that is "held"
         * first save the "data" and "num_of_dwords" of the original instruction.
         *
         * check if the "instruction->data" is a match to a held value in fw_vars_map
         * if it is, we need to write into instruction->address the data "held" in the map */
        w_data_dwords = fw_instruction->num_of_dwords;
        w_data = (unsigned char*)&(fw_instruction->data);

        /* this is a "held" item, take the data and validate that size fits */
        if (TRUE == cl_qmap_contains(fw_vars_map, fw_instruction->data)) {
            hold_map_item = cl_qmap_get(fw_vars_map, fw_instruction->data);
            hold_info = PARENT_STRUCT(hold_map_item, sxd_fw_dbg_hold_info_t, map_item);
            w_data = hold_info->data;
            /* make sure the instruction is to write the same amount of dwords we "held" */
            if (hold_info->num_of_dwords != fw_instruction->num_of_dwords) {
                if (hold_info->num_of_dwords < fw_instruction->num_of_dwords) {
                    w_data_dwords = hold_info->num_of_dwords;
                }
                SX_LOG_ERR("hold instruction:[%" PRId64 "] has:[%" PRId64 "] dwords held "
                           "but the write of the instruction is for:[%" PRId64 "] dwords "
                           "using the smaller value:[%" PRId64 "] to prevent CR space overrun\n",
                           fw_instruction->data, hold_info->num_of_dwords,
                           fw_instruction->num_of_dwords, w_data_dwords);
            }
        } else {
            if (w_data_dwords > (int64_t)(sizeof(fw_instruction->data) / DBG_DMP_BYTES_IN_DWORD)) {
                SX_LOG_ERR("write instruction error, data is:[%zu] bytes (%zu dwords) and number of dwords to write is:[%" PRId64 "] "
                           "skipping to prevent CR space overrun\n",
                           sizeof(fw_instruction->data),
                           (sizeof(fw_instruction->data) / DBG_DMP_BYTES_IN_DWORD),
                           w_data_dwords);
                rc = SXD_STATUS_HANDLE_ERROR;
                goto out;
            }
        }

        rc = __sxd_dbg_utils_get_instruction_ops(w_data_dwords, &ops_num, &last_op_bytes);
        if (rc) {
            goto out;
        }
        for (i = 0; i < ops_num; i++) {
            /* by default we will read the max, if this is the last read we will only read "last_op_bytes"*/
            tmp_bytes = DBG_DMP_BYTES_IN_DWORD * DBG_DMP_MAX_DWORDS;
            /* read from the address at record start + the number of bytes already read */
            tmp_addr = fw_instruction->address + (i * DBG_DMP_MAX_DWORDS * DBG_DMP_BYTES_IN_DWORD);

            /* if this is the last read (also valid for only 1 read), use "last_op_bytes"
             * else use the maximal value (4 * ctx.max_dwords) */
            if (i == (ops_num - 1)) {
                tmp_bytes = last_op_bytes;
            }

            rc = sx_cr_access_write(dev_id, tmp_addr, w_data, tmp_bytes);
            if (rc) {
                SX_LOG_ERR("device:[%d], could not write:[%d] bytes from address:[0x%06x]\n",
                           dev_id, tmp_bytes, tmp_addr);
                rc = SXD_STATUS_SUCCESS;     /* ignore and continue, best effort */
            }
        }
        break;

    case SXD_FW_INSTRUCTION_TYPE_HOLD:
        /* Read all the data from the addresses which we will want to "hold" */
        rc = __sxd_dbg_utils_get_instruction_ops(fw_instruction->num_of_dwords, &ops_num, &last_op_bytes);
        if (rc) {
            goto out;
        }
        if (ops_num > 1) {
            /* for now this is a programming error! */
            rc = SXD_STATUS_PARAM_ERROR;
            SX_LOG_ERR("FW instruction hold is only implemented for max of:[%d] dwords\n",
                       DBG_DMP_MAX_DWORDS);
            goto out;
        }
        for (i = 0; i < ops_num; i++) {
            /* by default we will read the max, if this is the last read we will only read "last_op_bytes"*/
            tmp_bytes = DBG_DMP_BYTES_IN_DWORD * DBG_DMP_MAX_DWORDS;
            /* read from the address at record start + the number of bytes already read */
            tmp_addr = fw_instruction->address + (i * DBG_DMP_MAX_DWORDS * DBG_DMP_BYTES_IN_DWORD);

            /* if this is the last read (also valid for only 1 read), use "last_op_bytes"
             * else use the maximal value (4 * DBG_DMP_MAX_DWORDS) */
            if (i == (ops_num - 1)) {
                tmp_bytes = last_op_bytes;
            }

            rc = sx_cr_access_read(dev_id, tmp_addr, data, tmp_bytes);
            if (rc) {
                SX_LOG_ERR("device:[%d], could not read:[%d] bytes from address:[0x%06x]\n",
                           dev_id, tmp_bytes, tmp_addr);
                rc = SXD_STATUS_SUCCESS;      /* ignore and continue, best effort */
            }
            hold_info = (sxd_fw_dbg_hold_info_t*)cl_malloc(sizeof(sxd_fw_dbg_hold_info_t));
            memcpy(hold_info->data, data, sizeof(hold_info->data));
            hold_info->num_of_dwords = fw_instruction->num_of_dwords;
            /* Hold the data that was read, in the fmap:global_fw_vars_map
             * Key: in the instruction->data which is the "name" -> key
             * Data: data we just read from the sx_cr_access_read calls */
            cl_qmap_insert(fw_vars_map, fw_instruction->data, &(hold_info->map_item));
        }

        break;

    case SXD_FW_INSTRUCTION_TYPE_PRINT:
        /*fw_instruction->data is presumed to be ASCII, maybe add some logic to convert and check */
        dbg_utils_print(stream, "\t%" PRId64 " \n", fw_instruction->data);
        break;

    default:
        SX_LOG_ERR("not valid chip type\n");
        rc = SXD_STATUS_PARAM_ERROR;
        break;
    }


    *addr_count += address_count;
out:
    return rc;
}

static sxd_status_t __sxd_dbg_utils_perform_fw_tile_instruction(const sxd_dev_id_t dev_id,
                                                                FILE             * stream,
                                                                uint32_t           instruction_idx,
                                                                unsigned char     *data,
                                                                uint8_t            tile_idx,
                                                                uint32_t          *addr_count)
{
    sxd_status_t                    rc = SXD_STATUS_SUCCESS;
    int                             ops_num = 0;
    int                             last_op_bytes = 0;
    int                             tmp_bytes = 0;
    int                             tmp_addr = 0;
    int                             i = 0;
    int                             j = 0;
    const sxd_fw_dbg_instruction_t *fw_instruction = NULL;
    uint32_t                        address_count = 0;

    if (instruction_idx >= sxd_global_fw_dbg_tiles_offsets.num_of_inst) {
        rc = SXD_STATUS_PARAM_ERROR;
        goto out;
    }
    fw_instruction = &(sxd_global_fw_dbg_tiles_offsets.sxd_fw_dbg_instructions[instruction_idx]);

    if (fw_instruction->type != SXD_FW_INSTRUCTION_TYPE_READ) {
        rc = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR(" FW instruction is not valid at index:[%d] instruction :[%d]\n",
                   instruction_idx,
                   fw_instruction->type);
        goto out;
    }

    rc = __sxd_dbg_utils_get_instruction_ops(fw_instruction->num_of_dwords, &ops_num, &last_op_bytes);
    if (rc) {
        goto out;
    }
    for (i = 0; i < ops_num; i++) {
        /* by default we will read the max, if this is the last read we will only read "last_op_bytes"*/
        tmp_bytes = DBG_DMP_BYTES_IN_DWORD * DBG_DMP_MAX_DWORDS;
        tmp_addr = fw_instruction->address + (DBG_DMP_TILES_BASE_ADDR + (DBG_DMP_TILES_OFFSET * tile_idx))
                   + (i * DBG_DMP_MAX_DWORDS * DBG_DMP_BYTES_IN_DWORD);

        /* if this is the last read (also valid for only 1 read), use "last_op_bytes"
         * else use the maximal value (4 * ctx.max_dwords) */
        if (i == (ops_num - 1)) {
            tmp_bytes = last_op_bytes;
        }

        rc = sx_cr_access_read(dev_id, tmp_addr, data, tmp_bytes);
        if (rc) {
            SX_LOG_ERR("device:[%d], could not read:[%d] bytes from address:[0x%06x] code:[%d, %s]\n",
                       dev_id, tmp_bytes, tmp_addr, rc, SXD_STATUS_MSG(rc));
            rc = SXD_STATUS_SUCCESS;     /* ignore and continue, best effort */
        }

        /* write the data to the file */
        for (j = 0; j < (tmp_bytes / DBG_DMP_BYTES_IN_DWORD); j++) {
            /* print the address and Process every byte in the data, do 4 at a time to save I/O */
            dbg_utils_print(stream, "0x%08x 0x%02x%02x%02x%02x\n",
                            tmp_addr, data[(j * 4) + 0], data[(j * 4) + 1], data[(j * 4) + 2], data[(j * 4) + 3]);
            tmp_addr += DBG_DMP_BYTES_IN_DWORD;
            address_count++;
        }
    }

    *addr_count += address_count;
out:
    return rc;
}

/*
 * this function will return a pointer to the memory which holds ASIC type
 * the FW debug instructions and their amount
 *
 * ret_num_of_inst is 1 based
 */
static sxd_status_t __sxd_dbg_get_fw_dbg_instruction(const sxd_chip_types_t           chip_type,
                                                     uint32_t                         instruction_idx,
                                                     const sxd_fw_dbg_instruction_t **ret_instruction)
{
    sxd_status_t err = 0;

    if (instruction_idx >= sxd_global_fw_dbg_per_type[chip_type].num_of_inst) {
        err = SXD_STATUS_PARAM_ERROR;
        goto out;
    }
    *ret_instruction = &(sxd_global_fw_dbg_per_type[chip_type].sxd_fw_dbg_instructions[instruction_idx]);

out:
    return err;
}

sxd_status_t sxd_fw_dbg_extract(sxd_chip_types_t chip_type, sxd_dev_id_t dev_id, FILE * stream,
                                uint32_t* address_count)
{
    sxd_status_t   err = 0;
    int            err_cleanup = 0;
    uint32_t       i = 0, tile_idx = 0;
    unsigned char *data = NULL;
    cl_qmap_t      fw_vars_map;   /* to hold variables given by the FW */
    boolean_t      cr_access_inited = FALSE;
    int            read_err_cnt = 0;

    /* Init map to hold the FW variables and their values */
    cl_qmap_init(&fw_vars_map);

    if (FALSE == sxd_global_fw_dbg_per_type[chip_type].is_inited) {
        SX_LOG_NTC("sxd_fw_dbg_extract FW instruction structure for type:[%d] not yet initialized, "
                   "trying to initialize it now\n",
                   chip_type);

        err = sxd_fw_dbg_init_info_per_asic_type(chip_type);
        if (err != SXD_STATUS_SUCCESS) {
            err = SXD_STATUS_ERROR;
            SX_LOG_ERR("sxd_fw_dbg_extract failed to initialize FW instructions for device id:[%u] ASIC type:[%d]\n",
                       dev_id, chip_type);
            goto out;
        }
    }

    /* need, not already made elsewhere in dvs_start*/
    if (!sx_cr_access_is_initialized()) {
        err = sx_cr_access_init();
        if (err != SXD_STATUS_SUCCESS) {
            err = SXD_STATUS_ERROR;
            SX_LOG_ERR("sxd_fw_dbg_extract failed to open CR access for device id:[%u] ASIC type:[%d]\n",
                       dev_id, chip_type);
            goto out;
        }
        cr_access_inited = TRUE;
    }

    /* allocate the read buffer, 4 bytes in a dword */
    data = (unsigned char*)cl_malloc(sizeof(unsigned char) * (DBG_DMP_BYTES_IN_DWORD * DBG_DMP_MAX_DWORDS));
    memset(data, 0, sizeof(unsigned char) * (DBG_DMP_BYTES_IN_DWORD * DBG_DMP_MAX_DWORDS));

    for (i = 0; i < sxd_global_fw_dbg_per_type[chip_type].num_of_inst; i++) {
        read_err_cnt +=
            (SXD_STATUS_ERROR ==
             __sxd_dbg_utils_perform_fw_instruction(dev_id, chip_type, stream, i, data, &fw_vars_map, address_count));
        memset(data, 0, sizeof(unsigned char) * (DBG_DMP_BYTES_IN_DWORD * DBG_DMP_MAX_DWORDS));
        if (MAX_FAILED_READS_ALLOWED == read_err_cnt) {
            SX_LOG_ERR("sxd_fw_dbg_extract failed to read %d times, aborting..\n",
                       MAX_FAILED_READS_ALLOWED);
            break;
        }
    }

    /* handle tiles segment  */
    if (chip_type == SXD_CHIP_TYPE_SPECTRUM3) {
        if (FALSE == sxd_global_fw_dbg_tiles_offsets.is_inited) {
            err = sxd_fw_dbg_init_tiles_info_per_asic_type(chip_type);
            if (err != SXD_STATUS_SUCCESS) {
                err = SXD_STATUS_ERROR;
                SX_LOG_ERR("Failed to initialize FW tiles instructions for device id:[%u]\n",
                           chip_type);
                goto out;
            }
        }
        for (tile_idx = 0; tile_idx < sxd_global_fw_dbg_tiles_info_g.num_of_tiles; tile_idx++) {
            if (!(sxd_global_fw_dbg_tiles_info_g.disabled_tiles_bitmap & (1 << tile_idx))) {
                /* if tile idx bit is down - print tile info to crspace dump */
                for (i = 0; i < sxd_global_fw_dbg_tiles_offsets.num_of_inst; i++) {
                    __sxd_dbg_utils_perform_fw_tile_instruction(dev_id, stream, i, data, tile_idx, address_count);
                    memset(data, 0, sizeof(unsigned char) * (DBG_DMP_BYTES_IN_DWORD * DBG_DMP_MAX_DWORDS));
                }
            }
        }
    }

out:
    if (data) {
        cl_free(data);
    }

    if (cr_access_inited) {
        err_cleanup = sx_cr_access_deinit();
        if (err_cleanup != 0) {
            SX_LOG_ERR("sx_cr_access_deinit error: %s\n", strerror(errno));
        }
    }

    /* empty the hush */
    cl_qmap_remove_all(&fw_vars_map);
    return err;
}

#define HEX_DIGIT_TO_CHAR(dig) (((dig) <= 9) ? (dig) + '0' : (dig) - 10 + 'a')

/* dump line is based on the specific format "0x%02x%02x%02x%02x 0x%02x%02x%02x%02x\n" */
static int __generate_one_dump_line(char *buf, const unsigned char *byte)
{
    /* DO NOT USE sprintf() here!!! You'll get a performance problem! */

    buf[0] = '0';
    buf[1] = 'x';
    buf[2] = HEX_DIGIT_TO_CHAR(byte[0] >> 4);
    buf[3] = HEX_DIGIT_TO_CHAR(byte[0] & 0xf);
    buf[4] = HEX_DIGIT_TO_CHAR(byte[1] >> 4);
    buf[5] = HEX_DIGIT_TO_CHAR(byte[1] & 0xf);
    buf[6] = HEX_DIGIT_TO_CHAR(byte[2] >> 4);
    buf[7] = HEX_DIGIT_TO_CHAR(byte[2] & 0xf);
    buf[8] = HEX_DIGIT_TO_CHAR(byte[3] >> 4);
    buf[9] = HEX_DIGIT_TO_CHAR(byte[3] & 0xf);
    buf[10] = ' ';
    buf[11] = '0';
    buf[12] = 'x';
    buf[13] = HEX_DIGIT_TO_CHAR(byte[4] >> 4);
    buf[14] = HEX_DIGIT_TO_CHAR(byte[4] & 0xf);
    buf[15] = HEX_DIGIT_TO_CHAR(byte[5] >> 4);
    buf[16] = HEX_DIGIT_TO_CHAR(byte[5] & 0xf);
    buf[17] = HEX_DIGIT_TO_CHAR(byte[6] >> 4);
    buf[18] = HEX_DIGIT_TO_CHAR(byte[6] & 0xf);
    buf[19] = HEX_DIGIT_TO_CHAR(byte[7] >> 4);
    buf[20] = HEX_DIGIT_TO_CHAR(byte[7] & 0xf);
    buf[21] = '\n';

    return 22;
}

static void __dump_memblk_to_file(unsigned char *dump_buff, int size, int out_char_num, FILE *fp,
                                  uint32_t  *addr_count)
{
    int            i, ret = 0, buf_len = 0;
    char          *tmp = NULL;
    unsigned char *dev_data = NULL;
    size_t         write_len = 0, offset = 0;
    uint32_t       address_count = 0;

    if (size <= 0) {
        goto out;
    }
    if (size % DBG_DMP_BYTES_PER_LINE != 0) {
        SX_LOG_ERR("cr_dump buff size (%x) is not %d aligned, e.g.,{32bit address, 32 bit value}.\n",
                   size,
                   DBG_DMP_BYTES_PER_LINE);
        goto out;
    }

    /* size                          ===> number of bytes in the current dump bulk.
     * size / DBG_DMP_BYTES_PER_LINE ===> number of address/value pairs (lines) in the current dump bulk.
     * out_char_num                  ===> number of characters per dump line.
     * +1                            ===> '\0' at the end of the last line.
     */
    buf_len = (size / DBG_DMP_BYTES_PER_LINE) * out_char_num + 1;
    tmp = (char *)cl_malloc(buf_len);
    if (!tmp) {
        /* if no bulk memory, we follow old way with less writing speed */
        for (i = 0; i < size; i += DBG_DMP_BYTES_PER_LINE) {
            dev_data = (unsigned char *)(dump_buff + i);
            dbg_utils_print(fp, "0x%02x%02x%02x%02x 0x%02x%02x%02x%02x\n",
                            dev_data[0], dev_data[1], dev_data[2], dev_data[3],
                            dev_data[4], dev_data[5], dev_data[6], dev_data[7]);
            address_count++;
        }
        goto out;
    }
    /* we change crspace bytes to string format and fill them into to a bulk memory, then fwrite to file to get higher writing speed. */
    for (i = 0; i < size; i += DBG_DMP_BYTES_PER_LINE) {
        ret = __generate_one_dump_line(tmp + offset, dump_buff + i);
        offset += ret;
        address_count++;
    }
    write_len = cl_fwrite(tmp, sizeof(char), offset, fp);
    if (write_len < offset) {
        SX_LOG_ERR("cr_dump buff writing (size: %lu, written size: %lu) error.\n", offset, write_len);
    }
out:

    if (addr_count != NULL) {
        *addr_count += address_count;
    }

    if (tmp) {
        cl_free(tmp);
    }
    return;
}

static void __sxd_dump_buf(FILE * stream, unsigned char *data, uint64_t buf_size, uint32_t  *addr_count)
{
    boolean_t single_cafe = FALSE;

    if (buf_size % SX_CR_DUMP_CANARY_BYTE_NUM) {
        SX_LOG_ERR("cr_dump buff size (%lx) is not DWORD aligned, and canary word would be only 1.\n",
                   buf_size);
        single_cafe = TRUE;
    }

    if (buf_size >= SX_CR_DUMP_CANARY_BYTE_NUM) {
        if (cl_ntoh32(*(uint32_t *)(data + buf_size - 4)) != SX_CR_DUMP_CANARY_MAGIC_WORD) {
            SX_LOG_ERR("cr_dump last canary word mismatch: return value (0x%X), expected value (0x%X).\n",
                       *(uint32_t *)(data + buf_size - SX_CR_DUMP_CANARY_BYTE_NUM + 4),
                       SX_CR_DUMP_CANARY_MAGIC_WORD);
            return;
        }
        if (!single_cafe &&
            (cl_ntoh32(*(uint32_t *)(data + buf_size - SX_CR_DUMP_CANARY_BYTE_NUM)) != SX_CR_DUMP_CANARY_MAGIC_WORD)) {
            SX_LOG_ERR("cr_dump last 2nd canary word mismatch: return value (0x%X), expected value (0x%X).\n",
                       *(uint32_t *)(data + buf_size - SX_CR_DUMP_CANARY_BYTE_NUM),
                       SX_CR_DUMP_CANARY_MAGIC_WORD);
            return;
        }
        /* "0x%02x%02x%02x%02x 0x%02x%02x%02x%02x\n" per 8 bytes to dump, 22 bytes of string */
        __dump_memblk_to_file(data, buf_size - SX_CR_DUMP_CANARY_BYTE_NUM, 22, stream, addr_count);
        /* clear canary tail */
        *(uint32_t *)(data + buf_size - SX_CR_DUMP_CANARY_BYTE_NUM + 4) = 0;
        *(uint32_t *)(data + buf_size - SX_CR_DUMP_CANARY_BYTE_NUM) = 0;
    }
}

sxd_status_t sxd_allow_secure_fw_dump(boolean_t permit)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    err = sxd_dpt_issu_in_progress_set(!permit);
    if (SXD_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set ISSU in-progress flag to %s in DPT\n", (!permit) ? "TRUE" : "FALSE");
        goto out;
    }

    if (!permit) {
        /* Depending on mem-blk size and FW transfer rate, we must consider the longest time
         *  consumed of a FW dump session, and wait for it to finish. */
        usleep(SX_SECURE_DUMP_MAX_WAIT_FW_DUMP_MS(__secure_fw_dump_dma_memblk_size, __secure_fw_gdb_dump) * 1000);
    }

out:
    return err;
}

void __sxd_dump_binary_buf(FILE * stream, unsigned char *data, uint64_t buf_size)
{
    boolean_t single_cafe = FALSE;
    size_t    write_len = 0, valid_len = 0;

    if (buf_size >= SX_CR_DUMP_CANARY_BYTE_NUM) {
        if (cl_ntoh32(*(uint32_t *)(data + buf_size - 4)) != SX_CR_DUMP_CANARY_MAGIC_WORD) {
            SX_LOG_ERR("cr_dump last canary word mismatch: return value (0x%X), expected value (0x%X).\n",
                       *(uint32_t *)(data + buf_size - SX_CR_DUMP_CANARY_BYTE_NUM + 4),
                       SX_CR_DUMP_CANARY_MAGIC_WORD);
            return;
        }
        if (!single_cafe &&
            (cl_ntoh32(*(uint32_t *)(data + buf_size - SX_CR_DUMP_CANARY_BYTE_NUM)) != SX_CR_DUMP_CANARY_MAGIC_WORD)) {
            SX_LOG_ERR("cr_dump last 2nd canary word mismatch: return value (0x%X), expected value (0x%X).\n",
                       *(uint32_t *)(data + buf_size - SX_CR_DUMP_CANARY_BYTE_NUM),
                       SX_CR_DUMP_CANARY_MAGIC_WORD);
            return;
        }
        valid_len = buf_size - SX_CR_DUMP_CANARY_BYTE_NUM;
        write_len = cl_fwrite(data, sizeof(char), valid_len, stream);
        if (write_len < valid_len) {
            SX_LOG_ERR("cr_dump buff writing (size: %lu, written size: %lu) error.\n", valid_len, write_len);
        }
        /* clear canary tail */
        *(uint32_t *)(data + buf_size - SX_CR_DUMP_CANARY_BYTE_NUM + 4) = 0;
        *(uint32_t *)(data + buf_size - SX_CR_DUMP_CANARY_BYTE_NUM) = 0;
    }
}

sxd_status_t sxd_secure_fw_op_transaction_dump(sxd_chip_types_t chip_type,
                                               sxd_dev_id_t     dev_id,
                                               uint8_t          opcode,
                                               FILE           * stream,
                                               uint32_t        *address_count_p,
                                               uint32_t        *layer1_count_p)
{
    sxd_status_t          err = 0;
    int                   err_cleanup = 0;
    uint32_t              dumped_size = 0, dump_size = 0;
    unsigned char        *data = NULL;
    int                   layer2_timeout = SXD_CR_DUMP_LAYER2_TIMEOUT;
    boolean_t             is_finished = FALSE;
    boolean_t             memory_mapped = FALSE;
    boolean_t             cancel_sent = FALSE;
    pid_t                 pid = 0;
    uint8_t               start_opcode = opcode;
    struct sx_cr_dump_ret dump_ret;
    boolean_t             issu_in_progress = FALSE;
    boolean_t             cr_access_inited = FALSE;
    uint32_t              layer1_timeout_count = 0;

    if (!IS_VALID_START_OPCODE(start_opcode)) {
        SX_LOG_ERR("ERROR: unsupported start opcode value (%u).\n", (start_opcode));
        err = SXD_STATUS_ERROR;
        goto out;
    }

    err = sxd_dpt_issu_in_progress_get(&issu_in_progress);
    if (SXD_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to get ISSU in-progress flag from DPT\n");
        goto out;
    }

    if (issu_in_progress) {
        SX_LOG_ERR("CR-Space dump is not permitted since ISSU is now in progress\n");
        err = SXD_STATUS_ERROR;
        goto out;
    }

    /* need, not already made elsewhere in dvs_start*/
    if (!sx_cr_access_is_initialized()) {
        err = sx_cr_access_init();
        if (err != SXD_STATUS_SUCCESS) {
            err = SXD_STATUS_ERROR;
            SX_LOG_ERR(
                "sxd_secure_fw_op_transaction_dump failed to open CR access for opcode:[%u] device id:[%u] chip_type:[%d]\n",
                opcode,
                dev_id,
                chip_type);
            goto out;
        }
        cr_access_inited = TRUE;
    }
    err = sx_cr_dump_get_pid(&pid);
    if (err) {
        SX_LOG_ERR("Fail to get current pid\n");
        err = SXD_STATUS_ERROR;
        goto out;
    }

    __secure_fw_dump_dma_memblk_size = SX_CR_DUMP_MEMBLK_SIZE;
    __secure_fw_gdb_dump = FALSE;

    memset(&dump_ret, 0, sizeof(dump_ret));
    if (IS_SINGLE_DUMP_MODE(opcode, chip_type)) {
        err = sx_cr_dump(dev_id, SX_CR_DUMP_OP_GET_GDB_DUMP_LIMIT, 0, 0, NULL, 0, &dump_ret);
        if (err) {
            SX_LOG_ERR(
                "Failed to get dump limit, err:[%d, %s], ret: %d, dump_sn:%u, trans_sn:%u, host_size_used:%" PRId64 "\n",
                err,
                SXD_STATUS_MSG(err),
                dump_ret.ret_code,
                dump_ret.ret_cmd_mem.dump_sn,
                dump_ret.ret_cmd_mem.trans_sn,
                dump_ret.ret_cmd_mem.host_size_used);
            err = SXD_STATUS_ERROR;
            goto out;
        }

        /* we need to check possible oversize of GDB dump, and need double check with FW. */
        if (dump_ret.ret_cmd_mem.host_size_used > (SX_CR_DUMP_MEMBLK_SIZE * 2)) {
            SX_LOG_NTC(
                "dump limit (%" PRId64 ") is too big to be a valid 'cap_dump_host_size_gdb' for a single dump.\n",
                dump_ret.ret_cmd_mem.host_size_used);
        }

        __secure_fw_dump_dma_memblk_size = ROUNDUP(dump_ret.ret_cmd_mem.host_size_used, SXD_CR_DUMP_HOST_MEM_ALIGN);
        __secure_fw_gdb_dump = TRUE;
    }

    /* set the memory allocation scheme to be kmalloc. */
    err = sx_cr_dump_set_mem_alloc_scheme_kmalloc();
    if (err) {
        SX_LOG_ERR("Failed to set the memory allocation scheme to kmalloc\n");
        goto out;
    }

    /* cr_dump requires a consecutive kernel memory, and mmap may fail. We will try to mmap a smaller memory block. */
    do {
        err = sx_cr_dump_mmap((void **)&data, sizeof(unsigned char) * __secure_fw_dump_dma_memblk_size);
        if (err == SXD_STATUS_SUCCESS) {
            break;
        }
        if (IS_SINGLE_DUMP_MODE(opcode, chip_type)) {
            break;
        }
        __secure_fw_dump_dma_memblk_size = __secure_fw_dump_dma_memblk_size / 2;
    } while (__secure_fw_dump_dma_memblk_size > SX_CR_DUMP_MIN_MEMBLK_SIZE);

    if (err != SXD_STATUS_SUCCESS) {
        err = SXD_STATUS_NO_MEMORY;
        SX_LOG_ERR(
            "sxd_secure_fw_op_transaction_dump failed to allocate memory block (size:%lu) for device id:[%u] opcode:[%u] chip_type:[%d]\n",
            sizeof(unsigned char) * __secure_fw_dump_dma_memblk_size,
            dev_id,
            opcode,
            chip_type);
        goto out;
    }
    memory_mapped = TRUE;
    memset(data, 0, sizeof(unsigned char) * __secure_fw_dump_dma_memblk_size);

    dump_size = __secure_fw_dump_dma_memblk_size;
    /* cr-dump session */
    do {
        err = sx_cr_dump(dev_id, opcode, pid, dumped_size, data, dump_size, &dump_ret);
        /* check syscall ret */
        if (err) {
            SX_LOG_ERR(
                "Something is wrong with cr_dump, err:[%d, %s], ret: %d, dump_sn:%u, trans_sn:%u, host_size_used:%" PRId64 "\n",
                err,
                SXD_STATUS_MSG(err),
                dump_ret.ret_code,
                dump_ret.ret_cmd_mem.dump_sn,
                dump_ret.ret_cmd_mem.trans_sn,
                dump_ret.ret_cmd_mem.host_size_used);
            err = SXD_STATUS_ERROR;
            goto out;
        }
        SX_LOG_DBG("after sx_cr_dump, err:[%d, %s], ret: %d, dump_sn:%u, trans_sn:%u, host_size_used:%" PRId64 "\n",
                   err,
                   SXD_STATUS_MSG(err),
                   dump_ret.ret_code,
                   dump_ret.ret_cmd_mem.dump_sn,
                   dump_ret.ret_cmd_mem.trans_sn,
                   dump_ret.ret_cmd_mem.host_size_used);
        /* check whether there is cancel triggered from other API, i.e., ISSU */
        if (!cancel_sent) {
            err = sxd_dpt_issu_in_progress_get(&issu_in_progress);
            if (SXD_CHECK_FAIL(err)) {
                SX_LOG_ERR("Failed to get ISSU in-progress flag from DPT\n");
                goto out;
            }

            if (issu_in_progress) {
                SX_LOG_ERR("cr_dump is requested to cancel from outside, e.g, by a FW_ISSU API call.\n");
                dump_size = 0; /* prepare to CANCEL cr_dump */
                cancel_sent = TRUE;
                continue;
            }
        }

        if (dump_ret.ret_code != SX_CR_DUMP_RET_LAYER1_TIMEOUT) {
            layer2_timeout = SXD_CR_DUMP_LAYER2_TIMEOUT;
        }

        switch (dump_ret.ret_code) {
        case SX_CR_DUMP_RET_CANCEL_GENERAL:
            SX_LOG_ERR("Cr_dump cancels normally.\n");
            goto out;

        case SX_CR_DUMP_RET_CANCEL_OLD_DUMP:
        case SX_CR_DUMP_RET_CANCEL_MESS_FW:
        case SX_CR_DUMP_RET_CANCEL_FW_PARAM_MISALIGN:
        case SX_CR_DUMP_RET_CANCEL_DUMP_SIZE_OVERFLOW:
        case SX_CR_DUMP_RET_CANCEL_DUMPSN_ERR:
        case SX_CR_DUMP_RET_CANCEL_TRANSSN_ERR:
        case SX_CR_DUMP_RET_CANCEL_FW_WRITE_OVERWRITE:
        case SX_CR_DUMP_RET_CANCEL_CANARY_ERR:
            SX_LOG_ERR("Cr_dump is to cancel due to internal errors (reason code: %d)\n",
                       dump_ret.ret_code);
            err = SXD_STATUS_ERROR;
            goto out;

        case SX_CR_DUMP_RET_FINISH:
            is_finished = TRUE;
            break;

        case SX_CR_DUMP_RET_TO_BE_CONT:
            opcode = SX_CR_DUMP_OP_CONT;
            break;

        case SX_CR_DUMP_RET_LAYER1_TIMEOUT:
            layer1_timeout_count++;
            layer2_timeout--;
            SX_LOG_NTC("receive layer1 timeout: sdk will continue to after wait some time. (Return value: %u).\n",
                       dump_ret.ret_code);
            if (layer2_timeout <= 0) {
                dump_size = 0;
                opcode = SX_CR_DUMP_OP_CANCEL;
            } else {
                if ((opcode == SX_CR_DUMP_OP_START_FLAT) || (opcode == SX_CR_DUMP_OP_START_REDUCED_FLAT) ||
                    (opcode == SX_CR_DUMP_OP_START_GDB)) {
                    opcode = SX_CR_DUMP_OP_START_WAIT;
                }
                if (opcode == SX_CR_DUMP_OP_CONT) {
                    opcode = SX_CR_DUMP_OP_CONT_WAIT;
                }
            }
            break;

        case SX_CR_DUMP_RET_FATAL_FW_ERR:
            SX_LOG_ERR("ERROR: FW is in wrong state and cr_dump cannot work. (Return value: %u).\n",
                       dump_ret.ret_code);
            err = SXD_STATUS_PARAM_ERROR;
            goto out;

        default:
            SX_LOG_ERR("ERROR: unrecognized return value (%u).\n", dump_ret.ret_code);
            err = SXD_STATUS_PARAM_ERROR;
            goto out;
        }

        if (dump_ret.ret_code == SX_CR_DUMP_RET_LAYER1_TIMEOUT) {
            continue;
        }

        if ((start_opcode == SX_CR_DUMP_OP_START_FLAT) || (start_opcode == SX_CR_DUMP_OP_START_REDUCED_FLAT) ||
            (start_opcode == SX_CR_DUMP_OP_START_GW)) {
            __sxd_dump_buf(stream, data, dump_ret.ret_cmd_mem.host_size_used, address_count_p);
        } else {
            /* SX_CR_DUMP_OP_START_GDB */
            __sxd_dump_binary_buf(stream, data, dump_ret.ret_cmd_mem.host_size_used);
        }
        dumped_size += dump_ret.ret_cmd_mem.host_size_used;
    } while (!is_finished);

    if (layer1_count_p != NULL) {
        *layer1_count_p += layer1_timeout_count;
    }

out:
    if (memory_mapped) {
        err_cleanup = sxd_memory_unmap(data, sizeof(unsigned char) * __secure_fw_dump_dma_memblk_size);
        if (err_cleanup != 0) {
            SX_LOG_ERR("Cr_dump memory block: sxd_memory_unmap error: %s\n", strerror(errno));
        }
    }

    if (cr_access_inited) {
        err_cleanup = sx_cr_access_deinit();
        if (err_cleanup != 0) {
            SX_LOG_ERR("sx_cr_access_deinit error: %s\n", strerror(errno));
        }
    }

    return err;
}

/*
 * this function will create a SINGLETON "large" memory (~1m) to hold the FW instructions
 * on how to extract FW debug info. this info is per ASIC type encountered.
 *
 * This method is used to access the main CRspace segment.
 */
sxd_status_t sxd_fw_dbg_init_info_per_asic_type(sxd_chip_types_t chip_type)
{
    return (__sxd_fw_dbg_init_info_per_asic_type(chip_type, SXD_FW_INSTRUCTION_SEGMENT_TYPE_MAIN));
}

/*
 * This function will allocate a SINGLETON "large" memory to hold the FW tiles offsets
 * on how to extract FW debug info.
 *
 * This method is used to access the tiles CRspace segment.
 */
sxd_status_t sxd_fw_dbg_init_tiles_info_per_asic_type(sxd_chip_types_t chip_type)
{
    return (__sxd_fw_dbg_init_info_per_asic_type(chip_type, SXD_FW_INSTRUCTION_SEGMENT_TYPE_TILES));
}

/*
 * this function will create a SINGLETON "large" memory (~1m) to hold the FW instructions
 * on how to extract FW debug info. this info is per ASIC type encountered.
 *
 * I.E usually there will be only one,
 * in director systems maybe more depending on ASIC types in the chassis.
 *
 * In SPC2 systems will create one for the main CRspace addresses and another for the tiles offsets
 * which will be used to access the mapped tiles CRspace addresses.
 *
 * in order to allocate the buffer we need to read the "fw debug header" and allocate according to "number of instructions"
 */
static sxd_status_t __sxd_fw_dbg_init_info_per_asic_type(sxd_chip_types_t                  chip_type,
                                                         sxd_fw_instruction_segment_type_t segment_type)
{
    sxd_status_t            err = SXD_STATUS_SUCCESS;
    cl_status_t             rc = CL_SUCCESS;
    uint32_t                num_of_inst = 0;
    FILE                   *file_p = NULL;
    const char             *file_name = NULL;
    char                    path[FULL_FILE_PATH_LENGTH] = {0};
    const long int          max_len = DBG_DMP_MAX_LEN;
    char                    buff[DBG_DMP_MAX_LEN + 1] = {0};
    char                   *token = NULL;
    char                   *token2 = NULL;
    size_t                  file_size = 0;
    char                   *file_buff = NULL;
    uint32_t                i = 0;
    char                   *rest_str = NULL;
    sxd_fw_dbg_inst_info_t *dbg_inst_info_p = NULL;
    char                   *custom_prefix = NULL;
    uint32_t                custom_prefix_len = 0;
    uint32_t                max_prefix_len = 0;
    uint32_t                filename_len = 0;
    uint32_t                dbg_path_len = 0;

    /* Devices that support only secured-FW should skip this phase */
    if ((chip_type == SXD_CHIP_TYPE_QUANTUM2) || (chip_type == SXD_CHIP_TYPE_SPECTRUM4) ||
        (chip_type == SXD_CHIP_TYPE_QUANTUM3) || (chip_type == SXD_CHIP_TYPE_SPECTRUM5)) {
        return 0;
    }

    /* check type validity */
    /* check device_id validity */

    if (segment_type == SXD_FW_INSTRUCTION_SEGMENT_TYPE_MAIN) {
        file_name = sxd_fw_dbg_chip_type2file(chip_type);
    } else {
        file_name = sxd_fw_dbg_chip_type2_tiles_file(chip_type);
    }
    if (NULL == file_name) {
        err = SXD_STATUS_PARAM_ERROR;
        /* coverity[lock_order] */
        SX_LOG_ERR("no debug file associated with ASIC type:[%d]\n", chip_type);
        goto out;
    }

    dbg_path_len = strlen(DBG_DMP_MAP_PATH);
    filename_len = strlen(file_name);
    custom_prefix = getenv(SX_SDK_CUSTOM_PREFIX);
    if (custom_prefix) {
        custom_prefix_len = strlen(custom_prefix);
        if (custom_prefix_len) {
            max_prefix_len = (FULL_FILE_PATH_LENGTH - dbg_path_len - filename_len - 1);
            if (custom_prefix_len > max_prefix_len) {
                err = SXD_STATUS_PARAM_ERROR;
                SX_LOG_ERR("for ASIC type:[%d], custom prefix is too long:[%s] for path [%s/%s]\n",
                           chip_type, custom_prefix,  DBG_DMP_MAP_PATH, file_name);
                goto out;
            }
            sprintf(path, "%s/", custom_prefix);
        }
    } else {
        if (FULL_FILE_PATH_LENGTH < (dbg_path_len + filename_len + 1)) {
            err = SXD_STATUS_PARAM_ERROR;
            SX_LOG_ERR("for ASIC type:[%d], path is too long:[%s/%s]\n", chip_type, DBG_DMP_MAP_PATH, file_name);
            goto out;
        }
    }
    strcat(path, DBG_DMP_MAP_PATH);
    strcat(path, file_name);

    /* Open the file relating to that device_id, for MR consider only doing this once in the API
     * I.E call this from: dbg_generate_dump_ext() API
     * */
    if (NULL == (file_p = cl_fopen(path, "r"))) {
        err = SXD_STATUS_HANDLE_ERROR;
        SX_LOG_ERR("could not open file:[%s] ASIC type:[%d] code:[%s]\n",
                   file_name, chip_type, strerror(errno));
        goto out;
    }

    rc = cl_file_size(file_p, &file_size);
    if (rc != CL_SUCCESS) {
        SX_LOG_ERR("Error checking for file size, code:[%s] \n", CL_STATUS_MSG(rc));
        err = SXD_STATUS_ERROR;
        goto out;
    }

    /* No need to allocate memory and read an empty file. */
    if (file_size == 0) {
        goto out;
    }

    /* Allocate a memory to hold the file */
    file_buff = (char*)cl_malloc(sizeof(unsigned char) * file_size);
    if (file_buff == NULL) {
        err = SXD_STATUS_NO_MEMORY;
        goto out;
    }
    memset(file_buff, 0, sizeof(char) * file_size);

    /* read the whole file in a single blow into: file_buff */
    if (1 != cl_fread((void*)file_buff, file_size, 1, file_p)) {
        err = SXD_STATUS_SUCCESS;
        goto out;
    }

    /* get the number of lines which are expected to be in the last line of the file */
    /* move the FD to 15 "bytes" (chars) from the end */
    if (0 != fseek(file_p, -max_len, SEEK_END)) {
        SX_LOG_ERR("could not jump to EOF\n");
        err = SXD_STATUS_ERROR;
        goto out;
    }

    /* read max_len chars and reach the EOF */
    if (cl_fread(buff, sizeof(char), max_len, file_p) == 0) {
        SX_LOG_ERR("Failed reading from file\n");
        err = SXD_STATUS_ERROR;
        goto out;
    }
    /* brake the sting so we can get the "token" after the ":" delimiter which is the amount of lines
     * NOTE: this assumes there is only one such delimiter in the last line which we read from the file
     * no verification on file formation was made here */
    rest_str = &buff[0];
    token = strtok_r(rest_str, ":", &rest_str);  /* buff is:{XXXXX\nline:WANTED_VALUE */
    token = strtok_r(NULL, " ,.-\n", &rest_str);
    num_of_inst = (uint32_t)strtoul(token, NULL, 10);
    SX_LOG_NTC("file:[%s] lines:[%u]\n", file_name, num_of_inst);

    /* allocate the memory */
    if (segment_type == SXD_FW_INSTRUCTION_SEGMENT_TYPE_MAIN) {
        err = __sxd_dbg_alloc_fw_dbg_info_per_asic_type(chip_type, num_of_inst);
        if (SXD_STATUS_SUCCESS != err) {
            goto out;
        }
        dbg_inst_info_p = &sxd_global_fw_dbg_per_type[chip_type];
    } else {
        err = __sxd_dbg_alloc_fw_dbg_tiles_info(num_of_inst);
        if (SXD_STATUS_SUCCESS != err) {
            goto out;
        }
        dbg_inst_info_p = &sxd_global_fw_dbg_tiles_offsets;
    }

    rest_str = file_buff;
    /* go over each line in file_buff and brake it to a sxd_fw_dbg_instructions */

    /* 0 Iteration */
    token = strtok_r(rest_str, " ,.-\n", &rest_str);   /* address 0 */
    token2 = strtok_r(NULL, " ,.-\n", &rest_str);   /* num_of_dwords 0*/
    dbg_inst_info_p->sxd_fw_dbg_instructions[i].address = strtol(token, NULL, 16);
    dbg_inst_info_p->sxd_fw_dbg_instructions[i].data = 0;
    dbg_inst_info_p->sxd_fw_dbg_instructions[i].num_of_dwords = strtol(token2, NULL, 10);
    dbg_inst_info_p->sxd_fw_dbg_instructions[i].type = SXD_FW_INSTRUCTION_TYPE_READ;

    for (i = 1; i < num_of_inst; i++) {
        token = strtok_r(NULL, " ,.-\n", &rest_str);   /* address (i = 1:num_of_inst) */
        if (NULL == token) {
            SX_LOG_WRN("file:[%s] expected:[%d] lines but has:[%d]\n",
                       file_name, num_of_inst, i);
            break;
        }
        token2 = strtok_r(NULL, " ,.-\n", &rest_str);   /* num_of_dwords (i = 1:num_of_inst)  */
        if (NULL == token) {
            SX_LOG_WRN("file:[%s] expected:[%d] lines but line:[%d], 2nd token is missing\n",
                       file_name, num_of_inst, i);
            break;
        }
        dbg_inst_info_p->sxd_fw_dbg_instructions[i].address = strtol(token, NULL, 16);
        dbg_inst_info_p->sxd_fw_dbg_instructions[i].data = 0;
        dbg_inst_info_p->sxd_fw_dbg_instructions[i].num_of_dwords = strtol(token2, NULL, 10);
        dbg_inst_info_p->sxd_fw_dbg_instructions[i].type = SXD_FW_INSTRUCTION_TYPE_READ;
    }
/* consider verifying this is the last line (I.E line: is the nest token) and print an issue if not */
    SX_LOG_NTC("file:[%s] parsing done\n", file_name);
out:
    if (NULL != file_p) {
        if (CL_SUCCESS != cl_fclose(file_p)) {
            SX_LOG_ERR("could not close file:[%s]\n", file_name); /* not sure what to do about it */
        }
    }
    if (NULL != file_buff) {
        if (CL_SUCCESS != cl_free(file_buff)) {
            SX_LOG_ERR("could not free memory allocated to hold file:[%s]\n", file_name); /* not sure what to do about it */
        }
        file_buff = NULL;
    }
    return err;
}

sxd_status_t sxd_fw_dbg_force_info_reinit(sxd_chip_types_t chip_type)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    if (chip_type > SXD_CHIP_TYPES_MAX) {
        SX_LOG_ERR("chip unknown and  not supported : [%d]\n", chip_type);
        return SXD_STATUS_PARAM_ERROR;
    }

    err = __sxd_dbg_dealloc_fw_dbg_info_per_asic_type(chip_type);
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deallocate FW instructions\n");
        goto out;
    }

    if (chip_type == SXD_CHIP_TYPE_SPECTRUM3) {
        err = __sxd_dbg_dealloc_fw_dbg_tiles_info();
        if (err != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to deallocate FW tiles instructions\n");
            goto out;
        }
    }

out:
    return err;
}

void sxd_fw_dbg_tiles_info_set(uint16_t disabled_tiles_bitmap)
{
    sxd_global_fw_dbg_tiles_info_g.num_of_tiles = DBG_DMP_TILES_NUM;
    sxd_global_fw_dbg_tiles_info_g.disabled_tiles_bitmap = disabled_tiles_bitmap;
    sxd_global_fw_dbg_tiles_info_g.is_inited = TRUE;

    return;
}

boolean_t sxd_fw_dbg_tiles_info_is_inited(void)
{
    return sxd_global_fw_dbg_tiles_info_g.is_inited;
}

sxd_status_t sxd_fw_dbg_deinit_info(void)
{
    sxd_status_t     err = SXD_STATUS_SUCCESS;
    sxd_chip_types_t chip_type = 0;

    for (chip_type = 1; chip_type < SXD_CHIP_TYPES_MAX; chip_type++) {
        err = __sxd_dbg_dealloc_fw_dbg_info_per_asic_type(chip_type);
        if (err != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to deallocate FW instructions\n");
            goto out;
        }
    }

    err = __sxd_dbg_dealloc_fw_dbg_tiles_info();
    if (err != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to deallocate FW tiles instructions\n");
        goto out;
    }

out:
    return err;
}

sxd_status_t sxd_fw_dbg_log_verbosity_level(sxd_access_cmd_t cmd, sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Get an unsupported access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    return err;
}

sxd_status_t sxd_dbg_generate_driver_dump(FILE *stream)
{
    sxd_status_t        rc = SXD_STATUS_SUCCESS;
    char                dumpfile_full_path[DUMPFILE_FULL_PATH_BUF_LEN] = "";
    DIR                *driver_dump_dir = NULL;
    struct dirent      *dumpfile = NULL;
    struct         stat fst;
    FILE               *driver_tmp_file = NULL;
    unsigned char       buffer[4096] = "";
    size_t              bytes_read = 0, total_bytes_written = 0, bytes_written = 0;
    size_t              c_size = sizeof(unsigned char);
    int                 ret = 0;
    uint8_t             write_error = 0;
    const char         *proc_dir_name = "/proc/" SX_DBG_DUMP_PROC_DIR;
    char                proc_dir_name_per_device[DBG_PROC_FOLDER_MAX_NAME_LEN] = {0};
    sxd_dev_id_t        predefined_dev = 0;
    char                dev_string[DEVICE_ID_STRING_MAX_LEN] = {0};

    /* In Multi-Asic systems we have a predefined device number associated with the SDK process.
     * Since we have a dbg_dump folder per each asic (/proc/dbg_dump/dev_X for device X),
     * we need to get this device number and read from it's proc files folder. */
    predefined_dev = __sxd_dbg_utils_get_predefined_dev();
    if (predefined_dev) {
        strncpy(proc_dir_name_per_device, proc_dir_name, DBG_PROC_FOLDER_MAX_NAME_LEN);
        snprintf(dev_string, DEVICE_ID_STRING_MAX_LEN, "/dev_%u", predefined_dev);
        strncat(proc_dir_name_per_device, dev_string, DEVICE_ID_STRING_MAX_LEN);
        proc_dir_name = proc_dir_name_per_device;
    }

    /* Open proc_dir_name directory for driver dump proc files */
    driver_dump_dir = opendir(proc_dir_name);
    if (driver_dump_dir == NULL) {
        SX_LOG_ERR("driver_dbg_generate_dump failed to open directory (%s), error (%s).\n",
                   proc_dir_name, strerror(errno));
        rc = SXD_STATUS_ERROR;
        goto out;
    }

    while ((dumpfile = readdir(driver_dump_dir)) != NULL) {
        if (dumpfile->d_type == DT_REG) {
            /* Get pull path string */
            ret = snprintf(dumpfile_full_path, DUMPFILE_FULL_PATH_BUF_LEN,
                           "%s/%s", proc_dir_name, dumpfile->d_name);
            if ((ret < 0) || (ret >= DUMPFILE_FULL_PATH_BUF_LEN)) {
                SX_LOG_ERR("Failed to extract pull path for file (%s). ret: (%d)\n",
                           dumpfile->d_name, ret);
                continue;
            }

            ret = stat(dumpfile_full_path, &fst);
            if ((ret == 0) && !(fst.st_mode & (S_IRUSR | S_IRGRP | S_IROTH))) {
                /* file is not readable, skip it (the 'dbg_cmd' proc file that is write-only) */
                continue;
            }

            /* Open driver dump file for reading */
            driver_tmp_file = cl_fopen(dumpfile_full_path, "r");
            if (driver_tmp_file == NULL) {
                SX_LOG_ERR("driver_dbg_generate_dump failed to open file (%s). return code: (%s)\n",
                           dumpfile_full_path, strerror(errno));
                continue;
            }

            write_error = 0;

            /* Copy driver dump file content into stream */
            /* Read from driver dump file */
            while ((bytes_read = fread(buffer, c_size, sizeof(buffer), driver_tmp_file)) > 0
                   && !ferror(driver_tmp_file) && !write_error) {
                /* Write the buffer to sdk dump file (stream) */
                total_bytes_written = 0;
                while (total_bytes_written < bytes_read) {
                    bytes_written = fwrite((buffer + (total_bytes_written * c_size)),
                                           c_size, (bytes_read - total_bytes_written),
                                           stream);
                    total_bytes_written += bytes_written;
                    if ((total_bytes_written < bytes_read) && ferror(stream)) {
                        write_error = 1;
                        SX_LOG_ERR("driver_dbg_generate_dump failed to write to debug "
                                   "dump file. return code: (%s)\n", strerror(errno));
                        break;
                    }
                }
            }
            if (ferror(driver_tmp_file)) {
                SX_LOG_ERR("driver_dbg_generate_dump failed to read driver debug "
                           "dump file (%s). return code: (%s)\n",
                           dumpfile_full_path, strerror(errno));
            }
            /* Close driver dump file */
            if (cl_fclose(driver_tmp_file)) {
                SX_LOG_ERR("driver_dbg_generate_dump failed to close file (%s). return code: (%s)\n",
                           dumpfile_full_path, strerror(errno));
            }
        }
    }

out:
    if (driver_dump_dir != NULL) {
        closedir(driver_dump_dir);
    }
    return rc;
}


static sxd_dev_id_t __sxd_dbg_utils_get_predefined_dev(void)
{
    struct ku_dev_info dev_info;
    sxd_dev_id_t       dev_id = 0;
    sxd_status_t       sxd_st = SXD_STATUS_SUCCESS;

    memset(&dev_info, 0, sizeof(dev_info));
    sxd_st = sxd_get_device_info(&dev_info);
    if (sxd_st != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get device information (err=%d)\n", sxd_st);
        goto out;
    }

    dev_id = dev_info.dev_id;

out:
    return dev_id;
}


sxd_status_t sxd_fw_dbg_dump_completion_state(u_int8_t dev_id, boolean_t query, fw_dump_completion_state_t* state)
{
    return sx_cr_dump_notify_dump_complete(dev_id, query, state);
}
