/*
 * Copyright (C) 2001-2022 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#ifndef SXD_FW_DBG_INT_H_
#define SXD_FW_DBG_INT_H_

#include <sx/sxd/sxd_status.h>
#include "sx/sxd/sxdev.h"
#include "sx/sxd/cr_access.h"
#include <sx/sxd/kernel_user.h>
#include "sx/sxd/sxd_fw_dbg.h"
#include <complib/sx_log.h>
/************************************************
 *  Defines
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/


/************************************************
 *  Type definitions
 ***********************************************/

#define SXD_FOREACH_INSTRUCTION_TYPE(INST)             \
    INST(SXD_FW_INSTRUCTION_TYPE_UNKNOWN, , "unknown") \
    INST(SXD_FW_INSTRUCTION_TYPE_READ, , "read")       \
    INST(SXD_FW_INSTRUCTION_TYPE_WRITE, , "write")     \
    INST(SXD_FW_INSTRUCTION_TYPE_HOLD, , "hold")       \
    INST(SXD_FW_INSTRUCTION_TYPE_SLEEP, , "sleep")     \
    INST(SXD_FW_INSTRUCTION_TYPE_PRINT, , "print")     \
    INST(SXD_FW_INSTRUCTION_TYPE_READ_MAX, , "max")


typedef enum sxd_fw_instruction_type {
    SXD_FOREACH_INSTRUCTION_TYPE(SXD_GENERATE_ENUM)
} sxd_fw_instruction_type_t;

#define SXD_FOREACH_INSTRUCTION_SEGMENT_TYPE(SEG_TYPE)       \
    SEG_TYPE(SXD_FW_INSTRUCTION_SEGMENT_TYPE_MAIN, , "main") \
    SEG_TYPE(SXD_FW_INSTRUCTION_SEGMENT_TYPE_TILES, , "tiles")

typedef enum sxd_fw_instruction_segment_type {
    SXD_FOREACH_INSTRUCTION_SEGMENT_TYPE(SXD_GENERATE_ENUM)
} sxd_fw_instruction_segment_type_t;

/* this structure describes an "instruction" as it appears in the FW "dbg DB"*/
typedef struct sxd_fw_dbg_instruction {
    sxd_fw_instruction_type_t type;
    int64_t                   address;            /* the address of which we want to read / write */
    int64_t                   num_of_dwords;            /* how many dwords we want to read / write */
    /* the data per instruction type:
     *                               - read: expected value
     *                               - write: value to write
     *                               - sleep:time in usec
     *                               - hold: variable name
     *                               - print:print (in ASCII) */
    int64_t data; /* 8 Bytes as we read from the FW instruction*/
} sxd_fw_dbg_instruction_t;

/************************************************
 *  Type definitions
 ***********************************************/

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

#endif /* SXD_FW_DBG_INT_H_ */
