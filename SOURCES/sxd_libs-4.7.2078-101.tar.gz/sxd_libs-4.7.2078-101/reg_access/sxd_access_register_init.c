/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <errno.h>
#include <complib/cl_mem.h>
#include <complib/cl_process_id.h>
#include <sx/sxd/sxd_emad.h>
#include <sx/sxd/sxd_emad_parser.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_access_register_init.h>
#include <sx/sxd/kernel_user.h>
#include "dpt.h"
#include "../common/sxd_utils.h"
#include <sx/sxd/sxd_fw_trace.h>
#include <sx/utils/debug_cmd.h>
#include <sx/utils/dbg_utils.h>

#include "sxd_access_reg_common.h"
#include "sxd_access_reg_infra.h"

#ifdef IB_PRESENT_FLAG
#include <infiniband/mad.h>
#include "access_register_mad.h"
#include <dlfcn.h>
#endif

/************************************************
 *  Local variables
 ***********************************************/
#undef  __MODULE__
#define __MODULE__ ACCESS_REG_INIT
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

#ifdef IB_PRESENT_FLAG
static void* lib_handle[2] = {NULL};
#endif

/************************************************
 *  Global variables
 ***********************************************/

extern sxd_dpt_t           *dpt_ptr;
extern sxd_access_reg_hw_t *hw_p;

/************************************************
 *  Local function declarations
 ***********************************************/
static void __access_reg_debug_cmd_register(void);
static void __debug_cmd_sxd_reg_verbosity_lvl_set(FILE *stream, int argc, const char *argv[], void *handler_context);
/************************************************
 *  Global function declarations
 ***********************************************/
void sxd_reg_mrrr_init(void);
void sxd_reg_sbhrr_init(void);
void sxd_reg_sbhbr_init(void);
void sxd_reg_sbdcc_init(void);
void sxd_reg_sbdcm_init(void);
void sxd_reg_sbctc_init(void);
void sxd_reg_ppbmi_init(void);
void sxd_reg_pcnr_init(void);
void sxd_reg_ptce3_init(void);
void sxd_reg_perpt_init(void);
void sxd_reg_percr_init(void);
void sxd_reg_peabfe_init(void);
void sxd_reg_pererp_init(void);

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_access_reg_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        err = sxd_emad_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, SXD LIBS, return message: [%s]\n", SXD_STATUS_MSG(err));
        }

        err = sxd_emad_parser_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, SXD EMAD PARSER, return message: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_dpt_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, SXD_DPT, return message: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = dpt_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, DPT, return message: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_command_ifc_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, COMMAND IFC, return message: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_fw_dbg_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, SXD_FW_DBG, return message: [%s]\n", SXD_STATUS_MSG(err));
        }
        err = sxd_fw_trace_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, SXD_FW_TRACE, return message: [%s]\n", SXD_STATUS_MSG(err));
        }
#ifdef IB_PRESENT_FLAG
        err = dpt_mad_log_verbosity_level(SXD_ACCESS_CMD_SET, verbosity_level_p);
        if (SXD_CHECK_FAIL(err)) {
            SX_LOG_ERR("Failed to set log level, DPT MAD, return message: [%s]\n", SXD_STATUS_MSG(err));
        }
#endif
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    SX_LOG_EXIT();
    return err;
}

static boolean_t __get_proc_boolean_param(const char *proc_path)
{
    int       fd, rc;
    char      byte;
    boolean_t param = FALSE;

    fd = open(proc_path, O_RDONLY);
    if (fd < 0) {
        SX_LOG_NTC("Failed to open '%s' sysfs (err=%d)\n", proc_path, errno);
        goto out;
    }

    rc = read(fd, &byte, 1);
    if (rc != 1) {
        SX_LOG_NTC("Failed to read '%s' sysfs (err=%d)\n", proc_path, errno);
        goto out_close;
    }

    param = (byte == '1');

out_close:
    close(fd);

out:
    return param;
}

boolean_t sxd_cr_mode(void)
{
    static boolean_t cr_mode_s = FALSE;
    static boolean_t cr_mode_init_s = FALSE;

    if (!cr_mode_init_s) {
        cr_mode_s = __get_proc_boolean_param("/sys/module/sx_core/parameters/i2c_mode") ||
                    __get_proc_boolean_param("/sys/module/sx_core/parameters/mst_mode");
        cr_mode_init_s = TRUE;
    }

    return cr_mode_s;
}

void sxd_access_register_infra_init(void)
{
    sxd_register_infra_init();
}

void sxd_access_register_infra_deinit(void)
{
    sxd_register_infra_deinit();
}

/* use this function only when the calling process is a fork() of a parent process */
sxd_status_t sxd_access_reg_init_after_fork(uint32_t             app_id,
                                            sx_log_cb_t          logging_cb,
                                            sx_verbosity_level_t verbosity_level)
{
    hw_p = NULL;
    return sxd_access_reg_init(app_id, logging_cb, verbosity_level);
}

/*
 * THIS FUNCTION IS USED BY MST/MFT TOOLS! DON'T CHANGE BINARY COMPATIBILITY
 * OF THIS FUNCTION BEFORE COORDINATING IT WITH THEM!
 */
sxd_status_t sxd_access_reg_init(uint32_t app_id, sx_log_cb_t logging_cb, sx_verbosity_level_t verbosity_level)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;
    int          pid = -1;

    if (hw_p != NULL) {
        /* ACCESS REG was already initialized */
        return status;
    }

    sx_log_init(TRUE, NULL, logging_cb);

    status = sxd_access_reg_log_verbosity_level(
        SXD_ACCESS_CMD_SET,
        &verbosity_level);

    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    SX_LOG_ENTER();

#ifdef IB_PRESENT_FLAG
#define DLOPEN_LIBS_FLAGS (RTLD_NOW | RTLD_GLOBAL)
    lib_handle[0] = dlopen("libibmad.so", DLOPEN_LIBS_FLAGS);
    if (!lib_handle[0]) {
        SX_LOG_ERR("Failed opening libibmad: %s\n", dlerror());
        return SXD_STATUS_ERROR;
    }
    lib_handle[1] = dlopen("libibumad.so", DLOPEN_LIBS_FLAGS);
    if (!lib_handle[1]) {
        SX_LOG_ERR("Failed opening libibumad: %s\n", dlerror());
        return SXD_STATUS_ERROR;
    }
#endif

    hw_p = (sxd_access_reg_hw_t*)cl_calloc(1, sizeof(sxd_access_reg_hw_t));
    if (NULL == hw_p) {
        SX_LOG_ERR("Failed to allocate memory\n");
        status = SXD_STATUS_NO_MEMORY;
        goto out_close;
    }

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed loading the DPT\n");
            goto out_free;
        }
    }

    status = sxd_command_ifc_init(logging_cb, verbosity_level, &(hw_p->cmd_ifc_hw_p));
    if (status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed initializing command ifc lib\n");
        goto out_dpt;
    }

    cl_get_process_id(&pid);
    app_id = pid;
    status = sxd_emad_init(app_id);
    if (status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("failed initializing the emad lib\n");
        goto out_err;
    }

    M_SXD_UTILS_MUTEX_INIT(&(hw_p->mtx));

    /* Initialize all registers */
    sxd_access_register_infra_init();

    __access_reg_debug_cmd_register();

    SX_LOG_NTC("ACCESS REG:   ACCESS REG INIT DONE\n");
    SX_LOG_EXIT();
    return status;

out_err:
    sxd_command_ifc_deinit(hw_p->cmd_ifc_hw_p);
out_dpt:
    dpt_unload();
out_free:
    cl_free(hw_p);
    hw_p = NULL;
out_close:
#ifdef IB_PRESENT_FLAG
    dlclose(lib_handle[0]);
    dlclose(lib_handle[1]);
    lib_handle[0] = NULL;
    lib_handle[1] = NULL;
#endif
    SX_LOG_NTC("ACCESS REG:   ACCESS REG INIT FAILED\n");
    SX_LOG_EXIT();
    return status;
}

sxd_status_t sxd_access_reg_init_strict(uint32_t app_id, sx_log_cb_t logging_cb, sx_verbosity_level_t verbosity_level)
{
    if (hw_p) {
        return SXD_STATUS_ALREADY_INITIALIZED;
    }

    return sxd_access_reg_init(app_id, logging_cb, verbosity_level);
}


/*
 * THIS FUNCTION IS USED BY MST/MFT TOOLS! DON'T CHANGE BINARY COMPATIBILITY
 * OF THIS FUNCTION BEFORE COORDINATING IT WITH THEM!
 */
sxd_status_t sxd_access_reg_deinit()
{
    sxd_status_t status = SXD_STATUS_SUCCESS;
    sxd_dev_id_t dev_id;
    uint8_t      ref_count = 0;

    SX_LOG_ENTER();

    if (NULL == hw_p) {
        return status;
    }

    status = sxd_dpt_get_ref_count(&ref_count);
    if (status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("sxd_dpt_get_ref_count()  failed\n");
        return status;
    }

    status = sxd_command_ifc_deinit(hw_p->cmd_ifc_hw_p);
    if (status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Command IFC deinit failed\n");
    }

    status = sxd_emad_deinit();
    if (status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Emad deinit failed\n");
    }

#ifdef IB_PRESENT_FLAG
    if (dpt_ptr->system_type != SYS_TYPE_EN) {
        if (hw_p->sport) {
            mad_rpc_close_port(hw_p->sport);
            hw_p->sport = NULL;
        }
    }
    dlclose(lib_handle[0]);
    dlclose(lib_handle[1]);
    lib_handle[0] = NULL;
    lib_handle[1] = NULL;
#endif

    if (ref_count <= 1) {
        for (dev_id = 0; dev_id < SXD_DEV_ID_MAX; dev_id++) {
            status = sxd_dpt_set_access_control(dev_id, READ_WRITE);
            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("sxd_dpt_set_access_control failed\n");
            }
        }
    }

    dpt_unload();
    cl_free(hw_p);

    sxd_access_register_infra_deinit();

    hw_p = NULL;
    SX_LOG_NTC("ACCESS REG:   ACCESS REG DEINIT DONE\n");
    SX_LOG_EXIT();
    sx_log_close();
    return status;
}

/*
 * THIS FUNCTION IS USED BY MST/MFT TOOLS! DON'T CHANGE BINARY COMPATIBILITY
 * OF THIS FUNCTION BEFORE COORDINATING IT WITH THEM!
 */
sxd_status_t sxd_access_reg_max_size(sxd_dev_id_t dev_id, uint32_t *max_reg_size_in_dwords)
{
    dpt_encapsulation_t    encapsulation = CMD_IFC_PATH;
    sxd_status_t           status = SXD_STATUS_SUCCESS;
    swid_type_t            swid_type = SWID_TYPE_UNKNOWN;
    internal_path_params_t params;

    if (hw_p == NULL) {
        SX_LOG_ERR("reg_max_size: Handle is NULL\n");
        status = SXD_STATUS_NOT_INITIALIZED;
        goto out;
    }

    status = dpt_get_swid_type(0, &swid_type);
    if (status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get swid type from the DPT\n");
        goto out;
    }

    switch (swid_type) {
    case SWID_TYPE_EN:
        status = dpt_get_encapsulation(dev_id, 0, FIRST_GROUP, &encapsulation, &params, TRUE);
        break;

    case SWID_TYPE_IB:
        status = dpt_get_encapsulation(dev_id, 0, SECOND_GROUP, &encapsulation, &params, FALSE);
        break;

    default:
        break;
    }

    if (status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed to get the encapsulation from the DPT\n");
        goto out;
    }

    switch (encapsulation) {
    case EMAD_PATH:
        /* REG_TLV->len (length in dwords) is a 11-bit value, which means maximum of 2047 dwords */
        *max_reg_size_in_dwords = 2047;
        break;

    case CMD_IFC_PATH:
        /* command interface is sent over a 4K mailbox (1024 dwords). However, along with the
         * register itself we also push the operation_TLV (4 dwords) and REG_TLV (1 dword).
         * so the register maximum size is 1019 dwords.
         */
        *max_reg_size_in_dwords = 1019;
        break;

#ifdef IB_PRESENT_FLAG
    case MAD_PATH:
        *max_reg_size_in_dwords = (MAX_REG_SIZE_IN_MAD) / 4;
        break;

#endif
    default:
        SX_LOG_ERR("Invalid encapsulation: %d\n", encapsulation);
        status = SXD_STATUS_ERROR;
        goto out;
    }

out:
    return status;
}

sxd_status_t sxd_transaction_mode_set(boolean_t enable)
{
    return sxd_emad_transaction_mode_set(enable);
}

sxd_status_t sxd_transaction_mode_get(boolean_t *enable)
{
    return sxd_emad_transaction_mode_get(enable);
}

sxd_status_t sxd_access_reg_swid_to_rdq(sxd_swid_t swid, uint8_t             *rdq_p)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    return sxd_command_ifc_swid_to_rdq(hw_p->cmd_ifc_hw_p, swid, rdq_p);
}


static sxd_status_t __sxd_access_reg_pci_device_restart(sxd_dev_id_t dev_id, boolean_t force)
{
    if (hw_p == NULL) {
        SX_LOG_ERR("Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (!force && !DEFAULT_DEVICE_ID_CHECK(dev_id)) {
        if ((dpt_ptr->device_access_control[dev_id] == READ_ONLY) ||
            (dpt_ptr->device_access_control[dev_id] == NO_ACCESS)) {
            return SXD_STATUS_SUCCESS;
        }
    }

    return sxd_command_ifc_pci_device_restart(hw_p->cmd_ifc_hw_p, dev_id);
}


sxd_status_t sxd_access_reg_pci_device_restart(sxd_dev_id_t dev_id)
{
    return __sxd_access_reg_pci_device_restart(dev_id, FALSE);
}


sxd_status_t sxd_access_reg_pci_device_restart_force(sxd_dev_id_t dev_id)
{
    return __sxd_access_reg_pci_device_restart(dev_id, TRUE);
}
static void __debug_cmd_sxd_reg_verbosity_lvl_set(FILE *stream, int argc, const char *argv[], void *handler_context)
{
    sxd_status_t         err = SXD_STATUS_SUCCESS;
    sxd_access_cmd_t     cmd = SXD_ACCESS_CMD_SET;
    sx_verbosity_level_t verbosity_level = SX_VERBOSITY_LEVEL_NONE;

    UNUSED_PARAM(handler_context);

    if (argc != 1) {
        dbg_utils_print(stream,
                        "sxd_reg_verbosity_lvl_set: wrong number of params. Run command with parameters: <verbosity_level>\n");
        err = SXD_STATUS_PARAM_ERROR;
        return;
    }

    verbosity_level = atoi(argv[0]);

    if (!SX_VERBOSITY_LEVEL_CHECK_RANGE(verbosity_level)) {
        dbg_utils_print(stream, "sxd_reg_verbosity_lvl_set: verbosity level [%d] is out of range\n", verbosity_level);
        return;
    }

    err = sxd_access_reg_log_verbosity_level(cmd, &verbosity_level);
    if (SXD_CHECK_FAIL(err)) {
        SX_LOG_ERR("Failed to set log level, SXD LIBS, return message: [%s]\n", SXD_STATUS_MSG(err));
        dbg_utils_print(stream,
                        "sxd_reg_verbosity_lvl_set: Failed to set verbosity level [%d], error [%s]\n",
                        verbosity_level,
                        SXD_STATUS_MSG(err));
    }
    return;
}

static void __access_reg_debug_cmd_register(void)
{
    sx_utils_debug_cmd_register_path("sxd_reg_verbosity_lvl_set", __debug_cmd_sxd_reg_verbosity_lvl_set, NULL);
}
