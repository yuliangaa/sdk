/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __DPT_H__
#define __DPT_H__

#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/sxd_port.h>

/************************************************
 *  Local Defines
 ***********************************************/

#define MAX_SWITCHX_PORTS        (MAX_PHYPORT_NUM + 1)
#define MAX_SWITCHX_SLOTS        16
#define MAX_SWITCHX_SYSTEM_PORTS ((1 << 16) - 1)
#define MAX_SWITCHX_MODULES      130
#define MAX_LANES_PER_MODULE     8
#define MAX_SPAN_SESSION_IDS     8
#define PATH                     "/dpt"
#define DPT_INIT_VAL             0xde

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

typedef enum swid_type {
    SWID_TYPE_UNKNOWN,
    SWID_TYPE_IB,
    SWID_TYPE_EN,
    SWID_TYPE_MIN = SWID_TYPE_UNKNOWN,
    SWID_TYPE_MAX = SWID_TYPE_EN,
} swid_type_t;

typedef struct internal_dr_path_params {
    uint16_t path_len;
    uint16_t path_ports[MAX_DR_PATH_LEN];
    uint16_t path_device_id[MAX_DR_PATH_LEN];
} internal_dr_path_params_t;

typedef struct internal_ib_dr_path_params {
#ifdef IB_PRESENT_FLAG
    ib_dr_path_t drpath;
#endif
    internal_dr_path_params_t local_ports_dr;
    int                       is_valid;
} internal_ib_dr_path_params_t;

typedef struct sxd_dpt_dev_swid_path_info {
    internal_ib_dr_path_params_t dr_params;
    sys_port_path_params_t       sys_port_params;
    oob_path_params_t            oob_params;
    dpt_encapsulation_t          first_set_path;    /* cmd + emad */
    dpt_encapsulation_t          second_set_path;    /* cmd + mad */
    dpt_encapsulation_t          third_set_path;    /* emad only */
} sxd_dpt_dev_swid_path_info_t;

typedef struct sxd_dpt_local_port_info {
    uint8_t           dev_id;
    sxd_port_phy_id_t local_port;
} sxd_dpt_local_port_info_t;

typedef struct sxd_dpt {
    uint16_t                     dpt_initialized;
    sys_type_t                   system_type;
    cl_plock_t                   p_lock;
    swid_type_t                  swid_type[SXD_SWID_ID_COUNT];
    sxd_dpt_dev_swid_path_info_t table[SXD_DEV_ID_MAX + 1][SXD_SWID_ID_COUNT];
    uint8_t                      ports_map[SXD_DEV_ID_MAX + 1][MAX_SWITCHX_PORTS];
    uint8_t                      modules_map[SXD_DEV_ID_MAX + 1][MAX_SWITCHX_PORTS];
    uint16_t                     local_to_system[SXD_DEV_ID_MAX + 1][MAX_SWITCHX_PORTS];
    sxd_dpt_local_port_info_t    system_to_local[MAX_SWITCHX_SYSTEM_PORTS];
    uint16_t                     module_to_ports_map[SXD_DEV_ID_MAX +
                                                     1][MAX_SWITCHX_SLOTS][MAX_SWITCHX_MODULES][MAX_LANES_PER_MODULE];
    uint16_t modules_to_port_map_count[SXD_DEV_ID_MAX +
                                       1][MAX_SWITCHX_SLOTS][MAX_SWITCHX_MODULES];
    uint8_t                              port_to_module_map[SXD_DEV_ID_MAX + 1][MAX_SWITCHX_PORTS];
    uint8_t                              port_to_slot_map[SXD_DEV_ID_MAX + 1][MAX_SWITCHX_PORTS];
    uint8_t                              lanes_num_per_module_max;
    dpt_access_control_t                 device_access_control[SXD_DEV_ID_MAX + 1];
    uint32_t                             host_ifc_vtrap2trap_map[SXD_TRAPS_NUM + 1];
    uint32_t                             host_ifc_hwtrap2vtrap_map[SXD_TRAPS_NUM + 1];
    uint8_t                              ref_count;
    sxd_chip_types_t                     chip_type[SXD_DEV_ID_MAX + 1];
    uint64_t __attribute__((aligned(8))) system_m_key[SXD_DEV_ID_MAX + 1];
    boolean_t                            string_tlv_cap[SXD_DEV_ID_MAX + 1];
    boolean_t                            latency_tlv_cap[SXD_DEV_ID_MAX + 1];
    uint16_t                             port_to_mirror_label_port_map[SXD_DEV_ID_MAX + 1][MAX_SWITCHX_PORTS];
    uint8_t                              span_session_id_valid[MAX_SPAN_SESSION_IDS];
    uint8_t                              span_session_id_sdk_to_hw[MAX_SPAN_SESSION_IDS];
    boolean_t                            fw_dump_in_progress;
    boolean_t                            issu_in_progress;
} sxd_dpt_t;

typedef union internal_dpt_path_params {
    internal_ib_dr_path_params_t dr_params;
    uint16_t                     sys_port;
} internal_dpt_path_params_t;

typedef union internal_path_params {
    internal_ib_dr_path_params_t dr_params;
    uint16_t                     sys_port;
} internal_path_params_t;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

/**
 * This function sets the log verbosity level of the DPT MODULE
 * @param[in] cmd               - SET / GET
 * @param[in] verbosity_level_p - verbosity level
 *
 * @return SX_STATUS_SUCCESS operation completes successfully
 *          SX_STATUS_ERROR   general error
 */
sxd_status_t dpt_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                     IN sx_verbosity_level_t *verbosity_level_p);

sxd_status_t dpt_load(void);

sxd_status_t dpt_unload(void);

#ifdef IB_PRESENT_FLAG
sxd_status_t dpt_translate_local_to_ib_path(sxd_dev_id_t      dev_id,
                                            sxd_swid_t        swid,
                                            dr_path_params_t *local_ports_dr);
#endif

sxd_status_t dpt_get_encapsulation(sxd_dev_id_t            dev_id,
                                   sxd_swid_t              swid,
                                   sxd_dpt_group_t         group,
                                   dpt_encapsulation_t    *encapsulation,
                                   internal_path_params_t *params,
                                   boolean_t               check_path);

sxd_status_t dpt_get_swid_type(sxd_swid_t   swid,
                               swid_type_t *type);

sxd_status_t dpt_set_system_m_key(sxd_dev_id_t dev_id, uint64_t *system_m_key);
sxd_status_t dpt_get_system_m_key(sxd_dev_id_t dev_id, uint64_t *system_m_key);

#endif /* __DPT_H__ */
