/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/cl_byteswap_osd.h>
#include <complib/cl_mem.h>
#include <sx/sxd/sxd_emad_common_data.h>
#include <sx/sxd/sxd_emad_port_reg.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_dpt.h>

#include <common/sxd_utils.h>

#ifdef IB_PRESENT_FLAG
#include <infiniband/mad.h>
#include "access_register_mad.h"
#endif /* IB_PRESENT_FLAG */

#include <emad/emad.h>

#include "dpt.h"
#include "sxd_access_reg_infra.h"
#include "sxd_access_reg_common.h"
#include "sxd_sniffer/sniffer/sxd_sniffer.h"

#undef  __MODULE__
#define __MODULE__ ACCESS_REG_INFRA

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  MACROS
 ***********************************************/

#define IFC_VALID  (1 << 0)
#define MAD_VALID  (1 << 1)
#define EMAD_VALID (1 << 2)

#define VALID_REG_ID(reg_id) ((((int)(reg_id)) >= 0) && (((int)(reg_id)) < SXD_MAX_REGISTERS))

#define IS_ACCESS_CMD_WRITE(cmd)      \
    (((cmd) == SXD_ACCESS_CMD_SET) || \
     ((cmd) == SXD_ACCESS_CMD_ADD) || \
     ((cmd) == SXD_ACCESS_CMD_DELETE))
#define IS_ACCESS_CMD_READ(cmd) ((cmd) == SXD_ACCESS_CMD_GET)

/************************************************
 *  Global variables
 ***********************************************/

extern sxd_access_reg_hw_t *hw_p;
extern sxd_dpt_t           *dpt_ptr;

/************************************************
 *  Local variables
 ***********************************************/
struct register_entry {
    boolean_t                     valid;
    struct sxd_register_info      reg_info;
    uint8_t                       valid_access_methods;
    struct access_reg_ifc_params  ifc_params;
    struct access_reg_mad_params  mad_params;
    struct access_reg_emad_params emad_params;
};
static struct register_entry            __registers_info[SXD_MAX_REGISTERS];
static struct sxd_register_sniffer_info __registers_sniffer_info[CTRL_CMD_ACCESS_REG_MAX - CTRL_CMD_ACCESS_REG_MIN +
                                                                 1];
static uint32_t      g_infra_init_ref_cnt = 0;
static cl_spinlock_t reg_infra_db_lock = CL_SPINLOCK_INITIALIZER;

#define SXD_REG_ATTR_F_DEFAUT_DEV_ACCESS (1 << 0) /* register can be user with default device (254/255) */
#define SXD_REG_ATTR_F_IGNORE_READ_ONLY  (1 << 1) /* register ignores read-only permission for a device */

/* each register has its own bitmask of attributes */
static uint8_t g_static_reg_attributes[SXD_MAX_REGISTERS] = {
    [SXD_REG_ID_MGIR_E] = SXD_REG_ATTR_F_DEFAUT_DEV_ACCESS,
    [SXD_REG_ID_MFBA_E] = SXD_REG_ATTR_F_DEFAUT_DEV_ACCESS,
    [SXD_REG_ID_MFBE_E] = SXD_REG_ATTR_F_DEFAUT_DEV_ACCESS,
    [SXD_REG_ID_MFPA_E] = SXD_REG_ATTR_F_DEFAUT_DEV_ACCESS,
    [SXD_REG_ID_MTMP_E] = SXD_REG_ATTR_F_DEFAUT_DEV_ACCESS, /* used on director systems */
    [SXD_REG_ID_HTGT_E] = SXD_REG_ATTR_F_IGNORE_READ_ONLY, /* director systems access HTGT on both management boards */
    [SXD_REG_ID_HPKT_E] = SXD_REG_ATTR_F_IGNORE_READ_ONLY, /* director systems access HPKT on both management boards */
};

/************************************************
 *  Local function declarations
 ***********************************************/
extern void build_emad_common(const sxd_reg_meta_t   *meta,
                              uint16_t                sys_port,
                              sxd_emad_common_data_t *common);
extern sxd_status_t sxd_command_ifc_access_reg(sxd_command_ifc_hw_t               *hw_p,
                                               sxd_access_cmd_t                    access_cmd,
                                               sxd_dev_id_t                        dev_id,
                                               sxd_reg_id_e                        reg_id,
                                               void                               *ku_reg_buff,
                                               uint32_t                            ku_reg_size,
                                               const struct access_reg_ifc_params* ifc_params);

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t emad_access_reg_infra_log_verbosity_level_set(const sx_verbosity_level_t verbosity_level)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    return status;
}

sxd_status_t emad_access_reg_infra_log_verbosity_level_get(sx_verbosity_level_t *verbosity_level)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    *verbosity_level = LOG_VAR_NAME(__MODULE__);

    return status;
}


void sxd_register_infra_init(void)
{
    cl_spinlock_acquire(&reg_infra_db_lock);
    g_infra_init_ref_cnt++;
    if (g_infra_init_ref_cnt == 1) {
        sxd_reg_auto_init();   /* Init auto generated registers */
        sxd_reg_htac_init();   /* HTAC */
        sxd_reg_mpibe_init();  /* MPIBE */
        sxd_reg_mrrr_init();   /* MRRR */
        sxd_reg_ppbmi_init();  /* PPBMI */
        sxd_reg_ppaos_init();  /* PPAOS */
        sxd_reg_sbctc_init();  /* SBCTC */
        sxd_reg_sbdcc_init();  /* SBDCC */
        sxd_reg_sbdcm_init();  /* SBDCM */
        sxd_reg_sbhbr_init();  /* SBHBR */
        sxd_reg_sbhrr_init();  /* SBHRR */
        sxd_reg_pvlc_init();   /* PVLC */
        sxd_reg_mfsm_init();   /* MFSM */
        sxd_reg_mcia_init();   /* MCIA */
        sxd_reg_hopf_init();   /* HOPF */
        sxd_reg_pcnr_init();   /* PCNR */
        sxd_reg_ppbmc_init();  /* PPBMC */
        sxd_reg_ppbmp_init();  /* PPBMP */
        sxd_reg_qhll_init();   /* QHLL */
        sxd_reg_mtpptr_init(); /* MTPPTR */
        sxd_reg_qpsc_init();   /* QPSC */
        sxd_reg_mtpppc_init(); /* MTPPPC */
        sxd_reg_ptce3_init();  /* PTCE_V3 */
        sxd_reg_percr_init();  /* PERCR */
        sxd_reg_perpt_init();  /* PERPT */
        sxd_reg_peabfe_init(); /* PEABFE */
        sxd_reg_pererp_init();  /* PERERP */
        sxd_reg_slcr_v2_init(); /* SLCR_V2 */
        sxd_reg_mfm_init();    /* MFM */
        sxd_reg_mhsr_init();   /* MHSR */
        sxd_reg_mfsc_init();   /* MFSC */
        sxd_reg_ibsni_init();  /* IBSNI */
        sxd_reg_nv_switch_conf_init();  /* NV_SWITCH_CONF */
    }
    cl_spinlock_release(&reg_infra_db_lock);
}

void sxd_register_infra_deinit(void)
{
    cl_spinlock_acquire(&reg_infra_db_lock);
    g_infra_init_ref_cnt--;
    if (g_infra_init_ref_cnt == 0) {
        memset(__registers_info, 0, sizeof(__registers_info));
        memset(__registers_sniffer_info, 0, sizeof(__registers_sniffer_info));
    }
    cl_spinlock_release(&reg_infra_db_lock);
}


sxd_status_t sxd_register_init(sxd_reg_id_e                            reg_id,
                               const struct sxd_register_info        * reg_info,
                               const struct sxd_register_sniffer_info* sniffer_info,
                               const struct access_reg_ifc_params    * ifc_params,
                               struct access_reg_mad_params          * mad_params,
                               const struct access_reg_emad_params   * emad_params)
{
    struct register_entry           * entry;
    struct sxd_register_sniffer_info* sniffer_entry;

    if (!VALID_REG_ID(reg_id)) {
        SX_LOG_ERR("Fail to init: invalid reg-id: 0x%x\n", reg_id);
        return SXD_STATUS_ERROR;
    }

    if (__registers_info[reg_id].valid) {
        SX_LOG_ERR("Fail to init: reg_id 0x%x already exists\n", reg_id);
        return SXD_STATUS_ERROR; /* already exists! */
    }

    if (reg_info == NULL) {
        SX_LOG_ERR("Fail to init: reg_info is NULL\n");
        return SXD_STATUS_PARAM_ERROR; /* reg_info is a must! */
    }

    if (sniffer_info) {
        if ((sniffer_info->ctrl_cmd < CTRL_CMD_ACCESS_REG_MIN) || (sniffer_info->ctrl_cmd > CTRL_CMD_ACCESS_REG_MAX)) {
            SX_LOG_ERR("Fail to init: sniffer_info's ctrl_cmd is invalid\n");
            return SXD_STATUS_PARAM_ERROR;
        }

        sniffer_entry = &__registers_sniffer_info[sniffer_info->ctrl_cmd - CTRL_CMD_ACCESS_REG_MIN];
        memcpy(sniffer_entry, sniffer_info, sizeof(*sniffer_entry));
        sniffer_entry->valid = TRUE;
    }

    entry = &__registers_info[reg_id];
    memset(entry, 0, sizeof(*entry));

    memcpy(&entry->reg_info, reg_info, sizeof(entry->reg_info));

    if (ifc_params) {
        entry->valid_access_methods |= IFC_VALID;
        memcpy(&entry->ifc_params, ifc_params, sizeof(entry->ifc_params));
    }

    if (mad_params) {
        entry->valid_access_methods |= MAD_VALID;
        memcpy(&entry->mad_params, mad_params, sizeof(entry->mad_params));
    }

    if (emad_params) {
        entry->valid_access_methods |= EMAD_VALID;
        memcpy(&entry->emad_params, emad_params, sizeof(entry->emad_params));
    }

    entry->valid = TRUE;
    return SXD_STATUS_SUCCESS;
}


const char* REG_ID_TO_NAME(sxd_reg_id_e reg_id)
{
    if (VALID_REG_ID(reg_id) && __registers_info[reg_id].valid) {
        return __registers_info[reg_id].reg_info.name;
    }

    return "<unknown>";
}


struct sxd_register_info* sxd_register_get_info(sxd_reg_id_e reg_id)
{
    if (VALID_REG_ID(reg_id) && __registers_info[reg_id].valid) {
        return &__registers_info[reg_id].reg_info;
    }

    return NULL;
}


const struct sxd_register_sniffer_info* sxd_register_get_sniffer_info(enum ku_ctrl_cmd_access_reg ctrl_cmd)
{
    if ((ctrl_cmd >= CTRL_CMD_ACCESS_REG_MIN) &&
        (ctrl_cmd <= CTRL_CMD_ACCESS_REG_MAX) &&
        __registers_sniffer_info[ctrl_cmd - CTRL_CMD_ACCESS_REG_MIN].valid) {
        return &__registers_sniffer_info[ctrl_cmd - CTRL_CMD_ACCESS_REG_MIN];
    }

    return NULL;
}


static const struct access_reg_ifc_params* sxd_register_get_ifc_params(sxd_reg_id_e reg_id)
{
    if (VALID_REG_ID(reg_id) && __registers_info[reg_id].valid) {
        if (__registers_info[reg_id].valid_access_methods & IFC_VALID) {
            return &__registers_info[reg_id].ifc_params;
        }
    }

    return NULL;
}


struct access_reg_mad_params* sxd_register_get_mad_params(sxd_reg_id_e reg_id)
{
    if (VALID_REG_ID(reg_id) && __registers_info[reg_id].valid) {
        if (__registers_info[reg_id].valid_access_methods & MAD_VALID) {
            return &__registers_info[reg_id].mad_params;
        }
    }

    return NULL;
}


const struct access_reg_emad_params* sxd_register_get_emad_params(sxd_reg_id_e reg_id)
{
    if (VALID_REG_ID(reg_id) && __registers_info[reg_id].valid) {
        if (__registers_info[reg_id].valid_access_methods & EMAD_VALID) {
            return &__registers_info[reg_id].emad_params;
        }
    }

    return NULL;
}


sxd_status_t sxd_register_deparse(sxd_reg_id_e                      reg_id,
                                  struct sxd_emad_general_reg_data* reg_data,
                                  const void                      * reg_buff,
                                  sxd_sniffer_print_data_cb_t       print_data)
{
    if (VALID_REG_ID(reg_id) && __registers_info[reg_id].valid) {
        if (__registers_info[reg_id].emad_params.deparse_cb == NULL) {
            return SXD_STATUS_ERROR;
        }

        return __registers_info[reg_id].emad_params.deparse_cb(reg_data, reg_buff,
                                                               __registers_info[reg_id].emad_params.deparse_context,
                                                               print_data);
    }

    return SXD_STATUS_NOT_INITIALIZED;
}


sxd_status_t sxd_access_reg_common(void                   * ku_reg_data,
                                   const sxd_reg_meta_t   * reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                   * handler_context,
                                   sxd_reg_id_e             reg_id)
{
    dpt_encapsulation_t                   encapsulation = CMD_IFC_PATH;
    internal_path_params_t                params;
    sxd_status_t                          status = SXD_STATUS_SUCCESS;
    struct sxd_emad_general_reg_data      reg_data;
    swid_type_t                           swid_type;
    struct sxd_register_info            * reg_info;
    const struct access_reg_ifc_params  * ifc_params;
    struct access_reg_mad_params        * mad_params;
    const struct access_reg_emad_params * emad_params;
    uint32_t                              i;

#if !defined(IB_PRESENT_FLAG)
    UNUSED_PARAM(mad_params);
#endif

    if (NULL == hw_p) {
        SX_LOG_ERR("ACCESS REG Handle is NULL\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (NULL != handler) {
        SX_LOG_ERR("handler is not NULL, but asynchronous register accesses "
                   "are not supported\n");
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    reg_info = sxd_register_get_info(reg_id);
    if (reg_info == NULL) {
        SX_LOG_ERR("REG 0x%x: Register is not initialized!\n", reg_id);
        SX_LOG_EXIT();
        return SXD_STATUS_NOT_INITIALIZED;
    }

    if (ku_reg_data == NULL) {
        SX_LOG_ERR("REG %s: ku_reg_data is NULL\n", reg_info->name);
        SX_LOG_EXIT();
        return SXD_STATUS_PARAM_ERROR;
    }

    if (reg_meta == NULL) {
        SX_LOG_ERR("REG %s: reg_meta is NULL\n", reg_info->name);
        SX_LOG_EXIT();
        return SXD_STATUS_PARAM_ERROR;
    }

    ifc_params = sxd_register_get_ifc_params(reg_id);
    mad_params = sxd_register_get_mad_params(reg_id);
    emad_params = sxd_register_get_emad_params(reg_id);

    if (reg_info->is_dynamic == TRUE) {
        reg_info->reg_struct_size = \
            reg_info->blank_reg_size + reg_info->dynamic_item_size * emad_params->dynamic_arr_num_get_cb(ku_reg_data);
    }

    for (i = 0; i < data_num; i++) {
        const sxd_reg_meta_t *curr_reg_meta = reg_meta + i;
        void                 *curr_reg_data = ((uint8_t*)ku_reg_data) + i * reg_info->reg_struct_size;
        sxd_access_cmd_t      access_cmd = curr_reg_meta->access_cmd;
        sxd_dev_id_t          dev_id = curr_reg_meta->dev_id;
        sxd_swid_t            swid = curr_reg_meta->swid;

        /* Default device (254,255) access allowed only for limited number of registers */
        if (DEFAULT_DEVICE_ID_CHECK(dev_id) && !(g_static_reg_attributes[reg_id] & SXD_REG_ATTR_F_DEFAUT_DEV_ACCESS)) {
            SX_LOG_ERR("REG %s: access isn't allowed for device %u \n", reg_info->name, dev_id);
            return SXD_STATUS_PARAM_ERROR;
        }

        if (!DEFAULT_DEVICE_ID_CHECK(dev_id) &&
            (dpt_ptr->device_access_control[dev_id] == NO_ACCESS)) {
            SX_LOG_ERR("REG %s: The access control for device %u was not set\n", reg_info->name, dev_id);
            return SXD_STATUS_NOT_INITIALIZED;
        }

        /* if the device is read-only and current command is a 'write' one, skip it if the register
         * does not have the 'ignore read-only' attribute.
         */
        if (!DEFAULT_DEVICE_ID_CHECK(dev_id) &&
            (dpt_ptr->device_access_control[dev_id] == READ_ONLY) &&
            IS_ACCESS_CMD_WRITE(access_cmd) &&
            !(g_static_reg_attributes[reg_id] & SXD_REG_ATTR_F_IGNORE_READ_ONLY)) {
            continue;
        }

        status = dpt_get_swid_type(swid, &swid_type);
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("REG %s: Failed to get swid type from the DPT\n", reg_info->name);
            return status;
        }

        if (swid_type == SWID_TYPE_EN) {
            status = dpt_get_encapsulation(dev_id, swid, FIRST_GROUP, &encapsulation, &params, TRUE);
        } else if (swid_type == SWID_TYPE_IB) {
            status = dpt_get_encapsulation(dev_id, swid, SECOND_GROUP, &encapsulation, &params, TRUE);
        }

        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("REG %s: Failed to get the encapsulation from the DPT\n", reg_info->name);
            return status;
        }

        switch (encapsulation) {
        case EMAD_PATH:
            if ((emad_params == NULL) ||
                (emad_params->parse_cb == NULL) ||
                (emad_params->deparse_cb == NULL)) {
                SX_LOG_ERR("REG %s: emad_params are not set or have missing callbacks\n", reg_info->name);
                return SXD_STATUS_ERROR;
            }

            if (IS_ACCESS_CMD_READ(access_cmd) || IS_ACCESS_CMD_WRITE(access_cmd)) {
                reg_data.reg_data = curr_reg_data;
                build_emad_common(curr_reg_meta, params.sys_port, &reg_data.common);
                status = emad_common_set_ex(&reg_data, 1, reg_id, handler, handler_context, emad_params);
                if (status != SXD_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed accessing %s register through EMAD (iteration %u) for device %u (err=%d)\n",
                               reg_info->name, i, dev_id, status);
                    return status;
                }
            } else {
                SX_LOG_ERR("REG %s: The access command of register is not valid\n", reg_info->name);
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }
            break;

        case CMD_IFC_PATH:
#ifdef IB_PRESENT_FLAG
fallback_to_ifc:
#endif /* ifdef IB_PRESENT_FLAG */
            if (ifc_params == NULL) {
                uint8_t                          raw_buff[2 * 1024] = { 0 };
                uint32_t                         raw_buff_size = sizeof(raw_buff);
                struct ku_raw_reg                raw_reg = {
                    .buff = raw_buff,
                    /* .size will be set later */
                };
                struct sxd_emad_general_reg_data reg_data = {
                    .reg_data = curr_reg_data
                };

                if (emad_params == NULL) {
                    SX_LOG_ERR("REG %s: no EMAD or command-interface parameters set\n", reg_info->name);
                    return SXD_STATUS_ERROR;
                }

                status = emad_params->parse_cb(&reg_data, raw_buff, &raw_buff_size, NULL, NULL);
                if (status != SXD_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed parsing %s register through CMD IFC (err=%d)\n", reg_info->name, status);
                    return status;
                }

                raw_reg.size = raw_buff_size;
                status = sxd_command_ifc_access_raw_reg(hw_p->cmd_ifc_hw_p, access_cmd, dev_id, reg_id, &raw_reg);
                if (status != SXD_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed accessing %s register through CMD IFC for device %u (err=%d)\n",
                               reg_info->name,
                               dev_id,
                               status);
                    return status;
                }

                status = emad_params->deparse_cb(&reg_data, raw_buff, NULL, NULL);
                if (status != SXD_STATUS_SUCCESS) {
                    SX_LOG_ERR("Failed deparsing %s register through CMD IFC (err=%d)\n", reg_info->name, status);
                    return status;
                }
            } else {
                status = sxd_command_ifc_access_reg(hw_p->cmd_ifc_hw_p,
                                                    access_cmd,
                                                    dev_id,
                                                    reg_id,
                                                    curr_reg_data,
                                                    reg_info->reg_struct_size,
                                                    ifc_params);
                if (status != SXD_STATUS_SUCCESS) {
                    SX_LOG_ERR("REG %s: Failed accessing register through CMD IFC\n", reg_info->name);
                }
            }

            break;

#ifdef IB_PRESENT_FLAG
        case MAD_PATH:
            if (mad_params == NULL) { /* MAD is not implemented at all, just fallback to cmd-ifc  */
                goto fallback_to_ifc;
            }

            if ((mad_params->reg_size_in_dwords == 0) ||
                (mad_params->reg_pack_cb == NULL) ||
                (mad_params->reg_unpack_cb == NULL)) {
                SX_LOG_ERR("REG %s: mad_params are not set or have missing callbacks.\n", reg_info->name);
                status = SXD_STATUS_ERROR;
                goto ibmad_error;
            }

            if (IS_ACCESS_CMD_WRITE(access_cmd)) {
                status = sxd_command_mad_access_reg(hw_p->sport,
                                                    dev_id,
                                                    &params.dr_params,
                                                    reg_id,
                                                    TLV_OP_METHOD_WRITE_E,
                                                    curr_reg_data,
                                                    mad_params);
            } else if (IS_ACCESS_CMD_READ(access_cmd)) {
                status = sxd_command_mad_access_reg(hw_p->sport,
                                                    dev_id,
                                                    &params.dr_params,
                                                    reg_id,
                                                    TLV_OP_METHOD_QUERY_E,
                                                    curr_reg_data,
                                                    mad_params);
            } else {
                SX_LOG_ERR("REG %s: The access command of register is not valid\n", reg_info->name);
                return SXD_STATUS_INVALID_ACCESS_CMD;
            }

ibmad_error:

            if (status != SXD_STATUS_SUCCESS) {
                SX_LOG_ERR("REG %s: Failed accessing register through IBMAD "
                           "dev %d.\n", reg_info->name, reg_meta->dev_id);
                return status;
            }

            break;

#endif /* ifdef IB_PRESENT_FLAG */
        default:
            SX_LOG_ERR("REG %s: There is no valid path for accessing register\n", reg_info->name);
            return SXD_STATUS_NO_PATH_TO_DEVICE;
        }
    }

    return status;
}
