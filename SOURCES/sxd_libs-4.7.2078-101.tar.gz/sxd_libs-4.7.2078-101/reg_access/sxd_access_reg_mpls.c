/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap_osd.h>
#include <sx/sxd/sxd_emad_common_data.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_emad_mpls_reg.h>

#ifdef IB_PRESENT_FLAG
#include <infiniband/mad.h>
#include "access_register_mad.h"
#endif /* IB_PRESENT_FLAG */

#include <reg_access/sxd_access_reg_infra.h>

/* ******************************************************************************************************* */
/* MPIBE - MPLS ILM Bulk ECMP Update                                                                       */
/* ******************************************************************************************************* */

static sxd_status_t __mpibe_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    const struct ku_mpibe_reg * mpibe_data = (struct ku_mpibe_reg*)reg_common_data->reg_data;
    sxd_emad_mpibe_reg_t      * mpibe_reg = (sxd_emad_mpibe_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mpibe_reg->label_space = mpibe_data->label_space;
    mpibe_reg->nhlfe_index = cl_hton32(mpibe_data->nhlfe_ptr & 0xffffff);
    mpibe_reg->ecmp_size = cl_hton16(mpibe_data->ecmp_size & 0x1fff);
    mpibe_reg->new_nhlfe_index = cl_hton32(mpibe_data->new_nhlfe_ptr & 0xffffff);
    mpibe_reg->new_ecmp_size = cl_hton16(mpibe_data->new_ecmp_size & 0x1fff);
    *reg_size = sizeof(sxd_emad_mpibe_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __mpibe_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_mpibe_reg       * mpibe_data = (struct ku_mpibe_reg*)reg_common_data->reg_data;
    const sxd_emad_mpibe_reg_t* mpibe_reg = (const sxd_emad_mpibe_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mpibe_data->label_space = mpibe_reg->label_space;
    mpibe_data->nhlfe_ptr = cl_hton32(mpibe_reg->nhlfe_index & 0xffffff);
    mpibe_data->ecmp_size = cl_hton16(mpibe_reg->ecmp_size & 0x1fff);
    mpibe_data->new_nhlfe_ptr = cl_hton32(mpibe_reg->new_nhlfe_index & 0xffffff);
    mpibe_data->new_ecmp_size = cl_hton16(mpibe_reg->new_ecmp_size & 0x1fff);

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_mpibe_init(void)
{
    const struct access_reg_emad_params emad_params = {
        .parse_cb = __mpibe_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __mpibe_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info      reg_info = {
        .name = "mpibe",
        .emad_struct_size = sizeof(sxd_emad_mpibe_reg_t),
        .reg_struct_size = sizeof(struct ku_mpibe_reg)
    };
    sxd_status_t                        st;

    st = sxd_register_init(SXD_REG_ID_MPIBE_E,
                           &reg_info,
                           NULL,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}
