/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap_osd.h>
#include <sx/sxd/sxd_emad_common_data.h>
#include <sx/sxd/sxd_emad_system_reg.h>
#include <sx/sxd/sxd_access_register.h>

#ifdef IB_PRESENT_FLAG
#include <infiniband/mad.h>
#include "access_register_mad.h"
#endif /* IB_PRESENT_FLAG */

#include <reg_access/sxd_access_reg_infra.h>

/* ******************************************************************************************************* */
/* MFSM - Management Fan Speed Measurement                                                                 */
/* ******************************************************************************************************* */

#define MFSM_REG_SIZE_IN_DWORDS (2)

static sxd_status_t __mfsm_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_mfsm_reg * mfsm_data = (struct ku_mfsm_reg*)reg_common_data->reg_data;
    sxd_emad_mfsm_reg_t* mfsm_reg = (sxd_emad_mfsm_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mfsm_reg->tacho = mfsm_data->tacho & 0xf;
    mfsm_reg->n = mfsm_data->n & 0x3;
    mfsm_reg->rpm = cl_hton16(mfsm_data->rpm);

    *reg_size = sizeof(sxd_emad_mfsm_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __mfsm_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_mfsm_reg       * mfsm_data = (struct ku_mfsm_reg*)reg_common_data->reg_data;
    const sxd_emad_mfsm_reg_t* mfsm_reg = (const sxd_emad_mfsm_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mfsm_data->tacho = mfsm_reg->tacho & 0xf;
    mfsm_data->n = mfsm_reg->n & 0x3;
    mfsm_data->rpm = cl_ntoh16(mfsm_reg->rpm);

    return SXD_STATUS_SUCCESS;
}


#ifdef IB_PRESENT_FLAG
static uint32_t __mfsm_mad_pack(const void* ku_reg_buff, uint8_t* packed_buffer, void* context)
{
    const struct ku_mfsm_reg* mfsm_data = (const struct ku_mfsm_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    push_to_buff(packed_buffer, 4, 4, mfsm_data->tacho);
    push_to_buff(packed_buffer, 30, 2, mfsm_data->n);
    push_to_buff(packed_buffer, 48, 16, mfsm_data->rpm);

    return 4 * MFSM_REG_SIZE_IN_DWORDS;
}


static void __mfsm_mad_unpack(void* ku_reg_buff, uint8_t* buffer_to_unpack, void* context)
{
    struct ku_mfsm_reg* mfsm_data = (struct ku_mfsm_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    mfsm_data->tacho = pop_from_buff(buffer_to_unpack, 4, 4);
    mfsm_data->n = pop_from_buff(buffer_to_unpack, 30, 2);
    mfsm_data->rpm = pop_from_buff(buffer_to_unpack, 48, 16);
}
#endif /* IB_PRESENT_FLAG */


void sxd_reg_mfsm_init(void)
{
    const struct access_reg_ifc_params  ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MFSM
    };
    const struct access_reg_emad_params emad_params = {
        .parse_cb = __mfsm_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __mfsm_emad_deparse,
        .deparse_context = NULL
    };

#ifdef IB_PRESENT_FLAG
    struct access_reg_mad_params mad_params = {
        .reg_size_in_dwords = MFSM_REG_SIZE_IN_DWORDS,
        .reg_pack_cb = __mfsm_mad_pack,
        .reg_pack_context = NULL,
        .reg_unpack_cb = __mfsm_mad_unpack,
        .reg_unpack_context = NULL
    };
#endif /* IB_PRESENT_FLAG */

    const struct sxd_register_info         reg_info = {
        .name = "mfsm",
        .emad_struct_size = sizeof(sxd_emad_mfsm_reg_t),
        .reg_struct_size = sizeof(struct ku_mfsm_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_MFSM",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MFSM,
        .ctrl_cmd_size = sizeof(struct ku_access_mfsm_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_MFSM_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
#ifdef IB_PRESENT_FLAG
                           &mad_params,
#else /* IB_PRESENT_FLAG */
                           NULL,
#endif /* IB_PRESENT_FLAG */
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* MCIA - Management Cable Info Access                                                                     */
/* ******************************************************************************************************* */

static sxd_status_t __mcia_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_mcia_reg * mcia_data = (struct ku_mcia_reg*)reg_common_data->reg_data;
    sxd_emad_mcia_reg_t* mcia_reg = (sxd_emad_mcia_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mcia_reg->l = (mcia_data->l & 0x1) << 7;
    mcia_reg->module = mcia_data->module;
    mcia_reg->slot_index = mcia_data->slot_index << 4;
    mcia_reg->status = mcia_data->status;
    mcia_reg->i2c_device_address = mcia_data->i2c_device_address;
    mcia_reg->page_number = mcia_data->page_number;
    mcia_reg->device_address = cl_hton16(mcia_data->device_address);
    mcia_reg->size = cl_hton16(mcia_data->size);
    mcia_reg->dword_0 = cl_hton32(mcia_data->dword_0);
    mcia_reg->dword_1 = cl_hton32(mcia_data->dword_1);
    mcia_reg->dword_2 = cl_hton32(mcia_data->dword_2);
    mcia_reg->dword_3 = cl_hton32(mcia_data->dword_3);
    mcia_reg->dword_4 = cl_hton32(mcia_data->dword_4);
    mcia_reg->dword_5 = cl_hton32(mcia_data->dword_5);
    mcia_reg->dword_6 = cl_hton32(mcia_data->dword_6);
    mcia_reg->dword_7 = cl_hton32(mcia_data->dword_7);
    mcia_reg->dword_8 = cl_hton32(mcia_data->dword_8);
    mcia_reg->dword_9 = cl_hton32(mcia_data->dword_9);
    mcia_reg->dword_10 = cl_hton32(mcia_data->dword_10);
    mcia_reg->dword_11 = cl_hton32(mcia_data->dword_11);

    *reg_size = sizeof(sxd_emad_mcia_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __mcia_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_mcia_reg       * mcia_data = (struct ku_mcia_reg*)reg_common_data->reg_data;
    const sxd_emad_mcia_reg_t* mcia_reg = (const sxd_emad_mcia_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mcia_data->l = mcia_reg->l >> 7;
    mcia_data->module = mcia_reg->module;
    mcia_data->slot_index = mcia_reg->slot_index >> 4;
    mcia_data->status = mcia_reg->status;
    mcia_data->i2c_device_address = mcia_reg->i2c_device_address;
    mcia_data->page_number = mcia_reg->page_number;
    mcia_data->device_address = cl_ntoh16(mcia_reg->device_address);
    mcia_data->size = cl_ntoh16(mcia_reg->size);
    mcia_data->dword_0 = cl_ntoh32(mcia_reg->dword_0);
    mcia_data->dword_1 = cl_ntoh32(mcia_reg->dword_1);
    mcia_data->dword_2 = cl_ntoh32(mcia_reg->dword_2);
    mcia_data->dword_3 = cl_ntoh32(mcia_reg->dword_3);
    mcia_data->dword_4 = cl_ntoh32(mcia_reg->dword_4);
    mcia_data->dword_5 = cl_ntoh32(mcia_reg->dword_5);
    mcia_data->dword_6 = cl_ntoh32(mcia_reg->dword_6);
    mcia_data->dword_7 = cl_ntoh32(mcia_reg->dword_7);
    mcia_data->dword_8 = cl_ntoh32(mcia_reg->dword_8);
    mcia_data->dword_9 = cl_ntoh32(mcia_reg->dword_9);
    mcia_data->dword_10 = cl_ntoh32(mcia_reg->dword_10);
    mcia_data->dword_11 = cl_ntoh32(mcia_reg->dword_11);

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_mcia_init(void)
{
    const struct access_reg_emad_params emad_params = {
        .parse_cb = __mcia_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __mcia_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info      reg_info = {
        .name = "mcia",
        .emad_struct_size = sizeof(sxd_emad_mcia_reg_t),
        .reg_struct_size = sizeof(struct ku_mcia_reg)
    };
    sxd_status_t                        st;

    st = sxd_register_init(SXD_REG_ID_MCIA_E,
                           &reg_info,
                           NULL,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* MFM - Management Fabric Memory Register                                                                 */
/* ******************************************************************************************************* */

static sxd_status_t __mfm_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                     void                                  * reg_buff,
                                     uint32_t                              * reg_size,
                                     void                                  * context,
                                     sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_mfm_reg * mfm_data = (struct ku_mfm_reg*)reg_common_data->reg_data;
    sxd_emad_mfm_reg_t* mfm_reg = (sxd_emad_mfm_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mfm_reg->index = mfm_data->index & 0xf;
    mfm_reg->memory = cl_hton64(mfm_data->memory);
    mfm_reg->memory_mask = cl_hton64(mfm_data->memory_mask);

    *reg_size = sizeof(sxd_emad_mfm_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __mfm_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                       const void                      * reg_buff,
                                       void                            * context,
                                       sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_mfm_reg       * mfm_data = (struct ku_mfm_reg*)reg_common_data->reg_data;
    const sxd_emad_mfm_reg_t* mfm_reg = (const sxd_emad_mfm_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mfm_data->index = mfm_reg->index & 0xf;
    mfm_data->memory = cl_ntoh64(mfm_reg->memory);
    mfm_data->memory_mask = cl_ntoh64(mfm_reg->memory_mask);

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_mfm_init(void)
{
    const struct access_reg_ifc_params     ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MFM
    };
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __mfm_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __mfm_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_MFM",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MFM,
        .ctrl_cmd_size = sizeof(struct ku_access_mfm_reg)
    };
    const struct sxd_register_info         reg_info = {
        .name = "mfm",
        .emad_struct_size = sizeof(sxd_emad_mfm_reg_t),
        .reg_struct_size = sizeof(struct ku_mfm_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_MFM_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* MHSR - Management Health State Register                                                                 */
/* ******************************************************************************************************* */

static sxd_status_t __mhsr_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_mhsr_reg * mhsr_data = (struct ku_mhsr_reg*)reg_common_data->reg_data;
    sxd_emad_mhsr_reg_t* mhsr_reg = (sxd_emad_mhsr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mhsr_reg->health = ((uint8_t)mhsr_data->health) & 0xf;

    *reg_size = sizeof(sxd_emad_mhsr_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __mhsr_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_mhsr_reg       * mhsr_data = (struct ku_mhsr_reg*)reg_common_data->reg_data;
    const sxd_emad_mhsr_reg_t* mhsr_reg = (const sxd_emad_mhsr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mhsr_data->health = (enum mhsr_health_mode)(mhsr_reg->health & 0xf);

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_mhsr_init(void)
{
    const struct access_reg_ifc_params     ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MHSR
    };
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __mhsr_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __mhsr_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_MHSR",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MHSR,
        .ctrl_cmd_size = sizeof(struct ku_access_mhsr_reg)
    };
    const struct sxd_register_info         reg_info = {
        .name = "mhsr",
        .emad_struct_size = sizeof(sxd_emad_mhsr_reg_t),
        .reg_struct_size = sizeof(struct ku_mhsr_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_MHSR_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* MFSC - Management Fan Speed Control                                                                     */
/* ******************************************************************************************************* */

static sxd_status_t __mfsc_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_mfsc_reg * mfsc_data = (struct ku_mfsc_reg*)reg_common_data->reg_data;
    sxd_emad_mfsc_reg_t* mfsc_reg = (sxd_emad_mfsc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mfsc_reg->pwm = mfsc_data->pwm & 0x7;
    mfsc_reg->pwm_duty_cycle = mfsc_data->pwm_duty_cycle;

    *reg_size = sizeof(sxd_emad_mfsc_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __mfsc_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_mfsc_reg       * mfsc_data = (struct ku_mfsc_reg*)reg_common_data->reg_data;
    const sxd_emad_mfsc_reg_t* mfsc_reg = (const sxd_emad_mfsc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mfsc_data->pwm = mfsc_reg->pwm & 0x7;
    mfsc_data->pwm_duty_cycle = mfsc_reg->pwm_duty_cycle;

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_mfsc_init(void)
{
    const struct access_reg_ifc_params     ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MFSC
    };
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __mfsc_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __mfsc_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_MFSC",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MFSC,
        .ctrl_cmd_size = sizeof(struct ku_access_mfsc_reg)
    };
    const struct sxd_register_info         reg_info = {
        .name = "mfsc",
        .emad_struct_size = sizeof(sxd_emad_mfsc_reg_t),
        .reg_struct_size = sizeof(struct ku_mfsc_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_MFSC_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* IBSNI - IB Switch Network Info                                                                          */
/* ******************************************************************************************************* */

#define IBSNI_NUM_OF_RECORDS 4
static sxd_status_t __ibsni_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_ibsni_reg * ibsni_data = (struct ku_ibsni_reg*)reg_common_data->reg_data;
    sxd_emad_ibsni_reg_t* ibsni_reg = (sxd_emad_ibsni_reg_t*)reg_buff;
    uint32_t              i, j;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    for (i = 0; i < IBSNI_NUM_OF_RECORDS; i++) {
        ibsni_reg->ipv4_record[i].ipv4 = cl_hton32(ibsni_data->ipv4_record[i].ipv4);
        ibsni_reg->ipv4_record[i].netmask = cl_hton32(ibsni_data->ipv4_record[i].netmask);
        ibsni_reg->ipv4_record_port2[i].ipv4 = cl_hton32(ibsni_data->ipv4_record_port2[i].ipv4);
        ibsni_reg->ipv4_record_port2[i].netmask = cl_hton32(ibsni_data->ipv4_record_port2[i].netmask);
        for (j = 0; j < IBSNI_NUM_OF_RECORDS; j++) {
            ibsni_reg->ipv6_record[i].ipv6[j] = cl_hton32(ibsni_data->ipv6_record[i].ipv6[j]);
            ibsni_reg->ipv6_record[i].netmask[j] = cl_hton32(ibsni_data->ipv6_record[i].netmask[j]);
            ibsni_reg->ipv6_record_port2[i].ipv6[j] = cl_hton32(ibsni_data->ipv6_record_port2[i].ipv6[j]);
            ibsni_reg->ipv6_record_port2[i].netmask[j] = cl_hton32(ibsni_data->ipv6_record_port2[i].netmask[j]);
        }
    }

    *reg_size = sizeof(sxd_emad_ibsni_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __ibsni_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_ibsni_reg       * ibsni_data = (struct ku_ibsni_reg*)reg_common_data->reg_data;
    const sxd_emad_ibsni_reg_t* ibsni_reg = (const sxd_emad_ibsni_reg_t*)reg_buff;
    uint32_t                    i, j;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    for (i = 0; i < IBSNI_NUM_OF_RECORDS; i++) {
        ibsni_data->ipv4_record[i].ipv4 = cl_ntoh32(ibsni_reg->ipv4_record[i].ipv4);
        ibsni_data->ipv4_record[i].netmask = cl_ntoh32(ibsni_reg->ipv4_record[i].netmask);
        ibsni_data->ipv4_record_port2[i].ipv4 = cl_ntoh32(ibsni_reg->ipv4_record_port2[i].ipv4);
        ibsni_data->ipv4_record_port2[i].netmask = cl_ntoh32(ibsni_reg->ipv4_record_port2[i].netmask);
        for (j = 0; j < IBSNI_NUM_OF_RECORDS; j++) {
            ibsni_data->ipv6_record[i].ipv6[j] = cl_ntoh32(ibsni_reg->ipv6_record[i].ipv6[j]);
            ibsni_data->ipv6_record[i].netmask[j] = cl_ntoh32(ibsni_reg->ipv6_record[i].netmask[j]);
            ibsni_data->ipv6_record_port2[i].ipv6[j] = cl_ntoh32(ibsni_reg->ipv6_record_port2[i].ipv6[j]);
            ibsni_data->ipv6_record_port2[i].netmask[j] = cl_ntoh32(ibsni_reg->ipv6_record_port2[i].netmask[j]);
        }
    }

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_ibsni_init(void)
{
    const struct access_reg_ifc_params     ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_IBSNI
    };
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __ibsni_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __ibsni_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_IBSNI",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_IBSNI,
        .ctrl_cmd_size = sizeof(struct ku_access_ibsni_reg)
    };
    const struct sxd_register_info         reg_info = {
        .name = "ibsni",
        .emad_struct_size = sizeof(sxd_emad_ibsni_reg_t),
        .reg_struct_size = sizeof(struct ku_ibsni_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_IBSNI_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

/* ******************************************************************************************************* */
/* NV_SWITCH_CONF                                                                                          */
/* ******************************************************************************************************* */

#define NV_SWITCH_CONF_VALID_OFFSET_IN_DWORD 6
#define NV_SWITCH_CONF_DAS_OFFSET_IN_DWORD   4

static sxd_status_t __nv_switch_conf_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                                void                                  * reg_buff,
                                                uint32_t                              * reg_size,
                                                void                                  * context,
                                                sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_mnvda_nv_switch_conf_reg * nv_switch_conf_data =
        (struct ku_mnvda_nv_switch_conf_reg*)reg_common_data->reg_data;
    sxd_emad_nv_switch_conf_reg_t* nv_switch_conf_reg = (sxd_emad_nv_switch_conf_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    nv_switch_conf_reg->valid = nv_switch_conf_data->valid << NV_SWITCH_CONF_VALID_OFFSET_IN_DWORD;
    nv_switch_conf_reg->length = nv_switch_conf_data->length;
    nv_switch_conf_reg->type_class_index = cl_hton32(nv_switch_conf_data->type_class_index);
    nv_switch_conf_reg->crc16 = cl_hton16(nv_switch_conf_data->crc16);
    nv_switch_conf_reg->nv_switch_conf.das = nv_switch_conf_data->nv_switch_conf.das <<
                                             NV_SWITCH_CONF_DAS_OFFSET_IN_DWORD;
    nv_switch_conf_reg->nv_switch_conf.is_nvlink = nv_switch_conf_data->nv_switch_conf.is_nvlink;
    nv_switch_conf_reg->nv_switch_conf.split_mode = nv_switch_conf_data->nv_switch_conf.split_mode;

    *reg_size = sizeof(sxd_emad_nv_switch_conf_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __nv_switch_conf_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                                  const void                      * reg_buff,
                                                  void                            * context,
                                                  sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_mnvda_nv_switch_conf_reg * nv_switch_conf_data =
        (struct ku_mnvda_nv_switch_conf_reg*)reg_common_data->reg_data;
    const sxd_emad_nv_switch_conf_reg_t* nv_switch_conf_reg = (const sxd_emad_nv_switch_conf_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    nv_switch_conf_data->valid = nv_switch_conf_reg->valid >> NV_SWITCH_CONF_VALID_OFFSET_IN_DWORD;
    nv_switch_conf_data->length = nv_switch_conf_reg->length;
    nv_switch_conf_data->type_class_index = cl_ntoh32(nv_switch_conf_reg->type_class_index);
    nv_switch_conf_data->crc16 = cl_ntoh16(nv_switch_conf_reg->crc16);
    nv_switch_conf_data->nv_switch_conf.das = nv_switch_conf_reg->nv_switch_conf.das >>
                                              NV_SWITCH_CONF_DAS_OFFSET_IN_DWORD;
    nv_switch_conf_data->nv_switch_conf.is_nvlink = nv_switch_conf_reg->nv_switch_conf.is_nvlink;
    nv_switch_conf_data->nv_switch_conf.split_mode = nv_switch_conf_reg->nv_switch_conf.split_mode;

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_nv_switch_conf_init(void)
{
    const struct access_reg_ifc_params     ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MNVDA_NV_SWITCH_CONF
    };
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __nv_switch_conf_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __nv_switch_conf_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_MNVDA_NV_SWITCH_CONF",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MNVDA_NV_SWITCH_CONF,
        .ctrl_cmd_size = sizeof(struct ku_access_mnvda_nv_switch_conf_reg)
    };
    const struct sxd_register_info         reg_info = {
        .name = "MNVDA",
        .emad_struct_size = sizeof(sxd_emad_nv_switch_conf_reg_t),
        .reg_struct_size = sizeof(struct ku_mnvda_nv_switch_conf_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_MNVDA_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}
