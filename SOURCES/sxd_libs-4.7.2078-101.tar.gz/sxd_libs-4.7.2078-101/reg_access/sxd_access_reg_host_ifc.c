/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sx/sxd/sxd_emad_system_reg.h"
#include "reg_access/sxd_access_reg_infra.h"
#include <sx/sxd/sxd_emad_host_reg.h>
#include <complib/cl_byteswap_osd.h>


/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

/* ******************************************************************************************************* */
/* HTAC                                                                                                    */
/* ******************************************************************************************************* */

#define HTAC_REG_SIZE_IN_DWORDS (4)

static sxd_status_t __htac_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_htac_reg * htac_data = (struct ku_htac_reg*)reg_common_data->reg_data;
    sxd_emad_htac_reg_t* htac_reg = (sxd_emad_htac_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    htac_reg->trap_id = cl_hton16(htac_data->trap_id);

    switch (htac_data->trap_id) {
    case SXD_TRAP_ID_ICMPV6_CONF_TYPE0:
    case SXD_TRAP_ID_ICMPV6_CONF_TYPE1:
    case SXD_TRAP_ID_OVERLAY_ICMPV6_CONF_TYPE:
        htac_reg->attr[0].icmpv6_type_attr.icmp_type = htac_data->attr[0].icmp_type;
        break;

    case SXD_TRAP_ID_NVE_DECAP_ETH:
        htac_reg->attr[0].nve_decap_et_type_attr.eth_type = cl_hton16(htac_data->attr[0].eth_type);
        htac_reg->attr[1].nve_decap_et_type_attr.eth_type = cl_hton16(htac_data->attr[1].eth_type);
        break;

    case SXD_TRAP_ID_ETH_CONF_TYPE0:
    case SXD_TRAP_ID_ETH_CONF_TYPE1:
        htac_reg->attr[0].nve_decap_et_type_attr.eth_type = cl_hton16(htac_data->attr[0].eth_type);
        break;

    default:
        return SXD_STATUS_ERROR;
    }
    *reg_size = sizeof(sxd_emad_htac_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __htac_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_htac_reg       * htac_data = (struct ku_htac_reg*)reg_common_data->reg_data;
    const sxd_emad_htac_reg_t* htac_reg = (const sxd_emad_htac_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    htac_data->trap_id = cl_ntoh16(htac_reg->trap_id);

    switch (htac_data->trap_id) {
    case SXD_TRAP_ID_ICMPV6_CONF_TYPE0:
    case SXD_TRAP_ID_ICMPV6_CONF_TYPE1:
    case SXD_TRAP_ID_OVERLAY_ICMPV6_CONF_TYPE:
        htac_data->attr[0].icmp_type = htac_reg->attr[0].icmpv6_type_attr.icmp_type;
        break;

    case SXD_TRAP_ID_NVE_DECAP_ETH:
        htac_data->attr[0].eth_type = cl_ntoh16(htac_reg->attr[0].nve_decap_et_type_attr.eth_type);
        htac_data->attr[1].eth_type = cl_ntoh16(htac_reg->attr[1].nve_decap_et_type_attr.eth_type);
        break;

    case SXD_TRAP_ID_ETH_CONF_TYPE0:
    case SXD_TRAP_ID_ETH_CONF_TYPE1:
        htac_data->attr[0].eth_type = cl_ntoh16(htac_reg->attr[0].nve_decap_et_type_attr.eth_type);
        break;

    default:
        return SXD_STATUS_ERROR;
    }

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_htac_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __htac_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __htac_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "htac",
        .emad_struct_size = sizeof(sxd_emad_htac_reg_t),
        .reg_struct_size = sizeof(struct ku_htac_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_HTAC",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_HTAC,
        .ctrl_cmd_size = sizeof(struct ku_access_htac_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_HTAC_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* HOPF - Host Out-of-Band Packet Flow                                                                     */
/* ******************************************************************************************************* */

static sxd_status_t __hopf_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_hopf_reg * hopf_data = (struct ku_hopf_reg*)reg_common_data->reg_data;
    sxd_emad_hopf_reg_t* hopf_reg = (sxd_emad_hopf_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    hopf_reg->sr_cqever_flownum = cl_hton32(((hopf_data->sr & 0x1) << 31) |
                                            ((hopf_data->cqe_ver & 0xf) << 24) |
                                            (hopf_data->flow_number & 0xffffff));
    hopf_reg->rcv_cpu_tclass = hopf_data->rcv_cpu_tclass & 0xf;
    hopf_reg->cpu_tclass = hopf_data->cpu_tclass & 0xf;
    hopf_reg->i_f = hopf_data->i_f & 0x7;

    hopf_reg->mac_47_32 = cl_hton16((hopf_data->mac[0] << 8) | hopf_data->mac[1]);
    hopf_reg->mac_31_0 = cl_hton32((hopf_data->mac[2] << 24) |
                                   (hopf_data->mac[3] << 16) |
                                   (hopf_data->mac[4] << 8) |
                                   hopf_data->mac[5]);

    hopf_reg->vlan_ex_dei_pcp_vid = cl_hton32(((hopf_data->vlan_ex & 0x1) << 16) |
                                              ((hopf_data->dei & 0x1) << 15) |
                                              ((hopf_data->pcp & 0x7) << 12) |
                                              (hopf_data->vid & 0xfff));

    *reg_size = sizeof(sxd_emad_hopf_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __hopf_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_hopf_reg       * hopf_data = (struct ku_hopf_reg*)reg_common_data->reg_data;
    const sxd_emad_hopf_reg_t* hopf_reg = (const sxd_emad_hopf_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    hopf_data->sr = (cl_ntoh32(hopf_reg->sr_cqever_flownum) >> 31) & 0x1;
    hopf_data->cqe_ver = (cl_ntoh32(hopf_reg->sr_cqever_flownum) >> 24) & 0xf;
    hopf_data->flow_number = cl_ntoh32(hopf_reg->sr_cqever_flownum) & 0xffffff;
    hopf_data->rcv_cpu_tclass = hopf_reg->rcv_cpu_tclass & 0xf;
    hopf_data->cpu_tclass = hopf_reg->cpu_tclass & 0xf;
    hopf_data->i_f = hopf_reg->i_f & 0x7;
    hopf_data->mac[0] = (cl_ntoh16(hopf_reg->mac_47_32) >> 8) & 0xff;
    hopf_data->mac[1] = cl_ntoh16(hopf_reg->mac_47_32) & 0xff;
    hopf_data->mac[2] = (cl_ntoh32(hopf_reg->mac_31_0) >> 24) & 0xff;
    hopf_data->mac[3] = (cl_ntoh32(hopf_reg->mac_31_0) >> 16) & 0xff;
    hopf_data->mac[4] = (cl_ntoh32(hopf_reg->mac_31_0) >> 8) & 0xff;
    hopf_data->mac[5] = cl_ntoh32(hopf_reg->mac_31_0) & 0xff;
    hopf_data->vlan_ex = (cl_ntoh32(hopf_reg->vlan_ex_dei_pcp_vid) >> 16) & 0x1;
    hopf_data->dei = (cl_ntoh32(hopf_reg->vlan_ex_dei_pcp_vid) >> 15) & 0x1;
    hopf_data->pcp = (cl_ntoh32(hopf_reg->vlan_ex_dei_pcp_vid) >> 12) & 0x7;
    hopf_data->vid = cl_ntoh32(hopf_reg->vlan_ex_dei_pcp_vid) & 0xfff;

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_hopf_init(void)
{
    const struct access_reg_emad_params emad_params = {
        .parse_cb = __hopf_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __hopf_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info      reg_info = {
        .name = "hopf",
        .emad_struct_size = sizeof(sxd_emad_hopf_reg_t),
        .reg_struct_size = sizeof(struct ku_hopf_reg)
    };
    sxd_status_t                        st;

    st = sxd_register_init(SXD_REG_ID_HOPF_E,
                           &reg_info,
                           NULL,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}
