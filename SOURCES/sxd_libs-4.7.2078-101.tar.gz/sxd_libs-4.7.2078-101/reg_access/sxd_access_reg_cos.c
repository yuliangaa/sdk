/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap_osd.h>
#include <sx/sxd/sxd_emad_common_data.h>
#include <sx/sxd/sxd_emad_cos_reg.h>
#include <sx/sxd/sxd_access_register.h>

#ifdef IB_PRESENT_FLAG
#include <infiniband/mad.h>
#include "access_register_mad.h"
#endif /* IB_PRESENT_FLAG */

#include <reg_access/sxd_access_reg_infra.h>


/* ******************************************************************************************************* */
/* SBDCC                                                                                                   */
/* ******************************************************************************************************* */

#define SBDCC_REG_SIZE_IN_DWORDS (132)

static sxd_status_t __sbdcc_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_sbdcc_reg * sbdcc_data = (struct ku_sbdcc_reg*)reg_common_data->reg_data;
    sxd_emad_sbdcc_reg_t* sbdcc_reg = (sxd_emad_sbdcc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    sbdcc_reg->clr = (sbdcc_data->clr) << 7;
    *reg_size = sizeof(sxd_emad_sbdcc_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __sbdcc_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_sbdcc_reg       * sbdcc_data = (struct ku_sbdcc_reg*)reg_common_data->reg_data;
    const sxd_emad_sbdcc_reg_t* sbdcc_reg = (const sxd_emad_sbdcc_reg_t*)reg_buff;
    int                         i = 0;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    for (i = 0; i < NUM_COUNTERS_SBDCC; i++) {
        sbdcc_data->ctr[i] = cl_ntoh64(sbdcc_reg->tclass[i]);
    }

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_sbdcc_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __sbdcc_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __sbdcc_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "sbdcc",
        .emad_struct_size = sizeof(sxd_emad_sbdcc_reg_t),
        .reg_struct_size = sizeof(struct ku_sbdcc_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_SBDCC",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_SBDCC,
        .ctrl_cmd_size = sizeof(struct ku_access_sbdcc_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_SBDCC_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* SBDCM                                                                                                   */
/* ******************************************************************************************************* */

#define SBDCM_REG_SIZE_IN_DWORDS (5)

static sxd_status_t __sbdcm_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_sbdcm_reg * sbdcm_data = (struct ku_sbdcm_reg*)reg_common_data->reg_data;
    sxd_emad_sbdcm_reg_t* sbdcm_reg = (sxd_emad_sbdcm_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    sbdcm_reg->ctr_index_set_type |= (cl_hton32(sbdcm_data->ctr_index) >> 8);
    sbdcm_reg->ctr_index_set_type |= (((uint32_t)sbdcm_data->ctr_set_type) << 24);

    *reg_size = sizeof(sxd_emad_sbdcm_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __sbdcm_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_sbdcm_reg       * sbdcm_data = (struct ku_sbdcm_reg*)reg_common_data->reg_data;
    const sxd_emad_sbdcm_reg_t* sbdcm_reg = (const sxd_emad_sbdcm_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    sbdcm_data->ctr_index = (cl_ntoh32(sbdcm_reg->ctr_index_set_type) & 0xFFFFFF);
    sbdcm_data->ctr_set_type = (cl_ntoh32(sbdcm_reg->ctr_index_set_type) >> 24);

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_sbdcm_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __sbdcm_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __sbdcm_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "sbdcm",
        .emad_struct_size = sizeof(sxd_emad_sbdcm_reg_t),
        .reg_struct_size = sizeof(struct ku_sbdcm_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_SBDCM",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_SBDCM,
        .ctrl_cmd_size = sizeof(struct ku_access_sbdcm_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_SBDCM_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* SBHBR                                                                                                   */
/* ******************************************************************************************************* */

#define SBHBR_REG_SIZE_IN_DWORDS (7)

static sxd_status_t __sbhbr_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_sbhbr_reg * sbhbr_data = (struct ku_sbhbr_reg*)reg_common_data->reg_data;
    sxd_emad_sbhbr_reg_t* sbhbr_reg = (sxd_emad_sbhbr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    sbhbr_reg->opcode = (sbhbr_data->opcode) << 4;
    sbhbr_reg->local_port = sbhbr_data->local_port;
    sbhbr_reg->hist_id = sbhbr_data->hist_id;
    sbhbr_reg->hist_type = cl_hton16(sbhbr_data->hist_type << 0x0C);
    sbhbr_reg->hist_params.tclass = sbhbr_data->hist_parameters & 0xFF;
    sbhbr_reg->hist_max = cl_hton32(sbhbr_data->hist_max);
    sbhbr_reg->hist_min = cl_hton32(sbhbr_data->hist_min);
    sbhbr_reg->sample_time = (sbhbr_data->sample_time) & 0x3F;
    *reg_size = sizeof(sxd_emad_sbhbr_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __sbhbr_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_sbhbr_reg       * sbhbr_data = (struct ku_sbhbr_reg*)reg_common_data->reg_data;
    const sxd_emad_sbhbr_reg_t* sbhbr_reg = (const sxd_emad_sbhbr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    sbhbr_data->opcode = (sbhbr_reg->opcode) >> 4;
    sbhbr_data->local_port = sbhbr_reg->local_port;
    sbhbr_data->hist_type = cl_ntoh16(sbhbr_reg->hist_type) >> 0x0C;
    sbhbr_data->hist_parameters = sbhbr_reg->hist_params.tclass;
    sbhbr_data->hist_max = cl_ntoh32(sbhbr_reg->hist_max);
    sbhbr_data->hist_min = cl_ntoh32(sbhbr_reg->hist_min);
    sbhbr_data->sample_time = (sbhbr_reg->sample_time) & 0x3F;

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_sbhbr_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __sbhbr_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __sbhbr_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "sbhbr",
        .emad_struct_size = sizeof(sxd_emad_sbhbr_reg_t),
        .reg_struct_size = sizeof(struct ku_sbhbr_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_SBHBR",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_SBHBR,
        .ctrl_cmd_size = sizeof(struct ku_access_sbhbr_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_SBHBR_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

/* ******************************************************************************************************* */
/* SBHRR                                                                                                   */
/* ******************************************************************************************************* */

#define SBHRR_REG_SIZE_IN_DWORDS (24)

static sxd_status_t __sbhrr_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_sbhrr_reg * sbhrr_data = (struct ku_sbhrr_reg*)reg_common_data->reg_data;
    sxd_emad_sbhrr_reg_t* sbhrr_reg = (sxd_emad_sbhrr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    sbhrr_reg->clr = (sbhrr_data->clr) << 7;
    sbhrr_reg->hist_id = sbhrr_data->hist_id;
    *reg_size = sizeof(sxd_emad_sbhrr_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __sbhrr_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    int                         i = 0;
    struct ku_sbhrr_reg       * sbhrr_data = (struct ku_sbhrr_reg*)reg_common_data->reg_data;
    const sxd_emad_sbhrr_reg_t* sbhrr_reg = (const sxd_emad_sbhrr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    for (i = 0; i < NUM_BINS_SBHRR; i++) {
        sbhrr_data->bin[i] = cl_ntoh64(sbhrr_reg->bin[i]);
    }

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_sbhrr_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __sbhrr_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __sbhrr_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "sbhrr",
        .emad_struct_size = sizeof(sxd_emad_sbhrr_reg_t),
        .reg_struct_size = sizeof(struct ku_sbhrr_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_SBHRR",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_SBHRR,
        .ctrl_cmd_size = sizeof(struct ku_access_sbhrr_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_SBHRR_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

/* ******************************************************************************************************* */
/* SBCTC                                                                                                    */
/* ******************************************************************************************************* */

#define SBCTC_REG_SIZE_IN_DWORDS (6)

static sxd_status_t __sbctc_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_sbctc_reg * sbctc_data = (struct ku_sbctc_reg*)reg_common_data->reg_data;
    sxd_emad_sbctc_reg_t* sbctc_reg = (sxd_emad_sbctc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    sbctc_reg->dir_ing = sbctc_data->dir_ing & 0x3;
    sbctc_reg->local_port = sbctc_data->local_port;
    sbctc_reg->lp_msb = (sbctc_data->lp_msb & 0x03) << 4;
    sbctc_reg->res_mode = (sbctc_data->res & 0x1) << 4;
    sbctc_reg->res_mode |= sbctc_data->mode & 0x1;
    sbctc_reg->en_config = (sbctc_data->en_config & 0x01) << 7;
    sbctc_reg->event = (sbctc_data->event) & 0x3;
    sbctc_reg->tclass_en = cl_hton64(sbctc_data->tclass_en);
    sbctc_reg->thr_max = cl_hton32(sbctc_data->thr_max & 0xFFFFFF);
    sbctc_reg->thr_min = cl_hton32(sbctc_data->thr_min & 0xFFFFFF);

    *reg_size = sizeof(sxd_emad_sbctc_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __sbctc_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_sbctc_reg       * sbctc_data = (struct ku_sbctc_reg*)reg_common_data->reg_data;
    const sxd_emad_sbctc_reg_t* sbctc_reg = (const sxd_emad_sbctc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    sbctc_data->dir_ing = sbctc_reg->dir_ing & 0x3;
    sbctc_data->local_port = sbctc_reg->local_port;
    sbctc_data->lp_msb = (sbctc_reg->lp_msb >> 4) & 0x03;
    sbctc_data->mode = sbctc_reg->res_mode & 0x1;
    sbctc_data->res = (sbctc_reg->res_mode >> 4) & 0x1;
    sbctc_data->event = (sbctc_reg->event) & 0x3;
    sbctc_data->tclass_en = cl_ntoh64(sbctc_reg->tclass_en);
    sbctc_data->thr_max = cl_ntoh32(sbctc_reg->thr_max) & 0xFFFFFF;
    sbctc_data->thr_min = cl_ntoh32(sbctc_reg->thr_min) & 0xFFFFFF;
    return SXD_STATUS_SUCCESS;
}

#ifdef IB_PRESENT_FLAG
static uint32_t __sbctc_mad_pack(const void* ku_reg_buff, uint8_t* packed_buffer, void* context)
{
    const struct ku_sbctc_reg* sbctc_data = (const struct ku_sbctc_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    push_to_buff(packed_buffer, 6, 2, sbctc_data->dir_ing);
    push_to_buff(packed_buffer, 8, 8, sbctc_data->local_port);
    push_to_buff(packed_buffer, 27, 1, sbctc_data->res);
    push_to_buff(packed_buffer, 31, 1, sbctc_data->mode);
    push_to_buff(packed_buffer, 32, 1, sbctc_data->en_config);
    push_to_buff(packed_buffer, 62, 2, sbctc_data->event);
    push_to_buff_64(packed_buffer, 64, sbctc_data->tclass_en);
    push_to_buff(packed_buffer, 136, 24, sbctc_data->thr_max);
    push_to_buff(packed_buffer, 168, 24, sbctc_data->thr_max);

    /* return register size in bytes */
    return 4 * SBCTC_REG_SIZE_IN_DWORDS;
}


static void __sbctc_mad_unpack(void* ku_reg_buff, uint8_t* buffer_to_unpack, void* context)
{
    struct ku_sbctc_reg* sbctc_data = (struct ku_sbctc_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    sbctc_data->dir_ing = pop_from_buff(buffer_to_unpack, 6, 2);
    sbctc_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    sbctc_data->mode = pop_from_buff(buffer_to_unpack, 31, 1);
    sbctc_data->res = pop_from_buff(buffer_to_unpack, 27, 1);
    sbctc_data->en_config = pop_from_buff(buffer_to_unpack, 32, 1);
    sbctc_data->event = pop_from_buff(buffer_to_unpack, 62, 2);
    sbctc_data->tclass_en = pop_from_buff_64(buffer_to_unpack, 64);
    sbctc_data->thr_max = pop_from_buff(buffer_to_unpack, 136, 24);
    sbctc_data->thr_max = pop_from_buff(buffer_to_unpack, 168, 24);
}
#endif /* IB_PRESENT_FLAG */

void sxd_reg_sbctc_init()
{
    const struct access_reg_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_SBCTC
    };

#ifdef IB_PRESENT_FLAG
    struct access_reg_mad_params mad_params = {
        .reg_size_in_dwords = SBCTC_REG_SIZE_IN_DWORDS,
        .reg_pack_cb = __sbctc_mad_pack,
        .reg_pack_context = NULL,
        .reg_unpack_cb = __sbctc_mad_unpack,
        .reg_unpack_context = NULL
    };
#endif /* IB_PRESENT_FLAG */

    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __sbctc_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __sbctc_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "sbctc",
        .emad_struct_size = sizeof(sxd_emad_sbctc_reg_t),
        .reg_struct_size = sizeof(struct ku_sbctc_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_SBCTC",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_SBCTC,
        .ctrl_cmd_size = sizeof(struct ku_access_sbctc_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_SBCTC_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
#ifdef IB_PRESENT_FLAG
                           &mad_params,
#else /* IB_PRESENT_FLAG */
                           NULL,
#endif /* IB_PRESENT_FLAG */
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

/* ******************************************************************************************************* */
/* QHLL                                                                                                   */
/* ******************************************************************************************************* */

#define QHLL_REG_SIZE_IN_DWORDS (3)

static sxd_status_t __qhll_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_qhll_reg * qhll_data = (struct ku_qhll_reg*)reg_common_data->reg_data;
    sxd_emad_qhll_reg_t* qhll_reg = (sxd_emad_qhll_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    qhll_reg->local_port = (qhll_data->local_port);
    qhll_reg->lp_msb = (qhll_data->lp_msb & 0x03) << 4;
    qhll_reg->hll_time = qhll_data->hll_time & 0x1F;
    qhll_reg->stall_cnt = qhll_data->stall_cnt & 0x7;
    qhll_reg->stall_en = ((qhll_data->stall_en & 0x1) << 7);

    *reg_size = sizeof(sxd_emad_qhll_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __qhll_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_qhll_reg       * qhll_data = (struct ku_qhll_reg*)reg_common_data->reg_data;
    const sxd_emad_qhll_reg_t* qhll_reg = (const sxd_emad_qhll_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    qhll_data->local_port = qhll_reg->local_port;
    qhll_data->lp_msb = (qhll_reg->lp_msb >> 4) & 0x03;
    qhll_data->hll_time = ((qhll_reg->hll_time) & 0x1F);
    qhll_data->stall_cnt = qhll_reg->stall_cnt & 0x7;
    qhll_data->stall_en = ((qhll_reg->stall_en & 0x80) >> 7);

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_qhll_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __qhll_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __qhll_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "qhll",
        .emad_struct_size = sizeof(sxd_emad_qhll_reg_t),
        .reg_struct_size = sizeof(struct ku_qhll_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_QHLL",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_QHLL,
        .ctrl_cmd_size = sizeof(struct ku_access_qhll_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_QHLL_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

/* ******************************************************************************************************* */
/* QPSC - QoS PTP Shaper Configuration Register                                                            */
/* ******************************************************************************************************* */

#define QPSC_REG_SIZE_IN_DWORDS (11)
static sxd_status_t __qpsc_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    const struct ku_qpsc_reg * qpsc_data = (struct ku_qpsc_reg*)reg_common_data->reg_data;
    sxd_emad_qpsc_reg_t      * qpsc_reg = (sxd_emad_qpsc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    qpsc_reg->port_speed = (qpsc_data->port_speed) & 0xF;
    qpsc_reg->time_exp = (qpsc_data->time_exp) & 0xF;
    qpsc_reg->time_mantissa = (qpsc_data->time_mantissa) & 0x1F;
    qpsc_reg->shaper_inc = (qpsc_data->shaper_inc) & 0x1F;
    qpsc_reg->shaper_bs = (qpsc_data->shaper_bs) & 0x3F;
    qpsc_reg->ptsc_we = (qpsc_data->ptsc_we & 0x1) << 7;
    qpsc_reg->port_to_shaper_credits = (qpsc_data->port_to_shaper_credits) & 0xFF;
    qpsc_reg->ing_timestamp_inc = cl_ntoh32(qpsc_data->ing_timestamp_inc);
    qpsc_reg->egr_timestamp_inc = cl_ntoh32(qpsc_data->egr_timestamp_inc);

    *reg_size = sizeof(sxd_emad_qpsc_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __qpsc_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_qpsc_reg       * qpsc_data = (struct ku_qpsc_reg*)reg_common_data->reg_data;
    const sxd_emad_qpsc_reg_t* qpsc_reg = (const sxd_emad_qpsc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    qpsc_data->time_exp = (qpsc_reg->time_exp) & 0xF;
    qpsc_data->time_mantissa = (qpsc_reg->time_mantissa) & 0x1F;
    qpsc_data->shaper_inc = (qpsc_reg->shaper_inc) & 0x1F;
    qpsc_data->shaper_bs = (qpsc_reg->shaper_bs) & 0x3F;
    qpsc_data->port_to_shaper_credits = (qpsc_reg->port_to_shaper_credits) & 0xFF;
    qpsc_data->ing_timestamp_inc = cl_ntoh32(qpsc_reg->ing_timestamp_inc);
    qpsc_data->egr_timestamp_inc = cl_ntoh32(qpsc_reg->egr_timestamp_inc);
    return SXD_STATUS_SUCCESS;
}

void sxd_reg_qpsc_init(void)
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __qpsc_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __qpsc_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "qpsc",
        .emad_struct_size = sizeof(sxd_emad_qpsc_reg_t),
        .reg_struct_size = sizeof(struct ku_qpsc_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_QPSC",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_QPSC,
        .ctrl_cmd_size = sizeof(struct ku_access_qpsc_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_QPSC_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* MTPPTR                                                                                                   */
/* ******************************************************************************************************* */

#define MTPPTR_REG_SIZE_IN_DWORDS (20)

static sxd_status_t __mtpptr_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                        void                                  * reg_buff,
                                        uint32_t                              * reg_size,
                                        void                                  * context,
                                        sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_mtpptr_reg * mtpptr_data = (struct ku_mtpptr_reg*)reg_common_data->reg_data;
    sxd_emad_mtpptr_reg_t* mtpptr_reg = (sxd_emad_mtpptr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mtpptr_reg->local_port = (mtpptr_data->local_port);
    mtpptr_reg->lp_msb = (mtpptr_data->lp_msb & 0x03) << 4;
    mtpptr_reg->dir = mtpptr_data->dir & 0x01;
    mtpptr_reg->clr_read_one = ((mtpptr_data->clr & 0x01) << 7) | ((mtpptr_data->read_one & 0x01) << 6);

    *reg_size = sizeof(sxd_emad_mtpptr_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __mtpptr_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                          const void                      * reg_buff,
                                          void                            * context,
                                          sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_mtpptr_reg       * mtpptr_data = (struct ku_mtpptr_reg*)reg_common_data->reg_data;
    const sxd_emad_mtpptr_reg_t* mtpptr_reg = (const sxd_emad_mtpptr_reg_t*)reg_buff;
    uint8_t                      i = 0;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mtpptr_data->local_port = mtpptr_reg->local_port;
    mtpptr_data->lp_msb = (mtpptr_reg->lp_msb >> 4) & 0x03;
    mtpptr_data->dir = mtpptr_reg->dir;
    mtpptr_data->ovf = mtpptr_reg->ovf;
    mtpptr_data->num_record = mtpptr_reg->num_record;

    for (i = 0; i < mtpptr_data->num_record; i++) {
        mtpptr_data->records[i].domain_number = mtpptr_reg->records[i].domain_number;
        mtpptr_data->records[i].message_type = mtpptr_reg->records[i].message_type & 0x0F;
        mtpptr_data->records[i].sequence_id = cl_ntoh16(mtpptr_reg->records[i].sequence_id);
        mtpptr_data->records[i].timestamp = cl_ntoh64(mtpptr_reg->records[i].timestamp);
    }

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_mtpptr_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __mtpptr_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __mtpptr_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "mtpptr",
        .emad_struct_size = sizeof(sxd_emad_mtpptr_reg_t),
        .reg_struct_size = sizeof(struct ku_mtpptr_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_MTPPTR",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MTPPTR,
        .ctrl_cmd_size = sizeof(struct ku_access_mtpptr_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_MTPPTR_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}
