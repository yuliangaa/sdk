/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <sx/sxd/sxd_swid.h>
#include <sx/sxd/sxd_access_register.h>
#include "dpt.h"
#include <time.h>
/************************************************
 *  Local variables
 ***********************************************/
#undef  __MODULE__
#define __MODULE__ ACCESS_REG
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;


#define MIN_WINDOW_TIME 16

/************************************************
 *  Global variables
 ***********************************************/
extern sxd_dpt_t *dpt_ptr;
static boolean_t  dpt_unload_in_process = FALSE;

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t dpt_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    SX_LOG_EXIT();
    return err;
}

sxd_status_t dpt_load(void)
{
    int          shmid, err;
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (dpt_unload_in_process == TRUE) {
        /* coverity[lock_order] */
        SX_LOG_ERR("Failed to load DPT due to simultaneous unload process\n");
        return SXD_STATUS_NOT_INITIALIZED;
    }

    err = cl_shm_open(PATH, &shmid);
    if (err) {
        SX_LOG_ERR("Failed to open the DPT shared memory\n");
        return SXD_STATUS_NO_MEMORY;
    }

    dpt_ptr = mmap(NULL, sizeof(sxd_dpt_t), PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
    close(shmid);
    if (dpt_ptr == MAP_FAILED) {
        SX_LOG_ERR("Failed to map the shared memory of the DPT\n");
        return SXD_STATUS_NO_MEMORY;
    }

    if (dpt_ptr->dpt_initialized != DPT_INIT_VAL) {
        SX_LOG_ERR("DPT is not yet initialized\n");
        return SXD_STATUS_NOT_INITIALIZED;
    }

    status = sxd_dpt_set_ref_count(REF_COUNT_INCREMENT);
    if (status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("sxd_dpt_set_ref_count(REF_COUNT_INCREMENT)  failed\n");
        return status;
    }

    return SXD_STATUS_SUCCESS;
}

sxd_status_t dpt_unload(void)
{
    int          err = 0;
    sxd_status_t status = SXD_STATUS_SUCCESS;
    sxd_dpt_t   *tmp_dpt_ptr;

    dpt_unload_in_process = TRUE;
    status = sxd_dpt_set_ref_count(REF_COUNT_DECREMENT);
    if (status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("sxd_dpt_set_ref_count(REF_COUNT_DECREMENT)  failed\n");
        dpt_unload_in_process = FALSE;
        return status;
    }

    tmp_dpt_ptr = dpt_ptr;
    dpt_ptr = NULL;
    err = munmap(tmp_dpt_ptr, sizeof(sxd_dpt_t));
    if (err == -1) {
        SX_LOG_ERR("Failed to unmap the shared memory of the DPT\n");
    }

    dpt_unload_in_process = FALSE;
    return status;
}

#ifdef IB_PRESENT_FLAG
sxd_status_t dpt_translate_local_to_ib_path(sxd_dev_id_t dev_id, sxd_swid_t swid, dr_path_params_t    *local_ports_dr)
{
    int           i;
    ib_dr_path_t *ib_dr_path = &dpt_ptr->table[dev_id][swid].dr_params.drpath;

    memset(ib_dr_path, 0, sizeof(ib_dr_path_t));

    for (i = 0; i < local_ports_dr->dr_path->path_len; i++) {
        int      curr_dev_id = local_ports_dr->dr_path->path_device_id[i];
        uint8_t *map = dpt_ptr->ports_map[curr_dev_id];

        ib_dr_path->p[i + 1] = map[local_ports_dr->dr_path->path_ports[i]];
    }

    ib_dr_path->cnt = i;

    return SXD_STATUS_SUCCESS;
}

#endif /* ifdef IB_PRESENT_FLAG */

sxd_status_t dpt_get_encapsulation(sxd_dev_id_t            dev_id,
                                   sxd_swid_t              swid,
                                   sxd_dpt_group_t         group,
                                   dpt_encapsulation_t    *encapsulation,
                                   internal_path_params_t *params,
                                   boolean_t               check_path)
{
    UNUSED_PARAM(check_path);
    /* DEFAULT_DEVICE_ID always means the local device,
     * and we always access it using CMD_IFC */
    if (sxd_cr_mode() || DEFAULT_DEVICE_ID_CHECK(dev_id)) {
        *encapsulation = CMD_IFC_PATH;
        return SXD_STATUS_SUCCESS;
    }

    if (swid > SXD_SWID_MAX) {
        if ((swid != SWID_NUM_DONT_CARE) && (swid != SXD_SWID_ID_STACKING)) {
            return SXD_STATUS_PARAM_ERROR;
        }
        swid = 0;
    }
    cl_plock_acquire(&dpt_ptr->p_lock);

    switch (group) {
    case FIRST_GROUP:
        *encapsulation = dpt_ptr->table[dev_id][swid].first_set_path;
        if (*encapsulation == EMAD_PATH) {
            params->sys_port =
                dpt_ptr->table[dev_id][swid].sys_port_params.sys_port;
        }
        break;

#if defined(IB_PRESENT_FLAG) || defined(IB_NVLINK_FLAG)
    case SECOND_GROUP:
        *encapsulation = dpt_ptr->table[dev_id][swid].second_set_path;
        if (*encapsulation == MAD_PATH) {
            memcpy(&params->dr_params,
                   &dpt_ptr->table[dev_id][swid].dr_params,
                   sizeof(params->dr_params));
        }
        break;

#endif
    case THIRD_GROUP:
        *encapsulation = dpt_ptr->table[dev_id][swid].third_set_path;
        if (*encapsulation == EMAD_PATH) {
            (*params).sys_port =
                dpt_ptr->table[dev_id][swid].sys_port_params.sys_port;
        }
        break;

    default:
        *encapsulation = INVALID_PATH;
    }

    cl_plock_release(&dpt_ptr->p_lock);


    return SXD_STATUS_SUCCESS;
}

sxd_status_t dpt_get_swid_type(sxd_swid_t swid, swid_type_t *type)
{
    if (swid > SXD_SWID_MAX) {
        swid = 0;
    }
    cl_plock_acquire(&dpt_ptr->p_lock);

    *type = dpt_ptr->swid_type[swid];

    cl_plock_release(&dpt_ptr->p_lock);
    return SXD_STATUS_SUCCESS;
}

sxd_status_t dpt_set_system_m_key(sxd_dev_id_t dev_id, uint64_t *system_m_key)
{
    if (dev_id > SXD_DEV_ID_MAX) {
        SX_LOG_ERR("dev_id %d exceed range [0..%d]\n",
                   dev_id, SXD_DEV_ID_MAX);
        return SXD_STATUS_PARAM_ERROR;
    }
    cl_plock_acquire(&dpt_ptr->p_lock);

    dpt_ptr->system_m_key[dev_id] = *system_m_key;

    cl_plock_release(&dpt_ptr->p_lock);
    return SXD_STATUS_SUCCESS;
}

sxd_status_t dpt_get_system_m_key(sxd_dev_id_t dev_id, uint64_t *system_m_key)
{
    if (dev_id > SXD_DEV_ID_MAX) {
        SX_LOG_ERR("dev_id %d exceed range [0..%d]\n",
                   dev_id, SXD_DEV_ID_MAX);
        return SXD_STATUS_PARAM_ERROR;
    }
    cl_plock_acquire(&dpt_ptr->p_lock);

    *system_m_key = dpt_ptr->system_m_key[dev_id];

    cl_plock_release(&dpt_ptr->p_lock);
    return SXD_STATUS_SUCCESS;
}
