/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __ACCESS_REGISTER_MAD_H__
#define __ACCESS_REGISTER_MAD_H__

#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_registers.h>
#include <complib/sx_log.h>
#include <infiniband/mad.h>
#include "dpt.h"


#ifdef SXD_ACCESS_REGISTER_MAD_C_

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

#endif

/************************************************
 *  Defines
 ***********************************************/

#define IB_ATTR_ACCESS_REG 0xff52
#define IB_ATTR_CABLE_INFO 0xff60
#ifdef PD_BU
#define IB_ACCESS_REG_TIMEOUT 250000 /*500*/       /* in ms */
#else
#define IB_ACCESS_REG_TIMEOUT 500       /* in ms */
#endif


#define TLV_OPERATION_SIZE       sizeof(struct TLV_OPERATION)
#define TLV_REG_SIZE             sizeof(struct TLV_REG)
#define TLV_OPERATION_DWORD_SIZE 4

#define TLV_OPERATION_R_REQUEST  0
#define TLV_OPERATION_R_RESPONSE 1

#define ACCESS_REG_CLASS_ID 1

#define MAX_REG_SIZE_IN_MAD   44
#define REG_SIZE_DWORDS_MTBR  11 /* That's the maximum possible reg size for a mad */
#define REG_SIZE_DWORDS_MFSM  2
#define REG_SIZE_DWORDS_PTYS  11 /* That's the maximum possible reg size for a mad */
#define REG_SIZE_DWORDS_PMLP  11 /* That's the maximum possible reg size for a mad */
#define REG_SIZE_DWORDS_PSPA  2
#define REG_SIZE_DWORDS_PLIB  4
#define REG_SIZE_DWORDS_PPLM  16
#define REG_SIZE_DWORDS_PLPC  10
#define REG_SIZE_DWORDS_PMPC  8
#define REG_SIZE_DWORDS_RTPS  2
#define REG_SIZE_DWORDS_RTCA  4
#define REG_SIZE_DWORDS_RTAR  8
#define REG_SIZE_DWORDS_RATR  10
#define REG_SIZE_DWORDS_RDPM  2
#define REG_SIZE_DWORDS_RRCR  4
#define REG_SIZE_DWORDS_RICA  4
#define REG_SIZE_DWORDS_RCAP  2
#define REG_SIZE_DWORDS_RGCR  8
#define REG_SIZE_DWORDS_RECR  4
#define REG_SIZE_DWORDS_MJTAG 11 /* That's the maximum possible reg size for a mad */
#define REG_SIZE_DWORDS_PMPR  4
#define REG_SIZE_DWORDS_MFPA  8
#define REG_SIZE_DWORDS_MFBA  11 /* That's the maximum possible reg size for a mad */
#define REG_SIZE_DWORDS_MFBE  11 /* That's the maximum possible reg size for a mad */
#define REG_SIZE_DWORDS_PELC  10
#define REG_SIZE_DWORDS_PPSC  11 /* That's the maximum possible reg size for a mad */
#define REG_SIZE_DWORDS_QPBR  4
#define REG_SIZE_DWORDS_QPCR  10
#define REG_SIZE_DWORDS_PLBF  2
#define REG_SIZE_DWORDS_MSCI  4
#define REG_SIZE_DWORDS_MLCR  3
#define REG_SIZE_DWORDS_MPSC  5

#define MTBR_MAX_TEMPERATURE_RECORD 7

/************************************************
 *  Macros
 ***********************************************/

/************************************************
 *  Type definitions
 ***********************************************/

/*************************************/
/* Name: REG_PTYS
 * Size: 352 bits
 * Description: REG_PTYS */

struct REG_PTYS {
    uint8_t  proto_mask;    /* bit_offset:0 */    /* element_size: 3 */
    uint16_t reserved0;    /* bit_offset:3 */    /* element_size: 13 */
    uint8_t  local_port;    /* bit_offset:16 */    /* element_size: 8 */
    uint8_t  reserved1;    /* bit_offset:24 */    /* element_size: 8 */
    uint32_t reserved2;    /* bit_offset:32 */    /* element_size: 32 */
    uint32_t ext_eth_proto_capability;    /* bit_offset:64 */    /* element_size: 32 */
    uint32_t eth_proto_capability;    /* bit_offset:96 */    /* element_size: 32 */
    uint32_t ib_proto_capability;    /* bit_offset:128 */    /* element_size: 32 */
    uint32_t ext_eth_proto_admin;    /* bit_offset:160 */    /* element_size: 32 */
    uint32_t eth_proto_admin;    /* bit_offset:192 */    /* element_size: 32 */
    uint32_t ib_proto_admin;    /* bit_offset:224 */    /* element_size: 32 */
    uint32_t ext_eth_proto_oper;    /* bit_offset:256 */    /* element_size: 32 */
    uint32_t eth_proto_oper;    /* bit_offset:288 */    /* element_size: 32 */
    uint32_t ib_proto_oper;    /* bit_offset:320 */    /* element_size: 32 */
};

/*************************************/
/* Name: TLV_REG
 * Size: 32 bits
 * Description: TLV_REG */

typedef struct TLV_REG {
    uint16_t reserved0;    /* bit_offset:0 */    /* element_size: 16 */
    uint16_t len;    /* bit_offset:16 */    /* element_size: 11 */
    uint8_t  type;    /* bit_offset:27 */    /* element_size: 5 */
} tlv_reg_t;

/*************************************/
/* Name: TLV_OPERATION
 * Size: 128 bits
 * Description: TLV_OPERATION */

typedef struct TLV_OPERATION {
    uint8_t  reserved0;    /* bit_offset:0 */    /* element_size: 8 */
    uint8_t  status;    /* bit_offset:8 */    /* element_size: 7 */
    uint8_t  dr;    /* bit_offset:15 */    /* element_size: 1 */
    uint16_t len;    /* bit_offset:16 */    /* element_size: 11 */
    uint8_t  type;    /* bit_offset:27 */    /* element_size: 5 */
    uint8_t  class;    /* bit_offset:32 */    /* element_size: 8 */
    uint8_t  method;    /* bit_offset:40 */    /* element_size: 7 */
    uint8_t  r;    /* bit_offset:47 */    /* element_size: 1 */
    uint16_t register_id;    /* bit_offset:48 */    /* element_size: 16 */
    uint64_t tid;    /* bit_offset:64 */    /* element_size: 64 */
} tlv_operation_t;

typedef enum {
    TLV_TYPE_END_E,
    TLV_TYPE_OPERATION_E,
    TLV_TYPE_DR_E,
    TLV_TYPE_REG_E,
    TLV_TYPE_USER_DATA_E
} tlv_type_e;

typedef enum {
    TLV_OP_METHOD_QUERY_E = 1,
    TLV_OP_METHOD_WRITE_E = 2,
    TLV_OP_METHOD_SEND_E  = 3,
    TLV_OP_METHOD_EVENT_E = 5
} tlv_operarion_method_e;

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Function declarations
 ***********************************************/

sxd_status_t dpt_mad_log_verbosity_level(IN sxd_access_cmd_t      cmd,
                                         IN sx_verbosity_level_t *verbosity_level_p);

sxd_status_t mad_get_ptys_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ptys_reg           *reg_ptys);

sxd_status_t mad_set_ptys_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ptys_reg           *reg_ptys);

sxd_status_t mad_get_mtbr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mtbr_reg           *reg_mtbr);

sxd_status_t mad_set_mtbr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mtbr_reg           *reg_mtbr);

sxd_status_t mad_get_pmlp_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmlp_reg           *reg_pmlp);

sxd_status_t mad_set_pmlp_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmlp_reg           *reg_pmlp);

sxd_status_t mad_get_pspa_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pspa_reg           *reg_pspa);

sxd_status_t mad_set_pspa_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pspa_reg           *reg_pspa);

sxd_status_t mad_get_plib_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plib_reg           *reg_plib);

sxd_status_t mad_set_plib_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plib_reg           *reg_plib);

sxd_status_t mad_get_pplm_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pplm_reg           *reg_pplm);

sxd_status_t mad_set_pplm_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pplm_reg           *reg_pplm);

sxd_status_t mad_get_mpsc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mpsc_reg           *reg_mpsc);

sxd_status_t mad_set_mpsc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mpsc_reg           *reg_mpsc);

sxd_status_t mad_get_plpc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plpc_reg           *reg_plpc);

sxd_status_t mad_set_plpc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plpc_reg           *reg_plpc);

sxd_status_t mad_get_pmpc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmpc_reg           *reg_pmpc);

sxd_status_t mad_set_pmpc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmpc_reg           *reg_pmpc);

sxd_status_t mad_get_mjtag_reg(struct ibmad_port           * sport,
                               sxd_dev_id_t                  dev_id,
                               internal_ib_dr_path_params_t *dr_path_params,
                               struct ku_mjtag_reg          *reg_mjtag);

sxd_status_t mad_set_mjtag_reg(struct ibmad_port           * sport,
                               sxd_dev_id_t                  dev_id,
                               internal_ib_dr_path_params_t *dr_path_params,
                               struct ku_mjtag_reg          *reg_mjtag);

sxd_status_t mad_get_ppsc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ppsc_reg           *reg_ppsc);

sxd_status_t mad_set_ppsc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ppsc_reg           *reg_ppsc);

sxd_status_t mad_get_pelc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pelc_reg          * reg_pelc);

sxd_status_t mad_set_pelc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pelc_reg          * reg_pelc);

sxd_status_t mad_set_pmpr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmpr_reg           *reg_pmpr);

sxd_status_t mad_get_pmpr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmpr_reg           *reg_pmpr);

sxd_status_t mad_get_mfpa_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfpa_reg           *reg_mfpa);

sxd_status_t mad_set_mfpa_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfpa_reg           *reg_mfpa);

sxd_status_t mad_get_mfba_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfba_reg           *reg_mfba);

sxd_status_t mad_set_mfba_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfba_reg           *reg_mfba);

sxd_status_t mad_get_mfbe_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfbe_reg           *reg_mfba);

sxd_status_t mad_set_mfbe_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfbe_reg           *reg_mfba);

sxd_status_t mad_get_rtps_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtps_reg           *reg_rtps);

sxd_status_t mad_set_rtps_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtps_reg           *reg_rtps);

sxd_status_t mad_get_rtca_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtca_reg           *reg_rtca);

sxd_status_t mad_set_rtca_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtca_reg           *reg_rtca);

sxd_status_t mad_get_ratr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ratr_reg           *reg_ratr);

sxd_status_t mad_set_ratr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ratr_reg           *reg_ratr);

sxd_status_t mad_get_rtar_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtar_reg           *reg_rtar);

sxd_status_t mad_set_rtar_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtar_reg           *reg_rtar);

sxd_status_t mad_get_rica_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rica_reg           *reg_rica);

sxd_status_t mad_set_rica_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rica_reg           *reg_rica);

sxd_status_t mad_get_rrcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rrcr_reg           *reg_rrcr);

sxd_status_t mad_set_rrcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rrcr_reg           *reg_rrcr);

sxd_status_t mad_get_rdpm_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rdpm_reg           *reg_rdpm);

sxd_status_t mad_set_rdpm_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rdpm_reg           *reg_rdpm);

sxd_status_t mad_get_rcap_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rcap_reg           *reg_rcap);

sxd_status_t mad_set_rcap_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rcap_reg           *reg_rcap);

sxd_status_t mad_get_rgcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rgcr_reg           *reg_rgcr);

sxd_status_t mad_set_rgcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rgcr_reg           *reg_rgcr);

sxd_status_t mad_get_recr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_recr_reg           *reg_recr);

sxd_status_t mad_set_recr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_recr_reg           *reg_recr);

sxd_status_t mad_get_qpbr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_qpbr_reg           *reg_qpbr);

sxd_status_t mad_set_qpbr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_qpbr_reg           *reg_qpbr);

sxd_status_t mad_get_qpcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_qpcr_reg           *reg_qpcr);

sxd_status_t mad_set_qpcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_qpcr_reg           *reg_qpcr);


sxd_status_t mad_get_plbf_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plbf_reg           *reg_plbf);
sxd_status_t mad_set_plbf_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plbf_reg           *reg_qpbr);

sxd_status_t mad_get_sgcr_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_sgcr_reg           *reg_sgcr);

sxd_status_t mad_set_sgcr_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_sgcr_reg           *reg_sgcr);

sxd_status_t mad_get_msci_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_msci_reg           *reg_sgcr);

sxd_status_t mad_set_msci_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_msci_reg           *reg_sgcr);

sxd_status_t mad_get_mcia_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mcia_reg           *reg_mcia);

sxd_status_t mad_set_mcia_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mcia_reg           *reg_mcia);

sxd_status_t mad_get_raw_reg(struct ibmad_port           * sport,
                             sxd_dev_id_t                  dev_id,
                             internal_ib_dr_path_params_t *dr_path_params,
                             uint16_t                      register_id,
                             struct ku_raw_reg            *reg_raw);

sxd_status_t mad_set_raw_reg(struct ibmad_port           * sport,
                             sxd_dev_id_t                  dev_id,
                             internal_ib_dr_path_params_t *dr_path_params,
                             uint16_t                      register_id,
                             struct ku_raw_reg            *reg_raw);

sxd_status_t mad_get_mlcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mlcr_reg           *reg_mlcr);

sxd_status_t mad_set_mlcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mlcr_reg           *reg_mlcr);


uint64_t pop_from_buff_64(const uint8_t *buff, uint32_t bit_offset);
uint32_t pop_from_buff_32(const uint8_t *buff, uint32_t bit_offset);
uint32_t pop_from_buff(const uint8_t *buff, uint32_t bit_offset, uint32_t field_size);
void push_to_buff_64(uint8_t *buff, uint32_t bit_offset, uint64_t field_value);
void push_to_buff_32(uint8_t *buff, uint32_t bit_offset, uint32_t field_value);
void push_to_buff(uint8_t *buff, uint32_t bit_offset, uint32_t field_size, uint32_t field_value);

struct access_reg_mad_params;
sxd_status_t sxd_command_mad_access_reg(struct ibmad_port           * sport,
                                        sxd_dev_id_t                  dev_id,
                                        internal_ib_dr_path_params_t *dr_path_params,
                                        sxd_reg_id_e                  reg_id,
                                        tlv_operarion_method_e        tlv_op_method,
                                        void                         *ku_reg_buff,
                                        struct access_reg_mad_params *mad_params);

#endif /* ifndef __ACCESS_REGISTER_MAD_H__ */
