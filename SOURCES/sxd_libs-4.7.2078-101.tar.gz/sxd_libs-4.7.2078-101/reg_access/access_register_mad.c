/*
 * Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <errno.h>
#include <stdio.h>
#include <sys/types.h>
#include <stdint.h>
#include <endian.h>
#include <unistd.h>
#include <complib/cl_mem.h>
#include <sx/sxd/sxd_emad_status.h>
#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_status.h>
#include <sx/sxd/sxd_dev.h>
#include <sx/sxd/sxdev.h>
#include <sx/sxd/kernel_user.h>
#include <sx/sxd/sxd_access_register.h>
#include <reg_access/sxd_access_reg_infra.h>
#include "access_register_mad.h"
#include "../common/sxd_utils.h"

/************************************************
 *  MACROS
 ***********************************************/
#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif
/* Bit manipulation macros */

/* MASK generate a bit mask S bits width */
/* #define MASK32(S)     ( ((uint32_t) ~0L) >> (32-(S)) ) */
#define MASK8(S) (((uint8_t) ~0) >> (8 - (S)))

/* BITS generate a bit mask with bits O+S..O set (assumes 32 / 8 bit integer) */
/* #define BITS32(O,S)   ( MASK32(S) << (O) ) */
#define BITS8(O, S) (MASK8(S) << (O))

/* EXTRACT32/8 macro extracts S bits from (uint32_t/uint8_t)W with offset O
 * and shifts them O places to the right (right justifies the field extracted) */
/* #define EXTRACT32(W,O,S)  ( ((W)>>(O)) & MASK32(S) ) */
#define EXTRACT8(W, O, S) (((W) >> (O)) & MASK8(S))


/* INSERT32/8 macro inserts S bits with offset O from field F into word W (uint32_t/uint8_t) */
/* #define INSERT32(W,F,O,S)     ((W)= ( ( (W) & (~BITS32(O,S)) ) | (((F) & MASK32(S))<<(O)) )) */
#define INSERT8(W, F, O, S) ((W) = (((W)&(~BITS8(O, S))) | (((F)&MASK8(S)) << (O))))

/* #define INSERTF_32(W,O1,F,O2,S)   (INSERT32(W, EXTRACT32(F, O2, S), O1, S) ) */
#define INSERTF_8(W, O1, F, O2, S) (INSERT8(W, EXTRACT8(F, O2, S), O1, S))

#define PTR_64_OF_BUFF(buf, offset)   ((uint64_t*)((uint8_t*)(buf) + (offset)))
#define PTR_32_OF_BUFF(buf, offset)   ((uint32_t*)((uint8_t*)(buf) + (offset)))
#define PTR_8_OF_BUFF(buf, offset)    ((uint8_t*)((uint8_t*)(buf) + (offset)))
#define FIELD_64_OF_BUFF(buf, offset) (*PTR_64_OF_BUFF(buf, offset))
#define FIELD_32_OF_BUFF(buf, offset) (*PTR_32_OF_BUFF(buf, offset))
#define FIELD_8_OF_BUFF(buf, offset)  (*PTR_8_OF_BUFF(buf, offset))
#define DWORD_N(buf, n)               FIELD_32_OF_BUFF((buf), (n) * 4)
#define BYTE_N(buf, n)                FIELD_8_OF_BUFF((buf), (n))

#if __BYTE_ORDER == __LITTLE_ENDIAN
#define BE64_TO_CPU(x)                                       \
    (((uint64_t)ntohl((uint32_t)((x) & 0xffffffff)) << 32) | \
     ((uint64_t)ntohl((uint32_t)((x >> 32) & 0xffffffff))))
#else
#define BE64_TO_CPU(x) (x)
#endif

#define CPU_TO_BE64(x) BE64_TO_CPU(x)

/************************************************
 *  Local variables
 ***********************************************/
#undef  __MODULE__
#define __MODULE__ ACCESS_REG_MAD
static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;

/************************************************
 *  Global variables
 ***********************************************/
/* Used to store the info is ibmad library was already initialized
 * for the specific user. It cannot be initialized in sxd_access_reg_init
 * because hwd calls it before IB swid is enabled */
extern sxd_access_reg_hw_t *hw_p;
extern sxd_dpt_t           *dpt_ptr;

/************************************************
 *  Local function declarations
 ***********************************************/

typedef struct port_speed_state {
    uint16_t  local_port_num;
    uint8_t   link_width_enabled;
    uint8_t   link_width_supported;
    uint8_t   link_width_active;
    uint8_t   link_speed_supported;
    uint8_t   link_speed_enabled;
    uint8_t   link_speed_active;
    uint8_t   port_logical_state; /* PortState */
    uint8_t   port_phy_state;
    uint8_t   link_down_default_state;
    uint8_t   mtu_cap; /* max MTU supported by this port */
    uint8_t   neighbor_mtu; /* active transmit max MTU for this port */
    uint8_t   vl_cap;
    uint8_t   oper_vl;
    u_int16_t lid;
} port_speed_state_t;

/************************************************
 *  Function implementations
 ***********************************************/

sxd_status_t dpt_mad_log_verbosity_level(sxd_access_cmd_t cmd, sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    SX_LOG_EXIT();

    return err;
}

uint64_t pop_from_buff_64(const uint8_t *buff, uint32_t bit_offset)
{
#if defined(__ia64__)
    uint64_t value = 0;
    memcpy(&value, PTR_32_OF_BUFF(buff, (bit_offset / 8)), sizeof(u_int64_t));
    return (BE64_TO_CPU(value));
#else
    return (BE64_TO_CPU(FIELD_64_OF_BUFF(buff, (bit_offset / 8))));
#endif
}


uint32_t pop_from_buff_32(const uint8_t *buff, uint32_t bit_offset)
{
    return (ntohl(FIELD_32_OF_BUFF(buff, (bit_offset / 8))));
}

uint32_t pop_from_buff(const uint8_t *buff, uint32_t bit_offset, uint32_t field_size)
{
    uint32_t i = 0;
    uint32_t byte_n = bit_offset / 8;
    uint32_t byte_n_offset = bit_offset % 8;
    uint32_t field_32 = 0;
    uint32_t to_pop;

    while (i < field_size) {
        to_pop = MIN(8 - byte_n_offset, field_size - i);
        i += to_pop;
        INSERTF_8(field_32, field_size - i, BYTE_N(buff, byte_n), 8 - to_pop - byte_n_offset, to_pop);
        byte_n_offset = 0;  /* (byte_n_offset + to_pop) % 8; */
        byte_n++;
    }

    return field_32;
}

void push_to_buff_64(uint8_t *buff, uint32_t bit_offset, uint64_t field_value)
{
#if defined(__ia64__)
    uint32_t *buffer = PTR_32_OF_BUFF(buff, (bit_offset / 8));
    uint64_t  value = CPU_TO_BE64(field_value);
    memcpy(buffer, &value, sizeof(value));
#else
    uint64_t *buffer = PTR_64_OF_BUFF(buff, (bit_offset / 8));
    memcpy(buffer, &field_value, sizeof(field_value));
    *buffer = CPU_TO_BE64(*buffer);
#endif
}

void push_to_buff_32(uint8_t *buff, uint32_t bit_offset, uint32_t field_value)
{
    uint32_t *buffer = PTR_32_OF_BUFF(buff, (bit_offset / 8));

    memcpy(buffer, &field_value, sizeof(field_value));
    *buffer = htonl(*buffer);
}

void push_to_buff(uint8_t *buff, uint32_t bit_offset, uint32_t field_size, uint32_t field_value)
{
    uint32_t i = 0;
    uint32_t byte_n = bit_offset / 8;
    uint32_t byte_n_offset = bit_offset % 8;
    uint32_t to_push;

    while (i < field_size) {
        to_push = MIN(8 - byte_n_offset, field_size - i);
        i += to_push;
        INSERTF_8(BYTE_N(buff, byte_n), 8 - to_push - byte_n_offset, field_value, field_size - i, to_push);
        byte_n_offset = 0;  /* (byte_n_offset + to_push) % 8; */
        byte_n++;
    }
}

uint32_t REG_MTBR_pack(struct ku_mtbr_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 20, 12, data_to_pack->base_sensor_index);
    push_to_buff(packed_buffer, 56, 8, data_to_pack->num_rec);

    return 20;
}

void REG_MTBR_unpack(struct ku_mtbr_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    int      i = 0;
    uint16_t mtbr_max_temperature = 0;
    uint16_t mtbr_temperature = 0;

    while (i < unpacked_data->num_rec) {
        mtbr_max_temperature = pop_from_buff(buffer_to_unpack, 128 + (i * 32), 16);
        mtbr_temperature = pop_from_buff(buffer_to_unpack, 144 + (i * 32), 16);
        unpacked_data->temperature_record[i].max_temperature = mtbr_max_temperature;
        unpacked_data->temperature_record[i].temperature = mtbr_temperature;
        i++;
        if (i >= MTBR_MAX_TEMPERATURE_RECORD) {
            unpacked_data->num_rec = MTBR_MAX_TEMPERATURE_RECORD;
            break;
        }
    }
}

uint32_t REG_PMLP_pack(struct ku_pmlp_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 8, 8, data_to_pack->local_port);
    push_to_buff(packed_buffer, 18, 2, data_to_pack->lp_msb);
    push_to_buff(packed_buffer, 24, 8, data_to_pack->width);
    push_to_buff(packed_buffer, 46, 2, data_to_pack->lane[0]);
    push_to_buff(packed_buffer, 52, 4, data_to_pack->slot[0]);
    push_to_buff(packed_buffer, 56, 8, data_to_pack->module[0]);
    push_to_buff(packed_buffer, 78, 2, data_to_pack->lane[1]);
    push_to_buff(packed_buffer, 84, 4, data_to_pack->slot[1]);
    push_to_buff(packed_buffer, 88, 8, data_to_pack->module[1]);
    push_to_buff(packed_buffer, 110, 2, data_to_pack->lane[2]);
    push_to_buff(packed_buffer, 116, 4, data_to_pack->slot[2]);
    push_to_buff(packed_buffer, 120, 8, data_to_pack->module[2]);
    push_to_buff(packed_buffer, 142, 2, data_to_pack->lane[3]);
    push_to_buff(packed_buffer, 148, 4, data_to_pack->slot[3]);
    push_to_buff(packed_buffer, 152, 8, data_to_pack->module[3]);

    return 44;
}

void REG_PMLP_unpack(struct ku_pmlp_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 18, 2);
    unpacked_data->width = pop_from_buff(buffer_to_unpack, 24, 8);
    unpacked_data->lane[0] = pop_from_buff(buffer_to_unpack, 46, 2);
    unpacked_data->slot[0] = pop_from_buff(buffer_to_unpack, 52, 4);
    unpacked_data->module[0] = pop_from_buff(buffer_to_unpack, 56, 8);
    unpacked_data->lane[1] = pop_from_buff(buffer_to_unpack, 78, 2);
    unpacked_data->slot[1] = pop_from_buff(buffer_to_unpack, 84, 4);
    unpacked_data->module[1] = pop_from_buff(buffer_to_unpack, 88, 8);
    unpacked_data->lane[2] = pop_from_buff(buffer_to_unpack, 110, 2);
    unpacked_data->slot[2] = pop_from_buff(buffer_to_unpack, 116, 4);
    unpacked_data->module[2] = pop_from_buff(buffer_to_unpack, 120, 8);
    unpacked_data->lane[3] = pop_from_buff(buffer_to_unpack, 142, 2);
    unpacked_data->slot[3] = pop_from_buff(buffer_to_unpack, 148, 4);
    unpacked_data->module[3] = pop_from_buff(buffer_to_unpack, 152, 8);
}

uint32_t REG_PTYS_pack(struct ku_ptys_reg *data_to_pack, u_int8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 1, 1, data_to_pack->an_disable_admin);
    push_to_buff(packed_buffer, 7, 1, data_to_pack->force_tx_aba_param);
    push_to_buff(packed_buffer, 8, 8, data_to_pack->local_port);
    push_to_buff(packed_buffer, 26, 2, data_to_pack->lp_msb);
    push_to_buff(packed_buffer, 29, 3, data_to_pack->proto_mask);
    push_to_buff_32(packed_buffer, 160, data_to_pack->ext_eth_proto_admin);
    push_to_buff_32(packed_buffer, 192, data_to_pack->eth_proto_admin);
    push_to_buff(packed_buffer, 224, 16, data_to_pack->ib_link_width_admin);
    push_to_buff(packed_buffer, 240, 16, data_to_pack->ib_proto_admin);

    return 44;
}

void REG_PTYS_unpack(struct ku_ptys_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->an_disable_admin = pop_from_buff(buffer_to_unpack, 1, 1);
    unpacked_data->an_disable_cap = pop_from_buff(buffer_to_unpack, 2, 1);
    unpacked_data->force_tx_aba_param = pop_from_buff(buffer_to_unpack, 7, 1);
    unpacked_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 26, 2);
    unpacked_data->proto_mask = pop_from_buff(buffer_to_unpack, 29, 3);
    unpacked_data->an_status = pop_from_buff(buffer_to_unpack, 32, 4);
    unpacked_data->data_rate_oper = pop_from_buff(buffer_to_unpack, 48, 16);
    unpacked_data->ext_eth_proto_capability = pop_from_buff_32(buffer_to_unpack, 64);
    unpacked_data->eth_proto_capability = pop_from_buff_32(buffer_to_unpack, 96);
    unpacked_data->ib_link_width_capability = pop_from_buff(buffer_to_unpack, 128, 16);
    unpacked_data->ib_proto_capability = pop_from_buff(buffer_to_unpack, 144, 16);
    unpacked_data->ext_eth_proto_admin = pop_from_buff_32(buffer_to_unpack, 160);
    unpacked_data->eth_proto_admin = pop_from_buff_32(buffer_to_unpack, 192);
    unpacked_data->ib_link_width_admin = pop_from_buff(buffer_to_unpack, 224, 16);
    unpacked_data->ib_proto_admin = pop_from_buff(buffer_to_unpack, 240, 16);
    unpacked_data->ext_eth_proto_oper = pop_from_buff_32(buffer_to_unpack, 256);
    unpacked_data->eth_proto_oper = pop_from_buff_32(buffer_to_unpack, 288);
    unpacked_data->ib_link_width_oper = pop_from_buff(buffer_to_unpack, 320, 16);
    unpacked_data->ib_proto_oper = pop_from_buff(buffer_to_unpack, 336, 16);
    unpacked_data->eth_proto_lp_valid = pop_from_buff(buffer_to_unpack, 352, 1);
    unpacked_data->eth_proto_lp_advertise = pop_from_buff_32(buffer_to_unpack, 384);
    /* MAD access is limited to 11 * 32bits register access */
}

uint32_t REG_PSPA_pack(struct ku_pspa_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 0, 8, data_to_pack->swid);
    push_to_buff(packed_buffer, 8, 8, data_to_pack->local_port);
    push_to_buff(packed_buffer, 16, 8, data_to_pack->sub_port);
    push_to_buff(packed_buffer, 30, 2, data_to_pack->lp_msb);

    return 8;
}

void REG_PSPA_unpack(struct ku_pspa_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->swid = pop_from_buff(buffer_to_unpack, 0, 8);
    unpacked_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->sub_port = pop_from_buff(buffer_to_unpack, 16, 8);
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 30, 2);
}

uint32_t REG_PLIB_pack(struct ku_plib_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 8, 8, data_to_pack->local_port);
    push_to_buff(packed_buffer, 18, 2, data_to_pack->lp_msb);
    push_to_buff(packed_buffer, 24, 8, data_to_pack->ib_port);

    return 16;
}

void REG_PLIB_unpack(struct ku_plib_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 18, 2);
    unpacked_data->ib_port = pop_from_buff(buffer_to_unpack, 24, 8);
}


uint32_t REG_PPLM_pack(struct ku_pplm_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 8, 8, data_to_pack->local_port);
    push_to_buff(packed_buffer, 18, 2, data_to_pack->lp_msb);
    push_to_buff(packed_buffer, 64, 8, data_to_pack->port_profile_mode);
    push_to_buff(packed_buffer, 72, 8, data_to_pack->static_port_profile);
    push_to_buff(packed_buffer, 80, 8, data_to_pack->active_port_profile);
    push_to_buff(packed_buffer, 96, 8, data_to_pack->retransmission_active);
    push_to_buff(packed_buffer, 104, 24, data_to_pack->fec_mode_active);
    push_to_buff(packed_buffer, 448, 16, data_to_pack->ib_fec_override_admin_hdr);
    push_to_buff(packed_buffer, 464, 16, data_to_pack->ib_fec_override_admin_edr);
    push_to_buff(packed_buffer, 480, 16, data_to_pack->ib_fec_override_admin_fdr);
    push_to_buff(packed_buffer, 528, 16, data_to_pack->ib_fec_override_admin_ndr);
    push_to_buff(packed_buffer, 624, 16, data_to_pack->ib_fec_override_admin_xdr);

    return 16;
}

void REG_PPLM_unpack(struct ku_pplm_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 18, 2);
    unpacked_data->port_profile_mode = pop_from_buff(buffer_to_unpack, 64, 8);
    unpacked_data->static_port_profile = pop_from_buff(buffer_to_unpack, 72, 8);
    unpacked_data->active_port_profile = pop_from_buff(buffer_to_unpack, 80, 8);
    unpacked_data->retransmission_active = pop_from_buff(buffer_to_unpack, 96, 8);
    unpacked_data->fec_mode_active = pop_from_buff(buffer_to_unpack, 104, 24);
    unpacked_data->ib_fec_override_admin_hdr = pop_from_buff(buffer_to_unpack, 448, 16);
    unpacked_data->ib_fec_override_admin_edr = pop_from_buff(buffer_to_unpack, 464, 16);
    unpacked_data->ib_fec_override_admin_fdr = pop_from_buff(buffer_to_unpack, 480, 16);
    unpacked_data->ib_fec_override_admin_ndr = pop_from_buff(buffer_to_unpack, 528, 16);
    unpacked_data->ib_fec_override_admin_xdr = pop_from_buff(buffer_to_unpack, 624, 16);
}

uint32_t REG_MPSC_pack(struct ku_mpsc_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 8, 8, data_to_pack->local_port);
    push_to_buff(packed_buffer, 18, 2, data_to_pack->lp_msb);
    push_to_buff(packed_buffer, 32, 1, data_to_pack->clear_count);
    push_to_buff(packed_buffer, 33, 1, data_to_pack->enable);
    push_to_buff(packed_buffer, 34, 1, data_to_pack->cong);
    push_to_buff(packed_buffer, 64, 32, data_to_pack->rate);
    push_to_buff_64(packed_buffer, 96, data_to_pack->count_drops);

    return 20;
}

void REG_MPSC_unpack(struct ku_mpsc_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 18, 2);
    unpacked_data->clear_count = pop_from_buff(buffer_to_unpack, 32, 1);
    unpacked_data->enable = pop_from_buff(buffer_to_unpack, 33, 1);
    unpacked_data->cong = pop_from_buff(buffer_to_unpack, 34, 1);
    unpacked_data->rate = pop_from_buff(buffer_to_unpack, 64, 32);
    unpacked_data->count_drops = pop_from_buff_64(buffer_to_unpack, 96);
}

uint32_t REG_PLPC_pack(struct ku_plpc_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 4, 12, data_to_pack->profile_id);
    push_to_buff(packed_buffer, 20, 4, data_to_pack->proto_mask);
    push_to_buff(packed_buffer, 48, 16, data_to_pack->lane_speed);
    push_to_buff(packed_buffer, 87, 1, data_to_pack->lpbf);
    push_to_buff(packed_buffer, 88, 8, data_to_pack->fec_mode_policy);
    push_to_buff(packed_buffer, 96, 8, data_to_pack->retransmission_capability);
    push_to_buff(packed_buffer, 104, 24, data_to_pack->fec_mode_capability);
    push_to_buff(packed_buffer, 128, 8, data_to_pack->retransmission_support_admin);
    push_to_buff(packed_buffer, 136, 24, data_to_pack->fec_mode_support_admin);
    push_to_buff(packed_buffer, 156, 8, data_to_pack->retransmission_request_admin);
    push_to_buff(packed_buffer, 164, 24, data_to_pack->fec_mode_request_admin);

    return 16;
}

void REG_PLPC_unpack(struct ku_plpc_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->profile_id = pop_from_buff(buffer_to_unpack, 4, 12);
    unpacked_data->proto_mask = pop_from_buff(buffer_to_unpack, 20, 4);
    unpacked_data->lane_speed = pop_from_buff(buffer_to_unpack, 48, 16);
    unpacked_data->lpbf = pop_from_buff(buffer_to_unpack, 87, 1);
    unpacked_data->fec_mode_policy = pop_from_buff(buffer_to_unpack, 88, 8);
    unpacked_data->retransmission_capability = pop_from_buff(buffer_to_unpack, 96, 8);
    unpacked_data->fec_mode_capability = pop_from_buff(buffer_to_unpack, 104, 24);
    unpacked_data->retransmission_support_admin = pop_from_buff(buffer_to_unpack, 128, 8);
    unpacked_data->fec_mode_support_admin = pop_from_buff(buffer_to_unpack, 136, 24);
    unpacked_data->retransmission_request_admin = pop_from_buff(buffer_to_unpack, 156, 8);
    unpacked_data->fec_mode_request_admin = pop_from_buff(buffer_to_unpack, 164, 24);
}


uint32_t REG_PMPC_pack(struct ku_pmpc_reg *data_to_pack, uint8_t *packed_buffer)
{
    uint32_t i = 0;

    for (i = 0; i < 8; i++) {
        push_to_buff(packed_buffer, (32 * i), 32, data_to_pack->module_state_updated_bitmap[i]);
    }

    return 16;
}

void REG_PMPC_unpack(struct ku_pmpc_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    uint32_t i = 0;

    for (i = 0; i < 8; i++) {
        unpacked_data->module_state_updated_bitmap[i] = pop_from_buff(buffer_to_unpack, 0 + (32 * i), 32);
    }
}

uint32_t REG_RTPS_pack(struct ku_rtps_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 0, 8, data_to_pack->swid);
    push_to_buff(packed_buffer, 24, 4, data_to_pack->tca_log_pstate);
    push_to_buff(packed_buffer, 28, 4, data_to_pack->tca_phy_pstate);
    push_to_buff(packed_buffer, 56, 4, data_to_pack->switch_log_pstate);
    push_to_buff(packed_buffer, 60, 4, data_to_pack->switch_phy_pstate);
    return 16;
}


void REG_RTPS_unpack(struct ku_rtps_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->swid = pop_from_buff(buffer_to_unpack, 0, 8);
    unpacked_data->tca_log_pstate = pop_from_buff(buffer_to_unpack, 24, 4);
    unpacked_data->tca_phy_pstate = pop_from_buff(buffer_to_unpack, 28, 4);
    unpacked_data->switch_log_pstate = pop_from_buff(buffer_to_unpack, 56, 4);
    unpacked_data->switch_phy_pstate = pop_from_buff(buffer_to_unpack, 60, 4);
}

uint32_t REG_RCAP_pack(struct ku_rcap_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 16, 16,  data_to_pack->rif);
    push_to_buff(packed_buffer, 56, 8, data_to_pack->vir_router);
    return 16;
}


void REG_RCAP_unpack(struct ku_rcap_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->rif = pop_from_buff(buffer_to_unpack, 16, 16);
    unpacked_data->vir_router = pop_from_buff(buffer_to_unpack, 56, 8);
}

uint32_t REG_RGCR_pack(struct ku_rgcr_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 0,  1, data_to_pack->ipv4_enable);
    push_to_buff(packed_buffer, 1,  1, data_to_pack->ipv6_enable);
    push_to_buff(packed_buffer, 2,  1, data_to_pack->mpls_enable);
    push_to_buff(packed_buffer, 48, 16, data_to_pack->max_vlan_router_interfaces);
    push_to_buff(packed_buffer, 80, 16, data_to_pack->max_port_router_interfaces);
    push_to_buff(packed_buffer, 112, 16, data_to_pack->max_pkey_router_interfaces);
    push_to_buff(packed_buffer, 144, 16, data_to_pack->max_router_interfaces);
    push_to_buff(packed_buffer, 176, 16, data_to_pack->max_virtual_routers);
    push_to_buff(packed_buffer, 196, 4, data_to_pack->grht);
    push_to_buff(packed_buffer, 203, 1, data_to_pack->usp);
    push_to_buff(packed_buffer, 206, 1, data_to_pack->pcp_rw);
    push_to_buff(packed_buffer, 214, 1, data_to_pack->ipb);
    push_to_buff(packed_buffer, 215, 1, data_to_pack->allr);
    push_to_buff(packed_buffer, 219, 1, data_to_pack->mcsi);
    push_to_buff(packed_buffer, 223, 1, data_to_pack->rpf);
    push_to_buff(packed_buffer, 230, 2, data_to_pack->ipv6_op_type);
    push_to_buff(packed_buffer, 235, 5, data_to_pack->ipv6_packet_rate);
    push_to_buff(packed_buffer, 246, 2, data_to_pack->ipv4_op_type);
    push_to_buff(packed_buffer, 251, 5, data_to_pack->ipv4_packet_rate);
    push_to_buff(packed_buffer, 264, 8, data_to_pack->grh_hop_limit);
    push_to_buff(packed_buffer, 280, 1, data_to_pack->activity_dis_adjacency_entry);
    push_to_buff(packed_buffer, 281, 1, data_to_pack->activity_dis_host_entry);
    push_to_buff(packed_buffer, 282, 1, data_to_pack->activity_dis_uc_route_entry);
    push_to_buff(packed_buffer, 296, 24, data_to_pack->expected_irif_list_index_base);


    return 16;
}

void REG_RGCR_unpack(struct ku_rgcr_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->ipv4_enable = pop_from_buff(buffer_to_unpack, 0, 1);
    unpacked_data->ipv6_enable = pop_from_buff(buffer_to_unpack, 1, 1);
    unpacked_data->mpls_enable = pop_from_buff(buffer_to_unpack, 2, 1);
    unpacked_data->max_vlan_router_interfaces = pop_from_buff(buffer_to_unpack, 48, 16);
    unpacked_data->max_port_router_interfaces = pop_from_buff(buffer_to_unpack, 80, 16);
    unpacked_data->max_pkey_router_interfaces = pop_from_buff(buffer_to_unpack, 112, 16);
    unpacked_data->max_router_interfaces = pop_from_buff(buffer_to_unpack, 144, 16);
    unpacked_data->max_virtual_routers = pop_from_buff(buffer_to_unpack, 176, 16);
    unpacked_data->grht = pop_from_buff(buffer_to_unpack, 196, 4);
    unpacked_data->usp = pop_from_buff(buffer_to_unpack, 203, 1);
    unpacked_data->pcp_rw = pop_from_buff(buffer_to_unpack, 206, 2);
    unpacked_data->ipb = pop_from_buff(buffer_to_unpack, 214, 1);
    unpacked_data->allr = pop_from_buff(buffer_to_unpack, 215, 1);
    unpacked_data->mcsi = pop_from_buff(buffer_to_unpack, 219, 1);
    unpacked_data->rpf = pop_from_buff(buffer_to_unpack, 223, 1);
    unpacked_data->ipv6_op_type = pop_from_buff(buffer_to_unpack, 230, 2);
    unpacked_data->ipv6_packet_rate = pop_from_buff(buffer_to_unpack, 235, 5);
    unpacked_data->ipv4_op_type = pop_from_buff(buffer_to_unpack, 246, 2);
    unpacked_data->ipv4_packet_rate = pop_from_buff(buffer_to_unpack, 251, 5);
    unpacked_data->grh_hop_limit = pop_from_buff(buffer_to_unpack, 264, 8);
    unpacked_data->activity_dis_adjacency_entry = pop_from_buff(buffer_to_unpack, 280, 1);
    unpacked_data->activity_dis_host_entry = pop_from_buff(buffer_to_unpack, 281, 1);
    unpacked_data->activity_dis_uc_route_entry = pop_from_buff(buffer_to_unpack, 282, 1);
    unpacked_data->expected_irif_list_index_base = pop_from_buff(buffer_to_unpack, 296, 24);
}


uint32_t REG_RTAR_pack(struct ku_rtar_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 0, 4, data_to_pack->operation);
    push_to_buff(packed_buffer, 24, 8, data_to_pack->type);
    push_to_buff(packed_buffer, 48, 16, data_to_pack->tcam_size);
    return 16;
}


void REG_RTAR_unpack(struct ku_rtar_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->operation = pop_from_buff(buffer_to_unpack, 0, 4);
    unpacked_data->type = pop_from_buff(buffer_to_unpack, 24, 8);
    unpacked_data->tcam_size = pop_from_buff(buffer_to_unpack, 48, 16);
}

uint32_t REG_RECR_pack(struct ku_recr_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 23, 1, data_to_pack->symmetric_hash);
    push_to_buff(packed_buffer, 28, 4, data_to_pack->hash_type);
    push_to_buff(packed_buffer, 44, 20, data_to_pack->hash_configuration);
    push_to_buff(packed_buffer, 64, 32, data_to_pack->seed);
    return 16;
}


void REG_RECR_unpack(struct ku_recr_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->symmetric_hash = pop_from_buff(buffer_to_unpack, 23, 1);
    unpacked_data->hash_type = pop_from_buff(buffer_to_unpack, 28, 4);
    unpacked_data->hash_configuration = pop_from_buff(buffer_to_unpack, 44, 20);
    unpacked_data->seed = pop_from_buff(buffer_to_unpack, 64, 32);
}

uint32_t REG_MSCI_pack(struct ku_msci_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 28, 4, data_to_pack->index);
    return 16;
}


void REG_MSCI_unpack(struct ku_msci_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->index = pop_from_buff(buffer_to_unpack, 28, 4);
    unpacked_data->version = pop_from_buff_32(buffer_to_unpack, 32);
}

uint32_t REG_RATR_pack(struct ku_ratr_reg *data_to_pack, uint8_t *packed_buffer)
{
    int i;

    push_to_buff(packed_buffer, 0,   4, data_to_pack->operation);
    push_to_buff(packed_buffer, 7,   1, data_to_pack->valid);
    push_to_buff(packed_buffer, 16, 16, data_to_pack->size);
    push_to_buff(packed_buffer, 32,  4, data_to_pack->type);
    push_to_buff(packed_buffer, 45,  3, data_to_pack->table);
    push_to_buff(packed_buffer, 48, 16, data_to_pack->adjacency_index);
    switch (data_to_pack->type) {
    case ETHERNET:
        for (i = 0; i < 6; i++) {
            push_to_buff(packed_buffer,
                         144 + (i * 8),
                         8,
                         data_to_pack->adj_parameters.eth_adj_parameters.destination_mac[5 - i]);
        }
        break;

    case PKEY_UNI_WITHOUT_GRH:
        push_to_buff(packed_buffer, 136,  4, data_to_pack->adj_parameters.pkey_uni_without_grh_parameters.sl);
        push_to_buff(packed_buffer, 144, 16, data_to_pack->adj_parameters.pkey_uni_without_grh_parameters.dlid);
        push_to_buff(packed_buffer, 168, 24, data_to_pack->adj_parameters.pkey_uni_without_grh_parameters.dqpn);
        push_to_buff(packed_buffer, 217,  7, data_to_pack->adj_parameters.pkey_uni_without_grh_parameters.my_lid);
        break;

    case PKEY_UNI_WITH_GRH:
        push_to_buff(packed_buffer, 129,  7, data_to_pack->adj_parameters.pkey_uni_with_grh_parameters.my_lid);
        push_to_buff(packed_buffer, 136,  4, data_to_pack->adj_parameters.pkey_uni_with_grh_parameters.sl);
        push_to_buff(packed_buffer, 144, 16, data_to_pack->adj_parameters.pkey_uni_with_grh_parameters.dlid);
        push_to_buff(packed_buffer, 168, 24, data_to_pack->adj_parameters.pkey_uni_with_grh_parameters.dqpn);
        for (i = 0; i < 16; i++) {
            push_to_buff(packed_buffer, 192 + (i * 8),
                         8,
                         data_to_pack->adj_parameters.pkey_uni_with_grh_parameters.dgid.addr_octet[i]);
        }
        break;

    case PKEY_MULTI:
        push_to_buff(packed_buffer, 136,  4, data_to_pack->adj_parameters.pkey_multi_parameters.sl);
        push_to_buff(packed_buffer, 144,  16, data_to_pack->adj_parameters.pkey_multi_parameters.dlid);
        push_to_buff(packed_buffer, 216,  8, data_to_pack->adj_parameters.pkey_multi_parameters.tclass);
        break;

    case MPLS:
    case L3_TUNNEL_ENCAP:
    case RELOOKUP_ECMP:
    case RELOOKUP_LPM:
    case NAT4TO6:
    case ARN_ENCAP:
        break;
    }
    return 16;
}


void REG_RATR_unpack(struct ku_ratr_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    int i;

    unpacked_data->operation = pop_from_buff(buffer_to_unpack, 0, 4);
    unpacked_data->valid = pop_from_buff(buffer_to_unpack, 7, 1);
    unpacked_data->size = pop_from_buff(buffer_to_unpack, 16, 16);
    unpacked_data->type = pop_from_buff(buffer_to_unpack, 32, 4);
    unpacked_data->table = pop_from_buff(buffer_to_unpack, 45, 3);
    unpacked_data->adjacency_index = pop_from_buff(buffer_to_unpack, 48, 16);
    switch (unpacked_data->type) {
    case ETHERNET:
        for (i = 0; i < 6; i++) {
            unpacked_data->adj_parameters.eth_adj_parameters.destination_mac[5 - i] = pop_from_buff(buffer_to_unpack,
                                                                                                    144 + (i * 8),
                                                                                                    8);
        }
        break;

    case PKEY_UNI_WITHOUT_GRH:
        unpacked_data->adj_parameters.pkey_uni_without_grh_parameters.sl = pop_from_buff(buffer_to_unpack, 136, 4);
        unpacked_data->adj_parameters.pkey_uni_without_grh_parameters.dlid = pop_from_buff(buffer_to_unpack, 144, 16);
        unpacked_data->adj_parameters.pkey_uni_without_grh_parameters.dqpn = pop_from_buff(buffer_to_unpack, 168, 24);
        unpacked_data->adj_parameters.pkey_uni_without_grh_parameters.my_lid = pop_from_buff(buffer_to_unpack, 217, 7);
        break;

    case PKEY_UNI_WITH_GRH:
        unpacked_data->adj_parameters.pkey_uni_with_grh_parameters.my_lid = pop_from_buff(buffer_to_unpack, 129, 7);
        unpacked_data->adj_parameters.pkey_uni_with_grh_parameters.sl = pop_from_buff(buffer_to_unpack, 136, 4);
        unpacked_data->adj_parameters.pkey_uni_with_grh_parameters.dlid = pop_from_buff(buffer_to_unpack, 144, 16);
        unpacked_data->adj_parameters.pkey_uni_with_grh_parameters.dqpn = pop_from_buff(buffer_to_unpack, 168, 24);
        for (i = 0; i < 16; i++) {
            unpacked_data->adj_parameters.pkey_uni_with_grh_parameters.dgid.addr_octet[i] = pop_from_buff(
                buffer_to_unpack,
                192 + (i * 8),
                8);
        }
        break;

    case PKEY_MULTI:
        unpacked_data->adj_parameters.pkey_multi_parameters.sl = pop_from_buff(buffer_to_unpack, 136, 4);
        unpacked_data->adj_parameters.pkey_multi_parameters.dlid = pop_from_buff(buffer_to_unpack, 144, 16);
        unpacked_data->adj_parameters.pkey_multi_parameters.tclass = pop_from_buff(buffer_to_unpack, 216, 8);
        break;

    case MPLS:
    case L3_TUNNEL_ENCAP:
    case RELOOKUP_ECMP:
    case RELOOKUP_LPM:
    case NAT4TO6:
    case ARN_ENCAP:
        break;
    }
}

uint32_t REG_RDPM_pack(struct ku_rdpm_reg *data_to_pack, uint8_t *packed_buffer)
{
    int i;

    for (i = 0; i < DSCP_CODES_NUMBER; i++) {
        push_to_buff(packed_buffer, i * 8, 1, data_to_pack->dscp_update[DSCP_CODES_NUMBER - i - 1]);
        push_to_buff(packed_buffer, i * 8 + 5, 3, data_to_pack->priority[DSCP_CODES_NUMBER - i - 1]);
    }
    return 16;
}


void REG_RDPM_unpack(struct ku_rdpm_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    int i;

    for (i = 0; i < DSCP_CODES_NUMBER; i++) {
        unpacked_data->dscp_update[DSCP_CODES_NUMBER - i - 1] = pop_from_buff(buffer_to_unpack, i * 8, 1);
        unpacked_data->priority[DSCP_CODES_NUMBER - i - 1] = pop_from_buff(buffer_to_unpack, i * 8 + 5, 3);
    }
}

uint32_t REG_RICA_pack(struct ku_rica_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 0,  2, data_to_pack->operation);
    push_to_buff(packed_buffer, 24, 8, data_to_pack->index);
    push_to_buff(packed_buffer, 64, 32, data_to_pack->ingress_counter_set.index);
    push_to_buff(packed_buffer, 96, 32, data_to_pack->egress_counter_set.index);
    return 16;
}


void REG_RICA_unpack(struct ku_rica_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->operation = pop_from_buff(buffer_to_unpack, 0, 2);
    unpacked_data->index = pop_from_buff(buffer_to_unpack, 24, 8);
    unpacked_data->ingress_counter_set.index = pop_from_buff(buffer_to_unpack, 64, 32);
    unpacked_data->ingress_counter_set.type = unpacked_data->ingress_counter_set.index >> 24;
    unpacked_data->egress_counter_set.index = pop_from_buff(buffer_to_unpack, 96, 32);
    unpacked_data->egress_counter_set.type = unpacked_data->egress_counter_set.index >> 24;
}

uint32_t REG_RRCR_pack(struct ku_rrcr_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 0,  4, data_to_pack->op);
    push_to_buff(packed_buffer, 16, 16, data_to_pack->offset);
    push_to_buff(packed_buffer, 48, 16, data_to_pack->size);
    push_to_buff(packed_buffer, 88, 8, data_to_pack->table_id);
    push_to_buff(packed_buffer, 112, 16, data_to_pack->dest_offset);
    return 16;
}


void REG_RRCR_unpack(struct ku_rrcr_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->op = pop_from_buff(buffer_to_unpack, 0, 4);
    unpacked_data->offset = pop_from_buff(buffer_to_unpack, 16, 16);
    unpacked_data->size = pop_from_buff(buffer_to_unpack, 48, 16);
    unpacked_data->table_id = pop_from_buff(buffer_to_unpack, 88, 8);
    unpacked_data->dest_offset = pop_from_buff(buffer_to_unpack, 112, 16);
}

uint32_t REG_RTCA_pack(struct ku_rtca_reg *data_to_pack, uint8_t *packed_buffer)
{
    int i;

    push_to_buff(packed_buffer, 0, 8, data_to_pack->swid);
    push_to_buff(packed_buffer, 13, 3, data_to_pack->lmc);
    push_to_buff(packed_buffer, 16, 16, data_to_pack->lid);
    for (i = 0; i < 16; i++) {
        push_to_buff(packed_buffer, 32 + (8 * i), 8, data_to_pack->gid.addr_octet[i]);
    }
    return 16;
}


void REG_RTCA_unpack(struct ku_rtca_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    int i;

    unpacked_data->swid = pop_from_buff(buffer_to_unpack, 0, 8);
    unpacked_data->lmc = pop_from_buff(buffer_to_unpack, 24, 4);
    unpacked_data->lid = pop_from_buff(buffer_to_unpack, 28, 4);
    for (i = 0; i < 16; i++) {
        unpacked_data->gid.addr_octet[i] = pop_from_buff(buffer_to_unpack, 32 + (8 * i), 8);
    }
}


uint32_t REG_MJTAG_pack(struct ku_mjtag_reg *data_to_pack, uint8_t *packed_buffer)
{
    int     i = 0;
    uint8_t jtag = 0;

    push_to_buff(packed_buffer, 0, 2, data_to_pack->cmd);
    push_to_buff(packed_buffer, 4, 4, data_to_pack->seq_num);
    push_to_buff(packed_buffer, 24, 8, data_to_pack->size);
    for (; i++ < data_to_pack->size;) {
        jtag = (data_to_pack->jtag_transaction_sets[i].tdo & 0x01) << 3 |
               (data_to_pack->jtag_transaction_sets[i].tdi & 0x01) << 1 |
               (data_to_pack->jtag_transaction_sets[i].tms & 0x01);
        push_to_buff(packed_buffer, 32 + (i * 8), 8, jtag);
    }

    return 16;
}

void REG_MJTAG_unpack(struct ku_mjtag_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    int      i = 0;
    uint32_t jtag = 0;

    unpacked_data->cmd = pop_from_buff(buffer_to_unpack, 0, 2);
    unpacked_data->seq_num = pop_from_buff(buffer_to_unpack, 4, 4);
    unpacked_data->size = pop_from_buff(buffer_to_unpack, 24, 8);
    for (; i++ < unpacked_data->size;) {
        jtag = pop_from_buff(buffer_to_unpack, 32 + (i * 8), 8);
        unpacked_data->jtag_transaction_sets[i].tms = (uint8_t)(jtag & 0x01);
        unpacked_data->jtag_transaction_sets[i].tdi = (uint8_t)((jtag & 0x02) >> 1);
        unpacked_data->jtag_transaction_sets[i].tdo = (uint8_t)((jtag & 0x08) >> 3);
    }
}

uint32_t REG_PMPR_pack(struct ku_pmpr_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 8, 8, data_to_pack->module);
    push_to_buff(packed_buffer, 56, 8, data_to_pack->attenuation5g);
    push_to_buff(packed_buffer, 88, 8, data_to_pack->attenuation7g);
    push_to_buff(packed_buffer, 120, 8, data_to_pack->attenuation12g);

    return 16;
}

void REG_PMPR_unpack(struct ku_pmpr_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->module = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->attenuation5g = pop_from_buff(buffer_to_unpack, 56, 8);
    unpacked_data->attenuation7g = pop_from_buff(buffer_to_unpack, 88, 8);
    unpacked_data->attenuation12g = pop_from_buff(buffer_to_unpack, 120, 8);
}

uint32_t REG_MFPA_pack(struct ku_mfpa_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 23, 1, data_to_pack->p);
    push_to_buff(packed_buffer, 26, 2, data_to_pack->fs);
    push_to_buff_32(packed_buffer, 32, data_to_pack->boot_address);
    push_to_buff(packed_buffer, 156, 4, data_to_pack->flash_num);
    push_to_buff_32(packed_buffer, 160, data_to_pack->jedec_id);
    push_to_buff(packed_buffer, 200, 8, data_to_pack->block_allignment);
    push_to_buff(packed_buffer, 214, 10, data_to_pack->sector_size);
    push_to_buff(packed_buffer, 224, 1, data_to_pack->capability_mask);

    return 16;
}

void REG_MFPA_unpack(struct ku_mfpa_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->p = pop_from_buff(buffer_to_unpack, 23, 1);
    unpacked_data->fs = pop_from_buff(buffer_to_unpack, 26, 2);
    unpacked_data->boot_address = pop_from_buff_32(buffer_to_unpack, 32);
    unpacked_data->flash_num = pop_from_buff(buffer_to_unpack, 156, 4);
    unpacked_data->jedec_id = pop_from_buff_32(buffer_to_unpack, 160);
    unpacked_data->block_allignment = pop_from_buff(buffer_to_unpack, 200, 8);
    unpacked_data->sector_size = pop_from_buff(buffer_to_unpack, 214, 10);
    unpacked_data->capability_mask = pop_from_buff(buffer_to_unpack, 224, 1);
}

uint32_t REG_MFBA_pack(struct ku_mfba_reg *data_to_pack, uint8_t *packed_buffer)
{
    int i = 0;

    push_to_buff(packed_buffer, 23, 1, data_to_pack->p);
    push_to_buff(packed_buffer, 26, 2, data_to_pack->fs);
    push_to_buff(packed_buffer, 55, 9, data_to_pack->size);
    push_to_buff_32(packed_buffer, 64, data_to_pack->address);
    for (i = 0; i < data_to_pack->size; i++) {
        push_to_buff(packed_buffer, 96 + 8 * i, 8, data_to_pack->data[i]);
    }

    return 16;
}

void REG_MFBA_unpack(struct ku_mfba_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    int i = 0;

    unpacked_data->p = pop_from_buff(buffer_to_unpack, 23, 1);
    unpacked_data->fs = pop_from_buff(buffer_to_unpack, 26, 2);
    unpacked_data->size = pop_from_buff(buffer_to_unpack, 55, 9);
    unpacked_data->address = pop_from_buff_32(buffer_to_unpack, 64);
    for (i = 0; i < unpacked_data->size; i++) {
        unpacked_data->data[i] = pop_from_buff(buffer_to_unpack, 96 + 8 * i, 8);
    }
}

uint32_t REG_MFBE_pack(struct ku_mfbe_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 23, 1, data_to_pack->p);
    push_to_buff(packed_buffer, 26, 2, data_to_pack->fs);
    push_to_buff_32(packed_buffer, 64, data_to_pack->address);

    return 16;
}

void REG_MFBE_unpack(struct ku_mfbe_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->p = pop_from_buff(buffer_to_unpack, 23, 1);
    unpacked_data->fs = pop_from_buff(buffer_to_unpack, 26, 2);
    unpacked_data->address = pop_from_buff_32(buffer_to_unpack, 64);
}

uint32_t REG_PELC_pack(struct ku_pelc_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 0, 4, data_to_pack->op);
    push_to_buff(packed_buffer, 8, 8, data_to_pack->local_port);
    push_to_buff(packed_buffer, 18, 2, data_to_pack->lp_msb);
    push_to_buff(packed_buffer, 32, 8, data_to_pack->op_admin);
    push_to_buff(packed_buffer, 40, 8, data_to_pack->op_capability);
    push_to_buff(packed_buffer, 48, 8, data_to_pack->op_request);
    push_to_buff(packed_buffer, 56, 8, data_to_pack->op_active);
    push_to_buff_64(packed_buffer, 64, data_to_pack->admin);
    push_to_buff_64(packed_buffer, 128, data_to_pack->capability);
    push_to_buff_64(packed_buffer, 192, data_to_pack->request);
    push_to_buff_64(packed_buffer, 256, data_to_pack->active);

    return 16;
}

void REG_PELC_unpack(struct ku_pelc_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->op = pop_from_buff(buffer_to_unpack, 0, 4);
    unpacked_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 18, 2);
    unpacked_data->op_admin = pop_from_buff(buffer_to_unpack, 32, 8);
    unpacked_data->op_capability = pop_from_buff(buffer_to_unpack, 40, 8);
    unpacked_data->op_request = pop_from_buff(buffer_to_unpack, 48, 8);
    unpacked_data->op_active = pop_from_buff(buffer_to_unpack, 56, 8);
    unpacked_data->admin = pop_from_buff_64(buffer_to_unpack, 64);
    unpacked_data->capability = pop_from_buff_64(buffer_to_unpack, 128);
    unpacked_data->request = pop_from_buff_64(buffer_to_unpack, 192);
    unpacked_data->active = pop_from_buff_64(buffer_to_unpack, 256);
}


uint32_t REG_PPSC_pack(struct ku_ppsc_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 8, 8, data_to_pack->local_port);
    push_to_buff(packed_buffer, 18, 2, data_to_pack->lp_msb);
    push_to_buff(packed_buffer, 156, 4, data_to_pack->wrps_admin);
    push_to_buff(packed_buffer, 188, 4, data_to_pack->wrps_status);
    push_to_buff(packed_buffer, 200, 8, data_to_pack->up_threshold);
    push_to_buff(packed_buffer, 216, 8, data_to_pack->down_threshold);
    push_to_buff(packed_buffer, 284, 4, data_to_pack->srps_admin);
    push_to_buff(packed_buffer, 316, 4, data_to_pack->srps_status);

    return 16;
}

uint32_t REG_PPSC_unpack(struct ku_ppsc_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 18, 2);
    unpacked_data->wrps_admin = pop_from_buff(buffer_to_unpack, 156, 4);
    unpacked_data->wrps_status = pop_from_buff(buffer_to_unpack, 188, 4);
    unpacked_data->up_threshold = pop_from_buff(buffer_to_unpack, 200, 8);
    unpacked_data->down_threshold = pop_from_buff(buffer_to_unpack, 216, 8);
    unpacked_data->srps_admin = pop_from_buff(buffer_to_unpack, 284, 4);
    unpacked_data->srps_status = pop_from_buff(buffer_to_unpack, 316, 4);

    return 16;
}

uint32_t REG_QPBR_pack(struct ku_qpbr_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 0, 2, data_to_pack->operation);
    push_to_buff(packed_buffer, 6, 2, data_to_pack->lp_msb);
    push_to_buff(packed_buffer, 8, 8, data_to_pack->port);
    push_to_buff(packed_buffer, 16, 1, data_to_pack->global_policer);
    push_to_buff(packed_buffer, 18, 14, data_to_pack->pid);
    push_to_buff(packed_buffer, 59, 1, data_to_pack->unregistered_multicast);
    push_to_buff(packed_buffer, 60, 1, data_to_pack->unknown_unicast);
    push_to_buff(packed_buffer, 61, 1, data_to_pack->broadcast);
    push_to_buff(packed_buffer, 62, 1, data_to_pack->multicast);
    push_to_buff(packed_buffer, 63, 1, data_to_pack->unicast);

    return 16;
}

void REG_QPBR_unpack(struct ku_qpbr_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->operation = pop_from_buff(buffer_to_unpack, 0, 2);
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 6, 2);
    unpacked_data->port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->global_policer = pop_from_buff(buffer_to_unpack, 16, 1);
    unpacked_data->pid = pop_from_buff(buffer_to_unpack, 18, 14);
    unpacked_data->unregistered_multicast = pop_from_buff(buffer_to_unpack, 59, 1);
    unpacked_data->unknown_unicast = pop_from_buff(buffer_to_unpack, 60, 1);
    unpacked_data->broadcast = pop_from_buff(buffer_to_unpack, 61, 1);
    unpacked_data->multicast = pop_from_buff(buffer_to_unpack, 62, 1);
    unpacked_data->unicast = pop_from_buff(buffer_to_unpack, 63, 1);
}

uint32_t REG_QPCR_pack(struct ku_qpcr_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 6, 2, data_to_pack->lp_msb);
    push_to_buff(packed_buffer, 8, 8, data_to_pack->port);
    push_to_buff(packed_buffer, 16, 2, data_to_pack->global_policer);
    push_to_buff(packed_buffer, 18, 14, data_to_pack->pid);
    push_to_buff(packed_buffer, 32, 1, data_to_pack->clear_counter);
    push_to_buff(packed_buffer, 33, 1, data_to_pack->add_counter);
    push_to_buff(packed_buffer, 48, 1, data_to_pack->color_aware);
    push_to_buff(packed_buffer, 49, 1, data_to_pack->use_bytes);
    push_to_buff(packed_buffer, 51, 1, data_to_pack->ir_units);
    push_to_buff(packed_buffer, 54, 2, data_to_pack->type);
    push_to_buff(packed_buffer, 62, 2, data_to_pack->mode);
    push_to_buff(packed_buffer, 66, 6, data_to_pack->committed_burst_size);
    push_to_buff(packed_buffer, 74, 6, data_to_pack->extended_burst_size);
    push_to_buff_32(packed_buffer, 96, data_to_pack->committed_information_rate);
    push_to_buff_32(packed_buffer, 128, data_to_pack->excess_information_rate);
    push_to_buff(packed_buffer, 188, 4, data_to_pack->exceed_action);
    push_to_buff(packed_buffer, 220, 4, data_to_pack->violate_action);
    push_to_buff_64(packed_buffer, 256, data_to_pack->violate_count);

    return 16;
}

void REG_QPCR_unpack(struct ku_qpcr_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 6, 2);
    unpacked_data->port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->global_policer = pop_from_buff(buffer_to_unpack, 16, 2);
    unpacked_data->pid = pop_from_buff(buffer_to_unpack, 18, 14);
    unpacked_data->clear_counter = pop_from_buff(buffer_to_unpack, 32, 1);
    unpacked_data->add_counter = pop_from_buff(buffer_to_unpack, 33, 1);
    unpacked_data->color_aware = pop_from_buff(buffer_to_unpack, 48, 1);
    unpacked_data->use_bytes = pop_from_buff(buffer_to_unpack, 49, 1);
    unpacked_data->ir_units = pop_from_buff(buffer_to_unpack, 51, 1);
    unpacked_data->type = pop_from_buff(buffer_to_unpack, 54, 2);
    unpacked_data->mode = pop_from_buff(buffer_to_unpack, 62, 2);
    unpacked_data->committed_burst_size = pop_from_buff(buffer_to_unpack, 66, 6);
    unpacked_data->extended_burst_size = pop_from_buff(buffer_to_unpack, 74, 6);
    unpacked_data->committed_information_rate = pop_from_buff_32(buffer_to_unpack, 96);
    unpacked_data->excess_information_rate = pop_from_buff_32(buffer_to_unpack, 128);
    unpacked_data->exceed_action = pop_from_buff(buffer_to_unpack, 188, 4);
    unpacked_data->violate_action = pop_from_buff(buffer_to_unpack, 220, 4);
    unpacked_data->violate_count = pop_from_buff_64(buffer_to_unpack, 256);
}


uint32_t TLV_REG_pack(tlv_reg_t *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 16, 16, data_to_pack->reserved0);
    push_to_buff(packed_buffer, 5, 11, data_to_pack->len);
    push_to_buff(packed_buffer, 0, 5, data_to_pack->type);

    return 4;
}

uint32_t TLV_OPERATION_pack(tlv_operation_t *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 24, 8, data_to_pack->reserved0);
    push_to_buff(packed_buffer, 17, 7, data_to_pack->status);
    push_to_buff(packed_buffer, 16, 1, data_to_pack->dr);
    push_to_buff(packed_buffer, 5, 11, data_to_pack->len);
    push_to_buff(packed_buffer, 0, 5, data_to_pack->type);
    push_to_buff(packed_buffer, 56, 8, data_to_pack->class);
    push_to_buff(packed_buffer, 49, 7, data_to_pack->method);
    push_to_buff(packed_buffer, 48, 1, data_to_pack->r);
    push_to_buff(packed_buffer, 32, 16, data_to_pack->register_id);
    push_to_buff_64(packed_buffer, 64, data_to_pack->tid);

    return 16;
}

void TLV_OPERATION_unpack(tlv_operation_t *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->reserved0 = pop_from_buff(buffer_to_unpack, 24, 8);
    unpacked_data->status = pop_from_buff(buffer_to_unpack, 17, 7);
    unpacked_data->dr = pop_from_buff(buffer_to_unpack, 16, 1);
    unpacked_data->len = pop_from_buff(buffer_to_unpack, 5, 11);
    unpacked_data->type = pop_from_buff(buffer_to_unpack, 0, 5);
    unpacked_data->class = pop_from_buff(buffer_to_unpack, 56, 8);
    unpacked_data->method = pop_from_buff(buffer_to_unpack, 49, 7);
    unpacked_data->r = pop_from_buff(buffer_to_unpack, 48, 1);
    unpacked_data->register_id = pop_from_buff(buffer_to_unpack, 32, 16);
    unpacked_data->tid = pop_from_buff_64(buffer_to_unpack, 64);
}

uint32_t REG_PLBF_pack(struct ku_plbf_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 8, 8, data_to_pack->port);
    push_to_buff(packed_buffer, 29, 3, data_to_pack->lbf_mode);
    return 16;
}

void REG_PLBF_unpack(struct ku_plbf_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->lbf_mode = pop_from_buff(buffer_to_unpack, 29, 3);
}

uint32_t REG_SGCR_pack(struct ku_sgcr_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 56, 8, data_to_pack->llb);
    return 16;
}

void REG_SGCR_unpack(struct ku_sgcr_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->llb = pop_from_buff(buffer_to_unpack, 56, 8);
}

void CABLE_INFO_pack(struct ku_mcia_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 0, 8, data_to_pack->i2c_device_address);
    push_to_buff(packed_buffer, 8, 8, data_to_pack->page_number);
    push_to_buff(packed_buffer, 16, 16, data_to_pack->device_address);
    push_to_buff(packed_buffer, 48, 16, data_to_pack->size);
    push_to_buff(packed_buffer, 128 + (32 * 0), 32, data_to_pack->dword_0);
    push_to_buff(packed_buffer, 128 + (32 * 1), 32, data_to_pack->dword_1);
    push_to_buff(packed_buffer, 128 + (32 * 2), 32, data_to_pack->dword_2);
    push_to_buff(packed_buffer, 128 + (32 * 3), 32, data_to_pack->dword_3);
    push_to_buff(packed_buffer, 128 + (32 * 4), 32, data_to_pack->dword_4);
    push_to_buff(packed_buffer, 128 + (32 * 5), 32, data_to_pack->dword_5);
    push_to_buff(packed_buffer, 128 + (32 * 6), 32, data_to_pack->dword_6);
    push_to_buff(packed_buffer, 128 + (32 * 7), 32, data_to_pack->dword_7);
    push_to_buff(packed_buffer, 128 + (32 * 8), 32, data_to_pack->dword_8);
    push_to_buff(packed_buffer, 128 + (32 * 9), 32, data_to_pack->dword_9);
    push_to_buff(packed_buffer, 128 + (32 * 10), 32, data_to_pack->dword_10);
    push_to_buff(packed_buffer, 128 + (32 * 11), 32, data_to_pack->dword_11);
}

void CABLE_INFO_unpack(struct ku_mcia_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->i2c_device_address = pop_from_buff(buffer_to_unpack, 0, 8);
    unpacked_data->page_number = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->device_address = pop_from_buff(buffer_to_unpack, 16, 16);
    unpacked_data->size = pop_from_buff(buffer_to_unpack, 48, 16);
    unpacked_data->dword_0 = pop_from_buff(buffer_to_unpack, 128 + (32 * 0), 32);
    unpacked_data->dword_1 = pop_from_buff(buffer_to_unpack, 128 + (32 * 1), 32);
    unpacked_data->dword_2 = pop_from_buff(buffer_to_unpack, 128 + (32 * 2), 32);
    unpacked_data->dword_3 = pop_from_buff(buffer_to_unpack, 128 + (32 * 3), 32);
    unpacked_data->dword_4 = pop_from_buff(buffer_to_unpack, 128 + (32 * 4), 32);
    unpacked_data->dword_5 = pop_from_buff(buffer_to_unpack, 128 + (32 * 5), 32);
    unpacked_data->dword_6 = pop_from_buff(buffer_to_unpack, 128 + (32 * 6), 32);
    unpacked_data->dword_7 = pop_from_buff(buffer_to_unpack, 128 + (32 * 7), 32);
    unpacked_data->dword_8 = pop_from_buff(buffer_to_unpack, 128 + (32 * 8), 32);
    unpacked_data->dword_9 = pop_from_buff(buffer_to_unpack, 128 + (32 * 9), 32);
    unpacked_data->dword_10 = pop_from_buff(buffer_to_unpack, 128 + (32 * 10), 32);
    unpacked_data->dword_11 = pop_from_buff(buffer_to_unpack, 96 + (32 * 11), 32);
}

uint32_t REG_MLCR_pack(struct ku_mlcr_reg *data_to_pack, uint8_t *packed_buffer)
{
    push_to_buff(packed_buffer, 8, 8, data_to_pack->local_port);
    push_to_buff(packed_buffer, 6, 2, data_to_pack->lp_msb);
    push_to_buff(packed_buffer, 27, 1, data_to_pack->cap_local_or_uid_only);
    push_to_buff(packed_buffer, 28, 4, data_to_pack->led_type);
    push_to_buff(packed_buffer, 48, 16, data_to_pack->beacon_duration);
    push_to_buff(packed_buffer, 80, 16, data_to_pack->beacon_remain);

    return 16;
}

void REG_MLCR_unpack(struct ku_mlcr_reg *unpacked_data, uint8_t *buffer_to_unpack)
{
    unpacked_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    unpacked_data->lp_msb = pop_from_buff(buffer_to_unpack, 6, 2);
    unpacked_data->cap_local_or_uid_only = pop_from_buff(buffer_to_unpack, 27, 1);
    unpacked_data->led_type = pop_from_buff(buffer_to_unpack, 28, 4);
    unpacked_data->beacon_duration = pop_from_buff(buffer_to_unpack, 48, 16);
    unpacked_data->beacon_remain = pop_from_buff(buffer_to_unpack, 80, 16);
}

void prepare_tlv_operation(sxd_reg_id_e register_id, tlv_operation_t *tlv_op, tlv_operarion_method_e method)
{
    tlv_op->type = TLV_TYPE_OPERATION_E;
    tlv_op->len = TLV_OPERATION_DWORD_SIZE;
    tlv_op->dr = 0;
    tlv_op->register_id = register_id;
    tlv_op->r = TLV_OPERATION_R_REQUEST;
    tlv_op->method = method;
    tlv_op->class = ACCESS_REG_CLASS_ID;
}

void prepare_tlv_register(uint8_t reg_size, tlv_reg_t *tlv_reg)
{
    tlv_reg->type = TLV_TYPE_REG_E;
    tlv_reg->len = reg_size + 1; /* Size of register + size of TLV_REG header */
}

void prepare_tlv_operation_register(tlv_operation_t       *tlv_op,
                                    tlv_reg_t            * tlv_reg,
                                    sxd_reg_id_e           register_id,
                                    uint8_t                reg_size,
                                    tlv_operarion_method_e method)
{
    memset(tlv_op, 0, sizeof(tlv_operation_t));
    memset(tlv_reg, 0, sizeof(tlv_reg_t));
    prepare_tlv_operation(register_id, tlv_op, method);
    prepare_tlv_register(reg_size, tlv_reg);
}

sxd_status_t send_access_reg_mad(sxd_dev_id_t dev_id, uint8_t* mad, struct ibmad_port* sport, ib_portid_t* portid)
{
    sxd_status_t    status = SXD_STATUS_SUCCESS;
    tlv_operation_t tlv_op;
    int             retry_count = 0;
    uint64_t        system_m_key;

    /******** LOCK ********/
    M_SXD_UTILS_MUTEX_LOCK(&(hw_p->mtx));

    if (!hw_p->sport) {
        int mgmt_classes[5] = { IB_SMI_CLASS, IB_SMI_DIRECT_CLASS, IB_SA_CLASS,
                                IB_PERFORMANCE_CLASS, 9 };

        hw_p->sport = mad_rpc_open_port(NULL, 0, mgmt_classes, 5);
        sport = hw_p->sport;
        if (sport == NULL) {
            SX_LOG_ERR("failed initializing the ibmad lib\n");
            status = SXD_STATUS_DEVICE_OPEN_ERROR;
            goto out;
        }

        mad_rpc_set_retries(sport, 10);
        mad_rpc_set_timeout(sport, 300);
    }

    status = dpt_get_system_m_key(dev_id, &system_m_key);
    if (status) {
        SX_LOG_ERR("failed dpt_get_system_m_key for dev_id %d. \n", dev_id);
        goto out;
    }
    smp_mkey_set(hw_p->sport, system_m_key);

    if (!smp_set_via(mad, portid, IB_ATTR_ACCESS_REG, 0, IB_ACCESS_REG_TIMEOUT, sport)) {
        status = SXD_STATUS_PARAM_ERROR;
    }

    TLV_OPERATION_unpack(&tlv_op, mad);

    while (retry_count < NUM_OF_RETRIES && tlv_op.status == SXD_STATUS_ERROR) {
        usleep(RETRY_WAIT_TIME);
        if (!smp_set_via(mad, portid, IB_ATTR_ACCESS_REG, 0, IB_ACCESS_REG_TIMEOUT, sport)) {
            status = SXD_STATUS_PARAM_ERROR;
            goto out;
        }

        TLV_OPERATION_unpack(&tlv_op, mad);
        retry_count++;
    }

    if (tlv_op.status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("MAD returned with error %d in operation tlv\n", tlv_op.status);
        if (tlv_op.status == SXD_STATUS_ERROR) {
            status = SXD_STATUS_ERROR;
        } else {
            status = SXD_STATUS_FW_ERROR;
        }

        goto out;
    }

out:
    /******** UNLOCK ********/
    M_SXD_UTILS_MUTEX_UNLOCK(&(hw_p->mtx));

    return status;
}

sxd_status_t send_smp_mad(uint8_t               *mad,
                          struct ibmad_port     *sport,
                          ib_portid_t           *portid,
                          unsigned               attrid,
                          unsigned               attr_mod,
                          tlv_operarion_method_e method,
                          uint32_t              *mad_status)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;
    uint8_t     *res = NULL;

    /******** LOCK ********/
    M_SXD_UTILS_MUTEX_LOCK(&(hw_p->mtx));

    if (!hw_p->sport) {
        int mgmt_classes[5] = { IB_SMI_CLASS, IB_SMI_DIRECT_CLASS, IB_SA_CLASS,
                                IB_PERFORMANCE_CLASS, 9 };

        hw_p->sport = mad_rpc_open_port(NULL, 0, mgmt_classes, 5);
        sport = hw_p->sport;
        if (sport == NULL) {
            SX_LOG_ERR("failed initializing the ibmad lib\n");
            status = SXD_STATUS_DEVICE_OPEN_ERROR;
            goto out;
        }

        mad_rpc_set_retries(sport, 10);
        mad_rpc_set_timeout(sport, 300);
    }

    if (method == TLV_OP_METHOD_QUERY_E) {
        res = smp_query_status_via(mad, portid, attrid, attr_mod,
                                   IB_ACCESS_REG_TIMEOUT, (int*)mad_status, sport);
    } else {
        res = smp_set_status_via(mad, portid, attrid, attr_mod,
                                 IB_ACCESS_REG_TIMEOUT, (int*)mad_status, sport);
    }

    /* Only if the MAD wasn't returned at all we should return an error in this case */
    if ((res == NULL) && (mad_status == 0)) {
        SX_LOG_ERR("SMP send failed\n");
        status = SXD_STATUS_ERROR;
    }

out:
    /******** UNLOCK ********/
    M_SXD_UTILS_MUTEX_UNLOCK(&(hw_p->mtx));

    return status;
}

sxd_status_t mad_get_mtbr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mtbr_reg          * reg_mtbr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MTBR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MTBR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MTBR_E,
                                   REG_SIZE_DWORDS_MTBR, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MTBR_pack(reg_mtbr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MTBR_unpack(reg_mtbr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_mtbr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mtbr_reg          * reg_mtbr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MTBR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MTBR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MTBR_E,
                                   REG_SIZE_DWORDS_MTBR, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MTBR_pack(reg_mtbr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MTBR_unpack(reg_mtbr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_ptys_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ptys_reg           *reg_ptys)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + sizeof(struct REG_PTYS)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + sizeof(struct REG_PTYS));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PTYS_E,
                                   REG_SIZE_DWORDS_PTYS, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PTYS_pack(reg_ptys, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PTYS_unpack(reg_ptys, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_ptys_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ptys_reg           *reg_ptys)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + sizeof(struct REG_PTYS)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + sizeof(struct REG_PTYS));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PTYS_E,
                                   REG_SIZE_DWORDS_PTYS, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PTYS_pack(reg_ptys, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PTYS_unpack(reg_ptys, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_pmlp_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmlp_reg          * reg_pmlp)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMLP)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMLP));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PMLP_E,
                                   REG_SIZE_DWORDS_PMLP, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PMLP_pack(reg_pmlp, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PMLP_unpack(reg_pmlp, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_pmlp_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmlp_reg          * reg_pmlp)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMLP)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMLP));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PMLP_E,
                                   REG_SIZE_DWORDS_PMLP, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PMLP_pack(reg_pmlp, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PMLP_unpack(reg_pmlp, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_pspa_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pspa_reg          * reg_pspa)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PSPA)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PSPA));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PSPA_E,
                                   REG_SIZE_DWORDS_PSPA, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PSPA_pack(reg_pspa, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PSPA_unpack(reg_pspa, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_pspa_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pspa_reg          * reg_pspa)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PSPA)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PSPA));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PSPA_E,
                                   REG_SIZE_DWORDS_PSPA, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PSPA_pack(reg_pspa, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PSPA_unpack(reg_pspa, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_plib_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plib_reg          * reg_plib)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLIB)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLIB));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PLIB_E,
                                   REG_SIZE_DWORDS_PLIB, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PLIB_pack(reg_plib, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PLIB_unpack(reg_plib, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_plib_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plib_reg          * reg_plib)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLIB)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLIB));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PLIB_E,
                                   REG_SIZE_DWORDS_PLIB, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PLIB_pack(reg_plib, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PLIB_unpack(reg_plib, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_pplm_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pplm_reg          * reg_pplm)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PPLM)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PPLM));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PPLM_E,
                                   REG_SIZE_DWORDS_PPLM, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PPLM_pack(reg_pplm, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PPLM_unpack(reg_pplm, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_pplm_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pplm_reg          * reg_pplm)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PPLM)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PPLM));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PPLM_E,
                                   REG_SIZE_DWORDS_PPLM, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PPLM_pack(reg_pplm, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PPLM_unpack(reg_pplm, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_mpsc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mpsc_reg          * reg_mpsc)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MPSC)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MPSC));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MPSC_E,
                                   REG_SIZE_DWORDS_MPSC, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MPSC_pack(reg_mpsc, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MPSC_unpack(reg_mpsc, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_mpsc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mpsc_reg          * reg_mpsc)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MPSC)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MPSC));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MPSC_E,
                                   REG_SIZE_DWORDS_MPSC, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MPSC_pack(reg_mpsc, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MPSC_unpack(reg_mpsc, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_plpc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plpc_reg          * reg_plpc)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLPC)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLPC));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PLPC_E,
                                   REG_SIZE_DWORDS_PLPC, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PLPC_pack(reg_plpc, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PLPC_unpack(reg_plpc, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_plpc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plpc_reg          * reg_plpc)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLPC)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLPC));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PLPC_E,
                                   REG_SIZE_DWORDS_PLPC, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PLPC_pack(reg_plpc, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PLPC_unpack(reg_plpc, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_pmpc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmpc_reg          * reg_pmpc)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMPC)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMPC));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PMPC_E,
                                   REG_SIZE_DWORDS_PMPC, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PMPC_pack(reg_pmpc, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PMPC_unpack(reg_pmpc, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_pmpc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmpc_reg          * reg_pmpc)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMPC)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMPC));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PMPC_E,
                                   REG_SIZE_DWORDS_PMPC, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PMPC_pack(reg_pmpc, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PMPC_unpack(reg_pmpc, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_access_mjtag_reg(struct ibmad_port           * sport,
                                  sxd_dev_id_t                  dev_id,
                                  internal_ib_dr_path_params_t *dr_path_params,
                                  struct ku_mjtag_reg          *reg_mjtag,
                                  tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MJTAG)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MJTAG));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MJTAG_E,
                                   REG_SIZE_DWORDS_MJTAG, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MJTAG_pack(reg_mjtag, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MJTAG_unpack(reg_mjtag, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_mjtag_reg(struct ibmad_port           * sport,
                               sxd_dev_id_t                  dev_id,
                               internal_ib_dr_path_params_t *dr_path_params,
                               struct ku_mjtag_reg          *reg_mjtag)
{
    return mad_access_mjtag_reg(sport, dev_id, dr_path_params, reg_mjtag, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_mjtag_reg(struct ibmad_port           * sport,
                               sxd_dev_id_t                  dev_id,
                               internal_ib_dr_path_params_t *dr_path_params,
                               struct ku_mjtag_reg          *reg_mjtag)
{
    return mad_access_mjtag_reg(sport, dev_id, dr_path_params, reg_mjtag, TLV_OP_METHOD_WRITE_E);
}


sxd_status_t mad_access_ppsc_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_ppsc_reg           *reg_ppsc,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PPSC)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PPSC));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PPSC_E,
                                   REG_SIZE_DWORDS_PPSC, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PPSC_pack(reg_ppsc, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PPSC_unpack(reg_ppsc, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}


sxd_status_t mad_access_rtps_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_rtps_reg           *reg_rtps,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RTPS)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RTPS));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_RTPS_E,
                                   REG_SIZE_DWORDS_RTPS, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_RTPS_pack(reg_rtps, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_RTPS_unpack(reg_rtps, buff + sizeof_tlv_reg + sizeof_tlv_op);


    return status;
}

sxd_status_t mad_get_rtps_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtps_reg           *reg_rtps)
{
    return mad_access_rtps_reg(sport, dev_id, dr_path_params, reg_rtps, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_rtps_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtps_reg           *reg_rtps)
{
    return mad_access_rtps_reg(sport, dev_id, dr_path_params, reg_rtps, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_get_ppsc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ppsc_reg           *reg_ppsc)
{
    return mad_access_ppsc_reg(sport, dev_id, dr_path_params, reg_ppsc, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_ppsc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ppsc_reg           *reg_ppsc)
{
    return mad_access_ppsc_reg(sport, dev_id, dr_path_params, reg_ppsc, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_access_rtca_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_rtca_reg           *reg_rtca,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RTCA)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RTCA));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_RTCA_E,
                                   REG_SIZE_DWORDS_RTCA, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_RTCA_pack(reg_rtca, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_RTCA_unpack(reg_rtca, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_rtca_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtca_reg           *reg_rtca)
{
    return mad_access_rtca_reg(sport, dev_id, dr_path_params, reg_rtca, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_rtca_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtca_reg           *reg_rtca)
{
    return mad_access_rtca_reg(sport, dev_id, dr_path_params, reg_rtca, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_access_ratr_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_ratr_reg           *reg_ratr,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RATR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RATR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_RATR_E,
                                   REG_SIZE_DWORDS_RATR, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_RATR_pack(reg_ratr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_RATR_unpack(reg_ratr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_ratr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ratr_reg           *reg_ratr)
{
    return mad_access_ratr_reg(sport, dev_id, dr_path_params, reg_ratr, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_ratr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_ratr_reg           *reg_ratr)
{
    return mad_access_ratr_reg(sport, dev_id, dr_path_params, reg_ratr, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_access_rtar_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_rtar_reg           *reg_rtar,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RTAR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RTAR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_RTAR_E,
                                   REG_SIZE_DWORDS_RTAR, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_RTAR_pack(reg_rtar, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_RTAR_unpack(reg_rtar, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_rtar_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtar_reg           *reg_rtar)
{
    return mad_access_rtar_reg(sport, dev_id, dr_path_params, reg_rtar, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_rtar_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rtar_reg           *reg_rtar)
{
    return mad_access_rtar_reg(sport, dev_id, dr_path_params, reg_rtar, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_access_rica_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_rica_reg           *reg_rica,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RICA)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RICA));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_RICA_E,
                                   REG_SIZE_DWORDS_RICA, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_RICA_pack(reg_rica, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_RICA_unpack(reg_rica, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_rica_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rica_reg           *reg_rica)
{
    return mad_access_rica_reg(sport, dev_id, dr_path_params, reg_rica, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_rica_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rica_reg           *reg_rica)
{
    return mad_access_rica_reg(sport, dev_id, dr_path_params, reg_rica, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_access_rrcr_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_rrcr_reg           *reg_rrcr,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RICA)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RICA));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_RRCR_E,
                                   REG_SIZE_DWORDS_RRCR, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_RRCR_pack(reg_rrcr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_RRCR_unpack(reg_rrcr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_rrcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rrcr_reg           *reg_rrcr)
{
    return mad_access_rrcr_reg(sport, dev_id, dr_path_params, reg_rrcr, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_rrcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rrcr_reg           *reg_rrcr)
{
    return mad_access_rrcr_reg(sport, dev_id, dr_path_params, reg_rrcr, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_access_rdpm_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_rdpm_reg           *reg_rdpm,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RDPM)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RDPM));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_RDPM_E,
                                   REG_SIZE_DWORDS_RDPM, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_RDPM_pack(reg_rdpm, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_RDPM_unpack(reg_rdpm, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_rdpm_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rdpm_reg           *reg_rdpm)
{
    return mad_access_rdpm_reg(sport, dev_id, dr_path_params, reg_rdpm, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_rdpm_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rdpm_reg           *reg_rdpm)
{
    return mad_access_rdpm_reg(sport, dev_id, dr_path_params, reg_rdpm, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_access_rcap_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_rcap_reg           *reg_rcap,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RCAP)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RCAP));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_RCAP_E,
                                   REG_SIZE_DWORDS_RCAP, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_RCAP_pack(reg_rcap, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_RCAP_unpack(reg_rcap, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_rcap_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rcap_reg           *reg_rcap)
{
    return mad_access_rcap_reg(sport, dev_id, dr_path_params, reg_rcap, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_rcap_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rcap_reg           *reg_rcap)
{
    return mad_access_rcap_reg(sport, dev_id, dr_path_params, reg_rcap, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_access_rgcr_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_rgcr_reg           *reg_rgcr,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RGCR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RGCR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_RGCR_E,
                                   REG_SIZE_DWORDS_RGCR, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_RGCR_pack(reg_rgcr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_RGCR_unpack(reg_rgcr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_rgcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rgcr_reg           *reg_rgcr)
{
    return mad_access_rgcr_reg(sport, dev_id, dr_path_params, reg_rgcr, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_rgcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_rgcr_reg           *reg_rgcr)
{
    return mad_access_rgcr_reg(sport, dev_id, dr_path_params, reg_rgcr, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_access_recr_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_recr_reg           *reg_recr,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RECR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_RECR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_RECR_E,
                                   REG_SIZE_DWORDS_RECR, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_RECR_pack(reg_recr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_RECR_unpack(reg_recr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_recr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_recr_reg           *reg_recr)
{
    return mad_access_recr_reg(sport, dev_id, dr_path_params, reg_recr, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_recr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_recr_reg           *reg_recr)
{
    return mad_access_recr_reg(sport, dev_id, dr_path_params, reg_recr, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_set_pmpr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmpr_reg          * reg_pmpr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMPR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMPR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PMPR_E,
                                   REG_SIZE_DWORDS_PMPR, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PMPR_pack(reg_pmpr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PMPR_unpack(reg_pmpr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_pmpr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pmpr_reg          * reg_pmpr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMPR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PMPR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PMPR_E,
                                   REG_SIZE_DWORDS_PMPR, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PMPR_pack(reg_pmpr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PMPR_unpack(reg_pmpr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}


sxd_status_t mad_get_mfpa_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfpa_reg           *reg_mfpa)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFPA)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFPA));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MFPA_E,
                                   REG_SIZE_DWORDS_MFPA, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MFPA_pack(reg_mfpa, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MFPA_unpack(reg_mfpa, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_mfpa_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfpa_reg          * reg_mfpa)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFPA)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFPA));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MFPA_E,
                                   REG_SIZE_DWORDS_MFPA, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MFPA_pack(reg_mfpa, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MFPA_unpack(reg_mfpa, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_mfba_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfba_reg           *reg_mfba)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFBA)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    /* The MAD is only 64 bytes, op tlv is 16 bytes, reg tlv first dword is
     * occupied, so the register can only be 11 dwords long */
    if (reg_mfba->size > 36) {
        return SXD_STATUS_PARAM_ERROR;
    }

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFBA));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MFBA_E,
                                   REG_SIZE_DWORDS_MFBA, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MFBA_pack(reg_mfba, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MFBA_unpack(reg_mfba, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_mfba_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfba_reg          * reg_mfba)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFBA)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    /* The MAD is only 64 bytes, op tlv is 16 bytes, reg tlv first dword is
     * occupied, so the register can only be 11 dwords long */
    if (reg_mfba->size > 36) {
        return SXD_STATUS_PARAM_ERROR;
    }

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFBA));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MFBA_E,
                                   REG_SIZE_DWORDS_MFBA, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MFBA_pack(reg_mfba, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MFBA_unpack(reg_mfba, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_mfbe_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfbe_reg           *reg_mfbe)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFBE)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFBE));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MFBE_E,
                                   REG_SIZE_DWORDS_MFBE, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MFBE_pack(reg_mfbe, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MFBE_unpack(reg_mfbe, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_mfbe_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mfbe_reg          * reg_mfbe)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFBE)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MFBE));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MFBE_E,
                                   REG_SIZE_DWORDS_MFBE, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MFBE_pack(reg_mfbe, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MFBE_unpack(reg_mfbe, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_pelc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pelc_reg          * reg_pelc)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PELC)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PELC));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PELC_E,
                                   REG_SIZE_DWORDS_PELC, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PELC_pack(reg_pelc, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PELC_unpack(reg_pelc, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_pelc_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_pelc_reg          * reg_pelc)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PELC)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PELC));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PELC_E,
                                   REG_SIZE_DWORDS_PELC, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PELC_pack(reg_pelc, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PELC_unpack(reg_pelc, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_qpbr_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_qpbr_reg           *reg_qpbr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_QPBR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_QPBR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_QPBR_E,
                                   REG_SIZE_DWORDS_QPBR, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_QPBR_pack(reg_qpbr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_QPBR_unpack(reg_qpbr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_qpbr_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_qpbr_reg           *reg_qpbr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_QPBR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_QPBR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_QPBR_E,
                                   REG_SIZE_DWORDS_QPBR, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_QPBR_pack(reg_qpbr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_QPBR_unpack(reg_qpbr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_qpcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_qpcr_reg           *reg_qpcr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_QPCR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_QPCR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_QPCR_E,
                                   REG_SIZE_DWORDS_QPCR, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_QPCR_pack(reg_qpcr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_QPCR_unpack(reg_qpcr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_qpcr_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_qpcr_reg           *reg_qpcr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_QPCR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_QPCR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_QPCR_E,
                                   REG_SIZE_DWORDS_QPCR, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_QPCR_pack(reg_qpcr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_QPCR_unpack(reg_qpcr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}


sxd_status_t mad_get_plbf_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plbf_reg           *reg_plbf)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLBF)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLBF));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PLBF_E,
                                   REG_SIZE_DWORDS_PLBF, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PLBF_pack(reg_plbf, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PLBF_unpack(reg_plbf, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_plbf_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_plbf_reg           *reg_plbf)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLBF)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLBF));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_PLBF_E,
                                   REG_SIZE_DWORDS_PLBF, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_PLBF_pack(reg_plbf, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_PLBF_unpack(reg_plbf, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_sgcr_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_sgcr_reg           *reg_sgcr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLBF)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLBF));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_SGCR_E,
                                   REG_SIZE_DWORDS_PLBF, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_SGCR_pack(reg_sgcr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_SGCR_unpack(reg_sgcr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}


sxd_status_t mad_set_sgcr_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_sgcr_reg           *reg_sgcr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLBF)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_PLBF));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_SGCR_E,
                                   REG_SIZE_DWORDS_PLBF, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_SGCR_pack(reg_sgcr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_SGCR_unpack(reg_sgcr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_mlcr_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mlcr_reg           *reg_mlcr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MLCR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MLCR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MLCR_E,
                                   REG_SIZE_DWORDS_MLCR, TLV_OP_METHOD_QUERY_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MLCR_pack(reg_mlcr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MLCR_unpack(reg_mlcr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_set_mlcr_reg(struct ibmad_port            *sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mlcr_reg           *reg_mlcr)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MLCR)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MLCR));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MLCR_E,
                                   REG_SIZE_DWORDS_MLCR, TLV_OP_METHOD_WRITE_E);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MLCR_pack(reg_mlcr, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MLCR_unpack(reg_mlcr, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_access_msci_reg(struct ibmad_port           * sport,
                                 sxd_dev_id_t                  dev_id,
                                 internal_ib_dr_path_params_t *dr_path_params,
                                 struct ku_msci_reg           *reg_msci,
                                 tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MSCI)];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + (4 * REG_SIZE_DWORDS_MSCI));
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, SXD_REG_ID_MSCI_E,
                                   REG_SIZE_DWORDS_MSCI, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    REG_MSCI_pack(reg_msci, buff + sizeof_tlv_reg + sizeof_tlv_op);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    REG_MSCI_unpack(reg_msci, buff + sizeof_tlv_reg + sizeof_tlv_op);

    return status;
}

sxd_status_t mad_get_msci_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_msci_reg           *reg_msci)
{
    return mad_access_msci_reg(sport, dev_id, dr_path_params, reg_msci, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_set_msci_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_msci_reg           *reg_msci)
{
    return mad_access_msci_reg(sport, dev_id, dr_path_params, reg_msci, TLV_OP_METHOD_WRITE_E);
}

static sxd_status_t translate_cableinfo_status_to_mcia_status(uint32_t mad_status, uint8_t *mcia_status)
{
#define MAD_STATUS_INVALID_PORT                   0x1
#define MAD_STATUS_OPERATION_NOT_SUPPORTED        0x2
#define MAD_STATUS_CABLE_NOT_CONNECTED            0x3
#define MAD_STATUS_NO_EEPROM                      0x4
#define MAD_STATUS_PAGE_NUM_OUT_OF_RANGE          0x5
#define MAD_STATUS_INVALID_DEVICE_ADDRESS_OR_SIZE 0x6
#define MAD_STATUS_INVALID_I2C_SLAVE_ADDRESS      0x7
#define MAD_STATUS_QSFP_SPEC_VIOLATION            0x8
#define MAD_STATUS_I2C_BUS_BUSY                   0x9
#define MCIA_STATUS_GOOD                          0x0
#define MCIA_STATUS_NO_EEPROM                     0x1
#define MCIA_STATUS_MODULE_NOT_SUPPORTED          0x2
#define MCIA_STATUS_MODULE_NOT_CONNECTED          0x3
#define MCIA_STATUS_I2C_ERROR                     0x9
    sxd_status_t status = SXD_STATUS_SUCCESS;
    uint8_t      cableinfo_mad_code = (mad_status >> 2) & 0x7;
    uint8_t      cableinfo_mad_error = (mad_status >> 8) & 0xff;

    *mcia_status = MCIA_STATUS_GOOD;
    if (cableinfo_mad_code == 0) {
        goto out;
    } else if (cableinfo_mad_code != 7) {
        SX_LOG_ERR("translate_cableinfo_status_to_mcia_status: mad_status=0x%x is unknown\n",
                   mad_status);
        status = SXD_STATUS_FW_ERROR;
        goto out;
    }

    switch (cableinfo_mad_error) {
    case MAD_STATUS_INVALID_PORT:
    case MAD_STATUS_PAGE_NUM_OUT_OF_RANGE:
    case MAD_STATUS_INVALID_DEVICE_ADDRESS_OR_SIZE:
    case MAD_STATUS_INVALID_I2C_SLAVE_ADDRESS:
    case MAD_STATUS_QSFP_SPEC_VIOLATION:
        SX_LOG_ERR("Got error %u in Cableinfo MAD\n", cableinfo_mad_error);
        status = SXD_STATUS_PARAM_ERROR;
        break;

    case MAD_STATUS_OPERATION_NOT_SUPPORTED:
        *mcia_status = MCIA_STATUS_MODULE_NOT_SUPPORTED;
        break;

    case MAD_STATUS_CABLE_NOT_CONNECTED:
        *mcia_status = MCIA_STATUS_MODULE_NOT_CONNECTED;
        break;

    case MAD_STATUS_NO_EEPROM:
        *mcia_status = MCIA_STATUS_NO_EEPROM;
        break;

    case MAD_STATUS_I2C_BUS_BUSY:
        *mcia_status = MCIA_STATUS_I2C_ERROR;
        break;

    default:
        SX_LOG_ERR("translate_cableinfo_status_to_mcia_status:"
                   "mad_status=0x%x is unknown\n", mad_status);
        status = SXD_STATUS_FW_ERROR;
        break;
    }

out:
    return status;
}

/* Since MCIA register is too big to fit in a MAD we send a cableinfo
 * vendor specific MAD instead */
static sxd_status_t mad_access_mcia_reg(struct ibmad_port           * sport,
                                        sxd_dev_id_t                  dev_id,
                                        internal_ib_dr_path_params_t *dr_path_params,
                                        struct ku_mcia_reg           *reg_mcia,
                                        tlv_operarion_method_e        method)
{
    ib_dr_path_t *drpath = &dr_path_params->drpath;
    sxd_status_t  status;
    uint8_t       buff[64];
    ib_portid_t   portid;
    unsigned      attr_mod = 0;
    uint16_t      ib_port;
    uint32_t      mad_status = 0;

    UNUSED_PARAM(dev_id);

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, 64);
    CABLE_INFO_pack(reg_mcia, buff);
    ib_port = dpt_ptr->modules_map[dev_id][reg_mcia->module];
    attr_mod = ib_port & 0xffff;
    attr_mod |= (reg_mcia->l & 0x1) << 31;
    status = send_smp_mad(buff, sport, &portid, IB_ATTR_CABLE_INFO,
                          attr_mod, method, &mad_status);
    if (status != SXD_STATUS_SUCCESS) {
        SX_LOG_ERR("Failed sending Cableinfo MAD\n");
        return status;
    }

    CABLE_INFO_unpack(reg_mcia, buff);

    return translate_cableinfo_status_to_mcia_status(mad_status, &reg_mcia->status);
}

sxd_status_t mad_set_mcia_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mcia_reg           *reg_mcia)
{
    return mad_access_mcia_reg(sport, dev_id, dr_path_params, reg_mcia, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_get_mcia_reg(struct ibmad_port           * sport,
                              sxd_dev_id_t                  dev_id,
                              internal_ib_dr_path_params_t *dr_path_params,
                              struct ku_mcia_reg           *reg_mcia)
{
    return mad_access_mcia_reg(sport, dev_id, dr_path_params, reg_mcia, TLV_OP_METHOD_QUERY_E);
}

sxd_status_t mad_access_raw_reg(struct ibmad_port           * sport,
                                sxd_dev_id_t                  dev_id,
                                internal_ib_dr_path_params_t *dr_path_params,
                                struct ku_raw_reg            *reg_raw,
                                uint16_t                      register_id,
                                tlv_operarion_method_e        tlv_op_method)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t         buff[TLV_OPERATION_SIZE + TLV_REG_SIZE + MAX_REG_SIZE_IN_MAD];
    ib_portid_t     portid;

    UNUSED_PARAM(dev_id);

    if (reg_raw->size > MAX_REG_SIZE_IN_MAD) {
        SX_LOG_ERR("mad_access_raw_reg: reg size (%u) is bigger than the maximum "
                   "allowed for MAD (%u)\n", reg_raw->size, MAX_REG_SIZE_IN_MAD);
        return SXD_STATUS_ERROR;
    }

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, TLV_OPERATION_SIZE + TLV_REG_SIZE + MAX_REG_SIZE_IN_MAD);
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, register_id,
                                   (reg_raw->size / 4), tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    memcpy(buff + sizeof_tlv_reg + sizeof_tlv_op, reg_raw->buff, reg_raw->size);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status != SXD_STATUS_SUCCESS) {
        return status;
    }

    memcpy(reg_raw->buff, buff + sizeof_tlv_reg + sizeof_tlv_op, reg_raw->size);

    return status;
}

sxd_status_t mad_set_raw_reg(struct ibmad_port           * sport,
                             sxd_dev_id_t                  dev_id,
                             internal_ib_dr_path_params_t *dr_path_params,
                             uint16_t                      register_id,
                             struct ku_raw_reg            *reg_raw)
{
    return mad_access_raw_reg(sport, dev_id, dr_path_params, reg_raw,
                              register_id, TLV_OP_METHOD_WRITE_E);
}

sxd_status_t mad_get_raw_reg(struct ibmad_port           * sport,
                             sxd_dev_id_t                  dev_id,
                             internal_ib_dr_path_params_t *dr_path_params,
                             uint16_t                      register_id,
                             struct ku_raw_reg            *reg_raw)
{
    return mad_access_raw_reg(sport, dev_id, dr_path_params, reg_raw,
                              register_id, TLV_OP_METHOD_QUERY_E);
}


sxd_status_t sxd_command_mad_access_reg(struct ibmad_port           * sport,
                                        sxd_dev_id_t                  dev_id,
                                        internal_ib_dr_path_params_t *dr_path_params,
                                        sxd_reg_id_e                  reg_id,
                                        tlv_operarion_method_e        tlv_op_method,
                                        void                         *ku_reg_buff,
                                        struct access_reg_mad_params *mad_params)
{
    ib_dr_path_t   *drpath = &dr_path_params->drpath;
    sxd_status_t    status;
    unsigned int    sizeof_tlv_op = 0;
    unsigned int    sizeof_tlv_reg = 0;
    tlv_operation_t tlv_op;
    tlv_reg_t       tlv_reg;
    uint8_t        *buff = NULL;
    uint32_t        buff_sz;
    ib_portid_t     portid;

#define BUFF_SIZE ((TLV_OPERATION_SIZE) + (TLV_REG_SIZE)+4 * mad_params->reg_size_in_dwords)

    buff_sz = BUFF_SIZE;
    if (buff_sz < IB_SMP_DATA_SIZE) {
        buff_sz = IB_SMP_DATA_SIZE; /* MAD always reads IB_SMP_DATA_SIZE bytes */
    }

    buff = (uint8_t*)cl_malloc(buff_sz);
    if (buff == NULL) {
        return SXD_STATUS_NO_MEMORY;
    }

    memset(&portid, 0, sizeof(ib_portid_t));
    memcpy(&portid.drpath, drpath, sizeof(portid.drpath));
    memset(buff, 0, buff_sz);
    prepare_tlv_operation_register(&tlv_op, &tlv_reg, reg_id,
                                   mad_params->reg_size_in_dwords, tlv_op_method);
    sizeof_tlv_op = TLV_OPERATION_pack(&tlv_op, buff);
    sizeof_tlv_reg = TLV_REG_pack(&tlv_reg, buff + sizeof_tlv_op);
    mad_params->reg_pack_cb(ku_reg_buff, buff + sizeof_tlv_reg + sizeof_tlv_op, mad_params->reg_pack_context);
    status = send_access_reg_mad(dev_id, buff, sport, &portid);
    if (status == SXD_STATUS_SUCCESS) {
        mad_params->reg_unpack_cb(ku_reg_buff, buff + sizeof_tlv_reg + sizeof_tlv_op, mad_params->reg_unpack_context);
    }

    cl_free(buff);

    return status;
}
