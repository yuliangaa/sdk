/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/cl_passivelock.h>
#include <sys/mman.h>
#include <errno.h>
#include <sx/sxd/sxd_dpt.h>
#include <sx/sxd/sxd_emad.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/utils/debug_cmd.h>
#include "dpt.h"

#undef  __MODULE__
#define __MODULE__ SXD_DPT

/**********************************************
 *  Global variables
 ***********************************************/

/**********************************************
 *  Local variables
 ***********************************************/

static sx_verbosity_level_t LOG_VAR_NAME(__MODULE__) = SX_VERBOSITY_LEVEL_NOTICE;
sxd_dpt_t *dpt_ptr = NULL;

/**********************************************
 *  Local function declarations
 ***********************************************/

/**********************************************
 *  Function implementations
 ***********************************************/

sxd_status_t sxd_dpt_log_verbosity_level(IN sxd_access_cmd_t cmd, IN sx_verbosity_level_t *verbosity_level_p)
{
    sxd_status_t err = SXD_STATUS_SUCCESS;

    switch (cmd) {
    case SXD_ACCESS_CMD_GET:
        verbosity_level_p[0] = LOG_VAR_NAME(__MODULE__);
        break;

    case SXD_ACCESS_CMD_SET:
        LOG_VAR_NAME(__MODULE__) = verbosity_level_p[0];
        break;

    default:
        SX_LOG_ERR("Reached default access command: [%s]\n", SXD_ACCESS_CMD_STR(cmd));
        err = SXD_STATUS_CMD_UNSUPPORTED;
    }

    SX_LOG_EXIT();
    return err;
}


static void _sxd_dpt_set_access_cb(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    sxd_status_t         status = SXD_STATUS_SUCCESS;
    sxd_dev_id_t         dev_id;
    dpt_access_control_t access_control;

    UNUSED_PARAM(handler_context);
    if (argc != 2) {
        fprintf(stream, "sxd dpt set access control <dev-id> <NO_ACCESS|READ_ONLY|READ_WRITE>\n");
        return;
    }

    dev_id = atoi(argv[0]);
    if (!strcmp(argv[1], "NO_ACCESS")) {
        access_control = NO_ACCESS;
    } else if (!strcmp(argv[1], "READ_ONLY")) {
        access_control = READ_ONLY;
    } else if (!strcmp(argv[1], "READ_WRITE")) {
        access_control = READ_WRITE;
    } else {
        fprintf(stream, "valid access control is: <NO_ACCESS|READ_ONLY|READ_WRITE>\n");
        return;
    }

    if (!SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        fprintf(stream, "invalid dev-id (%u)\n", dev_id);
        return;
    }

    status = sxd_dpt_set_access_control(dev_id, access_control);
    if (SXD_CHECK_FAIL(status)) {
        fprintf(stream, "Failed to sxd_dpt_set_access_control, err = [%d]\n", status);
    }
}


static void _sxd_dpt_get_access_cb(FILE* stream, int argc, const char *argv[], void *handler_context)
{
    sxd_status_t         status = SXD_STATUS_SUCCESS;
    sxd_dev_id_t         dev_id;
    dpt_access_control_t access_control;
    char                *access_str[READ_WRITE + 1] = {"NO_ACCESS", "READ_ONLY", "READ_WRITE"};

    UNUSED_PARAM(handler_context);
    if (argc != 1) {
        fprintf(stream, "sxd dpt get access control <dev-id>\n");
        return;
    }

    dev_id = atoi(argv[0]);

    if (!SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        fprintf(stream, "invalid dev-id (%u)\n", dev_id);
        return;
    }

    status = sxd_dpt_get_access_control(dev_id, &access_control);
    if (SXD_CHECK_FAIL(status)) {
        fprintf(stream, "Failed to sxd_dpt_get_access_control, err = [%d]\n", status);
    } else if (access_control <= sizeof(access_str)) {
        fprintf(stream, "sxd dpt access control %s\n", access_str[access_control]);
    }
}

sxd_status_t sxd_dpt_init(sys_type_t sys_type, sx_log_cb_t logging_cb, const sx_verbosity_level_t verbosity_level)
{
    int          shmid;
    int          i, j;
    int          err;
    sxd_status_t status = SXD_STATUS_SUCCESS;

    sx_log_init(TRUE, NULL, logging_cb);

    LOG_VAR_NAME(__MODULE__) = verbosity_level;

    SX_LOG_ENTER();

    err = cl_shm_create(PATH, &shmid);
    if (err) {
        if (errno == EEXIST) { /* one retry is allowed */
            SX_LOG_WRN("sxd_dpt_init(): Shared memory of the DPT already exists,"
                       "destroying it and re-creating\n");
            cl_shm_destroy(PATH);
            err = cl_shm_create(PATH, &shmid);
        }

        if (err) {
            SX_LOG_ERR("Failed to create shared memory for the DPT\n");
            status = SXD_STATUS_NO_MEMORY;
            goto out;
        }
    }

    if (ftruncate(shmid, sizeof(sxd_dpt_t)) == -1) {
        SX_LOG_ERR("Failed to set shared memory size for the DPT\n");
        cl_shm_destroy(PATH);
        status = SXD_STATUS_NO_MEMORY;
        goto out;
    }

    dpt_ptr = mmap(NULL, sizeof(sxd_dpt_t), PROT_READ | PROT_WRITE, MAP_SHARED, shmid, 0);
    close(shmid);
    if (dpt_ptr == MAP_FAILED) {
        SX_LOG_ERR("Failed to map the shared memory of the DPT\n");
        dpt_ptr = NULL;
        cl_shm_destroy(PATH);
        status = SXD_STATUS_NO_MEMORY;
        goto out;
    }

    memset(dpt_ptr, 0, sizeof(sxd_dpt_t));
    err = cl_plock_init_pshared(&dpt_ptr->p_lock);
    if (err) {
        SX_LOG_ERR("Failed to initialize the DPT rwlock\n");
        munmap(dpt_ptr, sizeof(sxd_dpt_t));
        dpt_ptr = NULL;
        cl_shm_destroy(PATH);
        status = SXD_STATUS_NO_MEMORY;
        goto out;
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);

    dpt_ptr->system_type = sys_type;
    for (i = 0; i < SXD_DEV_ID_MAX; i++) {
        for (j = 0; j < NUMBER_OF_SWIDS; j++) {
            dpt_ptr->table[i][j].first_set_path = CMD_IFC_PATH;
            dpt_ptr->table[i][j].second_set_path = CMD_IFC_PATH;
            dpt_ptr->table[i][j].third_set_path = INVALID_PATH;
        }
        dpt_ptr->chip_type[i] = SXD_CHIP_TYPE_UNKNOWN;
    }
    for (i = 0; i < NUMBER_OF_SWIDS; i++) {
        dpt_ptr->swid_type[i] = SWID_TYPE_UNKNOWN;
    }

    dpt_ptr->dpt_initialized = DPT_INIT_VAL;
    msync(dpt_ptr, sizeof(sxd_dpt_t), MS_SYNC);
    cl_plock_release(&dpt_ptr->p_lock);

    sx_utils_debug_cmd_register_path("sxd dpt get access control <dev-id>",
                                     _sxd_dpt_get_access_cb,
                                     NULL);
    sx_utils_debug_cmd_register_path("sxd dpt set access control <dev-id> <NO_ACCESS|READ_ONLY|READ_WRITE>",
                                     _sxd_dpt_set_access_cb,
                                     NULL);

out:
    SX_LOG_EXIT();
    return status;
}

sxd_status_t sxd_dpt_deinit(void)
{
    int          err = 0;
    sxd_status_t status = SXD_STATUS_SUCCESS;

    SX_LOG_ENTER();

    cl_shm_destroy(PATH);
    if (!dpt_ptr) {
        return status;
    }

    cl_plock_destroy(&dpt_ptr->p_lock);
    err = munmap(dpt_ptr, sizeof(sxd_dpt_t));
    if (err == -1) {
        SX_LOG_ERR("Failed to unmap the shared memory of the DPT\n");
        status = SXD_STATUS_NO_RESOURCES;
    }
    sx_utils_debug_cmd_unregister_path("sxd dpt get access control <dev-id>");
    sx_utils_debug_cmd_unregister_path("sxd dpt set access control <dev-id> <<NO_ACCESS|READ_ONLY|READ_WRITE>");

    SX_LOG_EXIT();
    return SXD_STATUS_SUCCESS;
}

sxd_status_t sxd_dpt_set_access_control(sxd_dev_id_t dev_id, dpt_access_control_t access_control)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);

    dpt_ptr->device_access_control[dev_id] = access_control;

    msync(dpt_ptr, sizeof(sxd_dpt_t), MS_SYNC);
    cl_plock_release(&dpt_ptr->p_lock);

    return status;
}

sxd_status_t sxd_dpt_get_access_control(sxd_dev_id_t dev_id, dpt_access_control_t *access_control_p)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if ((access_control_p == NULL) || (!SXD_DEV_ID_CHECK_RANGE(dev_id))) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Bad parameter for function sxd_dpt_get_access_control\n");
        return status;
    }

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);
    *access_control_p = dpt_ptr->device_access_control[dev_id];
    cl_plock_release(&dpt_ptr->p_lock);

    return status;
}

sxd_status_t sxd_dpt_get_ref_count(uint8_t* ref_count)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (ref_count == NULL) {
        return SXD_STATUS_ERROR;
    }

    if (dpt_ptr == NULL) {
        return SXD_STATUS_ERROR;
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);
    *ref_count = dpt_ptr->ref_count;
    msync(dpt_ptr, sizeof(sxd_dpt_t), MS_SYNC);
    cl_plock_release(&dpt_ptr->p_lock);

    return status;
}

sxd_status_t sxd_dpt_set_ref_count(ref_count_direction_t direction)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (dpt_ptr == NULL) {
        return SXD_STATUS_ERROR;
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);

    if (direction == REF_COUNT_INCREMENT) {
        dpt_ptr->ref_count++;
    } else if (direction == REF_COUNT_DECREMENT) {
        if (dpt_ptr->ref_count > 1) {
            dpt_ptr->ref_count--;
        } else {
            dpt_ptr->ref_count = 0;
        }
    } else {
        status = SXD_STATUS_ERROR;
        msync(dpt_ptr, sizeof(sxd_dpt_t), MS_SYNC);
        cl_plock_release(&dpt_ptr->p_lock);
        return status;
    }
    msync(dpt_ptr, sizeof(sxd_dpt_t), MS_SYNC);
    cl_plock_release(&dpt_ptr->p_lock);

    return status;
}

sxd_status_t sxd_dpt_add_ports_map(sxd_dev_id_t dev_id, local_to_ib_map_t   *ports_map, uint32_t num_of_ports)
{
    uint32_t     i;
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    SX_LOG_NTC("sxd_dpt_add_ports_map: Adding ports map to device %d\n", dev_id);
    cl_plock_excl_acquire(&dpt_ptr->p_lock);

    if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
        SX_LOG_ERR("sxd_dpt_add_ports_map: The access control for device %u "
                   "was not set\n", dev_id);
        status = SXD_STATUS_NOT_INITIALIZED;
        goto out;
    }

    for (i = 0; i < num_of_ports; i++) {
        if ((ports_map[i].local_port >= MAX_SWITCHX_PORTS) ||
            (ports_map[i].port_module >= MAX_SWITCHX_PORTS)) {
            SX_LOG_ERR("sxd_dpt_add_ports_map: port is out of range\n");
            status = SXD_STATUS_PARAM_ERROR;
            goto out;
        }

        dpt_ptr->ports_map[dev_id][ports_map[i].local_port] = ports_map[i].ib_port;
        if (ports_map[i].ib_port > 0) {
            dpt_ptr->modules_map[dev_id][ports_map[i].port_module] = ports_map[i].ib_port;
        }
    }

out:
    msync(dpt_ptr, sizeof(sxd_dpt_t), MS_SYNC);
    cl_plock_release(&dpt_ptr->p_lock);

    return status;
}

sxd_status_t sxd_dpt_path_add(sxd_dev_id_t dev_id, sxd_swid_t swid, dpt_path_type_t path,
                              dpt_path_params_t path_params)
{
    sxd_status_t        status = SXD_STATUS_SUCCESS;
    dpt_encapsulation_t old_path;

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    SX_LOG_INF("sxd_dpt_path_add: Add path to dev_id (%d) swid (%d) path type (%s)\n",
               dev_id, swid, path == DR_PATH ? "DR_PATH" : "SYS_PORT_ROUTE_PATH");
    cl_plock_excl_acquire(&dpt_ptr->p_lock);

    if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
        SX_LOG_ERR("The access control for device %u wasn't set\n", dev_id);
        status = SXD_STATUS_NOT_INITIALIZED;
        goto out;
    }

    switch (path) {
#ifdef IB_PRESENT_FLAG
    case DR_PATH:
        old_path = dpt_ptr->table[dev_id][swid].second_set_path;
        dpt_translate_local_to_ib_path(dev_id, swid, &path_params.dr_params);
        dpt_ptr->table[dev_id][swid].dr_params.local_ports_dr.path_len =
            path_params.dr_params.dr_path[0].path_len;
        memcpy(&dpt_ptr->table[dev_id][swid].dr_params.local_ports_dr.path_ports,
               path_params.dr_params.dr_path[0].path_ports,
               path_params.dr_params.dr_path[0].path_len * sizeof(uint16_t));
        memcpy(&dpt_ptr->table[dev_id][swid].dr_params.local_ports_dr.path_device_id,
               path_params.dr_params.dr_path[0].path_device_id,
               path_params.dr_params.dr_path[0].path_len * sizeof(uint16_t));
        dpt_ptr->table[dev_id][swid].dr_params.is_valid = 1;
        dpt_ptr->table[dev_id][swid].second_set_path = MAD_PATH;
        dpt_ptr->swid_type[swid] = SWID_TYPE_IB;
        if (old_path != MAD_PATH) {
            SX_LOG_NTC("sxd_dpt_path_add: Path for device (%d) was changed "
                       "to MAD_PATH\n", dev_id);
        }

        break;

#endif
    case SYS_PORT_ROUTE_PATH:
        old_path = dpt_ptr->table[dev_id][swid].first_set_path;
        dpt_ptr->table[dev_id][swid].sys_port_params.sys_port = path_params.sys_port_params.sys_port;
        dpt_ptr->table[dev_id][swid].sys_port_params.is_valid = 1;
        dpt_ptr->table[dev_id][swid].first_set_path = EMAD_PATH;
        dpt_ptr->table[dev_id][swid].third_set_path = EMAD_PATH;
        dpt_ptr->swid_type[swid] = SWID_TYPE_EN;
        if (old_path != EMAD_PATH) {
            SX_LOG_NTC("sxd_dpt_path_add: Path for device (%d) was changed "
                       "to EMAD_PATH\n", dev_id);
        }
        /* In older FW versions the string_tlv and latency_tlv headers may not be supported */
        dpt_ptr->string_tlv_cap[dev_id] = FALSE;
        dpt_ptr->latency_tlv_cap[dev_id] = FALSE;
        break;

    case OOB_PATH:
        old_path = dpt_ptr->table[dev_id][swid].first_set_path;
        memcpy(&dpt_ptr->table[dev_id][swid].oob_params,
               &path_params.oob_params,
               sizeof(dpt_ptr->table[dev_id][swid].oob_params));
        dpt_ptr->table[dev_id][swid].first_set_path = EMAD_PATH;
        dpt_ptr->table[dev_id][swid].second_set_path = EMAD_PATH;
        dpt_ptr->table[dev_id][swid].third_set_path = EMAD_PATH;
        dpt_ptr->swid_type[swid] = SWID_TYPE_IB;
        if (old_path != EMAD_PATH) {
            SX_LOG_NTC("sxd_dpt_path_add: Path for device (%d) was changed "
                       "to EMAD_PATH\n", dev_id);
        }
        /* In older FW versions the string_tlv and latency_tlv headers may not be supported */
        dpt_ptr->string_tlv_cap[dev_id] = FALSE;
        dpt_ptr->latency_tlv_cap[dev_id] = FALSE;

        break;

    case CMD_IF_PATH: /* this option is a WA and should be used only in modular systems! */
        old_path = dpt_ptr->table[dev_id][swid].first_set_path;
        dpt_ptr->table[dev_id][swid].first_set_path = CMD_IFC_PATH; /* Used for ETH SWID */
        dpt_ptr->table[dev_id][swid].second_set_path = CMD_IFC_PATH; /* Used for IB SWID */
        dpt_ptr->table[dev_id][swid].third_set_path = CMD_IFC_PATH;
        dpt_ptr->swid_type[swid] = SWID_TYPE_IB;
        if (old_path != CMD_IFC_PATH) {
            SX_LOG_NTC("sxd_dpt_path_add: Path for device (%d) was changed "
                       "to CMD_IFC_PATH\n", dev_id);
        }
        break;

    default:
        SX_LOG_WRN("Got an invalid path to add to the DPT\n");
        status = SXD_STATUS_PARAM_ERROR;
    }

out:
    msync(dpt_ptr, sizeof(sxd_dpt_t), MS_SYNC);
    cl_plock_release(&dpt_ptr->p_lock);

    return status;
}

sxd_status_t sxd_dpt_path_remove(sxd_dev_id_t dev_id, sxd_swid_t swid, dpt_path_type_t path)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    SX_LOG_INF("sxd_dpt_path_remove: Remove path from dev_id (%d) swid (%d) path type (%s)\n",
               dev_id, swid, path == DR_PATH ? "DR_PATH" : "SYS_PORT_ROUTE_PATH");
    cl_plock_excl_acquire(&dpt_ptr->p_lock);

    if (dpt_ptr->device_access_control[dev_id] == NO_ACCESS) {
        SX_LOG_ERR("The access control for device %u wasn't set\n", dev_id);
        status = SXD_STATUS_NOT_INITIALIZED;
        goto out;
    }

    switch (path) {
#ifdef IB_PRESENT_FLAG
    case DR_PATH:
        if (dpt_ptr->table[dev_id][swid].second_set_path != MAD_PATH) {
            SX_LOG_ERR("DR_PATH was not added so it cannot be removed\n");
        }
        dpt_ptr->table[dev_id][swid].dr_params.drpath.cnt = 0;
        dpt_ptr->table[dev_id][swid].dr_params.is_valid = 0;
        dpt_ptr->table[dev_id][swid].second_set_path = CMD_IFC_PATH;
        SX_LOG_NTC("sxd_dpt_path_remove: Path for device (%d) was changed to CMD_IFC_PATH\n", dev_id);
        break;

#endif
    case SYS_PORT_ROUTE_PATH:
        if ((dpt_ptr->table[dev_id][swid].first_set_path != EMAD_PATH) &&
            (dpt_ptr->table[dev_id][swid].third_set_path != EMAD_PATH)) {
            SX_LOG_ERR("SYS_PORT_ROUTE_PATH was not added so it cannot be removed\n");
        }
        dpt_ptr->table[dev_id][swid].sys_port_params.is_valid = 0; /* Invalidate the params */
        dpt_ptr->table[dev_id][swid].first_set_path = CMD_IFC_PATH;
        dpt_ptr->table[dev_id][swid].third_set_path = INVALID_PATH;
        SX_LOG_NTC("sxd_dpt_path_remove: Path for device (%d) was changed to CMD_IFC_PATH\n", dev_id);
        break;

    default:
        SX_LOG_ERR("Error: Got an invalid path\n");
        status = SXD_STATUS_PARAM_ERROR;
    }

out:
    msync(dpt_ptr, sizeof(sxd_dpt_t), MS_SYNC);
    cl_plock_release(&dpt_ptr->p_lock);

    return status;
}


sxd_status_t sxd_dpt_set_uc_route(uint16_t system_port, sxd_dev_id_t dev_id, uint16_t local_port, uint8_t is_ib_port)
{
    sxd_status_t status;

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    if (SXD_DEV_ID_CHECK_RANGE(dev_id) == FALSE) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("sxd_dpt_set_uc_route: Device ID %d is not in range [%d-%d] \n",
                   dev_id, SXD_DEV_ID_MIN, SXD_DEV_ID_MAX);
        return status;
    }

    if (local_port > (MAX_SWITCHX_PORTS - 1)) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("sxd_dpt_set_uc_route: local port [%d] is out of range\n", local_port);
        return status;
    }

    if (system_port > (MAX_SWITCHX_SYSTEM_PORTS - 1)) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("sxd_dpt_set_uc_route: sys port [%d] is out of range\n", system_port);
        return status;
    }
    cl_plock_acquire(&dpt_ptr->p_lock);

    if (is_ib_port == FALSE) {
        dpt_ptr->local_to_system[dev_id][local_port] = system_port;
    }
    dpt_ptr->system_to_local[system_port].dev_id = dev_id;
    dpt_ptr->system_to_local[system_port].local_port = local_port;

    cl_plock_release(&dpt_ptr->p_lock);
    return SXD_STATUS_SUCCESS;
}

sxd_status_t sxd_dpt_get_local_port_by_uc_route(uint16_t           system_port,
                                                sxd_dev_id_t      *dev_id,
                                                sxd_port_phy_id_t *local_port)
{
    sxd_status_t status;

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    if (system_port > (MAX_SWITCHX_SYSTEM_PORTS - 1)) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("sxd_dpt_get_local_port_by_uc_route: port is out of range\n");
        return status;
    }
    cl_plock_acquire(&dpt_ptr->p_lock);

    *dev_id = dpt_ptr->system_to_local[system_port].dev_id;
    *local_port = dpt_ptr->system_to_local[system_port].local_port;

    cl_plock_release(&dpt_ptr->p_lock);
    return SXD_STATUS_SUCCESS;
}

sxd_status_t sxd_dpt_get_uc_route_by_local_port(sxd_dev_id_t dev_id, uint16_t local_port, uint16_t *system_port)
{
    sxd_status_t status;

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    if (SXD_DEV_ID_CHECK_RANGE(dev_id) == FALSE) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("sxd_dpt_get_uc_route_by_local_port: Device ID %d is not in range [%d-%d] \n",
                   dev_id, SXD_DEV_ID_MIN, SXD_DEV_ID_MAX);
        return status;
    }

    if (local_port > (MAX_SWITCHX_PORTS - 1)) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("xd_dpt_get_uc_route_by_local_port: port is out of range\n");
        return status;
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    *system_port = dpt_ptr->local_to_system[dev_id][local_port];

    cl_plock_release(&dpt_ptr->p_lock);
    return SXD_STATUS_SUCCESS;
}

sxd_status_t sxd_dpt_port_max_lanes_per_module_set(uint8_t lanes_per_module)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (dpt_ptr == NULL) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't load dpt shared memory db\n");
            goto out;
        }
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);

    dpt_ptr->lanes_num_per_module_max = lanes_per_module;

    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}

sxd_status_t sxd_dpt_port_module_map_set(const sxd_access_cmd_t  cmd,
                                         const sxd_dev_id_t      device_id,
                                         const sxd_slot_id_t     slot_id,
                                         const sxd_port_mod_id_t module_id,
                                         const sxd_port_phy_id_t port)
{
    uint16_t     i, j;
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (device_id >= SXD_DEV_ID_MAX) {
        SX_LOG_ERR("Bad parameter for function sxd_dpt_port_module_map_set\n");
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (dpt_ptr == NULL) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't load dpt shared memory db\n");
            goto out;
        }
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);

    switch (cmd) {
    case SXD_ACCESS_CMD_SET:
        for (i = 0; i < dpt_ptr->modules_to_port_map_count[device_id][slot_id][module_id]; i++) {
            if (dpt_ptr->module_to_ports_map[device_id][slot_id][module_id][i] == port) {
                cl_plock_release(&dpt_ptr->p_lock);
                goto out;
            }
        }

        if (dpt_ptr->modules_to_port_map_count[device_id][slot_id][module_id] == dpt_ptr->lanes_num_per_module_max) {
            status = SXD_STATUS_PARAM_ERROR;
            /* coverity[lock_order] */
            SX_LOG_ERR("modules to port map is full\n");
            break;
        }
        dpt_ptr->module_to_ports_map[device_id][slot_id][module_id][dpt_ptr->modules_to_port_map_count[device_id][
                                                                        slot_id][module_id]] =
            port;
        dpt_ptr->modules_to_port_map_count[device_id][slot_id][module_id]++;
        dpt_ptr->port_to_module_map[device_id][port] = module_id;
        dpt_ptr->port_to_slot_map[device_id][port] = slot_id;
        break;

    case SXD_ACCESS_CMD_DELETE:
        if (((dpt_ptr->port_to_slot_map[device_id][port] != slot_id) ||
             (dpt_ptr->port_to_module_map[device_id][port] != module_id)) ||
            (dpt_ptr->modules_to_port_map_count[device_id][slot_id][module_id] == 0)) {
            break;
        }
        for (i = 0; i < dpt_ptr->modules_to_port_map_count[device_id][slot_id][module_id]; i++) {
            if (dpt_ptr->module_to_ports_map[device_id][slot_id][module_id][i] == port) {
                for (j = i; j < dpt_ptr->modules_to_port_map_count[device_id][slot_id][module_id] - 1; j++) {
                    dpt_ptr->module_to_ports_map[device_id][slot_id][module_id][j] =
                        dpt_ptr->module_to_ports_map[device_id][slot_id][module_id][j + 1];
                }
                dpt_ptr->modules_to_port_map_count[device_id][slot_id][module_id]--;
                break;
            }
        }
        break;

    default:
        SX_LOG_ERR("unsupported command (%d).\n", cmd);
        status = SXD_STATUS_CMD_UNSUPPORTED;
        break;
    }

    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}

sxd_status_t sxd_dpt_port_module_map_port_get(const sxd_dev_id_t      device_id,
                                              const sxd_slot_id_t     slot_id,
                                              const sxd_port_mod_id_t module_id,
                                              sxd_port_phy_id_t      *port_list_p,
                                              uint32_t               *list_size_p)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;
    uint32_t     i;

    if ((list_size_p == NULL) || (port_list_p == NULL) || (device_id >= SXD_DEV_ID_MAX)) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Bad parameter for function sxd_dpt_port_module_map_port_get\n");
        goto out;
    }

    if (dpt_ptr == NULL) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't load dpt shared memory db\n");
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);
    for (i = 0; i < dpt_ptr->modules_to_port_map_count[device_id][slot_id][module_id]; i++) {
        port_list_p[i] = dpt_ptr->module_to_ports_map[device_id][slot_id][module_id][i];
    }
    *list_size_p = dpt_ptr->modules_to_port_map_count[device_id][slot_id][module_id];
    cl_plock_release(&dpt_ptr->p_lock);
out:
    return status;
}

sxd_status_t sxd_dpt_port_module_map_module_get(const sxd_dev_id_t      device_id,
                                                const sxd_port_phy_id_t port,
                                                sxd_slot_id_t          *slot_id,
                                                sxd_port_mod_id_t      *module_id)
{
    sxd_status_t      status = SXD_STATUS_SUCCESS;
    sxd_port_mod_id_t temp_module;
    sxd_slot_id_t     temp_slot;
    uint32_t          i;
    uint8_t           found = 0;

    if ((slot_id == NULL) || (module_id == NULL) || (device_id >= SXD_DEV_ID_MAX)) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Bad parameter for function sxd_dpt_port_module_map_module_get\n");
        goto out;
    }

    if (dpt_ptr == NULL) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't load dpt shared memory db\n");
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);
    temp_module = dpt_ptr->port_to_module_map[device_id][port];
    temp_slot = dpt_ptr->port_to_slot_map[device_id][port];
    for (i = 0; i < dpt_ptr->modules_to_port_map_count[device_id][temp_slot][temp_module]; i++) {
        if (dpt_ptr->module_to_ports_map[device_id][temp_slot][temp_module][i] == port) {
            *module_id = temp_module;
            *slot_id = temp_slot;
            found = 1;
            break;
        }
    }
    if (!found) {
        status = SXD_STATUS_PARAM_ERROR;
    }
    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}

sxd_status_t sxd_dpt_mirror_label_port_map_set(const sxd_dev_id_t      device_id,
                                               const sxd_port_phy_id_t port,
                                               const uint16_t          label_port)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (device_id >= SXD_DEV_ID_MAX) {
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (port >= MAX_SWITCHX_PORTS) {
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    dpt_ptr->port_to_mirror_label_port_map[device_id][port] = label_port;

    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}

sxd_status_t sxd_dpt_mirror_label_port_map_port_get(const sxd_dev_id_t device_id,
                                                    const uint16_t     label_port,
                                                    sxd_port_phy_id_t *port)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;
    uint16_t     i = 0;

    if (device_id >= SXD_DEV_ID_MAX) {
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == port) {
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't load dpt shared memory db\n");
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    for (i = 0; i < MAX_SWITCHX_PORTS; i++) {
        if (dpt_ptr->port_to_mirror_label_port_map[device_id][i] == label_port) {
            *port = i;
            cl_plock_release(&dpt_ptr->p_lock);
            goto out;
        }
    }

    status = SXD_STATUS_ERROR;

    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}

sxd_status_t sxd_dpt_mirror_label_port_map_label_port_get(const sxd_dev_id_t      device_id,
                                                          const sxd_port_phy_id_t port,
                                                          uint16_t               *label_port)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (port >= MAX_SWITCHX_PORTS) {
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (device_id >= SXD_DEV_ID_MAX) {
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == label_port) {
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't load dpt shared memory db\n");
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    *label_port = dpt_ptr->port_to_mirror_label_port_map[device_id][port];

    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}


sxd_status_t sxd_dpt_span_session_map_set(sxd_access_cmd_t cmd,
                                          const uint8_t    span_session_id,
                                          const uint8_t    hw_span_session_id)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (span_session_id >= MAX_SPAN_SESSION_IDS) {
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    if (cmd == SXD_ACCESS_CMD_ADD) {
        dpt_ptr->span_session_id_sdk_to_hw[span_session_id] = hw_span_session_id;
        dpt_ptr->span_session_id_valid[span_session_id] = 1;
    } else if (cmd == SXD_ACCESS_CMD_DELETE) {
        dpt_ptr->span_session_id_sdk_to_hw[span_session_id] = 0;
        dpt_ptr->span_session_id_valid[span_session_id] = 0;
    } else {
        status = SXD_STATUS_ERROR;
        /* coverity[lock_order] */
        SX_LOG_ERR("span session map set wrong cmd : %d \n", cmd);
    }

    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}


sxd_status_t sxd_dpt_span_session_map_get(const uint8_t span_session_id, uint8_t        *hw_span_session_id_p)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (span_session_id >= MAX_SPAN_SESSION_IDS) {
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == hw_span_session_id_p) {
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Can't load dpt shared memory db\n");
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    if (dpt_ptr->span_session_id_valid[span_session_id] == 0) {
        status = SXD_STATUS_ERROR;
        cl_plock_release(&dpt_ptr->p_lock);
        goto out;
    }

    *hw_span_session_id_p =
        dpt_ptr->span_session_id_sdk_to_hw[span_session_id];

    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}


sxd_status_t sxd_dpt_vtrap_mapping_set(uint32_t vtrap, uint32_t trap)
{
    sxd_status_t status;

    if (vtrap > SXD_TRAPS_NUM) {
        return SXD_STATUS_PARAM_ERROR;
    }

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    dpt_ptr->host_ifc_vtrap2trap_map[vtrap] = trap;
    if (dpt_ptr->host_ifc_hwtrap2vtrap_map[trap] == 0) {
        dpt_ptr->host_ifc_hwtrap2vtrap_map[trap] = vtrap;
    }

    cl_plock_release(&dpt_ptr->p_lock);
    return SXD_STATUS_SUCCESS;
}

sxd_status_t sxd_dpt_vtrap_virt_to_hw_mapping_get(uint32_t vtrap, uint32_t *trap)
{
    sxd_status_t status;

    if (vtrap > SXD_TRAPS_NUM) {
        return SXD_STATUS_PARAM_ERROR;
    }

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    /* if mapping is not set vtrap is trap */
    *trap = dpt_ptr->host_ifc_vtrap2trap_map[vtrap];
    if (*trap == 0) {
        *trap = vtrap;
    }

    cl_plock_release(&dpt_ptr->p_lock);
    return SXD_STATUS_SUCCESS;
}

sxd_status_t sxd_dpt_vtrap_hw_to_virt_mapping_get(uint32_t trap, uint32_t *vtrap)
{
    sxd_status_t status;

    if (trap > SXD_TRAPS_NUM) {
        return SXD_STATUS_PARAM_ERROR;
    }

    if (NULL == dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            return status;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    /* if mapping is not set vtrap is trap */
    *vtrap = dpt_ptr->host_ifc_hwtrap2vtrap_map[trap];
    if (*vtrap == 0) {
        *vtrap = trap;
    }

    cl_plock_release(&dpt_ptr->p_lock);
    return SXD_STATUS_SUCCESS;
}


sxd_status_t sxd_dpt_set_device_type(sxd_dev_id_t dev_id, const sxd_chip_types_t dev_type)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (FALSE == SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        SX_LOG_ERR("dev_id %d exceed range [0..%d]\n",
                   dev_id, SXD_DEV_ID_MAX);
        status = SXD_STATUS_PARAM_ERROR;
        goto out;
    }

    if (!dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            goto out;
        }
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);

    dpt_ptr->chip_type[dev_id] = dev_type;

    /* if this is a "new type" we have not yet learned, we need to get it's "fw debug instructions"
     * since the  sxd_init_fw_dbg_info_per_asic_type makes a "singleton" object just call it */
    /* coverity[lock_order] */
    status = sxd_fw_dbg_init_info_per_asic_type(dev_type);

    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}

sxd_status_t sxd_dpt_get_device_type(sxd_dev_id_t dev_id, sxd_chip_types_t *ret_chip_type)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (FALSE == SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        SX_LOG_ERR("dev_id %d exceed range [0..%d]\n",
                   dev_id, SXD_DEV_ID_MAX);
        return SXD_STATUS_PARAM_ERROR;
    }

    if (!dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    *ret_chip_type = dpt_ptr->chip_type[dev_id];

    cl_plock_release(&dpt_ptr->p_lock);
out:
    return status;
}

sxd_status_t sxd_dpt_set_string_tlv_cap(sxd_dev_id_t dev_id, boolean_t is_enabled)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (!SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Bad parameter for function sxd_dpt_set_string_tlv_cap\n");
        goto out;
    }

    if (!dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            goto out;
        }
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);
    dpt_ptr->string_tlv_cap[dev_id] = is_enabled;
    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}


sxd_status_t sxd_dpt_get_string_tlv_cap(sxd_dev_id_t dev_id, boolean_t    *is_enabled)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (!SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Bad parameter for function sxd_dpt_set_string_tlv_cap\n");
        goto out;
    }

    if (!dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);
    *is_enabled = dpt_ptr->string_tlv_cap[dev_id];
    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}


sxd_status_t sxd_dpt_set_latency_tlv_cap(sxd_dev_id_t dev_id, boolean_t is_enabled)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (!SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Bad parameter for function sxd_dpt_set_latency_tlv_cap\n");
        goto out;
    }

    if (!dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            goto out;
        }
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);
    dpt_ptr->latency_tlv_cap[dev_id] = is_enabled;
    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}


sxd_status_t sxd_dpt_get_latency_tlv_cap(sxd_dev_id_t dev_id, boolean_t    *is_enabled)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (!SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Bad parameter for function sxd_dpt_set_latency_tlv_cap\n");
        goto out;
    }

    if (!dpt_ptr) {
        status = dpt_load();
        if (status != SXD_STATUS_SUCCESS) {
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);
    *is_enabled = dpt_ptr->latency_tlv_cap[dev_id];
    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}


void sxd_set_device_ready(sxd_dev_id_t dev_id)
{
    struct ku_mgir_reg mgir_data;
    sxd_reg_meta_t     mgir_meta;
    sxd_status_t       st = SXD_STATUS_SUCCESS;
    boolean_t          emad_enabled = FALSE;
    sxd_swid_t         swid;

    memset(&mgir_data, 0, sizeof(mgir_data));
    memset(&mgir_meta, 0, sizeof(mgir_meta));

    if (!SXD_DEV_ID_CHECK_RANGE(dev_id)) {
        SX_LOG_ERR("SXD: Bad parameter on device-ready event\n");
        goto out;
    }

    if (!dpt_ptr) {
        st = dpt_load();
        if (st != SXD_STATUS_SUCCESS) {
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);
    for (swid = 0; swid < SXD_SWID_ID_COUNT; swid++) {
        if (dpt_ptr->table[dev_id][swid].first_set_path == EMAD_PATH) {
            emad_enabled = TRUE;
            break;
        }
    }
    cl_plock_release(&dpt_ptr->p_lock);

    if (!emad_enabled) {
        goto out;
    }

    mgir_meta.dev_id = dev_id;
    mgir_meta.swid = swid;
    mgir_meta.access_cmd = SXD_ACCESS_CMD_GET;
    st = sxd_access_reg_mgir(&mgir_data, &mgir_meta, 1, NULL, NULL);

out:
    SX_LOG_NTC("SXD device ready event status = %u\n", st);
}

sxd_status_t sxd_dpt_fw_dump_in_progress_set(boolean_t in_progress, boolean_t *already_set)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;
    boolean_t    value_in_dpt = FALSE;

    if (already_set == NULL) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Parameter already_set is NULL\n");
        goto out;
    }

    if (dpt_ptr == NULL) {
        status = dpt_load();
        if (SXD_CHECK_FAIL(status)) {
            goto out;
        }
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);
    value_in_dpt = dpt_ptr->fw_dump_in_progress;
    if ((value_in_dpt && in_progress) ||
        ((!value_in_dpt) && (!in_progress))) {
        *already_set = TRUE;
    } else {
        dpt_ptr->fw_dump_in_progress = !!in_progress;
        msync(dpt_ptr, sizeof(sxd_dpt_t), MS_SYNC);
        *already_set = FALSE;
    }
    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}

sxd_status_t sxd_dpt_issu_in_progress_set(boolean_t in_progress)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (dpt_ptr == NULL) {
        status = dpt_load();
        if (SXD_CHECK_FAIL(status)) {
            goto out;
        }
    }

    cl_plock_excl_acquire(&dpt_ptr->p_lock);
    dpt_ptr->issu_in_progress = !!in_progress;
    msync(dpt_ptr, sizeof(sxd_dpt_t), MS_SYNC);
    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}

sxd_status_t sxd_dpt_issu_in_progress_get(boolean_t *in_progress)
{
    sxd_status_t status = SXD_STATUS_SUCCESS;

    if (in_progress == NULL) {
        status = SXD_STATUS_PARAM_ERROR;
        SX_LOG_ERR("Parameter in_progress is NULL\n");
        goto out;
    }

    if (dpt_ptr == NULL) {
        status = dpt_load();
        if (SXD_CHECK_FAIL(status)) {
            goto out;
        }
    }

    cl_plock_acquire(&dpt_ptr->p_lock);
    *in_progress = dpt_ptr->issu_in_progress;
    cl_plock_release(&dpt_ptr->p_lock);

out:
    return status;
}

sxd_status_t sxd_dpt_is_emad_used(sxd_dev_id_t dev_id, boolean_t *is_emad_used)
{
    dpt_encapsulation_t    encapsulation = INVALID_PATH;
    sxd_status_t           sxd_rc = SXD_STATUS_SUCCESS;
    internal_path_params_t params;
    uint32_t               group = 0;

    memset(&params, 0, sizeof(params));

    for (group = FIRST_GROUP; group < NUM_OF_GROUPS; group++) {
        sxd_rc = dpt_get_encapsulation(dev_id, 0, group, &encapsulation, &params, FALSE);
        if (sxd_rc != SXD_STATUS_SUCCESS) {
            SX_LOG_ERR("Failed to get encapsulation to find if EMAD is used\n");
            goto out;
        }

        if (encapsulation == EMAD_PATH) {
            *is_emad_used = TRUE;
            goto out;
        }
    }

    *is_emad_used = FALSE;

out:
    return sxd_rc;
}

static const char * __sys_type_to_str(sys_type_t sys_type)
{
    switch (sys_type) {
    case SYS_TYPE_EN:
        return "Ethernet";

    case SYS_TYPE_IB:
        return "Infiniband";

    case SYS_TYPE_VPI:
        return "VPI";

    default:
        break;
    }

    return "N/A";
}

static const char * __swid_type_to_str(swid_type_t swid_type)
{
    switch (swid_type) {
    case SWID_TYPE_EN:
        return "Ethernet";

    case SWID_TYPE_IB:
        return "Infiniband";

    case SWID_TYPE_UNKNOWN:
        return "Unknown";

    default:
        break;
    }

    return "N/A";
}

static const char * __encap_to_str(dpt_encapsulation_t encap)
{
    switch (encap) {
    case INVALID_PATH:
        return "Invalid";

    case EMAD_PATH:
        return "EMAD";

    case MAD_PATH:
        return "MAD";

    case CMD_IFC_PATH:
        return "Command-Interface";

    default:
        break;
    }

    return "N/A";
}

static const char * __access_control_to_str(dpt_access_control_t ac)
{
    switch (ac) {
    case NO_ACCESS:
        return "No-Access";

    case READ_ONLY:
        return "Read-Only";

    case READ_WRITE:
        return "Read-Write";

    default:
        break;
    }

    return "N/A";
}

static const char * __chip_type_to_str(sxd_chip_types_t chip_type)
{
    switch (chip_type) {
    case SXD_CHIP_TYPE_UNKNOWN:
        return "Unknown";

    case SXD_CHIP_TYPE_SWITCHX_A2:
        return "SwitchX-A2";

    case SXD_CHIP_TYPE_SWITCHX_A1:
        return "SwitchX-A1";

    case SXD_CHIP_TYPE_SWITCHX_A0:
        return "SwitchX-A0";

    case SXD_CHIP_TYPE_SWITCH_IB:
        return "Switch-IB";

    case SXD_CHIP_TYPE_SPECTRUM:
        return "Spectrum-1";

    case SXD_CHIP_TYPE_SWITCH_IB2:
        return "Switch-IB/2";

    case SXD_CHIP_TYPE_SPECTRUM_A1:
        return "Spectrum-A1";

    case SXD_CHIP_TYPE_SPECTRUM2:
        return "Spectrum-2";

    case SXD_CHIP_TYPE_QUANTUM:
        return "Quantum";

    case SXD_CHIP_TYPE_SPECTRUM3:
        return "Spectrum-3";

    case SXD_CHIP_TYPE_QUANTUM2:
        return "Quantum-2";

    case SXD_CHIP_TYPE_SPECTRUM4:
        return "Spectrum-4";

    case SXD_CHIP_TYPE_QUANTUM3:
        return "Quantum-3";

    case SXD_CHIP_TYPE_SPECTRUM5:
        return "Spectrum-5";

    default:
        break;
    }

    return "N/A";
}

void sxd_dpt_dump(FILE* stream, sxd_dev_id_t dev_id)
{
    int i;

    if (!dpt_ptr) {
        fprintf(stream, "DPT is NULL\n");
        return;
    }

    if (!dpt_ptr->dpt_initialized) {
        fprintf(stream, "DPT is not initialized\n");
        return;
    }

    cl_plock_acquire(&dpt_ptr->p_lock);

    fprintf(stream, "Globals\n");
    fprintf(stream, "    system_type .......................... %s (%u)\n",
            __sys_type_to_str(dpt_ptr->system_type),
            dpt_ptr->system_type);
    fprintf(stream, "    swid_type ............................ {");
    for (i = 0; i < SXD_SWID_ID_COUNT; i++) {
        fprintf(stream, "%s (%u), ",
                __swid_type_to_str(dpt_ptr->swid_type[i]),
                dpt_ptr->swid_type[i]);
    }
    fprintf(stream, "}\n");
    fprintf(stream, "    fw_dump_in_progress .................. %s\n",
            ((dpt_ptr->fw_dump_in_progress) ? "True" : "False"));
    fprintf(stream, "    issu_in_progress ..................... %s\n",
            ((dpt_ptr->issu_in_progress) ? "True" : "False"));
    fprintf(stream, "    lanes_num_per_module_max ............. %u\n",
            dpt_ptr->lanes_num_per_module_max);

    fprintf(stream, "\n");

    fprintf(stream, "Device #%u\n", dev_id);

    fprintf(stream, "    device_access_control ................ %s (%d)\n",
            __access_control_to_str(dpt_ptr->device_access_control[dev_id]),
            dpt_ptr->device_access_control[dev_id]);
    fprintf(stream, "    chip_type ............................ %s (%d)\n",
            __chip_type_to_str(dpt_ptr->chip_type[dev_id]),
            dpt_ptr->chip_type[dev_id]);
    fprintf(stream, "    table\n");
    fprintf(stream, "        1st_path ......................... %s (%d)\n",
            __encap_to_str(dpt_ptr->table[dev_id][0].first_set_path),
            dpt_ptr->table[dev_id][0].first_set_path);
    fprintf(stream, "        2nd_path ......................... %s (%d)\n",
            __encap_to_str(dpt_ptr->table[dev_id][0].second_set_path),
            dpt_ptr->table[dev_id][0].second_set_path);
    fprintf(stream, "        3rd_path ......................... %s (%d)\n",
            __encap_to_str(dpt_ptr->table[dev_id][0].third_set_path),
            dpt_ptr->table[dev_id][0].third_set_path);
    fprintf(stream, "    string_tlv_cap ....................... %s\n",
            ((dpt_ptr->string_tlv_cap[dev_id]) ? "True" : "False"));
    fprintf(stream, "    latency_tlv_cap ...................... %s\n",
            ((dpt_ptr->latency_tlv_cap[dev_id]) ? "True" : "False"));
    cl_plock_release(&dpt_ptr->p_lock);
}
