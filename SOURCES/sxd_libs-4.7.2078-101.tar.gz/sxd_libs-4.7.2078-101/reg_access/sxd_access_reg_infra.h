/*
 * Copyright (C) 2010-2024 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#ifndef __SXD_ACCESS_REG_INFRA_H__
#define __SXD_ACCESS_REG_INFRA_H__

#include <sx/sxd/sxd_registers.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_emad_buffer.h>

#define REGISTER_NAME_MAX_LEN (16)

struct access_reg_ifc_params {
    enum ku_ctrl_cmd_access_reg ctrl_cmd;
};

struct access_ifc_params {
    enum ku_ctrl_cmd ctrl_cmd;
};

typedef uint32_t (*sxd_mad_reg_pack_cb_t)(const void* ku_reg_buff,
                                          uint8_t   * packed_buffer,
                                          void      * context);

typedef void (*sxd_mad_reg_unpack_cb_t)(void   * ku_reg_buff,
                                        uint8_t* buffer_to_unpack,
                                        void   * context);

struct access_reg_mad_params {
    uint32_t                reg_size_in_dwords;
    sxd_mad_reg_pack_cb_t   reg_pack_cb;
    void                  * reg_pack_context;
    sxd_mad_reg_unpack_cb_t reg_unpack_cb;
    void                  * reg_unpack_context;
};

struct sxd_emad_raw_reg_ext_data {
    sxd_reg_id_e           reg_id;
    struct ku_raw_reg_ext *raw;
};

struct sxd_emad_raw_reg_data {
    sxd_reg_id_e       reg_id;
    struct ku_raw_reg *raw;
};
struct sxd_emad_general_reg_data {
    sxd_emad_common_data_t common;
    const void           * reg_data;
};

typedef void (*sxd_sniffer_print_data_cb_t)(const char *data, sxd_reg_id_e reg_id, sxd_emad_send_receive_e emad_state);

typedef sxd_status_t (*sxd_emad_parse_cb_t)(const struct sxd_emad_general_reg_data *reg_common_data,
                                            void                                   *reg_buff,
                                            uint32_t                               *reg_size,
                                            void                                   *parser_context,
                                            sxd_sniffer_print_data_cb_t             print_data);

typedef sxd_status_t (*sxd_emad_deparse_cb_t)(struct sxd_emad_general_reg_data *reg_common_data,
                                              const void                       *reg_buff,
                                              void                             *context,
                                              sxd_sniffer_print_data_cb_t       print_data);

typedef uint32_t (*sxd_emad_dynamic_arr_num_get_cb_t)(void *reg_data);


struct access_reg_emad_params {
    sxd_emad_parse_cb_t               parse_cb;
    void                            * parse_context;
    sxd_emad_deparse_cb_t             deparse_cb;
    void                            * deparse_context;
    sxd_emad_dynamic_arr_num_get_cb_t dynamic_arr_num_get_cb;
};
struct sxd_register_info {
    char      name[REGISTER_NAME_MAX_LEN + 1];
    uint32_t  emad_struct_size;
    uint32_t  reg_struct_size;
    boolean_t is_dynamic;
    uint32_t  dynamic_item_size;
    uint32_t  dynamic_item_prm_size;
    uint32_t  reg_struct_prm_size;
    uint32_t  blank_reg_size;
};
struct sxd_register_sniffer_info {
    boolean_t                   valid;
    char                      * ctrl_cmd_name;
    enum ku_ctrl_cmd_access_reg ctrl_cmd;
    uint32_t                    ctrl_cmd_size;
};

sxd_status_t sxd_register_init(sxd_reg_id_e                            reg_id,
                               const struct sxd_register_info        * reg_info,
                               const struct sxd_register_sniffer_info* sniffer_info,
                               const struct access_reg_ifc_params    * ifc_params,
                               struct access_reg_mad_params          * mad_params,
                               const struct access_reg_emad_params   * emad_params);

void sxd_register_infra_init(void);
void sxd_register_infra_deinit(void);

const char* REG_ID_TO_NAME(sxd_reg_id_e reg_id);
struct sxd_register_info        * sxd_register_get_info(sxd_reg_id_e reg_id);
const struct sxd_register_sniffer_info* sxd_register_get_sniffer_info(enum ku_ctrl_cmd_access_reg ctrl_cmd);

sxd_status_t sxd_register_deparse(sxd_reg_id_e                      reg_id,
                                  struct sxd_emad_general_reg_data* reg_data,
                                  const void                      * reg_buff,
                                  sxd_sniffer_print_data_cb_t       print_data);

sxd_status_t sxd_access_reg_common(void                   * ku_reg_data,
                                   const sxd_reg_meta_t   * reg_meta,
                                   uint32_t                 data_num,
                                   sxd_completion_handler_t handler,
                                   void                   * handler_context,
                                   sxd_reg_id_e             reg_id);

const struct access_reg_emad_params* sxd_register_get_emad_params(sxd_reg_id_e reg_id);

#endif /* __SXD_ACCESS_REG_INFRA_H__ */
