/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#ifndef __SXD_ACCESS_REG_COMMON_H__
#define __SXD_ACCESS_REG_COMMON_H__

/************************************************
 *  Global function declarations
 ***********************************************/

/* Modules by lexicographic order */

/* Auto generated registers  */
/* ========================= */
void sxd_reg_auto_init(void);

/* Registers of module 'acl' */
/* ========================== */

void sxd_reg_ppbmi_init(void);
/* Registers of module 'cos' */
/* ========================= */
void sxd_reg_sbdcc_init(void);
void sxd_reg_sbdcm_init(void);
void sxd_reg_qhll_init(void);
void sxd_reg_mtpptr_init(void);
void sxd_reg_qpsc_init(void);
void sxd_reg_mtpppc_init(void);

/* Registers of module 'gc' */
/* ======================== */
void sxd_reg_mrrr_init(void);

/* Registers of module 'host ifc' */
/* ============================== */
void sxd_reg_htac_init(void);
void sxd_reg_hopf_init(void);

/* Registers of module 'mpls' */
/* ========================== */
void sxd_reg_mpibe_init(void);

/* Registers of module 'port' */
/* ========================== */
void sxd_reg_ppaos_init(void);         /* PPAOS */
void sxd_reg_pcnr_init(void);          /* PCNR */
void sxd_reg_pvlc_init(void);          /* PVLC */
void sxd_reg_pmaos_init(void);         /* PMAOS */

/* Registers of module 'system'/'management' */
/* ========================== */
void sxd_reg_mfsm_init(void);
void sxd_reg_mcia_init(void);
void sxd_reg_mfm_init(void);
void sxd_reg_mhsr_init(void);
void sxd_reg_mfsc_init(void);
void sxd_reg_ppbmp_init(void);
void sxd_reg_ppbmc_init(void);
void sxd_reg_ptce3_init(void);
void sxd_reg_perpt_init(void);
void sxd_reg_percr_init(void);
void sxd_reg_pererp_init(void);
void sxd_reg_peabfe_init(void);
void sxd_reg_ibsni_init(void);
void sxd_reg_nv_switch_conf_init(void);


/* Registers of module 'tele' */
/* ========================== */
void sxd_reg_sbhrr_init(void);
void sxd_reg_sbhbr_init(void);
void sxd_reg_sbctc_init(void);


/* Registers of module 'lag' */
/* ========================== */
void sxd_reg_slcr_v2_init(void);

#endif /* __SXD_ACCESS_REG_COMMON_H__ */
