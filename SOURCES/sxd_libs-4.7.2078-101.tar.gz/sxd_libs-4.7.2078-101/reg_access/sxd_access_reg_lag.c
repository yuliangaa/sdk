/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */


#include <complib/cl_byteswap_osd.h>
#include <sx/sxd/sxd_emad_common_data.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_emad_lag_reg.h>

#include <reg_access/sxd_access_reg_infra.h>

/************************************************
 *  Global variables
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

/*
 *  SLCR_V2 - Configures the LAG hash fields. Note that there is also support
 *  for SLCR which does the same function
 *
 */


static sxd_status_t __slcr_v2_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                         void                                  * reg_buff,
                                         uint32_t                              * reg_size,
                                         void                                  * context,
                                         sxd_sniffer_print_data_cb_t             print_data)
{
    uint32_t                i = 0;
    struct ku_slcr_v2_reg * slcr_v2_data = (struct ku_slcr_v2_reg*)reg_common_data->reg_data;
    sxd_emad_slcr_v2_reg_t* slcr_v2_reg = (sxd_emad_slcr_v2_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    slcr_v2_reg->pp = slcr_v2_data->pp & 0x1;
    slcr_v2_reg->local_port = slcr_v2_data->local_port;
    slcr_v2_reg->msb_and_sh = (slcr_v2_data->lp_msb & 0x3) << 4;
    slcr_v2_reg->msb_and_sh |= slcr_v2_data->sh & 0x1;
    slcr_v2_reg->type = ((uint8_t)slcr_v2_data->type) & 0xf;
    slcr_v2_reg->seed = cl_hton32(slcr_v2_data->seed);
    slcr_v2_reg->general_fields = cl_hton32(slcr_v2_data->general_fields);
    slcr_v2_reg->outer_header_enables = cl_hton16(slcr_v2_data->outer_header_enables);
    for (i = 0; i < 5; i++) {
        slcr_v2_reg->outer_header_fields_enable[i] = cl_hton32(slcr_v2_data->outer_header_fields_enable[4 - i]);
    }
    slcr_v2_reg->inner_header_enables = cl_hton16(slcr_v2_data->inner_header_enables);
    slcr_v2_reg->inner_header_fields_enable = cl_hton64(slcr_v2_data->inner_header_fields_enable);

    *reg_size = sizeof(sxd_emad_slcr_v2_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __slcr_v2_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                           const void                      * reg_buff,
                                           void                            * context,
                                           sxd_sniffer_print_data_cb_t       print_data)
{
    uint32_t                      i = 0;
    struct ku_slcr_v2_reg       * slcr_v2_data = (struct ku_slcr_v2_reg*)reg_common_data->reg_data;
    const sxd_emad_slcr_v2_reg_t* slcr_v2_reg = (const sxd_emad_slcr_v2_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    slcr_v2_data->sh = slcr_v2_reg->msb_and_sh & 0x1;
    slcr_v2_data->lp_msb = (slcr_v2_reg->msb_and_sh >> 4) & 0x3;
    slcr_v2_data->type = (slcr_v2_hash_type_e)(slcr_v2_reg->type & 0xf);
    slcr_v2_data->seed = cl_hton32(slcr_v2_reg->seed);
    slcr_v2_data->general_fields = cl_hton32(slcr_v2_reg->general_fields);
    slcr_v2_data->outer_header_enables = cl_ntoh16(slcr_v2_reg->outer_header_enables);
    for (i = 0; i < 5; i++) {
        slcr_v2_data->outer_header_fields_enable[i] = cl_ntoh32(slcr_v2_reg->outer_header_fields_enable[4 - i]);
    }
    slcr_v2_data->inner_header_enables = cl_ntoh16(slcr_v2_reg->inner_header_enables);
    slcr_v2_data->inner_header_fields_enable = cl_ntoh64(slcr_v2_reg->inner_header_fields_enable);

    return SXD_STATUS_SUCCESS;
}

void sxd_reg_slcr_v2_init(void)
{
    const struct access_reg_ifc_params     ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_SLCR_V2
    };
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __slcr_v2_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __slcr_v2_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "slcr_v2",
        .emad_struct_size = sizeof(sxd_emad_slcr_v2_reg_t),
        .reg_struct_size = sizeof(struct ku_slcr_v2_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_SLCR_V2",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_SLCR_V2,
        .ctrl_cmd_size = sizeof(struct ku_access_slcr_v2_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_SLCR_V2_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}
