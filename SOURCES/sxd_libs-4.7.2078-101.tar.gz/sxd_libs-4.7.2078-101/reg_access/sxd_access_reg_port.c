/*
 * SPDX-FileCopyrightText: Copyright (c) 2010-2024 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
 * SPDX-License-Identifier: LicenseRef-NvidiaProprietary
 *
 * NVIDIA CORPORATION, its affiliates and licensors retain all intellectual
 * property and proprietary rights in and to this material, related
 * documentation and any modifications thereto. Any use, reproduction,
 * disclosure or distribution of this material and related documentation
 * without an express license agreement from NVIDIA CORPORATION or
 * its affiliates is strictly prohibited.
 */

#include <complib/cl_byteswap_osd.h>
#include <sx/sxd/sxd_emad_common_data.h>
#include <sx/sxd/sxd_emad_port_reg.h>
#include <sx/sxd/sxd_access_register.h>

#ifdef IB_PRESENT_FLAG
#include <infiniband/mad.h>
#include "access_register_mad.h"
#endif /* IB_PRESENT_FLAG */

#include <reg_access/sxd_access_reg_infra.h>


/* ******************************************************************************************************* */
/* PCNR - PHY configuration register                                                                       */
/* ******************************************************************************************************* */

static sxd_status_t __pcnr_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_pcnr_reg * pcnr_data = (struct ku_pcnr_reg*)reg_common_data->reg_data;
    sxd_emad_pcnr_reg_t* pcnr_reg = (sxd_emad_pcnr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    pcnr_reg->local_port = pcnr_data->local_port;
    pcnr_reg->lp_msb = (pcnr_data->lp_msb & 0x03) << 4;
    pcnr_reg->tuning_override = pcnr_data->tuning_override & 0x1;
    *reg_size = sizeof(sxd_emad_pcnr_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __pcnr_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_pcnr_reg       * pcnr_data = (struct ku_pcnr_reg*)reg_common_data->reg_data;
    const sxd_emad_pcnr_reg_t* pcnr_reg = (const sxd_emad_pcnr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    pcnr_data->tuning_override = pcnr_reg->tuning_override & 0x1;

    return SXD_STATUS_SUCCESS;
}

void sxd_reg_pcnr_init(void)
{
    const struct access_reg_ifc_params     ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PCNR
    };
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __pcnr_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __pcnr_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "pcnr",
        .emad_struct_size = sizeof(sxd_emad_pcnr_reg_t),
        .reg_struct_size = sizeof(struct ku_pcnr_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_PCNR",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PCNR,
        .ctrl_cmd_size = sizeof(struct ku_access_pcnr_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_PCNR_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

#define PPAOS_REG_SIZE_IN_DWORDS (4)

/************************************************
 *  Local function declarations
 ***********************************************/


/************************************************
 *  Function implementations
 ***********************************************/

static sxd_status_t __ppaos_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_ppaos_reg * ppaos_data = (struct ku_ppaos_reg*)reg_common_data->reg_data;
    sxd_emad_ppaos_reg_t* ppaos_reg = (sxd_emad_ppaos_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    ppaos_reg->swid = ppaos_data->swid;
    ppaos_reg->local_port = ppaos_data->local_port;
    ppaos_reg->msb_and_phy_test_mode_admin = ((ppaos_data->lp_msb & 0x3) << 4);
    ppaos_reg->msb_and_phy_test_mode_admin |= (ppaos_data->phy_test_mode_admin & 0x0F);

    *reg_size = (uint32_t)sizeof(sxd_emad_ppaos_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __ppaos_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_ppaos_reg       * ppaos_data = (struct ku_ppaos_reg*)reg_common_data->reg_data;
    const sxd_emad_ppaos_reg_t* ppaos_reg = (const sxd_emad_ppaos_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    ppaos_data->phy_test_mode_admin = (ppaos_reg->msb_and_phy_test_mode_admin & 0x0F);
    ppaos_data->phy_test_mode_status = (ppaos_reg->phy_test_mode_status & 0x0F);

    return SXD_STATUS_SUCCESS;
}
#ifdef IB_PRESENT_FLAG
static uint32_t __ppaos_mad_pack(const void* ku_reg_buff, uint8_t* packed_buffer, void* context)
{
    const struct ku_ppaos_reg* ppaos_data = (const struct ku_ppaos_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    push_to_buff(packed_buffer, 0, 8, ppaos_data->swid);
    push_to_buff(packed_buffer, 8, 8, ppaos_data->local_port);
    push_to_buff(packed_buffer, 20, 4, ppaos_data->phy_test_mode_admin);

    return 4 * PPAOS_REG_SIZE_IN_DWORDS;
}


static void __ppaos_mad_unpack(void* ku_reg_buff, uint8_t* buffer_to_unpack, void* context)
{
    struct ku_ppaos_reg* ppaos_data = (struct ku_ppaos_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    ppaos_data->phy_test_mode_admin = pop_from_buff(buffer_to_unpack, 20, 4);
    ppaos_data->phy_test_mode_status = pop_from_buff(buffer_to_unpack, 28, 4);
}
#endif /* IB_PRESENT_FLAG */

void sxd_reg_ppaos_init(void)
{
    const struct access_reg_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PPAOS
    };

#ifdef IB_PRESENT_FLAG
    struct access_reg_mad_params mad_params = {
        .reg_size_in_dwords = PPAOS_REG_SIZE_IN_DWORDS,
        .reg_pack_cb = __ppaos_mad_pack,
        .reg_pack_context = NULL,
        .reg_unpack_cb = __ppaos_mad_unpack,
        .reg_unpack_context = NULL
    };
#endif /* IB_PRESENT_FLAG */
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __ppaos_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __ppaos_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "ppaos",
        .emad_struct_size = sizeof(sxd_emad_ppaos_reg_t),
        .reg_struct_size = sizeof(struct ku_ppaos_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_PPAOS",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PPAOS,
        .ctrl_cmd_size = sizeof(struct ku_access_ppaos_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_PPAOS_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
#ifdef IB_PRESENT_FLAG
                           &mad_params,
#else /* IB_PRESENT_FLAG */
                           NULL,
#endif /* IB_PRESENT_FLAG */
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* PVLC                                                                                                    */
/* ******************************************************************************************************* */

#define PVLC_REG_SIZE_IN_DWORDS (4)

static sxd_status_t __pvlc_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_pvlc_reg * pvlc_data = (struct ku_pvlc_reg*)reg_common_data->reg_data;
    sxd_emad_pvlc_reg_t* pvlc_reg = (sxd_emad_pvlc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    pvlc_reg->local_port = pvlc_data->local_port;
    pvlc_reg->vl_hw_cap = pvlc_data->vl_cap & 0xf;
    pvlc_reg->vl_admin = pvlc_data->vl_admin & 0xf;
    pvlc_reg->vl_operational = pvlc_data->vl_operational & 0xf;

    *reg_size = sizeof(sxd_emad_pvlc_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __pvlc_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_pvlc_reg       * pvlc_data = (struct ku_pvlc_reg*)reg_common_data->reg_data;
    const sxd_emad_pvlc_reg_t* pvlc_reg = (const sxd_emad_pvlc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    pvlc_data->local_port = pvlc_reg->local_port;
    pvlc_data->vl_cap = pvlc_reg->vl_hw_cap & 0xf;
    pvlc_data->vl_admin = pvlc_reg->vl_admin & 0xf;
    pvlc_data->vl_operational = pvlc_reg->vl_operational & 0xf;

    return SXD_STATUS_SUCCESS;
}


#ifdef IB_PRESENT_FLAG
static uint32_t __pvlc_mad_pack(const void* ku_reg_buff, uint8_t* packed_buffer, void* context)
{
    const struct ku_pvlc_reg* pvlc_data = (const struct ku_pvlc_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    push_to_buff(packed_buffer, 8, 8, pvlc_data->local_port);
    push_to_buff(packed_buffer, 60, 4, pvlc_data->vl_cap);
    push_to_buff(packed_buffer, 92, 4, pvlc_data->vl_admin);
    push_to_buff(packed_buffer, 124, 4, pvlc_data->vl_operational);

    return 4 * PVLC_REG_SIZE_IN_DWORDS;
}


static void __pvlc_mad_unpack(void* ku_reg_buff, uint8_t* buffer_to_unpack, void* context)
{
    struct ku_pvlc_reg* pvlc_data = (struct ku_pvlc_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    pvlc_data->local_port = pop_from_buff(buffer_to_unpack, 8, 8);
    pvlc_data->vl_cap = pop_from_buff(buffer_to_unpack, 60, 4);
    pvlc_data->vl_admin = pop_from_buff(buffer_to_unpack, 92, 4);
    pvlc_data->vl_operational = pop_from_buff(buffer_to_unpack, 124, 4);
}
#endif /* IB_PRESENT_FLAG */


void sxd_reg_pvlc_init(void)
{
    const struct access_reg_ifc_params  ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PVLC
    };
    const struct access_reg_emad_params emad_params = {
        .parse_cb = __pvlc_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __pvlc_emad_deparse,
        .deparse_context = NULL
    };

#ifdef IB_PRESENT_FLAG
    struct access_reg_mad_params mad_params = {
        .reg_size_in_dwords = PVLC_REG_SIZE_IN_DWORDS,
        .reg_pack_cb = __pvlc_mad_pack,
        .reg_pack_context = NULL,
        .reg_unpack_cb = __pvlc_mad_unpack,
        .reg_unpack_context = NULL
    };
#endif /* IB_PRESENT_FLAG */

    const struct sxd_register_info         reg_info = {
        .name = "pvlc",
        .emad_struct_size = sizeof(sxd_emad_pvlc_reg_t),
        .reg_struct_size = sizeof(struct ku_pvlc_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_PVLC",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PVLC,
        .ctrl_cmd_size = sizeof(struct ku_access_pvlc_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_PVLC_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
#ifdef IB_PRESENT_FLAG
                           &mad_params,
#else /* IB_PRESENT_FLAG */
                           NULL,
#endif /* IB_PRESENT_FLAG */
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* PPBMP                                                                                                    */
/* ******************************************************************************************************* */

#define PPBMP_REG_SIZE_IN_DWORDS (11)

static sxd_status_t __ppbmp_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_ppbmp_reg * ppbmp_data = (struct ku_ppbmp_reg*)reg_common_data->reg_data;
    sxd_emad_ppbmp_reg_t* ppbmp_reg = (sxd_emad_ppbmp_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    ppbmp_reg->local_port = ppbmp_data->local_port;
    ppbmp_reg->pnat_lp_msb = (((ppbmp_data->pnat) & 0x03) << 6) | (((ppbmp_data->lp_msb) & 0x03) << 4);
    ppbmp_reg->monitor_group = (ppbmp_data->monitor_group) & 0xF;
    ppbmp_reg->alarm_th_mantissa = (ppbmp_data->monitor_params.alarm_th_mantissa) & 0xF;
    ppbmp_reg->alarm_th_exp = ppbmp_data->monitor_params.alarm_th_exp;
    ppbmp_reg->warning_th_mantissa = (ppbmp_data->monitor_params.warning_th_mantissa) & 0xF;
    ppbmp_reg->warning_th_exp = ppbmp_data->monitor_params.warning_th_exp;
    ppbmp_reg->normal_th_mantissa = (ppbmp_data->monitor_params.normal_th_mantissa) & 0xF;
    ppbmp_reg->normal_th_exp = ppbmp_data->monitor_params.normal_th_exp;

    *reg_size = sizeof(sxd_emad_ppbmp_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __ppbmp_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_ppbmp_reg       * ppbmp_data = (struct ku_ppbmp_reg*)reg_common_data->reg_data;
    const sxd_emad_ppbmp_reg_t* ppbmp_reg = (const sxd_emad_ppbmp_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    ppbmp_data->monitor_params.alarm_th_mantissa = (ppbmp_reg->alarm_th_mantissa) & 0xF;
    ppbmp_data->monitor_params.alarm_th_exp = ppbmp_reg->alarm_th_exp;
    ppbmp_data->monitor_params.warning_th_mantissa = (ppbmp_reg->warning_th_mantissa) & 0xF;
    ppbmp_data->monitor_params.warning_th_exp = ppbmp_reg->warning_th_exp;
    ppbmp_data->monitor_params.normal_th_mantissa = (ppbmp_reg->normal_th_mantissa) & 0xF;
    ppbmp_data->monitor_params.normal_th_exp = ppbmp_reg->normal_th_exp;

    return SXD_STATUS_SUCCESS;
}

#ifdef IB_PRESENT_FLAG
static uint32_t __ppbmp_mad_pack(const void* ku_reg_buff, uint8_t* packed_buffer, void* context)
{
    const struct ku_ppbmp_reg* ppbmp_data = (const struct ku_ppbmp_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    push_to_buff(packed_buffer, 8, 8, ppbmp_data->local_port);
    push_to_buff(packed_buffer, 16, 2, ppbmp_data->pnat);
    push_to_buff(packed_buffer, 28, 4, ppbmp_data->monitor_group);
    push_to_buff(packed_buffer, 36, 4, ppbmp_data->monitor_params.alarm_th_mantissa);
    push_to_buff(packed_buffer, 40, 8, ppbmp_data->monitor_params.alarm_th_exp);
    push_to_buff(packed_buffer, 52, 4, ppbmp_data->monitor_params.warning_th_mantissa);
    push_to_buff(packed_buffer, 56, 8, ppbmp_data->monitor_params.warning_th_exp);
    push_to_buff(packed_buffer, 68, 4, ppbmp_data->monitor_params.normal_th_mantissa);
    push_to_buff(packed_buffer, 72, 8, ppbmp_data->monitor_params.normal_th_exp);
    /* return register size in bytes */
    return 4 * PPBMP_REG_SIZE_IN_DWORDS;
}

static void __ppbmp_mad_unpack(void* ku_reg_buff, uint8_t* buffer_to_unpack, void* context)
{
    struct ku_ppbmp_reg* ppbmp_data = (struct ku_ppbmp_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    ppbmp_data->monitor_params.alarm_th_mantissa = pop_from_buff(buffer_to_unpack, 36, 4);
    ppbmp_data->monitor_params.alarm_th_exp = pop_from_buff(buffer_to_unpack, 40, 8);
    ppbmp_data->monitor_params.warning_th_mantissa = pop_from_buff(buffer_to_unpack, 52, 4);
    ppbmp_data->monitor_params.warning_th_exp = pop_from_buff(buffer_to_unpack, 56, 8);
    ppbmp_data->monitor_params.normal_th_mantissa = pop_from_buff(buffer_to_unpack, 68, 4);
    ppbmp_data->monitor_params.normal_th_exp = pop_from_buff(buffer_to_unpack, 72, 8);
}
#endif /* IB_PRESENT_FLAG */

void sxd_reg_ppbmp_init()
{
    const struct access_reg_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PPBMP
    };

#ifdef IB_PRESENT_FLAG
    struct access_reg_mad_params mad_params = {
        .reg_size_in_dwords = PPBMP_REG_SIZE_IN_DWORDS,
        .reg_pack_cb = __ppbmp_mad_pack,
        .reg_pack_context = NULL,
        .reg_unpack_cb = __ppbmp_mad_unpack,
        .reg_unpack_context = NULL
    };
#endif /* IB_PRESENT_FLAG */

    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __ppbmp_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __ppbmp_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "ppbmp",
        .emad_struct_size = sizeof(sxd_emad_ppbmp_reg_t),
        .reg_struct_size = sizeof(struct ku_ppbmp_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_PPBMP",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PPBMP,
        .ctrl_cmd_size = sizeof(struct ku_access_ppbmp_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_PPBMP_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
#ifdef IB_PRESENT_FLAG
                           &mad_params,
#else /* IB_PRESENT_FLAG */
                           NULL,
#endif /* IB_PRESENT_FLAG */
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


/* ******************************************************************************************************* */
/* PPBMC                                                                                                    */
/* ******************************************************************************************************* */

#define PPBMC_REG_SIZE_IN_DWORDS (4)

static sxd_status_t __ppbmc_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_ppbmc_reg * ppbmc_data = (struct ku_ppbmc_reg*)reg_common_data->reg_data;
    sxd_emad_ppbmc_reg_t* ppbmc_reg = (sxd_emad_ppbmc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    ppbmc_reg->local_port = ppbmc_data->local_port;
    ppbmc_reg->pnat_msb_monitor_type = (ppbmc_data->monitor_type) & 0xF;
    ppbmc_reg->pnat_msb_monitor_type |= (ppbmc_data->lp_msb & 0x03) << 4;
    ppbmc_reg->pnat_msb_monitor_type |= ((ppbmc_data->pnat) & 0x3) << 6;
    ppbmc_reg->monitor_ctrl = (ppbmc_data->monitor_ctrl) & 0xF;
    ppbmc_reg->e_event_ctrl = ((ppbmc_data->e) & 0x03) << 6 | ((ppbmc_data->event_ctrl) & 0xF);

    *reg_size = sizeof(sxd_emad_ppbmc_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __ppbmc_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_ppbmc_reg       * ppbmc_data = (struct ku_ppbmc_reg*)reg_common_data->reg_data;
    const sxd_emad_ppbmc_reg_t* ppbmc_reg = (const sxd_emad_ppbmc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    ppbmc_data->monitor_type = (ppbmc_reg->pnat_msb_monitor_type) & 0xF;
    ppbmc_data->e = ((ppbmc_reg->e_event_ctrl) >> 6) & 0x03;
    ppbmc_data->event_ctrl = (ppbmc_reg->e_event_ctrl) & 0xF;
    ppbmc_data->monitor_ctrl = (ppbmc_reg->monitor_ctrl) & 0xF;
    ppbmc_data->monitor_state = ppbmc_reg->monitor_state;

    return SXD_STATUS_SUCCESS;
}

#ifdef IB_PRESENT_FLAG
static uint32_t __ppbmc_mad_pack(const void* ku_reg_buff, uint8_t* packed_buffer, void* context)
{
    const struct ku_ppbmc_reg* ppbmc_data = (const struct ku_ppbmc_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    push_to_buff(packed_buffer, 8, 8,  ppbmc_data->local_port);
    push_to_buff(packed_buffer, 16, 2, ppbmc_data->pnat);
    push_to_buff(packed_buffer, 32, 2, ppbmc_data->e);
    push_to_buff(packed_buffer, 36, 4, ppbmc_data->event_ctrl);
    push_to_buff(packed_buffer, 44, 4, ppbmc_data->monitor_ctrl);
    push_to_buff(packed_buffer, 56, 8, ppbmc_data->monitor_state);
    /* return register size in bytes */
    return 4 * PPBMC_REG_SIZE_IN_DWORDS;
}

static void __ppbmc_mad_unpack(void* ku_reg_buff, uint8_t* buffer_to_unpack, void* context)
{
    struct ku_ppbmc_reg* ppbmc_data = (struct ku_ppbmc_reg*)ku_reg_buff;

    UNUSED_PARAM(context);

    ppbmc_data->monitor_type = pop_from_buff(buffer_to_unpack, 20, 4);
    ppbmc_data->e = pop_from_buff(buffer_to_unpack, 32, 2);
    ppbmc_data->event_ctrl = pop_from_buff(buffer_to_unpack, 36, 4);
    ppbmc_data->monitor_ctrl = pop_from_buff(buffer_to_unpack, 44, 4);
    ppbmc_data->monitor_state = pop_from_buff(buffer_to_unpack, 56, 8);
}
#endif /* IB_PRESENT_FLAG */

void sxd_reg_ppbmc_init()
{
    const struct access_reg_ifc_params ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PPBMC
    };

#ifdef IB_PRESENT_FLAG
    struct access_reg_mad_params mad_params = {
        .reg_size_in_dwords = PPBMC_REG_SIZE_IN_DWORDS,
        .reg_pack_cb = __ppbmc_mad_pack,
        .reg_pack_context = NULL,
        .reg_unpack_cb = __ppbmc_mad_unpack,
        .reg_unpack_context = NULL
    };
#endif /* IB_PRESENT_FLAG */

    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __ppbmc_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __ppbmc_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "ppbmc",
        .emad_struct_size = sizeof(sxd_emad_ppbmc_reg_t),
        .reg_struct_size = sizeof(struct ku_ppbmc_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_PPBMC",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PPBMC,
        .ctrl_cmd_size = sizeof(struct ku_access_ppbmc_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_PPBMC_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
#ifdef IB_PRESENT_FLAG
                           &mad_params,
#else /* IB_PRESENT_FLAG */
                           NULL,
#endif /* IB_PRESENT_FLAG */
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

/* ******************************************************************************************************* */
/* MTPPPC                                                                                                    */
/* ******************************************************************************************************* */

#define MTPPPC_REG_SIZE_IN_DWORDS (11)
static sxd_status_t __mtpppc_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                        void                                  * reg_buff,
                                        uint32_t                              * reg_size,
                                        void                                  * context,
                                        sxd_sniffer_print_data_cb_t             print_data)
{
    const struct ku_mtpppc_reg * mtpppc_data = (struct ku_mtpppc_reg*)reg_common_data->reg_data;
    sxd_emad_mtpppc_reg_t      * mtpppc_reg = (sxd_emad_mtpppc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mtpppc_reg->egr_timestape_message_type = (mtpppc_data->egr_timestape_message_type);
    mtpppc_reg->ing_timestape_message_type = (mtpppc_data->ing_timestape_message_type);
    mtpppc_reg->gm_local_port_0 = (mtpppc_data->gm_local_port_0);
    mtpppc_reg->gm_local_port_1 = (mtpppc_data->gm_local_port_1);
    mtpppc_reg->we = (mtpppc_data->we) & 0xF;

    *reg_size = sizeof(sxd_emad_mtpppc_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __mtpppc_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                          const void                      * reg_buff,
                                          void                            * context,
                                          sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_mtpppc_reg       * mtpppc_data = (struct ku_mtpppc_reg*)reg_common_data->reg_data;
    const sxd_emad_mtpppc_reg_t* mtpppc_reg = (const sxd_emad_mtpppc_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mtpppc_data->egr_timestape_message_type = (mtpppc_reg->egr_timestape_message_type);
    mtpppc_data->ing_timestape_message_type = (mtpppc_reg->ing_timestape_message_type);
    mtpppc_data->gm_local_port_0 = (mtpppc_reg->gm_local_port_0);
    mtpppc_data->gm_local_port_1 = (mtpppc_reg->gm_local_port_1);
    return SXD_STATUS_SUCCESS;
}

void sxd_reg_mtpppc_init(void)
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __mtpppc_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __mtpppc_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "mtpppc",
        .emad_struct_size = sizeof(sxd_emad_mtpppc_reg_t),
        .reg_struct_size = sizeof(struct ku_mtpppc_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_MTPPPC",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MTPPPC,
        .ctrl_cmd_size = sizeof(struct ku_access_mtpppc_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_MTPPPC_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}
