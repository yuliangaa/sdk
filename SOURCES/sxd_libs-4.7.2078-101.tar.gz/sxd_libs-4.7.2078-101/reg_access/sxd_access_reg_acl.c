/*
 * Copyright (C) 2010-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include <complib/cl_byteswap_osd.h>
#include <sx/sxd/sxd_emad_common_data.h>
#include <sx/sxd/sxd_access_register.h>
#include <sx/sxd/sxd_emad_acl_reg.h>

#ifdef IB_PRESENT_FLAG
#include <infiniband/mad.h>
#include "access_register_mad.h"
#endif /* IB_PRESENT_FLAG */

#include <reg_access/sxd_access_reg_infra.h>

/* ******************************************************************************************************* */
/* PPBMI - Policy Based MPLS ILM Register                                                                  */
/* ******************************************************************************************************* */

static sxd_status_t __ppbmi_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    const struct ku_ppbmi_reg * ppbmi_data = (struct ku_ppbmi_reg*)reg_common_data->reg_data;
    sxd_emad_ppbmi_reg_t      * ppbmi_reg = (sxd_emad_ppbmi_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    ppbmi_reg->ilm_index = cl_hton32(ppbmi_data->ilm_index & 0xffffff);
    ppbmi_reg->nhlfe_index = cl_hton32(ppbmi_data->nhlfe_index & 0xffffff);
    ppbmi_reg->npop = ppbmi_data->npop & 0x3;
    ppbmi_reg->ecmp_size = cl_hton16(ppbmi_data->ecmp_size & 0x1fff);
    *reg_size = sizeof(sxd_emad_ppbmi_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __ppbmi_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_ppbmi_reg       * ppbmi_data = (struct ku_ppbmi_reg*)reg_common_data->reg_data;
    const sxd_emad_ppbmi_reg_t* ppbmi_reg = (const sxd_emad_ppbmi_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    ppbmi_data->ilm_index = cl_ntoh32(ppbmi_reg->ilm_index) & 0xffffff;
    ppbmi_data->nhlfe_index = cl_ntoh32(ppbmi_reg->nhlfe_index) & 0xffffff;
    ppbmi_data->npop = ppbmi_reg->npop & 0x3;
    ppbmi_data->ecmp_size = cl_ntoh16(ppbmi_reg->ecmp_size) & 0x1fff;

    return SXD_STATUS_SUCCESS;
}


void sxd_reg_ppbmi_init(void)
{
    const struct access_reg_emad_params emad_params = {
        .parse_cb = __ppbmi_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __ppbmi_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info      reg_info = {
        .name = "ppbmi",
        .emad_struct_size = sizeof(sxd_emad_ppbmi_reg_t),
        .reg_struct_size = sizeof(struct ku_ppbmi_reg)
    };
    sxd_status_t                        st;

    st = sxd_register_init(SXD_REG_ID_PPBMI_E,
                           &reg_info,
                           NULL,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}


static sxd_status_t __ptce3_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_ptce3_reg * ptce3_data = (struct ku_ptce3_reg*)reg_common_data->reg_data;
    sxd_emad_ptce3_reg_t* ptce3_reg = (sxd_emad_ptce3_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    ptce3_reg->valid = (ptce3_data->valid & 0x1) << 7;
    ptce3_reg->op = (ptce3_data->op & 0x7) << 4;
    ptce3_reg->dup = ptce3_data->dup & 0x1f;
    ptce3_reg->priority = cl_hton32(ptce3_data->priority & 0xffffff);
    memcpy(ptce3_reg->tcam_region_info, ptce3_data->tcam_region_info, SXD_TCAM_REGION_INFO_SIZE_BYTES);
    memcpy(ptce3_reg->flex2_key_blocks, ptce3_data->flex2_key_blocks, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES);
    ptce3_reg->erp_id = ptce3_data->erp_id & 0xf;
    ptce3_reg->delta_start = cl_hton16(ptce3_data->delta_start & 0x3ff);
    ptce3_reg->delta_mask = ptce3_data->delta_mask;
    ptce3_reg->delta_value = ptce3_data->delta_value;
    ptce3_reg->prune_vector = cl_hton16(ptce3_data->prune_vector);
    ptce3_reg->prune_ctcam = (ptce3_data->prune_ctcam & 0x1) << 7;
    ptce3_reg->large_exists_large_entry_key_id =
        cl_hton32(((ptce3_data->large_exists & 0x1) << 31) | (ptce3_data->large_entry_key_id & 0xffffff));
    ptce3_reg->action_pointer = cl_hton32(ptce3_data->action_pointer & 0xffffff);
    ptce3_reg->region_id_dup_1 = cl_hton16(ptce3_data->region_id_dup[0]);
    ptce3_reg->region_id_dup_2 = cl_hton16(ptce3_data->region_id_dup[1]);
    ptce3_reg->region_id_dup_3 = cl_hton16(ptce3_data->region_id_dup[2]);
    ptce3_reg->region_id_dup_4 = cl_hton16(ptce3_data->region_id_dup[3]);
    ptce3_reg->region_id_dup_5 = cl_hton16(ptce3_data->region_id_dup[4]);
    ptce3_reg->region_id_dup_6 = cl_hton16(ptce3_data->region_id_dup[5]);
    ptce3_reg->region_id_dup_7 = cl_hton16(ptce3_data->region_id_dup[6]);
    ptce3_reg->region_id_dup_8 = cl_hton16(ptce3_data->region_id_dup[7]);
    ptce3_reg->region_id_dup_9 = cl_hton16(ptce3_data->region_id_dup[8]);
    ptce3_reg->region_id_dup_10 = cl_hton16(ptce3_data->region_id_dup[9]);
    ptce3_reg->region_id_dup_11 = cl_hton16(ptce3_data->region_id_dup[10]);
    ptce3_reg->region_id_dup_12 = cl_hton16(ptce3_data->region_id_dup[11]);
    ptce3_reg->region_id_dup_13 = cl_hton16(ptce3_data->region_id_dup[12]);
    ptce3_reg->region_id_dup_14 = cl_hton16(ptce3_data->region_id_dup[13]);
    ptce3_reg->region_id_dup_15 = cl_hton16(ptce3_data->region_id_dup[14]);

    *reg_size = (uint32_t)sizeof(sxd_emad_ptce3_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __ptce3_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_ptce3_reg       * ptce3_data = (struct ku_ptce3_reg*)reg_common_data->reg_data;
    const sxd_emad_ptce3_reg_t* ptce3_reg = (const sxd_emad_ptce3_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    ptce3_data->valid = ((ptce3_reg->valid) >> 7) & 0x1;
    ptce3_data->op = ((ptce3_reg->op) >> 4) & 0x7;
    ptce3_data->priority = cl_ntoh32(ptce3_reg->priority) & 0xffffff;
    ptce3_data->delta_start = cl_ntoh16(ptce3_reg->delta_start) & 0x3ff;
    ptce3_data->delta_mask = ptce3_reg->delta_mask;
    ptce3_data->delta_value = ptce3_reg->delta_value;
    ptce3_data->prune_vector = cl_ntoh16(ptce3_reg->prune_vector);
    ptce3_data->prune_ctcam = ((ptce3_reg->prune_ctcam) >> 7) & 0x1;
    ptce3_data->large_entry_key_id = cl_ntoh32(ptce3_reg->large_exists_large_entry_key_id) & 0xffffff;
    ptce3_data->action_pointer = cl_ntoh32(ptce3_reg->action_pointer) & 0xffffff;

    return SXD_STATUS_SUCCESS;
}

void sxd_reg_ptce3_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __ptce3_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __ptce3_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "ptce3",
        .emad_struct_size = sizeof(sxd_emad_ptce3_reg_t),
        .reg_struct_size = sizeof(struct ku_ptce3_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_PTCE3",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PTCE3,
        .ctrl_cmd_size = sizeof(struct ku_access_ptce3_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_PTCE3_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

static sxd_status_t __perpt_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_perpt_reg * perpt_data = (struct ku_perpt_reg*)reg_common_data->reg_data;
    sxd_emad_perpt_reg_t* perpt_reg = (sxd_emad_perpt_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    perpt_reg->erpt_bank = perpt_data->erpt_bank & 0xf;
    perpt_reg->erpt_index = perpt_data->erpt_index;
    perpt_reg->key_size = perpt_data->key_size & 0xf;
    perpt_reg->bf_bypass = perpt_data->bf_bypass & 0x1;
    perpt_reg->erp_id = perpt_data->erp_id & 0xf;
    perpt_reg->erpt_base_bank = perpt_data->erpt_base_bank & 0xf;
    perpt_reg->erpt_base_index = perpt_data->erpt_base_index;
    perpt_reg->erp_index_in_vector = perpt_data->erp_index_in_vector & 0xf;
    perpt_reg->erp_vector = cl_hton16(perpt_data->erp_vector);
    memcpy(perpt_reg->mask, perpt_data->mask, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES);

    *reg_size = (uint32_t)sizeof(sxd_emad_perpt_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __perpt_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_perpt_reg       * perpt_data = (struct ku_perpt_reg*)reg_common_data->reg_data;
    const sxd_emad_perpt_reg_t* perpt_reg = (const sxd_emad_perpt_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    perpt_data->erpt_bank = perpt_reg->erpt_bank & 0xf;
    perpt_data->erpt_index = perpt_reg->erpt_index;
    perpt_data->key_size = perpt_reg->key_size & 0xf;
    perpt_data->bf_bypass = perpt_reg->bf_bypass & 0xf;
    perpt_data->erp_id = perpt_reg->erp_id & 0xf;
    perpt_data->erpt_base_bank = perpt_reg->erpt_base_bank & 0xf;
    perpt_data->erpt_base_index = perpt_reg->erpt_base_index;
    perpt_data->erp_index_in_vector = perpt_reg->erp_index_in_vector & 0xf;
    perpt_data->erp_vector = cl_ntoh16(perpt_reg->erp_vector);
    memcpy(perpt_data->mask, perpt_reg->mask, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES);

    return SXD_STATUS_SUCCESS;
}

void sxd_reg_perpt_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __perpt_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __perpt_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "perpt",
        .emad_struct_size = sizeof(sxd_emad_perpt_reg_t),
        .reg_struct_size = sizeof(struct ku_perpt_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_PERPT",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PERPT,
        .ctrl_cmd_size = sizeof(struct ku_access_perpt_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_PERPT_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

static sxd_status_t __percr_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                       void                                  * reg_buff,
                                       uint32_t                              * reg_size,
                                       void                                  * context,
                                       sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_percr_reg * percr_data = (struct ku_percr_reg*)reg_common_data->reg_data;
    sxd_emad_percr_reg_t* percr_reg = (sxd_emad_percr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    percr_reg->region_id = cl_hton16(percr_data->region_id);
    percr_reg->atcam_ctcam_disable_prune =
        (((percr_data->atcam_ignore_prune & 0x1) << 1) | (percr_data->ctcam_ignore_prune & 0x1));
    percr_reg->bf_bypass = percr_data->bf_bypass & 0x1;
    memcpy(percr_reg->master_mask, percr_data->master_mask, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES);

    *reg_size = (uint32_t)sizeof(sxd_emad_percr_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __percr_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                         const void                      * reg_buff,
                                         void                            * context,
                                         sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_percr_reg       * percr_data = (struct ku_percr_reg*)reg_common_data->reg_data;
    const sxd_emad_percr_reg_t* percr_reg = (const sxd_emad_percr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    percr_data->region_id = cl_ntoh16(percr_reg->region_id);
    percr_data->atcam_ignore_prune = (percr_reg->atcam_ctcam_disable_prune >> 1) & 0x1;
    percr_data->ctcam_ignore_prune = percr_reg->atcam_ctcam_disable_prune & 0x1;
    percr_data->bf_bypass = percr_reg->bf_bypass & 0x1;
    memcpy(percr_data->master_mask, percr_reg->master_mask, SXD_ACL_FLEX_KEY_BLOCK_SIZE_BYTES);

    return SXD_STATUS_SUCCESS;
}
void sxd_reg_percr_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __percr_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __percr_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "percr",
        .emad_struct_size = sizeof(sxd_emad_percr_reg_t),
        .reg_struct_size = sizeof(struct ku_percr_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_PERCR",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PERCR,
        .ctrl_cmd_size = sizeof(struct ku_access_percr_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_PERCR_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

static sxd_status_t __pererp_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                        void                                  * reg_buff,
                                        uint32_t                              * reg_size,
                                        void                                  * context,
                                        sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_pererp_reg * pererp_data = (struct ku_pererp_reg*)reg_common_data->reg_data;
    sxd_emad_pererp_reg_t* pererp_reg = (sxd_emad_pererp_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    pererp_reg->region_id = cl_hton16(pererp_data->region_id);
    pererp_reg->ctcam_le = (pererp_data->ctcam_le & 0x1) << 4;
    pererp_reg->erpt_pointer_valid_ctcam_only = (pererp_data->erpt_pointer_valid & 0x1) << 7;
    pererp_reg->erpt_pointer_valid_ctcam_only |= (pererp_data->ctcam_only & 0x1) << 6;
    pererp_reg->erpt_bank_pointer = pererp_data->erpt_bank_pointer & 0xf;
    pererp_reg->erpt_pointer = pererp_data->erpt_pointer;
    pererp_reg->erpt_vector = cl_hton16(pererp_data->erpt_vector);
    pererp_reg->master_rp_id = pererp_data->master_rp_id & 0xf;

    *reg_size = (uint32_t)sizeof(sxd_emad_pererp_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __pererp_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                          const void                      * reg_buff,
                                          void                            * context,
                                          sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_pererp_reg       * pererp_data = (struct ku_pererp_reg*)reg_common_data->reg_data;
    const sxd_emad_pererp_reg_t* pererp_reg = (const sxd_emad_pererp_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    pererp_data->region_id = cl_ntoh16(pererp_reg->region_id);
    pererp_data->ctcam_le = (pererp_reg->ctcam_le >> 4) & 0x1;
    pererp_data->erpt_pointer_valid = (pererp_reg->erpt_pointer_valid_ctcam_only >> 7) & 0x1;
    pererp_data->ctcam_only = (pererp_reg->erpt_pointer_valid_ctcam_only >> 6) & 0x1;
    pererp_data->erpt_bank_pointer = pererp_reg->erpt_bank_pointer & 0xf;
    pererp_data->erpt_pointer = pererp_reg->erpt_pointer;
    pererp_data->erpt_vector = cl_ntoh16(pererp_reg->erpt_vector);
    pererp_data->master_rp_id = pererp_reg->master_rp_id & 0xf;

    return SXD_STATUS_SUCCESS;
}
void sxd_reg_pererp_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __pererp_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __pererp_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "pererp",
        .emad_struct_size = sizeof(sxd_emad_pererp_reg_t),
        .reg_struct_size = sizeof(struct ku_pererp_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_PERERP",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PERERP,
        .ctrl_cmd_size = sizeof(struct ku_access_pererp_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_PERERP_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}

static sxd_status_t __peabfe_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                        void                                  * reg_buff,
                                        uint32_t                              * reg_size,
                                        void                                  * context,
                                        sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_peabfe_reg * peabfe_data = (struct ku_peabfe_reg*)reg_common_data->reg_data;
    sxd_emad_peabfe_reg_t* peabfe_reg = (sxd_emad_peabfe_reg_t*)reg_buff;
    uint16_t               i = 0;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    peabfe_reg->size = cl_hton16(peabfe_data->size & 0x1ff);
    for (i = 0; (i < peabfe_data->size) && (i < SXD_ACL_BLOOM_FILTER_ENTRIES); i++) {
        peabfe_reg->bf_entry[i] = cl_hton32((peabfe_data->bf_entry[i].state & 0x01) << 31);
        peabfe_reg->bf_entry[i] |= cl_hton32((peabfe_data->bf_entry[i].bf_bank & 0x03) << 24);
        peabfe_reg->bf_entry[i] |= cl_hton32(peabfe_data->bf_entry[i].bf_index & 0xffffff);
    }

    *reg_size = (uint32_t)sizeof(sxd_emad_peabfe_reg_t);

    return SXD_STATUS_SUCCESS;
}

static sxd_status_t __peabfe_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                          const void                      * reg_buff,
                                          void                            * context,
                                          sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_peabfe_reg       * peabfe_data = (struct ku_peabfe_reg*)reg_common_data->reg_data;
    const sxd_emad_peabfe_reg_t* peabfe_reg = (const sxd_emad_peabfe_reg_t*)reg_buff;
    uint16_t                     i = 0;
    uint32_t                     bf_entry = 0;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    peabfe_data->size = cl_ntoh16(peabfe_reg->size);
    for (i = 0; i < SXD_ACL_BLOOM_FILTER_ENTRIES; i++) {
        bf_entry = cl_ntoh32(peabfe_reg->bf_entry[i]);
        peabfe_data->bf_entry[i].state = (bf_entry >> 31) & 0x1;
        peabfe_data->bf_entry[i].bf_bank = (bf_entry >> 24) & 0x3;
        peabfe_data->bf_entry[i].bf_index = bf_entry & 0xffffff;
    }
    return SXD_STATUS_SUCCESS;
}

void sxd_reg_peabfe_init()
{
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __peabfe_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __peabfe_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "peabfe",
        .emad_struct_size = sizeof(sxd_emad_peabfe_reg_t),
        .reg_struct_size = sizeof(struct ku_peabfe_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_PEABFE",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_PEABFE,
        .ctrl_cmd_size = sizeof(struct ku_access_peabfe_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_PEABFE_E,
                           &reg_info,
                           &reg_sniffer_info,
                           NULL,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}
