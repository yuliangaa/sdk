/*
 * Copyright (C) 2001-2023 NVIDIA CORPORATION & AFFILIATES, Ltd. ALL RIGHTS RESERVED.
 *
 * This software product is a proprietary product of NVIDIA CORPORATION & AFFILIATES, Ltd.
 * (the "Company") and all right, title, and interest in and to the software product,
 * including all associated intellectual property rights, are and shall
 * remain exclusively with the Company.
 *
 * This software product is governed by the End User License Agreement
 * provided with the software product.
 *
 */

#include "sx/sxd/sxd_emad_system_reg.h"
#include "reg_access/sxd_access_reg_infra.h"
#include "complib/cl_byteswap_osd.h"

/************************************************
 *  Local Defines
 ***********************************************/

/************************************************
 *  Local Macros
 ***********************************************/

/************************************************
 *  Local Type definitions
 ***********************************************/

/************************************************
 *  Local variables
 ***********************************************/

/************************************************
 *  Local function declarations
 ***********************************************/

/************************************************
 *  Function implementations
 ***********************************************/

static sxd_status_t __mrrr_emad_parse(const struct sxd_emad_general_reg_data* reg_common_data,
                                      void                                  * reg_buff,
                                      uint32_t                              * reg_size,
                                      void                                  * context,
                                      sxd_sniffer_print_data_cb_t             print_data)
{
    struct ku_mrrr_reg * mrrr_data = (struct ku_mrrr_reg*)reg_common_data->reg_data;
    sxd_emad_mrrr_reg_t* mrrr_reg = (sxd_emad_mrrr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mrrr_reg->init_rr = mrrr_data->init_rr;
    *reg_size = sizeof(sxd_emad_mrrr_reg_t);

    return SXD_STATUS_SUCCESS;
}


static sxd_status_t __mrrr_emad_deparse(struct sxd_emad_general_reg_data* reg_common_data,
                                        const void                      * reg_buff,
                                        void                            * context,
                                        sxd_sniffer_print_data_cb_t       print_data)
{
    struct ku_mrrr_reg       * mrrr_data = (struct ku_mrrr_reg*)reg_common_data->reg_data;
    const sxd_emad_mrrr_reg_t* mrrr_reg = (const sxd_emad_mrrr_reg_t*)reg_buff;

    UNUSED_PARAM(context);
    UNUSED_PARAM(print_data);

    mrrr_data->rr_status = mrrr_reg->rr_status;

    return SXD_STATUS_SUCCESS;
}

void sxd_reg_mrrr_init(void)
{
    const struct access_reg_ifc_params     ifc_params = {
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MRRR
    };
    const struct access_reg_emad_params    emad_params = {
        .parse_cb = __mrrr_emad_parse,
        .parse_context = NULL,
        .deparse_cb = __mrrr_emad_deparse,
        .deparse_context = NULL
    };
    const struct sxd_register_info         reg_info = {
        .name = "mrrr",
        .emad_struct_size = sizeof(sxd_emad_mrrr_reg_t),
        .reg_struct_size = sizeof(struct ku_mrrr_reg)
    };
    const struct sxd_register_sniffer_info reg_sniffer_info = {
        .ctrl_cmd_name = "CTRL_CMD_ACCESS_REG_MRRR",
        .ctrl_cmd = CTRL_CMD_ACCESS_REG_MRRR,
        .ctrl_cmd_size = sizeof(struct ku_access_mrrr_reg)
    };
    sxd_status_t                           st;

    st = sxd_register_init(SXD_REG_ID_MRRR_E,
                           &reg_info,
                           &reg_sniffer_info,
                           &ifc_params,
                           NULL,
                           &emad_params);

    CL_ASSERT(st == SXD_STATUS_SUCCESS);
}
